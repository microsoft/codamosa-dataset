

# Generated at 2022-06-25 04:21:51.148483
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('&ob69ja.<b~b')
    except Exception as exc:
        assert type(exc).__name__ == 'AnsibleParserError'
        assert str(exc) == "We were unable to read either as JSON nor YAML, these are the errors we got from each:\n" \
                           "JSON: Expecting value: line 1 column 1 (char 0)\n\n" \
                           "The error appears to have been in '&ob69ja.<b~b': line 1, column 1, but may\n" \
                           "be elsewhere in the file depending on the exact syntax problem.\n" \
                           "The offending line appears to be:\n\n" \
                           "&ob69ja.<b~b"
    else:
        assert False, 'expected exception'

# Generated at 2022-06-25 04:21:54.182915
# Unit test for function from_yaml
def test_from_yaml():
    assert(callable(from_yaml))



# Generated at 2022-06-25 04:22:02.900723
# Unit test for function from_yaml
def test_from_yaml():
    print('Test function from_yaml.')
    test_case_0()

    # from ansible.playbook.play import Play
    # from ansible.playbook.task import Task
    # from ansible.playbook.block import Block
    #
    #
    # class SubPlay(Play):
    #     pass
    #
    #
    # class SubTask(Task):
    #     def __init__(self):
    #         Task.__init__(self, is_handler=False, load_from=None)
    #
    #
    # class SubBlock(Block):
    #     def __init__(self):
    #         super(SubBlock, self).__init__(parent_block=None, role=None, task_include=None, use_handlers=True, implicit=True)



# Generated at 2022-06-25 04:22:11.603788
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{' + "'" + 'var_0' + "'" ': ' + "'" + 'hi' + "'" + '}'
    var_0 = from_yaml(str_0, 'str_0')
    assert var_0['var_0'] == 'hi'
    str_0 = '{' + "'" + 'var_0' + "'" ': ' + "'" + 'hey' + "'" + '}'
    var_0 = from_yaml(str_0, 'str_0')
    assert var_0['var_0'] == 'hey'
    str_0 = '{' + "'" + 'var_1' + "'" ': ' + "'" + 'hi' + "'" + '}'

# Generated at 2022-06-25 04:22:20.430629
# Unit test for function from_yaml
def test_from_yaml():
    # Test function from_yaml
    str_0 = '*'
    var_0 = from_yaml(str_0, str_0)

# def main():
if __name__ == '__main__':
    from json import dumps as json_dump
    from sys import argv as sys_argv
    from timeit import timeit

    for arg in sys_argv[1:]:
        with open(arg, 'r') as f:
            print(json_dump(from_yaml(f.read(), arg)))

    test_from_yaml()

    str_0 = '*'
    var_0 = from_yaml(str_0, str_0)
    print(timeit('test_from_yaml()', setup='from __main__ import test_from_yaml'))

# Generated at 2022-06-25 04:22:21.173890
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Function to test module

# Generated at 2022-06-25 04:22:24.457277
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    # var_0: [{'key': '&ob69ja.<b~b'}]
    assert var_0 == [{'key': '&ob69ja.<b~b'}]

# Generated at 2022-06-25 04:22:34.200353
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == '&ob69ja.<b~b'
    str_1 = '&ob69ja.<b~b'
    var_1 = from_yaml(str_1, str_1)
    assert var_1 == '&ob69ja.<b~b'
    str_2 = '~`wg&rp_y'
    var_2 = from_yaml(str_2, str_2)
    assert var_2 == '~`wg&rp_y'
    str_3 = '~`wg&rp_y'
    var_3 = from_yaml(str_3, str_3)
    assert var_3

# Generated at 2022-06-25 04:22:35.232004
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert type(from_yaml('foobar')) == dict
    except Exception as e:
        print(e)

# Generated at 2022-06-25 04:22:46.222438
# Unit test for function from_yaml
def test_from_yaml():
    import random
    import string

    str_chars = string.ascii_letters + string.digits  # string.ascii_letters + string.digits + string.punctuation + ' '*10
    str_size = 2 ** random.randint(0, 14)
    str_0 = ''.join([random.choice(str_chars) for x in range(str_size)])

    # Test with 'file_name' equal to '<string>'
    var_0 = from_yaml(str_0, str_0)

    # Test with 'file_name' equal to '<string>'
    var_0 = from_yaml(str_0, '<string>')

    # Test with 'file_name' equal to '<string>' and 'show_content' equal to False
    var

# Generated at 2022-06-25 04:22:56.519498
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)

    assert var_0 == str_0, var_0

    str_1 = '---\n- &a \'foo\'\n- *a\n...'
    var_1 = from_yaml(str_1, str_1)

    assert var_1 == ['foo', 'foo'], var_1

    str_2 = '\'bar\''
    var_2 = from_yaml(str_2, str_2)

    assert var_2 == u'bar', var_2

    str_3 = '!!bool \'bar\''
    var_3 = from_yaml(str_3, str_3)

    assert isinstance(var_3, bool), var_

# Generated at 2022-06-25 04:23:00.575927
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'

    # testing the values returned by from_yaml
    assert from_yaml(str_0, str_0) is None

    assert from_yaml(str_0, str_0) is None


# Generated at 2022-06-25 04:23:13.147788
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)

    str_1 = 'QJS;!9~V'
    var_1 = from_yaml(str_1, str_1)

    str_2 = 'gXj"t'
    var_2 = from_yaml(str_2, str_2)

    str_3 = 'rC9{zLE2>j'
    var_3 = from_yaml(str_3, str_3)

    str_4 = '&6BzU#69'
    var_4 = from_yaml(str_4, str_4)

    str_5 = 'm(1qY'

# Generated at 2022-06-25 04:23:17.799676
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == "&ob69ja.<b~b"

if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:23:18.436818
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:23:21.310111
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    assert from_yaml('&ob69ja.<b~b') == '&ob69ja.<b~b'
    assert from_yaml('') is None

# Generated at 2022-06-25 04:23:26.960199
# Unit test for function from_yaml
def test_from_yaml():

    # Assert False. Valid assertion is: AssertionError
    try:
        assert False
    except AssertionError as e:
        print('AssertionError: ', e)

    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:33.616016
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'abcd'
    str_0_copy = str_0
    str_1 = 'abcd'
    int_0 = 4
    var_0 = from_yaml(str_1, str_0_copy)
    assert var_0 == str_0
    var_0 = from_yaml(int_0, str_0_copy)
    assert var_0 == int_0

    # test_from_yaml.py
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)

    str_0 = '{from_yaml(str_1, str_0_copy)}'
    str_1 = 'from_yaml(str_1, str_0_copy)'

# Generated at 2022-06-25 04:23:35.176951
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:38.990413
# Unit test for function from_yaml
def test_from_yaml():
    print("Test 0: Basic tests")
    test_case_0()

### Run tests
test_from_yaml()

# Generated at 2022-06-25 04:23:44.587606
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert test_case_0() == ''
    except Exception as e:
        print(e)
        print("FAILED test for function from_yaml")

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:23:46.400886
# Unit test for function from_yaml
def test_from_yaml():
    pass


# Generated at 2022-06-25 04:23:51.213141
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '""'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == None # Object with no representation
    str_1 = '""'
    var_1 = from_yaml(str_1, str_1)
    assert var_1 == None # Object with no representation
    str_2 = '"^/&I/9$\'"'
    var_2 = from_yaml(str_2, str_2)
    assert var_2 == None # Object with no representation


# Generated at 2022-06-25 04:23:55.373608
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_1 = from_yaml(str_0, str_0)
    assert var_1 == None


test_case_0()

# Generated at 2022-06-25 04:23:55.942184
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()



# Generated at 2022-06-25 04:24:04.300197
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    assert from_yaml(str_0, str_0) == '&ob69ja.<b~b', 'Unable to parse &ob69ja.<b~b'

    str_1 = 'b-o@ob69)ja.<b~b'
    assert from_yaml(str_1, str_1) == 'b-o@ob69)ja.<b~b', 'Unable to parse b-o@ob69)ja.<b~b'

    str_2 = '%ob69ja.<b~b'
    assert from_yaml(str_2, str_2) == '%ob69ja.<b~b', 'Unable to parse %ob69ja.<b~b'

# Generated at 2022-06-25 04:24:12.248918
# Unit test for function from_yaml
def test_from_yaml():

    # Normal test case
    #  JSON
    str_0 = 'all'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == 'all'

    #  YAML
    str_1 = '{all: all}'
    var_1 = from_yaml(str_1, str_1)
    assert var_1 == {'all': 'all'}

    #  JSON
    str_2 = 'all'
    var_2 = from_yaml(str_2, str_2)
    assert var_2 == 'all'

    # Exception test case
    #  JSON
    str_3 = '.all'

# Generated at 2022-06-25 04:24:17.741750
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()
    test_case_0()

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:24:26.788028
# Unit test for function from_yaml
def test_from_yaml():
    """
    :return:
    """

    assert from_yaml('{"a": 1}', '<string>') == {'a': 1}
    # assert from_yaml('{"a": 1}', filename='<string>') == {'a': 1}
    # assert from_yaml('{"a": 1}', file_name='<string>') == {'a': 1}
    # assert from_yaml('{"a": 1}', is_valid_json=True) == {'a': 1}

    assert from_yaml('{"a": 1}', '<string>', True) is not None
    assert from_yaml('{"a": 1}', '/tmp/x', False) is not None
    assert from_yaml('{"a": 1}', '/tmp/y', True) is not None
    #

# Generated at 2022-06-25 04:24:36.839504
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit tests for from_yaml
    '''

    str_0 = '-1'
    var_0 = from_yaml(str_0)
    var_1 = -1

    assert var_0 == var_1

    str_0 = '-1'
    var_0 = from_yaml(str_0, str_0)
    var_1 = -1

    assert var_0 == var_1


# Generated at 2022-06-25 04:24:46.868906
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    str_1 = '&ob69ja.<b~b'
    var_1 = from_yaml(str_1, str_1)
    str_2 = '&ob69ja.<b~b'

    try:
        from_yaml(str_2, str_2)
    except AnsibleParserError as exc:
        assert exc.show_content == True



# Generated at 2022-06-25 04:24:55.920142
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'gnij'
    var_0 = from_yaml(str_0, str_0)

    str_1 = 'wyr[k'
    var_1 = from_yaml(str_1, str_1)

    str_2 = 'rsv'
    var_2 = from_yaml(str_2, str_2)

    str_3 = ':u__7'
    var_3 = from_yaml(str_3, str_3)

    str_4 = ':u__7'
    var_4 = from_yaml(str_4, str_4)

    str_5 = ':u__7'
    var_5 = from_yaml(str_5, str_5)

    str_6 = ':u__7'

# Generated at 2022-06-25 04:24:58.733987
# Unit test for function from_yaml
def test_from_yaml():
    print('Testing get_ansible_vars')
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:25:03.621774
# Unit test for function from_yaml
def test_from_yaml():
    arg = '{"b1": [1,2,3]}'
    var = from_yaml(arg, arg)
    assert var == {'b1': [1, 2, 3]}


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:25:13.955976
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') is None
    assert from_yaml('{}') == {}
    assert from_yaml('{}', json_only=True) == {}
    assert from_yaml('{"a": 1}') == {'a': 1}
    assert from_yaml('{"a": 1}', json_only=True) == {'a': 1}
    assert from_yaml('{"a": 1}', '<string>', True) == {'a': 1}
    assert from_yaml('{"a": 1}', '<string>', True, None) == {'a': 1}
    assert from_yaml('{"a": 1}', '<string>', True, None, True) == {'a': 1}

# Generated at 2022-06-25 04:25:14.832383
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)


# Generated at 2022-06-25 04:25:24.054892
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    var_1 = from_yaml(str_0, str_0, False)
    var_2 = from_yaml(str_0, str_0, False, None)
    var_3 = from_yaml(str_0, str_0, False, None, False)
    var_4 = from_yaml(str_0, str_0, False, None, True)
    var_5 = from_yaml(str_0, str_0, False, True, False)
    var_6 = from_yaml(str_0, str_0, False, True, True)

# Generated at 2022-06-25 04:25:27.473560
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    assert(str_0 == var_0)


# Generated at 2022-06-25 04:25:35.422138
# Unit test for function from_yaml
def test_from_yaml():
    # Test basic case
    assert from_yaml('') == None
    assert from_yaml('') == None
    assert from_yaml(b'') == None
    assert from_yaml(0) == None
    assert from_yaml(0.0) == None
    assert from_yaml(1) == None
    assert from_yaml(1.0) == None
    assert from_yaml(1.1) == None
    test_case_0()
    # Test empty file
    assert from_yaml('', '') == None
    assert from_yaml('', '') == None
    assert from_yaml(b'', '') == None
    assert from_yaml(b'', '') == None
    assert from_yaml(0, '') == None
    assert from_yaml

# Generated at 2022-06-25 04:25:39.021932
# Unit test for function from_yaml
def test_from_yaml():
    # 
    # We cannot emulate a YAML file for testing this function.
    # 
    assert True == True



# Generated at 2022-06-25 04:25:42.399454
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:25:45.794397
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'key1: key1_val'
    var_0 = {'key1': 'key1_val'}
    var_1 = from_yaml(str_0)
    assert var_0 == var_1

# Generated at 2022-06-25 04:25:48.329952
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as e:
        print('%s' % e)
        raise

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:25:52.837950
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    assert isinstance(var_0, dict)
    assert not var_0
test_from_yaml()

# Generated at 2022-06-25 04:26:00.193399
# Unit test for function from_yaml
def test_from_yaml():
    print('Unit test for function from_yaml')
    import json
    import random
    import string

# Generated at 2022-06-25 04:26:01.392956
# Unit test for function from_yaml
def test_from_yaml():
    # read_csv
    # test_case_0()
    pass

# Generated at 2022-06-25 04:26:06.620294
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&2h'
    str_1 = '*|31'
    str_2 = '*3&2'
    str_3 = '*l1&1'
    var_0 = from_yaml(str_1, str_0)
    var_1 = from_yaml(str_2, str_3)

    assert var_0 == 31
    assert var_1 == 'l1&1'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:26:15.652172
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == {'session': 'y"M5E5+xI', 'id': 'cnuQz}J'}

    str_0 = 'Gn!2>?1'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == {'session': 's?Mq3[', 'id': '?v['}

    str_0 = ')1:H'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == {'session': '0~.8B', 'id': 'f#'}

    str_0 = '}F'
    var

# Generated at 2022-06-25 04:26:17.911802
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()



# Generated at 2022-06-25 04:26:24.285952
# Unit test for function from_yaml
def test_from_yaml():
    args_0 = dict()
    args_0['data'] = '&ob69ja.<b~b'
    args_0['file_name'] = '&ob69ja.<b~b'
    with pytest.raises(AnsibleParserError):
        from_yaml(**args_0)

# Generated at 2022-06-25 04:26:37.164072
# Unit test for function from_yaml
def test_from_yaml():
    arg_str0 = "test_str"
    arg_bool1 = True
    arg_int2 = 123
    arg_float3 = 1.23
    arg_dict4 = {'foo': 'bar'}
    arg_list5 = ['baz', 'qux']

    # test basic scalars
    assert from_yaml('test_str') == arg_str0
    assert from_yaml('123') == arg_int2
    assert from_yaml('1.23') == arg_float3
    assert from_yaml('true') == arg_bool1

# Generated at 2022-06-25 04:26:45.637983
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = '4 < 2'
    var_1 = from_yaml(str_1, str_1)
    assert var_1 is True
    # Test from_yaml(str_1, str_1) == True with no exceptions
    str_2 = '4 > 2'
    var_2 = from_yaml(str_2, str_2)
    assert var_2 is True
    str_3 = '---\n- [Gaga, Gugus]\n- false'
    var_3 = from_yaml(str_3, str_3)
    str_4 = '---\n- [Gaga, Gugus]\n- false'
    var_4 = from_yaml(str_4, str_4)
    assert var_3 == var_4

# Generated at 2022-06-25 04:26:49.714807
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError):
        str_0 = '&ob69ja.<b~b'
        var_0 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:26:50.911248
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:26:58.516281
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!File \"/etc/cron.d/*\"\nvars:\n  v0: !Var \'{{ v }}\'\n'
    str_1 = '!Vault {\npassword: secret\n}\n'
    var_0 = from_yaml(str_1, str_1)
    var_1 = from_yaml(str_1, str_0)
    str_2 = '\n'.join([str_0, str_1])
    var_2 = from_yaml(str_2, str_2)
    str_3 = '!File \"/etc/cron.d/*\"\n'
    var_3 = from_yaml(str_3, str_3)

# Generated at 2022-06-25 04:27:02.239832
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    assert isinstance(from_yaml('---\n', '<string>'), dict)



# Generated at 2022-06-25 04:27:11.906038
# Unit test for function from_yaml
def test_from_yaml():
    #TODO: check what happens if I give a different file_name and see if it is used in the error message
    #TODO: see what happens if I do not give a file name, is default used?
    #TODO: check what happens with json_only
    #TODO: check what happens with show_content
    #TODO: test with something that is not json or yaml
    #TODO: try to have a yaml file that is not a string
    str_0 = '{ firstName: \'John\', lastName : \'Smith\' }'
    var_0 = from_yaml(str_0)
    assert var_0 == {'firstName': 'John', 'lastName': 'Smith'}

# Generated at 2022-06-25 04:27:12.774923
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Generated at 2022-06-25 04:27:15.112454
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:27:17.196443
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '<string>'
    var_0 = from_yaml(str_0, str_0)



# Generated at 2022-06-25 04:27:31.708996
# Unit test for function from_yaml
def test_from_yaml():
    assert (from_yaml('{"foo": "bar"}') == {'foo': 'bar'})
    assert (from_yaml('{"foo": "bar"}', json_only=True) == {'foo': 'bar'})
    assert (from_yaml('[ "foo", "bar"]') == ['foo', 'bar'])
    assert (from_yaml('[ "foo", "bar"]', json_only=True) == ['foo', 'bar'])
    assert (from_yaml('\nfoo: bar') == {'foo': "bar"})
    assert (from_yaml('\nfoo: bar', json_only=True) == None)
    assert (from_yaml('') == None)
    assert (from_yaml('', json_only=True) == None)

# Generated at 2022-06-25 04:27:34.041962
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except:
        pass

# Generated at 2022-06-25 04:27:35.433115
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()



# Generated at 2022-06-25 04:27:38.217377
# Unit test for function from_yaml
def test_from_yaml():
    print(test_case_0.__doc__)
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:27:40.160793
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("<=yo") is not None


if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-25 04:27:53.020114
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('--- str_0') is None
    assert from_yaml('--- str_1') is None
    assert from_yaml('--- str_2') is None
    assert from_yaml('--- str_3') is None
    assert from_yaml('--- str_4') is None
    assert from_yaml('--- str_5') is None
    assert from_yaml('--- str_6') is None
    assert from_yaml('--- str_7') is None
    assert from_yaml('--- str_8') is None
    assert from_yaml('--- str_9') is None
    assert from_yaml('--- str_10') is None
    assert from_yaml('--- str_11') is None
    assert from_yaml('--- str_12') is None
    assert from_

# Generated at 2022-06-25 04:27:54.497790
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:28:04.421652
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '^XD{I"u+&'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == "'^XD{I\"u+&'"
    try:
        str_1 = '\\'
        var_1 = from_yaml(str_1, str_1)
    except AnsibleParserError:
        pass
    else:
        assert False, 'AnsibleParserError not raised'
    str_2 = 'a'
    var_2 = from_yaml(str_2, str_2)
    assert var_2 == 'a'
    str_3 = '1'
    var_3 = from_yaml(str_3, str_3)
    assert var_3 == 1
    str_4 = '1.0'

# Generated at 2022-06-25 04:28:07.144757
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%1YH8Z.G=p'
    var_0 = from_yaml(str_0, str_0)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:28:10.409421
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    # add testcases here
    assert var_0 == None

# Generated at 2022-06-25 04:28:23.311560
# Unit test for function from_yaml
def test_from_yaml():
    print ('Starting Test', '-' * 20)
    test_1 = ""
    # Test pass
    print ('Test Pass', '-' * 20)
    test_case_0()
    print ('Test Pass Finished', '-' * 20)
    # Test fail
#     try:
#         test_case_1()
#     except Exception as e:
#         print e.__str__()
    print ('Test Finished', '-' * 20)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:32.563312
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{}'
    var_0 = from_yaml(str_0, str_0)
    assert type(var_0) == dict
    assert var_0 == {}

    str_0 = '[]'
    var_0 = from_yaml(str_0, str_0)
    assert type(var_0) == list
    assert var_0 == []

    str_0 = '{'
    try:
        var_0 = from_yaml(str_0, str_0)
    except AnsibleParserError:
        pass
    else:
        assert False

    str_0 = '['
    try:
        var_0 = from_yaml(str_0, str_0)
    except AnsibleParserError:
        pass
    else:
        assert False

    str_

# Generated at 2022-06-25 04:28:35.943283
# Unit test for function from_yaml
def test_from_yaml():
    # Asserting Iterable
    assert test_from_yaml.__name__ == 'test_from_yaml'
    assert test_from_yaml.__doc__ == 'Unit test for function from_yaml'
    assert callable(from_yaml)
    try:
        from_yaml()
        print('Unit test for function from_yaml() is successful')
    except Exception as e:
        print(e)
        print('Unit test for function from_yaml() is unsuccessful')

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:44.864313
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == None
    str_1 = '@N'
    var_1 = from_yaml(str_1, str_1)
    assert var_1 == None
    str_2 = '_d\x1cY\x0e'
    var_2 = from_yaml(str_2, str_2)
    assert var_2 == None

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:46.387608
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:28:54.061065
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    
    # Call function from_yaml without passing in any required args.
    # Expecting to get an exception from from_yaml due to missing required argument.
    try:
        from_yaml()
    except TypeError as err:
        # Verify error message is what is expected
        assert(err.args[0] == "from_yaml() missing 1 required positional argument: 'data'")

# Generated at 2022-06-25 04:29:04.962738
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'bx&a*<X>J$'
    var_0 = from_yaml(str_0, str_0)
    # yaml_str_to_data_simple
    yaml_str_0 = """---
- name: test_var
  value: "1234"
- name: test_var2
  value: "5678"
"""
    yaml_data_0 = from_yaml(yaml_str_0)
    assert yaml_data_0['test_var'] == '1234'
    assert yaml_data_0['test_var2'] == '5678'
    # yaml_str_to_data_complex

# Generated at 2022-06-25 04:29:06.630799
# Unit test for function from_yaml
def test_from_yaml():
    print('Test #0, function from_yaml')
    test_case_0()
    print('Test #1, function from_yaml')
    test_case_1()

test_from_yaml()

# Generated at 2022-06-25 04:29:08.763702
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 04:29:09.439801
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Generated at 2022-06-25 04:29:19.894575
# Unit test for function from_yaml
def test_from_yaml():
    # Run test cases
    test_case_0()


# Generated at 2022-06-25 04:29:23.186676
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert from_yaml('&ob69ja.<b~b') == None
    except AssertionError as e:
        raise AssertionError(str(e) + '\nTest Case:test_case_0')


test_case_map = {
    'test_case_0': test_case_0,
}



# Generated at 2022-06-25 04:29:28.033576
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)

    assert var_0 == '&ob69ja.<b~b'

# Generated at 2022-06-25 04:29:31.160638
# Unit test for function from_yaml
def test_from_yaml():
    with open('test/yaml/data/valid_yaml.yml', 'r') as f:
        var_0 = f.read()
        test_case_0()
        test_case_0()

# Generated at 2022-06-25 04:29:36.288745
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "str": "str" }'
    filename = 'filename'
    vault_secrets = ''
    json_only = False
    retval = from_yaml(data, filename, vault_secrets, json_only)
    assert retval == json.loads(data)
    json_only = True
    with pytest.raises(AnsibleParserError):
        retval = from_yaml(data, filename, vault_secrets, json_only)

# Generated at 2022-06-25 04:29:38.421021
# Unit test for function from_yaml
def test_from_yaml():
    # run it just for fun
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:29:48.332523
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '*eN.8$v{.&q3c%pr4w-*eN.8$v{.&q3c%pr4w-'

    # yaml string with ansible-vault encrypted content
    str_1 = '$ANSIBLE_VAULT;1.1;AES256' \
            '\n6332353139313066363764326430623932653764323566386265353737653936393666666565\n' \
            '6338656136376566313233306630653537643438623439393532386162323165376633393066\n' \
            '633538313034383537613338616336643565306361616539\n'

    # yaml string with ansible

# Generated at 2022-06-25 04:29:50.667963
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!&,!*obhbb#*#'
    var_0 = from_yaml(str_0, str_0)


if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:29:55.785367
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == '&ob69ja.<b~b'

    str_0 = '- &ob69ja.<b~b'
    str_1 = '  - ansible'
    str_2 = '[*]  '
    str_3 = '- &ob69ja.<b~b'
    str_4 = '- ansible'
    str_5 = '[*]'
    var_0 = from_yaml('\n'.join([str_0, str_1, str_2, str_3, str_4, str_5]))

# Generated at 2022-06-25 04:30:00.938344
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '*F_b\x0b\x1a(.x\x0f\x06\x03'
    var_0 = from_yaml(str_0, str_0)


# Generated at 2022-06-25 04:30:20.669893
# Unit test for function from_yaml
def test_from_yaml():
    # test_case_0()
    return None

# TODO:
# Fix:
# Traceback (most recent call last):
#   File "./ansible/parsing/yaml/__init__.py", line 63, in from_yaml
#     new_data = json.loads(data, cls=AnsibleJSONDecoder)
#   File "/home/daniel/.virtualenvs/py-ansible/lib/python3.5/json/__init__.py", line 318, in loads
#     return _default_decoder.decode(s)
#   File "/home/daniel/.virtualenvs/py-ansible/lib/python3.5/json/decoder.py", line 342, in decode
#     raise ValueError(errmsg("Extra data", s, end, len(s)))


# Generated at 2022-06-25 04:30:29.077327
# Unit test for function from_yaml

# Generated at 2022-06-25 04:30:33.676876
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '$I6jiJ%<'
    var_0 = from_yaml(str_0, str_0)
    # assert var_0 == var_0, 'Unable to parse var_0'
    assert isinstance(var_0, dict)



# Generated at 2022-06-25 04:30:35.445582
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Validate our test code
if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:30:45.042293
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)
    str_1 = '#K2h;'
    var_1 = from_yaml(str_1, str_1)
    str_2 = '*hxK<'
    var_2 = from_yaml(str_2, str_2)
    str_3 = 'b<%'
    var_3 = from_yaml(str_3, str_3)
    str_4 = '#rH'
    var_4 = from_yaml(str_4, str_4)
    str_5 = '#$yC-r'
    var_5 = from_yaml(str_5, str_5)

# Generated at 2022-06-25 04:30:50.645300
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '*a^q3D'
    file_0 = '<string>'
    vault_secret_0 = []
    test_result_0 = from_yaml(str_0, file_0, show_content=False, vault_secrets=vault_secret_0)
    test_result_0 = from_yaml(str_0, file_0, show_content=True, vault_secrets=vault_secret_0)
    str_1 = '*a^q3D'
    file_1 = '<string>'
    vault_secret_1 = {'vn}U#': 'Bq+]!'}
    test_result_1 = from_yaml(str_1, file_1, show_content=False, vault_secrets=vault_secret_1)


# Generated at 2022-06-25 04:30:53.132351
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'D'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == 'D'


# Generated at 2022-06-25 04:31:03.211358
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '&#_jz@n^o>+ab'
    var_0 = from_yaml(str_0, str_0)
    str_1 = '8yj=3sx'
    var_1 = from_yaml(str_1, str_1)
    str_2 = '*w2x#xj_f'
    var_2 = from_yaml(str_2, str_2)
    str_3 = '5%d=5@'
    var_3 = from_yaml(str_3, str_3)
    str_4 = '5m5=kg'
    var_4 = from_yaml(str_4, str_4)
    str_5 = 'f$j(7!&h#<8t7q$'
    var

# Generated at 2022-06-25 04:31:09.707047
# Unit test for function from_yaml
def test_from_yaml():

    str_0 = '{"foo": "bar", "baz": "foobaz"}'
    str_1 = '{"baz": "foobaz", "foo": "bar"}'
    str_2 = '{"foo": "bar"}'

    var_0 = from_yaml(str_0, str_0)
    var_1 = from_yaml(str_1, str_1)
    var_2 = from_yaml(str_2, str_2)

    assert var_0 == var_1
    assert var_0 != var_2



# Generated at 2022-06-25 04:31:14.681566
# Unit test for function from_yaml
def test_from_yaml():

    # Call function from_yaml
    str_0 = '&ob69ja.<b~b'
    var_0 = from_yaml(str_0, str_0)

    # Assertions
    assert var_0 == "'&ob69ja.<b~b'"


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:31:35.451382
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'foo') == 'foo'
    assert from_yaml(b'foo: bar') == {'foo': 'bar'}
    assert from_yaml(b'foo: bar\n') == {'foo': 'bar'}
    assert from_yaml(b'foo: bar\n\n') == {'foo': 'bar'}
    assert from_yaml(b'foo: bar\n\n\n') == {'foo': 'bar'}
    assert from_yaml(b'foo: bar\n\n\n\n') == {'foo': 'bar'}
    assert from_yaml(b'foo: bar\n  baz: qux') == {'baz': 'qux', 'foo': 'bar'}

# Generated at 2022-06-25 04:31:38.403502
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as err:
        import traceback
        from ansible.utils.unicode import to_unicode
        raise AssertionError(to_unicode(traceback.format_exc()))


# Generated at 2022-06-25 04:31:40.231252
# Unit test for function from_yaml
def test_from_yaml():
    # FIXME: This test is really really incomplete
    try:
        test_case_0()
    except Exception as e:
        print('exception: %s' % str(e))