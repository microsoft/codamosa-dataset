

# Generated at 2022-06-25 04:21:48.304075
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(test_case_0) is True
    assert from_yaml(test_case_0) is True
    assert from_yaml(test_case_0) is True



# Generated at 2022-06-25 04:21:50.812776
# Unit test for function from_yaml
def test_from_yaml():
    bool_0 = True
    var_0 = from_yaml(bool_0, bool_0, bool_0)

    token_0 = None

    var_1 = from_yaml(token_0, token_0, token_0)

# Generated at 2022-06-25 04:21:59.389232
# Unit test for function from_yaml
def test_from_yaml():
    bool_0 = (0)

# Generated at 2022-06-25 04:22:01.412714
# Unit test for function from_yaml
def test_from_yaml():
    assert isinstance(test_case_0(), type(None))

# Generated at 2022-06-25 04:22:07.356923
# Unit test for function from_yaml
def test_from_yaml():
    bool_0 = True
    int_0 = 0
    string_0 = "foo"
    from_yaml(bool_0, bool_0, bool_0)
    from_yaml(bool_0, bool_0, int_0)
    try:
        from_yaml(string_0, bool_0)
    except AnsibleParserError:
        pass
    except YAMLError:
        pass
    except Exception:
        pass


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:22:18.877721
# Unit test for function from_yaml
def test_from_yaml():
    bool_0 = True
    var_0 = from_yaml(bool_0)
    assert type(var_0) == bool
    assert var_0 == True

    bool_1 = False
    var_1 = from_yaml(bool_1)
    assert type(var_1) == bool
    assert var_1 == False

    num_0 = 1234
    var_2 = from_yaml(num_0)
    assert type(var_2) == int
    assert var_2 == 1234

    num_1 = 1234.5678
    var_3 = from_yaml(num_1)
    assert type(var_3) == float
    assert var_3 == 1234.5678

    str_0 = 'ansible'
    var_4 = from_yaml(str_0)


# Generated at 2022-06-25 04:22:29.887845
# Unit test for function from_yaml
def test_from_yaml():
    bool_0 = True
    str_0 = "&"
    str_1 = " "
    try:
        var_0 = from_yaml(bool_0, bool_0, bool_0)
    except Exception as exc_0:
        str_2 = str(exc_0)
        try:
            str_3 = str_2.split(str_0, str_1)
        except Exception as exc_1:
            str_4 = str(exc_1)
            try:
                str_5 = str_4.split(str_0, str_1)
            except Exception as exc_2:
                str_6 = str(exc_2)
                assert False
            else:
                assert False
        else:
            assert False
    else:
        assert False



# Generated at 2022-06-25 04:22:38.856311
# Unit test for function from_yaml
def test_from_yaml():
    import yaml # TODO: ondemand import

    # Testing different types of inputs
    with pytest.raises(AnsibleParserError) as excinfo:
        from_yaml(1.0)
    assert 'We were unable to read either as JSON nor YAML, these are the errors we got from each:' in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        from_yaml(yaml.BaseLoader)
    assert "is not JSON serializable" in str(excinfo.value)

    # Testing other parameters
    with pytest.raises(AnsibleParserError) as excinfo:
        from_yaml('{"test": "test_parsing"}', file_name="test", show_content=False, vault_secrets=["asd"])

# Generated at 2022-06-25 04:22:46.037363
# Unit test for function from_yaml
def test_from_yaml():
    var_1 = False
    var_2 = '<string>'
    var_3 = True
    var_4 = 'json_only'
    var_5 = 'from_yaml'
    data_from_yaml = [var_5]
    data_from_yaml = from_yaml(var_1, var_2, var_3, var_4)
    assert data_from_yaml == data_from_yaml


# Generated at 2022-06-25 04:22:46.815277
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True # implemented

# Generated at 2022-06-25 04:22:58.358324
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'test_str'
    bool_0 = True
    var_0 = from_yaml(bool_0, bool_0, bool_0)
    var_1 = from_yaml((), bool_0, bool_0)
    var_2 = from_yaml((), bool_0, bool_0)
    var_3 = from_yaml((), bool_0, bool_0)
    var_4 = from_yaml((), bool_0, bool_0)
    var_5 = from_yaml((), bool_0, bool_0)
    var_6 = from_yaml((), bool_0, bool_0)
    var_7 = from_yaml((), bool_0, bool_0)

# Generated at 2022-06-25 04:23:04.103957
# Unit test for function from_yaml
def test_from_yaml():
    print('Test 0')
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:10.933853
# Unit test for function from_yaml
def test_from_yaml():
    not_var_0 = True
    var_0 = True
    var_1 = True
    var_2 = True
    var_3 = 'hi'
    var_4 = ['hi']
    var_5 = {'hi': 10}
    if isinstance(var_0, bool):
        test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:19.401726
# Unit test for function from_yaml
def test_from_yaml():
    try:
        ansible_data = json.dumps({
            "hosts": ["host1", "host2"],
            "vars": {
                "http_port": 80,
                "max_clients": 200
            }
        })
        print(from_yaml(ansible_data, ansible_data))
        ansible_data_2 = ''
        ansible_data_3 = 'invalid_value'
        ansible_data_4 = None
        ansible_data_5 = [1, 2, 3]
        ansible_data_6 = {}
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:23:27.991972
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = from_yaml('test_value_0', 'test_value_1', bool(1))
    try:
        assert var_0 == 'test_value_0'
    except AssertionError as e:
        raise AssertionError(str(e) + " | " + str(var_0))

    var_10 = from_yaml('test_value_0', 'test_value_1', bool(0))
    try:
        assert var_10 == 'test_value_0'
    except AssertionError as e:
        raise AssertionError(str(e) + " | " + str(var_10))

    var_20 = from_yaml('var_0', 'test_value_1', bool(1))

# Generated at 2022-06-25 04:23:34.172640
# Unit test for function from_yaml
def test_from_yaml():
    bool_0 = False
    str_0 = 'test_str_str'
    str_1 = 'test_str_str'
    test_dict = {}
    test_dict['test_key'] = 'test_value'
    test_list = []
    test_list.append(test_dict)
    test_dict2 = {}
    test_dict2['test_key2'] = 'test_value2'
    test_list.append(test_dict2)
    test_json = json.dumps(test_list)

    var_0 = from_yaml(test_json, str_0, bool_0, str_1)
    var_1 = from_yaml('test_str_str', str_0, bool_0, str_1)

# Generated at 2022-06-25 04:23:43.365040
# Unit test for function from_yaml
def test_from_yaml():
    bool_0 = True
    test_data = {"bar": {"baz": 5, "foo": 7}, "foo": {"bar": 7, "foo": 5}, "z": 5}
    var_0 = from_yaml(bool_0, bool_0, bool_0)
    var_1 = from_yaml(test_data, test_data, test_data)
    assert var_0 == bool_0
    assert var_1 == test_data


if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:23:46.533048
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError):
        test_case_0()

# Generated at 2022-06-25 04:23:59.292635
# Unit test for function from_yaml
def test_from_yaml():
    assert (from_yaml("foo\nbar") == "foo\nbar")
    assert (from_yaml("{0:1, 1:2, 2:3}") == {0: 1, 1: 2, 2: 3})
    assert (from_yaml("['foo', 'bar']") == ['foo', 'bar'])
    assert (from_yaml("{'foo': 'bar'}") == {'foo': 'bar'})
    assert (from_yaml("foo: 'bar'") == {'foo': 'bar'})
    assert (from_yaml("foo: inline") == {'foo': 'inline'})
    assert (from_yaml("foo:\n  - bar\n  - baz") == {'foo': ['bar', 'baz']})

# Generated at 2022-06-25 04:24:11.793024
# Unit test for function from_yaml
def test_from_yaml():
    source = """
    ansible: 2.7
    collections:
      - name: community.general
        version: 1.0.0
      - name: community.aws
        version: 1.0.0
"""
    ansible_dict = from_yaml(source,"<string>",True,None)
    assert(ansible_dict['ansible'] == 2.7)
    assert(ansible_dict['collections'][0]['name'] == 'community.general')
    assert(ansible_dict['collections'][0]['version'] == '1.0.0')
    assert(ansible_dict['collections'][1]['name'] == 'community.aws')
    assert(ansible_dict['collections'][1]['version'] == '1.0.0')



# Generated at 2022-06-25 04:24:22.348490
# Unit test for function from_yaml
def test_from_yaml():

    # Call from_yaml with correct arguments
    assert from_yaml(None, None, None) is None
    assert from_yaml(None, None, None, json_only=True) is None

    # Call from_yaml with incorrect arguments
    try:
        from_yaml(None)
    except Exception:
        assert True
    else:
        assert False

    # Call to_native with incorrect arguments
    test_case_0()

    # Call AnsibleBaseYAMLObject
    AnsibleBaseYAMLObject()
    AnsibleBaseYAMLObject.__init__()

    # Call AnsibleJSONDecoder
    AnsibleJSONDecoder().decode()
    AnsibleJSONDecoder.decode()

    # Call AnsibleLoader
    AnsibleLoader()
    AnsibleLoader.__init__()
    Ans

# Generated at 2022-06-25 04:24:31.206594
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError) as excinfo:
        test_case_0()
    assert 'nstr\n\nAnsible encountered a YAML syntax error while parsing a dynamic inventory script. \n\nThe error was: while parsing a block collection\n\nThe error appears to be in \'None\': line 1, column 1, but may\nbe elsewhere in the file depending on the exact syntax problem.\n\nThe offending line appears to be:\n\n    bool_0 = True\n    ^ here\n' in str(excinfo.value)

# Generated at 2022-06-25 04:24:36.151330
# Unit test for function from_yaml
def test_from_yaml():
    data = {'foo': 'bar'}
    if isinstance(from_yaml(YAML_SYNTAX_ERROR % u'', '<string>', True), dict):
        pass
    elif isinstance(from_yaml('', '<string>', True), dict):
        pass
    elif isinstance(from_yaml(True, '<string>', True), dict):
        pass
    else:
        pass

# Generated at 2022-06-25 04:24:42.035980
# Unit test for function from_yaml
def test_from_yaml():

    # Case 0 - Test with a boolean
    try:
        test_case_0()
    except AnsibleParserError:
        pass


if __name__ == '__main__':

    test_from_yaml()

# Generated at 2022-06-25 04:24:50.553265
# Unit test for function from_yaml
def test_from_yaml():
    bool_0 = True
    var_0 = from_yaml(bool_0, bool_0, bool_0)
    var_1 = from_yaml(var_0, bool_0, bool_0)
    var_2 = from_yaml(var_0, bool_0, bool_0, vault_secrets=bool_0)
    var_3 = from_yaml(var_0, bool_0, bool_0, vault_secrets=bool_0, json_only=bool_0)

# Generated at 2022-06-25 04:25:00.936497
# Unit test for function from_yaml
def test_from_yaml():
    test_0_string = 'data0'
    test_0_dict = dict()
    test_0_dict['hello'] = 1
    test_0_dict['world'] = 2

    test_0_yaml = yaml.dump(test_0_dict, default_flow_style=False)

    test_1_string = 'data1'
    test_1_dict = dict()
    test_1_dict['ansible'] = 'is awesome'

    test_1_yaml = yaml.dump(test_1_dict, default_flow_style=False)

    test_0_result = from_yaml(test_0_yaml, test_0_string)
    test_1_result = from_yaml(test_1_yaml, test_1_string)

    assert test_0_result

# Generated at 2022-06-25 04:25:08.877429
# Unit test for function from_yaml
def test_from_yaml():
    bool_0 = True
    var_0 = from_yaml(bool_0, bool_0, bool_0)

    test_0_0 = {
        u'ansible_pos': (u'<string>', 1, 1),
        u'bool_field': True,
        u'list_field': [
            u'foo',
            u'bar'
        ],
        u'object_field': {
            u'baz': u'qux'
        }
    }
    var_1 = from_yaml(u'bool_field: yes\nlist_field: [foo, bar]\nobject_field:\n  baz: qux\n', u'<string>', True)
    assert var_1 == test_0_0


# Generated at 2022-06-25 04:25:09.562304
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:25:10.727388
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Generated at 2022-06-25 04:25:18.271831
# Unit test for function from_yaml
def test_from_yaml():
    '''
    AnsibleParserError: We were unable to read either as JSON nor YAML, these are the errors we got from each:
    JSON: No JSON object could be decoded
    YAML: expected '<document start>', but found BlockMappingStart
      in "False", line 1, column 1:
      ^
    '''
    bool_0 = False
    str_0 = "False"
    var_0 = from_yaml(str_0, bool_0, bool_0)
    test_case_0()

test_from_yaml()

# Generated at 2022-06-25 04:25:27.235514
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:25:35.178807
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{}'
    var_0 = from_yaml(str_0, str_0)

    str_1 = '{}'
    var_1 = from_yaml(str_1, str_1)

    str_2 = '{}'
    var_2 = from_yaml(str_2, str_2)

    str_3 = '{}'
    var_3 = from_yaml(str_3, str_3)

    str_4 = '{}'
    var_4 = from_yaml(str_4, str_4)

    str_5 = '{}'
    var_5 = from_yaml(str_5, str_5)

    str_6 = '{}'

# Generated at 2022-06-25 04:25:41.744152
# Unit test for function from_yaml
def test_from_yaml():
    str = '''
        david:
            name: david
            job: devops
            skills:
                - linux
                - python
                - git
        frank:
            name: frank
            job: devops
            skills:
                - linux
                - shell
                - aws
        vars:
            var1: 1
            var2: "2"
    '''
    data = from_yaml(str, str)
    print(data)

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:25:43.654531
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:25:46.326886
# Unit test for function from_yaml
def test_from_yaml():
    # Run test on all test cases
    print('')
    test_case_0()

# Collect all test cases in this file
test_cases = (test_from_yaml,)


# Generated at 2022-06-25 04:25:55.745751
# Unit test for function from_yaml
def test_from_yaml():
    import ctypes


# Generated at 2022-06-25 04:25:58.071304
# Unit test for function from_yaml
def test_from_yaml():
    # No example exists for this one
    pass


# Generated at 2022-06-25 04:26:06.562534
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'SFZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)
    assert isinstance(var_0, dict)

    str_0 = 'a: b'
    var_0 = from_yaml(str_0, str_0)
    assert isinstance(var_0, dict)

    str_0 = 'a: b\nc: d'
    var_0 = from_yaml(str_0, str_0)
    assert isinstance(var_0, dict)

    str_0 = 'a: b\nc: d\nd: e'
    var_0 = from_yaml(str_0, str_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 04:26:15.617900
# Unit test for function from_yaml
def test_from_yaml():

    assert_equals = assert_equals_test_case_0

    # Try to fake a YAMLError instance with no problem mark set
    try:
        raise YAMLError()
    except YAMLError as yaml_exc:
        _handle_error(None, yaml_exc, 'foo', False)

    # Try to fake a YAMLError instance with a problem mark set
    try:
        raise YAMLError()
    except YAMLError as yaml_exc:
        yaml_exc.problem_mark = YAMLError('problem')
        _handle_error(None, yaml_exc, 'foo', False)

    # Now try to create valid YAMLError instances with problem marks
    # in various locations within a multiline string

# Generated at 2022-06-25 04:26:26.094836
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "---\n- test"
    var_0 = from_yaml(str_0, str_0)
    assert 'test' in var_0

    str_0 = "---\n- test"
    var_0 = from_yaml(str_0, str_0, False)
    assert 'test' in var_0

    str_0 = "---\n- test"
    var_0 = from_yaml(str_0, str_0, True)
    assert 'test' in var_0

    str_0 = "---\n- test"
    var_0 = from_yaml(str_0, str_0, True, False)
    assert 'test' in var_0

# Generated at 2022-06-25 04:26:37.773627
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)


# Generated at 2022-06-25 04:26:40.335672
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '~'
    var_0 = from_yaml(str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:26:42.535593
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:26:53.464636
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault
    from ansible.parsing.vault import VaultLib

    vault_store = vault.VaultLib()
    str_0 = '{"a": 1}'
    data_0 = from_yaml(str_0, str_0)
    if isinstance(data_0, dict):
        pass
    else:
        raise RuntimeError("test failure")

    str_1 = '{"a": 1}'
    secrets_1 = dict(vault_password=str_1)
    data_1 = from_yaml(str_1, str_1, vault_secrets=secrets_1)
    if isinstance(data_1, dict):
        pass
    else:
        raise RuntimeError("test failure")

# Generated at 2022-06-25 04:26:59.073497
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        assert False
        return

    try:
        test_case_0()
    except Exception as err:
        assert False
        return

    assert True

# Generated at 2022-06-25 04:27:10.374270
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)

    str_5 = '{"a":"b"}'
    var_5 = from_yaml(str_5, str_5)

    str_2 = '{}'
    var_2 = from_yaml(str_2, str_2)

    str_3 = '{"a":"b","c":{"$":"d"}}'
    var_3 = from_yaml(str_3, str_3)

    str_1 = '{"a":"b","c":{"$":"d"},"d":{"e":{"f":{"g":{"h":{"i":{"j":"k"}}}}}}}'
    var_1 = from_yaml(str_1, str_1)


# Generated at 2022-06-25 04:27:15.001623
# Unit test for function from_yaml
def test_from_yaml():

    # bad JSON
    with pytest.raises(AnsibleParserError) as err:
        from_yaml('invalid json string')
    assert 'not valid JSON' in to_native(err.value)

    # bad YAML
    with pytest.raises(AnsibleParserError) as err:
        from_yaml('invalid yaml string', json_only=True)
    assert 'not valid JSON' in to_native(err.value)

# Generated at 2022-06-25 04:27:18.938532
# Unit test for function from_yaml
def test_from_yaml():
    import random
    import string

    # random string
    str_0 = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(random.randint(1, 1000)))

    from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:27:22.128475
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = from_yaml('a: 1\nb:\n  - 1\n', '&')
    assert var_0 == {u'a': 1, u'b': [1]}


# Generated at 2022-06-25 04:27:23.049060
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:27:41.139837
# Unit test for function from_yaml
def test_from_yaml():
    var = ""
    var_0 = from_yaml(var)
    assert var_0 is None

    var = "odu_ut"
    var_0 = from_yaml(var)
    assert var_0 is None

    var = "o\u0094\u00ad_vt"
    var_0 = from_yaml(var)
    assert var_0 is None

    var = ""
    var_0 = from_yaml(var, "ex_j")
    assert var_0 is None

    var = "o\u0094\u00ad_vt"
    var_0 = from_yaml(var, "op")
    assert var_0 is None

    var = ""
    var_0 = from_yaml(var, "")
    assert var_0 is None


# Generated at 2022-06-25 04:27:42.908672
# Unit test for function from_yaml
def test_from_yaml():
    for i in range(10):
        try:
            test_case_0()
        except Exception as raised_exception:
            print(raised_exception)

# Generated at 2022-06-25 04:27:47.304136
# Unit test for function from_yaml
def test_from_yaml():
    print('Test: test_case_0:', end='')
    test_case_0()
    print('')


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:27:49.817722
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Generated at 2022-06-25 04:27:50.883125
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:27:59.675434
# Unit test for function from_yaml
def test_from_yaml():
    assert isinstance(from_yaml('Ansible'), dict)

from ansible.module_utils.common._collections_compat import Mapping
from ansible.module_utils.common.collections import is_sequence
from ansible.module_utils.common.text.converters import to_bytes
from ansible.module_utils.common.text.converters import to_unicode
from ansible.module_utils.six import iteritems
from ansible.module_utils.six import itervalues
from ansible.module_utils.six import string_types
from ansible.module_utils.six import text_type

from ansible.parsing.ajson import AnsibleJSONDecoder
from ansible.parsing.yaml.loader import AnsibleLoader

from ansible.errors.yaml_strings import Y

# Generated at 2022-06-25 04:28:00.508778
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None

# Generated at 2022-06-25 04:28:09.027451
# Unit test for function from_yaml
def test_from_yaml():
    # Make sure the function can be properly called
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)
    # Ensure the proper exception is raised if the input is invalid
    with pytest.raises(AnsibleParserError) as excinfo:
        from_yaml(str_0, str_0, vault_secrets={"/dev/urandom": "foo"})
    # Ensure the proper exception is raised if the input is invalid
    with pytest.raises(AnsibleParserError) as excinfo:
        from_yaml(str_0, str_0, vault_secrets={"/dev/urandom": "foo"})
    # Ensure the proper exception is raised if the input is invalid

# Generated at 2022-06-25 04:28:11.363477
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'd4\n\x00\x00\x00\x00\x00\x00'
    var_0 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:28:14.179717
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    # test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:28:26.676808
# Unit test for function from_yaml
def test_from_yaml():
    for test_func in [test_case_0]:
        test_func()

# Generated at 2022-06-25 04:28:33.139819
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('---') == {}
    assert from_yaml('---[0]') == {}
    assert from_yaml('---\n- value\n') == {'value'}
    assert from_yaml('''---
    4303;4303
    ''') == {4303: 4303}
    assert from_yaml('---\n- test\n') == {'test'}
    assert from_yaml('---\n-\n  - "test"\n') == {'test'}
    assert from_yaml('---\n- test\n') == {'test'}
    assert from_yaml('---\n- test\n') == {'test'}
    assert from_yaml('---\n- test\n') == {'test'}

# Generated at 2022-06-25 04:28:36.268880
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except AnsibleParserError as ae:
        if 'JSON' in str(ae):
            raise ae
        if 'YAML' in str(ae):
            raise ae

# Generated at 2022-06-25 04:28:37.932924
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:47.899948
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("hello", "...") == "hello"
    assert from_yaml("[1,2]", "...") == [1,2]
    assert from_yaml("{\"k\":\"v\"}", "...") == {"k":"v"}

    try:
        from_yaml("a: b", "...")
        assert False
    except AnsibleParserError:
        pass

    try:
        from_yaml("a: b", "...", show_content=False)
        assert False
    except AnsibleParserError:
        pass

    try:
        from_yaml("a: b", "...", show_content=True)
        assert False
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 04:28:57.611701
# Unit test for function from_yaml
def test_from_yaml():
    # Case 0
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == 'FZ\x0c%)]w'

    # Case 1
    str_0 = 'FZ\x0c-=d3r7'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == 'FZ\x0c-=d3r7'

    # Case 2
    str_0 = 'FZ\x0c~\x98\x0eI'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == 'FZ\x0c~\x98\x0eI'

    # Case 3

# Generated at 2022-06-25 04:29:08.075748
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "${'yaml': 'yaml'}"
    str_0 = "---\n- ${'yaml': 'yaml'}\n"
    from_yaml(str_0, str_0)
    str_0 = "${'yaml': 'yaml'}"
    str_0 = "---\n- ${'yaml': 'yaml'}\n"
    from_yaml(str_0, str_0)
    str_0 = "---\n- ${'yaml': 'yaml'}\n"
    from_yaml(str_0, str_0)
    str_0 = "---\n- ${'yaml': 'yaml'}\n"
    from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:29:15.078304
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)


if __name__ == '__main__':
    print(test_case_0())
    test_from_yaml()

# Generated at 2022-06-25 04:29:17.393357
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:29:25.147892
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'v+Z\x14Q'
    file_name_0 = 'T'
    var_0 = from_yaml(str_0, file_name_0)
    int_0 = 2
    file_name_1 = '+D'
    show_content_0 = False

# Generated at 2022-06-25 04:29:37.193069
# Unit test for function from_yaml
def test_from_yaml():
    # str_0 = 'FZ\x0c%)]w'
    # var_0 = from_yaml(str_0, str_0)
    pass


if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:29:39.922847
# Unit test for function from_yaml
def test_from_yaml():
    try:
        print(from_yaml(str_0, str_0))
    except Exception as e:
        print(e)
        print(type(e))


# Generated at 2022-06-25 04:29:43.278932
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)
    return True

# vim: reset ts=4 sw=4 expandtab

# Generated at 2022-06-25 04:29:45.128693
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)
    pass

# Generated at 2022-06-25 04:29:47.256844
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [
        (('c_u\x1b', str), {})
    ]

    for args, _ in test_cases:
        yield test_case_0, args

# Generated at 2022-06-25 04:29:50.866696
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:29:52.488631
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)

# Boilerplate

# Generated at 2022-06-25 04:29:54.509948
# Unit test for function from_yaml
def test_from_yaml():
    # Replace with a valid test case
    try:
        test_case_0()
    except AssertionError:
        pass
    # Replace with a valid test case
    try:
        test_case_0()
    except AssertionError:
        pass

# Generated at 2022-06-25 04:29:59.703690
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '<0]\xc2\xce\xca\xcd\xb9\x9e\xbb\xb1\xb5'
    var_0 = from_yaml(str_0, str_0)
    str_1 = 'Jh\x0fjj\xb8\xbe'
    var_1 = from_yaml(str_1, str_1)
    str_2 = '8W\x17[\x1a\x1f'
    var_2 = from_yaml(str_2, str_2)

    assert (var_0, var_1, var_2) == ('<0]', 'Jh', '8W')

# Generated at 2022-06-25 04:30:10.126215
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('{}', json_only=True) == {}
    assert from_yaml('null') == None
    assert from_yaml('null', json_only=True) == None
    assert from_yaml('[]') == []
    assert from_yaml('[]', json_only=True) == []
    assert from_yaml('{"a": 1}') == {'a': 1}
    assert from_yaml('{"a": 1}', json_only=True) == {'a': 1}
    assert from_yaml('a: 1') == {'a': 1}
    try: from_yaml('a: 1', json_only=True)
    except: pass
    else: assert False

# Generated at 2022-06-25 04:30:29.182791
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)
    print(var_0)

# Generated at 2022-06-25 04:30:40.084897
# Unit test for function from_yaml
def test_from_yaml():
    # example code from ansible_vault._decrypt_unsafe()
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('{a: 1}') == {'a': 1}
    assert from_yaml('{a: {a: 1, b: 2}, b: 3}') == {'a': {'a': 1, 'b': 2}, 'b': 3}
    assert from_yaml('{a: {a: 1, b: [2, 3, 4]}, b: 3}') == {'a': {'a': 1, 'b': [2, 3, 4]}, 'b': 3}

# Generated at 2022-06-25 04:30:42.139259
# Unit test for function from_yaml
def test_from_yaml():
    print("Test Case : 0")
    test_case_0()
    
test_from_yaml()

# Generated at 2022-06-25 04:30:43.556392
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() == 0, 'Failed test_case_0'

ansible_module_utils_basic.run_unit_tests(globals())

# Generated at 2022-06-25 04:30:48.397404
# Unit test for function from_yaml
def test_from_yaml():
    print('Start test for function from_yaml')

    # Test case 1
    print('Test case 1:')
    str_1 = '{'
    try:
        from_yaml(str_1, str_1)
        assert False
    except AnsibleParserError:
        assert True
    except:
        assert False

    # Test case 2
    print('Test case 2:')
    str_2 = '{"a" : "b c"}'
    try:
        from_yaml(str_2, str_2)
        assert True
    except:
        assert False

    # Test case 3
    print('Test case 3:')
    str_3 = '{"a" : "b\nc"}'

# Generated at 2022-06-25 04:30:52.432884
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:30:57.940288
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{"username":"joe","password":"12345"}'
    var_0 = from_yaml(str_0, str_0)
    str_1 = '---\n- hosts: localhost\n  tasks:\n    - name: test\n      raw: test\n'
    var_1 = from_yaml(str_1, str_1)

# Generated at 2022-06-25 04:31:00.955617
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'R_=\x16A\x0f94G\x0e\x1c'
    var_0 = from_yaml(str_0, str_0)



# Generated at 2022-06-25 04:31:08.184461
# Unit test for function from_yaml

# Generated at 2022-06-25 04:31:09.338972
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:31:31.139238
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Generated at 2022-06-25 04:31:33.210362
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'FZ\x0c%)]w'
    var_0 = from_yaml(str_0, str_0)



# Generated at 2022-06-25 04:31:36.137411
# Unit test for function from_yaml
def test_from_yaml():
    string_0 = 'FZ\x0c%)]w'
    actual_0 = from_yaml(string_0, string_0)
    wanted_0 = 'FZ\x0c%)]w'
    assert actual_0 == wanted_0, 'Failed test_0'

test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:31:36.642303
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:31:45.700561
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '}"\'\n'
    var_0 = from_yaml(str_0, str_0)
    str_1 = 'FZ\x0c%)]w'
    var_1 = from_yaml(str_1, str_1)
    str_2 = '\x00\x00\x01\x00\x00\x00\x00\x00\x00\x02@\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02'
    var_2 = from_yaml(str_2, str_2)
    str_3 = '\xdf\x00\x00\x00'
    var_3 = from_yaml(str_3, str_3)