

# Generated at 2022-06-25 04:21:52.518988
# Unit test for function from_yaml
def test_from_yaml():
    # load_bytes_0 loads bytes_0 from the data section
    def load_bytes_0():
        return [
            0x3e, 0x3d, 0x41, 0x2a, 0xa1, 0xda, 0xb4, 0xc4, 0xce, 0x31,
            0xfe, 0xd2, 0xa3, 0xd9, 0x69, 0x34
        ]

    # load_bytes_1 loads bytes_1 from the data section

# Generated at 2022-06-25 04:22:01.462177
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)
    assert var_0 == None



# Generated at 2022-06-25 04:22:09.257070
# Unit test for function from_yaml
def test_from_yaml():
    # Test case for function from_yaml
    # Normal use case:
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)

    # Test case for function from_yaml
    # JSON load error
    bytes_0 = b'MoCuYl'
    try:
        var_0 = from_yaml(bytes_0, bytes_0)
    except AnsibleParserError:
        pass

    # Test case for function from_yaml
    # Missing 'json_only' argument

# Generated at 2022-06-25 04:22:15.829424
# Unit test for function from_yaml
def test_from_yaml():
    # Test 1: simple text.
    data = 'simple text'
    assert from_yaml(data) == data

    # Test 2: dictionary.
    data = '{ "key": "value"}'
    assert from_yaml(data) == {'key': 'value'}

    # Test 3: list.
    data = '[i, ii, iii]'
    assert from_yaml(data) == ['i', 'ii', 'iii']

# Generated at 2022-06-25 04:22:22.545501
# Unit test for function from_yaml
def test_from_yaml():
    args = ()
    try:
        from_yaml(*args)
    except TypeError as exc:
        assert 'from_yaml() takes at least 1 argument (0 given)' in str(exc)

    args = {}
    try:
        from_yaml(**args)
    except TypeError as exc:
        assert "from_yaml() missing required argument: 'data'" in str(exc)



# Generated at 2022-06-25 04:22:24.816030
# Unit test for function from_yaml
def test_from_yaml():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 04:22:33.659245
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert 1
        # pass
    except AssertionError as ae:
        raise ae

# Generated from package:ansible.parsing.yaml.objects

# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
from ansible.parsing.yaml.objects import AnsibleSequence
from ansible.parsing.yaml.objects import AnsibleMapping
from ansible.parsing.yaml.objects import AnsibleUnicode
from ansible.parsing.yaml.objects import AnsibleUnsafeText
from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnic

# Generated at 2022-06-25 04:22:39.928201
# Unit test for function from_yaml
def test_from_yaml():

    assert (from_yaml(b'{ "foo": "bar" }')) == { "foo": "bar" }
    assert (from_yaml(b'{ "foo": \'bar\' }')) == { "foo": "bar" }
    assert (from_yaml(b'[ "foo", "bar" ]')) == [ "foo", "bar" ]
    assert (from_yaml(b'"foo"')) == "foo"
    assert (from_yaml(b'"\\"foo\\""')) == "\"foo\""
    assert (from_yaml(b'{ "foo": "bar", }')) == { "foo": "bar", }
    assert (from_yaml(b'{ "foo": "bar" }', json_only=True)) == { "foo": "bar" }

# Generated at 2022-06-25 04:22:44.963395
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)
    assert var_0 is not None

# Generated at 2022-06-25 04:22:50.789824
# Unit test for function from_yaml
def test_from_yaml():
    # Doesn't test the exception case because it contains no iterable information.
    # Compilation is however, dependent on this function.
    test_case_0()

# Generated at 2022-06-25 04:22:56.481400
# Unit test for function from_yaml
def test_from_yaml():

    # Assert that some call to the function works
    try:
        test_case_0()
        assert True
    except:
        assert False

# Generated at 2022-06-25 04:23:05.147399
# Unit test for function from_yaml
def test_from_yaml():
    # Example of passing in a json string.
    bytes_0 = b'{"key": "value"}'
    var_0 = from_yaml(bytes_0, bytes_0)
    assert var_0 == {"key": "value"}

    # Example of passing in a yaml string that is indented with spaces.
    bytes_1 = b'---\n  key: value\n'
    var_1 = from_yaml(bytes_1, bytes_1)
    assert var_1 == {"key": "value"}

    # Example of passing in a yaml string that is indented with tabs.
    bytes_2 = b'---\n\tkey: value\n'
    var_2 = from_yaml(bytes_2, bytes_2)
    assert var_2 == {"key": "value"}

    # Example of

# Generated at 2022-06-25 04:23:06.231986
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0()


# Generated at 2022-06-25 04:23:17.415544
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'/\x14\xb2\x80\xd3\xf3\x84\xc8"\t\x0c\x9f\xd9\xda\xac\x05\x89\x17\x15\x8f\xb9'
    int_0 = 0
    str_0 = ''
    str_1 = ''
    int_1 = 0
    var_0 = ansible.parsing.yaml.dumper.AnsibleDumper()
    # assuming this is the constructor method for AnsibleDumper
    # Need to add some data for the method to return
    ansible.parsing.yaml.dumper.AnsibleDumper.__init__(var_0)
    str_2 = 'safe_dump'

# Generated at 2022-06-25 04:23:27.602371
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)
    bytes_1 = b'><\xb7\x8c\x88\x05\x85\xd7\x8b\x05'
    var_1 = from_yaml(bytes_1, bytes_1)
    bytes_2 = b'{w\xa6\x86\x89\x9c6\x87\x86\xc8\x95'
    var_2 = from_yaml(bytes_2, bytes_2)

# Generated at 2022-06-25 04:23:38.502167
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'4'
    bytes_1 = b'!-'
    bytes_2 = b'5'
    dict_0 = {
        '2': '2',
        '1': '1',
        '3': '3'
    }

# Generated at 2022-06-25 04:23:43.817393
# Unit test for function from_yaml
def test_from_yaml():
    bytes_2 = b'\xac\x00\x00\x00'
    var_2 = from_yaml(bytes_2, bytes_2, False, None)
    assert var_2 == 1234

    bytes_1 = '\xac\x00\x00\x00'
    var_1 = from_yaml(bytes_1, bytes_1, False, None)
    assert var_1 == 1234

    bytes_3 = b'[1, 2, 3]\n'
    var_3 = from_yaml(bytes_3, bytes_3, False, None)
    assert var_3 == [1, 2, 3]

    bytes_4 = '[1, 2, 3]\n'
    var_4 = from_yaml(bytes_4, bytes_4, False, None)


# Generated at 2022-06-25 04:23:53.076108
# Unit test for function from_yaml
def test_from_yaml():

    # unknown str type arg (1st arg of 1 required).
    yaml_obj = from_yaml(None)
    assert yaml_obj is None

    # unknown str type arg (1st arg of 1 required).
    yaml_obj = from_yaml(None, bytes('stream'))
    assert yaml_obj is None

    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'

    try:
        # unknown str type arg (1st arg of 1 required).
        var_0 = from_yaml(bytes_0)
        assert False
    except AnsibleParserError as e:
        assert e.orig_exc.__class__ is YAMLError

# Generated at 2022-06-25 04:23:59.591301
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b' [ 1, 2, 3 ] '
    bytes_1 = b" [\n    1,\n    2,\n    3,\n]"
    bytes_2 = b'---\n- 1\n- 2\n- 3\n'
    var_0 = from_yaml(bytes_0)
    var_1 = from_yaml(bytes_1)
    var_2 = from_yaml(bytes_2)
    assert var_0 == [1, 2, 3]
    assert var_1 == [1, 2, 3]
    assert var_2 == [1,2,3]

# Generated at 2022-06-25 04:24:01.528379
# Unit test for function from_yaml
def test_from_yaml():
    data = b'foo: bar\r\n'
    var_1 = from_yaml(data, '<unicode>')

# Generated at 2022-06-25 04:24:06.622527
# Unit test for function from_yaml
def test_from_yaml():
    assert False


# Generated at 2022-06-25 04:24:12.048127
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test for from_yaml
    '''
    # From local file
    with open('from_yaml.yaml', 'r') as stream:
        data = from_yaml(stream)
        print(data)
    # From string
    yaml_str = '''
    - Hesperiidae
    - Papilionidae
    - Apatelodidae
    - Epiplemidae
    '''
    data = from_yaml(yaml_str)
    print(data)

# Generated at 2022-06-25 04:24:22.181141
# Unit test for function from_yaml
def test_from_yaml():
    import sys

    # We need to have the value of "from_yaml" before we can run the test,
    # so we must import it here instead of at the top.
    #from ansible.parsing.yaml.dumper import AnsibleDumper
    #from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.utils import AnsibleUnicode

    bytes_0 = b'<\x82j\xe4\x80\xfe\xed\x07\x9a\x84B\xc6\x0f\xfdI\xd3\xd7'

# Generated at 2022-06-25 04:24:33.788682
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)
    str_0 = '\x01\x02\x07\x08'
    var_1 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:24:40.342792
# Unit test for function from_yaml

# Generated at 2022-06-25 04:24:42.817377
# Unit test for function from_yaml
def test_from_yaml():
    print(">> test_from_yaml")


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:24:46.817489
# Unit test for function from_yaml
def test_from_yaml():
    print('Testing yaml_loader.from_yaml()')
    test_case_0()
    print('Test passed')

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:24:55.337117
# Unit test for function from_yaml
def test_from_yaml():
    filename = "tests/data/from_yaml/create.yml"
    bytes_0 = None
    with open(filename, "rb") as stream:
        bytes_0 = stream.read()
    var_0 = from_yaml(bytes_0, filename)
    assert isinstance(var_0, dict) == True
    assert var_0["inventory_name"] == "basic_inventory"
    assert isinstance(var_0['name'], str) == True
    assert var_0['name'] == 'basic_inventory'
    assert isinstance(var_0['hosts'], list) == True
    assert var_0['hosts'][0] == 'testhost'
    assert var_0['hosts'][1] == 'testhost2'
    assert len(var_0['vars']) == 2


# Generated at 2022-06-25 04:25:05.786372
# Unit test for function from_yaml
def test_from_yaml():
    string_0 = '\x00\x00\x01\x00\x00\x00\x00\x03\x00\x00\x00\x00\x00\xac\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = from_yaml(string_0, string_0)
    # '{\x00\x00\x01\x00\x00\x00\x00\x03\x00\x00\x00\x00\x00\xac\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00': '{\x00\x00\x01\x00\x00\x

# Generated at 2022-06-25 04:25:14.199292
# Unit test for function from_yaml
def test_from_yaml():

    # If the test gets this far, it's successful.

    assert True


# Testcases for function from_yaml
from_yaml_test_cases = []


# Testcases for function test_from_yaml
test_from_yaml_test_cases = []


# Testcases for function test_case_0
test_case_0_test_cases = []


# Testcases for function test_case_1
test_case_1_test_cases = []


# Testcases for function test_case_2
test_case_2_test_cases = []


# Testcases for function test_case_3
test_case_3_test_cases = []

# Testcases for function test_case_4
test_case_4_test_cases = []

# Testcases for function test_case_5
test

# Generated at 2022-06-25 04:25:21.165507
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None

# Generated at 2022-06-25 04:25:32.835223
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'N\xeb\xab\x8er\x03\x1d\xb3\x81\xcc\x89\xa0\xa1'
    bytes_1 = b'\xf4\x7f\t\x9e\x8d\xaa\x02\x1f\xb8\x94\xa0\xa3'
    bytes_2 = b'\x89\xa1\x98\xdd\xa8\x15\x1d\xb9\x88\xa0\xbe'
    bytes_3 = b'\xf8h\xaa\x94\xd6\x9c\x1f\xb8\x8a\xa0\xac'

# Generated at 2022-06-25 04:25:37.774965
# Unit test for function from_yaml
def test_from_yaml():

    # Asserts: Test #0
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)

# Generated at 2022-06-25 04:25:44.993102
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = from_yaml("%&")
    assert var_0 is None
    var_1 = from_yaml("""%YAML 1.2
    ---
    !!map {
      ? !!str "foobar"
        : !!str "tarbar",
      ? !!str "boofar"
        : !!str "farbar",
    }""")
    assert var_1 == {'boofar': 'farbar', 'foobar': 'tarbar'}
    var_2 = from_yaml("""%YAML 1.2
    ---
    - !!str "foo"
    - !!str "bar"
    - !!str "baz"
    """)
    assert var_2 == ['foo', 'bar', 'baz']

# Generated at 2022-06-25 04:25:54.462589
# Unit test for function from_yaml

# Generated at 2022-06-25 04:26:04.625921
# Unit test for function from_yaml
def test_from_yaml():
    case_0_result_0 = b'/\xec\x95\xac\xeb\x93\xa4\xec\x9d\xb4\xed\x96\x89\xed\x8a\xb8\xec\x9d\xb4\xec\x8a\xa4\xeb\xa5\xb4\xec\x9d\xb4\xec\x8a\xa4\xeb\xa5\xb4\xec\x9d\xb4\xec\x8a\xa4\xeb\xa5'  # noqa: E501

# Generated at 2022-06-25 04:26:14.337196
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-25 04:26:15.677340
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None

# Generated at 2022-06-25 04:26:26.462648
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b')\xd1\x0c\xd4\xee\x92\x93\x9b\x04\xb1\xfb-\xdeG`\xa02\x15'
    bytes_1 = b'\xe3\x12\xe0Rp\x8f\xab\xfe\xf6\x8a\x00\x9c\xbe\x95(\x01\x0f\xda\xeb\x90\xee\xf4\x12'

# Generated at 2022-06-25 04:26:30.553335
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except (AnsibleParserError, YAMLError) as exc:
        print('\nException encountered while testing! {}'.format(to_native(exc)))

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:26:44.624106
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'a: foo\nb: bar\n'
    int_0 = 1
    str_11 = 'a'
    int_1 = 0
    str_12 = 'b'
    int_2 = 1
    bytes_1 = b'b: bar\na: foo\n'
    str_0 = '{}'
    str_1 = '{}'
    str_2 = '{}'
    str_3 = '{}'
    str_4 = '{}'
    str_5 = '{}'
    str_6 = '{}'
    str_7 = '{}'
    str_8 = '{}'
    str_9 = '{}'
    str_10 = '{}'
    str_13 = '{}'
    str_14

# Generated at 2022-06-25 04:26:55.552150
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)
    bytes_1 = b'{"x8%\xbe\x80\x08\xbd\xe8[\x89\xdf\x9b'
    var_1 = json.loads(bytes_1)
    var_2 = b'H\x92\xb7\x9d\x00\x0f\xfe\x00*\x1b\xdc\xb8'
    var_3 = json.dumps(var_2, separators=(',', ':'))
    var_4 = from_yaml(var_3, var_3)

# Generated at 2022-06-25 04:26:59.274463
# Unit test for function from_yaml
def test_from_yaml():
    class template:
        SUCCESS_MSG = 'All Tests OK'
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 04:27:10.514117
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xd5\xfe\x19r\xfd\x8a\xe6\xac\xdd\x9c\x8e\xa5\xbb\xb7\x16\xd8\x95\x90\x1a\xfb\x80\xae\x95\xe42*\xc1\xed\xfc\xac'
    bytes_1 = b'Z\xed\xe0\xdc\xd5\x1d\xcc\x0b\x11\xf9\x0f\x0c\x7f\xd3\xc2:s\xf4\x91\x0f\xa1\x9f\xcd'

# Generated at 2022-06-25 04:27:17.951463
# Unit test for function from_yaml
def test_from_yaml():
    # Test with bytes as input
    t_0 = b'foo bar'
    t_1 = b'\u1234'
    t_2 = b'\n\n'
    t_3 = b'{"test": "json"}'
    assert from_yaml(t_0) == 'foo bar'
    assert from_yaml(t_1) == '\u1234'
    assert from_yaml(t_2) == '\n\n'
    assert from_yaml(t_3) == {'test': 'json'}

    # Test with strings as input
    s_0 = 'foo bar'
    s_1 = '\u1234'
    s_2 = '\n\n'
    s_3 = '{"test": "json"}'

# Generated at 2022-06-25 04:27:19.558392
# Unit test for function from_yaml
def test_from_yaml():
    data = '>>>'
    yaml_str = from_yaml(data, data)


# Generated at 2022-06-25 04:27:26.250022
# Unit test for function from_yaml
def test_from_yaml():
    # Run the function
    test_case_0()


# Unit test execution
if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:27:27.679216
# Unit test for function from_yaml
def test_from_yaml():
    assert True



# Generated at 2022-06-25 04:27:33.228935
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    test_case_0()

# Tests for AnsibleLoader class

# Generated at 2022-06-25 04:27:36.695365
# Unit test for function from_yaml
def test_from_yaml():
    global args, bytes_0
    bytes_0 = None
    test_case_0()
    print('bytes_0: ', bytes_0)
    return

# Import necessary modules

# Generated at 2022-06-25 04:27:45.942808
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    str_0 = to_native(bytes_0)
    var_0 = from_yaml(bytes_0, bytes_0)


if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:27:54.247295
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    bytes_1 = b'A\x8f\x9e\xbbH\x16\xb8y8\x05\x00\x16\x00\x00\x00'
    bytes_2 = b'f\xdb\x16\xc2\x15I\x0c\x8b\xb9\x11\x0f\xdd\x1f]\x93'
    bytes_3 = b'f\xdb\x16\xc2\x15I\x0c\x8b\xb9\x11\x0f\xdd\x1f]\x93'

# Generated at 2022-06-25 04:27:57.897053
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None

if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-25 04:27:58.996510
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    test_case_0()

# Generated at 2022-06-25 04:28:02.789464
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(TypeError):
        from_yaml()
    with pytest.raises(TypeError):
        from_yaml(data=1.0, file_name=1.0)

if __name__ == '__main__':
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:28:03.715769
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [test_case_0]
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-25 04:28:09.735776
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'_>\x1a\xed\xcf\x8e\xc4\xdda\xab\xb2\xca\xa0\x1e\x9b\x1a\xc5\xec3'
    var_0 = from_yaml(bytes_0)
    assert var_0 == {'key_0': 'value_0'}

# Generated at 2022-06-25 04:28:13.843262
# Unit test for function from_yaml
def test_from_yaml():
    assert globals().get('from_yaml') == __all__[0]



# Generated at 2022-06-25 04:28:14.845038
# Unit test for function from_yaml
def test_from_yaml():
    # TEST CASE: No tests written
    assert True

# Generated at 2022-06-25 04:28:19.925055
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{"t4hx_dX9=": -0.02416191226521572}'
    var_0 = from_yaml(str_0, str_0)


# Generated at 2022-06-25 04:28:31.077430
# Unit test for function from_yaml
def test_from_yaml():
    # The following test cases are used to determine whether the functions in the script work properly.
    # Each test case will be functional unit tested individually.

    # Test Case 0
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)
    return True


if __name__ == '__main__':
    print(test_from_yaml())

# Generated at 2022-06-25 04:28:36.698906
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    assert from_yaml(bytes_0, bytes_0)

# Generated at 2022-06-25 04:28:42.332968
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)


# Generated at 2022-06-25 04:28:46.478243
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 04:28:54.397468
# Unit test for function from_yaml
def test_from_yaml():
    kwargs = {}

    # Call function 'from_yaml' with the appropriate arguments
    try:
        file_name = 'foobar'
        show_content = True
        vault_secrets = None
        json_only = False
        ret_val = from_yaml(file_name, show_content, vault_secrets, json_only)
        assert ret_val is None
    except Exception as e:
        print('AnsibleParserError: "%s"' % (e,))
        raise

    # Check that the function returns the correct result
    assert ret_val == None

# Generated at 2022-06-25 04:28:58.115701
# Unit test for function from_yaml
def test_from_yaml():
    test_var = from_yaml('string')
    assert test_var == 'string'

# Generated at 2022-06-25 04:29:03.001274
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() == None

# Generated at 2022-06-25 04:29:11.140705
# Unit test for function from_yaml
def test_from_yaml():
    # Test case #0
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)

    # Test case #1
    bytes_1 = b'\xab\xec\xaa\x0c\xff\xa4'
    var_1 = from_yaml(bytes_1, bytes_1)

    # Test case #2
    bytes_2 = b'\xb2\x02\x00\xaa\x00\x11\x00\x1f\x00\x08'
    var_2 = from_yaml(bytes_2, bytes_2)

    # Test case #3

# Generated at 2022-06-25 04:29:19.215893
# Unit test for function from_yaml
def test_from_yaml():
    json_0 = '[1, {"test": 1}]'
    var_0 = from_yaml(json_0, '', False, None, True)
    assert var_0 == [1, {"test": 1}]
    assert var_0[0] == 1
    assert var_0[1] == {"test": 1}
    assert var_0[1]['test'] == 1
    json_1 = '{"test": 1}'
    var_1 = from_yaml(json_1, '', False, None, True)
    assert var_1 == {"test": 1}
    assert var_1['test'] == 1
    json_2 = '[1, [2, [3, [4, [5, [6]]]]]]'

# Generated at 2022-06-25 04:29:25.436367
# Unit test for function from_yaml
def test_from_yaml():
    # Try to from_yaml a UTF-8 encoded string (which is also a valid JSON)
    test_string = u"\u3042\u3044\u3046\u3048\u304a"
    assert isinstance(from_yaml(test_string), unicode) == True

    # Try to from_yaml a true boolean value and ensure a bool is returned
    assert isinstance(from_yaml(': true'), bool) == True

    # Try to from_yaml a false boolean value and ensure a bool is returned
    assert isinstance(from_yaml(': false'), bool) == True

    # Try to from_yaml a unicode string
    assert isinstance(from_yaml(u': "unicode"'), unicode) == True

    # Try to from_yaml an ASCII string

# Generated at 2022-06-25 04:29:39.684990
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)
    assert var_0 == [b'>', b'A', b'*', b'\xad\xc2\x9e\xe8', b'\x08\x82\x01\x02', b'\x00+\x19\xf9\xa1', b'\x82\x11\x13\x86', b'\x83\xc4\xdb\xc1', b'\x07\xe2\xff\x87', b'\x8b\x81@\x1f']


# Generated at 2022-06-25 04:29:48.452400
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'O\xb0\x86\xd4\x17\xe6'
    var_0 = from_yaml(bytes_0, bytes_0)
    bytes_1 = b'\xf9\x93\xfa\x88'
    var_1 = from_yaml(bytes_1, bytes_1)
    dict_2 = {
        'line': 13,
        'col': 7,
    }
    str_3 = 'test_value'
    dict_4 = {
        'row': 16,
        'col': 9,
    }
    dict_5 = {
    }
    dict_6 = {
        'line': 26,
        'col': 5,
    }

# Generated at 2022-06-25 04:29:48.904274
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:29:55.251122
# Unit test for function from_yaml
def test_from_yaml():
    # check if from_yaml() can handle the following types of input:
    #   1. a byte string
    bytes_0 = b'"abcdefg"'
    var_0 = from_yaml(bytes_0, bytes_0)
    assert(var_0 == 'abcdefg')

    #   2. a regular string w/ non-ascii characters
    bytes_1 = u'\u20ac'
    var_1 = from_yaml(bytes_1, bytes_1)
    assert(var_1 == u'\u20ac')

    # test the error handling cases, mainly to check if the exception
    # contains a file name and position of the error
    tmp_file_name = 'foo'

    # try parsing something that isn't json or yaml

# Generated at 2022-06-25 04:29:57.424482
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)

# Generated at 2022-06-25 04:30:04.373406
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)
    assert var_0 == b']>A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'

# Generated at 2022-06-25 04:30:08.915594
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)

# Generated at 2022-06-25 04:30:18.838664
# Unit test for function from_yaml
def test_from_yaml():
    def _from_yaml_test_case(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=False):
        return from_yaml(data, file_name, show_content, vault_secrets, json_only)

    # Call function
    _from_yaml_test_case('foo')

    # Call function
    _from_yaml_test_case('foo')

    # Call function
    _from_yaml_test_case('foo')

    from ansible.parsing.yaml.objects import AnsibleVaultSecret



# Generated at 2022-06-25 04:30:19.585551
# Unit test for function from_yaml
def test_from_yaml():
    assert False


# Generated at 2022-06-25 04:30:20.245091
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:30:30.309527
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)

# Generated at 2022-06-25 04:30:40.927456
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'S\x93\xba\x1e\x106\xa7\x85\x8a\xde\xd3\xebQ\x16\x1f\xa3\x9a\x1b\xde'
    bytes_1 = b'\x16\xba\x1e\x106\xa7\x85\x8a\xde\xd3\xebQ\x16\x1f\xa3\x9a\x1b\xde'
    bytes_2 = b'\x17\xb6\x1e\x106\xa7\x85\x8a\xde\xd3\xebQ\x16\x1f\xa3\x9a\x1b\xde'

# Generated at 2022-06-25 04:30:44.713706
# Unit test for function from_yaml
def test_from_yaml():
    mock = Mock()

    # Call method
    from_yaml(mock)

    # Check if method was called
    assert mock.called is True

    # Check number of method calls
    assert mock.call_count == 1



if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:30:47.418380
# Unit test for function from_yaml
def test_from_yaml():
    assert False


# Generated at 2022-06-25 04:30:48.532945
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Load a yaml formatted playbook.  Return data structure

# Generated at 2022-06-25 04:30:55.132172
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)


if __name__ == '__main__':
    # Testing
    test_from_yaml()

# Generated at 2022-06-25 04:31:02.532074
# Unit test for function from_yaml
def test_from_yaml():
    data = b'fix_unicode_0: fix_unicode_0'
    file_name = b'<string>'
    show_content = True
    vault_secrets = None
    json_only = False
    var_3 = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    assert var_3 == {'fix_unicode_0': 'fix_unicode_0'}


# Test for function test_case_0

# Generated at 2022-06-25 04:31:07.075167
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()

    parser.add_argument("--debug",
                        action='store_true',
                        help="Enable debugging")

    args, _ = parser.parse_known_args()

    if args.debug:
        import logging
        logging.basicConfig(level=logging.DEBUG)
        logging.debug("Enabling debug mode")

    test_from_yaml()

# Generated at 2022-06-25 04:31:11.447634
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    var_0 = from_yaml(bytes_0, bytes_0)


# Generated at 2022-06-25 04:31:20.062362
# Unit test for function from_yaml

# Generated at 2022-06-25 04:31:39.042775
# Unit test for function from_yaml
def test_from_yaml():
    # Arguments for test case 0
    bytes_0 = b'>]A*\xa1\xda\xb4\xc4\xce1\xfe\xd2\xa3\xd9i4'
    # Arguments for test case 1
    bytes_1 = b'\x0c\x01\x14\x00\x03\x01\x07\x00\x00\x00\x02\x00\x00\x00\x00\x00'
    # Arguments for test case 2

# Generated at 2022-06-25 04:31:48.039106
# Unit test for function from_yaml
def test_from_yaml():
    def test_func_0(var_0):
        bytes_0 = b'}\x0e\x1d\x84\r\xa0\x9b\x81\x88\x12\x0c\xd8Q\xb1\x1e\xe5\xbd\x9f\xa6'
        if len(var_0) > len(bytes_0):
            print('>', end='')
        else:
            print('<', end='')

    def test_func_1(var_1):
        bytes_0 = b'\xbe\x04\x07\x96\xf5\x85=\xb4\xcd\x0f\x9a\xab\xcd\xf1\x8d\xb6\x91\x13'