

# Generated at 2022-06-25 04:21:46.586898
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    test_case_0()
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 04:21:52.370747
# Unit test for function from_yaml
def test_from_yaml():
    # Reset the internal name list
    AnsibleJSONDecoder.reset_secrets()

    # Test case 0
    test_case_0()


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:21:59.564590
# Unit test for function from_yaml
def test_from_yaml():
    float_0 = -12.23528531637405
    var_0 = from_yaml(float_0)
    assert var_0 == -12.23528531637405
    bool_0 = True
    var_1 = from_yaml(bool_0)
    assert var_1
    bool_1 = False
    var_2 = from_yaml(bool_1)
    assert not var_2
    str_0 = 'asf'
    var_3 = from_yaml(str_0)
    assert var_3 == 'asf'
    int_0 = 817154167
    var_4 = from_yaml(int_0)
    assert var_4 == 817154167
    list_0 = []
    var_5 = from_yaml(list_0)

# Generated at 2022-06-25 04:22:01.887131
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()
    print('All test cases for from_yaml passed')

# Generated at 2022-06-25 04:22:09.614264
# Unit test for function from_yaml
def test_from_yaml():

    # Test case where float_0 = float(float_0) + float(-12.23528531637405)
    float_0 = float(float_0) + float(-12.23528531637405)
    var_0 = from_yaml(float_0)
    # Test case where int_1 = int(int_1) + int(1)
    int_1 = int(int_1) + int(1)
    var_1 = from_yaml(int_1)
    # Test case where str_2 = chr(ord(str_2) + int(1))
    str_2 = chr(ord(str_2) + int(1))
    var_2 = from_yaml(str_2)
    # Test case where tuple_3 = list((tuple_3))
    tuple_

# Generated at 2022-06-25 04:22:10.204131
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:22:12.089610
# Unit test for function from_yaml
def test_from_yaml():
    assert True


# Generated at 2022-06-25 04:22:20.841649
# Unit test for function from_yaml
def test_from_yaml():
    def test_case_0():
        float_0 = -12.23528531637405
        var_0 = from_yaml(float_0)

    def test_case_1():
        float_0 = -4.157626587304743e-05
        var_0 = from_yaml(float_0)

    def test_case_2():
        float_0 = -0.00018452700302011838
        var_0 = from_yaml(float_0)

    def test_case_3():
        float_0 = 4.961224871763836e-05
        var_0 = from_yaml(float_0)

    def test_case_4():
        float_0 = -2.8539952967603887
        var_0 = from_

# Generated at 2022-06-25 04:22:21.654503
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml == 'from_yaml'

# Generated at 2022-06-25 04:22:27.242744
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
        [foo, bar, baz]
'''
    data = from_yaml(data)
    assert data == ['foo', 'bar', 'baz']

    data = '''
        foo: 1
        bar:
          - 2
          - 3
        baz:
          - 4
          - 5
          - 6
'''
    data = from_yaml(data)
    assert data == {'foo': 1, 'bar': [2, 3], 'baz': [4, 5, 6]}

    data = '''
        a: 1
        b:
          c: 2
          d:
            e: 3
            f:
              g: 4
'''
    data = from_yaml(data)

# Generated at 2022-06-25 04:22:34.075771
# Unit test for function from_yaml
def test_from_yaml():
    # assert from_yaml() ==
    pass



# Generated at 2022-06-25 04:22:34.958342
# Unit test for function from_yaml
def test_from_yaml():
    assert(True)

# Generated at 2022-06-25 04:22:37.408690
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'k\n'
    var_0 = from_yaml(str_0, str_0)



# Generated at 2022-06-25 04:22:43.935106
# Unit test for function from_yaml
def test_from_yaml():
    global str_0, str_1
    str_0 = 'a: k\n'
    str_1 = 'v\n'

    print('Running unit test for function from_yaml')

    # Test case 0
    test_case_0()

    # Test case 1
    ret_1 = from_yaml(str_1, str_1)
    assert ret_1 == 'v\n'
    print('Test case 1 passed')

    print('All test cases passed')

# Generated at 2022-06-25 04:22:51.082291
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'k\n'
    var_0 = 'k\n'
    var_1 = from_yaml(str_0, var_0)


# Generated at 2022-06-25 04:22:55.759170
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == '__main__':
    #from ansible.module_utils.basic import AnsibleModule
    #mod = AnsibleModule(
    #    argument_spec=dict(
    #       params=dict(required=True, type='str', default=None),
    #    )
    #)
    test_from_yaml()

# Generated at 2022-06-25 04:23:07.734104
# Unit test for function from_yaml
def test_from_yaml():
    # We only need to test what we're using in this file. Otherwise, it's a direct
    # pass-through to other code that's already tested.
    # test_case_0(self)

    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-25 04:23:10.658878
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = 'k'
    var_1 = from_yaml(str_1, str_1)

# Generated at 2022-06-25 04:23:19.881010
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.utils.unicode as unicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    value = {
        'unicode': unichr(40960),
        'list': [1,2,3,4],
        'dict': {
            'one': 1,
            'two': 2,
            'three': 3
        }
    }

    yaml_value1 = '''dict: {three: 3, two: 2, one: 1}
list: [1, 2, 3, 4]
unicode: "\u0a00"
'''

    yaml_value2 = b'''dict: {three: 3, two: 2, one: 1}
list: [1, 2, 3, 4]
unicode: "\u0a00"
'''

   

# Generated at 2022-06-25 04:23:28.246283
# Unit test for function from_yaml
def test_from_yaml():
    # test_case_0
    str_0 = 'k\n'
    var_0 = from_yaml(str_0, str_0)
    # test_case_1
    str_1 = 'k'
    var_1 = from_yaml(str_1, str_1)
    # test_case_2
    str_2 = ''
    var_2 = from_yaml(str_2, str_2)
    # test_case_3
    str_3 = '"k\n"'
    var_3 = from_yaml(str_3, str_3)
    # test_case_4
    str_4 = '{'
    var_4 = from_yaml(str_4, str_4)

# Generated at 2022-06-25 04:23:36.128874
# Unit test for function from_yaml
def test_from_yaml():
    # Tests with a loaded file
    with open('data.yaml') as f:
        data = f.read()
        data = from_yaml(data)
    return data


if __name__ == '__main__':
    data = test_from_yaml()
    print(data)

# Generated at 2022-06-25 04:23:38.036724
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)


if __name__ == "__main__":
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:23:44.855993
# Unit test for function from_yaml
def test_from_yaml():
    data = b"foo: 13\nbar: I love you!\n"
    data1 = b"{'foo': 1, 'bar': 2}"

    assert from_yaml(data1) == {'foo': 1, 'bar': 2}
    assert from_yaml(data) == {'foo': 13, 'bar': 'I love you!'}

    assert from_yaml(b'[3, 5, 7]') == [3, 5, 7]
    assert from_yaml(b'{"a": 3, "b": 5}') == {"a": 3, "b": 5}


if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:23:47.038060
# Unit test for function from_yaml
def test_from_yaml():
    print("BEFORE FUNC")
    test_case_0()
    print("AFTER FUNC")

# Generated at 2022-06-25 04:23:51.386970
# Unit test for function from_yaml
def test_from_yaml():
    for param in [bytes, string]:
        for arg in [bytes, string]:
            try:
                assert isinstance(from_yaml(arg), dict)
            except AssertionError:
                pass
    try:
        assert isinstance(from_yaml(bytes), dict)
    except AssertionError:
        pass
    try:
        assert isinstance(from_yaml(string), dict)
    except AssertionError:
        pass


test_case_0()

test_from_yaml()

# Generated at 2022-06-25 04:23:58.988684
# Unit test for function from_yaml
def test_from_yaml():
    # Bytes IO object
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)
    # Test assertion
    print(var_0)
    # BytesIO with position and mode arguments
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0, '<string>')
    # Test assertion
    print(var_0)


# Generated at 2022-06-25 04:24:03.225724
# Unit test for function from_yaml
def test_from_yaml():
    t_1 = b'\xea\x15\xc6\xac\x07\x16\xed'
    try:
        t_0 = from_yaml(t_1)
    except AnsibleParserError as e:
        t_2 = e
    assert t_0 is None
    assert t_2 is not None


# Generated at 2022-06-25 04:24:12.944564
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = b'\n\nname: Bob\n'
    result = from_yaml(yaml_data)
    assert result == {'name': 'Bob'}
    yaml_data = b'name: Bob\n\n'
    result = from_yaml(yaml_data)
    assert result == {'name': 'Bob'}
    yaml_data = b'name: Bob\n  age: 25\n'
    result = from_yaml(yaml_data)
    assert result == {'name': 'Bob', 'age': 25}
    yaml_data = b'---\nname: Bob\n'
    result = from_yaml(yaml_data)
    assert result == {'name': 'Bob'}

# Generated at 2022-06-25 04:24:14.482382
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# No-op test for functions with yaml strings in their names

# Generated at 2022-06-25 04:24:22.332347
# Unit test for function from_yaml
def test_from_yaml():
    res_1 = None
    ret_1 = None
    ret_2 = None
    ret_3 = None
    ret_4 = None
    ret_5 = None
    ret_6 = None
    ret_7 = None

    # Function call
    ret_1 = from_yaml('{}')
    ret_2 = from_yaml('\n{}\n\n')

    # Return type
    assert isinstance(ret_1, dict)
    assert isinstance(ret_2, dict)

    # Function call
    res_1 = from_yaml('\n{}\n')

    # Return type
    assert isinstance(res_1, dict)

    # Function call
    ret_3 = from_yaml('\n{}\n\n')

    # Return type

# Generated at 2022-06-25 04:24:30.454238
# Unit test for function from_yaml
def test_from_yaml():
    # Example string
    input = "test string"

    # Example unicode
    expected = 'test string'

    # Run the function
    result = from_yaml(input)

    # Assert the expected result
    assert result == expected


# Unit tests for function _handle_error

# Generated at 2022-06-25 04:24:34.141601
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except (TypeError, ValueError, NameError):
        assert False
    # assert True

# CHECK
from_yaml(b'\xea\x15\xc6\xac\x07\x16\xed')

# Generated at 2022-06-25 04:24:36.593173
# Unit test for function from_yaml
def test_from_yaml():
    assert True


# Generated at 2022-06-25 04:24:42.645965
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [
        (b'\xea\x15\xc6\xac\x07\x16\xed', None, None, True, None, True, None),
    ]
    for args in test_cases:
        if args[-1] is not None:
            continue
        try:
            retval = from_yaml(*args[:-1])
        except Exception as e:
            retval = repr(e)
        print(retval)
        assert retval == args[-1]

# Generated at 2022-06-25 04:24:53.642736
# Unit test for function from_yaml
def test_from_yaml():
    buf = bytearray(b"\xbe\x0b\x00\x00\x00\x00\x00\x00\x00")
    bytes_0 = b'|\n  A line\n  that contains\n  multiple\n  lines\n'
    bytes_1 = b'{}\n'
    bytes_2 = b'{A line\nthat contains\nmultiple\nlines\n'
    bytes_3 = b'A line\nthat contains\nmultiple\nlines\n'
    bytes_4 = b'{A line\nthat contains\nmultiple\nlines\n\n'

# Generated at 2022-06-25 04:24:57.090767
# Unit test for function from_yaml
def test_from_yaml():
    print('start to test')
    assert callable(from_yaml)
    print('test passed')

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:25:04.259061
# Unit test for function from_yaml
def test_from_yaml():
    # Ensure the following is true:
    # `json.loads(data) == from_yaml(data, json_only=True)`
    data = '{"a": "b"}'
    json_data = json.loads(data)
    yaml_data = from_yaml(data, json_only=True)
    assert json_data == yaml_data

# Generated at 2022-06-25 04:25:14.559918
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest


# Generated at 2022-06-25 04:25:19.288775
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)
    print(var_0)
    test_case_0()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 04:25:21.295148
# Unit test for function from_yaml
def test_from_yaml():
    # TODO: implement your unit test here!
    print('Test unit test not implemented')

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:25:34.857846
# Unit test for function from_yaml
def test_from_yaml():
    data = '{\n  "foo": "bar"\n}'
    file_name = '<string>'
    show_content = True
    vault_secrets = None
    json_only = False
    var_0 = from_yaml(data, file_name, show_content, vault_secrets, json_only)

    # Check the type of var_0, should be dict
    if not isinstance(var_0, dict):
        raise AssertionError()

    # Check the size of var_0, should be 1
    if len(var_0) != 1:
        raise AssertionError()

    # Check if the dict has the key foo
    var_0_foo = var_0.get('foo', None)
    if var_0_foo is None:
        raise AssertionError()

   

# Generated at 2022-06-25 04:25:43.951259
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)
    var_1 = from_yaml(b'\x10\xea\x01\xea\xed\xf5\x7f;\xfc\x8d')
    var_2 = from_yaml(b'\xb2\xee>\xdc\xea"\xb8\x0b')
    var_3 = from_yaml(b'\xb2\xee>\xdc\xea"\xb8\x0b')

# Generated at 2022-06-25 04:25:45.061374
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# vim: expandtab filetype=python

# Generated at 2022-06-25 04:25:54.524645
# Unit test for function from_yaml
def test_from_yaml():

    bytes_0 = b'\xee\xa7\x82\xcf\xe2\xab\x11\x15\x92\x11\x8b\x0f\xe2\xb2\x85\xa6\x1e'
    bytes_1 = b'\x0a'
    bytes_2 = b'\x00\xab\x9f\x9b\xe5\x91\x8f\x11\x1e\xca\x8b\x9d\x99\x80\xee\xbe'
    bytes_3 = b'\xab'

# Generated at 2022-06-25 04:25:55.716763
# Unit test for function from_yaml
def test_from_yaml():
    assert False



# Generated at 2022-06-25 04:25:58.024523
# Unit test for function from_yaml
def test_from_yaml():
    assert True  # testing is not yet implemented


# Generated at 2022-06-25 04:26:06.534624
# Unit test for function from_yaml
def test_from_yaml():
    # Option 1
    print(from_yaml(b'test'))
    # Option 2
    print(from_yaml(b'test', file_name='<string>'))
    # Option 3
    print(from_yaml(b'test', file_name='<string>', show_content=True))
    # Option 4
    print(from_yaml(b'test', file_name='<string>', show_content=True, vault_secrets=None))
    # Option 5
    print(from_yaml(b'test', file_name='<string>', show_content=True, vault_secrets=None, json_only=False))
    # Option 6
    # Non-exhaustive test


# Generated at 2022-06-25 04:26:10.355242
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:26:20.233581
# Unit test for function from_yaml
def test_from_yaml():
  test_cases = [
    # Copyright (c) 2018, Red Hat, Inc.
    test_case_0,
  ]
  for test_case in test_cases:
    try:
      test_case()
    except Exception as e:
      print(e)
      assert False
      return

  print('Test passed.')

if __name__ == "__main__":
  test_from_yaml()

# Generated at 2022-06-25 04:26:26.457821
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.modules.system.ping import Ping

    data = '1'
    ret0 = from_yaml(data, file_name='/tmp/cyberoam.yml', show_content=True, vault_secrets=None, json_only=False)
    ret1 = from_yaml(data, file_name='/tmp/ping.py', show_content=True, vault_secrets=None, json_only=False)
    print(ret0)
    print(ret1)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:26:36.717532
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as exc:
        print(exc)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:26:45.400178
# Unit test for function from_yaml
def test_from_yaml():

    # Test if the function from_yaml exits
    try:
        from ansible.parsing.yaml.dumper import AnsibleDumper
        from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    except ImportError:
        # Ansible < 2.0
        from ansible.utils.yaml import AnsibleDumper
        from ansible.utils.yaml import AnsibleMapping, AnsibleUnicode

    test_dict = {
        "hosts": "localhost",
        "remote_user": "root",
        "tasks": [
            {
                "name": "Print date",
                "command": "date"
            }
        ]
    }

    data = yaml.dump(test_dict, Dumper=AnsibleDumper)

    yaml

# Generated at 2022-06-25 04:26:49.130850
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml('\n#!\n---') == '#!')


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:26:50.048801
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)

# Generated at 2022-06-25 04:26:58.169986
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x01\x02\xff\x01\xff\xfe'
    #bytes_0 = b'1'
    #bytes_0 = b'\x7f'
    #bytes_0 = b'\xff'
    #bytes_0 = b'foo'
    #bytes_0 = b'1' * 10000
    #bytes_0 = b'\xff' * 1000
    #bytes_0 = b'\xff' * 10000
    #bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    #bytes_0 = b'[1,2,3]'
    #bytes_0 = b'[1,2,3,4,5]'
    #bytes_0 = b'[1,2,3,4,5

# Generated at 2022-06-25 04:27:04.017539
# Unit test for function from_yaml
def test_from_yaml():
    with open('tests/yaml/unicode.yml', 'rb') as file:
        src_bytes = b'\xef\xbb\xbf'
        src_bytes += file.read()
    var_1 = from_yaml(src_bytes)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:27:10.387742
# Unit test for function from_yaml
def test_from_yaml():
    a = 'this is a string'
    assert from_yaml(a) == 'this is a string'
    b = "this is also a string\nand another line"
    assert from_yaml(b) == "this is also a string\nand another line"
    c = '''\
    ---
    - hosts: all
      sudo: True'''
    assert from_yaml(c) == [{'hosts': 'all', 'sudo': True}]

# Generated at 2022-06-25 04:27:11.674575
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("") != None


# Generated at 2022-06-25 04:27:18.605637
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b"\x61\x61") == "aa"
    assert from_yaml(b"\x62") == "b"
    assert from_yaml(b"\x62\x6c\x6f\x6e\x6b") == "blonk"
    assert from_yaml(b"\x62\x6f\x6b\x6e\x6f") == "bokno"
    assert from_yaml(b"\x63\x6f\x6e\x6c\x6f\x6e") == 'colon'
    assert from_yaml(b"\x69\x74\x68") == 'ith'

# Generated at 2022-06-25 04:27:30.038238
# Unit test for function from_yaml
def test_from_yaml():
    # Testing basic json input
    bytes_0 = b'[1,2,3,4,5]'
    var_0 = from_yaml(bytes_0)
    assert var_0 == [1, 2, 3, 4, 5]
    # Testing basic yaml input
    bytes_0 = b'---\n[1,2,3,4,5]'
    var_0 = from_yaml(bytes_0)
    assert var_0 == [1, 2, 3, 4, 5]
    # Testing a invalid json input
    bytes_0 = b'{"name": "a",}'
    var_0 = from_yaml(bytes_0)
    assert var_0 == {"name": "a"}
    # Testing a invalid yaml input

# Generated at 2022-06-25 04:27:38.854631
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)


if __name__ == "__main__":
    test_case_0();

# Generated at 2022-06-25 04:27:44.623859
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Test for function from_yaml

# Generated at 2022-06-25 04:27:47.261320
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-25 04:27:53.799440
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    import ansible.module_utils.basic

    if PY3:
        # Sometimes we get a lot of instances of this, but it doesn't seem
        # to be a problem.  This is from the json parser, which is part of
        # the json module.
        ansible.module_utils.basic._ANSIBLE_ARGS = None

    for i in range(0, 5000):
        try:
            test_case_0()
        except AnsibleParserError as e:
            # We expect this to happen, so we can ignore it
            pass


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:27:58.920812
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)
    assert var_0 == '\xea\x15\xc6\ac\x07\x16\xed'

# Generated at 2022-06-25 04:28:06.803036
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)


if __name__ == "__main__":
    from random import randint
    from timeit import default_timer as timer
    from platform import architecture

    program_start = timer()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13

# Generated at 2022-06-25 04:28:08.616084
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)



# Generated at 2022-06-25 04:28:16.509726
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)
    assert str(var_0) == "true"
    var_1 = from_yaml(b'\xfb\x00\x06\x01\x80\x00\x00\x00\x00\x00\x00')
    assert var_1 == 9.223372036854776e+18
    var_2 = from_yaml(b"\x8a4\x10\x00\x00\x00\x00\x00\x00")
    assert var_2 == -35184372088832

# Generated at 2022-06-25 04:28:20.069899
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:28:20.885228
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True



# Generated at 2022-06-25 04:28:39.734630
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [
        # Test case #0
        {
            'inputs': [
                b'\xea\x15\xc6\xac\x07\x16\xed',  # bytes_0
            ],
            'outputs': [
                None,  # var_0
            ],
            'expects': [
                None,
            ],
        },
    ]
    test_case_count = len(test_cases)
    print('Test case count = %d' % test_case_count)

    test_case_index = 0
    while test_case_index < test_case_count:
        test_case = test_cases[test_case_index]

        # Create variables from inputs
        var_0 = test_case['inputs'][0]

        # Call the function under test

# Generated at 2022-06-25 04:28:40.342031
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Test case 1: JSON only

# Generated at 2022-06-25 04:28:45.376314
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)
    bytes_1 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_1 = from_yaml(bytes_1)
    bytes_2 = b'\xa9\x9f\x16\xf8\xfb\x05\xad'
    var_2 = from_yaml(bytes_2)
    bytes_3 = b'\xa9\x9f\x16\xf8\xfb\x05\xad'
    var_3 = from_yaml(bytes_3)

# Generated at 2022-06-25 04:28:55.907725
# Unit test for function from_yaml
def test_from_yaml():
    bytes_1 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_1 = from_yaml(bytes_1)
    assert var_1 == '\xea\x15\xc6\xac\x07\x16\xed'

    bytes_2 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_2 = from_yaml(bytes_2, json_only=True)
    assert var_2 == '\xea\x15\xc6\xac\x07\x16\xed'

    bytes_3 = b"\x1b[2J\x1b[H"
    var_3 = from_yaml(bytes_3)

# Generated at 2022-06-25 04:28:58.221313
# Unit test for function from_yaml
def test_from_yaml():
    assert_equal(from_yaml(bytes_0), var_0)

# Generated at 2022-06-25 04:29:05.151037
# Unit test for function from_yaml
def test_from_yaml():
    '''
    The function from_yaml is not implemented
    '''
    try:
        from_yaml()
    except NotImplementedError:
        pass # desired result

# Generated at 2022-06-25 04:29:07.095575
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as exception_1:
        print(str(exception_1))

# Generated at 2022-06-25 04:29:17.596046
# Unit test for function from_yaml
def test_from_yaml():
    # <ParseResult(func=test_case_0, args=(), kwargs={})>
    result = test_case_0.__code__.co_consts[0]

    assert result == (
        'ea15c6ac0716ed',
        'Y\xea\x15\xc6\xac\x07\x16\xed',
        '\x15_\x15\xea\x15\xc6\xac\x07\x16\xed',
    )


if __name__ == '__main__':
    # add arguments for more testing
    import sys

    args = sys.argv[1:]

    # test case 0
    if '-t0' in args:
        test_case_0()

# Generated at 2022-06-25 04:29:24.299904
# Unit test for function from_yaml
def test_from_yaml():
    data = b'''{
        "foo": "bar"
    }'''

    # yaml parser mode
    var_0 = from_yaml(data)
    assert var_0 == {u'foo': u'bar'}

    # json parser mode
    var_1 = from_yaml(data, json_only=True)
    assert var_1 == {"foo": "bar"}



# Generated at 2022-06-25 04:29:29.109723
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Ensure the from_yaml function works properly
    '''
    import os
    import tempfile
    import textwrap
    import contextlib

    @contextlib.contextmanager
    def _tempfile_maker(content):
        fd, fpath = tempfile.mkstemp()
        with os.fdopen(fd, 'w') as f:
            f.write(content)
        yield fpath
        os.remove(fpath)

    data_set = {'test1': ['test1', 'test2']}
    with _tempfile_maker(u'[1,2,3]') as fpath:
        data = from_yaml(fpath)
        assert data == [1, 2, 3]

# Generated at 2022-06-25 04:29:49.237010
# Unit test for function from_yaml
def test_from_yaml():
    # code to test

    # test cases

    # test case 0
    try:
        test_case_0()
    except Exception as err:
        print(err)

# Generated at 2022-06-25 04:29:52.812465
# Unit test for function from_yaml
def test_from_yaml():
    function_name = 'from_yaml'
    try:
        # Run 'from_yaml' function
        test_case_0()
    except Exception as e:
        # Assertion error
        assert False, "Error raised during testing of " + function_name + " function. Error: " + str(e)

# Main function
if __name__ == '__main__':
    # Run test function
    test_from_yaml()

# Generated at 2022-06-25 04:29:58.989675
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)

    bytes_0 = b'\x99\xa6\xeb\xf2\x9c\x0e\x1c\xae'
    var_0 = from_yaml(bytes_0)

    bytes_0 = b'\x98\x88'
    var_0 = from_yaml(bytes_0)

    bytes_0 = b'\x94\x06\xae\x1f\xdf\xc1\x0c\x93'
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:30:09.973264
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = b'''\
    package:
      name: nginx
      state: installed
      update_cache: yes

    service:
      name: nginx
      state: started
      enable: yes
    '''
    var_1 = from_yaml(var_0, '<string>')
    if not var_1 == {'package': {'state': 'installed', 'update_cache': True, 'name': 'nginx'}, 'service': {'state': 'started', 'enable': True, 'name': 'nginx'}}:
        raise Exception('Failed test_from_yaml')
    var_1 = b'hello\x10\t\n\t\n'
    var_2 = from_yaml(var_1, '<string>', False)

# Generated at 2022-06-25 04:30:14.409352
# Unit test for function from_yaml
def test_from_yaml():
    # Test `data` type parameter
    test_case_0()

# Generated at 2022-06-25 04:30:16.280851
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:30:22.160195
# Unit test for function from_yaml
def test_from_yaml():
    print('Running test for from_yaml()')
    test_case_0()

if __name__ == '__main__':
    print('Running test for from_yaml.py')
    test_from_yaml()

# Generated at 2022-06-25 04:30:25.168525
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_1 = from_yaml(bytes_0)
    print(var_1)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:30:35.213800
# Unit test for function from_yaml
def test_from_yaml():
    test_input_0 = 'FwLxB'
    test_input_1 = '\x00'
    test_input_2 = b'\x00'
    test_input_3 = '\x00'
    test_input_4 = b'\x00'
    test_input_5 = '\x00'
    test_input_6 = b'\x00'
    test_input_7 = '\x00'
    test_input_8 = b'\x00'
    test_input_9 = b'\x00'
    test_input_10 = '\x00'
    test_input_11 = b'\x00'
    test_input_12 = '\x00'
    test_input_13 = b'\x00'

# Generated at 2022-06-25 04:30:38.521261
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    ---
    foo: bar
    ...
    '''

    assert from_yaml(data) == {'foo': 'bar'}

# Generated at 2022-06-25 04:30:59.660895
# Unit test for function from_yaml
def test_from_yaml():
    # Test case 0
    test_case_0()


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:31:00.614794
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:31:03.979308
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xea\x15\xc6\xac\x07\x16\xed'
    var_0 = from_yaml(bytes_0)
    try:
        assert var_0 == bytes_0
    except AssertionError:
        test_case_0()


# Generated at 2022-06-25 04:31:06.598869
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True


# Generated at 2022-06-25 04:31:12.004477
# Unit test for function from_yaml
def test_from_yaml():
    # See: https://github.com/ansible/ansible/blob/devel/lib/ansible/parsing/dataloader.py
    # import lib_from_yaml as syms
    # test_case_0()
    pass


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:31:15.383210
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = bytes("\xea\x15\xc6\xac\x07\x16\xed", "utf-8")
    var_0 = from_yaml(bytes_0)



# Generated at 2022-06-25 04:31:22.355254
# Unit test for function from_yaml
def test_from_yaml():
    # Example of a unicode string
    var_1 = u'\u20ac'
    var_2 = from_yaml(var_1)
    # Example of a unicode string
    var_3 = u'\xe9'
    var_4 = from_yaml(var_3)
    # Example of a unicode string
    var_5 = u'\u10d0'
    var_6 = from_yaml(var_5)
    # Example of a unicode string
    var_7 = u'\uef03'
    var_8 = from_yaml(var_7)
    # Example of a unicode string
    var_9 = u'\xea\x15\xc6\xac\x07\x16\xed'

# Generated at 2022-06-25 04:31:24.938061
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [
        (None, None)
    ]

    for arg, expected in test_cases:
        assert expected == from_yaml(arg)

# Generated at 2022-06-25 04:31:29.594690
# Unit test for function from_yaml
def test_from_yaml():
    file_name = ""
    show_content = True
    data = ""
    vault_secrets = ""
    json_only = False

    assert isinstance(from_yaml(data, file_name, show_content, vault_secrets, json_only), (dict, list))


# Generated at 2022-06-25 04:31:36.795289
# Unit test for function from_yaml
def test_from_yaml():
    n_data = u'\x50\x4e\x4f\x54\x4f\x4f\x4e\x20\x5a\x45\x48\x4f'  #u'PNOTOON ZEHO'
    n_file = u'./test/data/vault_parsing.yaml'
    n_show_content = True
    vault_secrets = None
    n_json_only = False
    new_data = from_yaml(n_data, n_file, n_show_content, vault_secrets, n_json_only)
    assert new_data == u'PNOTOON ZEHO'
