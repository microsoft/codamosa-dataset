

# Generated at 2022-06-25 04:21:47.071196
# Unit test for function from_yaml
def test_from_yaml():
    print('Test case 0: Verify simple python loads and dumps...')
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:21:54.609745
# Unit test for function from_yaml
def test_from_yaml():
    args = None
    assert from_yaml(args) is None

    args = False
    assert from_yaml(args) is False

    args = True
    assert from_yaml(args) is True

    args = ['test', 'array']
    assert from_yaml(args) == ['test', 'array']

    args = {'test': 'dict'}
    assert from_yaml(args) == {'test': 'dict'}

# Generated at 2022-06-25 04:21:57.052322
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:21:59.088165
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True

test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:22:08.194491
# Unit test for function from_yaml
def test_from_yaml():
    assert (from_yaml(1384.0) == 1384.0)
    assert (from_yaml('hello') == 'hello')
    assert (from_yaml(['hello'])[0] == 'hello')
    assert (from_yaml({'hello':'world'})['hello'] == 'world')
    assert (from_yaml(None) is None)
    assert (from_yaml([]) == [])
    assert (from_yaml({}) == {})
    assert (from_yaml([1, "2", {"3": 4}]) == [1, "2", {"3": 4}])
    assert (from_yaml({"1": 2, "3": 4}) == {"1": 2, "3": 4})

# Generated at 2022-06-25 04:22:11.812570
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:22:12.736663
# Unit test for function from_yaml
def test_from_yaml():
    assert True



# Generated at 2022-06-25 04:22:17.098611
# Unit test for function from_yaml
def test_from_yaml():
    # For function from_yaml
    float_0 = 1384.0
    var_0 = from_yaml(float_0)

    assert var_0 != float_0

# Generated at 2022-06-25 04:22:19.857386
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    pass

# Generated at 2022-06-25 04:22:21.419914
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception:
        assert False


# Generated at 2022-06-25 04:22:33.602466
# Unit test for function from_yaml
def test_from_yaml():
    assert ansible.parsing.yaml.dumper.yaml.dump(from_yaml(u'{ "test": "yes", "test2": { "deep": { "deeper": "yes", "deeper2": "no" } }, "test3": "nested" }')) == u'{test: yes, test2: {deep: {deeper: yes, deeper2: no}}, test3: nested}\n'

# Generated at 2022-06-25 04:22:35.188200
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('''['foo', {'bar': ('baz', None, 1.0, 2)}]''') == [u'foo', {u'bar': (u'baz', None, 1.0, 2)}]

# Generated at 2022-06-25 04:22:38.251785
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)


# Generated at 2022-06-25 04:22:41.076201
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('')

# Generated at 2022-06-25 04:22:51.840594
# Unit test for function from_yaml
def test_from_yaml():
    assert 'eyJhcGlfa2V5IjogImFiYyJ9' == from_yaml('eyJhcGlfa2V5IjogImFiYyJ9')
    assert ansible.constants.FROM_YAML_ALLOWLIST == from_yaml('eyJhcGlfa2V5IjogImFiYyJ9')
    assert [ 'data' ] == from_yaml('eyJhcGlfa2V5IjogImFiYyJ9')
    assert [ 'data' ] == from_yaml('eyJhcGlfa2V5IjogImFiYyJ9')
    assert [ 'data' ] == from_yaml('eyJhcGlfa2V5IjogImFiYyJ9')

# Generated at 2022-06-25 04:22:58.790380
# Unit test for function from_yaml
def test_from_yaml():
    cases = [
        ('\n    rand_comm:\n      - This has been randomized\n    ', {'rand_comm': ['This has been randomized']}),
        ('{this is not json}', None),
        ('{this is not json', None),
        ('\n- this is not yaml', None),
    ]

    for arg, expected in cases:
        actual = from_yaml(arg)
        if expected != actual:
            raise Exception('%s != %s' % (expected, actual))


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:23:13.074408
# Unit test for function from_yaml
def test_from_yaml():
    """ Test for jackson-databind RCE
    """
    # Test default behavior: no object is instantiated even if the input is valid
    assert from_yaml("An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s") is not None
    # Test another variant of the YAML input: no object is instantiated
    assert from_yaml("An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s") is not None
    # Test with a valid default input: no object is instantiated
    assert from_yaml("") is not None
    # Test with a valid input: no object is instantiated

# Generated at 2022-06-25 04:23:15.899341
# Unit test for function from_yaml
def test_from_yaml():
    """ Test function from_yaml """
    # Call function from_yaml without parameters.
    test_case_0()



if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:23:27.492720
# Unit test for function from_yaml

# Generated at 2022-06-25 04:23:28.566946
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:23:35.056736
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('foo: bar\nspam: eggs', vault_secrets=None)
    assert result == {'foo': 'bar', 'spam': 'eggs'}

# Generated at 2022-06-25 04:23:41.258084
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('- name: test\n  state: present',
                     file_name='<string>',
                     show_content=True,
                     vault_secrets=None,
                     json_only=False) == [{"name": "test", "state": "present"}]



# Generated at 2022-06-25 04:23:49.598708
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = """%s
This is a simple test for the import
"""
    str_1 = "{0:s},{1:d}"
    str_2 = "This is a simple test for the import"
    str_3 = "This does not work if you remove the quotes from the first line"
    str_4 = "this has a 'single quote' in it"
    str_5 = "this has a 'single quote' in it"
    var_0 = from_yaml(str_0)
    var_1 = from_yaml(str_1)
    var_2 = from_yaml(str_2)
    var_3 = from_yaml(str_3)
    var_4 = from_yaml(str_4)
    var_5 = from_yaml(str_5)

#

# Generated at 2022-06-25 04:23:56.191670
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a real code snippet
    # That marks the begining of the file
    str_0 = "// vim: ts=4 sw=4 et syn=yaml"
    var_0 = from_yaml(str_0)

    # Test with a real code snippet
    # Test that reads a string and parses to a dict
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)

    # Test with a real code snippet
    # Test that reads a string and parses to a dict
    str_0 = "---"
    var_0 = from_yaml(str_0)

    # Test with a real code snippet
    # Test that reads a string and parses to a dict
    str

# Generated at 2022-06-25 04:23:59.056078
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""Test string""", file_name='<string>', show_content=True,
                     vault_secrets=None, json_only=False) == "Test string"

# Generated at 2022-06-25 04:24:01.565104
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a": "b"}'
    assert from_yaml(data) == data
    data = '---'
    try:
        from_yaml(data, json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False, 'AnsibleParserError not raised'

# Generated at 2022-06-25 04:24:06.272955
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"

    assert from_yaml(str_1) == str_1

# Generated at 2022-06-25 04:24:14.671705
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "---"
    var_1 = from_yaml(str_0)
    assert var_1 == None

    str_1 = "123"
    var_2 = from_yaml(str_1)
    assert var_2 == 123

    str_2 = "---\n- 123\n- 456"
    var_3 = from_yaml(str_2)
    assert var_3 == [123, 456]

    str_3 = "---\nfoo: bar"
    var_4 = from_yaml(str_3)
    assert var_4 == {"foo": "bar"}

    str_4 = "---\n- one: two\n  three: four\n- one: two\n  three: four\n"

# Generated at 2022-06-25 04:24:21.430471
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    str_1 = "The task includes an option with an undefined variable. The error was: '%s' is undefined\n\nThe error appears to be in '/home/travis/my_playbook.yml': line 12, column 7, but may\nbe elsewhere in the file depending on the exact syntax problem.\n\nThe offending line appears to be:\n\n  tasks:\n    - debug: msg=\"%s\"\n      ^ here\n"
    var_1 = from_yaml(str_1)


# Generated at 2022-06-25 04:24:22.655796
# Unit test for function from_yaml
def test_from_yaml():
    assert(test_case_0)

test_from_yaml()

# Generated at 2022-06-25 04:24:31.207195
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = """
    - name: test_for_error
      hosts: localhost
      vars:
        test: bad: json
        test2: other: json
      tasks:
        - debug:
            name: hello world
        - debug:
            msg: "{{ 'test' | from_yaml |  }}"
"""
    var_0 = from_yaml(str_0)
    var_1 = from_yaml(str_0)

# Generated at 2022-06-25 04:24:39.327051
# Unit test for function from_yaml

# Generated at 2022-06-25 04:24:47.874068
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    import sys
    import types
    from ansible.parsing.yaml import from_yaml

    from ansible.errors import AnsibleParserError

    # This is just a basic test of the module.
    #
    # The full test suite for this module is located at:
    #    https://github.com/ansible/ansible/blob/devel/test/units/parsing/yaml/test_ajson.py
    #


# Generated at 2022-06-25 04:24:51.980661
# Unit test for function from_yaml
def test_from_yaml():
    print("Test #1: ")
    str = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var = from_yaml(str)
    print(var)


test_from_yaml()

# Generated at 2022-06-25 04:24:52.975107
# Unit test for function from_yaml
def test_from_yaml():
    assert fake_from_yaml() == 'A valid result'

# Generated at 2022-06-25 04:25:02.512270
# Unit test for function from_yaml

# Generated at 2022-06-25 04:25:05.137190
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)

# 0
test_from_yaml()

# Generated at 2022-06-25 04:25:07.005429
# Unit test for function from_yaml
def test_from_yaml():
    data = 'test'
    from_yaml(data)

# Generated at 2022-06-25 04:25:07.558687
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:25:18.482518
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str_0 = "{'msg': 'Could not find online disk device for disk {{ disk_name }}'}"
    from_yaml(yaml_str_0)
    yaml_str_1 = "{'hostkey_filename': '/tmp/ansible-ssh-hostkeys/' + '{{ inventory_hostname }}', 'remote_port': '{{ (22 + ansible_ssh_port) | int }}'}"
    from_yaml(yaml_str_1)
    yaml_str_2 = "{'msg': 'Could not find disk {{ disk.name }}'}"
    from_yaml(yaml_str_2)
    yaml_str_3 = "{'msg': 'No disk found on host {{ inventory_hostname }}'}"
    from_yaml(yaml_str_3)
    yaml

# Generated at 2022-06-25 04:25:24.104406
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"

    var_0 = from_yaml(str_0)

    assert isinstance(var_0, str)



# Generated at 2022-06-25 04:25:34.035357
# Unit test for function from_yaml
def test_from_yaml():

    # Testing when all parameters are provided    
    var_1 = 'foo: bar'
    var_2 = 'foo/bar'
    var_3 = True
    var_4 = {'ANSIBLE_VAULT': 'my_vault_pass'}
    var_5 = False
    var_6 = from_yaml(var_1, var_2, var_3, var_4, var_5)
    assert(var_6 == {'foo': 'bar'})

    # Testing when default parameters are provided 
    var_7 = from_yaml(var_1)
    assert(var_7 == {'foo': 'bar'})
    
test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:25:39.749951
# Unit test for function from_yaml
def test_from_yaml():
    with open('yaml-0.yaml') as f_0:
        assert from_yaml(f_0.read(), 'yaml-0.yaml') == from_yaml('yaml-0.yaml')

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(["-v", __file__]))

# Generated at 2022-06-25 04:25:43.604846
# Unit test for function from_yaml
def test_from_yaml(): 
    assert isinstance(from_yaml(''), dict) == True
    assert isinstance(from_yaml([]), list) == True

# Generated at 2022-06-25 04:25:48.940690
# Unit test for function from_yaml
def test_from_yaml():
    """Test function from_yaml."""
    assert test_case_0() == "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"

# Generated at 2022-06-25 04:25:50.367019
# Unit test for function from_yaml
def test_from_yaml():
    assert True
# END of unit test for function from_yaml
# START of unit test for function test_case_0

# Generated at 2022-06-25 04:26:00.081458
# Unit test for function from_yaml

# Generated at 2022-06-25 04:26:03.943039
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    assert var_0 == "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"



# Generated at 2022-06-25 04:26:14.280776
# Unit test for function from_yaml
def test_from_yaml():
    assert get_str(str_0) == var_0


# Copyright (c) 2012-2013, Michael DeHaan <michael.dehaan@gmail.com>
# Copyright: (c) 2018, Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import io
import os
import sys

from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
from ansible.parsing.yaml.loader import AnsibleLoader
from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-25 04:26:19.943837
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    assert len(var_0) == 3


# Generated at 2022-06-25 04:26:22.929749
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()



# Generated at 2022-06-25 04:26:29.293170
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.module_utils.network.nxos.nxos as nxos_utils
    # AnsibleParserError
    # AnsibleParserError
    test_case_0()
    # AnsibleParserError
    # AnsibleParserError
    test_case_0()

# Generated at 2022-06-25 04:26:29.904760
# Unit test for function from_yaml
def test_from_yaml():
    # ...
    pass

# Generated at 2022-06-25 04:26:33.324720
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_1 = from_yaml(str_1)

    assert var_1 == str_1

# Generated at 2022-06-25 04:26:44.411073
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"строка"'
    str_1 = 'логическое значение'
    str_2 = '12345'

# Generated at 2022-06-25 04:26:48.834887
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    print(var_0)

# Generated at 2022-06-25 04:26:49.386741
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:26:53.999199
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    assert var_0 == ("An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s",)

# Generated at 2022-06-25 04:27:00.616363
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing from_yaml...")
    try:
        test_case_0()
    except Exception as e:
        print("Failed test case: " + repr(e))
    print("Done!")


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:27:02.422970
# Unit test for function from_yaml
def test_from_yaml():
    assert(test_case_0())

# Generated at 2022-06-25 04:27:08.674004
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    assert var_0 == "%s"


# Generated at 2022-06-25 04:27:17.535076
# Unit test for function from_yaml
def test_from_yaml():
    # ansible/module_utils/urls.py:handle_proxy
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)

    assert var_0 == str_0

    # ansible/module_utils/connection.py:Connection._get_unix_socket_path
    str_1 = """{{ inventory_dir + '/' + ansible_ssh_host }}"""
    var_1 = from_yaml(str_1)

    assert var_1 == str_1

    # ansible/module_utils/connection.py:Connection._get_local_host
    str_2 = """/etc/ansible/hosts"""
    var_2 = from_yaml(str_2)



# Generated at 2022-06-25 04:27:29.015876
# Unit test for function from_yaml

# Generated at 2022-06-25 04:27:34.278849
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    str_1 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    var_1 = from_yaml(str_1)


# Generated at 2022-06-25 04:27:40.509968
# Unit test for function from_yaml
def test_from_yaml():
    try:
        str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
        var_0 = from_yaml(str_0)
    except AnsibleParserError as e:
        assert 'AnsibleParserError exception' in str(e)
    except Exception as e:
        assert 'AnsibleParserError exception' not in str(e)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:27:44.959336
# Unit test for function from_yaml
def test_from_yaml():
    try:
        str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
        var_0 = from_yaml(str_0)
    except Exception as e:
        print(e)
        raise
    assert var_0 == "'%s'. Error was a %s, original message: %s"


# Generated at 2022-06-25 04:27:48.115185
# Unit test for function from_yaml
def test_from_yaml():
    tests = [
        (None, 3),
    ]
    for inp, expected in tests:
        actual = from_yaml(inp)
        assert actual == expected

# Generated at 2022-06-25 04:27:50.036986
# Unit test for function from_yaml
def test_from_yaml():
    # Write code here to test 'from_yaml'
    raise Exception("No test for 'from_yaml'")


# Generated at 2022-06-25 04:27:52.169723
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml("An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"))
# test_from_yaml()

# Generated at 2022-06-25 04:27:55.243151
# Unit test for function from_yaml
def test_from_yaml():
    assert str_0 != None
    assert var_0 != None

# Generated at 2022-06-25 04:28:05.162083
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml("An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"))
    try:
        assert(from_yaml("An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s", json_only=False))
        assert(from_yaml("An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s", json_only=True))
    except:
        pass


# Generated at 2022-06-25 04:28:08.973221
# Unit test for function from_yaml
def test_from_yaml():
    # Test 1: no exception raised
    test_case_0()

# Generated at 2022-06-25 04:28:15.263700
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}
    assert from_yaml("{'foo': 'bar'}", json_only=True) == {'foo': 'bar'}
    assert from_yaml("{'foo': 'bar'}", json_only=True) == {'foo': 'bar'}
    assert from_yaml("{not_json: true}", json_only=True) == "{not_json: true}"

# Generated at 2022-06-25 04:28:19.065510
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:23.479830
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    assert var_0 == "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s", var_0


# Generated at 2022-06-25 04:28:32.587712
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "{% if (foo is bar) and (bar is not foo) %} foo {% endif %}"
    var_0 = from_yaml(str_0, file_name='<string>')

    str_0 = "{% if (foo is bar) and (bar is not foo) %} foo {% endif %}"
    var_0 = from_yaml(str_0, file_name='<string>', show_content=True)

    str_0 = "{% if (foo is bar) and (bar is not foo) %} foo {% endif %}"
    var_0 = from_yaml(str_0, file_name='<string>', show_content=True, vault_secrets=None)


# Generated at 2022-06-25 04:28:36.600279
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('hi')
        from_yaml("'hi'")
        from_yaml("- hi")
        from_yaml("[ 'hi']")
        from_yaml("{ }")
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("Expected failure")

# Generated at 2022-06-25 04:28:47.317552
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [
        # Unit test case 0
        {
            "name": "test_case_0",
            "data": "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s",
        },
    ]
    for case in test_cases:
        try:
            yaml_str = case.get("data")
            assert from_yaml(yaml_str) is not None, "from_yaml() returned None"
        except AssertionError as err:
            print("AssertionError: {}".format(err))
            print("Test case name: {}".format(case.get("name")))
            print("Data: {}".format(case.get("data")))

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:28:47.988213
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:28:50.050691
# Unit test for function from_yaml
def test_from_yaml():
    source = "Vmware configuration file"
    output = from_yaml(source)
    assert type(output) == list

# Generated at 2022-06-25 04:29:09.803043
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(None) is None

    # expected_data = {
    #     "A": {
    #         "B":{
    #             "C": ["D", "E", "F", "G"],
    #             "H": ["I", "J", "K"],
    #             "L": ["M", "N", "O", "P"],
    #             "Q": ["R", "S", "T", "U"],
    #             "V": ["W", "X", "Y", "Z"],
    #         }
    #     }
    # }
    # assert from_yaml(expected_data) == expected_data



# Generated at 2022-06-25 04:29:10.691945
# Unit test for function from_yaml
def test_from_yaml():
    loader = AnsibleLoader("abc", "abc", "abc")


# Generated at 2022-06-25 04:29:18.898308
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    assert isinstance(var_0, str)
    str_1 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_1 = from_yaml(str_1)
    assert isinstance(var_1, str)
    str_2 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_2 = from_yaml(str_2)
    assert isinstance(var_2, str)

# Generated at 2022-06-25 04:29:23.101291
# Unit test for function from_yaml
def test_from_yaml():
    test_0 = "---"
    var_0 = from_yaml(test_0)

    test_1 = "foo"
    var_1 = from_yaml(test_1)


test_0 = '---'
test_1 = '{foo}'
test_2 = 'foo'
test_3 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"

# Generated at 2022-06-25 04:29:34.852362
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s") == \
        '''An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s'''

# Generated at 2022-06-25 04:29:35.640336
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(str)

# Generated at 2022-06-25 04:29:45.318808
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{ "key": "value" }'
    assert isinstance(from_yaml(str_0), dict) == True

    str_1 = "{'key': 'value'}"
    assert isinstance(from_yaml(str_1), dict) == True

    str_2 = ["{'key': 'value'}", "{'key2': 'value2'}"]
    assert isinstance(from_yaml(str_2), list) == True

    str_3 = "{'key': 'value'}\n{'key2': 'value2'}"
    assert isinstance(from_yaml(str_3), list) == True

    str_4 = "invalid json"
    assert isinstance(from_yaml(str_4), str) == True


# Generated at 2022-06-25 04:29:51.969997
# Unit test for function from_yaml
def test_from_yaml():
    fh_0 = open('/etc/ansible/hosts')
    data_0 = fh_0.read()
    data_1 = "foo: bar\n"
    data_2 = data_0.splitlines()
    data_3 = {'foo': ['bar']}
    var_0 = from_yaml(data_0, file_name='/etc/ansible/hosts', show_content=True, vault_secrets=[], json_only=False)
    var_1 = from_yaml(data_1, file_name='/etc/ansible/hosts', show_content=True, vault_secrets=[], json_only=False)

# Generated at 2022-06-25 04:29:54.191999
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)

    assert isinstance(var_0, str) is True

# Generated at 2022-06-25 04:30:03.303937
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"key":"value"}') is not None
    assert from_yaml('key: value') is not None


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:30:30.604380
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)

    str_1 = "[1, 2, 3, 4, 5]"
    var_1 = from_yaml(str_1)
    assert var_0 == str_0
    assert var_1 == json.loads(str_1)

    str_2 = "[1,, 2, 3, 4, 5]"
    try:
        var_2 = from_yaml(str_2)
    except AnsibleParserError as e:
        var_2 = e.orig_exc
    assert isinstance(var_2, YAMLError)

    str_3 = "{\"foo\": \"bar\"}"
    var_3 = from_y

# Generated at 2022-06-25 04:30:32.466734
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'a': 'b'}") == {'a': 'b'}


# Generated at 2022-06-25 04:30:42.700190
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    import logging
    import ansible.constants as C
    from ansible.utils.color import ANSIBLE_COLOR, stringc
    logging.basicConfig(filename=C.DEFAULT_LOG_PATH, level=C.DEFAULT_LOG_LEVEL)
    # logging.basicConfig(level=logging.DEBUG)
    # logging.getLogger().setLevel(logging.DEBUG)
    # import unittest
    # unittest.TextTestRunner().run(unittest.makeSuite(Test_str_functions))
    # Code Here
    a = 1
    test_case_0()
    test_from_yaml()
    print('Test OK')

    # print(stringc(from_yaml('{ "name":

# Generated at 2022-06-25 04:30:45.729967
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    {
      "a": {
        "b": [
          "a",
          "b",
          "c"
        ]
      }
    }
    '''
    var_0 = from_yaml(data)
    print(var_0)



# Generated at 2022-06-25 04:30:48.715567
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    assert var_0 == str_0


if __name__ == '__main__':
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:30:54.074916
# Unit test for function from_yaml
def test_from_yaml():
    str_2 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_1 = from_yaml(str_2)
# END OF TEST CASES

# Generated at 2022-06-25 04:30:54.485819
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:31:02.446817
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    assert( str(var_0) == "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s" )
    assert( var_0 == "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s" )


# Generated at 2022-06-25 04:31:05.845579
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)

    assert var_0 == "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"

# Generated at 2022-06-25 04:31:08.550587
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None



# Generated at 2022-06-25 04:31:34.747636
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    assert var_0 is not None
    str_1 = '"%s" is an invalid boolean, please use one of the following: %s'
    var_1 = from_yaml(str_1)
    assert var_1 is not None


# Generated at 2022-06-25 04:31:41.887483
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "An unhandled exception occurred while templating '%s'. Error was a %s, original message: %s"
    var_0 = from_yaml(str_0)
    # Should be:
    # 'An unhandled exception occurred while templating \'%s\'. Error was a %s, original message: %s'
    # not: 'An unhandled exception occurred while templating \'%s\'. Error was a %s, original message: %s'
    #
    # assertEquals(var_0, 'An unhandled exception occurred while templating \'%s\'. Error was a %s, original message: %s')
    exit()


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()