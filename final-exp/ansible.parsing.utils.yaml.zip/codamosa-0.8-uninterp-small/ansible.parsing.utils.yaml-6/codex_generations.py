

# Generated at 2022-06-25 04:21:43.286597
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '--no-cache'
    var_0 = from_yaml(str_0)
    assert var_0 == '--no-cache'

    str_1 = '--no-cache --version'
    var_1 = from_yaml(str_1)
    assert var_1 == '--no-cache --version'

    str_2 = 'key: value'
    var_2 = from_yaml(str_2)
    assert var_2 == {'key': 'value'}

    str_3 = '''
        - key: value
        - key1: value1
        - key2: value2'''
    var_3 = from_yaml(str_3)

# Generated at 2022-06-25 04:21:52.222046
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('arg1') == 'arg1'
    assert from_yaml('/foo/bar') == '/foo/bar'
    assert from_yaml('- /foo/bar') == ['- /foo/bar']
    assert from_yaml('arg1\narg2') == 'arg1\narg2'
    assert from_yaml('arg1\narg2', json_only=True) == 'arg1\narg2'
    assert from_yaml('["foo", "bar"]') == ["foo", "bar"]
    assert from_yaml('arg1\\narg2') == 'arg1\narg2'
    assert from_yaml('arg1\\narg2', json_only=True) == 'arg1\narg2'

# Generated at 2022-06-25 04:21:58.830518
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'chris'
    var_0 = {'ansible_user': 'chris'}
    var_1 = from_yaml(str_0)
    assert str(var_0) == str(var_1)

# Generated at 2022-06-25 04:22:02.972007
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '--no-cache'
    var_0 = from_yaml(str_0)
    str_1 = '--no-cache'
    var_1 = from_yaml(str_1)
    assert var_0 == var_1


# Generated at 2022-06-25 04:22:07.288229
# Unit test for function from_yaml
def test_from_yaml():
    jsn_0 = '{"foo": "bar"}'
    var_0 = from_yaml(jsn_0)
    assert var_0 == {"foo": "bar"}
    yml_0 = 'key: value'
    var_1 = from_yaml(yml_0)
    assert var_1 == {u'key': u'value'}

# Generated at 2022-06-25 04:22:18.809906
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '--no-cache'
    var_0 = from_yaml(str_0)
    assert var_0 == '--no-cache'

    str_1 = '--no-cache --cache'
    var_1 = from_yaml(str_1)
    assert var_1 == '--no-cache --cache'

    str_2 = '''---
                a: 1
                b: 2
            ...'''

    var_2 = from_yaml(str_2)
    assert var_2 == {'a': 1, 'b': 2}

    str_3 = '''---
                {"a": 1, "b": 2}
            ...'''

    var_3 = from_yaml(str_3)
    assert var_3 == {'a': 1, 'b': 2}

# Generated at 2022-06-25 04:22:20.118193
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo') == 'foo'

# Generated at 2022-06-25 04:22:21.173354
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 04:22:30.358419
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '--no-cache'

    var_0 = from_yaml(str_0)
    assert var_0 == "--no-cache"

    str_1 = '---\n- hosts: all\n  gather_facts: False\n  tasks:\n  - name: test\n    ping:\n'
    var_1 = from_yaml(str_1)
    assert isinstance(var_1, list)
    assert var_1[0]['hosts'] == 'all'


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:22:32.932767
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '''
    ansible all -i hosts  -m yum -a 'name=httpd state=present'
    '''

    var_0 = from_yaml(str_0)


# Generated at 2022-06-25 04:22:37.170258
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Generated at 2022-06-25 04:22:44.852366
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    import os
    import sys

    status = 0

    try:
        from unittest import TestCase
    except ImportError:
        TestCase = None

    from ansible.module_utils.basic import AnsibleModule

    ansible_module = AnsibleModule(
        argument_spec=dict(),
    )

    try:
        test_from_yaml()
    except AssertionError as exc:
        if TestCase is not None and isinstance(exc, TestCase.failureException):
            # Do nothing, this is expected
            pass
        else:
            raise

    sys.exit(status)

# Generated at 2022-06-25 04:22:51.084258
# Unit test for function from_yaml
def test_from_yaml():
    print(test_case_0())


if __name__ == '__main__':
    print('Running test cases for from_yaml')
    print(test_from_yaml())

# Generated at 2022-06-25 04:22:52.115498
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert test_case_0()
        assert True
    except AssertionError:
        assert False

# Generated at 2022-06-25 04:22:55.687778
# Unit test for function from_yaml
def test_from_yaml():

    var_0 = '--no-cache'
    var_1 = str

    var_2 = from_yaml(var_0)

    assert(var_1 == type(var_2))

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 04:22:59.465492
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Generated at 2022-06-25 04:23:02.846504
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml is None


# Generated at 2022-06-25 04:23:14.528429
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a":123}') == {'a':123}
    assert from_yaml('a: 123') == {'a':123}
    assert from_yaml('a:  123') == {'a': 123}
    assert from_yaml('a: 123\nb: 456') == {'a': 123, 'b': 456}
    assert from_yaml('a: 1 2 3') == {'a': '1 2 3'}
    assert from_yaml('a: [1, 2, 3]') == {'a': [1, 2, 3]}
    assert from_yaml('a: "1 2 3"') == {'a': '1 2 3'}
    assert from_yaml('a: "one two"') == {'a': 'one two'}

# Generated at 2022-06-25 04:23:20.333716
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = '--no-cache'
    var_1 = from_yaml(str_1)
    assert var_1 == '--no-cache'

    try:
        str_2 = '{"var1": 1, "var2": {"key1":"val1"}}'
        var_2 = from_yaml(str_2)
        assert var_2 == {"var1": 1, "var2": {"key1": "val1"}}
    except Exception:
        raise AssertionError()

    try:
        str_3 = '- - var1\n  - var2\n'
        var_3 = from_yaml(str_3)
        assert var_3 == [["var1"], ["var2"]]
    except Exception:
        raise AssertionError()


# Generated at 2022-06-25 04:23:28.749720
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '''
    - hosts: all
      connection: local
      tasks:
      - name: Print a message.
        debug:
          msg: "Hello world!"
    '''
    var_0 = from_yaml(str_0)
    str_1 = '''
    - hosts: all
      connection: local
      tasks:
      - name: Print a message.
        debug:
          msg: "Hello world!"
    '''
    var_1 = from_yaml(str_1)
    assert str(var_0) == str(var_1)
    str_2 = '''
    tasks:
    - debug:
        msg: Hello world!
    '''
    var_2 = from_yaml(str_2)

# Generated at 2022-06-25 04:23:31.382387
# Unit test for function from_yaml
def test_from_yaml():
    assert 1 == 1

# Generated at 2022-06-25 04:23:36.981855
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "!swarm\n"
    str_data = json.loads(str_0)
    #print(json.dumps(str_data,indent=4))
    #print(str_data)


    #print(var_0)
    #assert var_0 == 2


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:23:44.611413
# Unit test for function from_yaml
def test_from_yaml():
    cmd = '''
    ansible -i 127.0.0.1, all -m ping
    '''

    var = from_yaml(cmd)
    #print(var)
    pass


# Generated at 2022-06-25 04:23:48.617215
# Unit test for function from_yaml
def test_from_yaml():
    print("test_from_yaml()")

    test_cases = [
        test_case_0,
    ]

    for test_case in test_cases:
        test_case()


if __name__ == '__main__':
    # test_from_yaml()
    print("Done")

# Generated at 2022-06-25 04:24:02.890001
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{"foo": "bar"}\n'
    var_0 = from_yaml(str_0)
    str_1 = '---\nfoo: bar\n'
    var_1 = from_yaml(str_1)
    assert var_0 == var_1
    str_2 = '---\nfoo:\n bar: baz\n'
    var_2 = from_yaml(str_2)
    str_3 = '---\nfoo:\n  bar: baz\n'
    var_3 = from_yaml(str_3)
    assert var_2 == var_3
    str_4 = '---\n- key: val\n'
    var_4 = from_yaml(str_4)

# Generated at 2022-06-25 04:24:12.906144
# Unit test for function from_yaml
def test_from_yaml():
    # Test for valid YAML, expected result True
    b_0 = '---\n- hosts: localhost\n'
    a_0 = from_yaml(b_0)
    assert a_0 == [{'hosts': 'localhost'}]

    # Test for invalid YAML, expected result got error
    str_1 = '---\n- hosts:\n  - localhost\n'
    try:
        a_1 = from_yaml(str_1)
        raise Exception('Need to have error')
    except Exception as e:
        assert True

    # Test for valid YAML, expected result True
    b_1 = '---\n- hosts: localhost\n'
    a_1 = from_yaml(b_1)

# Generated at 2022-06-25 04:24:15.651066
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '--no-cache'
    var_0 = from_yaml(str_0)

    # Test if parsing is done correctly
    assert var_0 == '--no-cache'


# Generated at 2022-06-25 04:24:21.873474
# Unit test for function from_yaml

# Generated at 2022-06-25 04:24:33.600403
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{"0": "a", "1": "b"}'
    var_0 = from_yaml(str_0)
    print(var_0)
    assert var_0 == {"1": "b", "0": "a"}
    str_0 = '{"0": "a", "1": "b"}'
    var_0 = from_yaml(str_0, json_only=True)
    print(var_0)
    assert var_0 == {"1": "b", "0": "a"}
    str_0 = '{"a": "b", "c": "d"}'
    var_0 = from_yaml(str_0)
    print(var_0)
    assert var_0 == {"a": "b", "c": "d"}

# Generated at 2022-06-25 04:24:36.221165
# Unit test for function from_yaml
def test_from_yaml():
    assert 1 == 1

#
# Unit test to test the yaml parsing
#

# Generated at 2022-06-25 04:24:47.598561
# Unit test for function from_yaml
def test_from_yaml():

    # Test case 1
    str_0 = '{!menu item=blackjack\n'
    var_0 = from_yaml(str_0)
    assert var_0 == 'blackjack'
    # Test case 2
    str_1 = '!swarm\n'
    var_1 = from_yaml(str_1)
    assert var_1 == 'swarm'
    # Test case 3
    str_2 = '{!include foo.yml}'
    var_2 = from_yaml(str_2)

    # Test case 4
    str_3 = '\n\n'
    var_3 = from_yaml(str_3)

    # Test case 5
    str_4 = '{!include foo.yml}\n'

# Generated at 2022-06-25 04:24:51.074094
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:25:00.741611
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = '!swarm\n'
    var_1 = from_yaml(str_1)
    str_2 = '!ansible\n'
    var_2 = from_yaml(str_2)
    str_3 = '!remote\n'
    var_3 = from_yaml(str_3)
    str_4 = '!pipe\n'
    var_4 = from_yaml(str_4)
    str_5 = '!gce\n'
    var_5 = from_yaml(str_5)
    str_6 = '!aws\n'
    var_6 = from_yaml(str_6)
    src_vault = dict()
    str_7 = '!vault\n'

# Generated at 2022-06-25 04:25:05.441175
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:25:06.456933
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:25:08.588172
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert var_0 == '!swarm'



# Generated at 2022-06-25 04:25:12.003782
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)

    assert var_0 == 'swarm' or var_0 == '!swarm\n'

# Generated at 2022-06-25 04:25:21.499398
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [
      (1, '!swarm\n', {'!swarm': ''}),
      (3, '!swarm\n', {'!swarm': ''}),
      (6, '!swarm\n', {'!swarm': ''}),
    ]
    # Loop over test_cases saving result in str_var_list
    str_var_list = ['']
    for case in test_cases:
        str_var_list.append(from_yaml(case[1]))
    # Check to make sure we get expected results
    assert str_var_list[1] == {'!swarm': ''}, 'Expected {\'!swarm\': \'\'}, got ' + str(str_var_list[1])

# Generated at 2022-06-25 04:25:23.723531
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:25:29.574341
# Unit test for function from_yaml
def test_from_yaml():
    """Test the ansible.parsing.yaml.utils method."""
    str_0 = "Hello World\n"
    var_0 = from_yaml(str_0)
    assert var_0 == 'Hello World\n'

# Generated at 2022-06-25 04:25:37.758776
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 04:25:39.750773
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    print(var_0)

# Generated at 2022-06-25 04:25:42.556564
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = ''
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:25:48.046533
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert var_0 == {'ansible_type': 'Swarm',
           'ansible_vault': None,
           'ansible_line': 1,
           'ansible_pos': (0, 0),
           'ansible_role_name': None,
           'ansible_role_vars': {}}

# Generated at 2022-06-25 04:25:50.984596
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)


# Generated at 2022-06-25 04:25:55.250671
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()



# Generated at 2022-06-25 04:25:55.903004
# Unit test for function from_yaml
def test_from_yaml():
    assert False == False

# Generated at 2022-06-25 04:26:01.139742
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)

    s = '''---
---
'''
    var_1 = from_yaml(s)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:26:02.655800
# Unit test for function from_yaml
def test_from_yaml():
    # Unit test for function from_yaml, ensure it is a dict
    test_case_0()
    assert True

# Generated at 2022-06-25 04:26:13.467426
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:26:33.314495
# Unit test for function from_yaml
def test_from_yaml():
    args_0 = [{'b': 1, 'c': 2, 'a': 0}]
    str_0 = '{"a":0,"c":2,"b":1}\n'
    var_0 = from_yaml(str_0)
    assert var_0 == args_0[0], 'String: %s' % str_0
    str_1 = '{"a":0,"c":2,"b":1}\n'
    test_0 = '{"a":0,"c":2,"b":1}'
    var_1 = from_yaml(str_1)
    assert var_1 == {'a': 0, 'c': 2, 'b': 1}, 'String: %s' % str_1
    str_2 = '{"a":0,"c":2,"b":1}\n'
    var

# Generated at 2022-06-25 04:26:36.810646
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 04:26:37.657522
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None


# Generated at 2022-06-25 04:26:40.532241
# Unit test for function from_yaml
def test_from_yaml():
    # Unit test for function from_yaml
    try:
        assert not (test_case_0())
    except AssertionError:
        raise Exception('Failed test_case_0')



# Generated at 2022-06-25 04:26:41.922970
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') == None


# Generated at 2022-06-25 04:26:53.680799
# Unit test for function from_yaml
def test_from_yaml():
    # Unit test for function from_yaml
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert var_0 == '!swarm\n'
    str_1 = '!swarm\n#comment\n'
    var_1 = from_yaml(str_1)
    assert var_1 == '!swarm\n#comment\n'
    str_2 = '!swarm\n#comment\n\n'
    var_2 = from_yaml(str_2)
    assert var_2 == '!swarm\n#comment\n\n'
    str_3 = '''!swarm\n#comment\n\n'''
    var_3 = from_yaml(str_3)

# Generated at 2022-06-25 04:27:00.875453
# Unit test for function from_yaml
def test_from_yaml():
    
    # Setup test data
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    
    
    
    # Setup test data
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)



# Generated at 2022-06-25 04:27:05.770112
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)

    # yaml.safe_load() should return a NoneType object here if the yaml tag
    # is unknown by the parser.
    assert var_0 is None, '\nExpected: %s\nBut got: %s' % (type(None), type(var_0))



# Generated at 2022-06-25 04:27:06.265138
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:27:10.300210
# Unit test for function from_yaml
def test_from_yaml():
    line_list = [ '!swarm\n' ]
    for line in line_list:
        var_0 = from_yaml(line)
        print(var_0)



# Generated at 2022-06-25 04:27:26.274799
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert var_0 == '!swarm'


# Generated at 2022-06-25 04:27:29.919407
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_data = from_yaml('!swarm')
    assert from_yaml_data is not None
    assert from_yaml_data == {'!swarm': None}

# Generated at 2022-06-25 04:27:36.100100
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'some text\n'
    var_0 = from_yaml(str_0)
    print(var_0)

    str_1 = '- some text\n'
    var_1 = from_yaml(str_1)
    print(var_1)


#import json
#test_case_0()
#test_from_yaml()
#print('The test ended with no error.')

# Generated at 2022-06-25 04:27:39.682303
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    ans_0 = None

    # assert statements
    #assert var_0 == ans_0
    assert True


# Generated at 2022-06-25 04:27:52.991480
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    assert from_yaml(str_0) == 'swarm'
    assert from_yaml(str_0, show_content=False) == 'swarm'

    str_1 = '{}'
    assert from_yaml(str_0, show_content=False) == 'swarm'

    str_2 = '---\n- this was a triumph\n- i\'m making a note here:\n  - HUGE SUCCESS\n'
    expect_res_2 = [{'this was a triumph': None}, {'i\'m making a note here:': [{'HUGE SUCCESS': None}]}]
    assert from_yaml(str_2) == expect_res_2
    assert from_yaml(str_2, show_content=False)

# Generated at 2022-06-25 04:27:57.021235
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert var_0 == '!swarm\n', 'Expected:"!swarm\n", but got: ' + str(var_0)


# Generated at 2022-06-25 04:28:04.710586
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    print(var_0)
    assert var_0 == {'ansible_object_type': 'tag:yaml.org,2002:str', 'ansible_tag': 'tag:yaml.org,2002:str', 'value': 'swarm'}
    str_1 = '!swarm 123\n'
    var_1 = from_yaml(str_1)
    print(var_1)
    assert var_1 == {'ansible_object_type': 'tag:yaml.org,2002:str', 'ansible_tag': 'tag:yaml.org,2002:str', 'value': '123'}


# Generated at 2022-06-25 04:28:10.445988
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)


if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:28:15.508736
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    str_1 = '!swarm\n'
    var_1 = from_yaml(str_1)

    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    str_1 = '!swarm\n'
    var_1 = from_yaml(str_1)

# Generated at 2022-06-25 04:28:17.936246
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None

# Generated at 2022-06-25 04:28:43.150451
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    str_1 = '!swarm\n'
    var_1 = from_yaml(str_1)
    str_2 = '!swarm\n'
    var_2 = from_yaml(str_2)
    str_3 = '!swarm\n'
    var_3 = from_yaml(str_3)
    str_4 = '!swarm\n'
    var_4 = from_yaml(str_4)
    str_5 = '!swarm\n'
    var_5 = from_yaml(str_5)
    str_6 = '!swarm\n'
    var_6 = from_yaml(str_6)
    str_

# Generated at 2022-06-25 04:28:47.349253
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = ''
    str_1 = ''
    var_1 = from_yaml(str_0, str_1)
    str_0 = ''
    str_1 = ''
    var_0 = from_yaml(str_0, str_1)

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-25 04:28:49.838675
# Unit test for function from_yaml
def test_from_yaml():
    data = 'hello'
    var_0 = from_yaml(data)
    assert var_0 == 'hello'


# Generated at 2022-06-25 04:28:50.698307
# Unit test for function from_yaml
def test_from_yaml():
    assert False


# Generated at 2022-06-25 04:28:51.903811
# Unit test for function from_yaml
def test_from_yaml():
    assert False
# END test_from_yaml


# Generated at 2022-06-25 04:28:54.272026
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 04:29:04.986326
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:29:11.682554
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)

    # Test for failure if not given a string
    test_var = 0
    try:
        var_1 = from_yaml(test_var)
    except AnsibleParserError as e:
        var_1 = e

    # Test for failure if given a file name of an object that doesn't exist
    str_2 = '/invalid/file/path'
    var_2 = from_yaml(str_2)

    str_3 = 'some_string'
    var_3 = from_yaml(str_3, json_only=True)



# Generated at 2022-06-25 04:29:17.017648
# Unit test for function from_yaml
def test_from_yaml():
    # Tests the following code path:
    #
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:29:25.126580
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    # if param is None
    str_0 = None
    var_0 = from_yaml(str_0)
    assert var_0 is None

    # if param is a yaml string
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert isinstance(var_0, dict)
    str_0 = '''
        - name: "{{ inventory_hostname }}"
          server: "{{ ansible_host }}"
        '''
    var_0 = from_yaml(str_0)
    assert isinstance(var_0, list)

    # if param is a json string

# Generated at 2022-06-25 04:29:51.115165
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert var_0 == "!swarm"

    str_1 = '!swarm\n---\n'
    var_1 = from_yaml(str_1)
    assert var_1 == "!swarm"


# Function to test AnsibleLoader

# Generated at 2022-06-25 04:29:57.622197
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!!python/tuple (1, 2, 3, 4, 5)'
    var_0 = from_yaml(str_0)
    t_op = var_0;

    str_1 = '---\n- - 0\n  - 1\n'
    var_1 = from_yaml(str_1)
    my_list = var_1;

    str_2 = '---\n- [0, 1, 2]\n- [3, 4, 5]\n'
    var_2 = from_yaml(str_2)
    my_list = var_2;

    str_3 = '---\n- - 0\n  - 1\n  - 2\n'
    var_3 = from_yaml(str_3)
    my_list = var_3

# Generated at 2022-06-25 04:30:03.449950
# Unit test for function from_yaml
def test_from_yaml():
    print("in test_from_yaml()")
    test_case_0()


#
# Run unit tests if executed directly
#
#if __name__ == "__main__":
#    test_from_yaml()

# Generated at 2022-06-25 04:30:05.038436
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:30:10.501841
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = '''---
- hosts: all
  tasks:
  - name: test
    local_action: >
      debug msg="{{ item.value }}"
    with_dict: "{{ test_dict }}"
'''

    ansible_dict_0 = from_yaml(str_1)
    # assert(ansible_dict_0['hosts'].value == 'all')

# Generated at 2022-06-25 04:30:20.627556
# Unit test for function from_yaml
def test_from_yaml():

    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    str_1 = '!ansible/object/swarm\n'
    var_1 = from_yaml(str_1)
    str_2 = '!ansible/object/swarm/\n'
    var_2 = from_yaml(str_2)
    str_3 = '!swarm/\n'
    var_3 = from_yaml(str_3)
    str_4 = '!swarm1\n'
    var_4 = from_yaml(str_4)
    str_5 = '!__ansible/swarm\n'
    var_5 = from_yaml(str_5)

# Generated at 2022-06-25 04:30:29.944757
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert var_0 == 'swarm'

    str_1 = '- test\n'
    var_1 = from_yaml(str_1)
    assert var_1 == ['test']

    str_2 = '{test: test}\n'
    var_2 = from_yaml(str_2)
    assert var_2 == {'test': 'test'}

    str_3 = '!ansible.module_utils.basic.AnsibleModule {}\n'
    var_3 = from_yaml(str_3)
    assert var_3 == 'ansible.module_utils.basic.AnsibleModule'

# Generated at 2022-06-25 04:30:33.717440
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    print(var_0)
    assert var_0 == {'!swarm': None}


# Generated from a script

# Generated at 2022-06-25 04:30:37.976365
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)

    print('answer: !swarm\n\ntest 0 passed')



if __name__ == '__main__':

    test_from_yaml()

# Generated at 2022-06-25 04:30:44.255976
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)

    str_1 = 'abc'
    var_1 = from_yaml(str_1)

    str_2 = '!swarm\n'
    var_2 = from_yaml(str_2, json_only=False)
    var_3 = from_yaml(str_2, json_only=True)


if __name__ == '__main__':
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-25 04:31:10.683139
# Unit test for function from_yaml
def test_from_yaml():
    # Test case 0
    try:
        test_case_0()
    except Exception as exception:
        var_0 = exception.__str__()
        print("test case 0 threw exception " + str(exception))
        assert False
    
    # Test case 1

# Generated at 2022-06-25 04:31:12.152548
# Unit test for function from_yaml
def test_from_yaml():

    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:31:15.206935
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert(str(var_0) == '!swarm')
#

# Generated at 2022-06-25 04:31:22.239267
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '!swarm\n'
    var_0 = from_yaml(str_0)
    assert type(var_0) == dict
    assert var_0['_yaml_tag'] == '!swarm'
    assert var_0['_ansible_pos'] == (u'<string>', 1, 1)
    str_1 = '"false"\n'
    var_1 = from_yaml(str_1)
    assert type(var_1) == str
    str_2 = '1\n'
    var_2 = from_yaml(str_2)
    assert type(var_2) == int
    assert var_2 == 1
    str_3 = '1.0\n'
    var_3 = from_yaml(str_3)

# Generated at 2022-06-25 04:31:23.417845
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()



# Generated at 2022-06-25 04:31:25.332286
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    # Run tests
    test_from_yaml()

# Generated at 2022-06-25 04:31:30.889157
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('key: value\n') == {'key': 'value'}, 'Expected key: value to be loaded and converted to a Python dict.'

    try:
        from_yaml('key: value\\n')
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('Expected AnsibleParserError to be raised')



# Generated at 2022-06-25 04:31:32.180883
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:31:41.228790
# Unit test for function from_yaml
def test_from_yaml():
    test_case1 = """---
- hosts: all
  tasks:
    - name: install httpd
      yum: name=httpd state=installed
    - name: copy and enable httpd.conf
      template: src=httpd.conf.j2 dest=/etc/httpd/conf/httpd.conf
      notify: restart httpd
    - name: start and enable httpd service
      service: name=httpd state=started enabled=yes
  handlers:
    - name: restart httpd
      service: name=httpd state=restarted
"""

    # Test of function from_yaml from module ansible.parsing.yaml.loader