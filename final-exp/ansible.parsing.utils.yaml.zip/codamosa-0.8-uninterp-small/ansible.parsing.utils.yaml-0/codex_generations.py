

# Generated at 2022-06-25 04:21:45.928095
# Unit test for function from_yaml
def test_from_yaml():
    file_name = "data/storage/ansible/test_cases/parsing/yaml/from_yaml.yml"
    result = from_yaml(file_name)
    help(result)



# Generated at 2022-06-25 04:21:47.517731
# Unit test for function from_yaml
def test_from_yaml():
    unittest.TestCase
    t = test_case_0
    assert t == 0.2
    return t

# Generated at 2022-06-25 04:21:50.124666
# Unit test for function from_yaml
def test_from_yaml():
    assert 1 == 1


# Generated at 2022-06-25 04:21:54.232956
# Unit test for function from_yaml
def test_from_yaml():
    print("\n")
    import sys

    # Setup
    str_1 = '5'

    # Exercise
    var_0 = from_yaml(sys.argv[1])

    # Verify

    # Cleanup


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:21:58.211845
# Unit test for function from_yaml
def test_from_yaml():
    # Run unit tests for function from_yaml
    # Float data as string to yaml
    float_0 = "0.2"
    try:
        var_0 = from_yaml(float_0)
    except AnsibleParserError as e:
        assert False, "YAML parse error, expected success."

# Generated at 2022-06-25 04:22:07.953088
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_text


# Generated at 2022-06-25 04:22:14.676221
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == "__main__":
    try:
        test_from_yaml()
    except Exception as exception:
        import traceback
        print("ERROR! Call to from_yaml() failed: %s" % (exception))
        print(traceback.format_exc())
        sys.exit(1)

    sys.exit(0)

# Generated at 2022-06-25 04:22:16.447721
# Unit test for function from_yaml
def test_from_yaml():
    float_0 = 0.2
    var_0 = from_yaml(float_0)

    test_case_0()

# Generated at 2022-06-25 04:22:21.420375
# Unit test for function from_yaml
def test_from_yaml():
    stream = """
    ["foo", {"bar":["baz", null, 1.0, 2]}]
    """
    assert from_yaml(stream) == ["foo", {"bar": ["baz", None, 1.0, 2]}]



# Generated at 2022-06-25 04:22:27.122997
# Unit test for function from_yaml

# Generated at 2022-06-25 04:22:29.033873
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:22:36.238640
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)
    assert var_0 == 'p\x0cSU\\-GFtC'

# Generated at 2022-06-25 04:22:47.303896
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)
    assert var_0 == 'p%1BSU+GFtC'
    str_1 = 'p\x0cSU\\-GFtC'
    var_1 = from_yaml(str_1)
    assert var_1 == 'p%1BSU+GFtC'
    str_2 = "\x0C-\x0C\x0C-\x0C\x0C\x0C-\x0C\x0C-\x06\x06\x06\x06\n"
    var_2 = from_yaml(str_2)

# Generated at 2022-06-25 04:22:52.844231
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '\n      \n        \n          \n            \n              \n                \n                  \n                    \n                      \n                        \n                          \n                            \n                              \n                                \n                                  \n                            \n                        \n                    \n                \n            \n        \n    \n'
    var_0 = from_yaml(str_0)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:22:59.698451
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError) as excinfo:
        test_case_0()
    assert 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: Expecting property name enclosed in double quotes: line 1 column 2 (char 1)\n\n%s\n  in "</string>"' in str(excinfo.value)

# Generated at 2022-06-25 04:23:05.641908
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:23:17.003798
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('5J*dR') == '5J*dR'
    assert from_yaml('3J*dR') == '3J*dR'
    assert from_yaml('p\x0cSU\\-GFtC') is not None
    assert from_yaml('R\x0cSU\\-GFtC') is not None
    assert from_yaml('\nSU\\-GFtC') is not None
    assert from_yaml('\tSU\\-GFtC') is not None
    assert from_yaml('\x0cSU\\-GFtC') is not None
    assert from_yaml('4\x0cSU\\-GFtC') is not None
    assert from_yaml('4J\x0cSU\\-GFtC') is not None


# Generated at 2022-06-25 04:23:25.074092
# Unit test for function from_yaml
def test_from_yaml():

    # test case 0
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)

    # test case 1
    str_1 = '\x1a'
    var_1 = from_yaml(str_1)

    # test case 2
    str_2 = ')y\x0cF4\x0c'
    var_2 = from_yaml(str_2)


# Generated at 2022-06-25 04:23:29.846797
# Unit test for function from_yaml
def test_from_yaml():
    var_1 = 'p\x0cSU\\-GFtC'
    var_2 = from_yaml(var_1)
    assert var_1 == var_2

# Generated at 2022-06-25 04:23:34.331024
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'X[...)b4*1'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:23:45.184319
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)
    assert var_0 == 'p\x0cSU\x1dGFtC'
    str_1 = 'p\x0cSU-GFtC'
    var_1 = from_yaml(str_1)
    assert var_1 == 'p\x0cSU-GFtC'
    str_2 = 'p\x0cSU-GFtC'
    var_2 = from_yaml(str_2)
    assert var_2 == 'p\x0cSU-GFtC'
    str_3 = 'p\x0cSU\\-GFtC'
    var_3 = _safe_load(str_3)
    assert var_3

# Generated at 2022-06-25 04:23:51.827918
# Unit test for function from_yaml
def test_from_yaml():
    # Test when it succeeds
    str_0 = '\x0bG\x0b\x1e\x1c@'
    var_0 = from_yaml(str_0)

    # Test when it fails
    str_1 = '\r\r\r\r\r\r'
    try:
        var_1 = from_yaml(str_1)
    except YAMLError:
        pass

    # Test when it fails
    str_2 = '\x0bG\x0b\x1e\x1c@'
    try:
        var_2 = from_yaml(str_2)
    except YAMLError:
        pass

    # Test when it fails
    str_3 = '\r\r\r\r\r\r'

# Generated at 2022-06-25 04:23:54.534838
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)
    assert var_0 == 'p\x0cSU\x0c-GFtC'



# Generated at 2022-06-25 04:23:57.482139
# Unit test for function from_yaml
def test_from_yaml():
    print('Test Case 0')
    test_case_0()
    print("")


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:24:07.656552
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'V)vx8S[W'
    var_0 = from_yaml(str_0)
    str_1 = '\x1c[0\x16\x0f\x1a\x1c:+\x13J6\x1f'
    var_1 = from_yaml(str_1)
    str_2 = '\x04\x16\x0f\x16\x12'
    var_2 = from_yaml(str_2)
    str_3 = '\x1b^X\x0c\x08\x1c\x03o\x1f'
    var_3 = from_yaml(str_3)

# Generated at 2022-06-25 04:24:10.412317
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)
    assert var_0['l'][0]['r'] == [1,3]



# Generated at 2022-06-25 04:24:16.518906
# Unit test for function from_yaml
def test_from_yaml():
    encode_0 = 'ascii'
    str_0 = '\n    -   name: echo "hello world"\n'
    list_1 = list()
    dict_0 = dict()
    dict_0['name'] = 'echo "hello world"'
    list_1.append(dict_0)
    var_0 = from_yaml(str_0, json_only=True)
    assert var_0 == list_1, 'Expected {}, but got: {}'.format(repr(list_1), repr(var_0))


# Generated at 2022-06-25 04:24:18.687714
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:24:21.994456
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

test_from_yaml()

# Generated at 2022-06-25 04:24:22.716578
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True

# Generated at 2022-06-25 04:24:28.168485
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(test_case_0)

# Generated at 2022-06-25 04:24:34.259873
# Unit test for function from_yaml
def test_from_yaml():
  str_0 = """
  h\x0b{:g
&\x7f
  }
  """
  var_0 = from_yaml(str_0)
  assert var_0.get('h\x0b{:g') == '&\x7f'

  str_0 = 'p\x0cSU\\-GFtC'
  var_0 = from_yaml(str_0)
  assert var_0 == 'p\x0cSU\\-GFtC'

# Generated at 2022-06-25 04:24:47.261061
# Unit test for function from_yaml

# Generated at 2022-06-25 04:24:52.965884
# Unit test for function from_yaml
def test_from_yaml():
    print('Data to yaml:\n%s' % test_case_0.__code__.co_consts[0])
    print('YAML:')
    try:
        print(test_case_0())
    except:
        print('Error!')

# Standard boilerplate to call the main() function
if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:24:57.971508
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)  # type: ignore
    test_case_0()
    var_0 = from_yaml(str_0, True)
    var_0 = from_yaml(str_0, False)


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:24:59.735024
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('pSU\\-GFtC') == 'p\x0cSU\\-GFtC'

# Generated at 2022-06-25 04:25:08.013254
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('p\x0cSU\\-GFtC')
    assert from_yaml('p\x0cSU\\-GFtC')
    assert from_yaml('T\x04T\x1aI')
    assert from_yaml(str_0)
    assert from_yaml(str_1)
    assert from_yaml('p\x0cSU\\-GFtC')
    assert from_yaml('\x04')
    assert from_yaml('p\x0cSU\\-GFtC')
    assert from_yaml('T\x04T\x1aI')
    assert from_yaml('p\x0cSU\\-GFtC')
    assert from_yaml(str_2)
    assert from_yaml(str_3)
   

# Generated at 2022-06-25 04:25:12.837159
# Unit test for function from_yaml
def test_from_yaml():
    import yaml, zlib, random
    data = {'a': random.randint(0, 255)}
    x = yaml.dump(data, default_flow_style=False)
    y = from_yaml(x)
    assert y == data



# Generated at 2022-06-25 04:25:16.380512
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'q3g6f"r^lqa'
    var_0 = from_yaml(str_0)


# Generated at 2022-06-25 04:25:21.987154
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Run unit tests
if __name__ == '__main__':
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:25:31.956505
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'd\x0c"J]\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00qb\x00.'
    var_0 = from_yaml(str_0)

    str_1 = 'd\x0c"J]\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00qb\x00.'
    var_1 = from_yaml(str_1)

# Generated at 2022-06-25 04:25:33.490225
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() == None

# Generated at 2022-06-25 04:25:37.372317
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)
    assert var_0 == 'p\x0cSU\\-GFtC'


# Generated at 2022-06-25 04:25:40.008701
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '- name: test\n  password: 123'
    assert from_yaml(test_data) == [{'password': '123', 'name': 'test'}]



# Generated at 2022-06-25 04:25:51.459018
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml({'p\x0cSU\\-GFtC': ''}) == {'p\x0cSU\\-GFtC': ''}
    assert from_yaml({'p\x0cSU\\-GFtC': '', 'p\x0cSU\\-GFtC': '', 'p\x0cSU\\-GFtC': ''}) == {'p\x0cSU\\-GFtC': '', 'p\x0cSU\\-GFtC': '', 'p\x0cSU\\-GFtC': ''}

# Generated at 2022-06-25 04:26:04.366431
# Unit test for function from_yaml

# Generated at 2022-06-25 04:26:14.303696
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    ### Test case 0
    try:
        obj_0 = VaultSecret(name='foo', tokens=['t'])
        var_0 = VaultLib(tokens=obj_0)
        str_0 = 'p\x0cSU\\-GFtC'
        var_1 = from_yaml(str_0, vault_secrets=[var_0])
    except Exception as e:
        print(e)
        raise

    ### Test case 1

# Generated at 2022-06-25 04:26:16.334279
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:26:20.350991
# Unit test for function from_yaml
def test_from_yaml():

    # FIXME: This unit test is incomplete.
    # assert from_yaml() == expected
    assert test_case_0() == None


# Generated at 2022-06-25 04:26:25.969037
# Unit test for function from_yaml
def test_from_yaml():
    # str_0 = 'p\x0cSU\\-GFtC'
    # var_0 = from_yaml(str_0)

    str_1 = 'p\x0cSU\\-GFtC'
    var_1 = from_yaml(str_1, file_name='<string>', show_content=True)

if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:26:36.101899
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:26:38.008211
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError):
        from_yaml('{"a": "Hi"}')



# Generated at 2022-06-25 04:26:39.015915
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Generated at 2022-06-25 04:26:46.729288
# Unit test for function from_yaml

# Generated at 2022-06-25 04:26:49.214186
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('p\x0cSU\\-GFtC') == 'p\x0cSU\\-GFtC'


# Generated at 2022-06-25 04:26:50.088818
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:26:53.641142
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert from_yaml == 'p\x0cSU\\-GFtC'
    except AssertionError:
        assert from_yaml == 'p\x0cSU\\-GFtC'



# Generated at 2022-06-25 04:27:00.875002
# Unit test for function from_yaml
def test_from_yaml():
    print('Testing function from_yaml')
    try:
        test_case_0()
    except (AnsibleParserError, YAMLError) as exc:
        assert False, traceback.format_exc()


if __name__ == '__main__':
    print('Testing Ansible', __version__)
    test_from_yaml()

# Generated at 2022-06-25 04:27:11.118362
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-25 04:27:13.317791
# Unit test for function from_yaml
def test_from_yaml():
    # Make sure that this compiles, that is all we need to do
    assert callable(from_yaml)

# Test if function from_yaml compiles.

# Generated at 2022-06-25 04:27:33.718612
# Unit test for function from_yaml
def test_from_yaml():
    # Test with valid data.
    str_0 = '{"KL-GFtC": [null, "", "p\x0cSU\\-GFtC", false, {"pt": "KL-GFtC"}, 0.0]}'
    var_0 = from_yaml(str_0)
    assert var_0 is not None
    assert isinstance(var_0, dict)
    assert len(var_0) == 1

    # Test with invalid data.
    str_1 = '{"KL-GFtC": [null, "", "p\x0cSU\\-GFtC", false, {"pt": "KL-GFtC"}, 0.0]}'

# Generated at 2022-06-25 04:27:38.354310
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('\x03') == 3
    assert from_yaml('true') == True
    assert from_yaml('\x00') is None
    assert from_yaml('text') == 'text'
    assert from_yaml('array', json_only=True) == 'array'

# Generated at 2022-06-25 04:27:46.331610
# Unit test for function from_yaml

# Generated at 2022-06-25 04:27:54.333420
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "T\x00\x00\x00123\x00\x00\x00\x00\x00\x00\x00"
    str_1 = "<string>"
    i_2 = from_yaml(str_0, str_1)
    i_3 = from_yaml(str_1, str_1)
    str_4 = "5\x00\x00\x00123\x00\x00\x00\x00\x00\x00\x00"
    i_5 = from_yaml(str_4, str_1)

# Generated at 2022-06-25 04:27:57.972791
# Unit test for function from_yaml
def test_from_yaml():
    assert 0 == 0
    # This tests a subset of the cases.
    # Additional tests can be found in the Ansible project.
    pass


# Generated at 2022-06-25 04:28:06.036206
# Unit test for function from_yaml
def test_from_yaml():
    # Tests for the function from_yaml
    str_0 = ''

# Generated at 2022-06-25 04:28:14.192284
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:25.431829
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:31.192803
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'nr0cL\x008{'
    from_yaml(str_0)
    str_0 = 'dnr0cL\x008{'
    from_yaml(str_0)
    str_0 = 'znr0cL\x008{'
    from_yaml(str_0)
    str_0 = 'inr0cL\x008{'
    from_yaml(str_0)
    str_0 = ';nr0cL\x008{'
    from_yaml(str_0)

# Generated at 2022-06-25 04:28:35.631938
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '@'
    var_0 = from_yaml(str_0)


# Generated at 2022-06-25 04:28:55.735361
# Unit test for function from_yaml
def test_from_yaml():
    # Tests our ability to process a JSON string
    json_str = '{"pi": 3.14159265358979, "f": 42}'
    new_data = from_yaml(json_str)
    assert new_data == {"pi": 3.14159265358979, "f": 42}

    # Tests our ability to process a YAML string
    yaml_str = '---\nlist: [1, 2, 3]\ndict:\n  str: string\n  int: 42\n'
    new_data = from_yaml(yaml_str)
    assert new_data == {"list": [1, 2, 3], "dict": {"str": "string", "int": 42}}

    # Tests our ability to process a YAML string containing a YAML sequence

# Generated at 2022-06-25 04:29:05.066550
# Unit test for function from_yaml
def test_from_yaml():
    shown_content_0 = True
    file_name_0 = '<string>'
    # Call function from_yaml with appropriate arguments.
    # It is better to set show_content_0 to True to get an accurate failure message.
    test_case_0()

if __name__ == "__main__":
    import ansible.parsing.dataloader
    from ansible.parsing.vault import VaultLib
    
    vault = VaultLib("secret") # Vault password is secret
    loader = ansible.parsing.dataloader.DataLoader()
    data = loader.load_from_file('redhat.yml')
    
    vault.load_decryption_key("redhat_vault_key")
    
    secret = vault.decrypt(data)
    print(secret)

# Generated at 2022-06-25 04:29:08.442663
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"\\x00"'
    str_1 = 'p\x0cSU\\-GFtC'
    str_2 = '\x00'
    str_3 = '\x00'

    for _ in range(10):
        var_0 = from_yaml(str_0)
        var_1 = from_yaml(str_1)
        var_2 = from_yaml(str_2)
        var_3 = from_yaml(str_3)

# Generated at 2022-06-25 04:29:15.112818
# Unit test for function from_yaml
def test_from_yaml():
    tests = [
        'p\x0cSU\\-GFtC'
    ]
    for test in tests:
        var_0 = from_yaml(test)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:29:19.463241
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    test_case_0()

# Generated at 2022-06-25 04:29:21.014642
# Unit test for function from_yaml
def test_from_yaml():
    print("Test 0")
    test_case_0()


if __name__ == '__main__':
    pass

# Generated at 2022-06-25 04:29:22.282731
# Unit test for function from_yaml
def test_from_yaml():
    print("Running unit test for function from_yaml")

    test_case_0()

test_from_yaml()

# Generated at 2022-06-25 04:29:25.548262
# Unit test for function from_yaml
def test_from_yaml():
    assert isinstance(test_case_0(), dict)


# Generated at 2022-06-25 04:29:28.207467
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:29:37.669878
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '?mQf*'
    str_1 = '=FmYE'
    str_2 = '*_N'
    str_3 = 'k'
    str_4 = 's'
    str_5 = 'D'
    str_6 = '*'
    str_7 = '$'
    str_8 = 'a'
    str_9 = 'l'
    str_10 = 'n'
    str_11 = '\\"6'
    str_12 = 'C'
    str_13 = '\\"'
    str_14 = 'X'
    str_15 = 'm'
    str_16 = '+'
    str_17 = '6'
    str_18 = 'M'
    str_19 = 'p'
    str_20 = ')'


# Generated at 2022-06-25 04:30:06.553172
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{ "Error": "Incorrect usage" }'
    var_0 = from_yaml(str_0)
    assert var_0 == {'Error': 'Incorrect usage'}

    str_1 = '''{ 
        "answer": 42,
        "question": "How many roads must a man walk down?",
        "reference": "Banks",
        "answerer": "Igor"
    }'''
    var_1 = from_yaml(str_1)

    assert var_1 == {'answer': 42, 'question': 'How many roads must a man walk down?', 'reference': 'Banks', 'answerer': 'Igor'}


# Generated at 2022-06-25 04:30:12.680809
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'Z+r_r\rCIM|\x00h\x0f\x13U\x1b\x14\x06'
    var_0 = from_yaml(str_0)
    assert var_0 is not None

    str_1 = 'J\x0fq\x0b'
    var_1 = from_yaml(str_1)
    assert var_1 is not None

    str_2 = '|W\x1b'
    var_2 = from_yaml(str_2)
    assert var_2 is not None

    str_3 = 'B&\x1b\x11'
    var_3 = from_yaml(str_3)
    assert var_3 is not None


# Generated at 2022-06-25 04:30:20.735681
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '\n    - r\x0cb6\n    - l\x0c,\n    - g\x0c-\n    - y\x0c4\n    - \x0c\n    - \x0c\n    - \x0c\n    - \x0c\n    - \x0c\n    - \x0c\n    - \x0c\n    - \x0c\n'
    var_0 = from_yaml(str_0)

    str_1 = '\n    - b\x0c4\n    - e\x0c\n    - \x0c\n    - \x0c\n    - \x0c\n'
    var_1 = from_yaml(str_1)

    str

# Generated at 2022-06-25 04:30:28.634255
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo":"bar"}') == {u'foo': u'bar'}
    assert from_yaml('{foo:"bar"}') == {u'foo': u'bar'}
    assert from_yaml('---\n- foo\n- bar\n') == [u'foo', u'bar']
    assert from_yaml('[foo, bar]') == [u'foo', u'bar']
    assert from_yaml('\n- foo\n- bar\n') == [u'foo', u'bar']

# Generated at 2022-06-25 04:30:39.180862
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)
    str_1 = '!string foobar'

# Generated at 2022-06-25 04:30:45.941485
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'p\x0cSU\\-GFtC'
    var_0 = from_yaml(str_0)
    # var_0 should be an instance of AnsibleBaseYAMLObject
    assert isinstance(var_0, AnsibleBaseYAMLObject)
    assert var_0.ansible_type == 'dict'
    assert var_0.ansible_pos[0] == '<string>'
    str_1 = 'p\x0cSU\\-GFtC'
    var_1 = from_yaml(str_1)
    # var_1 should be an instance of AnsibleBaseYAMLObject
    assert isinstance(var_1, AnsibleBaseYAMLObject)
    assert var_1.ansible_type == 'dict'
    assert var_1.ansible_

# Generated at 2022-06-25 04:30:47.732691
# Unit test for function from_yaml
def test_from_yaml():
    with open('res/ansible.cfg') as file:
        data = file.read()
        var_0 = from_yaml(data)
        assert type(var_0) is dict


# Generated at 2022-06-25 04:30:55.132361
# Unit test for function from_yaml
def test_from_yaml():
    arg_0 = '"`"E-~pI9x=\x14dO\x0e\x7fS'
    arg_1 = '<string>'
    arg_2 = True
    arg_3 = None
    arg_4 = False
    ret_0 = from_yaml(arg_0, arg_1, arg_2, arg_3, arg_4)


# Generated at 2022-06-25 04:31:05.216653
# Unit test for function from_yaml

# Generated at 2022-06-25 04:31:10.433439
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(data=None, file_name=None, show_content=None, vault_secrets=None, json_only=None)