

# Generated at 2022-06-25 04:21:50.315870
# Unit test for function from_yaml
def test_from_yaml():
    # pylint: disable=E1120
    # pylint: disable=E1123
    # pylint: disable=W0613

    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    dict_0 = from_yaml(bytes_0)
    dict_1 = from_yaml(dict_0)

    # Verify that the given variable is unknown to the script
    assert dict_1 is None

    # Verify that the given variable is unknown to the script
    assert dict_0 is None

# Test the function named 'is_list_list'

# Generated at 2022-06-25 04:21:58.944493
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    assert isinstance(var_0, dict)
    assert var_0 == {"_meta": {"hostvars": {}}}

    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0, json_only=False)
    assert isinstance(var_0, dict)
    assert var_0 == {"_meta": {"hostvars": {}}}


# Generated at 2022-06-25 04:22:05.797428
# Unit test for function from_yaml
def test_from_yaml():
    test_data = b'\x8fz\xe0\x1a\xda\xad\xe8'
    test_file_name = 'test file name'
    test_show_content = True
    test_vault_secrets = 'test vault secrets'
    test_json_only = False
    assert from_yaml(test_data, test_file_name, test_show_content, test_vault_secrets, test_json_only) is not None



# Generated at 2022-06-25 04:22:08.078736
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:22:12.170088
# Unit test for function from_yaml
def test_from_yaml():
    x = from_yaml('[ foo, bar, foobar ]')
    assert x == ['foo', 'bar', 'foobar']

# Generated at 2022-06-25 04:22:15.730169
# Unit test for function from_yaml
def test_from_yaml():
    var_1 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_2 = '<string>'
    var_3 = True
    # Call function
    result = from_yaml(var_1, var_2, var_3)
    assert result == {'[G': 8.8385408e-33, '\xdd\x8e\x0c1': 8.8385408e-33, '\xe4\xef\x00': 8.8385408e-33}



# Generated at 2022-06-25 04:22:20.881186
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    assert var_0 == None

# Generated at 2022-06-25 04:22:21.423791
# Unit test for function from_yaml
def test_from_yaml():
    assert True



# Generated at 2022-06-25 04:22:22.832027
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:22:25.244636
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    assert test_case_0() == None


# Generated at 2022-06-25 04:22:35.944812
# Unit test for function from_yaml

# Generated at 2022-06-25 04:22:46.857866
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x07\xc8\xa6\xae\xd2\xbf\x8c\xad\x17\x14\xadO\x8f\xa3\x96\x94\x06\x0b\xd2\xb6\xc5;'
    bytes_1 = b'\xa3\x17\x1f\xb3,\x9f\xcb\x13\xe8\xff\x00'
    bytes_2 = b'\xa3\x1f\x08\xfa\x8c\x0e\xcf\xed\xff\x00'
    bytes_3 = b'\xa3\x12\xd3\x00\x87\xa5\x1e\xe8\xff\x00'
    bytes_4

# Generated at 2022-06-25 04:22:56.031901
# Unit test for function from_yaml
def test_from_yaml():
    string_0 = 'i\x05\x00\x00\x00world\x06\x00\x00\x00s.\x00\x00\x00\x00\x00\x0c\x00\x00\x00z\x0e\x00\x00\x00'
    assert from_yaml(string_0) == 'world'
    # test_file_0 - test_file_0
    result = from_yaml('', 'test_file_0')
    assert result == ''
    string_0 = '\x80\x02}q\x01(U\x05stateq\x02U\x07installq\x03u.'
    var_0 = from_yaml(string_0)

# Generated at 2022-06-25 04:23:00.783220
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(TypeError):
        from_yaml('\x10\xbd\xfc\xb1\x02')

# Generated at 2022-06-25 04:23:13.147358
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'

# Generated at 2022-06-25 04:23:21.756081
# Unit test for function from_yaml
def test_from_yaml():
    data = b'\x93\xcd\xab\xcb\x8c\xb6\x89\xc5\xc7\x8d\x01\xed\x81\x96\x9d\x18\x89\x92\x98\x8d\x01\xed\x82\x96\x9d\xa3\xcd\xab\xcb\x8c\xb6\x89\xc5\xc7\x8d\x01\xed\x81\x96\x9d\x18\x89\x92\x98\x8d\x01\xed\x82\x96\x9d'
    var = from_yaml(data)

if __name__ == '__main__':
    test_case_0()
   

# Generated at 2022-06-25 04:23:27.264765
# Unit test for function from_yaml
def test_from_yaml():
    print('TEST 1: ')
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    from_yaml(bytes_0)
    print("pass")

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:33.864288
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    assert var_0 is None
    bytes_1 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_1 = from_yaml(bytes_1)
    assert var_1 is None
    bytes_2 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_2 = from_yaml(bytes_2)
    assert var_2 is None

if __name__ == "__main__":
    test_case_0()
    test_from_

# Generated at 2022-06-25 04:23:41.441541
# Unit test for function from_yaml
def test_from_yaml():
    counter = 0
    while True:
        counter += 1
        try:
            test_case_0()
            break
        except Exception:
            if counter > 3:
                raise

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:43.446512
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing for an exception to be thrown")
    test_case_0()

# Generated at 2022-06-25 04:23:51.809900
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x92Q\x00P\x000\n'
    var_0 = from_yaml(bytes_0)

    str_0 = '\x9c\xc7\xdb\x82\x1b\xe5\xdb\x82\x1b\x1b\x9d'
    var_1 = from_yaml(str_0)

    bytearray_0 = bytearray(b'\x9d\x9e\x9f\xa0\xa1\xa2\xa3')
    var_2 = from_yaml(bytearray_0)

    bytes_1 = b'\x00\x01\x02\x03\x04\x05\x06'

# Generated at 2022-06-25 04:23:56.306803
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:23:58.370875
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:59.655407
# Unit test for function from_yaml
def test_from_yaml():

    assert True # TODO: implement your test here


# Generated at 2022-06-25 04:24:10.268064
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    assert type(var_0) is dict
    assert var_0 == {'h': 'h', 'g': 'g', 'f': 'f'}

# Generated at 2022-06-25 04:24:12.007609
# Unit test for function from_yaml
def test_from_yaml():
    assert type(from_yaml(b'\xa3[G\xdd\x8e\x0c1\xef\x00')) == dict

# Generated at 2022-06-25 04:24:19.413944
# Unit test for function from_yaml
def test_from_yaml():
    input = b'{\n    "foo": "bar"\n}'
    actual = from_yaml(input)
    expected = {'foo': 'bar'}
    assert actual == expected

    input = b'{ foo: bar }'
    actual = from_yaml(input)
    expected = {'foo': 'bar'}
    assert actual == expected

# Generated at 2022-06-25 04:24:26.864396
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    assert var_0 == None
    bytes_1 = b'#\x00\x00\x00\x03foo\x00\x03bar\x00\x07foobar\x00\x00\x00\x04\x00\x00\x00\x00'
    var_1 = from_yaml(bytes_1)
    assert var_1 == None
    bytes_2 = b',[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_2 = from_yaml(bytes_2)
    assert var_2 == None
   

# Generated at 2022-06-25 04:24:31.141503
# Unit test for function from_yaml
def test_from_yaml():
    # Try to decode the binary string "b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'" as JSON
    data = '\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    test_case_0()


test_from_yaml()

# Generated at 2022-06-25 04:24:38.805036
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() == None
#
# Unit tests for function from_yaml
#
# test_case_0 is a yaml dump of a random string which should raise a yaml parsing error
#
# test_case_1 is a yaml dump of a random string which should raise a json parsing error
#
# test_case_2 is a multiline string which should be parsed and returned
#
# test_case_3 is a list of strings which should be parsed and returned
#
# test_case_4 is a dict of strings which should be parsed and returned
#
# test_case_5 is a yaml dump of a None object and should return None
#
# test_case_6 is a yaml dump of an empty object and should raise a yaml parsing error



# Generated at 2022-06-25 04:24:49.522762
# Unit test for function from_yaml
def test_from_yaml():
    string_1 = "aoeu"
    test_from_yaml_0(string_1)
    string_1 = "aoeu"
    test_from_yaml_1(string_1)
    test_from_yaml_3()
    test_from_yaml_4()
    test_from_yaml_5()


# Generated at 2022-06-25 04:25:00.907510
# Unit test for function from_yaml
def test_from_yaml():
    # Test that the first 1000 generated test cases have no exceptions
    for i in range(1000):
        test_case_0()

    # Test that the first 1000 generated test cases have no exceptions
    for i in range(1000):
        test_case_0()

    # Test that the first 1000 generated test cases have no exceptions
    for i in range(1000):
        test_case_0()

    # Test that the first 1000 generated test cases have no exceptions
    for i in range(1000):
        test_case_0()

    # Test that the first 1000 generated test cases have no exceptions
    for i in range(1000):
        test_case_0()

    # Test that the first 1000 generated test cases have no exceptions
    for i in range(1000):
        test_case_0()

    # Test that the first 1000 generated test cases have no exceptions

# Generated at 2022-06-25 04:25:08.556752
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml(b'\xc5\x00\x02\xa3\xa5\x00\x00\xb9\xa0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    except Exception as e:
        return True
    return False

# Generated at 2022-06-25 04:25:09.515987
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True

# Generated at 2022-06-25 04:25:19.680243
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    value_0 = from_yaml(bytes_0)
    expected_value_0 = [97, 71, 253, 142, 12, 49, 228, 239, 0]
    assert value_0 == expected_value_0
    bytes_1 = b'\xf8\xeb\x15\x13\xb9\x89\xd2\x00\x99\xb4\xfe\xc4\xeb\x00\x94\xbb\x8a\x00\xbb\x00'
    value_1 = from_yaml(bytes_1)

# Generated at 2022-06-25 04:25:25.021185
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml()
        assert False
    except TypeError:
        assert True
    except AssertionError:
        assert True
    except Exception:
        assert False
# Tests end here

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        globals()[sys.argv[1]]()
    else:
        raise Exception("Missing function name as argument")

# Generated at 2022-06-25 04:25:27.548235
# Unit test for function from_yaml
def test_from_yaml():
    # No input for json_only argument
    assert test_case_0() == None

# Generated at 2022-06-25 04:25:28.285129
# Unit test for function from_yaml
def test_from_yaml():
    assert True


# Generated at 2022-06-25 04:25:33.697724
# Unit test for function from_yaml
def test_from_yaml():
    data = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(data)
    assert type(var_0) == list
    assert var_0 == [u'G', u'\u8e01', u'1', u'\u4ef6', u'\u0000']
    assert len(var_0) == 5



# Generated at 2022-06-25 04:25:39.410738
# Unit test for function from_yaml
def test_from_yaml():
    try:
        # Test passes if this parses without an exception
        from_yaml(u'{"foo": "bar"}')
    except:
        # Some other exception was thrown
        assert(False)

    # Test passes if this raises an exception
    try:
        from_yaml('{foo: bar}')
        assert(False)
    except:
        # Expected exception
        pass

# Generated at 2022-06-25 04:25:44.789351
# Unit test for function from_yaml
def test_from_yaml():
    assert True==True # FIXME: implement some test cases here.


# Generated at 2022-06-25 04:25:46.244778
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Test suite main

# Generated at 2022-06-25 04:25:55.694817
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.display import Display
    display = Display()
    display.notify('testing from_yaml')


# Generated at 2022-06-25 04:26:00.642588
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    assert var_0 == 'a'

test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:26:11.326065
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    # test_case_0
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    assert var_0 is not None
    bytes_1 = b'\xb4\xad\xe2\xe8\x14\xab>\x9c\xa8\x94\x98\xbd\x1d\xc1\x00'
    var_1 = from_yaml(bytes_1)
    assert var_1 is not None

# Generated at 2022-06-25 04:26:18.577361
# Unit test for function from_yaml

# Generated at 2022-06-25 04:26:24.615077
# Unit test for function from_yaml
def test_from_yaml():
    data = 'test'
    file_name = '<string>'
    show_content = True
    vault_secrets = None
    json_only = False
    assert_equals(from_yaml(data, file_name, show_content, vault_secrets,
                            json_only), 'test')



# Generated at 2022-06-25 04:26:31.312665
# Unit test for function from_yaml
def test_from_yaml():

    test_data = '''
---
- hosts: localhost
  gather_facts: false
  tasks:
  - name: example task
    debug:
      msg: "This is an example"
'''

    var_1 = from_yaml(test_data)
    assert var_1 == [{'gather_facts': False, 'hosts': 'localhost', 'tasks': [{'name': 'example task', 'debug': {'msg': 'This is an example'}}]}]

# Generated at 2022-06-25 04:26:36.087159
# Unit test for function from_yaml
def test_from_yaml():
    assert 'Authorization' in test_case_0()
    assert 'json' in test_from_yaml

# Generated at 2022-06-25 04:26:44.663194
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    var_d = {"a": [], "b": {"c": [1, 2, 3]}}
    var_1 = from_yaml(to_native(var_d))
    assert var_d == var_1
    # yaml_0 is a str
    yaml_0 = """
    ---
    - hosts: localhost
      tasks:
         - action: debug msg={{ var }}
    """
    # var_2 is a str
    var_2 = from_yaml(yaml_0)

# Generated at 2022-06-25 04:26:57.006358
# Unit test for function from_yaml
def test_from_yaml():
    # False positive, issue #12774
    test_case_0()

# Generated at 2022-06-25 04:27:02.640081
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'[G]') == [u'G']
    assert from_yaml(b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00') == u'[G]'

# Generated at 2022-06-25 04:27:03.726406
# Unit test for function from_yaml
def test_from_yaml():
    assert True


# Generated at 2022-06-25 04:27:13.158263
# Unit test for function from_yaml
def test_from_yaml():
    # Simple case
    bytes_0 = b'\x84foo\xa3bar\x83\xa3baz\x03foo\x83\xa3bar\x03baz'
    var_0 = from_yaml(bytes_0)
    assert var_0 == {'foo': ['bar', {'baz': 'foo'}, {'bar': 'baz'}]}

    # This is a bit more complicated
    bytes_1 = b'\x85foo\xa4bar\x81\x85baz\x80\x84bat\xa3man\x81\x83\xa3foo\x02\x03bar\x03bat\x03man'
    var_1 = from_yaml(bytes_1)

# Generated at 2022-06-25 04:27:17.947680
# Unit test for function from_yaml
def test_from_yaml():
    # Test with big endian
    input_bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(input_bytes_0)
    print("var_0: " + str(var_0))
    assert var_0 == "test"

# Generated at 2022-06-25 04:27:19.211367
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 04:27:31.649513
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    assert var_0 == None

    bytes_1 = b'\x9e\xa0!\xe5\x94\x18\xa2\x0c0\xe4\xef\x00'
    var_1 = from_yaml(bytes_1)
    assert var_1 == None

    bytes_2 = b'\x9d\xd2\xaa\x0b\xdc\x8f\x882\xe4\xef\x00'
    var_2 = from_yaml(bytes_2)
    assert var_2 == None


# Generated at 2022-06-25 04:27:37.545805
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    assert var_0 == b'[G\xdd\x8e\x0c1\xe4\xef\x00'

# Generated at 2022-06-25 04:27:42.904710
# Unit test for function from_yaml

# Generated at 2022-06-25 04:27:48.268883
# Unit test for function from_yaml
def test_from_yaml():

    # TODO: generate random data and pass to the function,
    # then assert that the results are correct for each possible case
    # TODO: create test cases for each of the function exit points
    test_case_0()

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:28:15.875256
# Unit test for function from_yaml
def test_from_yaml():
    test_path = 'ansible/parsing/dataloader/tests/data/yaml'

# Generated at 2022-06-25 04:28:19.449354
# Unit test for function from_yaml
def test_from_yaml():
    assert var_0 == b'[G\xdd\x8e\x0c1\xe4\xef\x00'

# Generated at 2022-06-25 04:28:20.213496
# Unit test for function from_yaml
def test_from_yaml():
    assert 0 == 0


# Generated at 2022-06-25 04:28:22.934523
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except AnsibleParserError as e:
        assert False, "AnsibleParserError was raised:" + str(e)



# Generated at 2022-06-25 04:28:26.636699
# Unit test for function from_yaml
def test_from_yaml():
    assert type(test_case_0()) == list



# Generated at 2022-06-25 04:28:32.455426
# Unit test for function from_yaml
def test_from_yaml():
    import os
    # In case of no arguments being passed, the default string '<string>' is used.
    # This is the default behavior.
    var_0 = from_yaml(b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00')
    assert var_0 == '<string>'
    # Pass all arguments in order.
    var_1 = from_yaml(b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00', 'yaml_file', True, '123', True)
    assert var_1 == '<string>'



# Generated at 2022-06-25 04:28:40.963916
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import ansible.errors
    # Case 1
    bytes_1 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_1 = from_yaml(bytes_1)
    assert((var_1 == b'[G\xdd\x8e\x0c1\xe4\xef'))
    # Case 2 ok
    bytes_2 = b'{\x00'
    var_2 = from_yaml(bytes_2)
    assert((var_2 == {}))

    # Case 10 ok

# Generated at 2022-06-25 04:28:43.910118
# Unit test for function from_yaml
def test_from_yaml():
    call_args = [
        {
            'b': 0,
            'c': 1,
            'd': 2,
            'e': 3,
        },
    ]
    return_value = None

    return_value = from_yaml(*call_args)
    
    # Check if from_yaml matches return value from original
    assert return_value == test_case_0(), "Return value does not match"

# Generated at 2022-06-25 04:28:48.126766
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    assert from_yaml(bytes_0) == True

# Generated at 2022-06-25 04:28:49.145002
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)

# Generated at 2022-06-25 04:29:35.566224
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'abc'
    bytes_1 = b'\x1b[;31mabc\x1b[m'

    result = from_yaml(bytes_0)

    ans = 'abc'
    assert result == ans

    try:
        result = from_yaml(bytes_1)
    except Exception as err:
        assert isinstance(err, AnsibleParserError)
        assert 'We were unable to read either as JSON nor YAML, these are the errors we got from each: JSON: Expecting property name enclosed in double quotes: line 1 column 2 (char 1)' in to_native(err.orig_exc)

    try:
        result = from_yaml(bytes_0, show_content=False)
    except Exception as err:
        assert isinstance(err, AnsibleParserError)

    # assert

# Generated at 2022-06-25 04:29:39.950249
# Unit test for function from_yaml
def test_from_yaml():
    data = "some"
    file_name = "<string>"
    show_content = True
    vault_secrets = None
    json_only = False
    result = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    assert result is not None


# Generated at 2022-06-25 04:29:46.690842
# Unit test for function from_yaml
def test_from_yaml():
    ds = '''
    ---
    # this is a YAML comment
    name: foo
    {# this is a YAML comment in a line block #}
    description: |
      This is
      a multiline
      value
    build_date: "2017-10-12"
    '''

    d = from_yaml(ds)
    assert d['name'] == 'foo'
    assert d['description'] == "This is\na multiline\nvalue\n"
    assert d['build_date'] == '2017-10-12'

# Generated at 2022-06-25 04:29:55.080387
# Unit test for function from_yaml
def test_from_yaml():

    bytes_0 = b'x\x9c\xab\xcd\xef\x01\x00\x81\x9f'
    bytes_1 = b'\x00\x00'
    bytes_2 = b'\x00'

# Generated at 2022-06-25 04:29:55.871753
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None



# Generated at 2022-06-25 04:30:02.268016
# Unit test for function from_yaml
def test_from_yaml():
    # Call function from_yaml with arguments:
    #   arg_0: '\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    assert test_case_0() == None

# Generated at 2022-06-25 04:30:10.699757
# Unit test for function from_yaml
def test_from_yaml():
    # Ensure the test reproduces some of the failures from test_case_0
    # with these settings.
    import os
    import sys
    os.environ['ANSIBLE_YAML_FILENAME'] = 'test_case_0'
    ansible_debug_enabled = os.environ.get('ANSIBLE_DEBUG', None)
    if not ansible_debug_enabled:
        os.environ['ANSIBLE_DEBUG'] = 'true'

    # Load the yaml module
    # AnsibleDumper=None, AnsibleConstructor=None, AnsibleSafeDumper=None
    # AnsibleSafeConstructor=None, Indent=None, default_flow_style=None,
    # width=None, allow_unicode=None, line_break=None, encoding=None,
    # explicit_start=None, explicit_

# Generated at 2022-06-25 04:30:14.912096
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    bytes_1 = b'\xde\xe2\xac\x80'
    var_1 = from_yaml(bytes_1)

    assert var_0 == ['a', 'b', 'c', '1', '2', '3']
    assert var_1 == [1,2,3,4]

# Generated at 2022-06-25 04:30:16.431006
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(None, file_name=None)

# Generated at 2022-06-25 04:30:26.767998
# Unit test for function from_yaml

# Generated at 2022-06-25 04:31:10.815089
# Unit test for function from_yaml
def test_from_yaml():
    poc_json = b'{"menu": {"id": "file", "value": "File", "popup": {"menuitem": [{"value": "New", "onclick": "CreateNewDoc()"}, {"value": "Open", "onclick": "OpenDoc()"}, {"value": "Close", "onclick": "CloseDoc()"}]}}}'
    poc_yaml = b'menu:\n  id: file\n  popup:\n    menuitem:\n    - value: New\n      onclick: CreateNewDoc()\n    - value: Open\n      onclick: OpenDoc()\n    - value: Close\n      onclick: CloseDoc()\n  value: File\n'

# Generated at 2022-06-25 04:31:15.149662
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b"%YAML 1.2\n---\n!!str 'hello world'\n...\n"
    var_0 = from_yaml(bytes_0)
    # Test for equality using known output
    assert var_0 == 'hello world'



# Generated at 2022-06-25 04:31:22.213125
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing function from_yaml")
    test_case_0()
    #test_case_1()
    #test_case_2()
    #test_case_3()
    #test_case_4()
    #test_case_5()
    #test_case_6()
    #test_case_7()
    #test_case_8()
    #test_case_9()
    #test_case_10()
    #test_case_11()
    #test_case_12()
    #test_case_13()
    #test_case_14()
    #test_case_15()
    #test_case_16()
    #test_case_17()
    #test_case_18()
    #test_case_19()
    #test_case_20()


# Generated at 2022-06-25 04:31:22.912941
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True

# Generated at 2022-06-25 04:31:32.981855
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xa3[G\xdd\x8e\x0c1\xe4\xef\x00'
    var_0 = from_yaml(bytes_0)
    bytes_1 = b'\x00'
    var_1 = from_yaml(bytes_1)
    bytes_2 = b'\x00'
    var_2 = from_yaml(bytes_2)
    bytes_3 = b'\x00'
    var_3 = from_yaml(bytes_3)
    bytes_4 = b'\x00'
    var_4 = from_yaml(bytes_4)
    bytes_5 = b'\x00'
    var_5 = from_yaml(bytes_5)
    bytes_6 = b'\x00'
    var

# Generated at 2022-06-25 04:31:36.471214
# Unit test for function from_yaml
def test_from_yaml():

    test_0 = '{"charset": "utf-8", "content": "Hi"}'

# Generated at 2022-06-25 04:31:37.543593
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)


# Generated at 2022-06-25 04:31:38.569240
# Unit test for function from_yaml
def test_from_yaml():
    print('Testing test_case_0...')
    test_case_0()

# Generated at 2022-06-25 04:31:42.312207
# Unit test for function from_yaml
def test_from_yaml():
    # Parameters
    data = 'The quick brown fox'
    file_name = '/tmp/foo'
    show_content = True
    vault_secrets = None
    json_only = False
    # Execute the function
    result = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    # Verify the result
    assert result == 'The quick brown fox'

