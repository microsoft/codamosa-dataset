

# Generated at 2022-06-25 04:21:41.735529
# Unit test for function from_yaml
def test_from_yaml():
    dict_0 = {'key_0': 'value_0', 'key_1': ['value_1', 'value_2'], 'key_2': {'key_3': 'value_3', 'key_4': ['value_4', 'value_5'], 'key_5': ['value_6', 'value_7']}, 'key_8': ['value_8', 'value_9']}
    var_0 = from_yaml(dict_0)



# Generated at 2022-06-25 04:21:44.731786
# Unit test for function from_yaml
def test_from_yaml():
    dict_0 = {}
    var_0 = from_yaml(dict_0)



# Generated at 2022-06-25 04:21:47.933443
# Unit test for function from_yaml
def test_from_yaml():

    # Test for with no args
    dict_0 = {}
    var_0 = from_yaml(dict_0)

    # Test for with list arg
    dict_1 = {}
    var_1 = from_yaml(dict_1)

# Generated at 2022-06-25 04:21:58.198959
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = from_yaml('{"a": 1, "b": 2}')
    assert var_0 == {"a": 1, "b": 2}
    var_1 = from_yaml('{"a": 1, "b": 2}', '<string>')
    assert var_1 == {"a": 1, "b": 2}
    var_2 = from_yaml('{"a": 1, "b": 2}', '<string>', True)
    assert var_2 == {"a": 1, "b": 2}
    var_3 = from_yaml('{"a": 1, "b": 2}', '<string>', True, None)
    assert var_3 == {"a": 1, "b": 2}

# Generated at 2022-06-25 04:21:59.846968
# Unit test for function from_yaml
def test_from_yaml():

    try:
        test_case_0()
    except AnsibleParserError as e:
        assert False, str(e)
    else:
        assert True

# Generated at 2022-06-25 04:22:01.544399
# Unit test for function from_yaml
def test_from_yaml():
    dict_0 = {}
    var_0 = from_yaml(dict_0)



# Generated at 2022-06-25 04:22:03.484899
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml({}) == {}


    assert from_yaml("hello") == {'hello': True}

# Generated at 2022-06-25 04:22:04.292595
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml == dict_0

# Generated at 2022-06-25 04:22:12.337061
# Unit test for function from_yaml
def test_from_yaml():
    j = '{"a": "ansible", "b": "banana", "c": "cat"}'
    y = '---\na: "ansible"\nb: "banana"\nc: "cat"\n...\n'

    d1 = from_yaml(to_bytes(y, errors='surrogate_or_strict'))
    d2 = from_yaml(to_bytes(j, errors='surrogate_or_strict'))
    assert d1 == d2

    # We should raise an error if JSON fails
    from_yaml(to_bytes('{ 1: 1}', errors='surrogate_or_strict'), json_only=True)


# Generated at 2022-06-25 04:22:19.609155
# Unit test for function from_yaml
def test_from_yaml():

    # Verify that AnsibleParserError exception is raised by function from_yaml
    # Verify that AnsibleParserError exception is raised with message
    # 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\n'
    # 'JSON: %s\n\n%s' % (to_native(json_exc), n_yaml_syntax_error)
    # gets called
    # where n_yaml_syntax_error is the value of
    # YAML_SYNTAX_ERROR % to_native(getattr(yaml_exc, 'problem', u''))
    pass

# Generated at 2022-06-25 04:22:26.543095
# Unit test for function from_yaml
def test_from_yaml():
    stream_test_0 = '[a, b]'
    var_test_0 = from_yaml(stream_test_0, stream_test_0)
    assert var_test_0 == ['a', 'b']



# Generated at 2022-06-25 04:22:30.234186
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:22:39.220737
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = '%Mnn!Bwl\x0czO|I(($'
    var_1 = from_yaml(str_1)
    str_2 = '%Mnn!Bwl\x0czO|I(($'
    var_2 = from_yaml(str_2)
    str_3 = '%Mnn!Bwl\x0czO|I(($'
    var_3 = from_yaml(str_3)
    str_4 = '%Mnn!Bwl\x0czO|I(($'
    var_4 = from_yaml(str_4)
    str_5 = '%Mnn!Bwl\x0czO|I(($'
    var_5 = from_yaml(str_5)

# Generated at 2022-06-25 04:22:48.283551
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "I'm a string!"
    var_0 = from_yaml(str_0)
    assert var_0 == 'I\'m a string!'
    str_1 = '{"key":"value"}'
    var_1 = from_yaml(str_1)
    assert isinstance(var_1, dict)
    assert var_1['key'] == 'value'
    str_2 = '{"key":"value"\n}'
    var_2 = from_yaml(str_2)
    assert isinstance(var_2, dict)
    assert var_2['key'] == 'value'

# Generated at 2022-06-25 04:22:52.803412
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)

# Generated at 2022-06-25 04:23:03.736366
# Unit test for function from_yaml
def test_from_yaml():
    from units.compat.mock import patch
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.module_utils.six import PY2, PY3
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    with patch('ansible.parsing.yaml.loader.AnsibleLoader') as mock_AnsibleLoader:
        mock_AnsibleLoader.return_value = AnsibleLoader
        mock_AnsibleLoader.get_single_data.return_value = AnsibleMapping
        mock_AnsibleLoader.dispose.return_value = None
        assert isinstance(from_yaml('{}'), AnsibleMapping)

# Generated at 2022-06-25 04:23:15.811116
# Unit test for function from_yaml
def test_from_yaml():
    local_var = 'fOy\xc1\x85\x06\xfd\xda\x7f\x91\x98\xc2[\xad\xebv\xed\x15i\xc5\xc8\xb5'
    local_var_0 = ']\x8f\x04\xe7\x03\xa6\x8b\xbb>\xac6\x07^'
    local_var_1 = '\xc4\xbd\x8aLh\xa7\x9b\x0c\x88\x00\xfd\xab\x14\xc3\xa2\x05\xd9\x9c'

# Generated at 2022-06-25 04:23:22.659847
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%Mnn!Bwl\x0czO|I(($'

    # Call function from_yaml with arguments str_0
    # is expected True
    assert from_yaml(str_0) == True

# Generated at 2022-06-25 04:23:26.386560
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing:", end=' ')

    test_case_0()
    print("OK")


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:28.760912
# Unit test for function from_yaml
def test_from_yaml():
    # Try to use a non-string variable as a variable name
    str_1 = '{test'
    var_1 = from_yaml(str_1, str_1)


# Generated at 2022-06-25 04:23:38.326323
# Unit test for function from_yaml
def test_from_yaml():
    var = from_yaml('{}', '<string>')
    assert isinstance(var, dict)
    assert var == {}

    var_1 = from_yaml('', '<string>')
    assert isinstance(var_1, (str, type(None)))
    assert var_1 == ''

    var_2 = from_yaml((), '<string>')
    assert isinstance(var_2, tuple)
    assert var_2 == ()

    var_3 = from_yaml('test', '<string>')
    assert isinstance(var_3, str)
    assert var_3 == 'test'

    var_4 = from_yaml([], '<string>')
    assert isinstance(var_4, list)
    assert var_4 == []


# Generated at 2022-06-25 04:23:40.101180
# Unit test for function from_yaml
def test_from_yaml():
    # str_0 = ''
    var_0 = from_yaml('')



# Generated at 2022-06-25 04:23:42.027989
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)



# Generated at 2022-06-25 04:23:42.704701
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:23:47.164648
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = {'api_key': 'ASDFASDFASDFASDFASDFASDF', 'api_password': '!QAZ2wsx'}
    var_1 = from_yaml("api_key: ASDFASDFASDFASDFASDFASDF\napi_password: '!QAZ2wsx'\n", str_0)
    assert var_0 == var_1


# Generated at 2022-06-25 04:23:56.508297
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 is None
    str_0 = '$s*3@'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 is None
    str_0 = '+Qt\x7f\x0a\x0a0^\x7f'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 is None
    str_0 = '\x1dO\x7f'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 is None

# Generated at 2022-06-25 04:24:05.101591
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{"bar":{"foo":{"baz":"1 2 3"}}}'
    # Expect True for fixture_0
    fixture_0 = from_yaml(str_0, str_0)
    assert fixture_0 is not False

    str_1 = "---\n- name: this is a test play\n  hosts: all\n  vars: {foo: 'bar baz'}\n  tasks:\n  - debug: msg='test'\n"
    # Expect True for fixture_1
    fixture_1 = from_yaml(str_1, str_1)
    assert fixture_1 is not False

    str_2 = '{"foo": "bar"}'
    # Expect True for fixture_2
    fixture_2 = from_yaml(str_2, str_2)

# Generated at 2022-06-25 04:24:09.484562
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == ()

# Generated at 2022-06-25 04:24:16.082744
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Ensure from_yaml accepts a string and returns a dict
    '''
    str_0 = '''
    list_of_int:
        - 1
        - 2
        - 3
    '''
    dict_0 = from_yaml(str_0)
    dict_1 = {'list_of_int': [1, 2, 3]}
    assert dict_0 == dict_1

# Generated at 2022-06-25 04:24:17.703078
# Unit test for function from_yaml
def test_from_yaml():

    test_case_0()

# --------------------------------------------------------------------------------------

if __name__ == "__main__":

    test_from_yaml()

# Generated at 2022-06-25 04:24:33.465976
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'dNzA6iZn9z'
    var_0 = from_yaml(str_0, str_0, True)

    str_1 = 'foo: bar'
    var_1 = from_yaml(str_1, str_1, True)

    str_2 = 'foo: bar\nbar: baz'
    var_2 = from_yaml(str_2, str_2, True)

    str_3 = 'foo: [1, 2, 3]'
    var_3 = from_yaml(str_3, str_3, True)

    str_4 = 'foo: [1, 2, 3]\nbar: [4, 5, 6]'
    var_4 = from_yaml(str_4, str_4, True)


# Generated at 2022-06-25 04:24:34.297378
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True


# Generated at 2022-06-25 04:24:45.437548
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("foo", "foo") == "foo"
    assert from_yaml("[1, 2, 3]", "[1, 2, 3]") == [1, 2, 3]

    # Test with a real-world YAML file.
    with open("playbook.yml", "r") as f:
        data = f.read()
    var_0 = from_yaml(data, "playbook.yml")
    assert isinstance(var_0, AnsibleBaseYAMLObject)
    assert var_0.ansible_pos == ("playbook.yml", 1, 1)

# Generated at 2022-06-25 04:24:54.775193
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    manifest_json = '{ "foo": 1}'
    manifest_yaml = 'foo: 1\n'
    assert from_yaml(manifest_json) == {'foo': 1}
    assert from_yaml(manifest_yaml) == {'foo': 1}
    assert from_yaml(manifest_json, json_only=True) == {'foo': 1}
    assert from_yaml(manifest_yaml, json_only=True) == {'foo': 1}
    assert from_yaml(manifest_yaml, json_only=False) == {'foo': 1}
    assert from_yaml(manifest_yaml + 'bar: 2\n') == {'foo': 1, 'bar': 2}


# Generated at 2022-06-25 04:25:02.444594
# Unit test for function from_yaml
def test_from_yaml():
    mock_in = StringIO('ZQB{sI<)$Gz]E%PJHNz{t')
    var_1 = from_yaml(mock_in)
    assert var_1 == 'ZQB{sI<)$Gz]E%PJHNz{t'
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == '%Mnn!Bwl\x0czO|I(($'

# Generated at 2022-06-25 04:25:09.893279
# Unit test for function from_yaml

# Generated at 2022-06-25 04:25:20.014873
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = '$0kW=G8@wTt'
    var_1 = from_yaml(str_1, str_1)
    assert (var_1 == "{'a': {'b': 1, 'c': 2}}")
    str_2 = 'G-kc\x7f~\x19\x1d:>'
    var_2 = from_yaml(str_2, str_2)
    assert (var_2 == "{'a': {'b': 1, 'c': 2}}")
    str_3 = '<\x11\x0c\x1c'
    var_3 = from_yaml(str_3, str_3)
    assert (var_3 == "{'a': {'b': 1, 'c': 2}}")

# Generated at 2022-06-25 04:25:24.834967
# Unit test for function from_yaml
def test_from_yaml():
    try:
        # Test case str_0
        str_0 = '%Mnn!Bwl\x0czO|I(($'
        var_0 = from_yaml(str_0, str_0)
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-25 04:25:34.799172
# Unit test for function from_yaml

# Generated at 2022-06-25 04:25:43.887005
# Unit test for function from_yaml
def test_from_yaml():

    # Test to make sure we use first json.loads, then from_yaml
    ansible_json_string = '''
    {
        "ansible_facts": {
            "distribution": "Fedora"
        },
        "changed": false,
        "invocation": {
            "module_args": {
                "key_name": "%(key_name)s",
                "name": "%(name)s"
            }
        }
    }
    '''
    out = from_yaml(ansible_json_string, '<string>')
    assert out['invocation']['module_args']['key_name'] == '%(key_name)s'
    assert out['invocation']['module_args']['name'] == '%(name)s'

# Generated at 2022-06-25 04:26:04.402619
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert(from_yaml('a:3', 'a:3') == {'a': 3})
    except Exception as e:
        print(e)
        e_type, e_obj, e_tb = sys.exc_info()
        traceback.print_tb(e_tb)
    try:
        assert(from_yaml('{"a": 3}', '{"a": 3}') == {'a': 3})
    except Exception as e:
        print(e)
        e_type, e_obj, e_tb = sys.exc_info()
        traceback.print_tb(e_tb)

# Generated at 2022-06-25 04:26:06.205374
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Test main
if __name__ == "__main__":

    test_from_yaml()

# Generated at 2022-06-25 04:26:13.801696
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "GSuz'_S=G$-[\x0e(\x1f"
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == "GSuz'_S=G$-[\x0e(\x1f", "Expected (''GSuz'_S=G$-[\\x0e(\\x1f'', 'GSuz'_S=G$-[\x0e(\x1f')"

if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

    print("All Tests Pass!")

# Generated at 2022-06-25 04:26:25.798104
# Unit test for function from_yaml

# Generated at 2022-06-25 04:26:33.544699
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'{}') == {}
    assert from_yaml(b'{"null": null}') == {"null": None}
    assert from_yaml(b'{"boolean": true}') == {"boolean": True}
    assert from_yaml(b'{"boolean": false}') == {"boolean": False}
    assert from_yaml(b'{"integer": 42}') == {"integer": 42}
    assert from_yaml(b'{"array": [1, 2, 3]}') == {"array": [1, 2, 3]}
    assert from_yaml(b'{"string": "abc"}') == {"string": "abc"}
    assert from_yaml(b'{"object": {"a": "b"}}') == {"object": {"a": "b"}}

# Generated at 2022-06-25 04:26:38.615933
# Unit test for function from_yaml
def test_from_yaml():

    # test_case_0
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:26:46.536506
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import crypt
    except ImportError:
        crypt = None

    str_0 = 'hE#\x0e(j\x7f\x12\x15i\x17{\x0e\x13\x0f:c\x1a\x00{'

# Generated at 2022-06-25 04:26:56.207874
# Unit test for function from_yaml
def test_from_yaml():
    # Scenario 0: Test with a string
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)
    print(var_0)

    # Scenario 1: Test with a number
    int_0 = -1
    var_1 = from_yaml(int_0, int_0)
    print(var_1)

    # Scenario 2: Test with a dict
    dict_0 = {'a': 'b', 'c': 'd'}
    var_2 = from_yaml(dict_0, dict_0)
    print(var_2)

    # Scenario 3: Test with a list
    list_0 = ['a', 'b', 'c']
    var_3 = from_y

# Generated at 2022-06-25 04:26:58.228951
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('!c8h1zNxFH') == None



# Generated at 2022-06-25 04:27:09.650777
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from yaml import CSafeLoader as SafeLoader
    except ImportError:
        from yaml import SafeLoader

    str_0 = '|-\n  \n'
    str_1 = '  \n'
    str_2 = 'hostname ansible-test\n'
    str_3 = 'alias ansible-another-test'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}

    # tests with yaml.safe_load and yaml.full_load
    dict_1 = yaml.safe_load(str_0)
    dict_2 = yaml.full_load(str_1)
    dict_3 = yaml.safe_load(str_2)

    # Tests with AnsibleJSONDecoder and AnsibleLoader
   

# Generated at 2022-06-25 04:27:29.840875
# Unit test for function from_yaml
def test_from_yaml():

    output = from_yaml('{ "foo": "bar" }')
    assert output == {"foo": "bar"}

    import sys

    # make sure yaml loading errors are handled
    if sys.version_info >= (3, 0):
        # python3 doesn't have an exec/compile call so these tests don't make sense
        return

    py_ver = '%s.%s' % (sys.version_info[0], sys.version_info[1])
    exec('def bad_yaml_handler(): raise YAMLError')


# Generated at 2022-06-25 04:27:40.350262
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import tempfile
    import shutil
    import lzma

    src = os.path.join(os.path.dirname(__file__), 'foo.yml')
    dst = os.path.join(tempfile.mkdtemp(), 'foo.yml')
    shutil.copy(src, dst)



    with lzma.open(dst, mode='rt', encoding='utf-8') as f:
        for line in f:
            if line.startswith('test: '):
                new_line = line.replace('test', 'test_new')
                break
    with open(dst, mode='w') as f:
        f.write(new_line)

    assert from_yaml(new_line) == {'test_new': 'foo'}
    assert from_

# Generated at 2022-06-25 04:27:44.589353
# Unit test for function from_yaml
def test_from_yaml():
    # Prepare for test
    data, file_name, show_content, json_only = None, None, None, None

    # Execute the function
    test_case_0()

# Generated at 2022-06-25 04:27:53.759547
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:03.653568
# Unit test for function from_yaml
def test_from_yaml():
    # Let's test when everything is OK
    str_0 = '- 0'
    var_0 = from_yaml(str_0, str_0, False)
    assert var_0 == [0]

    # Let's test when JSON raises error

# Generated at 2022-06-25 04:28:13.308825
# Unit test for function from_yaml
def test_from_yaml():
    try:
        str_0 = ''
        var_0 = from_yaml(str_0, str_0)
    except AnsibleParserError as exception:
        assert exception is not None

    try:
        str_0 = '\x0f\x0f^GZ\x16+\x06F\x1e9FK'
        var_0 = from_yaml(str_0, str_0, False)
    except AnsibleParserError as exception:
        assert exception is not None


# Generated at 2022-06-25 04:28:20.230420
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {
            'key3-0': 'value3',
            'key3-1': ['value3-1', 'value3-2']
        }
    }
    var_0 = from_yaml(json.dumps(str_0))

    assert var_0 == str_0


# Generated at 2022-06-25 04:28:28.259791
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'n'
    var_0 = from_yaml(str_0, str_0)

    str_1 = 'w'
    var_1 = from_yaml(str_1, str_1)

    str_2 = 'B'
    var_2 = from_yaml(str_2, str_2)

    str_3 = 'z'
    var_3 = from_yaml(str_3, str_3)

    str_4 = 'l'
    var_4 = from_yaml(str_4, str_4)

    str_5 = 'c'
    var_5 = from_yaml(str_5, str_5)

    str_6 = '|I(($'
    var_6 = from_yaml(str_6, str_6)



# Generated at 2022-06-25 04:28:37.933247
# Unit test for function from_yaml
def test_from_yaml():

    # Input parameters tests
    try:
        from_yaml()
    except SystemExit as e1:
        assert e1.code == 2

    # Example: '''A sample data structure.'''

    str_0 = '''hello: world'''
    var_0 = from_yaml(str_0, str_0)
    ans_0 = {'hello': 'world'}
    assert var_0 == ans_0

    # Example: '''A sample data structure with a multiline value.'''

    str_0 = '''hello: |\n  This is a multiline\n  value.\n'''
    var_0 = from_yaml(str_0, str_0)
    ans_0 = {'hello': 'This is a multiline\nvalue.'}

# Generated at 2022-06-25 04:28:48.373134
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'B4Y4v-9e@H8N{j\x1c+cf\x1a\x0c"*\tHP\x10\x1b\x1a'
    str_1 = '\x0b\x06\x1d\n\x1d&'
    str_2 = '\x0e\x00\x13\t\x14'
    str_3 = '\x1c\x0e\x07\r\r'
    str_4 = '\x1f\x0c\x0e\x1b\x1d'
    str_5 = '\x1a\x09\x0e\x0f\x06'
    str_6 = '\n\x1a\x15'
    str_7

# Generated at 2022-06-25 04:29:12.747575
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None

    # Test #0
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == '%Mnn!Bwl\x0czO|I(($'

    # Test #1: JSON format, list
    str_1 = '[{"key_2": true}]'
    var_1 = from_yaml(str_1, str_1)
    assert var_1 == [{u'key_2': True}]

    # Test #2: JSON format, object
    str_2 = '{"key_1": "value_2"}'

# Generated at 2022-06-25 04:29:24.272693
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('node1.yml')
    from_yaml('0\n1\n2\n3\n4\n5\n6\n7\n')
    from_yaml('0\n1\n2\n3\n4\n5\n6\n7\n')
    from_yaml('ssh_host')
    from_yaml('0\n1\n2\n3\n4\n5\n6\n7\n')
    from_yaml('ssh_host')
    from_yaml('ssh_host')
    from_yaml('0\n1\n2\n3\n4\n5\n6\n7\n')
    from_yaml('ssh_host')
    from_yaml('"', '"')

# Generated at 2022-06-25 04:29:29.113979
# Unit test for function from_yaml
def test_from_yaml():
    # YAML file path
    yaml_file = 'vault.yaml'
    # Performs the verification test
    assert from_yaml(yaml_file) == json.load(open(yaml_file))

test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:29:32.781359
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'test_str'
    yaml_0 = from_yaml(str_0, str_0)

# Test steps:
# 1. run "pytest -v test_case.py"
# 2. see if the test_result.afl is written.

# Generated at 2022-06-25 04:29:43.146099
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{"name": "my_svc", "state": "started"}'
    var_0 = from_yaml(str_0, str_0)
    assert json.loads(str_0) == var_0['name']
    str_1 = '%Mnn!Bwl\x0czO|I(($'
    with pytest.raises(AnsibleParserError):
        var_1 = from_yaml(str_1, str_1)

# Generated at 2022-06-25 04:29:53.054701
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '["Saga","Sari","Sava"]'
    var_0 = from_yaml(str_0, str_0)

    str_1 = '{"Mihai":{"age":23.5,"name":"Mihai"},"Saga":{"age":20.0,"name":"Saga"},"Sari":{"age":19.0,"name":"Sari"},"Sava":{"age":22.0,"name":"Sava"}}'
    var_1 = from_yaml(str_1, str_1)


# Generated at 2022-06-25 04:29:53.768482
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() == None



# Generated at 2022-06-25 04:29:59.703119
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '---\nvalue: 8'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == {u'value': 8}

    str_0 = '--- Bob'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == 'Bob'

    str_0 = '  - 1\n  - 2 '
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == [1, 2]

    str_0 = ''
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == None

    str_0 = 'foo: bar'
    var_0 = from_yaml(str_0, str_0)

# Generated at 2022-06-25 04:30:01.875352
# Unit test for function from_yaml
def test_from_yaml():
    (str_1, str_2, str_3) = ('', '', '')
    var_1 = from_yaml(str_1, str_2, True, str_3)

test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:30:05.236391
# Unit test for function from_yaml
def test_from_yaml():
    import collections
    assert collections.namedtuple('sentinel', 's')(s='sentinel') == from_yaml('s: sentinel')

# Generated at 2022-06-25 04:30:30.628605
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '@\x07\x04\x00\x00\x00\x00\x00\x00(\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 is not None

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:30:32.508250
# Unit test for function from_yaml
def test_from_yaml():
    assert(test_case_0() == True)

# class AnsibleJSONDecoder

# Generated at 2022-06-25 04:30:42.702064
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '\x19\xfb\xdd\x11\xeb\x0c\xd4\x8c\xce0\xd4\xc0'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == '\x19\xfb\xdd\x11\xeb\x0c\xd4\x8c\xce0\xd4\xc0'
    var_0 = from_yaml('\x19\xfb\xdd\x11\xeb\x0c\xd4\x8c\xce0\xd4\xc0', str_0)

# Generated at 2022-06-25 04:30:44.153835
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml(None)
    except Exception:
        assert False, 'Exception raised'

# Generated at 2022-06-25 04:30:45.535189
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)
    assert var_0 == None

# Generated at 2022-06-25 04:30:55.456555
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)
    str_1 = '%Mnn!Bwl\x0czO|I(($'
    var_1 = from_yaml(str_1, str_1)
    str_2 = '%Mnn!Bwl\x0czO|I(($'
    var_2 = from_yaml(str_2, str_2)
    str_3 = '%Mnn!Bwl\x0czO|I(($'
    var_3 = from_yaml(str_3, str_3)
    str_4 = '%Mnn!Bwl\x0czO|I(($'
    var_4 = from_y

# Generated at 2022-06-25 04:31:05.250784
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("foo") == "foo"
    assert from_yaml("42") == 42
    assert from_yaml("true") == True
    assert from_yaml("false") == False
    assert from_yaml("null") == None
    assert from_yaml("42.03") == 42.03
    assert from_yaml("-42.03") == -42.03
    assert from_yaml("foo: bar") == { "foo": "bar" }
    assert from_yaml("42: [1, 2, 3]") == { "42": [1, 2, 3] }
    assert from_yaml("[1, 2, 3]") == [1, 2, 3]
    assert from_yaml("{ foo: bar }") == { "foo": "bar" }
    assert from_

# Generated at 2022-06-25 04:31:09.975134
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)



# Generated at 2022-06-25 04:31:18.863760
# Unit test for function from_yaml
def test_from_yaml():
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
    var_14 = str_0
   

# Generated at 2022-06-25 04:31:20.726215
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%Mnn!Bwl\x0czO|I(($'
    var_0 = from_yaml(str_0, str_0)
    assert (var_0 == '%Mnn!Bwl\x0czO|I(($')
