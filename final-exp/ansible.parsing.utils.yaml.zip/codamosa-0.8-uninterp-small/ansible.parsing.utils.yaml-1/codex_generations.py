

# Generated at 2022-06-25 04:21:44.727796
# Unit test for function from_yaml
def test_from_yaml():
  # TODO: Test for function from_yaml
    raise NotImplementedError


# Generated at 2022-06-25 04:21:46.346727
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(None)
    from_yaml(set())

# Generated at 2022-06-25 04:21:47.443284
# Unit test for function from_yaml
def test_from_yaml():
    print(test_case_0())


test_from_yaml()

# Generated at 2022-06-25 04:21:50.182503
# Unit test for function from_yaml
def test_from_yaml():

    set_0 = set()
    var_0 = from_yaml(set_0)

# Generated at 2022-06-25 04:21:53.286379
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except TypeError as e:
        print(e)
        print("In test_from_yaml, exception occurred")

# Main function to test code

# Generated at 2022-06-25 04:21:59.355696
# Unit test for function from_yaml
def test_from_yaml():
    data = '''{
        "test_cases": [
            "test_case_0",
            "test_case_1"
        ]
    }'''
    var_0 = from_yaml(data)

    assert var_0 == {'test_cases': ['test_case_0', 'test_case_1']}

# Generated at 2022-06-25 04:22:00.361083
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:22:01.886995
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True



# Generated at 2022-06-25 04:22:09.579359
# Unit test for function from_yaml
def test_from_yaml():
    try:
        set_0 = set()
        var_0 = from_yaml(set_0)
        assert var_0 == set_0
    except Exception as e:
        print('Yaml value error: %s' % e)
    try:
        dict_0 = dict()
        var_0 = from_yaml(dict_0)
        assert var_0 == dict_0
    except Exception as e:
        print('Yaml value error: %s' % e)
    try:
        list_0 = list()
        var_0 = from_yaml(list_0)
        assert var_0 == list_0
    except Exception as e:
        print('Yaml value error: %s' % e)

# Generated at 2022-06-25 04:22:13.873100
# Unit test for function from_yaml
def test_from_yaml():
    #assert not callable(from_yaml)
    # FIXME: The assert above is correct but produces sporadic errors.  This is
    # due to a dynamic nature of the function.
    assert True

# Generated at 2022-06-25 04:22:19.030029
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True # changed for test_case_0



# Generated at 2022-06-25 04:22:25.896629
# Unit test for function from_yaml
def test_from_yaml():
    # Case 1: Arbitrary bytes
    bytes_1 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_1 = from_yaml(bytes_1)
    assert var_1 == "3\xb9\xe0\xb6\x8b"

    # Case 2: Arbitrary bytes /w unquoted string
    bytes_2 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0"test"'
    var_2 = from_yaml(bytes_2)
    assert var_2 == "3\xb9\xe0\xb6\x8b"
    var_3 = from_

# Generated at 2022-06-25 04:22:35.224568
# Unit test for function from_yaml
def test_from_yaml():
    # Test 1: Simple case
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    assert var_0 == 257
    # Test 2: Exception case
    str_0 = "Oops"
    try:
        var_0 = from_yaml(str_0)
    except AnsibleParserError:
        assert True
    else:
        assert False
    # Test 3: Exception case
    str_0 = "Oops"
    try:
        var_0 = from_yaml(str_0)
    except AnsibleParserError:
        assert True
    else:
        assert False
    # Test 4: Exception case
   

# Generated at 2022-06-25 04:22:39.214323
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError) as error:
        test_case_0()
    assert str(error.value) == "We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: Expecting value: line 1 column 1 (char 0)\n\n"

# Generated at 2022-06-25 04:22:42.759030
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:22:52.993885
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    assert var_0 == '19', 'Failed asserting that var_0 == 19.'
    bytes_1 = b'[\xb4\x8e\x17L86\xf4l\x8d\x1eS\x85\t\xa7'
    var_1 = from_yaml(bytes_1)
    assert var_1 == '19', 'Failed asserting that var_1 == 19.'

if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:22:59.461636
# Unit test for function from_yaml
def test_from_yaml():
    # From /ansible/lib/ansible/parsing/__init__.py
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)

# Generated at 2022-06-25 04:23:03.326235
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 04:23:09.976275
# Unit test for function from_yaml
def test_from_yaml():
    # Check if function created correctly
    assert callable(from_yaml)
    # Check if function is returning the correct result
    assert from_yaml(b'\x9d\x9e>\x9f\x11\xcc\x89\xeb\xc1\x0b\x9d\x9b') == [1, 2, 3, 4]

# Generated at 2022-06-25 04:23:11.907842
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('abc') is not None


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:23:19.077371
# Unit test for function from_yaml
def test_from_yaml():
    json_str = '{"json_str": true}'
    yaml_str = '{"yaml_str": true}'
    # assert from_yaml(json_str) == yaml.load(json_str)
    # assert from_yaml(yaml_str) == yaml.load(yaml_str)
    # assert from_yaml(json_str, json_only=True) == json.loads(json_str)
    # assert from_yaml(yaml_str, json_only=True) == json.loads(yaml_str)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:23:24.562000
# Unit test for function from_yaml
def test_from_yaml():
  assert False
  #assert from_yaml(b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0') == b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'

# Generated at 2022-06-25 04:23:35.070864
# Unit test for function from_yaml
def test_from_yaml():

    # yaml.safe_load() uses yaml.Loader class which we can't access here
    # so we load data with AnsibleLoader class and ensure that the data is loaded
    # exactly the same way as with function 'safe_load'.
    test_data = [
        'abc: def # comment',
        'abc: null',
        'abc: 12345',
        'abc: 3.1415',
        'abc: true',
        'abc: false',
        'abc: >-\n     multiline string that is\n     indented but has no leading\n     spaces\n     ',
        '# comment',
        '',
    ]
    for i, data_str in enumerate(test_data):
        data = _safe_load(data_str)
        assert data == {'abc': 'def'}


# Generated at 2022-06-25 04:23:36.847274
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() == None


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:41.428583
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)

test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:23:49.560931
# Unit test for function from_yaml
def test_from_yaml():
    # Source bytes (e.g. b'foo') will be "parsed" as a string, and
    # strings are iterables of characters, so with a list comprehension
    # we can convert every character to its native int equivalent.
    # We can't use int() with base 2 because it requires a proper
    # string for a prefix ('0b', in this case).
    #
    # In python 2, we cast the bytes to str so that the comprehension
    # works.
    if isinstance(b'\x02', str):
        ints_0 = [ord(x) for x in '\x02\x7f']
    else:
        ints_0 = [x for x in b'\x02\x7f']

    # A list of the values that will be used for the test:
    #   1. an empty

# Generated at 2022-06-25 04:24:02.930012
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xf4\xd4'
    assert from_yaml(bytes_0) == (1069)

    bytes_0 = b'\x0ebp\xaa\xf8\xc4\x0b\xbe\xd8\xac\x9b<\xb5\x94'
    assert from_yaml(bytes_0) == (16)

    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    assert from_yaml(bytes_0) == (0)


# Generated at 2022-06-25 04:24:08.879176
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    check_list_0 = [var_0]
    # validation
    assert check_list_0[0] == '{serial}'

# Generated at 2022-06-25 04:24:10.932790
# Unit test for function from_yaml

# Generated at 2022-06-25 04:24:13.677298
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    assert(from_yaml(bytes_0)) == None

# Generated at 2022-06-25 04:24:26.788669
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    bytes_1 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    dict_0 = dict()
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict

# Generated at 2022-06-25 04:24:32.722440
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import yaml
        if yaml.__with_libyaml__:
            from tests.unit.parsing.yaml.base import YAMLTests
        else:
            from tests.unit.parsing.yaml.base import PyYAMLTests
    except ImportError:
        import warnings
        warnings.warn("no libyaml-dev available, skipping unit test for from_yaml")
        return

    YAMLTests.test__from_yaml(from_yaml=from_yaml)
    PyYAMLTests.test__from_yaml()

# Generated at 2022-06-25 04:24:38.977824
# Unit test for function from_yaml
def test_from_yaml():
    try:
        with open('test-cases/test_from_yaml.yml') as f:
            for line in f:
                try:
                    if '#' == line.strip()[0]:
                        continue
                except IndexError:
                    continue
                func_name = line.strip()
                print(func_name)
                globals()[func_name]()
    except IOError as e:
        print(e)
    print("Unit test for function from_yaml finished!")

# Main function

# Generated at 2022-06-25 04:24:42.786918
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True # TODO: implement your test here

# Run mocks
if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:24:50.994605
# Unit test for function from_yaml
def test_from_yaml():

    # Test a string
    assert from_yaml('---') is None

    # Test a YAML object
    assert from_yaml({'test': 'test'}) == {'test': 'test'}

    # Test a JSON object
    assert from_yaml('{"test": "test"}') == {'test': 'test'}

    # Test wrong syntax
    try:
        from_yaml('[oops')
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-25 04:24:53.004903
# Unit test for function from_yaml
def test_from_yaml():
    var_1 = b'value'
    var_2 = b'value'

    result = from_yaml(var_1, var_2)
    assert result is None

# Generated at 2022-06-25 04:25:01.386606
# Unit test for function from_yaml
def test_from_yaml():
    # Test 1
    bytes_0 = b'\n#random file\n\n# this should pass\na_string: This is a string!\n\n# this should pass as well\nan_int: 42\n\n# this should fail\nnot_an_int: not a number!\n'
    var_0 = from_yaml(bytes_0)
    assert var_0 == {u'a_string': u'This is a string!', u'an_int': 42}

    # Test 2
    bytes_0 = b'%YAML 1.2\n---\n!!str &id001 "foo"\n'
    var_0 = from_yaml(bytes_0)
    assert var_0 == u'foo'

    # Test 3

# Generated at 2022-06-25 04:25:13.032891
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '1'
    assert from_yaml(yaml_str) == 1

    yaml_str = '1.1'
    assert from_yaml(yaml_str) == 1.1

    yaml_str = '1.1.1'
    assert from_yaml(yaml_str) == '1.1.1'

    yaml_str = '-1'
    assert from_yaml(yaml_str) == -1

    yaml_str = '- 1'
    assert from_yaml(yaml_str) == -1

    yaml_str = 'True'
    assert from_yaml(yaml_str) is True

    yaml_str = 'true'
    assert from_yaml(yaml_str)


# Generated at 2022-06-25 04:25:13.955618
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None

# Generated at 2022-06-25 04:25:18.102937
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)

    # test code
    assert var_0 == '\u03b9\u0376\u03a6'

# Generated at 2022-06-25 04:25:28.206423
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 04:25:32.032247
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)

    assert var_0 == 's3cr3t'



# Generated at 2022-06-25 04:25:35.713984
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:25:40.567888
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    res_0 = from_yaml(bytes_0)

# Generated at 2022-06-25 04:25:51.530298
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = "bar"
    var_1 = '{"name": "foo", "foo": [1, 2, 3]}'
    var_2 = "foo"
    var_3 = ['{"name": "foo", "foo": [1, 2, 3]}', 'dummy']
    var_4 = 'dummy'
    var_5 = 'foo'
    var_7 = 'dummy'
    var_8 = "foo"
    var_9 = '{"foo": [1,2, 3]}'
    var_10 = "foo"
    var_11 = 'invalid'
    var_12 = 'invalid'
    var_13 = 'dummy'
    var_14 = "foo"
    var_15 = 'invalid'
    var_16 = 'invalid'

# Generated at 2022-06-25 04:26:04.365928
# Unit test for function from_yaml
def test_from_yaml():
    # Test the function with a datastructure
    ds = { "a": 1, "b": 2 }
    assert from_yaml(ds) is ds

    # Test the function with json input
    json_data = '{"a":1, "b":2}'
    assert from_yaml(json_data) == {"a": 1, "b": 2}

    # Test the function with yaml input
    yaml_data = 'a: 1\nb: 2'
    assert from_yaml(yaml_data) == {"a": 1, "b": 2}

    # Test the function with a non-decodable string

# Generated at 2022-06-25 04:26:14.541525
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)

    # Testing with a str value
    bytes_1 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_1 = from_yaml(bytes_1)

    # Testing with a bytes value
    str_2 = 'ansible_collections/not/a/real/path'
    var_2 = from_yaml(str_2)

    # Testing with a str value

# Generated at 2022-06-25 04:26:17.775233
# Unit test for function from_yaml
def test_from_yaml():
    assert 'from_yaml' in globals()
    from_yaml('foobar')


# Generated at 2022-06-25 04:26:26.209544
# Unit test for function from_yaml
def test_from_yaml():
    try:
        data = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
        file_name = '<string>'
        show_content = True
        vault_secrets = None
        json_only = False
        actual_return = from_yaml(data, file_name, show_content, vault_secrets, json_only)
        print(actual_return)
    except Exception as e:
        print(str(e))
    #assert actual_return == expected_return


# Generated at 2022-06-25 04:26:32.493768
# Unit test for function from_yaml
def test_from_yaml():
    class Mixin0(object):
        def method(self, var_1):
            var_2 = from_yaml(var_1)
            return var_2
    var_5 = Mixin0()

    # Test with YAML.
    data = """---
    - hosts: localhost
      vars:
        var_3: myvalue
      tasks:
        - include_vars:
            file: '{{ var_3 }}'
    """
    assert var_5.method(data) == [{u'vars': {u'var_3': u'myvalue'}, u'hosts': u'localhost', u'tasks': [{u'include_vars': {u'file': u'{{ var_3 }}'}}]}]

    # Test with JSON.

# Generated at 2022-06-25 04:26:43.341177
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == "__main__":
    print("Testing yaml")
    test_from_yaml()

# Generated at 2022-06-25 04:26:54.542922
# Unit test for function from_yaml
def test_from_yaml():
    reload(json)
    import yaml
    reload(yaml)
    from yaml import CLoader, CDumper
    from yaml import Loader, Dumper

    # basic types
    my_dict = dict(a=1, b=2, c=3)
    my_list = [1, 2, 3]
    my_string = u'string'
    my_int = 1
    my_float = 1.5
    my_none = None
    my_true = True
    my_false = False
    my_bytes = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'

    assert from_yaml(json.dumps(my_dict)) == my_dict
    assert from_yaml

# Generated at 2022-06-25 04:27:06.038925
# Unit test for function from_yaml

# Generated at 2022-06-25 04:27:11.268388
# Unit test for function from_yaml
def test_from_yaml():
    # bytes to test from yaml
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    # calling function from_yaml
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:27:13.941435
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except AnsibleParserError:
        pass
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:27:23.510031
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    string_0 = 'i\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0\x8bz\x05\x1f\xaa\xe4\x87d\xbbY/\x8aU\r\xa6'
    string_1 = '\x04\x10\x7f\\\xd1\x8c@\xa2\x87\x92\xdd\xcc\xa5\x85g\x92\x0e\xebO\x03\xbb'
    bytes_1 = b

# Generated at 2022-06-25 04:27:35.511230
# Unit test for function from_yaml
def test_from_yaml():
    # Test with simple string literal
    bytes_0 = b"root_dir: /"
    var_0 = from_yaml(bytes_0)
    assert(var_0['root_dir'] == '/')

    # Test with quoted string literal
    bytes_1 = b"'root_dir': '/'"
    var_1 = from_yaml(bytes_1)
    assert(var_1['root_dir'] == '/')

    # Test with multiline string
    bytes_2 = b"root_dir: |\n  /\n  /var/lib/jenkins\n  /opt/my_app\n"
    var_2 = from_yaml(bytes_2)
    assert(var_2['root_dir'] == '/\n/var/lib/jenkins\n/opt/my_app')



# Generated at 2022-06-25 04:27:36.460831
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:27:40.866425
# Unit test for function from_yaml
def test_from_yaml():
    data = b'hello world'
    file = 'ansible.cfg'
    show_content = True
    vault_secrets = {}
    json_only = True

    json_0 = json.loads(data)

    result = from_yaml(data, file, show_content, vault_secrets, json_only)
    assert json_0 == result

# Generated at 2022-06-25 04:27:45.635893
# Unit test for function from_yaml
def test_from_yaml():

    # Try to call function 'from_yaml'
    test_case_0()



# Generated at 2022-06-25 04:27:57.859123
# Unit test for function from_yaml
def test_from_yaml():
    x = from_yaml(b"[1, 2]")
    assert x == [1, 2]

# Generated at 2022-06-25 04:28:05.941468
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:15.876821
# Unit test for function from_yaml
def test_from_yaml():
    # Correct usage
    assert from_yaml(b'{}') is not None
    assert from_yaml(b'{}', show_content=False) is not None
    assert from_yaml(b'{}', vault_secrets=()) is not None

    # Bad argument types
    try:
        from_yaml(0)
    except TypeError:
        pass
    except Exception as exc:
        assert False, "Expected TypeError, got %r" % exc

    try:
        from_yaml(b'{}', file_name=0)
    except TypeError:
        pass
    except Exception as exc:
        assert False, "Expected TypeError, got %r" % exc


# Generated at 2022-06-25 04:28:18.349916
# Unit test for function from_yaml
def test_from_yaml():
    assert True
# END Unit test for function from_yaml

# Generated at 2022-06-25 04:28:25.142699
# Unit test for function from_yaml
def test_from_yaml():

    # Test parameters
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    str_0 = '\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'

    # Execution
    var_0 = from_yaml(str_0)

    # Verification
    assert var_0 is not None

    # Cleanup - none necessary


if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:28:31.841772
# Unit test for function from_yaml
def test_from_yaml():
    # Ensure the correct number of arguments have been specified
    try:
        from_yaml()
        assert False
    except TypeError:
        assert True

    # Ensure the correct number of arguments have been specified
    try:
        from_yaml(None)
        assert False
    except TypeError:
        assert True

    # Ensure the correct number of arguments have been specified
    try:
        from_yaml(None, None)
        assert False
    except TypeError:
        assert True

    # Ensure the correct number of arguments have been specified
    try:
        from_yaml(None, None, None)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-25 04:28:35.594668
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)


# Generated at 2022-06-25 04:28:38.282110
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


# Bootstrap this module by performing the tests
if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    test_from_yaml()

# Generated at 2022-06-25 04:28:48.398587
# Unit test for function from_yaml
def test_from_yaml():
    # noinspection PyUnresolvedReferences
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    bytes_1 = b'{"foo": "bar"}'
    bytes_2 = b'{"foo_0": "bar_1"}'
    bytes_3 = b'{foo: bar}'
    bytes_4 = b'"foo"'
    bytes_5 = b'[1, 2, 3, 4, 5]'
    bytes_6 = b'{foo: "bar"}'
    bytes_7 = b'!@=#?^%_&'

    # test cases for from_yaml


# Generated at 2022-06-25 04:28:52.688742
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    # assert var_0 == 



# Generated at 2022-06-25 04:29:06.012730
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert isinstance(bytes_0, str) and len(bytes_0) == 15
        test_case_0()
    except:
        assert False

# vim: AnsibleLineEditor=emacs
# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4 :

# Generated at 2022-06-25 04:29:12.346781
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    str_0 = '\u0706\U00017b12\u04a9\u2360\U0001bb7c'
    int_0 = -2147483648

# Generated at 2022-06-25 04:29:19.253485
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    assert from_yaml(bytes_0) == (4079, 2496, 1568, 4380, 8556, 3230, 3647, 60, 242, 95, 97, 192, 240)

# rbac.authorization.k8s.io/v1beta1/events.yaml

# Generated at 2022-06-25 04:29:22.663878
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    if (isinstance(var_0, type(None))):
        raise Exception('test failed')



# Generated at 2022-06-25 04:29:34.813575
# Unit test for function from_yaml
def test_from_yaml():
    text_0 = '\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'

    # Test with arguments:
    #     data='\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    #     file_name='<string>'
    #     show_content=True
    #     vault_secrets=None
    #     json_only=False
    from_yaml(text_0)

if __name__ == '__main__':
    import argparse
    # Test case 0:
    test_case_0()

    # Test function:
    #     from_yaml
    test_from_yaml()

# Generated at 2022-06-25 04:29:45.300250
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    bytes_1 = b'\xa4\x82\x8b\xbb\xb4\x9a\x0c\xe5#\xa5\x91\xa5\x8c\xc6\xb5\x05\xde'

# Generated at 2022-06-25 04:29:47.420796
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as e:
        assert False, "Unable to run test case, error: " + str(e)

# Generated at 2022-06-25 04:29:53.680849
# Unit test for function from_yaml
def test_from_yaml():

    class TestException(Exception):
        pass

    class TestClass:
        __str__ = None

    try:
        test_case_0()
    except:
        raise TestException

    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)

    try:
        bytes_1 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
        var_1 = from_yaml(bytes_1)
    except:
        raise TestException


# Generated at 2022-06-25 04:29:58.866336
# Unit test for function from_yaml
def test_from_yaml():
    byte_0 = b'test string'
    byte_1 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    byte_2 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf1'
    byte_list = [byte_0, byte_1, byte_2]
    for byte in byte_list:
        try:
            from_yaml(byte)
        except:
            pass

test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:30:09.923430
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)

    bytes_1 = b'{"a": 1, "b": 2}'
    var_1 = from_yaml(bytes_1)

    bytes_2 = b'\x02\xb1\xbb\xcc\xe2\x9a\x8eU\xd6\x12\xef\x19\x8d\x87\xf7\x1a\x8b\x08\xb0'
    var_2 = from_yaml(bytes_2)

    bytes_3 = b'"1"'

# Generated at 2022-06-25 04:30:32.924591
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    assert var_0 is None

# Generated at 2022-06-25 04:30:34.851375
# Unit test for function from_yaml
def test_from_yaml():
    # Test for from_yaml
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:30:44.547916
# Unit test for function from_yaml

# Generated at 2022-06-25 04:30:50.324118
# Unit test for function from_yaml
def test_from_yaml():
    string_0 = '\x01\xfe\x84\xc0+\xcb\xdc\xeb\x1b\xfe\\\xe2?\\\x8f<\xde\xa2?\xd2'
    var_0 = from_yaml(string_0)
    assert var_0 == string_0
    var_1 = from_yaml(string_0)
    assert var_1 == string_0
    assert var_1 == var_0
    var_2 = from_yaml(string_0)
    assert var_2 == string_0
    assert var_2 == var_0
    assert var_2 == var_1
    var_3 = from_yaml(string_0)
    assert var_3 == string_0
    assert var_3 == var_0
   

# Generated at 2022-06-25 04:30:55.718776
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    assert var_0 == 75167
    return None

if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:31:05.250505
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'{}') == {}
    assert from_yaml('{}') == {}
    assert from_yaml(b'{"test":42}') == {"test": 42}
    assert from_yaml('{"test":42}') == {"test": 42}
    assert from_yaml(1) == 1
    assert from_yaml(b'1') == 1
    assert from_yaml(b'null') is None
    assert from_yaml(b'false') is False
    assert from_yaml(b'true') is True
    assert from_yaml('false') is False
    assert from_yaml('true') is True

    var_0 = from_yaml(b'''key: value

another key: another value
''')

# Generated at 2022-06-25 04:31:13.166440
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)
    assert var_0 is not None

test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:31:15.149588
# Unit test for function from_yaml
def test_from_yaml():
    print(test_case_0())

# vim: set et sts=4 sw=4 ts=4 ft=python:

# Generated at 2022-06-25 04:31:17.005258
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()
    print('all tests passed!')


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:31:20.455280
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x03\xb9\xe0\xb6\x8bc\x7f&\x97<\xf2_a\xc0\xf0'
    var_0 = from_yaml(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()