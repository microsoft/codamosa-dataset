

# Generated at 2022-06-25 04:21:52.300349
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '''%s: %s\n'''
    str_1 = """---

- name: "%s"
  hosts: localhost
  user: %s
  sudo: no
  become: yes
  become_method: sudo

- hosts: "%s"
  user: %s
  sudo: no
  become: yes
  become_method: sudo
  become_user: root

  """
    str_2 = '{host}'
    str_3 = 'ansible'
    str_4 = 'all'
    str_5 = 'ansible'
    str_6 = '''%s\n'''
    str_7 = '''%s\n'''
    str_8 = '''%s\n'''
    str_9 = '''%s\n'''

# Generated at 2022-06-25 04:22:00.369359
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    assert var_0 == '[WARNING]: %s'
    str_1 = '---\n- \'abc\''
    var_1 = from_yaml(str_1)
    assert var_1 == ['abc']
    str_2 = '---\n- abc\n- def'
    var_2 = from_yaml(str_2)
    assert var_2 == ['abc', 'def']


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:22:10.422919
# Unit test for function from_yaml
def test_from_yaml():

    # Test the function with a YAML string
    str_0 = '''\
---
- hosts: all
  gather_facts: False
  serial: 1
  pre_tasks:
    - name: gather info
      debug:
        msg: "hello"
  tasks:
    - name: do something
      debug:
        msg: "world"
  handlers:
    - name: fail
      debug:
        msg: "fail"
'''
    var_0 = from_yaml(str_0)
    # Verify the result
    assert isinstance(var_0, list)

    # Test the function with a JSON string

# Generated at 2022-06-25 04:22:13.956119
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    ansible_0 = from_yaml(str_0)

    assert ansible_0 == ['WARNING:', '%s']


# Generated at 2022-06-25 04:22:15.748551
# Unit test for function from_yaml
def test_from_yaml():
    inp = "[WARNING]: %s"
    out = from_yaml(inp)
    assert out == "[WARNING]: %s"

# Generated at 2022-06-25 04:22:19.126517
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    test_case_0()

# Generated at 2022-06-25 04:22:23.335746
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    str_0 = '[WARNING]: %s'
    try:
        var_0 = from_yaml(str_0)
    except YAMLError as yaml_exc:
        assert yaml_exc is not None

# Main program
if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:22:32.766930
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{ "key": "value" }'
    var_0 = from_yaml(str_0)
    assert var_0 == { "key": "value" }
    str_1 = '- This is a YAML string.'
    var_1 = from_yaml(str_1)
    assert var_1 == '- This is a YAML string.'
    str_2 = '"{"key": "value"}"'
    var_2 = from_yaml(str_2)
    assert var_2 == '{"key": "value"}'

    # Unit test for function _handle_error
    test_case_0()

# Generated at 2022-06-25 04:22:35.624427
# Unit test for function from_yaml
def test_from_yaml():

    # From docstring
    result = from_yaml("""
    - name: a list of dictionaries
      hosts: localhost
      gather_facts: false
      tasks:
      - name: a task
        shell: echo "hello world"
        register: output
    """)
    assert result == [{'tasks': [{'register': 'output', 'shell': 'echo "hello world"', 'name': 'a task'}], 'hosts': 'localhost', 'name': 'a list of dictionaries', 'gather_facts': False}]



# Generated at 2022-06-25 04:22:46.554031
# Unit test for function from_yaml
def test_from_yaml():
    print('Test from_yaml')
    str_0 = "[WARNING]: %s"
    var_0 = from_yaml(str_0)
    print('Test from_yaml')
    str_1 = '''{'msg': '[WARNING]: %s\n', 'warnings': ['DeprecationWarning: DEFAULT_SUDO_USER will become an ansible_become_user option in 2.7, ']}'''
    var_1 = from_yaml(str_1)
    print('Test from_yaml')
    str_2 = '2017-11-13 23:11:14,761 p=2 u=root | [WARNING]: %s\n'
    var_2 = from_yaml(str_2)
    print('Test from_yaml')

# Generated at 2022-06-25 04:22:54.002914
# Unit test for function from_yaml
def test_from_yaml():

    # Test case from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=False)
    test_case_0()



# Generated at 2022-06-25 04:23:04.400356
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '["a", "b", "c"]'
    var_0 = from_yaml(str_0)
    str_1 = '["a", "b", "c"]'
    var_1 = from_yaml(str_1)
    str_2 = '{"a": "b", "c": "d"}'
    var_2 = from_yaml(str_2)
    str_3 = '{"a": "b", "c": "d"}'
    var_3 = from_yaml(str_3)
    str_4 = '["a", "b", "c"]'
    var_4 = from_yaml(str_4)
    str_5 = '["a", "b", "c"]'
    var_5 = from_yaml(str_5)
   

# Generated at 2022-06-25 04:23:13.463289
# Unit test for function from_yaml
def test_from_yaml():
    # Test for str
    str_0 = '{ "a": 5 }'
    var_0 = from_yaml(str_0)
    assert var_0 == {'a': 5}

    # Test for list
    str_1 = '[{ "a": 5 }]'
    var_1 = from_yaml(str_1)
    assert var_1 == [{'a': 5}]

    # Test for dict
    str_2 = '{ "b": [{ "a": 5 }] }'
    var_2 = from_yaml(str_2)
    assert var_2 == {'b': [{'a': 5}]}

# Generated at 2022-06-25 04:23:20.014421
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    assert type(var_0) is list
    assert var_0 == ['[WARNING]: %s']

    str_0 = "[WARNING]: 'file' rsync method not supported."

    var_0 = from_yaml(str_0)
    assert type(var_0) is list
    assert var_0 == "[WARNING]: 'file' rsync method not supported."

    str_0 = 'file not found'
    var_0 = from_yaml(str_0)
    assert type(var_0) is list
    assert var_0 == 'file not found'

    str_0 = 'file: not found'
    var_0 = from_yaml(str_0)
    assert type(var_0)

# Generated at 2022-06-25 04:23:28.310432
# Unit test for function from_yaml
def test_from_yaml():
    var_1 = json.loads('{"b": "glob", "a": "glob"}', cls=AnsibleJSONDecoder)
    var_3 = json.loads('{"b": "glob", "a": "glob"}', cls=AnsibleJSONDecoder)
    var_4 = json.loads('{"b": "glob", "a": "glob"}', cls=AnsibleJSONDecoder)
    var_5 = from_yaml('{"b": "glob", "a": "glob"}')
    var_8 = from_yaml('{"b": "glob", "a": "glob"}', file_name='<unknown>')

# Generated at 2022-06-25 04:23:31.260300
# Unit test for function from_yaml
def test_from_yaml():
    import pdb
    import inspect
    frame = inspect.currentframe()
    pdb.Pdb().set_trace(frame)
    # Test for value with no special case
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:23:41.511822
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""\n""") == "\n"
    assert from_yaml("""a: 1\nb: 2\n""") == {"a": 1, "b": 2}
    assert from_yaml("""\n""") == "\n"
    assert from_yaml("""a: 1\nb: 2\n""") == {"a": 1, "b": 2}
    assert from_yaml("""\n""") == "\n"
    assert from_yaml("""a: 1\nb: 2\n""") == {"a": 1, "b": 2}
    assert from_yaml("""\n""") == "\n"
    assert from_yaml("""a: 1\nb: 2\n""") == {"a": 1, "b": 2}

# Generated at 2022-06-25 04:23:50.632969
# Unit test for function from_yaml
def test_from_yaml():
    str0 = '[WARNING]: %s'
    ret0 = from_yaml(str0)
    assert ret0 is not None
    assert ret0 == [u'WARNING'], "Expected: %r, Got: %r" % (u'WARNING', ret0)
    str1 = '- include_role: test.yml\n\n- ssh {{ ansible_ssh_user }}@{{ ansible_ssh_host }}\n'
    ret1 = from_yaml(str1)
    assert ret1 is not None

# Generated at 2022-06-25 04:23:54.088226
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    assert from_yaml(str_0)



# Generated at 2022-06-25 04:24:00.059201
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[WARNING]: %s') == ['[WARNING]: %s']
    assert from_yaml('[WARNING]: %s', json_only=True) == '[WARNING]: %s'
    assert from_yaml('{ \"a\": 1 }', json_only=True) == {"a": 1}
    assert from_yaml('{ \"a\": 1 }') == {"a": 1}

# Generated at 2022-06-25 04:24:12.280510
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "[WARNING]: %s"
    var_0 = from_yaml(str_0)

    assert var_0 == ["WARNING", "%s"], "The return should be the same as in the expected result"

    str_1 = "1"
    var_1 = from_yaml(str_1)

    assert var_1 == 1, "The return should be the same as in the expected result"

    str_2 = "${test}"
    var_2 = from_yaml(str_2)

    assert var_2 == "${test}", "The return should be the same as in the expected result"

    str_3 = "\"${test}\""
    var_3 = from_yaml(str_3)


# Generated at 2022-06-25 04:24:18.292442
# Unit test for function from_yaml
def test_from_yaml():
    assert True
    str_0 = "[WARNING]: %s"
    var_0 = from_yaml(str_0)
    assert var_0 == 'WARNING'


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:24:21.292534
# Unit test for function from_yaml
def test_from_yaml():
    try:
        str_0 = '[WARNING]:'
        var_0 = from_yaml(str_0)
        var_1 = '%s'
        var_2 = (var_0, var_1)
        var_1 = var_2
    except Exception as err:
        print(err)

test_case_0()
test_from_yaml()

# Generated at 2022-06-25 04:24:21.974149
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:24:32.320058
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '''
- hosts: 192.168.0.0/24
  name: base
  gather_facts: yes
- hosts: database_servers
  name: database
  tasks:
    - name: ensure db is running
      service: name={{ "mongodb" if ansible_pkg_mgr in [ "yum", "zypper" ] else "mongodb-server" }} state=started enabled=yes
  roles:
    - mongodb
    '''
    var_0 = from_yaml(str_0)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:24:39.714174
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.data import handle_mapping_type_for_yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.ajson import AnsibleJSONEncoder
    str_0 = '#!/usr/bin/python'
    str_1 = '# -*- coding: utf-8 -*-\n\n'
    str_2 = '# (c) 2012-2014, Michael DeHaan <michael.dehaan@gmail.com>'
    str_3 = '# Copyright: (c) 2017, Ansible Project'

# Generated at 2022-06-25 04:24:41.932574
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[WARNING]: %s') != None


# Generated at 2022-06-25 04:24:45.931676
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "ohai"
    var_0 = from_yaml(str_0)
    pass

if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:24:54.989531
# Unit test for function from_yaml
def test_from_yaml():
    print("Skipping test_from_yaml...")
    #assert False
    #print(from_yaml(str: '', file_name: str: '<string>', show_content: bool: True, vault_secrets: __main__.object, json_only: bool: False):
    #print(from_yaml(str: '', file_name: str: '<string>', show_content: bool: True, vault_secrets: __main__.object, json_only: bool: False):
    #print(from_yaml(str: '', file_name: str: '<string>', show_content: bool: True, vault_secrets: __main__.object, json_only: bool: False):
    #print(from_yaml(str: '', file_name: str: '<string>

# Generated at 2022-06-25 04:24:58.501132
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '%s'
    var_0 = from_yaml(str_0)
    assert var_0 == '%s'

# Generated at 2022-06-25 04:25:09.995409
# Unit test for function from_yaml
def test_from_yaml():
    arg = None
    # Test with test case 0
    test_case_0()

    # Test with test data 1
    str_1 = '[WARNING]: Updating certs on localhost'
    var_1 = from_yaml(str_1)
    assert var_1 == ['WARNING' ':' ' Updating certs on localhost']

    # Test with test data 2
    str_2 = '[WARNING]: Updating certs'
    var_2 = from_yaml(str_2)
    assert var_2 == ['WARNING' ':' ' Updating certs']

    # Test with test data 3
    str_3 = '[WARNING]: Could not find any file(s) matching supplied pattern(s)'
    var_3 = from_yaml(str_3)

# Generated at 2022-06-25 04:25:12.495480
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('')
    from_yaml('{')
    from_yaml('{')
    from_yaml('[')

# Generated at 2022-06-25 04:25:21.480937
# Unit test for function from_yaml

# Generated at 2022-06-25 04:25:23.387299
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:25:26.611586
# Unit test for function from_yaml
def test_from_yaml():
    # Test for function from_yaml
    assert from_yaml == '[WARNING]: %s'

# Generated at 2022-06-25 04:25:28.662213
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"foo\": \"bar\"}") == dict(foo='bar')

# Generated at 2022-06-25 04:25:29.998893
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:25:35.714633
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    print(var_0)


if __name__ == '__main__':

    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:25:44.824735
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence


# Generated at 2022-06-25 04:25:45.964282
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:25:54.577274
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:25:57.596369
# Unit test for function from_yaml
def test_from_yaml():
    # test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()



# Generated at 2022-06-25 04:26:00.043431
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = """
- hosts: localhost
  roles:
    - role: allow_service
"""
    var_0 = from_yaml(str_0)
    assert var_0 == [{'roles': [{'role': 'allow_service'}], 'hosts': 'localhost'}]

# Generated at 2022-06-25 04:26:05.540470
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') == None
    assert from_yaml('{}') == {}
    assert from_yaml('{"key": "value"}') == {'key': 'value'}
    assert from_yaml('[]') == []
    assert from_yaml('[{"key": "value"}]') == [{'key': 'value'}]
    assert from_yaml('[]', json_only=True) is None
    assert from_yaml('[WARNING]: %s') is None

# Generated at 2022-06-25 04:26:09.939562
# Unit test for function from_yaml
def test_from_yaml():
    # Arrange
    str_0 = '[WARNING]: %s'
    # Act
    var_0 = from_yaml(str_0)

    # Assert
    assert var_0 == ['[WARNING]:', '%s'], 'Expected different value for var_0'

# Generated at 2022-06-25 04:26:24.431594
# Unit test for function from_yaml
def test_from_yaml():
    print(from_yaml('[WARNING]: %s'))
    print('test_from_yaml')
    print(from_yaml('[WARNING]: %s', vault_secrets=None))
    print(from_yaml('[WARNING]: %s', file_name='<string>', vault_secrets=None))
    print(from_yaml('[WARNING]: %s', file_name='<string>', show_content=True, vault_secrets=None))
    print(from_yaml('[WARNING]: %s', file_name='<string>', show_content=True, vault_secrets=None, json_only=False))
    print(from_yaml('[WARNING]: %s', file_name='<string>', show_content=True, vault_secrets=None, json_only=True))


# Generated at 2022-06-25 04:26:29.135832
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    from ansible.parsing.yaml import from_yaml
    var_0 = from_yaml(str_0)
    assert from_yaml is not None


# Generated at 2022-06-25 04:26:32.369515
# Unit test for function from_yaml
def test_from_yaml():
    # assert that str_0 is equal to the return value of from_yaml(arg_0, arg_1, arg_2)
    str_0 = '[WARNING]: %s'
    arg_0 = ('1','2','3','4','5')
    assert str_0 == from_yaml(arg_0)



# Generated at 2022-06-25 04:26:33.291766
# Unit test for function from_yaml
def test_from_yaml():
    assert False, 'No unit tests defined'

# Generated at 2022-06-25 04:26:43.801208
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    str_1 = 'MISSING: [WARNING]: %s'
    var_1 = '[WARNING]: \"foo\"'
    var_2 = from_yaml(str_1)
    str_2 = '[WARNING]: %s'
    var_3 = from_yaml(str_2)
    str_3 = 'MISSING: [WARNING]: %s'
    var_4 = '[WARNING]: \"foo\"'
    var_5 = from_yaml(str_3)
    str_4 = '[WARNING]: %s'
    var_6 = from_yaml(str_4)


# Generated at 2022-06-25 04:26:56.895182
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[root@lcm-centos73-01 conf.d]#") == "[root@lcm-centos73-01 conf.d]#"
    assert from_yaml("- include_tasks:") == "- include_tasks:"
    assert from_yaml("rescue:") == "rescue:"
    assert from_yaml("state:") == "state:"
    assert from_yaml("- name:") == "- name:"
    assert from_yaml("ip:") == "ip:"
    assert from_yaml("with_items:") == "with_items:"
    assert from_yaml("when:") == "when:"
    assert from_yaml("- debug:") == "- debug:"
    assert from_yaml("debug:") == "debug:"
    assert from_yaml

# Generated at 2022-06-25 04:27:05.373805
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[WARNING]: %s') == '[WARNING]: %s'
    assert from_yaml('[WARNING]: %s', json_only=True)
    assert from_yaml('[WARNING]: %s', show_content=True) == '[WARNING]: %s'
    assert from_yaml('[WARNING]: %s', file_name=10) == '[WARNING]: %s'
    assert from_yaml('[WARNING]: %s', vault_secrets='test_from_yaml') == '[WARNING]: %s'
    assert from_yaml('[WARNING]: %s', vault_secrets=123) == '[WARNING]: %s'

# Generated at 2022-06-25 04:27:10.031337
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": 3}', file_name='my_file') == {'a': 3}
    assert from_yaml('{"a": 3}') == {'a': 3}
    assert from_yaml('[1, "a"]') == [1, "a"]
    assert from_yaml('{"a": 3}') == {'a': 3}


# Generated at 2022-06-25 04:27:11.965302
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == "__main__":
    print(test_from_yaml())

# Generated at 2022-06-25 04:27:18.748493
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{"ansible_key": "ansible_val"}'
    var_0 = from_yaml(str_0)
    assert var_0 == {'ansible_key': 'ansible_val'}
    str_1 = '{"ansible_key": "ansible_val"}'
    var_1 = from_yaml(str_1)
    assert var_1 == {'ansible_key': 'ansible_val'}
    str_2 = '{"guest_key": "guest_val"}'
    var_2 = from_yaml(str_2)
    assert var_2 == {'guest_key': 'guest_val'}
    str_3 = '{"host_key": "host_val"}'

# Generated at 2022-06-25 04:27:25.707020
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    print(var_0)  # List String


# main
if __name__ == "__main__":
    function_list = [x for x in dir() if not x.startswith('_')]
    for func in function_list:
        if func.startswith('test_'):
            eval(func + '()')
    print('done')

# Generated at 2022-06-25 04:27:30.371714
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{[0,1,2],}'
    var_0 = from_yaml(str_0)
    str_1 = '{[0,1,2],}'
    var_1 = from_yaml(str_1)
    print(var_0, var_1)


# Generated at 2022-06-25 04:27:31.751340
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() is None, 'Failed to parse'

# Generated at 2022-06-25 04:27:41.358779
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '''
       - name: Run the public-hostname fact on a remote system
         action: command /bin/echo {{ ansible_facts['public_hostname'] }}
         register: result
         ignore_errors: True
       - name: Debug the command result
         debug: var=result.stdout_lines
       - name: Set the hostname to the system's public hostname
         hostname: name={{ result.stdout_lines }}
         delegate_to: localhost
    '''
    var_0 = from_yaml(str_0)

    # assert that the yaml string has been parsed correctly
    assert var_0[0]['name'] == "Run the public-hostname fact on a remote system"

# Generated at 2022-06-25 04:27:48.193280
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
# ------------------------------------------------------------------------------

# Generated at 2022-06-25 04:27:57.725589
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_data = from_yaml('''---
- hosts: localhost
  tasks:
  - name: command
    command: cat /etc/passwd
    register: result
  - debug:
      var: result
...
''')
    print(from_yaml_data)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:28:06.208109
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("\"'\"") is not None
    assert from_yaml("A\nB\nC\nD") is not None
    assert from_yaml("A\nB\nC\nD\n") is not None
    assert from_yaml("{\"a\": 2}") is not None
    assert from_yaml("[1, 2]") is not None
    assert from_yaml("[1, 2,]") is not None

# Generated at 2022-06-25 04:28:15.902838
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    assert var_0 == ['WARNING', '%s']
    str_1 = '''---
a:
  - 1
  - 2
  - 3
'''
    var_1 = from_yaml(str_1)
    assert var_1 == {'a': [1, 2, 3]}
    str_2 = '''---
a:
  - 1
  - 2
  - 3
'''
    var_2 = from_yaml(str_2, vault_secrets='test_value')
    assert var_2 == {'a': [1, 2, 3]}
    str_3 = '''---
a: 1
'''

# Generated at 2022-06-25 04:28:25.541708
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    assert var_0 == [ "WARNING: %s" ]
    str_1 = u'this is a yaml str: \u8be5\u6570\u636e\u5386'
    var_1 = from_yaml(str_1)
    assert var_1 == u'this is a yaml str: \u8be5\u6570\u636e\u5386'
    str_2 = '''[WARNING]: %s
  msg: |
    HERE DOC
'''
    var_2 = from_yaml(str_2)
    assert var_2 == [ { "WARNING: %s": { "msg": "HERE DOC\n" } } ]

# Unit test

# Generated at 2022-06-25 04:28:27.272400
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:28:37.707979
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:46.696117
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[WARNING]: %s') == [u'[WARNING]: %s']
    assert from_yaml('[WARNING]: %s', json_only=True) == [u'[WARNING]: %s']
    assert from_yaml('---\n[WARNING]: %s\n...\n') == [u'[WARNING]: %s']
    assert from_yaml('---\n[WARNING]: %s\n...\n', json_only=True) == [u'[WARNING]: %s']


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:50.416641
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = '[WARNING]: %s'
    assert from_yaml(str_1) is not None, 'Failed to assert non-None value of from_yaml(str_1)'


# Generated at 2022-06-25 04:28:54.015119
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = """
- name: Ensure HA configuration for all switches
  ios_config:
    lines: dst
    provider: "{{ cli }}"
    parents: router bgp 100
    state: replaced

  loop: "{{ groups['all'] }}"
"""

#     str_0 = str_0.encode('utf-8')
    var_0 = from_yaml(str_0)
    print(var_0)

# Generated at 2022-06-25 04:28:59.173953
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)



# Generated at 2022-06-25 04:29:15.078155
# Unit test for function from_yaml
def test_from_yaml():

    #
    # Test cases for string 'str_0 = '[WARNING]: %s''
    #
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    assert var_0 == '[WARNING]: %s'



# Generated at 2022-06-25 04:29:20.221989
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as e:
        err = str(e)

    expected_err = 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: Expecting value: line 1 column 1 (char 0)\n\n' \
        'AnsibleError: yaml.scanner.ScannerError: mapping values are not allowed here\n in "<unknown>", line 1, column 1'

    assert err == expected_err

# Generated at 2022-06-25 04:29:21.688739
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'b\'\\n[WARNING]: \''
    yaml_1 = from_yaml(str_0)
    assert yaml_1 == str_0


# Generated at 2022-06-25 04:29:28.297732
# Unit test for function from_yaml
def test_from_yaml():
    
    assert from_yaml('[WARNING]: %s') == [
        'WARNING]: %s'
    ]
    assert from_yaml('[WARNING]: %s') == [
        'WARNING]: %s'
    ]
    assert from_yaml('[WARNING]: %s') == [
        'WARNING]: %s'
    ]
    assert from_yaml('[WARNING]: %s') == [
        'WARNING]: %s'
    ]
    assert from_yaml('[WARNING]: %s') == [
        'WARNING]: %s'
    ]
    assert from_yaml('{WARNING]: %s') == {
        'WARNING]: %s': None
    }
    assert from_yaml('{WARNING]: %s') == {
        'WARNING]: %s': None
    }
    assert from_yaml

# Generated at 2022-06-25 04:29:38.007400
# Unit test for function from_yaml
def test_from_yaml():
    str1 = '''
- name: test
  hosts: localhost
  gather_facts: false
  tasks:
  - name: test
    shell: echo pwd
    register: out
    ignore_errors: true
'''
    str2 = '''
- name: test
  hosts: localhost
  gather_facts: false
  tasks:
  - name: test
    shell: echo pwd
    register: out
    ignore_errors: true
  vars:
    var1: value1
'''

# Generated at 2022-06-25 04:29:43.738673
# Unit test for function from_yaml
def test_from_yaml():

    try:
        str_0 = '[WARNING]: %s'
        var_0 = from_yaml(str_0)

        assert var_0 == [u'WARNING'], "AnsibleParserError is not raised."
    except AnsibleParserError as e:
        assert False, "AnsibleParserError is raised."

# Generated at 2022-06-25 04:29:53.976816
# Unit test for function from_yaml
def test_from_yaml():
    expected_0 = [u'[WARNING]: %s']
    str_0 = '[WARNING]: %s'
    obtained_0 = from_yaml(str_0)
    assert obtained_0 == expected_0

    expected_1 = u'some_var'
    str_1 = 'some_var'
    obtained_1 = from_yaml(str_1)
    assert obtained_1 == expected_1

    expected_2 = {u"somekey": "some_var"}
    str_2 = '{"somekey": "some_var"}'
    obtained_2 = from_yaml(str_2)
    assert obtained_2 == expected_2

    expected_3 = {u"somekey": "some_var", u"anotherkey": "a_var"}

# Generated at 2022-06-25 04:29:56.036390
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    assert var_0 == ['WARNING'], 'Expected [\'WARNING\']'



# Generated at 2022-06-25 04:30:00.989107
# Unit test for function from_yaml
def test_from_yaml():
    cur_desc = str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    print("%s = %s" %(cur_desc, var_0))

# Unit test stubs

# Generated at 2022-06-25 04:30:04.437368
# Unit test for function from_yaml
def test_from_yaml():
    # Test case 0
    try:
        test_case_0()
    except:
        import traceback
        tb = traceback.format_exc()
        print(tb)
        assert False



# Generated at 2022-06-25 04:30:25.070401
# Unit test for function from_yaml
def test_from_yaml():
    assert 'problem' in test_case_0()

# Generated at 2022-06-25 04:30:26.636080
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleUnsafeLoader
    loader = AnsibleUnsafeLoader
    assert loader



# Generated at 2022-06-25 04:30:28.859432
# Unit test for function from_yaml
def test_from_yaml():
    string_0 = '[WARNING]: %s'
    assert from_yaml(string_0) == ['WARNING:'], f'Expected {["WARNING:"]}, but got {from_yaml(string_0)}'

# Generated at 2022-06-25 04:30:29.897757
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() == None

# Generated at 2022-06-25 04:30:38.676866
# Unit test for function from_yaml
def test_from_yaml():
    str_1 = 'list_1:\n- val_1\n- val_2'
    dict_1 = from_yaml(str_1)
    assert dict_1['list_1'][0] == 'val_1'
    assert dict_1['list_1'][1] == 'val_2'

    dict_2 = from_yaml(str_1, json_only=True)
    assert dict_2 is None

    str_2 = '{{item_1.attr_1}}'
    dict_3 = from_yaml(str_2)
    assert dict_3 == '{{item_1.attr_1}}'

# Generated at 2022-06-25 04:30:40.201686
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[WARNING]: %s') == ['WARNING]: %s']

# Generated at 2022-06-25 04:30:47.554834
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '[WARNING]: %s'
    var_0 = from_yaml(str_0)
    assert var_0 is None
    str_1 = '{[2020-03-31T12:48:51,576][INFO ][o.e.m.j.JvmGcMonitorService]][gc'
    var_1 = from_yaml(str_1)
    assert var_1 is None
    str_2 = '#'
    var_2 = from_yaml(str_2)
    assert var_2 is None
    str_3 = ''
    var_3 = from_yaml(str_3)
    assert var_3 is None
    str_4 = '\\'
    var_4 = from_yaml(str_4)
    assert var_4 is None
    str_5

# Generated at 2022-06-25 04:30:52.515936
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as e:
        print("An exception occurred in test case:\n" + str(e))

# Generated at 2022-06-25 04:30:54.378078
# Unit test for function from_yaml
def test_from_yaml():

    # Tests that the act of checking expression is well-defined.
    #
    #   str_0 = '[WARNING]: %s'
    #   from_yaml(str_0)

    assert True



# Generated at 2022-06-25 04:30:59.583104
# Unit test for function from_yaml
def test_from_yaml():
    '''
    `from_yaml` tests.
    '''
    # tests.
    assert test_case_0() is None, 'unit_tests.test_from_yaml.test_case_0'

# Generated at 2022-06-25 04:31:41.858495
# Unit test for function from_yaml
def test_from_yaml():
    # test_case_0()

    # TODO: add more test cases
    str_0 = '''{ "hello": "world"}'''
    var_0 = from_yaml(str_0, json_only=True)
    print(var_0)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:31:42.232521
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True