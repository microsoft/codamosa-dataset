

# Generated at 2022-06-25 04:21:49.570290
# Unit test for function from_yaml
def test_from_yaml():
    tuple_0 = ()
    list_0 = []
    string_0 = 'string'
    dictionary = {
        'key': 'value',
    }

    test_cases = [
        # value,
        # expected result
        (tuple_0, None),
        (list_0, None),
        (string_0, None),
        (dictionary, None),
    ]

    for params, expected in test_cases:
        result = from_yaml(params)
        assert result == expected

# Generated at 2022-06-25 04:21:58.501469
# Unit test for function from_yaml
def test_from_yaml():
    src1 = ""
    data1 = from_yaml(src1)
    assert data1 == {}

    src2 = "{}"
    data2 = from_yaml(src2)
    assert data2 == {}

    src3 = "foo: bar"
    data3 = from_yaml(src3, json_only=True)
    assert data3 is None

    src4 = '{ "foo": "bar", "baz": "qux" }'
    data4 = from_yaml(src4, json_only=True)
    assert data4 == {"foo": "bar", "baz": "qux"}

    src5 = '{ foo: "bar", "baz": "qux" }'
    data5 = from_yaml(src5)

# Generated at 2022-06-25 04:22:06.541927
# Unit test for function from_yaml
def test_from_yaml():
    try:
        tuple_0 = ()
        var_0 = from_yaml(tuple_0)
        if var_0:
            try:
                assert tuple_0 == var_0
            except AssertionError as exc:
                raise AssertionError(str(exc) + '\n Expected: ' + str(tuple_0) + '\n but found: ' + str(var_0))

    except Exception:
        raise AssertionError('An error occurred in test #0')

if __name__ == "__main__":
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:22:09.470209
# Unit test for function from_yaml
def test_from_yaml():
    tuple_0 = ()
    test_0 = from_yaml(tuple_0)


if __name__ == '__main__':
    try:
        test_case_0()
    except Exception:
        print("Exception in user code:")
        print("-"*60)
        traceback.print_exc(file=sys.stdout)
        print("-"*60)
    else:
        print("No exception was raised")

# Generated at 2022-06-25 04:22:19.857433
# Unit test for function from_yaml
def test_from_yaml():
    tuple_0 = ()
    var_0 = from_yaml(tuple_0)
    assert var_0 == ()

    # ensure the vault secrets are actually being used

# Generated at 2022-06-25 04:22:30.606170
# Unit test for function from_yaml

# Generated at 2022-06-25 04:22:42.861593
# Unit test for function from_yaml
def test_from_yaml():
    a = None
    b = from_yaml(a)
    assert isinstance(b, type(None))

    a = 'str'
    b = from_yaml(a)
    assert isinstance(b, type('str'))
    assert b == 'str'

    a = 1
    b = from_yaml(a)
    assert isinstance(b, type(1))
    assert b == 1

    a = 1.0
    b = from_yaml(a)
    assert isinstance(b, type(1.0))
    assert b == 1.0

    a = '{"a": 1}'
    b = from_yaml(a)
    assert isinstance(b, dict)
    assert b == {'a': 1}

    a = json.dumps({"a": 1})
   

# Generated at 2022-06-25 04:22:53.277698
# Unit test for function from_yaml
def test_from_yaml():
    args = [{"name":"foo","location":"earth"},{"name":"bar","location":"mars"}]
    expt = [{u'name': u'foo', u'location': u'earth'}, {u'name': u'bar', u'location': u'mars'}]
    assert expt == from_yaml(args)
    args = [{"name":"foo","location":"earth"},{"name":"bar","location":"mars"}]
    expt = [{u'name': u'foo', u'location': u'earth'}, {u'name': u'bar', u'location': u'mars'}]
    assert expt == from_yaml(args)
    args = [{"name":"foo","location":"earth"},{"name":"bar","location":"mars"}]

# Generated at 2022-06-25 04:23:04.158784
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[]') == []
    assert from_yaml('{}') == {}
    assert from_yaml('hi') == 'hi'
    assert from_yaml('"hi"') == 'hi'
    assert from_yaml('["hi"]') == ['hi']
    assert from_yaml('{"hi": "ho"}') == {'hi': 'ho'}
    assert from_yaml('{"hi": ["ho"]}') == {'hi': ['ho']}
    #assert from_yaml('[{"hi": ["ho"]}]') == [{'hi': ['ho']}]
    #assert from_yaml('{"hi": {"ho": "hu"}}') == {'hi': {'ho': 'hu'}}

# Generated at 2022-06-25 04:23:16.131128
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.data import strip_yaml_comments
    from ansible.utils import split_args

    # Test for case_0
    # Test for case_1
    # Test for case_2
    # Test for case_3
    # Test for case_4
    # Test for case_5
    # Test for case_6
    # Test for case_7
    # Test for case_8
    # Test for case_9
    # Test for case_10
    # Test for case_11
    # Test for case_12
    # Test for case_13
    # Test for case_14
    # Test for case_15
    j_str = '{}'
    var_0 = from_yaml

# Generated at 2022-06-25 04:23:24.596179
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{}'
    str_1 = '{"key":"value"}'
    str_2 = '{"key":"value"}'
    str_3 = '{"key":"value"}'
    str_4 = '{"key":"value"}'

# Unit test using pytest
from _pytest.monkeypatch import MonkeyPatch
from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-25 04:23:26.645866
# Unit test for function from_yaml
def test_from_yaml():
    ansible_origin_data = {}
    ansible_result = from_yaml(str_0)
    assert ansible_result is not None
    assert ansible_origin_data == ansible_result

# Generated at 2022-06-25 04:23:33.378741
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{}'
    str_1 = '[]'
    str_2 = '1'
    str_3 = 'true'
    str_4 = 'false'
    str_5 = '"1"'
    str_6 = '""'
    str_7 = '{"key":"value"}'
    str_8 = '[1,2,3,4,5]'
    str_9 = '[true,false,true]'
    str_10 = '{"key1":"value1","key2":"value2","key3":"value3"}'
    str_11 = '{"key":"value","key2":"value2"}'

    assert (from_yaml(str_0) == json.loads(str_0))
    assert (from_yaml(str_1) == json.loads(str_1))
   

# Generated at 2022-06-25 04:23:42.760693
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
  - name: aaa
    bbb: ccc
  - name: ddd
    eee: fff
"""
    file_name = "/tmp/ansible-test"
    res = from_yaml(test_data, file_name)
    assert(res[0]['name'] == 'aaa')
    assert(res[0]['bbb'] == 'ccc')
    assert(res[1]['name'] == 'ddd')
    assert(res[1]['eee'] == 'fff')

# Generated at 2022-06-25 04:23:45.194376
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(str_0) == {}

# Test for coverage (partial)

# Generated at 2022-06-25 04:23:51.827417
# Unit test for function from_yaml
def test_from_yaml():
    print('Test #0: Test case of test_case_0')
    test_case_0()
    print('Success: test_case_0')
    print('Test #1: Default case: {}')
    assert from_yaml('{}') == {}
    assert from_yaml('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert from_yaml('{"a": [1, 2, 3], "b": 2}') == {"a": [1, 2, 3], "b": 2}
    
    
# Collect all test cases in this class
testcasesFromYaml = [
    # Unit test for function from_yaml
    (test_from_yaml)
]

# Collect all test cases in this file

# Generated at 2022-06-25 04:23:59.491512
# Unit test for function from_yaml
def test_from_yaml():
    ansible_str = '{\n"failed" : true,\n"msg" : "The task includes an option with an undefined variable. The error was: \'dict object\' has no attribute \'ansible_become_exe\'\n\nThe error appears to have been in \'<path>/ansible/playbooks/site.yml\': line 15, column 7, but may\nbe elsewhere in the file depending on the exact syntax problem.\n\nThe offending line appears to be:\n\n\n- include: roles/site.yml\n  ^ here\n"}'
    print(from_yaml(ansible_str))



# Generated at 2022-06-25 04:24:08.260350
# Unit test for function from_yaml
def test_from_yaml():
    print('****** TEST ******')
    str_0 = '{}'
    str_1 = '{"test":"test value"}'

    str_2 = '''
    ---
    {
        "asf" : "sadf"
    }'''

    res_0 = from_yaml(str_0)
    res_1 = from_yaml(str_1)
    res_2 = from_yaml(str_2)
    print(res_0)
    print(res_1)
    print(res_2)
    print('****** TEST ******')


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:24:16.553869
# Unit test for function from_yaml

# Generated at 2022-06-25 04:24:18.973518
# Unit test for function from_yaml
def test_from_yaml():
    print("WARNING: You should manually verify this output!")

    from_yaml(str_0)
    print('%s: PASS' % str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:24:25.113193
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{}'
    expected_str_0 = {}

    result_str_0 = from_yaml(str_0)
    assert  result_str_0 == expected_str_0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:24:35.044710
# Unit test for function from_yaml
def test_from_yaml():
    string_0 = '{}'
    assert from_yaml(string_0) == dict()

    string_1 = '{"a":"b"}'
    assert from_yaml(string_1) == {"a":"b"}

    # test with string that can be parsed either as JSON or as YAML
    string_2 = '{"include":"all"}'
    assert from_yaml(string_2) == {"include":"all"}

    # test with invalid JSON string
    string_3 = '{"include":"all" }'
    try:
        from_yaml(string_3)
    except AnsibleParserError as e:
        pass

    # test with invalid YAML string
    string_4 = 'invalid_yaml_string'

# Generated at 2022-06-25 04:24:47.260914
# Unit test for function from_yaml
def test_from_yaml():

    # Test for string: {}
    data_0 = '{}'
    # Test for string: {}
    data_1 = '{}'
    # Test for string: {'foo': 'bar'}
    data_2 = '{"foo": "bar"}'
    # Test for string: {'foo': 'bar', 'bam': {'hello': 'world'}}
    data_3 = '{"foo": "bar", "bam": {"hello": "world"}}'
    # Test for string: {'foo': ['bar', 'bam'], 'baz': 'bar'}
    data_4 = '{"foo": ["bar", "bam"], "baz": "bar"}'
    # Test for string: [{'foo': 'bar'}]
    data_5 = '[{"foo": "bar"}]'


# Generated at 2022-06-25 04:24:56.221256
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml("""
        ---
        - hosts: all
        - tasks:
            - name: task 1
              shell: echo 1
            - name: task 2
              shell: echo 2
    """) == [{u'hosts': u'all'}, {u'tasks': [{u'name': u'task 1', u'shell': u'echo 1'}, {u'name': u'task 2', u'shell': u'echo 2'}]}]

    # Test with the vault secret

# Generated at 2022-06-25 04:25:02.401374
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{}'
    res_0 = from_yaml(str_0)
    obj_0 = {}
    assert res_0 == obj_0


# Generated at 2022-06-25 04:25:07.755238
# Unit test for function from_yaml
def test_from_yaml():
    # Test case 0
    str_0 = '{}'
    ret_0 = from_yaml(str_0)
    assert ret_0 == {}
    # Test case 1
    str_1 = '[1, 2, 3]'
    ret_1 = from_yaml(str_1)
    assert ret_1 == [1, 2, 3]

if __name__ == '__main__':
    test_case_0()
    # test_from_yaml()

# Generated at 2022-06-25 04:25:18.729150
# Unit test for function from_yaml
def test_from_yaml():
    # Test for passing an invalid value
    try:
        from_yaml("{", show_content=True)
    except Exception:
        pass
    else:
        raise Exception("Expected exception, but none encountered")
    try:
        from_yaml("", show_content=True)
    except Exception:
        pass
    else:
        raise Exception("Expected exception, but none encountered")
    str_0 = '{}'
    str_1 = '{"a": 1, "b": 2}'
    str_2 = '{"a": {"b": 2}}'
    str_3 = '{"a": {"b": {"c": 3}}}'
    # Test for passing a valid value
    assert from_yaml(str_0, show_content=True) == {}

# Generated at 2022-06-25 04:25:25.811556
# Unit test for function from_yaml
def test_from_yaml():
    test_cases = [
        ('{}', {}),
        ('{"a":1,"b":2}', {u'a': 1, u'b': 2}),
        ('{"a": 1, "b": 2}', {u'a': 1, u'b': 2}),
        ('[1,2,3]', [1, 2, 3]),
    ]

    for test_case in test_cases:
        yaml_str, result = test_case
        assert from_yaml(yaml_str) == result, 'test_from_yaml failed'

# Generated at 2022-06-25 04:25:34.912005
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{}'
    str_1 = '{"dic": {"a": "b", "b": "a"}}'
    str_2 = '{"a": "b", "b": "a"}'
    str_3 = '[1, 2, 3]'
    str_4 = '''
            ---
            dic:
              a: "b"
              b: "a"
            '''
    str_5 = '''
            dic:
              a: "b"
              b: "a"
            '''
    str_6 = '''
            {
                "a": "b",
                "b": "a"
            }
            '''

# Generated at 2022-06-25 04:25:43.964698
# Unit test for function from_yaml
def test_from_yaml():
    # Test argument 'data'
    data = '{}'
    res = from_yaml(data)
    assert res == {}

    data = '{"a":1}'
    # Test argument 'file_name'
    file_name = 'test_file_name'
    res = from_yaml(data, file_name)
    assert res == {'a': 1}

    # Test argument 'show_content'
    show_content = True
    res = from_yaml(data, show_content=show_content)
    assert res == {'a': 1}

    # Test argument 'vault_secrets'
    vault_secrets = {'a': 1}
    res = from_yaml(data, vault_secrets=vault_secrets)
    assert res == {'a': 1}

   

# Generated at 2022-06-25 04:25:48.951132
# Unit test for function from_yaml
def test_from_yaml():
    # Test cases
    print("----test case 0--")
    test_case_0()

test_from_yaml()



# Generated at 2022-06-25 04:25:51.674072
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-25 04:25:55.257061
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(str_0)

# Generated at 2022-06-25 04:25:58.738714
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(str_0)
    result = loader.get_data()
    assert result == {}

# Generated at 2022-06-25 04:26:01.474136
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '{}'

    try:
        new_data = json.loads(str_0, cls=AnsibleJSONDecoder)
    except Exception as e:
        raise


# Generated at 2022-06-25 04:26:02.333960
# Unit test for function from_yaml
def test_from_yaml():

    pass


# Generated at 2022-06-25 04:26:11.240903
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '''
    - hosts: localhost
      connection: local
      gather_facts: no
      tasks:
      - name: 获取hosts列表
        delegate_to: localhost
        raw: cat /etc/hosts
        register: hosts
      - name: 获取os_platform列表
        delegate_to: localhost
        raw: cat /etc/os-release
        register: os_platform
    '''
    from_yaml(str_0)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:26:18.538646
# Unit test for function from_yaml
def test_from_yaml():
    json_str_0 = '{\'A\': [1, 2, 3, 4, 5]}'
    json_str_1 = '{\'B\': [1, 2, 3, 4, 5]}'
    json_str_2 = '{\'C\': [1, 2, 3, 4, 5]}'
    json_str_3 = '{\'D\': [1, 2, 3, 4, 5]}'
    json_str_4 = '{\'E\': [1, 2, 3, 4, 5]}'
    json_str_5 = '{\'F\': [1, 2, 3, 4, 5]}'
    test_str_0 = '{\'foo\': [1, 2, 3, 4, 5]}'

# Generated at 2022-06-25 04:26:27.349235
# Unit test for function from_yaml
def test_from_yaml():
    # Try reading a JSON string
    str_0 = '''
{
    "user": "ansible",
    "db": "vault_role2_db",
    "passwd": "vault_role2_pwd",
    "host": "vault_role2_host"
}
'''
    from_yaml_ret = None
    err = 0
    try:
        from_yaml_ret = from_yaml(str_0)
    except Exception as e:
        err = 1
    assert err == 0 and from_yaml_ret is not None
    assert type(from_yaml_ret) is dict
    assert len(from_yaml_ret) is 4
    assert from_yaml_ret['user'] == 'ansible'

# Generated at 2022-06-25 04:26:34.144570
# Unit test for function from_yaml
def test_from_yaml():
    # defaults
    start_time = time.time()
    test_case_0()
    end_time = time.time()
    # print('Time: %s', (end_time - start_time))
    # print(type(end_time - start_time))
    return end_time - start_time


if __name__ == "__main__":
    print("Load ansible module cost time: %s" % test_from_yaml())

# Generated at 2022-06-25 04:26:44.925998
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a json-only yaml string body
    string_0 = '{"Qmbo\\x0c%E"}'
    string_1 = from_yaml(string_0, json_only=True)
    assert string_1 == "{'Qmbo\\x0c%E'}"

    # Test with a dynamic yaml string body
    dynamic_0 = '"Qmbo\\x0c%E"}'
    dynamic_1 = from_yaml(dynamic_0)
    assert dynamic_1 == 'Qmbo\\x0c%E'

    # Test with a safe yaml string body
    safe_0 = '''
---
- 1
- 2
- 3
'''
    safe_1 = from_yaml(safe_0)
    assert safe_1 == [1, 2, 3]



# Generated at 2022-06-25 04:26:46.677498
# Unit test for function from_yaml
def test_from_yaml():

    test_cases_0()


# Generated at 2022-06-25 04:26:51.532725
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'Qm9jdW1lbnQgc2hhcmVkIHdpdGggc29tZSAoUG9ydHNlYWN0IGlkZWEp'
    var_0 = from_yaml(str_0)
    assert var_0 == 'Document shared with some (Portsmouth idea)'

# Generated at 2022-06-25 04:26:53.509217
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:26:56.221153
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:26:59.274375
# Unit test for function from_yaml
def test_from_yaml():
    # Input arguments list for unit test
    argument_0 = [
        '"Qm9j\x0c%E'
        ]

    testcase_0(argument_0)

# Generated at 2022-06-25 04:27:00.917602
# Unit test for function from_yaml
def test_from_yaml():
    assert 1 == 1



# Generated at 2022-06-25 04:27:02.292466
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True

# Test case for function from_yaml

# Generated at 2022-06-25 04:27:06.915147
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = None
    try:
        var_0 = from_yaml(str_0)
    except AnsibleParserError as e:
        assert False
    assert var_0 is not None


# vim:ai:cin:et:sts=4:sw=4:tw=78:

# Generated at 2022-06-25 04:27:12.442557
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)
    var_1 = 'Qm9j\n%E'
    assert var_0 == var_1, 'Expected {}, but got {}'.format(var_1, var_0)

# def from_yaml(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=False):

# Generated at 2022-06-25 04:27:25.976760
# Unit test for function from_yaml
def test_from_yaml():
    try:
        # Testing with string_data
        str_0 = '"Qm9j\x0c%E'
        var_0 = from_yaml(str_0)
        print("from_yaml() returned: ", repr(var_0))
    except Exception as e:
        print("from_yaml() failed with", repr(e))
        raise

# Unit test execution
if __name__ == "__main__":
    print("Executing unit tests for from_yaml")
    test_from_yaml()
    print("Executing from_yaml() test case 0:")
    test_case_0()
    print("Done!")

# Generated at 2022-06-25 04:27:28.148222
# Unit test for function from_yaml
def test_from_yaml():
    # Test the function without Boa.
    pass


# Generated at 2022-06-25 04:27:40.907300
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:27:44.255363
# Unit test for function from_yaml
def test_from_yaml():
    print(test_case_0())

# Generated at 2022-06-25 04:27:45.857722
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:27:54.216230
# Unit test for function from_yaml
def test_from_yaml():

    # test case with json and yaml
    yaml_str = """
    - hosts: localhost
      tasks:
        - name: test
          debug: msg='hello world'
    """
    json_data = from_yaml(yaml_str, file_name='<string>', show_content=True, json_only=True)
    assert type(json_data) == list
    assert len(json_data) == 1
    assert json_data[0].get('hosts') == 'localhost'
    assert json_data[0].get('tasks') == [{'name': 'test', 'debug': {'msg': 'hello world'}}]

    # test case with json and yaml

# Generated at 2022-06-25 04:27:57.591685
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('A: B') == {'A': 'B'}



# Generated at 2022-06-25 04:28:05.522890
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)
    assert var_0 == None, "from_yaml returned an unexpected value: %s" % var_0

    # test for str, int, float and complex types
    str_1 = '"Qm9j\x0c%E"'
    var_1 = from_yaml(str_1)
    assert var_1 == None, "from_yaml returned an unexpected value: %s" % var_1

    str_2 = '"Qm9j\x0c%E"'
    var_2 = from_yaml(str_2)
    assert var_2 == None, "from_yaml returned an unexpected value: %s" % var_2


# Generated at 2022-06-25 04:28:06.197288
# Unit test for function from_yaml
def test_from_yaml():

    return



# Generated at 2022-06-25 04:28:12.086107
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - hosts:
        - localhost
    tasks:
    - name: test
      ping:
    '''
    result = from_yaml(data)
    assert result == {
        'hosts': [
            'localhost',
        ],
        'tasks': [
            {
                'name': 'test',
                'ping': None,
            },
        ],
    }

# Generated at 2022-06-25 04:28:18.914035
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()
    # FIXME: improve this test
    pass

# Generated at 2022-06-25 04:28:24.819697
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.compat.tests import unittest
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestFromYaml(unittest.TestCase):
        def test_empty_key(self):
            ds = from_yaml('''{
                "foo": {
                    "": "bar"
                }
            }''')
            self.assertEqual(ds, {'foo': {'': 'bar'}})

            ds = from_yaml('''{
                "foo": {
                    "": "bar"
                },
                "": "bar",
                "": "baz"
            }''')

# Generated at 2022-06-25 04:28:32.652833
# Unit test for function from_yaml
def test_from_yaml():
    # Check if it can recognize and convert YAML string to datastructure
    assert from_yaml('{ key: value }') == {'key': 'value'}
    # Check if it can recognize and convert JSON string to datastructure
    assert from_yaml('{ "key": "value" }') == {'key': 'value'}
    # Check if it can cast string to boolean
    assert from_yaml('{ "key": "True" }') == {'key': True}
    assert from_yaml('{ "key": "False" }') == {'key': False}
    # Check if it can cast string to integer
    assert from_yaml('{ "key": "1" }') == {'key': 1}
    # Check if it can cast string to float

# Generated at 2022-06-25 04:28:34.756171
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:35.331040
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:28:37.858015
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)
    assert var_0 == '"Qm9j\x0c%E'


# Generated at 2022-06-25 04:28:48.343816
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)
    str_1 = '"Qm9j\x0c%E'
    var_1 = from_yaml(str_1)
    str_2 = '"Qm9j\x0c%E'
    var_2 = from_yaml(str_2)
    str_3 = '"Qm9j\x0c%E'
    var_3 = from_yaml(str_3)
    str_4 = '"Qm9j\x0c%E'
    var_4 = from_yaml(str_4)
    str_5 = '"Qm9j\x0c%E'

# Generated at 2022-06-25 04:28:50.620907
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:28:51.483150
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:28:53.500196
# Unit test for function from_yaml
def test_from_yaml():

    # Example 1
    str_1 = 'apple'
    var_1 = from_yaml(str_1)

# Generated at 2022-06-25 04:29:10.228798
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)
    str_1 = '"Qm9j\x0c%E'
    var_1 = from_yaml(str_1, '<string>', False)
    str_2 = '"Qm9j\x0c%E'
    var_2 = from_yaml(str_2, '<string>', True, None)
    str_3 = '"Qm9j\x0c%E'
    var_3 = from_yaml(str_3, '<string>', True, None, True)
    str_4 = '"Qm9j\x0c%E'

# Generated at 2022-06-25 04:29:20.220653
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)
    str_1 = '"Qm9j\x0c%E'
    var_1 = from_yaml(str_1)
    str_2 = '"Qm9j\x0c%E'
    var_2 = from_yaml(str_2)
    str_3 = '"Qm9j\x0c%E'
    var_3 = from_yaml(str_3)
    str_4 = '"Qm9j\x0c%E'
    var_4 = from_yaml(str_4)
    str_5 = '"Qm9j\x0c%E'

# Generated at 2022-06-25 04:29:28.216462
# Unit test for function from_yaml
def test_from_yaml():
    # Test no secrets are needed
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)
    assert var_0 == "Qm9j%E", "from_yaml(str_0) is (\"Qm9j%E\"), but (\"{0}\") was returned instead.".format(var_0)

    str_1 = '5'
    var_1 = from_yaml(str_1)
    assert var_1 == 5, "from_yaml(str_1) is (5), but ({0}) was returned instead.".format(var_1)

    str_2 = '{"0":"Qm9j%E"}'
    var_2 = from_yaml(str_2)

# Generated at 2022-06-25 04:29:37.659560
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '45'
    var_0 = from_yaml(str_0)
    assert type(var_0) is int
    assert var_0 == 45

    str_1 = 'true'
    var_1 = from_yaml(str_1)
    assert type(var_1) is bool
    assert var_1

    str_2 = '- 1'
    var_2 = from_yaml(str_2)
    assert type(var_2) is list
    assert var_2 == [-1]

    str_3 = '"Qm9j\x0c%E'
    var_3 = from_yaml(str_3)
    assert type(var_3) is str
    assert var_3 == "Qm9j\x0c%E"


# Generated at 2022-06-25 04:29:44.725367
# Unit test for function from_yaml
def test_from_yaml():

    # Tests that an Exception is thrown when the input size is bigger than the
    # maximum length and the maximum length is set.
    with pytest.raises(AnsibleParserError):
        test_case_0()

    # Tests that an Exception is thrown when the input size is bigger than the
    # maximum length and the maximum length is set.
    with pytest.raises(AnsibleParserError):
        test_case_0()

# Generated at 2022-06-25 04:29:51.496925
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    assert from_yaml(str_0) == 'Qm9j\x0c%E'
    str_0 = 'y'
    assert from_yaml(str_0) == u'y'
    str_0 = 'n'
    assert from_yaml(str_0) == u'n'
    str_0 = '1'
    assert from_yaml(str_0) == 1
    str_0 = '0'
    assert from_yaml(str_0) == 0
    str_0 = ''
    assert from_yaml(str_0) == u''
    str_0 = 'kFj\x1c'

# Generated at 2022-06-25 04:29:53.491759
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:30:01.915663
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'Ng==\n"'
    var_0 = from_yaml(str_0)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:30:04.761424
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Presets for ansible-test compatibility

# Generated at 2022-06-25 04:30:09.457068
# Unit test for function from_yaml
def test_from_yaml():
    # Temporary function to raise error if incorrect type.
    # If you want to define error-raising function,
    # define your function and set assert_raises_regexp's third argument to your function name.
    def wrong_tpye_error(message):
        assert False, message

    assert_raises_regexp(AssertionError, '.*', test_case_0)

# Generated at 2022-06-25 04:30:29.120741
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '''- hosts: localhost
  tasks:
    - debug: msg={{ lookup['ansible_env']['SOME_VAR'] }}
    - debug: msg={{ lookup('env','SOME_VAR') }}
'''
    var_0 = from_yaml(str_0)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 04:30:31.274227
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:30:41.692566
# Unit test for function from_yaml
def test_from_yaml():
    test_dict = from_yaml('{ "foo": "bar" }')
    assert test_dict == {'foo': 'bar'}

    test_list = from_yaml('{ "foo": "bar", "baz": ["a", "b", "c"], "bam": true }')
    assert test_list == {'foo': 'bar', 'baz': ['a', 'b', 'c'], 'bam': True}

    test_list = from_yaml('[foo, bar, baz]')
    assert test_list == ['foo', 'bar', 'baz']

    test_str = from_yaml('"foo bar baz"')
    assert test_str == 'foo bar baz'

    test_array = from_yaml('foo\nbar\nbaz')
    assert test_array

# Generated at 2022-06-25 04:30:43.581233
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = '"Qm9j\x0c%E'
    var_0 = from_yaml(str_0)

# Generated at 2022-06-25 04:30:47.435551
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = "1111111111111111111"
    var_0 = from_yaml(str_0)
    assert len(var_0) == 20
    str_1 = "\n- hosts: localhost\n  tasks:\n  - command: ls\n  - command: ls -al"
    var_1 = from_yaml(str_1)
    assert var_1['tasks'][0]['command'] == 'ls'

# Generated at 2022-06-25 04:30:49.682833
# Unit test for function from_yaml
def test_from_yaml():
    try:
        str_0 = '"Qm9j\x0c%E'
        var_0 = from_yaml(str_0)
    except Exception:
        assert False

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:30:58.116489
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('Lw==') == '1'
    assert from_yaml('MDRm') == '00f'
    assert from_yaml('Lg==') == '2'
    assert from_yaml('MjAx') == '201'
    assert from_yaml('LT4=') == '0<'
    assert from_yaml('MjAxKg==') == '201*'
    assert from_yaml('LT5A') == '0Z'
    assert from_yaml('MjAxMDM=') == '20103'
    assert from_yaml('LT5C') == '0['
    assert from_yaml('MjAxMC4x') == '2010.1'
    assert from_yaml('LT5D') == '0\\'
    assert from_yaml

# Generated at 2022-06-25 04:30:59.164066
# Unit test for function from_yaml
def test_from_yaml():
    try:
        assert True
    except:
        print('Test failed')



# Generated at 2022-06-25 04:31:06.387565
# Unit test for function from_yaml
def test_from_yaml():
    data = "key: value"
    file_name = "<string>"
    show_content = True
    vault_secrets = None
    json_only = False
    try:
        var_0 = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    except Exception as e:
        var_0 = e
    except:
        var_0 = "exception"
    try:
        var_1 = from_yaml(data)
    except Exception as e:
        var_1 = e
    except:
        var_1 = "exception"
    assert var_0 == {'key': 'value'}
    assert var_1 == {'key': 'value'}



# Generated at 2022-06-25 04:31:17.405589
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('h') == None
    assert from_yaml('a') == None
    assert from_yaml('e') == None
    assert from_yaml('n') == None
    assert from_yaml('g') == None
    assert from_yaml('{}') == None
    assert from_yaml('13') == None
    assert from_yaml('@') == None
    assert from_yaml('|') == None
    assert from_yaml('\n') == None
    assert from_yaml('}') == None
    assert from_yaml('>') == None
    assert from_yaml('z') == None
    assert from_yaml(']') == None
    assert from_yaml(':') == None
    assert from_yaml('r') == None
    assert from_y