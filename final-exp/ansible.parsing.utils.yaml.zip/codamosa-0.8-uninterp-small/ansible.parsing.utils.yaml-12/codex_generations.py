

# Generated at 2022-06-25 04:21:49.057763
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)
    data = '''
        - name: foo
          state: present
          foo: bar
        - name: bar
          state: absent'''
    assert from_yaml(data) == [dict(name='foo', state='present', foo='bar'), dict(name='bar', state='absent')]

# Generated at 2022-06-25 04:21:58.279189
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    test_yaml = """
    ---
    - hosts: all
      tasks:
        - name: Place the current Python environment into a file
          pip:
            name: "{{ item }}"
            state: present
          with_items:
            - pip
            - virtualenv
            - virtualenvwrapper
          environment: "{{ python_environ }}"

        - name: Restart Apache
          service:
            name: httpd
            state: restarted
    """
    var_0 = from_yaml(test_yaml)

# Generated at 2022-06-25 04:22:03.158119
# Unit test for function from_yaml
def test_from_yaml():
    import random

    for item in (bytearray(random.getrandbits(8) for _ in range(random.randint(1, 1000))), bytearray(random.getrandbits(8) for _ in range(random.randint(1, 1000)))):
        test_case_0()

# Generated at 2022-06-25 04:22:09.919063
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'{}\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bytes_1 = b'{}\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 04:22:15.721812
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xff\xeb\xfe\x03\xfd\xfe\xfd'
    int_0 = from_yaml(bytes_0)
    assert int_0 == -15329

    bytes_1 = b'\xcc\x0b\xcc\x99\x00\xb5\xce\x0b\xcc\x99\x00\xb5\xce'
    dict_0 = from_yaml(bytes_1)
    assert dict_0 == {'time': 372471.6666666667, 'time': 372471.6666666667}

    bytes_2 = b'\xfe\x08\x00\x00\x00\x00\x00\x00\x00'
    dict_1 = from_yaml(bytes_2)
   

# Generated at 2022-06-25 04:22:20.539303
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)

# Testing for function from_yaml
if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:22:27.774653
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)


if __name__ == '__main__':
    import traceback

    res = test_from_yaml()
    if res:
        traceback.print_exc()
    else:
        print('OK')

# Generated at 2022-06-25 04:22:36.359418
# Unit test for function from_yaml
def test_from_yaml():
    import inspect
    from ansible.parsing.dataloader import DataLoader
    caller = inspect.getouterframes(inspect.currentframe())[1][3]

    # Safe-load test cases

# Generated at 2022-06-25 04:22:41.496152
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:22:46.406660
# Unit test for function from_yaml
def test_from_yaml():
    print("### START from_yaml unit tests ###")
    test_case_0()
    print("### END from_yaml unit tests ###")

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:22:52.585540
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:23:01.380610
# Unit test for function from_yaml

# Generated at 2022-06-25 04:23:02.146277
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:23:13.426341
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    assert var_0 == b'?]\x9d\x06\x12|/\xfa\xa2N'
    bytes_1 = b'\x0f\xbe?\x0c\x1a\x1c\x1a\x1e'
    var_1 = from_yaml(bytes_1)
    assert var_1 == b'\x0f\xbe?\x0c\x1a\x1c\x1a\x1e'

# Generated at 2022-06-25 04:23:18.493959
# Unit test for function from_yaml
def test_from_yaml():
    # Pretend input
    input = "toto"
    # Function call
    result = from_yaml(input)
    assert isinstance(result, str)
    assert result.startswith("toto")

if __name__ == "__main__":
    # Example snippets
    import doctest
    doctest.testmod()

    # test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:23:24.078872
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    assert var_0 == {'key_0': 'value_1'}, 'Failed to assert: var_0 == {\'key_0\': \'value_1\'}'

# Generated at 2022-06-25 04:23:28.431212
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:23:29.616234
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a string parameter
    assert from_yaml('foo') is not None

# Generated at 2022-06-25 04:23:36.339914
# Unit test for function from_yaml
def test_from_yaml():
    # bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    bytes_0 = b'{"a": "A"}'
    var_0 = from_yaml(bytes_0)
    assert var_0 == {"a":"A"}, "Expected values to be equal"



# Generated at 2022-06-25 04:23:48.691559
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import test.yaml_syntax_failures
    # pylint: disable=broad-except
    except Exception as e:
        print(str(e))
        print("\n")
        print("No need to run tests if you don't have unit tests from devel branch")
        return
    for f in test.yaml_syntax_failures.test_cases:
        try:
            from_yaml(f)
            assert False, "Should have failed parsing '%s'" % f
        except AnsibleParserError:
            pass
        except Exception as e:
            print(str(e))
            assert False, "Should not have thrown exception '%s' parsing '%s'" % (e, f)



# Generated at 2022-06-25 04:24:00.270658
# Unit test for function from_yaml
def test_from_yaml():
    import collections
    import io
    import sys


# Generated at 2022-06-25 04:24:03.705716
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)

    assert isinstance(var_0, dict) is True
    assert var_0.get('xxx') is None


# Generated at 2022-06-25 04:24:09.194115
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    assert var_0 is None
    assert isinstance(var_0, object)



# Generated at 2022-06-25 04:24:17.363024
# Unit test for function from_yaml
def test_from_yaml():
    # These are just some examples to verify the output

    # Test case from issue #39442
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-25 04:24:26.768286
# Unit test for function from_yaml

# Generated at 2022-06-25 04:24:27.373439
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml()


# Generated at 2022-06-25 04:24:36.537498
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b"---\n- hosts:\n  - localhost") == b"---\n- hosts:\n  - localhost"
    assert from_yaml(b"[a,b,c]") == b"[a,b,c]"
    assert from_yaml(b"a") == b"a"
    assert from_yaml(b"123") == b"123"
    assert from_yaml(b"true") == b"true"
    assert from_yaml(b"asdasd") == b"asdasd"
    assert from_yaml(b"\x00") == b"\x00"
    assert from_yaml(b"\x00", vault_secrets=None) == b"\x00"

# Generated at 2022-06-25 04:24:43.056440
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    - name: hello
      when: false
      hosts:
      - localhost
    '''
    res = from_yaml(data)
    assert_equal(res, [{'name': 'hello', 'when': False, 'hosts': ['localhost']}])


# Generated at 2022-06-25 04:24:44.728945
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# Generated at 2022-06-25 04:24:54.528198
# Unit test for function from_yaml
def test_from_yaml():
    # Invalid case
    bytes_0 = b'?\xfbA\xd3\xa3\xa7\xc9\x11\xf1'
    var_0 = from_yaml(bytes_0)

    # Invalid case
    bytes_1 = b'?\x0c\x04v\xf7QW8'
    var_1 = from_yaml(bytes_1)

    # Invalid case
    bytes_2 = b'?\x8a\xb7\xdb\xf15'
    var_2 = from_yaml(bytes_2)

    # Invalid case
    bytes_3 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_3 = from_yaml(bytes_3)

    # Invalid case

# Generated at 2022-06-25 04:25:07.353792
# Unit test for function from_yaml
def test_from_yaml():
    # Test case 0
    test_case_0()
    # Test case 1
    bytes_1 = b'\x96\xf3\x8c\x88\x02\xdc\xbc\x8e\xf0\xfc\xd1\x9c'
    var_1 = from_yaml(bytes_1)

if __name__ == '__main__':
    test_from_yaml()
    from_yaml(b'\x96\xf3\x8c\x88\x02\xdc\xbc\x8e\xf0\xfc\xd1\x9c')

# Generated at 2022-06-25 04:25:08.921203
# Unit test for function from_yaml
def test_from_yaml():
    assert callable(from_yaml)


# Generated at 2022-06-25 04:25:19.213950
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

if __name__ == '__main__':
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.module_utils.six import PY3

    ansible_2_4_0 = AnsibleMapping(
        {
            'name': 'ansible',
            'version': '2.4.0.0',
            'foo': [
                {'bar': 'baz'},
                PY3,
            ],
        }
    )
    ansible_2_4_0_json = b'{"name": "ansible", "version": "2.4.0.0", "foo": [{"bar": "baz"}, true]}'

# Generated at 2022-06-25 04:25:24.720215
# Unit test for function from_yaml
def test_from_yaml():
    the_value_0 = '?'
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    if (var_0 != the_value_0):
        print('FAIL: expected {}, observed {}'.format(the_value_0, var_0))

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:25:34.212073
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six.moves import StringIO

    data = StringIO('---\n- hosts: localhost')
    assert from_yaml(data.read())[0]['hosts'] == 'localhost'

    # data = StringIO('[1, 2, 3]')
    # assert from_yaml(data.read()) == [1, 2, 3]

    # data = StringIO('{"_raw_params": "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQDYl5f5SyEKjZlC5vRj0KW8kfNucp7TWwMvjNZC/6q3X6/Ey2/UZCARL/j2K8TmTlh7VztiOGoZp7V8j

# Generated at 2022-06-25 04:25:43.476299
# Unit test for function from_yaml
def test_from_yaml():
    data = b'foo: 1\nbar: 2\nbaz:\n  - 3\n  - 4\n'
    new_data = from_yaml(data)
    assert new_data == {'foo': 1, 'bar': 2, 'baz': [3, 4]}
    data = b'---\nfoo: 1\nbar: 2\nbaz:\n  - 3\n  - 4\n'
    new_data = from_yaml(data)
    assert new_data == {'foo': 1, 'bar': 2, 'baz': [3, 4]}
    data = b'foo: 1\nbar: 2\nbaz:\n- 3\n- 4\n'
    new_data = from_yaml(data)

# Generated at 2022-06-25 04:25:46.200408
# Unit test for function from_yaml
def test_from_yaml():
    assert False


# Generated at 2022-06-25 04:25:55.640979
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml

    Wrapper around yaml.safe_load to also support json. Should be called
    with either json or yaml data.
    '''

    # Setup test values
    text = b'a: 1'
    encoding = 'utf-8'
    file_name = '<string>'
    show_content = True
    vault_secrets = None
    json_only = False

    ###
    # Test execution
    #
    # We expect to get back a dictionary of "a": 1
    #
    new_data = from_yaml(
        text=text,
        file_name=file_name,
        show_content=show_content,
        vault_secrets=vault_secrets,
        json_only=json_only)


# Generated at 2022-06-25 04:25:59.039602
# Unit test for function from_yaml
def test_from_yaml():
    try:
        test_case_0()
    except Exception as e:
        print("Exception occurred in test_from_yaml. %s" % e)

# Main Function

# Generated at 2022-06-25 04:26:10.356310
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xce\x9f\xce\x92\xce\x97\xce\x93\xce\x95\xce\x9e\xce\xa9\xce\xa4\xce\x9e\xce\xa4\xce\x9f\xce\x9e\xce\xa4\xce\x9f\xce\xa5\xce\x9f\xce\x92\xce\x95\xce\x9e\xce\x9f\xce\xa3\xce\x98'
    var_0 = from_yaml(bytes_0, file_name='<string>', show_content=True, vault_secrets=None, json_only=False)

# Generated at 2022-06-25 04:26:16.370309
# Unit test for function from_yaml
def test_from_yaml():

    # The following line can be used to
    # generate the obj file
    # The obj file should not be checked in
    # subprocess.call(["python", "-m", "dis", "-o", "test_case_0.obj", "test_case_0"])
    import test_case_0

    print(str(test_case_0.var_0))

# Generated at 2022-06-25 04:26:25.560362
# Unit test for function from_yaml
def test_from_yaml():
    # Test with bad args
    try:
        from_yaml()
    except Exception as e:
        print(e.__class__.__name__)
        assert(e.__class__.__name__ == 'TypeError')

    # Test with good args
    good_data = """{
    "object_name": "foo"
}
"""
    data = from_yaml(good_data)
    assert(data == {'object_name': 'foo'})
# /Unit test for function from_yaml

# Generated at 2022-06-25 04:26:29.723295
# Unit test for function from_yaml
def test_from_yaml():
    arg0 = 'data'
    arg1 = 'file_name'
    arg2 = True
    arg3 = 'vault_secrets'
    arg4 = True
    to_native(from_yaml(arg0, arg1, arg2, arg3, arg4))

# Generated at 2022-06-25 04:26:33.685966
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    print(var_0)

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:26:44.504415
# Unit test for function from_yaml
def test_from_yaml():
    # Specify bytes data
    bytes_0 = b'k?\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    assert var_0 == "k?\x9d\x06\x12|/\xfa\xa2N", var_0
    # Specify file name
    var_0 = from_yaml(bytes_0, file_name='<string>')
    assert var_0 == "k?\x9d\x06\x12|/\xfa\xa2N", var_0
    # Specify show_content
    var_0 = from_yaml(bytes_0, show_content=False)

# Generated at 2022-06-25 04:26:50.392265
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError) as exc_info:
        test_case_0()
    assert re.match(r'^We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: .*Expecting value: line 1 column 1 \(char 0\)$', exc_info.value.message)

# Generated at 2022-06-25 04:26:56.575473
# Unit test for function from_yaml
def test_from_yaml():
    import os
    ansible_test_data_path = os.path.join(os.path.dirname(__file__), '..', 'unit', 'test_data')
    test_case_0_data_path = os.path.join(ansible_test_data_path, 'test_case_0.txt')
    with open(test_case_0_data_path, 'rb') as test_case_0_data_file:
        bytes_0 = test_case_0_data_file.read()

    var_0 = from_yaml(bytes_0)

# Generated at 2022-06-25 04:26:58.989370
# Unit test for function from_yaml
def test_from_yaml():
    sl_0 = b'hello world'
    var_0 = from_yaml(sl_0)
    test_case_0()


# Generated at 2022-06-25 04:27:10.299769
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    assert var_0 == None

    bytes_1 = b'g\xab\x0e\xf4\xd8\x9dx4\x08\xbb3W\xb8\x19\x83\xcd\x1f\xf8\x1b\xac\x9b'
    var_1 = from_yaml(bytes_1)
    assert var_1 == None


# Generated at 2022-06-25 04:27:17.869727
# Unit test for function from_yaml

# Generated at 2022-06-25 04:27:23.498347
# Unit test for function from_yaml
def test_from_yaml():
    assert True


# Generated at 2022-06-25 04:27:25.060502
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:27:29.101340
# Unit test for function from_yaml
def test_from_yaml():
    func_return_value = None  # default return value

    # Call function: from_yaml
    try:
        func_return_value = from_yaml()
    except Exception as exception:
        assert False
    else:
        assert True



# Generated at 2022-06-25 04:27:37.507766
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    var_1 = from_yaml(var_0)
    # TODO: compare with var_0

if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:27:40.234185
# Unit test for function from_yaml
def test_from_yaml():
    ansible_yaml_bytes = b"---\n  - {host: localhost}\n\n---\n- {host: localhost}"

    from_yaml(ansible_yaml_bytes)

    test_case_0()

# Generated at 2022-06-25 04:27:44.741733
# Unit test for function from_yaml
def test_from_yaml():
    with pytest.raises(AnsibleParserError):
        test_case_0()

# Generated at 2022-06-25 04:27:48.308743
# Unit test for function from_yaml
def test_from_yaml():

    # Test cases
    print("Test case 0")
    test_case_0()

# Execute unit tests
if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:27:54.416873
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:04.347524
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'

# Generated at 2022-06-25 04:28:10.138256
# Unit test for function from_yaml
def test_from_yaml():
    stream_0 = b'[{  "attributes": {  "key1": "value1",  "key2": "value2"  },  "name": "test_1"  }, {  "attributes": {  "key1": "value1",  "key2": "value2"  },  "name": "test_2"}]'
    var_0 = from_yaml(stream_0)
    assert var_0 == [{'attributes': {'key2': 'value2', 'key1': 'value1'}, 'name': 'test_1'}, {'attributes': {'key2': 'value2', 'key1': 'value1'}, 'name': 'test_2'}]


# Generated at 2022-06-25 04:28:14.874461
# Unit test for function from_yaml
def test_from_yaml():
    print('Testing function from_yaml')
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:28:20.219052
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'\x0c\x05alias\x02\x03foo\x06bar\x12\x03\x05mike') == {'alias': [{'foo': 'bar'}, 'mike']}

# Generated at 2022-06-25 04:28:28.259241
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:33.031180
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\xc1\x19\xa6\x8d\x17\x1b\xc0\xa8\x98\xa5\x18\x0c\xd8\x81\x1d\x7f\x9b'
    var_0 = from_yaml(bytes_0)

# Generated at 2022-06-25 04:28:44.359267
# Unit test for function from_yaml
def test_from_yaml():
    print("Testing from_yaml")

    assert type(from_yaml(b'---\n- 1\n- 2\n- 3\n')) == list
    assert type(from_yaml(b'---\n1: one\n2: two\n3: three\n')) == dict
    assert type(from_yaml(b'---\n{}\n')) == dict
    assert type(from_yaml(b'---\n[]\n')) == list
    assert type(from_yaml(b'---\ntrue\n')) == bool
    assert type(from_yaml(b'---\n1.1\n')) == float
    assert type(from_yaml(b'---\n1.1')) == float

# Generated at 2022-06-25 04:28:46.345685
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'?') == from_yaml(b'?')

# Generated at 2022-06-25 04:28:48.901180
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True

# vi: ft=python:et:ts=4:sts=4:sw=4

# Generated at 2022-06-25 04:28:49.288885
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-25 04:29:00.317950
# Unit test for function from_yaml
def test_from_yaml():
    # Testing for YAML parsing
    assert from_yaml("---\nfoo: bar") == {"foo": "bar"}, "Simple YAML test failed"

    # Testing for JSON parsing
    assert from_yaml("{\"foo\": \"bar\"}") == {"foo": "bar"}, "Simple JSON test failed"

    # Testing for default value in JSONDecoder
    assert from_yaml("", json_only=True) == {}, "JSON default value test failed"

    # Testing for missing required key
    try:
        from_yaml("{}")
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML" in e.message, "JSON required key test failed"

    # Testing for Unexpected YAML errors

# Generated at 2022-06-25 04:29:10.737105
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import json
        import yaml
        from ansible.parsing.yaml.loader import AnsibleLoader
        from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
        from ansible.parsing.ajson import AnsibleJSONDecoder
    except ImportError:
        # skip if not all dependencies are installed
        import sys
        print("Skipping since import failed: {0}".format(sys.exc_value), file=sys.stderr)
        sys.exit(0)

    # ansible_module_generated
    bytes_0 = b'---\n- hosts: localhost\n  tasks:\n    - ping:  {\n\n}'
    var_0 = from_yaml(bytes_0)

    # ansible_module_generated
    bytes_

# Generated at 2022-06-25 04:29:16.340218
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    assert var_0 
    assert var_0



# Generated at 2022-06-25 04:29:22.880104
# Unit test for function from_yaml
def test_from_yaml():
    data = b'[1, 2, 3]\n'
    file_name = '<string>'
    show_content = True
    vault_secrets = None
    json_only = False
    assert from_yaml(data, file_name, show_content, vault_secrets, json_only)


if __name__ == "__main__":
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:29:32.040769
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b"---\n") == None
    assert from_yaml(b'--- {}\n') == {}
    assert from_yaml(b'--- [1,2,3]\n') == [1, 2, 3]
    assert from_yaml(b'--- !\n') == None
    assert from_yaml(b'--- #\n') == None
    assert from_yaml(b'--- !!\n') == None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:29:42.526280
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b'[]') == []
    assert from_yaml(b'[ ]') == []
    assert from_yaml(b'[a]') == ['a']

    assert from_yaml(b'{}') == {}
    assert from_yaml(b'{ }') == {}
    assert from_yaml(b'{a: b}') == {'a': 'b'}

    assert from_yaml(b'test') == 'test'
    assert from_yaml(b'123') == 123
    assert from_yaml(b'1.23') == 1.23
    assert from_yaml(b'_123') == '_123'
    assert from_yaml(b'"test"') == 'test'

# Generated at 2022-06-25 04:29:45.802866
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'{\r\n  "name": "James"\r\n}\r\n'
    assert from_yaml(bytes_0) == {'name': 'James'}

    # This should raise an exception
    bytes_0 = b']\x9d\x06\x12|/\xfa\xa2N'
    from_yaml(bytes_0)

# Generated at 2022-06-25 04:29:51.550323
# Unit test for function from_yaml
def test_from_yaml():
    data = b'---\nvault_password_file: ../vault_pass'
    file_name = '<string>'
    show_content = True
    vault_secrets = None
    json_only = False
    test_case_0()

# Generated at 2022-06-25 04:29:57.994887
# Unit test for function from_yaml
def test_from_yaml():
    data = b'#!/usr/bin/env python\n# encoding: utf-8\n{\n    "_meta": {\n        "hostvars": {\n            "hostname": {\n            }\n        }\n    },\n    "all": {\n        "children": [\n            "group",\n            "ungrouped"\n        ]\n    },\n    "group": {\n        "children": [\n            "subgroup"\n        ]\n    },\n    "subgroup": {\n        "children": []\n    },\n    "ungrouped": {\n        "children": []\n    }\n}\n'

# Generated at 2022-06-25 04:30:09.572900
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    if PY3:
        return


# Generated at 2022-06-25 04:30:16.121174
# Unit test for function from_yaml
def test_from_yaml():
    var_1 = {'a': 'b'}
    var_0 = from_yaml(var_1)
    assert('a' in var_0)

# Generated at 2022-06-25 04:30:26.484563
# Unit test for function from_yaml

# Generated at 2022-06-25 04:30:33.916245
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    assert repr(var_0) == "b'?]\\x9d\\x06\\x12|/\\xfa\\xa2N'"



# Generated at 2022-06-25 04:30:43.657819
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    bytes_1 = b'\xce\xc7\xadx\x8fS\xf9\x9b\xec'
    var_1 = from_yaml(bytes_1)
    bytes_2 = b'\xba\x92\x1b\x85\x1b\xec\x04\x93'
    var_2 = from_yaml(bytes_2)
    bytes_3 = b'3\x06\xbd\x8b#\x9f\x1e:T'
    var_3 = from_yaml(bytes_3)

# Generated at 2022-06-25 04:30:44.875053
# Unit test for function from_yaml
def test_from_yaml():
    # Runs the unit test
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)

# Generated at 2022-06-25 04:30:50.544852
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)

# Generated at 2022-06-25 04:30:58.201636
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(b'[]')
    from_yaml(b'{}')
    from_yaml(b'{"foo":"bar"}')
    from_yaml(b'{"foo":"bar","asd":"sdf","number":1.2}')
    from_yaml(b"{'foo':'bar'}")
    from_yaml(b"{'foo':'bar','asd':'sdf','number':1.2}")
    from_yaml(b'{\n  "foo": "bar"\n}')
    from_yaml(b'{\n  "foo": "bar",\n  "asd": "sdf",\n  "number": 1.2\n}')
    from_yaml(b"[]")

# Generated at 2022-06-25 04:31:00.666069
# Unit test for function from_yaml
def test_from_yaml():
  # (str, str, bool, Optional[List[str]], bool) -> Any
  from_yaml('foo', 'bar')
  print("Returns valid data")

# Generated at 2022-06-25 04:31:02.754278
# Unit test for function from_yaml
def test_from_yaml():
    buffer = 'a: 1'
    result = from_yaml(buffer)

    assert result == {'a': 1}, 'from_yaml did not return the expected result'



# Generated at 2022-06-25 04:31:10.590749
# Unit test for function from_yaml
def test_from_yaml():
    # Test case with "bytes" as an input.
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    # Test case with "bool" as an input.
    arg_1 = True
    var_1 = from_yaml(arg_1)
    # Test case with "str" as an input.
    str_0 = "w)\xbb\xdf\x98Y\xd8\x1f\xf3\x9b\x97n"
    var_2 = from_yaml(str_0)
    # Test case with "float" as an input.
    arg_3 = -31.941491
    var_3 = from_yaml(arg_3)
    #

# Generated at 2022-06-25 04:31:15.246892
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)
    var_1 = from_yaml('#x')


if __name__ == '__main__':
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:31:22.265101
# Unit test for function from_yaml

# Generated at 2022-06-25 04:31:27.845144
# Unit test for function from_yaml
def test_from_yaml():
    # Test case #0
    try:
        test_case_0()
    except Exception:
        pass



# Generated at 2022-06-25 04:31:31.674138
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?]\x9d\x06\x12|/\xfa\xa2N'
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:31:32.206576
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:31:35.140151
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'?'
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:31:42.361111
# Unit test for function from_yaml
def test_from_yaml():
    import inspect
    import sys
    import os
    import itertools

    # The traceback module might not be available on 2.6
    import traceback

    # The doctest module is not available in 2.6
    import doctest
    class DummyImportLib(object):
        def import_module(self, modulename, package=None):
            if modulename == '_json':
                return json
            raise ImportError('Not found')
    from ansible.compat.six import PY3
    if PY3:
        from importlib import reload
    else:
        reload = reload

    old_import_module = __import__
    try:
        __builtins__.__import__ = DummyImportLib().import_module
        reload(from_yaml)
    except ImportError:
        traceback.print