

# Generated at 2022-06-25 04:21:48.623608
# Unit test for function from_yaml
def test_from_yaml():
    try:
        expected = None
        file_name = '<string>'
        show_content = False
        vault_secrets = None
        json_only = False
        actual = from_yaml(file_name, json_only, show_content, vault_secrets)
        assert actual == expected
    except AssertionError as e:
        print(e)



# Generated at 2022-06-25 04:21:58.264134
# Unit test for function from_yaml
def test_from_yaml():

    str_0 = 'a: 1'
    var_0 = from_yaml(str_0)
    print(var_0)
    assert var_0 == {'a': 1}

    str_1 = 'b: 2'
    var_1 = from_yaml(str_1, vault_secrets=None)
    print(var_1)
    assert var_1 == {'b': 2}

    str_2 = 'c: 3'
    var_2 = from_yaml(str_2, show_content=False, json_only=False)
    print(var_2)
    assert var_2 == {'c': 3}

    str_3 = 'd: 4'

# Generated at 2022-06-25 04:22:07.991978
# Unit test for function from_yaml
def test_from_yaml():
    # Set up test inputs
    str_0 = 'Nl?B1#'
    str_1 = 'abc'
    str_2 = '\\u263a'
    str_3 = '\\U0001F600'
    str_4 = 'a\\u003db'
    str_5 = 'a\\u003db'
    str_6 = 'foo\x00bar'
    str_7 = 'foo \x00 bar'

    # Perform the test
    var_0 = from_yaml(str_0)
    var_1 = from_yaml(str_1)
    var_2 = from_yaml(str_2)
    var_3 = from_yaml(str_3)
    var_4 = from_yaml(str_4)

# Generated at 2022-06-25 04:22:19.286349
# Unit test for function from_yaml
def test_from_yaml():
    str_0 = 'c3RyaW5n'
    var_0 = from_yaml(str_0)
    assert var_0 == 'string'
    str_1 = 'ImEgc3RyaW5nIg=='
    var_1 = from_yaml(str_1)
    assert var_1 == 'a string'
    str_2 = 'ImEgc3RyaW5nIg=='
    var_2 = from_yaml(str_2)
    assert var_2 == 'a string'
    str_3 = 'ImEgc3RyaW5nIg=='
    var_3 = from_yaml(str_3)
    assert var_3 == 'a string'

# Generated at 2022-06-25 04:22:20.641442
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('Yg?M"') == 'Yg?M"'



# Generated at 2022-06-25 04:22:23.106097
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = test_case_0()

# MAIN
if __name__ == '__main__':
    test_from_yaml()
    print("Done")

# Generated at 2022-06-25 04:22:25.818380
# Unit test for function from_yaml
def test_from_yaml():
    assert True


if __name__ == '__main__':
    # Run unit tests
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:22:27.287358
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = 'Nl?B1#'
    assert from_yaml(var_0) == None



# Generated at 2022-06-25 04:22:28.420324
# Unit test for function from_yaml
def test_from_yaml():
    assert str(test_case_0()) == 'Nl?B1#'

# Generated at 2022-06-25 04:22:31.066645
# Unit test for function from_yaml
def test_from_yaml():

    # Testing with a string
    test_from_yaml_str_0()

    # Testing with a unicode string
    test_from_yaml_str_1()

# Testing with a string

# Generated at 2022-06-25 04:22:39.443519
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)
    assert var_0 == [1, 2, 3, 4, 5, False, True]
    bytes_1 = b'\x8e\x01\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x04\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00'
    var_1 = from_yaml(bytes_1)
    assert var_1 == [1, 2, 3, 4, 5, False, True]

# Generated at 2022-06-25 04:22:50.381785
# Unit test for function from_yaml

# Generated at 2022-06-25 04:22:58.765739
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(b'%YAML 1.1\n---\n{}\n...\n')
    from_yaml(b'{}')
    from_yaml(b'[{}, {}]')
    from_yaml(b'{"a": "a"}')
    from_yaml(b'[{"a": "a"}]')
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)

# Generated at 2022-06-25 04:23:00.804321
# Unit test for function from_yaml
def test_from_yaml():
    # Test case for function from_yaml
    assert test_case_0() == None

# Generated at 2022-06-25 04:23:13.153038
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'YWJjZA=='
    str_0 = 'a'
    str_1 = 'ANSIBLE_STDOUT_CALLBACK'
    str_2 = 'as'
    str_3 = 'b'
    str_4 = 'nocows'
    int_0 = 64
    int_1 = 64

# Generated at 2022-06-25 04:23:21.755408
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml(b'foobar') == u'foobar')
    assert(from_yaml(u'foobar') == u'foobar')
    assert(from_yaml(b'42') == 42)
    assert(from_yaml(u'42') == 42)
    assert(from_yaml(b'42.5') == 42.5)
    assert(from_yaml(u'42.5') == 42.5)
    assert(from_yaml(b'foo\nbar') == 'foo\nbar')
    assert(from_yaml(u'foo\nbar') == 'foo\nbar')
    assert(from_yaml(b'{"foo":"bar"}') == {u'foo': u'bar'})

# Generated at 2022-06-25 04:23:25.318219
# Unit test for function from_yaml
def test_from_yaml():
    t = test_case_0()
    assert t

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:23:29.181817
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:23:36.059952
# Unit test for function from_yaml
def test_from_yaml():
    res = from_yaml('foo: bar')
    assert res == {"foo": "bar"}

    res = from_yaml('foobar')
    assert res == "foobar"

    res = from_yaml('true')
    assert res is True

    res = from_yaml('false')
    assert res is False

    res = from_yaml('null')
    assert res is None

    res = from_yaml('- foo')
    assert res == ["foo"]

    res = from_yaml('- foo\n- bar')
    assert res == ["foo", "bar"]

    res = from_yaml('foo: bar\nbar: baz')
    assert res == {"foo": "bar", "bar": "baz"}


# Generated at 2022-06-25 04:23:48.117903
# Unit test for function from_yaml
def test_from_yaml():

    # novault
    yamlstr = '{"a": "!vault |\n      $ANSIBLE_VAULT;1.2;AES256;ansible\n      653964633166383539666437623963363566373465633739643238633932656330386332386335323\n      863623831366131613331346165636339653563346339626664666332626666656161363137613761\n      6337623661366436356134643037356434365a643363613165383561316336623731666262623231\n      65653065383338343966303437666565346639393366363835\n      "}\n'
    var_

# Generated at 2022-06-25 04:23:56.895322
# Unit test for function from_yaml
def test_from_yaml():
    # Testing 'bytes_0' for from_yaml
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)
    bytes_1 = b'\x92\xa6first\xb6second'
    var_1 = from_yaml(bytes_1)
    bytes_2 = b'\x92\xa3one\xa3two'
    var_2 = from_yaml(bytes_2)
    bytes_3 = b'\x92\xa6{ foo: bar, baz: qux }\xa6{ foo: bar, baz: qux }'
    var_3 = from_yaml(bytes_3)

# Generated at 2022-06-25 04:23:58.920543
# Unit test for function from_yaml
def test_from_yaml():
    # test for function from_yaml

    # Test for function from_yaml
    assert True



# Generated at 2022-06-25 04:23:59.524964
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:24:00.851401
# Unit test for function from_yaml
def test_from_yaml():

    # Test case 0
    test_case_0()


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:24:11.198290
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()
    try:
        import runpy
        runpy.run_module(__name__, run_name='__main__')
    except ImportError:
        # Probably python 3.4
        import runpy
        runpy.run_module(__name__, run_name='__main__', altargv=['from_yaml.py'])

if __name__ == '__main__':
    import sys
    import traceback
    try:
        test_from_yaml()
    except Exception as exc:
        print(exc)
        traceback.print_exc(file=sys.stdout)
        sys.exit(1)

# Generated at 2022-06-25 04:24:19.182877
# Unit test for function from_yaml

# Generated at 2022-06-25 04:24:23.710785
# Unit test for function from_yaml
def test_from_yaml():

    test_case_0()


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    test_from_yaml()
    AnsibleModule(argument_spec={}).exit_json(changed=True)

# Generated at 2022-06-25 04:24:26.281624
# Unit test for function from_yaml
def test_from_yaml():
    # FIXME: see test_case_0()
    assert True == True


# Generated at 2022-06-25 04:24:35.855254
# Unit test for function from_yaml
def test_from_yaml():

    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)

    unicode_0 = u'2d.4^'
    bytes_1 = b"\x8f\x91\x0f\x02'+\xb8\xfd"
    bytes_2 = b'[\x8c\xfd\xa2\x03\xeb\xec\x13p'
    bytes_3 = b"\x8f\x91\x0f\x02'+\xb8\xfd"
    bytes_4 = b'\x8e\x85\x1b\xcb\xde\xe2\x13%'

# Generated at 2022-06-25 04:24:39.072263
# Unit test for function from_yaml
def test_from_yaml():
    assert True


# Generated at 2022-06-25 04:24:56.221298
# Unit test for function from_yaml
def test_from_yaml():

    print('test_from_yaml')
    from_yaml(to_native(None), file_name=u'<string>', show_content=True, vault_secrets=None, json_only=False)
    from_yaml('', file_name=u'<string>', show_content=True, vault_secrets=None, json_only=False)
    from_yaml(to_native(None), file_name=u'<string>', show_content=True, vault_secrets=None, json_only=False)
    from_yaml('', file_name=u'<string>', show_content=True, vault_secrets=None, json_only=False)

# Generated at 2022-06-25 04:25:02.972014
# Unit test for function from_yaml
def test_from_yaml():
    import base64
    encoded_0 = b'\x8e[\x02>(\xb9'

    bytes_0 = base64.b64decode(encoded_0)

    var_0 = from_yaml(bytes_0)

# Generated at 2022-06-25 04:25:04.963830
# Unit test for function from_yaml
def test_from_yaml():
    TestCaseList = [test_case_0]
    for TestCase in TestCaseList:
        TestCase()

# Generated at 2022-06-25 04:25:07.869934
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)



# Generated at 2022-06-25 04:25:09.932411
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()

# End of Unit test for function from_yaml

# Generated at 2022-06-25 04:25:20.034026
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x0c\x00\x00\x00\x00\x00\x00\x00"\x00\x00\x00\x00\x00\x00\x00\x00'
    assert from_yaml(bytes_0) == 2.2
    var_1 = from_yaml(b'- \x00\x00\x00A\x00\x00\x00')
    assert var_1 == 'A'
    var_2 = from_yaml(b'\x0c\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00')
    assert var_2 == 3.2
    var_3 = from_y

# Generated at 2022-06-25 04:25:22.206179
# Unit test for function from_yaml

# Generated at 2022-06-25 04:25:28.016209
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)
    assert isinstance(var_0, dict)
    bytes_1 = b'\xe6\x1b\xd9\xc8\xba\xb6'
    var_1 = from_yaml(bytes_1)
    assert isinstance(var_1, dict)
    bytes_2 = b'\xa2\x1a\x06\x01\xa0%\xd4'
    var_2 = from_yaml(bytes_2)
    assert isinstance(var_2, dict)
    bytes_3 = b'\xa2\x1a\x06\x01\xa0%\xd4'

# Generated at 2022-06-25 04:25:29.877589
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml(b'[\x8e[\x02>(\xb9')

# Generated at 2022-06-25 04:25:34.874011
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)
    assert var_0 is not None
    assert var_0 == [2, 3, 4]

# Generated at 2022-06-25 04:26:04.403483
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    # Call function from_yaml
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:26:14.559624
# Unit test for function from_yaml
def test_from_yaml():
    # Test case 1
    bytes_0 = b'!\x9e\xd3\x01\x00\x00\x00'
    var_0 = from_yaml(bytes_0)
    assert var_0 == "!\x9e\xd3\x01\x00\x00\x00"

    # Test case 2
    bytes_1 = b'\x93\x01\x00\x00\x00\x93\x02\x00\x00\x00\x93\x03\x00\x00\x00'
    var_1 = from_yaml(bytes_1)

# Generated at 2022-06-25 04:26:26.094536
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    file_name = 'test_file'
    vault_secrets = dict()

    # Test from_yaml with bytes as input, should return an AnsibleMapping.
    var_0 = from_yaml(b'a: b')
    assert isinstance(var_0, AnsibleMapping)

    # Test from_yaml with a single string, should return a string.
    var_1 = from_yaml('hello')
    assert isinstance(var_1, str)

    # Test from_yaml with a different string, should return a string.
    var_2 = from_yaml('world')

# Generated at 2022-06-25 04:26:33.639625
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)
    assert isinstance(var_0, list)
    assert var_0 == [2, ">("]
    bytes_1 = b'\x82\xa3key\xa3val'
    var_1 = from_yaml(bytes_1)
    assert isinstance(var_1, dict)
    assert var_1 == {"key": "val"}
    bytes_2 = b'\x82\xa3key\xa3bar'
    var_2 = from_yaml(bytes_2)
    assert isinstance(var_2, dict)
    assert var_2 == {"key": "bar"}

# Generated at 2022-06-25 04:26:44.475320
# Unit test for function from_yaml
def test_from_yaml():
    data_1 = '!vars\nalibrary: &alibrary\n  name: "my_library"\n  src: "https://..."\n  version: "1.0"\n\nlibraries:\n  - *alibrary\n'
    file_name_1 = '<string>'
    show_content_1 = True
    vault_secrets_1 = None
    json_only_1 = False
    test_case_0(from_yaml(data_1, file_name_1, show_content_1, vault_secrets_1, json_only_1))
    data_2 = '3\n'
    file_name_2 = '<string>'
    show_content_2 = True
    vault_secrets_2 = None
    json_only_2 = False
    test

# Generated at 2022-06-25 04:26:45.309069
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:26:55.898215
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from ansible.module_utils._text import to_native
    from ansible.errors import AnsibleParserError
    from ansible.errors.yaml_strings import YAML_SYNTAX_ERROR
    import json
    import unittest
    from yaml import YAMLError
    from test._common import yaml_files, yaml_failure_files

    class TestCase0(unittest.TestCase):
        def test_0(self):
            bytes_0 = b'\x8e[\x02>(\xb9'
            var_0 = from_

# Generated at 2022-06-25 04:27:03.935570
# Unit test for function from_yaml
def test_from_yaml():
    # Conversion from byte to unicode failed in case
    # of a zero length byte string.
    test_case_0()


if __name__ == '__main__':
    import sys
    import logging
    logging.basicConfig(level=logging.DEBUG)
    from ansible.module_utils.common.yaml import from_yaml

    for _file in sys.argv[1:]:
        logging.debug('Loading: %s', _file)
        with open(_file, 'r') as f:
            logging.debug(from_yaml(f.read()))

# Generated at 2022-06-25 04:27:13.160967
# Unit test for function from_yaml
def test_from_yaml():
    fixture_0 = {'key_0': [True, False, True], 'key_1': [u'\u05d7', u'\u05d7', u'\u05d7', u'\u05d7', u'\u05d7', u'\u05d7', u'\u05d7', u'\u05d7', u'\u05d7', u'\u05d7']}
    fixture_1 = {'key_0': [False, True, False], 'key_1': [u'\u062d', u'\u062d', u'\u062d', u'\u062d']}

# Generated at 2022-06-25 04:27:21.008545
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleBaseLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)
    assert isinstance(var_0, AnsibleMapping)
    bytes_1 = b'\xf1\x8e\xe6\x9d\x02\x8e\x02>\xf2(\xb9'
    var_1 = from_yaml(bytes_1)
    assert isinstance(var_1, AnsibleMapping)


test_case_0()

# Generated at 2022-06-25 04:28:02.981473
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib

    vault_secrets = [VaultLib.parse('vault_password.txt', open('test/unit/test_test_data/test_vault_password.txt').read())]
    data = """
    foo:
      bar: baz
      list:
        - 1
        - 2
        - 3
    """
    fname = 'testfile.yaml'
    test_data = from_yaml(data, fname, False, vault_secrets)
    assert test_data == {'foo': {'bar': 'baz', 'list': [1, 2, 3]}}

# Generated at 2022-06-25 04:28:04.632575
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "a": "b"}'
   
    new_data = from_yaml(data)
    assert new_data == {"a": "b"}


if __name__ == '__main__':
    test_from_yaml()
    test_case_0()

# Generated at 2022-06-25 04:28:10.287359
# Unit test for function from_yaml
def test_from_yaml():
    data_0 = "{a: 1, b: 2, c: 3, d: 4, e: 5}"
    var_0 = from_yaml(data_0)
    assert(var_0.get('a') == 1)
    assert(var_0.get('b') == 2)
    assert(var_0.get('c') == 3)
    assert(var_0.get('d') == 4)
    assert(var_0.get('e') == 5)
    data_1 = "[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]"
    var_1 = from_yaml(data_1)
    assert(var_1[0] == 1)
    assert(var_1[1] == 2)
    assert(var_1[2] == 3)
   

# Generated at 2022-06-25 04:28:14.753733
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)
    # Place holder to ensure the test actually ran
    assert True



# Generated at 2022-06-25 04:28:19.635119
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)
    assert var_0 is not None

# Generated at 2022-06-25 04:28:20.394504
# Unit test for function from_yaml
def test_from_yaml():
    assert True == True



# Generated at 2022-06-25 04:28:28.350122
# Unit test for function from_yaml
def test_from_yaml():
    data = '---\n- 1\n- 2\n- 3\n'
    data_obj = from_yaml(data)
    assert data_obj == [1, 2, 3]

    data = '{"abool": true, "afloat": 3.5, "aninteger": 0, "anull": null}'
    data_obj = from_yaml(data)
    assert data_obj == {
        'abool': True,
        'afloat': 3.5,
        'anull': None,
        'aninteger': 0
    }

    data = '{"0": true, "1": false, "2": null}'
    data_obj = from_yaml(data)

# Generated at 2022-06-25 04:28:41.726874
# Unit test for function from_yaml

# Generated at 2022-06-25 04:28:44.578307
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:28:48.711443
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo') == 'foo'
    # FIXME: need to write more test cases

# vim: expandtab tabstop=4 shiftwidth=4 autoindent

# Generated at 2022-06-25 04:29:24.606031
# Unit test for function from_yaml
def test_from_yaml():
    assert True

# Generated at 2022-06-25 04:29:28.978236
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'
    var_0 = from_yaml(bytes_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:29:38.214204
# Unit test for function from_yaml
def test_from_yaml():

    # From JSON
    data_0 = '{"foo": "bar"}'
    var_0 = from_yaml(data_0)
    assert var_0 == {'foo': 'bar'}

    # From YAML
    data_1 = '---\nfoo: bar'
    var_1 = from_yaml(data_1)
    assert var_1 == {'foo': 'bar'}

    # Error
    import io
    with io.StringIO() as sentinel:
        sentinel.write('hello, world\n')
        sentinel.seek(0)

# Generated at 2022-06-25 04:29:48.333367
# Unit test for function from_yaml
def test_from_yaml():
    data = b'\x8e[\x02>(\xb9'
    file_name = '<inline>'
    show_content = True
    vault_secrets = None
    json_only = False

    # test error conditions
    try:
        from_yaml(data, file_name=file_name, show_content=show_content, vault_secrets=vault_secrets, json_only=json_only)
    except AnsibleParserError as e:
        assert e.message == "We were unable to read either as JSON nor YAML, these are the errors we got from each:\n" \
                               "JSON: %s\n\n%s" % (to_native(e.orig_exc), 'Invalid control character at: line 1 column 0')
        assert e.obj is None

# Generated at 2022-06-25 04:29:54.625806
# Unit test for function from_yaml
def test_from_yaml():
    var_0 = from_yaml('- foo')
    assert var_0 == [u'foo']

    var_1 = from_yaml('-\n foo')
    assert var_1 == [u'foo']

    var_2 = from_yaml('-\n - foo\n - bar')
    assert var_2 == [u'foo', u'bar']

    var_3 = from_yaml('a: 1')
    assert var_3 == {u'a': 1}

    var_4 = from_yaml('a: 1,\n b: 2')
    assert var_4 == {u'a': 1, u'b': 2}

    var_5 = from_yaml('a: {b: 2}')
    assert var_5 == {u'a': {u'b': 2}}



# Generated at 2022-06-25 04:29:55.397357
# Unit test for function from_yaml
def test_from_yaml():
    assert True # TODO: implement your test here

# Generated at 2022-06-25 04:29:57.104979
# Unit test for function from_yaml
def test_from_yaml():
    print('test from yaml')
    test_case_0()

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:29:57.879952
# Unit test for function from_yaml
def test_from_yaml():
    assert test_case_0() == None

# Generated at 2022-06-25 04:30:03.873123
# Unit test for function from_yaml
def test_from_yaml():
    # bytes_0 = b'\x8e[\x02>(\xb9'
    bytes_0 = b''
    var_0 = from_yaml(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_from_yaml()

# Generated at 2022-06-25 04:30:05.524037
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e\x15\xe2\x02>(X\xb9A'
    var_0 = from_yaml(bytes_0)


# Generated at 2022-06-25 04:30:48.325581
# Unit test for function from_yaml
def test_from_yaml():
    # Get the path of the test data file
    import os.path
    tdata = os.path.join(os.path.dirname(__file__), "test_from_yaml.json")
    with open(tdata, "r") as f:
        tlist = json.load(f)


    for tdict in tlist:
        # print("Test case %s" % tdict["test_id"])
        try:
            var = from_yaml(tdict["data"])
        except:
            print("Test case %s failed" % tdict["test_id"])
            raise

        # Check whether the parsed data is the same as the expected data
        assert var == tdict["expect"]

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:30:54.600689
# Unit test for function from_yaml
def test_from_yaml():
    inp_0 = (b"\x8e\x02\x9e\xa4\x04\x8d\x03\xaa\x04'\n",)
    var_0 = from_yaml(inp_0)



# Generated at 2022-06-25 04:30:58.291728
# Unit test for function from_yaml
def test_from_yaml():
    test_case_0()
    
if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-25 04:31:06.308897
# Unit test for function from_yaml
def test_from_yaml():

    # AssertionError: <class 'ansible.parsing.yaml.objects.AnsibleUnicode'> != <class 'str'>
    assert from_yaml('') == None
    # AssertionError: <class 'ansible.parsing.yaml.objects.AnsibleUnicode'> != <class 'str'>
    assert from_yaml('', json_only=True) == None
    # AssertionError: <class 'ansible.parsing.yaml.objects.AnsibleUnicode'> != <class 'str'>
    assert from_yaml('', vault_secrets=None, json_only=True) == None
    # AssertionError: <class 'ansible.parsing.yaml.objects.AnsibleUnicode'> != <class 'str'>

# Generated at 2022-06-25 04:31:17.405535
# Unit test for function from_yaml

# Generated at 2022-06-25 04:31:19.249055
# Unit test for function from_yaml
def test_from_yaml():
    print(test_case_0())
    print("test_from_yaml(): ")

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-25 04:31:26.398368
# Unit test for function from_yaml
def test_from_yaml():
    data = "---\n" \
           "foo:\n" \
           "   bar: 'baz'\n" \
           "qux: 'quux'"
    file_name = "/path/to/file.yml"
    result = from_yaml(data, file_name)
    assert result == {'foo': {'bar': 'baz'}, 'qux': 'quux'}



# Generated at 2022-06-25 04:31:36.854190
# Unit test for function from_yaml

# Generated at 2022-06-25 04:31:43.463553
# Unit test for function from_yaml
def test_from_yaml():
    bytes_0 = b'\x8e[\x02>(\xb9'

    try:
        from_yaml(bytes_0)
    except AnsibleParserError as e:
        assert(e.show_content is True)
        assert(e.file_name == '<string>')
        assert(e.obj.ansible_pos == (None,0,0))
        var_0 = e.orig_exception
        assert(isinstance(var_0, YAMLError))
    else:
        assert(False)

    try:
        from_yaml(b'{}', json_only=True)
    except AnsibleParserError as e:
        assert(isinstance(e.orig_exception, StopIteration))
    else:
        assert(False)


# unit test for function _