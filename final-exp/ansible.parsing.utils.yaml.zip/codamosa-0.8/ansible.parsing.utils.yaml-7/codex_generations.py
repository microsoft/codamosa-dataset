

# Generated at 2022-06-11 09:04:41.018834
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import unittest

    # Support Python 2.6
    if sys.version_info[0] == 2 and sys.version_info[1] <= 6:
        import unittest2 as unittest

    class MyTestCase(unittest.TestCase):
        def test_from_yaml(self):
            # Test YAML
            data = "a_string_var: hello\n"
            new_data = from_yaml(data)
            self.assertEqual(new_data, {u'a_string_var': u'hello'})

            # Test JSON
            data = '{"a_string_var": "hello", "key2": "value2"}'
            new_data = from_yaml(data)

# Generated at 2022-06-11 09:04:51.764241
# Unit test for function from_yaml
def test_from_yaml():
    stream = "This is a test"
    ansible_yaml = from_yaml(stream, file_name='test_from_yaml')
    assert ansible_yaml == 'This is a test'
    stream = "This is a test : ':' is an invalid yaml character"
    ansible_yaml = from_yaml(stream, file_name='test_from_yaml')
    assert ansible_yaml == 'This is a test : \':\' is an invalid yaml character'
    stream = '{ "this": "is json" }'
    ansible_yaml = from_yaml(stream, file_name='test_from_yaml', json_only=True)
    assert ansible_yaml == {"this": "is json"}
    # TODO: implement a test for vault encryption use case

   

# Generated at 2022-06-11 09:05:05.399079
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils import basic

    assert from_yaml('{ "a": "b" }') == { 'a': 'b' }
    assert from_yaml('{"a": "b"}') == { 'a': 'b' }
    assert from_yaml('{ "a": "b" }', json_only=True) == { 'a': 'b' }
    assert from_yaml('{"a": "b"}', json_only=True) == { 'a': 'b' }
    assert from_yaml('{ "a": "b" }', json_only=True) == { 'a': 'b' }
    assert from_yaml('{"a": "b"}', json_only=True) == { 'a': 'b' }

# Generated at 2022-06-11 09:05:13.507270
# Unit test for function from_yaml
def test_from_yaml():
    expected = {'testing': True, 'id': 2, 'foos': [{'name': 'foo', 'id': 1}, {'name': 'foo', 'id': 1}]}
    result = from_yaml('{"testing": true, "id": 2, "foos":[{"name": "foo", "id": 1}, {"name": "foo", "id": 1}]}')
    assert result == expected

    result = from_yaml('{"testing": true, "id": 2, "foos":[{"name": "foo", "id": 1}, {"name": "foo", "id": 1}]}\n')
    assert result == expected

    expected = {'testing': True, 'id': 2, 'foos': {'name': 'foo', 'id': 1}}

# Generated at 2022-06-11 09:05:24.890107
# Unit test for function from_yaml
def test_from_yaml():
    match = True
    match = match and is_equal("{'number': 1, 'item': {'name': 'foo', 'count': 2}}", from_yaml("{'number': 1, 'item': {'name': 'foo', 'count': 2}}"))
    match = match and is_equal("{'number': 1, 'item': {'name': 'foo', 'count': 2}}", from_yaml("{number: 1, item: {name: 'foo', count: 2}}"))
    match = match and is_equal("{'number': 1, 'item': {'name': 'foo', 'count': 2}}", from_yaml("{'number': 1, item: {name: 'foo', count: 2}}"))

# Generated at 2022-06-11 09:05:29.298014
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('''
- hosts: localhost
  tasks:
  - name: test
    debug: msg="hello world"
''')
    assert result is not None
    assert type(result[0]) is dict
    assert result[0]['hosts'] == 'localhost'

# Generated at 2022-06-11 09:05:37.507742
# Unit test for function from_yaml
def test_from_yaml():
    # string data
    data_str = '''
    - hosts: all
      gather_facts: false
      tasks:
        - name: test copy
          copy:
            src: /etc/hosts
            dest: /tmp/hosts
            owner: root
            group: root
            mode: '0644'
    '''
    from_yaml(data_str)
    # int data
    data_int =123
    from_yaml(data_int)
    # list data
    data_list = ['hello',123,1.3]
    from_yaml(data_list)
    # tuple data
    data_tuple = ('hello',123,1.3)
    from_yaml(data_tuple)
    # dict data

# Generated at 2022-06-11 09:05:49.040247
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Function: test_from_yaml
    Description: Test function from_yaml
    Parameters: None
    Return: None
    '''
    print("Testing function from_yaml\n")


# Generated at 2022-06-11 09:05:50.759880
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "key": "value" }') == {'key': 'value'}

# Generated at 2022-06-11 09:06:00.178621
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo') == 'foo'
    assert from_yaml('wibble: wubble') == {'wibble': 'wubble'}

    try:
        from_yaml(' "foo" : bar')
    except AnsibleParserError as e:
        assert 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: Expecting ' \
               'property name enclosed in double quotes: line 1 column 1 (char 1)\n\n' in str(e)
        assert 'YAML:  did not find expected <document start>' in str(e)

        assert e.show_content is True
        assert '"foo" : bar' in str(e)
        assert e.obj.ansible_pos == ('<string>', 1, 1)

# Generated at 2022-06-11 09:06:14.768270
# Unit test for function from_yaml
def test_from_yaml():
    text1 = """
    - hosts: all  
      vars:
        version: 1.0.0
      tasks:
      - name: copy nginx repo file
        copy:
           src: "{{ item }}"
           dest: "/etc/yum.repos.d/"
        with_items: 
           - nginx-stable.repo
           - nginx-mainline.repo
      - name: install nginx
        yum:
           name: nginx
           state: present
    """


# Generated at 2022-06-11 09:06:23.270808
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": "b" }') == {'a': u'b'}
    assert from_yaml('{ "a": "b" }', json_only=True) == {'a': u'b'}
    try:
        from_yaml('{ "a": "b" }', json_only=True, show_content=False)
        raise RuntimeError('from_yaml did not raise AnsibleParserError')
    except AnsibleParserError:
        pass

    assert from_yaml('a: b') == {'a': 'b'}
    try:
        from_yaml('a: b', show_content=False)
        raise RuntimeError('from_yaml did not raise AnsibleParserError')
    except AnsibleParserError:
        pass


# Generated at 2022-06-11 09:06:34.317662
# Unit test for function from_yaml
def test_from_yaml():
    data = "" #name: !vault |
                #          $ANSIBLE_VAULT;1.1;AES256
                #          6333356436353066393061366332613666323463386136633561633962626239633333363303436666435
                #          336235643533633237306630633761633232626239633761610a66383539363564646263373166623761
                #          333532346265336532316538346639616366613161366638363934386266373936386638386238396261
                #          3133353135613566390a3234396238396631333239636236386331626664363337626335306536383561

# Generated at 2022-06-11 09:06:36.878539
# Unit test for function from_yaml
def test_from_yaml():
    # Test to assure that from_yaml() returns a list
    from_yaml(
        """
        - host: localhost
          connection: local
        """,
    )

# Generated at 2022-06-11 09:06:40.788788
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('''{ 'a' : 'b' }''') == {'a': 'b'}
    assert from_yaml('''
    a: b
    ''') == {'a':'b'}



# Generated at 2022-06-11 09:06:50.021452
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import tempfile

    # Create a temporary file
    temp = tempfile.NamedTemporaryFile(delete=False)

    # Write to the file, then open it
    with temp as f:
        f.write(b"---\n- hosts: localhost")
    f = open(temp.name, "rb")

    # Test from_yaml
    result = from_yaml(f.read(), file_name=temp.name, show_content=False,
                       vault_secrets=None, json_only=False)

    # Check first line of file
    expected = [{"hosts": "localhost"}]
    unittest.TestCase().assertListEqual(result, expected)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:06:59.105740
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('''
        - nope
        - {{ 1 }}
        - { a: "b" }
        - 1
        - [1,2,3]
        - true
        - false
        - null
    ''') == [
        u'nope',
        {u'1': 1},
        {u'a': u'b'},
        1,
        [1, 2, 3],
        True,
        False,
        None,
    ]

    # JSON can be represented as YAML
    assert from_yaml('''
        [1,2,3]
    ''') == [1, 2, 3]


# Generated at 2022-06-11 09:07:08.749346
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
    foo: bar
    bar:
      baz: qux
    """

    class FakeAnsibleLoader(AnsibleLoader):

        def __init__(self, yaml_str, *args, **kwargs):
            self.result = yaml_str

        def get_single_data(self):
            return self.result

        def compose_node(self, parent, index):
            return self.result

        def construct_document(self, node):
            return self.result

    # Mock out _safe_load
    _orig_safe_load = AnsibleLoader._safe_load
    AnsibleLoader._safe_load = FakeAnsibleLoader


# Generated at 2022-06-11 09:07:12.546697
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('test: value')
    from_yaml('{"test": "value"}')
    from_yaml('{"test": "value"}', json_only=True)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 09:07:23.368065
# Unit test for function from_yaml
def test_from_yaml():

    data1 = ('---\n'
             '# comment\n'
             'a: b\n'
             'c: d\n'
             'e: 123\n'
             'f: true\n'
             'g: false\n'
             'h:\n'
             '  - 1\n'
             '  - 2\n'
             '  - 3\n'
             'i: 10.0\n'
             'j: [1, 2, 3]\n'
             'k:\n'
             '  hello: there\n'
             '  how: are\n'
             '  you?: true\n'
             'l:\n'
             '  d: [1, 2, 3]\n'
             '  e: 10.0\n')

# Generated at 2022-06-11 09:07:26.605445
# Unit test for function from_yaml
def test_from_yaml():
    # Arrange
    data = '{"a": java, "b": "c"}'

    # Act
    new_data = from_yaml(data)

    # Assert
    assert new_data is not None
    assert new_data == {"a": "java", "b": "c"}

# Generated at 2022-06-11 09:07:31.455081
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[]') == []
    assert from_yaml('{}') == {}
    assert from_yaml('{"a": 0}') == {"a": 0}
    assert from_yaml('key: value') == {"key": "value"}
    assert from_yaml('{"a": [0, "0", false, [{"b": false}], null]}') == {"a": [0, "0", False, [{"b": False}], None]}


# vim: set fileencoding=utf-8 :

# Generated at 2022-06-11 09:07:44.008105
# Unit test for function from_yaml
def test_from_yaml():
    # unit test
    test1 = '''
    j1:
      j2:
        j3: j4
    '''

    test2 = '''
    # just a comment
    j1:
      j2:
        j3: j4
    '''

    test3 = '''
    j1: {j2: {j3: j4}}
    '''

    test4 = '''
    j1:
      j2: {j3: j4}
    '''

    test5 = '''
    j1:
      j2:
        j3: {j4: k4}
    '''

    test6 = '''
    ---
    j1:
      j2:
        j3: j4
    '''


# Generated at 2022-06-11 09:07:48.257383
# Unit test for function from_yaml
def test_from_yaml():
    json_string = '{"key":"value"}'
    json_dict = {'key': 'value'}
    assert from_yaml(json_string) == json_dict

    yaml_string = '{"key":"value"}'
    assert from_yaml(yaml_string) == json_dict

# Generated at 2022-06-11 09:07:50.316371
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"a\": 1, \"b\":\"c\"}", json_only=True) == {"a": 1, "b": "c"}

# Generated at 2022-06-11 09:07:59.861673
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("FAIL") == "FAIL"
    assert from_yaml("FAIL", json_only=True) == "FAIL"
    assert from_yaml("{'a': 'b'}") == {'a': 'b'}
    assert from_yaml('{"a": "b"}') == {'a': 'b'}
    assert from_yaml("{ 'a': 'b' }") == {'a': 'b'}
    assert from_yaml("{'a': 'b', 'c': 'd'}") == {'a': 'b', 'c': 'd'}
    assert from_yaml("['a', 'b', 'c']") == ['a', 'b', 'c']
    assert from_yaml("{'list': ['a', 'b']}")

# Generated at 2022-06-11 09:08:04.537195
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = '''
---
- hosts: all
  vars:
    from_yaml: passed
  tasks:

  - name: 'from_yaml test'
    debug:
      msg: 'from_yaml {{ from_yaml }}'
'''
    assert from_yaml(test_yaml)


# Generated at 2022-06-11 09:08:15.424327
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo') == 'foo'
    assert from_yaml('1.0') == 1.0
    assert from_yaml('[1, 1.0, "foo"]') == [1, 1.0, "foo"]
    assert from_yaml('{"foo": "1.0", "bar": 2}') == {"foo": "1.0", "bar": 2}
    assert from_yaml('{"foo": "1.0", "bar": 2}', json_only=True) == {"foo": "1.0", "bar": 2}
    assert from_yaml('{"foo": "1.0", "bar": 2}', json_only=True) == {"foo": "1.0", "bar": 2}

# Generated at 2022-06-11 09:08:25.429459
# Unit test for function from_yaml
def test_from_yaml():
    tests = [
        ('''{
            "this": {"is": {"a": "test"}},
            "one": "two",
            "three": [1,2,3]
        }''',
        {"this": {"is": {"a": "test"}}, "one": "two", "three": [1,2,3]}),

        ("""
        ---
        this:
          is:
            - a test
        """,
        {"this": {"is": ["a test"]}}),

        ("""
        this:
          is:
            - "{{ a }} test"
        """,
        {"this": {"is": ["{{ a }} test"]}})

    ]

    for test in tests:
        assert json.dumps(from_yaml(test[0]), sort_keys=True) == json.dumps

# Generated at 2022-06-11 09:08:36.383545
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    # Verify we can read yaml
    data = {'foo': [1, 2, 3]}
    yaml_data = AnsibleModule._json_dict_to_b64(data)
    assert from_yaml(yaml_data, json_only=False) == data
    # Verify we can read json
    json_data = AnsibleModule._json_dict_to_b64(data, format="json")
    assert from_yaml(json_data, json_only=False) == data
    # Verify we can read vault secrets

# Generated at 2022-06-11 09:08:47.004637
# Unit test for function from_yaml
def test_from_yaml():

    json_test = '{"test":1}'
    json_result = from_yaml(json_test)
    assert json_result == {"test":1}

    yaml_test = 'test: 1'
    yaml_result = from_yaml(yaml_test)
    assert yaml_result == {"test":1}

    error_test = '{"test":1\n}'
    error_result = from_yaml(error_test)
    assert error_result == '{"test":1}'

# Generated at 2022-06-11 09:08:56.501301
# Unit test for function from_yaml
def test_from_yaml():
    import glob
    import os

    filename = os.path.basename(__file__)
    for yaml_file in glob.glob("tests/*.yaml"):
        with open(yaml_file, 'r') as test_file:
            data = test_file.read()

        ord_data = from_yaml(data, filename)
        assert(isinstance(ord_data, dict))
        assert(len(ord_data) != 0)
        assert(ord_data['string'] == 'string')
        assert(ord_data['key_1']['key_2']['list_1'][0] == 'test')



# Generated at 2022-06-11 09:09:02.910641
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAes256

    import sys

    res = from_yaml('- foo: bar\n- baz: foobar')
    assert res == [{"foo": "bar"}, {"baz": "foobar"}]

    # test no vault strings

# Generated at 2022-06-11 09:09:14.184830
# Unit test for function from_yaml
def test_from_yaml():
    # Ensure invalid YAML is correctly parsed, and raises AnsibleParserError
    invalid_yaml = '''- foo:
    - bar
    - 123'''
    try:
        from_yaml(invalid_yaml)
    except AnsibleParserError as exc:
        # The error should contain output that matches the input, but is
        # indented and colored
        assert exc.obj.ansible_pos[2] == 2
        assert exc.obj.show_content
        assert invalid_yaml in exc.message
    else:
        assert False, 'AnsibleParserError should be raised'

    # Ensure our code can handle jinja generated YAML too

# Generated at 2022-06-11 09:09:23.994570
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import json

    try:
        import yaml
    except ImportError:
        yaml = None

    assert from_yaml(None) == None

    assert from_yaml('''
{ "myvar": "myvalue" }
''') == dict(myvar="myvalue")

    assert from_yaml('''
{ "myvar": "myvalue" }
''', json_only=True) == dict(myvar="myvalue")

    # This is valid YAML, but not valid JSON.  So this should only work with json_only=False
    assert from_yaml('''
myvar:
- myvalue
''') == dict(myvar=['myvalue'])


# Generated at 2022-06-11 09:09:34.327876
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader

    assert from_yaml('') == None

    assert from_yaml('---') == True

    assert len(from_yaml(
        '---\n'
        '- hosts: localhost\n'
        '  tasks:\n'
        '    - debug: msg="Hello World!"\n'
        '- hosts: webservers\n'
        '  tasks:\n'
        '    - name: copy config file\n'
        '      copy: src=srv/httpd.conf dest=/etc/httpd.conf owner=root group=root mode=0644\n'
    )) == 2


# Generated at 2022-06-11 09:09:43.626777
# Unit test for function from_yaml
def test_from_yaml():

    # TEST:
    # 1. valid yaml
    # 2. invalid yaml
    # 3. valid json
    # 4. invalid json

    # valid yaml
    yaml = '''---
one:
  - 1
  - 2
  - "3"

two:
  - a
  - b
  - c
'''
    from_yaml(yaml, json_only=False)

    # invalid yaml
    yaml = '''---
one:
  - 1
  - 2

two:
  - a
  - b
  - c
'''
    from_yaml(yaml, json_only=False)

    # valid json
    json = '{"one": [1,2,3], "two": ["a", "b", "c"]}'
    from_y

# Generated at 2022-06-11 09:09:48.767449
# Unit test for function from_yaml
def test_from_yaml():
    # Test data
    json_str = "{'name': 'dummy'}"
    yaml_str = "{name: dummy}"

    # Test json string
    assert from_yaml(json_str) == {u'name': u'dummy'}

    # Test yaml string
    assert from_yaml(yaml_str) == {u'name': u'dummy'}

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:09:56.264071
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}
    try:
        from_yaml("{'foo': 'bar'}", json_only=True)
        assert False, 'Should have thrown an exception'
    except Exception as e:
        assert str(e) == "Expecting property name enclosed in double quotes: line 1 column 2 (char 1)"

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:10:05.229991
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import glob
    import os
    import re
    import pytest
    if sys.platform.startswith('win32'):
        pytest.skip("Unable to run on Windows")

    # Fetch the paths to all the example playbooks we are going to test
    playbook_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    playbook_path = os.path.join(playbook_path, 'examples')
    playbook_paths = glob.glob(os.path.join(playbook_path, '*.yml'))
    playbook_paths += glob.glob(os.path.join(playbook_path, '*.yaml'))

    # We want to test from_yaml with both JSON and YAML examples, so

# Generated at 2022-06-11 09:10:18.570986
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.utils.unsafe_proxy

    # Test valid json
    assert from_yaml('{"foo": "bar"}') == {u'foo': u'bar'}
    assert from_yaml('{"foo": "bar"}', json_only=True) == {u'foo': u'bar'}

    # Test valid yaml
    assert from_yaml('foo: bar') == {u'foo': u'bar'}

    # Test invalid json
    try:
        from_yaml('{foo: bar}')
        assert False, "Should have raised an AnsibleParserError"
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 09:10:25.635342
# Unit test for function from_yaml
def test_from_yaml():
    data1 = '{"hello": "world"}'
    data2 = '''{
      "a": "b",
      "c": "d",
      "e": "f"
    }'''
    data3 = "hello: world"

    assert from_yaml(data1) == {'hello': 'world'}
    assert from_yaml(data2) == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert from_yaml(data3) == {u'hello': u'world'}

# Generated at 2022-06-11 09:10:32.729634
# Unit test for function from_yaml
def test_from_yaml():
    ''' Test that the from_yaml function works.  '''

    # Check that we handle None, specifically.
    assert(from_yaml(None) is None)

    # Check that we handle empty string, specifically.
    assert(from_yaml('') == '')

    # Check that we handle JSON
    assert(from_yaml('{"key": "value"}') == {'key': 'value'})

    # Check that we handle YAML
    assert(from_yaml('hello: world\n') == {'hello': 'world'})

    # Check that we handle JSON Array
    assert(from_yaml('["hello", "world"]') == ['hello', 'world'])

    # Check that we handle YAML Array

# Generated at 2022-06-11 09:10:39.729433
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": [{"bar": 1, "baz": "asdf"}], "bar": "baz", "baz": "foo"}'
    result = from_yaml(data)
    assert result == {u'baz': u'foo', u'foo': [{u'baz': u'asdf', u'bar': 1}], u'bar': u'baz'}


# Generated at 2022-06-11 09:10:50.311557
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.validation import check_type_bool

    (result, exception) = (None, None)
    try:
        result = from_yaml("")
    except Exception as e:
        exception = e

    assert result is None, "expected None result but got %s" % result
    assert isinstance(exception, AnsibleParserError), "expected an AnsibleParserError exception but got %s" % exception

    (result, exception) = (None, None)
    try:
        result = from_yaml("{}")
    except Exception as e:
        exception = e

    assert isinstance(result, dict), "expected a dict result but got %s" % result

# Generated at 2022-06-11 09:10:55.917288
# Unit test for function from_yaml
def test_from_yaml():
    module_name = 'test'
    data = '{ "a": 1 }'
    file_name = '<string>'
    show_content = True
    vault_secrets = 'test_vaults'
    json_only = False

    new_data = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    assert new_data['a'] == 1

# Generated at 2022-06-11 09:11:06.507599
# Unit test for function from_yaml
def test_from_yaml():

    # Test that from_yaml does not accept invalid JSON data
    try:
        from_yaml('{"key": "value", "key: "value 2"}', json_only=True)
        assert False, "Invalid JSON data should raise Exception"
    except AnsibleParserError as e:
        assert 'We were unable to read either as JSON nor YAML' in str(e)
        assert 'column 5 (char 24)' in str(e)

    # Test with invalid YAML
    try:
        from_yaml('key: value\nkey: value2')
        assert False, "Invalid JSON data should raise Exception"
    except AnsibleParserError as e:
        assert 'We were unable to read either as JSON nor YAML' in str(e)

    # Test with valid YAML

# Generated at 2022-06-11 09:11:07.967073
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ test: 123 }") == { "test": 123 }

# Generated at 2022-06-11 09:11:17.885966
# Unit test for function from_yaml
def test_from_yaml():
    res = from_yaml("1")
    assert res == 1
    res = from_yaml("- 1\n- 2")
    assert res == [-1, -2]
    res = from_yaml("{'a': 1}")
    assert res == {'a': 1}
    try:
        from_yaml("[not,json]", json_only=True)
        assert False, "json_only=True with non-json input should raise an exception"
    except AnsibleParserError:
        pass
    res = from_yaml("[not,json]")
    assert res == ['not', 'json']

    # test handler for errors

# Generated at 2022-06-11 09:11:26.785103
# Unit test for function from_yaml
def test_from_yaml():
    fail_json = {}
    from_yaml(u'[1,2,3]', 0) == [1,2,3]
    from_yaml(u'[1,2,3]') == [1,2,3]
    from_yaml(u'{"a":"b"}') == {u'a':u'b'}
    try:
        from_yaml(u'invalid')
        fail_json['msg'] = "Parsing exception not raised"
    except AnsibleParserError:
        pass
    try:
        from_yaml(u'invalid', "file", True, None, True)
        fail_json['msg'] = "Parsing exception not raised"
    except AnsibleParserError:
        pass


# Generated at 2022-06-11 09:11:39.049201
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils.six import PY3

    if not PY3:
        import sys
        reload(sys)
        sys.setdefaultencoding('utf-8')

    # Test standard yaml
    yaml_data = u'{ foo: bar }'
    assert isinstance(from_yaml(yaml_data), AnsibleMapping)

    # Test JSON
    yaml_data = u'{"foo": "bar"}'
    assert isinstance(from_yaml(yaml_data), AnsibleMapping)

    # Test JSON with unicode string
    yaml_data = u'{"foo": "bar", "bar": "baz"}'

# Generated at 2022-06-11 09:11:47.671605
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder
    err_msg = 'Unable to create datastructure from input data.'
    # Test simple dict
    data = dict(a=1, b=2)
    json_text = json.dumps(data, cls=AnsibleJSONEncoder)
    yaml_text = AnsibleDumper().dump(data)

    assert from_yaml(json_text) == data, err_msg
    assert from_yaml(yaml_text) == data, err_msg

    # Test nested dicts
    data = dict(a=1, b=2, c=dict(A=1, B=2, C=dict(a=1, b=2)))
    json

# Generated at 2022-06-11 09:11:54.736545
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Run unit tests to test the from_yaml function.
    '''
    file_name = 'test_from_yaml.yaml'
    # Test the case where we have valid JSON, but invalid YAML
    data = '{ "json_key" : "json_value" }\n-not yaml\n'
    with pytest.raises(AnsibleParserError):
        from_yaml(data, file_name='<string>', show_content=False)

    # Test the case where we have valid JSON, and valid YAML
    data = '{ "json_key" : "json_value" }\n---\n- a_list_item\n'

# Generated at 2022-06-11 09:12:06.811961
# Unit test for function from_yaml
def test_from_yaml():
    print("Begin test_from_yaml")
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    filename = './test_data/test_vault_string.yml'
    with open(filename, 'rb') as fh:
        data = fh.read()
    
    yaml_data = from_yaml(data, file_name=filename, show_content=True, json_only=False)
    print("Vault Password: %s" % yaml_data['vault_password'])
    
    assert yaml_data['vault_password'] == 'password'
    print("End test_from_yaml")



# Generated at 2022-06-11 09:12:09.664172
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml("{\"foo\": [1,2,3], \"bar\": \"baz\"}")
    assert result == {u"foo": [1, 2, 3], u"bar": u"baz"}

# Generated at 2022-06-11 09:12:19.889666
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from yaml import safe_dump
    from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-11 09:12:30.384410
# Unit test for function from_yaml
def test_from_yaml():
    # Test simple string
    result = from_yaml("Hello World")
    assert result == "Hello World"
    # Test string with a JSON object
    result = from_yaml("Hello { key: value }")
    assert result == "Hello { key: value }"
    # Test with JSON object
    result = from_yaml("{ key: value }")
    assert result == {"key": "value"}
    # Test with list in JSON object
    result = from_yaml("{ key: [ one, two, three ] }")
    assert result == {"key": ["one", "two", "three"]}
    # Test with list in JSON object with escaping
    result = from_yaml("{ key: [ \"one\", \"two\", \"three\" ] }")
    assert result == {"key": ["one", "two", "three"]}

# Generated at 2022-06-11 09:12:37.308358
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import objects
    import sys

    data = """
    - hosts: localhost
      vars:
        user: username
      tasks:
        - name: something
          connection: local
          command: "ls -la /home/username"
    """
    data2 = """
    - hosts: localhost
      vars:
        user: username
      tasks:
        - name: something
          connection: local
          command: "ls -la /home/username"
    """
    data3 = """
    - hosts: localhost
      vars:
        user: username
      tasks:
        - name: something
          connection: local
          command: "ls -la /home/username"
    """

    # Test with a file name, vault secrets and show_content enabled

# Generated at 2022-06-11 09:12:41.600909
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[1, 2, 3]") == [1, 2, 3]
    assert from_yaml("{'a': 1, 'b': 2, 'c': 3}") == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 09:12:52.309040
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping
    import pytest
    # Test yaml.load
    data = """
a: 1
b:
  c: 3
  d: 4
"""
    res = from_yaml(data)
    assert isinstance(res, AnsibleMapping)
    assert res['a'] == 1

    # Test fail on non-yaml.
    with pytest.raises(AnsibleParserError):
        from_yaml('{', json_only=True)
    from_yaml('{}', json_only=True)

    # Test fail on yaml.
    with pytest.raises(AnsibleParserError):
        from_yaml('{')
    from_yaml('{}')

    # Test json.loads

# Generated at 2022-06-11 09:13:03.900177
# Unit test for function from_yaml
def test_from_yaml():
    actual = from_yaml('[ { "a": "b" } ]')
    expected = [{'a': 'b'}]
    assert(expected == actual)
    actual = from_yaml('[ { "a": "b", "c": "d" } ]')
    expected = [{'a': 'b', 'c': 'd'}]
    assert(expected == actual)
    actual = from_yaml('{ "a": "b", "c": "d" }')
    expected = {'a': 'b', 'c': 'd'}
    assert(expected == actual)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:13:11.940803
# Unit test for function from_yaml
def test_from_yaml():
    yaml_content = '''
{% for i in range(0, 10) %}
'{{ i }}': {{ i }}
{% endfor %}
'''

    # Given
    expected_data = {
        "0": 0,
        "1": 1,
        "2": 2,
        "3": 3,
        "4": 4,
        "5": 5,
        "6": 6,
        "7": 7,
        "8": 8,
        "9": 9,
    }

    # When
    actual_data = from_yaml(yaml_content, 'test_from_yaml')

    # Then
    assert expected_data == actual_data

# Generated at 2022-06-11 09:13:23.142767
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'name': 'foo'}") == {'name': 'foo'}
    assert from_yaml("{'name': 'foo', 'age': 43}") == {'name': 'foo', 'age': 43}
    assert from_yaml('{name: foo}') == {u'name': u'foo'}
    assert from_yaml('{name: foo, age: 43}') == {u'name': u'foo', u'age': 43}
    assert from_yaml('{name : foo}') == {u'name': u'foo'}
    assert from_yaml('{name : foo, age : 43}') == {u'name': u'foo', u'age': 43}

# Generated at 2022-06-11 09:13:24.883508
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("test:test", show_content=True) == {"test": "test"}


# Generated at 2022-06-11 09:13:34.524186
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAwareParameterParser

    vault_password = 'vaultpassword'
    vault = VaultLib([(vault_password)])
    vault_secret = VaultSecret(vault_password)
    vault_data = {"cluster": "cluster_name"}
    encrypted_data = vault.encrypt(json.dumps(vault_data))

    data = '''
    cluster: "!vault | {encrypted_data}
    '''

    new_data = json.loads(from_yaml(data, vault_secrets={'_ansible_vault': vault_secret}))

# Generated at 2022-06-11 09:13:47.512778
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('test') == 'test'
    assert from_yaml('1') == 1
    assert from_yaml('[1,2,3]') == [1,2,3]
    assert from_yaml('{"a":1}') == {'a': 1}
    assert from_yaml('{"a" : 1, "b" : 2}') == {'a': 1, 'b': 2}
    try:
        from_yaml('{"a" : 1, "b" : 2')
    except AnsibleParserError as e:
        pass
    except Exception as e:
        assert False, "Exception in from_yaml: %s" % e.message

    try:
        from_yaml('--A---')
    except AnsibleParserError as e:
        pass

# Generated at 2022-06-11 09:13:56.353997
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
    ---
    - hosts: localhost
      vars:
        var1:
            name: var1
            value: var1
      tasks:
      - name: This is a task
        shell: echo "test"
    '''
    data = from_yaml(yaml_data)
    assert isinstance(data, list)
    assert len(data) == 1
    assert isinstance(data[0], dict)
    play = data[0]
    assert 'hosts' in play
    assert play['hosts'] == 'localhost'
    assert 'vars' in play
    vars = play['vars']
    assert isinstance(vars, dict)
    assert 'var1' in vars
    var1 = vars['var1']

# Generated at 2022-06-11 09:14:01.458702
# Unit test for function from_yaml

# Generated at 2022-06-11 09:14:11.345855
# Unit test for function from_yaml
def test_from_yaml():
    """Test to ensure that AnsibleBaseYAMLObject objects are instantiated
    for YAML data that contains errors.
    """
    bad_input = '{ notyaml: True }'

    try:
        from_yaml(bad_input)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)
        assert isinstance(e.obj, AnsibleBaseYAMLObject)

    # Test that file_name is properly passed to the AnsibleParserError
    file_name = '/home/foo/bar'
    try:
        from_yaml(bad_input, file_name=file_name)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)
        assert isinstance(e.obj, AnsibleBaseYAMLObject)

# Generated at 2022-06-11 09:14:22.381350
# Unit test for function from_yaml
def test_from_yaml():

    def _data_matches(test_name, data, expected_result, yaml_only=False, json_only=False):
        result = from_yaml(data, yaml_only=yaml_only, json_only=json_only)
        assert result == expected_result, "Result %s did not match expected %s for test: %s" % (result, expected_result, test_name)

    def _data_errors(test_name, data, exception_class, yaml_only=False, json_only=False):
        try:
            result = from_yaml(data, yaml_only=yaml_only, json_only=json_only)
        except Exception as e:
            if e.__class__ == exception_class:
                return

# Generated at 2022-06-11 09:14:33.191940
# Unit test for function from_yaml
def test_from_yaml():
    # Test function from_yaml
    # Test whether it can process yaml file correctly
    # this yaml file has only one key-value pair

    yaml_file = '''
    ---
    test: string
    '''

    # test whether it can process json file correctly
    # this json file has only one key-value pair
    json_file = '''
    {"test": "string"}
    '''
    # test whether it can process invalid file correctly
    invalid_file = '''
    {
        "test": "string"
    }
    '''

    # test whether it can process invalid json file with json_only flag correctly
    invalid_json_file = '''
    ----
    test: string
    '''

    from ansible.parsing.yaml.data import from_yaml

    # test whether