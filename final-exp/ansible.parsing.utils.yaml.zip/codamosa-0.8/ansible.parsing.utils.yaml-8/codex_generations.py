

# Generated at 2022-06-11 09:04:40.982044
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    dl = DataLoader()
    path1 = dl.path_dwim_relative('./', './hiera/common.yml')
    path2 = dl.path_dwim_relative('./', './hiera/foo.yml')
    res = combine_vars(loader=dl, variables=from_yaml(dl.load_file(path1), file_name=path1), variables2=from_yaml(dl.load_file(path2), file_name=path2))
    assert res == {'var1': 1, 'var2': 2, 'var3': 3}

# Generated at 2022-06-11 09:04:51.691197
# Unit test for function from_yaml
def test_from_yaml():
    '''
    This function reads test_data.yaml and simply tests whether it can be parsed using from_yaml()
    '''
    import os
    from ansible.utils.path import unfrackpath

    try:
        from yaml import CSafeLoader as SafeLoader
    except ImportError:
        from yaml import SafeLoader

    yaml_file = unfrackpath(os.path.join(os.path.dirname(__file__), 'test_data.yaml'))
    with open(yaml_file, 'r') as stream:
        data = stream.read()
        new_data = yaml.load(data, Loader=SafeLoader)

        # This call is what we are testing
        new_data = from_yaml(data, file_name='test_data.yaml', show_content=True)

# Generated at 2022-06-11 09:05:05.260258
# Unit test for function from_yaml
def test_from_yaml():

    # Test argument combinations
    assert from_yaml('{}') == {}, 'Could not parse empty JSON string "{}" as {}'
    assert from_yaml('{}', json_only=True) == {}, 'Could not parse empty JSON string "{}" as JSON'

    # Test default argument value
    assert from_yaml('{}') == {}, 'Could not parse empty JSON string "{}" as {}'

    # Test JSON only parsing
    assert from_yaml('{}', json_only=True) == {}, 'Could not parse empty JSON string "{}" as JSON'

    # Test incorrect argument

# Generated at 2022-06-11 09:05:13.450148
# Unit test for function from_yaml
def test_from_yaml():
    '''
    tests the from_yaml function.
    The test works by first calling the function on a valid yaml and a valid json string
    to check that it returns the expected result.
    Then it tests for the error messages by calling the function on invalid strings
    and catch the corresponding error messages.
    '''
    # test for valid json and yaml string
    valid_json = "{" + \
        "\"test_json_string\": \"foo\"," + \
        "\"test_json_int\": 42," + \
        "\"test_json_list\": [1,2,3]," + \
        "\"test_json_dict\": {\"foo\": \"bar\"}" + \
        "}"


# Generated at 2022-06-11 09:05:15.415148
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[]", json_only=True) == []

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:05:27.332871
# Unit test for function from_yaml
def test_from_yaml():

    import os
    import unittest
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    class TestYaml(unittest.TestCase):

        def test_safe_load(self):
            test_data = to_text(u"""
                # This is a python dictionary
                {one: {two: three}, 'four': ['five', 'six'], seven: 8, 'nine': None}
                """)

            # test as string
            new_data = from_yaml(test_data, '<string>', vault_secrets='TEST-VAULT')
            self.assertEqual(type(new_data), dict)

# Generated at 2022-06-11 09:05:36.402712
# Unit test for function from_yaml
def test_from_yaml():
    import unittest


# Generated at 2022-06-11 09:05:37.949677
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml("{'foo': 'bar'}'")

# Generated at 2022-06-11 09:05:49.488530
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    - hosts: localhost
      become: yes
      tasks:
      - name: this is a key
        debug:
          msg: "this is my message"
      - name: this is a key
        debug:
          msg: "this is my message"
    """

    try:
        from_yaml(data)
    except AnsibleParserError:
        assert False, "The input data is OK"


# Generated at 2022-06-11 09:05:58.237185
# Unit test for function from_yaml
def test_from_yaml():

    # Test YAML to JSON conversion
    assert from_yaml('---') == None
    assert from_yaml('---\n- 1\n- test:1') == [1, dict(test=1)]

    # Test JSON to JSON conversion
    assert from_yaml('{}') == {}
    assert from_yaml('[]') == []
    assert from_yaml('{"test":3}') == dict(test=3)
    assert from_yaml('{"test": [1,2,3]}') == dict(test=[1,2,3])


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v', '-x'])

# Generated at 2022-06-11 09:06:13.195826
# Unit test for function from_yaml
def test_from_yaml():

    # Test for JSON
    json_str_1 = """
{
  "key0": 0,
  "key1": 1,
  "key2": 2
}
"""

    json_str_2 = """
[{
  "key0": 0,
  "key1": 1,
  "key2": 2
},
{
  "key0": 0,
  "key1": 1,
  "key2": 2
}]
"""

    data = from_yaml(json_str_1)
    assert type(data) is dict
    assert len(data) == 3
    assert data['key0'] == 0
    assert data['key1'] == 1
    assert data['key2'] == 2

    data = from_yaml(json_str_2, json_only=True)

# Generated at 2022-06-11 09:06:16.505226
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}
    assert from_yaml("{'foo': 'bar'}", json_only=True) == {'foo': 'bar'}
    assert from_yaml("{'foo': 'bar'}", json_only=False) == {'foo': 'bar'}



# Generated at 2022-06-11 09:06:28.432717
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.module_utils._text import to_bytes

    # We test from_yaml with a string that is valid YAML but not valid JSON.
    example_data = {'scalar': 'a scalar',
                    'list': [1, 2, 3],
                    'dict': {'a': 'dict', 'that': ['has', 2, 'elements']}}
    yaml_string = to_bytes(AnsibleDumper(None, width=80).dump(example_data))
    try:
        json.loads(yaml_string)
    except ValueError:
        # The string is not valid JSON. This is the case we want.
        pass

# Generated at 2022-06-11 09:06:38.098524
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("---\n- one\n- two\n") == ['one', 'two']
    assert from_yaml("---\n- one\n- two\n", json_only=True) == ['one', 'two']
    assert from_yaml("---\none\ntwo\n", json_only=True) == ['one', 'two']
    assert from_yaml('{"one":"two"}', json_only=True) == {'one': 'two'}
    assert from_yaml("one\ntwo\n", json_only=True) == ['one', 'two']
    assert from_yaml("---\n[ one, two ]\n") == ['one', 'two']

# Generated at 2022-06-11 09:06:48.312827
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    data = """
    - one:
        two: three
        four: five
    - six: 
        seven: eight
        nine: ten
    """

    ds = from_yaml(data)
    assert isinstance(ds, AnsibleSequence)
    assert len(ds) == 2
    assert isinstance(ds[0], AnsibleMapping)
    assert isinstance(ds[1], AnsibleMapping)
    assert ds[0]['one']['two'] == 'three'
    assert ds[0]['one']['four'] == 'five'
    assert ds[1]['six']['seven'] == 'eight'

# Generated at 2022-06-11 09:06:57.206726
# Unit test for function from_yaml
def test_from_yaml():
    # Test yaml.safe_load()
    data = {'name': 'ansible'}
    assert(data == from_yaml(json.dumps(data)))

    # Test JSON
    thisdict = {
        "key1": "value1",
        "key2": "value2",
        "key3": {
            "key31": "value31",
            "key32": "value32",
            "key33": {
                "key331": "value331",
                "key332": "value332",
            }
        }
    }

    dump = json.dumps(thisdict)
    assert(thisdict == from_yaml(dump))

    # Test nested comments

# Generated at 2022-06-11 09:07:06.089178
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.inventory.host import Host
    assert isinstance(from_yaml("{'foo': 'bar'}"), dict)
    assert isinstance(from_yaml("foo: bar"), dict)
    assert isinstance(from_yaml("{}"), dict)
    assert isinstance(from_yaml("[]"), list)
    assert isinstance(from_yaml("{\"a\": 1, \"b\": \"test\", \"c\": [1,2,3], \"d\": {\"a\": 1}}"), dict)
    assert from_yaml("foo: bar").get('foo') == 'bar'
    assert from_yaml("foo: bar\nfuz: boz").get('foo') == 'bar'
    assert isinstance(from_yaml("foo: bar\nfuz: boz"),dict)

# Generated at 2022-06-11 09:07:16.694084
# Unit test for function from_yaml
def test_from_yaml():

    import pytest

    from ansible.utils.unsafe_proxy import to_safe_args
    from ansible.errors.yaml_strings import YAML_SYNTAX_ERROR
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.errors import AnsibleParserError

    source_yaml = """
        ---
        one:
        - 1
        - 2
        - 3
        ...
    """
    source_yaml_bad = """
        ---
        this is a badly formatted yaml file:
    """
    source_json = """
        {"one":[1,2,3]}
    """
    source_json_bad = """
        {'one':'a list'}
    """

    # Test loading good yaml with from_yaml
    assert from_y

# Generated at 2022-06-11 09:07:22.947817
# Unit test for function from_yaml
def test_from_yaml():
    import os
    avg_file_name = "./Unified_AVG_Rule_Set.yml"
    avg_file_data = open(avg_file_name, 'r')
    avg_file_data_from_yml = from_yaml(avg_file_data, file_name=avg_file_name)

    print(avg_file_data_from_yml)

test_from_yaml()

# Generated at 2022-06-11 09:07:29.415492
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
    foo:
      bar: 1
      baz:
        - 2
        - hi
      bam: [3, 4]
    buz: null
    '''
    expected_result = {u'foo': {u'bar': 1, u'baz': [2, u'hi'], u'bam': [3, 4]}, u'buz': None}
    assert from_yaml(yaml_data) == expected_result

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:07:44.133250
# Unit test for function from_yaml
def test_from_yaml():

    from ruamel.yaml.round_trip import round_trip_dump
    import os

    # test for yaml parsing with yaml.safe_load()
    yaml = '''
    ---
    - hosts: localhost
      tasks:
      - debug: var=foobar
    '''


# Generated at 2022-06-11 09:07:52.507863
# Unit test for function from_yaml
def test_from_yaml():

    data = {}
    data['json_only'] = {
        'str': 'abc',
        'int' : 1,
        'array': [1, 2, 3],
        'dict': {'a': 1, 'b': 2}
    }
    data['yaml'] = {
        'str': 'def',
        'int' : 2,
        'array': [4, 5, 6],
        'dict': {'c': 3, 'd': 4}
    }

    msg = 'from_yaml() json_only=True failed for type: %s'
    data_str = json.dumps(data['json_only'])

# Generated at 2022-06-11 09:08:02.407104
# Unit test for function from_yaml
def test_from_yaml():
    import random, string

    random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(20))

    # Test for empty file
    assert from_yaml('') == None

    # Test for empty YAML file
    assert from_yaml('---') == None

    # Test for empty JSON file
    assert from_yaml('{}') == {}

    # Test for empty JSON file with whitespace
    assert from_yaml(' \n\n {} ') == {}

    # Test for empty YAML file with whitespace
    assert from_yaml(' \n\n --- ') == None

    # Test for empty YAML file with whitespace and ending with a newline (see issue #31517)

# Generated at 2022-06-11 09:08:14.032849
# Unit test for function from_yaml
def test_from_yaml():

    # create a datastructure and convert to json and yaml
    d = { 'a': 1, 'b': 2 }
    d_yaml = 'a: 1\nb: 2\n'
    d_json = '{"a": 1, "b": 2}'

    # Test with json string
    j = from_yaml(d_json)
    assert j == d

    # Test with yaml string
    y = from_yaml(d_yaml)
    assert y == d

    # Test that AnsibleJSONDecoder is called
    class TestClass:
        def __init__(self):
            self.a = 'test'

        def to_json(self):
            return json.dumps({'__class__': 1})

    t = TestClass()

# Generated at 2022-06-11 09:08:23.389947
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert from_yaml('{"a": 1, "b": 2}', json_only=True) == {'a': 1, 'b': 2}
    assert from_yaml('{"a": 1, "b": 2}', json_only=False) == {'a': 1, 'b': 2}
    assert from_yaml('some plain text') == 'some plain text'
    assert from_yaml('{"a": 1, "b": 2', json_only=True) == '{"a": 1, "b": 2'
    assert from_yaml('{"a": 1, "b": 2', json_only=False) == '{"a": 1, "b": 2'
    assert from_

# Generated at 2022-06-11 09:08:31.453584
# Unit test for function from_yaml
def test_from_yaml():
    # This should be working and return a dictionary
    data="""{
      "false": false
    }"""
    assert(isinstance(from_yaml(data, json_only=True), dict))

    # This should work and return None
    data="~"
    assert(from_yaml(data) is None)

    # This should fail
    data="a"
    try:
        from_yaml(data)
    except Exception as e:
        assert(isinstance(e, AnsibleParserError))

# Generated at 2022-06-11 09:08:39.083222
# Unit test for function from_yaml
def test_from_yaml():
    """
    To test this function, run ``python -m test.ansible_test.unit.utils.test_from_yaml`` inside
    the unit test directory.

    This function tests the ability of the function to :
       - return the expected data structure when loaded with a valid YAML or JSON string
       - throw an exception when loaded with an invalid YAML or JSON string
    """

    try:
        import __builtin__ as builtins  # python2
    except ImportError:
        import builtins  # python3

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder


# Generated at 2022-06-11 09:08:52.558240
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test for function from_yaml
    '''

    # Test for YAML
    data_yaml = '''
    - hosts: localhost
      tasks:
        - debug: msg="Hello, I am inside a YAML file"
    '''

    file_name_yaml = 'test_file_yaml.yaml'
    
    data_yaml_expected = [
        {'hosts': 'localhost', 'tasks': [{'debug': {'msg': 'Hello, I am inside a YAML file'}}]}
    ]

    data_yaml_result = from_yaml(data_yaml, file_name_yaml, show_content=True, vault_secrets=None, json_only=False)

    assert data_yaml_result == data_yaml_expected

# Generated at 2022-06-11 09:09:00.889420
# Unit test for function from_yaml
def test_from_yaml():
    import prefixsuffix.core
    config_data = {}
    config_data = prefixsuffix.core.from_yaml('''
---
prefixes:
  - '&#x1F44B;'
  - '&#x1F44C;'
  - '&#x1F3C3;'
  - '&#x1F3C4;'
suffixes:
  - '&#x1F3C3;'
  - '&#x1F3C4;'
  - '&#x1F44B;'
  - '&#x1F44C;'
''')
    assert config_data['prefixes'][0] == '\U0001F44B'

# Generated at 2022-06-11 09:09:12.045378
# Unit test for function from_yaml
def test_from_yaml():
    sample1 = "---\n- foo\n"
    assert from_yaml(sample1, file_name='<string>') == ["foo"]
    assert from_yaml("", file_name='<string>') == []

    # Should raise error when its not a yaml or json
    try:
        from_yaml("foo: bar")
    except AnsibleParserError:
        pass

    assert from_yaml("[1, 2, 3]") == [1, 2, 3]

    # It should also work for non string too
    assert from_yaml({"a": {"b": 6}}) == {"a": {"b": 6}}

    # Will fail because yaml doesn't support non-string key in dictionary

# Generated at 2022-06-11 09:09:25.088104
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"some": "json"}') == {u'some': u'json'}
    assert from_yaml('{"some": "json"}', json_only=True) == {u'some': u'json'}
    assert from_yaml('some: non-json') == {u'some': u'non-json'}
    assert from_yaml('{"some": "json"}', json_only=False) == {u'some': u'json'}

    import collections
    import pytest

    def check_type_error(s):
        with pytest.raises(AnsibleParserError) as e:
            from_yaml(s)
        assert isinstance(e.value.__cause__, YAMLError)

# Generated at 2022-06-11 09:09:32.393196
# Unit test for function from_yaml
def test_from_yaml():
    '''Unit test for function from_yaml'''
    assert(from_yaml('{"hello": "world"}') == {"hello": "world"})
    assert(from_yaml('{"hello": "world"}', json_only=True) == {"hello": "world"})
    assert(from_yaml('hello: world') == {'hello': 'world'})
    assert(from_yaml('hello: world', json_only=True) == {'hello': 'world'})


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:09:42.295200
# Unit test for function from_yaml
def test_from_yaml():
    #from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultSecret
    from tests.unit.parsing.vault import test_vault as vault_test
    vault_secret = VaultSecret(vault_test.TEST_VAULT_SECRET)

    # The basic case
    data = 'name: foobar'
    assert from_yaml(data, vault_secrets=[vault_secret]) == {'name': 'foobar'}

    # Error cases
    with pytest.raises(AnsibleParserError):
        data = 'name: foo:bar'
        from_yaml(data, vault_secrets=[vault_secret])

    with pytest.raises(AnsibleParserError):
        data = 'name: !foo bar'

# Generated at 2022-06-11 09:09:50.701597
# Unit test for function from_yaml
def test_from_yaml():

    # Test with simple json
    test_data = '{"simple": "json"}'
    result = from_yaml(test_data, json_only=True)
    assert result == {"simple": "json"}

    # Test with simple yaml
    test_data = 'simple: yaml'
    result = from_yaml(test_data)
    assert result == {"simple": "yaml"}

    # Test with vars_prompt yaml
    test_data = '---\n- prompt: "Please enter your first name"\n  private: no\n  name: first_name\n  type: string\n'
    result = from_yaml(test_data)
    assert result == [{"first_name": {"private": False, "prompt": "Please enter your first name", "type": "string"}}]


# Generated at 2022-06-11 09:10:01.143418
# Unit test for function from_yaml
def test_from_yaml():
    # Test for valid json data
    assert from_yaml('{"hello":"world"}') == {'hello': 'world'}

    # Test for valid yaml data
    assert from_yaml('hello: world') == {'hello': 'world'}

    # Test for invalid json data
    try:
        from_yaml('{"hello":"world"')
    except AnsibleParserError:
        pass

    # Test for invalid yaml data
    try:
        from_yaml('hello: "world')
    except AnsibleParserError:
        pass

    # Test for json data, which cannot be parsed as yaml
    try:
        from_yaml('{"hello:"world"}', json_only=True)
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 09:10:07.750485
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Tests for the from_yaml() function.
    '''
    import io

    # Test JSON and YAML parsing.
    assert from_yaml('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert from_yaml('[ 1, 2]') == [ 1, 2]
    assert from_yaml('a: 1\n') == {'a': 1}

    # Test a JSON traversable error.
    try:
        from_yaml('{"a": 1, "b": [')
        assert False, 'Incorrect JSON should raise a ValueError.'
    except ValueError:
        pass

    # Test a JSON parse error.

# Generated at 2022-06-11 09:10:14.122824
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"data": "value"}', json_only=True) == {"data": "value"}
    assert from_yaml('{"data": "value"}', json_only=False) == {"data": "value"}
    assert from_yaml('{data: value}', json_only=True) == None
    assert from_yaml('this: is not data', json_only=False) == {'this': 'is not data'}

# Generated at 2022-06-11 09:10:20.846106
# Unit test for function from_yaml
def test_from_yaml():
    import yaml
    yaml_str = '''
    a:
      - 1
      - b:
        - 2
        - c
      - d
      - e
      - f
      - 3
    '''
    expected_dict = {'a': [1, {'b': [2, 'c']}, 'd', 'e', 'f', 3]}
    result = from_yaml(yaml_str)
    assert result == expected_dict

# Generated at 2022-06-11 09:10:21.697610
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''

    import doctest
    doctest.testmod()

# Generated at 2022-06-11 09:10:28.136474
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_data = from_yaml('{"a": "easy as", "b c": "do re mi"}')
    assert(isinstance(from_yaml_data, dict) and
           len(from_yaml_data) == 2 and
           "a" in from_yaml_data and
           "b c" in from_yaml_data and
           from_yaml_data["a"] == "easy as" and
           from_yaml_data["b c"] == "do re mi")
    return True

# Generated at 2022-06-11 09:10:45.310387
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    ---
    hosts:
      - localhost
      - example.org
    """
    assert from_yaml(data) == {
        'hosts': ['localhost', 'example.org']
    }
    data = """
    ---
    - foobar
    - foo: bar
    - [1, 2, 3]
    """
    assert from_yaml(data) == [
        'foobar',
        {'foo': 'bar'},
        [1, 2, 3]
    ]

# Generated at 2022-06-11 09:10:48.512562
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"key":"value"}'
    file_name = 'ansible.cfg'
    expected = {"key":"value"}
    actual = from_yaml(data, file_name=file_name)
    assert actual == expected

# Generated at 2022-06-11 09:10:57.953173
# Unit test for function from_yaml
def test_from_yaml():
    d = from_yaml('{"test": ["a", "b", "c"]}')
    assert d == {'test': ['a', 'b', 'c']}
    d = from_yaml("{test: ['a', 'b', 'c']}")
    assert d == {'test': ['a', 'b', 'c']}
    d = from_yaml("{'test': ['a', 'b', 'c']}")
    assert d == {'test': ['a', 'b', 'c']}
    d = from_yaml('[1, 2, 3]')
    assert d == [1, 2, 3]
    d = from_yaml('[1, 2, 3,]')
    assert d == [1, 2, 3]

# Generated at 2022-06-11 09:11:03.207481
# Unit test for function from_yaml
def test_from_yaml():
    good_yaml = '''
    - hosts: localhost
      tasks:
      - debug: 
          msg: Hello from yaml
        name: a task
    '''
    assert from_yaml(good_yaml) == [{'hosts': 'localhost', 
        'tasks': [{'debug': {'msg': 'Hello from yaml'}, 'name': 'a task'}]}]

# Generated at 2022-06-11 09:11:08.829431
# Unit test for function from_yaml
def test_from_yaml():
    # can't use a lambda here as ansible/test/units/test_utils.py calls this
    # function with a dict as the first parameter,
    # which would evaluate the lambda and won't call this function
    def test(param1, param2, param3):
        return from_yaml(param1, param2, param3)
    return test

# Generated at 2022-06-11 09:11:17.285093
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 7, "b": 62 }') == {"a": 7, "b": 62}
    assert from_yaml('["a", "b"]') == ["a", "b"]
    assert from_yaml('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert from_yaml('{"a": "b", "b": "c"}') == {"a": "b", "b": "c"}
    assert from_yaml('foo') == "foo"
    assert from_yaml('7') == 7
    assert from_yaml('[1,2,3]') == [1,2,3]

# Generated at 2022-06-11 09:11:25.757869
# Unit test for function from_yaml
def test_from_yaml():
    data = '''{
    "my_var": {
        "foo": "bar"
    }
}'''
    data = from_yaml(data, json_only=True)
    assert data == {'my_var': {'foo': 'bar'}}

    data = '''my_var: {foo: bar}'''
    data = from_yaml(data, json_only=True)
    assert data == {'my_var': {'foo': 'bar'}}

    data = '''{
    my_var: {
        foo: bar
    }
}'''
    data = from_yaml(data, json_only=True)
    assert data == {'my_var': {'foo': 'bar'}}


# Generated at 2022-06-11 09:11:33.213671
# Unit test for function from_yaml
def test_from_yaml():
    json = '{"json": "foo"}'
    yaml = '---\nyaml: bar\n'
    assert from_yaml(json, json_only=True) == {'json': 'foo'}
    assert from_yaml(yaml, json_only=False) == {'yaml': 'bar'}
    assert from_yaml(yaml, json_only=True) == {'yaml': 'bar'}
    assert from_yaml(json, json_only=False) == {'json': 'foo'}

# Generated at 2022-06-11 09:11:36.784717
# Unit test for function from_yaml
def test_from_yaml():
    # This can be called like this if you want to test that serializing
    # the data structure to YAML will result in the same YAML string
    # that was used to deserialize it.
    #
    # Ensure we test with a python data structure that contains all
    # of the base types so we can ensure round-tripping is working.
    data = [
        'string',
        1,
        2.0,
        None,
        True,
        {
            'foo': 'bar',
            'baz': 'quux',
            'bam': {
                'baz': 'bam',
                'yay': 'yay'
            }
        }
    ]
    data_copy = from_yaml(to_yaml(data))

    assert data == data_copy

# Generated at 2022-06-11 09:11:46.118033
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test from_yaml function
    """
    import os
    ansible_dir = os.path.dirname(os.path.dirname(__file__))
    test_dir = os.path.join(ansible_dir, 'test', 'units', 'parsing', 'yaml')
    test_file = os.path.join(test_dir, 'test_yaml.yml')
    data = open(test_file).read()

# Generated at 2022-06-11 09:12:07.290112
# Unit test for function from_yaml
def test_from_yaml():
    res = from_yaml(data="{'a':'b'}")
    assert res == {'a': 'b'}

# Generated at 2022-06-11 09:12:17.565116
# Unit test for function from_yaml
def test_from_yaml():

    import os
    import sys
    import getpass
    import json

    try:
        from ansible.module_utils.parsing.convert_bool import boolean
        from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
        from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
        from ansible.module_utils.parsing.convert_bool import BOOLEANS
    except:
        from ansible.module_utils.facts.parsing.convert_bool import boolean
        from ansible.module_utils.facts.parsing.convert_bool import BOOLEANS_TRUE
        from ansible.module_utils.facts.parsing.convert_bool import BOOLEANS_FALSE
       

# Generated at 2022-06-11 09:12:27.573219
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.plugins.loader import from_yaml
    from ansible.module_utils._text import to_text
    import pytest

    a = u"{'name': 'bob', 'age': 5}"  # Invalid YAML
    json_only = True
    with pytest.raises(AnsibleParserError) as excobj:
        from_yaml(a, json_only=json_only)
    assert 'not JSON' in to_text(excobj)

    b = u"{'name': 'bob', 'age': 5}"  # Valid JSON
    json_only = True
    assert from_yaml(b, json_only=json_only) == {"name": "bob", "age": 5}
    json_only = False

# Generated at 2022-06-11 09:12:33.609807
# Unit test for function from_yaml
def test_from_yaml():
    x = from_yaml('{"a":{"b": [1, 2, 3]}, "c" : [1, 2, 3]}')
    assert x == {u'a': {u'b': [1, 2, 3]}, u'c': [1, 2, 3]}

    x = from_yaml('---\n - key: value')
    assert x == [{u'key': u'value'}]


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:12:38.835710
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = []
    vault_secrets.append(VaultSecret(password='test'))
    vault_secrets.append(VaultSecret(password='test2', identifier={'test': 'data'}))

    assert from_yaml('{ "key": "test", "key2": "{{testvault}}" }', vault_secrets=vault_secrets) == {'key': 'test', 'key2': VaultLib().encrypt('test2', vault_secrets)}

# Generated at 2022-06-11 09:12:42.023162
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.tests.unit.parsing.yaml.test_yaml import test_from_yaml

    test_from_yaml(from_yaml)

# Generated at 2022-06-11 09:12:47.123372
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("false") is False
    assert from_yaml("[1,2]") == [1,2]
    assert from_yaml("{'a':1}") == {'a':1}
    assert from_yaml("a:1") == {'a':1}

# Generated at 2022-06-11 09:12:51.280242
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ 'foo': 1 }") == {u'foo': 1}
    assert from_yaml("{ 'foo': 1 }", json_only=True) == {u'foo': 1}
    assert from_yaml("foo: 1", json_only=True) is None


# Generated at 2022-06-11 09:12:53.925251
# Unit test for function from_yaml
def test_from_yaml():
    data = "['item', 'item2']"
    assert from_yaml(data) == ['item', 'item2']
    data = "{'a': 'b'}"
    assert from_yaml(data) == {'a': 'b'}

# Generated at 2022-06-11 09:13:04.493952
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('{}', json_only=True) == {}

    assert from_yaml('''
        foo: bar
        bar:
          - baz
          - bah
        ''') == {
            "foo": "bar",
            "bar": [
                "baz",
                "bah"
            ]
        }
    assert from_yaml('''
        foo: bar
        bar:
          - baz
          - bah
        ''') == {
            "foo": "bar",
            "bar": [
                "baz",
                "bah"
            ]
        }


# Generated at 2022-06-11 09:13:33.711230
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml("{'a': 1, 'b': 2}")
        from_yaml("{'a': 1, 'b': 2}")
    except AnsibleParserError as e:
        assert False, 'Should have parsed JSON here.'

    try:
        from_yaml("a: 1\nb: 2")
        from_yaml("a: 1\nb: 2")
    except AnsibleParserError as e:
        assert False, 'Should have parsed YAML here.'

    try:
        from_yaml("a: {b: {c: {d: hello}}}")
    except AnsibleParserError as e:
        assert False, 'Should have parsed YAML here.'


# Generated at 2022-06-11 09:13:46.747273
# Unit test for function from_yaml
def test_from_yaml():
    data = "{\"name\": \"test_name\", \"comment\": \"test comment\"}"
    data_dict = from_yaml(data)
    assert data_dict == {u'name': u'test_name', u'comment': u'test comment'}

    data = "{\"name\": \"test_name\", \"comment\": \"test comment\"}"
    data_dict = from_yaml(data, json_only=True)
    assert data_dict == {u'name': u'test_name', u'comment': u'test comment'}

    data = "name: test_name\ncomment: test comment"
    data_dict = from_yaml(data, json_only=True)
    assert data_dict == {u'name': u'test_name', u'comment': u'test comment'}


# Generated at 2022-06-11 09:13:54.582833
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    # encrypted_secrets = dict(secret1=vault.encrypt('abc'), secret2=vault.encrypt('xyz'))
    encrypted_secrets = vault.encrypt('abc')
    data = '{ "a": "b", "secret1": %s }' % json.dumps(encrypted_secrets)
    decrypted_data = from_yaml(data, vault_secrets=vault)
    assert decrypted_data['a'] == 'b'
    assert decrypted_data['secret1'] == vault.decrypt(encrypted_secrets)['secret1']

# Generated at 2022-06-11 09:14:03.440977
# Unit test for function from_yaml
def test_from_yaml():

    #data = '{"key1": "value1", "key2": "value2"}'
    data = '{key1: value1, key2: value2}'
    assert from_yaml(data) == {'key1': 'value1', 'key2': 'value2'}
    #print(">>> json test: ", from_yaml(data))

    #data = 'key1: value1\nkey2: value2'
    data = '---\nkey1: value1\nkey2: value2'
    assert from_yaml(data) == {'key1': 'value1', 'key2': 'value2'}
    #print(">>> yaml test: ", from_yaml(data))

    data = '{"key1": "value1", "key2": "value2"}'

# Generated at 2022-06-11 09:14:13.880667
# Unit test for function from_yaml
def test_from_yaml():

    # Test with YAML
    yaml_data = '''\
        ---
        - hosts: test_host1
          gather_facts: false
          vars:
            test_var: test

        - hosts: test_host2
          gather_facts: false
          vars:
            test_var: test
    '''
    result = from_yaml(yaml_data, '', True, '')
    assert len(result) == 2
    assert result[0]['hosts'] == 'test_host1'
    assert result[0]['vars']['test_var'] == 'test'
    assert result[1]['hosts'] == 'test_host2'
    assert result[1]['vars']['test_var'] == 'test'

    # Test with JSON

# Generated at 2022-06-11 09:14:23.718320
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('dummy', VaultLib())]


# Generated at 2022-06-11 09:14:28.698001
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import pytest

    dirname = os.path.dirname(__file__)
    filename = os.path.join(dirname, 'data', 'test_ajson.json')

    with open(filename, 'r') as stream:
        data = stream.read()

    result = from_yaml(data, file_name='<string>', show_content=True)

    assert result == {'a': 'b', 'c': 'd', 'e': 'f'}