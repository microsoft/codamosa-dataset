

# Generated at 2022-06-11 09:04:40.483613
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.vars import VaultSecret
    from io import BytesIO


# Generated at 2022-06-11 09:04:42.016228
# Unit test for function from_yaml
def test_from_yaml():
    data = from_yaml(u"test: yes")
    assert data == {u"test":u"yes"}

# Generated at 2022-06-11 09:04:53.254661
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ 'a': { 'b': { 'c': 'd' } } }") == {'a': {'b': {'c': 'd'}}}
    assert from_yaml("{ 'key': 'value' }") == {'key': 'value'}
    assert from_yaml("{ 'key': 'value', 'key2': 'value2' }") == {'key': 'value', 'key2': 'value2'}
    assert from_yaml("key: value") == {'key': 'value'}
    assert from_yaml("key: value\nkey2: value2") == {'key': 'value', 'key2': 'value2'}

# Generated at 2022-06-11 09:05:06.688623
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from ansible.module_utils.six import string_types


# Generated at 2022-06-11 09:05:08.543615
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml("{'test_k': 'test_v'}", json_only=True)

# Generated at 2022-06-11 09:05:15.109277
# Unit test for function from_yaml
def test_from_yaml():
    '''
    from_yaml function unit test
    '''
    assert from_yaml("{'a': 1}") == {'a': 1}
    assert from_yaml("a: 1") == {'a': 1}
    assert from_yaml("1") == 1
    assert from_yaml("- 1") == [-1]
    assert from_yaml("1.1") == 1.1

    # integer limits
    assert from_yaml("18446744073709551615") == 18446744073709551615
    assert from_yaml("18446744073709551616") == u'18446744073709551616'

    # json boolean handling
    assert from_yaml('false') is False
    assert from_yaml('true') is True
    assert from_

# Generated at 2022-06-11 09:05:26.995502
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

    # test empty string
    with pytest.raises(AnsibleParserError):
        from_yaml('', json_only=True)

    # test empty yaml
    with pytest.raises(AnsibleParserError):
        from_yaml('', json_only=False)

    # test empty json
    with pytest.raises(AnsibleParserError):
        from_yaml('{}')

    # test some simple yaml data
    assert from_yaml('[ 1, 2, 3]', json_only=True) is None

    assert from_yaml('[ 1, 2, 3]', json_only=False) == [1, 2, 3]

    # test some simple json data

# Generated at 2022-06-11 09:05:29.817430
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}
    assert from_yaml('a: 1\nb: 2') == {'a': 1, 'b': 2}

# Generated at 2022-06-11 09:05:34.273763
# Unit test for function from_yaml
def test_from_yaml():
    try:
        x = from_yaml("[{'a': 'fish'}, {'a': 'fox'}]")
        y = from_yaml('[{"a": "fish"}, {"a": "fox"}]')
        assert x == y == [{"a": "fish"}, {"a": "fox"}]
    except:
        assert False

# Generated at 2022-06-11 09:05:36.347519
# Unit test for function from_yaml
def test_from_yaml():
    data = "this is a test"
    new_data = from_yaml(data)
    assert new_data == data

# Generated at 2022-06-11 09:05:44.956492
# Unit test for function from_yaml
def test_from_yaml():
    jdata = "---\nnull: null"
    result1 = from_yaml(jdata)
    assert result1 == {"null": None}
    result2 = from_yaml(jdata, json_only=True)
    assert result2["null"] == "null"
    if __name__ == "__main__":
        test_from_yaml()

# Generated at 2022-06-11 09:05:50.857611
# Unit test for function from_yaml
def test_from_yaml():
    data = {'var1': 'val1', 'var2': 'val2'}
    yaml_data = "var1: val1\nvar2: val2\n"
    assert from_yaml(yaml_data) == data
    assert from_yaml(yaml_data, json_only=True) is None
    assert from_yaml(yaml_data, vault_secrets=({"vault_id": "test"},)) == data

# Generated at 2022-06-11 09:06:00.251710
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # basic test
    test_value = {u'a': u'foo', u'b': u'bar'}
    test_yaml_string = to_native(AnsibleDumper().dump(test_value, width=1000))
    test_data = from_yaml(test_yaml_string)
    assert test_data == test_value

    # test with templating
    templar = Templar(loader=DataLoader())
    test_yaml_string = to_native(AnsibleDumper().dump(test_value, width=1000))

# Generated at 2022-06-11 09:06:13.285931
# Unit test for function from_yaml
def test_from_yaml():
    import datetime
    from ansible.vars.manager import VariableManager

    data = """
    foo:
        hosts:
        - localhost
        gather_facts: no
        tasks:
        - debug:
            msg: hello from {{ ansible_user }} to {{ socket.gethostname() }}
    """
    res = from_yaml(data, vault_secrets=VariableManager()._vault._secrets)
    assert isinstance(res, dict)
    assert 'foo' in res
    assert isinstance(res['foo'], dict)
    assert 'hosts' in res['foo']
    assert isinstance(res['foo']['hosts'], list)
    assert 'localhost' in res['foo']['hosts']
    assert 'gather_facts' in res['foo']

# Generated at 2022-06-11 09:06:20.066491
# Unit test for function from_yaml
def test_from_yaml():
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.urls as urlutils
    import requests
    yaml_url = "https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/parsing/whitelist_values.yaml"
    yaml_text = requests.get(yaml_url).text
    assert(isinstance(from_yaml(yaml_text), dict))
    return True

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:06:31.771595
# Unit test for function from_yaml
def test_from_yaml():

    # Helper function to generate AnsibleBaseYAMLObject
    def create_yaml_object(yaml_string, file_name='<none>'):
        err_obj = AnsibleBaseYAMLObject()
        err_obj.ansible_pos = (file_name, 1, 1)
        err_obj.ansible_line = yaml_string
        return err_obj

    # Empty string
    assert from_yaml('', show_content=False) is None

    # Valid strings
    assert from_yaml('{}', show_content=False) == {}
    assert from_yaml('{"foo": "bar"}', show_content=False) == {"foo": "bar"}

# Generated at 2022-06-11 09:06:42.002353
# Unit test for function from_yaml
def test_from_yaml():
    "Loads a python datastructure from either a JSON or YAML string"
    def ansible_json_encoder(obj):
        "Passed to the encoder to handle the Ansible types"
        if obj and getattr(obj, 'ansible_types', None):
            return {'__ansible_user_type__': obj.ansible_types}
        return obj

    # Create a JSON string from a python datastructure
    test_data = dict(base_url='http://example.com/', ansible=dict(version='2.4.3.0'))
    test_data['ansible_types'] = ['test_data']
    json_test_data = json.dumps(test_data, default=ansible_json_encoder)

# Generated at 2022-06-11 09:06:48.327803
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": "bar" }') == { 'foo': 'bar' }
    assert from_yaml('{ foo: bar }') == { 'foo': 'bar' }
    assert from_yaml('{ foo: [1, 2, 3] }') == { 'foo': [1, 2, 3] }
    assert from_yaml('{ foo: [1, 2, 3] }', json_only=True) == { 'foo': [1, 2, 3] }

# Generated at 2022-06-11 09:06:57.244955
# Unit test for function from_yaml
def test_from_yaml():
    from nose.tools import assert_equals


# Generated at 2022-06-11 09:07:06.133045
# Unit test for function from_yaml

# Generated at 2022-06-11 09:07:19.270553
# Unit test for function from_yaml
def test_from_yaml():

    # Checking the return type is dict.
    # Incase of string input, json.loads will be called and the return type of
    # json.loads is dict.
    assert type(from_yaml(u'{\n    "key": "value"\n}')) is dict

    # Checking the return type is dict.
    # Incase of string input, json.loads will be called and the return type of
    # json.loads is dict.
    assert type(from_yaml(u'[\n  {\n    "key": "value"\n  },\n  {\n    "abc": "def"\n  }\n]')) is dict



# Generated at 2022-06-11 09:07:24.698669
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    parts:
        - name: one
          part_no: 1
          desc: one
    '''

    assert from_yaml(data=yaml_str, json_only=True) is None
    assert from_yaml(data=yaml_str) == {'parts': [{'name': 'one', 'part_no': 1, 'desc': 'one'}]}

# Generated at 2022-06-11 09:07:31.899874
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.ajson import AnsibleJSONDecoder
    import os.path
    import sys
    import tempfile
    import shutil

    this_dir = os.path.dirname(__file__)
    yaml_data_dir = os.path.join(this_dir, '..', '..', 'test', 'units', 'parsing', 'yaml_data')


# Generated at 2022-06-11 09:07:44.621461
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'json': 'works'}", json_only=False) == {'json': 'works'}
    assert from_yaml("{'json': 'works'}", json_only=True) == {'json': 'works'}
    assert from_yaml("{\"json\": 'works'}") == {'json': 'works'}
    assert from_yaml("{'json': \"works\"}") == {'json': 'works'}
    assert from_yaml("{u'json': u'works'}") == {'json': 'works'}
    assert from_yaml("json: works") == {'json': 'works'}
    assert from_yaml("json: this 'works' too") == {'json': "this 'works' too"}
    assert from_yaml

# Generated at 2022-06-11 09:07:52.687361
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string = '''
    {
      "key": "value",
      "key2": [
        "value1",
        "value2"
      ],
      "key3": [],
      "key4": {
        "key4_1": "value3"
      },
      "key5": true,
      "key6": [
        {
          "key6_1": [
            {
              "key6_1_1": "value4"
            }
          ]
        }
      ],
      "key7": [
        {
          "key7_1": [
            {
              "key7_1_1": "value5"
            }
          ]
        }
      ]
    }
    '''
    yaml_dict = from_yaml(yaml_string)

# Generated at 2022-06-11 09:07:59.164097
# Unit test for function from_yaml
def test_from_yaml():
    # test with json string
    input_str = """{
      "changed": false,
      "ping": "pong"
    }"""
    AnsibleJSONDecoder.set_secrets(None)
    new_data = from_yaml(input_str, file_name='<string>', show_content=True, vault_secrets=None)
    assert new_data['ping'] == "pong"
    assert new_data['changed'] == False
    assert new_data.get('failed', None) == None

# Generated at 2022-06-11 09:08:10.535372
# Unit test for function from_yaml
def test_from_yaml():
    '''Unit test for function from_yaml'''

    def do_parse_yaml_test(data, expected_result, expected_raises=None, json_only=False):
        try:
            the_data = from_yaml(data, show_content=False, json_only=json_only)
            assert the_data == expected_result, "Got: %s" % the_data
        except Exception as e:
            if expected_raises:
                assert type(e).__name__ == expected_raises, "Got %s, but %s was expected" % (type(e).__name__, expected_raises)
            else:
                raise

    # valid yaml test cases
    do_parse_yaml_test("{ }", {})

# Generated at 2022-06-11 09:08:18.231516
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert from_yaml("{}") == {}
    assert from_yaml("[1, 2, 3]") == [1, 2, 3]
    assert from_yaml("test") == "test"

    assert from_yaml("test: foo") == {"test": "foo"}
    assert from_yaml("key: {a: 1, b: 2}") == {"key": {"a": 1, "b": 2}}
    assert from_yaml("key:\n  - a: 1\n  - b: 2") == {"key": [{"a": 1}, {"b": 2}]}

# Generated at 2022-06-11 09:08:21.411191
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[]') == []
    assert from_yaml('{"a": 1}') == {'a': 1}
    assert from_yaml('-b\n- c') == ['b', 'c']

# Generated at 2022-06-11 09:08:33.029856
# Unit test for function from_yaml
def test_from_yaml():
    # Create a fake YAML data string
    print("\n*** Testing the creation of a fake YAML data string ***")
    data = """
    ---
    - hosts: localhost
      tasks:
      - name: include a variable
        debug: msg="{{ test_var }}"
    """
    print("\n*** Data string: \n{0}\n".format(data))

    # Test from_yaml on the fake YAML data string
    print("\n*** Testing from_yaml on the data string ***")
    new_data = from_yaml(data)
    print("\n*** The new data string is: \n{0}\n".format(new_data))
    assert new_data is not None

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:08:54.799236
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') == None
    assert from_yaml('', vault_secrets=[]) == None

    # JSON
    assert from_yaml('{}') == {}
    assert from_yaml('{}', vault_secrets=[]) == {}
    assert from_yaml('{ "a":"b" }') == { "a": "b" }
    assert from_yaml('{ "a":"b" }', vault_secrets=[]) == { "a": "b" }

    # YAML
    assert from_yaml('[]') == []
    assert from_yaml('[]', vault_secrets=[]) == []
    assert from_yaml('{}') == {}
    assert from_yaml('{}', vault_secrets=[]) == {}

# Generated at 2022-06-11 09:08:57.389876
# Unit test for function from_yaml
def test_from_yaml():
    data = {'test': 1, 'test2': '2'}
    yaml_str = u"test: 1\n" \
               "test2: '2'"
    assert data == from_yaml(yaml_str)

# Generated at 2022-06-11 09:09:06.914786
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import os
    import tempfile

    def create_fake_vault_secret(vault_id, secret, **kwargs):
        return AnsibleUnicode(u"$ANSIBLE_VAULT;2.0;" + u';'.join([u"%s=%s" % (key, value) for (key, value) in kwargs.items() if value is not None]) + u";" + vault_id + u"\n" + secret + u"\n")

    data = u"""
    --- json_object
    foo: bar
    baz: qux
    """

# Generated at 2022-06-11 09:09:18.886141
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[1, 2, 3]") == [1, 2, 3]
    assert from_yaml("[1, 2, 3]", json_only=True) == [1, 2, 3]
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}
    assert from_yaml("{'foo': 'bar'}", json_only=True) == {'foo': 'bar'}
    assert from_yaml("{'foo': 'bar'}", json_only=True) == {'foo': 'bar'}
    assert from_yaml("""
        {
          'foo': 'bar'
        }
        """) == {'foo': 'bar'}

# Generated at 2022-06-11 09:09:26.155849
# Unit test for function from_yaml
def test_from_yaml():
    '''Parse a YAML string and ensure it is a dict with the right contents'''
    result = from_yaml('{foo: bar}')
    assert isinstance(result, dict)
    assert 'foo' in result
    assert result['foo'] == 'bar'

    # Ensure nulls and floats are parsed correctly
    result = from_yaml("""---
floatSecond:
  value: 1.1
  type: float
floatSecond:
  value: 2.2
  type: float
nullSecond:
  type: null
booleanSecond:
  value: true
  type: boolean""")
    assert result['floatSecond']['type'] == 'float'
    assert result['floatSecond']['value'] == 1.1
    assert result['nullSecond']['type'] == 'null'

# Generated at 2022-06-11 09:09:35.243978
# Unit test for function from_yaml
def test_from_yaml():
    expected = {
        'a': 'b',
        'c': ['d'],
        'e': {
            'f': ['g']
        }
    }
    input = '''a: b
c:
- d
e:
    f:
    - g
'''
    assert from_yaml(input) == expected
    assert from_yaml("{% for i in [1] %}foo{% endfor %}: bar", show_content=False) == {u'foo': u'bar'}
    assert from_yaml("{% for i in [1] %}foo{% endfor %}: bar", show_content=True) == {u'foo': u'bar'}

# Generated at 2022-06-11 09:09:44.344290
# Unit test for function from_yaml
def test_from_yaml():

    data = """
    - name: hello world
      version: 1
      items:
        - test
        - test2
    """

    new_data = from_yaml(data)
    assert isinstance(new_data, list)
    assert new_data[0]['name'] == 'hello world'
    assert new_data[0]['version'] == 1
    assert new_data[0]['items'] == ['test', 'test2']

    data = """
    {
        "Name": "Chandra",
        "Age": 35,
        "City": "Hyderabad"
    }
    """

    new_data = from_yaml(data)
    assert isinstance(new_data, dict)
    assert new_data['Name'] == 'Chandra'
    assert new_data['Age'] == 35


# Generated at 2022-06-11 09:09:55.265601
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "test": { "greetings": "hello world" } }'
    assert from_yaml(data, file_name='<string>')['test']['greetings'] == 'hello world'

    # broken YAML should fail next

    data = '{ "test": { "greetings": "hello world" }'

# Generated at 2022-06-11 09:09:57.569117
# Unit test for function from_yaml
def test_from_yaml():
    parser = from_yaml('{"test": "unit_test"}')
    assert parser.get('test') == 'unit_test'

# Generated at 2022-06-11 09:10:05.925773
# Unit test for function from_yaml
def test_from_yaml():
    '''
    from_yaml(data, file_name, show_content=True, vault_secrets=None, json_only=False)
        data - hash of the data to parse, can be YAML or JSON
        file_name - file name that the data came from, used only for error display
        show_content - boolean; if True, the line and column where the error occurred
        vault_secrets - optional list of vault secrets (as strings) to decrypt the data with
        json_only - only attempt to parse the data as JSON, do not fall back to YAML

    Creates a python datastructure from the given data, which can be either
    a JSON or YAML string.
    '''
    assert from_yaml('{"foo":"bar"}') == {"foo": "bar"}

# Generated at 2022-06-11 09:10:31.475751
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import os.path
    import subprocess
    import tempfile
    import unittest
    workdir = tempfile.mkdtemp()

# Generated at 2022-06-11 09:10:44.469282
# Unit test for function from_yaml
def test_from_yaml():

    import os
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    if os.path.exists('/tmp/testdata'):
        os.unlink('/tmp/testdata')

    f = open('/tmp/testdata', 'wb')
    f.write(b'{"a":1}')
    f.close()

    f = open('/tmp/testdata', 'rb')
    ds = from_yaml(f, '/tmp/testdata')
    f.close()

    assert ds == {'a': 1}

    # Now test file URL.
    f = open('/tmp/testdata', 'wb')
    f.write(b'{"a":2}')
    f.close()


# Generated at 2022-06-11 09:10:52.938164
# Unit test for function from_yaml
def test_from_yaml():
    def compare_valid_yamls(yaml_data):
        json_data = json.loads(json.dumps(yaml_data))
        assert from_yaml(yaml_data) == json_data
        assert from_yaml(json.dumps(yaml_data)) == json_data
    compare_valid_yamls({"a": {"b": [{"c": "d"}, {"e": "f"}]}})
    compare_valid_yamls({"a": {"b": "c"}})


# Generated at 2022-06-11 09:11:00.501253
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a simple valid yaml
    simple_yaml = "foo: bar"
    # This should succeed and return a dictionary.
    from_yaml(simple_yaml)
    # Test with an invalid yaml
    simple_yaml = "foo: bar\nbaz: blah"
    # This should raise an exception.
    from_yaml(simple_yaml)
    printf("Unit test for function from_yaml passed.\n")

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:11:11.268221
# Unit test for function from_yaml
def test_from_yaml():
    # Set the vault secrets for the test
    vault_test_passwords = ('test_from_yaml_password',)
    from_yaml.vault_secrets = vault_test_passwords

    # Test with valid JSON data
    json_data = '{"all": {"hosts": {"host1.domain.com": {"hostvars": {"ansible_user": "{{ vault_ansible_user }}"}}}}}'
    with open('test_from_yaml.vault', 'w') as vault_file:
        vault_file.write('$ANSIBLE_VAULT;1.1;AES256\n')

# Generated at 2022-06-11 09:11:16.643171
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1 }') == {"a": 1}  # JSON
    assert from_yaml('a\n1') == {'a': 1}  # YAML
    assert from_yaml('{ "a": 1 }', json_only=True) == {"a": 1}  # JSON Only

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:11:21.250973
# Unit test for function from_yaml
def test_from_yaml():
    # Verify that from_yaml has no internal dependencies on other classes or functions.
    # It should also work without any vault_secrets loaded.
    try:
        from_yaml('{ "bogus": "yaml" }', json_only=True)
        from_yaml('{ "bogus": "yaml" }', vault_secrets={})
        from_yaml('bogus: yaml', vault_secrets={})
    except:
        assert False

# Generated at 2022-06-11 09:11:30.843791
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    yaml_string = '{"test": "1", "test2": "2"}'
    ansible_dumper = AnsibleDumper()

    # validating the encoding
    assert(from_yaml(ansible_dumper.encode(json.loads(yaml_string))) == json.loads(yaml_string))

    # validating the decoding
    assert(from_yaml(yaml_string) == json.loads(yaml_string))

    # validating the decoding process on AnsibleDumper class
    assert(from_yaml(ansible_dumper.encode(json.loads(yaml_string))) == json.loads(yaml_string))

# Generated at 2022-06-11 09:11:40.425590
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '{"a": "b"}'

    # Test a valid JSON object
    assert from_yaml(data) == json.loads(data, cls=AnsibleJSONDecoder)

    # Test a valid YAML object
    data = '---\na: b\n'
    assert from_yaml(data) == {"a": "b"}

    # Test a valid YAML list
    data = '---\n- a\n- b\n'
    assert from_yaml(data) == ["a", "b"]

    # Test an invalid JSON object
    data = '{"a": "b" '
    assert from_yaml(data) == None

    # Test a valid JSON object with a bad decrypt

# Generated at 2022-06-11 09:11:48.212135
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    # JSON
    json_data = {
            "b": {
                "a": 0,
                "b": "c"
            },
            "a": 1
        }
    json_string = '{"a": 1, "b": {"a": 0, "b": "c"}}'
    assert from_yaml(json_string) == json_data
    assert from_yaml(json_string, json_only=True) == json_data
    # YAML
    yaml_data = {
        "a": 1,
        "b": {
            "a": 0,
            "b": "c"
        }
    }

# Generated at 2022-06-11 09:12:34.576301
# Unit test for function from_yaml
def test_from_yaml():
    import unittest

    def test_validate_from_yaml(self):
        data = '{"a": "b"}'
        new_data = {"a": "b"}
        self.assertEqual(from_yaml(data), new_data)

        data = "{'a': 'b'}"
        new_data = {"a": "b"}
        self.assertEqual(from_yaml(data), new_data)

        data = "{'a': 'b', 'c': 'd'}"
        new_data = {"a": "b", "c": "d"}
        self.assertEqual(from_yaml(data), new_data)

        data = "- a"
        new_data = ["a"]
        self.assertEqual(from_yaml(data), new_data)

        data

# Generated at 2022-06-11 09:12:46.214575
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault

    test_string = '{ "test": "{{ testvar }}" }'

    secrets = vault.get_vault_secrets(None, None)
    # Unencrypted var
    assert from_yaml(test_string, vault_secrets=secrets) == {'test': '{{ testvar }}'}

    # Encrypted var

# Generated at 2022-06-11 09:12:52.425378
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.utils.unsafe_proxy

    data = """
    ---
    # test
    tests:
      - a
      - b
      -
        - c
        - d
    """

    try:
        assert from_yaml(data) == {u'tests': [u'a', u'b', [u'c', u'd']]}
    except AssertionError:
        assert from_yaml(data) == {'tests': ['a', 'b', ['c', 'd']]}

# Generated at 2022-06-11 09:13:02.265822
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    data = u'["a", "b", "c"]'
    assert from_yaml(data) == ["a", "b", "c"]
    data = u'{"a": 1, "b": "c"}'
    assert from_yaml(data) == {"a": 1, "b": "c"}
    data = u'{"a": [1, 2, 3], "b": "c"}'
    assert from_yaml(data) == {"a": [1, 2, 3], "b": "c"}
    data = u'{"a": "{{ variable }}", "b": "c"}'
    assert from_yaml(data) == {"a": "{{ variable }}", "b": "c"}

# Generated at 2022-06-11 09:13:10.907022
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_text
    from ansible.utils.unicode import to_unicode

    test_data = '''
        foo:
            - 1
            - 2
            - 3
        bar:
            bam: true
            baz: false
        bam: [1, 2, 3]
        '''
    test_data_dict = {u'foo': [1, 2, 3], u'bar': {u'bam': True, u'baz': False}, u'bam': [1, 2, 3]}
    assert test_data_dict == from_yaml(to_unicode(test_data))
    assert test_data_dict == from_yaml(to_text(test_data))

# Generated at 2022-06-11 09:13:20.435700
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") == {u'foo': u'bar'}
    assert from_yaml("{'foo': 'bar'}", json_only=True) == {u'foo': u'bar'}
    assert from_yaml("{'foo': \"bar\"}") == {u'foo': u'bar'}
    assert from_yaml("{'foo': [1,2,3]}") == {u'foo': [1, 2, 3]}
    assert from_yaml("{'foo': [1,2,3]}", json_only=True) == {u'foo': [1, 2, 3]}

# Generated at 2022-06-11 09:13:28.987618
# Unit test for function from_yaml
def test_from_yaml():

    sample_json = '{"a": "b"}'
    sample_yaml = 'a: b'

    # test a JSON string
    ansible_data = from_yaml(sample_json)
    assert ansible_data['a'] == 'b'

    # test a YAML string
    ansible_data = from_yaml(sample_yaml)
    assert ansible_data['a'] == 'b'

    # test an invalid YAML string
    ansible_data = from_yaml('a :')
    assert ansible_data['a'] == 'b'

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:13:33.012109
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml("""
    - hosts: localhost
      tasks:
        - name: test task
          debug:
            var: "{{ 'test' if foo else 'fail' }}"
    """)
    assert result == {
        'tasks': [{
            'name': 'test task',
            'debug': {
                'var': '{{ \'test\' if foo else \'fail\' }}'
            }
        }],
        'hosts': 'localhost'
    }

# Generated at 2022-06-11 09:13:45.351585
# Unit test for function from_yaml
def test_from_yaml():
    # JSON Tests
    assert from_yaml("{'a': 'b'}") == {'a': 'b'}
    assert from_yaml("{}") == {}
    assert from_yaml("{\"a\": 1}") == {"a": 1}
    assert from_yaml("{\"a\": [\"b\", \"c\"]}") == {"a": ["b", "c"]}
    assert from_yaml("{}", json_only=True) == {}
    assert from_yaml("{\"a\": 1}", json_only=True) == {"a": 1}
    assert from_yaml("{\"a\": [\"b\", \"c\"]}", json_only=True) == {"a": ["b", "c"]}

    # YAML Tests
    assert from_yaml("a: b")

# Generated at 2022-06-11 09:13:50.258753
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    yaml.safe_dump(dict(key="value"), default_flow_style=False, Dumper=AnsibleDumper)
    yaml.safe_dump(dict(key="value"), default_flow_style=False, Dumper=AnsibleDumper)