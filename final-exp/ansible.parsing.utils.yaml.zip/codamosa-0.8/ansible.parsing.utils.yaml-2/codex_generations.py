

# Generated at 2022-06-11 09:04:41.018854
# Unit test for function from_yaml
def test_from_yaml():

    # Testing with a JSON string
    data = '''{
          "test_var1": {
            "hosts": ["host-1", "host-2", "host-3"],
            "vars": {
              "var1": false,
              "var2": 3
            }
          }
        }
    '''

    result = from_yaml(data, 'test.yml')
    assert result == {'test_var1': {u'vars': {u'var2': 3, u'var1': False}, u'hosts': [u'host-1', u'host-2', u'host-3']}}

    # Testing with an empty string
    data = ''
    result = from_yaml(data, 'test.yml')
    assert result == {}


# Generated at 2022-06-11 09:04:51.763913
# Unit test for function from_yaml
def test_from_yaml():
    # test case 1
    data = """
    peter: 123
    paul: 456
    """

    _data = from_yaml(data, file_name='<string>')
    assert _data['peter'] == 123
    assert _data['paul'] == 456

    # test case 2
    data = '{"test": "msg"}'

    _data = from_yaml(data, file_name='<string>')
    assert _data['test'] == 'msg'

    # test case 3
    data = '{"test": "msg"\n}\n'

# Generated at 2022-06-11 09:05:05.410301
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    test_dir = os.path.dirname(os.path.realpath(__file__))
    yaml_file = os.path.join(test_dir, 'test_documents/user_defined_b64.yml')

    with open(yaml_file) as test_data:
        data = test_data.read()

    with patch.object(sys, 'argv', ['ansible', '--vault-id', '@prompt']):
        # first test with vault-id argument
        result = from_yaml(data)

# Generated at 2022-06-11 09:05:13.507039
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    test_input_yaml = {
        "key1": "value1",
        "key2": "value2",
        "key3": {
            "key4": "value4",
            "key5": "value5",
            "key6": [0, 1, 2, 3, 4, 5, 6]
        }
    }
    test_input_json = json.dumps(test_input_yaml, sort_keys=True, indent=2, cls=AnsibleJSONDecoder)
    test_input_yaml_string = yaml.dump(test_input_yaml, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-11 09:05:24.832774
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()

    # Test yaml
    data = 'foo: bar'
    new_data = from_yaml(data)
    assert not isinstance(new_data['foo'], AnsibleUnicode)
    assert new_data['foo'] == 'bar'

    # Test json
    data = '{"foo": "bar"}'
    new_data = from_yaml(data)
    assert isinstance(new_data['foo'], AnsibleUnicode)
    assert new_data['foo'] == 'bar'

    # Test invalid yaml
    data = '"foo" bar'

# Generated at 2022-06-11 09:05:32.236129
# Unit test for function from_yaml
def test_from_yaml():

    # Test to load Ansible Playbook
    assert isinstance(from_yaml("""\
- hosts: all
  tasks:
    - debug: msg=\"Hello World\""""), list)

    # Test to load Ansible Playbook in JSON format
    assert isinstance(from_yaml("""\
[
    {
        "hosts": "all",
        "tasks": [
            {
                "debug": {
                    "msg": "Hello World"
                }
            }
        ]
    }
]"""), list)

# Generated at 2022-06-11 09:05:42.075153
# Unit test for function from_yaml
def test_from_yaml():
    from unittest import TestCase

    class ParameterizedTestCase(TestCase):
        """ TestCase classes that want to be parameterized should
            inherit from this class.
        """
        def __init__(self, methodName='runTest', test_data=None):
            super(ParameterizedTestCase, self).__init__(methodName)
            self.test_data = test_data

    class TestUnit_from_yaml(ParameterizedTestCase):
        def test_case_01(self):
            data = self.test_data[0]
            expected = self.test_data[1]
            result = from_yaml(data)
            self.assertEqual(expected, result)


# Generated at 2022-06-11 09:05:51.697730
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import unittest
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestModule(unittest.TestCase):

        def test_to_json(self):
            my_dict = {'a': 1, 'b': 2, 'c': 3}
            data = json.dumps(my_dict, sort_keys=True, indent=4, separators=(',', ': '))
            yaml_data = from_yaml(data, json_only=True)
            self.assertEqual(my_dict['a'], yaml_data['a'])

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-11 09:05:58.435452
# Unit test for function from_yaml
def test_from_yaml():

    import ansible.module_utils.basic

    data = '''
    - hosts: localhost
      connection: local
      tasks:
      - name: test
        test_from_yaml:
          name: "{{ ansible_date_time.iso8601 }}"
          state: present
        register: result
      - debug:
          var: result.ansible_facts.test_from_yaml
    '''

    playbook = ansible.module_utils.basic.AnsibleModule({}).load_from_file('', data)
    assert playbook

# Generated at 2022-06-11 09:06:04.177554
# Unit test for function from_yaml
def test_from_yaml():
    good_yaml = """
    hello: world
    """

    good_json = """{"hello": "world"}"""

    bad_yaml = """
    hello:
        - world
    """

    bad_json = """
    hello:
        - world
    """

    # Test good YAML
    assert from_yaml(good_yaml) == {"hello": "world"}

    # Test good JSON
    assert from_yaml(good_json) == json.loads(good_json)

    # Test bad YAML
    # from_yaml should raise an error because there's an extra dash in the string

# Generated at 2022-06-11 09:06:16.093344
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 3 }') == {'a': 3}
    assert from_yaml('[1, 2, 3]') == [1,2,3]
    assert from_yaml('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert from_yaml('[') is None
    assert from_yaml('{') is None
    assert from_yaml('[1') is None
    assert from_yaml('{1') is None
    assert from_yaml('') is None


# Generated at 2022-06-11 09:06:24.148943
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml.
    '''

    # Try a JSON string
    text = '''
{
    "michael": {
        "age": 25,
        "is_old": false,
        "loves": ["python","ansible","swimming","sauna"],
        "has_a_dog": false
    },
    "jesse": {
        "age": 29,
        "is_old": true,
        "loves": ["ansible","cooking","batman","jerry"],
        "has_a_dog": true
    }
}
'''

# Generated at 2022-06-11 09:06:35.116092
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert from_yaml('', json_only=True) is None

    assert from_yaml('{"a":2,"b":{}}') == {'a': 2, 'b': {}}

    assert from_yaml('[1,2,3]') == [1, 2, 3]

    assert from_yaml('[1,2,3]', json_only=True) == [1, 2, 3]

    assert from_yaml('{"a":2,"b":[1,2,3]}', json_only=True) == {'a': 2, 'b': [1, 2, 3]}

# Generated at 2022-06-11 09:06:45.725122
# Unit test for function from_yaml
def test_from_yaml():
    unittest.TestCase.assertEqual(from_yaml("{'key': 'value'}"), {u'key': u'value'})
    unittest.TestCase.assertEqual(from_yaml("{'key': 138}"), {u'key': 138})
    unittest.TestCase.assertEqual(from_yaml("{'key': [1, 2, '3']}"), {u'key': [1, 2, u'3']})
    unittest.TestCase.assertEqual(from_yaml("{'key': [1, 2, '3']}"), {u'key': [1, 2, u'3']})
    unittest.TestCase.assertEqual(from_yaml("'key'"), u'key')
    unittest.TestCase.assertE

# Generated at 2022-06-11 09:06:53.030640
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
---
- name: Test
  hosts: all
- name: Another test
  hosts: localhost
  gather_facts: yes
    '''
    result = from_yaml(data, json_only=False)
    assert len(result) == 2
    assert result[0]['name'] == 'Test'
    assert result[1]['hosts'] == 'localhost'
    assert result[1]['gather_facts'] == 'yes'

    data_json = '''
    [{"name": "Test", "hosts": "all"}, {"name": "Another test", "hosts": "localhost", "gather_facts": "yes"}]
    '''
    result = from_yaml(data_json, json_only=False)
    assert isinstance(result, list)

# Generated at 2022-06-11 09:06:56.936645
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'''
        {
            "test": {
                "test_results": [
                    "test",
                    "test2"
                ]
            }
        }
    ''') == {'test': {'test_results': ['test', 'test2']}}



# Generated at 2022-06-11 09:07:00.299308
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ 'a' : 1 }") == {'a': 1}
    try:
        from_yaml("a: 1")
        assert False
    except AnsibleParserError as e:
        assert 'We were unable to read either as JSON nor YAML' in str(e)


# Generated at 2022-06-11 09:07:10.585721
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = '{ "foo": "bar" }'
    result = from_yaml(data)
    assert result == {u'foo': u'bar'}
    assert isinstance(result['foo'], AnsibleUnicode)

    data = '{ foo: bar }'
    result = from_yaml(data)
    assert result == {u'foo': u'bar'}
    assert isinstance(result['foo'], AnsibleUnicode)

    data = '{ foo: bar }'
    result = from_yaml(data, json_only=True)
    assert result == data

    data = '{ "foo": "bar" }'
    result = from_yaml(data, json_only=True)
    assert result

# Generated at 2022-06-11 09:07:19.814602
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
{
    "name": "test",
    "value": 1.5,
    "dict": {
        "string": "dict string"
    },
    "list": [
        "list item one",
        "list item two"
    ]
}
    """
    result = from_yaml(test_data)
    assert result['name'] == 'test'
    assert result['value'] == 1.5
    assert result['dict']['string'] == 'dict string'
    assert result['list'][0] == 'list item one'
    assert result['list'][1] == 'list item two'

test_from_yaml()

# Generated at 2022-06-11 09:07:29.126211
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = '''
a: foo
b:
  - 1
  - 2
c:
  c1:
    d1: this is d1
  c2:
    d2: this is d2
    d3:
      - x
      - y
      - z
    d4:
      - xx
      - yy
      - zz
  c3:
    - 1
    - 2
    - 3
'''
    result = from_yaml(test_yaml)
    assert result
    assert len(result) == 3
    assert 'a' in result
    assert result['a'] == 'foo'
    assert 'b' in result
    assert result['b'] == [1, 2]
    assert 'c' in result
    assert 'c1' in result['c']
   

# Generated at 2022-06-11 09:07:43.563468
# Unit test for function from_yaml

# Generated at 2022-06-11 09:07:47.651686
# Unit test for function from_yaml
def test_from_yaml():
    try:
        ### FIXME: TypeError: ord() expected a character, but string of length 0 found
        #from_yaml(data)
        pass
    except Exception as e:
        pass



if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:07:54.056603
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import glob

    TEST_DIR = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'sanity', 'validate-modules', 'yaml')

    if os.path.isdir(TEST_DIR):
        for filename in glob.glob(os.path.join(TEST_DIR, "*.yml")):
            f = open(filename, 'rb')
            r = from_yaml(f.read(), filename)
            if r is None:
                print('failed to process file: %s' % filename)
                sys.exit(1)
            else:
                print('successfully processed file: %s' % filename)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:07:59.029716
# Unit test for function from_yaml
def test_from_yaml():
    data = "---\n- abc\n- 123\n- '{{ foo.bar }}'"
    new_data = from_yaml(data)
    assert isinstance(new_data[2], AnsibleBaseYAMLObject)
    data = 'true'
    new_data = from_yaml(data)
    assert isinstance(new_data, bool)

# Generated at 2022-06-11 09:08:00.357410
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"a\":1}") == {"a": 1}

# Generated at 2022-06-11 09:08:12.199533
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    class TestYAMLObject(object):
        def __init__(self, data):
            self.data = data

        def __repr__(self):
            return "TestYAMLObject(%s)" % self.data

        @staticmethod
        def to_yaml(dumper, data):
            return dumper.represent_scalar(u'tag:yaml.org,2002:str', data.data)

    AnsibleDumper.add_multi_representer(TestYAMLObject, TestYAMLObject.to_yaml)
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:08:15.839746
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Provides a unit test for the from_yaml function.
    '''
    assert from_yaml('{"a":1}') == {"a": 1}
    assert from_yaml('a: 1') == {"a": 1}
    assert from_yaml('{a: 1}') != {"a": 1}
    assert from_yaml('{"a":1', json_only=True) != {"a": 1}

# Generated at 2022-06-11 09:08:25.860975
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.config.manager import ConfigManager
    from unit.mock.loader import DictDataLoader

    ad = AnsibleDumper()
    v_c = ConfigManager(loader=DictDataLoader({'defaults': {}}))
    v = VaultLib(v_c)
    data = {"vaulted": "{{vault_secret}}"}
    try:
        v.encrypt_string(ad.dump(data))
    except NotImplementedError:
        # running unit test in a non-python 2.7 environment, test is skipped
        return


# Generated at 2022-06-11 09:08:36.748150
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder

    original_data = dict(
        a=5,
        b=dict(
            c=[1,2,3],
            d="foo",
            e=dict(
                f=[],
                g=dict(
                    h='bar'
                )
            )
        ),
        i=' { foo: bar} '
    )

    # Test a YAML string
    yaml_string = yaml.dump(original_data, Dumper=AnsibleDumper, default_flow_style=False, indent=4)
    string_data = from_yaml(yaml_string)

    assert string_data == original_data

    # Test a JSON string
   

# Generated at 2022-06-11 09:08:49.231962
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test to ensure that from_yaml doesn't fail and return expected results.
    """
    expected = [{'hosts': '127.0.0.1', 'vars': {'ansible_connection': 'local'}}]
    assert from_yaml('[{hosts: 127.0.0.1, vars: {ansible_connection: local}}]') == expected
    assert from_yaml('[{\'hosts\': \'127.0.0.1\', \'vars\': {\'ansible_connection\': \'local\'}}]') == expected
    assert from_yaml('[{hosts: "127.0.0.1", vars: {ansible_connection: "local"}}]') == expected

# Generated at 2022-06-11 09:08:59.586185
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test for function from_yaml
    '''

    from ansible.parsing import vault

    # Make sure we are loading test secrets
    vault.get_file_vault_secrets = lambda _: {'vault_password_file': 'fake_secrets'}
    # Create a vault in the test data
    data = vault.encrypt_string('test', 'secret-stuff')
    # Load the data, making sure we can read the vault
    ansible_data = from_yaml(data, vault_secrets=dict(vault_password_file='fake_secrets'))
    assert ansible_data == 'test', ansible_data


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:09:09.712120
# Unit test for function from_yaml
def test_from_yaml():
    data = 'this is junk'
    try:
        from_yaml(data)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('a bad yaml string failed to raise an error')

    # Make sure we deal with byte and unicode data
    data = b'{"foo": "bar"}'
    assert from_yaml(data) == {'foo': 'bar'}

    data = u'{foo: bar}'
    assert from_yaml(data) == {'foo': 'bar'}

    # And with non-strings
    data = [1, 2, 3]
    assert from_yaml(data) == data
    data = {1: 2}
    assert from_yaml(data) == data

    # And with non-strings that look like strings

# Generated at 2022-06-11 09:09:21.529535
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(data=None, file_name='<string>', show_content=True, vault_secrets=None, json_only=False) is None
    assert from_yaml(data='abc', file_name='<string>', show_content=True, vault_secrets=None, json_only=False) == 'abc'
    assert from_yaml(data='123', file_name='<string>', show_content=True, vault_secrets=None, json_only=False) == 123
    assert from_yaml(data='[]', file_name='<string>', show_content=True, vault_secrets=None, json_only=False) == []

# Generated at 2022-06-11 09:09:31.717091
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedBytes

    test_pos_data = "test_data"
    test_len_data = len(test_pos_data)

    test_pos_data_b = "test_data"
    test_len_data_b = len(test_pos_data_b)


# Generated at 2022-06-11 09:09:41.714818
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    test_str = '''
- hosts: all
  gather_facts: no
  roles:
    - role: apache
    - role: postgresql
    - role: mysql
      tags:
      - 'database'
      - 'mysql'
    - role: foo
'''
    result = from_yaml(test_str)
    assert result is not None

    assert len(result) == 2
    assert isinstance(result[0], dict)
    assert isinstance(result[1], list)

    assert len(result[0]) == 2


# Generated at 2022-06-11 09:09:42.570485
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("abc") == "abc"

# Generated at 2022-06-11 09:09:48.624610
# Unit test for function from_yaml
def test_from_yaml():
    # Test case 1:
    # No password, valid JSON, valid YAML
    # Expect return YAML
    assert from_yaml("""{
        "plays": [{
            "hosts": "all"
        }]
    }""") == {'plays': [{'hosts': 'all'}]}

    # Test case 2:
    # No password, valid JSON, invalid YAML
    # Expect return JSON
    assert from_yaml("""{
        "plays": [
            "hosts": "all"
        ]
        }""") == {'plays': [{'hosts': 'all'}]}

    # Test case 3:
    # No password, invalid JSON, valid YAML
    import json

# Generated at 2022-06-11 09:10:00.276207
# Unit test for function from_yaml
def test_from_yaml():
    failure_msgs = []

# Generated at 2022-06-11 09:10:02.666676
# Unit test for function from_yaml
def test_from_yaml():
    # Create new object using function from_yaml
    new_data = from_yaml("{ a: 1 }")
    # Test attributes of the object new_data
    assert new_data['a'] == 1

# Generated at 2022-06-11 09:10:10.748504
# Unit test for function from_yaml
def test_from_yaml():
    import json

    assert from_yaml('[1,2,3]') == json.loads('[1,2,3]')
    assert from_yaml('{"a":1, "b":2}') == json.loads('{"a":1, "b":2}')

    # this should fail
    try:
        from_yaml('{"a":1, "b":2')
        assert False
    except AssertionError:
        pass
    except Exception as e:
        assert 'We were unable to read either as JSON nor YAML' in '%s' % to_native(e)

# Generated at 2022-06-11 09:10:23.969434
# Unit test for function from_yaml
def test_from_yaml():
    _test_data = [
        {'sample_data': '[{"a": 1, "b": [1,2], "d": {"a": "b"}}]', 'valid_json': True, 'valid_yaml': True},
        {'sample_data': '{"a": 1, "b": [1,2], "d": {"a": "b"}}', 'valid_json': True, 'valid_yaml': True},
        {'sample_data': 'a: 1', 'valid_json': False, 'valid_yaml': True},
        {'sample_data': 'a: 1\nb:', 'valid_json': False, 'valid_yaml': False}
    ]


# Generated at 2022-06-11 09:10:31.859549
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.ajson import AnsibleJSONDecoder
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    assert from_yaml("{'red': 'rojo', 'blue': 'azul'}") == {'blue': 'azul', 'red': 'rojo'}
    assert from_yaml("---") == {}
    assert from_yaml("{}") == {}
    assert from_yaml("blue: azul\nred: rojo") == {'blue': 'azul', 'red': 'rojo'}
    assert from_yaml("---\nblue: azul\nred: rojo") == {'blue': 'azul', 'red': 'rojo'}

# Generated at 2022-06-11 09:10:44.911216
# Unit test for function from_yaml
def test_from_yaml():
    json_data = '{"foo": "foovalue", "bar": "barvalue"}'
    json_result = from_yaml(json_data)
    assert json_result == {"foo": "foovalue", "bar": "barvalue"}

    yaml_data = """
    foo: foovalue
    bar: barvalue
    """
    yaml_result = from_yaml(yaml_data)
    assert yaml_result == {"foo": "foovalue", "bar": "barvalue"}

    # Note: it doesn't (currently) make sense to try to use the vaulted version of this test,
    # as the decryption happens in the parser, not here.


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 09:10:53.129723
# Unit test for function from_yaml
def test_from_yaml():
    # setup test variables

    # test a simple yaml string
    yaml_data = """
    a:
      - b
      - c
      - d
    """
    # test a simple json string
    json_data = '{"a": ["b", "c", "d"]}'
    # test a complex nested json string
    complex_json_data = '{"a": [{"b": "b", "c": "c"}, {"b": "e", "c": "f"}]}'
    # test a string with different syntax errors in both json and yaml
    file_name = 'test'
    show_content = False
    json_only = False
    vault_secrets = None

    # test a simple yaml string

# Generated at 2022-06-11 09:10:59.953570
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("foo: bar") == {'foo': 'bar'}
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('foo: bar\nfred: barney') == {'foo': 'bar', 'fred': 'barney'}
    assert from_yaml('one: two\n three\nfour: five') == {'one': 'two three', 'four': 'five'}

# Generated at 2022-06-11 09:11:10.763998
# Unit test for function from_yaml
def test_from_yaml():
    # Test JSON parsing
    assert from_yaml('{"key": ["value1", "value2"]}') == {'key': ['value1', 'value2']}

    # Test YAML parsing
    # Test single value
    assert from_yaml("key: value") == {'key': 'value'}
    # Test list value
    assert from_yaml("key: [value1, value2]") == {'key': ['value1', 'value2']}
    # Test quoted value from YAML spec
    assert from_yaml('key: "A \"quote\" may \\\\ also be indicated with \n\n"') == {'key': 'A "quote" may \\ also be indicated with \n\n'}
    # Test multiple values

# Generated at 2022-06-11 09:11:20.051872
# Unit test for function from_yaml
def test_from_yaml():
    value = ('[{"name": "a", "network_uuid": "uuid_a", "uuid": "uuid_a",'
             '"drbd_usermode_helper": "/usr/libexec/drbd/drbd-user-helper"},'
             '{"name": "b", "network_uuid": "uuid_b", "uuid": "uuid_b",'
             '"drbd_usermode_helper": "/usr/libexec/drbd/drbd-user-helper"}]')
    value = from_yaml(value)
    assert len(value) == 2
    assert 'uuid' in value[0]
    assert 'uuid' in value[1]
    assert value[0]['uuid'] == 'uuid_a'

# Generated at 2022-06-11 09:11:30.138566
# Unit test for function from_yaml
def test_from_yaml():
    # Test 1: Simple JSON
    assert from_yaml('{"name":"f", "age":1}') == {u'age': 1, u'name': u'f'}

    # Test 2: Simple YAML
    assert from_yaml('age: 1\nname: f') == {u'age': 1, u'name': u'f'}

    # Test 3: JSON with a comment.
    # This should fail because we cannot store comments and this should
    # be handled as JSON instead of YAML in order to prevent losing comments.
    # Caveat: If a YAML file has extra spaces at the end of a line then
    # the comment will be removed by yaml parser.
    #
    # e.g. in the following example, the comment at the end of the 2nd line
    # will be removed and the

# Generated at 2022-06-11 09:11:39.888079
# Unit test for function from_yaml

# Generated at 2022-06-11 09:11:47.991987
# Unit test for function from_yaml
def test_from_yaml():
    test_data = "{\"json_list\": [1, 2, 3]}"
    result = from_yaml(test_data, json_only=True)
    assert result == json.loads(test_data)

    test_data = "{{json_list: [1, 2, 3]}}"
    try:
        from_yaml(test_data, json_only=True)
    except AnsibleParserError as e:
        result = True

    assert result

    test_data = "{'json_list': [1, 2, 3]}"
    result = from_yaml(test_data, json_only=True)
    assert result == json.loads(test_data)

    test_data = "{'json_list': [1, 2, 3]}"
    result = from_yaml(test_data)
   

# Generated at 2022-06-11 09:12:05.482359
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import re

    if sys.version_info < (2, 7):
        from unittest2 import TestCase, skipUnless
    else:
        from unittest import TestCase, skipUnless
        from re import fullmatch

    assert fullmatch(re.compile(r"\d+\.[0-9.]*"), json.__version__) is not None

    class FromYaml(TestCase):
        def setUp(self):
            self.data = dict(
                a_list=["foo", "bar", "baz"],
                a_str="foobar",
                a_dict=dict(
                    answer=42,
                    foo="bar"
                )
            )

            self.data_json = json.dumps(self.data)

# Generated at 2022-06-11 09:12:08.460462
# Unit test for function from_yaml
def test_from_yaml():
    import doctest
    doctest.testmod(verbose=1)


# run unit tests if this isn't an import
if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:12:11.702881
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"name": "hello"}'
    assert from_yaml(data)
    data = '"name: hello"'
    assert from_yaml(data, json_only=True) is None
    assert from_yaml(data)



# Generated at 2022-06-11 09:12:14.694914
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') is None
    assert from_yaml('a') == 'a'
    assert from_yaml('a: 1') == dict(a=1)


# Generated at 2022-06-11 09:12:18.476163
# Unit test for function from_yaml
def test_from_yaml():
    s = '''
    hello: 1
    world: 2
    '''

    d = from_yaml(s)

    assert d['hello'] == 1
    assert d['world'] == 2
    assert d.get('foo') is None

# Generated at 2022-06-11 09:12:23.472411
# Unit test for function from_yaml
def test_from_yaml():
    data = "test_yaml: 'test_data'"
    parse_data = from_yaml(data)
    assert parse_data['test_yaml'] == 'test_data'
    # parse_data: {'test_yaml': 'test_data'}
    # test_parse_data = json.loads(parse_data)
    # assert test_parse_data == "test_data"

# Generated at 2022-06-11 09:12:33.499118
# Unit test for function from_yaml
def test_from_yaml():
    # Test 1: Regular YAML
    result = [dict(key='value')]
    data = "---\n- key: value"
    assert result == from_yaml(data)

    # Test 2: JSON
    result = [dict(key='value')]
    data = "[{\"key\": \"value\"}]"
    assert result == from_yaml(data)

    # Test 3: JSON
    result = [dict(key='value')]
    data = "[\n{\n\"key\": \"value\"\n}\n]"
    assert result == from_yaml(data)

    # Test 4: Vault
    result = [dict(key='vaultvalue')]

# Generated at 2022-06-11 09:12:43.875093
# Unit test for function from_yaml
def test_from_yaml():
    tests = (
        # check whether a yaml syntax error is detected
        # and the JSON error is ignored
        {'input': '{1:2}', 'expect': 'YAML parser error'},
        {'input': '{1:a}', 'expect': 'YAML parser error'},
        {'input': 'abc', 'expect': 'JSON parser error'},
        {'input': '123', 'expect': 'JSON parser error'},
        {'input': 'def', 'expect': 'JSON parser error'},
    )
    for t in tests:
        try:
            from_yaml(t['input'])
            assert False
        except AnsibleParserError as e:
            assert to_native(e).split(':', 1)[0] == t['expect']

# Generated at 2022-06-11 09:12:53.749729
# Unit test for function from_yaml
def test_from_yaml():
    """
    Unit test for function ansible.errors.yaml.from_yaml
    """

    from datetime import datetime
    from io import StringIO
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder

    from _json import dumps as json_dumps
    from yaml import dump as yaml_dump, dump_all as yaml_dump_all

    def to_yaml(obj, is_list=False):
        """
        Returns a YAML string representing obj
        """
        if is_list:
            return yaml_dump_all([obj], stream=None, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-11 09:13:04.276175
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
{
"from": "server-1.example.com",
"from_ip": "10.7.0.1",
"from_port": 56789,
"to": "server-2.example.com",
"to_ip": "192.168.0.1",
"to_port": "56789"
}
'''

    expected_data = {
        "from": "server-1.example.com",
        "from_ip": "10.7.0.1",
        "from_port": 56789,
        "to": "server-2.example.com",
        "to_ip": "192.168.0.1",
        "to_port": "56789"
    }

    assert from_yaml(data) == expected_data

# Generated at 2022-06-11 09:13:25.112674
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import tempfile
    import os
    import io
    import random
    import shutil
    import time
    import string

    # Store random passwords in vault files
    # generate random strings
    def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
        return ''.join(random.choice(chars) for _ in range(size))
    vault_random_string = id_generator()
    vault_random_string2 = id_generator()
    vault_random_string3 = id_generator()
    vault_random_string4 = id_generator()
    vault_random_string5 = id_generator()
    vault_random_string6 = id_generator()
    vault_random_string7 = id_generator()
    vault_

# Generated at 2022-06-11 09:13:28.773230
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": "bar"}'
    assert from_yaml(data) == {u'foo': u'bar'}

    data = 'foo: bar\n'
    assert from_yaml(data) == {u'foo': u'bar'}

# Generated at 2022-06-11 09:13:36.861469
# Unit test for function from_yaml
def test_from_yaml():
    # Test string that is valid json and yaml, with and without vault secrets
    test_string = """
    - name: Test play 1
      connection: local
      hosts: localhost
      gather_facts: no
      tasks:
        - name: Test task 1
          command: echo "Hello, world!"
          register: result
        - name: Test task 2
          command: echo "{{ result.stdout }}"
          when: result.rc == 0
    """

    # Test string that is not valid json or yaml

# Generated at 2022-06-11 09:13:49.124945
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_text

    json_str = to_text('''{
        "results": [
            {
                "item": {
                    "key": "value1"
                },
                "error": null
            },
            {
                "item": {
                    "key": "value2"
                },
                "error": null
            }
        ]
    }''')

    assert from_yaml(json_str) == {'results': [{'error': None, 'item': {'key': 'value1'}}, {'error': None, 'item': {'key': 'value2'}}]}


# Generated at 2022-06-11 09:13:57.670153
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml_string = ("---\n"
                        "- hosts: localhost\n"
                        "  become: true\n"
                        "  tasks:\n"
                        "   - name: Run {{ role_name }} role\n"
                        "     include_role: name={{ role_name }}")
    string_list = from_yaml(test_yaml_string)
    assert(string_list[0]['hosts'] == 'localhost')
    assert(string_list[0]['tasks'][0]['name'] == 'Run {{ role_name }} role')
    assert(string_list[0]['tasks'][0]['include_role']['name'] == '{{ role_name }}')


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:13:59.180747
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"{a\": \"b\"}") == {"{a": "b"}

# Generated at 2022-06-11 09:14:03.972335
# Unit test for function from_yaml
def test_from_yaml():
    data = "foo: {bar: baz}"
    file_name = "<string>"
    show_content = True
    vault_secrets = None
    json_only = False
    new_data = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    assert new_data['foo']['bar'] == 'baz'

# Generated at 2022-06-11 09:14:14.650799
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
---
- {
    "key": "value",
    "key2": "value2"
  }
'''
    yaml_str2 = '''
  name: value
  name2: value2
  name3:
    - one
    - two
    - three
  name4:
    key1: val1
    key2: val2
    key3: val3
'''
    yaml_str3 = '''
  - name: value1
  - name: value2
  - name: value3
'''
    yaml_str4 = '''
  key1:
    - one
    - two
  key2:
    - three
    - four
'''

# Generated at 2022-06-11 09:14:17.770742
# Unit test for function from_yaml
def test_from_yaml():
    # if function works without error, test passed
    from_yaml("---\n{}")

if __name__=="__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:14:25.400796
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.json_utils import from_json
    json_file = './test_data/test_utils_common_json.json'
    with open(json_file, 'r') as file_obj:
        # Test JSON
        content = file_obj.read()
        v = from_json(content, json_file)
        assert v['easy_mode']
        assert v['easy_mode_separators']['key_value'] == '='
        assert v['easy_mode_separators']['list_value'] == ':'
        assert v['easy_mode_separators']['dict_value'] == ','

    yaml_file = './test_data/test_utils_common_yaml.yml'