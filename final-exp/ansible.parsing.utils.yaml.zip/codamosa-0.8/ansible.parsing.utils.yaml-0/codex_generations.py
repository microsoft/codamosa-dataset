

# Generated at 2022-06-11 09:04:35.927843
# Unit test for function from_yaml
def test_from_yaml():
    data = """---
a: b
c: d
e: 1
"""
    res = from_yaml(data)
    assert res == {"a": "b", "c": "d", "e": 1}

# Generated at 2022-06-11 09:04:37.257885
# Unit test for function from_yaml
def test_from_yaml():
    data = '{}'
    assert json == from_yaml(data)



# Generated at 2022-06-11 09:04:41.790893
# Unit test for function from_yaml
def test_from_yaml():
    # Test JSON type string
    result = from_yaml("{\"a\": \"b\"}")
    assert result['a'] == 'b'

    # Test YAML type string
    result = from_yaml("a: b")
    assert result['a'] == 'b'

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:04:52.926349
# Unit test for function from_yaml
def test_from_yaml():
    # Test a valid JSON and YAML string
    json_str = b'{"display_sku": false, "index_sku": false}'
    yaml_str = b"""---
    fail_sku: true
    """

    from_yaml(json_str)
    from_yaml(yaml_str)

    # Test invalid strings
    bad_json = b"{{{{{{"
    bad_yaml = b"""
    ::
    """

    try:
        from_yaml(bad_json)
    except AnsibleParserError:
        pass
    else:
        assert False, "Should have failed as bad_json is not valid JSON/YAML"

    try:
        from_yaml(bad_yaml)
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 09:05:04.482408
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = '''
    list_in_list:
    - item1: value1
    - item2: value2
    - item3: value3
    '''
    yaml_dict = from_yaml(yaml_str)
    assert yaml_dict == {'list_in_list': [{'item1': 'value1'}, {'item2': 'value2'}, {'item3': 'value3'}]}
    assert type(yaml_dict) == dict
    assert type(yaml_dict['list_in_list']) == list
    assert type(yaml_dict['list_in_list'][0]) == dict

# Generated at 2022-06-11 09:05:12.266051
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml("{ }")
    from_yaml("{}")
    from_yaml("{ }", file_name='foo.yml')
    from_yaml("{ }", file_name=None)
    from_yaml("{ }", file_name=None, show_content=False)
    from_yaml("{}", file_name=None, show_content=False)
    from_yaml("{}", file_name=None, show_content=True)
    from_yaml("{}", file_name='foo.yml', show_content=True)
    from_yaml("{}", file_name='foo.yml', show_content=False)

# Generated at 2022-06-11 09:05:23.362160
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.yaml
    import ansible.parsing.ajson

    # Load a string from a YAML file
    yamlfile = open("test.yml", "r")
    yamlstr = yamlfile.read()
    test_data = ansible.parsing.ajson.from_yaml(yamlstr)
    assert type(test_data) is dict, "Could not load YAML string"
    yamlfile.close()

    # Load a string from a JSON file
    jsonfile = open("test.json", "r")
    jsonstr = jsonfile.read()
    test_data = ansible.parsing.ajson.from_yaml(jsonstr)
    assert type(test_data) is dict, "Could not load JSON string"
   

# Generated at 2022-06-11 09:05:30.882780
# Unit test for function from_yaml

# Generated at 2022-06-11 09:05:34.512606
# Unit test for function from_yaml
def test_from_yaml():
    data_json = {'foo':'bar','bar':'baz','baz':'foo'}
    data_yaml = '---\n'+'foo: bar\nbar: baz\nbaz: foo\n'

    assert from_yaml(data_yaml, json_only=True) is None
    assert from_yaml(data_json, json_only=True) == data_json
    assert from_yaml(data_yaml, json_only=False) == data_json



# Generated at 2022-06-11 09:05:46.535062
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.module_utils.six import PY3
    if PY3:
        unicode = str


# Generated at 2022-06-11 09:05:58.474552
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import unittest

    class FromYamlTests(unittest.TestCase):
        def _test_json_only(self, data):
            data = from_yaml(data, json_only=True)
            self.assertEqual([data], [{'k1': 'v1'}])

        def _test_no_json_only(self, data):
            data = from_yaml(data)
            self.assertEqual([data], [{'k1': 'v1'}])

        def test_json_dict_string(self):
            self._test_json_only('{"k1": "v1"}')

        def test_json_dict_string_no_json_only(self):
            self._test_no_json_only('{"k1": "v1"}')

# Generated at 2022-06-11 09:06:09.644825
# Unit test for function from_yaml
def test_from_yaml():
    # Test for AnsibleParserError
    try:
        from_yaml('{[{{{{[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[', file_name='<string>')
    except AnsibleParserError as e:
        assert 'AnsibleParserError' in str(e)

    # Test for YAMLError

# Generated at 2022-06-11 09:06:19.860012
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Code coverage testing of the from_yaml() function.
    :return:
    '''
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.utils import VaultLib

    # YAML string with a vault encrypted string

# Generated at 2022-06-11 09:06:24.020528
# Unit test for function from_yaml
def test_from_yaml():
    # Test with JSON only
    assert from_yaml('{"key1": "value1", "key2": "value2"}') == {'key1': 'value1', 'key2': 'value2'}

    # Test with JSON and YAML
    assert from_yaml('{"key1": "value1", "key2": "value2"}', json_only=False) == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-11 09:06:35.023458
# Unit test for function from_yaml

# Generated at 2022-06-11 09:06:45.677433
# Unit test for function from_yaml
def test_from_yaml():
    data = "a: b\n"
    data_dict = from_yaml(data)
    assert data_dict == {'a': 'b'}, data_dict

    data = "[1, 2, 3]\n"
    data_dict = from_yaml(data)
    assert data_dict == [1, 2, 3], data_dict

    data = "{'a': 1, 'b': 2}\n"
    data_dict = from_yaml(data)
    assert data_dict == {'a': 1, 'b': 2}, data_dict

    data = "{a: 1, b: 2}\n"
    data_dict = from_yaml(data)
    assert data_dict == {'a': 1, 'b': 2}, data_dict

    data = "---\na: b\n"


# Generated at 2022-06-11 09:06:50.097271
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("not yaml") == "not yaml"
    assert from_yaml("{'key': 'value'}") == {'key': 'value'}
    assert from_yaml("{'key': {'key': 'value'}}") == {'key': {'key': 'value'}}
    assert from_yaml("""
      #!yaml
      list:
      - a
      - b
      - c
    """) == {'list': ['a', 'b', 'c']}

# Generated at 2022-06-11 09:06:59.185187
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('{}', json_only=True) == {}
    assert from_yaml('{') is None
    assert from_yaml('{', json_only=True) is None
    assert from_yaml('{"a": 1}') == {"a": 1}
    assert from_yaml('{"a": 1}', json_only=True) == {"a": 1}
    assert from_yaml('{a: 1}', json_only=True) is None
    assert from_yaml('a: 1') is None
    assert from_yaml('a: 1', json_only=True) is None

# Run unit test
if __name__ == "__main__":
    import sys
    import os
    import doctest
    doctest.test

# Generated at 2022-06-11 09:07:08.905958
# Unit test for function from_yaml
def test_from_yaml():
    ''' Basic unit tests for function from_yaml '''
    import os
    import tempfile
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from .dataloader import DataLoader

    # Create temporary file
    _, f_name = tempfile.mkstemp()

    # Test file with some YAML
    with open(f_name, 'w') as f:
        f.write('- hosts: localhost\n  tasks:\n    - name: test\n      debug: msg="ansible"\n')

    test_yaml = os.path.abspath(f_name)

    loader = DataLoader()

    # Test playbook

# Generated at 2022-06-11 09:07:19.722009
# Unit test for function from_yaml
def test_from_yaml():
    # json file
    data = '{ "key": "value", "list": [1,2,3,4,5] }'
    result = from_yaml(data)

    if result['key'] != 'value' or result['list'] != [1,2,3,4,5]:
        print("json file is not parsed correctly!")

    # yaml file
    data = '''
    key: value
    list:
      - 1
      - 2
      - 3
      - 4
      - 5
    '''
    result = from_yaml(data)

    if result['key'] != 'value' or result['list'] != [1,2,3,4,5]:
        print("yaml file is not parsed correctly!")

    # mixed file

# Generated at 2022-06-11 09:07:25.705777
# Unit test for function from_yaml
def test_from_yaml():
    val = from_yaml('''
- hosts: localhost
  gather_facts: no
  tasks:
  - shell: 'echo hi'
  - fail:
''')

    assert len(val) == 1
    assert val[0]['hosts'] == 'localhost'

# Generated at 2022-06-11 09:07:32.333486
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    vault_secrets = []
    vault_secrets.append(VaultSecret('id', VaultAES256('password')))
    data_1 = "remote_user: root"
    data_2 = "{}"
    data_3 = "[]"
    data_4 = "{\"id\": \"password\"}"
    data_5 = "{\"x\": \"vault | id\"}"
    data_6 = "[{\"x\": \"vault | id\"}, {\"x\": \"vault | id\"}]"

# Generated at 2022-06-11 09:07:45.174247
# Unit test for function from_yaml

# Generated at 2022-06-11 09:07:48.982846
# Unit test for function from_yaml
def test_from_yaml():
    # this is a pretty stupid test, however it just doesn't make sense
    # to try to be fancy with it, given that we are just testing the
    # public API anyway
    rval = from_yaml('["foo", "bar"]')
    assert [u'foo', u'bar'] == rval

# Generated at 2022-06-11 09:07:54.691198
# Unit test for function from_yaml
def test_from_yaml():

    # Simple test of string to string
    assert from_yaml('foo') == 'foo'

    # Test of simple string to list
    assert from_yaml('[ foo, bar ]') == ['foo', 'bar']

    # Test of simple list to list
    assert from_yaml(['foo', 'bar']) == ['foo', 'bar']

    # Test of simple list to list
    assert from_yaml(['foo', [ 'bar', 'baz' ]]) == ['foo', ['bar', 'baz']]

    # Test of simple list to list
    assert from_yaml(['foo', [ 'bar', 'baz' ], 'bat']) == ['foo', ['bar', 'baz'], 'bat']

    # Test of simple list to list

# Generated at 2022-06-11 09:08:04.976635
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    class TestFromYAML(unittest.TestCase):

        def test_from_yaml(self):
            example_list = ['item1', 'item2', 'item3']
            example_dict = {'key1': 'value1', 'key2': 'value2'}
            example_json = json.dumps(example_dict)
            example_json_list = json.dumps(example_list)
            example_yaml = """
            key1: value1
            key2: value2
            """
            example_yaml_list = """
            - item1
            - item2
            - item3
            """

            # From string
            result = from_yaml(example_json)
            assert result == example_dict


# Generated at 2022-06-11 09:08:15.659478
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import json
    import yaml


# Generated at 2022-06-11 09:08:18.787800
# Unit test for function from_yaml
def test_from_yaml():
    # Test with a yaml file
    yaml_file = open('file.yml', 'r')
    new_data = from_yaml(yaml_file)
    print(new_data)

test_from_yaml()

# Generated at 2022-06-11 09:08:22.560534
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = """
    - this
    - is
    - a
    - yaml
    - file
    - ansible: True
    """

    assert from_yaml(yaml_data) == {'ansible': True}

# Generated at 2022-06-11 09:08:32.134698
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    this_is_garbage: without a doubt
    '''
    try:
        a = from_yaml(data, file_name='/tmp/somefile', vault_secrets=None, json_only=False)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
        assert isinstance(e.orig_exc, YAMLError)
        assert e.message.startswith('We were unable to read either as JSON nor YAML, these are the errors we got from each:')
        assert e.obj.ansible_pos == ('/tmp/somefile', 1, 1)

# Generated at 2022-06-11 09:08:37.487506
# Unit test for function from_yaml
def test_from_yaml():
    src = "---\n- key1: val1\n- key2: val2"
    dest = [{'key1': 'val1'}, {'key2': 'val2'}]
    returned = json.dumps(from_yaml(src))
    assert returned == json.dumps(dest)

# Generated at 2022-06-11 09:08:50.317524
# Unit test for function from_yaml

# Generated at 2022-06-11 09:08:52.079313
# Unit test for function from_yaml
def test_from_yaml():
    import doctest
    return doctest.testmod(from_yaml)

# Generated at 2022-06-11 09:08:53.789357
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes
    data = '{ "foo": "bar" }'
    new_data = from_yaml(to_bytes(data))
    assert type(new_data) == dict
    assert u'foo' in new_data
    assert new_data[u'foo'] == u'bar'

# Generated at 2022-06-11 09:08:57.803407
# Unit test for function from_yaml
def test_from_yaml():
    yaml = """
        playbook: test.yml
        inventory: hosts

        filters:
          - "ipaddr"
          - "ipv4"
        """
    assert from_yaml(yaml) == {"filters": ["ipaddr", "ipv4"], "inventory": "hosts", "playbook": "test.yml"}

# Generated at 2022-06-11 09:09:00.776807
# Unit test for function from_yaml
def test_from_yaml():

    assert None is from_yaml('\n')
    assert {'a': 'b'} == from_yaml('{   "a"   :   "b"   }')
    assert {'a': 'b'} == from_yaml('a: b')

# Generated at 2022-06-11 09:09:05.732808
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[" + json.dumps([1, 2, 3, 4]) + "]") == [[1, 2, 3, 4]]
    assert from_yaml("!include excludes.yml") == {'include': 'excludes.yml'}

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:09:17.806595
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-11 09:09:20.696714
# Unit test for function from_yaml
def test_from_yaml():
    """
    Unit test for function from_yaml
    """
    data1 = "foo: bar\n"
    assert from_yaml(data1) == {'foo': 'bar'}

# Generated at 2022-06-11 09:09:30.959756
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_text
    # json
    assert from_yaml(to_text('{"foo": "bar"}')) == {'foo': "bar"}

    # yaml
    assert from_yaml(to_text('foo: bar')) == {'foo': "bar"}

    # json with yaml
    assert from_yaml(to_text('{"foo": bar}')) == {'foo': "bar"}

    # yaml with json
    assert from_yaml(to_text('foo: {"bar": "baz"}')) == {'foo': {"bar": "baz"}}

    # invalid yaml

# Generated at 2022-06-11 09:09:42.805922
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:09:52.195026
# Unit test for function from_yaml

# Generated at 2022-06-11 09:10:02.619432
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import unichr
    from ansible.parsing.ajson import AnsibleJSONEncoder

    testobj = {
        'plain': {},
        'single-quoted': { 'a': 'b' },
        'double-quoted': { 'a': 'b' },
        'non-ascii': { 'a': u'\u20ac' },
        'bool true': { 'a': True },
        'bool false': { 'a': False },
        'number': { 'a': 1 },
        'list': { 'a': ['b', 'c'] },
    }


# Generated at 2022-06-11 09:10:04.492829
# Unit test for function from_yaml
def test_from_yaml():
    json_string = '{"a": "A", "b": "B"}'
    yaml_strin

# Generated at 2022-06-11 09:10:15.517621
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('[1, 2, 3]')
    from_yaml('{"a": 1, "b": 2}')
    from_yaml('- a')
    from_yaml('- a: 1')
    from_yaml('---\n- a: 1')
    from_yaml('---\n- a: 1')
    from_yaml('---\n- a: 1')
    from_yaml('---\n- a: 1\n')
    from_yaml('---\n- a:\n    b: 1\n    c: 2\n')
    from_yaml('---\n- a:\n    b:\n    - c: 1\n      d: 2\n')
    from_yaml('---\n-\n - foo\n - bar\n')
   

# Generated at 2022-06-11 09:10:26.176326
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string = '''
- hosts: localhost
  tasks:
  - name: test
    shell: ls
'''
    expected = [{'tasks': [{'name': 'test', 'shell': 'ls'}], 'hosts': 'localhost'}]
    output = from_yaml(yaml_string)
    assert output == expected

    yaml_string = '''
- hosts: localhost
  tasks:
  - name: test
    shell: ls
  - name: test2
    shell: ls
'''
    expected = [{'tasks': [{'name': 'test', 'shell': 'ls'},
                           {'name': 'test2', 'shell': 'ls'}],
                 'hosts': 'localhost'}]

# Generated at 2022-06-11 09:10:32.968053
# Unit test for function from_yaml
def test_from_yaml():
    from unittest import TestCase
    from ansible.parsing.yaml import objects
    import ansible.parsing.vault

    class TestFromYAML(TestCase):

        def test_basic_from_yaml(self):
            data = "{foo: bar}"
            result = from_yaml(data)
            self.assertEqual(result, {'foo': "bar"})
            self.assertTrue(isinstance(result, dict))

        def test_from_yaml_composite_type(self):
            data = "{foo: bar, baz: [1,2,3]}"
            result = from_yaml(data)
            self.assertEqual(result, {'foo': "bar", 'baz': [1,2,3]})

# Generated at 2022-06-11 09:10:43.940528
# Unit test for function from_yaml
def test_from_yaml():

    json_data = "{\"a\": 1, \"b\": 2, \"c\": 3, \"d\": 4, \"e\": 5}"
    json_data_out = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    yaml_data = "{a: 1, b: 2, c: 3, d: 4, e: 5}"
    yaml_data_out = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert from_yaml(json_data) == json_data_out
    assert from_yaml(yaml_data) == yaml_data_out

# Generated at 2022-06-11 09:10:45.176747
# Unit test for function from_yaml
def test_from_yaml():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 09:10:48.759523
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "a": 1 }'
    file_name = '<string test>'
    data_s = from_yaml(data, file_name, True, None, False)
    assert isinstance(data_s, dict) and data_s['a'] == 1

# Generated at 2022-06-11 09:11:04.008584
# Unit test for function from_yaml

# Generated at 2022-06-11 09:11:10.297609
# Unit test for function from_yaml
def test_from_yaml():
    data = """
- hosts: localhost
  tasks:
    - name: Create a directory
      file:
        state: directory
        path: /tmp/mydir
"""
    assert from_yaml(data) == \
        [{'tasks': [{'name': 'Create a directory', 'file': {'state': 'directory', 'path': '/tmp/mydir'}}],
          'hosts': 'localhost'}]

# Generated at 2022-06-11 09:11:19.752611
# Unit test for function from_yaml
def test_from_yaml():

    import ansible.parsing.yaml.loader

    test_data = '- include_tasks: foo.yml\n  loop: "{{ test_var }}"'
    test_use_json = '{"include_tasks": "foo.yml", "loop": "{{ test_var }}"}'

    ansible.parsing.yaml.loader.set_default_flow_style()

    from_yaml(test_data)
    from_yaml(test_use_json, json_only=True)

    # try with something that fails to parse as JSON, but is valid YAML
    test_data2 = '- include_tasks: "foo.yml"\n  loop: "{{ test_var }}"'

# Generated at 2022-06-11 09:11:29.808136
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('abc') == 'abc'
    assert from_yaml('[1,2,3]') == [1,2,3]
    assert from_yaml('{"a": "b"}') == {'a': 'b'}

    assert from_yaml('qwerty\n - 123\n  - 456\n') == 'qwerty - 123  - 456'
    assert from_yaml('qwerty\n - 123\n - 456')   == 'qwerty\n - 123\n - 456'
    assert from_yaml('qwerty\n- 123\n- 456')     == ['qwerty', '123', '456']

# Generated at 2022-06-11 09:11:39.598112
# Unit test for function from_yaml
def test_from_yaml():
    valid_yaml = """
    a: 1
    b:
      c: 3
      d: 4
    """
    valid_json = """{
        "a": 1,
        "b": {
            "c": 3,
            "d": 4
        }
    }
    """
    invalid_yaml = """
    a: 1
    b:
      c: 3
      d: 4
      """
    invalid_json = """
        {
            "a": 1,
            "b": {
                "c": 3,
                "d": 4
            }
        }
        """
    #test valid yaml
    assert from_yaml(valid_yaml) == {"a": 1, "b": {"c": 3, "d": 4}}
    #test valid json
    assert from_yaml

# Generated at 2022-06-11 09:11:47.916428
# Unit test for function from_yaml
def test_from_yaml():
    """
    Tests for from_yaml
    """
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.ajson import AnsibleJSONEncoder

    from ansible.parsing.vault import VaultLib

    # encrypt test data
    data1 = {'password': 'secret'}
    vault = VaultLib(['password'])
    data1 = vault.dump(data1)

    # decrypt test data
    data2 = vault.load(data1)

    # encrypt with vault (data2) and then convert to json
    json_data2 = json.dumps(data2, cls=AnsibleJSONEncoder)
    # convert json to yaml
    yaml_data = from_yaml(json_data2, vault_secrets=['password'])

# Generated at 2022-06-11 09:11:54.896994
# Unit test for function from_yaml
def test_from_yaml():
    # empty string
    assert from_yaml(' ') == None

    # empty list
    assert from_yaml('[]') == []

    # empty dict
    assert from_yaml('{}') == {}

    # string of digits
    assert from_yaml('123') == 123

    # string of "True"
    assert from_yaml('true') is True

    # string of "None"
    assert from_yaml('null') is None

    # list of objects
    assert from_yaml('[1, true]') == [1, True]

    # dict of objects
    assert from_yaml('{"a": 123, "b": "text"}') == {'a': 123, 'b': "text"}

    # list of lists
    assert from_yaml('[[1, 2], [3, 4]]')

# Generated at 2022-06-11 09:12:07.692117
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import pytest
    from ansible.utils.vault import VaultLib

    file  = 'test.yml'
    yaml  = open(file, 'r').read()

    # test_from_yaml - YAML    - no vault
    result = from_yaml(yaml, file_name=file, show_content=True, vault_secrets=None, json_only=False)
    assert result['foo'] == 'bar'

    # test_from_yaml - YAML    - vault
    result = from_yaml(yaml, file_name=file, show_content=True, vault_secrets={'default': ['vaultpass']}, json_only=False)
    assert result['foo'] == 'bar'

    # test_from_yaml - YAML    - vault

# Generated at 2022-06-11 09:12:18.018653
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # load vault secrets
    vault_password_file = os.path.join(os.path.dirname(__file__), '../../../../.vault_pass.txt')
    vault_secrets = VaultSecret([vault_password_file])

    # this is the data encrypted by vault

# Generated at 2022-06-11 09:12:20.522554
# Unit test for function from_yaml
def test_from_yaml():
    data = "{ 'foo': 'bar' }"
    parsed = from_yaml(data, file_name='<test>')
    assert {'foo': 'bar'} == parsed

# Generated at 2022-06-11 09:12:35.764964
# Unit test for function from_yaml
def test_from_yaml():
    test_data = {
        'json': u'{ "foo": "bar" }',
        'yaml': u'foo: bar',
        'json_array': u'[ "foo", "bar" ]',
        'string': u'string',
    }
    test_expecting = {
        'json': {'foo': 'bar'},
        'yaml': {'foo': 'bar'},
        'json_array': ['foo', 'bar'],
        'string': 'string',
    }
    for k, v in test_expecting.items():
        assert v == from_yaml(test_data[k])

# Generated at 2022-06-11 09:12:43.949075
# Unit test for function from_yaml
def test_from_yaml():
    ''' unit tests for from_yaml '''
    invalid_yaml = """
    failed:
    - to
    - validate
    """

    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence

    yaml_file = StringIO(invalid_yaml)
    yaml_data = AnsibleLoader(yaml_file).get_single_data()
    assert isinstance(yaml_data, AnsibleSequence)

# Generated at 2022-06-11 09:12:53.822858
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""
                a: 1
                b: 2
                """) == {'a': 1, 'b': 2}
    assert from_yaml("""
                a: 1
                b: [ 2, 3 ]
                """) == {'a': 1, 'b': [2, 3]}
    assert from_yaml("""
                a:
                  b: 1
                """) == {'a': {'b': 1}}
    assert from_yaml("""
                a:
                  b: 1
                  c: 2
                """) == {'a': {'b': 1, 'c': 2}}
    assert from_yaml("""
                a:
                  b:
                    c: 1
                """) == {'a': {'b': {'c': 1}}}
    assert from_y

# Generated at 2022-06-11 09:13:04.343021
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.dataloader
    import os

    class test_dataloader(ansible.parsing.dataloader.DataLoader):
        def __init__(self):
            self.basedir = os.path.dirname(os.path.realpath(__file__))

        def load_from_file(self, file_name):
            return open(file_name).read()

    loader = test_dataloader()
    test_file = os.path.join(loader.basedir, 'test.yml')
    test_data = from_yaml(loader.load_from_file(test_file), file_name=test_file, show_content=False)

    assert test_data is not None


# Generated at 2022-06-11 09:13:10.946205
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
    {
        "first": "one",
        "second": [
            1,
            2
        ]
    }
    """
    assert from_yaml(test_data) == {u'first': 'one', u'second': [1, 2]}

if __name__ == '__main__':
    test_data = """
    {
        "first": "one",
        "second": [
            1,
            2
        ]
    }
    """
    print("data is: " + repr(from_yaml(test_data)))

# Generated at 2022-06-11 09:13:21.997604
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3

    # Create YAML data from variables
    test_yaml = \
'''
- hosts: localhost
  tasks:
    - name: Test
      debug:
        msg: Test.
'''
    test_yaml_data = test_yaml.lstrip('\n')
    assert test_yaml_data != test_yaml

    # Create JSON data from variables
    test_json = \
{
  "tasks": [
    {
      "name": "Test",
      "debug": {
        "msg": "Test."
      }
    }
  ],
  "hosts": "localhost"
}
    test_json_data = json.dumps(test_json)
    assert test_json_data

    # Test that Ansible

# Generated at 2022-06-11 09:13:29.233514
# Unit test for function from_yaml
def test_from_yaml():
    '''Test function from_yaml'''
    json_data = '{"test": "test"}'
    yaml_data = 'test: test'
    assert from_yaml(json_data, json_only=True) == {'test': 'test'}
    assert from_yaml(yaml_data, json_only=True) == {'test': 'test'}
    assert from_yaml(json_data) == {'test': 'test'}
    assert from_yaml(yaml_data) == {'test': 'test'}

# Generated at 2022-06-11 09:13:34.960733
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1,2,3]') == [1, 2, 3]
    assert from_yaml('[1,2,3]\n') == [1, 2, 3]
    assert from_yaml('[1,2,3]\n', json_only=True) == [1, 2, 3]
    assert from_yaml('[1,2,3]', json_only=True) == [1, 2, 3]

# Generated at 2022-06-11 09:13:40.897755
# Unit test for function from_yaml
def test_from_yaml():
    import os
    test_file = os.getcwd() + "/test_data/input/yaml_test.yml"
    data = open(test_file, 'r').read()
    new_data = from_yaml(data)
    assert type(new_data) is type({})

# Generated at 2022-06-11 09:13:46.240508
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Validate that the from_yaml() function initializes properly
    '''
    # simple test
    test_yaml = '''
---
 - name: test1
   state: present
   enabled: true
'''
    parsed = from_yaml(test_yaml)
    assert parsed[0]['enabled']

# Generated at 2022-06-11 09:14:07.114766
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test function from_yaml

    Test Case 1
    """
    assert from_yaml("{'foo': 'bar'}", file_name='test_from_yaml') == "{'foo': 'bar'}"

# Ansible supports multiple vault ids

# Generated at 2022-06-11 09:14:19.085086
# Unit test for function from_yaml
def test_from_yaml():
    # test -> load YAML
    yaml_str = """
---
  name: Alice
  phone: 123-456-7890
  gender: Female
  dog:
    name: Ein
    breed: Corgi
"""
    d = from_yaml(yaml_str)
    assert d['name'] == 'Alice'
    assert d['dog']['name'] == 'Ein'
    assert d['phone'] == '123-456-7890'

    # test -> load JSON
    json_str = """
{
  "name": "Alice",
  "phone": "123-456-7890",
  "gender": "Female",
  "dog": {
    "name": "Ein",
    "breed": "Corgi"
  }
}
"""
    d = from_y

# Generated at 2022-06-11 09:14:25.807396
# Unit test for function from_yaml

# Generated at 2022-06-11 09:14:30.391543
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('9') == 9
    assert from_yaml('{}') == {}
    assert from_yaml('"string"') == "string"
    assert from_yaml('true') is True
    assert from_yaml('false') is False
    assert from_yaml('null') is None
    assert from_yaml('[1, 2, 3, 4]') == [1, 2, 3, 4]