

# Generated at 2022-06-11 09:04:36.797248
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a": "b"}'
    assert from_yaml(data) == {"a": "b"}
    with pytest.raises(AnsibleParserError):
        from_yaml('a: 1')

# Generated at 2022-06-11 09:04:44.163214
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml("{\"foo\": \"{{ my_var }}\"}", json_only=True)
    except AnsibleParserError as exc:
        assert exc.show_content is True
        assert exc.obj is None
        assert exc.orig_exc.__class__.__name__ == 'ValueError'
        assert str(exc.orig_exc) == 'Expecting property name enclosed in double quotes: line 1 column 2 (char 1)'
    else:
        raise AssertionError("Should have raised AnsibleParserError")
    try:
        from_yaml("foo: bar")
    except AnsibleParserError as exc:
        assert exc.show_content is True
        assert str(exc.obj) == '<string>:1.1-1.10'
        assert exc.orig_exc.__class__.__

# Generated at 2022-06-11 09:04:56.293585
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.parsing.yaml import objects

    def _load(data):
        return from_yaml(data)

    assert _load('[1, 2, 3]') == [1, 2, 3]
    assert _load('{"foo": "bar"}') == {'foo': 'bar'}

# Generated at 2022-06-11 09:05:06.689158
# Unit test for function from_yaml
def test_from_yaml():
    assert isinstance(from_yaml("{ 'json': 'object' }"), dict)
    assert isinstance(from_yaml("- yaml \n- list"), list)
    assert isinstance(from_yaml("- yaml \n- list", json_only=True), dict)
    # The next two lines test that strings are quoted around other strings.
    assert from_yaml("{ 'json': '\"object\"' }")['json'] == '"object"'
    assert from_yaml("{ 'json': '\"object\"' }", json_only=True)['json'] == '"object"'

# Generated at 2022-06-11 09:05:14.086094
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert from_yaml('{"some_key": "some_value"}') == {'some_key': 'some_value'}
    assert from_yaml('{"some_key": "some_value"}', json_only=True) == {'some_key': 'some_value'}
    assert from_yaml('{}') == {}
    assert from_yaml('{"some_key": "some_value"}') == {'some_key': 'some_value'}
    assert from_yaml('{\n"some_key": "some_value"\n}') == {'some_key': 'some_value'}

# Generated at 2022-06-11 09:05:25.588324
# Unit test for function from_yaml

# Generated at 2022-06-11 09:05:35.334177
# Unit test for function from_yaml
def test_from_yaml():
    file_name = "<string>"
    show_content = True
    vault_secrets = None
    json_only = False

    try:
        # Test JSON only
        json_only = True
        data = '{ "msg": "test json only" }'
        from_yaml(data, file_name, show_content, vault_secrets, json_only)
    except Exception as e:
        assert e.message == 'We were unable to read either as JSON nor YAML, these are the errors we got from each:\n' \
                            'JSON: No JSON object could be decoded\n\n'

    # Test JSON with bad input
    json_only = False
    data = '{ msg: "test json only" }'

# Generated at 2022-06-11 09:05:36.347113
# Unit test for function from_yaml
def test_from_yaml():
    # TODO
    pass

# Generated at 2022-06-11 09:05:48.083290
# Unit test for function from_yaml
def test_from_yaml():
    file_name = 'TEST'
    show_content = True
    vault_secrets = {}

    # load json string
    data = '{"foo": 1, "bar": 2}'
    assert from_yaml(data, file_name, show_content, vault_secrets) == dict(foo=1, bar=2)

    # load yaml string
    data = '---\nfoo: 1\nbar: 2'
    assert from_yaml(data, file_name, show_content, vault_secrets) == dict(foo=1, bar=2)

    # load json string as json only
    data = '{"foo": 1, "bar": 2}'

# Generated at 2022-06-11 09:05:56.994050
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test YAML parsing.
    '''

    # YAML string to test
    yaml_str = '''
    ---
    - hosts:
        - localhost
      gather_facts: False
      tasks:
        - debug:
            msg: 'Hello World'
    '''

    # test
    yaml_res = from_yaml(yaml_str)

    # assert
    assert yaml_res[0]['hosts'][0] == 'localhost'

    # test
    yaml_res = from_yaml(yaml_str, json_only=True)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:06:11.423140
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vars_manager = VariableManager()
    my_vars = combine_vars(loader=loader, variables=vars_manager)

    # test JSON loading
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('{ "foo": "bar" }') == {'foo': 'bar'}

    # test YAML loading
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_y

# Generated at 2022-06-11 09:06:17.808932
# Unit test for function from_yaml
def test_from_yaml():
    try:
        data = '{"basic_key": "basic_value"}'
        print(from_yaml(data))
        data = '{"basic":"value1", "basic2": "value2"}'
        print(from_yaml(data))
        data = '[{"basic":"value1", "basic2": "value2"}]'
        print(from_yaml(data))
    except Exception as e:
        print(e)

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:06:25.031855
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    test_data = {'a': [1, 2, 3],
                 'b': [{'c': 'a'}, {'c': 'b'}]}

    # Test the basic functionality
    assert from_yaml(json.dumps(test_data)) == test_data

    # Test that the function supports unicode input
    assert from_yaml(to_text(json.dumps(test_data))) == test_data

    # Test that a json_only parameter prevents loading non-json data
    yaml_text = to_text(AnsibleDumper(sort_keys=True, allow_unicode=True).dump(test_data))

# Generated at 2022-06-11 09:06:35.582448
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes
    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleVaultEncryptedUnicode

    data = to_bytes('{ "key": "value", "key2": "value2" }')
    result = from_yaml(data)
    assert result["key"] == "value"
    assert result["key2"] == "value2"

    data = to_bytes('{ "key": "value" : "key2": "value2" }')
    with pytest.raises(AnsibleParserError):
        result = from_yaml(data)


# Generated at 2022-06-11 09:06:46.245786
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes

    # Test when vault secrets are present
    # Test when vault secrets are present
    data = '{"password": "vault:foo:bar"}'
    vault_secrets = [{'value': 'vaultpass', 'identity': 'foo'}]
    data = to_bytes(data)
    # Convert the data to a python datastructure
    data = from_yaml(data, vault_secrets=vault_secrets)
    # Validate the conversion
    assert(data['password'] == 'vaultpass')

    # Test when vault secrets are not present
    data = '{"password": "vault:foo:bar"}'
    vault_secrets = []
    data = to_bytes(data)
    # Convert the data to a python datastructure
   

# Generated at 2022-06-11 09:06:48.049486
# Unit test for function from_yaml
def test_from_yaml():
    s = """
{
"key":"value"
}
"""
    result = from_yaml(s)
    assert result['key'] == 'value'

# Generated at 2022-06-11 09:06:51.697178
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Verifies that we get a AnsibleParserError from from_yaml.  It doesn't
    validate whether we got the correct thing in the error, just that an
    exception was raised.
    '''
    import pytest

    with pytest.raises(AnsibleParserError):
        from_yaml("foobar")


# Generated at 2022-06-11 09:07:00.508280
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("foo") == "foo"
    assert from_yaml("{ \"foo\" : \"bar\" }") == { "foo" : "bar" }
    assert from_yaml("{ \"foo\": \"bar\" }") == { "foo" : "bar" }  # noqa
    assert from_yaml("{ 'foo' : 'bar' }") == { 'foo' : 'bar' }
    assert from_yaml("{ 'foo': 'bar' }") == { 'foo' : 'bar' }  # noqa
    assert from_yaml("{ 'foo': 1 }") == { 'foo' : 1 }
    assert from_yaml("{ 'foo': true }") == { 'foo' : True }

# Generated at 2022-06-11 09:07:06.997062
# Unit test for function from_yaml
def test_from_yaml():
    assert type(from_yaml("{}")) == dict
    assert type(from_yaml("{}", json_only=True)) == dict
    assert type(from_yaml("---{}", json_only=True)) == dict
    assert type(from_yaml("")) == list
    assert type(from_yaml("", json_only=True)) == list
    assert type(from_yaml("---")) == list
    assert type(from_yaml("---", json_only=True)) == list

# Generated at 2022-06-11 09:07:17.975375
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    test_data = ['foo', 'bar', 'baz']
    result = from_yaml(json.dumps(test_data))
    assert result == test_data

    test_data = {'foo': 1, 'bar': 2, 'baz': 3}
    result = from_yaml(json.dumps(test_data))
    assert result == test_data

    test_data = {'foo': 1, 'bar': ['bar', 'list'], 'baz': {'foo': 'bar'}}
    result = from_yaml(json.dumps(test_data))
    assert result == test_data


# Generated at 2022-06-11 09:07:30.660554
# Unit test for function from_yaml
def test_from_yaml():

    import sys
    import io

    python_version = sys.version_info[0]
    # On Python3, the return value of io.StringIO is a io.TextIOWrapper instance
    # which is NOT a subclass of io.StringIO.  Downstream we test whether
    # the passed object is a subclass of io.StringIO, so we need to use
    # io.BytesIO here to pass the test.
    # On Python2, io.StringIO and io.BytesIO are both file-like objects.
    if python_version == 3:
        sample_yaml = io.BytesIO(b'''
- hosts: all
  gather_facts: no
''')
    else:
        sample_yaml = io.StringIO(u'''
- hosts: all
  gather_facts: no
''')

    # Unit

# Generated at 2022-06-11 09:07:43.235400
# Unit test for function from_yaml
def test_from_yaml():
    # Valid yaml
    yaml_str = 'key: value'
    assert from_yaml(yaml_str) == {'key': 'value'}

    # Invalid yaml
    yaml_str = 'key: !!python/object/apply:os.path.basename ["/etc/passwd", "^(.*)/[^/]*$", 1]'
    try:
        from_yaml(yaml_str)
        assert False, 'should raise AnsibleParserError'
    except AnsibleParserError as e:
        assert to_native(e).startswith('We were unable to read either as JSON nor YAML,')

    # Valid json
    json_str = '{"key": "value"}'
    assert from_yaml(json_str) == {'key': 'value'}

    # Invalid

# Generated at 2022-06-11 09:07:52.101528
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.ajson import AnsibleJSONDecoder
    import json

    # we first try to load this data as JSON.
    # Fixes issues with extra vars json strings not being parsed correctly by the yaml parser
    json_data = "{'json_dict': {'a': 'b'}, 'json_list': ['a', 'b']}"
    json_data_r = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert json_data_r == {"json_dict": {"a": "b"}, "json_list": ["a", "b"]}

    # must not be JSON, let the rest try

# Generated at 2022-06-11 09:08:01.775303
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test function from_yaml
    '''

    import os

    # Test JSON input
    test_json = r'{"test1": 1, "test2": 2, "test3": [1, 2, 3], "test4": {"test5": 5}}'
    test_json_list = json.loads(test_json, cls=AnsibleJSONDecoder)
    test_json_dict = from_yaml(test_json)
    assert test_json_list == test_json_dict, 'The input JSON does not equal to the output JSON dict'

    # Test YAML input
    test_yaml = r'---\ntest1: 1\ntest2: 2\ntest3:\n  - 1\n  - 2\n  - 3\ntest4: { test5: 5 }'

# Generated at 2022-06-11 09:08:05.596948
# Unit test for function from_yaml
def test_from_yaml():
    data = b"{'fake_data': 'fake_value'}"
    try:
        assert from_yaml(data) == {"fake_data": "fake_value"}
    except AnsibleParserError:
        assert False


# Generated at 2022-06-11 09:08:11.129853
# Unit test for function from_yaml
def test_from_yaml():
    val = [1,2,3]
    json_data = json.dumps(val)
    yaml_data = yaml.dump(val)
    assert json_data == from_yaml(json_data)
    assert yaml_data == from_yaml(yaml_data)

# Generated at 2022-06-11 09:08:18.366879
# Unit test for function from_yaml
def test_from_yaml():

    # test string
    str_test = u"""
        ---
        id: 1
    """

    # test dict
    dict_test = {
        'id': 1
    }

    # test list
    list_test = [1, 2, 3]

    # test empty string
    empty_test = u"""
    """

    # test None
    none_test = None

    # Test
    test_dict = from_yaml(str_test)
    assert dict_test == test_dict, 'dict is not the same after from_yaml'

    test_list = from_yaml(list_test)
    assert list_test == test_list, 'list is not the same after from_yaml'

    test_empty = from_yaml(empty_test)

# Generated at 2022-06-11 09:08:30.271618
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(None) is None
    assert from_yaml(42) == 42
    assert from_yaml('[]') == []
    assert from_yaml('{}') == {}
    assert from_yaml('[foo]') == ['foo']
    assert from_yaml('[foo, bar]') == ['foo', 'bar']
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('{"foo": "bar", "biz": "baz"}') == {'foo': 'bar', 'biz': 'baz'}
    assert from_yaml('echo: "hello"') == {'echo': 'hello'}
    assert from_yaml('{echo: "hello"}') == {'echo': 'hello'}
    assert from_

# Generated at 2022-06-11 09:08:38.489973
# Unit test for function from_yaml
def test_from_yaml():
    a = {}
    a = from_yaml('{ "test_string": "simple string", "test_int": 10, "test_true": true, "test_false": false, "test_array": ["a", "b", "c"], "test_dict": { "a": "1", "b": "2" }, "test_none": null }')
    assert type(a) is dict
    assert a['test_string'] == "simple string"
    assert a['test_int'] == 10
    assert a['test_true'] == True
    assert a['test_false'] == False
    assert type(a['test_array']) is list
    assert a['test_array'][0] == "a"
    assert a['test_array'][1] == "b"
    assert a['test_array'][2]

# Generated at 2022-06-11 09:08:44.107281
# Unit test for function from_yaml
def test_from_yaml():
    with open('./ansible/test/test_data/test_from_yaml/test.yml', encoding='utf-8') as f:
        data = f.read()
    data = from_yaml(data)
    print(data)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:08:54.656701
# Unit test for function from_yaml
def test_from_yaml():
    data = 'name: foo'
    file_name = 'testyaml.yml'
    show_content = True
    vault_secrets = 'test'
    json_only = False
    new_data = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    assert new_data['name'] == 'foo'
    assert new_data['name'] == 'foo'

# Generated at 2022-06-11 09:09:01.927234
# Unit test for function from_yaml

# Generated at 2022-06-11 09:09:13.199584
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml

    :param data: the data to encode
    :param file_name: the file name to load
    :param show_content: a bool that specifies if the content should be printed or not
    :param vault_secrets: a vault secret.
    :param json_only: if set to True, only JSON is returned.
    :returns: new_data
    '''
    data = '{"key":"value", "name":"ansible"}'
    file_name = "test_file"
    show_content = True
    vault_secrets = "SECRET"
    json_only = False
    new_data = from_yaml(data, file_name, show_content, vault_secrets, json_only)

# Generated at 2022-06-11 09:09:23.501726
# Unit test for function from_yaml
def test_from_yaml():
    import tempfile
    import shutil

    fake_vault = {'vault_password': 'MY_PASS'}

    string_yaml = """
    - hosts: localhost
      vars:
        key: value
        anotherkey: anothervalue
    - name: "host 2"
      action:
      - tokenize
      - replace
    """

    string_json = """
    [
        { "hosts": "localhost",
          "vars": {"key": "value", "anotherkey": "anothervalue" }
        },
        { "name": "host 2",
          "action": ["tokenize", "replace"]
        }
    ]
    """

    temp_dir = tempfile.mkdtemp()

    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file_

# Generated at 2022-06-11 09:09:33.855109
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.dataloader
    # Test basic YAML parsing and JSON parsing
    assert from_yaml('{ "a": 1 }') == { "a": 1 }
    assert from_yaml('{ "a": "one" }') == { "a": "one" }
    assert from_yaml('{ "a": "one", "b": "two" }') == { "a": "one", "b": "two" }
    assert from_yaml('{ "a": "one", "b": "two", "c": "three" }') == { "a": "one", "b": "two", "c": "three" }

# Generated at 2022-06-11 09:09:43.259674
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": "b" }') == {u'a': u'b'}
    assert from_yaml('a: b') == {u'a': u'b'}

    try:
        from_yaml('{ "a" }')
    except AnsibleParserError:
        pass
    else:
        assert False

    try:
        from_yaml('{ "a" }', json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False

    try:
        from_yaml('{ "a": "b" }', json_only=True)
    except AnsibleParserError:
        assert False

    assert from_yaml('a: b', json_only=True) == {u'a': u'b'}

# Generated at 2022-06-11 09:09:46.156941
# Unit test for function from_yaml
def test_from_yaml():
    yamlstr = "{'a': 'b', 'c': 'd'}"
    data = from_yaml(yamlstr, file_name=None)
    assert data
    assert data['a'] == 'b'
    assert data['c'] == 'd'

# Generated at 2022-06-11 09:09:52.562526
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml('{}'))
    assert(from_yaml('{}', json_only=True))
    assert(from_yaml('[]'))
    assert(from_yaml('[]', json_only=True))
    assert(from_yaml('invalid') is None)

    # May raise an exception and is not testing from_yaml specifically
    from_yaml('invalid', json_only=True)

# Generated at 2022-06-11 09:10:02.970730
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars import VariableManager, UnifiedVariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import tempfile

    # Make sure we can read YAML documents with a single-quote line
    # Starting in 2.8, the string '''hi''' is interpreted as the literal
    # string 'hi', not the single character 'h' followed by the single
    # character 'i'.  This is a breaking change.
    # We can't have a single-quote line in this file, so we have a
    # temporary file to test whether or not we can read YAML documents
    # that contain one.
    tf = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.yml')

# Generated at 2022-06-11 09:10:13.560595
# Unit test for function from_yaml
def test_from_yaml():
    a = '''
---
- { name: "test_ajson", test: "test_ajson" }
- { name: "test_ajson", test: "test_ajson" }
'''
    b = '''
---
- { name: "test_ajson", test: "test_ajson" }
- { name: "test_ajson", test: "test_ajson" }
'''
    c = [{'name': 'test_ajson', 'test': 'test_ajson'}, {'name': 'test_ajson', 'test': 'test_ajson'}]
    a_ = from_yaml(a)
    b_ = from_yaml(b)
    assert a == b
    assert a_ == c == b_

# Generated at 2022-06-11 09:10:30.811584
# Unit test for function from_yaml
def test_from_yaml():
    """Tests the from_yaml function."""
    import os
    import tempfile

    try:
        from_yaml(None)
        from_yaml(None, json_only=True)
    except AnsibleParserError:
        pass
    else:
        assert False, "Did not fail for None"

    try:
        from_yaml("""[{}, {}, {}]""")
    except AnsibleParserError:
        pass
    else:
        assert False, "Did not fail for a json string not loadable by yaml"

    try:
        from_yaml("{}")
        from_yaml("{}", json_only=True)
    except AnsibleParserError:
        assert False, "Failed for a valid json string"
    else:
        pass


# Generated at 2022-06-11 09:10:43.873626
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.yaml.objects
    import ansible.vars.unsafe_proxy
    import ansible
    from pprint import pprint

    vault_secret = 'foo'

    #YAML to JSON
    yaml_code_01 = """
    ---
    [{
        "foo": "bar"
    },
    {
        "meh": "meh"
    }]
    """
    json_result_01 = json.loads(ansible.parsing.yaml.objects.from_yaml(yaml_code_01, vault_secrets=vault_secret), cls=ansible.parsing.ajson.AnsibleJSONDecoder)
    #pprint(json_result_01)

    #YAML to JSON with variables
    yaml_code_

# Generated at 2022-06-11 09:10:48.512672
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml("{ hello: wold }")
        assert False, "should've raised an exception"
    except AnsibleParserError as e:
        assert "JSON" in to_native(e), to_native(e)
        assert "YAML" in to_native(e), to_native(e)

# Generated at 2022-06-11 09:10:49.664426
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("what is this") == "what is this"


# Generated at 2022-06-11 09:10:59.665342
# Unit test for function from_yaml
def test_from_yaml():
    # Load a valid YAML file
    yaml_file = "test/data/test_valid.yml"
    loaded_yaml = from_yaml(open(yaml_file).read(), file_name=yaml_file, show_content=True)
    assert (loaded_yaml.get('key')) == 'value'

    # Test bad YAML syntax
    bad_yaml = "{'key': 'value'}"
    with pytest.raises(AnsibleParserError) as e:
        loaded_bad = from_yaml(bad_yaml, file_name='<string>', show_content=True)
    assert (e.value.message.startswith("We were unable to read either as JSON nor YAML, these are the errors we got from each:"))

    # Test bad YAML

# Generated at 2022-06-11 09:11:03.067059
# Unit test for function from_yaml
def test_from_yaml():
    print ("Testing function_from_yaml")

    test_data = {'a':'b'}

    result = from_yaml(json.dumps(test_data))

    assert result == test_data, "from_yaml failed"

# Generated at 2022-06-11 09:11:13.852311
# Unit test for function from_yaml
def test_from_yaml():
    # Should be started with vault_secrets = None
    # Example 1
    data = '''
    {
        'name' : 'test',
        'value' : True
    }
    '''
    is_error = False
    try:
        check_obj = from_yaml(data)
    except Exception as e:
        print(str(e))
        is_error = True
    if is_error:
        assert False
    else:
        assert True

    # Example 2
    data = '''
    {
        'name': 'test',
        'value': True
    }
    '''
    is_error = False
    try:
        check_obj = from_yaml(data)
    except Exception as e:
        print(str(e))
        is_error = True

# Generated at 2022-06-11 09:11:15.631293
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{')
    from_yaml('{')
    from_yaml('{')

# Generated at 2022-06-11 09:11:22.828839
# Unit test for function from_yaml
def test_from_yaml():
    j = {"Name": "Foo", "Path": "/thing"}
    y = "Name: Foo\nPath: /thing"
    assert json.dumps(j) == json.dumps(from_yaml(j))
    assert json.dumps(j) == json.dumps(from_yaml(y))

    # Test actual syntax error
    y = "Name\n  Foo\nPath: /thing"

# Generated at 2022-06-11 09:11:33.488827
# Unit test for function from_yaml
def test_from_yaml():
    print("test_from_yaml")

    # With YAML
    yaml_data = """
    foo:
      - hosts: web
        vars:
          http_port: 80
          max_clients: 200
      - hosts: dbservers
        user: root
        vars:
          mysql_port: 3306
    """
    data = from_yaml(yaml_data)
    print("data:", data)

    # With JSON

# Generated at 2022-06-11 09:11:43.874289
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('---\nthis is YAML') == "this is YAML"

# Generated at 2022-06-11 09:11:47.904698
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.parsing.dataloader
    data_loader = ansible.parsing.dataloader.DataLoader()
    import copy
    data = '{"a": "b", "c": "d"}'
    test_datastruct = {'a':'b', 'c': 'd'}
    new_data = from_yaml(data)
    assert(new_data==test_datastruct)

# Generated at 2022-06-11 09:11:57.817774
# Unit test for function from_yaml
def test_from_yaml():
    '''
    :rtype: str
    :return: a string representing the result of this function.
    '''

    # first test invalid json data
    data = '{"foo":"bar"'
    try:
        result = from_yaml(data)
        return 'unable to raise exception for invalid json data'
    except AnsibleParserError as e:
        if "We were unable to read either as JSON nor YAML" in to_native(e):
            return 'good, exception raised for invalid json data'
        else:
            return 'incorrect exception message for invalid json data'

    # then test invalid yaml data
    data = "foo:\nbar"

# Generated at 2022-06-11 09:12:02.848398
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"iam": "yaml"}'

    new_data = from_yaml(data, json_only=True)

    assert new_data['iam'] == 'yaml'


if __name__ == '__main__':
    import pytest
    test_from_yaml()

# Generated at 2022-06-11 09:12:13.135847
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    import pprint

    data = '''---
    runner:
    hosts: localhost
    tasks:
      - name: this is a test
        debug:
            msg: "hello world"
    '''
    data_json = '''{"runner": {"hosts": "localhost", "tasks": [{"debug": {"msg": "hello world"}, "name": "this is a test"}]}}'''
    vault_pass = 'vaultpass'
    vault_secrets = [VaultLib(vault_pass)]

    from_yaml_data = from_yaml(data)
    from_json_data = from_yaml(data_json)

    # Validate yaml data


# Generated at 2022-06-11 09:12:23.393582
# Unit test for function from_yaml

# Generated at 2022-06-11 09:12:33.112932
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "json": "string" }'
    from_yaml(data)
    data = '{ "json": "string" }\n'
    from_yaml(data)
    data = '''
    { "json": "string" }
    '''
    from_yaml(data)
    data = '''
    { "json": "string" }
    '''
    from_yaml(data)
    data = '''
    - json: "string"
    '''
    from_yaml(data)
    data = '''
    - json: "string"
    '''
    from_yaml(data)
    data = '''
    - json: string
    '''
    from_yaml(data)

# Generated at 2022-06-11 09:12:38.073221
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "somekey": "somevalue" }', json_only=True) == { "somekey": "somevalue" }
    assert from_yaml('{ "somekey": "somevalue" }') == { "somekey": "somevalue" }
    assert from_yaml('{ "somekey": "somevalue" }', json_only=False) == { "somekey": "somevalue" }


# Generated at 2022-06-11 09:12:45.587420
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
    - hosts: all
      tasks:
        - name: print a message
          debug: msg="Hello World!"
    """
    test_list = [
        {u'hosts': u'all',
         u'tasks': [{u'debug': {u'msg': u'Hello World!'},
                     u'name': u'print a message'}]}
    ]
    assert from_yaml(test_data) == test_list



# Generated at 2022-06-11 09:12:47.406469
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit tests for function from_yaml
    '''

    import doctest
    doctest.testmod()

# Generated at 2022-06-11 09:13:07.156551
# Unit test for function from_yaml
def test_from_yaml():
    # Test with bad json
    y = """{'a': 1}"""
    try:
        f = from_yaml(y)
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML, these are the errors we" in to_native(e)
        assert "JSON: " in to_native(e)
        assert "YAML: " in to_native(e)

    # Test with good JSON and good yaml
    y = """
    {'a': 1}
    ---
    a: 2
    """
    f = from_yaml(y)
    assert f == [{"a": 1}, {"a": 2}]

    # Test with good json and bad yaml

# Generated at 2022-06-11 09:13:17.945616
# Unit test for function from_yaml
def test_from_yaml():
    data_json = {
        'foo': '1\n2\n3',
        'bar': 4,
        'baz': {
            'nested_list': [
                5,
                6,
                {
                    'nested_dict': {
                        'nested_key': 'hello world!',
                    },
                },
            ],
        },
    }

    data_yaml = """
    foo: >
      1
      2
      3
    bar: 4
    baz:
      nested_list:
      - 5
      - 6
      - nested_dict:
          nested_key: "hello world!"
    """


# Generated at 2022-06-11 09:13:21.873510
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}
    assert from_yaml('foo: bar') == {"foo": "bar"}
    assert from_yaml('{"foo": "bar"') == {"foo": "bar" }

# Generated at 2022-06-11 09:13:31.434113
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 09:13:42.544086
# Unit test for function from_yaml
def test_from_yaml():
    test_with_dict = '''
{
    "param": {
        "key": "val"
    }
}   
'''

    test_with_list = '''
{
    "param": [
        "one", 
        "two", 
        "three"
    ]
}
'''

    test_with_dict_and_list = '''
{
    "param": {
        "key": ["val"]
    },
    "param1": [
        "one",
        "two",
        "three"
    ]
}
'''

    def compare(actual, expected):
        if actual != expected:
            raise AssertionError("expected %s, but returned %s" % (expected, actual))


# Generated at 2022-06-11 09:13:52.715378
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    if PY3:
        import sys
        # Setup required for Python 3 testing
        sys.modules['__builtin__'] = sys.modules['builtins']
    from ansible.parsing.yaml.loader import AnsibleLoader
    import pytest

    # Test encodings
    assert from_yaml('{ "test": "foo" }') == {"test": "foo"}

    # Test non-JSON/YAML data
    with pytest.raises(AnsibleParserError):
        from_yaml('this is bad data')
    with pytest.raises(AnsibleParserError):
        from_yaml('{ "test": "foo" ', json_only=True)

    # Test JSON Only param

# Generated at 2022-06-11 09:14:01.792295
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.collections import ImmutableDict
    data = "foo: [ 1, 2, 3 ]"
    assert from_yaml(data) == {u'foo': [1, 2, 3]}
    data = "{\"foo\": [1, 2, 3]}"
    assert from_yaml(data) == ImmutableDict([(u'foo', [1, 2, 3])])
    assert from_yaml(data, json_only=True) == ImmutableDict([(u'foo', [1, 2, 3])])
    data = "{'foo': [1, 2, 3]}"
    assert from_yaml(data, json_only=True) == {u'foo': [1, 2, 3]}
    data = "foo: [ 1, 2, 3 ]"

# Generated at 2022-06-11 09:14:11.637194
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import tempfile
    import shutil
    import random

    # Create random vault passwords
    master_password1 = ''.join([random.choice('abcdefghijklmnopqrstuvwxyz0123456789!@#$^&*(-_=+)') for i in range(20)])
    master_password2 = ''.join([random.choice('abcdefghijklmnopqrstuvwxyz0123456789!@#$^&*(-_=+)') for i in range(20)])

    # Create random test data
    test_dict1 = {
        'plain_string': 'test_string',
        'string_with_colon': 'test_string: test_string',
        'string_with_space': 'test string'
    }

# Generated at 2022-06-11 09:14:15.766721
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foobar') == 'foobar'
    assert from_yaml('- foo') == [u'foo']
    assert from_yaml('- foo: bar') == [{u'foo': u'bar'}]



# Generated at 2022-06-11 09:14:24.639145
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.collections import ImmutableDict

    assert from_yaml('[1,2]') == [1, 2]
    assert from_yaml('- 1\n- 2') == [1, 2]
    assert from_yaml('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert from_yaml('{a: 1, b: 2}') == {'a': 1, 'b': 2}
    assert from_yaml('{"a": 1, "b": 2, "a": 3}') == {'a': 3, 'b': 2}
    assert from_yaml('[1, 2, 1]') == [1, 2, 1]