

# Generated at 2022-06-11 09:04:40.917216
# Unit test for function from_yaml
def test_from_yaml():
    # Test what happens when we pass json string
    json_data = '{"foo": "bar"}'
    ansible_object = from_yaml(json_data)
    assert(ansible_object == {"foo": "bar"})

    # Test what happens when we pass yaml string
    yaml_data = "foo: bar"
    ansible_object = from_yaml(yaml_data)
    assert(ansible_object == {"foo": "bar"})

    # Test what happens when we pass json string with vault key

# Generated at 2022-06-11 09:04:51.585016
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    yaml_data = """
    - b: 1
    - c: 2
    - d: 3
    """
    vault_pass = 'vaultpassword'
    vault = VaultLib([])
    yaml_data_vault = vault.encrypt(yaml_data, vault_pass)
    decrypted_data = from_yaml(yaml_data_vault, file_name='<string>', show_content=True, vault_secrets=[vault_pass])
    print(decrypted_data)
    assert isinstance(decrypted_data, list)
    assert isinstance(decrypted_data[0], dict)
    assert decrypted_data[0]['b']

# Generated at 2022-06-11 09:04:58.824387
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

    from ansible.parsing.yaml.loader import AnsibleLoader

    # from_yaml should return a loader object on success
    res = from_yaml("{}")
    assert isinstance(res, AnsibleLoader)

    # from_yaml should raise error if the Yaml can not be parsed
    with pytest.raises(AnsibleParserError):
        from_yaml("")

# Generated at 2022-06-11 09:05:00.717163
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('', json_only=True) is None

# Generated at 2022-06-11 09:05:09.439042
# Unit test for function from_yaml
def test_from_yaml():
    d1 = """
    {
        'json_dict': {
            'a': 1,
            'b': 2
        }
    }
    """

    d2 = """
    yaml_dict:
        a: 1
        b: 2
    """

    assert(from_yaml(d1) == {"json_dict": {"a": 1, "b": 2}})
    assert(from_yaml(d2) == {"yaml_dict": {"a": 1, "b": 2}})

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:05:12.956573
# Unit test for function from_yaml
def test_from_yaml():
    dict1 = from_yaml("""
    before:
      - 1
      - 2
      - 3
      - 4
      - 5
      - 6
      - 7
      - 8
      - 9
      - 10
    """)
    assert dict1['before'] == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-11 09:05:24.195197
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u"{'foo': 'bar'}") == {'foo': 'bar'}
    assert from_yaml(u"{u'foo': 'bar'}") == {u'foo': 'bar'}
    assert from_yaml(u"{'foo': 'bar', 'baz': 42}") == {'foo': 'bar', 'baz': 42}
    assert from_yaml(u"{'foo': 'bar', 'baz': 42, 'boo': True}") == {'foo': 'bar', 'baz': 42, 'boo': True}

# Generated at 2022-06-11 09:05:34.079126
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"a": "b"}') == {'a': 'b'}
    assert from_yaml('a: b') == {'a': 'b'}
    bad_yaml = '"{"a": "b"}"'
    try:
        from_yaml(bad_yaml)
        raise Exception('Unexpectedly parsed bad YAML')
    except AnsibleParserError:
        pass
    bad_json = '{"a": "b"}'
    try:
        from_yaml(bad_json, json_only=True)
        raise Exception('Unexpectedly parsed bad JSON')
    except AnsibleParserError:
        pass
    assert from_yaml(bad_json, json_only=False) == {'a': 'b'}

# Generated at 2022-06-11 09:05:45.971163
# Unit test for function from_yaml

# Generated at 2022-06-11 09:05:56.315743
# Unit test for function from_yaml
def test_from_yaml():
    '''
    ansible.module_utils.basic.from_yaml test
    from_yaml accepts strings that are valid JSON or YAML
    from_yaml accepts a list of vault secrets
    '''
    from ansible.parsing.yaml.loader import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultSecret

    json_valid_string = '{"foo": "bar"}'
    yaml_valid_string = 'foo: bar\nbaz: quux'
    vault_secrets = [VaultSecret('vault_password', b'password', 'sha1')]

    # Must work
    data = from_yaml(json_valid_string)
    assert data == {"foo": "bar"}
    data = from_yaml(yaml_valid_string)
   

# Generated at 2022-06-11 09:06:08.391367
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = """
    test:
      - { name: test, state: present }
      - { name: test2, state: absent, type: sth }
    ignore_errors: true
    """
    assert from_yaml(yaml_str) == dict(test=[{'name': 'test', 'state': 'present'}, {'name': 'test2', 'state': 'absent', 'type': 'sth'}], ignore_errors=True)

    json_str = """{
    "test": [
        {
            "name": "test",
            "state": "present"
        },
        {
            "name": "test2",
            "state": "absent",
            "type": "sth"
        }
    ],
    "ignore_errors": true
}"""
    assert from_

# Generated at 2022-06-11 09:06:13.147099
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{\"a\": 1}") == {"a": 1}
    assert from_yaml("{\"a\": 1}", json_only=True) == {"a": 1}
    assert from_yaml("a: 1") == {"a": 1}

# Generated at 2022-06-11 09:06:13.896492
# Unit test for function from_yaml
def test_from_yaml():
    print(from_yaml('{}', ''))

# Generated at 2022-06-11 09:06:15.234156
# Unit test for function from_yaml
def test_from_yaml():
    assert type(from_yaml(data='invalid')) == type(None)

# Generated at 2022-06-11 09:06:18.778869
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
isit:
  member: [1, 2, 3]
'''
    res = from_yaml(data)
    assert isinstance(res, dict)
    assert res['isit']['member'] == [1 ,2, 3]

# Generated at 2022-06-11 09:06:20.652456
# Unit test for function from_yaml
def test_from_yaml():

    import os

    data = """
    {
        "foo": "bar"
    }
    """

    print(from_yaml(data))

# Generated at 2022-06-11 09:06:26.493579
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert from_yaml('') is None
    assert from_yaml('1') == 1
    assert from_yaml('true') is True
    assert from_yaml('false') is False
    assert from_yaml('""') == ''
    assert from_yaml('[]') == []
    assert from_yaml('{}') == {}
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('{foo: bar}') == {'foo': 'bar'}
    assert from_yaml('foo: bar') == {'foo': 'bar'}

# Generated at 2022-06-11 09:06:30.426225
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Tests for function from_yaml
    '''
    assert from_yaml('{foo: bar}') == {u'foo': u'bar'}
    assert from_yaml('[foo, bar]') == [u'foo', u'bar']
    assert from_yaml('[foo, bar,') == None
    assert from_yaml('[foo, bar]', json_only=True) is None
    assert from_yaml('[foo, bar]', json_only=True) is None
    assert from_yaml('{foo: bar', json_only=True) is None
    assert from_yaml('''
- name: foo
  hosts: localhost
''') == [{u'hosts': u'localhost', u'name': u'foo'}]

# Generated at 2022-06-11 09:06:40.362612
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.plugins.loader.vault import VaultLib

    json_failure_test_data = b'''
        {
            "thisKeyIsMissingAQuote": "oops
            "bad json": 'ignore'
        }
    '''

    yaml_failure_test_data = b'''
        thisKeyIsMissingAQuote: "oops
        badYaml: 'ignore'
    '''

    success_test_data = b'''
        theRightWay: "ok"
    '''

    show_content = True
    file_name = 'test_from_yaml'

    with VaultLib([]) as vault:
        vault_secrets = vault.secrets

# Generated at 2022-06-11 09:06:47.167345
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''\
---
# This is a YAML document.
name: Brian Coca
age: 55
weight: 180 # Pounds
active: true
children:
  - Mary
  - John
  - Paul
  - Susan
'''
    results = from_yaml(test_data)
    assert results['name'] == "Brian Coca"
    assert results['weight'] == 180
    assert results['active'] is True
    assert len(results['children']) == 4



# Generated at 2022-06-11 09:06:58.324811
# Unit test for function from_yaml
def test_from_yaml():
    results = []
    results.append(('{"foo": "bar"}', {"foo": "bar"}))

    # Playbook

# Generated at 2022-06-11 09:07:04.703391
# Unit test for function from_yaml
def test_from_yaml():
    def test_function(data, file_name='<string>', show_content=True, vault_secrets=None, json_only=False):
        return from_yaml(data, file_name, show_content, vault_secrets)

    import pytest
    from unittest import TestCase

    class TestError(Exception):
        pass

    class MyTest_test_function(TestCase):
        def runTest(self):
            print("Running test test_function")
            # Imports needed for test
            import json
            import sys
            import base64
            import copy


# Generated at 2022-06-11 09:07:15.068663
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''

    result = from_yaml('{"name": "rhel-server", "version": "7.5"}')
    assert isinstance(result, dict)
    assert result == {"name": "rhel-server", "version": "7.5"}

    result = from_yaml('''
        ---
        - hosts: all
          gather_facts: yes
          tasks:
            - name: install httpd
              yum:
                name: httpd
                state: present
    ''')
    assert isinstance(result, list)
    assert result[0]['hosts'][0] == 'all'
    assert result[0]['tasks'][0]['name'] == 'install httpd'

# Generated at 2022-06-11 09:07:25.875668
# Unit test for function from_yaml
def test_from_yaml():
    data1 = '''{
    "foo": "bar",
    "baz": 1
}
'''

    data2 = '''
foo: bar
baz: 1
'''

    data3 = '''
{
    "foo" : "bar",
    "baz" : 1,
    "list" : [
        "a",
        "b",
        "c"
    ],
    "dict" : {
        "foo" : "bar",
        "baz" : "foobar"
    }
}
'''

    expected = {'baz': 1, 'foo': 'bar'}

    assert(expected == from_yaml(data1))
    assert(expected == from_yaml(data2))
    json = from_yaml(data3)
    assert(expected == json)

# Generated at 2022-06-11 09:07:28.025383
# Unit test for function from_yaml
def test_from_yaml():
    assert not from_yaml("""
---
- hosts: all
  tasks:
  - name: foo
    shell: touch /tmp/bar
""", "test.yml") is None

# Generated at 2022-06-11 09:07:31.533227
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing import vault
    import json

    with open("/home/dmyan/vault.yml",'r') as f:
        data = f.read()
    
    ansible_vault_password = "test123"

    secret = VaultSecret(ansible_vault_password)
    vault_secrets = [secret]
    
    print("##### from_yaml 1 #####")
    try:
        new_data = from_yaml(data)
        print(json.dumps(new_data))
    except Exception as json_exc:
        print("json_exc: %s " % json_exc)
        print

# Generated at 2022-06-11 09:07:44.071920
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault

    _s = '''
---
secret:
  test: false
'''

    # Unencrypted String
    s = from_yaml(_s)
    assert s['secret']['test'] == False

    # Encrypted String
    _s = vault.encrypt_string(_s, password='password', return_input=True)
    s = from_yaml(_s, vault_secrets=['password'])
    assert s['secret']['test'] == False

    # Encrypted Vault File
    _s = vault.encrypt_string(_s, password='password', return_input=True, output_file="test_playbook.yml")
    res = from_yaml(open("test_playbook.yml").read(), vault_secrets=['password'])

# Generated at 2022-06-11 09:07:51.025924
# Unit test for function from_yaml
def test_from_yaml():
    # Test passing invalid YAML file
    data = "key:\n- { foo: bar }"
    file_name = '/invalid/yaml'
    show_content = False
    vault_secrets = None
    json_only = False

    try:
        from_yaml(data, file_name, show_content, vault_secrets, json_only)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('test_from_yaml did not raise')

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:07:56.330392
# Unit test for function from_yaml
def test_from_yaml():
    # Test reading from a string
    from ansible.parsing.yaml.objects import AnsibleUnicode
    yaml_obj = from_yaml("""
        name:
            - value1
            - value2
        """)
    assert(isinstance(yaml_obj['name'][0],  AnsibleUnicode))
    assert(yaml_obj['name'][0] == "value1")

# Generated at 2022-06-11 09:08:07.364100
# Unit test for function from_yaml
def test_from_yaml():

    import unittest
    import os

    class TestFromYaml(unittest.TestCase):

        def test_nested_dict(self):
            result = from_yaml('''
                name: Leo
                location:
                  city: NYC
                  state: NY
            ''', file_name='/test/file/name')
            expected = {
                'name': 'Leo',
                'location': {
                    'city': 'NYC',
                    'state': 'NY',
                }
            }
            self.assertEqual(result, expected)


# Generated at 2022-06-11 09:08:17.820646
# Unit test for function from_yaml
def test_from_yaml():
    # Load a dictionary from YAML.
    test_dict = {"x": 1}
    test_yaml = 'x: 1'
    result = from_yaml(test_yaml)
    assert result == test_dict, "YAML => Python failed"

    # Load a list from YAML.
    test_list = ["x", 1]
    test_yaml = '- x\n- 1'
    result = from_yaml(test_yaml)
    assert result == test_list, "YAML => Python failed"

    # Load a list from JSON.
    test_json = '[1,2,3]'
    result = from_yaml(test_json, json_only=True)
    assert result == [1, 2, 3], "JSON => Python failed"

    # Load a list from JSON

# Generated at 2022-06-11 09:08:29.783064
# Unit test for function from_yaml
def test_from_yaml():

    # GIVEN a string with valid JSON
    in_data = '{"name": "Andre", "age": 32, "is_valid": true}'

    # WHEN parsing into a Python structure using function from_yaml
    out_data = from_yaml(in_data)

    # THEN the output should be a Python structure as expected
    assert out_data == {'name': 'Andre', 'age': 32, 'is_valid': True}

    # GIVEN a string with valid YAML
    in_data = 'name: Andre\nage: 32\nis_valid: true'

    # WHEN parsing into a Python structure using function from_yaml
    out_data = from_yaml(in_data)

    # THEN the output should be a Python structure as expected

# Generated at 2022-06-11 09:08:38.189880
# Unit test for function from_yaml
def test_from_yaml():
    # This is a not very useful test, but at least we have some unit test coverage.
    from ansible.parsing.yaml.objects.dict import AnsibleMapping
    a = from_yaml('{"a": "b"}')
    assert a == {'a': 'b'}
    assert isinstance(a, dict)
    b = from_yaml('{"a": "b"}', json_only=True)
    assert b == {'a': 'b'}
    assert isinstance(b, dict)
    c = from_yaml('{"a": "b"}', json_only=False)
    assert c == {'a': 'b'}
    assert isinstance(c, dict)
    d = from_yaml('a: b')
    assert d == {'a': 'b'}

# Generated at 2022-06-11 09:08:51.297922
# Unit test for function from_yaml
def test_from_yaml():
    # Test the base case
    file_name = 'test.yml'
    data = "---\n- key: value\n- another key: another value"
    result = from_yaml(data, file_name)
    assert result == [{'key' : 'value'}, {'another key': 'another value'}]

    # Test a YAML parsing error
    data = "---\n- key: value\n- another key: another value:\n- what"
    try:
        result = from_yaml(data, file_name)
        assert result is None
    # pylint: disable=broad-except
    except Exception as e:
        assert 'While parsing' in str(e)
        assert 'expected <block end>, but found \'<scalar>\'' in str(e)

# Generated at 2022-06-11 09:09:00.217984
# Unit test for function from_yaml
def test_from_yaml():
    """
    unit test for from_yaml
    """
    def test_json(test_data):
        try:
            data = from_yaml(test_data, json_only=True)
        except AnsibleParserError as e:
            data = e

        assert isinstance(data, dict)
        assert data.get('foo') == 123

    def test_yaml(test_data):
        try:
            data = from_yaml(test_data)
        except AnsibleParserError as e:
            data = e

        assert isinstance(data, dict)
        assert data.get('foo') == 123

    def test_error(test_data):
        try:
            data = from_yaml(test_data)
        except AnsibleParserError as e:
            data = e


# Generated at 2022-06-11 09:09:10.918701
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.playbook.play
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.inventory.host import Host

    Jinja2Text = ansible.playbook.play.Jinja2Text

    source = '''
- hosts: localhost
  tasks:
    - name: print a message
      debug:
        msg: "hello world"
    - name: print another message
      debug:
        msg: "goodbye world"
'''

    result = from_yaml(source)

    assert isinstance(result[0]['hosts'], Host)
    assert isinstance(result[0]['tasks'][0], Play.Task)
    assert isinstance(result[0]['tasks'][1], Play.Task)

    playbook

# Generated at 2022-06-11 09:09:22.242703
# Unit test for function from_yaml
def test_from_yaml():
    import copy
    import random
    import string

    for i in range(10000):
        # generate random dictionary
        orig_data = {}
        for _ in range(random.randint(10, 100)):
            orig_data[random.choice(string.ascii_letters)] = random.choice(string.ascii_letters)

        # convert to JSON, then to YAML, then back to JSON
        json1 = json.dumps(orig_data, ensure_ascii=False)
        yaml1 = json.loads(json1)
        json2 = from_yaml(yaml1)

        # did we get the same dictionary back?
        assert json1 == json2


# Generated at 2022-06-11 09:09:32.352815
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3

    assert from_yaml("{\"a\": \"d\"}") == {'a': 'd'}
    assert from_yaml("{'a': 'd'}") == {'a': 'd'}
    assert from_yaml("{a: d}", file_name="<string>", show_content=True) == {'a': 'd'}
    if not PY3:
        assert from_yaml("{u'a': u'd'}") == {'a': 'd'}
        assert from_yaml("{u'a': u'\u2018d'}") == {'a': '\u2018d'}

# Generated at 2022-06-11 09:09:42.296795
# Unit test for function from_yaml
def test_from_yaml():
    data_yaml = '''
---
name:
- test
- playbook
'''
    data_yaml_arr = []
    data_yaml_arr.append(data_yaml)
    data_json = '{"name":["test", "playbook"]}'
    data_json_arr = []
    data_json_arr.append(data_json)
    for i in range(len(data_yaml_arr)):
        print(data_yaml_arr[i])
        print(data_json_arr[i])
        json_data = from_yaml(data_yaml_arr[i], 'tmpfile', show_content=True, vault_secrets=None, json_only=False)
        print(json_data)

# Generated at 2022-06-11 09:09:50.692336
# Unit test for function from_yaml
def test_from_yaml():
    data = {
        'basic_float': 42.0,
        'basic_int': 42,
        'basic_list': ['test1', 'test2'],
        'basic_dict': {
            'foo': 'bar',
            'bar': 'baz'
        },
        'basic_str': 'test',
        'basic_bool': True,
        'basic_none': None,
    }


# Generated at 2022-06-11 09:10:03.233237
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # test ansible_pos
    data = {'k1': 'v1'}
    dumper = AnsibleDumper()
    yaml = dumper.dump(data)
    yaml_obj = from_yaml(yaml, file_name='test_pos')
    assert yaml_obj.ansible_pos == ('test_pos', 1, 1)

    # test ansible_pos key

# Generated at 2022-06-11 09:10:14.588621
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test the from_yaml function
    '''
    import os
    import unittest

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils import plugin_docs

    class AnsibleFromYamlTest(unittest.TestCase):
        def setUp(self):
            self.docs_dir = plugin_docs.find('doc_fragments')

        def tearDown(self):
            pass

        def test_from_yaml(self):
            '''
            Test docs loaded as yaml
            '''

            #get list of yaml docs
            yaml_files = []

# Generated at 2022-06-11 09:10:15.517222
# Unit test for function from_yaml
def test_from_yaml():
    pass


# Generated at 2022-06-11 09:10:17.305333
# Unit test for function from_yaml
def test_from_yaml():
    data = {'key1': 'value1'}
    assert from_yaml(json.dumps(data)) == data

# Generated at 2022-06-11 09:10:27.795090
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("key: value") == {'key': 'value'}
    assert from_yaml("key: !!str value") == {'key': 'value'}
    assert from_yaml("key: !!python/unicode 'value'") == {'key': 'value'}
    assert from_yaml("key: !!python/str 'value'") == {'key': 'value'}
    assert from_yaml("key: !!python/int '42'") == {'key': 42}
    assert from_yaml("key: !!python/float '42.0'") == {'key': 42.0}
    assert from_yaml("key: !!python/complex '42+21j'") == {'key': 42+21j}

# Generated at 2022-06-11 09:10:33.682978
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1, "b": 2 }') == {'a': 1, 'b': 2}
    assert from_yaml('{ "a": 1, "b": 2 }\n{ "a": 1, "b": 2 }\n') == [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
    assert from_yaml('{ "a": 1, "b": 2 }', json_only=True) == {'a': 1, 'b': 2}
    assert from_yaml('{ "a": 1, "b": 2 }\n{ "a": 1, "b": 2 }\n', json_only=True) == [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]

# Generated at 2022-06-11 09:10:46.274892
# Unit test for function from_yaml
def test_from_yaml():

    # A valid json object
    assert from_yaml('{"My":"String"}') == {'My': 'String'}

    # A valid json list
    assert from_yaml('[1,2,3]') == [1, 2, 3]

    # A valid json dict
    assert from_yaml('{"1":"2"}') == {'1': '2'}

    # A valid yaml object
    assert from_yaml('My: String') == {'My': 'String'}

    # A valid yaml list
    assert from_yaml('[1,2,3]') == [1, 2, 3]

    # A valid yaml list
    assert from_yaml('- 1\n- 2\n- 3') == [1, 2, 3]

    # A valid yaml dict
    assert from_

# Generated at 2022-06-11 09:10:48.409849
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
    ---
    - hosts: localhost
      tasks:
      - name: this is a test
        shell: echo "hello"
    """
    result = from_yaml(test_data)
    assert result['tasks'][0]['shell'] == 'echo "hello"'

# Generated at 2022-06-11 09:10:51.622626
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    data = 'string: test'
    file_name = "testfile"
    show_content = True
    vault_secrets = None
    json_only = False
    assert from_yaml(data, file_name, show_content, vault_secrets,json_only) == {'string':'test'}



# Generated at 2022-06-11 09:11:02.168178
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils import json as json_utils


# Generated at 2022-06-11 09:11:07.186510
# Unit test for function from_yaml
def test_from_yaml():

    print(from_yaml('{ "foo" : "bar", "list": ["baz", "quz"] }', ''))


# Generated at 2022-06-11 09:11:13.701264
# Unit test for function from_yaml
def test_from_yaml():
    """
    Validates that from_yaml works
    """
    yaml_data = "name: bob"
    from_yaml(yaml_data)
    yaml_data = """- name: bob"""
    from_yaml(yaml_data)
    yaml_data = """- name: bob
      age: 24"""
    from_yaml(yaml_data)
    yaml_data = """- name: bob
      age: 24
      """
    from_yaml(yaml_data)

# Generated at 2022-06-11 09:11:20.627379
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    class TestFromYaml(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_from_yaml(self):
            data = "{ 'test' : 'test' }"
            file_name = '<string>'
            show_content = True
            vault_secrets = None
            json_only = False
            print(from_yaml(data, file_name, show_content, vault_secrets, json_only))
    unittest.main()
if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:11:27.151257
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
---
foo:
  - 1
  - 2
  - 3
'''
    json_data = '''{
  "foo": [
    1,
    2,
    3
  ]
}'''

    # A non-json string that can be parsed as YAML
    json_yaml = from_yaml(yaml_data)

    # A JSON string
    json_json = from_yaml(json_data)

    assert json_yaml == json_json

# Generated at 2022-06-11 09:11:37.237245
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml

    # does the function run
    from_yaml("a: 1")

    import sys, os
    sys.path.append(os.path.join(os.path.split(__file__)[0], '..', '..'))
    test_data_ud = os.path.join(os.path.split(__file__)[0], 'test_data_ud')

    # run with some test data
    from_yaml(open(os.path.join(test_data_ud, 'test_blockinfile.yml')).read())
    from_yaml(open(os.path.join(test_data_ud, 'test_blockinfile.json')).read())

# Generated at 2022-06-11 09:11:46.379618
# Unit test for function from_yaml
def test_from_yaml():
    # Test JSON
    assert from_yaml("[{'b':'a'},{'b': ['c', 'd']}]") == [{'b': 'a'}, {'b': ['c', 'd']}]
    assert from_yaml("{'a': {'b': ['c', 'd']}}") == {'a': {'b': ['c', 'd']}}
    # Test YAML
    assert from_yaml("- - a\n  - b\n") == [['a', 'b']]
    assert from_yaml("- { c : d }") == [{'c': 'd'}]

# Generated at 2022-06-11 09:11:53.831083
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("foo") == "foo"
    assert from_yaml("foo\n") == "foo\n"
    assert from_yaml("foo: bar") == dict(foo='bar')
    assert from_yaml("foo: bar\n") == dict(foo='bar')
    assert from_yaml("foo: !!python/object/apply:os.system\n- echo bar\n") == dict(foo='bar')
    assert from_yaml("foo: '!!python/object/apply:os.system\\n[echo bar]'") == dict(foo='bar')
    # NOTE: below is the YAML syntax, not a python literal
    assert from_yaml("- !!python/object/apply:os.system\n- echo bar") == ["bar"]

# Generated at 2022-06-11 09:11:58.995007
# Unit test for function from_yaml
def test_from_yaml():
    data = '{ "test": true }'
    file_name = 'test_file'
    new_data = from_yaml(data, file_name=file_name, show_content=True)
    assert new_data['test']



# Generated at 2022-06-11 09:12:10.102521
# Unit test for function from_yaml
def test_from_yaml():
    # Test with valid json input
    json_input = "{\"name\": \"Test1\"}"
    result = from_yaml(json_input)
    assert result["name"] == "Test1"

    # Test with valid yaml input
    yaml_input = "name: Test2"
    result = from_yaml(yaml_input)
    assert result["name"] == "Test2"

    # Test with invalid json input
    json_input = "{\"name: Test3\"}"
    try:
        result = from_yaml(json_input)
    except AnsibleParserError:
        result = False
    assert result == False

    # Test with invalid yaml input
    yaml_input = "name: Test4"

# Generated at 2022-06-11 09:12:20.322979
# Unit test for function from_yaml
def test_from_yaml():
    """Basic unit tests for ansible/parsing/yaml/__init__.py:from_yaml()
    The tests are based on the documentation.
    """
    assert from_yaml('{}') == {}
    assert from_yaml('{ }') == {}
    assert from_yaml('{}', json_only=True) == {}
    try:
        from_yaml('{', json_only=True)
        assert False
    except AnsibleParserError:
        pass
    assert from_yaml('[]') == []
    assert from_yaml('"foo"') == 'foo'
    assert from_yaml('"foo"', json_only=True) == 'foo'
    assert from_yaml('foo', json_only=True) == 'foo'

# Generated at 2022-06-11 09:12:31.865008
# Unit test for function from_yaml
def test_from_yaml():
    # Success case
    sample_yaml_data = 'foo: [bar, {a: b}]'
    assert from_yaml(sample_yaml_data) == {'foo': ['bar', {'a': 'b'}]}

    # Expected failure case
    sample_bad_yaml_data = 'foo: [bar, {a: b'
    assert from_yaml(sample_bad_yaml_data) == {'foo': ['bar', {'a': 'b'}]}

# Generated at 2022-06-11 09:12:40.271245
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Property based test for function from_yaml.

    Testcases are generated using hypothesis.
    '''
    from hypothesis import given, settings
    from hypothesis.strategies import text
    from hypothesis.provisional import ipv4_address

    @settings(deadline=None)
    @given(sample=text())
    def test_from_yaml_text(sample):
        try:
            assert from_yaml(sample) == from_yaml(sample)
        except Exception as e:
            assert from_yaml(sample) == str(e)

    test_from_yaml_text()


# Generated at 2022-06-11 09:12:46.214219
# Unit test for function from_yaml
def test_from_yaml():
    dict_data = {"test": "hello world"}
    str_data = '{"test": "hello world"}'

    # unit test json
    assert from_yaml(str_data) == dict_data

    # unit test yaml
    str_data = '\n'.join(str_data.split())
    assert from_yaml(str_data) == dict_data

# Generated at 2022-06-11 09:12:50.127252
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[]') == []
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}

# Generated at 2022-06-11 09:12:52.615032
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "name": "hello" }') == {'name': 'hello'}
    assert from_yaml('name: hello') == {'name': 'hello'}


# Generated at 2022-06-11 09:13:02.723786
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("") == None
    assert from_yaml("{}") == {}
    assert from_yaml("[]") == []
    assert from_yaml('{"a": 5}') == {"a": 5}
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('{"a": 5}', json_only=True) == {"a": 5}
    assert from_yaml('[1, 2, 3]', json_only=True) == [1, 2, 3]

    try:
        from_yaml(None)
        assert False
    except AnsibleParserError:
        pass


# Generated at 2022-06-11 09:13:12.000470
# Unit test for function from_yaml
def test_from_yaml():
    print('Testing from_yaml()')

    # Case 1: Basic YAML string
    yaml_str = """
    foo: bar
    baz:
      - quux
      - norf
    """
    json_str = """
    {
        "foo": "bar",
        "baz": [
            "quux",
            "norf"
        ]
    }
    """

    yaml_data = from_yaml(yaml_str)
    assert isinstance(yaml_data, dict)
    assert list(yaml_data.keys()) == ['foo', 'baz']
    assert yaml_data.get('foo') == 'bar'
    assert isinstance(yaml_data.get('baz'), list)

# Generated at 2022-06-11 09:13:19.412529
# Unit test for function from_yaml
def test_from_yaml():
    yaml_str = """
        #!/usr/bin/python3
        - { role: common, tags: [ 'foo', 'bar' ] }
        - debug:
          - var=foo_var
          - var=bar_var
          when: not (foo_var == 1 and bar_var == 1)
    """

    data = from_yaml(yaml_str)
    assert data[0]['role'] == 'common'
    assert data[0]['tags'] == ['foo', 'bar']

# Generated at 2022-06-11 09:13:29.528576
# Unit test for function from_yaml
def test_from_yaml():
    # Create yaml data with error and check error is raised
    yaml_string_error = '''---
- name: test
  community: "{{ community_string }}"
  ip: %s
  version: 3
  state: present
  groups:
   - cisco
   - ios
''' % '1.1.1.1'

    try:
        from_yaml(yaml_string_error)
    except AnsibleParserError as e:
        assert str(e).startswith(u"Unsupported string format")

    # Create yaml data with valid string and check the function returns a dictionary

# Generated at 2022-06-11 09:13:38.037787
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo') == 'foo'
    assert from_yaml('foo\n') == 'foo\n'
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml('foo: "1,2,3"') == {'foo': '1,2,3'}
    assert from_yaml('"1,2,3"') == '1,2,3'
    assert from_yaml('- 1\n- 2\n- 3') == [1, 2, 3]
    assert from_yaml('"1,2,3"\nfoo: bar') == {'1,2,3': 'foo', 'bar': None}
    assert from_yaml('foo\nfoo: bar') == {'foo': ['foo', 'bar']}

# Generated at 2022-06-11 09:13:56.080632
# Unit test for function from_yaml
def test_from_yaml():
    print ("\n\n########## Testing function from_yaml ########################\n")
    #Test 1
    #Test a simple dictionary
    test_data = '{"ansible_facts": {"distribution": "RedHat"}}'
    print ("\nTest1: \n",
           "Input data:", test_data, "\nExpected output: ",
           {"ansible_facts": {"distribution": "RedHat"}}, "\nActual output: ",
           from_yaml(test_data=test_data))

    #Test 2
    #Test a simple list
    test_data = "---\n- rhsm_ca_name: redhat-uep.pem"

# Generated at 2022-06-11 09:14:01.375815
# Unit test for function from_yaml
def test_from_yaml():
    # JSON input (basic)
    a = """
    { "test" : "testval" }
    """
    assert from_yaml(a) == {"test": "testval"}

    # JSON input (complex)
    b = """
    {
        "test": "testval",
        "test2": {
            "test3": ["testval3-1", "testval3-2"],
            "test4": {
                "test5": "testval5"
            },
            "test6": null
        }
    }
    """

# Generated at 2022-06-11 09:14:05.320298
# Unit test for function from_yaml
def test_from_yaml():

    # Fails
    #assert from_yaml('{"foo": 1}')  # JSON only, fails with XFAIL

    # Succeeds
    assert from_yaml('{"foo": 1}', json_only=True)

    # Succeeds
    assert from_yaml('foo: 1')

# Generated at 2022-06-11 09:14:16.418966
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.literals import LiteralToken
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.utils.vault import _get_decryption_context


# Generated at 2022-06-11 09:14:24.267958
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test function for function `from_yaml`.
    '''
    assert from_yaml('{"a": 1}') == {"a": 1}
    assert from_yaml('{"a": 1}', json_only=True) == {"a": 1}

    try:
        from_yaml('{"a": 1}', json_only=True)
    except AnsibleParserError as e:
        assert str(e) == r"We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: We were unable to read either as JSON nor YAML, these are the errors we got from each:\nJSON: Extra data: line 1 column 5 (char 4)"

# Generated at 2022-06-11 09:14:32.361233
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.playbook.vault import VaultSecret

    # simple example
    data = "{'foo': 42}"
    result = from_yaml(data)
    assert not isinstance(result, dict)
    assert result == {'foo': 42}

    # example with vault