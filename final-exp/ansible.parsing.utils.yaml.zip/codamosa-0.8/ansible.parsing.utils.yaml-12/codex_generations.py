

# Generated at 2022-06-11 09:04:42.400580
# Unit test for function from_yaml
def test_from_yaml():
    # Create a playbook with a v1 vault encrypted var and a v2 vault encrypted var.
    from ansible.parsing.vault import VaultLib
    import tempfile

    # Create the v2 vault password file
    v2_password_filename = tempfile.mktemp()
    with open(v2_password_filename, 'w') as v2_password_file:
        v2_password_file.write('v2_password')

    # Create the v2 vault secrets for decrypting the v2 vault
    vault_secrets = []
    vault_secrets.append({'vault_password_file': v2_password_filename, 'vault_identity': None})

    # Create the v1 vault password
    v1_password = 'v1_password'

    # Create the v1 vault secret for decrypting the v1 vault

# Generated at 2022-06-11 09:04:48.203626
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a" : 3}'
    assert from_yaml(data) == {"a" : 3}
    data = '{a : 3}'
    try:
        from_yaml(data)
    except AnsibleParserError:
        pass
    data = '{a : 3}'
    try:
        from_yaml(data, json_only=True)
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 09:04:53.984521
# Unit test for function from_yaml
def test_from_yaml():
    data = "---\ntestdata\n"
    new_data = from_yaml(data)
    assert new_data == "testdata"

    data = "{ \"testdata\" : \n\t 42 }"
    new_data = from_yaml(data)
    assert new_data == {"testdata": 42}

# Generated at 2022-06-11 09:05:07.186167
# Unit test for function from_yaml
def test_from_yaml():
    """ Unit test for function from_yaml """
    assert from_yaml('1') == 1
    assert from_yaml('{"a": 1}') == {'a': 1}
    assert from_yaml('---\na: 1') == {'a': 1}
    try:
        from_yaml('{a: 1}', json_only=True)
        assert False, "from_yaml should have throw an exception"
    except AnsibleParserError:
        pass
    try:
        from_yaml('{a: 1}')
        assert False, "from_yaml should have throw an exception"
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 09:05:12.273416
# Unit test for function from_yaml
def test_from_yaml():
    data = """
---
- { name: paul, age: 22 }
- name: jay
- etc: deng
    """
    list_res = [{'age': 22, 'name': 'paul'}, {'name': 'jay'}, {'etc': 'deng'}]
    test_data = from_yaml(data)
    assert list_res == test_data

# Generated at 2022-06-11 09:05:23.361085
# Unit test for function from_yaml
def test_from_yaml():
    import ansible.constants
    import ansible.utils
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.vault import VaultLib, VaultSecret

    class TestVaultSecret(VaultSecret):
        def __init__(self, password='ansible'):
            super(TestVaultSecret, self).__init__()
            self.password = password

        def get_payload(self, vault_secret):
            return self.password

    ansible.constants.HASH_SALT = None
    vault_secret = TestVaultSecret()
    _ = from_yaml('{"foo":"bar"}', vault_secrets=vault_secret)
    assert isinstance(_, dict)

    # test with vaulted values in the string
    vault_secret = TestVaultSecret

# Generated at 2022-06-11 09:05:29.864880
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    data = loader._read_vault_file("test/integration/vault_vars/vault_var_file_enc.yml")
    from_yaml(data, "test/integration/vault_vars/vault_var_file_enc.yml")

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:05:35.222885
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    data = '{"a": 1, "b": 2, "c": 3}'
    test_from_yaml = loader.from_yaml(data, '<string>')
    assert test_from_yaml == {'a': 1, 'b': 2, 'c': 3}, 'from_yaml is not working as expected'



# Generated at 2022-06-11 09:05:41.039588
# Unit test for function from_yaml
def test_from_yaml():
    data = "{'some': 'a_dict'}"
    file_name = '<string>'
    show_content = True
    vault_secrets = None
    json_only = False
    new_data = {'some': 'a_dict'}
    assert new_data == from_yaml(data, file_name, show_content, vault_secrets, json_only)


# Generated at 2022-06-11 09:05:52.106538
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import re


# Generated at 2022-06-11 09:06:02.108924
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleParserError

    path = os.path.dirname(__file__)
    fname = "%s/test_yaml.yml" % path
    json_fname = "%s/test_json.json" % path
    bad_fname = "%s/test_yaml_bad.yml" % path

    secrets = VaultLib([])
    secrets.secrets.append('password')

    #test yaml
    ds = from_yaml(open(fname).read(), file_name=fname, vault_secrets=secrets)

    assert ds is not None
    assert ds['foo'] == 'bar'
    assert ds['bar'] == 123

# Generated at 2022-06-11 09:06:15.188987
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1 }') == {"a": 1}
    assert from_yaml('{ "a": 1 }', json_only=True) == {"a": 1}
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('[1, 2, 3]', json_only=True) == [1, 2, 3]
    assert from_yaml('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert from_yaml('{"a": 1, "b": 2}', json_only=True) == {"a": 1, "b": 2}

# Generated at 2022-06-11 09:06:15.752435
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-11 09:06:23.963275
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('{"a": 1, "b": [2, 3]}') == {'a': 1, 'b': [2, 3]}
    assert from_yaml('["a", "b", 1, 2]') == ["a", "b", 1, 2]
    assert from_yaml('a: b') == {'a': 'b'}
    assert from_yaml('---\n- a') == ['a']
    assert from_yaml('{"a": 1, "b": [2, 3]}', show_content=False) == {'a': 1, 'b': [2, 3]}

# Generated at 2022-06-11 09:06:35.022974
# Unit test for function from_yaml

# Generated at 2022-06-11 09:06:45.631165
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit tests for the from_yaml function
    '''
    import os
    import sys

    # Mutates ``sys.path``, so create a copy to restore later.
    restored_sys_path = sys.path[:]

# Generated at 2022-06-11 09:06:52.770625
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import json
    import sys

    # Setup our test data
    data = u"{'foo': 'bar'}"
    json_data = json.loads(data)

    # Get our vault passwords
    vault_password = u'secret'
    vault_secrets = [u'secret']

    # Encrypt our data
    data = AnsibleVaultEncryptedUnicode.load(data, vault_password, keep_newline=True)
    print('Vault data: %s' % data)

    # Encrypt our JSON data
    json_data = AnsibleVaultEnc

# Generated at 2022-06-11 09:07:01.278254
# Unit test for function from_yaml
def test_from_yaml():
    # test valid json
    json_str = '{"a": "b"}'
    assert from_yaml(json_str) == json.loads(json_str)

    # test invalid json, valid yaml
    yaml_str = 'a: 1'
    assert from_yaml(yaml_str) == {"a": 1}

    # test string without json or yaml (gives SyntaxError)
    bad_str = 'a|b|c'
    try:
        from_yaml(bad_str)
        assert False
    except AnsibleParserError as e:
        assert True

    # test string with json syntax error but valid yaml (gives YAMLError)
    bad_json_yaml_str = '{"a": 1'

# Generated at 2022-06-11 09:07:11.930033
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Helper function to unit test the from_yaml function.
    '''
    my_junk = '''
    {
        "a": [
            {
                "b": [
                    { },
                    {
                        "c": "value1"
                    },
                    {
                        "d": "value2"
                    }
                ]
            }
        ]
    }
    '''
    try:
        print(json.dumps(from_yaml(my_junk), sort_keys=True, indent=4))
    except AnsibleParserError as e:
        print('Error %s' % to_native(e))

# Generated at 2022-06-11 09:07:22.750408
# Unit test for function from_yaml
def test_from_yaml():

    """
    Test the from_yaml function for json and yaml data.
    """

    json_data = "{\"a\": 1, \"test\": [1, 2, 3]}"
    assert from_yaml(json_data, json_only=True) == {u"a": 1, u"test": [1, 2, 3]}

    yaml_data = "{a: foo} bar\n"
    assert from_yaml(yaml_data, json_only=True) == {u"a": u"foo"}

    # Test file names, error messages and exception raising.
    # Exception raised directly, so assertRaises here doesn't work
    # and the exception is caught in the test.

# Generated at 2022-06-11 09:07:31.811567
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '{"a": 1, "b": 2}'
    assert isinstance(from_yaml(test_data), dict)

    test_data = '---\n- name: test\n  state: present\n'
    assert isinstance(from_yaml(test_data), list)

    try:
        test_data = 'name: test\n  state: present\n'
        from_yaml(test_data)
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML" in to_native(e)

# Generated at 2022-06-11 09:07:34.686794
# Unit test for function from_yaml
def test_from_yaml():
    print(from_yaml("""{
        "name": "{{ inventory_hostname_short }}",
        "gather_facts": "false"
    }"""))

# Generated at 2022-06-11 09:07:47.239388
# Unit test for function from_yaml
def test_from_yaml():
    '''
    This test makes sure that when the data cannot
    be parsed by json.loads, we try to parse it with yaml.
    '''
    import textwrap
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleSequence

    data = textwrap.dedent('''
    - hosts:
        - 192.168.0.1
    roles:
        - ssh
    ''')

    data = to_bytes(data)
    parsed = from_yaml(data)
    assert (isinstance(parsed, dict))
    assert (len(parsed) == 2)
    assert (isinstance(parsed['roles'], list))
    assert (isinstance(parsed['roles'], AnsibleSequence))

# Generated at 2022-06-11 09:07:50.876531
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence

    def my_safe_load(stream, file_name='<string>', vault_secrets=None):
        loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
        try:
            ds = loader.get_single_data()
        finally:
            loader.dispose()
        return ds

    assert from_yaml('{"a": 1}') == {"a": 1}

    assert my_safe_load('{"a": 1}') == {"a": 1}
    assert my_safe_load('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-11 09:08:00.504561
# Unit test for function from_yaml
def test_from_yaml():
    ansible_data = '---\n- hosts: localhost\n  connection: local'
    ansible_data2 = '---\n- hosts: localhost\n  connection: local\n  tasks:\n - test'
    yaml_data = 'ping: pong'
    json_data = '{"ping": "pong"}'
    json_data2 = '{"ping": "pong", "foo": "bar"}'
    json_data3 = '{"ping": {"foo": "bar"}}'
    # Test for Ansible Playbook
    assert from_yaml(ansible_data) == [{'hosts': 'localhost', 'connection': 'local'}]

# Generated at 2022-06-11 09:08:05.780085
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''
    foo_bar:
     - baz:
        qux:
         - zebra
         - zzyzx
         - zzz
        zzzz:
         - zzzz
    '''
    from_yaml(test_data)
    from_yaml(test_data, json_only=True)


# Generated at 2022-06-11 09:08:14.677626
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '''
    ---
    {
        "pluto": "pippo"
    }
    '''
    assert from_yaml(test_data) == {'pluto': 'pippo'}
    assert from_yaml(test_data, json_only=True) == {'pluto': 'pippo'}
    assert from_yaml('foo') is None
    assert from_yaml('') is None
    assert from_yaml(None) is None
    assert from_yaml('[0,1,2,3,4]') == [0,1,2,3,4]

# Generated at 2022-06-11 09:08:24.415372
# Unit test for function from_yaml
def test_from_yaml():
    '''Unit tests for method from_yaml'''

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # Test 1 - basic valid JSON
    test__from_yaml_1 = from_yaml("{\"key\":\"value\"}")
    assert isinstance(test__from_yaml_1, AnsibleMapping)
    assert len(test__from_yaml_1.keys()) == 1
    assert list(test__from_yaml_1.keys())[0] == 'key'
    assert isinstance(test__from_yaml_1['key'], AnsibleMapping)
    assert test__from_yaml_1['key'] == 'value'

    # Test 2 - basic valid YAML
    test__from_yaml_2 = from_yaml

# Generated at 2022-06-11 09:08:30.076550
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    somevar:
      - bar
      - baz
    """
    yaml_dict = from_yaml(data)
    test_dict = {'somevar': ['bar', 'baz']}
    assert dict(yaml_dict) == dict(test_dict)

# Generated at 2022-06-11 09:08:38.357282
# Unit test for function from_yaml
def test_from_yaml():
    # Create Yaml
    data = {
        "foo": True,
        "bar": 42,
        "baz": [1, 2, 3],
        "qux": 2.0,
        "some_string_key": "some_string_value",
        "some_list_key": ["some_list_value_1", "some_list_value_2"],
        "some_tuple_key": ("some_tuple_value_1", "some_tuple_value_2"),
        "some_dict_key": {
            "some_dict_key": "some_dict_value",
            "some_dict_list_key": ["some_dict_list_value_1", "some_dict_list_value_2"]
        }
    }
    # Text representation of the created yaml
    data_

# Generated at 2022-06-11 09:08:57.723007
# Unit test for function from_yaml
def test_from_yaml():
    """Some unit tests for the from_yaml function.
    """

    data = """
    ---
    - name: "somehost"
      somefact: something
      some: "{{ var }}"
      someint: 12
      somebool: false
      somelist:
        - 1
        - 2
        - 3
    """
    result = from_yaml(data)
    assert result == [{u'name': u'somehost', u'somefact': u'something',
                       u'some': u'{{ var }}', u'someint': 12, u'somebool': False,
                       u'somelist': [1, 2, 3]}], \
        "Failed to parse the correct yaml data: %s" % result


# Generated at 2022-06-11 09:09:07.394705
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import StringIO

    data_yaml = u'---\n' \
        u'test1: true\n' \
        u'test2: false\n' \
        u'test3: 123\n' \
        u'test4: abc\n'
    data_json = u'{"test1": true, "test2": false, "test3": 123, "test4": "abc"}'

    assert from_yaml(data_json) == from_yaml(data_yaml)
    assert from_yaml(data_json) == {u'test1': True, u'test2': False, u'test3': 123, u'test4': u'abc'}

    stream_yaml = StringIO(data_yaml)
    stream_json = String

# Generated at 2022-06-11 09:09:19.301343
# Unit test for function from_yaml
def test_from_yaml():
    from os.path import join, dirname
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import StringIO

    output = StringIO()
    basic._ANSIBLE_ARGS = basic.AnsibleOptions(connection='local', module_path=None, forks=10, become=None,
                                               become_method=None, become_user=None, check=False, diff=False,
                                               syntax=None,
                                               start_at_task=None)
    am = basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    yaml_file = join(dirname(__file__), 'test_data.yaml')

# Generated at 2022-06-11 09:09:28.036495
# Unit test for function from_yaml
def test_from_yaml():
    # Test valid YAML
    assert from_yaml("'foo'") == 'foo'
    assert from_yaml("foo: bar") == {'foo': 'bar'}
    assert from_yaml("key: [val1, val2]") == {'key': ['val1', 'val2']}
    assert from_yaml("key: {sub1: val1, sub2: val2}") == {'key': {'sub1': 'val1', 'sub2': 'val2'}}
    assert from_yaml("- foo") == ['foo']
    assert from_yaml('{}') == {}

    # Test valid JSON
    assert from_yaml('"foo"') == "foo"
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
   

# Generated at 2022-06-11 09:09:38.355284
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") is None
    assert from_yaml("[1,2,3,4]") is None
    assert from_yaml("[]") == []
    assert from_yaml("[1,2,3,4]") == [1,2,3,4]
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}
    assert from_yaml("{'foo': False}", json_only=True) == {'foo': False}
    assert from_yaml("{'foo': 'bar'}", json_only=True) is None

    assert from_yaml("") == None
    assert from_yaml("    ") == None
    assert from_yaml("  'foo'  ") == None


# Generated at 2022-06-11 09:09:46.364380
# Unit test for function from_yaml
def test_from_yaml():
    # template file content
    sample_json_data = '''
            {
                "sum": "{{ 1 + 2 }}",
                "sub": "{{ 10 - 2 }}",
                "mul": "{{ 2 * 5 }}",
                "div": "{{ 10 / 2 }}",
                "dict": {
                    "a": "{{ 3 }}",
                    "b": "{{ 'test' }}",
                    "c": "{{ 'test' | upper }}",
                    "d": "{{ 'test' | upper | lower }}",
                    "e": "{{ 'test' | upper | lower | upper }}",
                    "f": "{{ 'test' | upper | default('default') }}",
                }
            }
        '''

# Generated at 2022-06-11 09:09:57.946972
# Unit test for function from_yaml
def test_from_yaml():
    ''' test from_yaml '''
    from_yaml_test = from_yaml
    assert from_yaml_test('{"x":"y"}') == {"x":"y"}
    assert from_yaml_test('{"x":3}') == {"x":3}
    assert from_yaml_test('{"x":["red","green","blue"]}') == {"x":["red","green","blue"]}
    assert from_yaml_test('{"x":{"y":"z"}}') == {"x":{"y":"z"}}

    assert from_yaml_test('x: y') == {"x":"y"}
    assert from_yaml_test('x: 3') == {"x":3}
    assert from_yaml_test('x: [red,green,blue]') == {"x":["red","green","blue"]}


# Generated at 2022-06-11 09:10:06.086856
# Unit test for function from_yaml
def test_from_yaml():
    line1 = '{\n'
    line2 = '    "test_dict": {\n'
    line3 = '        "key1": "value1"\n'
    line4 = '    },\n'
    line5 = '    "test_list": [\n'
    line6 = '        "value1",\n'
    line7 = '        "value2"\n'
    line8 = '    ],\n'
    line9 = '    "test_string": "value3"\n'
    line10 = '}'

    data = line1 + line2 + line3 + line4 + line5 + line6 + line7 + line8 + line9 + line10

    new_data = from_yaml(data)

    # Expected datastructure in new_data
    # {
    #

# Generated at 2022-06-11 09:10:15.795883
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml import objects

    test_content = '''
    ---
    # Test file
    name: steve
    '''

    def foo(s):
        b = s.encode('utf-8') if PY3 else s
        return b

    results = from_yaml(foo(test_content), file_name='test_from_yaml')

    assert results[0] == 'name'
    assert results[1] == 'steve'

    # Create a YAML Object
    assert isinstance(objects.AnsibleMapping(results), objects.AnsibleBaseYAMLObject)



# Generated at 2022-06-11 09:10:26.621464
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    # Test that from_yaml can parse data which can be loaded as json or yaml
    # and return the same datastructure.
    #
    # We test this by loading the datastructure in json and yaml, and comparing
    # the dumped result of each (as JSON) against each other.
    def test(data):
        compared = json.loads(from_yaml(json.dumps(data), json_only=True))
        dumped = json.dumps(from_yaml(json.dumps(data), json_only=False), cls=AnsibleJSONDecoder)

# Generated at 2022-06-11 09:10:52.991332
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ 'test': 'value' }") == {"test": "value"}
    assert from_yaml("test: value") == {"test": "value"}
    try:
        from_yaml("test: value", json_only=True)
        assert False
    except AnsibleParserError:
        pass
    try:
        from_yaml("{ 'test': 'value' }", json_only=True)
        assert True
    except AnsibleParserError:
        assert False
    try:
        from_yaml("{ 'test': 'value", show_content=False)
        assert False
    except AnsibleParserError:
        pass
    try:
        from_yaml("{ 'test': 'value", show_content=True)
        assert False
    except AnsibleParserError:
        pass


# Generated at 2022-06-11 09:10:58.733608
# Unit test for function from_yaml
def test_from_yaml():
    data = "{'name': 'test', 'age': 10}"
    file_name = '<string>'
    show_content = True
    vault_secrets = None
    json_only = False

    new_data = from_yaml(data, file_name, show_content, vault_secrets, json_only)
    assert isinstance(new_data, dict)

# Generated at 2022-06-11 09:11:07.139705
# Unit test for function from_yaml
def test_from_yaml():
    # Test 1 - Invalid YAML
    try:
        from_yaml("""
        ---
        - one
          two
        - three
          four
        """, 'test_from_yaml_file.yaml')
    except AnsibleParserError as exc:
        assert exc.obj.ansible_pos == ('test_from_yaml_file.yaml', 3, 2)
        # No more assertions because the traceback is specific to the python
        # version and may change in the future.
        return

    # We should never reach this line
    raise AssertionError("The AnsibleParserError exception was not raised.")

# Generated at 2022-06-11 09:11:17.112240
# Unit test for function from_yaml
def test_from_yaml():
    
    from ansible.parsing.dataloader import DataLoader

    # Check loaded as JSON
    data_as_json = '{"key1": "value1"}'
    data_yaml = from_yaml(data_as_json)
    assert data_yaml == {"key1": "value1"}

    # Check loaded as YAML
    data_as_yaml = "- key1\n- key2\n"
    data_yaml = from_yaml(data_as_yaml)
    assert data_yaml == ["key1", "key2"] 

    # Check problem mark error
    data_as_yaml_with_error = "key1: value1\nkey2:\n- val1\n- val2"

# Generated at 2022-06-11 09:11:19.562290
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'a': 'b'}") == {'a': 'b'}
    assert from_yaml("{bad}") == {'b': 'a', 'd': ''}

# Generated at 2022-06-11 09:11:29.580642
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    if sys.version_info[0] > 2:
        builtin_module = 'builtins'
    else:
        builtin_module = '__builtin__'

    exec('from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes')
    exec('from {0} import unicode'.format(builtin_module))

    f = open('/tmp/test.yaml', 'w')
    f.write('''
#!/bin/bash
---
- hosts: all
  tasks:
    - debug: var=hostvars''')
    f.close()
    ansible_playbook_file = '/tmp/test.yaml'

    with open(ansible_playbook_file, 'r') as playbook:
        playbook_content = playbook.read()


# Generated at 2022-06-11 09:11:34.085344
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'test': 'string'}") == {'test': 'string'}
    assert from_yaml("test: string") == {'test': 'string'}
    assert from_yaml("test: {subtest: 'string'}") == {'test': {'subtest': 'string'}}



# Generated at 2022-06-11 09:11:40.777465
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = '''
        first_here:
            - a
            - b
        second_here:
            third_inside:
                - c
                - d
            fourth_inside:
                fifth_inside:
                    - e
                    - f
    '''
    yaml_data = from_yaml(test_yaml)
    assert yaml_data.get('first_here')[0] == 'a'
    assert yaml_data.get('second_here').get('fourth_inside').get('fifth_inside')[0] == 'e'

# Generated at 2022-06-11 09:11:48.311713
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # create a test Yaml file
    in_data = dict(
        thisismylongkey = dict(
            k1 = 'some string',
            k2 = 1234,
            k3 = ['a', 'list', 'of', 'strings'],
            k4 = dict(
                nested = 'dictionary'
            ),
            k5 = 'with trailing newline\n',
        ),
    )
    in_yaml = to_bytes(AnsibleDumper(in_data).get_single_data())

    print(in_yaml)
    out_data = from_yaml(in_yaml)

    assert(in_data == out_data)

# Generated at 2022-06-11 09:11:58.843786
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vault_secrets_filepath = 'test/ansible/test_vault.txt'
    vault_secrets = VaultLib(['vault_pass'], loader=loader)
    vault_secrets._load_secrets(vault_secrets_filepath)

    # single string.
    test_data = 'string'
    test_data_actual = from_yaml(test_data, vault_secrets=vault_secrets)
    assert test_data_actual == test_data

    # int
    test_data = 4

# Generated at 2022-06-11 09:12:46.111877
# Unit test for function from_yaml
def test_from_yaml():
    '''
    This is a unit test for the from_yaml() function.
    '''

    # test json input
    json_in = '''
{
    "foo": {
        "bar": {
            "baz": "this is a utf-8 string \xe9\x9b\x86"
        }
    }
}
    '''
    json_out = from_yaml(json_in)
    assert(json_out['foo']['bar']['baz'] == u'this is a utf-8 string \xe9\x9b\x86')

    # test json input with unicode characters

# Generated at 2022-06-11 09:12:54.895058
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    # some of these test cases are from the PyYAML unit tests for safe_load

# Generated at 2022-06-11 09:13:05.339351
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    ---
    - name: test
      foo: bar
      bam:
        - one
        - two
        - three
    - name: test2
      foo: bar2
      bam:
        - one2
        - two2
        - three2
    """

    results = from_yaml(data)
    assert isinstance(results, list)
    assert isinstance(results[0], dict)
    assert isinstance(results[0]['bam'], list)
    assert results[0]['bam'][1] == 'two'
    assert isinstance(results[1], dict)
    assert isinstance(results[1]['bam'], list)
    assert results[1]['bam'][1] == 'two2'


# Generated at 2022-06-11 09:13:15.872190
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.errors.yaml_strings import YAML_SYNTAX_ERROR
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml

    # test simple yaml -> python
    test_yaml = u'foo: bar'
    test_python = {u'foo': u'bar'}
    test_python_roundtrip = u'foo: bar\n...\n'
    assert test_python == from_yaml(test_yaml), 'Basic test failed'
    assert test_yaml == to_yaml(test_python), 'Round-trip test failed'
    assert test_python

# Generated at 2022-06-11 09:13:26.017088
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.compat.tests.mock import patch
    from ansible.parsing.vault import VaultLib

    # NOTE: for the following unit test code, you can use the following code to create a real-life example of the
    # vault-encrypted YAML.

    # from ansible.parsing.vault import VaultEditor
    # from ansible.module_utils.six.moves import input
    # vault_password = input('vault password: ')
    # editor = VaultEditor(vault_password)
    # editor.dump(data)

    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-11 09:13:35.385755
# Unit test for function from_yaml
def test_from_yaml():
    print("\nUnit test for function from_yaml")
    from ansible.parsing.yaml.loader import AnsibleLoader
    # This is a YAML string.  Should load cleanly
    yaml_string = """
    - debug: msg="This is a YAML file"
      run_once: True
    """
    print("YAML String: %s" % yaml_string)
    print("\tParsing as YAML")
    ansible_data = from_yaml(data=yaml_string)
    print("\tResult: %s" % ansible_data)
    
    # This is an invalid YAML string.  Should raise error
    # (The trailing "," after line 2 is the problem)

# Generated at 2022-06-11 09:13:47.935349
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for function from_yaml

    Basic tests to cover the various situations that can arise, including
    the defaulting to YAML when neither JSON nor YAML
    are valid.
    '''

    # invalid JSON string
    test_data = '{"foo": bar}'
    try:
        new_data = from_yaml(test_data)
    except AnsibleParserError as ansible_exc:
        assert 'JSON' in to_native(ansible_exc)
        assert 'We were unable to read either as JSON nor YAML' in to_native(ansible_exc)

    # valid JSON string
    test_data = '{"foo": "bar"}'
    new_data = from_yaml(test_data)
    assert type(new_data) == dict
    assert new_data['foo']

# Generated at 2022-06-11 09:13:53.860519
# Unit test for function from_yaml
def test_from_yaml():
    print ("Testing from_yaml")
    test_dict = {'key1': 'value1', 'key2':'value2'}
    test_yaml = "key1: value1\nkey2: value2"

    data = from_yaml(test_yaml)
    if isinstance(data, dict):
        for key, value in data.items():
            print("%s = %s" % (key, value))
    else:
        print("data is not a dict")


# Generated at 2022-06-11 09:14:02.880388
# Unit test for function from_yaml
def test_from_yaml():
    '''test_from_yaml.py'''

    import textwrap
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from unit.utils.vault_helper import VaultHelper


# Generated at 2022-06-11 09:14:13.054122
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes
    assert from_yaml(to_bytes("{\"a\": 1}\n")) == {"a": 1}
    assert from_yaml(to_bytes("{'a': 1}\n")) == {"a": 1}
    assert from_yaml(to_bytes(b"{\"a\": 1}\n")) == {"a": 1}
    assert from_yaml(to_bytes(b"{'a': 1}\n")) == {"a": 1}
    assert from_yaml(to_bytes("a: 1\n")) == {"a": 1}
    assert from_yaml(to_bytes("a: 1\n")) == {"a": 1}
    assert from_yaml(to_bytes(b"a: 1\n")) == {"a": 1}