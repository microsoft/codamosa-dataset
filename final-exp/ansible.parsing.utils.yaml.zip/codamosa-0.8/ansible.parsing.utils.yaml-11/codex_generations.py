

# Generated at 2022-06-11 09:04:41.307814
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for the from_yaml() function
    '''

    # Attempt to load valid JSON
    valid_json = '{"key1": "value1", "key2": 2, "key3": ["item1", "item2"]}'
    try:
        new_data = from_yaml(valid_json)
    except:
        assert False, "Unexpected failure to load valid JSON"

    assert new_data['key1'] == "value1", "Unexpected value for key1 in valid JSON"
    assert new_data['key2'] == 2, "Unexpected value for key2 in valid JSON"
    assert new_data['key3'][0] == "item1", "Unexpected item for key3 in valid JSON"

# Generated at 2022-06-11 09:04:43.019439
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('---\n- name: Joe') == [{'name': 'Joe'}]

# Generated at 2022-06-11 09:04:54.740276
# Unit test for function from_yaml
def test_from_yaml():
    import unittest

    # This is the dictionary to test from_yaml
    yml_test_dict = {'key1': 'val1', 'key_arr': ['el1', 'el2'], 'key_dict': {'inner_key': 'inner_val'}}

    yml_test_str = """
    key_dict:
      inner_key: inner_val
    key_arr:
    - el1
    - el2
    key1: val1
    """

    # Testing a normal flow, when everything is fine
    test_dict = from_yaml(yml_test_str)
    assert test_dict == yml_test_dict

    # Testing the case when YAMLError is raised

# Generated at 2022-06-11 09:05:00.784608
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"name": "test"}') == {'name': 'test'}
    assert from_yaml('[1, 2]') == [1, 2]
    assert from_yaml('{"name": test}') == {'name': 'test'}
    assert from_yaml('"test"') == 'test'

# Generated at 2022-06-11 09:05:07.785165
# Unit test for function from_yaml
def test_from_yaml():
  assert from_yaml('{ "test": "yes" }') == { "test": "yes" }
  assert from_yaml('{ "test": "yes", "bar": [ "foo"] }') == { "test": "yes", "bar": [ "foo"] }
  assert from_yaml('[ "bar" ]') == [ "bar" ]

if __name__ == '__main__':
  test_from_yaml()

# Generated at 2022-06-11 09:05:14.679987
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') == None
    assert from_yaml('{}') == {}
    assert from_yaml('[]') == []
    assert from_yaml('42') == 42

    assert (from_yaml('foo: bar') ==
            {'foo': 'bar'})
    assert (from_yaml('foo: bar\n'
                      'baz: qux') ==
            {'foo': 'bar', 'baz': 'qux'})

    assert (from_yaml('foo: "bar \\"baz\\""') ==
            {'foo': 'bar "baz"'})

    assert (from_yaml('nix: [ ]') ==
            {'nix': []})

# Generated at 2022-06-11 09:05:19.936261
# Unit test for function from_yaml
def test_from_yaml():
    test_dict = {
            'a' : 'hello',
            'b' : 'goodbye'
    }

    data = json.dumps(test_dict)
    new_data = from_yaml(data, '<string>', show_content=True)
    print(new_data)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:05:31.542874
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO

    text1 = u"hello: world"
    text2 = u"hello: !!python/unicode 'world'"

    m1 = from_yaml(text1)
    assert isinstance(m1, AnsibleMapping)
    assert isinstance(m1.get('hello'), string_types)
    assert m1.get('hello') == u'world'

    m2 = from_yaml

# Generated at 2022-06-11 09:05:40.590351
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test from_yaml
    """
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret

    yaml_test_data = [
        ('''
        a: 1
        b: 2
        ''', {u'a': 1, u'b': 2}),
        ('''
        a: 1
        b: 2
        ''', {u'a': 1, u'b': 2}, False),
    ]


# Generated at 2022-06-11 09:05:51.800578
# Unit test for function from_yaml
def test_from_yaml():
    data = u"{\"a\": 1, \"b\": 2}"
    data1 = u"---\n\"a\": 1\n  \"b\": 2"
    assert data == json.dumps(from_yaml(data))
    assert data == json.dumps(from_yaml(data1))
    assert data == json.dumps(from_yaml(data1, json_only=True))
    data2 = u"---\n\"a\": 1\n  \"b\": 2"
    assert json.loads(data2) == from_yaml(data1, json_only=False)
    data3 = u"\"a\": 1\n  \"b\": 2"
    try:
        from_yaml(data3, json_only=True)
        assert False
    except AnsibleParserError:
        pass


# Generated at 2022-06-11 09:06:01.876563
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('{ "key1": [ "value1", "value2" ] }')
    assert isinstance(result, dict)
    assert isinstance(result["key1"], list)
    assert result["key1"][0] == "value1"
    assert result["key1"][1] == "value2"
    result2 = from_yaml('{ "key2": "value3" }', json_only=True)
    assert isinstance(result2, dict)
    assert result2["key2"] == "value3"
    try:
        from_yaml('{ "key2: "value3" }', json_only=True)
    except AnsibleParserError as e:
        assert isinstance(e.orig_exc, ValueError)

# Generated at 2022-06-11 09:06:04.706791
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(":a: 1\n:b: 2") == {':a':1, ':b':2}

# Generated at 2022-06-11 09:06:16.972763
# Unit test for function from_yaml
def test_from_yaml():

    import ansible.module_utils.basic
    # test if from_yaml correctly parses YAML values

# Generated at 2022-06-11 09:06:22.696420
# Unit test for function from_yaml
def test_from_yaml():
    '''
    A simple test to ensure we can parse either JSON or YAML, and get the same data structure
    back.
    '''
    data_structure = {
        "actions": [
            { "test": 5 },
        ],
        "test2": "hello"
    }

    data_json = json.dumps(data_structure)
    new_data_json = from_yaml(data_json)
    assert data_structure == new_data_json

    # TODO: more complex test cases?

# Generated at 2022-06-11 09:06:33.887825
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

    x = '{"a": 1, "b": [1, 2, 3]}'
    assert from_yaml(x) == {"a": 1, "b": [1, 2, 3]}

    x = '{a: 1, b: [1, 2, 3]}'
    assert from_yaml(x) == {"a": 1, "b": [1, 2, 3]}

    x = '{a: 1, b: [1, 2, 3]}'
    assert from_yaml(x, json_only=True) == {"a": 1, "b": [1, 2, 3]}

    x = '{a: 1, b: [1, 2, 3]}'

# Generated at 2022-06-11 09:06:44.537164
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    import os
    data = '''{% raw %}
---
- hosts: localhost
  tasks:
  - debug:
      msg: "{{ item }}"
    with_items:
     - "{{ test | string }}"
     - foo
{% endraw %}
'''
    dl = DataLoader()
    ret = dl.load_from_file('/tmp/test.yml', is_playbook=True)
    fd = open('/tmp/test.yml', 'w')
    fd.write(data)
    fd.close()

# Generated at 2022-06-11 09:06:51.762646
# Unit test for function from_yaml
def test_from_yaml():
    data1 = '{ "a": "b" }'
    data2 = "{ 'a': 'b' }"
    data3 = '{ a: b }'
    data4 = '''{ "a": "b" }

{ 'a': 'b' }

{ a: b }'''
    data5 = '''
- { "a": "b" }
- { 'a': 'b' }
- { a: b }'''
    data6 = False

    assert isinstance(from_yaml(data1), dict)
    assert isinstance(from_yaml(data2), dict)
    assert isinstance(from_yaml(data3), dict)
    assert isinstance(from_yaml(data4), list)
    assert isinstance(from_yaml(data5), list)

# Generated at 2022-06-11 09:06:57.119278
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
    {
        "foo": "bar",
        "baz": [
            1,
            2,
            3
        ]
    }
    """
    _test = from_yaml(test_data, show_content=False)
    print(_test)
    assert _test == json.loads(test_data)

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:06:58.323841
# Unit test for function from_yaml
def test_from_yaml():
    # TODO: Create tests
    pass


# Generated at 2022-06-11 09:07:07.328147
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader

    test_1 = """
    key:
      - 1
      - 2
      - 3
      - 4
      - 5
      - 6
      - 7
      - 8
      - 9
      - 10
      - 11
      - 12
    list:
      - alpha
      - beta
      - gamma
      - delta
      - epsilon
    """

    expected_1 = {'key': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 'list': ['alpha', 'beta', 'gamma', 'delta', 'epsilon']}
    data1 = DataLoader()

    output_1 = data1.load(test_1)
    #assert expected_1 == output_1

    test

# Generated at 2022-06-11 09:07:20.285416
# Unit test for function from_yaml
def test_from_yaml():
    # JSON
    data = "{'a': 'hello'}"
    try:
        new_data = from_yaml(data)
    except AnsibleParserError as e:
        pass
    assert new_data == {'a': 'hello'}

    # YAML
    data = "- {a: hello}"
    new_data = from_yaml(data)
    assert new_data == [{'a': 'hello'}]

    # Syntax Error
    data = '- a: hello'

# Generated at 2022-06-11 09:07:26.381673
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') == None
    assert from_yaml('{}') == {}
    assert from_yaml('{"a": 1}') == {"a": 1}

    # Note that the next two tests pass if run from the command line
    # but fail in the unit tests.  Looking further into this.
    #assert from_yaml('a: 1') == {"a": 1}
    #assert from_yaml('{"a": 1}') == {"a": 1}

# Generated at 2022-06-11 09:07:28.853074
# Unit test for function from_yaml
def test_from_yaml():
    test_content = '{"foo": "bar"}'
    #Test 1: Should just return the same content when we set the json_only to True
    assert from_yaml(test_content, json_only=True) == '{"foo": "bar"}'
    #Test 2: Should return the json decoded content when we set the json_only to False
    assert from_yaml(test_content, json_only=False) == {'foo': 'bar'}


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:07:40.693279
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.vars.manager import VariableManager
    from ansible.vars.vault_lookup import VaultLookupError
    from ansible.vars.vault_manager import VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    secret = VaultSecret(b'test_secret')

# Generated at 2022-06-11 09:07:50.786732
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    class MockVaultSecret:
        secret = 'foo'
        id = 'bar'


# Generated at 2022-06-11 09:07:51.327249
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-11 09:08:01.005973
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test for function from_yaml
    '''

    import mock

    # No exception should occur
    mock_file_name = mock.Mock()
    mock_data = mock.Mock()
    mock_vault_secrets = mock.Mock()
    mock_show_content = mock.Mock()


# Generated at 2022-06-11 09:08:12.886997
# Unit test for function from_yaml
def test_from_yaml():
    import types
    # Test input:
    test_str = '''
    ---
    # An empty list
    -
    # A list of numbers
    - 1
    - 2
    - 3
    '''
    # Expected output:
    test_list = [None, 1, 2, 3]
    assert test_list == from_yaml(test_str)
    # Test input:
    test_str = '''
    ---
    # An empty dictionary
    {}
    # A dictionary with keys and values
    test_key: test_value
    '''
    # Expected output:
    test_dict = [{}, {u'test_key': u'test_value'}]
    assert test_dict == from_yaml(test_str)

    # Test input:

# Generated at 2022-06-11 09:08:19.994840
# Unit test for function from_yaml
def test_from_yaml():
    import pytest

    yaml_data = """
---
simple: no
list:
 - item1
 - item2
...
"""
    assert from_yaml(yaml_data) == {'simple': 'no', 'list': ['item1', 'item2']}

    # NOTE: from_yaml should be able to handle a YAML stream with multiple documents, but
    #       using this raises an UnsafeLoaderWarning as it is not safe to use a YAML
    #       stream with multiple documents without a default_flow_style.
    with pytest.raises(YAMLError):
        from_yaml('---\nhello: world\n...\n---\nhello: world\n')



# Generated at 2022-06-11 09:08:31.994186
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Make sure the from_yaml function doesn't raise any relevant errors
    '''

    # test json
    data_json = '{"key": "value"}'
    data = from_yaml(data_json, file_name="<json>")
    assert isinstance(data, dict)

    # test yaml
    data_yaml = 'key: value'
    data = from_yaml(data_yaml, file_name="<yaml>")
    assert isinstance(data, dict)

    # test yaml
    data_list = '- item_1\n- item_2'
    data = from_yaml(data_list, file_name="<yaml>")
    assert isinstance(data, list)

    # make sure that we're allowing json strings in yaml
    data_both

# Generated at 2022-06-11 09:08:39.266796
# Unit test for function from_yaml
def test_from_yaml():
    test_data = '{"a": "b"}'
    assert from_yaml(test_data) == {"a": "b"}
    assert from_yaml(test_data, json_only=True) == {"a": "b"}

# Generated at 2022-06-11 09:08:52.726285
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('[1, 2, 3]', json_only=True) == [1, 2, 3]
    assert from_yaml('{}') == {}
    assert from_yaml('{}', json_only=True) == {}
    assert from_yaml('foo') == 'foo'
    assert from_yaml('foo', json_only=True) == 'foo'
    assert from_yaml('true') == True
    assert from_yaml('true', json_only=True) == True
    assert from_yaml('true', json_only=True, vault_secrets=[]) == True
    assert from_yaml('true', vault_secrets=[]) == True

# Generated at 2022-06-11 09:08:58.036508
# Unit test for function from_yaml
def test_from_yaml():
    assert(from_yaml('[1,2,3]') == [1,2,3])
    assert(from_yaml('{ "a": 1 }') == { "a": 1 })
    assert(from_yaml('{"a": 1, "b": 2}') == {"a": 1, "b": 2})
    assert(from_yaml('{"a": 1, "b": 2,}') == {"a": 1, "b": 2})

# Generated at 2022-06-11 09:09:04.496911
# Unit test for function from_yaml
def test_from_yaml():
    try:
        import yaml
    except ImportError:
        print("SKIP: yaml is unavailable")
        sys.exit(0)

    yaml_string = "{a: 1}"
    yaml_result = {'a': 1}
    assert isinstance(yaml.safe_load(yaml_string), dict)
    assert yaml.safe_load(yaml_string) == yaml_result

if __name__ == '__main__':
    import sys

    test_from_yaml()

# Generated at 2022-06-11 09:09:16.148589
# Unit test for function from_yaml
def test_from_yaml():
    # Basic
    assert from_yaml('{a: b}') == {'a': 'b'}

    # Invalid YAML
    try:
        from_yaml('][')
        assert False
    except AnsibleParserError:
        pass
    try:
        from_yaml('{')
        assert False
    except AnsibleParserError:
        pass
    try:
        from_yaml('}')
        assert False
    except AnsibleParserError:
        pass
    try:
        from_yaml('a: b')
        assert False
    except AnsibleParserError:
        pass
    try:
        from_yaml('')
        assert False
    except AnsibleParserError:
        pass

    # Invalid JSON

# Generated at 2022-06-11 09:09:25.003823
# Unit test for function from_yaml
def test_from_yaml():
    assert 'foo' == from_yaml('foo')
    assert 'foo' == from_yaml('foo\n')
    assert 'foo' == from_yaml('"foo"')
    assert True == from_yaml('true')
    assert False == from_yaml('false')
    assert [1, True, 'foo'] == from_yaml('[1, true, "foo"]')
    assert [1, True, 'foo'] == from_yaml('\n- 1\n- true\n- "foo"\n')
    assert [1, True, {'foo': 'bar'}, 'foo'] == from_yaml('[1, true, {"foo": "bar"}, "foo"]')

# Generated at 2022-06-11 09:09:35.242831
# Unit test for function from_yaml
def test_from_yaml():

    # Test with valid yaml
    yaml_data = {"a": { "b": ["c", "d"]}}
    new_data = from_yaml(yaml_data)
    assert new_data == {"a": { "b": ["c", "d"]}}

    # Test with non-valid yaml
    yaml_data = "a:\n b:c"
    try:
        new_data = from_yaml(yaml_data)
        assert False
    except AnsibleParserError as e:
        assert "YAML syntax error" in str(e)

    # Test with valid json
    json_data = '{"a": {"b": ["c", "d"]}}'
    new_data = from_yaml(json_data)

# Generated at 2022-06-11 09:09:44.314823
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test from_yaml with some data from a real playbook.
    """
    data = """
tasks:
 - set_fact:
     ansible_python_interpreter: /usr/bin/python3
 - name: Test the last time the package was updated.
     shell: echo "{{ ansible_python_interpreter }}"
     register: shell_out
     changed_when: "'lib' in shell_out.stdout"
"""


# Generated at 2022-06-11 09:09:52.653518
# Unit test for function from_yaml
def test_from_yaml():
    test1 = '{"a": 1, "b": 2, "c": 3}'
    assert from_yaml(test1) == json.loads(test1)

    test2 = '\n'.join([
        '---',
        '- a: 1',
        '  b: 2',
        '  c: 3'
    ])
    assert from_yaml(test2) == [{
        'a': 1,
        'b': 2,
        'c': 3
    }]

    try:
        from_yaml('{a: 1, b: 2, c: 3}')
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 09:10:03.008806
# Unit test for function from_yaml
def test_from_yaml():
    # AnsibleJSONDecoder.set_secrets(vault_secrets)
    print("vault_secrets: ")
    print(vault_secrets)
    # print("Id: ")
    # print(id(vault_secrets))

    # we first try to load this data as JSON.
    # Fixes issues with extra vars json strings not being parsed correctly by the yaml parser
    data = """
    {
        "my_var": 123,
        "my_list": [1, 2, 3],
        "my_dict": {
            "name": "Joe"
        }
    }
    """

    new_data = from_yaml(data, show_content=False)
    print("new_data: ")
    print(new_data)
    # print("Id: ")


# Generated at 2022-06-11 09:10:23.548454
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test function to test function from_yaml
    '''

    import unittest

    # Invalid JSON string
    sample_inv_json = "{{ foo : bar }}"
    # Valid JSON string
    sample_v_json   = "{\"foo\" : \"bar\"}"
    # Valid YAML string
    sample_v_yaml   = "---\nfoo: bar\n"

    # Create a TestCase instance
    test_case = unittest.TestCase(methodName='assertTrue')

    # Test that a JSON string raises an exception
    test_case.assertRaises(json.JSONDecodeError, from_yaml, sample_inv_json)
    # Test that a valid JSON string does dict conversion

# Generated at 2022-06-11 09:10:24.925257
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}

# Generated at 2022-06-11 09:10:29.303676
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}
    assert from_yaml("""
---
test:
  foo: bar""") == {'test': {"foo": "bar"}}
    assert from_yaml("""
---
test:
  foo: bar
      """) == {'test': {"foo": "bar"}}

# Generated at 2022-06-11 09:10:42.566671
# Unit test for function from_yaml
def test_from_yaml():
    from ansible import context
    data = ""
    assert(from_yaml(data) == None)
    data = "{\"test\": \"value\"}"
    assert(from_yaml(data) == {u'test': u'value'})
    data = "{\"test\": \"value\"}"
    assert(from_yaml(data, json_only=True) == {u'test': u'value'})
    data = "{"
    try:
        from_yaml(data, json_only=True)
        assert(False)
    except AnsibleParserError:
        pass
    data = "{\"test\": \"value\"}"
    assert(from_yaml(data, vault_secrets="dummy") == {u'test': u'value'})
    data = "{\"test\": \"value\"}"

# Generated at 2022-06-11 09:10:51.866211
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    {
        "foo": [1, {"bar": 2}, 3],
        "baz": {
            "qux": "quux",
            "quux": ["quuxquux", "quuxquuxquux"]
        }
    }'''

    assert from_yaml(data) == {
        'foo': [1, {"bar": 2}, 3],
        'baz': {
            "qux": "quux",
            "quux": ["quuxquux", "quuxquuxquux"]
        }
    }


# Generated at 2022-06-11 09:11:02.545003
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    # Ensure 'unicode' type is handled as expected
    # - see https://github.com/ansible/ansible/issues/33467
    class TestAnsibleBaseYAMLObject(AnsibleBaseYAMLObject):
        def __init__(self, data):
            self.data = data

    # Ensure the AnsibleParserError contains the expected text
    class TestYAMLError(YAMLError):
        def __init__(self, value):
            self.problem = value

    class TestAnsibleParserError(AnsibleParserError):
        def __init__(self, value):
            self.message = value

    # Test loading valid JSON

# Generated at 2022-06-11 09:11:07.785812
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("[{'b':1},{'a':1}]") == [{'b': 1}, {'a': 1}]
    assert from_yaml("[{'b':1},{'a':1}]", json_only=True) == [{'b': 1}, {'a': 1}]

# Generated at 2022-06-11 09:11:08.410235
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-11 09:11:18.251759
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    data = "hi: there"
    assert from_yaml(data) == {'hi': 'there'}
    data = "{'hi': 'there'}"
    pytest.raises(AnsibleParserError, from_yaml, data)
    data = "{hi: there}"
    pytest.raises(AnsibleParserError, from_yaml, data)

    # This is a data structure which is valid yaml but not valid json
    data = "{foo: !!python/object/apply:int [u'7']}"
    # should pass for test_yaml
    assert from_yaml(data) == {'foo': 7}

    # This is a data structure valid in yaml
    data

# Generated at 2022-06-11 09:11:27.583499
# Unit test for function from_yaml
def test_from_yaml():
    # Tests that an AnsibleParserError exception is raised
    # when both yaml and json input are improperly structured
    # and that it contains the error message
    yaml_string = "{key: value: 2"  # should raise an error
    try:
        ansible_obj = from_yaml(yaml_string)
    except AnsibleParserError as err:
        assert err.message == u'We were unable to read either as JSON nor YAML, these are the errors we got from each:\n' \
                              u'JSON: Expecting property name enclosed in double quotes: line 1 column 2 (char 1)\n\n' \
                              u'AnsibleUndefinedVariable: ' in err.message
        return
    raise Exception("from_yaml failed test, no exception raised")


# Generated at 2022-06-11 09:11:42.116969
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Ensure that the same result is returned
    when loading an object with json.loads or from_yaml.
    '''
    data = '{"test": "this"}'
    data_dict = json.loads(data, cls=AnsibleJSONDecoder)
    yaml_dict = from_yaml(data)

    assert data_dict == yaml_dict

# Generated at 2022-06-11 09:11:45.940062
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('{"a": "A"}') == {"a": "A"}

    import pytest
    with pytest.raises(AnsibleParserError) as e_info:
        from_yaml('[1, 2, 3')
    assert e_info

# Generated at 2022-06-11 09:11:48.908983
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    assert from_yaml('{"a":{"b":"c"}}') == {"a":{"b":"c"}}

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:11:51.989211
# Unit test for function from_yaml
def test_from_yaml():
    """Unittest function for function from_yaml"""
    data = """
        - hosts: all
          gather_facts: False
          vars:
            ansible_python_interpreter: "/usr/bin/python"
    """
    assert data == str(from_yaml(data))

# Generated at 2022-06-11 09:12:04.181845
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.utils.yaml_loader import state_from_yaml
    from ansible.utils._text import to_native
    
    data_yaml = """
- hosts: localhos
  gather_facts: yes
  tasks:
  - debug: msg="This is the last task"
    ignore_errors: yes
- hosts: localhost
  tasks:
    - name: This task will fail 
      debug: msg="Failed task"
      failed_when: True
"""

# Generated at 2022-06-11 09:12:08.763434
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": 1, "bar": "baz" }') == {u'foo': 1, u'bar': u'baz'}
    assert from_yaml('foo: 1\nbar: 2') == {u'foo': 1, u'bar': 2}


# Generated at 2022-06-11 09:12:19.029459
# Unit test for function from_yaml
def test_from_yaml():
    data = "{\"a\": 1, \"b\": [{\"c\": 2}]}"
    json_test = "{\"a\": 1, \"b\": [{\"c\": 2}]}"
    yaml_test = """
        a: 1
        b:
          - c: 2
    """
    assert from_yaml(data) == from_yaml(json_test)
    assert from_yaml(yaml_test) == from_yaml(json_test)
    try:
        from_yaml("{'a': 1, 'b': {'c': 2}}")
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
    else:
        assert False

# Generated at 2022-06-11 09:12:29.500344
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar baz'}") == {'foo': 'bar baz'}
    assert from_yaml("{'foo': 'bar baz'}", json_only=True) == {u'foo': u'bar baz'}
    assert from_yaml("---\n  foo: bar baz", json_only=True) == "---\n  foo: bar baz"
    assert from_yaml("{'foo': 'bar baz'}", json_only=False) == {u'foo': u'bar baz'}
    assert from_yaml("---\n  foo: bar baz", json_only=False) == {u'foo': u'bar baz'}

# Generated at 2022-06-11 09:12:33.823069
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault
    yaml_data = """
    ---
    # this is a YAML file

    project:
    - name: ansible
    - url: https://github.com/ansible/ansible
    - lang: python

    project:
    - name: tower-cli
    - url: https://github.com/ansible/tower-cli
    - lang: python
    """

    new_data = from_yaml(yaml_data)
    assert new_data['project'][0]['name'] == 'ansible'
    assert new_data['project'][1]['name'] == 'tower-cli'


# Generated at 2022-06-11 09:12:36.432040
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a": {"b": [1, 2, 3]}}'
    new_data = from_yaml(data)
    assert new_data == json.loads(data)



# Generated at 2022-06-11 09:12:54.764236
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1, 2, 3]', file_name='<string>', show_content=True, vault_secrets=None) == [1, 2, 3]
    assert from_yaml('{"a": foobar}', file_name='<string>', show_content=True, vault_secrets=None) == {'a': 'foobar'}
    assert from_yaml('{"a": foobar,}', file_name='<string>', show_content=True, vault_secrets=None) == {'a': 'foobar'}
    assert from_yaml('{a: foobar}', file_name='<string>', show_content=True, vault_secrets=None) == {'a': 'foobar'}

# Generated at 2022-06-11 09:13:05.184592
# Unit test for function from_yaml
def test_from_yaml():

    # Arrange
    yaml_str = '''
    foo: &foo
      name: foo
      lst:
        - abc
        - def
        - ghi
    bar: *foo
    '''

    # Act
    data = from_yaml(yaml_str)

    # Assert
    assert isinstance(data, dict)
    assert isinstance(data['foo'], AnsibleBaseYAMLObject)
    assert isinstance(data['bar'], AnsibleBaseYAMLObject)
    assert data['foo']['name'] == 'foo'
    assert data['foo']['lst'] == ['abc', 'def', 'ghi']
    assert data['bar']['name'] == 'foo'

# Generated at 2022-06-11 09:13:12.395192
# Unit test for function from_yaml
def test_from_yaml():
    input_strings = [
        '{"foo": "bar"}',
        '["foo", "bar"]',
        '{"foo": 1, "bar": 2.50, "baz": true}',
        '"foo"',
        '33.33',
        'false',
        '{"foo": null}',
        '---',
    ]
    for input_string in input_strings:
        result = from_yaml(input_string, json_only=True)
        assert result == json.loads(input_string)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:13:23.631015
# Unit test for function from_yaml
def test_from_yaml():

    class MyClass(object):
        def __init__(self, foo, msg=None):
            self.foo = foo
            self.msg = msg

    class MyConfig(object):
        def __init__(self):
            self.test = u'foo'

        def __call__(self, *args, **kwargs):
            return MyClass(self.test, **kwargs)

    config = MyConfig()
    obj = from_yaml('test: foo', json_only=True, vault_secrets=['foo', 'bar'])

    assert isinstance(obj, dict)
    assert obj['test'] == 'foo'

    obj = from_yaml('{"test": "foo"}', json_only=True, vault_secrets=['foo', 'bar'])
    assert isinstance(obj, dict)

# Generated at 2022-06-11 09:13:32.924362
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert from_yaml("") == None
    assert from_yaml("{}") == {}
    assert from_yaml("[]") == []
    assert from_yaml("a: 1") == {"a": 1}
    assert from_yaml("[a]") == ["a"]
    assert from_yaml("a: 1\nb: 2") == {"a": 1, "b": 2}
    # from ansible-galaxy 2.5.0 names are dicts
    assert from_yaml("a: 1\nb: 2") == {"a": 1, "b": 2}

    assert from_yaml("- a\n- b") == ["a", "b"]


# Generated at 2022-06-11 09:13:39.742105
# Unit test for function from_yaml
def test_from_yaml():

    # Test success
    result = from_yaml('{"foo": "bar"}')
    assert result == {'foo': 'bar'}

    # Test failure
    try:
        assert not from_yaml('{"foo": "bar"')
    except AssertionError:
        pass
    # Test failure
    try:
        assert not from_yaml(u'\x00')
    except AssertionError:
        pass

# Generated at 2022-06-11 09:13:45.810774
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.ajson import AnsibleJSONDecoder
    data = "{\"test\":1}"
    file_name = "test"
    show_content = True
    decoder = AnsibleJSONDecoder
    new_data = from_yaml(data, file_name, show_content, decoder)
    assert new_data["test"] == 1

# Generated at 2022-06-11 09:13:55.153514
# Unit test for function from_yaml
def test_from_yaml():
    # create an empty file
    import tempfile
    (handle, path) = tempfile.mkstemp()

    # make sure empty file returns empty dict
    data = from_yaml('')
    assert data == {}

    # add some valid yaml to test file
    with open(path, 'w') as f:
        f.write('test: value')
    
    # make sure we got the data
    data = from_yaml(path)
    assert data == {'test': 'value'}

    # add an invalid yaml string to test file
    with open(path, 'w') as f:
        f.write('test: value\n : more value\n')

    # make sure we get an exception

# Generated at 2022-06-11 09:14:00.361152
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml('42') == 42

    assert from_yaml('42', json_only=True) == 42

    assert from_yaml('{"foo": "bar", "baz": 42}') == {"foo": "bar", "baz": 42}

    assert from_yaml('{"foo": "bar", "baz": 42}', json_only=True) == {"foo": "bar", "baz": 42}


# For backwards compatibility
from_json = from_yaml

# Generated at 2022-06-11 09:14:08.715942
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.basic import missing_required_lib

    if missing_required_lib('yaml', url='http://pyyaml.org/wiki/PyYAML'):
        pytest.skip("skipping due to missing yaml library")

    try:
        for test_val in [True, False, None, int, float, str, dict, list]:
            assert from_yaml(AnsibleDumper(default_flow_style=False).dump({'a': test_val}, default_flow_style=False))['a'] == test_val
    except ImportError:
        pytest.skip("skipping due to missing yaml library")