

# Generated at 2022-06-11 09:04:42.089729
# Unit test for function from_yaml
def test_from_yaml():
    # Sample JSON data
    json_data = \
    '''[
        {
                "id": "1234567890",
                "type": "test"
        }
    ]'''

    # Sample YAML data
    yaml_data = \
    '''
    - hosts: 127.0.0.1
      tasks:
      - name: testing
        debug:
            msg: "Hi"
    '''

    #Test JSON
    from_yaml(json_data)
    #Test YAML
    from_yaml(yaml_data)


# Generated at 2022-06-11 09:04:53.360293
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for function from_yaml '''
    # pylint: disable=protected-access

    # Note: _safe_load() is the public function in yaml.load(), so the
    # calls below are safe and will function as documented.
    # pylint: disable=protected-access
    # pylint: disable=no-member

    # Test whether the function can handle dictionaries, lists, tuples and integers
    data = '''
test_dict:
  - 1
  - 2
  - 3
'''
    assert type(from_yaml(data)) == dict
    assert type(from_yaml(data).get('test_dict')) == list
    assert from_yaml(data)['test_dict'][0] == 1

    # Test whether the function can handle floats and booleans
   

# Generated at 2022-06-11 09:05:06.735502
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    data = '''
- hosts: all
  tasks:
  - debug:
      msg: "hello, my name is {{ vault_person }}"
    vars_files:
      - vault.yml
'''

    # Test that vault_file is read as unicode
    vault_data = AnsibleVaultEncryptedUnicode('UNITTESTENCRYPTED')
    assert isinstance(vault_data, unicode)

    # Test that yaml loader returns unicode
    result = _safe_load(data)
    assert isinstance(result[0]['tasks'][0]['vars_files'][0], unicode)

    # Test that yaml loader resolves vault

# Generated at 2022-06-11 09:05:14.110568
# Unit test for function from_yaml
def test_from_yaml():
    test_data = """
---
simple:
  control:
    - "2"
  data:
    - "2"
    - []
  value: a simple test
top:
  data:
    - value: a simple test
      other:
        - "2"
        - []
      control:
        - "2"
    -
      other:
        - "2"
        - []
      value: another simple value
      control:
        - "2"
"""
    test_from_yaml = from_yaml(test_data, 'test_from_yaml')
    assert test_from_yaml
    assert test_from_yaml['simple']['control'] == ["2"]
    assert test_from_yaml['simple']['data'] == ["2", []]
    assert test_

# Generated at 2022-06-11 09:05:20.033923
# Unit test for function from_yaml
def test_from_yaml():
    json_str = '{"name": "ankit", "class": "xii", "marks": "76"}'
    json_data = json.loads(json_str, cls=AnsibleJSONDecoder)
    #print(json_data)
    #parsed_data_new = from_yaml(json_data)
    #print(parsed_data_new)

#test_from_yaml()

# Generated at 2022-06-11 09:05:31.598972
# Unit test for function from_yaml
def test_from_yaml():
    # Test if it raises error on invalid yaml
    invalid_yaml = "foo: bar"
    try:
        data = from_yaml(invalid_yaml)
        assert False
    except AnsibleParserError:
        assert True

    # Test if it raises error on invalid JSON
    invalid_json = "{foo: bar'}"
    try:
        data = from_yaml(invalid_json)
        assert False
    except AnsibleParserError:
        assert True

    # Test if it can parse valid yaml valid json
    valid_yaml = "foo: bar"
    valid_json = "{'foo':'bar'}"
    data = from_yaml(valid_yaml)
    assert data == {'foo': 'bar'}
    data = from_yaml(valid_json)

# Generated at 2022-06-11 09:05:40.709936
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{}") == {}
    assert from_yaml("[]") == []
    assert from_yaml("{\"red\": 2}") == {'red': 2}
    assert from_yaml("[1, 2, 3]") == [1, 2, 3]
    assert from_yaml("---\n- 1\n- 2\n- 3\n") == [1, 2, 3]

    # In case you want to test from_yaml with real files, use this function to
    # load the file data.
    def load_file(name):
        import io
        import os

        with io.open(os.path.join(os.path.dirname(__file__), 'data/pyyaml/' + name), encoding='UTF-8', errors='ignore') as f:
            return

# Generated at 2022-06-11 09:05:45.506524
# Unit test for function from_yaml
def test_from_yaml():
    # A simple test to make sure that from_yaml parses json correctly
    json_string = "{'a': 'b'}"
    data = from_yaml(json_string)
    assert isinstance(data, dict)
    assert data['a'] == 'b'

# Generated at 2022-06-11 09:05:55.850377
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test decrypting regular value

# Generated at 2022-06-11 09:05:58.480721
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "foo": "bar" }') == {u'foo': u'bar'}
    assert from_yaml('{ foo: bar }') == {u'foo': u'bar'}

# Generated at 2022-06-11 09:06:13.146772
# Unit test for function from_yaml
def test_from_yaml():
    from io import StringIO

    test_yaml_text = """
    - hosts: all
      tasks:
        - name: ping
          action: ping

    - hosts: all
      tasks:
        - name: ping again
          action: ping
    """
    try:
        data = from_yaml(test_yaml_text)
    except AnsibleParserError as e:
        print(e)
        assert False

    #
    # Test JSON parser
    #
    test_json_text = """
    {
      "hosts": "all",
      "tasks": [
        {
          "name": "test"
        }
      ]
    }
    """

# Generated at 2022-06-11 09:06:22.084772
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test the function from_yaml using the yaml_to_json and json_to_yaml functions.
    '''
    import re
    from ansible.module_utils.common.collections import is_iterable
    from ansible.parsing.ajson import simple_object_hook
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # The following test cases were taken from tests/unit/test_yaml.py in the yaml-test-suite.
    # https://bitbucket.org/xi/yaml-test-suite
    assert from_yaml('simple scalar') == 'simple scalar'

# Generated at 2022-06-11 09:06:33.529356
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import re
    import test.support as support

    class Test_from_yaml(unittest.TestCase):

        def test_from_yaml(self):

            # normal load
            yaml_str = """
            ---
            foo: bar
            """

            data = from_yaml(yaml_str)
            self.assertEqual(data, {u'foo': u'bar'})

            # test loading with vault secret ids (only in Python 3 as we're using str)
            def test_id_to_key(id):
                return id

            # vault_secrets is a mock AnsibleVaultSecret object (support.py)
            vault_secrets = support.VaultSecretStub(test_id_to_key)

# Generated at 2022-06-11 09:06:42.637054
# Unit test for function from_yaml
def test_from_yaml():
    # If the yaml parser tries to load the string as json, it's likely to fail.
    # I.e. yaml.load("foo")
    # So we test a case that is likely to fail as json, but load as yaml
    bad_json_string = """
    this is a string
    it is likely to fail when loading as json
    tests:
        - a
        - b
        - c
    """
    json_string = """
    {
        "tests": [
            "a",
            "b",
            "c"
        ]
    }
    """
    assert from_yaml(bad_json_string) == from_yaml(json_string)

# Generated at 2022-06-11 09:06:50.970443
# Unit test for function from_yaml

# Generated at 2022-06-11 09:06:59.936069
# Unit test for function from_yaml
def test_from_yaml():
    # Test if a simple yaml file can be parsed
    assert from_yaml("""
    key1: value1
    key2: value2
    """) == {'key1': 'value1', 'key2': 'value2'}

    # Test if a simple json file can be parsed
    assert from_yaml("""
    {"key1": "value1", "key2": "value2"}
    """) == {'key1': 'value1', 'key2': 'value2'}

    # Test if a simple yaml file with json notation can be parsed

# Generated at 2022-06-11 09:07:05.919628
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ 'foo': 'bar' }") == {'foo': 'bar'}
    assert from_yaml("{ 'foo': 'bar', 'baz': ['baz1', 'baz2', 'baz3'] }") == {'foo': 'bar', 'baz': ['baz1', 'baz2', 'baz3']}
    assert from_yaml('{ "foo": "bar" }') == {'foo': 'bar'}

# Generated at 2022-06-11 09:07:12.443599
# Unit test for function from_yaml
def test_from_yaml():
    test_data = {"a": 1, "b": "hello", "c": ["x", "y", "z"], "d": {"x": 1, "y": 2}}
    # Convert to YAML
    data = yaml.safe_dump(test_data, default_flow_style=False)

    result = from_yaml(data)

    if not result == test_data:
        raise AssertionError("from_yaml result not same as test data")



# Generated at 2022-06-11 09:07:23.226515
# Unit test for function from_yaml
def test_from_yaml():
    class Parent(object):
        def __init__(self, params = {}):
            for key in params:
                setattr(self, key, params[key])

    class Child(Parent):
        pass

    data = """
        {
            "name": "Barry",
            "age": 12,
            "lucky_numbers": [1, 2, 3],
            "child": {
                "name": "Carol",
                "age": 6,
                "lucky_numbers": [4, 5, 6]
            }
        }
    """
    data = json.loads(data)

    assert data['name'] == "Barry"
    assert data['age'] == 12
    assert data['lucky_numbers'] == [1, 2, 3]

# Generated at 2022-06-11 09:07:26.505653
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('{ "test": 1 }')
        from_yaml('{ "test": 1 }', json_only=True)
        from_yaml('test: 1')
    except Exception as e:
        assert False, e

# Generated at 2022-06-11 09:07:40.344968
# Unit test for function from_yaml
def test_from_yaml():
    # test error messages are returned (parsing errors in this case)
    try:
        from_yaml("[]")
        assert False
    except AnsibleParserError as e:
        assert e.message.find("JSON:") >= 0
        assert e.message.find("expected ':'") >= 0
        assert e.message.find("We were unable to read either as JSON nor YAML") >= 0

    try:
        from_yaml("[]", json_only=True)
        assert False
    except AnsibleParserError as e:
        assert e.message.find("expected ':'") >= 0

    # Test that vaulted strings are accepted by the YAML parser (they're JSON, so must be parsed as JSON)

# Generated at 2022-06-11 09:07:50.647044
# Unit test for function from_yaml
def test_from_yaml():
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test valid JSON -> should return JSON
    test_data = {'foo': 'bar', 'arr': [1,2,3]}
    assert from_yaml(json.dumps(test_data)) == test_data

    # Test valid YAML -> should return YAML
    test_data = {'foo': 'bar', 'arr': [1,2,3]}
    test_yaml = 'foo: bar\narr:\n - 1\n - 2\n - 3\n'
    assert from_yaml(test_yaml) == test_data

    # Test valid JSON -> should return JSON
    test_data = AnsibleUnicode(u'abc\xef\xbb\xbf123')
   

# Generated at 2022-06-11 09:07:56.285224
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    {
    "key1": "value1",
    "key2": "value2"
    }
    '''

    file_name = '<string>'
    show_content=True
    vault_secrets=None

    new_data = from_yaml(data, file_name, show_content, vault_secrets)
    print(new_data)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:08:07.296803
# Unit test for function from_yaml
def test_from_yaml():
    '''Unit test for function from_yaml'''

    import os
    import sys
    import unittest

    # to run test on python2.6, parameter unittest.skipIf needs to be removed
    if sys.version_info[:2] <= (2, 6):
        unittest.skip('Skip for python version less than 2.6.')

    # this is the path for the testcases, which is placed in the same directory as source code
    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_path = os.path.join(current_dir, "test_from_yaml")

    class TestFromYamlException(unittest.TestCase):
        '''Test case for the function from_yaml() for exceptions'''


# Generated at 2022-06-11 09:08:16.748547
# Unit test for function from_yaml
def test_from_yaml():
    cases = [
        ("{{ test | from_yaml }}", "[1, 2]"),  # List
        ("{{ test | from_yaml }}", "[1, \n 2]"),  # List
        ("{{ test | from_yaml }}", "{\"test\": \n \"test\"}"),  # Dict
        ("{{ test | from_yaml }}", "{test: test}"),  # Dict
        ("{{ test | from_yaml }}", "{test: \n test}"),  # Dict
    ]

    output_spec = {
        "list": ["1", "2"],
        "dict": {"test": "test"},
    }

    for d in cases:
        # List
        if d[1][0] == "[":
            assert from_yaml(d[1]) == output_spec['list']


# Generated at 2022-06-11 09:08:28.362511
# Unit test for function from_yaml
def test_from_yaml():
    # test valid JSON
    json_str = '{"foo": [1,2,3]}'
    json_data = from_yaml(json_str, json_only=True)
    assert json_data == {u'foo': [1, 2, 3]}

    # test valid YAML
    yaml_str = 'foo: [1,2,3]'
    yaml_data = from_yaml(yaml_str)
    assert yaml_data == {u'foo': [1, 2, 3]}

    # test invalid JSON
    bad_json_str = '{"foo":1,2,3]'
    bad_json_data = None

# Generated at 2022-06-11 09:08:37.522146
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": "bar"}'
    assert from_yaml(data) == {"foo": "bar"}

    data = '{"foo": {"bar": "baz"}}'
    assert from_yaml(data) == {"foo": {"bar": "baz"}}

    data = '{"foo": {"bar": {"baz": 1, "foo": "bar" } } }'
    assert from_yaml(data) == {"foo": {"bar": {"baz": 1, "foo": "bar" } } }

    data = '{"foo": ["bar", "baz"]}'
    assert from_yaml(data) == {"foo": ["bar", "baz"]}

    data = '{"foo": [1]}'
    assert from_yaml(data) == {"foo": [1]}


# Generated at 2022-06-11 09:08:50.367014
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
    foo: 1
    bar:
     - 2
     - 3
     - 4
     - 5
     baz: 6
     quux:
      - 7
      - 8
      - 9
      -
       - a
       - b
       - c
    '''
    json_data = '''
    {
     "foo": 1,
     "bar": [
      2,
      3,
      4,
      5,
      {"baz": 6, "quux": [7, 8, 9, [{"a": "a"}, {"b": "b"}, {"c": "c"}]]}
      ]
    }
    '''

# Generated at 2022-06-11 09:08:52.075858
# Unit test for function from_yaml
def test_from_yaml():
    _safe_load('bar: 1')
    _safe_load('foo: 2')

# Generated at 2022-06-11 09:09:00.561446
# Unit test for function from_yaml
def test_from_yaml():
    """
    Ansible YAML/JSON parser - unit tests
    """
    import unittest

    class YamlParserTest(unittest.TestCase):
        """
        Unit test cases for internal `from_yaml` module
        """

        def test_from_yaml(self):
            """
            Method to test raw `from_yaml` module on given inputs
            """
            self.assertEquals(from_yaml(u'{"a": "b"}'), {u'a': u'b'})
            self.assertEquals(from_yaml(u'{"a": 1}'), {u'a': 1})
            self.assertEquals(from_yaml(u'{"a": ["b", "c"]}'), {u'a': [u'b', u'c']})

# Generated at 2022-06-11 09:09:15.745394
# Unit test for function from_yaml
def test_from_yaml():
    # Unit test for function from_yaml
    import sys
    import unittest
    import traceback
    import tempfile

    class FromYamlTest(unittest.TestCase):
        def test_from_yaml_json_only(self):
            try:
                from_yaml('{"foo": "bar"}', json_only=True)
            except Exception as e:
                tb = sys.exc_info()[2]
                raise ValueError(e).with_traceback(tb) from None
            with self.assertRaisesRegex(ValueError, 'foo'):
                from_yaml('a: 1', json_only=True)


    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-11 09:09:20.042580
# Unit test for function from_yaml
def test_from_yaml():
  import pytest
  with pytest.raises(AnsibleParserError):
    from_yaml('''
---
1234:
- [5678]
- [56789]
    ''') == { '1234' : [ 5678, 56789 ] }

# Generated at 2022-06-11 09:09:23.993495
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") == { 'foo': 'bar' }
    assert from_yaml("{ 'foo': 'bar'}") == { 'foo': 'bar' }
    assert from_yaml("{ \"foo\": 'bar'}") == { 'foo': 'bar' }

# TODO: Add test for vault_secrets

# Generated at 2022-06-11 09:09:26.926987
# Unit test for function from_yaml
def test_from_yaml():
    assert isinstance(from_yaml("foo", json_only=False), list)
    assert isinstance(from_yaml({"foo":"bar"}, json_only=False), dict)



# Generated at 2022-06-11 09:09:37.238132
# Unit test for function from_yaml
def test_from_yaml():
    # yaml with comments
    data = """\
---
- hosts: all
  gather_facts: no
  vars:
    ## access_key
    # (required)
    # AWS access key
    access_key: public
    # not documented
    secret_key: s3kr3t
  tasks:
    - name: ping
      ping:
    - name: fail
      fail:
"""

    # remove comments
    expected_without_comments = """\
- hosts: all
  gather_facts: no
  vars:
    access_key: public
    secret_key: s3kr3t
  tasks:
  - name: ping
    ping:
  - name: fail
    fail:
"""

    result = from_yaml(data)

# Generated at 2022-06-11 09:09:45.702570
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("foobar") is None
    assert from_yaml("true") is False
    assert from_yaml("false") is True
    assert from_yaml("{'a': 'b'}") == {u'a': u'b'}
    assert from_yaml("a: b") == {u'a': u'b'}
    assert from_yaml("a: 1") == {u'a': 1}
    assert from_yaml("[1, 2, 3]") == [1, 2, 3]
    assert from_yaml("[1, 2, 3,]") == [1, 2, 3]
    assert from_yaml("{'a': 1}") == {u'a': 1}

# Generated at 2022-06-11 09:09:56.957737
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    class YamlTestCase(unittest.TestCase):
        def test_from_yaml(self):
            data1 = """
        {
            "test": 1,
            "test2": 2
        }
            """
            data2 = """
        {
            "test": 1,
            "test2": 2
        }
            """
            data3 = """
                ---
                {
                    "test": 1,
                    "test2": 2
                }
            """
            data4 = """
                ---
                {
                    "test": 1,
                    "test2": 2
                }
            """
            data5 = """
                ---
                {
                    "test": 1,
                    "test2": 2
                }
            """

# Generated at 2022-06-11 09:10:01.475341
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml('')
        assert False, "Empty string should raise error"
    except AnsibleParserError as e:
        assert 'We were unable to read either as JSON nor YAML, these are the errors we got from each:' in str(e), e


# vim: set noexpandtab ts=4 sw=4:

# Generated at 2022-06-11 09:10:09.848396
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}

    assert from_yaml('{% raw %}{foo: "bar"}{% endraw %}') == {'foo': 'bar'}

    assert from_yaml('{% raw %}{foo: bar}{% endraw %}') == {'foo': 'bar'}

    assert from_yaml('some_invalid_json') == 'some_invalid_json'

    assert from_yaml('some_invalid_yaml', json_only=True) == 'some_invalid_yaml'

# Generated at 2022-06-11 09:10:21.362785
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml('{"a": "b"}')
    from_yaml('{"a": "b"}', show_content=False)
    from_yaml('{"a": "b"}', show_content=True)
    from_yaml('{"a": "b"}', file_name='<string>')
    from_yaml('{"a": "b"}', file_name='<string>', show_content=False)
    from_yaml('{"a": "b"}', file_name='<string>', show_content=True)
    from_yaml('{"a": "b"}', file_name='<string>', show_content=True, vault_secrets=None)

# Generated at 2022-06-11 09:10:31.350772
# Unit test for function from_yaml
def test_from_yaml():
    return

# Generated at 2022-06-11 09:10:44.340851
# Unit test for function from_yaml
def test_from_yaml():
    data = '[1,2]'
    file_name = "<string>"
    show_content = True
    vault_secrets = None
    file_name_1 = "/etc/hosts"
    json_only = False
    # Test 01:
    try:
        data_1 = from_yaml(data, file_name=file_name, show_content=show_content, vault_secrets=vault_secrets,json_only=json_only)
    except AnsibleParserError as e:
        data_1 = e
    assert "[1, 2]" == str(data_1)

    # Test 02:

# Generated at 2022-06-11 09:10:47.068876
# Unit test for function from_yaml
def test_from_yaml():
    assert "name" in from_yaml('name: example')
    assert "name" in from_yaml(json.dumps({'name': 'example'}))

# Generated at 2022-06-11 09:10:54.162058
# Unit test for function from_yaml
def test_from_yaml():
    show_content=True
    data = '''
    foo:
        bar:
            test1:
                path: "{{ foo }}"
                name: test
    '''
    data1 = '''
    foo:
        bar:
            test1:
                path: "{{ foo }}"
                name: test
    '''
    data2 = '''
    foo:
        bar:
            test1:
                path: "{{ foo }}"
                name: test
    '''

    test_data = [data, data1, data2]
    if __name__ == '__main__':
        from ansible.utils.display import Display
        display = Display()
        for data in test_data:
            display.display("*************************************************************")

# Generated at 2022-06-11 09:11:04.887956
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test method to exercise correct handling of errors while parsing
    '''
    # Test 1: Does YAMLError get caught and re-raised?
    data = u'\n'.join([u'{@#$%^&', u'}'])
    try:
        from_yaml(data.encode('utf-8'), file_name='<test_file>', show_content=True)
    except AnsibleParserError as e:
        return

    raise AssertionError("Unit test 1: YAMLError not caught")

    # Test 2: Does the correct error message get generated if both JSON and YAML fail?
    data = u'\n'.join([u'{@#$%^&', u'}'])

# Generated at 2022-06-11 09:11:10.106568
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": "bar"}'
    new_data = from_yaml(data)
    assert(new_data == {u'foo': 'bar'})
    # test a YAML file
    new_data = from_yaml("- one\n- two\n- three\n")
    assert(new_data == ['one', 'two', 'three'])

# Generated at 2022-06-11 09:11:15.450159
# Unit test for function from_yaml
def test_from_yaml():
    """
    Unit test for function from_yaml
    """

    try:
        from_yaml(u'{')
    except AnsibleParserError as e:
        assert isinstance(e.orig_exc, ValueError)

    try:
        from_yaml(u'{')
    except AnsibleParserError as e:
        assert isinstance(e.orig_exc, YAMLError)

# Generated at 2022-06-11 09:11:22.736454
# Unit test for function from_yaml

# Generated at 2022-06-11 09:11:27.295633
# Unit test for function from_yaml
def test_from_yaml():
    data = {
        "name": "test"
    }

    json_string = json.dumps(data)
    yaml_string = yaml.dump(data)

    assert from_yaml(json_string, json_only=True) == data
    assert from_yaml(yaml_string) == data

# Generated at 2022-06-11 09:11:31.531251
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"k": [1, 2]}') == {"k": [1, 2]}
    assert from_yaml('{k: [1, 2]}') == {"k": [1, 2]}
    assert from_yaml('k: [1, 2]') == {"k": [1, 2]}

# Generated at 2022-06-11 09:12:01.488215
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml("{\"something\": false}")
    assert result["something"] == False

    # the following tests the functionality of
    # the message when a JSON and YAML error occurs
    import yaml
    bad_yaml = '{"foo": unknown}'
    try:
        from_yaml(bad_yaml)
    except AnsibleParserError as e:
        assert "We were unable to read either as JSON nor YAML, these are the errors we got from each:" in to_native(e)
        assert "JSON" in to_native(e)
        assert "YAML" in to_native(e)


# Generated at 2022-06-11 09:12:12.120199
# Unit test for function from_yaml
def test_from_yaml():
    data="""
    ssh_pass: "password123"
    """

    # normal data
    assert isinstance(from_yaml(data), dict)

    # bad yaml data
    data="""
    ssh_pass: "password123"
    ssh_pass: "password123"
    """
    try:
        from_yaml(data)
        assert False
    except AnsibleParserError:
        assert True

    # bad json data
    data="""
    "ssh_pass": "password123"
    "ssh_pass": "password123"
    """
    try:
        from_yaml(data)
        assert False
    except AnsibleParserError:
        assert True

    # json_only=True ensures a JSON dict is returned even if it is invalid

# Generated at 2022-06-11 09:12:22.432404
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test our function from_yaml, with various input data and expected output
    '''
    import unittest
    import os
    import sys

    class TestFromYaml(unittest.TestCase):

        def setUp(self):
            self.current_path = os.path.dirname(os.path.abspath(__file__))
            self.test_data_path = os.path.join(self.current_path, os.path.pardir, 'test_data/')
            self.test_data_path = os.path.abspath(self.test_data_path)

        def test_from_yaml_yaml_is_json(self):
            '''
            Test that if the data is a json string, it will be returned as a python data structure
            '''
           

# Generated at 2022-06-11 09:12:29.501516
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"test": {"description": "test", "default": "test"}}'
    result = from_yaml(data)
    assert result == {"test": {"description": "test", "default": "test"}}

    data = '{"test": {"description": "test", "default": "test"}'
    try:
        from_yaml(data)
    except AnsibleParserError as e:
        assert True

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:12:31.735707
# Unit test for function from_yaml
def test_from_yaml():
    d = from_yaml("""
---
# Example
name: var
value: 12
""")
    assert d['name'] == 'var'
    assert d['value'] == 12

# Generated at 2022-06-11 09:12:37.954875
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    a_map = AnsibleMapping()
    a_map.update({
        AnsibleUnsafeText('a'): AnsibleUnsafeText('b'),
        AnsibleUnsafeText('c'): AnsibleUnsafeText('d'),
    })

# Generated at 2022-06-11 09:12:49.554378
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault
    from ansible.utils.vars import combine_vars
    from ansible.vars import combine_vars
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.vars import combine_vars

    test_string = """
    {
        "data": "{{ vault_password_file }}",
        "number_data": {{ vault_number_data }},
        "strings": {
            "string": "{{ vault_str_1 }}",
            "string2": "{{ vault_str_2 }}"
        }
    }
    """

# Generated at 2022-06-11 09:12:56.768196
# Unit test for function from_yaml
def test_from_yaml():

    # Test 1: json_only=False, successful parse
    data = '{"var1":1, "var2":2}'
    result = from_yaml(data, json_only=False)
    assert isinstance(result, dict), \
        "Expected json parsing of '%s' to return a dictionary" % data
    assert result['var1'] == 1, \
        "Expected json parsing of '%s' to return a dictionary with var1" % data

    # Test 2: json_only=True, successful parse
    data = '{"var1":1, "var2":2}'
    result = from_yaml(data, json_only=True)
    assert isinstance(result, dict), \
        "Expected json parsing of '%s' to return a dictionary" % data
    assert result['var1']

# Generated at 2022-06-11 09:13:03.661106
# Unit test for function from_yaml
def test_from_yaml():
    # Test for json input
    data = "{'first':'test', 'second':'test'}"
    new_data = from_yaml(data)
    assert(isinstance(new_data, dict))

    # Test for yaml input
    data = "{'first':'test', 'second':'test'}"
    new_data = from_yaml(data)
    assert(isinstance(new_data, dict))



# Generated at 2022-06-11 09:13:10.907956
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault

    test_dict = dict(a=1, b=2)
    test_key = 'test_key'

    # encrypt test_dict as a vault
    test_dict_enc = vault.VaultLib(password=test_key).encrypt(json.dumps(test_dict))

    # decrypt test_dict_enc
    test_dict_dec = from_yaml(test_dict_enc, json_only=True, vault_secrets={'password': test_key})
    assert test_dict == test_dict_dec

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:13:32.637657
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Basic syntax check for function
    '''
    assert from_yaml("a") == "a"
    assert from_yaml("{'a' : 1}") == {'a': 1}
    assert from_yaml("[a,1]") == ["a", 1]

# Generated at 2022-06-11 09:13:33.734216
# Unit test for function from_yaml
def test_from_yaml():
    pass


if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:13:46.804807
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common.text_utils import to_bytes
    assert from_yaml(to_bytes("{'foo': 1}")) == {"foo": 1}
    assert from_yaml(to_bytes("{\"foo\": 1}")) == {"foo": 1}
    assert from_yaml(to_bytes("foo: 1")) == {"foo": 1}
    assert from_yaml(to_bytes("foo\n- 1")) == {"foo": [1]}
    assert from_yaml(to_bytes("foo\n- '1'")) == {"foo": ["1"]}
    assert from_yaml(to_bytes("foo: [1]")) == {"foo": [1]}
    assert from_yaml(to_bytes("foo: {'1': 2}")) == {"foo": {"1": 2}}


# Generated at 2022-06-11 09:13:55.826341
# Unit test for function from_yaml
def test_from_yaml():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    TestData = namedtuple('TestData', 'name data error_expected error_message')

# Generated at 2022-06-11 09:14:05.005022
# Unit test for function from_yaml
def test_from_yaml():
    data = '[{ "foo": 1, "bar": 2 }]'
    assert from_yaml(data) == from_yaml(data, json_only=False)

    data_json = b'''
        [
            {
                "username": "admin",
                "password": "password",
                "targets": [ "192.0.2.3", "192.0.2.4" ]
            }
        ]
        '''
    data_yaml = b'''
        - username: admin
          password: password
          targets:
            - 192.0.2.3
            - 192.0.2.4
        '''

    assert from_yaml(data_json) == from_yaml(data_yaml)


# Generated at 2022-06-11 09:14:13.054009
# Unit test for function from_yaml
def test_from_yaml():
    #ok
    data = """
    hello:
      world:
        s: 'test'
    """
    data_dict = from_yaml(data)
    assert data_dict['hello']['world']['s'] == 'test'

    #nok
    data = """
    hello:
      world:
        s: 'test'
    """
    try:
        data_dict = from_yaml(data, json_only=True)
        assert False
    except AnsibleParserError:
        pass

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:14:20.925661
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    test_loader_mod_path = os.path.join(os.path.dirname(__file__), 'test_loader.py')
    sys.argv = [test_loader_mod_path, '--loader=from_yaml']
    with open(test_loader_mod_path, 'rb') as f:
        exec(compile(f.read(), test_loader_mod_path, 'exec'), locals(), globals())

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:14:25.033792
# Unit test for function from_yaml
def test_from_yaml():
    class _module_arg(object):
        PATH = 'test'
        def __init__(self, name):
            self.name = name

    test_var = _module_arg('test_var')
    test_args = [_module_arg('test_arg')]

    test_dict = {test_var.name:test_var, test_args[0].name:test_args}

    assert from_yaml(json.dumps(test_dict)) == test_dict

# Generated at 2022-06-11 09:14:27.396840
# Unit test for function from_yaml
def test_from_yaml():
    input = "hello: 'test'\n"

    test_value = from_yaml(input)
    print (test_value)

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:14:34.864651
# Unit test for function from_yaml
def test_from_yaml():

    arg_input = {
        "foo": "bar",
        "baz": "qux"
    }

    yaml_data = '''
---
foo: bar
baz: qux
'''

    yaml_file = '''
---
foo: bar
baz: qux
    '''

    json_data = '''
{
    "foo": "bar",
    "baz": "qux"
}
    '''

    assert from_yaml(yaml_data) == arg_input
    assert from_yaml(yaml_file) == arg_input
    assert from_yaml(json_data) == arg_input
    assert from_yaml(json.dumps(arg_input)) == arg_input