

# Generated at 2022-06-11 09:04:35.541154
# Unit test for function from_yaml
def test_from_yaml():
    test_dict = from_yaml("""
    ---
    this_could_be:
        - a list
        - or a dictionary
        - or any yaml structure
    created_with:
        a_list:
            - or a dictionary
            - see
        a_dict: " yaml"
    """)
    print(test_dict)

# Generated at 2022-06-11 09:04:42.557466
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for function from_yaml '''
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()

    assert from_yaml('[', '[') == []
    assert from_yaml('{', '{') == {}
    assert from_yaml('[{', '[{') == [{}]
    assert from_yaml('[{}]', '[{}]') == [{}]
    assert from_yaml('[{}]', '[{}]', False) == [{}]
    assert from_yaml('', '') == None

# Generated at 2022-06-11 09:04:53.921426
# Unit test for function from_yaml
def test_from_yaml():
    real_data = {
        "foo": 1,
        "bar": {
            "baz": 2,
        },
    }

    # Ensure that this data is a valid JSON or YAML string
    json_string = json.dumps(real_data)
    yaml_string = yaml.safe_dump(real_data)

    # Both of them should be the same python data structure
    assert from_yaml(json_string) == real_data
    assert from_yaml(yaml_string) == real_data

    # But if the string is not valid JSON or YAML, it raises an error
    invalid_json_string = 'This is not a valid JSON string.'
    invalid_yaml_string = 'This is not a valid YAML string.'

# Generated at 2022-06-11 09:05:07.186068
# Unit test for function from_yaml
def test_from_yaml():
    noop_dict = {'msg': 'this is a test'}
    yaml_str = "---\n- hosts: all\n  gather_facts: no\n  tasks:\n  - name: this is a\n          test\n    debug:\n      msg: \"this is a test\"\n"
    json_str = '{"msg": "this is a test"}'
    with open('/tmp/yaml_test.yaml', 'w') as f:
        f.write(yaml_str)
    assert from_yaml(yaml_str) == [{'hosts': 'all', 'gather_facts': 'no', 'tasks': [{'debug': {'msg': 'this is a test'}, 'name': 'this is a test'}]}]

# Generated at 2022-06-11 09:05:16.882732
# Unit test for function from_yaml
def test_from_yaml():
    good_yaml_data="""
foo:
- hosts: foo
  user: me
bar:
- hosts: bar
  user: you
    """
    # Make sure it loads YAML OK
    assert from_yaml(good_yaml_data) == {'bar': [{'hosts': 'bar', 'user': 'you'}], 'foo': [{'hosts': 'foo', 'user': 'me'}]}

    # Error handling
    bad_yaml_data="""
foo:
- hosts: foo
  user: me
bar:
- hosts: bar
  user: you
    """

# Generated at 2022-06-11 09:05:28.575742
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo":"bar", "bam": {"boo": {"hoo": [1,2,3]}}, "bar": ["a","b","c"], "arbitrary": null}'
    assert from_yaml(data) == {"foo": "bar", "bam": {"boo": {"hoo": [1, 2, 3]}}, "bar": ["a", "b", "c"], "arbitrary": None}
    assert from_yaml(data, json_only=True) == {"foo": "bar", "bam": {"boo": {"hoo": [1, 2, 3]}}, "bar": ["a", "b", "c"], "arbitrary": None}

# Generated at 2022-06-11 09:05:37.151415
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import os

    test_dir = os.path.dirname(__file__)
    test_file = os.path.join(test_dir, 'import_yaml_test.yml')

    with open(test_file, 'r') as source:
        data = source.read()
    parsed_data = from_yaml(data)
    # Note: the yml file contains a dict, with keys of type string and integer
    #       and it is dumped to YAML as a dict.
    assert type(parsed_data) is dict
    assert u'1' in parsed_data

# Generated at 2022-06-11 09:05:48.663413
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.module_utils._text import to_bytes

    data = {'a': 1}
    assert from_yaml(to_bytes(json.dumps(data))) == data
    assert from_yaml(to_bytes('{ a: 1 }')) == data
    assert from_yaml(to_bytes('{a: 1 }')) == data
    assert from_yaml(to_bytes('{a : 1}')) == data
    assert from_yaml(to_bytes('{ a : 1 }')) == data
    assert from_yaml(to_bytes('{ "a" : 1 }')) == data
    assert from_yaml(to_bytes('{ "a" : "1" }')) == data

# Generated at 2022-06-11 09:05:51.927880
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml("""
        ---
        - list_item_1
        - list_item_2
        -
          - inner_list_item_1
          - inner_list_item_2
        - list_item_3
        """)

# Generated at 2022-06-11 09:06:00.949669
# Unit test for function from_yaml
def test_from_yaml():
    # test valid yaml
    assert from_yaml('{ "key": "value" }') == { "key": "value" }
    # test invalid yaml
    import sys
    import pytest
    with pytest.raises(AnsibleParserError):
        from_yaml('{ "key": "value" ')
    # test valid json
    assert from_yaml('{ "key": "value" }', json_only=True) == { "key": "value" }
    # test invalid json
    with pytest.raises(AnsibleParserError):
        from_yaml('{ "key": "value" ', json_only=True)
    # Issue #43788 - unicode strings
    assert from_yaml(u'{ "key": "value" }') == {"key": "value"}
    #

# Generated at 2022-06-11 09:06:15.537502
# Unit test for function from_yaml
def test_from_yaml():
    ''' unit test for from_yaml '''
    import pytest

    # test if decoded data is correct
    assert from_yaml('{ "test": [100] }') == {"test": [100]}

    # this should fail due to invalid syntax
    with pytest.raises(AnsibleParserError):
        from_yaml('{ "test": [100 ] }')

    # this should fail due to use of only-json parser
    with pytest.raises(AnsibleParserError):
        from_yaml('{ "test": [100] }', json_only=True)

    # this should fail due to invalid syntax
    with pytest.raises(AnsibleParserError):
        from_yaml('{ "test": [100 }')

    # this should fail due to invalid syntax, and should not show the

# Generated at 2022-06-11 09:06:18.737774
# Unit test for function from_yaml
def test_from_yaml():
    try:
        res = from_yaml(None)
    except AnsibleParserError as e:
        pass
    except Exception as e:
        pass

if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:06:25.534130
# Unit test for function from_yaml
def test_from_yaml():
    import pytest
    from_yaml_fn = from_yaml
    # Check that yaml.safe_load() is called with correct vault_secrets.
    def mock_safe_load(stream, file_name=None, vault_secrets=None):
        assert vault_secrets == ['secret1', 'secret2']
        return stream

    from_yaml_fn.yaml_safe_load = mock_safe_load

    # Check that orig_exc is passed to AnsibleParserError.
    def mock_handle_error(json_exc, yaml_exc, file_name, show_content):
        msg = YAML_SYNTAX_ERROR % to_native(getattr(yaml_exc, 'problem', u''))

# Generated at 2022-06-11 09:06:31.065484
# Unit test for function from_yaml
def test_from_yaml():
    '''
    [{"foo": "bar"}, {"baz": "qux"}]
    '''

    data = "[{'foo': 'bar'}, {'baz': 'qux'}]"
    result = from_yaml(data)
    assert result == [{'foo': 'bar'}, {'baz': 'qux'}]



# Generated at 2022-06-11 09:06:41.079841
# Unit test for function from_yaml
def test_from_yaml():

    # Test with bad json string
    try:
        from_yaml('{ "test_key" : "test_value"')
    except AnsibleParserError as e:
        having_exception = True
    assert having_exception == True

    # Test with both json and yaml strings
    try:
        from_yaml('{ "test_key" : "test_value" }')
    except AnsibleParserError as e:
        having_exception = True
    assert having_exception == False

    try:
        from_yaml('test_key: test_value')
    except AnsibleParserError as e:
        having_exception = True
    assert having_exception == False

    # Test with good json string

# Generated at 2022-06-11 09:06:47.364241
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo":"bar"}') == {'foo': 'bar'}
    assert from_yaml('{foo: bar}') == {'foo': 'bar'}

    with pytest.raises(AnsibleParserError) as excinfo:
        from_yaml('{foo: bar}', json_only=True)

    assert 'We were unable to read either as JSON nor YAML, these are the errors we got from each:' in str(excinfo.value)

# Generated at 2022-06-11 09:06:53.642852
# Unit test for function from_yaml
def test_from_yaml():
    json_data = """
    {
        "a" : {
            "b": "val1"
        }
    }
    """
    json_data_structure = {'a': {'b': 'val1'}}

    yaml_data = """
    ---
    a:
        b: val1
    """

    yaml_data_structure = {'a': {'b': 'val1'}}

    assert from_yaml(json_data) == json_data_structure
    assert from_yaml(yaml_data) == yaml_data_structure

# Generated at 2022-06-11 09:07:01.890388
# Unit test for function from_yaml
def test_from_yaml():
    '''Unit test for function from_yaml'''
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    test_str1 = '\n- hosts: all\n  gather_facts: no\n'
    results = from_yaml(test_str1)
    assert type(results) is list
    assert len(results) == 1
    assert type(results[0]) is dict
    assert results[0]['hosts'] == 'all'
    assert results[0]['gather_facts'] == 'no'

    test_str2 = '\n- hosts: all\n  gather_facts: no\n  vars:\n    myvar1: test\n    myvar2: test2\n'
    results = from_yaml(test_str2)


# Generated at 2022-06-11 09:07:06.906156
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
        - hosts: localhost
          tasks:
            - name: test1
              debug: msg="test1"
    '''

    ret = from_yaml(data)
    print(ret[0])
    assert ret[0]['hosts'] == 'localhost'

test_from_yaml()

# Generated at 2022-06-11 09:07:17.877433
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import os
    ansible_dir = os.path.dirname(os.path.dirname(__file__))
    yaml_dir = os.path.join(ansible_dir, "lib/ansible/parsing/yaml")
    sys.path.append(yaml_dir)
    from ansible.parsing.yaml.objects import AnsibleMapping
    data = "a:b"
    new_data = from_yaml(data)
    assert isinstance(new_data, AnsibleMapping)
    assert new_data.get("a") == "b"
    new_data = from_yaml(data, file_name="abc")
    assert isinstance(new_data, AnsibleMapping)
    assert new_data.get("a") == "b"
    new

# Generated at 2022-06-11 09:07:29.451041
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    #
    # Test from_yaml with integers / decimals
    #

# Generated at 2022-06-11 09:07:30.014421
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-11 09:07:42.337046
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for function from_yaml. '''

    json_string = '{"test": "yaml"}'
    yaml_string = '''
        ---
        test: "yaml"
    '''


# Generated at 2022-06-11 09:07:51.627447
# Unit test for function from_yaml
def test_from_yaml():
    # Test loading a valid yaml file
    test = from_yaml('---\nfoo: bar\nbar: foo\n')
    assert test == {'foo': 'bar', 'bar': 'foo'}
    # Test loading a valid json file
    test = from_yaml('{"foo": "bar", "bar": "foo"}')
    assert test == {'foo': 'bar', 'bar': 'foo'}
    # Test loading a bad json file
    try:
        test = from_yaml('{"foo": "bar", "bar": "foo"')
    except Exception as e:
        assert 'We were unable to read either as JSON nor YAML' in to_native(e)
    # Test loading a bad yaml file

# Generated at 2022-06-11 09:08:00.175523
# Unit test for function from_yaml
def test_from_yaml():
    # Test for json string
    json_data = '{"key":"value"}'
    assert from_yaml(json_data, json_only=True) == {"key": "value"}
    # Test for yaml string
    yaml_data = '{key: value}'
    assert from_yaml(yaml_data, json_only=True) == {"key": "value"}
    # Test for non json/yaml string
    non_json_yaml_data = "i am a string"
    try:
        from_yaml(non_json_yaml_data, json_only=True)
        assert False
    except AnsibleParserError:
        assert True


# Generated at 2022-06-11 09:08:10.478384
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    sys.path.append("../")

    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_str = """
    - hosts: 192.168.1.1
      remote_user: root
      tasks:
        - name: ping
          ping:
    """
    yaml_data = _safe_load(yaml_str, file_name='<string>')
    print(yaml_data)  # [{'tasks': [{'ping': None, 'name': 'ping'}], 'hosts': '192.168.1.1', 'remote_user': 'root'}]

# test_from_yaml()

# Generated at 2022-06-11 09:08:13.287828
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') == None
    assert from_yaml('{') == None

# Generated at 2022-06-11 09:08:17.304516
# Unit test for function from_yaml
def test_from_yaml():
    data_str = '''
    {
        foo: 1,
        bar: "baz"
    }
    '''
    data_dict = {
        'foo': 1,
        'bar': 'baz',
    }
    assert(from_yaml(data_str) == data_dict)
    assert(from_yaml(json.dumps(data_dict)) == data_dict)


# Generated at 2022-06-11 09:08:21.662187
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    data = from_yaml('{ foo : "bar" }')
    assert data['foo'] == 'bar'
    data = from_yaml('{ foo : "bar" }', json_only=True)
    assert data['foo'] == 'bar'

# Generated at 2022-06-11 09:08:33.213442
# Unit test for function from_yaml
def test_from_yaml():

    # Test YAML data
    data = """
        foo: bar
        bam: { baz: foobar }
        bar: "foo"
        list:
            - foo: bar
            - bam: baz
            - baz: bam
        list2:
            - "foo"
            - "bam": "baz"
            - "baz": "bam"
    """

    # Test yaml parsing
    result = from_yaml(data)
    assert result['foo'] == 'bar'
    assert result['bam']['baz'] == 'foobar'
    assert result['bar'] == 'foo'
    assert result['list'][0]['foo'] == 'bar'
    assert result['list'][1]['bam'] == 'baz'

# Generated at 2022-06-11 09:08:47.216535
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault
    test_vault_password = u'this is a password'
    test_vault_secrets = [ vault.VaultSecret('password', test_vault_password) ]

    try:
        yaml_data = from_yaml(data=u'foo', file_name=u'<string>', show_content=True, vault_secrets=test_vault_secrets)
        assert True
    except AnsibleParserError as e:
        assert False

    try:
        json_data = from_yaml(data=u'foo', file_name=u'<string>', show_content=True, vault_secrets=test_vault_secrets, json_only=True)
        assert True
    except AnsibleParserError as e:
        assert False


# Generated at 2022-06-11 09:08:57.960963
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import sys

    class TestResult(unittest.TestResult):
        def startTest(self, test):
            unittest.TestResult.startTest(self, test)
            sys.stdout.write(test.shortDescription() + " ...")

        def addSuccess(self, test):
            unittest.TestResult.addSuccess(self, test)
            sys.stdout.write(" ok\n")

    class TestCase(unittest.TestCase):
        def shortDescription(self):
            return "Test the from_yaml function"


# Generated at 2022-06-11 09:09:07.742620
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"hello":"world"}'
    result = from_yaml(data)
    assert result == {"hello":"world"}, "result == %s, want: %s" % (result,{"hello":"world"})

    data = "{'hello': 'world'}"
    result = from_yaml(data)
    assert result == {"hello":"world"}, "result == %s, want: %s" % (result,{"hello":"world"})

    data = '''
    hello:
      - world
      - ansible
    '''
    result = from_yaml(data)
    assert result == {"hello": ["world", "ansible"]}, \
                 "result == %s, want: %s" % (result, {"hello": ["world", "ansible"]})


# Generated at 2022-06-11 09:09:16.087868
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') is None
    assert from_yaml('{}') == {}
    assert from_yaml('{"a": "b"}') == {"a": "b"}
    assert from_yaml('-\n  a: b') == [{"a": "b"}]
    assert from_yaml('[-\n  a: b]') == [[{"a": "b"}]]
    assert from_yaml('[-\n  a: b]', json_only=True) == [{"a": "b"}]

# Generated at 2022-06-11 09:09:24.974984
# Unit test for function from_yaml
def test_from_yaml():
    common = '''
        - hosts: all
          tasks:
            - name: whoami
              command: whoami
              register: who
    '''
    # json
    json_str = '''
    {
    "tasks": [{"name": "whoami", "command": "whoami", "register": "who"}]
    }
    '''
    # yaml
    yaml_str = '''
    ---
    tasks:
      - name: whoami
        command: whoami
        register: who
    '''
    # yaml in json

# Generated at 2022-06-11 09:09:29.444675
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a": { "b" : "{{ c }}" }}'
    data1 = '{"a": { "b" : "{{ \\n c }}" }}'
    from_yaml(data)
    from_yaml(data1)
    from_yaml(data1, json_only=True)



# Generated at 2022-06-11 09:09:39.758421
# Unit test for function from_yaml
def test_from_yaml():
    '''
    To run unit tests for this function, execute
    `python -m unit_tests.test_yaml as a module`
    '''

    # Test basic concept, yaml to python dictionary
    dict_data = {'test1': 'test1', 'test2': 'test2'}
    yaml_data = 'test1: test1\ntest2: test2'
    assert from_yaml(yaml_data) == dict_data

    # Test json to python dictionary, should use json_decoder instead of yaml
    json_data = '{"test1":"test1","test2":"test2"}'
    assert from_yaml(json_data) == dict_data

    # Test json is not yaml

# Generated at 2022-06-11 09:09:45.537198
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('foo: bar') == {'foo': 'bar'}

    try:
        from_yaml('{foo: "bar"')
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError should have been raised"

    try:
        from_yaml('foo: bar}')
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError should have been raised"

# Generated at 2022-06-11 09:09:50.349345
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import read_vault_secret
    vault_secrets = ['foo']
    myfile_name = '<string>'
    show_content = True
    json_only = False
    data = "{'a': 'b'}"
    assert from_yaml(data, file_name=myfile_name, show_content=show_content, vault_secrets=vault_secrets, json_only=json_only) == {"a": "b"}
    data = "---\n- 1\n- 2\n- 3\n"

# Generated at 2022-06-11 09:10:01.559435
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.unicode import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    plaintext_data = {'foo': 'bar'}
    plaintext_data_json_str = to_bytes(json.dumps(plaintext_data))

    vault_secret = VaultSecret('password')
    vault = VaultLib([vault_secret])
    ciphertext_data = vault.encrypt(plaintext_data_json_str)
    ciphertext_data_str = to_bytes(ciphertext_data.decode('utf-8'))

    # Omit from_yaml() parameters.
    d = from_yaml(ciphertext_data_str)
    assert d == plaintext_data

    d = from_y

# Generated at 2022-06-11 09:10:16.895220
# Unit test for function from_yaml
def test_from_yaml():

    # Test JSON only mode
    # NOTE: in the future, if we want to drop support for loading both YAML and JSON in the same time,
    #       we need to fix some unit tests that rely on this feature
    import pytest
    with pytest.raises(AnsibleParserError):
        from_yaml('{invalid json: "string"}\n', json_only=True)

    # Test without JSON only mode
    data = from_yaml('{invalid json: "string"}\n')
    assert data == '{invalid json: "string"}\n'

    import os
    from ansible.parsing.vault import VaultLib

    # Test encryption
    tmpdir = os.path.realpath('./test/test_utils_from_yaml_encrypted')

# Generated at 2022-06-11 09:10:22.728699
# Unit test for function from_yaml
def test_from_yaml():
    s = '''\
    ---
    # config data
    foo: bar
    baz: ["one", "two", "3", 4, 5.0]
    ...
    '''
    d = from_yaml(s)

    assert d['foo'] == 'bar'
    assert d['baz'] == ['one', 'two', '3', 4, 5.0]

# Generated at 2022-06-11 09:10:31.125100
# Unit test for function from_yaml
def test_from_yaml():
    first_dict = '{"a": 1, "b": 2, "c": 3}'
    first_dict_expected = {"a": 1, "b": 2, "c": 3}

    second_dict = "{ a: 1, b: 2, c: 3 }"
    second_dict_expected = {"a": 1, "b": 2, "c": 3}

    third_dict = "---\na: 1\nb: 2\nc: 3\n"
    third_dict_expected = {"a": 1, "b": 2, "c": 3}

    json_only = from_yaml(first_dict, json_only=True)
    assert json_only == first_dict_expected

    json = from_yaml(first_dict)
    assert json == first_dict_expected

    # Sometimes people write json like this

# Generated at 2022-06-11 09:10:44.144569
# Unit test for function from_yaml
def test_from_yaml():

    json_string = '["foo", {"bar":["baz", null, 1.0, 2]}]'
    assert from_yaml(json_string) == json.loads(json_string)

    yaml_string = '''
    ---
    - name: test.yml
      a:
        b: 1
        c: [1,2,3]
        d: "a string"
    '''
    assert from_yaml(yaml_string) == {'a': {'b': 1, 'c': [1, 2, 3], 'd': 'a string'}, 'name': 'test.yml'}


# Generated at 2022-06-11 09:10:52.795949
# Unit test for function from_yaml
def test_from_yaml():
    from pydoc import locate
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder

    # Search for AnsibleMapping to resolve circular-import issue.
    # This issue was introduced by AnsibleParserError refactoring.
    # This also needs to be fixed in production code.
    ansible_mapping_path = locate("ansible.parsing.yaml.objects.AnsibleMapping")
    ansible_mapping = ansible_mapping_path()

    test_data = "int: 1\nstring: one\ndict: {section: 1}"
    test_yaml = from_yaml(test_data)


# Generated at 2022-06-11 09:11:02.027517
# Unit test for function from_yaml
def test_from_yaml():

    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}
    assert from_yaml('foo: bar\n') == {"foo": "bar"}
    assert from_yaml('{ "foo": "bar" }') == {"foo": "bar"}
    assert from_yaml('foo: "bar"\n') == {"foo": "bar"}

    # we now use ajason for json, need to test it too
    assert from_yaml('{"a": "1", "b": [1, 2, {"c": 3.0}]}') == {"a": "1", "b": [1, 2, {"c": 3.0}]}

# Generated at 2022-06-11 09:11:12.807627
# Unit test for function from_yaml
def test_from_yaml():

    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dataloader = DataLoader()

    cm = ConfigManager(
        [],
        variables=VariableManager(loader=dataloader),
    )

    my_data = from_yaml(
            '''
            - name: test 1
              foo: bar
            - name: test 2
              foo: bar
            - name: test 3
              foo: bar
            ''',
            file_name='test_data.yml',
            vault_secrets=[cm],
        )

    assert len(my_data) == 3
    assert {'name': 'test 1', 'foo': 'bar'} in my_data

# Generated at 2022-06-11 09:11:18.252150
# Unit test for function from_yaml
def test_from_yaml():
    # test invalid yaml
    yaml_invalid = """\
- a: b
- c: d
- e: f\
"""
    try:
        from_yaml(yaml_invalid)
    except AnsibleParserError as e:
        pass
    else:
        assert False, "expected exception not raised"


    # test invalid json

# Generated at 2022-06-11 09:11:27.583414
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import sys
    import pytest
    mydir = os.path.dirname(__file__)
    mydir = os.path.abspath(mydir)
    sys.path.append(os.path.join(mydir, '../..'))
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.ajson import AnsibleJSONDecoder

    # Loads a YAML file and returns a python object
    def load_yaml(file_path):
        return DataLoader().load_from_file(file_path)

    # Loads a JSON file and

# Generated at 2022-06-11 09:11:37.696636
# Unit test for function from_yaml
def test_from_yaml():
    """
    Test the from_yaml function.
    """
    # Successfully load json data
    data = '{"ansible": {"hello": "world"}}'
    assert from_yaml(data) == {"ansible": {"hello": "world"}}

    # Successfully load yaml data
    data = '''
    ansible:
      hello: world
    '''
    assert from_yaml(data) == {"ansible": {"hello": "world"}}

    # Syntax error in yaml, raises AnsibleParserError
    data = '''
    ansible:
      hello world
    '''

# Generated at 2022-06-11 09:11:42.786417
# Unit test for function from_yaml
def test_from_yaml():
    pass

# Generated at 2022-06-11 09:11:48.801711
# Unit test for function from_yaml
def test_from_yaml():
    print('from_yaml test')
    print('---')
    print(from_yaml('{"python"="version"}'))
    print(from_yaml('python: version'))
    print(from_yaml('python: "version"'))
    print(from_yaml('python: "3.7.3"'))
    print(from_yaml('python: 3.7.3'))
    print(from_yaml('python: 3.7.3', json_only=True))
    print(from_yaml('python: version\npython: "version"', json_only=True))


if __name__ == "__main__":
    test_from_yaml()
    pass

# Generated at 2022-06-11 09:11:59.869917
# Unit test for function from_yaml
def test_from_yaml():
    # JSON tests
    try:
        from_yaml('{}')
    except AnsibleParserError as e:
        assert(False, 'Valid JSON should not generate an exception.')

    try:
        from_yaml('{')
    except AnsibleParserError as e:
        assert(True, 'Invalid JSON should generate an exception.')

    try:
        from_yaml('{', json_only=True)
    except AnsibleParserError as e:
        assert(True, 'Invalid JSON should generate an exception.')

    # YAML tests
    try:
        from_yaml('---\nfoo: bar')
    except AnsibleParserError as e:
        assert(False, 'Valid YAML should not generate an exception.')


# Generated at 2022-06-11 09:12:10.875854
# Unit test for function from_yaml
def test_from_yaml():
    # Test for valid JSON object.
    data1 = '{"age": 30, "name": "John"}'
    assert from_yaml(data1) == {'age': 30, 'name': 'John'}

    # Test for invalid JSON object.
    data2 = '{"age": 30, "name": "John"'
    try:
        from_yaml(data2)
    except AnsibleParserError as ex:
        assert True
    except:
        assert False, 'The AnsibleParserError exception was not raised.'

    # Test for valid YAML object.
    data3 = 'age: 30\nname: John'
    assert from_yaml(data3) == {'age': 30, 'name': 'John'}

    # Test for invalid YAML object.

# Generated at 2022-06-11 09:12:17.417989
# Unit test for function from_yaml
def test_from_yaml():
    try:
        from_yaml(data="{\"foo\": 5}")
    except Exception as e:
        print(e)
        if to_native(e) != "No JSON object could be decoded":
            raise AssertionError("from_yaml did not return the correct error")
        return
    raise AssertionError("from_yaml did not return an error")

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:12:25.083463
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('''
        ---
        - {name: "Object one", position: 1}
        - {name: "Object two", position: 2}
    ''')
    assert result[0]['name'] == 'Object one'
    assert result[1]['position'] == 2

    result = from_yaml('''
        ---
        - {name: "Object one", position: 1}
        - {name: "Object two", position: 2}
    ''', json_only=True)
    assert result[0]['name'] == 'Object one'
    assert result[1]['position'] == 2

# Generated at 2022-06-11 09:12:34.365514
# Unit test for function from_yaml
def test_from_yaml():

    # This test just verifies that from_yaml() is able to parse an empty yaml doc
    # This is to ensure that we don't get regressions from from_yaml()
    # It makes no sense to call from_yaml() with an empty string, but it is also
    # not possible to call yaml.safe_load with an empty string, so we have to
    # check that from_yaml() specifically can handle it
    data = ""
    file_name = "<string>"
    show_content = True
    vault_secrets = None
    json_only = False

    new_data = None

    new_data = from_yaml(
        data, file_name, show_content, vault_secrets, json_only
    )

    assert new_data is None

# Generated at 2022-06-11 09:12:39.006342
# Unit test for function from_yaml
def test_from_yaml():
    # Test valid yaml
    try:
        from_yaml("---\nfoo: bar")
    except AnsibleParserError as yaml_exc:
        pass

    # Test invalid yaml
    try:
        from_yaml("---\nfoo: bar: baz")
    except AnsibleParserError as yaml_exc:
        pass

# Generated at 2022-06-11 09:12:50.721607
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}", show_content=False) == {"foo": "bar"}
    assert from_yaml(u"{'foo': 'bar'}", show_content=False) == {"foo": "bar"}
    assert from_yaml("[1, 2, 3]", show_content=False) == [1, 2, 3]
    assert from_yaml(u"[1, 2, 3]", show_content=False) == [1, 2, 3]
    assert from_yaml("{'foo': [1, 2, 3]}", show_content=False) == {'foo': [1, 2, 3]}

# Generated at 2022-06-11 09:12:57.297497
# Unit test for function from_yaml
def test_from_yaml():
    # Setup some test cases

    # Random data to test
    test1 = "random-data"

    # Valid json data
    test2 = "{\"apiVersion\": \"v1\"}"

    # valid yaml data
    test3 = "{apiVersion: \"v1\"}"

    # invalid yaml data
    test4 = "{apiVersion: \"v1\""

    # invalid json data
    test5 = "{\"apiVersion\": \"v1\""

    # invalid yaml data, treated as json because of json_only
    test6 = "{apiVersion: \"v1\"}"

    # Tests from_yaml with a random string
    try:
        from_yaml(test1)
    except AnsibleParserError as e:
        print("Test 1 passed")

    # Tests from_yaml with valid json

# Generated at 2022-06-11 09:13:17.849427
# Unit test for function from_yaml
def test_from_yaml():
    from unittest import TestCase
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestYAML(TestCase):
        def test_from_yaml(self):
            # load a yaml string that is valid JSON as well
            jsn = '{ "a": "b" }'
            jsn_yaml = from_yaml(jsn)
            # assert the output is a python dict
            self.assertEqual(type(jsn_yaml), dict)

            # load a yaml string that is not valid JSON
            yml = '''
a: b
c:
  d: e
'''
            yml_yaml = from_yaml(yml)
            # assert the output is a python dict

# Generated at 2022-06-11 09:13:23.537580
# Unit test for function from_yaml
def test_from_yaml():
    s = """
    first_name: Michael
    last_name: DeHaan
    values
        - foo
        - bar
    """
    data = from_yaml(s)
    assert data['first_name'] == 'Michael'
    assert data['last_name'] == 'DeHaan'
    assert data['values'][0] == 'foo'
    assert data['values'][1] == 'bar'

# Generated at 2022-06-11 09:13:32.739939
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Tests the following cases:
        1. YAML and JSON values
        2. Empty string
        3. Invalid JSON string
        4. Invalid YAML string
        5. YAML list values
        6. YAML dictionary values
        7. YAML dictionary values with YAML list of Key-Value pairs
    '''

    # 1. YAML and JSON values
    yaml_string = '''
    - title: test_title
      name: test_name
      count: 3
      url: https://google.com
      description: This is a simple test case
    '''
    result = from_yaml(yaml_string)
    assert result[0]['title'] == 'test_title'


# Generated at 2022-06-11 09:13:39.311207
# Unit test for function from_yaml
def test_from_yaml():
    data = "{'a': '{\"foo\": \"bar\"}'}"
    new_data = from_yaml(data, json_only=True)
    assert new_data['a'] == '{\"foo\": \"bar\"}'

    data = "{'a': {'foo': 'bar'}}"
    new_data = from_yaml(data)
    assert new_data['a'] == {'foo': 'bar'}

# Generated at 2022-06-11 09:13:49.314343
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Just a simple test of the from_yaml function. Run with 'pytest -v'
    '''
    data = '''
- hosts: all
  gather_facts: false
  tasks:
  - name: ping test
    ping:
    register: result
  - debug: var=result
'''

    answer = { 'hosts' : "all",
               'tasks' : [ { 'name' : "ping test",
                             'ping' : { 'register' : "result" } },
                           { 'debug' : { 'var' : "result" } } ],
               'gather_facts' : False
             }

    assert(from_yaml(data) == answer)

# Generated at 2022-06-11 09:13:57.824469
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1, "b": 2, "c": 3 }') == { "a": 1, "b": 2, "c": 3 }

    # this example is from the yaml website: http://yaml.org/spec/1.2/spec.html#id2762107
    example = '''
        ---
        time: 20:03:20
        player: Sammy Sosa
        action: strike (miss)
    '''
    assert from_yaml(example) == {
        'time': '20:03:20',
        'player': 'Sammy Sosa',
        'action': 'strike (miss)',
    }
    assert from_yaml('[]') == []
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-11 09:14:00.914407
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a": 1, "b": false }') == {
        'a': 1,
        'b': False,
    }
    assert from_yaml('[ 1, 2, 3 ]') == [1, 2, 3]

# Generated at 2022-06-11 09:14:05.824806
# Unit test for function from_yaml
def test_from_yaml():
    # simple yaml
    yaml = '''
---
- hosts: all
  gather_facts: False
  tasks:
  - name: 'A check'
    raw: echo ok
'''
    assert from_yaml(yaml) == [{'hosts': 'all', 'gather_facts': False, 'tasks': [{'name': 'A check', 'raw': 'echo ok'}]}]

# Generated at 2022-06-11 09:14:10.165937
# Unit test for function from_yaml
def test_from_yaml():
    data = {
        'a': 1,
        'b': 2,
        'c': 'string'
    }

    new_data = from_yaml(json.dumps(data))
    assert isinstance(new_data, dict)
    assert len(new_data.items()), len(data.items())

# Generated at 2022-06-11 09:14:15.447095
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{ "a":1, "b":2, "c":{"d":3, "e":4} }') == {"a": 1, "b": 2, "c": {"d": 3, "e": 4}}

if __name__ == "__main__":
    test_from_yaml()

# Generated at 2022-06-11 09:14:26.750945
# Unit test for function from_yaml
def test_from_yaml():
    d = from_yaml('{ "json": true }')
    assert d == {'json': True}

