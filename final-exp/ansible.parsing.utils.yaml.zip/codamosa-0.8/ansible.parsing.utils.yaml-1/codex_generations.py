

# Generated at 2022-06-11 09:04:34.288696
# Unit test for function from_yaml
def test_from_yaml():
    file_name = '<test>'
    data = '''
test_data:
  - one
  - two
  - three
'''
    expected = {'test_data': ['one', 'two', 'three']}
    assert from_yaml(data, file_name) == expected

# Generated at 2022-06-11 09:04:43.110546
# Unit test for function from_yaml
def test_from_yaml():
    """
    Basic testing method for library function from_yaml.
    """
    # Test with proper json data
    json_data = """
    {"msg": "Hello World!"}
    """
    ansible_data = from_yaml(json_data)
    assert(ansible_data == {"msg": "Hello World!"})

    # Test with proper yaml data
    yaml_data = """
    msg: Hello World!
    """
    ansible_data = from_yaml(yaml_data)
    assert(ansible_data == {"msg": "Hello World!"})

    # Test with proper yaml data when json_only is True
    yaml_data = """
    msg: Hello World!
    """

# Generated at 2022-06-11 09:04:51.220959
# Unit test for function from_yaml
def test_from_yaml():
    # Should detect file format is JSON and load the data
    json_data = '{"name": "value"}'
    assert from_yaml(json_data) == {"name": "value"}

    # Should detect file format is YAML and load the data
    yaml_data = '---\nname: value'
    assert from_yaml(yaml_data) == {"name": "value"}

    # Should throw an exception if the format is not JSON or YAML
    with pytest.raises(AnsibleParserError):
        from_yaml('name: value')

# Generated at 2022-06-11 09:05:04.756451
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.ansible_release import __version__
    from ansible.parsing.vault import VaultLib

    vault_secrets = VaultLib([])
    vault_secrets.secrets = ['password1', 'password2']

    result = from_yaml('{ "foo": 1 }', vault_secrets=vault_secrets)
    assert result == {'foo': 1}, result


# Generated at 2022-06-11 09:05:09.920713
# Unit test for function from_yaml
def test_from_yaml():
    # JSON data
    input_data = '{"foo": "bar"}'

    # Expected output (JSON is parsed by AnsibleJSONDecoder)
    expected = {u'foo': u'bar'}

    # AnsibleJSONDecoder is needed to get unicode strings in both Python 2 and 3
    output_data = json.loads(input_data, cls=AnsibleJSONDecoder)

    assert output_data == expected

# Generated at 2022-06-11 09:05:19.732016
# Unit test for function from_yaml
def test_from_yaml():
    ex_yaml = '''
    ---
    foo:
      hello: world
      this_is_a_list:
        - item 1
        - item 2
    '''
    ex_yaml_dict = {
        'foo': {
            'hello': 'world',
            'this_is_a_list': [
                'item 1',
                'item 2',
            ],
        },
    }
    assert from_yaml(ex_yaml) == ex_yaml_dict

    ex_json = '''
    {"foo": {"hello": "world",
             "this_is_a_list": ["item 1", "item 2"]}}
    '''

# Generated at 2022-06-11 09:05:25.481797
# Unit test for function from_yaml
def test_from_yaml():
    value = {
        '_raw_params': '{{ foo.bar | to_json }}',
        'somethingelse': 'somevalue',
    }
    assert value == from_yaml('''
---
_raw_params: '{{ foo.bar | to_json }}'  # this comment should be ignored
somethingelse: somevalue
''')

# Generated at 2022-06-11 09:05:33.037391
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"a":"b"}'
    json_data = from_yaml(data)
    assert json_data == {"a":"b"}
    data = 'a: b\n'
    json_data = from_yaml(data)
    assert json_data == {"a":"b"}
    data = "{{a}}"
    json_data = from_yaml(data)
    assert json_data == "{{a}}"
    data = "{{ a }}"
    json_data = from_yaml(data)
    assert json_data == "{{ a }}"

# Generated at 2022-06-11 09:05:42.357636
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml("{ 'test': 'first' }", json_only=True)
    from_yaml("test: test")
    from_yaml("{ 'test': 'first' }")
    from_yaml("a: 1")
    from_yaml("---\na: 1")
    try:
        # Bad YAML
        from_yaml("--- {}")
        assert False
    except AnsibleParserError:
        pass
    try:
        # Unterminated string
        from_yaml("a: 'x")
        assert False
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 09:05:47.659364
# Unit test for function from_yaml
def test_from_yaml():
    json_data = '{"def": "abc"}'
    yaml_data = 'def: "abc"'
    data = from_yaml(json_data)
    assert data == {"def": "abc"}

    data = from_yaml(yaml_data)
    assert data == {"def": "abc"}


# Generated at 2022-06-11 09:05:59.095968
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("", json_only=True) is None

    # Test boolean detection in JSON
    json_true = '{"test": true}'
    assert from_yaml(json_true, json_only=True) == {"test": True}

    json_false = '{"test": false}'
    assert from_yaml(json_false, json_only=True) == {"test": False}

    # Test bool detection in YAML
    yaml_true = '{"test": true}'
    assert from_yaml(yaml_true) == {"test": True}

    yaml_false = '{"test": false}'
    assert from_yaml(yaml_false) == {"test": False}

    # Test bool detection when both JSON and YAML true is valid

# Generated at 2022-06-11 09:06:10.719765
# Unit test for function from_yaml
def test_from_yaml():

    import os, sys

    # Get diretory of this code file
    mod_dir = os.path.dirname(os.path.abspath(sys.modules[__name__].__file__))

    # Read file test_input.yml
    test_file = open(os.path.join(mod_dir, "test_input.yml"))
    test_stream = test_file.read()
    test_file.close()

    # Check that function can handle complex data
    decoded_data = from_yaml(test_stream, json_only=False)
    with open(os.path.join(mod_dir, "test_output.json")) as json_data:
        json_output = json.load(json_data)

    assert decoded_data == json_output

# Generated at 2022-06-11 09:06:20.499606
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Unit test for function from_yaml
    '''
    import unittest

    class TestModule(unittest.TestCase):
        '''
        Unit test for function from_yaml
        '''

        def test_from_yaml(self):
            '''
            Test from_yaml
            '''
            good_yamls = [
                "{ first: 'string', second: 'string' }",
                "{ first: 'string', second: 'string', third: { test: 'string' } }",
                "{ first: 'string', second: 'string', third: [ 'one', 2, 'three' ] }",
            ]

# Generated at 2022-06-11 09:06:32.182953
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml('{"a": "b"}')
    assert result == {'a': 'b'}
    result = from_yaml('{"a": "b" }')
    assert result == {'a': 'b'}
    result = from_yaml('{ "a" : "b" }')
    assert result == {'a': 'b'}
    result = from_yaml('{ "a" : "b", "c" : "d", "e" : "f" }')
    assert result == {'a': 'b', 'c': 'd', 'e': 'f'}
    result = from_yaml('{ "a" : "b", "c" : "d", "e" : "f", }')

# Generated at 2022-06-11 09:06:42.001957
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing import vault

    data = '''
cat: test_key_1

{%- if cat == "test_key_1" -%}
{%- set dog = "test_key_2" -%}
{%- endif -%}

dog: {{ dog }}
'''

    file_name = 'test.yml'
    show_content = True
    vault_secrets = vault.VaultSecret('vault_secret_1')

    try:
        new_data = from_yaml(data, file_name, show_content, vault_secrets, False)
        print(new_data)
    except AnsibleParserError as e:
        print(e.message)

# Running the unit test
test_from_yaml()

# Generated at 2022-06-11 09:06:50.644680
# Unit test for function from_yaml
def test_from_yaml():
    # Test for error handling
    import pytest
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_text

    yaml_data = '\n'.join(["- hosts: localhost",
                           "  gather_facts: False",
                           "  user: root",
                           "  tasks:",
                           "    - name: test",
                           "      ping"])

    # this is a basic test to make sure we get a data structure back with valid YAML
    data = from_yaml(yaml_data)
    assert type(data) == list

    # now we test for a broken YAML file, and make sure we get a specific error back

# Generated at 2022-06-11 09:06:53.484901
# Unit test for function from_yaml
def test_from_yaml():
    from .unit.parsing.parse_yaml_test import YamlTestCase
    yaml_test = YamlTestCase()
    yaml_test.test_from_yaml()


# Generated at 2022-06-11 09:07:01.768595
# Unit test for function from_yaml
def test_from_yaml():
    data1 = '{"foo": "bar", "baz": [1,2,3]}'
    data1a = from_yaml(data1)

    assert isinstance(data1a, dict)
    assert data1a['foo'] == 'bar'
    assert data1a['baz'][0] == 1
    assert data1a['baz'][1] == 2
    assert data1a['baz'][2] == 3

    data2 = 'foo: bar\nbaz: [1,2,3]\n'
    data2a = from_yaml(data2)

    assert isinstance(data2a, dict)
    assert data2a['foo'] == 'bar'
    assert data2a['baz'][0] == 1
    assert data2a['baz'][1] == 2

# Generated at 2022-06-11 09:07:07.446167
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Function for unit testing
    '''
    data = '''
    # a comment
    - name: myname
      # another comment
      age: 3
    '''
    result = from_yaml(data)
    expected_result = [{'name': 'myname', 'age': 3}]
    assert result == expected_result, 'result: %s' % result


# Generated at 2022-06-11 09:07:18.587239
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    yaml_output = '''
- hosts: all
  vars:
    var1: 1234
    var2: a string
  tasks:
  - name: sample task 1
    debug:
      msg: "this is a test"
  - name: sample task 2
    shell: /bin/false
'''

    data = from_yaml(yaml_output)
    assert isinstance(data, list)
    assert data[0]['hosts'] == 'all'
    assert data[0]['vars']['var1'] == 1234
    assert data[0]['vars']['var2'] == 'a string'
    assert data[0]['tasks'][0]['name'] == 'sample task 1'
   

# Generated at 2022-06-11 09:07:27.550462
# Unit test for function from_yaml
def test_from_yaml():
    ''' basic unit test for to_yaml '''

    # INFO(spredzy) This test is a simple one, as it is mainly testing that
    # the YAML parser is correctly loading the data.

    data = '''
    - name: "test0"
      state: "absent"
      some_bool: yes
      some_num: 0.001
      some_other_num: 0
     '''

    # we expect a list
    assert isinstance(from_yaml(data), list)



# Generated at 2022-06-11 09:07:30.300680
# Unit test for function from_yaml
def test_from_yaml():
    # Test data
    test_data = '{"a":2, "b":3}'
    file_name = '<string>'

    return_data = from_yaml(test_data)
    assert return_data == {"a":2, "b":3}

# Generated at 2022-06-11 09:07:42.792022
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml('foo: bar', vault_secrets=[]) == {'foo': 'bar'}
    assert from_yaml('foo: !!str 42') == {'foo': '42'}
    assert from_yaml('foo: !!str 42') != {'foo': 42}
    assert isinstance(from_yaml('foo: bar')['foo'], AnsibleUnicode)
    assert not isinstance(from_yaml('foo: !!str bar')['foo'], AnsibleUnicode)
    assert from_yaml('foo: !!str bar', to_native=lambda x: x)['foo'] is not None
    assert from_y

# Generated at 2022-06-11 09:07:51.836601
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.six import PY3

    data = """
    a: 1
    b:
      c: 3
      d: 4
    """

    assert isinstance(from_yaml(data), dict)
    assert from_yaml(data) == { u'a': 1, u'b': { u'c': 3, u'd': 4 } }

    # ensure that the DataLoader returns the YAML object with the filename set,
    # so the objects are properly serialized when stored in the variable manager
    ds = DataLoader().load_from_string(data)
    assert isinstance(ds, dict)
    assert isinstance(list(ds.keys())[0], AnsibleBaseYAMLObject)

# Generated at 2022-06-11 09:07:55.681718
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}
    assert from_yaml('foo: bar') == {"foo": "bar"}
    assert from_yaml('{foo: bar}') is None
    assert from_yaml('{foo: bar}', json_only=True) is None

# Generated at 2022-06-11 09:08:06.457421
# Unit test for function from_yaml
def test_from_yaml():

    # test_from_yaml_json
    assert from_yaml('{"a": 1, "b": 2}') == {u'a': 1, u'b': 2}

    # test_from_yaml_yaml
    assert from_yaml('a: 1\nb: 2') == {u'a': 1, u'b': 2}

    # test_from_yaml_mixed_json_yaml
    assert from_yaml('a: 1,\n"b": 2') == {u'a': 1, u'b': 2}

    # test_from_yaml_invalid_json
    assert from_yaml('{a: 1, b: 2}') == {u'a': 1, u'b': 2}

    # test_from_yaml_invalid_yaml

# Generated at 2022-06-11 09:08:16.353780
# Unit test for function from_yaml
def test_from_yaml():

    def assert_yaml_equal(yaml_string, expected):
        from_yaml_result = from_yaml(yaml_string)
        assert from_yaml_result == expected, 'from_yaml(%s) == %s != %s' % (yaml_string, from_yaml_result, expected)

    def assert_json_equal(json_string, expected):
        # FIXME: use jmespath?
        assert_yaml_equal(json_string, expected)

    assert_yaml_equal('true', True)
    assert_yaml_equal('false', False)
    assert_json_equal('true', True)
    assert_json_equal('false', False)
    assert_json_equal('"foo"', "foo")
    assert_json_equal('42', 42)

# Generated at 2022-06-11 09:08:27.533331
# Unit test for function from_yaml
def test_from_yaml():
    ''' Unit test for `from_yaml` function. '''

    from ansible.parsing.yaml.objects import AnsibleUnicode

    # test various common scenarios
    #
    # Note that in some of the cases below, we don't use assertEquals because
    # assertEquals would compare ascii representations of the unicode strings
    # which would invalidate the test
    data = u"unicode string"
    result = from_yaml(data)
    assert isinstance(result, AnsibleUnicode)
    assert result == u"unicode string"

    data = u"unicode string with non-ascii: ěščřžýáíé".encode('utf-8')
    result = from_yaml(data)

# Generated at 2022-06-11 09:08:33.537552
# Unit test for function from_yaml
def test_from_yaml():

    # Test: should raise `ValueError` when the `data` is not JSON or YAML
    # json.loads() raises `ValueError` when `data` is not valid JSON
    bad_json = '{invalid: json}'
    try:
        from_yaml(bad_json)
    except ValueError as e:
        pass
    except Exception:
        assert False, 'Should have raised ValueError: %s' % e

    # Test: should raise `YAMLError` when `data` is not valid YAML
    # yaml.safe_load raises `YAMLError` when `data` is not valid YAML
    bad_yaml = '- invalid-yaml'
    try:
        from_yaml(bad_yaml)
    except YAMLError as e:
        pass

# Generated at 2022-06-11 09:08:40.075889
# Unit test for function from_yaml
def test_from_yaml():
    '''
    This function should return a dict containing the names and ages of the
    people in the passed-in yaml string, which should be loaded into the dict
    in dictionary order, i.e. sorted by age.  If the yaml string contains
    duplicate ages, the people with those ages should be sorted by name.
    '''
    with open('/tmp/test_data.yml', 'r') as test_data_file:
        test_data = test_data_file.read()

    expected = {
        'bob adamowski': 32,
        'charles zolotow': 52,
        'ross zolotow': 52,
        'mike mcmillan': 55,
    }

    assert(from_yaml(test_data) == expected)


# Generated at 2022-06-11 09:08:55.201716
# Unit test for function from_yaml
def test_from_yaml():
    print("tests are not implemented")
    return 

    #valid yaml data
    yaml = """
    - hosts: localhost
      connection: local
      tasks:
      - name: install "pigz" utility
        yum:
          name: pigz
          state: latest
        notify:
        - restart cron
    """

    ansible_modutil.from_yaml(yaml)

    #incorrect yaml data
    yaml = """
    - hosts: localhost
      connection: local
      tasks:
      - name: install "pigz" utility
        yum:
          name: pigz
          state: latest
        notify:
        - restart cron
    """

    try:
        ansible_modutil.from_yaml(yaml)
    except Exception:
        pass
   

# Generated at 2022-06-11 09:09:02.237493
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import os

    testfile = os.path.join(os.path.dirname(__file__), '../../../test/units/module_utils/test_vault.yml')
    with open(testfile, 'r') as f:
        yml = f.read()

    vault_secrets = [('default', VaultLib([('default', 'test123')]))]
    result = from_yaml(yml, vault_secrets=vault_secrets)
    assert result['secret_string'] == AnsibleUnicode('my secret string')


# Generated at 2022-06-11 09:09:11.979082
# Unit test for function from_yaml
def test_from_yaml():
    good_yaml = '''
---
a: 1
b:
  c: 3
  d: 4
'''
    assert from_yaml(good_yaml) == {"a": 1, "b": {"c": 3, "d": 4}}

    bad_yaml = '''
---
a: 1
b:
  c: 3
    d: 4
'''

    try:
        from_yaml(bad_yaml)
    except AnsibleParserError as e:
        assert 'We were unable to read either as JSON nor YAML' in to_native(e)
    else:
        assert False, "Incorrect YAML should have raised an error"


# Generated at 2022-06-11 09:09:22.810584
# Unit test for function from_yaml
def test_from_yaml():
    test_yaml = """
    ---
    - hosts: servers
      roles:
         - common
         - foo
    """

    test_json = """
    [
        {
            "hosts": "servers",
            "roles": [
                "common",
                "foo"
            ]
        }
    ]
    """

    test_not_json = """
    ---
    {
        "hosts": "servers",
        "roles": [
            "common",
            "foo"
        ]
    }
    """

    try:
        assert from_yaml(test_json) == from_yaml(test_yaml)
    except AssertionError:
        print("from_yaml didn't work for json with yaml")


# Generated at 2022-06-11 09:09:27.851423
# Unit test for function from_yaml
def test_from_yaml():

    data = '{ "key1": "value1", "key2": [ "value2a", "value2b" ] }'

    new_data = from_yaml(data)
    assert isinstance(new_data, dict)
    assert new_data['key1'] == 'value1'
    assert new_data['key2'] == ['value2a', 'value2b']

# Generated at 2022-06-11 09:09:38.212998
# Unit test for function from_yaml
def test_from_yaml():
    print("")
    print("test_from_yaml()")
    print("")

    data = """
    ---
    - hosts: mockhost
      tasks:
        - name: Task 1
        - name: fail
          fail:
            msg: 'Not in debug mode'
          when: ansible_debug_mode is not defined
    """

    ansible_debug_mode = True

    p = from_yaml(data,json_only=False)
    p['tasks'][1]['when']= 'ansible_debug_mode is defined'

    data2 = """
    ---
    - hosts: mockhost
      tasks:
        - name: Task 1
        - name: fail
          fail:
            msg: 'Not in debug mode'
          when: ansible_debug_mode is defined
    """
    p

# Generated at 2022-06-11 09:09:44.981888
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{'foo': 'bar'}") == {"foo": "bar"}
    assert from_yaml("{'foo': 'bar'}", json_only=False, show_content=False) == {"foo": "bar"}
    assert from_yaml("{'foo': 'bar'}", file_name='<string>', json_only=False, show_content=False) == {"foo": "bar"}
    try:
        from_yaml("{'foo': 'bar'}", json_only=True, show_content=False)
    except AnsibleParserError:
        pass
    else:
        assert False

# Generated at 2022-06-11 09:09:56.032622
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("""{
        "hello": "world",
        "foo": "bar"
    }""") == {u'hello': u'world', u'foo': u'bar'}
    assert from_yaml("""
        hello: world
        foo: bar
    """, json_only=True) == {u'hello': u'world', u'foo': u'bar'}

# Generated at 2022-06-11 09:09:58.887583
# Unit test for function from_yaml
def test_from_yaml():
    assert "{'test': {'testvar': 'testvalue'}}" == str(from_yaml("""test: {testvar: testvalue}"""))

# Generated at 2022-06-11 09:10:05.191401
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''
    - debug: msg="System {{ inventory_hostname }} has uuid {{ ansible_product_uuid }}"
    - copy:
        content: "{{ ansible_product_uuid }}"
        dest: "/etc/uuid"
    '''

    assert from_yaml(yaml_data) == [{'debug': {'msg': 'System {{ inventory_hostname }} has uuid {{ ansible_product_uuid }}'}}, {'copy': {'content': '{{ ansible_product_uuid }}', 'dest': '/etc/uuid'}}]

# Generated at 2022-06-11 09:10:14.441611
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('[]') == []
    assert from_yaml('{"key1": "value1", "key2": "value2"}') == {"key1": "value1", "key2": "value2"}
    assert from_yaml('[{"key1": "value1", "key2": "value2"}]') == [{"key1": "value1", "key2": "value2"}]

# Generated at 2022-06-11 09:10:25.135144
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test for a given string, asset that the correct datastructure is created.
    '''
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader

    # Test json_only flag and json
    json_text = '{"a": "value", "with": {"nested": {"value": 1}}}'
    json_expected = {u'a': u'value', u'with': {u'nested': {u'value': 1}}}
    assert json_expected == from_yaml(json_text, file_name='<string>', show_content=True, json_only=True)

    # Test json string and json_only=False

# Generated at 2022-06-11 09:10:32.451826
# Unit test for function from_yaml
def test_from_yaml():
    # test basic string
    input_str = '{"key": "value"}'
    expected_output = {"key": "value"}
    output = from_yaml(input_str)
    assert output == expected_output

    input_str = '''
- hosts: localhost
  tasks:
  - name: this is a task
    command: echo "hello"
    when: 1 == 1
    register: output
  - debug: var=output.stdout_lines'''
    output = from_yaml(input_str)
    assert isinstance(output, list)
    assert 'hosts' in output[0]

    # test json error
    input_str = '{'
    output = False
    try:
        out = from_yaml(input_str);
    except AnsibleParserError:
        output = True

# Generated at 2022-06-11 09:10:45.418812
# Unit test for function from_yaml
def test_from_yaml():
    ''' Run from folder tests/parsing
    python -c "from ansible.parsing.yaml.dumper import test_from_yaml; test_from_yaml()" '''
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager


# Generated at 2022-06-11 09:10:53.389172
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = '$6$gUQys4M7$F4HA/Q2wxF/X/Dutq8a7SmIYAFYpNzoLdYvN8ar7c5l5z5e5VuZCx8wb7Eqv33CmAsU6g4D4QbH46VKYj1JiX0'


# Generated at 2022-06-11 09:10:58.685805
# Unit test for function from_yaml
def test_from_yaml():
    data = """
    - hosts: localhost
      tasks:
        - name: should be ok
          command: /bin/false
        - name: should fail
          fails_when: true
          command: /bin/false
    """

    result = from_yaml(data)
    assert result[0]['hosts'] == 'localhost'



# Generated at 2022-06-11 09:11:09.335184
# Unit test for function from_yaml
def test_from_yaml():
    # Try with a valid yaml file
    valid_yaml_file = __file__.replace('__init__.py', 'tests/testdata/from_yaml_valid.yaml')
    with open(valid_yaml_file, 'r') as f:
        data = f.read()
    new_data = from_yaml(data, valid_yaml_file, False)
    assert isinstance(new_data, dict)
    assert new_data['test_key'] == 'test_value'

    # Try with an invalid yaml file
    invalid_yaml_file = __file__.replace('__init__.py', 'tests/testdata/from_yaml_invalid.yaml')
    with open(invalid_yaml_file, 'r') as f:
        data = f.read()


# Generated at 2022-06-11 09:11:11.132645
# Unit test for function from_yaml
def test_from_yaml():
    data = "1"
    new_data = from_yaml(data)
    assert new_data == 1


# Generated at 2022-06-11 09:11:20.306330
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()

    test_string_0 = "this is plain text"
    test_string_1 = '{"a": 13, "b": "13", "c": ["13", 13]}'
    test_string_2 = '''
    {
        "a": 13,
        "b": "13",
        "c": [
            "13",
            13
        ]
    }'''
    test_string_3 = '''
    a: 13
    b: "13"
    c: [
        "13",
        13
    ]'''

    assert from_yaml(test_string_0) == test_string_0

# Generated at 2022-06-11 09:11:30.465350
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    import getpass

    def _get_vault_secrets():
        ''' Returns the vault secrets ''',

        vault_secrets = dict()
        vault_secrets['vault_password'] = getpass.getpass('Vault password: ')

        return vault_secrets

    # JSON test
    print('\nJSON test')

# Generated at 2022-06-11 09:11:41.729627
# Unit test for function from_yaml
def test_from_yaml():
    data = '{"foo": "bar", "biz": "baz"}'
    result = from_yaml(data)
    assert result == {u'foo': u'bar', u'biz': u'baz'}
    result = from_yaml(data, json_only=True)
    assert result == {u'foo': u'bar', u'biz': u'baz'}

    data = 'foo: bar'
    result = from_yaml(data)
    assert result == {u'foo': u'bar'}
    try:
        result = from_yaml(data, json_only=True)
    except AnsibleParserError:
        assert True
    else:
        assert False

    data = '{% include "data.json" %}'

# Generated at 2022-06-11 09:11:47.889746
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import PY3
    assert from_yaml("foo: bar") == {"foo": "bar"}

    if PY3:
        assert from_yaml("foo: !!str bar") == {"foo": "bar"}

    # test that the dumper works properly
    dumper = AnsibleDumper()
    # using a round-about way to get the dump so we can check it
    dump_str = dumper.represent_scalar('tag:yaml.org,2002:str', 'foo')
    assert from_yaml(dump_str) == 'foo'

# Generated at 2022-06-11 09:11:54.875531
# Unit test for function from_yaml
def test_from_yaml():
    # Test strings
    test_yaml_string = "---\n- a: 1\n  b: 2\n- c: 3\n  d: 4\n"
    test_json_string = "[{\"a\": 1, \"b\": 2}, {\"c\": 3, \"d\": 4}]"
    # Test lists
    test_yaml_list = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    test_json_list = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    # Test variable name
    variable_name = 'hosts_list'

    # YAML -> JSON
    test_json_list_from_yaml = from_yaml(test_yaml_string)

    assert variable

# Generated at 2022-06-11 09:11:59.042098
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_data = from_yaml('{ "key": "val" }', '<string>')
    assert from_yaml_data == { 'key': 'val'}

# Generated at 2022-06-11 09:12:02.577932
# Unit test for function from_yaml
def test_from_yaml():

    # Simple test
    data = {'this': {'is': 'work!'}}
    str_data = json.dumps(data)

    assert from_yaml(str_data) == data

# Generated at 2022-06-11 09:12:12.949588
# Unit test for function from_yaml
def test_from_yaml():
    import unittest
    import os

    class TestFromYaml(unittest.TestCase):
        def test_from_yaml(self):
            # Check json input
            json_str = '{"foo": "bar"}'
            self.assertTrue(from_yaml(json_str, json_only=True))
            # Check yaml input
            yaml_str = 'foo: bar'
            self.assertTrue(from_yaml(yaml_str))
            # Check missing input
            with self.assertRaises(AnsibleParserError):
                from_yaml('{')
                from_yaml(' ')
                from_yaml('')

    module_path = os.path.dirname(os.path.realpath(__file__))
    test_loader = unittest.TestLoader()

# Generated at 2022-06-11 09:12:14.030424
# Unit test for function from_yaml
def test_from_yaml():
    pass


# Generated at 2022-06-11 09:12:17.105520
# Unit test for function from_yaml
def test_from_yaml():
    data_str = "{\"k1\": \"v1\"}"
    data = from_yaml(data_str)
    assert data["k1"] == "v1"

# Generated at 2022-06-11 09:12:27.038142
# Unit test for function from_yaml
def test_from_yaml():
    result = from_yaml("{'key1':'value1'}")
    assert result == {"key1": "value1"}, "from_yaml({'key1':'value1'}) returns {key1: value1} but returns %s" % result
    result = from_yaml("{'key1':'value1'}", json_only=True)
    assert result == {"key1": "value1"}, "from_yaml({'key1':'value1'}) returns {key1: value1} but returns %s" % result
    result = from_yaml("{'key1':'value1'}\n", json_only=True)

# Generated at 2022-06-11 09:12:35.277063
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml import from_yaml
    data = '''
---
    - hosts: localhost
      connection: local
      gather_facts: no
      tasks:
        - debug: msg="Ansible rocks!"
    - hosts: localhost
      connection: local
      gather_facts: no
      tasks:
        - debug: msg="Ansible rocks! 2"
'''
    #
    # We do not want invalid YAML to explode with an error. As long as the
    # data can be parsed as valid JSON, we don't need to worry about it.
    #
    assert(from_yaml(data, json_only=True))

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 09:12:49.186956
# Unit test for function from_yaml
def test_from_yaml():
    import io
    try:
        from_yaml(u'---\nhello: world\n...\n', '<test>')
    except Exception as e:
        assert False, "Failed to parse a basic YAML string: %s" % to_native(e)

    try:
        from_yaml(u'{"hello": "world"}', '<test>')
    except Exception as e:
        assert False, "Failed to parse a basic JSON string: %s" % to_native(e)

    # Test for cases where the YAML/JSON parser cannot read the string.
    # This generates a JSONDecodeError

# Generated at 2022-06-11 09:12:56.597924
# Unit test for function from_yaml
def test_from_yaml():
    import os
    import tempfile
    import shutil
    import stat
    import subprocess
    import sys

    def _mkscript(contents, filename):
        script_path = os.path.join(tempdir, filename)
        with open(script_path, 'w') as f:
            f.write(contents)
        os.chmod(script_path, stat.S_IEXEC)
        return script_path

    # Run with Python 3
    if sys.version_info.major != 3:
        pycmd = os.path.join(os.path.dirname(sys.executable), 'pip3')
        subprocess.check_output([pycmd, 'install', '-q', 'PyYAML'])

# Generated at 2022-06-11 09:13:07.118667
# Unit test for function from_yaml

# Generated at 2022-06-11 09:13:14.161619
# Unit test for function from_yaml
def test_from_yaml():
    class DummyClass(object):
        def __init__(self, value):
            self.value = value
    original_data = {"a_key": DummyClass("foo")}
    json_data = json.dumps(original_data)
    result = from_yaml(json_data, json_only=True)
    assert result == original_data

    yaml_data = "a_key: !dummy_class foo"
    result = from_yaml(yaml_data)
    assert result == original_data

# Generated at 2022-06-11 09:13:18.080521
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1,2,3]', 'test_file') == [1,2,3]
    assert from_yaml('{"a": 1, "b": "c"}') == {"a": 1, "b": "c"}

# Generated at 2022-06-11 09:13:28.240443
# Unit test for function from_yaml
def test_from_yaml():
    # Test with valid JSON
    print("[from_yaml] Test with valid JSON")
    data1 = '{"result": true}'
    assert from_yaml(data1)
    # Test with valid YAML
    print("[from_yaml] Test with valid YAML")
    data2 = "result: true"
    assert from_yaml(data2)
    # Test with invalid YAML
    print("[from_yaml] Test with invalid YAML")
    data3 = "result true"
    try:
        from_yaml(data3)
    except AnsibleParserError as e:
        print("[from_yaml] Got AnsibleParserError: %s" %(e,))
    # Test with invalid JSON
    print("[from_yaml] Test with invalid JSON")
    data

# Generated at 2022-06-11 09:13:34.487336
# Unit test for function from_yaml
def test_from_yaml():
    yaml_string = '''
    - hosts: all
      gather_facts: false
    '''
    # This should be empty
    assert from_yaml(json.dumps({})) == {}
    # This should be a list.
    assert from_yaml(json.dumps([])) == []
    # This should be populated
    assert isinstance(from_yaml(yaml_string), list)


if __name__ == '__main__':
    test_from_yaml()

# Generated at 2022-06-11 09:13:47.407190
# Unit test for function from_yaml
def test_from_yaml():
    ansible_versions = (2, 3)
    # Ansible 2.6+ changed the error message so we need to test for both versions
    for ver in ansible_versions:
        if ver == 2:
            yaml_string = "---\n- [foo, bar, baz]\n...\n"
            msg_begin = "YAML content: \n\n"
            msg_end = "\n\n^ here"
        else:
            yaml_string = "---\n- [foo,\nbar, baz]\n...\n"
            msg_begin = "YAML Syntax Error: "
            msg_end = ""

        expected_msg = msg_begin + yaml_string + msg_end
        error = False

# Generated at 2022-06-11 09:13:48.311296
# Unit test for function from_yaml
def test_from_yaml():
    # TODO
    pass

# Generated at 2022-06-11 09:13:57.037905
# Unit test for function from_yaml
def test_from_yaml():
    # test: json
    data = '{"fruits": ["apple", "banana", {"favorite": "orange"}]}'
    new_data = from_yaml(data)
    # print("new_data:" + str(new_data))
    assert new_data['fruits'][2]['favorite'] == 'orange'

    # test: yaml

# Generated at 2022-06-11 09:14:09.675699
# Unit test for function from_yaml
def test_from_yaml():
    '''
    Test to check if the output of yaml.load is same as json.load
    '''
    yaml_dict = '''
            foo: bar
            bar: baz
            '''
    json_dict = '''
            {"foo": "bar",
             "bar": "baz"
            }'''
    json_dict_no_spaces = '''{"foo": "bar",
             "bar": "baz"
            }'''

    assert from_yaml(yaml_dict) == json.loads(json_dict)
    assert from_yaml(yaml_dict) == json.loads(json_dict_no_spaces)

# Generated at 2022-06-11 09:14:21.374819
# Unit test for function from_yaml
def test_from_yaml():
    import sys
    import os
    import subprocess
    import runpy

    test_file_path = os.path.abspath(sys.argv[0])
    test_file_dir = os.path.dirname(test_file_path)

    if sys.version_info < (2, 7):
        print("ERROR: Unit tests require python 2.7 or higher")
        sys.exit(1)

    print("INFO: Running unit tests on function AnsibleJSONDecoder.decode")

    # Run unit tests
    sys.argv = sys.argv[:1]  # Clear the arguments to unittest.main()
    test_path = os.path.join(test_file_dir, 'test_json_decode')

# Generated at 2022-06-11 09:14:29.110067
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import text_type
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_f = '''
        test_list:
          - one
          - two
          - three
        test_dict:
            key: value
        test_string: This is a simple test string.
    '''

    data = from_yaml(yaml_f, '<data>')
    assert isinstance(data, dict)
    assert isinstance(data['test_list'], list)
    assert isinstance(data['test_dict'], dict)
    assert isinstance(data['test_string'], text_type)
    assert len(data) == 3
    assert len(data['test_list']) == 3