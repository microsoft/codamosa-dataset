

# Generated at 2022-06-25 23:27:33.144400
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) != Box(1)
    assert Box(1) != Box(2)
    assert not Box(1) == Box(2)
    assert Box(1) != 1
    assert not Box(1) == 1


# Generated at 2022-06-25 23:27:37.765534
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Test if method __eq__ of class Box throws exception when executed.
    try:
        val_0 = Box(None)
        val_1 = Box(None)
        val_0.__eq__(val_1)
        assert True
    except Exception as exception:
        print('Fail')
        print(exception)
        assert False



# Generated at 2022-06-25 23:27:40.760380
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    object_0 = None
    object_1 = None
    box_0 = Box(object_0)
    box_1 = Box(object_1)
    assert box_0 == box_1


# Generated at 2022-06-25 23:27:44.111432
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    box_1 = Box(object_0)
    if box_0 == box_1:
        assert True
    else:
        assert False


# Generated at 2022-06-25 23:27:45.832571
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box(None)
    assert box_0 == box_0


# Generated at 2022-06-25 23:27:47.808454
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box(42)
    box_1 = Box(42)
    assert box_0 == box_1


# Generated at 2022-06-25 23:27:52.989650
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_2 = Box(module_0.object())
    box_1 = Box(module_0.object())
    box_0 = Box(module_0.object())
    box_0.__eq__()
    box_1.__eq__(box_0)
    box_2.__eq__(box_0)


# Generated at 2022-06-25 23:27:55.710815
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from random import randint
    object_0 = object()
    box_0 = Box(object_0)
    box_1 = Box(object_0)
    assert (box_0.__eq__(box_1) is True)


# Generated at 2022-06-25 23:27:58.942717
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    try:
        box_0 = Box(1)
        box_1 = Box(2)

        assert(box_0 == box_0)
        assert(box_1 == box_1)
        assert(box_0 != box_1)
    except Exception as e:
        assert False


# Generated at 2022-06-25 23:28:06.316285
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    object_0 = module_0.object()
    object_1 = module_0.object()
    box_0 = Box(object_1)
    box_1 = Box(object_0)
    box_2 = Box(object_0)
    assert_eq_bool(box_0 == box_1, False)
    assert_eq_bool(box_1 == box_2, True)



# Generated at 2022-06-25 23:28:12.520948
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy) and lazy_0() is object_0


# Generated at 2022-06-25 23:28:15.565452
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    assert box_0.to_lazy()


# Generated at 2022-06-25 23:28:18.413761
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(object())
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:28:25.984768
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Builtins is a builtin module
    import builtins as module_0

    object_0 = module_0.object()  # assign
    box_0 = Box(object_0)  # assign

    # method call 'to_lazy'
    lazy_0 = box_0.to_lazy()

    # var assignment for 'lazy_0' on line 12
    var_0 = None
    var_0 = lazy_0.fold(lambda: object_0)

    # var assignment for 'var_0' on line 13
    var_1 = None
    var_1 = module_0.isinstance(var_0, object_0)
    assert var_1 is True

# Generated at 2022-06-25 23:28:31.569794
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    def function_0(object_0_0: object) -> object:
        return object_0_0
    lazy_0 = box_0.to_lazy()
    assert function_0(lazy_0.value()) == box_0.value


# Generated at 2022-06-25 23:28:34.047162
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:28:37.731290
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    assert isinstance(box_0.to_lazy(), module_0.type(box_0.to_lazy()).__bases__[0])


# Generated at 2022-06-25 23:28:44.597585
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    number_0 = Box(None)
    assert number_0.to_lazy().get() is None
    box_0 = Box(1)
    assert box_0.to_lazy().get() == 1
    box_1 = Box('string')
    assert box_1.to_lazy().get() == 'string'
    array_0 = Box(['a', 'b', 'c'])
    assert array_0.to_lazy().get() == ['a', 'b', 'c']
    map_0 = Box(dict())
    assert map_0.to_lazy().get() == dict()
    function_0 = Box(lambda x: x)
    assert function_0.to_lazy().get()(1) == 1

# Generated at 2022-06-25 23:28:49.314234
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Init arguments for Box
    object_0 = module_0.object()
    box_0 = Box(object_0)

    # Call Box.to_lazy()
    lazy_0 = box_0.to_lazy()

    # Check the result is True
    assert lazy_0.is_just is True


# Generated at 2022-06-25 23:28:53.272946
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:28:57.399120
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(Try(5)).to_lazy().get() == Try(5)


# Generated at 2022-06-25 23:29:00.759377
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Prepare data
    int_0 = 0

    box = Box(int_0)

    # Perform test
    lazy = box.to_lazy()

    # Assert result
    assert lazy == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:29:03.495142
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0

    assert Box(int_0).to_lazy().force() == int_0
    assert Box(int_0).to_lazy().force_fail() == int_0


# Generated at 2022-06-25 23:29:04.819714
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    box = Box(int_0)
    lazy = box.to_lazy()
    assert lazy.is_folded() is False
    assert lazy.force() is int_0



# Generated at 2022-06-25 23:29:11.037343
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_laws import monad_identity_law, monad_left_identity_law, monad_right_identity_law, \
        monad_associativity_law

    int_0 = Box(0)
    int_1 = Box(1)

    # Test monad_identity_law
    assert monad_identity_law(int_0.to_lazy, int_0.value)
    assert monad_identity_law(int_1.to_lazy, int_1.value)
    assert monad_identity_law(int_0.to_lazy, int_0.value)

    # Test monad_left_identity_law

# Generated at 2022-06-25 23:29:13.467404
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    assert isinstance(box.to_lazy(), Lazy)
    assert box.to_lazy().get() == 1


# Generated at 2022-06-25 23:29:17.510341
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = Box(0)

    assert isinstance(int_0.to_lazy(), pymonet.lazy.Lazy)

    int_1 = Box(1)
    assert int_0.to_lazy() != int_1.to_lazy()


# Generated at 2022-06-25 23:29:22.395226
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as lazy

    int_0 = Box(0)
    int_lazy = int_0.to_lazy()
    assert isinstance(int_lazy, lazy.Lazy)
    assert int_lazy() == 0
    assert int_lazy.value() == 0


if __name__ == '__main__':
    test_case_0()
    test_Box_to_lazy()

# Generated at 2022-06-25 23:29:31.333869
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(1)
    box_1 = Box("hello_world")
    box_2 = Box("s")
    lazy_0 = box_0.to_lazy()
    lazy_1 = box_1.to_lazy()
    lazy_2 = box_2.to_lazy()
    assert(lazy_0.__eq__(Lazy(lambda: 1)))
    assert(lazy_1.__eq__(Lazy(lambda: "hello_world")))
    assert(lazy_2.__eq__(Lazy(lambda: "s")))

# Generated at 2022-06-25 23:29:37.104215
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functions import compare_function_lazy

    # Refactoring for same test for all monads
    # function's name must be passed to compare function lazy, because it can be checked only by string name
    test_case_0_lazy = Lazy(test_case_0)

    assert compare_function_lazy(test_case_0_lazy, test_case_0_lazy, 'test_case_0')


# Generated at 2022-06-25 23:29:48.035352
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest
    from pymonet.lazy import Lazy

    lazy_box = Box(2).to_lazy()
    assert lazy_box == Lazy(lambda: 2)
    assert lazy_box() == 2

    lazy_box = Box([1, 2, 3]).to_lazy()
    assert lazy_box == Lazy(lambda: [1, 2, 3])
    assert lazy_box() == [1, 2, 3]

    lazy_box = Box((1, 2, 3)).to_lazy()
    assert lazy_box == Lazy(lambda: (1, 2, 3))
    assert lazy_box() == (1, 2, 3)

    lazy_box = Box({1: 2, 3: 4}).to_lazy()

# Generated at 2022-06-25 23:29:50.090394
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    '''
    :return: Lazy instance of box
    :rtype: Lazy
    '''
    x = Box(10)
    lazy = x.to_lazy()
    assert lazy.is_folded == False
    assert lazy.value == 10


# Generated at 2022-06-25 23:29:54.891885
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # call to_lazy method with value of type integer
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    try_value = Try(34, is_success=True)
    try_value_lazy = try_value.to_lazy()
    assert isinstance(try_value_lazy, Lazy)
    assert isinstance(try_value_lazy.value(), Try)
    assert try_value_lazy.value().is_success
    assert try_value_lazy.value().value == try_value.value

    # call to_lazy method with zero value
    try_value = Try(0, is_success=True)
    try_value_lazy = try_value.to_lazy()

# Generated at 2022-06-25 23:30:04.853277
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_m1 = -1
    int_m2 = -2

    int_box_0 = Box[int](int_0)
    int_box_1 = Box[int](int_1)
    int_box_2 = Box[int](int_2)
    int_box_m1 = Box[int](int_m1)
    int_box_m2 = Box[int](int_m2)

    int_lazy = int_box_2.to_lazy()

    if(int_lazy.box.value != int_2):
        raise Exception("Lazy value is not is equal to 2")


# Generated at 2022-06-25 23:30:05.687546
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-25 23:30:07.928373
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-25 23:30:12.348724
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    # Arrange
    int_0 = 0
    box = Box(int_0)
    lazy = Lazy(lambda: int_0)
    # Act
    actual_result = box.to_lazy()
    # Assert
    assert lazy.equals(actual_result), "Lazy should be {}, but actual result is {}".format(lazy, actual_result)


# Generated at 2022-06-25 23:30:14.366533
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = Box(0)
    assert int_0.to_lazy() == Lazy(lambda: 0)



# Generated at 2022-06-25 23:30:17.588780
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Check to_lazy of Box
    """
    # Create Box with some value
    int_box = Box(0)

    # Transform Box into Lazy
    lazy = int_box.to_lazy()



# Generated at 2022-06-25 23:30:20.049233
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    box = Box(int_0)
    lazy = box.to_lazy()
    assert lazy.fold() == box.value



# Generated at 2022-06-25 23:30:34.183637
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test method .to_lazy() of class Box
    """
    from pymonet.functor import Functor
    from pymonet.lazy import Lazy
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad
    from pymonet.monad_try import Try
    from pymonet import Maybe
    from pymonet.either import Right
    from pymonet.validation import Validation

    box = Box(10)

    int_0 = box.to_lazy()
    assert isinstance(int_0, Lazy)
    assert int_0.run() == 10
    assert int_0.map(lambda x: x + 10).run() == box.map(lambda x: x + 10).value

    int_1 = box.to_validation()

# Generated at 2022-06-25 23:30:40.024177
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Create Box
    box_0 = Box(int_0)
    box_0_to_lazy = box_0.to_lazy()

    # Assert result
    assert isinstance(box_0_to_lazy, Lazy)
    assert box_0_to_lazy.is_lazy_of(int)
    assert box_0_to_lazy.value() == int_0


# Generated at 2022-06-25 23:30:50.132949
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from random import randint
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    cnt = randint(0, 5000)
    int_0 = Monad.pure(0)
    assert(isinstance(int_0, Box[int]))
    assert(int_0 == Box(0))
    lazy_0 = int_0.to_lazy()
    assert(isinstance(lazy_0, Lazy[int]))
    while cnt:
        cnt -= 1
        assert(lazy_0.value == 0)
    assert(lazy_0.is_cached)
    int_1 = Box(1)
    assert(isinstance(int_1, Box[int]))

# Generated at 2022-06-25 23:30:55.328635
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # test case 1
    expected_output_1 = 0
    result_1 = Box(expected_output_1).to_lazy()
    assert result_1.value() == expected_output_1

    # test case 2
    expected_output_2 = "abcd"
    result_2 = Box(expected_output_2).to_lazy()
    assert result_2.value() == expected_output_2



# Generated at 2022-06-25 23:30:58.467960
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test if method to_lazy returns correct value.
    """
    box_value = Box('Hello, world!')
    res = box_value.to_lazy()
    expected_res = 'Hello, world!'
    assert res.value() == expected_res, 'Test failed!'

# Generated at 2022-06-25 23:31:02.110275
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    
    assert Lazy(lambda: 1).equal(Box(1).to_lazy())

# Generated at 2022-06-25 23:31:05.202376
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = Box(0)
    lazy_0 = int_0.to_lazy()
    assert lazy_0.fold() == 0


# Generated at 2022-06-25 23:31:09.967117
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = Box(0).to_lazy()
    assert lazy_0.fold() == 0
    assert Box(lazy_0.fold()).map(lambda x: x + 1).fold() == 1
    assert Box(lazy_0.fold()).ap(Box(lambda x: x + 1)).fold() == 1


# Generated at 2022-06-25 23:31:13.971951
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = Box(0)
    assert(Lazy(lambda: int_0.value) == int_0.to_lazy())

test_case_0()

test_Box_to_lazy()

# Generated at 2022-06-25 23:31:17.781510
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    def func():
        return 1
    box = Box(func)

    # when
    result = box.to_lazy()

    # then
    assert result.func() == 1


# Generated at 2022-06-25 23:31:34.630533
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box(42).to_lazy() != Lazy(lambda: 24)

    try:
        Box(42).to_lazy()
    except:  # pragma: no cover
        assert False

# Generated at 2022-06-25 23:31:38.439554
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 0
    box = Box(value)
    result = box.to_lazy()
    try:
        assert callable(result.value)
    except:
        raise Exception("Error in test_Box_to_lazy().\nExpected: callable\nActual: not callable")


# Generated at 2022-06-25 23:31:43.943447
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # arrange
    int_0 = 0
    # act
    box_int_0 = Box(int_0)
    lazy_int_0 = box_int_0.to_lazy()
    # assert
    assert lazy_int_0.fold() == int_0


# Generated at 2022-06-25 23:31:48.175390
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    lazy = Box(int_0)
    assert lazy.to_lazy() == int_0, "Error"
    print ("test_Box_to_lazy: ", lazy)


# Generated at 2022-06-25 23:31:50.620687
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_a = Box(0)
    assert box_a.to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-25 23:31:54.979243
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    Box_0 = Box(int_0)
    Lazy_1 = Box_0.to_lazy()
    assert Lazy_1.is_folded is False
    result_2 = Lazy_1.get_value()
    assert result_2 == int_0


# Generated at 2022-06-25 23:31:58.585709
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    t_0 = Box(lambda: 1)
    t_1 = t_0.to_lazy()

    assert isinstance(t_1, Box)
    assert t_1.value() == 1

test_case_0()


# Generated at 2022-06-25 23:32:00.754957
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    lazy_int_0 = Box(int_0).to_lazy()
    assert lazy_int_0.value() == int_0


# Generated at 2022-06-25 23:32:03.980673
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case = Box(int_0)

    from pymonet.lazy import Lazy

    expected = Lazy(lambda: int_0)
    result = test_case.to_lazy()

    assert expected == result


# Generated at 2022-06-25 23:32:07.349991
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box([0, 1, 2]).to_lazy() == Lazy([0, 1, 2])
    assert Box(2).to_lazy() == Lazy(2)
    assert Box(True).to_lazy() == Lazy(True)


# Generated at 2022-06-25 23:32:27.776784
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    newLazy = Lazy(lambda: 0)
    box = Box(0)
    assert box.to_lazy().fold(lambda: int_0()) == newLazy.fold(lambda: int_0())


# Generated at 2022-06-25 23:32:33.428477
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Create Int
    int_0 = Box(0)

    # Access to_lazy in Int
    lazy_0 = int_0.to_lazy()

    # Check for correct unwrap
    result_correct = lazy_0 == Lazy(lambda: 0)

    # Check for incorrect unwrap
    result_incorrect = lazy_0 == Lazy(lambda: 1) or \
                       lazy_0 == Lazy(lambda: 2)

    # Return test result
    return result_correct and not result_incorrect


# Generated at 2022-06-25 23:32:34.844304
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0

    assert Box(int_0).to_lazy().eager is int_0

# Generated at 2022-06-25 23:32:41.203180
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    int_1 = 1

    def test_case_0():
        box_0 = Box(int_0)
        lazy_0 = box_0.to_lazy()
        assert lazy_0.get_value_or(int_1) is int_0

    def test_case_1():
        box_0 = Box(int_1)
        lazy_0 = box_0.to_lazy()
        assert lazy_0.get_value_or(int_0) is int_1


# Generated at 2022-06-25 23:32:43.307187
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    box_int_0 = Box(int_0)
    assert box_int_0.to_lazy().value() == int_0


# Generated at 2022-06-25 23:32:47.651639
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # testcase: Lazy((lambda: 1))
    assert Box(1).to_lazy().to_function()() == 1
    # testcase: Lazy((lambda: ((lambda: 0)())))
    assert Box(test_case_0).to_lazy().to_function()() == 0


# Generated at 2022-06-25 23:32:52.672586
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Testing Box to_lazy method
    """
    # using Box(0) as Box monad
    box_0 = Box(0)

    # using Box.to_lazy function to transform Box monad into Lazy monad
    lazy_0 = box_0.to_lazy()

    # using map function of lazy to inc value
    lazy_1 = lazy_0.map(lambda x: x + 1)

    assert lazy_1.value() == 1

# Generated at 2022-06-25 23:32:53.279205
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy() == Lazy(lambda: 42)



# Generated at 2022-06-25 23:33:01.744621
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Box
    from pymonet.monad_except import Try
    from pymonet.monad_maybe import Maybe

    # Try[Maybe[int]] -> Lazy[int]
    result = Try(Maybe.just(1)).to_lazy()
    assert isinstance(result, Lazy)
    assert result.fold() == 1

    # Maybe[int] -> Lazy[int]
    result = Maybe.just(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.fold() == 1

    # Box[int] -> Lazy[int]
    result = Box(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.fold() == 1

    # Box[

# Generated at 2022-06-25 23:33:05.860720
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = Box(0)

    lazy_box = int_0.to_lazy()

    assert isinstance(lazy_box, Lazy)

    assert lazy_box.get_value()() == 0

    string_box = Box('park')

    assert string_box.to_lazy().get_value()() == 'park'


# Generated at 2022-06-25 23:33:48.036286
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    empty_box = Box(None)
    lazy_1 = Lazy(lambda: 1)
    lazy_str = Lazy(lambda: 'str')

    assert empty_box.to_lazy() == Lazy(lambda: None)
    assert lazy_1.to_lazy() == Lazy(lambda: 1)
    assert lazy_str.to_lazy() == Lazy(lambda: 'str')


# Generated at 2022-06-25 23:33:50.116349
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    a = Box[int](1)
    b = Lazy(lambda: 1)
    assert a.to_lazy() == b


# Generated at 2022-06-25 23:33:51.397713
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(3)
    assert 3 == box.to_lazy().fold()


# Generated at 2022-06-25 23:33:52.634342
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-25 23:33:55.561369
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    test_lazy = Box(10).to_lazy()
    assert isinstance(test_lazy, Lazy)
    assert test_lazy.is_folded is False


# Generated at 2022-06-25 23:34:02.111767
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    # Given
    int_0 = Box(0)

    # When
    lazy_value = int_0.to_lazy()

    # Then
    assert isinstance(lazy_value, Lazy)
    assert int_0 == Box(lazy_value.value())


# Generated at 2022-06-25 23:34:05.047934
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    print('####### Test for Box to_lazy method')
    # Arrange
    value = Box(1)

    # Act
    result = value.to_lazy()

    # Assert
    assert result.value

# Generated at 2022-06-25 23:34:09.029498
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()
    test_int_0 = 0
    test_box_0 = Box(test_int_0)
    test_Lazy_0 = test_box_0.to_lazy()
    test_value_0 = test_Lazy_0.fold()
    assert test_value_0 is 0


# Generated at 2022-06-25 23:34:13.768930
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().call() == 1
    assert Box("1").to_lazy().call() == "1"
    assert Box(False).to_lazy().call() == False
    assert Box(test_case_0).to_lazy().call() == test_case_0


# Generated at 2022-06-25 23:34:15.263131
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(0).to_lazy() == Lazy(lambda:0)



# Generated at 2022-06-25 23:35:36.654954
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-25 23:35:39.124181
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 0) == Box(0).to_lazy()
    assert Box(0).to_lazy().is_folded



# Generated at 2022-06-25 23:35:40.678220
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    obj = Box(int_0)
    lazy_obj = obj.to_lazy()
    assert lazy_obj.force() is int_0


# Generated at 2022-06-25 23:35:43.940087
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    box = Box(Try(True, is_success=True))

    lazy = box.to_lazy()
    assert type(lazy) is Lazy
    assert lazy.fold().value is True

# Generated at 2022-06-25 23:35:45.750666
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 2) == Box(2).to_lazy()



# Generated at 2022-06-25 23:35:53.270549
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.math import add_lazy, multiply_lazy
    from pymonet.box import Box

    # --- Define lazy values ---
    lazy_value_1 = Lazy(lambda: 10 + 1)
    lazy_value_2 = Lazy(lambda: 20 * 2)

    # --- Define lazy operations ---
    lazy_operation_1 = add_lazy(lazy_value_1, lazy_value_2)
    lazy_operation_2 = multiply_lazy(lazy_value_1, lazy_value_2)

    # --- Apply Box value to Lazy operations ---
    Box(40).to_lazy().ap(lazy_operation_1)
    Box(40).to_lazy().ap(lazy_operation_2)

# Generated at 2022-06-25 23:35:55.247841
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = Box(0)
    int_0.to_lazy().get() == 0


# Generated at 2022-06-25 23:35:57.922764
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_10 = 10

    box = Box(int_10)
    lazy = box.to_lazy()

    # In case of lazy.value is function
    assert callable(lazy.value)

    assert int_10 == lazy.value()

# Generated at 2022-06-25 23:36:05.125476
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    int_0 = 0
    int_pos = 1
    int_neg = -1
    str_empty = ''
    str_non_empty = 'a'
    list_empty = []
    list_non_empty = [1, 2]
    bool_false = False
    bool_true = True

    # when
    box_0 = Box(int_0)
    box_pos = Box(int_pos)
    box_neg = Box(int_neg)
    box_str_empty = Box(str_empty)
    box_str_non_empty = Box(str_non_empty)
    box_list_empty = Box(list_empty)
    box_list_non_empty = Box(list_non_empty)
    box_bool_false = Box(bool_false)
    box_

# Generated at 2022-06-25 23:36:12.021894
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    # Setup
    int_0 = 0
    int_1 = 1

    # Verify
    lazy_int_0 = Box(int_0).to_lazy()
    assert isinstance(lazy_int_0, Lazy) and isinstance(lazy_int_0, Monad) and lazy_int_0 == Lazy(lambda: int_0)
    lazy_int_1 = Box(int_1).to_lazy()
    assert isinstance(lazy_int_1, Lazy) and isinstance(lazy_int_1, Monad) and lazy_int_1 == Lazy(lambda: int_1)
    
