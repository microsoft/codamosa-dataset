

# Generated at 2022-06-25 23:27:32.615331
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    var_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:27:35.035368
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_lazy = Box(42).to_lazy()
    assert box_lazy == Lazy(lambda: 42)

# Generated at 2022-06-25 23:27:38.077990
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'i-OK4E/;Bw\nN@iY^5S5'
    box_0 = Box(str_0)
    box_1 = box_0.to_lazy()


# Generated at 2022-06-25 23:27:47.590319
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Test special method to_lazy"""
    print("Unit test for method to_lazy of class Box")

    # str_0 = 'UMkH1Hu)\r"&"O@\x0chiI/'
    # box_0 = Box(str_0)
    # var_0 = box_0.to_lazy()
    #
    # str_1 = 'v/\n\x1e\x1c,{I<xn_}.'
    # box_1 = Box(str_1)
    # var_1 = box_1.to_lazy()
    #
    # str_2 = 'W!!9}0v?c0\x1e\x19\x0b\x1b'
    # box_2 = Box(str_2)
    # var_2 =

# Generated at 2022-06-25 23:27:50.100961
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None


# Generated at 2022-06-25 23:27:58.871316
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'UMkH1Hu)\r"&"O@\x0chiI/'
    box_0 = Box(str_0)
    var_0 = box_0.to_lazy()
    var_1 = var_0.get()
    var_2 = var_1()
    assert var_2 == str_0
    str_1 = 't_0.value'
    str_2 = 'assert %s == %s' % (str_1, str_0)
    exec(str_2)
    var_3 = var_0 is not None
    str_3 = 'var_0 is not None'
    str_4 = 'assert %s' % (str_3)
    exec(str_4)
    var_4 = var

# Generated at 2022-06-25 23:28:05.994801
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '&vhRrNr\r!NdW3:)wv\x0c'
    box_0 = Box(str_0)
    str_1 = '&vhRrNr\r!NdW3:)wv\x0c'
    assert box_0 == Box(str_1)


# Generated at 2022-06-25 23:28:17.235356
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'b\x0b\x17\x1bJ\x1e"'
    box_0 = Box(str_0)
    str_1 = 'H\x0f+\x1b\x1f\x1e\x18B'
    box_1 = Box(str_1)
    assert not box_0 == box_1

    str_2 = 'b\x0b\x17\x1bJ\x1e"'
    box_2 = Box(str_2)
    str_3 = 'b\x0b\x17\x1bJ\x1e"'
    box_3 = Box(str_3)
    assert box_2 == box_3


# Generated at 2022-06-25 23:28:26.117290
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    def outer_0(x):
        print(x)
        return x

    class ClassDef_0:
        def __init__(self, val_0):
            self.val_0 = val_0

        def __eq__(self, other):
            return isinstance(other, ClassDef_0) and self.val_0 == other.val_0

        def __str__(self):
            return 'ClassDef_0[val_0={}]'.format(self.val_0)

    class_inst_0 = ClassDef_0(39)
    class_inst_1 = ClassDef_0(50)
    box_0 = Box(class_inst_0)

# Generated at 2022-06-25 23:28:30.118283
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = Box(0.58)
    var_1 = Box(0.15)
    var_2 = Box(0.58)
    assert var_0 == var_2
    assert not var_0 == var_1


# Generated at 2022-06-25 23:28:41.323572
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit-test for method to_lazy of class Box
    """
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    ll = Box('Hello!').to_lazy()  # type: Lazy[Callable[[], str]]
    assert ll.value() == 'Hello!'
    assert isinstance(ll, Lazy)

    lll = Box('Hello!').to_maybe()  # type: Maybe[str]
    assert lll.value == 'Hello!'
    assert isinstance(lll, Maybe)

    llll = Box('Hello!').to_either()  # type: Right[str]

# Generated at 2022-06-25 23:28:45.940196
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x1c\r\x11\x04\r\r\r\x13\x0c\x1a\x18\x01'
    box_0 = Box(str_0)
    lazy = box_0.to_lazy()
    assert str_0 == lazy.value()


# Generated at 2022-06-25 23:28:56.955351
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    assert box_0 == Box(str_0), 'Box___eq__ test #0 failed'
    data_0 = box_0.to_lazy()
    data_1 = box_0.to_either()
    data_2 = box_0.to_maybe()
    data_3 = box_0.to_try()
    data_4 = box_0.to_validation()

# Generated at 2022-06-25 23:29:04.040153
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    str_1 = '\x15\x17\r\x1c\x0e\x18'
    str_2 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    box_1 = Box(str_2)
    assert box_0 == box_1, 'box_0.__eq__(box_1) failed'


# Generated at 2022-06-25 23:29:05.159012
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-25 23:29:06.574312
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box0 = Box(str_0)
    lazy_0 = box0.to_lazy()


# Generated at 2022-06-25 23:29:16.691979
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    str_1 = '\x15\x17\r\x1c\x0e\x18'
    box_1 = Box(str_1)
    if box_0 == box_1 is not True:
        exit(1)
    int_0 = 733922
    box_2 = Box(int_0)
    str_2 = '\x15\x17\r\x1c\x0e\x18'
    box_3 = Box(str_2)
    if box_2 == box_3 is True:
        exit(1)
    bool_0 = True
    box_4 = Box(bool_0)
    int_

# Generated at 2022-06-25 23:29:24.324541
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    str_1 = '\x15\x17\r\x1c\x0e\x18'
    lazy_0 = box_0.to_lazy()
    assert str_1 == lazy_0.get_value()
    str_2 = '\x15\x17\r\x1c\x0e\x18'
    str_3 = '\x15\x17\r\x1c\x0e\x18'
    lazy_1 = box_0.map(lambda str_0: str_0)
    str_4 = '\x15\x17\r\x1c\x0e\x18'
   

# Generated at 2022-06-25 23:29:35.230542
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '\x0c\x07\x15\x12\x0c\x1f\x0e\x19\x0c\x15\x18\x04\x0e\x13\x1a\x0e\x12\x0b\x0e\x1e'
    str_1 = '\x0f\x1b\x14\x10\x1c\x0e\x07\x08\x0b\x19\x0e\x1a'
    box_0 = Box(str_0)
    b = box_0.__eq__(box_0)
    assert b is True
    box_1 = Box(str_1)
    b = box_0.__eq__(box_1)
    assert b is False



# Generated at 2022-06-25 23:29:44.490841
# Unit test for method __eq__ of class Box

# Generated at 2022-06-25 23:29:48.991437
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)

    assert callable(box_0.to_lazy())


# Generated at 2022-06-25 23:29:50.072586
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = Box({'A': 'B'}).to_lazy()


# Generated at 2022-06-25 23:29:52.362137
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.get_value() == str_0


# Generated at 2022-06-25 23:30:02.199303
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from pymonet.validation import Validation
    from pymonet.tuple import Tuple2

    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = Lazy(lambda: str_0)
    lazy_1 = box_0.to_lazy()

    str_1 = '1\r8\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r'
    box_1 = Box(str_1)
    lazy_2

# Generated at 2022-06-25 23:30:06.489020
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_func = lambda: '\x15\x17\r\x1c\x0e\x18'
    result = Box(lazy_func).to_lazy()
    assert isinstance(result, Lazy)
    assert result.is_folded is False


# Generated at 2022-06-25 23:30:10.552172
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    str_1 = box_0.to_lazy().get()
    assert not str_1.is_empty()
    assert str_1.value == str_0


# Generated at 2022-06-25 23:30:13.213732
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_val()
    assert lazy_0.val == str_0


# Generated at 2022-06-25 23:30:17.092291
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.get()
    assert str_0 == str_1


# Generated at 2022-06-25 23:30:20.219549
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(str)
    lazy_1 = box_0.to_lazy()
    lazy_result_0 = lazy_1.fold(lambda: int)
    assert lazy_result_0 == str



# Generated at 2022-06-25 23:30:24.402647
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    val_0 = Box('\x18\x1f\x10\x02\x0f')
    lazy_0 = Lazy(lambda: '\x18\x1f\x10\x02\x0f')
    assert val_0.to_lazy() == lazy_0

# Generated at 2022-06-25 23:30:32.773778
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    str_0 = '\'\x14\x0b\r\t\r\t\r'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_0, Functor)
    assert str_0 == lazy_0.value()


# Generated at 2022-06-25 23:30:38.040718
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad import assert_that
    from pymonet.lazy import Lazy
    from pymonet.monad_builder import unit

    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert_that(lazy_0).is_instance_of(Lazy)
    value_0 = lazy_0()
    assert_that(value_0).is_equal_to(str_0)
    expect_1 = unit(str_0)
    assert_that(lazy_0).is_equal_to(expect_1())


# Generated at 2022-06-25 23:30:42.117945
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x1d'
    box_0 = Box(str_0)
    str_1 = box_0.to_lazy().bind(lambda x: x())
    assert str_0 is str_1


# Generated at 2022-06-25 23:30:47.924347
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    assert str_0 == box_0.value
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == str_0, 'lazy_0.value() not equals to box_0.value'


# Generated at 2022-06-25 23:30:56.835101
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    func_0 = (lambda x: [x, x])
    func_1 = (lambda x: [x, x])
    func_2 = (lambda x: [x, x])
    func_3 = (lambda x: x)
    func_4 = (lambda x: x)
    func_5 = (lambda x: x)
    func_6 = (lambda x: x)
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    str_1 = '\x15\x17\r\x1c\x0e\x18'
    str_2 = '\x15\x17\r\x1c\x0e\x18'

# Generated at 2022-06-25 23:31:04.330527
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '!\xa6\x81\x08\xa2\xd6'
    int_0 = 13
    assert Box(str_0).to_lazy() == Box(str_0).bind(lambda value: Lazy(lambda: value))
    assert Box(int_0).to_lazy() == Box(int_0).bind(lambda value: Lazy(lambda: value))


# Generated at 2022-06-25 23:31:09.007692
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_str_0 = '\x07\x06\x15\x1e\x1d\x19\x01\x1f\x11'
    test_box_0 = Box(test_str_0)
    test_box_0.to_lazy()


# Generated at 2022-06-25 23:31:14.362436
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\x19\x17\n\t\x1c\x0f'
    box_0 = Box(str_0)
    res_3 = box_0.to_lazy()
    assert res_3.get() == str_0


# Generated at 2022-06-25 23:31:20.264873
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    lazy_1 = lazy_0.map(str)
    str_1 = lazy_1.force()
    assert str_1 == str_0


# Generated at 2022-06-25 23:31:26.130147
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # First test
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)

    assert box_0.to_lazy() == Lazy(lambda: str_0)



# Generated at 2022-06-25 23:31:36.785171
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = Box('\x13\x01\x15\x05\x0b\x14\x15\x00\x1a\x0c\x00\x01\x09\x0b').to_lazy()
    def func_0(num_0):
        return num_0 ** num_0
    assert func_0(lazy_0.value()) == 34359738368


# Generated at 2022-06-25 23:31:40.795817
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    assert box_0.to_lazy().apply() == str_0


# Generated at 2022-06-25 23:31:43.734690
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(Box(25))
    value_0 = box_0.to_lazy()
    assert not callable(value_0)


# Generated at 2022-06-25 23:31:49.131951
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    assert box_0.to_lazy() == Lazy(lambda: str_0)

# Generated at 2022-06-25 23:31:53.706561
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    actual_0 = lazy_0.value()
    assert actual_0 == str_0


# Generated at 2022-06-25 23:31:56.788845
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = -1225
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.box.value() == int_0


# Generated at 2022-06-25 23:32:00.637084
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(100)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 100



# Generated at 2022-06-25 23:32:04.836930
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:32:05.679574
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    pass


# Generated at 2022-06-25 23:32:11.527495
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Define get_bytes of type function() -> Box[bytes] with function literal
    get_bytes = lambda: Box(b'\x15\x17\r\x1c\x0e\x18')

    # Create lazy_box of type Lazy[Box[bytes]] and invoke method to_lazy with argument value get_bytes
    lazy_box: Lazy[Box[bytes]] = get_bytes().to_lazy()

    # Verify that lazy_box.value is equals to Box(b'\x15\x17\r\x1c\x0e\x18')
    assert lazy_box.value == Box(b'\x15\x17\r\x1c\x0e\x18')



# Generated at 2022-06-25 23:32:20.821444
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '5\x06\x16\x17\x1f\x0f\x06\x1c\x1d'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    int_0 = lazy_0.get()
    str_1 = str(int_0)
    assert str_1 == str_0


# Generated at 2022-06-25 23:32:24.699445
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_1 = box_0.to_lazy()
    str_2 = lazy_1.value()

    assert str_0 == str_2


# Generated at 2022-06-25 23:32:28.074146
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    def func():
        return '\x15Z\x12\x1d\x0e\x16'

    box_0 = Box('\x15Z\x12\x1d\x0e\x16')

    assert box_0.to_lazy() == Lazy(func).to_lazy()

# Generated at 2022-06-25 23:32:32.518721
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'

    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.value()

    assert str_1 == str_0, f'Expected:{str_0}, Actual:{str_1}'



# Generated at 2022-06-25 23:32:36.975527
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_list import List
    from pymonet.lazy import Lazy
    box_0 = Box('\x0e\x06')
    lazy_1 = box_0.to_lazy()
    assert lazy_1.is_folded() is False
    str_0 = lazy_1.force()
    assert str_0 == '\x0e\x06'



# Generated at 2022-06-25 23:32:39.665874
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    buffer = []
    buf_0 = buffer
    lazy_0 = Box('\x10\x1f\x1c').to_lazy()

    assert lazy_0.memo == buf_0



# Generated at 2022-06-25 23:32:44.000617
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)

    assert(box_0.to_lazy() == Lazy(lambda: str_0))

# # Unit test for method to_maybe of class Box

# Generated at 2022-06-25 23:32:49.287010
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)

    result = box_0.to_lazy()

    if Lazy.is_instance(result):
        print("All ok")
    else:
        print("Error")



# Generated at 2022-06-25 23:32:58.058697
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('\x15\x17\r\x1c\x0e\x18').to_lazy().value() == '\x15\x17\r\x1c\x0e\x18'
    assert Box(None).to_lazy().value() is None
    assert Box(None).to_lazy().value() is None
    assert Box(None).to_lazy().value() is None
    assert Box(None).to_lazy().value() is None
    assert Box(None).to_lazy().value() is None
    assert Box(None).to_lazy().value() is None
    assert Box(None).to_lazy().value() is None
    assert Box(None).to_lazy().value() is None
    assert Box(None).to_lazy().value() is None
   

# Generated at 2022-06-25 23:33:00.732600
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    assert box_0.to_lazy().value() == str_0


# Generated at 2022-06-25 23:33:12.792435
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    result = box_0.to_lazy()
    assert result.value() == box_0.value


# Generated at 2022-06-25 23:33:16.478243
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_3 = '\x08\r'
    box_1 = Box(str_3)
    lazy_0 = box_1.to_lazy()
    str_4 = lazy_0.get()
    assert str_4 == '\x08\r'



# Generated at 2022-06-25 23:33:20.277930
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    result_0 = lazy_0.get()
    assert result_0 == str_0



# Generated at 2022-06-25 23:33:22.748381
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    @Lazy
    def lazy_0():
        Box('\x17\r').to_lazy()
    assert lazy_0.value() == Box('\x17\r').to_lazy().value


# Generated at 2022-06-25 23:33:26.741487
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = box_0.to_lazy()
    str_0 = 'v\x11KW8x\x11\x1b\x1c\x07\x0e\x1c\x1f\x1d\x03\x16\x1b'
    assert str(lazy_0.value) == str_0


# Generated at 2022-06-25 23:33:29.915231
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(2.3578610771693316)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded() is False
    assert isinstance(lazy_0.get(), float) is True


# Generated at 2022-06-25 23:33:33.794347
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = '\x1e\x0e\x09\x19\x07\x0d\x09'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert callable(lazy_0)


# Generated at 2022-06-25 23:33:37.999363
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_identity import Identity
    from nose.tools import assert_equals
    from random import randint

    value = randint(0, 100000)
    box = Box(value)
    assert_equals(box.to_lazy(), Lazy(lambda: value))
    assert_equals(box.to_lazy().to_identity(), Identity(value))



# Generated at 2022-06-25 23:33:41.495922
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.function import id

    for value in ['\x15\x17\r\x1c\x0e\x18', 5, True, (1, 2, 3), []]:
        assert Box(value).to_lazy() == Lazy(value)
        assert Box(value).to_lazy() == Lazy(id)[value]


# Generated at 2022-06-25 23:33:44.096144
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    assert box_0.to_lazy().is_folded() == False


# Generated at 2022-06-25 23:34:14.363189
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    bool_0 = isinstance(lazy_0, Lazy)
    str_1 = '\x01\x1b\x13\x0f\x10\x18\x01\x0f\x1c\x1b\x0f\x0e\x1b'
    lazy_0 = lazy_0.map(lambda value_0: value_0.upper())

# Generated at 2022-06-25 23:34:17.439204
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.value()


# Generated at 2022-06-25 23:34:25.362050
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:34:30.357428
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert(lazy_0.value() == str_0)


# Generated at 2022-06-25 23:34:37.072003
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    # Invoke method to_lazy of class Box with instance box_0
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:34:45.266277
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = '\x11\x1d\x0d\x03\x16\x0e'
    lazy_1 = lazy_0.map(str_1)
    str_2 = '\x0f\x16\r\x19\x1f\x0d'
    lazy_2 = lazy_1.ap(Box(str_2))
    str_3 = 'R\x00-\x13\x1c\x0f\x06\x03\x1b\x0f\x1a\x06@'
    assert str_3 == lazy_

# Generated at 2022-06-25 23:34:51.869358
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\x1a\x07\x13\n\x0c\x14\x19B\x1c\x066\x0f\x11'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:34:53.390032
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = Box(4).to_lazy()



# Generated at 2022-06-25 23:34:55.710593
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_box = Box(str)

    assert str_box.to_lazy().value()(str) == str



# Generated at 2022-06-25 23:34:59.317635
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'v\x13!E\x1a'
    list_0 = ['9', 'T\x85', 'w\x0fN\x1b', '\x1c']
    box_0 = Box(str_0)
    lazy_2 = box_0.to_lazy()


# Generated at 2022-06-25 23:35:50.829390
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from string import ascii_lowercase, ascii_uppercase
    from pymonet.utils import randstr, randstr_with_spec_chars
    from pymonet.lazy import Lazy
    for __ in range(100):
        str_0 = randstr(ascii_lowercase+ascii_uppercase)
        box_0 = Box(str_0)
        lazy_0 = box_0.to_lazy()
        str_1 = lazy_0.unsafe_eval()
        assert str_0 == str_1


# Generated at 2022-06-25 23:35:51.778854
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-25 23:35:57.990616
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    class_0 = str.upper
    box_1 = box_0.map(class_0)
    class_1 = str.lower
    test_box_0 = box_1.map(class_1)
    lazy_0 = test_box_0.to_lazy()
    test_box_1 = lazy_0.to_box()
    #assert(test_box_0 == test_box_1)



# Generated at 2022-06-25 23:36:01.937407
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x14\x15\n\x1d\x1f\t\n\x18\x19\x1a\x10\x1c\x1d\x1c\r\r\r\r\r\r'
    box_0 = Box(str_0)
    box_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:36:04.866950
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x1b\x1a'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()
    isinstance(lazy_0, Lazy)
    assert box_0.value == lazy_0.resolve()

# Generated at 2022-06-25 23:36:08.912757
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded == False
    assert lazy_0.value() == str_0
    assert lazy_0.is_folded == True


# Generated at 2022-06-25 23:36:10.305881
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(10)
    assert box_0.to_lazy().value() == 10


# Generated at 2022-06-25 23:36:18.113775
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import LazyFactory
    """
    Transforms box into lazy monad.

    :returns: lazy monad with value of current box
    :rtype: Lazy[A]
    """
    from pymonet.lazy import Lazy


# Generated at 2022-06-25 23:36:22.621654
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for to_lazy method of class Box.

    """
    str2 = '\x02\x03'
    lazy2 = Box(str2).to_lazy()
    assert isinstance(lazy2.value, Callable), "Box.to_lazy() return not Callable type"



# Generated at 2022-06-25 23:36:30.899847
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\x15\x17\r\x1c\x0e\x18'
    str_1 = '\x02\x01\x0e\x19\x1d\x05'
    int_0 = 164
    int_1 = 0
    float_0 = 1.23
    float_1 = 1.234
    float_2 = 3.2
    float_3 = 2.9
    float_4 = 9.8
    float_5 = 7.1
    box_0 = Box(str_0)
    box_1 = Box(str_1)
    box_2 = Box(int_0)
    box_3 = Box(int_1)
    box_4 = Box(float_0)
    box_5 = Box(float_1)
    box_6