

# Generated at 2022-06-25 23:27:32.313993
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.value == str_0



# Generated at 2022-06-25 23:27:36.231107
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    box_1 = Box(str_0)
    box_2 = Box('Sum[value={}]')
    assert box_0 == box_1 and not box_0 == box_2


# Generated at 2022-06-25 23:27:40.614682
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(7).to_lazy() == Lazy(lambda: 7)
    assert Box(Try(7)).to_lazy() == Lazy(lambda: Try(7, is_success=True))


# Generated at 2022-06-25 23:27:44.757637
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value == 1 and Box({'a': 1}).to_lazy().value == {'a': 1} and Box((1, {'a': 1}, [1, 2])).to_lazy().value == (1, {'a': 1}, [1, 2])


# Generated at 2022-06-25 23:27:49.048843
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    box_1 = Box(str_0)
    box_2 = Box(str_0)
    assert box_0 == box_0
    assert box_0 == box_1
    assert box_1 == box_2


# Generated at 2022-06-25 23:27:54.681288
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    expected_1 = Lazy(lambda: 'Sum[value={}]')

    box_lazy_2 = box_0.to_lazy()

    assert box_lazy_2 == expected_1, f"Expected: {expected_1}, got: {box_lazy_2}"


# Generated at 2022-06-25 23:27:59.029893
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 'Sum[value={}]'
    box_0 = Box(value)

    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_folded() is False
    assert lazy_0.get_value() == value


# Generated at 2022-06-25 23:28:10.533036
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box('')
    box_1 = Box('a')
    box_2 = Box(0)
    box_3 = Box(1)
    box_4 = Box('')
    box_5 = Box('a')
    box_6 = Box(0)
    box_7 = Box(1)
    box_8 = Box(())
    box_9 = Box((0,))
    box_10 = Box([])
    box_11 = Box([1])
    box_12 = Box({})
    box_13 = Box({0: 1})
    box_14 = Box('')
    box_15 = Box('a')
    box_16 = Box(0)
    box_17 = Box(1)
    box_18 = Box([])

# Generated at 2022-06-25 23:28:13.337609
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    lazy = box_0.to_lazy()
    assert lazy.value() == str_0

# Generated at 2022-06-25 23:28:16.022703
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box(3)
    assert box_0 == Box(3)
    assert box_0 != Box(4)



# Generated at 2022-06-25 23:28:22.779462
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    lazy_1 = lazy_0.map_lazy(lambda x: x.format(3))
    assert lazy_1.resolve() == 'Sum[value=3]'


# Generated at 2022-06-25 23:28:28.180959
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    box_1 = Box(str_0)

    try:
        assert box_0.__eq__(box_1)
    except AssertionError:
        print('Test failed')
        return
    print('Test passed')


# Generated at 2022-06-25 23:28:32.204124
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    box_1 = Box(str_0)
    box_2 = Box(str_0 + '0')
    assert box_0 == box_1
    assert not box_0 == box_2


# Generated at 2022-06-25 23:28:33.567103
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('123') == Box('123')



# Generated at 2022-06-25 23:28:36.928763
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box(str)
    box_1 = Box(str)
    assert box_0 == box_1
    box_2 = Box(lambda _: 'a')
    assert box_0 != box_2


# Generated at 2022-06-25 23:28:38.471702
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert(str_0 == lazy_0.value())
    assert(str_0 == str_0.format(10))


# Generated at 2022-06-25 23:28:41.506789
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    assert box_0.to_lazy() == Lazy(lambda: str_0)
    assert box_0.to_lazy().get() == str_0



# Generated at 2022-06-25 23:28:45.491723
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    assert box_0.to_lazy().map(lambda x: x()).get_value() == str_0


# Generated at 2022-06-25 23:28:48.556673
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # case 0
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)

    assert box_0.to_lazy().fold()() == str_0

# Generated at 2022-06-25 23:28:55.906425
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    box_1 = Box(str_0)
    box_2 = Box('Sum[value={}]')

    assert box_0 is not box_1
    assert box_0 == box_1
    assert box_0 != box_2


# Generated at 2022-06-25 23:29:02.552519
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_lazy import LazyMonad

    expected = Lazy("Sum[value={}]")
    actual = Box("Sum[value={}]").to_lazy()

    assert actual == expected
    assert isinstance(actual, LazyMonad)



# Generated at 2022-06-25 23:29:05.902813
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(42).to_lazy()
    # Case 0: it will be exec
    assert lazy.fold() == 42
    # Case 1: it will be exec
    assert lazy.fold() == 42
    # Case 2: it will be exec
    assert lazy.fold() == 42


# Generated at 2022-06-25 23:29:13.607680
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method.
    """
    from pymonet.lazy import Lazy

    #

    a = 1
    a_box = Box(a)
    a_lazy = a_box.to_lazy()
    assert a_lazy.is_folded is False
    assert a_lazy.value() == a


# Generated at 2022-06-25 23:29:16.943898
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold() == str_0


# Generated at 2022-06-25 23:29:20.603437
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'X'
    str_1 = str_0

    box_0 = Box(str_0)
    maybe_0 = box_0.to_lazy()
    maybe_1 = maybe_0.get_value()
    str_2 = maybe_1()

    assert str_1 == str_2

# Generated at 2022-06-25 23:29:25.150559
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(8)
    box_1 = box_0.to_lazy()

    assert isinstance(box_1, Lazy)
    assert box_1() == 8


# Generated at 2022-06-25 23:29:27.028740
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 'a') == Box('a').to_lazy()



# Generated at 2022-06-25 23:29:31.382604
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box(1)

    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.fold(lambda: None) == 1


# Generated at 2022-06-25 23:29:36.499078
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def str_0(a):
        return str(a)

    str_1 = 'Sum[value={}]'
    box_0 = Box(str_1)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold(str_0) == str_1


# Generated at 2022-06-25 23:29:41.937724
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    class BoxValue(Box[T]):
        def __init__(self, value) -> None:
            self.value = value
    box_a = BoxValue('a')
    def box_bind_mapper(value):
        box = BoxValue(value * 2)
        return box
    box_result = box_a.bind(box_bind_mapper)
    assert (box_result.value == 'aa') 



# Generated at 2022-06-25 23:29:45.166465
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold() == 1


# Generated at 2022-06-25 23:29:53.797277
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    str_4 = 'e'
    str_5 = 'f'
    str_6 = 'g'
    str_7 = 'h'
    str_8 = 'i'
    str_9 = 'j'

    # Create Box object
    box = Box(str_0)

    assert box.value == str_0

    # Transform Box into Lazy and get new value
    lazy = box.to_lazy()

    assert lazy.value() == str_0
    assert lazy.map(lambda str: str + str_1).value() == str_0 + str_1
    assert lazy.map(lambda str: str + str_1 + str_2).value() == str

# Generated at 2022-06-25 23:29:56.439027
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return str_0

    assert Box(str_0).to_lazy() == Lazy(func)


# Generated at 2022-06-25 23:29:59.135079
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('a').to_lazy() == Lazy(lambda: 'a')


# Generated at 2022-06-25 23:30:02.558930
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_not_folded = Box('a').to_lazy()
    assert lazy_not_folded == Lazy(lambda: 'a')
    assert lazy_not_folded.fold() == 'a'



# Generated at 2022-06-25 23:30:06.191368
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = 'a'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:30:14.479898
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    str_0 = 'a'
    assert Box(str_0).to_lazy() == Lazy(lambda: str_0)

    str_1 = 'b'
    assert Box(str_1).to_lazy() == Lazy(lambda: str_1)

    int_0 = 1
    assert Box(int_0).to_lazy() == Lazy(lambda: int_0)

    int_1 = 2
    assert Box(int_1).to_lazy() == Lazy(lambda: int_1)

    float_0 = 1
    assert Box(float_0).to_lazy() == Lazy(lambda: float_0)

    float_

# Generated at 2022-06-25 23:30:18.606707
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    _Box = Box(str_0)
    _Lazy = _Box.to_lazy()

    assert str(_Lazy) == 'Lazy[value: <function _Box.to_lazy.<locals>.<lambda> at 0x1021b0d90>]'

# Generated at 2022-06-25 23:30:20.874801
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    obj = Lazy(lambda: 'a')

    assert obj == Box('a').to_lazy()


# Generated at 2022-06-25 23:30:22.638715
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('a').to_lazy().unwrap() == 'a'


# Generated at 2022-06-25 23:30:30.316832
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    string = 'boxed string'
    box_0 = Box(string)

    lazy = box_0.to_lazy()

    assert lazy.is_lazy()
    assert lazy.fold(lambda: None) == string


# Generated at 2022-06-25 23:30:32.148442
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(str_0).to_lazy()) == str(Lazy(lambda: str_0))


# Generated at 2022-06-25 23:30:35.106089
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    lazy_expected = Lazy(lambda: 'a')
    lazy_actual = Box('a').to_lazy()

    assert lazy_actual == lazy_expected


# Generated at 2022-06-25 23:30:37.351195
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    box = Box(str_0)
    lazy = box.to_lazy()
    assert str_0 == lazy.value()


# Generated at 2022-06-25 23:30:48.446939
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    async def async_test():
        try:
            # Test 1
            # Test case of empty Box
            box = Box(None)
            assert box.to_lazy() == Lazy(None), 'test 1 failed'
        except:
            raise AssertionError('test 1 failed')

        try:
            # Test 2
            # Test case of filled Box
            box = Box('b')
            assert box.to_lazy() == Lazy('b'), 'test 2 failed'
        except:
            raise AssertionError('test 2 failed')

        try:
            # Test 3
            # Test case of filled Box
            box = Box(5)
            assert box.to_lazy() == Lazy(5), 'test 3 failed'
        except:
            raise AssertionError('test 3 failed')

    asyncio.run

# Generated at 2022-06-25 23:30:56.334022
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    a = Box(42)
    result = a.to_lazy()
    assert isinstance(result, Lazy)
    assert result.fold() == 42

    a = Box(Try(42, is_success=True))
    result = a.to_lazy()
    assert isinstance(result, Lazy)
    assert isinstance(result.fold(), Try)
    assert result.fold().value == 42

    a = Box('abc')
    result = a.to_lazy()
    assert isinstance(result, Lazy)
    assert result.fold() == 'abc'



# Generated at 2022-06-25 23:30:58.237813
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = Box(28)

    assert var_0.to_lazy() == Lazy(lambda: 28)



# Generated at 2022-06-25 23:31:01.682004
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
     assert Box(str_0).to_lazy().get() == Box(str_0).to_lazy().get()

# Generated at 2022-06-25 23:31:04.076943
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    class_0 = Box(str_0)
    value_0 = class_0.to_lazy()

    assert isinstance(value_0, Lazy)

# Generated at 2022-06-25 23:31:05.572131
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(0).to_lazy().value() == 0


# Generated at 2022-06-25 23:31:18.120414
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'a'
    box_0 = Box(str_0)
    assert(box_0.to_lazy() == Lazy(lambda: str_0))


# Generated at 2022-06-25 23:31:29.218554
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    int_1 = 1
    str_0 = 'a'
    result = Box(int_0).to_lazy()
    assert result.is_lazy()
    assert result.is_foldable() is False
    assert result.map(lambda a: a + int_1).is_foldable() is False
    assert result.map(lambda a: a + int_1).evaluate() == int_1

    result = Box(str_0).to_lazy()
    assert result.is_lazy()
    assert result.is_foldable() is False
    assert result.map(lambda a: a + str_1).is_foldable() is False
    assert result.map(lambda a: a + str_1).evaluate() == 'ab'



# Generated at 2022-06-25 23:31:33.240174
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    box_1 = Box(str_0)
    lazy_2 = box_1.to_lazy()
    str_3 = lazy_2.fold(lambda: str_0)
    assert str_0 == str_3, "AssertionError: {} != {}".format(str_0, str_3)



# Generated at 2022-06-25 23:31:35.244932
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    box = Box(str_0)
    assert box.to_lazy().force() == 'a'


# Generated at 2022-06-25 23:31:38.400273
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a_0 = Box('test')
    a_1 = a_0.to_lazy()
    assert a_1(str_0) == 'test'
    #assert a_1.value == 'test'


# Generated at 2022-06-25 23:31:42.783302
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    str_1 = 'a'
    assert Box(str_0).to_lazy().force() == Box(str_1).to_lazy().force()

# Generated at 2022-06-25 23:31:46.457222
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    str_0 = 'a'

    # Act
    result = Box(str_0)

    # Assert
    assert result.to_lazy() == 'a'



# Generated at 2022-06-25 23:31:49.782822
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('a').to_lazy() == Lazy(lambda: 'a')
    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-25 23:31:52.637595
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(str_0).to_lazy().is_defined
    assert Box(str_0).to_lazy().map(lambda lst: lst).value() == str_0


# Generated at 2022-06-25 23:31:58.498867
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Create new boxed value
    box_1: Box[str] = Box(str_0)

    str_1: str

    # To lazy should return lazy with value
    lazy_0: Lazy[str] = box_1.to_lazy()

    # This value should be equal stored value
    str_1 = lazy_0.get()

    assert str_0 == str_1

# Generated at 2022-06-25 23:32:08.824313
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monoid import Sum

    # Test0:
    assert Box(Sum(1)).to_lazy() == Sum(1)


if __name__ == '__main__':
    test_Box_to_lazy()

# Generated at 2022-06-25 23:32:15.509110
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Scenario: Create box with str and convert it to Lazy monad

    Given box contains str "a"
    And Lazy[Function(() -> A)] = Box.to_lazy()
    When res = Lazy.fold()
    Then type(res) is str
    And res == 'a'
    """
    str_0 = 'a'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    res = lazy_0.fold()

    assert isinstance(res, str)
    assert res == str_0


# Generated at 2022-06-25 23:32:20.235875
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    r = Box(str_0).to_lazy()

    assert isinstance(r, Lazy)
    assert str_0 == r.unwrap()

    r_1 = Box(str_0).to_lazy().unwrap
    assert callable(r_1)

    assert str_0 == r_1()


# Generated at 2022-06-25 23:32:21.907465
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    assert Box(str_0).to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:32:23.604854
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(str_0).to_lazy() == Lazy(lambda: str_0)

# Generated at 2022-06-25 23:32:26.293170
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.value()
    assert str_0 == str_1


# Generated at 2022-06-25 23:32:33.871504
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(str_0).to_lazy() == Lazy(lambda: str_0)
    assert Box(str_0).to_maybe() == Maybe.just(str_0)
    assert Box(str_0).to_either() == Right(str_0)
    assert Box(str_0).to_try() == Try(str_0, is_success=True)
    assert Box(str_0).to_validation() == Validation.success(str_0)


# Generated at 2022-06-25 23:32:39.904189
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('a').to_lazy().is_monad()
    assert Box('a').to_lazy().is_functor()
    assert Box('a').to_lazy().is_applicative_functor()
    assert Box('a').to_lazy().is_monoid()
    assert Box('a').to_lazy().is_foldable()
    assert Box('a').to_lazy().is_traverse()
    assert Box('a').to_lazy().value() == 'a'


# Generated at 2022-06-25 23:32:41.982017
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-25 23:32:47.890462
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(a).to_lazy().value() == Box(a).value
    assert Box(0).to_lazy().value() == Box(0).value
    assert Box(b).to_lazy().value() == Box(b).value
    assert Box(test_case_0).to_lazy().value() == Box(test_case_0).value
    assert Box(str_0).to_lazy().value() == Box(str_0).value


# Generated at 2022-06-25 23:32:58.562437
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad import box_to_lazy
    assert box_to_lazy(Box(2)) == 2
    assert str_0 == 'a'


# Generated at 2022-06-25 23:33:05.222627
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): 
    """
    Test Box value to_lazy method.
    """
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(2).to_lazy() == Lazy(lambda: 2)
    assert Box(3).to_lazy() == Lazy(lambda: 3)
    assert Box('a').to_lazy() == Lazy(lambda: 'a')
    assert Box('b').to_lazy() == Lazy(lambda: 'b')
    assert Box('c').to_lazy() == Lazy(lambda: 'c')
    assert Box([]).to_lazy() == Lazy(lambda: [])
    assert Box([1]).to_lazy() == Lazy(lambda: [1])

# Generated at 2022-06-25 23:33:09.532476
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    x0 = Box(x=str_0)
    x1 = Lazy.create(x=str_0)
    assert x0.to_lazy() == x1
    assert x0.to_lazy().is_equal_to(x1)
    assert x0.to_lazy().unbox() == str_0


# Generated at 2022-06-25 23:33:11.306957
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(str).to_lazy()
    assert lazy.value() == str



# Generated at 2022-06-25 23:33:13.137171
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a_0 = Box(str_0)
    assert a_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:33:19.466591
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Mapper
    str_0 = 'a'
    box_0 = Box(str_0)
    box_0_to_lazy = box_0.to_lazy()
    assert box_0_to_lazy == Lazy(lambda: str_0)
    box_Mapper = Mapper[Box, str](box_0_to_lazy)
    assert box_Mapper == Box(str_0)


# Generated at 2022-06-25 23:33:22.294641
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    Box_0 = Box(str_0)
    Lazy_0 = Box_0.to_lazy()
    str_1 = Lazy_0.value()
    assert str_1 == str_0


# Generated at 2022-06-25 23:33:26.561176
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Hello'
    str_1 = ' world!'
    str_2 = '!'
    box_0 = Box(str_0)
    assert box_0.to_lazy().map(lambda str_2: str_2 + str_1).map(lambda str_2: str_2 + str_1).value() == 'Hello world! world! world!'


# Generated at 2022-06-25 23:33:30.067031
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import unittest

    class TestBoxToLazy(unittest.TestCase):
        def test_case_0(self):
            str_0 = 'a'
            result = Box(str_0).to_lazy().get_value()
            assert result == str_0

    unittest.main()

# Generated at 2022-06-25 23:33:35.301957
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    Box_str_0 = Box['str'](str_0)
    Lazy_str_0 = Box_str_0.to_lazy()
    str_1 = Lazy_str_0.force()
    assert str_0 == str_1
    str_2 = 'b'
    Box_str_0 = Box['str'](str_2)
    Lazy_str_0 = Box_str_0.to_lazy()
    str_3 = Lazy_str_0.force()
    assert str_2 == str_3


# Generated at 2022-06-25 23:34:07.772997
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Unit test for instance Box[A] to_lazy -> Lazy[Function(() -> A)]
    str_1 = 'a'
    assert isinstance(Box(str_1).to_lazy(), Box.__bases__[0].__args__[0])
    assert Box(str_1).to_lazy().get_or_else('b') == str_1
    int_1 = 1
    assert isinstance(Box(int_1).to_lazy(), Box.__bases__[0].__args__[0])
    assert Box(int_1).to_lazy().get_or_else(2) == int_1
    float_1 = 1.1
    assert isinstance(Box(float_1).to_lazy(), Box.__bases__[0].__args__[0])
   

# Generated at 2022-06-25 23:34:10.424944
# Unit test for method to_lazy of class Box

# Generated at 2022-06-25 23:34:15.937861
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value_0: Box[str] = Box(str_0)
    lazy_0: Lazy[str] = value_0.to_lazy()
    value_1: Box[str] = Box(str_0)
    lazy_1: Lazy[str] = value_1.to_lazy()
    test_0 = (lazy_0 == lazy_1)
    assert test_0


# Generated at 2022-06-25 23:34:22.944059
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    assert isinstance(Box(str_0).to_lazy(), Lazy)


# Generated at 2022-06-25 23:34:27.109520
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    ret_1 = lazy_0.eval()
    assert str_0 == ret_1


# Generated at 2022-06-25 23:34:36.001797
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad_try import MonadTry
    import pymonet.monad_try as MT
    from pymonet.validation import Validation
    import pymonet.validation as V

    functor = Functor[Box]
    functor += (lambda n: n + 1, Box(3))
    functor += (lambda n: n*n, Box(3))
    functor += (lambda n: n + 2, Box(3))
    functor += (lambda n: n - 1, Box(3))

    assert functor.map(lambda n: n + 1) == Box(4), "test failed"

# Generated at 2022-06-25 23:34:38.901066
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    
    str_0 = 'a'


# Generated at 2022-06-25 23:34:42.607329
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(object())
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == box_0.value
    assert lazy_0.is_folded is False


# Generated at 2022-06-25 23:34:48.722505
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    from pymonet.lazy import Lazy

    test_case_0()
    test_case = (lambda: str_0)
    big_int_0 = 999

    box = Box(big_int_0)
    lazy = Lazy(test_case)

    assert box.to_lazy() == lazy


# Generated at 2022-06-25 23:34:54.370565
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box('a').to_lazy() == Lazy(lambda: 'a')
    assert Box('b').to_lazy() == Lazy(lambda: 'b')
    assert Box(lambda x: x).to_lazy() == Lazy(lambda: lambda x: x)
    assert Box(Monad.unit(2)).to_lazy() == Lazy(lambda: Monad.unit(2))
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(True).to_lazy() == Lazy(lambda: True)
    assert Box(1.2).to_lazy

# Generated at 2022-06-25 23:35:47.851005
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # test for correct response
    # test for correct response
    assert Box('a').to_lazy().value() == 'a'

    # test for correct response
    # test for correct response
    assert Box(2).to_lazy().value() == 2

    # test for correct response
    # test for correct response
    assert Box([1, 2]).to_lazy().value() == [1, 2]

    # test for correct response
    # test for correct response
    assert Box([1, 2, 3]).to_lazy().value() == [1, 2, 3]

    # test for correct response
    # test for correct response
    assert Box({1, 2}).to_lazy().value() == {1, 2}

    # test for correct response
    # test for correct response
    assert Box({1, 2}).to

# Generated at 2022-06-25 23:35:50.205789
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0: Box[str] = Box(str_0)
    assert box_0.to_lazy() == Lazy(lambda: str_0)



# Generated at 2022-06-25 23:35:52.670892
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    boxed_a = Box(str_0)
    assert isinstance(boxed_a.to_lazy(), type(None))  # Function returns no type, so None is the closest to it.


# Generated at 2022-06-25 23:35:59.886979
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.code_generation as code_gen
    import pymonet.monad_try as monad_try
    import pymonet.lazy as lazy

    string_builder = code_gen.CodeBuilder('def test_case_0():\n')
    string_builder.add_body('    str_0 = \'a\'')
    source_code = string_builder.get_code()
    generated_code = code_gen.SourceCodeGenerator(source_code).get_generated_code()
    exec(generated_code, globals())
    box_0 = Box(str_0)
    try_0 = box_0.to_lazy().force()
    assert try_0 == 'a'

# Generated at 2022-06-25 23:36:03.783851
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    This function tests Box.to_lazy() method using py.test
    """
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()
    # assert lazy_0.value() == str_0
    # assert lazy_0.get_value() == str_0
    # assert lazy_0.fold() == str_0



# Generated at 2022-06-25 23:36:05.059061
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_state import State

    State(test_case_0)


# Generated at 2022-06-25 23:36:08.562210
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    box_0 = Box(str_0)
    assert isinstance(box_0.to_lazy(), Lazy)
    assert isinstance(box_0.to_lazy().value, FunctionType)
    assert box_0.to_lazy().value() == str_0


# Generated at 2022-06-25 23:36:12.977017
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'a'
    box_0 = Box(str_0)
    box_0 = box_0.to_lazy()
    assert (isinstance(box_0, Box))
    assert isinstance(box_0.value, str)
    assert (box_0.value == 'a')
    box_0 = box_0.map(str.upper)
    assert (box_0.value == 'A')


# Generated at 2022-06-25 23:36:13.571303
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    pass


# Generated at 2022-06-25 23:36:14.890558
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result_0 = Box('a').to_lazy()
    assert result_0.value() == 'a'

# Generated at 2022-06-25 23:37:03.451745
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    result = box_0.to_lazy()
    assert result == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:37:06.212232
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(sum)

    assert box_0.to_lazy() == Lazy(lambda: sum)


# Generated at 2022-06-25 23:37:08.222007
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == str_0



# Generated at 2022-06-25 23:37:11.033823
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    print('Box.to_lazy')
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    result_0 = lazy_0.fold()
    assert str(result_0) == str_0


# Generated at 2022-06-25 23:37:16.660539
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy_0 = Box(Try(5, is_success=True)).to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.f() == 5
    assert lazy_0.is_folded is False
    assert lazy_0.is_failed is False
    assert lazy_0.value == 5


# Generated at 2022-06-25 23:37:17.696254
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(42)

    assert box.to_lazy().value() == 42



# Generated at 2022-06-25 23:37:25.302250
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    box_1 = Box(1)
    box_2 = Box(2)

    lazy_0 = box_0.to_lazy()
    assert lazy_0.f() == str_0

    assert lazy_0.f()(box_1, box_2) == 'Sum[value={}]'.format(1 + 2)



# Generated at 2022-06-25 23:37:31.070901
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Sum[value={}]'
    box_0 = Box(str_0)
    box_1 = Box(1)
    box_2 = Box(2)

    lazy_0 = box_0.to_lazy()
    lazy_1 = box_1.to_lazy()
    lazy_2 = box_2.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold() == str_0
    assert lazy_1.fold() == 1
    assert lazy_2.fold() == 2
