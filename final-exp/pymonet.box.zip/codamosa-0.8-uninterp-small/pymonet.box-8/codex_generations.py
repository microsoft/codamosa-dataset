

# Generated at 2022-06-25 23:27:37.203135
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    int_0 = 1744
    box_0 = Box(int_0)
    int_1 = 1745
    box_1 = Box(int_1)
    int_2 = 1744
    box_2 = Box(int_2)
    assert (not (box_0 == box_1))
    assert (box_0 == box_2)
    assert (not (box_1 == box_2))


# Generated at 2022-06-25 23:27:40.906062
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    int_t = 1744
    box_t = Box(int_t)
    lazy_t = box_t.to_lazy()
    assert lazy_t == Lazy(box_t.value)


# Generated at 2022-06-25 23:27:44.708883
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    int_0 = 1744

    # Act
    box_0 = Box(int_0)
    box_0_lazy = box_0.to_lazy()

    # Assert
    assert box_0_lazy.value() == int_0



# Generated at 2022-06-25 23:27:49.443609
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.maybe import Just

    int_0 = 1744
    box_0 = Box(int_0)
    ret_0 = box_0.to_lazy()
    assert ret_0 == Lazy(lambda: int_0)

test_case_0()

# Generated at 2022-06-25 23:27:55.487043
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    int_0 = 1744
    box_0 = Box(int_0)
    boolean_0 = box_0.__eq__(int_0)
    assert not boolean_0
    int_1 = 1745
    box_1 = Box(int_1)
    boolean_1 = box_0.__eq__(box_1)
    assert not boolean_1
    boolean_2 = box_0.__eq__(box_0)
    assert boolean_2


# Generated at 2022-06-25 23:28:01.380210
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    int_0 = 567
    int_1 = 567
    str_0 = "str_0"
    str_1 = "str_1"
    box_0 = Box(int_0)
    box_1 = Box(int_1)
    box_2 = Box(str_0)
    box_3 = Box(str_1)
    assert (box_0 == box_1) == True
    assert (box_0 == box_2) == False
    assert (box_2 == box_3) == False
    assert (box_1 == box_1) == True
    assert (box_3 == box_3) == True


# Generated at 2022-06-25 23:28:05.994517
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.__class__ == Lazy
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:28:10.827844
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.utils import deep_eq

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert deep_eq(lazy_0.value(), int_0)



# Generated at 2022-06-25 23:28:13.289412
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Test case 0
    box_0 = Box(str())
    box_1 = Box(str())
    assert box_0 == box_1


# Generated at 2022-06-25 23:28:21.494650
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    int_0 = 1744
    box_0 = Box(int_0)
    assert box_0 == box_0
    int_1 = -806
    box_1 = Box(int_1)
    assert box_1 == box_1
    assert box_0 != box_1
    int_2 = -322
    box_2 = Box(int_2)
    assert box_0 != box_2
    int_3 = -51
    box_3 = Box(int_3)
    assert box_1 != box_3
    assert box_2 != box_3
    int_4 = -52
    box_4 = Box(int_4)
    assert box_3 != box_4


# Generated at 2022-06-25 23:28:26.560548
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    int_1 = lazy_0.value()
    assert int_0 == int_1


# Generated at 2022-06-25 23:28:30.424773
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    test_input = 13
    box_0 = Box(test_input)
    assert box_0.to_lazy() == Lazy(lambda: test_input)


# Generated at 2022-06-25 23:28:32.572123
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    assert Box(int_0).to_lazy().get() == int_0


# Generated at 2022-06-25 23:28:36.715444
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Function

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value == Function(box_0.value)
    assert lazy_0.is_folded == False


# Generated at 2022-06-25 23:28:43.459085
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_lazy import Lazy

    def _mapper(value: int) -> bool:
        return value % 2 == 0

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    lazy_1 = lazy_0.bind(_mapper)
    assert isinstance(lazy_1, Lazy)
    assert lazy_1()

    int_1 = 1745
    box_1 = Box(int_1)
    lazy_2 = box_1.to_lazy()
    lazy_3 = lazy_2.bind(_mapper)
    assert not lazy_3()



# Generated at 2022-06-25 23:28:47.679565
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    from pymonet.lazy import Lazy
    int_0 = 1744
    box_0 = Box(int_0)
    # when
    lazy_0 = box_0.to_lazy()
    # then
    assert lazy_0 == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:28:54.677260
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    lazy_0_value = lazy_0.value()
    assert lazy_0_value == int_0


# Generated at 2022-06-25 23:28:57.309624
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1744
    box_0 = Box(int_0)
    assert box_0.to_lazy() == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:29:01.587152
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = Lazy(lambda: 1744)
    result_lazy = box_0.to_lazy()
    assert result_lazy.folded == lazy_0.folded


# Generated at 2022-06-25 23:29:03.454371
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda : 5)



# Generated at 2022-06-25 23:29:08.919316
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    print('start test_Box_to_lazy')
    
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    result_0 = lazy_0.get()

    assert int_0 == result_0


# Generated at 2022-06-25 23:29:13.431152
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    lazy_0 = Box(1744).to_lazy()
    assert isinstance(lazy_0, Lazy)
    bool_0 = Lazy() == lazy_0
    assert bool_0


# Generated at 2022-06-25 23:29:16.744418
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold(lambda: None) == int_0


# Generated at 2022-06-25 23:29:19.080964
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()
    from pymonet.lazy import Lazy
    assert(isinstance(box_0.to_lazy(), Lazy))


# Generated at 2022-06-25 23:29:22.054690
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """ Test Box.to_lazy() method"""
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.get_value() == int_0

# Generated at 2022-06-25 23:29:26.592376
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    print("\n\nUnit test for method to_lazy of class Box")

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.get() == int_0

# Generated at 2022-06-25 23:29:30.957441
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(lambda x, y: x+y)
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value()(1,2) == 3


# Generated at 2022-06-25 23:29:33.867545
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(test_case_0().to_lazy(), Lazy)
    assert test_case_0().to_lazy().value() == test_case_0().value


# Generated at 2022-06-25 23:29:43.044092
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.maybe import MaybeValue

    def f_0():
        return 7

    lazy_0 = Lazy(f_0)

    Box(0).to_lazy() == lazy_0
    Box(0).to_lazy().equals(lazy_0)
    Maybe.just(0).to_lazy() == lazy_0
    Maybe.just(0).to_lazy().equals(lazy_0)
    Maybe.nothing().to_lazy() == Lazy(lambda: MaybeValue.nothing())

# Generated at 2022-06-25 23:29:45.979758
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box_0 = Box(10)
    lazy = box_0.to_lazy()

    assert lazy.value() == 10
    assert type(lazy) == Lazy

# Generated at 2022-06-25 23:29:53.063084
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    assert Lazy(None, True, lambda: int_0) == box_0.to_lazy()


# Generated at 2022-06-25 23:29:56.440481
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert callable(lazy_0.get())
    assert lazy_0.get() == 1744



# Generated at 2022-06-25 23:29:58.792041
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    return Lazy(lambda: 1)


# Generated at 2022-06-25 23:30:01.599435
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    expected_lazy = Lazy(lambda: 0)

    lazy = Box(0).to_lazy()
    assert lazy == expected_lazy
test_Box_to_lazy.__test__ = False



# Generated at 2022-06-25 23:30:06.969659
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_variant = box_0.to_lazy()

    assert isinstance(lazy_variant, Lazy)
    assert lazy_variant.is_folded
    assert lazy_variant.get_value() == int_0


# Generated at 2022-06-25 23:30:09.989499
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1744
    box_0 = Box(int_0)
    assert box_0.to_lazy() == Lazy(lambda: int_0)



# Generated at 2022-06-25 23:30:18.564542
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(3).to_lazy() == Lazy(lambda: 3)
    assert Box(3).to_lazy().value == Lazy(lambda: 3).value
    assert Box(None).to_lazy() == Lazy(lambda: None)
    assert Box(None).to_lazy().value == Lazy(lambda: None).value
    assert Box(Lazy(lambda: 5)).to_lazy() == Lazy(lambda: Lazy(lambda: 5))
    assert Box(Lazy(lambda: 5)).to_lazy().value == Lazy(lambda: Lazy(lambda: 5)).value
    assert Box(Try(None, is_success=True)).to_

# Generated at 2022-06-25 23:30:21.750130
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = 1744
    box_0 = Box(int_0)
    assert box_0.to_lazy() == Lazy(lambda: 1744)



# Generated at 2022-06-25 23:30:31.793583
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    int_0 = 1744
    box_0 = Box(int_0)

    lazy_0 = box_0.to_lazy()
    assert lazy_0.isinstance_of(Lazy)
    assert lazy_0.value.is_none()
    assert lazy_0.is_instance

    assert lazy_0.value == int_0

    lazy_0.force()
    assert lazy_0.value.is_some()
    assert lazy_0.value.unwrap() == int_0
    assert lazy_0.is_instance

    lazy_1 = lazy_0.map(lambda value: value + 1)
    assert lazy_1.value.is_none

# Generated at 2022-06-25 23:30:33.659100
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(42)
    box_0_lazy = box_0.to_lazy()

    assert isinstance(box_0_lazy, Lazy) and box_0_lazy.value() == 42



# Generated at 2022-06-25 23:30:43.452788
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 42
    box_0 = Box(int_0)

    lazy_0 = box_0.to_lazy()

    assert (isinstance(lazy_0, Lazy))
    assert (lazy_0.fold(lambda: int_0) == int_0)


# Generated at 2022-06-25 23:30:48.351684
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744

    box_0 = Box(int_0)

    box_1 = box_0.to_lazy()

    lazy_0 = box_1.value

    lazy_1 = lazy_0()

    int_1 = lazy_1

    assert int_1 == int_0 == box_0.value


# Generated at 2022-06-25 23:30:57.160484
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test of Box.to_lazy() method.
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.unwrap().unwrap() == int_0

    int_1 = -753
    box_1 = Box(int_1)
    lazy_1 = box_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.unwrap().unwrap() == int_1


# Generated at 2022-06-25 23:31:05.277419
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    import random

    box_0 = Box(1744)
    lazy = box_0.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1744
    random.seed()
    a = random.randint(1, 1e6)
    box_1 = Box(a)
    lazy = box_1.to_lazy()
    assert lazy.value() == a


# Generated at 2022-06-25 23:31:08.705308
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == int_0



# Generated at 2022-06-25 23:31:14.060723
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(0)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)  # type hinting
    assert lazy.is_folded is False
    assert lazy.value() == box.value
    assert lazy.is_folded is True


# Generated at 2022-06-25 23:31:17.838086
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)

    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:31:20.883134
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.get() == int_0



# Generated at 2022-06-25 23:31:25.306533
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_1 = 10
    box_1 = Box(int_1)
    lazy_1 = box_1.to_lazy()
    assert lazy_1.value() == int_1


# Generated at 2022-06-25 23:31:32.977024
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold(lambda: 0) == int_0


# Generated at 2022-06-25 23:31:40.741980
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold() == 1744


# Generated at 2022-06-25 23:31:44.334097
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(0)
    lazy_0 = box_0.to_lazy()
    lazy_0_value = lazy_0.value()
    assert box_0.value == lazy_0_value


# Generated at 2022-06-25 23:31:46.063138
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    integer_value = 107
    result = Box(integer_value)


# Generated at 2022-06-25 23:31:49.782967
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0() == box_0.value


# Generated at 2022-06-25 23:31:52.125277
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    assert box_0.to_lazy().value() == int_0

# Generated at 2022-06-25 23:31:55.441453
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:31:59.376972
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_int_0 = Box(1)
    lazy_0 = box_int_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 1


# Generated at 2022-06-25 23:32:04.229233
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = Lazy(lambda: 0)

    assert box_0.to_lazy() == lazy_0.to_maybe()
    assert box_0.to_lazy() == maybe_0



# Generated at 2022-06-25 23:32:05.954179
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    box_0 = Box(1744)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.force() == 1744


# Generated at 2022-06-25 23:32:08.720795
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    int_0 = 1744
    box_0 = Box(int_0)

    assert box_0.to_lazy() == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:32:17.423695
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_box = Box(0)
    assert 0 == int_box.to_lazy().value()

    str_box = Box('str')
    assert 'str' == str_box.to_lazy().value()

    list_box = Box(['str'])
    assert ['str'] == list_box.to_lazy().value()


# Generated at 2022-06-25 23:32:23.874242
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    lz_0 = Box(42).to_lazy()

    assert isinstance(lz_0, Lazy)
    assert lz_0.fold() == 42

    lz_1 = Box(Right(42)).to_lazy()

    assert isinstance(lz_1, Lazy)
    assert isinstance(lz_1.fold(), Right)
    assert lz_1.fold().fold() == 42



# Generated at 2022-06-25 23:32:27.276275
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1744
    box_0 = Box(int_0)
    f_0 = lambda: int_0
    lazy_0 = Lazy(f_0)
    assert box_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:32:30.744322
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    test_value = 10
    box_0 = Box(test_value)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == test_value


# Generated at 2022-06-25 23:32:38.882925
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_case_1():
        box_1 = Box(1744)
        from pymonet.lazy import Lazy

        assert box_1.to_lazy() == Lazy(lambda: 1744)

    def test_case_2():
        box_2 = Box(0)
        from pymonet.lazy import Lazy

        assert box_2.to_lazy() == Lazy(lambda: 0)

    def test_case_3():
        box_3 = Box(2)
        from pymonet.lazy import Lazy

        assert box_3.to_lazy() == Lazy(lambda: 2)

    def test_case_4():
        box_4 = Box(-28)
        from pymonet.lazy import Lazy

        assert box_4.to_lazy() == L

# Generated at 2022-06-25 23:32:43.431091
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_folded() is False
    assert lazy_0.fold() == int_0


# Generated at 2022-06-25 23:32:46.507071
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int0 = 1
    b0 = Box(int0)
    l0 = b0.to_lazy()
    assert l0.value() == int0

# Generated at 2022-06-25 23:32:55.157746
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy
    import pymonet.functor

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    result_0 = pymonet.functor.functor_law_identity(lazy_0)
    assert result_0
    string_0 = "TEST"
    lazy_1 = lazy_0.map(lambda a: str(a) + string_0)
    result_1 = pymonet.functor.functor_law_composition(lazy_0, string_0, pymonet.lazy.Lazy)
    assert result_1

# Generated at 2022-06-25 23:32:57.158955
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(1744) == Box(1744).to_lazy()

# Generated at 2022-06-25 23:33:00.770314
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert(isinstance(lazy_0, Lazy))
    assert(lazy_0.value() == int_0)



# Generated at 2022-06-25 23:33:11.533890
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert isinstance(Box("hello").to_lazy(), Lazy)


# Generated at 2022-06-25 23:33:17.711566
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    res_0 = Box(7)
    assert res_0.to_lazy() is not None
    assert res_0.to_lazy() == Lazy(lambda: 7)
    res_1 = Box(Maybe.nothing())
    assert res_1.to_lazy() is not None
    assert res_1.to_lazy() == Lazy(lambda: Maybe.nothing())



# Generated at 2022-06-25 23:33:20.951196
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    int_1 = lazy_0.fold(lambda: 1)

    assert lazy_0 is not None
    assert int_1 == int_0



# Generated at 2022-06-25 23:33:23.707067
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    int_1 = lazy_0.get()
    assert int_0 == int_1


# Generated at 2022-06-25 23:33:26.815746
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test():
        int_0 = 1744
        box_0 = Box(int_0)
        lazy_0 = box_0.to_lazy()
        assert lazy_0._folded is False
        assert lazy_0._value() == int_0
    test()


# Generated at 2022-06-25 23:33:27.901486
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1


# Generated at 2022-06-25 23:33:31.106770
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    pass
    int_1 = 4752
    box_1 = Box(int_1)
    lazy_1 = box_1.to_lazy()
    fold_1 = lazy_1.fold()
    assert int_1 == fold_1


# Generated at 2022-06-25 23:33:32.687328
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 5
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:33:35.821329
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_0 = Lazy(lambda: 1744)
    box_0 = Box(1744)
    box_1 = Box(1744)

    assert box_0.to_lazy() == lazy_0
    assert box_0.to_lazy() == box_1.to_lazy()

# Generated at 2022-06-25 23:33:39.223240
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(1)
    assert box_0.to_lazy() is Lazy(lambda: 1)

    box_1 = Box(1)
    assert box_1.to_lazy() is Lazy(lambda: 1)


# Generated at 2022-06-25 23:34:10.606440
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_Box_to_lazy_0():
        from pymonet.lazy import Lazy

        int_0 = C19()
        box_0 = Box(int_0)
        lazy_0 = box_0.to_lazy()
        assert isinstance(lazy_0, Lazy)
        int_1 = lazy_0.get()
        assert int_1 == int_0
    test_Box_to_lazy_0()

    def test_Box_to_lazy_1():
        from pymonet.lazy import Lazy

        int_0 = C82()
        box_0 = Box(int_0)
        lazy_0 = box_0.to_lazy()
        assert isinstance(lazy_0, Lazy)
        int_1 = lazy_0.get()


# Generated at 2022-06-25 23:34:17.231999
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    
    num1 = Box(5)
    lazy_box = num1.to_lazy()
    assert isinstance(lazy_box, Lazy) == True
    assert lazy_box.value() == 5
    assert isinstance(lazy_box.value(), int) == True
    assert isinstance(lazy_box.value(), Maybe) == False

test_case_0()
test_Box_to_lazy()

# Generated at 2022-06-25 23:34:23.381782
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    """
    Returns boxed value
    :input Box[int]
    """
    int_0 = 1744
    lazy_0 = Lazy(lambda: int_0)

    box_0 = Box(int_0)

    assert box_0.to_lazy() == lazy_0

# Generated at 2022-06-25 23:34:25.793451
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.maybe import Maybe

    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    maybe_0 = lazy_0.fold()
    assert maybe_0 == Maybe.just(int_0)


# Generated at 2022-06-25 23:34:29.897627
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded() == False
    assert lazy_0.value == int_0


# Generated at 2022-06-25 23:34:37.524154
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def get(value):
        return value

    box = Box(get(1744))
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.return_value(), int)
    assert lazy.return_value() == 1744


# Generated at 2022-06-25 23:34:39.733452
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('@pymonet').to_lazy() == Lazy(lambda: '@pymonet')


# Generated at 2022-06-25 23:34:41.906498
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    number = 42
    lazy_number = Box(number).to_lazy()
    assert lazy_number.fold(lambda: None) == number


# Generated at 2022-06-25 23:34:48.911834
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    pymonet.lazy.test_case_0()
    assert isinstance(lazy_0, pymonet.lazy.Lazy)
    assert callable(lazy_0.value)
    assert lazy_0.value() == int_0

# Generated at 2022-06-25 23:34:50.088417
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = Box(1744).to_lazy()



# Generated at 2022-06-25 23:35:14.778900
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    assert box_0.to_lazy().value() == int_0
    int_1 = 6060
    box_1 = Box(int_1)
    assert box_1.to_lazy().value() == int_1


# Generated at 2022-06-25 23:35:18.389085
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # test case 0
    int_0 = 1744
    box_0 = Box(int_0)
    box_1 = box_0.to_lazy()
    assert int_0 == box_1.value()


# Generated at 2022-06-25 23:35:22.790933
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Preparing arguments
    int_0 = numpy.int32(1744)
    box_0 = Box(int_0)
    test_case_0()

    # Testing method
    val_0 = box_0.to_lazy()

    # Checking results
    assert isinstance(val_0, pymonet.lazy.Lazy)
    assert callable(val_0.callable)



# Generated at 2022-06-25 23:35:24.922859
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == int_0

# Generated at 2022-06-25 23:35:25.849334
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    val = Box(3).to_lazy()
    assert val.value() == 3

# Generated at 2022-06-25 23:35:29.319311
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(1744)
    lazy_0 = box_0.to_lazy()
    boolean_0 = lazy_0.is_folded
    lazy_0.fold()
    assert int_0 == 1744 and not boolean_0


# Generated at 2022-06-25 23:35:36.773105
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Catch

    int_0 = 1744
    box_0 = Box(int_0)
    try_0 = Try(int_0, is_success=True)

    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded == False
    assert lazy_0.value() == int_0

    lazy_1 = try_0.to_lazy()
    assert lazy_1.is_folded == False
    assert lazy_1.value() == int_0

    lazy_2 = Try(lambda: 1/0).to_lazy()
    assert lazy_2.is_folded == False
    assert lazy_2.value() == 1/0


# Generated at 2022-06-25 23:35:41.245197
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Create Box and convert it to Lazy
    lazy_0 = Box(1744).to_lazy()

    # Check that the Lazy is not empty
    assert lazy_0.is_present()

    # Unwrap Lazy
    int_0 = lazy_0.get()

    # Check that Box and Lazy are equals
    assert Box(1744) == Box(int_0) and 1744 == int_0



# Generated at 2022-06-25 23:35:46.814355
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    b_0 = lazy_0.is_folded()
    assert b_0 is False
    int_1 = lazy_0.fold()
    assert int_1 == int_0
    b_1 = lazy_0.is_folded()
    assert b_1 is True
    box_1 = lazy_0.to_box()
    assert box_1 is box_0


# Generated at 2022-06-25 23:35:48.716364
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_value = 1744
    test_box = Box(test_value)
    result = test_box.to_lazy()
    assert result.fold() == test_value


# Generated at 2022-06-25 23:36:36.839805
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for class Box method to_lazy.

    :return: None
    """
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])



# Generated at 2022-06-25 23:36:44.147254
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    int_m1 = int_0 + int_1
    int_m2 = int_m1 + int_1
    int_m3 = int_m2 + int_1
    int_m4 = int_m3 + int_1
    int_m5 = int_m4 + int_1
    int_m6 = int_m5 + int_1
    int_m7 = int_m6 + int_1
    int_m8 = int_m7 + int_1
    int_m9 = int_m8

# Generated at 2022-06-25 23:36:45.620807
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Box(2).to_lazy().value()


# Generated at 2022-06-25 23:36:50.375179
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_1 = 1

    box_int_1 = Box(int_1)

    lazy_box_int_1 = box_int_1.to_lazy()

    assert lazy_box_int_1.is_folded == False
    assert lazy_box_int_1.value() == box_int_1.value


# Generated at 2022-06-25 23:36:54.597022
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    # Box[A].to_lazy() -> Lazy[Function(() -> A)]
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    lazy_1 = (lambda: int_0)
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:37:06.179638
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    int_1 = int_0
    int_2 = int_1
    int_3 = int_2
    int_4 = int_3
    int_5 = int_4
    int_6 = int_5
    int_7 = int_6
    int_8 = int_7
    int_9 = int_8
    int_10 = int_9
    int_11 = int_10
    int_12 = int_11
    int_13 = int_12
    int_14 = int_13
    int_15 = int_14
    int_16 = int_15
    int_17 = int_16
    int_18 = int_17
    int_19 = int_18
    int_20 = int_19
    int_21 = int_20
    int

# Generated at 2022-06-25 23:37:08.762591
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    bx_int_0 = Box(int_0)
    lazy_int_0 = bx_int_0.to_lazy()
    assert lazy_int_0.value() == int_0
    assert lazy_int_0.value() == int_0



# Generated at 2022-06-25 23:37:11.810408
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    int_1 = -1066
    box_0 = Box(int_0)
    from pymonet.lazy import Lazy
    lazy_0 = Lazy(lambda: int_1)
    assert not lazy_0.folded
    lazy_1 = box_0.to_lazy()
    assert not lazy_1.folded
    assert lazy_1.value() == int_0


# Generated at 2022-06-25 23:37:15.636430
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1744
    box_0 = Box(int_0)
    result_0 = box_0.to_lazy()
    assert result_0.is_lazy()
    assert result_0.fold() == int_0


# Generated at 2022-06-25 23:37:25.649714
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.monad_either as me
    import pymonet.monad_maybe as mm
    import pymonet.monad_try as mt
    import pymonet.monad_validation as mv

    monad_to_lazy = lambda monad: monad.to_lazy()
