

# Generated at 2022-06-25 23:27:35.194846
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    box_1 = Box(str_0)
    assert box_0 == box_1



# Generated at 2022-06-25 23:27:37.893480
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box('')
    other_0 = Box('')
    is_equal = box_0.__eq__(other_0)
    assert is_equal == True


# Generated at 2022-06-25 23:27:41.298239
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    assert box_0 == Box(str_0), "Failed on test_Box___eq__ test"



# Generated at 2022-06-25 23:27:51.008732
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = ']|dVWQh'
    box_0 = Box(str_0)
    assert box_0 == box_0, "Box__eq__: 0"
    box_1 = Box(str_0)
    assert box_0 == box_1, "Box__eq__: 1"
    str_2 = '2K{N[IH.O'
    box_2 = Box(str_2)
    assert box_0 != box_2, "Box__eq__: 2"
    int_3 = -81973538
    box_3 = Box(int_3)
    assert box_0 != box_3, "Box__eq__: 3"
    box_4 = Box(int_3)
    assert box_4 == box_3, "Box__eq__: 4"
    str

# Generated at 2022-06-25 23:27:54.172516
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    assert box_0.to_lazy().value() == str_0


# Generated at 2022-06-25 23:27:58.682379
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'pRxR822jKS'
    box_0 = Box(str_0)

    eq_(True, box_0 == box_0)
    eq_(True, box_0 == Box(str_0))
    eq_(False, box_0 == Box(4))



# Generated at 2022-06-25 23:28:04.937605
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    str_1 = 'm8#d1'
    box_1 = Box(str_1)
    assert not box_0.__eq__(box_1)



# Generated at 2022-06-25 23:28:08.406145
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    box_0_ = Box(str_0)

    assert box_0 == box_0_
    assert not box_0 == None


# Generated at 2022-06-25 23:28:11.333289
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'Q'
    box_0 = Box(str_0)
    box_1 = Box(str_0)
    assert box_0 == box_1, 'Test failed'



# Generated at 2022-06-25 23:28:19.134919
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Right
    from pymonet.lazy import Lazy

    str_0 = 'Bt:#XtG&'
    maybe_0 = Maybe.just(str_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.is_lazy()
    assert lazy_0.get() == str_0

    box_0 = Box(str_0)
    lazy_1 = box_0.to_lazy()
    assert lazy_1.get() == str_0



# Generated at 2022-06-25 23:28:25.667253
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    tests_list = [
        {
            'name': 'test_case_0',
            'input': (
                test_case_0,
            ),
            'expected_result': None,
            'expected_result_type': type(None),
            'expected_error': None,
            'expected_error_type': None,
        },
    ]
    for test in tests_list:
        test_name = test['name']
        print('Running {}'.format(test_name))
        input_val = test['input']
        expected_result = test['expected_result']
        expected_result_type = test['expected_result_type']
        expected_error = test['expected_error']
        expected_error_type = test['expected_error_type']

# Generated at 2022-06-25 23:28:32.620213
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '~'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold() != box_0
    assert lazy_0.fold() == str_0
    assert lazy_0.fold() is not box_0
    assert lazy_0.fold() is str_0


# Generated at 2022-06-25 23:28:36.111258
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(3)

    lzy = box_0.to_lazy()
    assert lzy.fold(lambda: 0)() == 3
    assert lzy.fold(lambda: 0)() == 3


# Generated at 2022-06-25 23:28:43.720359
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # _______________________________
    # Test case 0
    print('\nTest case 0')
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    ret_0 = box_0.to_lazy()
    assert(str_0 == ret_0.value())
    print('passed')
    # _______________________________
    # Test case 1
    print('\nTest case 1')
    str_1 = 'x\x9d\xa7\xca\xe7\x98\xbb\xde\x05\x0b\x14\x8b\x80\xba'
    box_1 = Box(str_1)
    ret_1 = box_1.to_lazy()

# Generated at 2022-06-25 23:28:45.980920
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(21)
    lazy = box_0.to_lazy()
    val = lazy.value
    assert val == 21



# Generated at 2022-06-25 23:28:49.771563
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()
    assert lazy_0.eval() == str_0


# Generated at 2022-06-25 23:28:53.810262
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = Box(True).to_lazy()
    lazy_1 = Box(False).to_lazy().map(lambda value_0: value_0)
    lazy_0.flat_map(lambda value_0: lazy_1)


# Generated at 2022-06-25 23:28:57.574321
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    result_0 = lazy_0.fold(lambda: None, lambda value: value)
    assert result_0 == str_0

# Generated at 2022-06-25 23:29:01.418337
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.get_value() == str_0


# Generated at 2022-06-25 23:29:04.554575
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Case 0 of 1
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == str_0



# Generated at 2022-06-25 23:29:11.924457
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    box_0.to_lazy()



# Generated at 2022-06-25 23:29:17.790722
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def my_and(a, b):
        return a and b

    def my_or(a, b):
        return a or b

    def my_xor(a, b):
        return my_or(my_and(a, not b), my_and(not a, b))

    def my_not(a):
        return not a



# Generated at 2022-06-25 23:29:22.017887
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    from pymonet.lazy import Lazy
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.get()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:29:25.706208
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '@nH$Q-{y*+'
    box_0 = Box(str_0)

    assert box_0.to_lazy().force() == str_0


# Generated at 2022-06-25 23:29:28.221595
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    x = Box(0)
    y = x.to_lazy()
    assert y.__eq__(Box(0))


# Generated at 2022-06-25 23:29:32.604392
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'f-@"9?;iW8}vF'
    box_0 = Box(str_0)
    maybe_0 = box_0.to_lazy()
    assert maybe_0.fold() == str_0


# Generated at 2022-06-25 23:29:41.854706
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    box_0 = Box(42)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_same(Lazy(lambda: 42))
    int_0 = lazy_0.get_or_else(100)
    assert int_0 == 42
    int_0 = lazy_0.map(lambda i: i + 1).get_or_else(100)
    assert int_0 == 43
    lazy_1 = lazy_0.flat_map(lambda i: Lazy(lambda: i + 3))
    int_1 = lazy_1.get_or_else(100)
    assert int_1 == 45
    lazy_2 = lazy_1.filter(lambda i: i > 1000)
    int

# Generated at 2022-06-25 23:29:45.252587
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.fold(lambda f: f())


# Generated at 2022-06-25 23:29:49.662553
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)

    f = str.upper

    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.folded is False
    assert lazy_0.value(f) == str_0.upper()



# Generated at 2022-06-25 23:29:54.631071
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.identity import Identity
    from pymonet.maybe import Maybe
    from pymonet.either import Either
    from pymonet.validation import Validation

    box_0 = Box(123)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_value()
    assert lazy_0.is_value() == Lazy(lambda: 123).is_value()
    assert lazy_0.get_value() == Lazy(lambda: 123).get_value()
    assert lazy_0.fold(_identity=lambda: 123) == Lazy(lambda: 123).fold(_identity=lambda: 123)

    box_1 = Box(lambda: 123)
    lazy_1 = box_1.to_lazy()

# Generated at 2022-06-25 23:30:00.630302
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    box_0_lazy = box_0.to_lazy()
    assert box_0.value == box_0_lazy.value()


# Generated at 2022-06-25 23:30:04.525917
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = '#@vL<Yt{sHe'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(box_0.value)


# Generated at 2022-06-25 23:30:07.395751
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = Box(5).to_lazy()  # type: Lazy[int]
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.eval() == 5



# Generated at 2022-06-25 23:30:10.864626
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert(all([lazy_0.forced == str_0, lazy_0.is_forced == False]))


# Generated at 2022-06-25 23:30:12.632712
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    assert box_0.to_lazy().value() == str_0


# Generated at 2022-06-25 23:30:13.907727
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(1).to_lazy()
    assert lazy.fold(lambda: 0) == 1, "Value should be one"

# Generated at 2022-06-25 23:30:17.970540
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded() is False
    assert lazy_0.get_value() == str_0


# Generated at 2022-06-25 23:30:22.907348
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'uH?3y+}($H$'
    box_0 = Box(str_0)
    box_0_to_lazy = box_0.to_lazy()

    assert isinstance(box_0_to_lazy, Lazy)
    assert str_0 == box_0_to_lazy.get()



# Generated at 2022-06-25 23:30:29.746951
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Transform Box into Lazy with returning value function.

    :returns: not folded Lazy monad with function returning previous value
    :rtype: Lazy[Function(() -> A)]
    """
    from pymonet.lazy import Lazy

    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    result = box_0.to_lazy()
    assert result == Lazy(lambda: str_0)



# Generated at 2022-06-25 23:30:31.705581
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '3691'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_0.value(), str)


# Generated at 2022-06-25 23:30:39.018800
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_2 = Box(Lazy(lambda: Lazy(lambda: Lazy(lambda: "test"))))

    assert box_2.to_lazy().value().value().value() == "test"



# Generated at 2022-06-25 23:30:44.339002
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Create class instance
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)

    # Call method
    result = box_0.to_lazy()

    # Check result
    assert isinstance(result, Lazy)
    assert result().value == str_0


# Generated at 2022-06-25 23:30:49.253991
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    if (lazy_0.value() != str_0):
        raise AssertionError(
            "value of object lazy_0 is not equal to previous value of object box_0")



# Generated at 2022-06-25 23:30:52.469797
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:30:56.640121
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.__class__.__name__ == 'Lazy'
    assert lazy_0.value() == str_0

# Generated at 2022-06-25 23:31:02.741354
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    lazy_0.get()  # UH?3y+}($H$


# Generated at 2022-06-25 23:31:06.898726
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.value()
    assert str_0 == str_1

# Generated at 2022-06-25 23:31:17.135433
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'vtw.tZg+j_('
    box_0 = Box(str_0).to_lazy()
    assert box_0 == Lazy(lambda: 'vtw.tZg+j_('), 'AssertionError: {} != {}'.format(repr(box_0), repr(Lazy(lambda: 'vtw.tZg+j_('))
)
    int_0 = -567167007
    box_1 = Box(int_0).to_lazy()
    assert box_1 == Lazy(lambda: -567167007), 'AssertionError: {} != {}'.format(repr(box_1), repr(Lazy(lambda: -567167007))
)

# Generated at 2022-06-25 23:31:20.386443
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:31:25.512313
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(lambda: 'v4qhw<W[PX')
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)



# Generated at 2022-06-25 23:31:38.005088
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def fun_0():
        str_0 = 'UH?3y+}($H$'
        box_0 = Box(str_0)
        return box_0.to_lazy()

    lazy_0 = fun_0()
    str_0 = lazy_0.value()
    assert str_0 == 'UH?3y+}($H$'


# Generated at 2022-06-25 23:31:44.719493
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('A').to_lazy().evaluate() == 'A'
    assert Box(12).to_lazy().evaluate() == 12
    assert Box(1.2).to_lazy().evaluate() == 1.2
    assert Box(None).to_lazy().evaluate() is None
    assert Box(False).to_lazy().evaluate() is False
    assert Box(True).to_lazy().evaluate() is True


# Generated at 2022-06-25 23:31:50.946038
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    any_0 = Box('Y]5KI{F(a@R')
    any_1 = Lazy(lambda: 'Y]5KI{F(a@R')

    assert any_0.to_lazy() == any_1, 'Expected: %s, Actual: %s' % (any_0.to_lazy(), any_1)


# Generated at 2022-06-25 23:31:55.274918
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'i0.'
    str_1 = 'i0.'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_2 = lazy_0.value()
    assert str_1 == str_2



# Generated at 2022-06-25 23:32:00.163426
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Setup
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    expected_lazy_0 = Lazy(lambda: str_0)
    # Exercise

    actual_lazy_0 = box_0.to_lazy()
    assert actual_lazy_0 == expected_lazy_0

# Generated at 2022-06-25 23:32:03.399577
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    str_1 = box_0.to_lazy().value()
    assert str_0 == str_1



# Generated at 2022-06-25 23:32:06.192028
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_1 = box_0.to_lazy()
    assert lazy_1.get() == str_0


# Generated at 2022-06-25 23:32:09.582403
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert(lazy_0.fold(lambda: 'Wrong value') == str_0)


# Generated at 2022-06-25 23:32:15.549204
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    str_0 = '03D{gaH@mh'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0 is not None
    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_0, Functor)
    assert isinstance(lazy_0, Monad)


# Generated at 2022-06-25 23:32:17.953311
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)

    assert box_0.to_lazy().value() == str_0


# Generated at 2022-06-25 23:32:43.465106
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == str_0
    # Test case 1
    str_1 = 'u[mFUM$/6;/\n'
    box_1 = Box(str_1)
    lazy_1 = box_1.to_lazy()
    assert lazy_1.value() == str_1
    # Test case 2
    str_2 = 'lAbz"=p$*;'
    box_2 = Box(str_2)
    lazy_2 = box_2.to_lazy()
    assert lazy_2.value() == str_2
    # Test case 3


# Generated at 2022-06-25 23:32:47.176350
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().has_value() == False
    assert Box('Hi').to_lazy().value() == 'Hi'
    assert Box((1, 12)).to_lazy().value() == (1, 12)


# Generated at 2022-06-25 23:32:50.863250
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    str_1 = 'UH?3y+}($H$'
    lazy_0 = box_0.to_lazy()
    assert str_1 == lazy_0.eval()


# Generated at 2022-06-25 23:32:54.199890
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'box.value'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    value_from_lazy_0 = lazy_0.evaluate()
    assert value_from_lazy_0 == str_0

# Generated at 2022-06-25 23:33:01.816331
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for Box.to_lazy

    :return: None
    """
    from pymonet.lazy import Lazy
    from pymonet.exceptions import LazyEvaluationException

    string_0 = 'UH?3y+}($H$'
    box_0 = Box(string_0)

    assert box_0.to_lazy() == Lazy(lambda: string_0)
    assert box_0.to_lazy().is_folded() == False
    assert box_0.to_lazy().value() == string_0

    try:
        box_0.to_lazy().value()
        assert False
    except LazyEvaluationException as e:
        assert True


# Generated at 2022-06-25 23:33:05.091238
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    assert box_0.to_lazy() == Lazy(lambda: str_0)



# Generated at 2022-06-25 23:33:07.094377
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(42).to_lazy()

    assert isinstance(lazy, Lazy)



# Generated at 2022-06-25 23:33:11.152644
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    _str = 'UH?3y+}($H$'
    _box = Box(_str)
    _lazy = _box.to_lazy()
    _lazy_res = _lazy.value()
    assert isinstance(_lazy, Lazy)
    assert _str == _lazy_res


# Generated at 2022-06-25 23:33:14.330767
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    one_ = 1
    box_ = Box(one_)
    lazy_ = box_.to_lazy()
    actual_ = lazy_.value()

    assert(actual_ == one_)


# Generated at 2022-06-25 23:33:18.131223
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0() == str_0


# Generated at 2022-06-25 23:34:03.498209
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    class BoxTest(unittest.TestCase):
        def test_0(self):
            box_0 = Box("abc")
            lazy_0 = box_0.to_lazy()
            self.assertEqual(lazy_0.get(), box_0.value)

    suite = unittest.TestLoader().loadTestsFromTestCase(BoxTest)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-25 23:34:07.264066
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    box_1 = box_0.to_lazy()
    assert isinstance(box_1, Lazy)


# Generated at 2022-06-25 23:34:10.219854
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()



# Generated at 2022-06-25 23:34:14.834515
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Box[String]
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    # check value
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:34:18.668827
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    val_0 = Box('UH?3y+}($H$')
    result_lazy = val_0.to_lazy()
    assert isinstance(result_lazy, Lazy)
    assert result_lazy.is_folded is False
    result_lazy = result_lazy.fold()
    assert isinstance(result_lazy, str)


# Generated at 2022-06-25 23:34:26.386660
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import fold
    from pymonet.monad_try import to_failure
    from pymonet.maybe import is_nothing
    from pymonet.validation import is_failure, to_failure as to_failure_validation
    from pymonet.either import is_left
    from pymonet.monad_try import to_success

    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert fold(lazy_0) == str_0
    assert box_0 == Box(str_0)
    assert is_nothing(to_failure(lazy_0))

# Generated at 2022-06-25 23:34:32.260166
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def get_value():
        return 1

    int_1 = 1
    box_1 = Box(int_1)
    lazy_2 = box_1.to_lazy()
    boolean_3 = lazy_2.is_folded
    assert boolean_3 == False
    function_4 = lazy_2.value
    int_5 = function_4()
    assert int_5 == int_1


# Generated at 2022-06-25 23:34:34.398866
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = ')XNB+k_=j^'
    assert box_0.to_lazy().fold() == str_0


# Generated at 2022-06-25 23:34:40.936480
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    before = Box('test')
    after = before.to_lazy()
    assert before == Box('test')
    assert after == Box('test').to_lazy()
    assert after.map(lambda x: 1 + 1).value == 2
    assert after.map(lambda x: x * 1).value == 'test'
    assert after.map(lambda x: x.upper()).value == 'TEST'
    assert after.value == 'test'
    assert after.value == before.value



# Generated at 2022-06-25 23:34:44.706105
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    box_1 = box_0.to_lazy()

    assert isinstance(box_1, Lazy)
    assert isinstance(box_1.value(), str)
    assert box_1.value() == str_0


# Generated at 2022-06-25 23:36:12.123078
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '9'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:36:14.848883
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() is str_0

# Generated at 2022-06-25 23:36:18.177002
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    s = 'WH-?YVf*GmD'
    _lazy_0 = Box(s).to_lazy()
    assert _lazy_0.map(lambda s: s[:3].upper()).map(lambda s: s[-1] * len(s)).value() == 'MMM'

# Generated at 2022-06-25 23:36:23.213056
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '40>-?bu+~6P'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    lazy_0.fold(lambda: None)  # Run
    assert isinstance(lazy_0, pymonet.lazy.Lazy)
    # assert lazy_0.value == str_0



# Generated at 2022-06-25 23:36:27.413289
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    if not isinstance(lazy_0, Box):
        raise AssertionError('is not instance')

    if str_0 != lazy_0.value():
        raise AssertionError('not equal')



# Generated at 2022-06-25 23:36:30.600600
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)

    maybe_0 = box_0.to_lazy()

    assert maybe_0.value() == str_0



# Generated at 2022-06-25 23:36:32.119071
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'a') == Box('a').to_lazy()


# Generated at 2022-06-25 23:36:36.352523
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:36:38.668920
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'UH?3y+}($H$'
    box_0 = Box(str_0)
    box_1 = box_0.to_lazy()


# Generated at 2022-06-25 23:36:42.757969
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '^sKg`I(9,q3'
    len_1 = len(str_0)
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert len_1 == lazy_0.value()


_ = '''
~HA0r.;?wA8
'''