

# Generated at 2022-06-25 23:27:34.557160
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.maybe import Maybe

    bool_0 = True
    box_0 = Box(bool_0)
    box_1 = Box(bool_0)
    box_2 = Box(5)
    maybe_0 = Maybe.just(4)
    bool_1 = box_0 == box_1
    bool_2 = box_0 == box_2
    bool_3 = box_0 == maybe_0
    return bool_1, bool_2, bool_3


# Generated at 2022-06-25 23:27:37.934852
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test data
    bool_0 = True
    # Test execution
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    # Test assertion
    assert lazy_0.value == bool_0


# Generated at 2022-06-25 23:27:47.430826
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    bool_0 = True
    bool_1 = bool_0
    box_0 = Box(bool_0)
    box_1 = Box(bool_1)
    box_2 = box_1
    assert box_0 != box_1
    assert box_1 == box_2
    assert box_0 != box_2
    bool_0 = False
    bool_1 = False
    box_0 = Box(bool_0)
    box_1 = Box(bool_1)
    box_2 = box_1
    assert box_0 == box_1
    assert box_1 == box_2
    assert box_0 == box_2
    bool_0 = False
    bool_1 = True
    box_0 = Box(bool_0)
    box_1 = Box(bool_1)

# Generated at 2022-06-25 23:27:50.654049
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    bool_0 = True
    box_0 = Box(bool_0)
    bool_1 = True
    box_1 = Box(bool_1)
    assert box_0 == box_1


# Generated at 2022-06-25 23:27:53.498858
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    bool_0 = True
    box_0 = Box(bool_0)
    box_1 = Box(bool_0)
    assert box_0 == box_1



# Generated at 2022-06-25 23:28:00.463019
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import fmap

    box_0 = Box(3)
    lazy_0 = box_0.to_lazy()

    # Tests fmap for lazy
    lazy_fmap_0 = fmap(lambda x: x + 2, lazy_0)
    assert isinstance(lazy_fmap_0, Lazy)
    assert lazy_fmap_0.eval() == 5

    # Tests method to_lazy
    assert isinstance(box_0.to_lazy(), Lazy)
    assert isinstance(box_0.to_lazy().eval(), int)
    assert box_0.to_lazy().eval() == 3



# Generated at 2022-06-25 23:28:05.604124
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy
    def f():
        return 5
    int_0 = 5
    box_0 = Box(int_0)
    lazy = Lazy(f)
    assert isinstance(box_0.to_lazy(), Lazy)
    assert box_0.to_lazy() == lazy


# Generated at 2022-06-25 23:28:10.827983
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    bool_0 = True
    box_0 = Box(bool_0)
    box_1 = Box(str())
    assert not box_0 == box_1
    box_1 = Box(bool_0)
    assert box_0 == box_1


# Generated at 2022-06-25 23:28:20.363018
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Test if method Box.to_lazy() returns correct Lazy monad"""
    from pymonet.lazy import Lazy

    val_0 = 0
    val_1 = 1
    val_2 = 2
    val_3 = 3

    box_0 = Box(val_0)
    lazy_0 = Lazy(lambda: val_0)

    assert box_0.to_lazy() == lazy_0
    assert box_0 == lazy_0.to_box()

    assert box_0.to_lazy().map(lambda x: x + val_1) == lazy_0.map(lambda x: x + val_1)
    assert box_0 == lazy_0.to_box()


# Generated at 2022-06-25 23:28:22.993896
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(0).to_lazy() == Lazy(lambda: 0)
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box([0, 1]).to_lazy() != Lazy(lambda: [0, 1])


# Generated at 2022-06-25 23:28:28.517386
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    bool_0 = True
    box_0 = Box(bool_0)

    lazy_1 = Lazy(lambda: box_0.value)

    assert box_0.to_lazy() == lazy_1

# Generated at 2022-06-25 23:28:31.111491
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box('Test')
    lazy_0 = box_0.to_lazy()

    assert lazy_0.value == 'Test'


# Generated at 2022-06-25 23:28:32.827045
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(False).to_lazy() == Box(False).to_lazy()


# Generated at 2022-06-25 23:28:35.466933
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    x = Box(1)
    assert x.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:28:41.684893
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # type: () -> None
    from pymonet.lazy import Lazy
    from pymonet.monad_try import monad_try_call_unwind

    bool_0 = True
    box_0 = Box(bool_0)  # type: Box[bool]
    lazy_0 = box_0.to_lazy()  # type: Lazy[bool]
    assert(isinstance(lazy_0, Lazy))
    assert(monad_try_call_unwind(lazy_0) == bool_0)


# Generated at 2022-06-25 23:28:46.780268
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    box_0_lazy = box_0.to_lazy()
    assert isinstance(box_0_lazy, pymonet.lazy.Lazy)
    bool_1 = bool_0
    assert box_0_lazy.eval() == bool_1


# Generated at 2022-06-25 23:28:50.219883
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(True)

    assert(box_0.to_lazy() == Lazy(lambda: True))


# Generated at 2022-06-25 23:28:52.214641
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().unpack() == Box(5).value


# Generated at 2022-06-25 23:28:56.075283
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 2
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    value_0 = lazy_0.value()
    assert value_0 == int_0

# Generated at 2022-06-25 23:29:02.058206
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    value = Try(2, is_success=True)

    lazy_box = Box(value).to_lazy()
    assert isinstance(lazy_box, Lazy)
    assert lazy_box.is_lazy()
    assert not lazy_box.is_evaluated()
    assert lazy_box.value() == value



# Generated at 2022-06-25 23:29:06.537943
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Create function, which is fold Lazy and return result
    def to_lazy_result(folds: Callable[[int], int]) -> int:
        return folds(lambda: 1)

    assert to_lazy_result(Box(lambda: 1).to_lazy()) == 1

# Generated at 2022-06-25 23:29:08.068265
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(2)
    lazy = box.to_lazy()
    assert lazy.is_fold == False
    assert lazy.value() == 2

# Generated at 2022-06-25 23:29:14.439101
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    # test case
    lazy_0 = Lazy(lambda : 42)
    box_0 = Box(21)
    assert box_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:29:18.366649
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = Lazy(lambda: True)
    result_0 = box_0.to_lazy()
    assert lazy_0 == result_0


# Generated at 2022-06-25 23:29:22.210499
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for function which transform Box into Lazy.
    """

    from pymonet.lazy import Lazy

    box_0 = Box(bool(True))
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded is False
    assert lazy_0.value == bool(True)

# Generated at 2022-06-25 23:29:26.289493
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    box_1 = box_0.to_lazy()
    assert bool_0 == box_0.value
    assert bool_0 == box_1.value()

# Generated at 2022-06-25 23:29:29.877583
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)

    assert box_0.to_lazy().value() == bool_0



# Generated at 2022-06-25 23:29:32.732308
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    number_0 = 1
    box_0 = Box(number_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.unfold() is number_0

# Generated at 2022-06-25 23:29:36.049509
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold_left(lambda acc, x: acc + x) == 1
    assert Box([1, 2, 3]).to_lazy().fold_left(lambda acc, x: acc + [x]) == [1, 2, 3]

# Generated at 2022-06-25 23:29:40.805054
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import flattened

    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: bool_0)
    assert flattened(lazy_0) == bool_0



# Generated at 2022-06-25 23:29:46.076188
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box_0 = Box(1)
    assert(box_0.to_lazy() == Lazy(lambda: 1))


# Generated at 2022-06-25 23:29:48.574709
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == bool_0


# Generated at 2022-06-25 23:29:58.103546
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure

    failure_0 = Failure(True, is_success=False)
    lazy_0 = failure_0.to_lazy()
    assert lazy_0.value == failure_0

    failure_1 = Failure(False, is_success=False)
    lazy_1 = failure_1.to_lazy()
    assert lazy_1.value == failure_1

    box_0 = Box(True)
    lazy_2 = box_0.to_lazy()
    assert lazy_2.value() == True

    bool_1 = False
    box_1 = Box(bool_1)
    lazy_3 = box_1.to_lazy()
    assert lazy_3.value() == False


# Generated at 2022-06-25 23:30:03.195038
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    box_0 = Box(2)

    assert isinstance(box_0.to_lazy(), Lazy)
    assert box_0.to_lazy().cata(Functor) == 2

    with pytest.raises(TypeError):
        box_0.to_lazy().cata(2)


# Generated at 2022-06-25 23:30:10.406454
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Maybe(1).to_lazy() == Lazy(lambda: Maybe(1))
    assert Maybe(None).to_lazy() == Lazy(lambda: Maybe(None))
    assert Maybe(1).to_lazy().to_maybe() == Maybe(1)
    assert Maybe(None).to_lazy().to_maybe() == Maybe(None)
    assert Maybe(1).to_lazy().force() == 1
    assert Maybe(None).to_lazy().force() == None



# Generated at 2022-06-25 23:30:11.100417
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()



# Generated at 2022-06-25 23:30:13.073252
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: True)



# Generated at 2022-06-25 23:30:17.588509
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = False
    box_0 = Box(bool_0)

    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert not lazy_0.is_folded()
    assert lazy_0.force() == bool_0



# Generated at 2022-06-25 23:30:19.370554
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(4).to_lazy()().unsafe_extract()
    assert result == 4


# Generated at 2022-06-25 23:30:21.304889
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box(10)

    assert(box.to_lazy() == Lazy(lambda : 10))

# Generated at 2022-06-25 23:30:25.297630
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(True).to_lazy()
    assert result.fold(lambda: None)


# Generated at 2022-06-25 23:30:29.295244
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = False
    box_0 = Box(bool_0)
    lazy = box_0.to_lazy()
    val_0 = lazy.get()
    assert val_0 == bool_0


# Generated at 2022-06-25 23:30:32.963081
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try

    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box(Try(42, is_success=True)).to_lazy() == Lazy(lambda: Try(42, is_success=True))


# Generated at 2022-06-25 23:30:42.079328
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy_list import LazyList
    from pymonet.list_ import List

    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5

    box_lazy_0 = Box(int_0).to_lazy()
    assert isinstance(box_lazy_0, Lazy)
    assert box_lazy_0.unbox() == int_0

    box_lazy_1 = Box(Lazy(lambda: int_1)).to_lazy()
    assert isinstance(box_lazy_1, Lazy)
    assert box_lazy_1.unbox() == int_1


# Generated at 2022-06-25 23:30:47.496086
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Empty lazy monad
    test_lazy = Box(bool).to_lazy()
    assert test_lazy.value() is False

    # Filled lazy monad with empty function
    test_lazy = Box(bool).to_lazy().fmap(lambda x: box_0)
    assert test_lazy.value() is False


# Generated at 2022-06-25 23:30:52.816469
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_test_utils import (
        assert_left,
        assert_right,
        assert_nothing,
        assert_just
    )

    list_0 = [1, 2, 3]
    box_0 = Box(list_0)

    lazy_0 = box_0.to_lazy()

    assert_right(box_0)
    assert_left(lazy_0)


# Generated at 2022-06-25 23:30:57.797904
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box class.

    :return: Nothing to return
    :rtype: None
    """
    from pymonet.lazy import Lazy

    bool_0 = True
    box_0 = Box(bool_0)

    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value == Lazy(bool_0)



# Generated at 2022-06-25 23:31:01.204198
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 23:31:13.841926
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation, Failure

    int_0 = 123
    lazy_0 = Box(int_0).to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_computed() is False
    assert lazy_0.get_value() is int_0

    str_0 = 'foo'
    lazy_1 = Box(str_0).to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.is_computed() is False
    assert lazy_1.get_value() == str_0

    try_0 = Try(1234, is_success=True)

# Generated at 2022-06-25 23:31:18.543855
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Test case 1:
    # Test with concrete value
    box_0 = Box(Lazy(lambda: 3))
    assert box_0.to_lazy() == Lazy(lambda: Lazy(lambda: 3))



# Generated at 2022-06-25 23:31:30.012865
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.__repr__() == "<Lazy: callable>"
    assert lazy_0.__str__() == "<Lazy: callable>"
    assert lazy_0.get() == bool_0


# Generated at 2022-06-25 23:31:34.215310
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test of test_Box_to_lazy
    """
    m = Box(0).to_lazy()
    assert isinstance(m, Lazy)
    assert m.is_folded() is False


# Generated at 2022-06-25 23:31:37.728504
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    assert box_0.to_lazy() == Lazy(lambda: True)
    assert box_0.to_lazy() == Lazy(lambda: True)



# Generated at 2022-06-25 23:31:43.521037
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def _function_0():
        str_0 = "string 0"
        return str_0
    function_0 = _function_0

    boxed_function_0 = Box(function_0)
    lazy_0 = boxed_function_0.to_lazy()

    assert_equal(lazy_0.get(), "string 0")

# Generated at 2022-06-25 23:31:48.298126
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # 100 % covered
    initial_value = 12
    expected_value = 12

    box = Box(initial_value)
    lazy = box.to_lazy()

    lazy_value = lazy.value()

    assert lazy_value == expected_value



# Generated at 2022-06-25 23:31:52.883697
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.boolean import Boolean

    box_0 = Box(Boolean(True))
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold() == Boolean(True)



# Generated at 2022-06-25 23:31:56.041305
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # left_value = Box(42)
    # right_value = Box(28)
    # assert left_value.to_lazy() == right_value.to_lazy()
    pass

# Generated at 2022-06-25 23:32:01.937437
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Transform Box into Lazy with returning value function.

    :returns: not folded Lazy monad with function returning previous value
    :rtype: Lazy[Function(() -> A)]
    """
    from pymonet.lazy import Lazy

    lazy_0 = Box(True).to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() is True



# Generated at 2022-06-25 23:32:07.009351
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from lazy_test_fixtures import *

    nested_list2_result, _ = nested_list2_actual()
    lazy_result = Box(nested_list2).to_lazy()
    lazy_expected = Lazy(nested_list2)

    assert callable(lazy_result.value)
    assert lazy_result.value() == lazy_expected.value()
    assert lazy_result == lazy_expected



# Generated at 2022-06-25 23:32:09.787103
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure
    int_0 = 0
    box_0 = Box(int_0)
    assert box_0.to_lazy() == Lazy(lambda: int_0)

# Generated at 2022-06-25 23:32:16.722701
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(False)
    box_1 = box_0.to_lazy()
    assert isinstance(box_1, Lazy)
    assert False is box_1.value()


# Generated at 2022-06-25 23:32:25.711031
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box class
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    bool_0 = True
    box_0 = Box(bool_0)
    box_1 = Box(Lazy(lambda: "value"))
    box_2 = Box(Try(1))
    box_3 = Box(Validation.success(1))
    box_4 = Box(Right(1))
    box_5 = Box(Maybe.just(1))

    assert(box_0.to_lazy() == Lazy(lambda: bool_0))

# Generated at 2022-06-25 23:32:28.802974
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_lazy import Lazy
    # set up
    box = Box(10)
    expected = Lazy(lambda: 10)

    # exercise
    actual = box.to_lazy()
    # verify
    assert expected == actual


# Generated at 2022-06-25 23:32:31.015143
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet import Lazy

    _box_0 = Box
    _lazy_0 = Lazy()
    _box_0.to_lazy()



# Generated at 2022-06-25 23:32:31.849594
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(True).to_lazy().ge

# Generated at 2022-06-25 23:32:34.126676
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box_0 = Box(0)
    lazy_0 = Lazy(lambda: 0)
    assert box_0.to_lazy() == lazy_0

# Generated at 2022-06-25 23:32:37.687772
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Tests, whether to_lazy method returns correct result.

    :rtype: None
    """
    assert Box(3).to_lazy().fold(lambda: 0) == 3
    assert Box(0).to_lazy().fold(lambda: 3) == 3



# Generated at 2022-06-25 23:32:39.706225
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-25 23:32:46.063097
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    maybe_int_0 = Maybe(123)
    maybe_int_1 = Maybe(None)

    tested_maybe_int_0 = maybe_int_0.to_lazy()
    tested_maybe_int_1 = maybe_int_1.to_lazy()

    assert Lazy(lambda: 123) == tested_maybe_int_0 and Lazy(lambda: None) == tested_maybe_int_1



# Generated at 2022-06-25 23:32:48.008583
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = Box(True).to_lazy().get_value()()

    box_0 = Box(bool_0)



# Generated at 2022-06-25 23:32:57.388727
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:32:59.787517
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_case_1():
        bool_0 = True
        box_0 = Box(bool_0)
        assert box_0.to_lazy().is_computed() is False


# Generated at 2022-06-25 23:33:03.033064
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == bool_0
    lazy_1 = lazy_0.map(lambda value: not value)

# Generated at 2022-06-25 23:33:05.938833
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def function_0():
        return 1

    lazy = Lazy(1)
    box_0 = Box(lazy)
    result = box_0.to_lazy()

    assert result.fold(function_0, lambda: None) == 1


# Generated at 2022-06-25 23:33:09.606588
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(1)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_folded() is False
    assert lazy_0.force() == 1


# Generated at 2022-06-25 23:33:13.285681
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    first = Box(10)
    second = first.to_lazy()

    assert isinstance(second, Lazy)
    assert second.value is None
    assert second.computed is False
    assert first.value == second.compute()



# Generated at 2022-06-25 23:33:18.093653
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1
    assert Box('1').to_lazy().value() == '1'
    assert Box([]).to_lazy().value() == []
    assert Box({}).to_lazy().value() == {}
    assert Box(lambda x: x + 1).to_lazy().value()(1) == 2


# Generated at 2022-06-25 23:33:25.964298
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == bool_0
    bool_1 = False
    box_1 = Box(bool_1)
    lazy_1 = box_1.to_lazy()
    assert lazy_1.value() == bool_1
    str_0 = 'abc'
    box_2 = Box(str_0)
    lazy_2 = box_2.to_lazy()
    assert lazy_2.value() == str_0
    str_1 = 'efg'
    box_3 = Box(str_1)
    lazy_3 = box_3.to_lazy()
    assert lazy_3.value() == str_1
    int_0 = 123

# Generated at 2022-06-25 23:33:28.226791
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(2)
    func_0 = box_0.to_lazy().get_value()
    res_0 = func_0()
    assert res_0 == 2


# Generated at 2022-06-25 23:33:33.892817
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Preparation
    string = 'test message'
    box_0 = Box(string)
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Action
    lazy_0 = box_0.to_lazy()

    # Assertion
    if isinstance(lazy_0, Try):
        raise AssertionError("Lazy monad has unexpected type")
    elif isinstance(lazy_0.value(), str):
        return True
    raise AssertionError("Lazy monad has unexpected type")



# Generated at 2022-06-25 23:33:58.321298
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box_0 = Box(5)
    lazy_0 = box_0.to_lazy()
    return Lazy(lambda: 5, is_folded=False) == lazy_0


# Generated at 2022-06-25 23:34:02.806768
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert bool_0 == lazy_0.value(), "Folding lazy. Result: {0}".format(lazy_0)



# Generated at 2022-06-25 23:34:06.212230
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_1 = Box(bool_0)
    str_1 = 'lazy'
    lazy_0 = box_1.to_lazy()
    assert lazy_0.fold(lambda: str_1) == 'lazy'


# Generated at 2022-06-25 23:34:10.770913
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_folded is False
    assert lazy_0.value() == bool_0


# Generated at 2022-06-25 23:34:15.639995
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test that transform Lazy monad with function returning previous value.

    :return: None
    :rtype: None
    """
    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == bool_0


# Generated at 2022-06-25 23:34:24.976813
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    box_1 = box_0.to_lazy()

    # assert box_1.value() == bool_0
    # assert isinstance(box_1, Lazy)



# Generated at 2022-06-25 23:34:29.676504
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    box_1 = box_0.to_lazy()

    assert isinstance(box_1, Lazy)

    box_2 = box_1.fold()

    assert bool_0 == box_2


# Generated at 2022-06-25 23:34:35.552600
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Arrange
    value = 5
    box_0 = Box(value)

    # Assert
    assert callable(box_0.to_lazy().value)
    assert box_0.to_lazy().value() == value



# Generated at 2022-06-25 23:34:38.293551
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # global box_0
    # global int_0
    box_0 = Box[int](int_0)
    int_1 = box_0.to_lazy()


# Generated at 2022-06-25 23:34:41.205031
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box_0 = Box("value")
    result = box_0.to_lazy()
    assert type(result) == Lazy
    assert result.fold() == "value"


# Generated at 2022-06-25 23:35:32.906542
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.monad_try import Failure
    from pymonet.lazy import Lazy
    from pymonet.monad_list import MonadList
    from pymonet.monad_optional import MonadOptional
    from pymonet.validation import Validation
    from pymonet.validation import Failure as ValidationFailure

    def _(x):
        return x

    assert Box(0).to_lazy() == Lazy(_(0))
    assert Box(0).to_lazy().flat_map(lambda x: x+1) == Lazy(_(1))
    assert Box(0).to_lazy().map(lambda x: x+1) == Lazy(_(1))

# Generated at 2022-06-25 23:35:35.927771
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test case for Box.to_lazy
    """
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == bool_0



# Generated at 2022-06-25 23:35:37.099695
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:35:40.809508
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    int_0 = 1
    box_0 = Box(int_0)

    # Act
    lazy_0 = box_0.to_lazy()

    # Assert
    assert(lazy_0.is_folded is False)
    assert(lazy_0.value() == 1)



# Generated at 2022-06-25 23:35:43.264071
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()
    assert bool_0 == lazy_0.force()


# Generated at 2022-06-25 23:35:45.614131
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a = 1
    box_0 = Box(a)
    box_1 = box_0.to_lazy()
    assert a == box_1.value()


# Generated at 2022-06-25 23:35:48.166992
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_lazy import Lazy

    box_0 = Box(0)
    lazy_0 = Lazy.unit(0)
    lazy_1 = box_0.to_lazy()
    assert lazy_0.equals(lazy_1)



# Generated at 2022-06-25 23:35:56.787214
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.maybe import Maybe, Nothing, Just
    from pymonet.either import Either, Left, Right
    from pymonet.monad_try import Try, Failure, Success
    from pymonet.monadplus import MonadPlus
    from pymonet.monad import Monad

    # Test class inheritance
    assert issubclass(Box, Functor)
    assert issubclass(Box, MonadPlus)
    assert issubclass(Box, Monad)

    # Test instance of classes
    box_0 = Box(0)
    assert isinstance(box_0, Box)
    assert isinstance(box_0, Functor)

# Generated at 2022-06-25 23:35:59.205835
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bool_0 = True
    box_0 = Box(bool_0)
    result_0 = box_0.to_lazy().value()
    assert result_0 is True, 'AssertionError'


# Generated at 2022-06-25 23:36:03.650653
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_lazy = Box(lambda: 'hello').to_lazy()
    assert box_lazy.fold()() == 'hello'

    assert isinstance(Box(True).to_lazy(), Lazy)
    assert isinstance(Box(False).to_lazy(), Lazy)
    assert isinstance(Box(['l', 'f', 'm']).to_lazy(), Lazy)
