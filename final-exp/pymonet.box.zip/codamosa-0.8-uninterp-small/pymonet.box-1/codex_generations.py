

# Generated at 2022-06-25 23:27:30.671189
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box(11)
    assert box_0 == Box(11)


# Generated at 2022-06-25 23:27:35.176004
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_1 = '1f3T{0%%|rT[JH$'
    box_1 = Box(str_1)

    str_2 = '1f3T{0%%|rT[JH$'
    box_2 = Box(str_2)

    assert box_1.__eq__(box_2) is True

    str_3 = '1fG3T{0%%|rT[JH$'
    box_3 = Box(str_3)

    assert box_1.__eq__(box_3) is False


# Generated at 2022-06-25 23:27:42.881208
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    assert box_0.__eq__(box_0) == True
    int_0 = -1828657680
    box_1 = Box(int_0)
    assert box_0.__eq__(box_1) == False
    box_2 = Box(int_0)
    assert box_1.__eq__(box_2) == True
    box_3 = Box(int_0)
    assert box_1.__eq__(box_3) == True


# Generated at 2022-06-25 23:27:53.075845
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    str_1 = '1f3T{0%%|rT[JH$'
    box_1 = Box(str_1)
    bool_0 = box_0 == box_1
    str_2 = '1f3T{0%%|rT[JH$'
    box_2 = Box(str_2)
    box_3 = Box(box_2)
    bool_1 = box_0 == box_3
    str_3 = '1a3T{0%%|rT[JH$'
    box_4 = Box(str_3)
    bool_2 = box_0 == box_4
    assert bool_0 and bool_1 and not bool

# Generated at 2022-06-25 23:27:56.386382
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.box import Box

    box_0 = Box('foo')
    box_1 = Box('bar')
    box_2 = Box('baz')

    assert box_0 == box_0
    assert not box_0 == box_1
    assert not box_0 == box_2


# Generated at 2022-06-25 23:27:59.015340
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    box_1 = Box(str_0)
    assert box_0 == box_1


# Generated at 2022-06-25 23:28:04.184736
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.eval()


# Generated at 2022-06-25 23:28:14.393532
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '1f3T{0%%|rT[JH$'
    str_1 = '1f3T{0%%|rT[JH$'
    assert Box(str_0) == Box(str_1)

    str_0 = '1f3T{0%%|rT[JH$'
    str_1 = '1f3T{0%%|rT[JH$'
    assert Box(str_0) == Box(str_1)

    str_0 = ''
    str_1 = ''
    assert Box(str_0) == Box(str_1)

    list_0 = [2, 3, 4, 5, 5]
    list_1 = [2, 3, 4, 5, 5]
    assert Box(list_0) == Box(list_1)

# Generated at 2022-06-25 23:28:20.491636
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box('str').__eq__(Box('str'))) is True
    assert (Box('box').__eq__(Box('str'))) is False

    assert (Box(False).__eq__(Box(False))) is True
    assert (Box(False).__eq__(Box(True))) is False

    assert (Box(0).__eq__(Box(0))) is True
    assert (Box(0).__eq__(Box(1))) is False

    assert (Box(None).__eq__(Box(0))) is False



# Generated at 2022-06-25 23:28:25.750739
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = '1f3T{0%%|rT[JH$'
    str_1 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    box_1 = Box(str_1)
    assert box_0 == box_1
    str_2 = '1f3T{0%%|rT[JH$'
    str_3 = '1f3T{0%%|rT[JH$'
    box_2 = Box(str_2)
    box_3 = Box(str_3)
    assert box_2 == box_3
    str_4 = '1f3T{0%%|rT[JH$'
    str_5 = '1f3T{0%%|rT[JH$'

# Generated at 2022-06-25 23:28:28.686260
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(123).to_lazy().value() == 123



# Generated at 2022-06-25 23:28:36.365387
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Unit tests for Box.to_lazy"""

    # Check if method to_lazy works properly
    # We have boxed integer number and we try to translate it into Lazy,
    # which contains function that returns this number
    assert Box(1).to_lazy().get() == 1
    assert Box("Hello").to_lazy().get() == "Hello"
    assert Box((2, 3)).to_lazy().get() == (2, 3)
    assert Box(1.0).to_lazy().get() == 1.0


# Unit tests for method to_either of class Box

# Generated at 2022-06-25 23:28:39.618725
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Transfer to box.
    box = Box(10)

    # Transform to lazy.
    lazy_box = box.to_lazy()

    # Folding lazy
    result = lazy_box.fold(lambda: 0)

    assert result == 10


# Generated at 2022-06-25 23:28:42.924664
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_ = '1f3T{0%%|rT[JH$'
    box = Box(str_)
    lz = box.to_lazy()
    assert type(lz) == Lazy
    assert lz.value() == str_


# Generated at 2022-06-25 23:28:51.238401
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert(lazy_0.is_memoized())
    assert(lazy_0.value() is str_0)
    assert(lazy_0.is_memoized())
    assert(lazy_0.value() is str_0)
    assert(lazy_0.is_memoized())
    return lazy_0

# Generated at 2022-06-25 23:28:59.167671
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test with constructor
    # Init values
    str_1 = '1f3T{0%%|rT[JH$'
    box_1 = Box(str_1)
    # Computation
    lazy_1 = box_1.to_lazy()
    # Assertions
    assert isinstance(lazy_1, Lazy)
    value_1 = lazy_1.flatten()
    assert value_1 == str_1
    # Init values
    str_2 = '1f3T{0%%|rT[JH$'
    box_2 = Box(str_2)
    # Computation
    lazy_2 = box_2.to_lazy()
    # Assertions
    assert isinstance(lazy_2, Lazy)
    value_2 = lazy_2.flatten()

# Generated at 2022-06-25 23:29:01.632038
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('1f3T{0%%|rT[JH$').to_lazy().value().value == '1f3T{0%%|rT[JH$'

# Generated at 2022-06-25 23:29:06.573907
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_lazy import is_lazy, force
    from pymonet.monad_lazy import is_lazy, force

    box = Box(0)
    box_lazy = box.to_lazy()
    assert isinstance(box_lazy, Lazy)
    assert is_lazy(box_lazy)
    assert force(box_lazy) == 0


# Generated at 2022-06-25 23:29:10.938886
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('str').to_lazy() == Lazy(lambda: 'str')



# Generated at 2022-06-25 23:29:12.018465
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()



# Generated at 2022-06-25 23:29:16.744501
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(42)
    assert box_0.to_lazy().value() == 42



# Generated at 2022-06-25 23:29:20.370318
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Data initialization
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    # Check method to_lazy
    assert box_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:29:26.028006
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    ret_0 = box_0.to_lazy()
    str_1 = ret_0.value()
    assert str_0 == str_1


# Generated at 2022-06-25 23:29:31.952924
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    string = '1f3T{0%%|rT[JH$'
    box = Box(string)
    result = box.to_lazy()
    assert isinstance(result, Lazy)
    assert isinstance(result, Monad)
    assert result.fold() == string

# Generated at 2022-06-25 23:29:36.982394
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.bind(lambda s: s)
    assert str_0 == lazy_0.evaluate()


# Generated at 2022-06-25 23:29:46.318745
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_test import test_Lazy_map_Lazy
    from pymonet.monad_test import test_Lazy_unit

    orig_value = '4@$4#4$4#4%4^4'
    box_0 = Box(orig_value)

    mapper = lambda x: ''.join([y for y in x])
    lazy_monad = box_0.to_lazy()
    assert isinstance(lazy_monad, Lazy)
    assert lazy_monad.is_folded is False

    lazy_monad = test_Lazy_map_Lazy(lazy_monad, mapper)
    assert lazy_monad.is_folded is False

    lazy_monad = test_Lazy_

# Generated at 2022-06-25 23:29:51.164635
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    def func_0():
        return str_0

    assert lazy_0.is_lazy()
    assert lazy_0.get().get_value() == func_0().get_value()
    assert lazy_0.get().get_value() is str_0


# Generated at 2022-06-25 23:29:55.493723
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Setup
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)

    # Exercise
    lazy_0 = box_0.to_lazy()

    # Verify
    assert isinstance(lazy_0, Lazy)



# Generated at 2022-06-25 23:29:59.264221
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    expected_result = '1f3T{0%%|rT[JH$'
    test_case_0()
    actual_result = box_0.to_lazy().value()
    assert expected_result == actual_result

# Generated at 2022-06-25 23:30:03.961249
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    box_lazy_0 = box_0.to_lazy()
    assert isinstance(box_lazy_0, Lazy)
    assert box_lazy_0.value() == str_0


# Generated at 2022-06-25 23:30:09.416700
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    input_ = 3
    box = Box(input_)
    result = box.to_lazy()
    assert result.value() == input_


# Generated at 2022-06-25 23:30:15.702415
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = -1
    bool_0 = bool(0)
    func_0 = test_case_0
    num_0 = +1
    obj_0 = dict()
    str_0 = '1f3T{0%%|rT[JH$'
    list_0 = []
    set_0 = set()
    float_0 = float()
    tuple_0 = ()
    int_15 = test_case_0()
    str_1 = '1f3T{0%%|rT[JH$'

# Generated at 2022-06-25 23:30:25.297680
# Unit test for method to_lazy of class Box

# Generated at 2022-06-25 23:30:27.441325
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = test_case_0()
    Box(value).to_lazy()

# Generated at 2022-06-25 23:30:30.600223
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'abc'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.value()
    assert str_0 == str_1

# Generated at 2022-06-25 23:30:37.227511
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()


# Generated at 2022-06-25 23:30:41.946974
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)

    assert str_0 == box_0.to_lazy().fold()


# Generated at 2022-06-25 23:30:45.692237
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = Box('1f3T{0%%|rT[JH$').to_lazy()
    if type(lazy_0) != pymonet.lazy.Lazy:
        raise AssertionError()


# Generated at 2022-06-25 23:30:48.351407
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    x = 'str_0'
    x = Box(x).to_lazy()

    assert x.fold(lambda x: x) == 'str_0'


# Generated at 2022-06-25 23:30:52.256770
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    method_name = 'to_lazy'
    class_method = getattr(Box, method_name)
    assert callable(class_method)

    box_0 = Box(0)
    result_0 = class_method(box_0)

    assert result_0.value() == 0


# Generated at 2022-06-25 23:31:03.925383
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import cProfile, pstats

    pr = cProfile.Profile()
    pr.enable()

    # Test source code
    test_case_0()

    pr.disable()
    ps = pstats.Stats(pr).sort_stats('cumulative')
    ps.print_stats()


# Generated at 2022-06-25 23:31:05.451510
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box("hello").to_lazy().value() == "hello"


# Generated at 2022-06-25 23:31:08.529610
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(str_0).to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:31:11.363117
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    Box('1f3T{0%%|rT[JH$').to_lazy() == Lazy(lambda: '1f3T{0%%|rT[JH$')


# Generated at 2022-06-25 23:31:19.585465
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test 1
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert(isinstance(lazy_0, Lazy))
    assert(lazy_0.get_value() == str_0)

    # Test 2
    int_0 = 14907
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert(isinstance(lazy_0, Lazy))
    assert(lazy_0.get_value() == int_0)

    # Test 3
    bool_0 = True
    box_0 = Box(bool_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:31:20.799717
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().get() == 3


# Generated at 2022-06-25 23:31:26.364555
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '1f3T{0%%|rT[JH$'
    box = Box(str_0)
    lazy = box.to_lazy()

# Generated at 2022-06-25 23:31:31.124614
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    rng = mock.Mock()
    for value0 in rng:
        for value1 in rng:
            box = Box(value0)
            assert box.to_lazy().get() == value0
            box = Box(value1)
            assert box.to_lazy().get() == value1
            box = Box(value1)
            assert box.to_lazy().get() == value1


# Generated at 2022-06-25 23:31:34.464733
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_4 = Box(str_0)
    lazy_4 = box_4.to_lazy()
    assert(len(lazy_4.get())>0)


# Generated at 2022-06-25 23:31:37.651474
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box = Box(str_0)
    assert box.to_lazy().force() == str_0

num = 7


# Generated at 2022-06-25 23:31:54.338578
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Check that Box.to_lazy returns lazy monad with function returning value stored in box.
    """
    from pymonet.lazy import Lazy

    box = Box(42)
    lazy = box.to_lazy()
    lazy_value = lazy.value()

    assert lazy_value() == 42
    assert lazy == Lazy(lambda: 42)


# Generated at 2022-06-25 23:31:55.909760
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(7).to_lazy() == Box(7).to_lazy()


# Generated at 2022-06-25 23:31:59.494124
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    try:
        bool_0 = str_0.isalnum()
    except Exception:
        bool_0 = False
    assert bool_0


# Generated at 2022-06-25 23:32:02.353403
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(10).to_lazy()) == 'Lazy[value=<function test_case_0.<locals>.f at 0x000001FB9F1D03A8>]'


# Generated at 2022-06-25 23:32:04.229478
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1234
    assert Box(int_0).to_lazy().unfold() == int_0


# Generated at 2022-06-25 23:32:08.153607
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_value = Box(str_0)
    lazy_value = box_value.to_lazy()
    assert isinstance(lazy_value, pymonet.Lazy)
    assert lazy_value.value() == str_0, 'Mapped value is not expected'


# Generated at 2022-06-25 23:32:09.493258
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(test_case_0).to_lazy().value() == test_case_0


# Generated at 2022-06-25 23:32:12.489683
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value_0 = '1g_[R|>H%6Z`0{]Fo'
    box = Box(value_0)
    value_1 = box.to_lazy()

    assert value_1.get() == value_0


# Generated at 2022-06-25 23:32:16.603704
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    def f(a):
        return a

    x = Box(4)
    y = x.to_lazy()
    z = y.map(f)
    assert isinstance(z, Monad)



# Generated at 2022-06-25 23:32:20.383242
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    x0 = Box(str_0).to_lazy()

    assert x0.is_folded() == False
    assert x0.value() == str_0


# Generated at 2022-06-25 23:32:53.030151
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(3)
    lazy = box.to_lazy()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    assert lazy.data() == 3
    assert lazy.map(lambda value: value ** 2).data() == 9
    assert lazy.filter((lambda value: value % 2 == 0)).is_nothing()
    assert lazy.filter((lambda value: value % 2 == 1)).is_just()
    assert lazy.flat_map(lambda value: Lazy(lambda: value ** 2)).data() == 9


# Generated at 2022-06-25 23:32:56.523072
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test 1:
    str_0 = '1f3T{0%%|rT[JH$'
    box = Box(str_0)
    lazy = box.to_lazy()
    assert lazy.get_value() == str_0


# Generated at 2022-06-25 23:32:58.793027
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box('foo')
    assert box.to_lazy() == Lazy(box.value)


# Generated at 2022-06-25 23:33:05.363775
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Prepare test data
    str_0 = '1f3T{0%%|rT[JH$'
    str_1 = 'm2%cZf)P~$|{;e'
    str_2 = 'pXC&WC{i}3<g$nI'
    str_3 = 'n?pN}5/x[M9X&5i'

    # First exercise
    result_0 = Box(str_0).to_lazy()
    assert isinstance(result_0, Lazy)
    assert result_0.fold() == str_0

    # Second exercise
    result_1 = Box(str_1).to_lazy()
    assert isinstance(result_1, Lazy)

# Generated at 2022-06-25 23:33:06.193278
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    pass



# Generated at 2022-06-25 23:33:15.311087
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    test_cases = [
        Box(Lazy(lambda: 1)),
        Box(Lazy(lambda: '1')),
        Box(Lazy(lambda: [1, 2, 3])),
        Box(Try(1, is_success=True)),
        Box(Try('1', is_success=True)),
        Box(Try([1, 2, 3], is_success=True)),
        Box(Validation.success(1)),
        Box(Validation.success('1')),
        Box(Validation.success([1, 2, 3]))
    ]

    for test_case in test_cases:
        result = test_case.to_lazy()

# Generated at 2022-06-25 23:33:19.102071
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('f').to_lazy() == Lazy(lambda: 'f')
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1.3).to_lazy() == Lazy(lambda: 1.3)



# Generated at 2022-06-25 23:33:26.927942
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def str_to_int(value):
        return int(value)
    test_case_1 = Box('1')
    test_case_2 = Box('101')
    test_case_3 = Box('2311')
    test_case_4 = Box('4')
    test_case_5 = Box('10')
    test_case_6 = Box('20')
    test_case_7 = Box('1')
    test_case_8 = Box('101')
    test_case_9 = Box('2311')
    test_case_10 = Box('4')
    test_case_11 = Box('10')
    test_case_12 = Box('20')
    test_case_13 = Box('1')
    test_case_14 = Box('101')

# Generated at 2022-06-25 23:33:31.885790
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def in_Box_to_lazy():
        str_0 = 'h'
        var_1 = Box(str_0)
        var_2 = var_1.to_lazy() if var_1 else None
        str_1 = var_2.value() if var_2 else None

    from time_benchmark import benchmark_func
    benchmark_func(in_Box_to_lazy)
    assert in_Box_to_lazy() is None


# Generated at 2022-06-25 23:33:34.688063
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    box_0 = Box(1)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.is_instance_of(Lazy)
    assert lazy_0.is_instance_of(Lazy[int])
    assert lazy_0.is_value() == False
    assert lazy_0.value() == 1


# Generated at 2022-06-25 23:34:08.751092
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box_0 = Box('hello')
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert not lazy_0.is_folded()
    assert lazy_0.value() == 'hello'
    assert lazy_0.is_folded()


# Generated at 2022-06-25 23:34:11.795298
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def f_0():
        return 'Enter'


    box_1 = Box(f_0)
    lazy_0 = box_1.to_lazy()
    assert lazy_0.value() == 'Enter'


# Generated at 2022-06-25 23:34:19.664734
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value.name == '<lambda>'
    str_1 = lazy_0.fold()
    assert str_1 == str_0
    box_1 = Box(str_0)
    lazy_1 = box_1.to_lazy()
    assert lazy_1.value.name == '<lambda>'
    str_2 = lazy_1.fold()
    assert str_2 == str_0
    str_3 = '1f3T{0%%|rT[JH$'
    box_2 = Box(str_3)
    lazy_2 = box_2.to_lazy

# Generated at 2022-06-25 23:34:25.633715
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad import \
        fn, join, functor_to_monad_transformer, monad_to_functor_transformer, \
        compose, compose_right, compose_left, compose_Maybe

    square = lambda x: x ** 2
    cube = lambda x: x ** 3
    increment = lambda x: x + 1

    assert not Box(1).to_lazy().is_folded()
    assert Box(1).to_lazy().get() == 1

    assert compose_Maybe(square, Box.to_lazy)(Box(1)).get() == 1



# Generated at 2022-06-25 23:34:30.368540
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)

    assert isinstance(box_0.to_lazy(), Lazy)
    assert box_0.to_lazy().value() == str_0


# Generated at 2022-06-25 23:34:32.708392
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    pass



# Generated at 2022-06-25 23:34:38.333160
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(1)
    lazy_0 = box_0.to_lazy()
    assert 1 == lazy_0.evaluate()

    box_1 = Box('asdas')
    lazy_1 = box_1.to_lazy()
    assert 'asdas' == lazy_1.evaluate()


# Generated at 2022-06-25 23:34:41.550844
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.get()



# Generated at 2022-06-25 23:34:44.442896
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'h@6U<%6$f=+Pn)~r}'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.fold()


# Generated at 2022-06-25 23:34:50.940350
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = 'o8PdG6^]I6U:e6r'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.unbox() == str_0


# Generated at 2022-06-25 23:35:55.636780
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_0 = Lazy(lambda: 'lazy')
    box_0 = Box(lazy_0)
    assert box_0.to_lazy() == Lazy(lambda: lazy_0)



# Generated at 2022-06-25 23:35:57.687959
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    lazy_0 = Box(str_0).to_lazy()


# Generated at 2022-06-25 23:36:04.900947
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    result_0 = box_0.to_lazy()
    assert result_0.value() == str_0
    str_1 = '8PzkC,vqww1Fx4p4<&'
    box_1 = Box(str_1)
    result_1 = box_1.to_lazy()
    assert result_1.value() == str_1
    str_2 = '1f3T{0%%|rT[JH$'
    box_2 = Box(str_2)
    result_2 = box_2.to_lazy()
    assert result_2.value() == str_2

# Generated at 2022-06-25 23:36:10.421976
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Declare variables
    str_0 = 'vr1f_C1{(pzO.~Jw'
    box_0 = Box(str_0)
    box_1: Box[Callable[[], str]] = box_0.to_lazy()
    str_6 = 'vr1f_C1{(pzO.~Jw'
    str_5 = box_1.value()
    str_1 = 'vr1f_C1{(pzO.~Jw'
    assert str_1 == str_5


# Generated at 2022-06-25 23:36:14.030394
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '1f3T{0%%|rT[JH$'

    box = Box(str_0)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == str_0



# Generated at 2022-06-25 23:36:16.090766
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'I\'m simple string.'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:36:17.768242
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # TODO create real test
    true_result = False
    # result = Box().to_lazy()
    assert true_result == result

# Generated at 2022-06-25 23:36:22.479936
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy

    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = pymonet.lazy.get(lazy_0)
    assert str_0 == str_1


# Generated at 2022-06-25 23:36:26.385767
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    val = lazy_0.get()
    expected = '1f3T{0%%|rT[JH$'
    assert val == expected


# Generated at 2022-06-25 23:36:29.280856
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '1f3T{0%%|rT[JH$'
    box_0 = Box(str_0)
    assert box_0.to_lazy().fold() == str_0