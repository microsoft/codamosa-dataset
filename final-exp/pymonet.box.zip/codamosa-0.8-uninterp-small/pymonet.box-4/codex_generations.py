

# Generated at 2022-06-25 23:27:29.429575
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) == 1



# Generated at 2022-06-25 23:27:31.595813
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    int_0 = -8
    box_0 = Box(int_0)
    box_1 = Box(int_0)
    assert (box_0 == box_1)


# Generated at 2022-06-25 23:27:33.847217
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    int_0 = 1048
    box_0 = Box(int_0)
    box_1 = Box(int_0)
    box_2 = Box.__eq__(box_0, box_1)



# Generated at 2022-06-25 23:27:37.893391
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0 == Lazy(lambda: 1048)


# Generated at 2022-06-25 23:27:40.915932
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy = box_0.to_lazy()
    assert lazy == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:27:46.948944
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    int_0 = 1048
    box_0 = Box(int_0)
    box_1 = Box(int_0)
    box_2 = Box(int_0)
    box_3 = Box(int_0)
    assert box_0.__eq__(box_1) and box_1.__eq__(box_0) and box_0.__eq__(box_0) and box_1.__eq__(box_1)

# Unit tests for method map of class Box

# Generated at 2022-06-25 23:27:48.193115
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-25 23:27:57.721560
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    def should_assert_equality_for_values_with_different_type_identity(value_1, value_2):
        assert Box[int](value_1) == Box[int](value_2)
        assert Box[str](value_1) == Box[str](value_2)
        assert Box[int](value_1) != Box[str](value_2)

    def should_assert_equality_for_values_with_same_type_identity(value_1, value_2):
        assert Box[int](value_1) == Box[int](value_2)
        assert Box[str](value_1) == Box[str](value_2)
        assert not Box[int](value_1) != Box[int](value_2)

# Generated at 2022-06-25 23:28:00.850769
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def lazy_factory(value: int) -> int: return value * 2
    box_0 = Box(10)
    box_0_lazy = box_0.to_lazy()
    lazy_result = box_0_lazy.map(lazy_factory).value()
    assert lazy_result == 20


# Generated at 2022-06-25 23:28:10.652465
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Test case 1
    int_0 = 185
    int_1 = 185
    box_0 = Box(int_0)
    box_1 = Box(int_1)
    result_0 = box_0 == box_1
    assert result_0 == True

    # Test case 2
    str_0 = 'qjfbxz'
    str_1 = 'ugcekc'
    box_2 = Box(str_0)
    box_3 = Box(str_1)
    result_1 = box_2 == box_3
    assert result_1 == False

    # Test case 3
    int_2 = 313
    int_3 = -876
    box_4 = Box(int_2)
    box_5 = Box(int_3)
    result_2 = box_4 == box_5

# Generated at 2022-06-25 23:28:20.492642
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    value_to_test = 1048
    box_to_test = Box(value_to_test)

    lazy_monad_value = box_to_test.to_lazy()
    assert isinstance(
        lazy_monad_value,
        Lazy
    )

    lazy_value = lazy_monad_value.value()
    assert value_to_test == lazy_value
    assert isinstance(
        lazy_value,
        int
    )



# Generated at 2022-06-25 23:28:21.879566
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(123)
    assert box_0.to_lazy() == Lazy(lambda: 123)

# Generated at 2022-06-25 23:28:28.216642
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == int_0
    lazy_1 = lazy_0.map(lambda x: x + 1024)
    assert lazy_1.value() == 2072


# Generated at 2022-06-25 23:28:31.910646
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:28:35.285249
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    lazy_0 = Lazy(lambda: int_0)
    box_0 = Box(lazy_0)
    lazy_1 = box_0.to_lazy()


# Generated at 2022-06-25 23:28:41.245133
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 1048
    box = Box(value)
    lazy_box = box.to_lazy()
    assert lazy_box.fold_left(lambda acc, _: acc + 1, 0) == 1
    assert lazy_box.fold_left(lambda acc, _: acc + 1, 0) == 1
    assert lazy_box.__str__() == "Lazy[foldable=False, value=<function Box.__init__.<locals>.<lambda> at 0x7fb41a1a9950>]"



# Generated at 2022-06-25 23:28:44.484632
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    str_0 = lazy_0.__str__()


# Generated at 2022-06-25 23:28:46.059217
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    Box(int_0).to_lazy()


# Generated at 2022-06-25 23:28:48.957353
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case #0
    box = Box(1048)
    lazy = box.to_lazy()
    assert lazy.value() == 1048
    assert lazy.fold() == 1048

# Generated at 2022-06-25 23:28:59.937495
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybes.maybe_maybe import Maybe

    def ge(value: int) -> int:
        return value * value

    box = Box(1048)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1048
    assert lazy.map(ge).value() == Lazy(ge).ap(box.to_lazy()).value()
    assert lazy.bind(ge) == Lazy(ge).ap(box.to_lazy()).value()
    assert lazy.bind(ge).ap(box.to_lazy()) == ge(lazy.value()).ap(box.to_lazy())
    assert lazy.to_maybe() == Maybe.just(box.value)


# Generated at 2022-06-25 23:29:05.241284
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert(isinstance(lazy_0, Lazy))
    assert(lazy_0.is_folded is False)

    lazy_0_value = lazy_0.value()

    assert(lazy_0_value == int_0)
    assert(lazy_0.is_folded is True)



# Generated at 2022-06-25 23:29:09.795693
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    int_1 = lazy_0.unfold()
    box_1 = box_0.to_lazy().to_box()
    assert int_0 == int_1
    assert box_0 == box_1
    int_2 = box_0.to_lazy().to_box().bind(lambda x: x + 10).value
    assert int_0 + 10 == int_2


# Generated at 2022-06-25 23:29:20.603088
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.test_utils import val_eq
    from pymonet.test_utils import expect_exception

    # Test case 0
    int_0 = 1058
    box_0 = Box(int_0)
    val_eq(
        box_0.to_lazy().evaluate(),
        int_0
    )

    # Test case 1
    int_0 = -1301
    box_0 = Box(int_0)
    val_eq(
        box_0.to_lazy().evaluate(),
        int_0
    )

    # Test case 2
    box_0 = Box(None)
    val_eq(
        box_0.to_lazy().evaluate(),
        None
    )

    # Test case 3
    int_0 = 0

# Generated at 2022-06-25 23:29:32.814629
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Initial data
    int_0 = 1048
    enum_0 = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
    # Create Box instance
    box_0 = Box(int_0)
    # Execute function
    lazy_0 = box_0.to_lazy()
    # Checking result
    assert lazy_0.value() == int_0
    # Re execute and checking
    assert lazy_0.value() == int_0
    # Reassign value
    lazy_0.assign(enum_0)
    # Checking after reassign
    assert lazy_0.value() == enum_0
    # Re execute and checking
    assert lazy_0

# Generated at 2022-06-25 23:29:35.443011
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # init Box with string
    box_0 = Box("some test string")

    lazy_0 = box_0.to_lazy()

    assert(box_0.value == lazy_0.get())



# Generated at 2022-06-25 23:29:38.155352
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    int_1 = lazy_0.get()


# Generated at 2022-06-25 23:29:41.729555
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1048
    def_0 = lambda: int_0
    box_0 = Box(int_0)
    check_0 = box_0.to_lazy() == Lazy(def_0)

# Generated at 2022-06-25 23:29:44.444661
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(1048)
    assert box_0.to_lazy().fold(lambda: None) == box_0.value


# Generated at 2022-06-25 23:29:46.402899
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    x = Box(0)
    y = x.to_lazy()
    assert y.value() == x.value


# Generated at 2022-06-25 23:29:49.774074
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy) and lazy_0.value() == int_0


# Generated at 2022-06-25 23:29:57.958147
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    input_value = 10
    expected_value = Lazy(lambda: 10)
    box = Box(input_value)
    result = box.to_lazy()
    assert expected_value == result


# Generated at 2022-06-25 23:30:00.248466
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    number = 1048
    box = Box(number)
    lazy = box.to_lazy()
    actual = lazy.unwrap()()
    assert actual == number



# Generated at 2022-06-25 23:30:02.239432
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

# Generated at 2022-06-25 23:30:04.715802
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    string = '1048'
    box = Box(string)
    lazy = box.to_lazy()

    assert lazy.value() == string



# Generated at 2022-06-25 23:30:09.123178
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    '''
    Box.to_lazy()
    '''
    box_0 = Box([])
    Lazy_0 = box_0.to_lazy()
    box_1 = Box(Lazy_0)
    box_2 = box_1.to_lazy()
    _ = box_2.__class__


# Generated at 2022-06-25 23:30:11.968256
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048576
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    result_0 = lazy_0.value()
    assert result_0 == int_0



# Generated at 2022-06-25 23:30:15.187173
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    def lazy_value():
        return 1048
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = Lazy(lazy_value)
    assert box_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:30:19.045679
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_lazy import Lazy

    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:30:21.346698
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test with positive value
    test_Box_to_lazy_positive()
    # Test with negative value
    test_Box_to_lazy_negative()



# Generated at 2022-06-25 23:30:25.944935
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy
    functor = Box(1048)
    monad = functor.to_lazy()

    assert(isinstance(monad, Monad))
    assert(isinstance(monad, Lazy))

    assert(monad.value() == 1048)


# Generated at 2022-06-25 23:30:35.788593
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(12)
    assert box_0.to_lazy().get() == 12


# Generated at 2022-06-25 23:30:40.311730
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    test_value = "test"
    test_Box = Box(test_value)
    result_Box = test_Box.to_lazy()
    assert result_Box.get() == test_value
    assert type(result_Box) == Lazy


# Generated at 2022-06-25 23:30:49.678778
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.functor import Functor
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Either
    from pymonet.maybe import Maybe

    box_0 = Box(1048)
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy[T]), "lazy_0 instance must be instance of Lazy"
    assert lazy_0.value() == 1048, "lazy_0 value must be equal to 1048"
    assert lazy_0.value() is not 1048, "lazy_0 value must be not equal to 1048"


# Generated at 2022-06-25 23:30:53.233203
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == 1048
    # assert lazy_0.fold() == 1048


# Generated at 2022-06-25 23:30:55.445107
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    original_value = 1048
    box = Box(original_value)
    lazy = box.to_lazy()

    assert lazy.force() == original_value


# Generated at 2022-06-25 23:30:57.718101
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    #Init
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    fold_0 = lazy_0.fold()
    pass



# Generated at 2022-06-25 23:31:02.465858
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    a = 9
    b = Lazy(lambda: a)
    assert Box(a).to_lazy() == b


# Generated at 2022-06-25 23:31:07.038570
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functions import identity
    from pymonet.functions import increment
    from pymonet.functions import sum_int

    # prepare
    current_value = 1
    box_to_lazy = Box(current_value)

    # test
    lazy = box_to_lazy.to_lazy()
    res = lazy.eval()

    # verify
    expected = current_value
    assert res == expected

    # prepare
    current_value = 1
    box_to_lazy = Box(Lazy(identity).eval())

    # test
    lazy = box_to_lazy.to_lazy()
    res = lazy.eval()

    # verify
    expected = current_value
    assert res == expected

    # prepare
    current

# Generated at 2022-06-25 23:31:10.408498
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    result_0 = Box(32).to_lazy()
    assert(isinstance(result_0, Lazy))
    assert(result_0.value() == 32)


# Generated at 2022-06-25 23:31:14.692746
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_a = Box(1)
    lazy_a = box_a.to_lazy()

    assert lazy_a.value() == 1


# Generated at 2022-06-25 23:31:35.334179
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1048
    box_0 = Box(int_0)
    lazy = Lazy(lambda: int_0)
    assert lazy == box_0.to_lazy()


# Generated at 2022-06-25 23:31:37.279312
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.itry import itry
    from pymonet.lazy import Lazy

    box_0 = Box(10)

    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 10



# Generated at 2022-06-25 23:31:40.465823
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as lazy

    x = lazy.Lazy(lambda: 2)
    assert x.to_lazy() == x


# Generated at 2022-06-25 23:31:44.145564
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(1048)
    assert box_0.to_lazy().value()() == 1048

    box_1 = Box('abc')
    assert box_1.to_lazy().value()() == 'abc'



# Generated at 2022-06-25 23:31:51.635974
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe, Nothing
    from pymonet.monad_try import Try

    for v in ([1, 2, 3], ['hello', 'world'], {'a': 1, 'b': 2, 'c': 3}, {1, 2, 3}, (1, 2, 3), 1, 'a', None):
        assert Box(v).to_lazy() == Lazy(lambda: v)


# Generated at 2022-06-25 23:31:54.939628
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == 1048


# Generated at 2022-06-25 23:31:57.494907
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1048).to_lazy().fold(buffer='') == '1048'
    assert Box(1048).to_lazy().fold(buffer='') == '1048'


# Generated at 2022-06-25 23:32:02.062872
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    expected_result = lazy(lambda: 9)
    actual_result = Box(9).to_lazy()
    assert actual_result == expected_result
    assert actual_result.is_folded is False
    assert actual_result.get_value() == expected_result.get_value()


# Generated at 2022-06-25 23:32:05.875913
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(True)
    lazy_0 = box_0.to_lazy()
    lazy_1 = Lazy(lambda: True, is_memoized=False)
    b_0 = lazy_0 == lazy_1
    assert b_0


# Generated at 2022-06-25 23:32:11.976672
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.list import List
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try

    # List
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    lazy_0.fold() == box_0.value

    # Maybe
    maybe_0 = box_0.to_maybe()
    assert isinstance(maybe_0, Maybe)
    assert maybe_0.is_just()
    assert maybe_0.get() == box_0.value

    # Either
    either_0 = box_0.to_either()
   

# Generated at 2022-06-25 23:32:49.325664
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 42
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold() == int_0


# Generated at 2022-06-25 23:32:51.475279
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    t = Box(10)
    assert t.to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-25 23:32:54.961712
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded is False
    assert lazy_0.unwrap() is int_0


# Generated at 2022-06-25 23:33:00.919331
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.examples.example_applicative_lazy import math_sum

    int_0 = 5
    box_0 = Box(int_0)
    box_1 = box_0.map(lambda x: x)  # Box[int]
    lazy_0: Lazy[int] = box_1.to_lazy()
    lazy_1: Lazy[int] = lazy_0.ap(box_0)
    answer: Lazy[int] = lazy_1.ap(lazy_0)
    assert answer.fold(math_sum) == 15

# Generated at 2022-06-25 23:33:04.588861
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    test_val = lazy_0.get()
    try:
        assert test_val == 1048
        print("TestBox.test_Box_to_lazy assertTrue")
    except AssertionError as e:
        print("TestBox.test_Box_to_lazy assertFalse")


# Generated at 2022-06-25 23:33:07.475537
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:33:09.092416
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(1048)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:33:15.348787
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()
    try_0 = box_0.to_try()
    try_1 = lazy_0.to_try()
    if try_0 != try_1:
        raise Exception('Unit test for method to_lazy of class Box has failed')


# Generated at 2022-06-25 23:33:21.267245
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
     Unit test for method to_lazy of class Box
    """

    from pymonet.lazy import Lazy, memoized

    int_0 = 1048
    box_0 = Box(int_0)
    assert isinstance(box_0.to_lazy(), Lazy)

    lazy_0 = box_0.to_lazy()
    assert lazy_0._thunk() == int_0

    lazy_0 = memoized(lambda: box_0.to_lazy())
    assert lazy_0._thunk() == int_0



# Generated at 2022-06-25 23:33:23.449432
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0).to_lazy().resolve()
    assert int_0 == box_0
    return



# Generated at 2022-06-25 23:34:41.166111
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    case_0 = Box(1048).to_lazy()
    assert isinstance(case_0, Lazy)


# Generated at 2022-06-25 23:34:51.373011
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    lazy_0 = Lazy(lambda: 0)
    box_1048 = Box(1048)
    lazy_1048 = box_1048.to_lazy()
    actual_value = lazy_1048.value()
    assert actual_value == 1048
    # 
    try_0 = Try(0, is_success=True)
    box_failure = Box(try_0)
    lazy_failure = box_failure.to_lazy()
    actual_value = lazy_failure.value()
    assert actual_value.is_success
    class_name = actual_value.__class__.__name__
    assert class_name == 'Try'
    actual_value = actual_value.value

# Generated at 2022-06-25 23:34:55.110110
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    Box_0 = Box(int_0)
    Lazy_0 = Box_0.to_lazy()
    int_0_0 = Lazy_0.value()


# Generated at 2022-06-25 23:35:02.299386
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure

    for i in range(100):
        box_0 = Box(i)
        lazy_0 = box_0.to_lazy()
        assert type(lazy_0) is Lazy
        assert lazy_0.get() == i

        box_1 = Box(None)
        try_0 = box_1.to_try()
        assert type(try_0) is Try
        assert type(try_0.get()) is Failure
        assert try_0.get().get_value() == 'Value can\'t be None'



# Generated at 2022-06-25 23:35:06.710345
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(1).to_lazy()
    assert isinstance(lazy, Lazy)

    lazy_value = lazy.get_value()
    assert lazy_value == 1

    empty_lazy = Box(None).to_lazy()
    assert isinstance(empty_lazy, Lazy)

    empty_lazy_value = empty_lazy.get_value()
    assert empty_lazy_value == None

# Generated at 2022-06-25 23:35:13.085768
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def try_get_value_from_box(box):
        return box.map(lambda x: x).to_try()

    box = Box(123)
    assert box.to_lazy() == Lazy(box.value)

    box = Box(123)
    assert try_get_value_from_box(box) == Try(123)

    box = Box(123)
    assert try_get_value_from_box(box) == Try(123)

    box = Box(Try(123))
    assert try_get_value_from_box(box) == Try(Try(123))

    box = Box(Lazy(lambda: 123))
    assert try_get_value_from_box(box) == Try

# Generated at 2022-06-25 23:35:14.875576
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.folded == False


# Generated at 2022-06-25 23:35:21.723220
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    str_0 = Lazy(lambda: 'Hello world!')
    str_1 = Lazy(lambda: '')

    assert (str_0.to_box().to_lazy() == str_0)
    assert (str_1.to_box().to_lazy() == str_1)

    def func_0():
        return Maybe.just('Hello world!')

    str_2 = Lazy(func_0)

    assert (str_2.to_box().to_lazy() == str_2)


# Generated at 2022-06-25 23:35:25.449328
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(10)
    lazy_0 = box_0.to_lazy()
    lazy_1 = lazy_0.map(lambda x: x + 1)
    int_0 = lazy_0.force()
    int_1 = lazy_1.force()
    assert int_0 == 10
    assert int_1 == 11


# Generated at 2022-06-25 23:35:28.908572
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1048
    box_0 = Box(int_0)
    lazy_0 = Lazy.unit(int_0)
    lazy_1 = box_0.to_lazy()
    assert lazy_0 == lazy_1
