

# Generated at 2022-06-25 23:27:33.639474
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from random import randint
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    import pymonet.validation as validation

    for _ in range(100):
        str_0 = str(randint(0, 100))

        box_0 = Box(str_0)

        def func():
            return str_0

        lazy_var_0 = Lazy(func)

        test_0 = lazy_var_0.bind(lambda x: Maybe.just(x))
        var_1 = box_0.to_lazy().bind(lambda x: Maybe.just(x))

        assert test_0 == var_1


# Generated at 2022-06-25 23:27:38.384890
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Kb+d>=@}Q'
    list_0 = [str_0]
    str_1 = str_0
    var_0 = Box(str_1)
    var_1 = var_0.to_lazy()
    var_2 = var_1.force()
    assert var_2 == 'Kb+d>=@}Q'


# Generated at 2022-06-25 23:27:42.202295
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """

    box_0 = Box(7.24)
    box_1 = Box(2.03)
    assert box_0 != box_1
    assert box_0 == Box(7.24)


# Generated at 2022-06-25 23:27:44.072003
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    num_0 = 5
    box_0 = Box(num_0)
    var_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:27:47.292684
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    number_0 = 0
    var_0 = Box(number_0).to_lazy()
    assert isinstance(var_0, Lazy)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 23:27:56.868947
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.either import Either

    a = Box(4).to_lazy()
    assert isinstance(a, Lazy)
    assert a() == 4

    b = Box(Maybe.just(3)).to_lazy()
    assert isinstance(b, Lazy)
    assert b().or_else(None) == 3

    c = Box(Either.left('Error')).to_lazy()
    assert isinstance(c, Lazy)
    assert c().is_left
    assert c().get_left() == 'Error'

    d = Box(4).to_lazy().map(lambda x: Maybe.just(x + 1)).value
    assert isinstance(d, Maybe)

# Generated at 2022-06-25 23:28:05.483945
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test for method __eq__ of class Box
    """
    str_0 = 'O/N3N'
    str_1 = 'N/N3N'
    box_0 = Box(str_0)
    box_1 = Box(str_1)
    eq_0 = box_0 == box_1
    assert(isinstance(eq_0, bool))
    eq_1 = eq_0
    assert(eq_1 == False)
    box_2 = Box(str_1)
    eq_2 = box_0 == box_2
    assert(eq_2 == False)
    str_2 = 'O/N3N'
    box_3 = Box(str_2)
    eq_3 = box_0 == box_3
    assert(eq_3 == True)
    str_3

# Generated at 2022-06-25 23:28:17.235222
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '|3/H@2E>f_'
    str_1 = '~A]9bI?p-L'
    str_2 = 'IcxK,]HkiA'
    str_3 = 'ZT>)UH{aU_'
    float_0 = float(str_3)
    list_0 = [str_2, str_1, str_0]
    str_4 = 'NxL}p8F4oK'
    str_5 = '1tW8[vS2(t'
    list_1 = [str_4, str_5]
    set_0 = {str_1, str_2}
    tuple_0 = (str_3, str_0)
    tuple_1 = (str_4, tuple_0)
    tuple

# Generated at 2022-06-25 23:28:20.999212
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'a'
    str_1 = 'a'
    int_0 = 0
    box_0 = Box[str](str_0)
    box_1 = Box[str](str_1)
    assert None is None
    assert not box_0 == int_0
    assert box_0 == box_1


# Generated at 2022-06-25 23:28:23.290846
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    assert isinstance(Box('0').to_lazy(), Lazy)
    # Test case 1
    assert isinstance(Box('0').to_lazy(), Lazy)


# Generated at 2022-06-25 23:28:28.179687
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box(1)
    assert Lazy(lambda: 1) == box.to_lazy()


# Generated at 2022-06-25 23:28:32.251865
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Set up test data
    var_0 = None
    box_0 = Box(var_0)

    # Invoke method to_lazy() with test data
    result = box_0.to_lazy()

    # Check result
    assert result == Lazy(var_0)



# Generated at 2022-06-25 23:28:35.635849
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    box_0 = Box(var_0)
    assert box_0.to_lazy() == Lazy(lambda: var_0)


# Generated at 2022-06-25 23:28:36.880456
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test case for `Box.to_lazy` method
    """

    box = Box(1)
    assert box.to_lazy() == box.to_lazy()


# Generated at 2022-06-25 23:28:38.798336
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    result = box_0.to_lazy()


# Generated at 2022-06-25 23:28:41.031849
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    box_1 = box_0.to_lazy()
    assert box_1.folded
    assert (type(box_1.value())) == type(None)


# Generated at 2022-06-25 23:28:44.604841
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_0 = Box(1).to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 1


# Generated at 2022-06-25 23:28:49.314554
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = ["var_0"]
    box_0 = Box(var_0)

    def func_0():
        return var_0

    laz_0 = box_0.to_lazy()
    assert laz_0.is_lazy()
    assert laz_0 == Lazy(func_0)


# Generated at 2022-06-25 23:28:52.611866
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    result_0 = box_0.to_lazy()
    assert result_0.value() == var_0



# Generated at 2022-06-25 23:28:56.788075
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 'Test'
    box_0 = Box(var_0)

    var = box_0.to_lazy()

    assert var is not None
    assert var.is_callable
    assert var.is_folded is False
    assert var.get() is var_0


# Generated at 2022-06-25 23:29:02.016326
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = Box(None)
    var_1 = Lazy(lambda: var_0)
    var_2 = var_0.to_lazy()
    assert var_1 == var_2



# Generated at 2022-06-25 23:29:04.257907
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    try:
        box_0 = Box(1)
        
        errors_count, assertions_count = pytest.doctest_helper(box_0.to_lazy.__doc__, globals(), True)
        assert errors_count == 0

    except AssertionError as e:
        print(e)
        assert False


# Generated at 2022-06-25 23:29:14.755921
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    var_0 = 0
    var_1 = 1
    var_2 = 2
    try_0 = Try(var_0, is_success=True)
    try_1 = Try(var_1, is_success=False)
    validation_0 = Validation(valid=var_0, invalid=var_2)
    validation_1 = Validation(valid=var_1, invalid=var_2)
    box_0 = Box(var_0)
    box_1 = Box(var_1)
    box_2 = Box(var_2)
    box_try_0 = Box(try_0)
    box_try_1 = Box(try_1)

# Generated at 2022-06-25 23:29:16.158746
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == 1



# Generated at 2022-06-25 23:29:18.545948
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_1 = 1
    box_1 = Box(var_1).to_lazy()
    assert box_1.fold() == var_1


# Generated at 2022-06-25 23:29:19.405018
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    pass


# Generated at 2022-06-25 23:29:21.936208
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold() == var_0



# Generated at 2022-06-25 23:29:24.754726
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:29:29.276487
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    
    box_0 = Box(1)
    result_0 = box_0.to_lazy()
    assert isinstance(result_0, Lazy) is True
    


# Generated at 2022-06-25 23:29:32.172549
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Unit test for method to_lazy of class Box
    var_0 = None
    var_1 = Box(var_0)
    assert var_1.to_lazy() is not None


# Generated at 2022-06-25 23:29:36.457426
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:29:38.528748
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    lazy = box.to_lazy()
    assert lazy.value() == 1


# Generated at 2022-06-25 23:29:47.676275
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = Box(42)
    result_0 = var_0.to_lazy()
    assert result_0 == Lazy(lambda: 42), "Wrong result"
    var_1 = Box(None)
    result_1 = var_1.to_lazy()
    assert result_1 == Lazy(lambda: None), "Wrong result"
    var_2 = Box([1])
    result_2 = var_2.to_lazy()
    assert result_2 == Lazy(lambda: [1]), "Wrong result"
    var_3 = Box({2})
    result_3 = var_3.to_lazy()
    assert result_3 == Lazy(lambda: {2}), "Wrong result"

# Generated at 2022-06-25 23:29:49.574608
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = 2
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    assert isinstance(var_1, Lazy)


# Generated at 2022-06-25 23:29:51.238020
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:29:54.564484
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold(lambda: "empty")() == "empty"


# Generated at 2022-06-25 23:29:56.204706
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(var_0).to_lazy() == Lazy(lambda: var_0)


# Generated at 2022-06-25 23:30:01.800282
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = 42
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    assert var_1 is not None
    assert isinstance(var_1, Lazy)
    assert isinstance(var_1.value, type(lambda x: x))
    assert var_1.value() == 42


# Generated at 2022-06-25 23:30:05.724845
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    from pymonet.lazy import Lazy
    value = 5
    box = Box(value)

    # Act
    lazy = box.to_lazy()

    # Assert
    assert isinstance(lazy, Lazy)
    assert lazy.value() == value


# Generated at 2022-06-25 23:30:14.001829
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 5
    box_0 = Box(var_0)
    box_0_to_lazy_0 = box_0.to_lazy()
    box_0_to_lazy_1 = box_0.to_lazy()
    assert box_0_to_lazy_0 is box_0_to_lazy_1
    assert box_0_to_lazy_1.is_same_instance(box_0_to_lazy_0)
    box_0_to_lazy_0_get_0 = box_0_to_lazy_0.get()
    assert box_0_to_lazy_0_get_0 is var_0
    assert box_0_to_lazy_0_get_0 is var_0



# Generated at 2022-06-25 23:30:23.015852
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_2 = None
    box_2 = Box(var_2)
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = box_2.to_lazy()
    var_7 = var_6.get()
    var_8 = var_7()


# Generated at 2022-06-25 23:30:28.173895
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(2)
    lazy_0 = box_0.to_lazy()
    excep_0 = Exception()

    try:
        lazy_0.force()
    except Exception as e:
        excep_0 = e

    assert isinstance(excep_0, Exception)



# Generated at 2022-06-25 23:30:32.228747
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    check_0 = lazy_0.is_folded()
    check_1 = lazy_0.get_value()
    assert check_0 == False
    assert check_1 == None
    return


# Generated at 2022-06-25 23:30:32.619206
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert True == True

# Generated at 2022-06-25 23:30:34.404816
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Asserting NoneType to Lazy
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:30:36.204701
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    assert box_0.to_lazy()


# Generated at 2022-06-25 23:30:47.009823
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    assert type(box_0.to_lazy()) is Lazy

    var_0 = int()
    box_0 = Box(var_0)
    assert type(box_0.to_lazy()) is Lazy

    var_0 = []
    box_0 = Box(var_0)
    assert type(box_0.to_lazy()) is Lazy

    var_0 = object()
    box_0 = Box(var_0)
    assert type(box_0.to_lazy()) is Lazy

    var_0 = str()
    box_0 = Box(var_0)
    assert type(box_0.to_lazy()) is Lazy

    var_0 = complex()

# Generated at 2022-06-25 23:30:55.405663
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test with None value
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold(lambda: None) == var_0

    # Test with int value
    var_1 = 1
    box_1 = Box(var_1)
    lazy_1 = box_1.to_lazy()
    assert lazy_1.fold(lambda: 1) == var_1

    # Test with string value
    var_2 = 'value'
    box_2 = Box(var_2)
    lazy_2 = box_2.to_lazy()
    assert lazy_2.fold(lambda: 'value') == var_2



# Generated at 2022-06-25 23:30:58.528986
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 0
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    assert var_1.is_folded == False
    var_2 = var_1.value()
    assert var_2 == 0


# Generated at 2022-06-25 23:31:07.668658
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = True
    box_0 = Box(var_0)
    var_1 = None
    box_1 = Box(var_1)
    var_2 = False
    box_2 = Box(var_2)
    var_3 = Box(True)
    box_3 = Box(var_3)
    var_4 = Box(var_2)
    box_4 = Box(var_4)

    from pymonet.lazy import Lazy

    assert box_0.to_lazy() == Lazy(lambda: var_0)
    assert box_1.to_lazy() == Lazy(lambda: var_1)
    assert box_2.to_lazy() == Lazy(lambda: var_2)

# Generated at 2022-06-25 23:31:21.271477
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)



# Generated at 2022-06-25 23:31:26.460009
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    for var_0 in [None]:
        box_0 = Box(var_0)
        result = box_0.to_lazy()

        assert isinstance(result, Lazy)
        assert callable(result.value)
        assert result.value() == var_0

# Generated at 2022-06-25 23:31:29.421010
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var = 'test'
    box = Box(var)

    assert isinstance(box.to_lazy().eval(), str)
    assert box.to_lazy().eval() == var

    # Unit test for method to_maybe of class Box

# Generated at 2022-06-25 23:31:34.844516
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_lazy import Lazy

    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    def set_lazy_0():
        return var_0
    assert lazy_0 == Lazy(set_lazy_0)


# Generated at 2022-06-25 23:31:37.687894
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy = box_0.to_lazy()
    assert lazy.value() == var_0


# Generated at 2022-06-25 23:31:42.681151
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = None
    box_0 = Box(box_0)
    lazy_0 = None
    lazy_0 = box_0.to_lazy()
    val_0 = lazy_0.value
    assert val_0 is None


# Generated at 2022-06-25 23:31:51.723999
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    1. Wraps arg value into Box
    2. transforms Box into Lazy
    3. check Lazy is lazy and function is callable
    """
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    value = 42

    box_0 = Box(value)
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_0, Monad)
    assert lazy_0.is_lazy
    assert callable(lazy_0.value)


# Generated at 2022-06-25 23:31:53.735112
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = Box(2)
    var_1 = var_0.to_lazy()



# Generated at 2022-06-25 23:32:02.814589
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    string_0 = 'A'
    string_1 = 'B'
    box_0 = Box(string_1)
    lazy_0 = box_0.to_lazy()
    lazy_1 = lazy_0.compose(lambda var_0: Box(var_0 + string_0)).fmap(lambda var_0: var_0 + string_0)
    lazy_2 = lazy_0.compose(lambda var_1: Box(var_1 + string_0)).fmap(lambda var_0: var_0 + string_0)
    var_0 = lazy_1.fold()
    var_1 = lazy_2.fold()
    assert(var_0 == var_1)


# Generated at 2022-06-25 23:32:05.640413
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    var_0 = None
    box_0 = Box(var_0)
    assert isinstance(box_0.to_lazy(), Lazy)

# Generated at 2022-06-25 23:32:27.772644
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 5
    box_0 = Box(var_0)
    assert 5 == box_0.to_lazy().get()


# Generated at 2022-06-25 23:32:30.111687
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    box_1 = box_0.to_lazy()
    assert lazy_eq(box_1, box_0)


# Generated at 2022-06-25 23:32:32.850128
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().value() == 2
    assert Box("test").to_lazy().value() == "test"
    assert Box({1: 2}).to_lazy().value() == {1: 2}


# Generated at 2022-06-25 23:32:41.597639
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 23:32:43.387239
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 1
    box = Box(value)
    lazy = box.to_lazy()
    assert lazy.value is value

# Generated at 2022-06-25 23:32:47.466812
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 45
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    assert var_1.value() == 45, "Method to_lazy() in class Box return invalid value"


# Generated at 2022-06-25 23:32:49.873351
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    assert box_0.to_lazy().value() is None

# Unit tests for method to_maybe of class Box

# Generated at 2022-06-25 23:32:52.355679
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    box_0 = Box(var_0)
    assert isinstance(box_0.to_lazy(), Lazy)


# Generated at 2022-06-25 23:32:55.818714
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    assert isinstance(var_1, Lazy)


# Generated at 2022-06-25 23:33:03.507591
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(9)
    assert isinstance(box_0.to_lazy(), Lazy)
    box_1 = Box(9)
    assert isinstance(box_0.to_lazy(), Lazy)
    box_2 = Box(9)
    assert isinstance(box_0.to_lazy(), Lazy)
    assert (box_2.to_lazy() == Lazy(lambda: 9))
    var_0 = None
    box_3 = Box(var_0)
    assert isinstance(box_0.to_lazy(), Lazy)
    var_1 = None
    box_4 = Box(var_0)
    assert isinstance(box_0.to_lazy(), Lazy)
    assert box_0.value == 9
    assert box_1.value == 9


# Generated at 2022-06-25 23:33:52.292228
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from lazy import Lazy
    from optional import Optional

    assert isinstance(Box(0).to_lazy(), Lazy)
    assert 0 == Box(0).to_lazy().get()
    assert Optional.just(1) == Box(0).to_lazy().map(lambda x: x + 1).to_optional()



# Generated at 2022-06-25 23:33:55.758928
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    assert isinstance(var_1, Lazy)
    assert var_1.is_folded is False
    var_2 = var_1.resolve()
    assert var_2 is var_0
    return



# Generated at 2022-06-25 23:33:58.099172
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    var_2 = var_1.fold(lambda: None)
    assert var_2 is None


# Generated at 2022-06-25 23:34:02.192833
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    result = box_0.to_lazy()
    assert result.is_lazy
    assert not result.is_folded
    assert result.value() is None

# Generated at 2022-06-25 23:34:05.158864
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(1).to_lazy()) == 'Lazy[value=<function Box.to_lazy.<locals>.<lambda> at 0x7f78b8483b70>]'



# Generated at 2022-06-25 23:34:07.848993
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = Lazy(lambda: None)
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()



# Generated at 2022-06-25 23:34:11.443294
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Positive case test
    var_0 = [1, 2, 3]
    box_0 = Box(var_0)

    assert box_0.to_lazy().get() == var_0, "Box to Lazy unit test failed"



# Generated at 2022-06-25 23:34:19.536818
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.validation import Validation

    box_0 = Box(Try(1, True))
    assert box_0.to_lazy() == Lazy(lambda: 1)

    box_1 = Box(Lazy(lambda: Try(1, True)))
    assert box_1.to_lazy() == Lazy(lambda: Try(1, True))

    box_2 = Box(Maybe(1))
    assert box_2.to_lazy() == Lazy(lambda: 1)

    box_3 = Box(Right("a"))
    assert box_3.to_lazy() == Lazy(lambda: "a")



# Generated at 2022-06-25 23:34:23.555165
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Case 0
    var_0 = Box(None)
    var_1 = var_0.to_lazy()
    assert var_1.is_folded(), str(var_1)
    assert var_1.value() is var_0.value, str(var_1)


# Generated at 2022-06-25 23:34:26.811340
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    result_0 = box_0.to_lazy()
    assert result_0 == None


# Generated at 2022-06-25 23:36:13.248139
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    box_0_expect = Lazy(lambda: var_0)
    box_0_actual = box_0.to_lazy()
    assert box_0_expect == box_0_actual
    var_1 = 1.0
    box_1 = Box(var_1)
    box_1_expect = Lazy(lambda: var_1)
    box_1_actual = box_1.to_lazy()
    assert box_1_expect == box_1_actual
    var_2 = 'a'
    box_2 = Box(var_2)
    box_2_expect = Lazy(lambda: var_2)
    box_2_actual = box_2.to_lazy()
    assert box

# Generated at 2022-06-25 23:36:14.340405
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert(Box(10).to_lazy())



# Generated at 2022-06-25 23:36:16.785949
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    val_0 = box_0.to_lazy()
    assert val_0 is not None


# Generated at 2022-06-25 23:36:21.827844
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Create box
    box_0 = Box(3)

    # Transform box into lazy
    lazy_0 = box_0.to_lazy()

    # Check that lazy is not None
    assert lazy_0 is not None

    # Evaluate lazy
    lazy_0_value = lazy_0.get()

    # Check that lazy value is correct
    assert lazy_0_value == 3



# Generated at 2022-06-25 23:36:23.662421
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)

    assert box_0.to_lazy().value() == box_0.value



# Generated at 2022-06-25 23:36:27.311927
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_substituted() is False
    assert lazy_0.is_memoized() is False
    assert lazy_0.is_forced() is False


# Generated at 2022-06-25 23:36:29.965756
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = Lazy(lambda: 42)
    box_0 = Box(var_0)


# Generated at 2022-06-25 23:36:31.475733
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 5
    box_0 = Box(var_0)

    res_0 = box_0.to_lazy()



# Generated at 2022-06-25 23:36:38.095047
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(None).to_lazy() == None
    assert Box(True).to_lazy() == True
    assert Box(False).to_lazy() == False
    assert Box(0).to_lazy() == 0
    assert Box(100.0).to_lazy() == 100.0
    assert Box("").to_lazy() == ""
    assert Box("test").to_lazy() == "test"
    assert Box([]).to_lazy() == []
    assert Box([100]).to_lazy() == [100]
    assert Box(["test"]).to_lazy() == ["test"]


# Generated at 2022-06-25 23:36:39.167954
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(1).to_lazy(), Lazy)
