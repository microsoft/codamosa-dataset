

# Generated at 2022-06-25 23:27:41.684629
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box(1)
    box_1 = Box(1)
    box_2 = Box('1')
    box_3 = Box(1.0)
    box_4 = Box(2)
    box_5 = Box([1, 2, 3])
    box_6 = Box((1, 2, 3))
    box_7 = Box({1, 2, 3})
    box_8 = Box({'one': 1, 'two': 2, 'three': 3})
    assert box_0 == box_1
    assert box_0 == box_3
    assert not box_0 == box_2
    assert not box_0 == box_4
    assert not box_0 == box_5
    assert not box_0 == box_6
    assert not box_0 == box_7

# Generated at 2022-06-25 23:27:45.791827
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    #Case 1:
    box_0 = Box("Hello")
    box_1 = Box("Hello")
    if (box_0 != box_1):
        raise Exception("Test case 0 failed")
    if (box_0 == box_1):
        raise Exception("Test case 1 failed")
    #Case 2:



# Generated at 2022-06-25 23:27:51.626945
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box('')
    box_1 = Box('')
    box_2 = box_0.__eq__(box_1)
    box_3 = Box('')
    box_4 = Box('')
    box_5 = box_3.__eq__(box_4)
    box_6 = Box('x')
    box_7 = box_6.__eq__(box_6)


# Generated at 2022-06-25 23:27:55.675353
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'KU-#6PBZz4'
    str_1 = 'KU-#6PBZz4'
    box_0 = Box(str_0)
    box_1 = Box(str_1)
    assert(box_0 == box_1)



# Generated at 2022-06-25 23:27:57.683151
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')


# Generated at 2022-06-25 23:28:02.969516
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    str_0 = 'Z{1^|F,p^Jm-lkv#Ua"e'
    box_0 = Box(str_0)
    str_1 = box_0.__str__()
    str_2 = box_0.to_lazy()



# Generated at 2022-06-25 23:28:10.913176
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(1)
    b = Box(1)
    c = Box(2)
    
    assert (a == a), "Expected 'True'"
    assert (a == b), "Expected 'True'"
    assert (a != c), "Expected 'False'"
    assert (b == a), "Expected 'True'"
    assert (b == b), "Expected 'True'"
    assert (b != c), "Expected 'False'"
    assert (c != a), "Expected 'False'"
    assert (c != b), "Expected 'False'"
    assert (c == c), "Expected 'True'"


# Generated at 2022-06-25 23:28:15.522444
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Z{1^|F,p^Jm-lkv#Ua"e'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.fold()


# Generated at 2022-06-25 23:28:19.338084
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_a = 'bwwu~"V{XdO#}V;c[S'
    box_0 = Box(str_a)
    str_b = 'Y?4:"ChaJ;'
    box_1 = Box(str_b)

    assert box_0.__eq__(box_1) is False

# Generated at 2022-06-25 23:28:21.753612
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(0)
    lazy_0 = box_0.to_lazy()
    int_0 = lazy_0.value()
    assert int_0 == 0



# Generated at 2022-06-25 23:28:29.588947
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    try:
        str_0 = 'Y?4:"ChaJ;'
        box_0 = Box(str_0)
        assert box_0.to_lazy().value() == str_0
        assert box_0.to_lazy().map(lambda x: x.upper()).value() == str_0.upper()
    except Exception:
        return False

    return True


# Generated at 2022-06-25 23:28:31.696823
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box("abc")
    assert box_0.to_lazy() == Lazy("abc")


# Generated at 2022-06-25 23:28:35.886735
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    lazy_Box_0 = Box(str_0).to_lazy()

    assert(lazy_Box_0.value() == str_0)




test_case_0()
test_Box_to_lazy()

# Generated at 2022-06-25 23:28:39.165871
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.unbox()
    assert str_0 == str_1


# Generated at 2022-06-25 23:28:41.031843
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    assert box_0.to_lazy().is_folded is False


# Generated at 2022-06-25 23:28:43.500524
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a = Box(1)
    lazy = a.to_lazy()
    assert lazy.fold() == 1


# Generated at 2022-06-25 23:28:46.567139
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:28:57.747038
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_lazy().value() == 1
    assert Box('abc').to_lazy() == Lazy(lambda: 'abc')
    assert Box('abc').to_lazy().value() == 'abc'
    assert Box(True).to_lazy() == Lazy(lambda: True)
    assert Box(True).to_lazy().value() == True
    assert Box(1.5).to_lazy() == Lazy(lambda: 1.5)
    assert Box(1.5).to_lazy().value() == 1.5
    assert Box('a').to_lazy() != Lazy(lambda: 1.5)
    assert Box('a').to_lazy

# Generated at 2022-06-25 23:29:02.222947
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.just import Just

    box_0 = Box(True)
    lazy_0 = box_0.to_lazy()
    assert(isinstance(lazy_0, Lazy) and isinstance(lazy_0.value, (lambda: True)) )



# Generated at 2022-06-25 23:29:04.972675
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert(lazy_0.enclosed == str_0)

# Generated at 2022-06-25 23:29:20.404942
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    result_0 = box_0.to_lazy()

    str_1 = 'p]w6e'
    box_1 = Box(str_1)
    result_1 = box_1.to_lazy()

    str_2 = 'B-8(u'
    box_2 = Box(str_2)
    result_2 = box_2.to_lazy()

    str_3 = '+ K'
    box_3 = Box(str_3)
    result_3 = box_3.to_lazy()

    str_4 = 'Y!taI_'
    box_4 = Box(str_4)
    result_4 = box_4.to_lazy()

# Generated at 2022-06-25 23:29:27.226091
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a = Box("string").to_lazy().map_lazy(str.upper)
    box_1 = a.map_lazy(str.upper)

    assert str(box_1) == "Lazy[<function Box.to_lazy.<locals>.<lambda> at 0x000001C2FDCB49D8>]"
    assert box_1.fold() == "STRINGSTRING"

# Generated at 2022-06-25 23:29:31.524185
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == str_0

# Generated at 2022-06-25 23:29:34.666960
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:29:38.692238
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:29:47.755804
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Right, Left

    str_0 = 'Y?4:"ChaJ;'
    str_1 = 'X1]Cm|,BAc%>'
    box_0 = Box(str_0)
    box_1 = Box(str_1)
    string_0 = '\"Jr\"+LK>y2@}(Jh7'

    def func_0(value):
        return value

    maybe_0 = Maybe.just(string_0)
    maybe_1 = Maybe.nothing()
    try_0 = Try(True, is_success=True)

# Generated at 2022-06-25 23:29:48.879711
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert type(Box(5).to_lazy()) == Lazy


# Generated at 2022-06-25 23:29:52.014065
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    assert str(Box('abc').to_lazy()) == 'Lazy[<function Box.to_lazy.<locals>.<lambda> at 0x7fae781286a8>]'


# Generated at 2022-06-25 23:29:56.193926
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded() is False
    assert lazy_0.fold(lambda x: x) == str_0



# Generated at 2022-06-25 23:30:01.044633
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:30:13.676564
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_list import List
    from pymonet.monad_tuple import Tuple

    val_0 = Tuple(9, '`eW:')
    box_0 = Box(val_0)
    res_0 = box_0.to_lazy()
    isinstance(res_0, Lazy)
    assert val_0 == res_0.fold()
    arr_0 = [1, 8, 5]
    val_1 = List(arr_0)
    box_1 = Box(val_1)
    res_1 = box_1.to_lazy()
    isinstance(res_1, Lazy)
    assert val_1 == res_1.fold()

# Generated at 2022-06-25 23:30:17.588962
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lz_0 = box_0.to_lazy()
    lz_1 = Lazy(lambda: str_0)
    assert lz_0 == lz_1


# Generated at 2022-06-25 23:30:20.712771
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    input_str = 'Hello Pymonet'
    box_str = Box(input_str)
    lazy_str = box_str.to_lazy()
    assert lazy_str.value() == input_str



# Generated at 2022-06-25 23:30:23.867389
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box('R<#4O"4J6')
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value == 'R<#4O"4J6'


# Generated at 2022-06-25 23:30:30.884452
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def test_value(value):
        return value

    def test_function(value):
        return value

    box_0 = Box(test_value)
    assert box_0.to_lazy() == Lazy(test_value)
    assert box_0.to_lazy().map(test_function).force() == test_value
    assert box_0.to_lazy().to_box().value == test_value



# Generated at 2022-06-25 23:30:35.787674
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()
    assert lazy_0.get() == str_0

    try_0: Try[str] = box_0.to_try()
    assert try_0.get_or_else('') == str_0

    lazy_1 = box_0.to_lazy().map(str.upper)
    assert lazy_1.get() == str_0.upper()

# Generated at 2022-06-25 23:30:46.506545
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    # Check that str_0 == box_0.value
    assert str_0 == box_0.value
    lazy_0 = box_0.to_lazy()
    # Check that isinstance(lazy_0, pymonet.lazy.Lazy)
    assert isinstance(lazy_0, pymonet.lazy.Lazy)
    pymonet.lazy.Lazy.fold(lazy_0)
    # Check that str_0 == pymonet.lazy.Lazy.fold(lazy_0)
    assert str_0 == pymonet.lazy.Lazy.fold(lazy_0)

# Generated at 2022-06-25 23:30:51.017388
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_0():
        str_0 = 'Y?4:"ChaJ;'
        box_0 = Box(str_0)
        lazy_0 = box_0.to_lazy()
        ret_0 = lazy_0.force()
        assert ret_0 == str_0

    test_0()


# Unit tests for method to_validation of class Box

# Generated at 2022-06-25 23:30:57.378455
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from scraper.models.dict_extractor import DictExtractor
    from pymonet.monad_try import Try

    tests = [
        ([
            {'a': {'b': [1, 2, 3]}, 'c': 4}
        ],
            Try.just(DictExtractor('a.b').extract(
                {'a': {'b': [1, 2, 3]}, 'c': 4}))),
    ]

    for test, expected in tests:
        assert Box(*test).to_lazy().map(lambda x: x) == expected

# Generated at 2022-06-25 23:31:02.961342
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)

    r_0 = box_0.lazy().force()
    assert str_0 == r_0


# Generated at 2022-06-25 23:31:09.922613
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)

    assert box_0.to_lazy().value() == str_0



# Generated at 2022-06-25 23:31:11.402178
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(lambda x: x * 2)
    assert box.to_lazy().value()(3) == 6

# Generated at 2022-06-25 23:31:16.290929
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    var_0 = box_0.to_lazy()
    var_1 = var_0.value()
    var_2 = str_0 == var_1
    return var_2



# Generated at 2022-06-25 23:31:20.178461
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    name = 'Y?4:"ChaJ;'
    box = Box(name)

    assert box.to_lazy() == Lazy(lambda: name)


# Generated at 2022-06-25 23:31:27.115841
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box class.
    """
    from pymonet.lazy import Lazy

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold(lambda x: x) == str_0


# Generated at 2022-06-25 23:31:30.552698
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_forced
    assert lazy_0.value == str_0


# Generated at 2022-06-25 23:31:35.274431
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # 1
    new_0 = Box('aehtXc').to_lazy()
    assert new_0.fold() == 'aehtXc'

    # 2
    new_1 = Box(27).to_lazy()
    assert new_1.fold() == 27

    # 3
    new_2 = Box(98.87).to_lazy()
    assert new_2.fold() == 98.87

    # 4
    new_3 = Box(int).to_lazy()
    assert new_3.fold() == int


# Generated at 2022-06-25 23:31:40.464738
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold() == str_0


# Generated at 2022-06-25 23:31:45.301239
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of class Box
    """
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    result = box_0.to_lazy()
    assert isinstance(result, Lazy)
    assert result.unwrap() == box_0.value


# Generated at 2022-06-25 23:31:49.057371
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    assert box_0.to_lazy().value() == 'Y?4:"ChaJ;'

# Generated at 2022-06-25 23:32:00.872372
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    str_0 = 'Box_tests_0'
    box_0 = Box(str_0)

    # when
    lazy_0 = box_0.to_lazy()

    # then
    assert box_0.value == lazy_0.value()



# Generated at 2022-06-25 23:32:04.756254
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    isinstance(lazy_0, Lazy)
    eq_(str_0, lazy_0.value())
    

# Generated at 2022-06-25 23:32:08.614250
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    box_0_lazy = box_0.to_lazy()
    str_0_result = box_0_lazy.fold()
    str_0_compare = str_0
    assert str_0_result == str_0_compare


# Generated at 2022-06-25 23:32:12.126431
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded() == False
    assert lazy_0.get_value() == str_0


# Generated at 2022-06-25 23:32:16.489764
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy = box_0.to_lazy()
    assert isinstance(lazy, Lazy)
    assert not lazy.is_folded
    assert lazy.value() == str_0


# Generated at 2022-06-25 23:32:20.892463
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.map(lambda arg_0: arg_0.capitalize()).fold() == 'Y?4:"Chaj;'



# Generated at 2022-06-25 23:32:23.533535
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box("Lorem ipsum").to_lazy() == Lazy(lambda: "Lorem ipsum")
    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-25 23:32:26.512778
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    box_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:32:29.286702
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.value()

# Generated at 2022-06-25 23:32:32.766170
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box('K2hb@,vX')

    result = box_0.to_lazy()

    assert isinstance(result, Lazy)
    assert result.value == 'K2hb@,vX'


# Generated at 2022-06-25 23:32:52.034894
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    num_0 = 8519761150037103304
    box_0 = Box(num_0)

    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == num_0


# Generated at 2022-06-25 23:33:00.053378
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    box_0_lazy = box_0.to_lazy()
    assert box_0_lazy.fold() == box_0.value

    assert isinstance(box_0_lazy, Lazy)
    assert isinstance(box_0_lazy, Functor)
    assert isinstance(box_0_lazy, Monad)
    assert isinstance(box_0_lazy, Applicative)



# Generated at 2022-06-25 23:33:01.820956
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    assert box_0.to_lazy().folded_value() == str_0


# Generated at 2022-06-25 23:33:05.392823
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0 == Lazy(lambda: str_0)



# Generated at 2022-06-25 23:33:09.384932
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()


if __name__ == '__main__':
    test_case_0()
    print("Simple tests passed!")
    print("Run 'pytest tests/' from root dir for advanced tests")

# Generated at 2022-06-25 23:33:12.132518
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Fvll7W'
    box_0 = Box(str_0)
    assert box_0.to_lazy().value() == str_0


# Generated at 2022-06-25 23:33:16.440296
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.fold()
    assert str_0 == lazy_0.value()
    assert str_0 == box_0.value


# Generated at 2022-06-25 23:33:23.413298
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for Box.to_lazy()
    """
    from pymonet.lazy import Lazy

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy), 'box_0.to_lazy() => Lazy, but was {}'.format(type(lazy_0))
    value_0 = lazy_0()
    assert value_0 == str_0, 'box_0.to_lazy() => {} but was {}'.format(str_0, value_0)


# Generated at 2022-06-25 23:33:27.150263
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def make_thunk(value):
        return lambda: value

    box = Box(1)
    lazy = Lazy(make_thunk(1))

    assert box.to_lazy() == lazy
    assert box.to_lazy().eval() == lazy.eval()
    assert box.to_lazy() is not lazy

# Generated at 2022-06-25 23:33:31.251016
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    lazy_0 = Box('').to_lazy()
    assert isinstance(lazy_0, Lazy)

    str_0 = 'Y?4:"ChaJ;'
    lazy_1 = Box(str_0).to_lazy()
    assert lazy_1.value == str_0

# Generated at 2022-06-25 23:34:14.064436
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0() == str_0


# Generated at 2022-06-25 23:34:16.405499
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    assert box_0.to_lazy().value() == str_0


# Generated at 2022-06-25 23:34:23.345277
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    #given
    box_0 = Box('PLACEHOLDER')
    #when
    actual_output = box_0.to_lazy()
    #then
    from pymonet.lazy import Lazy
    expected_output = Lazy(lambda: 'PLACEHOLDER')
    assert actual_output == expected_output


# Generated at 2022-06-25 23:34:27.694027
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.fold()
    assert str_1 == str_0


# Generated at 2022-06-25 23:34:31.957882
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()

    assert not lazy_0.is_folded()
    assert lazy_0.fold() == str_0

# Generated at 2022-06-25 23:34:38.211821
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Test 0:
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.eval()

    print("UnitTest:: test_Box_to_lazy executed successfully!")



# Generated at 2022-06-25 23:34:48.369740
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Simple case
    x0 = 7
    x1 = Box(x0)
    x2 = x1.to_lazy()
    x3 = x2.unfold()

    assert x3 == x0

    # Case for function
    def f0(x):
        return x + 5

    x0 = 10
    x1 = Box(f0)
    x2 = x1.to_lazy()
    x3 = x2.unfold()

    assert x3(x0) == f0(x0)

    # Case for lambda
    x0 = 10
    x1 = Box(lambda x: x + 5)
    x2 = x1.to_lazy()
    x3 = x2.unfold()

    assert x3(x0) == 15

# Generated at 2022-06-25 23:34:53.592541
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Y?4:"ChaJ;'

    box_0 = Box(str_0)

    assert box_0.to_lazy() == Lazy(lambda: str_0)

# Generated at 2022-06-25 23:34:58.559602
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.value()
    str_2 = 'Y?4:"ChaJ;'
    assert str_1 == str_2, 'expected: {}, actual: {}'.format(str_2, str_1)


# Generated at 2022-06-25 23:35:02.874140
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.monad_lazy as lazy
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    box_mapped = box_0.map(lambda v: str(v) + ' {0}'.format('!!!'))
    assert str(box_mapped.to_lazy().get()) == str(box_mapped)


# Generated at 2022-06-25 23:36:34.292712
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    str_1 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    lazy_1 = lazy_0.map(lambda str_0: str_1)
    res_0 = lazy_1.value()
    assert res_0 == str_0


# Generated at 2022-06-25 23:36:38.357321
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0 is not None
    assert isinstance(lazy_0, Lazy)

    assert lazy_0.get() == str_0



# Generated at 2022-06-25 23:36:40.974937
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Case 0
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)

    # Assert
    assert box_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:36:43.806736
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(152)
    lazy_0 = box_0.to_lazy()
    lazy_0_expected = Lazy(lambda: 152)
    assert lazy_0 == lazy_0_expected


# Generated at 2022-06-25 23:36:45.238087
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('test_to_lazy').to_lazy().force() == 'test_to_lazy'



# Generated at 2022-06-25 23:36:50.280947
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Tests that to_lazy returns correct Lazy
    """
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)

    # act
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold() == str_0

# Generated at 2022-06-25 23:36:55.194601
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def lazy_func():
        import random
        return random.randint(0, 100)

    lazy_0 = Box[int](0).to_lazy()
    lazy_1 = Box[Callable[[], int]](lazy_func).to_lazy()

    assert lazy_0.fold(lambda x: x) == 0
    assert lazy_1.fold(lambda x: x()) in range(0, 100)


# Generated at 2022-06-25 23:37:00.276408
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    val_0 = 'jb'
    box_0 = Box(val_0)
    box_1 = box_0.to_lazy()
    print(box_1.value())


# Generated at 2022-06-25 23:37:04.337348
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Y?4:"ChaJ;'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    lazy_1 = lazy_0.map(lambda a0: a0.lower())
    assert 'y?4:"chaj;' == lazy_1()


# Generated at 2022-06-25 23:37:07.309392
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '314159'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.to_box().value == str_0

