

# Generated at 2022-06-25 23:27:31.872959
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    object_1 = module_0.object()
    box_1 = Box(object_1)
    assert box_0 != box_1
    assert box_0 != box_0
    assert box_1 != box_1


# Generated at 2022-06-25 23:27:35.892054
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    box_0 = Box(3)
    box_1 = Box(3)
    box_2 = Box(4)
    box_3 = Box(4)

    assert(box_0 == box_1)
    assert(box_1 == box_0)

    assert(box_2 == box_3)
    assert(box_3 == box_2)

    assert(box_0 != box_2)
    assert(box_2 != box_0)
    assert(box_1 != box_3)
    assert(box_3 != box_1)

# Generated at 2022-06-25 23:27:38.556445
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    box_1 = Box(object_0)

    assert box_0 == box_1


# Generated at 2022-06-25 23:27:40.858224
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:27:43.540283
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    box_1 = Box(object_0)
    assert box_0 == box_1


# Generated at 2022-06-25 23:27:44.837759
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    result = Box(0) == Box(0)
    assert result


# Generated at 2022-06-25 23:27:49.096164
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    box_1 = Box(object_0)
    object_1 = object_0 is object_0 is object_0
    print(object_1)
    __tracebackhide__ = True
    assert box_0 == box_1


# Generated at 2022-06-25 23:27:51.983531
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:27:56.006966
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_1 = Box(object_0)
    object_1 = box_1.to_lazy()
    str_0 = str(object_1)
    assert str_0 == 'Lazy[function=(lambda: {})]'.format(object_0)


# Generated at 2022-06-25 23:27:59.220023
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    box_1 = Box(object_0)
    box_2 = Box(module_0.object())
    assert box_0 == box_1
    assert not box_0 == box_2


# Generated at 2022-06-25 23:28:07.086869
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = Box(0).to_lazy()
    assert str(lazy_0) == str_0.format(0)
    assert lazy_0 == Lazy(lambda: 0)
    lazy_1 = Box(1).to_lazy()
    assert str(lazy_1) == str_0.format(1)
    assert lazy_1 == Lazy(lambda: 1)


# Generated at 2022-06-25 23:28:11.617320
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_method(x):
        assert str(Box(x).to_lazy()) == str_0.format(x)

    str_0 = 'Lazy[function=(lambda: {})]'
    test_method(1)
    test_method(2)
    test_method("Hello")
    test_method("World")


# Generated at 2022-06-25 23:28:15.732713
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    from pymonet.lazy import Lazy

    box = Box(123)

    # When
    lazy = box.to_lazy()

    # Then
    assert isinstance(lazy, Lazy)
    assert lazy.value == 123


# Generated at 2022-06-25 23:28:17.274316
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(0).to_lazy()) == 'Lazy[function=(lambda: 0)]'


# Generated at 2022-06-25 23:28:23.146007
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    print("Unit test for method to_lazy of class Box")

    assert Box(1).to_lazy().to_string() == 'Lazy[function=(lambda: 1)]'
    assert Box('abc').to_lazy().to_string() == 'Lazy[function=(lambda: abc)]'
    assert Box(None).to_lazy().to_string() == 'Lazy[function=(lambda: None)]'
    assert Box([1, 2, 3]).to_lazy().to_string() == 'Lazy[function=(lambda: [1, 2, 3])]'


# Generated at 2022-06-25 23:28:34.047854
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(1).to_lazy()) == str_0.format('1')
    assert str(Box('abc').to_lazy()) == str_0.format('\'abc\'')
    assert str(Box(['a', 'b', 'c']).to_lazy()) == str_0.format('[\'a\', \'b\', \'c\']')
    assert str(Box({'a': 'b'}).to_lazy()) == str_0.format('{\'a\': \'b\'}')
    assert str(Box(tuple()).to_lazy()) == str_0.format('()')
    assert str(Box((1, 2, 3)).to_lazy()) == str_0.format('(1, 2, 3)')



# Generated at 2022-06-25 23:28:39.698891
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # base cases
    assert Box(5).to_lazy() == Box(5).to_lazy()
    assert Box(5).to_lazy().unfold() == Box(5).to_lazy().unfold()

    # general cases
    assert Box(6).to_lazy() == Box(6).to_lazy()
    assert Box(6).to_lazy().unfold() == Box(6).to_lazy().unfold()


# Generated at 2022-06-25 23:28:42.454124
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(0).to_lazy().eval() == 0
    assert Box(1).to_lazy().eval() == 1
    assert Box(2).to_lazy().eval() == 2
    assert Box(3).to_lazy().eval() == 3


# Generated at 2022-06-25 23:28:46.937445
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Lazy[function=(lambda: {})]'
    box_0 = Box(0)
    lazy_0 = box_0.to_lazy()
    assert str(lazy_0) == str_0.format(str(box_0.value))


# Generated at 2022-06-25 23:28:50.449666
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(str)
    lazy_0 = box_0.to_lazy()
    lazy_0.folded
    assert lazy_0.folded() == '[]'


# Generated at 2022-06-25 23:28:59.475810
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Just

    lazy_0 = Box(1).to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold(lambda: 2) == 1

    lazy_0 = Box([1]).to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold(lambda: 2) == [1]

    lazy_0 = Lazy(lambda: Box(10).to_lazy())
    assert isinstance(lazy_0.fold(lambda: 'Lazy[function=(lambda: {})]'), str)
    assert '10' in lazy_0.fold(lambda: 'Lazy[function=(lambda: {})]')


# Generated at 2022-06-25 23:29:06.353087
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import unittest

    box_0 = Box('value 0')
    test_lazy_0 = box_0.to_lazy()
    str_lazy_0 = str(test_lazy_0)

    class TestStringMethods(unittest.TestCase):
        def test_to_string(self):
            self.assertEqual(str_lazy_0, 'Lazy[function=(lambda: value 0)]')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestStringMethods)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-25 23:29:16.572630
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def __test_method__(value, result):
        print('Box[value={}].to_lazy() = {}'.format(value, Box(value).to_lazy()))
        assert str(Box(value).to_lazy()) == result, 'Wrong result: {}'.format(str(Box(value).to_lazy()))

    __test_method__(1, 'Lazy[function=(lambda: 1)]')
    __test_method__(False, 'Lazy[function=(lambda: False)]')
    __test_method__(2.5, 'Lazy[function=(lambda: 2.5)]')
    __test_method__(lambda x: x + 1, 'Lazy[function=(lambda: <function <lambda> at 0x7fb8fd42fd08>)]')

# Generated at 2022-06-25 23:29:20.247736
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Lazy[function=(lambda: {})]'
    value = 'value'
    box = Box(value)
    test_to_lazy = str(box.to_lazy())
    str(box.to_lazy()) == str_0.format(value)


# Generated at 2022-06-25 23:29:32.773831
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def local_func_0():
        return 'value'
    def local_func_1():
        return 'value'
    def local_func_2():
        return 'value'
    def local_func_3():
        return 'value'
    def local_func_4():
        return 'value'
    def local_func_5():
        return 'value'
    def local_func_6():
        return 'value'
    value_0 = Box(Box(Box(Box(Box('value')))))
    value_1 = Box(Box(Box(Box(Box(Box(Box('value')))))))
    value_2 = Box(Box(Box(Box(Box(Box(Box(Box('value'))))))))
    value_3 = Box(Box(Box(Box(Box(Box(value_0))))))
   

# Generated at 2022-06-25 23:29:41.937489
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_validation import Validation

    val = 1

    try_0 = Try.success(val)
    try_1 = try_0.to_box().to_lazy()
    try_2 = Try.fail(-1).to_box().to_lazy()

    assert str(try_1) == 'Lazy[function=(lambda: 1)]'
    assert try_1.get() == val
    assert str(try_1) == 'Lazy[function=(lambda: 1)]'
    assert try_2.get() == None

    val2 = 3

    lazy_0 = Lazy.pure(val2)
    lazy_1 = lazy_0.to_box().to_

# Generated at 2022-06-25 23:29:44.320678
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = str(Box(17).to_lazy())
    str_1 = 'Lazy[function=(lambda: 17)]'
    assert str_0 == str_1



# Generated at 2022-06-25 23:29:50.317329
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box('hello').to_lazy()) == 'Lazy[function=(lambda: {})]'.format(repr('hello'))
    assert str(Box('hello').to_lazy()) != 'Lazy[function=(lambda: {})]'.format(repr('world'))
    assert str(Box(10).to_lazy()) == 'Lazy[function=(lambda: {})]'.format(repr(10))
    assert str(Box(10).to_lazy()) != 'Lazy[function=(lambda: {})]'.format(repr(1000))



# Generated at 2022-06-25 23:29:52.024877
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:30:00.028855
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # General cases
    assert str(Box('s').to_lazy()) == str_0.format('s')
    assert str(Box('A').to_lazy()) == str_0.format('A')
    assert str(Box(10).to_lazy()) == str_0.format('10')

    # Boundary cases
    assert str(Box(None).to_lazy()) == str_0.format('None')
    assert str(Box('').to_lazy()) == str_0.format('')
    assert str(Box(True).to_lazy()) == str_0.format('True')


# Generated at 2022-06-25 23:30:05.894030
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box('test_value').to_lazy()) == str_0.format('test_value')

# Generated at 2022-06-25 23:30:10.027988
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # create Box[int] with value = 10
    box_1 = Box(10)
    # transform box_1 to lazy
    lazy_1 = box_1.to_lazy()
    # check if lazy_1 has printed value
    assert str(lazy_1) == 'Lazy[function=(lambda: 10)]'


# Generated at 2022-06-25 23:30:11.493732
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(1).to_lazy()) == 'Lazy[function=(lambda: 1)]'


# Generated at 2022-06-25 23:30:15.050411
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'Lazy[function=(lambda: {})]'
    box_0 = Box('{}')
    lazy_0 = box_0.to_lazy()
    str_1 = str(lazy_0)
    assert str_1 == str_0.format('{}')
    box_1 = Box(None)
    lazy_1 = box_1.to_lazy()
    str_2 = str(lazy_1)
    assert str_2 == str_0.format('None')

# Generated at 2022-06-25 23:30:17.714773
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('my string').to_lazy() == Lazy(lambda: 'my string')


# Generated at 2022-06-25 23:30:24.651082
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test values
    str_0 = 'Lazy[function=(lambda: {})]'
    str_1 = 'Lazy[function=(lambda: "test_value")]'

    # Checks if to_lazy() return right type
    assert isinstance(Box(None).to_lazy(), type(Box('').to_lazy()))

    # Checks if to_lazy() return the same value of init
    assert str(Box(None).to_lazy()) == str_0.format(Box(None).value)
    assert str(Box('test_value').to_lazy()) == str_1



# Generated at 2022-06-25 23:30:28.459796
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    try:
        expected = str(Box('Lazy[function=(lambda: {})]').to_lazy())
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-25 23:30:30.234016
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(1).to_lazy()) == str_0.format(1)


# Generated at 2022-06-25 23:30:32.999121
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 'value'
    box = Box(value)
    lazy_value = box.to_lazy()
    str_box = str(lazy_value)
    assert str_box == 'Lazy[function=(lambda: {})]'.format(value)

# Generated at 2022-06-25 23:30:34.990479
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = str(Box(1).to_lazy())
    assert str_0 == 'Lazy[function=(lambda: 1)]'

# Unit tests for method to_try of class Box

# Generated at 2022-06-25 23:30:45.300736
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    int_0 = Box(0)
    assert str(int_0.to_lazy()) == 'Lazy[fold_value=0]'


# Generated at 2022-06-25 23:30:48.351419
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(42)
    str_0 = str(box_0.to_lazy())

    assert str_0 == 'Lazy[function=(lambda: 42)]'


# Generated at 2022-06-25 23:30:53.623815
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = str(Box('foo').to_lazy())
    assert str_0 == 'Lazy[function=(lambda: foo)]'
    str_1 = str(Box('bar').to_lazy())
    assert str_1 == 'Lazy[function=(lambda: bar)]'
    str_2 = str(Box(5).to_lazy())
    assert str_2 == 'Lazy[function=(lambda: 5)]'


# Generated at 2022-06-25 23:31:03.948641
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy


# Generated at 2022-06-25 23:31:07.831068
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert not ('Lazy[function=(lambda: {})]' in str(Box(42).to_lazy()))
    assert 'Lazy[function=(lambda: 42)]' in str(Box(42).to_lazy())



# Generated at 2022-06-25 23:31:11.091179
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 'foo'
    box = Box(value)
    lazy = box.to_lazy()
    str_value = str(lazy)
    assert str_value == 'Lazy[function=(lambda: {})]'.format(value)


# Generated at 2022-06-25 23:31:13.793518
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str_0 == str(Box(2).to_lazy())


# Generated at 2022-06-25 23:31:16.085906
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-25 23:31:21.045337
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(['foo']).to_lazy() == Lazy(lambda: ['foo'])
    assert Box((1, 2)).to_lazy() == Lazy(lambda: (1, 2))
    assert Box({'a': 1}).to_lazy() == Lazy(lambda: {'a': 1})


# Generated at 2022-06-25 23:31:31.689497
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from operator import eq, add
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    string = Box('test')
    function = Box(add)
    lazy = Lazy(lambda: 'test')
    success = Box(Try(True))

    print('\n> Testing "Box.to_lazy" method')
    print('Testing string value: ', string.to_lazy() == Lazy(lambda: 'test'))
    print('Testing function: ', function.to_lazy() == Lazy(lambda: add))
    print('Testing lazy: ', lazy.to_lazy() == Lazy(lambda: 'test'))

# Generated at 2022-06-25 23:31:45.959313
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_nothing() and not lazy_0.is_just()
    assert lazy_0.value() == object_0


# Generated at 2022-06-25 23:31:49.312227
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    
    lazy_0 = box_0.to_lazy()



# Generated at 2022-06-25 23:31:51.677978
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:31:55.656723
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy
    import pymonet.box

    expected = pymonet.lazy.Lazy(lambda: 'A')

    actual = pymonet.box.Box('A').to_lazy()

    assert actual == expected


# Generated at 2022-06-25 23:31:58.925008
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy

    box = Box(1)
    lazy = box.to_lazy()
    assert lazy == pymonet.lazy.Lazy(lambda: 1)


# Generated at 2022-06-25 23:32:00.749277
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 42) == Box(42).to_lazy()


# Generated at 2022-06-25 23:32:06.549100
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    from pymonet.lazy import Lazy

    box_0 = Box(...)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert Lazy(lambda: ...) == lazy_0

    box_1 = Box(module_0.object())
    object_0 = module_0.object()
    lazy_1 = box_1.to_lazy()
    assert Lazy(lambda: object_0) == lazy_1


# Generated at 2022-06-25 23:32:09.358820
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()


if __name__ == '__main__':
    test_case_0()
    test_Box_to_lazy()

# Generated at 2022-06-25 23:32:11.795693
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(object())
    lazy_0 = Lazy(lambda: object())
    lazy_1 = box_0.to_lazy()
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:32:14.237273
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    validation_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:32:32.478985
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    assert box_0.to_lazy().is_folded()


# Generated at 2022-06-25 23:32:35.592709
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(1)
    lazy_0 = box_0.to_lazy()
    lazy_1 = Lazy(lambda: 1)
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:32:37.648641
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:32:39.985015
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    print('Test method to_lazy')

    obj = Box(1)
    lazy = obj.to_lazy()

    assert lazy.fold() == 1


# Generated at 2022-06-25 23:32:46.506872
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 1 
    object_0 = module_0.object()
    box_0 = Box(object_0)
    result_0 = box_0.to_lazy()
    assert callable(result_0)

import pymonet.validation as module_1
import pymonet.monad_try as module_2
import pymonet.maybe as module_3
import pymonet.either as module_4
import pymonet.lazy as module_5


# Generated at 2022-06-25 23:32:55.122702
# Unit test for method to_lazy of class Box

# Generated at 2022-06-25 23:32:56.562447
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as lazy
    # TODO: Implement this fixture


# Generated at 2022-06-25 23:33:01.603618
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # pymonet.lazy.Lazy
    import pymonet.lazy as module_0

    # pymonet.lazy.Lazy(function)
    object_0 = module_0.Lazy(module_0.Lazy.__new__)
    assert object_0.value is module_0.Lazy.__new__
    # pymonet.monad.Box[pymonet.lazy.Lazy(function)]
    object_1 = Box(object_0)
    # pymonet.monad.Box[pymonet.lazy.Lazy(function)].to_lazy() -> pymonet.monad.Lazy
    object_2 = object_1.to_lazy()
    assert object_2.value() is module_0.Lazy.__new__


# Generated at 2022-06-25 23:33:03.350889
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(object())
    lazy_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:33:05.988878
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = object()
    box_0 = Box(object_0)
    lazy = box_0.to_lazy()
    assert lazy.value() is object_0

import builtins as module_0


# Generated at 2022-06-25 23:33:47.458597
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy as Lazy1
    from pymonet.lazy import Lazy as Lazy2
    from pymonet.lazy import Lazy as Lazy3

    def function_0():
        return Lazy1()

    def function_1():
        return Lazy2()

    def function_2():
        return Lazy3()

    def function_3():
        return Lazy()

    def function_4(x):
        return x

    lazy_0 = function_0()
    lazy_1 = function_1()
    lazy_2 = function_2()
    lazy_3 = function_3()
    lazy_4 = function_4()
    def function_5():
        return lazy_0

# Generated at 2022-06-25 23:33:53.922044
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    def test_cases():
        object_0 = module_0.object()
        box_0 = Box(object_0)
        lazy_0 = box_0.to_lazy()
        value_0 = lazy_0.get()
        assert object_0 is value_0
    
    def set_up():
        pass
    
    def tear_down():
        pass
    
    def test_template(test_case_func, set_up_func, tear_down_func, *args):
        set_up_func()
        test_case_func(*args)
        tear_down_func()
    
    test_template(test_cases, set_up, tear_down)


from pymonet.monad_try import Try


# Generated at 2022-06-25 23:33:56.647018
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded is False
    assert lazy_0.value == object_0


# Generated at 2022-06-25 23:34:00.887894
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()
    assert(not lazy_0.is_folded)
    assert(lazy_0.value() == box_0.value)



# Generated at 2022-06-25 23:34:03.969202
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    object_0 = module_0.object()
    box_0 = Box(object_0)

    assert box_0.to_lazy() == Lazy(lambda: object_0)


# Generated at 2022-06-25 23:34:06.705627
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    assert box_0.to_lazy() == Lazy(lambda: object_0)


# Generated at 2022-06-25 23:34:16.474741
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    object_1 = module_0.object()
    lazy_0 = box_0.to_lazy()
    def function_0(arg_0):
        return arg_0
    object_2 = module_0.object()
    lazy_1 = lazy_0.map(function_0)
    object_3 = module_0.object()
    object_4 = module_0.object()
    object_5 = module_0.object()
    object_6 = module_0.object()
    object_7 = module_0.object()
    object_8 = module_0.object()
    object_9 = module_0.object()
    bool_0 = lazy_1.is_computed()
    lazy_0

# Generated at 2022-06-25 23:34:26.330767
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Test 1
    lazy = Box(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1
    assert lazy.is_evaluated is False

    # Test 2
    lazy = Box(float()).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == float()
    assert lazy.is_evaluated is False

    # Test 3
    lazy = Box(str()).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == str()
    assert lazy.is_evaluated is False

    # Test 4
    lazy = Box(list()).to_lazy()
    assert isinstance(lazy, Lazy)

# Generated at 2022-06-25 23:34:35.675870
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Setup
    object_0 = module_0.object()
    box_0 = Box(object_0)
    # Assertion
    assert_0 = box_0.to_lazy()
    assert_1 = module_0.str(assert_0)
    assert_2 = module_0.str('Lazy[value=<function <lambda> at 0x7fa10e35f840>]')
    assert_3 = module_0.isinstance(assert_0, module_0.type(module_0.Lazy))
    assert_4 = module_0.isinstance(assert_0, module_0.type(module_0.Lazy))
    assert_5 = module_0.isinstance(assert_0, module_0.type(module_0.Lazy))
    # Cleaup
    del object_

# Generated at 2022-06-25 23:34:39.693158
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    object_0 = object()
    box_0 = Box(object_0)
    lazy_0 = Lazy(lambda: object_0)
    lazy_1 = box_0.to_lazy()

    assert lazy_1 == lazy_0


# Generated at 2022-06-25 23:36:02.475576
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    try:
        lazy_0 = box_0.to_lazy()
        # Unit test for method to_lazy of class Box
    finally:
        pass



# Generated at 2022-06-25 23:36:09.870621
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = object()
    box_0 = Box(object_0)
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
    object_15 = object()
    object_16 = object()
    object_17 = object()
    object_18 = object()
    object_19 = object()
    object_20 = object()
    object_21 = object()
    object_22 = object()
    object_

# Generated at 2022-06-25 23:36:11.519432
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-25 23:36:14.634389
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Init
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()

    # Assertion
    assert lazy_0.is_folded() == False


# Generated at 2022-06-25 23:36:17.463753
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:36:20.793159
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(1)
    lazy_0 = box_0.to_lazy();
    assert 2 == lazy_0.fold(lambda x: x + 1)


# Generated at 2022-06-25 23:36:27.762006
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    object_0 = module_0.object()
    box_0 = Box(object_0)
    lazy_0 = box_0.to_lazy()
    lazy_0.get()
    lazy_0.to_dict()
    lazy_0.to_list()
    lazy_0.to_set()
    lazy_0.to_tuple()
    lazy_0.to_try()
    lazy_0.to_validation()
    lazy_0.get_or_else(module_0.object())
    lazy_0.get_or_raise()
    lazy_0.get_or_raise()
    lazy_0.get_or_throw(module_0.int(1))


# Generated at 2022-06-25 23:36:30.899453
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    def mock_lazy(value):
        return value()

    monkeypatch.setattr(Box, "to_lazy", mock_lazy)

    assert Box('A').to_lazy() == 'A'



# Generated at 2022-06-25 23:36:35.038905
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Assign
    object_0 = module_0.object()
    box_0 = Box(object_0)

    # Act
    object_1 = box_0.to_lazy()

    # Assert
    assert isinstance(object_1, type(Box(1).to_lazy()))
    assert object_0 is object_1.unwrap()


# Generated at 2022-06-25 23:36:38.229982
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    object_0 = object()
    box_0 = Box(object_0)
    ret_0 = box_0.to_lazy()
    assert isinstance(ret_0, Lazy)
    assert ret_0._value() == object_0
