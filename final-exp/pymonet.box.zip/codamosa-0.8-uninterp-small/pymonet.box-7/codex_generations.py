

# Generated at 2022-06-25 23:27:32.717160
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    dict_0 = { }
    dict_1 = { }
    dict_1['a'] = 'a'
    dict_1['b'] = 'b'
    dict_1['c'] = 'c'
    dict_1['d'] = 'd'
    dict_1['e'] = 'e'
    dict_1['f'] = 'f'
    dict_1['g'] = 'g'
    dict_1['h'] = 'h'
    dict_1['i'] = 'i'
    dict_1['j'] = 'j'
    dict_1['k'] = 'k'
    dict_1['l'] = 'l'
    box_0 = Box(dict_0)
    box_1 = Box(dict_1)
    box_2 = Box(dict_0)
    assert box

# Generated at 2022-06-25 23:27:35.477450
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    dict_0 = {'a': 1}
    box_0 = Box(dict_0)
    bool_0 = box_0 == box_0
    assert bool_0 == True



# Generated at 2022-06-25 23:27:41.004218
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = {"key0":'value0'}
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()
    assert dict_0 == lazy_0.force()
    dict_1 = None
    box_1 = Box(dict_1)
    lazy_1 = box_1.to_lazy()
    assert dict_1 == lazy_1.force()


# Generated at 2022-06-25 23:27:50.701390
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Test cases
    # Corner 1
    dict_0 = None
    box_0 = Box(dict_0)
    assert box_0 == box_0
    box_1 = Box(dict_0)
    assert box_0 == box_1
    assert not box_1 == box_0
    # Corner 2
    dict_0 = -1
    box_0 = Box(dict_0)
    dict_1 = 0
    box_1 = Box(dict_1)
    assert not box_1 == box_0
    assert not box_0 == box_1
    # Corner 3
    dict_0 = -1
    box_0 = Box(dict_0)
    dict_1 = -1
    box_1 = Box(dict_1)
    assert box_0 == box_1

# Generated at 2022-06-25 23:27:55.414339
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    dict_1 = {'key_1': 1, 'key_2': 'value_2'}
    box_1 = Box(dict_1)
    dict_2 = {'key_1': 1, 'key_2': 'value_2'}
    box_2 = Box(dict_2)
    assert box_1 == box_2


# Generated at 2022-06-25 23:28:03.184909
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Test for 'Box[value=None]'
    def test_case_0():
        dict_0 = None
        box_0 = Box(dict_0)
        box_1 = Box(dict_0)
        assert box_0 == box_1

    # Test for 'Box[value=0]'
    def test_case_1():
        dict_0 = 0
        box_0 = Box(dict_0)
        box_1 = Box(dict_0)
        assert box_0 == box_1

    # Test for 'Box[value=inf]'
    def test_case_2():
        dict_0 = float('inf')
        box_0 = Box(dict_0)
        box_1 = Box(dict_0)
        assert box_0 == box_1

    # Test for 'Box[value=False

# Generated at 2022-06-25 23:28:13.035696
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Positive test
    # Input of type dict
    dict_0 = None
    box_0 = Box(dict_0)
    result_0 = box_0.to_lazy()
    assert not result_0.is_folded
    assert result_0.value() == dict_0
    # Input of type dict
    dict_1 = {}
    box_1 = Box(dict_1)
    result_1 = box_1.to_lazy()
    assert not result_1.is_folded
    assert result_1.value() == dict_1
    # Input of type int
    int_0 = None
    box_2 = Box(int_0)
    result_2 = box_2.to_lazy()
    assert not result_2.is_folded

# Generated at 2022-06-25 23:28:17.071148
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    dict_0 = None
    box_0_0 = Box(dict_0)
    try:
        if not box_0_0.__eq__(dict_0):
            raise AssertionError()
    except:
        raise AssertionError()



# Generated at 2022-06-25 23:28:18.894104
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box(None)
    box_1 = Box(None)
    assert box_0 == box_1


# Generated at 2022-06-25 23:28:22.241510
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    dict_0 = {0: 'O'}
    box_0 = Box(dict_0)
    box_1 = Box(dict_0)
    assert box_0 == box_1
    assert not (box_0 == None)
    assert not (box_0 == 1)


# Generated at 2022-06-25 23:28:27.407035
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'test'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:28:32.204641
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = None
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()
    value_0 = lazy_0.get_value()
    lazy_1 = box_0.to_lazy()
    value_1 = lazy_1.get_value()
    assert value_0 == value_1



# Generated at 2022-06-25 23:28:34.740615
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(5)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == 5


# Generated at 2022-06-25 23:28:36.970643
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box('value')
    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == 'value'

# Generated at 2022-06-25 23:28:44.194091
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test 1
    test_0_dict_0 = None
    test_0_box_0 = Box(test_0_dict_0)
    test_0_box_1 = test_0_box_0.to_lazy()
    test_0_after_1 = test_0_box_1.value()

    # Test 2
    test_1_dict_0 = {'a': 1, 'b': '2', 'c': None}
    test_1_box_0 = Box(test_1_dict_0)
    test_1_box_1 = test_1_box_0.to_lazy()
    test_1_after_1 = test_1_box_1.value()

    # Test 3
    test_2_box_0 = Box(None)
    test_2_box

# Generated at 2022-06-25 23:28:48.207145
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = []
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()
    result_lazy_0 = lazy_0.force()
    if  True:
        print("Test successed")
    else:
        print("Test failed")


# Generated at 2022-06-25 23:28:53.295505
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = 'hello'
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()

    def _assert_lazy_fun_0(x0):
        assert x0 == dict_0

    _assert_lazy_fun_0(lazy_0.value())



# Generated at 2022-06-25 23:28:56.063109
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.get() == 0


# Generated at 2022-06-25 23:29:02.013807
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_lazy().to_try() == Try(1)
    assert Box(1).to_lazy().to_validation() == Validation.success(1)



# Generated at 2022-06-25 23:29:04.478919
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box_0 = Box(42)
    lazy_0 = Lazy(lambda: 42)
    assert box_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:29:10.289418
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()

    test_dict = {
        'name': 'Vasya',
        'age': 23,
        'hobby': 'karate',
        'exp': [
            {'year': '5', 'title': '1 dan'}
        ]
    }

    box_0 = Box(test_dict)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.get_value() == test_dict

# Generated at 2022-06-25 23:29:14.394863
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Check that method successfully returns Lazy monad with function returning previous value
    """
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert box.value == lazy.force()



# Generated at 2022-06-25 23:29:22.868287
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = {}
    dict_0["key_0"] = "value_0"
    box_0 = Box(dict_0)

    box_0.value["key_1"] = "value_1"
    box_0.value["key_2"] = "value_2"
    box_0.value["key_3"] = "value_3"

    assert isinstance(box_0.to_lazy().value(), dict) == True
    assert isinstance(box_0.to_lazy().value(), int) == False
    assert box_0.to_lazy().value() == {"key_0": "value_0", "key_1": "value_1", "key_2": "value_2", "key_3": "value_3"}



# Generated at 2022-06-25 23:29:33.650967
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = {}
    box_0 = Box(dict_0)
    result_0 = box_0.to_lazy()
    dict_1 = {}
    box_1 = Box(dict_1)
    result_1 = box_1.to_lazy()
    dict_2 = {}
    box_2 = Box(dict_2)
    result_2 = box_2.to_lazy()
    dict_3 = {}
    box_3 = Box(dict_3)
    result_3 = box_3.to_lazy()

    print("Значение абстракции: " + str(result_0.fold(lambda: 0)))



# Generated at 2022-06-25 23:29:35.150185
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(9).to_lazy() == Lazy(lambda: 9)


# Generated at 2022-06-25 23:29:36.663253
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Lazy.of(2)


# Generated at 2022-06-25 23:29:38.404752
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().map(lambda x: x * 5).value() == 25



# Generated at 2022-06-25 23:29:47.556626
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = None
    box_0 = Box(dict_0)
    dict_1 = {'one': 1, 'two': 2}
    box_1 = Box(dict_1)
    box_1_result = box_1.to_lazy()
    dict_2 = {'one': 1, 'two': 2, 'three': 3}
    box_2 = Box(dict_2)
    box_2_result = box_2.to_lazy()
    dict_3 = {'one': 1, 'two': 2, 'three': 3, 'four': 4}
    box_3 = Box(dict_3)
    box_3_result = box_3.to_lazy()

# Generated at 2022-06-25 23:29:48.991241
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = None
    box_0 = Box(dict_0)
    box_0.to_lazy()

# Generated at 2022-06-25 23:29:58.580211
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Input data
    int_0 = 0
    int_1 = 1
    int_2 = 2
    str_0 = '0'
    list_0 = []
    list_1 = ['0']
    tuple_0 = ()
    tuple_1 = (0,)
    bool_0 = True
    bool_1 = False
    dict_0 = {'0': 0}

    # Call Box constructor for each input data
    box_0 = Box(int_0)
    box_1 = Box(int_1)
    box_2 = Box(int_2)
    box_3 = Box(str_0)
    box_4 = Box(list_0)
    box_5 = Box(list_1)
    box_6 = Box(tuple_0)

# Generated at 2022-06-25 23:30:01.721415
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold() == 1



# Generated at 2022-06-25 23:30:03.515880
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pickle
    box_0 = Box('Test')
    box_1 = pickle.loads(pickle.dumps(box_0))

# Generated at 2022-06-25 23:30:06.191369
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    actual_result = Box(8).to_lazy()
    excepted_result = Lazy(8)
    assert actual_result == excepted_result



# Generated at 2022-06-25 23:30:09.071321
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(4).to_lazy(), Lazy)
    assert eval(repr(Box(4).to_lazy())) == Box(4).to_lazy()


# Generated at 2022-06-25 23:30:11.957240
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('hello').to_lazy().force() == 'hello'
    assert Box(1).to_lazy().force() == 1
    assert Box(True).to_lazy().force() == True
    assert Box(None).to_lazy().force() == None

# Generated at 2022-06-25 23:30:14.627093
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = None
    box_0 = Box(dict_0)

    def func_0():
        return dict_0

    assert box_0.to_lazy().value() == func_0()



# Generated at 2022-06-25 23:30:16.367757
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box({}).to_lazy() == Lazy(lambda: {})



# Generated at 2022-06-25 23:30:21.913132
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for method to_lazy of class Box.
    """
    import pymonet.lazy
    from pymonet.lazy import Lazy

    if isinstance(Box(None).to_lazy(), Lazy):
        assert True, "Test OK"
    else:
        assert False, "Test FAILED"

# Unit test case for method Box.bind of class Box

# Generated at 2022-06-25 23:30:25.138414
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box_0 = Box(1)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.force() == 1


# Generated at 2022-06-25 23:30:27.863140
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a = 10
    l = Box(a).to_lazy()
    assert l() == a


# Generated at 2022-06-25 23:30:35.595498
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Test for method to_lazy of class Box.\n    '
    only_print_flag = True
    only_print_flag = False

    def test_case_0():
        str_1 = '\n        Test case 0.\n        '

# Generated at 2022-06-25 23:30:46.195866
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Test for method to_lazy of class Box.\n    '
    str_1 = 'Test case 0'
    res_0 = Box(1)
    lzy_0 = res_0.to_lazy()
    lzy_0.value()
    check_0 = (1, '')

# Generated at 2022-06-25 23:30:55.445885
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Right, Left
    test_case = '\n    Test for method to_lazy of class Box.\n    '

# Generated at 2022-06-25 23:31:05.679337
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy
    from pymonet.identity import Identity
    from pymonet.monad_maybe import Maybe
    met_box_to_lazy_0 = Lazy
    met_box_to_lazy_1 = met_box_to_lazy_0(lambda : Identity(1))
    met_box_to_lazy_2 = Box(met_box_to_lazy_1)
    met_box_to_lazy_3 = met_box_to_lazy_2.to_lazy()
    met_box_to_lazy_4 = met_box_to_lazy_3.fold(Lazy, Identity)
    met_box_to_lazy_5 = met

# Generated at 2022-06-25 23:31:16.480211
# Unit test for method to_lazy of class Box

# Generated at 2022-06-25 23:31:22.032683
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_1 = '\n    Unit test for method to_lazy of class Box.\n    '
    str_2 = 'Test for method to_lazy of class Box'
    str_3 = '\n    Unit test for method to_lazy of class Box finished.\n    '
    str_4 = '\n    Unit test for method bind of class Box.\n    '


# Generated at 2022-06-25 23:31:32.452257
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from typing import Any
    str_0 = '\n    Test for method to_lazy of class Box.\n    '
    globals().update({'str_0':str_0})
    def func_0(arg_0: Box[Any]) -> Lazy[Any]:
        assert (arg_0 is not None), 'Method, to_lazy of class Box with argument arg_0, is required'
        str_1 = '\n        Transform Box into Lazy with returning value function.\n        '
        str_2 = '\n        :returns: not folded Lazy monad with function returning previous value\n        :rtype: Lazy[Function(() -> A)]\n        '

# Generated at 2022-06-25 23:31:35.334036
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    result = Box('test').to_lazy()

    assert isinstance(result, Lazy)
    assert result == Lazy(lambda: 'test')


# Generated at 2022-06-25 23:31:43.427601
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Test for method to_lazy of class Box.\n    '


    # Test for method to_lazy of class Box
    def test_case_0():
        str_0 = '\n    Test for method to_lazy of class Box.\n    '
        number = Box(1)
        def_0 = number.to_lazy()
        def_1 = def_0.value()
        def_2 = def_1.value
        assert (def_2 == 1), str_0


# Generated at 2022-06-25 23:31:45.745262
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Unit test for method to_lazy of class Box.\n    '


# Generated at 2022-06-25 23:31:58.500596
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    str_0 = '\n    Test for method to_lazy of class Box.\n    '
    print('Unit test for method to_lazy of class Box')

    value_0 = 'test string'
    box_0 = Box(value_0)
    lazy_0 = box_0.to_lazy()

    if not ((type(lazy_0).__name__) == 'Lazy'):
        m_0 = 'Type \'' + (type(lazy_0).__name__) + '\''
        m_1 = 'Type \'Lazy\''
        raise AssertionError(('\n    Unit test for method to_lazy of class Box FAILED.\n    Expected: ' + m_1) + ('\n    Actual:   ' + m_0))



# Generated at 2022-06-25 23:32:03.357960
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'a') == Box('a').to_lazy()
    assert Lazy(lambda: 1) == Box(1).to_lazy()
    assert Lazy(lambda: []) == Box([]).to_lazy()
    assert Lazy(lambda: {}) == Box({}).to_lazy()



# Generated at 2022-06-25 23:32:08.406418
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import NoneType
    from pymonet.maybe import Just
    from pymonet.either import Left
    from pymonet.either import Right
    from pymonet.validation import Success
    from pymonet.validation import Failure
    import math
    func_0 = lambda : Box("#!$()!+_)(*&^%%$#")
    lazy_0 = Lazy(func_0)
    lazy_1 = Box("#!$()!+_)(*&^%%$#").to_lazy()
    assert lazy_0 == lazy_1
    lazy_0 = Lazy(lambda : Box(math.sqrt))
    lazy_1 = Box(math.sqrt).to

# Generated at 2022-06-25 23:32:11.093504
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    test_case = Box('abcdef')
    assert test_case.to_lazy() == Lazy(lambda: 'abcdef')


# Generated at 2022-06-25 23:32:13.115741
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str = '\n    Test for method to_lazy of class Box.\n    '
    lazy_0 = Lazy((lambda: str))


# Generated at 2022-06-25 23:32:16.291671
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Test for method to_lazy of class Box.\n    '
    assert (type(Box(1).to_lazy()) == pymonet.lazy.Lazy), str_0


# Generated at 2022-06-25 23:32:21.835070
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Test for method to_lazy of class Box.\n    '
    print(str_0)
    print('Function test_Box_to_lazy [line:68]')
    str_1 = 'Hello World!'
    obj_0 = Box(str_1)
    obj_1 = obj_0.to_lazy()
    assert_equal(obj_1.value(), str_1)
    return None


# Generated at 2022-06-25 23:32:22.926061
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    pass


# Generated at 2022-06-25 23:32:31.244637
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Test for method to_lazy of class Box.\n    '
    maybe_0 = Box(['h', 'e', 'l', 'l', 'o']).to_maybe()
    maybe_1 = maybe_0.map(lambda xs_0: xs_0[2:])
    maybe_2 = maybe_1.map(lambda xs_1: xs_1[::-1])
    maybe_3 = maybe_2.map(lambda xs_2: ''.join(xs_2))
    lazy_0 = maybe_3.to_lazy()
    lazy_1 = lazy_0.map(lambda s_0: lambda: '{}!'.format(s_0()))
    lazy_2 = lazy_1.map(lambda x_0: x_0())


# Generated at 2022-06-25 23:32:33.610434
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()

    from pymonet.lazy import Lazy

    res_0 = Lazy(lambda: 1)

    assert(Box(1).to_lazy() == res_0)



# Generated at 2022-06-25 23:32:38.380277
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = None
    box_0 = Box(dict_0)
    might_have_stored_value_0 = box_0.to_lazy()
    value_0 = might_have_stored_value_0.fold()

# Generated at 2022-06-25 23:32:42.915850
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_either import Left

    left = Left(1)
    lazy = left.to_lazy()

    assert lazy == Lazy(lambda: left)

    left = Left(1).to_lazy().force()

    assert left.to_lazy().force() == left.to_lazy()

# Generated at 2022-06-25 23:32:46.932778
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = dict(value_0=0, value_1=1, value_2=2)
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.fold() == dict_0



# Generated at 2022-06-25 23:32:51.639105
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_result import Ok
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    class FunctorImpl(Functor):
        def fmap(self, mapper: Callable[[T], T]) -> T:
            pass

    functor = FunctorImpl()

    assert isinstance(Box(Ok(functor)).to_lazy(), Lazy)


# Generated at 2022-06-25 23:32:55.120518
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()
    assert dict_0 == lazy_0.value()


# Generated at 2022-06-25 23:32:56.600705
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(3)
    assert box.to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-25 23:32:57.608477
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Box[None] -> Lazy[Function(() -> None)]
    assert Box(None).to_lazy().fold() is None


# Generated at 2022-06-25 23:32:59.976690
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Case 0: input box is None
    """

    box_0 = Box(0)
    result_0 = box_0.to_lazy()

    assert result_0.fold() == 0

# Generated at 2022-06-25 23:33:03.679289
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from typing import Dict, Union
    from pymonet.lazy import Lazy
    dict_0 = {'key_0': 'value_0', 'key_1': 'value_1'}
    box_0 = Box(dict_0)
    lazy_0 = Lazy(lambda: dict_0)
    assert box_0.to_lazy() == lazy_0



# Generated at 2022-06-25 23:33:06.634154
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    mock_0 = MagicMock()
    mock_0.return_value = None
    box_0 = Box(mock_0)
    ret_0 = box_0.to_lazy()
    assert ret_0.value() == None


# Generated at 2022-06-25 23:33:12.988174
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: {'foo': 'bar'}) == Box({'foo': 'bar'}).to_lazy()



# Generated at 2022-06-25 23:33:16.403514
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 2
    box_0 = Box(value)
    lazy_0 = box_0.to_lazy()

    result = lazy_0.value()
    assert result == value, "values are different"


# Generated at 2022-06-25 23:33:20.813101
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test behaviour of method to_lazy of Box object.
    """
    from pymonet.maybe import Maybe

    value = 1
    box_0 = Box(value)
    box_1 = box_0.to_lazy()

    value_0 = box_1.value()

    assert box_1.is_folded is False
    assert value_0 == value



# Generated at 2022-06-25 23:33:23.560561
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = {'a': 1}
    box_0 = Box(dict_0)
    lazy_0 = Lazy(lambda: dict_0)
    assert box_0.to_lazy().value() is dict_0


# Generated at 2022-06-25 23:33:31.429500
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 1
    dict_0 = "a"
    box_0 = Box(dict_0)
    lazy_1 = box_0.to_lazy()
    assert(lazy_1.value() == "a")
    # Test case 2
    dict_0 = "a"
    box_0 = Box(dict_0)
    lazy_1 = box_0.to_lazy()
    assert(lazy_1.value() == "a")
    # Test case 3
    dict_0 = "a"
    box_0 = Box(dict_0)
    lazy_1 = box_0.to_lazy()
    assert(lazy_1.value() == "a")
    # Test case 4
    dict_0 = "a"
    box_0 = Box(dict_0)
   

# Generated at 2022-06-25 23:33:32.721509
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(dict_0).to_lazy() == Lazy(lambda: dict_0)



# Generated at 2022-06-25 23:33:35.622050
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = dict()
    dict_0['a'] = 2
    dict_0['b'] = 0
    bool_0 = bool()
    bool_0 = False
    int_0 = int()
    int_0 = 8
    box = Box(int_0)
    lazy = box.to_lazy()
    result = lazy.value()
    expected = int_0
    assert result == expected
    

# Generated at 2022-06-25 23:33:42.952110
# Unit test for method to_lazy of class Box

# Generated at 2022-06-25 23:33:50.018408
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = {"a": 1, "b": 2}
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold() == dict_0
    assert lazy_0.fold(lambda: "lambda") == dict_0
    assert lazy_0.fold(lambda: "lambda", 1, 2) == dict_0
    dict_1 = {}
    box_1 = Box(dict_1)
    lazy_1 = box_1.to_lazy()
    assert lazy_1.fold() == dict_1
    assert lazy_1.fold(lambda: "lambda") == dict_1
    assert lazy_1.fold(lambda: "lambda", 1, 2) == dict_1
    dict_2 = {"a": 2}

# Generated at 2022-06-25 23:33:51.297097
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(42).to_lazy().value()
    assert result == 42


# Generated at 2022-06-25 23:34:03.081455
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = None
    box_0 = Box(dict_0)
    box_1 = box_0.to_lazy()


# Generated at 2022-06-25 23:34:04.651338
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().fold() == 5

# Generated at 2022-06-25 23:34:06.096637
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('Test').to_lazy().is_lazy_ok()


# Generated at 2022-06-25 23:34:08.842870
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(1).to_lazy()) == "Lazy[<function Box.to_lazy.<locals>.<lambda> at 0x7fa9d4a75268>]"


# Generated at 2022-06-25 23:34:12.839113
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 0
    box_0 = Box(int_0)

    lazy_0 = box_0.to_lazy()

    assert lazy_0.fold() == int_0
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:34:17.587006
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    def f():
        return 1

    box_0 = Box(f)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Monad)
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 1


# Generated at 2022-06-25 23:34:21.010869
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-25 23:34:23.329467
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-25 23:34:26.470831
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 'some-value'
    box = Box(value)
    lazy = box.to_lazy()
    assert lazy.value() == value


# Generated at 2022-06-25 23:34:35.713157
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = None
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_lazy()
    assert lazy_0.is_value()
    assert not lazy_0.is_value_or_exception()
    assert not lazy_0.is_exception()
    assert lazy_0.is_value()
    assert lazy_0.is_lazy()
    assert not lazy_0.is_exception()
    assert lazy_0 == lazy_0
    assert not lazy_0 != lazy_0
    assert lazy_0 is not lazy_0
    assert str(lazy_0) == 'Lazy[value=None]'
    assert lazy_0.value == None
    lazy_0.set_value('a')
    assert lazy

# Generated at 2022-06-25 23:34:57.975413
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # test_case_0
    dict_0 = {'a': 'b'}
    box_0 = Box(dict_0)
    lazy = box_0.to_lazy()
    assert isinstance(lazy, Lazy)
    assert not lazy.is_folded()
    assert lazy.get_value() == {'a': 'b'}
    assert lazy == Lazy({'a': 'b'})

# Generated at 2022-06-25 23:35:02.334056
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy

    monad_0 = Box(5)
    monad_1 = monad_0.to_lazy()

    assert isinstance(monad_1, Monad)
    assert isinstance(monad_1, Lazy)
    assert monad_1.fold(lambda x: x) == 5


# Generated at 2022-06-25 23:35:06.045966
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from random import randint
    from pymonet.lazy import Lazy

    random_value = randint(0, 100)
    box_lazy = Box(random_value).to_lazy()
    assert isinstance(box_lazy, Lazy)
    assert box_lazy.value == random_value



# Generated at 2022-06-25 23:35:08.094179
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = {1: 2, 3: 4}
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == dict_0


# Generated at 2022-06-25 23:35:10.680441
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy()
    assert Box(1).to_lazy() != Box(2).to_lazy()
    assert Box('f').to_lazy() == Box('f').to_lazy()


# Generated at 2022-06-25 23:35:13.505000
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    # Setup
    dict_0 = None
    box_0 = Box(dict_0)

    # Testing
    box_1 = box_0.to_lazy()

    # Verification
    lazy_0 = box_1
    assert isinstance(lazy_0, Lazy)



# Generated at 2022-06-25 23:35:17.255970
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_1 = dict()
    dict_0 = dict_1
    box_1 = Box(dict_0)
    box_1.to_lazy()
    dict_0 = dict()
    box_1 = Box(dict_0)
    box_1.to_lazy()


# Generated at 2022-06-25 23:35:22.578994
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy = Lazy(lambda: 5)
    try_ = Try(lambda: 5, is_success=True)
    try_1 = Try(lambda: 5, is_success=False)
    assert(Box(lazy).to_lazy() == lazy)
    assert(Box(try_).to_lazy() == Lazy(lambda: 5))
    assert(Box(try_1).to_lazy() == Lazy(lambda: None))

# Generated at 2022-06-25 23:35:27.509086
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test data
    dict_0 = {"a": 1}
    box_0 = Box(dict_0)
    # Expected result
    expected_result = dict_0
    # Why is a unit test for a monad constructor necessary?
    # Because bugs happen. And the more basic functionality a monad constructor has the better.
    # In this case the box constructor simply just stores a value internally.
    # The test makes sure that the constructor really does that.
    result = box_0.to_lazy().bind(lambda x: x()).value
    assert result == expected_result


# Generated at 2022-06-25 23:35:29.930544
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(1)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == 1



# Generated at 2022-06-25 23:36:16.839794
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    dict_0 = {'key_0': 'value_0'}
    dict_1 = {'key_1': 'value_1'}
    dict_2 = {'key_2': 'value_2'}

    box_0 = Box(dict_0)
    box_1 = Box(dict_1)
    box_2 = Box(dict_2)

    lazy_0 = box_0.to_lazy()
    lazy_1 = box_1.to_lazy()
    lazy_2 = box_2.to_lazy()

    assert type(lazy_0) == Lazy
    assert type(lazy_1) == Lazy
    assert type(lazy_2) == Lazy
    assert lazy_0 == lazy_0
    assert lazy

# Generated at 2022-06-25 23:36:20.333732
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_value = {"a": 1}
    box_0 = Box(dict_value)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.computed() == dict_value



# Generated at 2022-06-25 23:36:27.910310
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.monad_try
    # setUpClass
    dict_0 = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    list_0 = ['a', 'b', 'c']
    list_1 = ['b', 'c', 'a']
    str_0 = 'abc'
    str_1 = 'bca'
    str_2 = 'cab'
    box_0 = Box(dict_0)
    box_1 = Box(list_0)
    box_2 = Box(list_1)
    box_3 = Box(str_0)
    box_4 = Box(str_1)
    box_5 = Box(str_2)
    # print(box_5.value)
    # print(box_2.value)

# Generated at 2022-06-25 23:36:29.965421
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy() == Box(3).to_lazy()



# Generated at 2022-06-25 23:36:32.933422
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = {
        'key': 'value'
    }
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()
    lazy_0.fold(lambda: 'Error', lambda x: x())


# Generated at 2022-06-25 23:36:36.421280
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = None
    box_0 = Box(dict_0)
    dict_1 = box_0.to_lazy().value
    len_1 = 0
    assert len_1 == len(dict_1.value())
    len_2 = 3
    assert len_2 == len(dict_1.value())




# Generated at 2022-06-25 23:36:39.038359
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    dict_0 = {'a': 1}
    box_0 = Box(dict_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == dict_0



# Generated at 2022-06-25 23:36:47.073239
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # test case #0
    dict_0 = None
    box_0 = Box(dict_0)
    lazy = box_0.to_lazy()
    assert lazy.value() == dict_0

    # test case #1
    box_1 = Box(1)
    lazy = box_1.to_lazy()
    assert lazy.value() == 1

    # test case #2
    box_2 = Box(2.2)
    lazy = box_2.to_lazy()
    assert lazy.value() == 2.2

    # test case #3
    box_3 = Box(3j)
    lazy = box_3.to_lazy()
    assert lazy.value() == 3j

    # test case #4
    box_4 = Box(object())
    lazy = box_4.to_

# Generated at 2022-06-25 23:36:51.808371
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    test_box = Box(lambda x: x)
    assert test_box.to_lazy() == Lazy(test_box.value)



# Generated at 2022-06-25 23:36:53.432614
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 2
    box_0 = Box(value)
    assert box_0.to_lazy().get() == value
