

# Generated at 2022-06-25 23:27:31.976374
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Case 0: test equality with self
    var_0 = "abc"
    var_1 = "abc"
    var_2 = "def"

    box_0 = Box(var_0)
    box_1 = Box(var_1)
    box_2 = Box(var_2)

    assert box_0 == box_0
    assert box_0 == box_1

    assert not box_0 != box_0
    assert not box_0 != box_1

    assert not box_0 == box_2
    assert not box_2 == box_0

    assert box_0 != box_2
    assert box_2 != box_0



# Generated at 2022-06-25 23:27:32.896971
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    pass

# Generated at 2022-06-25 23:27:37.080183
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box(None)
    assert Box(1) != 1
    assert Box(1) != None
    assert Box(None) != Box(1)
    assert Box(None) != 1


# Generated at 2022-06-25 23:27:40.416912
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from nose.tools import assert_true

    var_0 = None
    box_0 = Box(var_0)
    lazy = box_0.to_lazy()
    assert_true(isinstance(lazy, Lazy))


# Generated at 2022-06-25 23:27:43.493823
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0: TypeVar = None
    box_0: Box[TypeVar] = Box(var_0)

# Generated at 2022-06-25 23:27:46.346349
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    box_1 = box_0.to_lazy()
    var_1 = None
    assert var_1 == box_1.value()

# Generated at 2022-06-25 23:27:54.871956
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = -575999357
    box_0 = Box(var_0)
    var_1 = Box(var_0)
    box_1 = Box(var_1)
    var_2 = 652909082.22
    box_2 = Box(var_2)
    var_3 = not var_0
    box_3 = Box(var_3)
    assert box_0 == box_1
    assert not (box_0 == box_2)
    assert not (box_2 == box_3)
    assert box_0 != box_2
    assert box_2 != box_3
    assert not (box_0 != box_1)



# Generated at 2022-06-25 23:27:58.372354
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = 'foo'
    box_0 = Box(var_0)
    var_1 = 'foo'
    box_1 = Box(var_1)
    assert box_0 == box_1, 'Expected values to be equal'


# Generated at 2022-06-25 23:28:01.495599
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test case for method __eq__ of class Box.
    """
    var_0 = 3
    box_0 = Box(var_0)
    assert box_0 == Box(3)
    var_1 = bool
    box_1 = Box(var_1)
    assert box_1 == Box(bool)


# Generated at 2022-06-25 23:28:05.665387
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test case for method __eq__ of class Box
    """
    var_0 = None
    var_1 = None
    box_0 = Box(var_0)
    box_1 = Box(var_1)
    assert box_0 == box_1



# Generated at 2022-06-25 23:28:11.566251
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0
    assert var_1.value == var_0


# Generated at 2022-06-25 23:28:13.247811
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert(Box(10).to_lazy() == Box(lambda: 10).to_lazy())


# Generated at 2022-06-25 23:28:16.609597
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = None
    box_1 = Box(var_1)
    assert box_0 == box_1


# Generated at 2022-06-25 23:28:21.038122
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = 1
    box_0 = Box(var_0)
    var_1 = 1
    box_1 = Box(var_1)
    assert box_0 == box_1
    var_2 = 1
    box_2 = Box(var_2)
    var_3 = 2
    box_3 = Box(var_3)
    assert box_2 != box_3


# Generated at 2022-06-25 23:28:23.528670
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = None
    var_1 = None
    box_0 = Box(var_0)
    box_1 = Box(var_1)
    box_0 = Box(var_0)
    var_0 = Box(box_0)
    assert var_0 == var_0


# Generated at 2022-06-25 23:28:26.030652
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    box_0.to_lazy()


# Generated at 2022-06-25 23:28:28.473787
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = Box(0)
    assert var_0 == Box(0)



# Generated at 2022-06-25 23:28:38.228016
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = None
    box_0 = Box(var_0)
    box_1 = Box(var_0)
    if box_0 == box_1:
        pass
    var_0 = None
    box_0 = Box(var_0)
    box_1 = Box(var_0)
    if box_0 == box_1:
        pass
    var_0 = None
    box_0 = Box(var_0)
    box_1 = Box(var_0)
    if box_0 == box_1:
        pass
    var_0 = None
    box_0 = Box(var_0)
    box_1 = Box(var_0)
    if box_0 == box_1:
        pass
    box_0 = None
    box_1 = None

# Generated at 2022-06-25 23:28:39.506845
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = True
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()


# Generated at 2022-06-25 23:28:42.603938
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Preparations before the test
    var_0 = None
    box_0 = Box(var_0)

    # Executing the test
    lazy_0 = box_0.to_lazy()

    # Verifying the test result
    assert lazy_0.is_value_exist() is False


# Generated at 2022-06-25 23:28:50.740841
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = 1
    box_0 = Box(var_0)

    var_1 = 1
    box_1 = Box(var_1)

    assert isinstance(box_0, Box)

    result_0 = box_0 == box_1

    assert isinstance(result_0, bool)



# Generated at 2022-06-25 23:28:58.400561
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = Box(1)
    var_1 = var_0
    assert var_0 == var_1
    assert not var_0 != var_1

    var_2 = Box(2)
    assert not var_0 == var_2
    assert var_0 != var_2

    var_3 = None

    def function_0(arg_0):
        return arg_0

    var_4 = function_0(var_0)
    assert var_4 == var_1
    assert not var_4 != var_1

    assert not var_4 == var_2
    assert var_4 != var_2



# Generated at 2022-06-25 23:29:01.982619
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = None
    var_1 = None
    box_0 = Box(var_0)
    box_1 = Box(var_1)
    assert box_0 == box_1, "Test for method __eq__ of class Box failed"


# Generated at 2022-06-25 23:29:05.048994
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for method to_lazy of class Box
    """
    var_0 = 5
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == var_0


# Generated at 2022-06-25 23:29:07.321147
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0 = Box(1)
    box_1 = Box(2)
    assert not box_0 == box_1
    box_1.value = 1
    assert box_0 == box_1



# Generated at 2022-06-25 23:29:15.197010
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 1
    box_0 = Box(var_0)

    # expected: Lazy!!
    var_1 = box_0.to_lazy()
    print(var_1)  # Lazy!!
    print(var_1.fold())  # 1


# Generated at 2022-06-25 23:29:17.241398
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    maybe_0 = box_0.to_lazy()


# Generated at 2022-06-25 23:29:20.165964
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = None
    box_1 = Box(var_1)
    assert box_0 == box_1, 'Result of comparison is invalid'


# Generated at 2022-06-25 23:29:23.372128
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.either import Left
    from pymonet.maybe import Nothing

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != Left(1)
    assert Box(1) != Nothing


# Generated at 2022-06-25 23:29:34.587710
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Set up test fixture
    var_0 = None
    box_0 = Box(var_0)
    box_1 = Box(var_0)
    box_2 = Box(var_0)
    box_3 = Box(var_0)
    expected_result_0 = True
    expected_result_1 = False
    expected_result_2 = False
    expected_result_3 = True
    expected_result_4 = False
    
    # Exercise SUT
    actual_result_0 = box_0 == box_1
    actual_result_1 = box_0 == box_2
    actual_result_2 = box_0 == box_3
    actual_result_3 = box_1 == box_1
    actual_result_4 = box_1 == box_2
    
    # Verify outcome

# Generated at 2022-06-25 23:29:42.230640
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    var_2 = var_1.value()
    var_3 = var_0
    var_4 = (var_2 == var_3)
    var_5 = False
    var_6 = (var_4 == var_5)
    assert(var_6)


# Generated at 2022-06-25 23:29:44.951101
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.__name__ == '<lambda>'


# Generated at 2022-06-25 23:29:47.875475
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    var_1 = Box(var_0)

    var_2 = var_1.to_lazy()
    var_3 = var_2.fold()
    assert var_0 == var_3

# Generated at 2022-06-25 23:29:48.728474
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()

# Generated at 2022-06-25 23:29:49.980566
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a = Box(10)
    b = a.to_lazy()
    assert b.value() == 10


# Generated at 2022-06-25 23:29:51.480232
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = int
    box_0 = Box(var_0).to_lazy()
    var_1 = box_0.run()
    assert var_1 == var_0

# Generated at 2022-06-25 23:29:55.904714
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    expected_0 = 'Lazy[value=(<function Box.__init__.<locals>.<lambda> at 0x0000000002B5B268>)]'
    actual_0 = None
    box_0 = Box(None)
    actual_0 = box_0.to_lazy().__str__()
    assert expected_0 == actual_0


# Generated at 2022-06-25 23:30:05.979506
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    none_box_0 = Box(None)
    assert none_box_0.to_lazy() == Lazy(lambda: None)

    none_box_1 = Box(0)
    assert none_box_1.to_lazy() == Lazy(lambda: 0)

    none_box_2 = Box("1")
    assert none_box_2.to_lazy() == Lazy(lambda: "1")

    none_box_3 = Box(())
    assert none_box_3.to_lazy() == Lazy(lambda: ())

    none_box_4 = Box("")
    assert none_box_4.to_lazy() == Lazy(lambda: "")

    none_box_5 = Box("2")

# Generated at 2022-06-25 23:30:09.494202
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    var_2 = Lazy(lambda:var_0)
    var_3 = var_1 == var_2


# Generated at 2022-06-25 23:30:13.818965
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_0 = Lazy(lambda: 1)
    box_0 = Box(lazy_0)
    lazy_1 = box_0.to_lazy()
    assert(lazy_0 == lazy_1)
    var_0 = 2
    box_1 = Box(var_0)
    lazy_2 = box_1.to_lazy()
    assert(lazy_2.eval() == 2)



# Generated at 2022-06-25 23:30:20.507352
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_1 = Box(1)
    lazy_monad_1 = box_1.to_lazy()
    assert lazy_monad_1.value == 1



# Generated at 2022-06-25 23:30:23.661567
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = 0
    box_0 = Box(var_0)
    assert box_0.to_lazy() == Lazy(lambda: var_0)


# Generated at 2022-06-25 23:30:33.388672
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(1)
    assert box_0.to_lazy().value().value == 1

    box_1 = Box(2.1)
    assert box_1.to_lazy().value().value == 2.1

    box_2 = Box("test string")
    assert box_2.to_lazy().value().value == "test string"

    box_3 = Box([1, 2, 3, 4, 5])
    assert box_3.to_lazy().value().value == [1, 2, 3, 4, 5]

    box_4 = Box({1: "one", 2: "two"})
    assert box_4.to_lazy().value().value == {1: "one", 2: "two"}


# Generated at 2022-06-25 23:30:34.891680
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()



# Generated at 2022-06-25 23:30:37.386288
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box('string').to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 'string'



# Generated at 2022-06-25 23:30:42.118056
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    # Tests if var_1 of type Lazy
    assert type(var_1) is Lazy


# Generated at 2022-06-25 23:30:46.755136
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Assert
    var_0 = None
    box_0 = Box(var_0)

    # Arrange
    actual = box_0.to_lazy()

    # Act
    expected = 'Box[value=None]'

    # Assert
    assert str(actual) == expected


# Generated at 2022-06-25 23:30:50.265498
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = 5
    box_0 = Box(var_0)
    lazy_0 = Lazy(lambda : 5)
    assert box_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:30:52.422669
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # set up
    box = Box(1)

    # assert
    assert box.to_lazy().get() == 1


# Generated at 2022-06-25 23:31:01.826800
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    def test_function():
        box_0 = Box(10)
        lazy = box_0.to_lazy()

        assert lazy.function() == 10

    def test_function_returns_maybe():
        box_0 = Box(10)
        lazy = box_0.to_lazy()

        maybe = lazy.function().to_maybe()

        assert maybe.is_nothing() is False
        assert maybe.is_just() is True
        assert maybe.value == 10

    def test_function_return_try():
        box_0 = Box(10)
        lazy = box_0.to_lazy()

        maybe = lazy.function().to_try()

# Generated at 2022-06-25 23:31:13.164321
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().to_value() == 1


# Generated at 2022-06-25 23:31:17.223476
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def func_0():
        var_0 = None
        box_0 = Box(var_0)
        lazy_0 = box_0.to_lazy()

    func_0()


# Generated at 2022-06-25 23:31:28.532892
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # assert Eq
    assert Box("Hello, world!").to_lazy() == Lazy(lambda: "Hello, world!")
    # assert Eq
    assert Box(None).to_lazy() == Lazy(lambda: None)
    # assert Eq
    assert Box(0.0).to_lazy() == Lazy(lambda: 0.0)
    # assert Eq
    assert Box(0).to_lazy() == Lazy(lambda: 0)
    # assert Eq
    assert Box({}).to_lazy() == Lazy(lambda: {})
    # assert Eq
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    # assert Eq
    assert Box(()).to_lazy() == Lazy(lambda: ())
    # assert Eq
   

# Generated at 2022-06-25 23:31:31.235273
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 42
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.get() == var_0


# Generated at 2022-06-25 23:31:34.546688
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.has_value == True


# Generated at 2022-06-25 23:31:39.903133
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box[type(None)](var_0)
    assert box_0 is not None
    lazy_0 = box_0.to_lazy()
    assert lazy_0 is not None
    assert lazy_0.value is not None
    var_1 = lazy_0.value()
    assert var_1 is None

# Generated at 2022-06-25 23:31:42.951803
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert(Box(4).to_lazy().fold() == 4)


# Generated at 2022-06-25 23:31:46.671531
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    value_0 = lazy_0.value


# Generated at 2022-06-25 23:31:55.829612
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    :returns: True if test passed, False otherwise
    :rtype: bool
    """
    from pymonet.lazy import Lazy
    class_name = 'Lazy'
    method_name = '__init__'
    value_0 = 1
    box_0 = Box(value_0)
    var_0 = box_0.to_lazy()
    assert isinstance(var_0, Lazy), 'Returned value is not instance of class {0}'.format(class_name)
    assert var_0.value.__name__ == method_name, 'Returned value is not {0}'.format(method_name)


# Generated at 2022-06-25 23:32:05.358823
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    assert Box(None).to_lazy().get_value() == None

    assert Box(1).to_lazy().get_value() == 1

    assert Box(1.1).to_lazy().get_value() == 1.1

    assert Box("abc").to_lazy().get_value() == "abc"

    assert Box(dict()).to_lazy().get_value() == dict()

    assert Box(list()).to_lazy().get_value() == list()

    assert Box(tuple()).to_lazy().get_value() == tuple()

    assert Box(set()).to_lazy().get_value() == set()

    assert Box(1) == Box(1)

    assert Box(1) != Box(1.1)

    assert Box(1) != Box("abc")


# Generated at 2022-06-25 23:32:26.401720
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0: Lazy[None] = box_0.to_lazy()
    var_1 = lazy_0.fold()
    assert var_0 == var_1


# Generated at 2022-06-25 23:32:29.222977
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    for _ in range(0, 100000):
        box_0 = Box(None)
        var_0 = box_0.to_lazy()
        var_0 = var_0.fold(func)



# Generated at 2022-06-25 23:32:32.407344
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(None)
    val_1 = Lazy(lambda: box_0.value)
    res_0 = box_0.to_lazy()

    assert res_0 == val_1


# Generated at 2022-06-25 23:32:35.357411
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Box)
    assert lazy_0.value == var_0



# Generated at 2022-06-25 23:32:36.935920
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:32:40.222311
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = Lazy(var_0)
    assert box_0.to_lazy() == lazy_0



# Generated at 2022-06-25 23:32:41.665339
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    maybe_0 = Box(var_0).to_lazy()


# Generated at 2022-06-25 23:32:50.747602
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    var_0 = None
    box_0 = Box(var_0)
    maybe_0 = box_0.to_maybe()
    assert maybe_0 == Maybe.nothing()
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: var_0)
    try_0 = box_0.to_try()
    assert try_0 == Try(var_0, is_success=True)
    either_0 = box_0.to_either()
    assert either_0 == Right(var_0)
    validation_0 = box_

# Generated at 2022-06-25 23:32:51.954923
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert(Box(1).to_lazy().value() == 1)


# Generated at 2022-06-25 23:32:56.095730
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    var_2 = var_1.fold()
    var_3 = isinstance(var_2, type(None))
    var_4 = isinstance(var_2, type(Box(None)))


# Generated at 2022-06-25 23:33:35.524366
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = str("hey")
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    lazy_0.fold(lambda _: None)


# Generated at 2022-06-25 23:33:37.337568
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().unwrap(methodcaller('__call__')) == 42


# Generated at 2022-06-25 23:33:38.337798
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('3').to_lazy() == Box('3').value


# Generated at 2022-06-25 23:33:39.803692
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    assert Box(None).to_lazy() == Box(None).to_lazy()



# Generated at 2022-06-25 23:33:43.109756
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for method to_lazy of class Box

    :return: nothing
    """

    def lambda_0() -> int:
        return 1

    box_0 = Box(lambda_0)
    lazy_0 = box_0.to_lazy()
    int_0 = lazy_0.get()
    assert int_0 == 1



# Generated at 2022-06-25 23:33:46.801148
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad import Dict, DictT, List, ListT, StateT, State, ReaderT, Reader, Writer, WriterT, Option

    var_1 = lambda: 5
    box_0 = Box(var_1)
    var_2 = box_0.to_lazy()
    assert var_2.fold() == 5



# Generated at 2022-06-25 23:33:50.925211
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = 'lazy_0'

    box_0 = Box(var_0)

    lazy_0 = box_0.to_lazy()

    # Ensure that lazy_0 is instance of Lazy
    assert isinstance(lazy_0, Lazy)

    # Ensure that lazy_0 is equal to Lazy(lambda: var_0)
    assert lazy_0 == Lazy(lambda: var_0)


# Generated at 2022-06-25 23:33:53.200144
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 5
    box_0 = Box(var_0)
    expected_0 = Lazy(lambda: 5)
    actual_0 = box_0.to_lazy()
    assert expected_0 == actual_0



# Generated at 2022-06-25 23:33:55.661988
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value_0 = None
    box_0 = Box(value_0)
    lazy_0 = box_0.to_lazy()
    contains_0 = lazy_0.contains
    result_0 = contains_0()


# Generated at 2022-06-25 23:34:04.973088
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    box_0 = Box([1, 2])
    lazy_0 = box_0.to_lazy()
    lazy_0.fold(None)
    assert lazy_0 == Lazy(lambda: [1, 2])
    try_0 = box_0.to_lazy().to_try()
    try_0.fold(lambda value: None, lambda exception: None)
    assert try_0 == Try([1, 2], True)
    lazy_1 = box_0.to_lazy().to_try().to_lazy()
    lazy_1.fold(None)
    assert lazy_1 == Lazy(lambda: Try([1, 2], True))


# Generated at 2022-06-25 23:35:30.650502
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Prepare data
    var_0 = None
    box_0 = Box(var_0)
    # Perform action
    lazy_0 = box_0.to_lazy()
    # Check result
    assert lazy_0.value() is var_0
    assert lazy_0.fold() is var_0

# Generated at 2022-06-25 23:35:33.838288
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    result = lazy_0.unwrap()
    var_1 = None
    assert result == var_1


# Generated at 2022-06-25 23:35:35.960440
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(10)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold() == 10


# Generated at 2022-06-25 23:35:37.970191
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = None
    lazy_0 = Box(box_0).to_lazy()
    lazy_0.fold(lambda: None, lambda: None)


# Generated at 2022-06-25 23:35:40.678361
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = None
    box_0 = Box(var_0)
    var_1 = box_0.to_lazy()
    var_2 = var_1.map(lambda x: x ** 2)
    var_3 = var_2.get()


# Generated at 2022-06-25 23:35:47.437488
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test case for method to_lazy of class Box
    """
    var_0 = None
    box_0 = Box(var_0)
    from pymonet.lazy import Lazy

    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0._value_func() is None

    var_0 = 1
    box_0 = Box(var_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0._value_func() == var_0



# Generated at 2022-06-25 23:35:49.035161
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().get() == 1
    assert Box(1).to_lazy().fold(_map=lambda _: 2) == 1


# Generated at 2022-06-25 23:35:52.730319
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    var_0 = Maybe.just(5)
    box_0 = Box(var_0)
    assert box_0.to_lazy() == Lazy(lambda: var_0)



# Generated at 2022-06-25 23:35:55.212284
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    var_0 = 10
    box_0 = Box(var_0)

    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold() == var_0

# Generated at 2022-06-25 23:35:57.358319
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    assert (box.to_lazy() == Lazy(lambda: 1))
