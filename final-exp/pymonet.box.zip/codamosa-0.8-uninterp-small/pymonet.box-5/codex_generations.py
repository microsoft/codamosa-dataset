

# Generated at 2022-06-25 23:27:33.987998
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1376155559.7949474).to_lazy() == Lazy(1376155559.7949474)


# Generated at 2022-06-25 23:27:43.327537
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = -0.19179014800057389
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded() is False
    assert lazy_0.force() == float_0
    float_1 = -0.19179014800057389
    box_1 = Box(float_1)
    lazy_1 = box_1.to_lazy()
    assert lazy_1.is_folded() is False
    assert lazy_1.force() == float_1
    float_2 = -0.19179014800057389
    box_2 = Box(float_2)
    lazy_2 = box_2.to_lazy()
    assert lazy_2.is_folded() is False

# Generated at 2022-06-25 23:27:53.541936
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    float_0 = -0.3
    float_1 = 0.0
    float_2 = 0.3
    float_3 = -37.75
    int_0 = 121471
    str_0 = '~g^Zp[M{T'
    str_1 = '~B^Zp[M{T'
    str_2 = '~g^Zp[M{T'
    complex_0 = complex(float_1, float_3)
    complex_1 = complex(float_3, float_1)
    complex_2 = complex(float_1, float_1)
    box_0 = Box(float_0)
    box_1 = Box(float_1)
    box_2 = Box(float_2)
    box_3 = Box(float_3)

# Generated at 2022-06-25 23:27:56.798491
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    float_1 = float(lazy_0.force())
    assert float_1 == float_0


# Generated at 2022-06-25 23:27:59.119492
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    t1 = Box(1)
    t2 = Box(1)
    assert t1 == t2

    t3 = Box(2)
    assert t1 != t3



# Generated at 2022-06-25 23:28:10.528627
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Just
    from pymonet.either import Left, Right

    # Case 0
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    box_1 = lazy_0.map(float_0.__add__).box()

    assert box_1 == Box(float_0 * 2)

    # Case 1
    string_0 = 'LmeBbZiBp'
    box_2 = Box(string_0)
    lazy_1 = box_2.to_lazy()

# Generated at 2022-06-25 23:28:17.475740
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from nose2.tools import params
    from random import random
    from pymonet.monad_maybe import NoneType

    @params(
        (0, 0),
        (1, 2),
        (0, False),
        (random(), random()),
        (None, None),
        (None, NoneType.NONE),
        (NoneType.NONE, None)
    )
    def test(val_0, val_1):
        assert Box(val_0) == Box(val_1)


# Generated at 2022-06-25 23:28:19.619944
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(float(42.25))

    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == 42.25


# Generated at 2022-06-25 23:28:29.711733
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    float_0 = 1316.8040317467547
    float_1 = -1316.8040317467547
    float_2 = 1.0
    box_0 = Box(float_0)
    box_1 = Box(float_1)
    box_2 = Box(float_2)
    box_3 = Box(float_0)
    box_4 = Box("hello")
    str_2 = str(box_2)
    str_1 = str(box_1)
    str_0 = str(box_0)
    box_5 = Box("hello")
    box_6 = Box("Hello")
    str_5 = str(box_5)
    str_4 = str(box_4)
    str_3 = str(box_3)

# Generated at 2022-06-25 23:28:34.836484
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Test function and expected values
    float_0 = 1318.2409035706512
    bool_0 = Box(float_0).__eq__(Box(float_0)) == True
    bool_1 = Box(float_0).__eq__(Box(float_0)) == False
    bool_2 = Box(float_0).__eq__(Box(float_0)) == False



# Generated at 2022-06-25 23:28:37.602299
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert callable(Box.to_lazy)


# Generated at 2022-06-25 23:28:44.543233
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Perhaps
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    int_0 = 9737
    box_0 = Box(int_0)
    assert isinstance(box_0.to_lazy(), Lazy)
    assert isinstance(box_0.to_maybe(), Perhaps)
    assert isinstance(box_0.to_try(), Try)
    assert isinstance(box_0.to_validation(), Validation)
    str_0 = 'tBhX'
    box_1 = Box(str_0)
    assert isinstance(box_1.to_maybe(), Perhaps)
    assert isinstance(box_1.to_try(), Try)

# Generated at 2022-06-25 23:28:51.512109
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import MonadFactory

    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    assert MonadFactory.is_lazy(lazy_0)
    assert Lazy.is_lazy(lazy_0) is True
    assert lazy_0.unwrap() == box_0.value

# Generated at 2022-06-25 23:28:55.635141
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

    actual_0 = box_0.to_lazy()
    expected_0 = float_0
    assert actual_0.value() == expected_0



# Generated at 2022-06-25 23:28:59.332366
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

    assert box_0.to_lazy() == Lazy(1318.2409035706512)


# Generated at 2022-06-25 23:29:02.469441
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_value = 1318.2409035706512
    box = Box(float_value)
    box_result = box.to_lazy()
    assert(box_result.value() == float_value)


# Generated at 2022-06-25 23:29:07.552754
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def get_maybe_0():
        return Maybe.just(1318.2409035706512)

    lazy_0 = get_maybe_0().to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_0.value, Maybe)
    assert lazy_0.value == Maybe.just(1318.2409035706512)


# Generated at 2022-06-25 23:29:20.509084
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy

# Generated at 2022-06-25 23:29:32.815028
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

    # Test case 1
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

    # Test case 2
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

    # Test case 3
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

    # Test case 4
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

    # Test case 5
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

   

# Generated at 2022-06-25 23:29:38.570626
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    try_0: Try = lazy_0.get()
    assert lazy_0.folded is False
    assert try_0.is_success()
    assert try_0.value == float_0


# Generated at 2022-06-25 23:29:47.954510
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    string_0 = 'aae98c0b-eae7-4157-91b7-95e9a03f7c74'
    box_0 = Box(string_0)
    
    # Act
    actual_0 = box_0.to_lazy()
    
    # Assert
    expected_0 = 'Box[value=Lazy[value=<function Box.to_lazy.<locals>.<lambda> at 0x0000021E4BCFBEA0>]]'
    assert str(actual_0) == expected_0


# Generated at 2022-06-25 23:29:49.107935
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().value() == 3, 'Box to_lazy return Lazy with correct value'


# Generated at 2022-06-25 23:29:54.241641
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    def test_case_0():
        # 1318.2409035706512
        float_0 = 1318.2409035706512
        box_0 = Box(float_0)
        lazy = box_0.to_lazy()
        assert lazy.fold() == float_0
        assert lazy.fold(lambda x: x + x) == float_0

    test_case_0()

    def test_case_1():
        string_0 = '1318.2409035706512'
        box_0 = Box(string_0)
        lazy = box_0.to_lazy()
        assert lazy.fold() == string_0
        assert lazy.fold(lambda x: x + x) == string_0

    test_case_1()

    def test_case_2():
        bool_0

# Generated at 2022-06-25 23:29:57.958038
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    lazy_0.fold(lambda: float_0)


# Generated at 2022-06-25 23:30:02.077330
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = -5.5
    box_0 = Box(float_0)
    string_0 = "test"
    box_1 = box_0.to_lazy()
    box_2 = Box(string_0)
    box_3 = box_1.ap(box_2)
    assert box_3.value == -5.5

# Generated at 2022-06-25 23:30:03.881074
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert_lazy_iterator_equal(Box(42).to_lazy().unfold(), Box(42).value)


# Generated at 2022-06-25 23:30:08.916614
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    unconstructed_lazy_0 = Box[float](1318.2409035706512).to_lazy()
    lazy_1 = lazy_0.force()
    assert lazy_1 == 1318.2409035706512
    lazy_0 = Box('a').to_lazy()
    assert lazy_0.force() == 'a'


# Generated at 2022-06-25 23:30:11.221723
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    assert box_0.to_lazy().value() == float_0



# Generated at 2022-06-25 23:30:20.008550
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Left
    from pymonet.maybe import Nothing
    from pymonet.validation import Validation

    float_0 = 1318.2409035706512

    box_0 = Box(float_0)

    lazy_0 = Lazy(lambda: 2.0)
    lazy_1 = Lazy(lambda: 1.0)

    to_lazy_0 = box_0.to_lazy()
    assert to_lazy_0.is_lazy()
    assert to_lazy_0.value == float_0
    assert to_lazy_0.fold(lambda: 1.0) == float_0

# Generated at 2022-06-25 23:30:22.809209
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_1 = 1318.2409035706512
    box_1 = Box(float_1)
    assert box_1.to_lazy() == Lazy(lambda: float_1)


# Generated at 2022-06-25 23:30:30.178106
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """ Test method to_lazy of class Box."""
    # Create the instance for class Box
    box_0 = Box(13.0)
    # Call the method to_lazy of class Box
    result_0 = box_0.to_lazy()
    # Check the method result
    assert isinstance(result_0, lazy.Lazy)


# Generated at 2022-06-25 23:30:34.837584
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from decimal import Decimal
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    float_1 = float_0
    lazy_0 = box_0.to_lazy()
    float_2 = float_1
    float_3 = lazy_0.fold()
    assert float_3 == float_2


# Generated at 2022-06-25 23:30:37.312454
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(False)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.bind(lambda value: Box(value)).value == False


# Generated at 2022-06-25 23:30:44.745764
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad import UnitTest
    from pymonet.lazy import Lazy

    test_case_0()

    UnitTest(
        test_case=test_case_0,
        expected=Lazy(Box(1318.2409035706512).bind),
        actual=Box(1318.2409035706512).to_lazy(),
        msg="Test Box to_lazy -> Lazy"
    ).run()

test_Box_to_lazy()



# Generated at 2022-06-25 23:30:54.260442
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    try:
        assert box_0.to_lazy() == Lazy(lambda: float_0)
    except AssertionError:
        print('Expected : Lazy[lambda: float_0]')
        print('Actual   : {}'.format(box_0.to_lazy()))
        assert False

    string_0 = 'string_0'
    box_1 = Box(string_0)

# Generated at 2022-06-25 23:30:55.126952
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    pass



# Generated at 2022-06-25 23:30:57.487876
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    input_0 = Box(float())
    output_0 = input_0.to_lazy()
    assert isinstance(output_0, pymonet.lazy.Lazy)


# Generated at 2022-06-25 23:31:07.453878
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    assert type(box_0.to_lazy()) is Lazy

    string_0 = 'str'
    box_1 = Box(string_0)
    assert type(box_1.to_lazy()) is Lazy

    list_0 = ["a", 'b', 9]
    box_2 = Box(list_0)
    assert type(box_2.to_lazy()) is Lazy


# Generated at 2022-06-25 23:31:13.289462
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    string_0 = 'Badger'
    box_0 = Box(string_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(
        lambda: string_0), "Assertion error: Expected box_0.to_lazy() == Lazy(lambda: string_0)"


# Generated at 2022-06-25 23:31:19.246537
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.__class__ == pymonet.lazy.Lazy
    assert lazy_0.value() == float_0


# Generated at 2022-06-25 23:31:34.669137
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(1)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.get() == 1


# Generated at 2022-06-25 23:31:37.846487
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    lazy_0 = Box(float_0).to_lazy()
    assert lazy_0.fold(identity)() == 1318.2409035706512


# Generated at 2022-06-25 23:31:43.984690
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # setup the test data.
    set_of_files = ["/etc/passwd", "/etc/hosts", "/etc/group"]
    lazy_box_of_set_of_files = Box(set_of_files).to_lazy()

    assert lazy_box_of_set_of_files.fold(lambda x: x) == set_of_files



# Generated at 2022-06-25 23:31:48.234660
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 203.826010896
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold() == box_0.value



# Generated at 2022-06-25 23:31:55.149206
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    We test the `to_lazy` method of the Box monad class.
    """
    from pymonet.lazy import Lazy

    # Create Lazy with function returning float_0 (result of getting Lazy from Box) and expected value.
    lazy_0 = Lazy(lambda: 1318.2409035706512)
    float_0 = 1318.2409035706512

    # Expected True.
    assert float_0 == lazy_0.value


# Generated at 2022-06-25 23:31:58.754068
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

    value_0 = box_0.to_lazy()

    value_0 = value_0.map(float_0)



# Generated at 2022-06-25 23:32:01.936528
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = BaseTestCase.box_0
    lazy_0 = box_0.to_lazy()
    value_0 = lazy_0.value()
    assert value_0 == "abracadabra"


# Generated at 2022-06-25 23:32:07.900886
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 0.07564285356682067
    box_0 = Box(float_0)
    box_0.to_lazy()
    float_0 = 0.15072317717459997
    box_0 = Box(float_0)
    float_0 = 0.1423750986731276
    box_1 = Box(float_0)
    box_0.to_lazy()
    box_0.to_lazy()
    box_1.to_lazy()
    box_0.to_lazy()


# Generated at 2022-06-25 23:32:09.751040
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(3)
    boxed_value = Lazy(box_0.value)
    assert box_0.to_lazy() == boxed_value



# Generated at 2022-06-25 23:32:12.785125
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_lazy = 0.2123
    box_lazy = Box(float_lazy)
    box_lazy_get_val = box_lazy.to_lazy().get_val()
    assert box_lazy_get_val == float_lazy


# Generated at 2022-06-25 23:32:38.959445
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()
    import pymonet.lazy
    assert isinstance( (Box(0)).to_lazy(), pymonet.lazy.Lazy)
    assert (Box(42)).to_lazy() == pymonet.lazy.Lazy(42)


# Generated at 2022-06-25 23:32:41.664990
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.fold() == 0


# Generated at 2022-06-25 23:32:45.502432
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 3621.735252415376
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.fold() == 3621.735252415376


# Generated at 2022-06-25 23:32:49.402280
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1782.9285502288843
    box_1 = Box(float_0)
    lazy_0 = box_1.to_lazy()
    float_1 = lazy_0.fold()
    float_2 = box_1.value
    assert float_2 == float_1


# Generated at 2022-06-25 23:32:52.514213
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_1 = Box(float_0)
    lazy_0 = box_1.to_lazy()
    float_1 = lazy_0.value()
    assert float_0 == float_1


# Generated at 2022-06-25 23:32:53.876105
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 1318.2409035706512
    box_0 = Box(float_0)

    assert box_0.to_lazy() == Lazy(box_0.value)



# Generated at 2022-06-25 23:33:01.603469
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as Lazy
    import pymonet.eager as Eager

    # Setup conditions
    float_0 = 212.12
    box_0 = Box(float_0)
    
    # Call method to_lazy of class Box with param box_0
    lazy_0 = box_0.to_lazy()
    
    # Call method get_result of class Lazy with param lazy_0
    float_1 = Lazy.get_result(lazy_0)
    
    # Assert result
    if (float_1 == float_0):
        Eager.print("Test Case 0: suceeded!")
    else:
        Eager.print("Test Case 0: failed!")
        


# Generated at 2022-06-25 23:33:04.230372
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    unit_0 = ()
    float_0 = 26.0
    f_0 = Lazy(float_0).fold(unit_0)
    assert f_0 == float_0


# Generated at 2022-06-25 23:33:07.174840
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    float_1 = lazy_0.get()
    assert(float_0 == float_1)


# Generated at 2022-06-25 23:33:14.537723
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    In order to run test please change <set_to_true_if_you_want_to_check_Box_to_lazy> field to True
    """
    if False:
        float_0 = 1318.2409035706512
        box_0 = Box(float_0)

        lazy_0 = box_0.to_lazy()

        assert (lazy_0.is_folded == False)
        assert (lazy_0.value() == float_0)
    else:
        print('test_Box_to_lazy: skipped')


# Generated at 2022-06-25 23:34:10.545968
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    box_1 = box_0.to_lazy()
    assert isinstance(box_1, Lazy)


# Generated at 2022-06-25 23:34:12.759467
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:34:16.508179
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = -0.738296353
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    function_0 = lazy_0.get()

    assert (function_0() == float_0)

# Generated at 2022-06-25 23:34:22.092779
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    number = 0
    box = Box(number)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: number)



# Generated at 2022-06-25 23:34:27.569310
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    from pymonet.lazy import Lazy

    initial_value = 123.321
    box_0 = Box(initial_value)

    # When
    lazy_0 = box_0.to_lazy()

    # Then
    assert lazy_0 == Lazy(lambda: initial_value)


# Generated at 2022-06-25 23:34:30.066122
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1318.2409035706512).to_lazy().get() == 1318.2409035706512  # pragma: no cover

# Generated at 2022-06-25 23:34:38.373078
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box0 = Box(0)
    box1 = Box(1)
    box_minus1 = Box(-1)

    assert Lazy(lambda: 0) == box0.to_lazy()
    assert Lazy(lambda: 1) == box1.to_lazy()
    assert Lazy(lambda: -1) == box_minus1.to_lazy()



# Generated at 2022-06-25 23:34:48.957724
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from decimal import Decimal
    
    box__result = Box(2).to_lazy()
    assert isinstance(box__result, Lazy)
    assert box__result.value() == 2

    box__result = Box(Decimal('1.234567890123456789')).to_lazy()
    assert isinstance(box__result, Lazy)
    assert box__result.value() == Decimal('1.234567890123456789')

    box__result = Box('2').to_lazy()
    assert isinstance(box__result, Lazy)
    assert box__result.value() == '2'

    box__result = Box(2.0).to_lazy()
    assert isinstance(box__result, Lazy)
   

# Generated at 2022-06-25 23:34:53.673285
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == float_0



# Generated at 2022-06-25 23:34:58.336394
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 523.6617376
    box_0 = Box(float_0)
    float_1 = 0.9
    box_1 = box_0.to_lazy()
    float_2 = box_1.get_value()
    float_3 = float_2()
    float_4 = float_3 - float_0
    assert float_4 < float_1


# Generated at 2022-06-25 23:37:08.450276
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def test_case_0():
        float_0 = 1318.2409035706512
        box_0 = Box(float_0)
        tup_0 = (box_0, box_0)
        tup_1 = tup_0[1]
        lazy_0 = tup_1.to_lazy()
        assert(isinstance(lazy_0, Lazy))
        assert(lazy_0.fold() == box_0.value)
        assert(lazy_0.fold() == tup_0[0].value)
        assert(lazy_0.fold() != 4229.2872630630136)
        return True

    def test_case_1():
        str_0 = 'FooBar'

# Generated at 2022-06-25 23:37:11.105313
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    result_0 = box_0.to_lazy()
    assert isinstance(result_0, Lazy)
    assert result_0.__class__ == Lazy


# Generated at 2022-06-25 23:37:22.524783
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Either

    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    str_0 = 'String!'
    str_1 = 'S'
    float_0 = 0.0
    float_1 = 1.0
    float_2 = 2.0
    float_3 = 3.0
    float_4 = 4.0

    def lambda_0(value):
        if value == int_0:
            return Try(int_1, is_success=True)
        if value == int_2:
            return Try(int_3, is_success=True)

# Generated at 2022-06-25 23:37:25.547535
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(int())
    assert box_0.to_lazy().fold() == int()


# Generated at 2022-06-25 23:37:29.009755
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    float_0 = 1318.2409035706512
    box_0 = Box(float_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_lazy() == True
    assert lazy_0.is_folded() == False


# Generated at 2022-06-25 23:37:33.527246
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.validation import Validation

    def f(x):
        return x + 1

    box_0 = Box(1)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.bind(f).get() == 2
    assert lazy_0.map(f).get() == 2
    assert lazy_0.ap(Lazy(f)).get() == 2
    assert lazy_0.to_maybe().bind(f).get() == 2
    assert lazy_0.to_either().bind(f).get() == 2