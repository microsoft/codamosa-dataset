

# Generated at 2022-06-25 23:27:35.477394
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    box_1 = Box('H"h%{Ubj7o?8\t)q')
    bool_0 = box_0 == box_1
    assert bool_0 == True


# Generated at 2022-06-25 23:27:39.238406
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('a') is not Box('a'), 'Equality of different instances of Box'
    assert Box('a') == Box('a'), 'Comparing equal boxes which contains the same values'

    assert Box('a') != Box('b'), 'Comparing not equal boxes which contains the same values'



# Generated at 2022-06-25 23:27:46.990757
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = "R"
    box_0 = Box(str_0)
    str_1 = "RqL"
    box_1 = Box(str_1)
    str_2 = "R"
    box_2 = Box(str_2)
    box_3 = Box(str_0)
    assert box_0 == box_2
    assert not (box_0 == box_1)
    assert not (box_0 == box_3)
    assert box_0 == box_0
    assert box_1 == box_1
    assert box_2 == box_2
    assert box_3 == box_3




# Generated at 2022-06-25 23:27:50.930685
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_0_1 = Box(0)
    box_0_2 = Box(0)
    box_1 = Box(1)

    assert box_0_1 == box_0_2

    assert box_0_1 != box_1


# Generated at 2022-06-25 23:27:55.592411
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_1 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_1)

    # assert equal test
    box_1 = Box(str_1)
    assert box_0 == box_1

    # assert not equal test
    box_2 = Box(None)
    assert box_0 != box_2


# Generated at 2022-06-25 23:28:03.349605
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'E1[QYy"t:X!t%u;=Fk'
    float_0 = 3.7449735402026453
    float_1 = -9.939952590780288
    str_1 = 'xF|qm]G_e6U$R8Wrnf6'
    int_0 = 3
    int_1 = 9
    int_2 = -5
    str_2 = '<9r$-d#=;_pO4O&BZ`#'
    box_0 = Box(float_0)
    box_1 = Box(float_0)
    box_2 = Box(float_1)
    box_3 = Box(float_1)
    box_4 = Box(str_0)

# Generated at 2022-06-25 23:28:07.012190
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    assert box_0 == box_0
    assert not (box_0 == None)


# Generated at 2022-06-25 23:28:12.020566
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    isinstance(lazy_0, Lazy)
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:28:21.305015
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'l[\x1f`n\t^]WtD'
    list_0 = [9, 'T']

# Generated at 2022-06-25 23:28:24.376770
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    box_1 = Box(str_0)
    box_2 = Box('H"h%{Ubj7o?8\t)q')

    assert box_0 == box_1
    assert box_0 == box_2



# Generated at 2022-06-25 23:28:30.771886
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:28:37.256843
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Return (Wrapper with value) by calling method to_lazy of Box
    """
    str_0 = '!U}7;uC?6y(g=J4"4cB]od#\t'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    lazy_1 = lazy_0.map(lambda x: x.upper())
    assert str_0.upper() == lazy_1.get_value()


# Generated at 2022-06-25 23:28:42.159226
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)
    assert Box('Hello').to_lazy() == Lazy(lambda: 'Hello')
    assert Box(('Hello', 'world')).to_lazy() == Lazy(lambda: ('Hello', 'world'))
    assert Box([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])


# Generated at 2022-06-25 23:28:46.655631
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    str_1 = lazy_0.eval()
    assert str_1 == str_0

# Generated at 2022-06-25 23:28:55.050232
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Assert that lazy monad is not folded and contains function returning previous value from box.
    """
    from pymonet.lazy import Lazy

    def func_0() -> int:  # pragma: no cover
        return 5

    box_0 = Box(func_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert not lazy_0.folded

    assert lazy_0.value() == func_0()
    assert lazy_0.value() == 5


# Generated at 2022-06-25 23:28:57.767453
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box_0 = Lazy(lambda: 'a')
    lazy_1 = box_0.to_lazy()
    str_2 = 'a'
    assert str_2 == lazy_1.value()



# Generated at 2022-06-25 23:29:01.015834
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    assert(box_0.to_lazy().value() == str_0)



# Generated at 2022-06-25 23:29:02.378580
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(None).to_lazy().is_folded() == False
    assert Box(3.0).to_lazy().fold(lambda: Box(4.0)) == Box(4.0).to_lazy()


# Generated at 2022-06-25 23:29:07.219006
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def _lazy_val():
        return 'Box "lazy"'

    str_0 = 'Box "lazy"'

    box_0 = Box(str_0)
    box_1 = box_0.to_lazy()  # Box[Lazy]

    assert isinstance(box_1, Box)
    assert box_1.value == _lazy_val()  # Lazy


# Generated at 2022-06-25 23:29:15.548523
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(1)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_folded() == False
    assert lazy_0.value() == 1
    assert isinstance(lazy_0, Lazy) == True



# Generated at 2022-06-25 23:29:23.539162
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.validation import Validation
    failure_message = 'Provided box contains not folded lazy monad'
    lazy = Box(1).to_lazy()
    assert_true(lazy.is_folded == False, failure_message) == None
    assert_true(lazy.value() == 1, failure_message) == None


# Generated at 2022-06-25 23:29:31.429637
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '

    # str -> str
    def get_name(a):
        return a + ' John'
    value = 'James'
    result = Box(value).to_lazy().map(get_name)
    success_assert(result.is_folded, str_0)
    success_assert(result.value() == 'James John', str_0)


# Generated at 2022-06-25 23:29:40.760117
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '

    def f_0():
        str_0 = '\n        Dummy function returning value of box.\n        '

        def f_1():
            str_0 = '\n            Create box with string value.\n            '
            string: str = 'str'
            box: Box[str] = Box(string)
            str_0 = '\n            Return from box.\n            '
            string = box.value
            return string
        (string,) = f_1()
        str_0 = '\n        Return from box.\n        '
        string = f_1()
        return string
    (string,) = f_0()

# Generated at 2022-06-25 23:29:49.405229
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    str_2 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    str_4 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    str_6 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    str_8 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    str_10 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    # Test with integer
   

# Generated at 2022-06-25 23:29:52.564162
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    str_0 = '\
    Assert that lazy monad is not folded and contains function returning previous value from box.\
    '
    value = 42
    box_0 = Box(value)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_folded is False
    assert lazy_0.perform() == value


# Generated at 2022-06-25 23:29:54.233903
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = test_case_0.__doc__
    assert str_0 is not None


# Generated at 2022-06-25 23:30:03.853711
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    f_0 = lambda : (1)
    f_1 = lambda : (2)
    f_2 = lambda : (3)
    box_0 = Box(f_0)
    box_1 = Box(f_1)
    box_2 = Box(f_2)

    # Act
    lazy_0 = box_0.to_lazy()
    lazy_1 = box_1.to_lazy()
    lazy_2 = box_2.to_lazy()

    # Assert
    assert not lazy_0.is_folded
    assert lazy_0.value() == f_0()
    assert not lazy_1.is_folded
   

# Generated at 2022-06-25 23:30:12.764002
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'assertion'
    str_1 = 'Assert that lazy monad is not folded and contains function returning previous value from box.'
    str_2 = 'lazy'
    str_3 = 'assertion'
    str_4 = 'result of applying function from container to the previous value from container'
    str_5 = 'box'
    str_6 = 'assertion'
    str_7 = 'result of applying function from container to the previous value from container'
    str_8 = 'box'
    number_0 = 1
    number_1 = 2
    number_2 = 3
    number_3 = 1
    number_4 = -1
    number_5 = 2
    number_6 = 2
    number_7 = 2
    number_8 = 6
    number_9 = 6

# Generated at 2022-06-25 23:30:16.452494
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '

    def fnc_0():
        nonlocal str_0
        str_0 = 'pass'

    fnc_1 = Box('test').to_lazy().get_value()
    str_1 = 'test'
    assert (fnc_1() == str_1)
    str_2 = str_0
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    assert (str_2 == str_0)


# Generated at 2022-06-25 23:30:24.609233
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '

    obj_0 = Box(1)
    _0_0 = obj_0.to_lazy()
    _1_0 = _0_0.unfold()

    expect(_1_0).to_be_a(bool)
    expect(_1_0).to_be_false()

    _2_0 = _0_0.eval_()

    expect(_2_0).to_be_equal_to(1)
    expect(obj_0.to_lazy().unfold()).to_be_false()


# Generated at 2022-06-25 23:30:29.065062
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    int_0 = 10
    int_1 = Box(int_0).to_lazy().get()
    int_2 = int_0
    bool_0 = int_1 == int_2
    str_1 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    assert bool_0, str_1


# Generated at 2022-06-25 23:30:33.790033
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    value = Box(1).to_lazy()
    assert not value.is_folded()
    assert value.value() == 1
    assert value.fold(lambda x: 'empty') == 1
    assert value.fold(lambda x: 'empty', lambda x: x) == 1


# Generated at 2022-06-25 23:30:35.787562
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()
    a = Box(1)
    res = a.to_lazy()
    assert res == Lazy(lambda: 1)


# Generated at 2022-06-25 23:30:46.504380
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    try:
        str_0
    except NameError:
        str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '

    def function_1(param_0, param_1):
        value_0 = param_1.fold()
        value_1 = param_0.value
        value_2 = value_0 == value_1
        return value_2

    assert_1 = True
    value_0 = Box(2)
    value_1 = Lazy(lambda: 2)
    value_2 = function_1(value_0, value_1)
    assert_2 = value_2 == assert_1
    assert assert_2
    value_3 = str_0
    value_4 = print(value_3)


# Generated at 2022-06-25 23:30:51.959491
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_var_0 = 'Assert that lazy monad is not folded and contains function returning previous value from box.'
    Box_var_0 = Box('string')
    Lazy_var_0 = Box_var_0.to_lazy()
    func_var_0 = Lazy_var_0.fold
    str_var_1 = Lazy_var_0.fold()
    assert func_var_0 == 'string'


# Generated at 2022-06-25 23:30:59.501474
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    str_1 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    lazy_0 = Box(100.0).to_lazy()
    str_2 = ''
    str_3 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    lazy_1 = Box(lambda a: a).to_lazy()
    str_4 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    lazy_2 = Box(lambda : 100.0).to_lazy()
    str_5 = ''
    str_

# Generated at 2022-06-25 23:31:05.692270
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    box = Box(1)
    lazy = box.to_lazy()
    assert lazy.value() == 1


# Generated at 2022-06-25 23:31:16.483283
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    def assert_eq_0(b, m):
        return assertEqual(b, m)

    def assert_eq_1(b, m):
        return assertEqual(b, m)

    def assert_eq_2(b, m):
        return assertEqual(b, m)

    def assert_eq_3(b, m):
        return assertEqual(b, m)

    def assert_eq_4(b, m):
        return assertEqual(b, m)

    def assert_eq_5(b, m):
        return assertEqual(b, m)

    def assert_eq_6(b, m):
        return assertEqual(b, m)

    def assert_eq_7(b, m):
        return assertEqual(b, m)


# Generated at 2022-06-25 23:31:22.032560
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '
    box = Box(42)
    lazy = box.to_lazy()
    str_1 = str(lazy)
    str_2 = 'Lazy[Function(() -> 42)]'
    bool_0 = (str_1 == str_2)
    assert bool_0


# Generated at 2022-06-25 23:31:28.614465
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Arrange
    str_0 = '\n    Assert that lazy monad is not folded and contains function returning previous value from box.\n    '

    box_0 = Box(4)

    # Act
    lazy_0 = box_0.to_lazy()

    # Assert
    assert lazy_0.is_folded == False
    assert lazy_0.callable_0() == 4



# Generated at 2022-06-25 23:31:42.226069
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.unit import Unit
    from pymonet.lazy import Lazy
    from pymonet.tuple import Tuple2

    assert Lazy.of(
        Box(Unit()).to_lazy()
    ) == Lazy.of(Lazy(lambda: Box(Unit())))

    assert Lazy.of(
        Box(Unit()).to_lazy().map(lambda x: x.value)
    ) == Lazy.of(Lazy(lambda: Box(Unit()).value))

    assert Lazy.of(
        Box('Test string').to_lazy().map(lambda x: x.value.upper())
    ) == Lazy.of(Lazy(lambda: Box('Test string').value.upper()))


# Generated at 2022-06-25 23:31:47.902317
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = '0"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    box_lazy = Lazy(lambda: str_0)
    assert box_0.to_lazy() == box_lazy


# Generated at 2022-06-25 23:31:51.840097
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value == str_0



# Generated at 2022-06-25 23:32:02.191702
# Unit test for method to_lazy of class Box

# Generated at 2022-06-25 23:32:08.412871
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def f_0():
        return 7
    box_0 = Box(f_0)
    try:
        la = box_0.to_lazy()
        assert la.value() == 7
    except Exception as e:
        print('test_Box_to_lazy failed')
        print('type(e):\t{}'.format(type(e)))
        print('e.msg:\n{}'.format(e.msg))
        print('e.expr:\n{}'.format(e.expr))
        print('e.extxt:\t{}'.format(e.extxt))
        raise e

# Generated at 2022-06-25 23:32:09.786276
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1


# Generated at 2022-06-25 23:32:18.300273
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.monad_list import List

    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold() == str_0

    try_0 = box_0.to_try()
    assert isinstance(try_0, Try)
    assert try_0.is_success
    assert try_0.error is None
    assert try_0.value == str_0

    list_0 = box_0.to_list()

# Generated at 2022-06-25 23:32:22.819013
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = Lazy(lambda: str_0)

    assert lazy_0.value == box_0.to_lazy().value()



# Generated at 2022-06-25 23:32:24.331445
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('a').to_lazy() == Lazy(lambda: 'a')


# Generated at 2022-06-25 23:32:26.102450
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def f():
        return 1
    box = Box(f)
    assert box.to_lazy().force() == 1



# Generated at 2022-06-25 23:32:35.874443
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, fold
    
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    assert box_0.to_lazy() == Lazy(lambda: box_0.value)
    assert box_0.to_lazy() == Lazy(lambda: str_0)
    assert fold(box_0.to_lazy()) == str_0


# Generated at 2022-06-25 23:32:37.010742
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('a').to_lazy().force() == 'a'

# Generated at 2022-06-25 23:32:40.616011
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # noqa: N802
    str_1 = '_1w<AZ/S/0M*sfD'
    box_1 = Box(str_1)
    test_0_result = box_1.to_lazy().map(len).fold()
    assert test_0_result == 18


# Generated at 2022-06-25 23:32:44.234967
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lst_0 = ['R', '&', '5', '6', 'U<Kdw6', 'U<Kdw6']
    box_0 = Box(lst_0)
    assert box_0.to_lazy().get() == lst_0



# Generated at 2022-06-25 23:32:50.072828
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value == str_0
    lazy_0 = lazy_0.map(lambda value: value + '"')
    assert lazy_0.value == str_0 + '"'
    assert lazy_0.value == str_0 + '"'


# Generated at 2022-06-25 23:32:53.586102
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.builder import build_lazy
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    result = box_0.to_lazy()
    assert str_0 == result.value()


# Generated at 2022-06-25 23:32:56.892255
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'r_!M_H|c'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:33:04.119257
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    str_1 = 'H"h%{Ubj7o?8\t)q'

# Generated at 2022-06-25 23:33:08.691161
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_computed is False
    assert lazy_0.value() == str_0



# Generated at 2022-06-25 23:33:15.310419
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = '7V\x1a?W8VY}n'
    str_1 = '5nJ/L[?mC+\x7f!x'
    box_0 = Box(str_0)
    assert box_0.to_lazy().value() == str_0
    assert box_0.value == str_0
    box_1 = Box(str_1)
    assert box_1.to_lazy().value() == str_1
    assert box_1.value == str_1


# Generated at 2022-06-25 23:33:30.890595
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    str_1 = 'H"h%{Ubj7o?8\t)q'
    box_1 = Box(str_1)
    int_0 = 0
    box_2 = Box(int_0)
    box_3 = box_0.to_lazy()
    assert box_3.value() == str_0
    assert box_1 == box_0
    assert box_2.value != box_2



# Generated at 2022-06-25 23:33:33.125378
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    expected_result = "abcd"
    box_0 = Box("abcd")
    result = box_0.to_lazy().get()
    assert result == expected_result


# Generated at 2022-06-25 23:33:38.370436
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    def dummy_function(value):
        """
        Dummy function for testing.

        :param value: String to print
        :type value: String
        :returns: Printed string
        :rtype: String
        """
        return value

    # Test Box class
    box_0 = Box(dummy_function)
    box_0_test = box_0.to_lazy()
    assert box_0_test.bind(lambda x: x('Test')) == 'Test', "AssertionError"
    assert box_0_test.bind(lambda x: x('Test1')) == 'Test1', "AssertionError"
    box_1 = Box(dummy_function)
    box_1_test = box_1.to_lazy()

# Generated at 2022-06-25 23:33:44.530197
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Declarations:
    str_0 = 'H"h%{Ubj7o?8\t)q'

    # Box[a]:
    box_0 = Box(str_0)

    # Lazy[A]:
    lazy_0 = box_0.to_lazy()

    # Lazy[A]:
    lazy_1 = lazy_0.fmap(lambda x: x + ' APOLLO')

    # A thunk to be evaluated:
    thunk_0 = lazy_1.thunk

    # A:
    value_0 = thunk_0()

    assert value_0 == 'H"h%{Ubj7o?8\t)q APOLLO'

# Generated at 2022-06-25 23:33:47.394193
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 is not None
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:33:51.264907
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.is_lazy()
    assert lazy_0.is_folded() is False
    assert lazy_0.get_value() == str_0



# Generated at 2022-06-25 23:33:52.302012
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('string').to_lazy().get() == 'string'

# Generated at 2022-06-25 23:33:55.761444
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)

    # Act
    lazy_0 = box_0.to_lazy()

    # Assert
    assert lazy_0 == Lazy(lambda: str_0)

# Generated at 2022-06-25 23:34:05.381669
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    str_1 = box_0.value
    str_2 = str_1.replace("%", "")
    str_3 = str_2.strip("\"")
    str_4 = str_3.capitalize()
    str_5 = str_4.replace("\"", "")
    int_0 = len(str_5)
    str_6 = '${}${}'.format(str_5, int_0)
    box_1 = box_0.to_lazy()
    str_7 = box_1.value()
    str_8 = str_7.replace("%", "")
    str_9 = str_8.strip("\"")
    str_

# Generated at 2022-06-25 23:34:15.223865
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def f_to_lazy_0():
        str_0 = 'H"h%{Ubj7o?8\t)q'
        box_0 = Box(str_0)
        lazy_0 = box_0.to_lazy()
        str_1 = str(lazy_0.get())

        # Check that the 2 string are equal
        assert str_1 == str_0

    def f_to_lazy_1():
        str_0 = '7$z\x03\x7f'
        box_0 = Box(str_0)
        lazy_0 = box_0.to_lazy()
        str_1 = str(lazy_0.get())

        # Check that the 2 string are equal
        assert str_1 == str_0


# Generated at 2022-06-25 23:34:37.795036
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'f_8eQW~0,$GIG:Zp5'
    box_0 = Box(str_0)

    lazy_0 = box_0.to_lazy()

    assert lazy_0.value() == str_0

    float_0 = 36.46503952121136
    box_1 = Box(float_0)

    lazy_1 = box_1.to_lazy()

    assert lazy_1.value() == float_0

    list_0 = ['x', 'H', 'y', 'Y', 'g', 'l', 'F']
    box_2 = Box(list_0)

    lazy_2 = box_2.to_lazy()

    assert lazy_2.value() == list_0



# Generated at 2022-06-25 23:34:41.940206
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as lazy

    box_0 = Box(0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == lazy.Lazy(0)
    box_1 = Box(1)
    lazy_1 = box_1.to_lazy()
    assert lazy_1 == lazy.Lazy(1)



# Generated at 2022-06-25 23:34:44.817002
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert(str_0 == lazy_0.force())


# Generated at 2022-06-25 23:34:49.857755
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(19)
    box_1 = box_0.to_lazy()
    assert box_1.value() == 19
    assert isinstance(box_1.value(), int)


# Generated at 2022-06-25 23:34:56.795352
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_lazy import MonadLazy

    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)

    # check is Lazy object
    assert isinstance(box_0.to_lazy(), Lazy)
    # check is MonadLazy object
    assert isinstance(box_0.to_lazy(), MonadLazy)



# Generated at 2022-06-25 23:35:01.238016
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_Box_to_lazy_0():
        str_0 = 'Rf)Sy(iN'
        box_0 = Box(str_0)
        lazy_0 = box_0.to_lazy()
        bool_0 = lazy_0.is_folded()
        assert bool_0 == False

    test_Box_to_lazy_0()


# Generated at 2022-06-25 23:35:05.086149
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    assert lazy_0 == Lazy(str_0)


# Generated at 2022-06-25 23:35:11.355278
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    r"""
    test_Box_to_lazy
    ****************
    Test for to_lazy method for class Box.
    """
    from pymonet.monad import Box
    from pymonet.lazy import Lazy
    from typing import Callable
    import unittest

    class CaseBase:
        def __init__(self, expected, input):
            self.expected = expected
            self.input = input

    class Test_Case_0(CaseBase):
        def __init__(self):
            str_0 = 'H"h%{Ubj7o?8\t)q'
            box_0 = Box(str_0)
            res = box_0.to_lazy()
            CaseBase.__init__(self, res, "to_lazy")


# Generated at 2022-06-25 23:35:14.398303
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Test 0
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert str_0 == lazy_0._value()

# Generated at 2022-06-25 23:35:18.176183
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(10)
    try:
        lazy_0 = box_0.to_lazy()
        assert lazy_0.foldl(lambda _: 0) == 10
    except AssertionError or TypeError:
        raise AssertionError


# Generated at 2022-06-25 23:36:06.136549
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test of instance Box
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = Lazy(lambda: str_0)
    assert box_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:36:10.531178
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Arrange
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)

    # Act
    from pymonet.lazy import Lazy

    lazy_0 = box_0.to_lazy()

    # Assert
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.fold() == str_0


# Generated at 2022-06-25 23:36:13.291117
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    assert str_0 == lazy_0.value()

# Generated at 2022-06-25 23:36:18.268402
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Init test value
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    # Init expected value
    str_1 = 'H"h%{Ubj7o?8\t)q'
    # Call function
    lazy = box_0.to_lazy()
    # Check result
    assert str_1 == lazy.value(), "Returned value is not as expected"
    


# Generated at 2022-06-25 23:36:21.660438
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as lazy
    x = Box(42)
    y = x.to_lazy()
    assert y == lazy.Lazy(lambda: 42)


# Generated at 2022-06-25 23:36:22.678922
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('wow').to_lazy().force() == 'wow'


# Generated at 2022-06-25 23:36:24.463053
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert_equals(Box(20).to_lazy().bind(lambda x: x + 3), 23)


# Generated at 2022-06-25 23:36:27.684710
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_0 = Box(str_0)
    lazy_0 = box_0.to_lazy()
    bool_0 = lazy_0.is_resolved()
    assert bool_0 == False

# Generated at 2022-06-25 23:36:36.139993
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    list_0 = [1, '2', 3.14]
    box_0 = Box(list_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: list_0)
    num_0 = 2.718281828459045
    box_1 = Box(num_0)
    lazy_1 = box_1.to_lazy()
    assert lazy_1 == Lazy(lambda: num_0)

# Generated at 2022-06-25 23:36:43.757134
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.int import Int
    from pymonet.box import Box

    # Test for value 5
    box_0 = Box(5)
    lazy_0 = box_0.to_lazy()
    int_0 = lazy_0.fold(lambda: Int)
    assert str(int_0) == 'Int[value=5]'

    # Test for value "H"h%{Ubj7o?8\t)q"
    str_0 = 'H"h%{Ubj7o?8\t)q'
    box_1 = Box(str_0)
    lazy_1 = box_1.to_lazy()
    str_1 = lazy_1.fold(lambda: str)