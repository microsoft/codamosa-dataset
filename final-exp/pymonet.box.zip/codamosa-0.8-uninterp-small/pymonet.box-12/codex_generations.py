

# Generated at 2022-06-25 23:27:30.225694
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    len_str_5 = 5
    box_str_5 = Box(len_str_5)
    lazy_str_5 = Lazy(lambda: 5)
    assert box_str_5.to_lazy() == lazy_str_5


# Generated at 2022-06-25 23:27:39.340329
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    # Assert Box eq Box
    assert Box(None) == Box(None)
    assert Box(True) == Box(True)
    assert Box(False) == Box(False)
    assert Box(0) == Box(0)
    assert Box(1) == Box(1)
    assert Box(0.0) == Box(0.0)
    assert Box(1.0) == Box(1.0)
    assert Box(1.1) == Box(1.1)
    assert Box('foo') == Box('foo')

    # Assert Box not eq Box
    assert Box(None) != Box(True)
    assert Box(None) != Box(False)
    assert Box(None) != Box(0)
    assert Box(None) != Box(1)
    assert Box(None) != Box(0.0)


# Generated at 2022-06-25 23:27:48.826226
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    box_1 = Box(bytes_0)
    bytes_1 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_2 = Box(bytes_1)
    assert box_0 == box_1
    assert box_0 == box_0
    assert not (box_0 == box_2)
    int_0 = -1
    box_3 = Box(int_0)
    byte_0 = 0
    box_4 = Box(byte_0)

# Generated at 2022-06-25 23:27:56.009922
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    lazy_0 = box_0.to_lazy()

    assert repr(lazy_0) == 'Lazy(<function Box.__bind__.<locals>.<lambda> at 0x7f167d2f2ea0>)'
    assert isinstance(lazy_0, Box) is False


# Generated at 2022-06-25 23:27:58.645262
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_0 = Box(1)
    box_1 = Lazy(lambda: 1)

    assert box_0.to_lazy() == box_1


# Generated at 2022-06-25 23:28:07.881642
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    assert box_0.to_lazy() == Lazy(lambda: b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea')
    assert box_0.to_lazy() is not Lazy(bytes_0)


# Generated at 2022-06-25 23:28:15.111667
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    bytes_1 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    box_1 = Box(bytes_1)

    assert box_0 == box_1



# Generated at 2022-06-25 23:28:23.326903
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_case_0():
        bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
        box_0 = Box(bytes_0)

        lazy_0 = box_0.to_lazy()
        bytes_0_as_lazy = lazy_0.value()
        if not bytes_0 == bytes_0_as_lazy:
            raise Exception('Test failed with bytes_0 = {}'.format(bytes_0))

    def test_case_1():
        bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'

# Generated at 2022-06-25 23:28:34.184147
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monoid import Monoid, Identity
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative
    from pymonet.liftable import Liftable
    from pymonet.monad_plus import MonadPlus
    from pymonet.alt_with import AltWith

    print(isinstance(Box, Monoid))
    print(isinstance(Box, Functor))
    print(isinstance(Box, Monad))
    print(isinstance(Box, Applicative))
    print(isinstance(Box, Liftable))
    print(isinstance(Box, MonadPlus))
    print(isinstance(Box, AltWith))

    box_0 = Box(0)
    assert box_0 == Box(0)

    box

# Generated at 2022-06-25 23:28:41.359201
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    bytes_1 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    box_1 = Box(bytes_0)
    box_2 = Box(bytes_1)

    assert box_0 == box_1
    assert not box_0 == box_2


# Generated at 2022-06-25 23:28:49.875747
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(
b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    ).to_lazy()
    assert result.is_lazy
    assert result.value() == b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    assert result.is_forced is False



# Generated at 2022-06-25 23:28:52.711440
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(0).to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-25 23:28:59.556236
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Either
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation

    # check that function is actually returning new monad
    assert isinstance(Box(1).to_maybe(), Maybe)
    assert isinstance(Box(1).to_either(), Either)
    assert isinstance(Box(1).to_lazy(), Lazy)
    assert isinstance(Box(1).to_try(), Try)
    assert isinstance(Box(1).to_validation(), Validation)

    # check that function is not changing value inside Box
    assert Box(1).to_maybe().get() == 1
    assert Box(1).to

# Generated at 2022-06-25 23:29:07.007916
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    with freeze_time("2012-01-14"):
        # Test for value <bytes>
        assert Box(b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea') != Box(b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea')

        # Test for value <int>
        assert Box(42) == Box(42)
        assert Box(42) == Box(42)

        # Test for value <float>
        assert Box(4.2) == Box(4.2)


# Generated at 2022-06-25 23:29:14.462572
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    skyr_0 = Box(bytes_0).to_lazy()
    skyr_1 = skyr_0.get_value()
    assert skyr_1 == bytes_0


# Generated at 2022-06-25 23:29:18.054812
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    value_1 = 1
    box_1 = Box(value_1)
    value_2 = 1
    box_2 = Box(value_2)
    bool_0 = box_1.__eq__(box_2)
    assert bool_0 == True


# Generated at 2022-06-25 23:29:20.249430
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    a = 5

    assert(Box(a).to_lazy() == Lazy(lambda: a))


# Generated at 2022-06-25 23:29:32.774190
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    box_1 = Box(bytes_0)
    box_2 = Box(bytes_0)
    box_3 = Box(bytes_0)
    box_4 = Box(bytes_0)
    box_5 = Box(bytes_0)
    box_6 = Box(bytes_0)
    box_7 = Box(bytes_0)
    box_8 = Box(bytes_0)
    box_9 = Box(bytes_0)
    box_10 = Box(bytes_0)
    box_11 = Box(bytes_0)

# Generated at 2022-06-25 23:29:37.021404
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_bytes_0 = Box(bytes_0)
    box_bytes_1 = Box(bytes_0)

    assert box_bytes_0 == box_bytes_1


# Generated at 2022-06-25 23:29:40.805629
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = False
    box_0 = Box(True)
    lazy_0 = box_0.to_lazy()
    if result and lazy_0.fold():
        print("Test case 0: Passed")
    else:
        print("Test case 0: Failed")


# Generated at 2022-06-25 23:29:47.994144
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().value == 5
    assert Box('Hello').to_lazy().value == 'Hello'
    assert Box({'key': 'value'}).to_lazy().value == {'key': 'value'}
    assert Box(test_case_0).to_lazy().value == test_case_0
    assert Box({1, 2, 3}).to_lazy().value == {1, 2, 3}
    assert Box(123).to_lazy().value == 123

# Generated at 2022-06-25 23:29:50.252948
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def get_bytes_1() -> bytes:
        return b'f\x01\x0f'
    bytes_1 = Box(get_bytes_1)
    bytes_2 = bytes_1.to_lazy()
    assert bytes_2.unfold() == get_bytes_1()

# Generated at 2022-06-25 23:29:52.315286
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(test_case_0)
    lazy = box.to_lazy()
    assert lazy.value() == box.value

# Generated at 2022-06-25 23:30:02.160261
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    import math
    import random
    import struct

    def random_bytes(size) -> bytes:
        return bytearray(os.urandom(size))

    def random_float(precision) -> float:
        format = '{p}f'.format(p=precision if precision > 0 else 1)
        value = struct.unpack(format, random_bytes(struct.calcsize(format)))[0]
        number = random.uniform(0, 1) if precision >= 0 else random.randint(0, 1)
        if number < 0.5:
            value = -value
        return value

    assert Box(0).to_lazy().fold() == 0
    assert Box([0] * 10).to_lazy().fold() == [0] * 10

# Generated at 2022-06-25 23:30:11.222138
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box("").to_lazy().value == "", "Assertion error"
    assert Box("").to_lazy().value is Box("").value, "Assertion error"
    assert Box("").to_lazy().value() == "", "Assertion error"
    assert Box("").to_lazy().value() is Box("").value, "Assertion error"
    assert Box("").to_lazy().value is Box("").value, "Assertion error"
    assert Box("123").to_lazy().value is Box("123").value, "Assertion error"
    assert Box("123").to_lazy().value == "123", "Assertion error"
    assert Box("123").to_lazy().value() is Box("123").value, "Assertion error"
    assert Box("123").to

# Generated at 2022-06-25 23:30:15.187100
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 1
    ()

    # Test case 2
    bytes_0 = b'\xd1\xb1\xa8H\x9f\x0e(g\x8c\xcd\x12\xb1\x1b'
    result_1 = Box(bytes_0).to_lazy()
    assert isinstance(result_1, pymonet.lazy.Lazy)
    assert result_1.is_folded() == False
    assert result_1 == result_1
    assert result_1.value() == bytes_0


# Generated at 2022-06-25 23:30:16.011189
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_case_0()


# Generated at 2022-06-25 23:30:25.784311
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    value = 123
    box = Box(value)
    lazy_expected = Box(value).to_lazy()

    # When
    lazy_result = box.to_lazy()

    # Then
    assert lazy_result == lazy_expected

    # Given
    value = 'aaa'
    box = Box(value)
    lazy_expected = Box(value).to_lazy()

    # When
    lazy_result = box.to_lazy()

    # Then
    assert lazy_result == lazy_expected

    # Given
    value = 123, 456
    box = Box(value)
    lazy_expected = Box(value).to_lazy()

    # When
    lazy_result = box.to_lazy()

    # Then
    assert lazy_result == lazy_expected

    # Given
   

# Generated at 2022-06-25 23:30:32.500376
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_box_1 = Box(12).to_lazy()
    assert isinstance(lazy_box_1, Lazy)
    assert lazy_box_1.value() == 12

    lazy_box_2 = Box(bytes([1, 2, 3])).to_lazy()
    assert isinstance(lazy_box_2, Lazy)
    assert lazy_box_2.value() == b'\x01\x02\x03'


# Generated at 2022-06-25 23:30:36.856803
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # set debug mode
    """
    Loader is used to load a module. It can be either a module, a class, a method or a function.
    """
    loader = unittest.TestLoader()
    test_suite = loader.loadTestsFromModule(sys.modules[__name__])

    # initialize a runner, pass it your suite and run it
    test_runner = unittest.TextTestRunner(verbosity=2)
    test_runner.run(test_suite)



# Generated at 2022-06-25 23:30:41.385670
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-25 23:30:44.114533
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_0 = Box(bytes_0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0.value == bytes_0


# Generated at 2022-06-25 23:30:49.722351
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box = Box(bytes_0)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: box.value)


# Generated at 2022-06-25 23:30:56.566756
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for Box::to_lazy method

    :return: nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    lazy_0 = Lazy(lambda: bytes_0)
    assert box_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:31:03.518336
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.abc import Monad
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    a = Box(1)
    b = a.to_lazy()
    assert (isinstance(b, Monad) and isinstance(b, Lazy))
    assert (b.monoid_unit() == 1)
    assert (b.then(Box(2).to_maybe()).monoid_unit() == 2)



# Generated at 2022-06-25 23:31:07.831430
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 'my-value'
    box = Box(value)

    assert isinstance(box.to_lazy(), Lazy)
    assert box.to_lazy().eval() == value


# Generated at 2022-06-25 23:31:17.493682
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Case #0
    bytes_0 = b'\x7f)U6\xc5\xdcB\x11\x1a\xbe\x06\x80\x8e\xb0'
    bytes_1 = b'\x7f)U6\xc5\xdcB\x11\x1a\xbe\x06\x80\x8e\xb0'
    # bytes_2 = b'\x7f\x81\xff\xdf\xff\xdb\xff\xff\xff\xdf\xff\xdb\xff\xff\xff\xdf\xff\xdb'
    # bytes_3 = b'\x7f\x81\xff\xdf\xff\xdb\xff\xff\xff\xdb\xff\xdf\xff\xdb\xff

# Generated at 2022-06-25 23:31:28.773045
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    test_case_0()

    assert Box(1).to_lazy() == Lazy(lambda: 1)

    assert Try(1, is_success=True).to_lazy() == Lazy(lambda: 1)
    assert Try(1, is_success=False).to_lazy() == Lazy(None)

    test_case_1()

    assert Box(1).to_lazy() == Lazy(lambda: 1)

    assert Try(1, is_success=True).to_lazy() == Lazy(lambda: 1)
    assert Try(1, is_success=False).to_lazy() == Lazy(None)

    test_case_2()

    assert Box(1).to_lazy

# Generated at 2022-06-25 23:31:34.492837
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    byte_type = type(bytes_0)
    lazy_fn = lambda: bytes_0
    lazy = Box(bytes_0).to_lazy()
    assert lazy.get() == bytes_0
    assert lazy.get().__class__ == byte_type
    assert lazy.get().__class__ == bytes_0.__class__
    assert lazy.get_fn() == lazy_fn


# Generated at 2022-06-25 23:31:45.123105
# Unit test for method to_lazy of class Box

# Generated at 2022-06-25 23:31:52.800386
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    s = 'value'
    lazy = Box(s).to_lazy()
    assert lazy.value() == s
    assert lazy.is_lazy == True


# Generated at 2022-06-25 23:32:02.981135
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea').to_lazy()
    assert Box(b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea').to_lazy().value == b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'

# Generated at 2022-06-25 23:32:04.837053
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # call method to_lazy with parameter [12] and value 12
    assert Box(12).to_lazy().value() == 12



# Generated at 2022-06-25 23:32:09.779744
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    b = Box(b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea')
    bytes_0 = b''
    c = b.to_lazy()
    assert b.to_lazy().get() == b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'


# Generated at 2022-06-25 23:32:16.409670
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test case 0
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box = Box(bytes_0)
    expected_value = Box(bytes_0)
    # Call to_lazy method of class Box
    lazy = box.to_lazy()
    # Call force method of class Lazy
    value = lazy.force()
    # Assert expected_value is value
    if value != expected_value:
        raise AssertionError()


# Generated at 2022-06-25 23:32:25.365282
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def bytes_str_lazy_equal(lazy_bytes, lazy_str):
        return lazy_bytes.to_evaluated() == lazy_str.to_evaluated()

    from hashlib import sha1

    sha1_0 = sha1()
    sha1_0.update(b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea')

    def str_0(bytes_0: bytes) -> str:
        return 'sha1 hmac: {}'.format(sha1_0.hexdigest())


# Generated at 2022-06-25 23:32:31.688614
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    value_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'

    # create box and transform it into Lazy
    box = Box(value_0)
    lazy = box.to_lazy()

    # check if lazy is instance of Lazy and if Lazy contains correct function
    assert type(lazy) is Lazy
    assert lazy.value() is value_0


# Generated at 2022-06-25 23:32:33.092940
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value_0 = Box(1)
    assert value_0.to_lazy().force() == 1

# Generated at 2022-06-25 23:32:36.899423
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    x = Box(1)
    y = x.to_lazy()

    # checks if instance of Box is an instance of Lazy
    assert isinstance(y, Lazy)
    # checks if  folded y is equal to x value
    assert y.value() == x.value


# Generated at 2022-06-25 23:32:40.183806
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(bytes_0).to_lazy() == Lazy(lambda: b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea')


# Generated at 2022-06-25 23:32:55.307964
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    lazy = box_0.to_lazy()
    assert lazy.value == bytes_0

# Generated at 2022-06-25 23:32:58.562364
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Create Box with value 1
    box = Box(1)
    # Transform Box into Lazy
    lazy = box.to_lazy()
    # Get result of applying Lazy value function
    result = lazy.value()

    assert result == 1, "Expected 1"


# Generated at 2022-06-25 23:32:59.780640
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box("Joe").to_lazy() == Lazy(lambda: "Joe")


# Generated at 2022-06-25 23:33:05.094605
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    #arrange
    expected = Lazy.of(b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea')
    actual = Box(b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea').to_lazy()

    #act

    #assert
    assert expected == actual

# Generated at 2022-06-25 23:33:06.563306
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy() == Lazy(lambda: 42)



# Generated at 2022-06-25 23:33:15.723429
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Right, Left

    assert Box(1).to_lazy() == lazy.Lazy(lambda: 1)

    assert Box(Maybe.just(1)).to_lazy() == lazy.Lazy(lambda: Maybe.just(1))

    assert Box(Maybe.fail()).to_lazy() == lazy.Lazy(lambda: Maybe.fail())

    assert Box(Try.success(1)).to_lazy() == lazy.Lazy(lambda: Try.success(1))

    assert Box(Try.fail(1)).to_lazy() == lazy.Lazy(lambda: Try.fail(1))

# Generated at 2022-06-25 23:33:23.891671
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_state import StateT
    from pymonet.monad_writer import WriterT
    from pymonet.monad_writer import Writer
    from pymonet.monad_state import State
    from pymonet.monad_reader import ReaderT
    from pymonet.monad_reader import Reader
    from pymonet.monad_list import ListT
    from pymonet.monad_list import List
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_maybe import Just
    from pymonet.monad_maybe import Nothing
    from pymonet.monad_either import Right
    from pymonet.monad_either import Left
    from pymonet.monad_either import Either


# Generated at 2022-06-25 23:33:31.780766
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # TestCase 0
    value_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(value_0)
    # TestCase 1
    value_1 = True
    box_1 = Box(value_1)
    # TestCase 2
    value_2 = True
    box_2 = Box(value_2)
    # TestCase 3

# Generated at 2022-06-25 23:33:36.380560
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box, expected_value, expected_result = Box(5), 5, Lazy(lambda: 5)
    try:
        assert box.to_lazy() == expected_result
        assert box.to_lazy().value() == expected_value
        assert box.to_lazy().value() == box.value
        assert box.to_lazy().value() == expected_result.value()
        assert isinstance(box.to_lazy(), Lazy)
        assert isinstance(box.to_lazy(), Monad)
    except Exception as exception:
        raise exception


# Generated at 2022-06-25 23:33:43.675464
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.functor as f
    import pymonet.monad_maybe as m
    from pymonet.lazy import Lazy

    def f_to_lazy(x):
        return x.to_lazy()

    f_to_lazy_test_cases = [
        ('test_0', None, None),
        ('test_1', Box(5), Lazy(lambda: 5)),
        ('test_2', Box('a'), Lazy(lambda: 'a')),
        ('test_3', Box('fab'), Lazy(lambda: 'fab')),
        ('test_4', Box(f.Maybe.just('fab')), Lazy(lambda: m.Maybe.just('fab'))),
    ]


# Generated at 2022-06-25 23:34:05.046018
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    box = Box(128)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: 128)
    assert box.to_maybe() == Maybe.just(128)
    assert box.to_try() == Try(128, is_success=True)
    assert box.to_validation() == Validation.success(128)


# Generated at 2022-06-25 23:34:10.123005
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box = Box(value)

    box_to_lazy = box.to_lazy()

    assert box_to_lazy.is_folded() is False

    result = box_to_lazy.fold()

    assert result == value



# Generated at 2022-06-25 23:34:16.012346
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    lazy_0 = box_0.to_lazy()
    lazy_result_0 = lazy_0.get()
    assert lazy_result_0 == box_0.value


# Generated at 2022-06-25 23:34:22.091570
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy.unit(1)

    assert Box(2).to_lazy().map(lambda x: x + 1) == Lazy.unit(1)



# Generated at 2022-06-25 23:34:33.446812
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x0b[\x81\x8a\xb5\xe7\x9c\x99\xa8\xcc\x17\xabQ\x18\x1d'
    int_0 = box_0.to_lazy()
    assert int_0.value() == bytes_0
    bytes_1 = b'@\t\xcb\x0f\x15~\xcd\x91\x0c'
    box_1 = Box(bytes_1)
    int_1 = box_1.to_lazy()
    assert int_1.value() == bytes_1

# Generated at 2022-06-25 23:34:41.015141
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    lazy_0 = Lazy(lambda:b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea')
    lazy_1 = box_0.to_lazy()
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:34:46.654168
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    box_1 = box_0.to_lazy()
    assert isinstance(box_1, Lazy)
    assert box_1.value() == bytes_0


# Generated at 2022-06-25 23:34:59.361855
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)

    def test_function():
        # ValueError: not enough values to unpack (expected 3, got 0)
        byte_array_0 = byte_array(1)
        byte_array_1 = byte_array(2)
        byte_array_2 = byte_array(3)
        byte_array_3 = byte_array(4)
        byte_array_4 = byte_array(5)
        byte_array_5 = byte_array(6)
        byte_array_6 = byte_array(7)
        byte_array_7 = byte_array(8)
        byte_

# Generated at 2022-06-25 23:35:07.085979
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(0).to_lazy() == Lazy(lambda: 0)
    assert Box('c').to_lazy() == Lazy(lambda: 'c')
    assert Box(0.0).to_lazy() == Lazy(lambda: 0.0)
    assert Box([0, 1, 2]).to_lazy() == Lazy(lambda: [0, 1, 2])
    assert Box((0, 1, 2)).to_lazy() == Lazy(lambda: (0, 1, 2))
    assert Box({'key': 'value'}).to_lazy() == Lazy(lambda: {'key': 'value'})
    assert Box('c').to

# Generated at 2022-06-25 23:35:10.128125
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    import random
    import math
    random_number = random.randint(0, math.inf)
    box_0 = Box(random_number)

    assert box_0.to_lazy().map(lambda value: value + 1).get() == random_number + 1


# Generated at 2022-06-25 23:35:41.447745
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Create box
    box_0 = Box(1)

    # Transform Box into Lazy
    lazy_0 = box_0.to_lazy()

    # Check Lazy value
    assert lazy_0.value() == 1



# Generated at 2022-06-25 23:35:44.040553
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    string_lazy = Box('string').to_lazy()
    assert isinstance(string_lazy, Lazy)
    assert string_lazy.value() == 'string'


# Generated at 2022-06-25 23:35:48.406719
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)

    # Act
    result = box_0.to_lazy()

    # Assert
    assert isinstance(result, Box)
    assert result.value == bytes_0


# Generated at 2022-06-25 23:35:51.370881
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    value = "string"
    box = Box(value)
    assert box.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-25 23:35:53.546602
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    from pymonet import Lazy

    data = Box(1)
    lazy_01 = Lazy(lambda: 1)
    assert data == lazy_01.to_box()
    assert lazy_01 == data.to_lazy()


# Generated at 2022-06-25 23:35:58.257059
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    s_0 = '!^[~bF\x0e\x83\x13\x8d\xcb\xe2\x7f\x16\xce'
    box_0 = Box(s_0)
    lazy_0 = box_0.to_lazy()
    lazy_1 = Lazy(lambda: s_0)
    assert lazy_0 == lazy_1



# Generated at 2022-06-25 23:35:59.896826
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    b = Box(2)
    b2 = b.to_lazy()
    assert b2.value() == 2


# Generated at 2022-06-25 23:36:03.237310
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)

    lazy = box_0.to_lazy()
    assert lazy.get() == bytes_0


# Generated at 2022-06-25 23:36:10.663309
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Arrange
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)

    # Act
    lazy_0 = box_0.to_lazy()

    # Assert
    assert isinstance(lazy_0, Lazy)
    assert lazy_0 == Lazy(lambda: bytes_0)
    assert lazy_0.eval() == bytes_0

    # Arrange
    container = (1, 2, 3, 4)
    box_1 = Box(container)

    # Act
    lazy_1 = box_1.to_l

# Generated at 2022-06-25 23:36:11.651713
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('test').to_lazy().run() == 'test'



# Generated at 2022-06-25 23:37:16.383919
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Prepare arguments
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)

    # Call Box's static method to_lazy
    result = box_0.to_lazy()
    assert(result == Lazy(lambda: bytes_0))



# Generated at 2022-06-25 23:37:26.285960
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Empty Box
    bytes_0 = b'\x7f\xc4D\xb1\xdb\xa2o\xdbc/\x18?\xe2\x8d\xea'
    box_0 = Box(bytes_0)
    print(box_0.to_lazy().folded())
    print()

    # Non-Empty Box
    bytes_1 = b'\xc4\xb0\x8f\x9f\x91\x1c%p\x8b\x0b\x1c\x8a\xe3\x07\xa5\xe2\x15\xa6\x97\xdb\x1c\x1e;\xc0\x89'
    box_1 = Box(bytes_1)