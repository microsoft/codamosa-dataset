

# Generated at 2022-06-12 04:47:23.523965
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) == Box(1)
    assert Box("some text") == Box("some text")
    assert Box("one") != Box("two")


# Generated at 2022-06-12 04:47:26.919658
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('test') == Box('test')
    assert Box('test') != Box('tes')



# Generated at 2022-06-12 04:47:29.481088
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != Box(2) is True
    assert Box(1) == Box('1') is False
    assert Box(1) != Box(1) is False

# Generated at 2022-06-12 04:47:40.830864
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    # Box(A) -> Lazy(() -> A)
    assert Box(2).to_lazy() == Lazy(lambda: 2)

    # Box(A) -> Lazy(A)
    assert Box(2).to_lazy().get()() == 2

    # Test to_lazy() -> get()() -> to_lazy() -> get()()
    assert Box(2).to_lazy().get()().to_lazy().get()() == 2

    # Test to_lazy() -> to_try() -> to_either() -> to_validation() -> to_lazy

# Generated at 2022-06-12 04:47:42.713840
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)


# Generated at 2022-06-12 04:47:44.409531
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy() == Box(42).to_lazy().get()

# Generated at 2022-06-12 04:47:45.563459
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:47:52.651865
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test Box.__eq__ method.
    """
    from tests.helpers import TestCase

    class Test(TestCase):
        def setUp(self):
            self.box = Box(1)

        def test_equal(self):
            self.assertEqual(Box(1), self.box)

        def test_not_equal(self):
            self.assertNotEqual(Box(2), self.box)

        def test_type_not_equal(self):
            self.assertNotEqual(2, self.box)

    Test.run()


# Generated at 2022-06-12 04:47:56.115373
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(7) == Box(7)
    assert Box(3) != Box(4)
    assert Box(4.4) != Box(4)
    assert Box(4.4) != [4]



# Generated at 2022-06-12 04:47:59.910735
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box.to_lazy() method with positive scenario.
    """
    assert Box(2).to_lazy() == Lazy(Box(2).bind)



# Generated at 2022-06-12 04:48:02.171200
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(1).to_lazy(), Box) is True

# Generated at 2022-06-12 04:48:03.898215
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != None

# Generated at 2022-06-12 04:48:08.777216
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Given
    value = 'some_value'
    box = Box(value)
    box2 = Box(value)
    box3 = Box(value + '_some_other_value')

    # When
    # Then
    assert box == box2
    assert not box2 == box3


# Generated at 2022-06-12 04:48:10.005501
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)



# Generated at 2022-06-12 04:48:12.748584
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == 'string'



# Generated at 2022-06-12 04:48:16.382263
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # given
    value = 'value'
    lazy = Lazy(lambda: value)

    # when
    box = Box(value)

    # then
    assert box.to_lazy() == lazy  # type: ignore

# Generated at 2022-06-12 04:48:18.232645
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy().fold()() == 1



# Generated at 2022-06-12 04:48:22.240014
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    object_1 = Box(10)
    object_2 = Box(10)
    object_3 = Box(20)

    assert object_1 == object_2
    assert object_1 != object_3
    assert object_1 != 2



# Generated at 2022-06-12 04:48:24.649859
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != Box("1")
    assert Box(1) != Box(1.1)
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:48:31.083271
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')
    assert Box(1) != Box(2)
    assert Box('a') != Box(1)
    assert Box(1) != 1
    assert Box('a') != 'a'


# Generated at 2022-06-12 04:48:35.174677
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(100).to_lazy() == Lazy(lambda: 100)


# Generated at 2022-06-12 04:48:39.087622
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Test with two equal Box objects
    assert Box(1) == Box(1)

    # Test with two different Box objects
    assert Box(1) != Box(2)

    # Test with one Box object and other object
    assert Box(1) != 1

# Generated at 2022-06-12 04:48:42.568569
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Tests to_lazy method of Box class.
    """
    box = Box('hello')
    expected = 'hello'
    actual = box.to_lazy().get()

    assert expected == actual


# Generated at 2022-06-12 04:48:49.701422
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box([1, 2, 3]) != Box([1, 2, 3])
    assert Box((1, 2, 3)) != Box((1, 2, 3))
    assert Box({'a': 1, 'b': 2}) != Box({'a': 1, 'b': 2})
    assert Box({'a': 1, 'b': 2}) != Box({'a': 1, 'b': 2})
    assert Box(set([1, 2])) != Box(set([1, 2]))
    assert Box(set([1, 2, 3, 4])) != Box(set([1, 2, 4]))

# Generated at 2022-06-12 04:48:52.726829
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Case when tested object and comparing object are equals.
    """
    box = Box(0)
    assert box == Box(0)


# Generated at 2022-06-12 04:48:55.301092
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert not Box(1) == None
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)



# Generated at 2022-06-12 04:48:58.360925
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box('test_data')
    box2 = Box(12)
    box3 = Box('test_data')

    assert box1 == box3
    assert not box1 == box2



# Generated at 2022-06-12 04:49:03.517467
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)
    assert Box(1) != Box(2)
    assert Box(1) != Box(None)
    assert Box(None) != Box(1)
    assert Box(Box(1)) != Box(1)
    assert Box(Box(None)) != Box(None)



# Generated at 2022-06-12 04:49:06.510163
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    x = Box(1)
    y = Box(1)
    z = Box(2)
    assert x == y
    assert not (x == z)


# Generated at 2022-06-12 04:49:11.694270
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pylint: disable=no-self-use
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy
    x = 10  # pylint: disable=invalid-name
    assert Box(x).to_lazy().to_box().value == Lazy(lambda: x).get()



# Generated at 2022-06-12 04:49:17.941797
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(123).to_lazy() == Lazy(lambda: 123)

# Generated at 2022-06-12 04:49:19.218283
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().force()() == 42

# Generated at 2022-06-12 04:49:22.063418
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:49:24.550723
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box('string'))
    assert not (Box(1) == '1')



# Generated at 2022-06-12 04:49:28.812804
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1), 'Box __eq__ method return False with two boxes with same value'
    assert not Box(1) == Box(2), 'Box __eq__ method return True with two boxes with different values'
    assert not Box(1) == 1, 'Box __eq__ method return True with box and any non-box'



# Generated at 2022-06-12 04:49:32.557426
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, force

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert force(Box(5).to_lazy()) == 5



# Generated at 2022-06-12 04:49:34.726738
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(3)
    assert Box(1) != 1



# Generated at 2022-06-12 04:49:37.842556
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(20)
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')



# Generated at 2022-06-12 04:49:41.784247
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    try:
        assert isinstance(Box(3).to_lazy(), Lazy)
    except NameError as e:
        msg = '{}. You have to run \'pip install -r requirements-test.txt\' before running tests.'.format(
            repr(e))
        raise NameError(msg)



# Generated at 2022-06-12 04:49:43.561064
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)


# Generated at 2022-06-12 04:49:55.157677
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(123).to_lazy() == Lazy(lambda: 123)



# Generated at 2022-06-12 04:49:57.411283
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(2) == Box(2)
    assert Box('2') != Box(2)
    assert Box(2) != 2



# Generated at 2022-06-12 04:49:59.107229
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box("a").to_lazy().value() == "a"

# Generated at 2022-06-12 04:49:59.789404
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box("1") == Box("1")

# Generated at 2022-06-12 04:50:05.463288
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    assert Box('abc') == Box('abc')
    assert Box('ab') != Box('abc')
    assert Box(123) == Box(123)
    assert Box([1,2,3]) == Box([1,2,3])
    assert Box((1,2,3)) == Box((1,2,3))
    assert Box({'a': 1}) == Box({'a': 1})



# Generated at 2022-06-12 04:50:08.448702
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    def test_function():
        return 'Test Box to Lazy'

    assert Box('Test Box to Lazy').to_lazy().get() == test_function()



# Generated at 2022-06-12 04:50:10.782006
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Lazy(lambda: 5) == Box('a').to_lazy()



# Generated at 2022-06-12 04:50:13.215316
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box, lazy = Box(1).to_lazy(), Lazy(lambda: 1)
    assert box == lazy



# Generated at 2022-06-12 04:50:16.734598
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == "Box(1)")
    assert not (Box(1) == None)


# Generated at 2022-06-12 04:50:19.858257
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == 1
    assert not Box(1) == Box(2)
    assert not Box(1) == Box('1')



# Generated at 2022-06-12 04:50:45.815111
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    left_value = 'left value'
    right_value = 'right value'

    # first test of method type
    assert isinstance(Box(left_value).value, object)

    # first test of method type
    assert isinstance(Box(left_value).value, object)

    # first test of method __eq__
    assert Box(left_value).__eq__(Box(left_value))

    # second test of method __eq__
    assert Box(left_value).__eq__(Box(left_value)) is False

    # third test of method __eq__
    assert Box(left_value).__eq__(left_value) is False

    # fourth test of method __eq__
    assert Box(left_value).__eq__(None) is False



# Generated at 2022-06-12 04:50:47.188558
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)



# Generated at 2022-06-12 04:50:50.447259
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def value() -> int:
        return 2

    assert Box(Try(value, is_success=True)).to_lazy() == Lazy(value)



# Generated at 2022-06-12 04:50:51.982586
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:50:55.010795
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(None)
    assert Box(10) != None  # noqa



# Generated at 2022-06-12 04:50:58.215401
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) == Box(3)
    assert Box(3) != Box(4)
    assert Box('3') != Box(3)



# Generated at 2022-06-12 04:51:00.182738
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box('test')
    assert Lazy(lambda: 'test') == box.to_lazy()

# Generated at 2022-06-12 04:51:03.358228
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(20).to_lazy(), pymonet.Lazy)
    assert Box(20).to_lazy().force() == 20
    #test_Box_to_lazy.py

# Generated at 2022-06-12 04:51:06.992170
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('some value') == Box('some value')
    assert Box(1) != Box('some value')
    assert Box(1) != Box(2)
    assert Box(None) != Box(None)



# Generated at 2022-06-12 04:51:08.592998
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)

# Generated at 2022-06-12 04:51:36.795758
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_box1 = Lazy(lambda: Box('test 1'))
    lazy_box2 = Lazy(lambda: Box('test 2'))

    assert lazy_box1.map(str).value() == lazy_box2.map(str).value()



# Generated at 2022-06-12 04:51:41.837395
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: 1)
    assert lazy.is_folded() is False
    assert lazy.value() == 1
    assert lazy.is_folded() is True


# Generated at 2022-06-12 04:51:48.137256
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(3).to_lazy() == Lazy(lambda: 3)
    assert Box(Lazy(lambda: 3)).to_lazy() == Lazy(lambda: 3)
    assert Box(Try(3, is_success=True)).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-12 04:51:54.205458
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Box('foo').to_lazy() == Lazy(lambda: 'foo'), 'Must be transformed to not folded Lazy'
    assert Box('foo').to_lazy().value() == 'foo', 'Must be transformed to not folded Lazy'
    assert Maybe('foo').to_lazy().value() == 'foo', 'Must be transformed to not folded Lazy'



# Generated at 2022-06-12 04:51:55.410497
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().force() == 3


# Generated at 2022-06-12 04:51:57.646139
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:52:05.789449
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy() of class Box.
    """
    # GIVEN two same Boxes
    box_1 = Box(1)
    box_2 = Box(1)

    # WHEN we got Lazy from this boxes
    lazy_1 = box_1.to_lazy()
    lazy_2 = box_2.to_lazy()

    # THEN both Lazy are not folded
    assert lazy_1.is_lazy
    assert lazy_2.is_lazy

    # AND both Lazy contains same value
    assert lazy_1.value() == lazy_2.value() == 1



# Generated at 2022-06-12 04:52:08.018761
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 04:52:13.017150
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    box = Box('value')
    lazy_value = box.to_lazy()
    assert isinstance(lazy_value, Lazy)
    assert isinstance(lazy_value, Functor)
    assert lazy_value.value() == 'value'


# Generated at 2022-06-12 04:52:16.200462
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()

# Generated at 2022-06-12 04:53:08.724889
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 1)
    box = Box(1)

    assert box.to_lazy() == lazy

# Generated at 2022-06-12 04:53:11.587807
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.__class__.__name__ == 'Lazy'
    assert lazy.value() == 1



# Generated at 2022-06-12 04:53:13.815783
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy
    from pymonet.lazy_test import _number_generator

    assert Box(5).to_lazy() == Lazy(_number_generator(5))



# Generated at 2022-06-12 04:53:15.368110
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().map(lambda d: d + 1).value() == 2


# Generated at 2022-06-12 04:53:20.621849
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy() method of class Box.

    Test that lazy monad value are computed only after call method value.
    """
    from pymonet.monad_list import List
    from pymonet.monad_lazy import Lazy
    lazy_list = List.just(1).to_lazy()
    assert not isinstance(lazy_list, Lazy)  # lazy list is not Lazy type before call value
    assert isinstance(lazy_list.value(), Lazy)  # lazy list is Lazy type after call value



# Generated at 2022-06-12 04:53:22.360920
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # when
    value = Box(10).to_lazy()

    # then
    assert value == Lazy(lambda: 10)



# Generated at 2022-06-12 04:53:27.777924
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box: Box[int] = Box(8)
    assert Lazy(lambda: box.value).equals(box.to_lazy()), 'should transform box into Lazy'
    assert Lazy(lambda: box.value).equals(box.to_lazy().map(lambda x: x * 2).to_lazy()), \
        'should transform box into Lazy and apply function'



# Generated at 2022-06-12 04:53:29.948415
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 2
    box = Box(value)
    lazy = Lazy(lambda: value)

    assert box.to_lazy() == lazy

# Generated at 2022-06-12 04:53:31.413015
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value == 1

# Generated at 2022-06-12 04:53:36.647605
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.

    :returns: assertion error if test fail
    :rtype: None
    :raises: AssertionError
    """
    assert isinstance(Box(5).to_lazy(), Lazy)
    assert Box(5).to_lazy().unwrap() == 5
    assert Box(5).to_lazy().fmap(lambda x: x + 6).unwrap() == 11



# Generated at 2022-06-12 04:55:34.346670
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:55:35.450532
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def lambda_func(): return 2

    assert Box(lambda_func).to_lazy().value == lambda_func


# Generated at 2022-06-12 04:55:38.090655
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 04:55:38.858953
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # to_lazy should return Lazy object
    assert(isinstance(Box(1).to_lazy(), Lazy))

# Generated at 2022-06-12 04:55:42.102784
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    def new_lazy():
        return Lazy(lambda: 2 + 2)

    def new_box():
        return Box(new_lazy())

    assert new_box().to_lazy().value() == new_lazy().value()


# Generated at 2022-06-12 04:55:43.768072
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-12 04:55:47.441209
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def inc(n):
        return n + 1
    
    def mapper(n):
        return inc(n)

    box = Box(1)
    assert box.to_lazy().map(mapper).value() == box.value + 1

# Generated at 2022-06-12 04:55:49.417919
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(3).to_lazy().get() == 3

# Generated at 2022-06-12 04:55:56.080317
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2).equals(Box(2).to_lazy())
    assert Lazy(lambda: '2').equals(Box('2').to_lazy())
    assert Lazy(lambda: []).equals(Box([]).to_lazy())
    assert Lazy(lambda: {'a': 'a'}).equals(Box({'a': 'a'}).to_lazy())
    assert Lazy(lambda: ('a', 'b')).equals(Box(('a', 'b')).to_lazy())



# Generated at 2022-06-12 04:55:58.275075
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(4).to_lazy()

    assert isinstance(lazy, Lazy) and lazy.value() == 4
