

# Generated at 2022-06-12 04:47:29.441089
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    box = Box('value')

    # Act
    lazy_box = box.to_lazy()

    # Assert
    assert lazy_box == Lazy(lambda: 'value')



# Generated at 2022-06-12 04:47:33.388945
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Method 'to_lazy' should convert box to lazy monad with function returning previous box value.
    """
    assert Box('test').to_lazy().get()() == 'test'

# Generated at 2022-06-12 04:47:36.588185
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # ARRANGE
    x = Box(1)
    y = Box(1)
    # ACT
    result = x == y
    # ASSERT
    assert result is True



# Generated at 2022-06-12 04:47:38.584380
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Box(1).to_lazy(), Lazy)

# Generated at 2022-06-12 04:47:39.916976
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 1) == Box(1).to_lazy()

# Generated at 2022-06-12 04:47:43.886033
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Box(5).to_lazy()
    assert (Box(lambda a: a * 2) >> (lambda f: Box(f(10)))).to_lazy() == Lazy(20)


# Generated at 2022-06-12 04:47:45.065076
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:47:47.663611
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(10.0)
    assert Box(10) != 10


# Generated at 2022-06-12 04:47:49.455361
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) == Box(1)) is True
    assert (Box(1) == Box(2)) is False



# Generated at 2022-06-12 04:47:58.323417
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert Box(None) == Box(None)
    assert not Box([]).__eq__(Box([1,2,3]))
    assert Box([]).__eq__(Box([]))
    assert not Box([1,2,3]).__eq__(Box([]))
    assert Box([1,2,3]).__eq__(Box([1,2,3]))
    assert not Box([[1,2,3]]).__eq__(Box([[1,2,3],[1,2,3]]))
    assert Box([[1,2,3]]).__eq__(Box([[1,2,3]]))

    class A():
        def __eq__(self, other):
            return True

   

# Generated at 2022-06-12 04:48:01.329626
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:48:02.969689
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange

    # Act
    lazy_box = Box(100).to_lazy()
    # Assert
    assert lazy_box.is_folded() is False
    assert lazy_box.value() == 100


# Generated at 2022-06-12 04:48:04.090946
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    b = Box(1).to_lazy()
    assert b.fold() == 1


# Generated at 2022-06-12 04:48:06.307592
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 2
    assert Box(value) == Lazy(lambda: value).to_box()

# Generated at 2022-06-12 04:48:09.517767
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(lambda x: x).to_lazy() == Lazy(lambda x: x)



# Generated at 2022-06-12 04:48:12.973301
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test that Box.to_lazy return Lazy monad with previous value.
    """
    from pymonet.lazy import Lazy

    assert(Box(1).to_lazy() == Lazy(lambda: 1))


# Generated at 2022-06-12 04:48:15.617941
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box_value = 666

    lazy = Box(box_value).to_lazy()
    assert lazy.is_suspend()
    assert lazy.value() == box_value



# Generated at 2022-06-12 04:48:18.030316
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_value = 1
    box = Box(test_value)

    assert box.to_lazy().value() == test_value

# Generated at 2022-06-12 04:48:26.348923
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest

    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import raise_exception

    def raise_exception_fn():
        """
        Function returns failed Try.

        :returns: failed Try
        :rtype: Try(None, is_success=False)
        """
        return Try(None, is_success=False)

    lazy = raise_exception_fn().to_lazy()
    assert lazy == Lazy(lambda: raise_exception(ValueError))

    assert Lazy(lambda: Try(1, is_success=True)) == Lazy(lambda: 1).to_try().to_lazy()

# Generated at 2022-06-12 04:48:27.181884
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('value').to_lazy() == Lazy(lambda: 'value')

# Generated at 2022-06-12 04:48:31.124285
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_box = Box(10).to_lazy()
    assert lazy_box == Lazy(lambda: 10)



# Generated at 2022-06-12 04:48:32.073268
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().eval() == 10

# Generated at 2022-06-12 04:48:37.146775
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    from pymonet.monad_try import Failure
    import pytest

    def get_value():
        return 'test_str'

    assert Functor.box(get_value).to_lazy() == Lazy(get_value)

    with pytest.raises(Failure):
        Functor.box(get_value).to_try()

# Generated at 2022-06-12 04:48:41.240920
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: nocover
    from pymonet.lazy import Lazy
    box = Box(10)
    lazy = box.to_lazy()
    assert type(lazy) == Lazy
    assert lazy.fold(lambda: None) == 10

# Generated at 2022-06-12 04:48:49.183872
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import LazyValueError
    from pymonet.functors import Identity
    from pymonet.functors import Functor
    from pymonet.functors import FunctorError
    from pymonet.functors import map_lazy

    assert Box('A').to_lazy() == Lazy(lambda: 'A')
    assert Box('A').to_lazy() == Lazy(lambda: Functor(Box(Functor('A'))).map(lambda x: x.value).value)
    assert Box(Functor(Box('A'))).to_lazy().map(lambda x: x.value).value == Functor(Box('A')).map(lambda x: x.value).value

# Generated at 2022-06-12 04:48:53.353904
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Check to_lazy method of Box class
    """
    from pymonet.lazy import Lazy

    assert isinstance(Box(1).to_lazy(), Lazy)
    assert Box(1).to_lazy().force() == 1


# Generated at 2022-06-12 04:48:54.727323
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:48:58.177455
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy().value()

# Generated at 2022-06-12 04:48:59.359521
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().get() == 1

# Generated at 2022-06-12 04:49:02.025836
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(1).to_lazy() == Box(1).value


# Generated at 2022-06-12 04:49:06.318623
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # GIVEN
    box = Box(5)

    # WHEN
    result = box.to_lazy()

    # THEN
    assert result.fold() == 5

# Generated at 2022-06-12 04:49:11.829207
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure, Success

    assert Box(2).to_lazy() == Lazy(lambda: 2)
    assert Box(Failure()).to_lazy() == Lazy(lambda: Failure())
    assert Box(Success(2)).to_lazy() == Lazy(lambda: Success(2))



# Generated at 2022-06-12 04:49:13.524814
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Box(10).to_lazy().value()



# Generated at 2022-06-12 04:49:16.149566
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:18.476219
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    box = Box(1)
    assert box.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:22.396806
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_lazy import Lazy

    box = Box('foo')
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy) and lazy.unwrap() == 'foo'

# Generated at 2022-06-12 04:49:24.551024
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 42) == Box(42).to_lazy()

# Generated at 2022-06-12 04:49:25.553365
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 04:49:35.378949
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()
    assert Lazy(lambda: 2) == Box(2).to_lazy()
    assert Lazy(lambda: 3) == Box(3).to_lazy()
    assert Lazy(lambda: 'a') == Box('a').to_lazy()
    assert Lazy(lambda: 'b') == Box('b').to_lazy()
    assert Lazy(lambda: [1, 2]) == Box([1, 2]).to_lazy()
    assert Lazy(lambda: (1, 2)) == Box((1, 2)).to_lazy()

# Generated at 2022-06-12 04:49:36.784550
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().unfold() == 2

# Generated at 2022-06-12 04:49:41.454507
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(12).to_lazy().fold(lambda x: x()) == 12

# Generated at 2022-06-12 04:49:43.514094
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(lambda x: x == 1).to_lazy().fold(lambda x: Box(x).value)().value() == Box(1).value

# Generated at 2022-06-12 04:49:46.508129
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = box.to_lazy()

    assert lazy == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:49.415599
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(2).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fold(lambda: None) == 2



# Generated at 2022-06-12 04:49:54.164056
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert isinstance(Box("foo").to_lazy(), Lazy)
    assert Box("foo").to_lazy().value == Lazy(lambda: "foo").value
    assert Box(Right("foo")).to_lazy() == Lazy(lambda: Right("foo"))

# Generated at 2022-06-12 04:50:02.691237
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import is_monad
    from pymonet.functor import is_functor
    from pymonet.applicative import is_applicative

    assert is_monad(Box(1).to_lazy())
    assert is_functor(Box(1).to_lazy())
    assert is_applicative(Box(1).to_lazy())

    assert Box(1).to_lazy().mvalue() == Lazy(lambda: 1)
    assert Box(1).to_lazy().fold() == Lazy(lambda: 1)
    assert Box(1).to_lazy().value() == Lazy(lambda: 1)
    assert Box(2).to_lazy().map(lambda value: value * value).value() == L

# Generated at 2022-06-12 04:50:10.383323
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as lazy
    from pymonet.functor import Functor

    f = Functor(lambda x: x * 2)
    lazy_box = Box([1, 2, 3]).to_lazy()
    assert f.fmap(lazy_box.value) == f.fmap(lambda x: x * 2)
    assert lazy_box.value() == lazy.Lazy(lambda: [1, 2, 3]).value()
    assert lazy.Lazy(lambda: [1, 2, 3]).value() == [1, 2, 3]

# Generated at 2022-06-12 04:50:13.850385
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box.unit(5)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: 5)


# Generated at 2022-06-12 04:50:16.013832
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(2)
    lazy = box.to_lazy()
    assert lazy.value() == 2

# Generated at 2022-06-12 04:50:17.981688
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(4).to_lazy() == Lazy(lambda: 4)



# Generated at 2022-06-12 04:50:23.296340
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 'test_value') == Box('test_value').to_lazy()

# Generated at 2022-06-12 04:50:26.997445
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Setup
    box = Box(42)

    # Exercise
    lazy = box.to_lazy()

    # Verify
    assert lazy.fold(lambda x, y: str(x) + " " + str(y)) == '42'

    # Cleanup - none

# Generated at 2022-06-12 04:50:28.677229
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(4).to_lazy() == Lazy(lambda: 4)



# Generated at 2022-06-12 04:50:31.011301
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()

# Generated at 2022-06-12 04:50:33.230741
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(1)

    assert isinstance(box.to_lazy(), Lazy)

# Generated at 2022-06-12 04:50:37.130931
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box(Try(42, is_success=True)).to_lazy() == Lazy(lambda: Try(42, is_success=True))

# Generated at 2022-06-12 04:50:40.655401
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for method `to_lazy` of class `Box`.
    """
    from pymonet.lazy import Lazy

    box = Box(1)

    assert box.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:50:43.690786
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box('hi').to_lazy() == Lazy(lambda: 'hi')
    assert Box(['hello', 'world']).to_lazy() == Lazy(lambda: ['hello', 'world'])



# Generated at 2022-06-12 04:50:47.506241
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Convert box to lazy.
    :return: None
    """
    from pymonet.lazy import Lazy

    result = Box(42).to_lazy()

    assert isinstance(result, Lazy)
    assert result() == 42

# Generated at 2022-06-12 04:50:50.562768
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test method to_lazy of Box.

    """
    assert Box(100).to_lazy().is_folded() is False
    assert Box(100).to_lazy().value() == 100



# Generated at 2022-06-12 04:51:00.831819
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)
    assert Box(3).to_lazy().is_folded() is False
    assert Box(3).to_lazy().get() == 3
    assert Box(3).to_lazy().is_folded() is True


# Generated at 2022-06-12 04:51:04.469440
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for Box.to_lazy method
    """
    from pymonet.lazy import Lazy

    box = Box(4)

    assert isinstance(box.to_lazy(), Lazy) is True


# Generated at 2022-06-12 04:51:05.762417
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).value

# Generated at 2022-06-12 04:51:09.909544
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box.to_lazy method.
    """
    # given
    value = 123
    box = Box(value)

    # when
    lazy = box.to_lazy()

    # then
    assert value == lazy.value()



# Generated at 2022-06-12 04:51:12.000804
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = Box(1)
    lazy_value = value.to_lazy()

    assert lazy_value.value() == 1


# Generated at 2022-06-12 04:51:15.503927
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    lazy = Box(123).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 123

# Generated at 2022-06-12 04:51:17.270948
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(1).to_lazy(), Lazy)
    assert False


# Generated at 2022-06-12 04:51:20.040144
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    data = Box(1)
    lazy = data.to_lazy()
    assert lazy.value() == data.value

# Generated at 2022-06-12 04:51:22.120253
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box('test').to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 'test'



# Generated at 2022-06-12 04:51:25.134145
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(10)
    lazy = box.to_lazy()

    assert lazy.eval() == 10



# Generated at 2022-06-12 04:51:40.895397
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 5

    assert str(Box(value).to_lazy()) == 'Lazy[value=<function test_Box_to_lazy.<locals>.<lambda> at 0x7f1f58e9b378>]'

# Generated at 2022-06-12 04:51:42.241837
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:51:45.264725
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    box = Box(1)
    lazy_value = box.to_lazy()
    assert lazy_value.value() == 1

# Generated at 2022-06-12 04:51:47.783587
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:51:51.688118
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for checking without error calling method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy

    assert Box(4).to_lazy() == Lazy(lambda: 4)
    assert Box(4).to_lazy() == Lazy(lambda: 4)


# Generated at 2022-06-12 04:51:53.653707
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:51:58.030845
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def _assert(lazy: Lazy) -> None:
        assert lazy.eval() == Try(1, is_success=True)

    _assert(Box(Try(1, is_success=True)).to_lazy())

# Generated at 2022-06-12 04:52:01.463225
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, maybe_lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

    assert maybe_lazy(Box(1)) == Lazy(lambda: Box(1))

# Generated at 2022-06-12 04:52:02.827792
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(1).to_lazy(), Lazy)

# Generated at 2022-06-12 04:52:05.151032
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()

# Generated at 2022-06-12 04:52:32.624758
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5) \
        .to_lazy() \
        .map(lambda x: x + 2) \
        .map(lambda x: x ** 2) \
        .get() == 49

# Generated at 2022-06-12 04:52:34.495599
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:52:35.569806
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().fold()() == 10

# Generated at 2022-06-12 04:52:38.275543
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-12 04:52:44.366173
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from unittest import TestCase
    import pymonet.lazy as lazy

    class TestBoxToLazy(TestCase):
        def test_to_lazy(self):
            box = Box(2)
            lazy_box = box.to_lazy()
            self.assertEqual(box, lazy_box.get())
            self.assertEqual(lazy_box.fold(), 2)

    test_case = TestBoxToLazy()
    test_case.test_to_lazy()



# Generated at 2022-06-12 04:52:45.695819
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().value() == 3


# Generated at 2022-06-12 04:52:47.672538
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    _lazy = Box(42).to_lazy()
    assert _lazy.value() == 42

# Generated at 2022-06-12 04:52:50.230036
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    value = 'test string'

    # Act
    result = Box(value).to_lazy()

    # Assert
    assert result.get() == value
    assert result.is_folded

# Generated at 2022-06-12 04:52:52.915523
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assertion = Box(5).to_lazy()
    assert assertion.equals(Box(5).to_lazy().memoized())
    assert assertio

# Generated at 2022-06-12 04:52:57.296804
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy

    :return: nothing
    :rtype: None
    :raises: AssertionError
    """

    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 5)
    assert Box(5).to_lazy() == lazy

# Generated at 2022-06-12 04:53:55.709182
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().value() == 2

# Generated at 2022-06-12 04:53:56.411559
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box.unit(1).to_lazy().value() == 1

# Generated at 2022-06-12 04:53:58.967796
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 'Test') == Box('Test').to_lazy()



# Generated at 2022-06-12 04:54:06.395701
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    a = Box(3)
    b = a.to_lazy()
    assert isinstance(b, Lazy)
    assert b.fold(lambda a, b: (a, b), lambda a: (a, None))[0] == 3
    assert b.fold(lambda a, b: (a, b), lambda a: (a, None))[1] is None


# Generated at 2022-06-12 04:54:10.718156
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(None).to_lazy().value() == None
    assert Box(3).to_lazy().value() == 3
    assert Box(None).to_lazy().map(lambda x: x).value() == None
    assert Box(3).to_lazy().map(lambda x: x + x).value() == 6
    assert Box(None).to_lazy().bind(lambda x: x).value() == None
    assert Box(3).to_lazy().bind(lambda x: x + x).value() == 6



# Generated at 2022-06-12 04:54:12.136905
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1


# Generated at 2022-06-12 04:54:19.342791
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test transforming Box into not folded Lazy monad with returning value function.

    :return: None
    :rtype: None
    """
    from pymonet.lazy import Lazy

    # Set return value
    ret_value = 42

    # Create Lazy monad instance of not folded function returning ret_value
    lazy = Lazy(lambda: ret_value)

    # Create Box of ret value
    box = Box(ret_value)

    # Assert that Lazy monads are equal
    assert lazy == box.to_lazy()



# Generated at 2022-06-12 04:54:22.112597
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad import assert_equals

    assert_equals(Box(1).to_lazy())(Lazy(lambda: 1))


# Generated at 2022-06-12 04:54:24.001045
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:54:32.689041
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    box: Box[int] = Box(42)
    lazy: Lazy[int] = Lazy(lambda: 42)
    try_left: Box[str] = Box('Hello world!')
    try_right: Box[str] = Box('Hello world!')
    validation: Validation[str, None] = Validation.success('Hello world!')

    assert box.to_lazy() == lazy
    assert box.to_either() == Right(42)
    assert box.to_maybe() == lazy.to_maybe()
    assert box.to_try() == lazy.to_try()
    assert box.to_validation() == validation

# Generated at 2022-06-12 04:56:44.070983
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    lazy = box.to_lazy()
    assert box.value == lazy.fold()



# Generated at 2022-06-12 04:56:47.342092
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    # GIVEN
    not_folded_lazy = Box(3).to_lazy()

    # WHEN
    lazy_value = not_folded_lazy.value()

    # THEN
    assert lazy_value == 3



# Generated at 2022-06-12 04:56:49.455474
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 1) == Box(1).to_lazy()
    assert Lazy(lambda: 'a') == Box('a').to_lazy()

# Generated at 2022-06-12 04:56:56.731938
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Test case for to_lazy method of Box class."""
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box('test').to_lazy() == Lazy(lambda: 'test')
    assert Box([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])
    assert Box({1, 2, 3}).to_lazy() == Lazy(lambda: {1, 2, 3})
    assert Box(True).to_lazy() == Lazy(lambda: True)
    assert Box(None).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 04:57:00.965820
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('hello').to_lazy() == Lazy(lambda: 'hello')
    assert Box(5).to_lazy() == Lazy(lambda: 5)
    # Lazy is not tested by equality now
    assert Box(5).to_lazy().force() == 5
    assert Box('Hello').to_lazy().force() == 'Hello'


# Generated at 2022-06-12 04:57:01.999118
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(4).to_lazy(), Lazy)


# Generated at 2022-06-12 04:57:07.793861
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(5).to_lazy().value == Lazy(lambda: 5).value
    assert Box(5).to_lazy().value() == Lazy(lambda: 5).value()
    assert Box(5).to_lazy().value() == 5
    assert Box(5).to_lazy().map(lambda x: x + 2).value() == 7


# Generated at 2022-06-12 04:57:12.138345
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Unit

    # given
    value = 'foo'
    box = Box(value)

    # when
    lazy = box.to_lazy()

    # then
    assert lazy.value() == value
    assert lazy.value() == value
    assert lazy.value() == value
    assert lazy.value() == value

# Generated at 2022-06-12 04:57:13.296521
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('test').to_lazy().force() == 'test'



# Generated at 2022-06-12 04:57:18.546502
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest

    @pytest.fixture()
    def value():
        return 321

    @pytest.fixture()
    def box(value):
        return Box(value)

    @pytest.fixture()
    def lazy(value):
        from pymonet.lazy import Lazy

        return Lazy(lambda: value)

    def test_returns_not_folded_Lazy(box, lazy):
        assert box.to_lazy() == lazy