

# Generated at 2022-06-12 04:47:28.131989
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box(1) != None

# Generated at 2022-06-12 04:47:30.929852
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box('a')
    box2 = Box('a')
    assert box1 == box2

    box1 = Box(1)
    box2 = Box(2)
    assert not (box1 == box2)



# Generated at 2022-06-12 04:47:34.400089
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(6) == Box(6)
    assert Box(6) != Box(7)
    assert Box('7') != Box(7)
    

# Generated at 2022-06-12 04:47:39.296841
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    data = [
        (Box(1), Box(1), True),
        (Box(1), Box(2), False),
        (Box(1), 1, False),
    ]

    for box_a, box_b, expected in data:
        actual = box_a.__eq__(box_b)
        assert actual == expected



# Generated at 2022-06-12 04:47:41.547742
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)
    assert Box(5) != 5


# Generated at 2022-06-12 04:47:45.129274
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(None)
    assert Box(1) != 1
    assert Box(None) != None
    assert Box(None) != Box(1)



# Generated at 2022-06-12 04:47:53.883458
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert "Lazy[Function(() -> 1)]" == str(Box(1).to_lazy())
    assert "Lazy[Function(() -> 'string')]" == str(Box('string').to_lazy()) # pragma: no cover
    assert "Lazy[Function(() -> 1.0)]" == str(Box(1.0).to_lazy())
    assert "Lazy[Function(() -> [1, 2, 3])]" == str(Box([1, 2, 3]).to_lazy())
    assert "Lazy[Function(() -> {'key1': 'value1', 'key2': 'value2'})]" == str(Box({'key1': 'value1', 'key2': 'value2'}).to_lazy())
    assert "Lazy[Function(() -> ('tuple'))]"

# Generated at 2022-06-12 04:47:57.817906
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(10)
    assert box.to_lazy() == Lazy(lambda: 10)

    box = Box('hi')
    assert box.to_lazy() == Lazy(lambda: 'hi')


# Generated at 2022-06-12 04:48:00.528543
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('a') == Box('a')
    assert not (Box('a') == Box('b'))



# Generated at 2022-06-12 04:48:02.726923
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Box(2).to_lazy().value()

# Generated at 2022-06-12 04:48:11.132341
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:48:20.748092
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import lazy_compose
    from pymonet.monad_lazy import lazy_unit
    from pymonet.lazy import Lazy

    # Create lazy of Box[1]
    lazy_box = lazy_unit(Box(1))

    assert isinstance(lazy_box, Lazy)

    # Test that Box transforms to Lazy
    assert lazy_box.fold() == Box(1)

    assert lazy_compose(lambda b: b.map(lambda i: i + 1))(lazy_box).fold() == Box(2)

    assert lazy_compose(lambda b: b.to_lazy())(lazy_box).fold() == Box(1)

# Generated at 2022-06-12 04:48:23.770671
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(3)
    assert box == Box(3)
    assert box == box
    assert not box == Box(1)
    assert not box == 1
    assert not box == True
    assert not box == None
    assert not box == '1'

# Generated at 2022-06-12 04:48:25.026175
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:48:26.067188
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(7)


# Generated at 2022-06-12 04:48:27.904354
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box('a') != None
    assert Box('') != None



# Generated at 2022-06-12 04:48:31.484858
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Box(1).to_lazy() == Lazy(1)
    assert Box(Maybe.just(5)).to_lazy() == Lazy(Maybe.just(5))



# Generated at 2022-06-12 04:48:34.141778
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(lambda x: x * 2)
    lazy = box.to_lazy()

    assert not lazy.is_folded()
    assert lazy.fold()(3) == 6



# Generated at 2022-06-12 04:48:35.553347
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:48:46.158162
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Create Box with value and transform it into Lazy. Next fold created Lazy and check if result value is the same.
    """
    from pymonet.lazy import Lazy
    from pymonet.instances import *

    assert str(Box(10).to_lazy().fold()) == str(Box(10).to_lazy().fold().map(id).ap(Lazy(lambda: Box(id))).fold())
    assert str(Box('some_text').to_lazy().fold()) == str(Box('some_text').to_lazy().fold().map(id).ap(Lazy(lambda: Box(id))).fold())
    assert Box(10).to_lazy().fold() == Box(10).to_lazy().fold().map(id).ap(Lazy(lambda: Box(id))).fold()

# Generated at 2022-06-12 04:48:52.776231
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-12 04:48:55.659551
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """ Unit test for method to_lazy of class Box """

    assert Box(1).to_lazy().get_value() == Lazy(lambda: 1).get_value()


# Generated at 2022-06-12 04:49:01.064072
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Assert to_lazy of Box return not evaluated Lazy
    def to_lazy(x):
        return Box(x).to_lazy()

    assert isinstance(to_lazy(1), Lazy)
    assert to_lazy(1).is_folded is False
    assert to_lazy(1).value() == 1



# Generated at 2022-06-12 04:49:05.256206
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box('Test')
    lazy = box.to_lazy()

    assert lazy == Lazy(lambda: 'Test')
    assert lazy.value() == 'Test'



# Generated at 2022-06-12 04:49:07.363315
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 04:49:13.669697
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    from unittest import TestCase, main
    from pymonet.box import Box

    class Box__eq__TestSuite(TestCase):
        def test_Box__eq__with_equal_objects(self):
            self.assertTrue(Box(1) == Box(1))

        def test_Box__eq__with_unequal_objects(self):
            self.assertTrue(Box(1) != Box(2))

    main()



# Generated at 2022-06-12 04:49:16.557351
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Assert to_lazy returns not folded Lazy monad with function returning previous value
    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 04:49:19.220890
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Empty
    assert Box(0).to_lazy().fold(None, None) == 0

    # Not empty
    assert Box(None).to_lazy().fold(None, None) is None

# Generated at 2022-06-12 04:49:22.061110
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('test') == Box('test')
    assert not (Box('test') == Box('test2'))



# Generated at 2022-06-12 04:49:24.961561
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != 'abc'


# Generated at 2022-06-12 04:49:32.982035
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box(1) != Box('some')



# Generated at 2022-06-12 04:49:34.669526
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-12 04:49:44.691940
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(Try(1)).to_lazy() == Lazy(lambda: Try(1))
    assert Box(Try(1)).to_lazy().value() == Try(1)
    assert Box(Try(1)).to_lazy().value() == Try.success(1)
    assert Box(Try(1, is_success=True)).to_lazy().value() == Try.success(1)
    assert Box(Try(1, is_success=False)).to_lazy().value() == Try.failure(1)
    assert Box(Try(1, is_success=True).value).to_lazy().value() == Try.success

# Generated at 2022-06-12 04:49:48.446623
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for to_lazy method of Box class.
    """
    from pymonet.lazy import Lazy

    a = Box(1)
    b = a.to_lazy()

    assert b == Lazy(lambda: 1)



# Generated at 2022-06-12 04:49:50.004496
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(0)
    assert Box(0) != Box(1)



# Generated at 2022-06-12 04:49:52.629465
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == 1
    assert not Box(1) == None  # noqa



# Generated at 2022-06-12 04:49:56.284992
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != None
    assert Box(1) != 1



# Generated at 2022-06-12 04:49:57.549531
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(True)

    assert box.to_lazy() == Lazy(lambda: True)



# Generated at 2022-06-12 04:50:00.078343
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(3)
    assert Box(5) != 3
    assert Box(5) != None



# Generated at 2022-06-12 04:50:07.814476
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box('test').to_lazy() == Lazy(lambda: 'test')
    assert Box([42, 0]).to_lazy() == Lazy(lambda: [42, 0])
    assert Box((42, 0)).to_lazy() == Lazy(lambda: (42, 0))
    assert Box({'first': 42, 'second': 0}).to_lazy() == Lazy(lambda: {'first': 42, 'second': 0})


# Generated at 2022-06-12 04:50:21.384691
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) == Box(2) is False
    assert Box('test') == Box('test')
    assert Box('test') == Box(1) is False
    assert Box(None) == Box(None)
    assert Box(None) == Box(1) is False



# Generated at 2022-06-12 04:50:23.534123
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Lazy(lambda: 5) == Box(5).to_lazy()

# Generated at 2022-06-12 04:50:26.169358
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(10)

    assert box == box
    assert Box(5) == Box(5)
    assert Box(5) != Box(-10)


# Generated at 2022-06-12 04:50:33.593480
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy() == Box(3).to_lazy()
    assert not Box(3).to_lazy() == Box(None)
    assert not Box(3).to_lazy() == Box(None).to_lazy()
    assert Box(3) == Box(3)
    assert not Box(3) == Box(None)
    assert not Box(3) == Box(None).to_lazy()
    assert Box(3).to_lazy() != Box(None).to_lazy()
    assert not Box(None) == Box(None).to_lazy()
    assert not Box(None) == None
    assert not Box(None) == Box(box_none=True)
    assert not Box(None).to_lazy() == Box(box_none=True)
    assert not Box

# Generated at 2022-06-12 04:50:35.629404
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != 1
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-12 04:50:41.513007
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('1') == Box('1')
    assert Box('2') == Box('2')
    assert Box('1') != Box('2')
    assert Box(1) != Box('1')
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)
    assert Box(1) != Box(2)
    assert Box(1) != Box(None)
    assert Box(None) != Box(1)



# Generated at 2022-06-12 04:50:45.585985
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    actual_result = Box(4) == Box(4)
    assert actual_result

    actual_result = Box(4) == 4
    assert not actual_result

    actual_result = Box(4) == Box(5)
    assert not actual_result



# Generated at 2022-06-12 04:50:48.011340
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(0)
    assert Box(None) == Box(None)
    assert Box(0) != Box(1)



# Generated at 2022-06-12 04:50:50.249869
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(4).to_lazy().map(lambda a: a + 2).get() == 6

test_Box_to_lazy()

# Generated at 2022-06-12 04:50:51.901340
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)

    assert Box(3) != Box(4)


# Generated at 2022-06-12 04:51:11.625607
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 04:51:12.974249
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().to_result() == 10


# Generated at 2022-06-12 04:51:19.028154
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('hello') == Box('hello')
    assert Box('hello') != 'hello'
    assert Box('hello') != Box('world')
    assert Box(1) == Box(1)
    assert Box(1) != Box(1.0)
    assert Box(1) != Box(2)
    assert Box(1.0) == Box(1.0)
    assert Box(1.0) != Box(2.0)


# Generated at 2022-06-12 04:51:20.050038
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    assert box1.__eq__(Box(1))
    assert not box1.__eq__(Box(2))



# Generated at 2022-06-12 04:51:24.133930
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    result = Box(5).to_lazy()

    assert(result == Lazy(lambda: 5))


# Generated at 2022-06-12 04:51:26.683074
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    box = Box(123).to_lazy()

    assert box == Lazy(lambda: 123)

# Generated at 2022-06-12 04:51:35.061628
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('test') == Box('test')
    assert Box([10, 20, 30]) == Box([10, 20, 30])
    assert Box({'a': 1}) == Box({'a': 1})
    assert Box({10, 20, 30}) == Box({10, 20, 30})
    assert Box(1) != Box('test')
    assert Box(1) != Box([10, 20, 30])
    assert Box(1) != Box({'a': 1})
    assert Box(1) != Box({10, 20, 30})
    assert Box('test') != Box(1)
    assert Box('test') != Box([10, 20, 30])
    assert Box('test') != Box({'a': 1})
    assert Box('test') != Box({10, 20, 30})

# Generated at 2022-06-12 04:51:37.067307
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('Hello').to_lazy() == Lazy(lambda: 'Hello')



# Generated at 2022-06-12 04:51:40.066975
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == Box("1")



# Generated at 2022-06-12 04:51:41.882019
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:51:59.115576
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 04:52:09.814309
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy in class Box
    """

    from pymonet.monad import Monad, Functor
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    def assertion(lazy: Lazy) -> None:
        """
        Assertion for Lazy unit test.

        :param lazy: tested lazy instance
        :type lazy: Lazy[A]
        :returns: None
        :rtype: None
        """
        assert isinstance(lazy, Lazy)
        assert isinstance(lazy, Monad)
        assert isinstance(lazy, Functor)
        assert lazy == Lazy(lambda: 42)

    lazy = Box(42).to_lazy()
    assertion(lazy)


# Generated at 2022-06-12 04:52:16.025768
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box class.
    """

    # New Box with value "hello"
    box = Box('hello')

    assert isinstance(box, Box)
    assert box.value == 'hello'

    # Convert Box to Lazy
    lazy = box.to_lazy()

    assert isinstance(lazy, Box)
    assert lazy.value == 'hello'

# Generated at 2022-06-12 04:52:17.935160
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()

# Generated at 2022-06-12 04:52:21.100960
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(25).to_lazy().is_same(Lazy(lambda: 25))



# Generated at 2022-06-12 04:52:23.081903
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Unit tests for method to_maybe of class Box

# Generated at 2022-06-12 04:52:25.046666
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:52:26.378006
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 1).get() == Box(1).to_lazy().get()

# Generated at 2022-06-12 04:52:28.134119
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import lazy

    value = lazy(lambda: 1)

    assert Box(value).to_lazy() == value


# Generated at 2022-06-12 04:52:30.781950
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    box = Box(1)

    assert box.to_lazy().value() == box.value

# Generated at 2022-06-12 04:53:05.915458
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    test_value = 1
    lazy_value_func = Lazy.pure(test_value)
    test_box = Box(test_value)
    assert test_box.to_lazy() == lazy_value_func



# Generated at 2022-06-12 04:53:08.797769
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Unit

    assert Box(10).to_lazy() == Lazy(lambda: 10)
    assert Unit().to_lazy() == Lazy(Unit)

# Generated at 2022-06-12 04:53:13.309449
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box.to_lazy method

    :returns: None
    :rtype: NoneType
    """

    def assert_lazy(lazy, expected_value):
        """
        Invoke Lazy and compare result with expected_value

        :param lazy: lazy value to evaluate
        :type lazy: Lazy
        :param expected_value: expected value
        :type expected_value: Any
        :returns: None
        :rtype: NoneType
        """
        assert lazy.value() == expected_value

    assert_lazy(Box(1).to_lazy(), 1)

# Generated at 2022-06-12 04:53:20.752274
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy_list import LazyList

    lazy = Lazy(lambda: "value")
    assert lazy.map(lambda x: x.upper()).to_lazy() == Lazy(lambda: "VALUE")
    assert lazy.to_lazy().to_lazy() == Lazy(lambda: "value")

    lazy_list = LazyList([1, 2, 3, 4]).to_lazy()
    assert lazy_list == Lazy(lambda: 1).cons(Lazy(lambda: 2).cons(Lazy(lambda: 3).cons(Lazy(lambda: 4).cons(Lazy(lambda: LazyList())))))

# Generated at 2022-06-12 04:53:22.494727
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box('a').to_lazy() == Lazy(lambda: 'a')

# Generated at 2022-06-12 04:53:24.870893
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    a = Box(1)
    b = a.to_lazy()

    assert isinstance(b, Lazy)
    assert b.fold() == 1

# Generated at 2022-06-12 04:53:27.529438
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('#').to_lazy() == Lazy(lambda: '#'), 'Test Box to_lazy failed'


# Generated at 2022-06-12 04:53:29.701786
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    result = Box('Hello').to_lazy()
    assert isinstance(result, Lazy)
    assert result.force() == 'Hello'



# Generated at 2022-06-12 04:53:32.242811
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().eval() == Lazy(lambda: 42).eval()



# Generated at 2022-06-12 04:53:33.611801
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold(lambda: 2) == 1


# Generated at 2022-06-12 04:54:45.216908
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:54:47.210315
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import _Lazy

    assert Box(1).to_lazy() == _Lazy(lambda: 1)

# Generated at 2022-06-12 04:54:50.156334
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    test_box = Box(42)

    assert test_box.to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-12 04:54:58.111426
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    assert(Box(1).to_lazy() == Lazy(lambda: 1))
    assert(Box(lambda v: v + 1).to_lazy() == Lazy(Box(lambda v: v + 1).value))
    assert(Box(lambda v: v + 1).to_lazy().map(lambda f: f(1)) == Lazy(2))
    assert(Box(1).to_lazy().bind(lambda f: f()) == 1)
    assert(Box(lambda v: v + 1).to_lazy().bind(lambda f: f(1)) == 2)


# Generated at 2022-06-12 04:55:00.015133
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    assert box.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:55:02.352620
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    value = 10
    box = Box(value)

    # when
    lazy = box.to_lazy()

    # then
    assert lazy.fold(lambda: None) == value


# Generated at 2022-06-12 04:55:03.927825
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy() == Lazy(lambda: 42)



# Generated at 2022-06-12 04:55:06.509325
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Box
    """
    box = Box(lambda x: x + 1)
    lazy = box.to_lazy()
    assert lazy.fold()(2) == 3

# Generated at 2022-06-12 04:55:08.822485
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(42).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 42


# Generated at 2022-06-12 04:55:11.477027
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test case for `Box.to_lazy` function.

    :return: None
    :rtype: None
    """
    assert Box(10).to_lazy() == Lazy(lambda: 10)
