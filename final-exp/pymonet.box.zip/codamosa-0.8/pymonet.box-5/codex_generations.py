

# Generated at 2022-06-12 04:47:26.323007
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(4) == Box(4)
    assert Box(4) != Box(5)
    assert Box(4.0) == Box(4.0)
    assert Box('test') == Box('test')



# Generated at 2022-06-12 04:47:30.427709
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Box(lambda: "hello").to_lazy() == Lazy(lambda: lambda: "hello")
    assert Box(lambda: "hello").to_lazy() == Lazy(lambda: (lambda: "hello")())


# Generated at 2022-06-12 04:47:37.467373
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert_that(Box(5) == Box(5))
    assert_that(Box(5) == 5)
    assert_that(5 == Box(5))
    assert_that(Box(5) == Box(10), equal_to(False))
    assert_that(Box(5) == 10, equal_to(False))
    assert_that(5 == Box(10), equal_to(False))



# Generated at 2022-06-12 04:47:39.245728
# Unit test for method __eq__ of class Box
def test_Box___eq__():
  assert Box(1) != Box(2)
  assert Box(2) != Box(2)


# Generated at 2022-06-12 04:47:43.198448
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Checks that to_lazy method returns Lazy monad with returning value function.
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    assert Lazy(lambda: Try(5, is_success=True)) == Box(Try(5, is_success=True)).to_lazy()

# Generated at 2022-06-12 04:47:47.985885
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Create Lazy with function returning previous value of Box.

    :param lazy: Lazy with function returning previous value of Box
    :type lazy: Lazy
    :param result: result of function evaluated in Lazy
    :type result: int
    """
    lazy = Box(42).to_lazy()
    result = lazy.force()
    assert result == 42

# Generated at 2022-06-12 04:47:55.192897
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2.) == Box(2.)
    assert Box('monad') == Box('monad')
    assert Box([]) == Box([])
    assert Box(set()) == Box(set())
    assert Box(dict()) == Box(dict())
    assert Box(Box(1)) == Box(Box(1))

    assert Box(1) != Box(2)
    assert Box(2.) != Box(2)
    assert Box('monad') != Box('monads')
    assert Box([]) != Box([1])
    assert Box(set()) != Box(set([1]))
    assert Box(dict()) != Box(dict([('key', 2)]))
    assert Box(Box(1)) != Box(Box(2))


# Generated at 2022-06-12 04:47:58.335622
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:48:02.634232
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) != Box(2)
    assert Box(1) != Box(1)
    assert Box(1) != 1
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:48:05.188368
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == 2)



# Generated at 2022-06-12 04:48:10.085727
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy

    number = Box(4) # type: Box[int]
    assert number.value == 4
    assert number.to_lazy().fold() == 4


# Generated at 2022-06-12 04:48:11.347011
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(3).to_lazy()
    assert result.value() == 3

# Generated at 2022-06-12 04:48:16.470915
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1
    assert Box('a').to_lazy().value() == 'a'
    assert Box(['a', 'b']).to_lazy().value() == ['a', 'b']
    assert Box(True).to_lazy().value() == True
    assert Box(None).to_lazy().value() == None

# Generated at 2022-06-12 04:48:18.552322
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test for method __eq__ of class Box.
    """
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == None)


# Generated at 2022-06-12 04:48:21.820103
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(11)
    assert Box('str') == Box('str')



# Generated at 2022-06-12 04:48:23.903173
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 'foo')
    box = Box('foo')

    assert box.to_lazy() == lazy

# Generated at 2022-06-12 04:48:28.742544
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy_result = box.to_lazy()
    assert lazy_result == Lazy(lambda: box.value)
    assert lazy_result.value == box.value


# Generated at 2022-06-12 04:48:32.292016
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy
    box_value = Box(3)
    assert box_value.to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 04:48:39.193893
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def _lazy_equal(lazy: Lazy[T], value: T) -> bool:
        return lazy.force() == value

    assert _lazy_equal(Box(10).to_lazy(), 10)
    assert _lazy_equal(Box(10.5).to_lazy(), 10.5)
    assert _lazy_equal(Box([]).to_lazy(), [])
    assert _lazy_equal(Box(['x']).to_lazy(), ['x'])
    assert _lazy_equal(Box((1, '2', [])).to_lazy(), (1, '2', []))
    assert _lazy_equal(Box({'a': 10}).to_lazy(), {'a': 10})
    assert _lazy_

# Generated at 2022-06-12 04:48:41.665012
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == 1)


# Generated at 2022-06-12 04:48:45.947130
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    res = Box(3).to_lazy()

    assert res.value() == 3


# Generated at 2022-06-12 04:48:50.185553
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # given
    box_a = Box('42')
    box_b = Box('42')

    # when
    eq_result = box_a == box_b

    # then
    assert eq_result



# Generated at 2022-06-12 04:48:52.379986
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 04:48:56.693112
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(10).to_lazy().run() == 10
    assert Box(0).to_lazy().run() == 0
    assert Box(None).to_lazy().run() is None
    assert Box('str').to_lazy().run() == 'str'


# Generated at 2022-06-12 04:49:04.329233
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # fail if equal
    assert Box(0) == Box(0)

    assert Box(-0.0) == Box(-0.0)

    assert Box(1) == Box(1)

    assert Box('a') == Box('a')

    assert Box(False) == Box(False)

    assert Box(True) == Box(True)

    assert Box(()) == Box(())

    assert Box((1, 2)) == Box((1, 2))

    assert Box([]) == Box([])

    assert Box([1, 2]) == Box([1, 2])

    assert Box({}) == Box({})

    assert Box({1: 2}) == Box({1: 2})

    assert Box(set()) == Box(set())

    assert Box(set([1, 2])) == Box(set([1, 2]))

    # raise if not

# Generated at 2022-06-12 04:49:07.170804
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box([]) == Box({}) == Box(None) == Box('') == Box(()), "Equality must works correctly"


# Generated at 2022-06-12 04:49:11.925318
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(3)
    assert Box(1) != object()  # type: ignore
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box([1, 2, 3]) != Box([1, 2, 4])



# Generated at 2022-06-12 04:49:13.669666
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-12 04:49:16.557316
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(1)
    b = Box(2)
    c = Box(1)

    assert not (a == b)
    assert a == c



# Generated at 2022-06-12 04:49:18.857606
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:49:28.062482
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.functors_test import eq_test_binary_operator
    from pymonet.functors import Box

    eq_test_binary_operator(Box(1), Box(1), '__eq__', is_equal=True)
    eq_test_binary_operator(Box(1), Box(2), '__eq__', is_equal=False)
    eq_test_binary_operator(Box(1), 1, '__eq__', is_equal=False)



# Generated at 2022-06-12 04:49:31.771038
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    assert Box('test') == Box('test')
    assert Box('test') != Box('test2')
    assert Box('test') != None

# Generated at 2022-06-12 04:49:34.490417
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == object()



# Generated at 2022-06-12 04:49:43.235177
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.validation import Validation

    def a():
        return "a"

    assert Box(a).to_lazy() == Lazy(a)
    assert Box(Try(1, is_success=True)).to_lazy() == Lazy(lambda: Try(1, is_success=True))
    assert Box(Right(1)).to_lazy() == Lazy(lambda: Right(1))
    assert Box(Validation.success(1)).to_lazy() == Lazy(lambda: Validation.success(1))



# Generated at 2022-06-12 04:49:45.778472
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)
    assert Box(1) != Box(2.0)



# Generated at 2022-06-12 04:49:48.177253
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:49:49.779428
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:49:51.240839
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(2).to_lazy().unwrap() == 2

# Generated at 2022-06-12 04:49:53.168298
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box('str')
    assert not Box(1) == object()

# Generated at 2022-06-12 04:49:57.198717
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box to_lazy function.
    """
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == \
        Lazy(func=lambda: 1)



# Generated at 2022-06-12 04:50:07.956223
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    assert Box(1).to_lazy().eval() == 1

# Generated at 2022-06-12 04:50:10.387815
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:50:12.772936
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:50:15.596153
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test for method eq of class for correct work
    """
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:50:17.594896
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:50:23.574818
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 1

    func = f()
    left = Lazy(lambda: func)
    right = Box(func)
    assert left.bind(lambda x: Lazy(lambda: x)) == right.to_lazy().bind(lambda x: Lazy(lambda: x))
    assert left == right.to_lazy()

# Generated at 2022-06-12 04:50:24.981065
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy()

# Generated at 2022-06-12 04:50:26.399677
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None



# Generated at 2022-06-12 04:50:29.164918
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for Box to_lazy method.

    :returns: None
    :rtype: None
    """
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:50:31.088967
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')


# Generated at 2022-06-12 04:50:52.271313
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(10).to_try() == Try(10, is_success=True)

    assert Box(10).to_validation() == Validation.success(10)

# Generated at 2022-06-12 04:50:57.260745
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box('test') == Box('test')
    assert Box(boxed) == Box(boxed)
    assert Box(lambda x: x + 1) == Box(lambda x: x + 1)



# Generated at 2022-06-12 04:50:58.967154
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('value').to_lazy().get_value() == 'value'


# Generated at 2022-06-12 04:51:04.518587
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(lambda x: x * 2)
    lazy = box.to_lazy()
    assert lazy.is_instance_of(Lazy)
    assert lazy.is_functor()
    assert lazy.is_monad()
    assert lazy()(4) == 8
    assert lazy.to_string() == "Lazy[function]"


# Generated at 2022-06-12 04:51:05.806031
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('1') == Box('1')



# Generated at 2022-06-12 04:51:08.321530
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)


# Unit tests for method __str__ of class Box

# Generated at 2022-06-12 04:51:14.112026
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box(2)
    box_2 = Box(2)
    box_3 = Box(1)
    box_4 = Box('2')

    assert box_1 == box_2

    assert box_1 != box_3
    assert box_2 != box_3

    assert box_1 != box_4
    assert box_2 != box_4
    assert box_3 != box_4



# Generated at 2022-06-12 04:51:18.980391
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover

    assert (Box(1) == Box(1)) is True
    assert (Box('test') == Box('test')) is True
    assert (Box(1) == Box('test')) is False
    assert (Box(1) == None) is False
    assert (Box('test') == 1) is False

# Generated at 2022-06-12 04:51:20.560071
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    value = Box(3)
    assert Box(3) == value
    assert Box(3) != 4



# Generated at 2022-06-12 04:51:26.002005
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1.0) == Box(1.0)
    assert Box(object()) == Box(object())
    assert Box(True) == Box(True)
    assert Box(None) == Box(None)



# Generated at 2022-06-12 04:52:03.074595
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    return

# Generated at 2022-06-12 04:52:05.790396
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Tests for method to_lazy of class Box
    """
    assert Box(5).to_lazy().fold() == 5


# Generated at 2022-06-12 04:52:08.623224
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 04:52:09.898421
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(1).to_lazy()

    assert result.value() == 1

# Generated at 2022-06-12 04:52:17.403934
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1
    assert Box('s').to_lazy().value() == 's'
    assert Box(2.5).to_lazy().value() == 2.5
    assert Box({'a': 1}).to_lazy().value() == {'a': 1}
    assert Box([1, 2]).to_lazy().value() == [1, 2]
    assert Box((1, 2)).to_lazy().value() == (1, 2)



# Generated at 2022-06-12 04:52:19.401010
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().eval() == 1

# Generated at 2022-06-12 04:52:21.902102
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box: Box[int] = Box(1)

    assert box.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:52:23.034046
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) == Box(1))



# Generated at 2022-06-12 04:52:25.010825
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 04:52:27.027263
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert not Box(10) == Box(20)
    assert not Box(10) == object


# Generated at 2022-06-12 04:53:07.096177
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1

# Generated at 2022-06-12 04:53:08.229279
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(0).to_lazy().value() == 0

# Generated at 2022-06-12 04:53:14.284327
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for lazy evaluation
    """
    from pymonet.monad_try import Try

    starting_value = 0

    def box_function(value):
        return Box(value + 1)

    def try_function(value):
        return Try(value + 1, is_success=True)

    def lazy_function(value):
        return lazy(box_function)(value)

    def lazy_function_try(value):
        return lazy(try_function)(value)

    def try_evaluation_function(boxed_value):
        return boxed_value.bind(box_function).bind(box_function).bind(box_function).bind(box_function).value

    def try_evaluation_function_try(boxed_value):
        return boxed_value.bind(try_function).bind(try_function).bind

# Generated at 2022-06-12 04:53:17.204752
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None
    assert Box(1) != Box(None)



# Generated at 2022-06-12 04:53:19.617799
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    value = 'test'
    box = Box(value)

    # Assert
    assert callable(box.to_lazy().value)
    assert value == box.to_lazy().value()


# Generated at 2022-06-12 04:53:22.564901
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert not Box(1).__eq__(None)
    assert not Box(1).__eq__(1)
    assert not Box(1).__eq__('str')
    assert Box(1).__eq__(Box(1))



# Generated at 2022-06-12 04:53:25.280284
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():   # pragma: no cover
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(None).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 04:53:27.365246
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(99) == Box(99)
    assert Box(99) != Box(999)


# Generated at 2022-06-12 04:53:30.312117
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.monad_list import List

    list_of_boxes = List([Box(1), Box(2)])
    assert list_of_boxes.map(lambda x: x.to_lazy()).item == [1, 2]

# Generated at 2022-06-12 04:53:33.921328
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box('test')
    box2 = Box('test')
    assert box1 == box2
    box1 = Box('test')
    box2 = Box('test2')
    assert box1 != box2



# Generated at 2022-06-12 04:54:20.447054
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().get_or(None) == 10
    assert Box("Hello, World!").to_lazy().get_or("") == "Hello, World!"

# Generated at 2022-06-12 04:54:23.593869
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    from pymonet.lazy import Lazy
    box = Box(5)
    expected_lazy = Lazy(lambda: 5)

    # When
    lazy = box.to_lazy()

    # Then
    assert lazy == expected_lazy


# Generated at 2022-06-12 04:54:26.581386
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().force() == 2

# Generated at 2022-06-12 04:54:28.060787
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 10
    box = Box(value)

    assert box.to_lazy().value() == value

# Generated at 2022-06-12 04:54:29.326356
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(3).to_lazy().force() == 3

# Generated at 2022-06-12 04:54:31.866272
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as Z

    def square(x):
        def _square():
            return x * x

        return Z.Lazy(_square)

    assert Z.Lazy(lambda: 4) == Box(4).to_lazy().map(square)

# Generated at 2022-06-12 04:54:37.318197
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    from pymonet.lazy import Lazy

    assert isinstance(Box(5).to_lazy(), Lazy)
    assert Box(5).to_lazy().fold() == 5
    assert Box(5).to_lazy().bind(lambda x: x * 5).fold() == 25
    assert Lazy(lambda: Box(5).value).fold() == 5



# Generated at 2022-06-12 04:54:42.070993
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.function import compose
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

    assert compose(
        Box.to_lazy,
        lambda x: Box(2 * x),
        lambda x: Box(x + 1),
        Box.to_lazy
    )(5) == Lazy(lambda: (2 * (5 + 1)))


# Generated at 2022-06-12 04:54:43.743720
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:54:44.928995
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold() == 1

# Generated at 2022-06-12 04:56:34.731195
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert (Box(25).to_lazy() == Lazy(lambda: 25))



# Generated at 2022-06-12 04:56:38.296078
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy
    from pymonet.exceptions import MaybeError

    value = 5
    lazy_result = Lazy(lambda: value)
    box_result = Box(value)
    assert box_result.to_lazy() == lazy_result

# Generated at 2022-06-12 04:56:39.154561
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 42)

    assert Box(42).to_lazy() == lazy

# Generated at 2022-06-12 04:56:41.353190
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    lazy = box.to_lazy()
    assert lazy.eval() == 1


# Generated at 2022-06-12 04:56:43.163286
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 'test'
    result = Box(value).to_lazy()
    assert result.value() == value

# Generated at 2022-06-12 04:56:50.908278
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for :class:`Box` class and its methods.

    Tests:

    - :meth:`Box.to_lazy`
    """
    from pymonet.test import GT
    from pymonet.test import check_laws

    from pymonet.monad_laws.lazy import lazy_right_identity_law, lazy_left_identity_law, lazy_associativity_law,\
        lazy_map_law

    check_laws(GT, Box, 'Box', [lazy_right_identity_law, lazy_left_identity_law, lazy_associativity_law,
                                lazy_map_law], is_lazy=True)

# Generated at 2022-06-12 04:56:52.673082
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Lazy(lambda: Box(1)).flat_map(lambda x: x.to_lazy()).force()

    assert Box(1) == lazy

# Generated at 2022-06-12 04:56:54.382160
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:56:55.508916
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(1).to_lazy()
    assert lazy.value() == 1

# Generated at 2022-06-12 04:56:57.790776
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    value = 1
    box = Box(value)

    # Act
    lazy = box.to_lazy()

    # Assert
    assert lazy.value() == value

