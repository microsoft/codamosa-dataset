

# Generated at 2022-06-12 04:47:28.733563
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box([1, 2]) == Box([1, 2])

    assert Box(1) != Box(2)
    assert Box([1, 2]) != Box([3, 4])



# Generated at 2022-06-12 04:47:39.876721
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(None) == Box(None)
    assert Box(None) != None
    assert Box(None) != 1
    assert Box(1) != None
    assert Box(1) != Box(None)
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box(2) != Box(1)
    assert Box(1) != Box(2)
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')
    assert Box('b') != Box('a')

    class MyClass(object):
        def __init__(self, value: int) -> None:
            self.value = value


# Generated at 2022-06-12 04:47:41.406066
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None


# Generated at 2022-06-12 04:47:42.985778
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:47:46.050982
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test function for equality of Box
    """
    assert Box(0) == Box(0)
    assert Box((1, 2)) == Box((1, 2))
    assert Box(0) != Box(1)



# Generated at 2022-06-12 04:47:47.903300
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 1).force() == Box(1).to_lazy().force()

# Generated at 2022-06-12 04:47:49.453045
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)



# Generated at 2022-06-12 04:47:51.751605
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box('abc') == Box('abc')
    assert Box(10) != Box(20)
    assert Box('abc') != Box('abcd')
    assert Box(10) != '10'



# Generated at 2022-06-12 04:47:55.355515
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    assert (box1 == box2)
    assert (box1 != Box('a'))
    assert (box1 != 'a')



# Generated at 2022-06-12 04:47:58.700268
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == 2


# Generated at 2022-06-12 04:48:04.407883
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)
    assert not Box(1) == Box(2)


# Generated at 2022-06-12 04:48:08.549791
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def put_string(string: str) -> Box[str]:
        print(string)
        return Box(string)

    monad = Box(42).to_lazy()
    assert monad.fold(lambda x: None) == 42


# Generated at 2022-06-12 04:48:13.680222
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    unit_right = Box("right")
    unit_right_equals = Box("right")
    unit_left = Box("left")

    assert (unit_right == unit_right_equals)
    assert (unit_right is not unit_right_equals)
    assert (unit_right != unit_left)
    assert (unit_right_equals != unit_left)


# Generated at 2022-06-12 04:48:17.069720
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # given
    left_box = Box(1)
    right_box = Box(2)

    # when
    is_equals = left_box == right_box

    # then
    assert is_equals is False



# Generated at 2022-06-12 04:48:22.587918
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a_box_one = Box(1)
    a_box_two = Box(1)
    b_box_one = Box(2)
    assert a_box_one == a_box_two
    assert a_box_one != b_box_one
    assert a_box_one != None
    assert a_box_one != [1, 2]


# Generated at 2022-06-12 04:48:33.440378
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Maybe(None).to_lazy() == Lazy(lambda: Maybe(None))
    assert Maybe(1).to_lazy() == Lazy(lambda: Maybe(1))
    assert Maybe(2).to_lazy() == Lazy(lambda: Maybe(2))
    assert Maybe(3).to_lazy() == Lazy(lambda: Maybe(3))
    assert Maybe(4).to_lazy() == Lazy(lambda: Maybe(4))
    assert Maybe(5).to_lazy() == Lazy(lambda: Maybe(5))
    assert Maybe(6).to_lazy() == Lazy(lambda: Maybe(6))
    assert Maybe(7).to_lazy() == Lazy(lambda: Maybe(7))
   

# Generated at 2022-06-12 04:48:37.920219
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert Box(None) == Box(None)
    assert Box(True) == Box(True)
    assert not (Box(True) == Box(False))
    assert Box('123') == Box('123')
    assert not (Box('123') == Box('1234'))
    assert Box('123') == Box('123')
    assert not (Box('123') == Box('1234'))



# Generated at 2022-06-12 04:48:41.333090
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(1).to_lazy()

    assert isinstance(lazy, Lazy)

    assert lazy.value() == 1



# Generated at 2022-06-12 04:48:43.648747
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(3)
    assert box == Box(3)
    assert box != Box(4)
    assert box != 'hello'



# Generated at 2022-06-12 04:48:46.667129
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # given
    box = Box(1)

    # when
    lazy = box.to_lazy()

    # then
    assert isinstance(lazy, Lazy)
    assert callable(lazy.wrapped)


# Generated at 2022-06-12 04:48:55.432312
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert(Box(5).to_lazy() == Lazy(lambda: 5))

# Generated at 2022-06-12 04:48:57.059887
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)



# Generated at 2022-06-12 04:48:59.974974
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    box_1 = Box(1)
    box_2 = Box(1)
    box_3 = Box(2)
    assert box_1 == box_2
    assert box_1 != box_3


# Generated at 2022-06-12 04:49:01.797390
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:49:06.365104
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == Box('abc')
    assert Box('abc') == Box('abc')
    assert not Box('abc') == Box('cba')


# Generated at 2022-06-12 04:49:08.741222
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 04:49:13.199185
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)

    assert box1 == box2, "Box[value=1] equals Box[value=1] must be True"
    assert not box1 == box3, "Box[value=1] equals Box[value=2] must be False"



# Generated at 2022-06-12 04:49:17.078749
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('value') != Box('other value')
    assert Box(1) != Box('1')
    assert Box({'key': 'value'}) != Box({'key': 'other value'})



# Generated at 2022-06-12 04:49:18.338467
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(7) == Box(7)


# Generated at 2022-06-12 04:49:20.493887
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(12) == Box(12)
    assert Box(12) != Box(21)
    assert Box(12) != 21



# Generated at 2022-06-12 04:49:29.305372
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:49:31.210371
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    x = Box('value')

    assert x == Box('value')



# Generated at 2022-06-12 04:49:36.471266
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    # two boxes with same integer value should be equal
    assert Box(123) == Box(123)

    # two boxes with different integer value should be not equal
    assert Box(123) != Box(321)

    # box and another object should not be equal
    assert Box(123) != "123"



# Generated at 2022-06-12 04:49:38.808678
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != object()

# Generated at 2022-06-12 04:49:40.640070
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))



# Generated at 2022-06-12 04:49:42.950553
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = box.to_lazy()

    assert lazy.is_same(Lazy(lambda: 1))

# Generated at 2022-06-12 04:49:46.306992
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(11) == Box(11)
    assert Box(12) != Box(11)
    assert Box(11) != 'Box[value=11]'
    assert Box(11) != '11'



# Generated at 2022-06-12 04:49:50.319278
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Box(3000).to_lazy() == Lazy(lambda: 3000)

    lazy_box = Try(lambda a: a + 1, is_success=True).to_lazy()
    assert lazy_box.value == 3000

# Generated at 2022-06-12 04:49:51.913060
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(42)
    assert box.map(lambda value: value + 1).to_lazy().force() == 43

# Generated at 2022-06-12 04:49:56.145718
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box.
    """
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) == 1
    assert Box(1) != 2
    assert Box(1) != None



# Generated at 2022-06-12 04:50:11.259793
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:50:15.110572
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.

    :return: nothing
    :rtype: None
    """

    fnc = Box(10).to_lazy()
    assert fnc.value() == 10


# Generated at 2022-06-12 04:50:17.552855
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(object()) == Box(object())
    assert not Box(object()) == Box(object())
    assert not Box(object()) == None  # type: ignore


# Generated at 2022-06-12 04:50:24.706179
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('') == Box('')
    assert Box('1') != Box('')
    assert Box(1) != Box('1')
    assert Box(1) != Box(1.0)
    assert Box([]) != Box('')
    assert Box(1) == Box(1)
    assert Box(1.0) == Box(1.0)
    assert Box([]) != Box([])
    assert Box({}) != Box({})



# Generated at 2022-06-12 04:50:28.750825
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box("abc")
    box2 = Box("abc")
    box3 = Box("xyz")
    assert box1 == box2
    assert not (box1 == box3)
    assert not (box2 == box3)
    assert not (box1 == "abc")



# Generated at 2022-06-12 04:50:30.985812
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from nose.tools import assert_equals
    from pymonet.lazy import Lazy

    assert_equals(Box(1).to_lazy(), Lazy(lambda: 1))


# Generated at 2022-06-12 04:50:33.520261
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.pdq_test import assert_that, equal_to
    from pymonet.lazy import Lazy

    assert_that(
        Box(20).to_lazy() == Lazy(lambda: 20),
        'Box should be transformed into Lazy'
    )


# Generated at 2022-06-12 04:50:37.800378
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 10
    box = Box(value)

    lazy = box.to_lazy()
    lazy_func = lazy.value

    initial_value = lazy_func.value

    assert not lazy.is_folded
    assert callable(lazy_func)
    assert isinstance(lazy, Lazy)
    assert value == initial_value

# Generated at 2022-06-12 04:50:40.116945
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))



# Generated at 2022-06-12 04:50:41.936634
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))


# Generated at 2022-06-12 04:50:54.664937
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().fold() == 10



# Generated at 2022-06-12 04:50:55.609169
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('1') != 1



# Generated at 2022-06-12 04:50:58.832759
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:51:02.261434
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Test to_lazy of class Box"""
    result = Box(42).to_lazy()

    assert isinstance(result, Lazy) is True
    assert result.get() == 42


# Generated at 2022-06-12 04:51:04.651807
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Arrange
    box = Box(10)

    # Act
    is_equal = box == Box(10)

    # Assert
    assert is_equal



# Generated at 2022-06-12 04:51:06.321928
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    assert box.to_lazy().fold(lambda: 1) == 1

# Generated at 2022-06-12 04:51:08.462819
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)


# Generated at 2022-06-12 04:51:13.876550
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    For this method we have only one case
    """
    # Arrange
    value = 2
    box1 = Box(value)
    box2 = Box(value)
    box3 = Box(value + 1)

    # Act & Assert
    assert box1 == box2
    assert not box1 == box3
    assert not box1 == 2
    assert not box1 == '2'


# Generated at 2022-06-12 04:51:15.687102
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(100).to_lazy().value() == 100



# Generated at 2022-06-12 04:51:18.201659
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('instance of Box') == Box('instance of Box')
    assert Box(42) != Box(24)
    assert Box(42) != 'instance of Box'



# Generated at 2022-06-12 04:51:42.838684
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    b1 = Box('test')

    assert b1 == b1
    assert b1 != Box(1)
    assert b1 != 'test'
    assert b1 != None


# Generated at 2022-06-12 04:51:45.770370
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    assert Box(20) == Box(20)


# Generated at 2022-06-12 04:51:48.118695
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    _lazy = Box(42).to_lazy()

    assert _lazy.is_folded()
    assert _lazy.__str__() == 'Lazy[value=42]'



# Generated at 2022-06-12 04:51:57.954903
# Unit test for method __eq__ of class Box

# Generated at 2022-06-12 04:51:59.159295
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().get() == 1



# Generated at 2022-06-12 04:52:01.639497
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box('123').to_lazy() == Lazy(lambda: '123')



# Generated at 2022-06-12 04:52:03.030149
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:52:05.381019
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-12 04:52:06.747543
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:52:10.021835
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.maybe import Maybe

    assert Box(1) == Box(1)
    assert Maybe(1) == Maybe(1)
    assert Box(1) != Maybe(1)


# Generated at 2022-06-12 04:52:57.934092
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:53:01.021937
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(1) == Box(1)

    assert Box(1) != Box(2)

    assert Box(1) != Box("a")



# Generated at 2022-06-12 04:53:06.720684
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def lazy_fib(x):
        return Lazy.lazy(lambda: Lazy.lazy(lambda: x) if x < 2 else lazy_fib(x-1) + lazy_fib(x-2))

    assert Box(5).to_lazy().map(lazy_fib).map(lambda x: x.value()).value() == 5

# Generated at 2022-06-12 04:53:08.168512
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) == Box(1.0)
    assert Box(1) != Box(2)


# Generated at 2022-06-12 04:53:11.044377
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_monad_with_value = Box(5).to_lazy()
    assert isinstance(lazy_monad_with_value, Lazy)
    assert lazy_monad_with_value() == 5

# Generated at 2022-06-12 04:53:14.949670
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)

    assert Box([0, 1, 2]) == Box([0, 1, 2])

    assert Box([0, 1, 2]) != Box([0, 2, 1])

    assert Box(10) != Box(None)

    assert Box(None) != Box(10)



# Generated at 2022-06-12 04:53:18.742213
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    # When Try(1) equals Maybe(1) not expected behaviour
    assert Try(1) != Maybe(1)

    # When Maybe(1) equals Try(1) not expected behaviour
    assert Maybe(1) != Try(1)


# Generated at 2022-06-12 04:53:24.829083
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Box with same value should be equal
    assert Box(1) == Box(1) is True

    # Box with different value should not be equal
    assert Box(1) == Box(2) is False

    # Box with another type value should not be equal
    assert Box(1) == Box('1') is False

    # Identical boxes should be equal
    x = Box(1)
    assert x == x

    # Box should not be equal to None
    assert x != None

    # Box should not be equal to any other type
    assert x != 1
    assert x != '1'



# Generated at 2022-06-12 04:53:26.967792
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')


# Generated at 2022-06-12 04:53:28.772474
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_lazy import Lazy

    assert Lazy(lambda: 42).equals(Box(42).to_lazy())


# Generated at 2022-06-12 04:54:21.924057
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy().value() == 1
    assert isinstance(Box(1).to_lazy(), Lazy)



# Generated at 2022-06-12 04:54:26.633023
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box('a') == Box('a')
    assert Box('b') != Box('a')
    assert Box(2) != Box('a')
    assert Box(3) != 3



# Generated at 2022-06-12 04:54:28.962691
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None  # noqa


# Generated at 2022-06-12 04:54:31.259131
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.

    :return: nothing
    :rtype: None
    """
    assert Box(3).to_lazy().value() == 3


# Generated at 2022-06-12 04:54:32.490371
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(8)
    assert box.to_lazy().get() == 8

# Generated at 2022-06-12 04:54:37.394670
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(42).to_lazy()

    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.value, Callable)
    assert lazy.value() == 42
    assert lazy.value() == 42



# Generated at 2022-06-12 04:54:38.627464
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)



# Generated at 2022-06-12 04:54:40.079127
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('foo') == Box('foo') and Box('foo') != Box('bar')



# Generated at 2022-06-12 04:54:42.215533
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) == Box('1')



# Generated at 2022-06-12 04:54:43.581998
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)


# Generated at 2022-06-12 04:56:51.630085
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Return not evaluated Lazy monad with function returning previous value.

    :returns: not evaluated Lazy monad with function returning previous value.
    :rtype: Lazy[Function(() -> A)]
    """
    from pymonet.lazy import Lazy

    box = Box(5)
    assert isinstance(box.to_lazy(), Lazy)
    assert box.to_lazy().get_value()() == 5


# Generated at 2022-06-12 04:56:53.949645
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(10) == Box(10)
    assert Box(10) != Box(20)
    assert Box(10) != Box([1, 2, 3])



# Generated at 2022-06-12 04:56:54.610503
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)

# Generated at 2022-06-12 04:56:58.941505
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box.
    """
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_lazy().bind(lambda x: x + 1) == 2
    assert Box(1).to_lazy().bind(lambda x: x + 1).bind(lambda x: x + 1) == 3



# Generated at 2022-06-12 04:57:04.765861
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    Functor.laws_identity(Functor, Box)
    Functor.laws_composition(Functor, Box)

    Monad.laws_left_identity(Monad, Box)
    Monad.laws_right_identity(Monad, Box)
    Monad.laws_associativity(Monad, Box)

    assert Lazy(lambda: Box(1)).value().value == 1

# Generated at 2022-06-12 04:57:06.646840
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:57:08.733174
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-12 04:57:12.228262
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(1) != Box(2)


if __name__ == '__main__':  # pragma: no cover
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 04:57:13.686555
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert not (Box(10) == Box(11))



# Generated at 2022-06-12 04:57:16.305894
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(1)
    b = Box(2)
    c = Box(1)

    assert not a == b
    assert a == c

# Unit Test For Method __str__ of Class Box