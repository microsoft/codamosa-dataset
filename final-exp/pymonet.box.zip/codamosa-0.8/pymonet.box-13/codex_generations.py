

# Generated at 2022-06-12 04:47:30.364696
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad import compose

    box = Box(2)
    lazy = Lazy(lambda: 2)

    assert box.to_lazy() == lazy
    assert compose(box.to_lazy(), lambda x: x + 2, Lazy.force)() == 4

# Generated at 2022-06-12 04:47:33.435907
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(123) == Box(123)
    assert Box('test') == Box('test')



# Generated at 2022-06-12 04:47:41.601116
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box("hello") != Box("hello world")
    assert Box("hello") == Box("hello")
    assert Box("hello world") != Box("hello")
    assert Box({"a": "b"}) != Box({"a": "b", "c": "d"})
    assert Box({"a": "b"}) == Box({"a": "b"})
    assert Box({"a": "b", "c": "d"}) != Box({"a": "b"})


# Generated at 2022-06-12 04:47:42.881518
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert(Box(1) == Box(1))



# Generated at 2022-06-12 04:47:47.992948
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) != "foo"
    assert Box("foo") == Box("foo")
    assert Box(2) == Box(2)
    assert Box("foo") != Box(2)
    assert Box(2) != Box("foo")
    assert Box(None) == Box(None)
    assert Box(1) != None
    assert Box(2.0) == Box(2)



# Generated at 2022-06-12 04:47:49.512142
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1) is True
    assert Box(0) == Box(1) is False


# Generated at 2022-06-12 04:47:52.925801
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box(1) != Box(None)



# Generated at 2022-06-12 04:47:56.451791
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    value = 'test_value'
    box = Box(value)

    assert Lazy(lambda: value) == box.to_lazy()



# Generated at 2022-06-12 04:47:58.746329
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(None) == Box(None)
    assert not Box(None) == Box(1)
    assert not Box(None) == None


# Generated at 2022-06-12 04:48:03.838948
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  #pragma: no cover
    """
    Test for method to_lazy of class Box.

    Should return Lazy monad with previous value of Box.
    """
    from pymonet.lazy import Lazy

    assert Box(12).to_lazy() == Lazy(lambda: 12)

# Generated at 2022-06-12 04:48:09.878896
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(2) == Box(1))



# Generated at 2022-06-12 04:48:13.301034
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """ Test that returns from method to_lazy of class Box is instance of type Lazy """
    from pymonet.lazy import Lazy
    assert isinstance(Box(4).to_lazy(), Lazy)


# Generated at 2022-06-12 04:48:14.649089
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert not Box(3) == Box(4)
    assert not Box(3) == Maybe.just(3)
    assert not Box(3) == None


# Generated at 2022-06-12 04:48:17.025207
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-12 04:48:19.537680
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(5) == Box(5)

    assert not (Box(4) == Box(5))

    assert not (Box(5) == None)

# Generated at 2022-06-12 04:48:23.061480
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('a')
    assert Box(1) != 1
    assert Box(1) != None



# Generated at 2022-06-12 04:48:28.331111
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functors import unit

    assert unit(1).to_lazy() == Lazy(lambda: 1)
    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)

# Generated at 2022-06-12 04:48:30.364039
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1) is True
    assert Box(1) == Box(2) is False
    assert Box(1) == Box('a') is False
    assert Box(1) == 1 is False



# Generated at 2022-06-12 04:48:31.762922
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    f = lambda: 1

    assert Box(1).to_lazy() == Lazy(f)

# Generated at 2022-06-12 04:48:33.791431
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()

# Generated at 2022-06-12 04:48:41.845369
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(5).to_lazy() == Box(5).to_lazy().to_lazy().to_lazy().to_lazy().value()
    assert Box(5).to_lazy().value() == 5

# Generated at 2022-06-12 04:48:43.385856
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().fold() == 42



# Generated at 2022-06-12 04:48:47.029169
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def first_pow_two(number: int) -> int:
        return pow(2, number)

    lazy_box = Box(2).to_lazy()

    assert lazy_box.value == first_pow_two(2)
    assert isinstance(lazy_box, Box)

# Generated at 2022-06-12 04:48:49.947599
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box("1")


# Generated at 2022-06-12 04:48:52.135705
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(100)

    lazy = box.to_lazy()
    assert lazy.value() == box.value

# Generated at 2022-06-12 04:48:54.687000
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert Box(1) != "Box[value=1]"



# Generated at 2022-06-12 04:48:57.059618
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:48:59.974744
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box('a') == Box('a')
    assert Box(10) != Box(20)
    assert Box(10) != 10
    assert Box(10) != 10



# Generated at 2022-06-12 04:49:01.797567
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    data = Box(123)
    lazy = data.to_lazy()

    assert lazy.value() == 123

# Generated at 2022-06-12 04:49:04.116867
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:49:17.309672
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # given
    result_value = 10
    box = Box(result_value)

    # when
    lazy = box.to_lazy()

    # then
    assert isinstance(lazy, Lazy)
    assert lazy.get()() == result_value



# Generated at 2022-06-12 04:49:22.638620
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Check equal two empty Boxs
    assert Box(1) == Box(1)

    # Check not equal two empty Boxs with different values
    assert Box(1) != Box(2)

    # Check not equal two empty Boxs with different values
    assert Box(1) != Box(2)

    # Check not equal Box with other type
    assert Box(1) != 1



# Generated at 2022-06-12 04:49:24.733323
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:49:28.718049
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy


    def lazy_compute(value: int) -> int:
        return value


    lazy_value = Lazy(lambda: lazy_compute(10))
    box_value = Box(10)
    assert lazy_value == box_value.to_lazy()

# Generated at 2022-06-12 04:49:36.736396
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box('abc') == Box('abc')
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box(Box(1)) == Box(Box(1))

    assert Box(1) != 1
    assert Box(1) != Box(2)
    assert Box(1) != Box('abc')
    assert Box(1) != Box([1, 2, 3])
    assert Box(1) != Box(Box(2))


# Generated at 2022-06-12 04:49:39.656259
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != [1]

# Generated at 2022-06-12 04:49:41.574931
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # when
    result = Box(1) == Box(1)

    # then
    assert result is True


# Generated at 2022-06-12 04:49:50.914260
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert isinstance((Box(2) + 4).to_lazy(), Lazy)
    assert (Box(2) + 4).to_lazy() == Lazy(lambda: 6)
    assert (Box(2) * 4).to_lazy() == Lazy(lambda: 8)
    assert (Box(2) - 4).to_lazy() == Lazy(lambda: -2)
    assert (Box(2) / 4).to_lazy() == Lazy(lambda: 0.5)
    assert (Box(2) // 4).to_lazy() == Lazy(lambda: 0)
    assert (Box(2) ** 4).to_lazy() == Lazy(lambda: 16)

# Generated at 2022-06-12 04:49:52.598292
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Box(lambda: 2).to_lazy()

# Generated at 2022-06-12 04:49:58.293307
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box("Hello") == Box("Hello")
    assert Box(True) == Box(True)
    assert Box(False) == Box(False)
    assert Box(1) != Box(2)
    assert Box("Hello") != Box("World")
    assert Box(True) != Box(False)
    assert Box(False) != Box(True)

# Generated at 2022-06-12 04:50:18.978904
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Success
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('b') != Box(5)
    assert Box(None) != Box(5)



# Generated at 2022-06-12 04:50:24.248156
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(None) == Box(None)
    assert Box(None) == Box(None)
    assert Box("some string") == Box("some string")
    assert Box("some string") == Box("some string")
    assert Box(12) == Box(12)
    assert Box(12.2) == Box(12.2)



# Generated at 2022-06-12 04:50:27.628539
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def my_function():
        return 5 # type: ignore

    box = Box(my_function)  # type: Box[Callable[[], int]]

    assert box.value() == box.to_lazy().value().value()

# Generated at 2022-06-12 04:50:30.060994
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(2) != Box("2")
    assert Box(2) == 2
    assert Box(2) != "2"



# Generated at 2022-06-12 04:50:31.400308
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box('value').to_lazy().value() == 'value'



# Generated at 2022-06-12 04:50:34.153732
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 'some value'
    box = Box(value)
    assert box.to_lazy() == Lazy(lambda: value)



# Generated at 2022-06-12 04:50:36.350012
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    class_ = Box['int']
    box_1 = class_(1)
    assert box_1 == box_1
    assert not box_1 == Box('string')

    

# Generated at 2022-06-12 04:50:38.433985
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert(Box(10).to_lazy() == Lazy(lambda: 10))

# Generated at 2022-06-12 04:50:41.168610
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    x = Box(1)

    assert x == Box(1)
    assert x != Box(2)
    assert x != []
    assert x != None



# Generated at 2022-06-12 04:50:42.617060
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_value = Box('test_string').to_lazy().force()
    assert lazy_value == 'test_string'

# Generated at 2022-06-12 04:51:19.344392
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box('test').to_lazy().eval()
    assert result == 'test'

# Generated at 2022-06-12 04:51:24.946099
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 2
    assert Box((1, 2)) == Box((1, 2))
    assert Box((1, 2)) != Box((1, 3))
    assert Box((1, 2)) != (1, 2)
    assert Box([1, 2]) == Box([1, 2])
    assert Box([1, 2]) != Box([1, 3])
    assert Box([1, 2]) != [1, 2]
    assert Box(set([1, 2])) == Box(set([1, 2]))
    assert Box(set([1, 2])) != Box(set([1, 3]))
    assert Box(set([1, 2])) != set([1, 2])

# Method map

# Generated at 2022-06-12 04:51:25.562639
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)


# Generated at 2022-06-12 04:51:27.543325
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box.to_lazy()
    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()



# Generated at 2022-06-12 04:51:35.422769
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) == Box(5.0)
    assert Box(5.0) == Box(5)
    assert Box(5.0) == Box(5.0)
    assert Box('123') == Box('123')
    assert Box(True) == Box(True)
    assert Box(Box('123')) == Box(Box('123'))
    assert Box(Box(Box('123'))) == Box(Box(Box('123')))
    assert Box({'a': 1, 'b': 2}) == Box({'a': 1, 'b': 2})

    assert Box(5) != Box(6)
    assert Box(5) != Box(6.0)
    assert Box(5.0) != Box(6)

# Generated at 2022-06-12 04:51:36.747410
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1).__eq__(Box(1)) is True


# Generated at 2022-06-12 04:51:39.033990
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(1).to_lazy()

    assert lazy.value == 1


# Generated at 2022-06-12 04:51:40.849892
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:51:45.350484
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Box(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.is_folded() is False
    assert lazy.get_value() == 1

# Generated at 2022-06-12 04:51:48.417778
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.unit import Unit

    box: Box[int] = Box(2)
    lazy: Lazy[Callable[[], Unit]] = box.to_lazy()
    assert lazy.fold(lambda: 0) == 2

# Generated at 2022-06-12 04:52:10.835165
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # arrange
    box = Box(5)
    expected = Lazy(lambda: 5)

    # act
    actual = box.to_lazy()

    # assert
    assert actual == expected



# Generated at 2022-06-12 04:52:15.243927
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of Box.
    """

    def f():
        return Box(3)

    assert f().to_lazy() == Box(3).to_lazy()


# Generated at 2022-06-12 04:52:19.239071
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Test case of Box with internal value equals 1
    data = Box(1)

    # Expected lazy structure
    expected_lazy = Lazy(lambda: 1)

    assert data.to_lazy() == expected_lazy

# Generated at 2022-06-12 04:52:21.380257
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:52:23.311514
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_value = Box(5).to_lazy()
    assert isinstance(lazy_value, Lazy)

    assert lazy_value.value() == 5


# Generated at 2022-06-12 04:52:25.719630
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    result = Lazy(lambda: 1)
    box = Box(1)

    assert box.to_lazy() == result



# Generated at 2022-06-12 04:52:28.197605
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_result = Box(1).to_lazy()
    assert isinstance(lazy_result, Lazy)
    assert lazy_result.fold(lambda: None) == 1

# Unit tests for method bind of class Box

# Generated at 2022-06-12 04:52:34.891752
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test method to_lazy of class Box.
    """
    assert Box(2).to_lazy().fold() == 2
    assert Box('abc').to_lazy().fold() == 'abc'
    assert Box('abc').to_lazy().map(lambda x: x + 'def').fold() == 'abcdef'
    assert Box({24: 11}).to_lazy().map(lambda x: x.get(24)).fold() == 11
    assert Box(None).to_lazy().map(lambda x: x).fold() is None



# Generated at 2022-06-12 04:52:38.559988
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(Lazy(lambda: 1)).value.fold(None) == 1
    assert Box(Lazy(lambda: 1)).to_lazy().value.fold(None) == 1


# Generated at 2022-06-12 04:52:39.697915
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('a').to_lazy().value() == 'a'

# Generated at 2022-06-12 04:53:21.702400
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1


# Generated at 2022-06-12 04:53:23.374728
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)

# Generated at 2022-06-12 04:53:25.153551
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:53:27.779402
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = box.to_lazy()
    assert box.value == lazy.value()

# Generated at 2022-06-12 04:53:29.043451
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    assert box.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:53:32.853123
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy

    box = Box(5)
    assert Lazy(lambda: 5) == box.to_lazy()

# Generated at 2022-06-12 04:53:34.563810
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 1) == Box(1).to_lazy()



# Generated at 2022-06-12 04:53:36.459218
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    lazy = box.to_lazy()
    assert lazy.is_folded() is False
    assert lazy.eval() == 1

# Generated at 2022-06-12 04:53:38.869765
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(lambda: 25)
    assert box.to_lazy() == Lazy(lambda: 25)

# Generated at 2022-06-12 04:53:40.995355
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    # GIVEN
    box = Box(10)
    # WHEN
    lazy = box.to_lazy()
    # THEN
    assert lazy.compute() == 10

# Generated at 2022-06-12 04:54:21.823988
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(10).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 10


# Generated at 2022-06-12 04:54:26.538853
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad import bind
    from pymonet.lazy import Lazy

    assert bind(Box(1), lambda x: Box(x + 1)).to_lazy() == Lazy(lambda: Box(2))

# Generated at 2022-06-12 04:54:29.630512
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Basic unit test for method to_lazy of class Box
    """

    # Given
    box = Box(2)
    # When
    result = box.to_lazy()
    # Then
    assert result.value() == 2

# Generated at 2022-06-12 04:54:30.688351
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().force() == 1

# Generated at 2022-06-12 04:54:32.237103
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try



# Generated at 2022-06-12 04:54:34.123449
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:54:39.529095
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from .lazy import Lazy
    box = Box(1)
    assert isinstance(box.to_lazy(), Lazy)
    assert box.to_lazy().force() == 1
    assert str(box.to_lazy()) == "Lazy[value=<function Lazy.force.<locals>.f at 0x11276bb70>]"


# Generated at 2022-06-12 04:54:45.046394
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Given
    value = 5
    box = Box(value)

    # When
    lazy = box.to_lazy()  # Lazy[Function(() -> 5)]

    # Then
    assert isinstance(lazy, Lazy)
    try:
        assert lazy.get() == value
    except Exception:
        assert isinstance(lazy.get(), Try)
        assert not lazy.get().is_success()
        assert lazy.get().get_value() == value


# Generated at 2022-06-12 04:54:47.663677
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    box = Box(5)
    # when
    lazy = box.to_lazy()
    # then
    assert lazy.computed() == box.value


# Generated at 2022-06-12 04:54:50.760400
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(float) == Box(float).to_lazy()


# Generated at 2022-06-12 04:55:41.417196
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('abc').to_lazy().fold() == 'abc'



# Generated at 2022-06-12 04:55:45.283300
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = Lazy(lambda: 1)
    assert (box.to_lazy() == lazy)

    box = Box("test")
    lazy = Lazy(lambda: "test")
    assert (box.to_lazy() == lazy)



# Generated at 2022-06-12 04:55:46.965856
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    input = Box(2).to_lazy()

    expected_output = 2

    assert expected_output == input.value()

# Generated at 2022-06-12 04:55:50.252072
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Create new Box with string value test and transform it into Lazy containing function
    which returns previous Box value.

    :returns: True if Lazy containing function returning value test
    :rtype: bool
    """
    from pymonet.lazy import Lazy

    return Lazy(lambda: 'test') == Box('test').to_lazy()

# Generated at 2022-06-12 04:55:52.658379
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    lazy = Box(1).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy() == 1



# Generated at 2022-06-12 04:55:54.489357
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().map(lambda a, b: a + b).value(Box(3)) is 5

# Generated at 2022-06-12 04:55:56.044803
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().fold() == 5

# Generated at 2022-06-12 04:55:57.676027
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 10
    box = Box(value)
    assert box.to_lazy().fold(lambda: value + 1) == value

# Generated at 2022-06-12 04:56:00.086697
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(12).to_lazy(), Lazy)
    assert callable(Box(12).to_lazy().value)
    assert Box(12).to_lazy().value() == 12

# Generated at 2022-06-12 04:56:04.807668
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box('Hello').to_lazy() == Lazy(lambda: 'Hello')
    assert Box([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])