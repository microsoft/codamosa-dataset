

# Generated at 2022-06-12 04:47:29.315308
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Case 1:
    assert Box(123).to_lazy() == Lazy(lambda: 123)

    # Case 2:
    assert Box('abc').to_lazy() == Lazy(lambda: 'abc')

    # Case 3:
    assert Box(Box(123)).to_lazy() == Lazy(lambda: Box(123))

# Generated at 2022-06-12 04:47:33.636655
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box([1, 2]) == Box([1, 2])
    assert Box(3) != Box(4)
    assert Box(2) != 1
    assert Box(2) != 1.0

# Generated at 2022-06-12 04:47:35.131396
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().get_or_else(None) == 5

# Generated at 2022-06-12 04:47:37.607108
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for Box.__eq__ method
    """
    assert Box(10) == Box(10)



# Generated at 2022-06-12 04:47:39.739336
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-12 04:47:45.004620
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    from pymonet.tests.utils import eq
    from nose.tools import (
        assert_true,
        assert_false,
    )

    assert_true(eq(Box(123), Box(123)))
    assert_false(eq(Box(123), Box(321)))
    assert_false(eq(Box(321), Box(123)))



# Generated at 2022-06-12 04:47:50.172910
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert isinstance(Box(1).to_lazy(), Functor)
    assert isinstance(Box(1).to_lazy(), Monad)
    assert callable(Box(1).to_lazy().value)
    assert Box(1).to_lazy().value() == 1


# Generated at 2022-06-12 04:47:54.636072
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def f():
        print('evaluate function')
        return 5
    assert Box(5).to_lazy() == Lazy(f)



# Generated at 2022-06-12 04:47:58.091222
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box(1)
    box_1_1 = Box(1)
    box_2 = Box(2)

    assert box_1 == box_1
    assert box_1 == box_1_1
    assert box_1 != box_2



# Generated at 2022-06-12 04:48:02.399262
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import mk_lazy

    lazy = Box(10).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy == mk_lazy(10)

# Generated at 2022-06-12 04:48:09.315983
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for Box class.
    """
    import pytest

    assert Box(1).to_lazy().fold(lambda: pytest.fail('Box to Lazy test')) == 1

# Generated at 2022-06-12 04:48:13.147528
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.comparator import AnyComparator
    from pymonet.assertion import assert_that

    assert_that(Box(42)).is_equal_to(Lazy(lambda: 42), AnyComparator())

# Generated at 2022-06-12 04:48:15.435414
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == object()


# Generated at 2022-06-12 04:48:18.278539
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')



# Generated at 2022-06-12 04:48:22.296284
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)

    assert box1 == box2

    box3 = Box('test')
    assert box1 != box3
    assert not(box1 == box3)



# Generated at 2022-06-12 04:48:25.025767
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:48:26.512647
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == 1


# Generated at 2022-06-12 04:48:34.407667
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from math import pi

    box1 = Box(pi)
    box2 = Box(pi)
    assert box1 == box2  # type: ignore[comparison-overlap]
    assert box1 == Maybe.just(pi)  # type: ignore[comparison-overlap]
    assert box1 == Lazy(lambda: pi)  # type: ignore[comparison-overlap]
    assert box1 == pi  # type: ignore[comparison-overlap]



# Generated at 2022-06-12 04:48:35.797689
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)


# Generated at 2022-06-12 04:48:41.711106
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Setup
    box1 = Box(26)
    box2 = Box(26)
    box3 = Box(77)

    # Exercise
    result1 = box1 == box2
    result2 = box1 == box3
    result3 = box2 == box3

    # Verify
    assert result1 is True
    assert result2 is False
    assert result3 is False
    
    

# Generated at 2022-06-12 04:48:48.224264
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_function_lazy_data(x: int) -> int:
        return x

    test_value = 1
    test_data = Box[int](test_value)
    result_data = test_data.to_lazy().map(test_function_lazy_data).get()
    assert result_data == test_function_lazy_data(test_value)

# Generated at 2022-06-12 04:48:54.557126
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    :returns: True if unit test successful else raises AssertionError
    :rtype: bool
    """
    from pymonet.lazy import Lazy
    from pymonet.iterable import Iterable

    def force_func(value) -> int:
        return value

    box = Box(2).to_lazy()
    assert isinstance(box, Lazy) and Iterable.fold(force_func, box, 0) == 2

# Generated at 2022-06-12 04:48:57.991816
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box([]) != Box(1)
    assert Box(1) != object()
    assert Box(1) != None

# Generated at 2022-06-12 04:48:59.864335
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(1) != Box(2)
    assert Box(1) != 2



# Generated at 2022-06-12 04:49:01.697385
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy().force() == Box(1).value

# Generated at 2022-06-12 04:49:05.492283
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not(Box(1) == Box(2))
    assert not(Box(1) == 1)
    assert Box(1).value == 1


# Generated at 2022-06-12 04:49:09.071904
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box('str') == Box('str')
    assert True == (Box(1) == Box(None))
    assert False == (Box(1) == 1)



# Generated at 2022-06-12 04:49:10.881630
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy()._value() == 1

# Generated at 2022-06-12 04:49:13.723700
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box(42).to_lazy().value() == 42

# Generated at 2022-06-12 04:49:16.037102
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)

    assert box1 == box2


# Generated at 2022-06-12 04:49:21.621600
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    value = Box(42).to_lazy().get_result()
    assert value == 42



# Generated at 2022-06-12 04:49:25.875625
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    from pymonet.lazy import Lazy

    # Test for mapping a simple function
    box = Box(1)
    lazy = box.to_lazy()

    lazy_set = set(lazy)
    assert len(lazy_set) == 1
    assert next(iter(lazy_set)) == Lazy(lambda : 1)

# Generated at 2022-06-12 04:49:30.323637
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    # Given
    box: Box[int] = Box(42)

    # When
    result = box.to_lazy()

    # Then
    assert result.fold(lambda x: x * 2) == 84


# Generated at 2022-06-12 04:49:32.371042
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-12 04:49:34.197255
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    v = Box(1)
    assert v.to_lazy().fold() == 1


# Generated at 2022-06-12 04:49:35.550828
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1).__eq__(Box(1)) == True


# Generated at 2022-06-12 04:49:37.573405
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:49:38.944299
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().map(lambda a: a).value() == 1

# Generated at 2022-06-12 04:49:42.546528
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: no cover
    import pytest

    with pytest.raises(Exception):
        raise Exception

    box = Box(5)
    lazy = box.to_lazy()

    assert lazy.value() == 5
    assert lazy.value() == 5



# Generated at 2022-06-12 04:49:44.818688
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None



# Generated at 2022-06-12 04:49:51.407511
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    lazy_box = Box('a').to_lazy()

    assert isinstance(lazy_box, Lazy)
    assert isinstance(lazy_box, Monad)
    assert lazy_box.eval() == 'a'


# Generated at 2022-06-12 04:49:55.263091
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    box = Box(lambda x: x ** x) # type: Box[Callable[int]]
    lazy = box.to_lazy() # type: Lazy[Callable[int]]
    assert isinstance(lazy, Lazy)
    assert lazy.fold(None) == box.value

# Generated at 2022-06-12 04:50:01.006226
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Test unit for Box.to_lazy.
    """
    from pymonet.lazy import Lazy

    current_value = 'test'
    box = Box(current_value)
    lazy = box.to_lazy()

    assert lazy is not None
    assert isinstance(lazy, Lazy)
    assert lazy.is_folded() is False
    assert lazy.value() == current_value


# Generated at 2022-06-12 04:50:05.368878
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Box(Lazy(lambda: 1)).to_lazy() == Lazy(lambda: 1)
    assert Box(Maybe(1)).to_lazy().to_box().value == Maybe(1)
    assert Box(1).to_lazy().to_box().value == 1


# Generated at 2022-06-12 04:50:07.868761
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    expected = ['test_value']
    actual = Box('test_value').to_lazy().get()
    assert actual == expected

# Generated at 2022-06-12 04:50:09.907300
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(lambda: 1).to_lazy().fold()() == 1


# Generated at 2022-06-12 04:50:11.306033
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1


# Generated at 2022-06-12 04:50:15.659819
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Unit test for method to_lazy of class Box."""
    from pymonet.lazy import Lazy

    box = Box(1)
    assert box.to_lazy() == Lazy(lambda: 1), 'Box to lazy error'


# Generated at 2022-06-12 04:50:21.329670
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try, is_success, is_failure

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(Try(1, is_success=True)).to_lazy() == Lazy(lambda: Try(1, is_success=True))
    assert Box(Try(1, is_success=False)).to_lazy() == Lazy(lambda: Try(1, is_success=False))
    assert Box(Try(lambda: 1 / 0, is_success=False)).to_lazy() == Lazy(lambda: Try(lambda: 1 / 0, is_success=False))

# Generated at 2022-06-12 04:50:27.806960
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Box(2).to_lazy()
    assert Box(2).to_lazy().map(lambda x: x * 2) == Box(4).to_lazy()
    assert Box(3).to_lazy().map(lambda x: x**2) == Box(9).to_lazy()
    assert Box(4).to_lazy().map(lambda x: x - 1) == Box(3).to_lazy()

# Generated at 2022-06-12 04:50:32.256646
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert type(Box(10).to_lazy()) is Lazy
    assert Box(10).to_lazy().get() == Box(10).value



# Generated at 2022-06-12 04:50:37.268670
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monoid import Monoid

    assert Functor(1).fmap(lambda x: x + 1).to_lazy() == Lazy(lambda: 2)
    assert Functor(30).fmap(lambda x: Monoid.empty().value).to_lazy() == Lazy(lambda: 0)

# Generated at 2022-06-12 04:50:39.540891
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(20).to_lazy() == Lazy(lambda: 20)

# Unit tests for the method ap of class Box

# Generated at 2022-06-12 04:50:42.123587
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy().value() == Lazy(lambda: 5).value()


# Generated at 2022-06-12 04:50:43.905809
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(12).to_lazy() == Lazy(lambda: 12)

# Generated at 2022-06-12 04:50:51.169623
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def assert_equality(lazy: Lazy[T], value: T) -> None:
        assert lazy.value() == value

    lazy = Box(42).to_lazy()
    assert_equality(lazy, 42)

    lazy = Box('42').to_lazy()
    assert_equality(lazy, '42')

    lazy = Lazy(Box(42)).to_lazy()
    assert_equality(lazy, Box(42))

    lazy = Lazy(Box('42')).to_lazy()
    assert_equality(lazy, Box('42'))

# Generated at 2022-06-12 04:50:54.876072
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(5).to_lazy().value == 5


# Generated at 2022-06-12 04:50:59.190086
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest
    from pymonet.lazy import Lazy

    with pytest.raises(TypeError):
        _ = Box('Foo').to_lazy().fold()

    assert Box('Foo').to_lazy().fold() == Lazy(lambda: 'Foo').fold()



# Generated at 2022-06-12 04:51:01.514285
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def foo(): return 1

    assert Box(foo()).to_lazy() == Lazy(foo)

# Generated at 2022-06-12 04:51:03.640417
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 04:51:10.958932
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    box = Box(1)

    # when
    actual = box.to_lazy()

    # then
    assert actual.value() == 1

# Generated at 2022-06-12 04:51:18.562579
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box[int](42).to_lazy() == Lazy(lambda: 42)
    assert Box[int](42).to_lazy().fold() == 42
    assert Box[Try[int]](Try(42)).to_lazy() == Lazy(lambda: Try(42, is_success=True))
    assert Box[Try[int]](Try(42, is_success=True)).to_lazy().fold() == Try(42, is_success=True)

# Generated at 2022-06-12 04:51:23.108615
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for to_lazy method of class Box
    """
    from pymonet.monad_functor import Functor
    from pymonet.monad_applicative import Applicative
    from pymonet.monad_monad import Monad

    assert issubclass(Box, Functor)
    assert issubclass(Box, Applicative)
    assert issubclass(Box, Monad)
    assert Box(5).to_lazy().value == Box(5).value

# Generated at 2022-06-12 04:51:26.319975
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    value = 7
    box = Box(value)

    # When
    lazy = box.to_lazy()

    # Then
    assert lazy.value() == value

# Generated at 2022-06-12 04:51:27.696364
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().value() == 5

# Generated at 2022-06-12 04:51:29.856273
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().value() == 2



# Generated at 2022-06-12 04:51:30.860574
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    Box(1).to_lazy().value() == 1

# Generated at 2022-06-12 04:51:32.446574
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(7)

    assert box.to_lazy().fold() == 7


# Generated at 2022-06-12 04:51:38.261364
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def foo_func():  # pylint: disable=unused-variable
        print('foo')

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box('foo').to_lazy() == Lazy(lambda: 'foo')
    assert Box(foo_func).to_lazy() == Lazy(lambda: foo_func)



# Generated at 2022-06-12 04:51:40.534756
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Box(10).to_lazy()

# Generated at 2022-06-12 04:51:53.354990
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    result = Box(True).to_lazy()
    assert isinstance(result, Lazy)
    assert result.fold() is True


# Generated at 2022-06-12 04:51:55.086566
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    assert box.to_lazy().value() == 1

# Generated at 2022-06-12 04:51:56.350440
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1


# Generated at 2022-06-12 04:51:59.889992
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy_box = Box('box').to_lazy()

    assert isinstance(lazy_box, Lazy) and lazy_box.compute() == 'box'

# Generated at 2022-06-12 04:52:01.965711
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test covered function to_lazy of class Box
    """
    assert Box(3).to_lazy().fold() == 3

# Generated at 2022-06-12 04:52:03.842156
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy.of(lambda: 42) == Box(42).to_lazy()


# Generated at 2022-06-12 04:52:05.743773
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('content').to_lazy() == Lazy(lambda: 'content')


# Generated at 2022-06-12 04:52:09.453989
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_lazy import MonadLazy

    assert MonadLazy.equals(
        Box(1).to_lazy(),
        Lazy(lambda: 1)
    )

# Generated at 2022-06-12 04:52:20.416504
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test on function to_lazy
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box("test").to_lazy() == Lazy(lambda: "test")
    assert Box([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])
    assert Box((10, "test")).to_lazy() == Lazy(lambda: (10, "test"))
    assert Box(set([1, 2, 3])).to_lazy() == Lazy(lambda: set([1, 2, 3]))
    assert Box(Try(5, is_success=True)).to

# Generated at 2022-06-12 04:52:22.780823
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = Lazy(lambda: 1)

    assert box.to_lazy() == lazy



# Generated at 2022-06-12 04:52:45.621895
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()

# Generated at 2022-06-12 04:52:49.950992
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, fold_lazy

    def f(*args, **kwargs):
        return Box(1).value

    assert Lazy(f) == fold_lazy(Box(lambda *args, **kwargs: 1).to_lazy())
    assert Lazy(f) == Box(1).to_lazy()

# Generated at 2022-06-12 04:52:57.079368
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monoid import Monoid
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()
    assert Lazy(lambda: []) == Box([]).to_lazy()
    assert Lazy(lambda: (1, 2, 3)) == Box((1, 2, 3)).to_lazy()
    assert Lazy(lambda: Monoid(1)) == Box(Monoid(1)).to_lazy()



# Generated at 2022-06-12 04:52:59.220250
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:53:02.182268
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_function():
        return 2

    assert Box(test_function).to_lazy().force() == 2

# Generated at 2022-06-12 04:53:04.564005
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Tests the to_lazy method of class Box
    """
    from pymonet.lazy import Lazy

    def test_inner_lazy_value():
        return 'test'

    test_box = Box('test')
    assert test_box.to_lazy() == Lazy(test_inner_lazy_value)


# Generated at 2022-06-12 04:53:08.026914
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(5).to_lazy().fold(lambda x: x + 1) == 6


# Generated at 2022-06-12 04:53:09.872072
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy().fold(lambda: -1) == 1

# Generated at 2022-06-12 04:53:11.239169
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:53:13.195162
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(5)
    lazy = box.to_lazy()
    assert lazy.fold(lambda: 5) == 5


# Generated at 2022-06-12 04:53:40.069105
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy_value = Box(15).to_lazy()

    assert isinstance(lazy_value, Lazy)
    assert lazy_value.fold() == 15

# Generated at 2022-06-12 04:53:41.941017
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 1)
    assert Box(1).to_lazy() == lazy



# Generated at 2022-06-12 04:53:44.166536
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == (
        lambda: 1
    )



# Generated at 2022-06-12 04:53:46.848097
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """

    # Test Box.to_lazy()
    assert Box(1).to_lazy() == Lazy(lambda: 1), 'Box.to_lazy() is broken'

# Generated at 2022-06-12 04:53:49.961089
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(5).to_lazy().map(lambda x: x * 5) == Lazy(lambda: 25)

# Generated at 2022-06-12 04:53:51.772306
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    input = Box(42)
    output = input.to_lazy()
    assert output.fold() == input.value

# Generated at 2022-06-12 04:53:56.151827
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for funcion to_lazy from Box class.

    Returns:
        AssertionError: if test is failed
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:54:07.512915
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Box(0).to_lazy() == Lazy(lambda: 0)
    assert Box('test').to_lazy() == Lazy(lambda: 'test')
    assert Box(Try()).to_lazy() == Lazy(lambda: Try())
    assert Box(Validation.success('')).to_lazy() == Lazy(lambda: Validation.success(''))
    assert Box(Maybe()).to_lazy() == Lazy(lambda: Maybe())

# Generated at 2022-06-12 04:54:16.056537
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    unit_value = Box(5)
    assert isinstance(unit_value.to_lazy(), Lazy)

    res = unit_value.to_lazy()
    assert res.fold(lambda val: val() + 5) == 10
    assert res.map(lambda val: val() + 5).fold(lambda val: val()) == 15
    assert res.bind(lambda val: Box(val() + 5)).value == 15

    assert unit_value.to_maybe() == Maybe(5)



# Generated at 2022-06-12 04:54:19.061937
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet import Lazy

    lazy_value = Lazy(lambda: 3)
    assert Box(3).to_lazy() == lazy_value

# Generated at 2022-06-12 04:55:07.580286
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:55:11.819050
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pylint: disable=R0903
    """
    Test the method to_lazy of the class Box.
    """
    value = 3
    box = Box(value)

    lazy_result = box.to_lazy()
    assert isinstance(lazy_result, Lazy)
    assert lazy_result.is_folded() is False
    assert lazy_result.value() == value

# Generated at 2022-06-12 04:55:14.448220
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:55:16.040980
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(1).to_lazy()
    assert lazy.value() == 1



# Generated at 2022-06-12 04:55:17.635316
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Box(2).to_lazy()

# Generated at 2022-06-12 04:55:18.780334
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Box(2).to_lazy()

# Generated at 2022-06-12 04:55:20.199789
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:55:23.803460
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    from pymonet.lazy import Lazy
    with_value = Box(5)
    without_value = Box(None)

    # when
    actual_with_value = with_value.to_lazy()
    actual_without_value = without_value.to_lazy()

    # then
    assert isinstance(actual_with_value, Lazy)
    assert actual_with_value.fold(lambda: None) == 5
    assert isinstance(actual_without_value, Lazy)
    assert actual_without_value.fold(lambda: None) is None



# Generated at 2022-06-12 04:55:27.277307
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    value = 'Hello world!'
    fmap = Functor(lambda x: x + '!')

    assert Box(value).to_lazy() == Lazy(lambda: value)
    assert Box(value).to_lazy() | fmap == Lazy(lambda: value + '!')


# Generated at 2022-06-12 04:55:29.179036
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Box(2).to_lazy()


# Generated at 2022-06-12 04:57:16.658375
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    value = object()
    box = Box(value=value)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: value)

# Generated at 2022-06-12 04:57:18.587239
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-12 04:57:20.770403
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet import Lazy

    b = Box(2)
    l = b.to_lazy()

    # l is not folded
    assert l == Lazy(lambda: 2)  # pragma: no cover

# Generated at 2022-06-12 04:57:22.162274
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(123).to_lazy() == Lazy(lambda: 123)
