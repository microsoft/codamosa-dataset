

# Generated at 2022-06-12 04:47:31.914278
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box([1]) == Box([1])
    assert Box(None) == Box(None)
    assert Box(None) != Box(1)
    assert Box(1) != Box(None)
    assert Box(1) != Box('str')
    assert Box('str') != Box(1)
    assert Box(1) != Box(list(range(5)))
    assert Box(list(range(5))) != Box(1)


# Generated at 2022-06-12 04:47:35.952259
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != Box(5)
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box('abc') != Box('def')



# Generated at 2022-06-12 04:47:38.000334
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(1)
    another_box = Box(1)

    assert box == another_box



# Generated at 2022-06-12 04:47:40.420126
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    lazy_monad = Box(3).to_lazy()
    assert lazy_monad.value() == 3



# Generated at 2022-06-12 04:47:42.672854
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:47:50.948422
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    val = Box(1)

    # val is Box[int]
    assert val.value == 1
    assert val.map(lambda x: x + 1).value == 2
    assert val.bind(lambda x: x + 1) == 2
    assert val.ap(Box(lambda x: x + 1)).value == 2

    # to_lazy method transform Box[A] into Lazy[Function(() -> A)]
    # So we need apply to Lazy our value to get Box value
    lazy_val = val.to_lazy()
    assert isinstance(lazy_val, Lazy)
    assert lazy_val.value() == 1



# Generated at 2022-06-12 04:47:54.960881
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('red') == Box('red')
    assert Box(1) == Box(1)
    assert Box(1) != Box('red')


# Generated at 2022-06-12 04:47:58.672556
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == object())



# Generated at 2022-06-12 04:48:00.614036
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:48:02.445048
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1



# Generated at 2022-06-12 04:48:09.751330
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(lambda: 1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:48:11.347786
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:48:14.459120
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def unit_test_for_Box():
        assert Box(1).to_lazy() == Lazy(lambda: 1)

    unit_test_for_Box()

# Generated at 2022-06-12 04:48:20.465719
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try

    try1 = Try(1)
    box1 = Box(1)
    assert box1 == box1
    assert box1 == Box(1)
    assert box1 == try1.to_box()
    assert box1 != Try(2)
    assert box1 != Try(2).to_box()
    assert box1 != None


# Generated at 2022-06-12 04:48:25.193286
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    empty_box = Box(None)
    filled_box = Box(10)

    assert empty_box.to_lazy() == Lazy(lambda: None)
    assert filled_box.to_lazy() == Lazy(lambda: 10)

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 04:48:27.106065
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    actual = Box(10).to_lazy()
    assert isinstance(actual, Lazy)
    assert isinstance(actual.value(), int)
    assert actual.value() == 10



# Generated at 2022-06-12 04:48:30.383122
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 04:48:32.373933
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 1

    assert Box(1).to_lazy() == Lazy(f)

# Generated at 2022-06-12 04:48:34.331086
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:48:35.968495
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)


# Generated at 2022-06-12 04:48:44.449277
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:48:48.035215
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box('1') == Box('1')
    assert Box('1') != Box(1)
    assert Box(1) != None
    assert Box(1) != 1
    assert Box(None) == Box(None)
    assert Box(None) != None


# Generated at 2022-06-12 04:48:50.377641
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-12 04:48:53.731415
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 12).fold(lambda: Box(34).to_lazy()) == Box(34)



# Generated at 2022-06-12 04:48:56.922459
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try

    assert Box(12) == Box(12)
    assert Box(12) != Try(12)
    assert Box(12) != Box(13)



# Generated at 2022-06-12 04:48:58.222681
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:01.906667
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box(3) != Box(1)
    assert Box(1) != Box(2)
    assert Box(2) != Box(3)



# Generated at 2022-06-12 04:49:06.133588
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box(Box(1)) != Box(1)
    assert Box(1) != [1]
    assert Box(1) != 1


# Generated at 2022-06-12 04:49:08.550396
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-12 04:49:11.504114
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('pymonet') == Box('pymonet')
    assert not Box(1) == Box('pymonet')


# Generated at 2022-06-12 04:49:23.662323
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(1).to_lazy())



# Generated at 2022-06-12 04:49:26.205287
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(1)

    assert box == box
    assert box == Box(1)
    assert Box(1) == box

    assert box != Box('1')
    assert Box('1') != box



# Generated at 2022-06-12 04:49:27.705959
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(2).to_lazy()
    assert lazy.value() == 2

# Generated at 2022-06-12 04:49:30.622227
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert not Box(5) == Box(6)
    assert not Box(5) == 6


Box_ = Box[int]

# Generated at 2022-06-12 04:49:33.395306
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(0)
    assert box1 == Box(0)
    assert not box1 == Box(1)



# Generated at 2022-06-12 04:49:34.674036
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().get() == 10

# Generated at 2022-06-12 04:49:36.782175
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-12 04:49:39.656628
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('abc')
    assert Box(1) != 123
    assert Box(1) != object


# Generated at 2022-06-12 04:49:41.955522
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != Box('1')
    assert Box(1) != Box(2)

    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-12 04:49:45.303173
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    b1 = Box(3)
    b2 = Box(3)
    assert b1 == b2

    b1 = Box(2)
    b2 = Box(3)
    assert b1 != b2



# Generated at 2022-06-12 04:50:10.538588
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(1)

    assert box == box
    assert box == Box(1)
    assert box != Box('a')
    assert box != Box([1, 2, 3])
    assert box != 'a'


# Generated at 2022-06-12 04:50:12.182591
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().run() == 1

# Generated at 2022-06-12 04:50:16.193644
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.monad_lazy import Lazy

    box_value = Box(1).to_lazy()

    assert isinstance(box_value, Lazy)

    assert box_value.fold() == 1


# Generated at 2022-06-12 04:50:18.408789
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(20)
    assert box.to_lazy() == Lazy(lambda: 20)

# Generated at 2022-06-12 04:50:22.461487
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(11)
    assert Box([]) != Box(())
    assert Box(10) != []



# Generated at 2022-06-12 04:50:27.763025
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    from pymonet.monad_try import TryTypeError

    # and
    box = Box(1)

    # and
    lazy = box.to_lazy()

    # when
    try:
        value = lazy.value()

        # then
        assert value == 1
    except TryTypeError:  # pragma: no cover
        pytest.fail()



# Generated at 2022-06-12 04:50:30.341675
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('Hello') == Box('Hello')
    assert Box('Hello') != Box('World')


# Generated at 2022-06-12 04:50:37.165296
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.validation import Validation

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(1).to_either() == Right(1)
    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-12 04:50:39.016644
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1, "Box should be converted to Lazy"



# Generated at 2022-06-12 04:50:41.315038
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(42)
    lazy = box.to_lazy()
    assert lazy.fold() == 42


# Generated at 2022-06-12 04:51:20.714750
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    # Case 1: Box with some value
    test_input = Box(42)
    expected_output = True
    actual_output = test_input == test_input
    assert expected_output == actual_output

    # Case 2: Box with some value and None value
    test_input = Box(42)
    expected_output = False
    actual_output = test_input == None
    assert expected_output == actual_output

    # Case 3: Box with some value and other Class instance
    test_input = Box(42)
    expected_output = False
    actual_output = test_input == object
    assert expected_output == actual_output

    # Case 4: Box with some value and other Box instance with another value
    test_input = Box(42)
    expected_output = False

# Generated at 2022-06-12 04:51:27.134829
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()
    assert Lazy(lambda: 'string') == Box('string').to_lazy()
    assert Lazy(lambda: [1, 2, 3]) == Box([1, 2, 3]).to_lazy()



# Generated at 2022-06-12 04:51:29.761186
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(4)



# Generated at 2022-06-12 04:51:31.788882
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == None)


# Generated at 2022-06-12 04:51:33.629882
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:51:35.082261
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)



# Generated at 2022-06-12 04:51:36.748134
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-12 04:51:47.673995
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def add_one(a): return a + 1
    assert Box(1).to_lazy() == Lazy(lambda: 1), 'that Box(1).to_lazy() == Lazy(lambda: 1)'
    assert Box(1).to_lazy().map(add_one) == Lazy(lambda: 2), 'that Box(1).to_lazy().map(add_one) == Lazy(lambda: 2)'
    assert Box(1).to_lazy().map(add_one).foldl() == 2, 'that Box(1).to_lazy().map(add_one).fold() == 2'
    assert Box(1).to_lazy().map(add_one).foldl(0) == 2, 'that Box(1).to_lazy().map(add_one).fold(0) == 2'

# Generated at 2022-06-12 04:51:49.066792
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box.to_lazy(Box(42)).evaluate() == 42

# Generated at 2022-06-12 04:51:52.405422
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def new_value() -> str:
        return "Foo"

    box: Box[str] = Box(new_value())
    lazy = box.to_lazy()
    assert lazy.is_folded == False
    assert lazy.unfold()() == "Foo"



# Generated at 2022-06-12 04:52:42.065517
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    data = Box('some data')
    assert data.to_lazy().value() == data.value

# Generated at 2022-06-12 04:52:43.550905
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().get() == 5

# Generated at 2022-06-12 04:52:47.201865
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box to_lazy method.
    """
    from pymonet.lazy import Lazy
    from pymonet import Box

    assert Box('x').to_lazy() == Lazy(lambda: 'x')

# Generated at 2022-06-12 04:52:48.407875
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:52:52.443040
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    assert Box(10) == Box(10)
    assert Box(-10) == Box(-10)
    assert Box('test') == Box('test')


from pymonet.functor import Functor



# Generated at 2022-06-12 04:52:53.960013
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != Box(5)

# Generated at 2022-06-12 04:52:56.322979
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(1).to_lazy(), Box(1).to_lazy().__class__)


# Generated at 2022-06-12 04:52:58.179029
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(0) == Box(0)
    assert Box(0) != Box(1)



# Generated at 2022-06-12 04:53:06.017571
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('test') == Box('test')
    assert Box({1: 2}) == Box({1: 2})
    assert not Box(1) == Box('test')
    assert not Box(1) == Box({1: 2})
    assert not Box('test') == Box({1: 2})
    assert not Box(1) == 1
    assert not Box(1) == 'test'
    assert not Box(1) == {1: 2}
    assert not Box('test') == {1: 2}


# Generated at 2022-06-12 04:53:07.745779
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    boxed_value = Box(42)

    assert boxed_value.to_lazy().value()() == 42

# Generated at 2022-06-12 04:54:58.221924
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.monad_lazy import Lazy

    box = Box(5)
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.fold() == box.value

# Generated at 2022-06-12 04:55:01.396343
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box("qwerty") == Box("qwerty")
    assert Box("qwerty") != Box("qwerty1")
    assert Box("qwerty") != Box(1)


# Generated at 2022-06-12 04:55:05.266661
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.test import is_equal

    is_equal(
        Box(1) == Box(1),
        True
    )

    is_equal(
        Box(1) == Box(2),
        False
    )

    is_equal(
        Box(1) == 1,
        False
    )


# Generated at 2022-06-12 04:55:08.314474
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('A') == Box('A')
    assert Box('A') != Box('B')
    assert Box(1) != Box('A')
    assert not Box(1) == 2
    assert not Box(1) == [1]


# Generated at 2022-06-12 04:55:10.925243
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Box(2).to_lazy()
    assert Box(2).to_lazy() != Box(2).to_lazy().value()
    assert Box(2).to_lazy().value() == 2

# Generated at 2022-06-12 04:55:14.334883
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(10)

    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.fold() == 10


# Generated at 2022-06-12 04:55:16.416761
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 3
    box = Box(value)
    lazy = box.to_lazy()
    assert value == lazy.extract()



# Generated at 2022-06-12 04:55:19.402883
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert not Box(10) == Box(11)
    assert Box('test') == Box('test')
    assert not Box('test') == Box('test1')



# Generated at 2022-06-12 04:55:24.221111
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    func = lambda x: x + 1
    x = Box(1)
    y = Box(func)
    f = Lazy(lambda: func)
    g = Lazy(lambda: f.get()(x.get()))
    x_lazy = x.to_lazy()
    y_lazy = y.to_lazy()
    assert x_lazy == Lazy(lambda: 1)
    assert y_lazy == Lazy(lambda: func)
    assert x_lazy.get() == 1
    assert y_lazy.get() == func
    assert x_lazy.map(func) == Lazy(lambda: func(1))
    assert y_lazy.map(func) == Lazy(lambda: func(func))
    assert x_l

# Generated at 2022-06-12 04:55:25.353121
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

