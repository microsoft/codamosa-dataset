

# Generated at 2022-06-12 04:47:28.780125
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(2)

    assert box1 == box1, "Same boxes should be equal"
    assert box1 != box2, "Different boxes should not be equal"



# Generated at 2022-06-12 04:47:32.043541
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box({}) == {}
    assert not Box(None) == None



# Generated at 2022-06-12 04:47:36.343172
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # type: () -> None
    """
    Unit test for method test_Box_to_lazy of class Box.
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:47:39.875889
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test function to_lazy of Box class.
    """

    assert Box(42).to_lazy() == Box(42).to_lazy() == Box(42).to_lazy().get()


# Generated at 2022-06-12 04:47:44.827500
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('a') != 'a'
    assert Box(1) != Try(1, is_success=True)
    assert Box(1) != Try(1, is_success=False)

# Generated at 2022-06-12 04:47:46.174431
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(23).to_lazy().value == Box(23).value

# Generated at 2022-06-12 04:47:50.172890
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    @given(strategies.data())
    def test_Box___eq__(value: str, data: DataObject) -> None:
        x = Box(value)
        assert x.__eq__(x) is True

    test_Box___eq__()



# Generated at 2022-06-12 04:47:54.630780
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:47:59.738946
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    1. Create Lazy
    2. Fold lazy.
    3. Check that lazy equals to correct result.
    """
    from pymonet.lazy import Lazy

    lazy = Box(5).to_lazy()
    assert lazy == Lazy(lambda: 5)
    assert lazy.fold() == 5


# Generated at 2022-06-12 04:48:05.939625
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assertBox(Box(10).to_lazy(), Lazy(lambda: 10))
    assertBox(Box(None).to_lazy(), Lazy(lambda: None))
    assertBox(Box('').to_lazy(), Lazy(lambda: ''))
    assertBox(Box((None, 10, '')).to_lazy(), Lazy(lambda: (None, 10, '')))

# Generated at 2022-06-12 04:48:10.382667
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == 1)



# Generated at 2022-06-12 04:48:14.499655
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2), "Comparison of identical data should return True"
    assert Box(1) != Box(2), "Comparison of different data should return False"
    assert not Box(1) == Box(3), "Comparison of different data should return False"


# Generated at 2022-06-12 04:48:17.497152
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box(None)
    assert Box(None) == Box(None)
    assert Box(1) != 2
    assert Box(1) != None



# Generated at 2022-06-12 04:48:22.299285
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != Box(2)
    assert Box('test') != Box('testa')
    assert Box(1) != Box('test')
    assert Box('test') != 1
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)



# Generated at 2022-06-12 04:48:27.084699
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    given_value = 1
    given_box = Box(given_value)

    # When
    result = given_box.to_lazy()

    # Then
    assert isinstance(result, Box)
    assert result.value == 1


# Generated at 2022-06-12 04:48:28.789986
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    actual = Box(1) == Box(1)
    expected = True

    assert expected == actual



# Generated at 2022-06-12 04:48:37.180764
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_list import List, monad_list
    from pymonet.monad_maybe import Maybe, monad_maybe
    from pymonet.monad_try import Try, monad_try
    from pymonet.monad_writer import Writer, monad_writer
    from pymonet.lazy import Lazy
    import unittest as ut

    class BoxToLazyTest(ut.TestCase):
        def test_to_lazy(self):
            monad_list.reset()
            monad_maybe.reset()
            monad_try.reset()
            monad_writer.reset()

            self.assertEqual(Box('test').to_lazy(), Lazy(lambda: 'test'))

# Generated at 2022-06-12 04:48:40.539040
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)

    assert box1 == box2

if __name__ == '__main__':
    test_Box___eq__()

# Generated at 2022-06-12 04:48:42.219030
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) == Box(1)) is True
    assert (Box(1) == Box(2)) is False

# Generated at 2022-06-12 04:48:45.729291
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_a = Box('123')
    box_b = Box('123')
    box_c = Box('456')
    assert box_a == box_b
    assert not box_a == box_c



# Generated at 2022-06-12 04:48:53.773602
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:48:55.527473
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    for value in range(10):
        assert Box(value) == Box(value)



# Generated at 2022-06-12 04:48:59.556091
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('1') == Box('1')
    assert Box('1') != Box('2')
    assert Box('1') != Box(1)



# Generated at 2022-06-12 04:49:02.243292
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(1).to_lazy()

    assert isinstance(lazy, Lazy) and lazy.fold() == 1

# Generated at 2022-06-12 04:49:05.985740
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.box import Box

    assert Box(5) == Box(5)
    assert Box(5) != Box(10)
    assert Box(5) != '5'



# Generated at 2022-06-12 04:49:07.665783
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:49:09.655479
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)



# Generated at 2022-06-12 04:49:11.829133
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-12 04:49:13.525945
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box('Hello') == Box('Hello')


# Generated at 2022-06-12 04:49:16.772591
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    eq_(Box('123'), Box('123'))
    eq_(Box('123'), Box('1234')) is False
    eq_(Box('1'), Box('123')) is False



# Generated at 2022-06-12 04:49:27.186115
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box monad.
    """
    
    from pymonet.lazy import Lazy
    
    box = Box(42)
    
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fold(lambda: 4) == 42
    assert lazy.map(lambda x: x ** 2).fold(lambda: 4) == 1764

# Generated at 2022-06-12 04:49:30.025313
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    box = Box(1)
    lazy = box.to_lazy()
    assert box == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:33.198117
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()


# Generated at 2022-06-12 04:49:35.981309
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box(2) != None  # noqa: E711
    assert Box(2) != 1



# Generated at 2022-06-12 04:49:46.035574
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(None) == Box(None) # Test for 0
    assert Box(None) != Box(0) # Test for 0
    assert Box(None) != Box(1) # Test for 1
    assert Box(None) != Box('') # Test for ''
    assert Box(None) != Box('not an empty string') # Test for 'not an empty string'
    assert Box(None) != Box([]) # Test for []
    assert Box(None) != Box([0]) # Test for [0]
    assert Box(None) != Box([0,1]) # Test for [0,1]
    assert Box(None) != Box([0,1,[]]) # Test for [0,1,[]]
    assert Box(None) != Box({}) # Test for {}
    assert Box(None) != Box({'foo': 'bar'})

# Generated at 2022-06-12 04:49:48.915542
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    # given
    box = Box(42)

    # when
    lazy = box.to_lazy()

    # then
    assert lazy.value() == 42


# Generated at 2022-06-12 04:49:50.791997
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    test_value = 10
    assert Box(test_value).to_lazy().evaluate() == test_value

# Generated at 2022-06-12 04:49:52.789435
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-12 04:49:57.010845
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from hypothesis import given
    from hypothesis.strategies import integers

    @given(integers())
    def test_cases(value):
        assert Box(value) == Box(value)
        assert not Box(value) == Box(value + 1)

    test_cases()


# Generated at 2022-06-12 04:49:59.108329
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(10) == Box(10)
    assert Box(10) != Box(20)



# Generated at 2022-06-12 04:50:06.988300
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)

    assert Box(1) != Box(2)

    assert Box('True') != True

# Generated at 2022-06-12 04:50:17.797280
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_lazy().__dict__ == Lazy(lambda: 1).__dict__
    assert Box(Exception).to_lazy() == Lazy(lambda: Exception)
    assert Box(Exception).to_lazy().__dict__ == Lazy(lambda: Exception).__dict__
    assert Box(1).to_lazy().map(lambda x: x + 1) == Lazy(lambda: 2)
    assert Box(1).to_lazy().map(lambda x: x + 1).__

# Generated at 2022-06-12 04:50:21.156133
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: Box(1).bind(lambda x: x))

# Generated at 2022-06-12 04:50:23.667387
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:50:25.072613
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(4).to_lazy().fold() == 4



# Generated at 2022-06-12 04:50:27.261888
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 10
    assert Box(value).to_lazy() == Lazy(lambda: value)

# Generated at 2022-06-12 04:50:28.562292
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)

# Generated at 2022-06-12 04:50:30.242070
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(10) == Box(10)
    assert not (Box(10) == Box(100))



# Generated at 2022-06-12 04:50:31.951485
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(15)
    assert Box(10) != 10



# Generated at 2022-06-12 04:50:35.561259
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def _print_hello_world():
        print('Hello world!')

    assert Box(lambda: _print_hello_world()).to_lazy() == Lazy(lambda: _print_hello_world())



# Generated at 2022-06-12 04:50:47.888416
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == "1")



# Generated at 2022-06-12 04:50:50.449487
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """

    assert Box(1) == Box(1)

    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:50:52.598185
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest  # type: ignore
    from pymonet.lazy import Lazy

    assert Box('test').to_lazy() == Lazy(lambda: 'test')

# Generated at 2022-06-12 04:51:00.101493
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    # scenario 1: test equal Box
    t1 = Box('test1')
    t2 = Box('test1')
    assert t1 == t2

    # scenario 2: test not equal Box with different values
    t3 = Box('test3')
    assert t3 != t1

    # scenario 3: test not equal Box with different types
    t4 = Box(4)
    assert t4 != t1

    # scenario 4: test not equal Box with None
    assert t4 != None


# Generated at 2022-06-12 04:51:02.147553
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    __test_to_lazy(Box(1).to_lazy(), 'Box')


# Generated at 2022-06-12 04:51:04.925844
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(lambda: "Hello World").to_lazy() == Lazy(lambda: "Hello World")



# Generated at 2022-06-12 04:51:13.627023
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # given
    first_value = 100
    second_value = 200
    first_box = Box(first_value)
    second_box = Box(first_value)
    third_box = Box(second_value)

    # when
    first_eq_second = first_box == second_box
    first_eq_third = first_box == third_box
    first_eq_int = first_box == first_value
    int_eq_second = first_value == second_box

    # then
    assert first_eq_second
    assert not first_eq_third
    assert not first_eq_int
    assert not int_eq_second



# Generated at 2022-06-12 04:51:17.361341
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # initialization
    box_value = 45
    expected_lazy_result = 45

    # action
    lazy_result = Box(box_value).to_lazy()

    # assertion
    assert lazy_result.value() == expected_lazy_result

# Generated at 2022-06-12 04:51:20.123188
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.maybe import Unit

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(Unit()) != Box(2)



# Generated at 2022-06-12 04:51:21.952534
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_value = Lazy(lambda: 1)
    assert Box(1).to_lazy() == lazy_value

# Generated at 2022-06-12 04:51:34.053148
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().fold() == 42

# Generated at 2022-06-12 04:51:36.610100
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Box(42).to_lazy()  

    assert isinstance(lazy, Lazy)

# Generated at 2022-06-12 04:51:47.413662
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box(True) == Box(True)
    assert Box((1, 2)) == Box((1, 2))
    assert Box({'a': 1, 'b': 2}) == Box({'a': 1, 'b': 2})
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box([1, 2, 3]) != Box([1, 2])
    assert Box('abc') != Box('abcd')
    assert Box(set([1, 2, 3])) == Box(set([1, 2, 3]))
    assert Box(set([1, 2, 3])) != Box(set([1, 2, 3, 4]))

# Generated at 2022-06-12 04:51:50.447233
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    >>> from pymonet.box import Box
    >>> from pymonet.lazy import Lazy
    >>> Box('foo').to_lazy() == Lazy(lambda: 'foo')
    True
    """
    pass



# Generated at 2022-06-12 04:51:53.207630
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('test_value').to_lazy() == Lazy(lambda: 'test_value')


# Generated at 2022-06-12 04:51:55.604280
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != []



# Generated at 2022-06-12 04:51:57.530474
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:52:00.104393
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_value = Box(1).to_lazy()

    assert lazy_value.is_folded() is False
    assert lazy_value.value() == 1

# Generated at 2022-06-12 04:52:06.306187
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('test') == Box('test')
    assert Box('test') != Box('teest')
    assert Box([1, 2, 3, [4, 5]]) == Box([1, 2, 3, [4, 5]])
    assert Box([1, 2, 3, [4, 5]]) != Box([1, 2, 4, [4, 5]])


# Generated at 2022-06-12 04:52:07.709456
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(5).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 5

# Generated at 2022-06-12 04:52:20.823380
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(2) == Box(1)
    assert not Box(2) == 1



# Generated at 2022-06-12 04:52:22.273779
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(42).to_lazy()
    assert lazy.fold() == 42



# Generated at 2022-06-12 04:52:25.398468
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.mappers import identity
    from pymonet.lazy import Lazy

    box = Box(1)

    result = box.to_lazy()

    assert isinstance(result, Lazy)
    assert result.map(identity) == 1

# Generated at 2022-06-12 04:52:27.659298
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('1') == Box('1')
    assert not Box('1') == Box(1)


# Generated at 2022-06-12 04:52:29.287017
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != object()


# Generated at 2022-06-12 04:52:33.639429
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().eval() == 5
    assert Box(5).to_lazy().map(lambda x: x+5).eval() == 10
    assert Box(5).to_lazy().map(lambda x: x+5).map(lambda x: x**2).eval() == 100

# Generated at 2022-06-12 04:52:37.684463
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Box(10).to_lazy() == Lazy(lambda: 10)

    assert Box(Maybe.none()).to_lazy() == Lazy(lambda: Maybe.none())

# Generated at 2022-06-12 04:52:40.730965
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)
    assert box1 == box2
    assert not(box1 == box3)



# Generated at 2022-06-12 04:52:42.690100
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 2


# Generated at 2022-06-12 04:52:44.046088
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('a').to_lazy().fold() == 'a'

# Generated at 2022-06-12 04:53:08.030102
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    a = Box(1)
    b = Box(1)
    assert a == b



# Generated at 2022-06-12 04:53:09.080560
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:53:11.355612
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(5)
    assert box.to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 04:53:12.225350
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 04:53:15.078825
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """

    box_first = Box(10)
    box_second = Box(10)
    assert box_first == box_second, ''



# Generated at 2022-06-12 04:53:15.870238
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('test') == Box('test')

# Generated at 2022-06-12 04:53:17.908559
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box.unit(2)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: 2)


# Generated at 2022-06-12 04:53:20.702049
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy

    box = Box(10)

    assert box.to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 04:53:22.150594
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy().bind(lambda x: x)

# Generated at 2022-06-12 04:53:23.812402
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 04:53:50.570702
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)

    assert not (Box(4) == Box(3))



# Generated at 2022-06-12 04:53:54.407829
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 2
    assert Box(1) != 1



# Generated at 2022-06-12 04:53:58.142342
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    b = Box(1)
    l = b.to_lazy()

    assert str(l) == 'Lazy[f=<function Box_to_lazy.<locals>.<lambda> at 0x7f4cd0eb2d90>]'

    assert l.value() == 1



# Generated at 2022-06-12 04:54:07.547013
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box({'a': 1}) == Box({'a': 1})
    assert Box(None) == Box(None)

    assert Box(1) != Box(1.0)
    assert Box('a') != Box('')
    assert Box([1, 2, 3]) != Box([1, 2])
    assert Box({'a': 1}) != Box({'a': 1.0})
    assert Box(None) != Box('')


# Generated at 2022-06-12 04:54:13.998820
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)
    box4 = Box('2')
    box5 = Box('2')

    assert box1 == box1
    assert box1 == box2
    assert not box1 == box3
    assert not box1 == box4
    assert box4 == box4
    assert box4 == box5



# Generated at 2022-06-12 04:54:15.835484
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))



# Generated at 2022-06-12 04:54:17.835459
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('1') == Box('1')



# Generated at 2022-06-12 04:54:24.499535
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.optional import Optional
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    from pymonet.monad_try import Try

    # Test int
    assert Optional(Lazy(lambda: Box(1)).bind(Box.to_lazy).fold()) == 1

    # Test str
    assert Optional(Lazy(lambda: Box("test").bind(Box.to_lazy).fold())) == "test"

    # Test left either
    assert Optional(Lazy(lambda: Box(Left("test")).bind(Box.to_lazy).fold())) == Left("test")

    # Test success try
    assert Optional(Lazy(lambda: Box(Try("test")).bind(Box.to_lazy).fold())) == Try("test")

# Generated at 2022-06-12 04:54:27.238224
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:54:29.356413
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(10)
    assert box.to_lazy().is_folded is False
    assert box.to_lazy().unfold()() == 10

# Generated at 2022-06-12 04:55:23.030423
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box('Box')
    assert box == Box('Box')



# Generated at 2022-06-12 04:55:23.978223
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert (Box(4).to_lazy()).extract()() == 4

# Generated at 2022-06-12 04:55:25.119805
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:55:27.153802
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box('1') != '1'
    assert Box(1) != None

# Generated at 2022-06-12 04:55:29.462119
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == 2



# Generated at 2022-06-12 04:55:32.033245
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert not (Box(2) == Box(3))
    assert Box(2) != Box(3)
    assert not (Box(2) != Box(2))



# Generated at 2022-06-12 04:55:34.817610
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box([1,2]) == Box([1,2])

    assert not Box(1) == Box(2)
    assert not Box(1) == Box('a')
    assert not Box(1) == Box([])



# Generated at 2022-06-12 04:55:37.000502
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) == Box(1)) == True
    assert (Box(1) == Box(2)) == False



# Generated at 2022-06-12 04:55:38.298580
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)



# Generated at 2022-06-12 04:55:41.452952
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    def test_success():
        assert Box(1) == Box(1)
    test_success()

    def test_failure():
        assert not Box(1) == Box(2)
    test_failure()

# Unit tests for method map of class Box