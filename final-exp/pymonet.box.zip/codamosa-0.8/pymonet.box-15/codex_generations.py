

# Generated at 2022-06-12 04:47:25.934130
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(5)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: 5)

# Generated at 2022-06-12 04:47:28.505766
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Lazy(lambda: 2) == Box(2).to_lazy()



# Generated at 2022-06-12 04:47:34.205696
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def function(x: int, y: int) -> int:
        return x + y

    assert Box(4).to_lazy() == Lazy(lambda: 4)
    assert Box(function).to_lazy() == Lazy(lambda: function)



# Generated at 2022-06-12 04:47:36.928831
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Box to Lazy test
    Box("hello").to_lazy() == Lazy("hello")
    assert isinstance(Box("hello").to_lazy(), Lazy)

# Generated at 2022-06-12 04:47:38.271427
# Unit test for method __eq__ of class Box
def test_Box___eq__():  #
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != "1"



# Generated at 2022-06-12 04:47:40.006011
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))


# Generated at 2022-06-12 04:47:42.267997
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 04:47:50.832620
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    # Create boxed data with value 6
    test_box = Box(6)

    # Check that value is 6
    assert test_box.value == 6

    # Convert to lazy function with return value
    lazy_test_box = test_box.to_lazy()

    # Check that type of lazy test box is Lazy
    assert isinstance(lazy_test_box, Lazy)

    # Execute lazy function from lazy test box
    execution_result = lazy_test_box.value_func()

    # Check that execution result is equal to 6
    assert execution_result == 6

    # Check that type of execution result is int
    assert isinstance(execution_result, int)

# Generated at 2022-06-12 04:47:53.564412
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test __eq__ method of Box
    """
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:47:57.030958
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method

    :return: nothing
    """
    from pymonet.lazy import Lazy
    value = "lazy"
    assert Box(value).to_lazy() == Lazy(lambda: value)

# Generated at 2022-06-12 04:48:04.363458
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    # Arrange
    from pymonet.lazy import Lazy
    box = Box('test')

    # Act
    lazy = box.to_lazy()

    # Assert
    assert isinstance(lazy, Lazy)
    assert lazy.computed_value == 'test'



# Generated at 2022-06-12 04:48:12.748584
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box(1).to_lazy()
    assert Box(1) != Box(1).to_maybe()
    assert Box(1) != Box(1).to_try()
    assert Box(1) != Box(1).to_validation()
    assert Box(1) != Try(1)
    assert Box(1) != Validation.success(1)



# Generated at 2022-06-12 04:48:14.708548
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None


# Generated at 2022-06-12 04:48:20.076397
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def inner_func():
        return 'inner'

    box_inner_func = Box(inner_func)
    lazy_func = box_inner_func.to_lazy()
    assert isinstance(lazy_func, Lazy)
    assert lazy_func.force() == 'inner'

# Generated at 2022-06-12 04:48:21.917668
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:48:23.138514
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:48:27.240346
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert(Box(3)==Box(3))
    assert(Box('asd')==Box('asd'))
    assert(Box(3)!=Box(3.0))



# Generated at 2022-06-12 04:48:28.606338
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    maybe = Box(3).to_lazy()

    assert maybe.value() == 3

# Generated at 2022-06-12 04:48:31.484176
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('hello').__eq__(Box('hello'))
    assert not Box('hello').__eq__(Box('world'))
    assert not Box(1).__eq__(Box('hello'))



# Generated at 2022-06-12 04:48:33.830265
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_value = Box(42)
    assert box_value.to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-12 04:48:37.075136
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 04:48:40.077303
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 'value'
    assert Box(value).to_lazy() == Lazy(lambda: value)

# Generated at 2022-06-12 04:48:46.700932
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    test_value = 42
    test_box = Box(test_value)
    test_lazy = test_box.to_lazy()

    assert isinstance(test_lazy, Lazy)
    assert test_lazy.is_folded() is False
    assert test_lazy.is_forced() is False
    assert test_lazy.get() == test_value
    assert test_lazy.is_folded() is False
    assert test_lazy.is_forced() is True

# Generated at 2022-06-12 04:48:52.029571
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    box = Box(1)

    # When
    lazy = box.to_lazy()

    # Then
    assert lazy is not None
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1


if __name__ == "__main__":
    test_Box_to_lazy()

# Generated at 2022-06-12 04:48:54.238322
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:01.380556
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of class Box. Should return Lazy Monad with function returning value.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_functions import unit_lazy

    box = Box(42)
    lazy = box.to_lazy()
    assert lazy == unit_lazy(42)
    assert lazy == Lazy(lambda: 42)
    assert lazy.fold() == box.value



# Generated at 2022-06-12 04:49:03.272791
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(123).to_lazy() == Lazy(lambda: 123)

# Generated at 2022-06-12 04:49:05.820444
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(8).to_lazy() == Lazy(lambda: 8)



# Generated at 2022-06-12 04:49:07.169527
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().fold() == 2

# Generated at 2022-06-12 04:49:09.211951
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(5)
    assert box.to_lazy().eval() == 5


# Generated at 2022-06-12 04:49:13.764389
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Verifies that Box can be transformed into Lazy by to_lazy method."""

    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 04:49:17.720875
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for Box.to_lazy()
    """
    from pymonet.lazy import Lazy

    value = 'Test'
    box = Box(value)
    lazy = Lazy(lambda: value)
    assert box.to_lazy() == lazy, "Box.to_lazy()"

# Generated at 2022-06-12 04:49:20.221943
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    x = Box(4)

    assert x.to_lazy() == Lazy(lambda: 4)



# Generated at 2022-06-12 04:49:23.777904
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box(True)
    lazy = box.to_lazy()
    assert lazy.is_callable()
    assert lazy == Lazy(box.value)

# Generated at 2022-06-12 04:49:26.314057
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test = Box(1)
    assert test.to_lazy().is_lazy()
    assert test.to_lazy().value == 1
    assert test.to_lazy().force() == 1

# Generated at 2022-06-12 04:49:28.717904
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:31.348423
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Just check the correct construct of Box.
    """

    assert Box('a').to_lazy().f() == 'a'

# Generated at 2022-06-12 04:49:36.519194
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(True).to_lazy() == Lazy(lambda: True)
    assert Box({'a': 1}).to_lazy() == Lazy(lambda: {'a': 1})


# Generated at 2022-06-12 04:49:38.118481
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold() == 1


# Generated at 2022-06-12 04:49:41.375389
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(5).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fold(lambda x: x) == 5


# Generated at 2022-06-12 04:49:46.585981
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Maybe(Box(1).to_lazy) == Maybe.just(Lazy.unit(1))

# Generated at 2022-06-12 04:49:49.495151
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(42).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fold() == 42


# Generated at 2022-06-12 04:49:56.715379
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.exceptions import NotFoldedError
    from pymonet.monad_unit_tests.monad_test import MonadTest

    def test_lazy_with_value(lazy_monad: Lazy, value, is_foldable=True, folded_value=None):
        lazy_monad.fold(lambda arg: arg, None)
        if folded_value is None:
            assert lazy_monad.is_folded
            assert lazy_monad.value == value
        else:
            assert lazy_monad.is_folded != is_foldable
            if lazy_monad.is_folded:
                assert lazy_monad.value == folded_value
            else:
                with pytest.raises(NotFoldedError):
                    lazy

# Generated at 2022-06-12 04:49:58.240701
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert isinstance(Box(5).to_lazy(), Lazy)
    assert Box(5).to_lazy() == Lazy(5)


# Generated at 2022-06-12 04:50:01.403404
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Testing method to_lazy of class Box.

    :returns: None
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert isinstance(Box(1).to_lazy(), Lazy)

# Generated at 2022-06-12 04:50:03.195508
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().value() == 42
    assert Box("42").to_lazy().value() == "42"



# Generated at 2022-06-12 04:50:06.101996
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(7)
    lazy_m = box.to_lazy()
    assert lazy_m.value == Lazy(lambda: 7).value

# Generated at 2022-06-12 04:50:08.736756
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 04:50:18.514066
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test transform Box into Lazy monad.

    :return True if test passed, otherwise return False
    :rtype: bool
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    x = Box(10)
    lazy = x.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fold(lambda: x.value) == 10
    assert lazy == Lazy(lambda: 10)
    assert lazy is not Lazy(lambda: 10)

    y = Lazy(lambda: Try(x, True).to_lazy()).fold(lambda: x.value)
    assert isinstance(y, Try)
    assert y.fold(lambda: 0, lambda: 1) == 1

# Generated at 2022-06-12 04:50:21.014867
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 04:50:24.935389
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).map(lambda x: lambda: x).value

# Generated at 2022-06-12 04:50:26.776770
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    with pytest.raises(NameError):
        Box("test_Box_to_lazy").to_lazy()

# Generated at 2022-06-12 04:50:29.846811
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box_lazy = Box(1).to_lazy()
    assert isinstance(box_lazy, Lazy)
    assert box_lazy.value() == 1


# Generated at 2022-06-12 04:50:30.934347
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().get_value() == 3



# Generated at 2022-06-12 04:50:32.875547
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Testing lazy box

    :returns: None
    """
    from pymonet.lazy import Lazy

    assert Box(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 04:50:36.275166
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Box(2).to_lazy() == Lazy(lambda: 2)
    assert Box(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 04:50:39.906550
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(3)
    lazy = box.to_lazy()
    assert lazy.value() == 3
    assert isinstance(lazy, Lazy)


# Generated at 2022-06-12 04:50:42.343448
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:50:44.576991
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert_equals(Box('foo').to_lazy(),
                  Lazy(lambda: 'foo'))


# Generated at 2022-06-12 04:50:48.172892
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Tests for method to_lazy of class Box."""
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() != Lazy(lambda: 10)
    assert Box(10).to_lazy().fold() == 10

# Generated at 2022-06-12 04:50:55.431222
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert(Box(5).to_lazy() == Lazy(lambda: 5))

# Generated at 2022-06-12 04:50:57.164720
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-12 04:50:59.189869
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()


# Generated at 2022-06-12 04:51:00.464626
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(12).to_lazy() == Lazy(lambda: 12)

# Generated at 2022-06-12 04:51:02.110067
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value == 1


# Generated at 2022-06-12 04:51:04.511466
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_int: Lazy[int] = Box(5).to_lazy()

    assert lazy_int.value() == 5

# Generated at 2022-06-12 04:51:08.458886
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for Box.to_lazy method
    """
    from pymonet.lazy import Lazy

    box = Box(42)
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.fold() == 42

# Generated at 2022-06-12 04:51:11.487184
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Box(5).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fold()() == 5

# Generated at 2022-06-12 04:51:21.348091
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    value = 'Some value'
    box = Box(value)
    lazy = Lazy(lambda: value)

    assert box.to_lazy() == lazy
    assert box.to_lazy().map(lambda x: x + value) == lazy.map(lambda x: x + value)

    assert box.to_lazy().flat_map(lambda x: Lazy(lambda: x + value)) == \
           lazy.flat_map(lambda x: Lazy(lambda: x + value))

    assert box.to_lazy().flat_map(lambda x: Lazy(lambda: x + value)) == Lazy(lambda: value + value)

    assert box.to_lazy().to_maybe() == Maybe.just(value)


#

# Generated at 2022-06-12 04:51:25.184174
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(10).to_lazy().value() is 10



# Generated at 2022-06-12 04:51:37.402878
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box(42).to_lazy().fmap(lambda x: x + 1).evaluate() == 43


# Generated at 2022-06-12 04:51:40.113369
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box[int](5).to_lazy().is_folded() is False
    assert Box[int](5).to_lazy().value() == 5



# Generated at 2022-06-12 04:51:44.643084
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # GIVEN
    i: int = 1
    b: Box[int] = Box(i)

    # WHEN
    l: Lazy[int] = b.to_lazy()

    # THEN
    assert(isinstance(l, Lazy))
    assert(l.value() == i)



# Generated at 2022-06-12 04:51:48.657065
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # given
    value = 5
    lazy_result = Lazy(lambda: value)
    # when
    result = Box(value).to_lazy()
    # then
    assert result == lazy_result
    assert result.value == lazy_result.value


# Generated at 2022-06-12 04:51:54.167293
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(5).to_lazy().map(lambda x: x * 3) == Lazy(lambda: 15)
    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:51:55.717930
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:52:05.521473
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Box(0).to_lazy() == Lazy(lambda: 0)
    assert Box(0).to_try().to_lazy() == Lazy(lambda: Try(0, True))
    assert Box(0).to_either().to_lazy() == Lazy(lambda: Right(0))
    assert Box(0).to_maybe().to_lazy() == Lazy(lambda: Maybe.just(0))
    assert Box(0).to_validation().to_lazy() == Lazy(lambda: Validation.success(0))

# Generated at 2022-06-12 04:52:07.790253
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:52:09.453967
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy() == lazy(3)


# Generated at 2022-06-12 04:52:11.974324
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:52:30.431785
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert isinstance(Box(1).to_lazy(), Lazy)
    assert isinstance(Box(1.2).to_lazy(), Lazy)
    assert isinstance(Box('str').to_lazy(), Lazy)
    assert isinstance(Box(True).to_lazy(), Lazy)
    assert isinstance(Box([1, 2, 3]).to_lazy(), Lazy)
    assert isinstance(Box({1, 2, 3}).to_lazy(), Lazy)
    assert isinstance(Box({'a': 1, 'b': 2, 'c': 3}).to_lazy(), Lazy)
    assert isinstance(Box(lambda x: x + 1).to_lazy(), Lazy)


# Generated at 2022-06-12 04:52:33.485638
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    a_box = Box(2)

    # Act
    lazy = a_box.to_lazy()

    # Assert
    assert lazy == Lazy(lambda: 2)

# Generated at 2022-06-12 04:52:35.497414
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Given
    value = 123456

    # When
    result = Box(value).to_lazy()

    # Then
    assert result.value() == value

# Generated at 2022-06-12 04:52:38.565189
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box_value: Lazy[int] = Box(10).to_lazy()
    assert box_value.value() == 10

# Generated at 2022-06-12 04:52:40.767349
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Box(5).to_lazy()


# Generated at 2022-06-12 04:52:46.570529
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try, Failure

    assert(Box(1).to_lazy() == Lazy(lambda: 1))
    assert(Try(1).to_lazy() == Lazy(lambda: Try(1, is_success=True)))
    assert(Try(1, is_success=False).to_lazy() ==
           Lazy(lambda: Try(1, is_success=False)))
    assert(Failure('Exception').to_lazy() ==
           Lazy(lambda: Failure('Exception')))



# Generated at 2022-06-12 04:52:49.656494
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for Box_to_lazy method.
    """
    from pymonet.lazy import Lazy
    assert Box(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 04:52:53.373345
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy

    assert Box(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 04:52:55.183186
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().to_list() == [1]



# Generated at 2022-06-12 04:52:57.935892
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:53:21.421475
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy()._value()() == 1

# Generated at 2022-06-12 04:53:26.901236
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    # !! Attention !!
    # This function passed only if you are execute test file, but it will not
    # passed if you execute all tests from repository because of box import!
    from pymonet.lazy import Lazy
    box = Box(1)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fold() == box.value

# Generated at 2022-06-12 04:53:29.601125
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    test_data = 42

    # When
    lazy_box = Box(test_data).to_lazy()

    # Then
    assert lazy_box.is_folded() is False
    assert lazy_box.value() == test_data



# Generated at 2022-06-12 04:53:39.093170
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    def times_2(value):
        return value * 2
    box = Box(1)
    lazy_box = box.to_lazy()
    assert lazy_box.is_folded() is False
    folded_lazy_box = lazy_box.call()
    assert isinstance(folded_lazy_box, Lazy)
    assert folded_lazy_box.is_folded() is True
    lazy_times_2_box = folded_lazy_box.map(times_2)
    assert isinstance(lazy_times_2_box, Lazy)
    assert lazy_times_2_box.is_folded() is False
    assert lazy_times_2_box.call() == 2
    assert lazy_times_2_box.is_folded

# Generated at 2022-06-12 04:53:45.968468
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(10).to_lazy().force() == 10
    assert Box("foo").to_lazy().force() == "foo"
    assert Box([1, 2, 3]).to_lazy().force() == [1, 2, 3]
    assert Box(type(lambda: 0)).to_lazy().force() == type(lambda: 0)
    assert Box(0.9).to_lazy().force() == 0.9
    assert Box({'a': 1, 'b': 2}).to_lazy().force() == {'a': 1, 'b': 2}


# Generated at 2022-06-12 04:53:47.968464
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Box(5).to_try().to_either().to_maybe().to_lazy()

# Generated at 2022-06-12 04:53:49.920285
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """Unit test for method to_lazy of class Box"""

    assert Box(10).to_lazy().fold() == 10

# Generated at 2022-06-12 04:53:51.991406
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Box(2).map(lambda x: lambda: x).value



# Generated at 2022-06-12 04:53:55.785342
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy

    assert Box('foo').to_lazy() == Lazy(lambda: 'foo')


# Generated at 2022-06-12 04:53:58.502550
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    >>> test_Box_to_lazy()
    True
    """

    from pymonet.lazy import Lazy

    laz = Box(2).to_lazy()
    return isinstance(laz, Lazy) and laz.eval() == 2


# Generated at 2022-06-12 04:54:40.196248
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:54:42.357748
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def function():
        return 5

    assert Box(function).to_lazy() == Lazy(function)


# Generated at 2022-06-12 04:54:43.947159
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test box to lazy monad transformation.
    """
    assert Box(10).to_lazy().value() == 10

# Generated at 2022-06-12 04:54:46.049963
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)
    assert Box('abc').to_lazy() == Lazy(lambda: 'abc')


# Generated at 2022-06-12 04:54:47.294485
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().force() == 1

# Generated at 2022-06-12 04:54:50.232676
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    value = 'value'
    lazy = Box(value).to_lazy()

    assert lazy.value() == value



# Generated at 2022-06-12 04:54:52.322327
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:54:54.450631
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    box = Box(1)

    # Act
    lazy = box.to_lazy()

    # Assert
    assert lazy.value() == 1

# Generated at 2022-06-12 04:54:57.506317
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(2).to_lazy() == Lazy(lambda: 2)
    assert Box('a').to_lazy() == Lazy(lambda: 'a')



# Generated at 2022-06-12 04:54:59.641364
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # GIVEN
    box = Box(1)

    # WHEN
    lazy_value = box.to_lazy()

    # THEN
    assert lazy_value.value == 1

# Generated at 2022-06-12 04:56:43.875303
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(100).to_lazy() == Lazy(lambda: 100)


# Generated at 2022-06-12 04:56:48.047795
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    "to_lazy" method in Box class should return not folded Lazy with function returning value.

    :returns: result of unit test
    :rtype: bool
    """

    def _():
        from pymonet.lazy import Lazy

        return Lazy(lambda: "value")

    assert Box("value").to_lazy() == _()

# Generated at 2022-06-12 04:56:49.906612
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('new value').to_lazy().value() == 'new value'


# Generated at 2022-06-12 04:56:55.656872
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from typing import Callable

    # Function returning Box with number 2
    foo: Callable[[], Box[int]] = lambda: Box(2)
    # Var contains lazy monad with function returning Box
    lazy: Lazy[Callable[[], Box[int]]] = foo.to_lazy()
    # Check that lazy in not folded
    assert lazy.is_folded is False
    # Check that result of calling function from lazy monad equals to Box
    assert lazy.value() == Box(2)



# Generated at 2022-06-12 04:56:57.366350
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(None)

    lazy = box.to_lazy()

    assert lazy.fold(lambda: 1) == 1

# Generated at 2022-06-12 04:57:02.066157
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy_try = Box(Try.success('foo'))
    assert lazy_try.to_lazy() == Lazy(lambda: Try.success('foo'))

    lazy_lazy = Box(Lazy(lambda: 'foo'))
    assert lazy_lazy.to_lazy() == Lazy(lambda: Lazy(lambda: 'foo'))

# Generated at 2022-06-12 04:57:11.317549
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy()
    assert Box(1).to_lazy() != Box(2).to_lazy()
    assert str(Box(1).to_lazy()) == 'Lazy[value=<function Box.<lambda> at 0x7f63e998e598>]'
    assert Box(1).to_lazy().to_lazy() == Box(1).to_lazy()
    assert Box(1).to_lazy().bind(lambda x: x + 1) == 2
    assert Box(1).to_lazy().bind(lambda x: x + 1) != 3
    assert Box(1).to_lazy().bind(lambda x: x + 1) != 0

# Generated at 2022-06-12 04:57:13.444891
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_func(arg):
        assert arg == 42

    Box(42).to_lazy().map(test_func).get_value()


# Generated at 2022-06-12 04:57:15.481349
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)  # pragma: no cover



# Generated at 2022-06-12 04:57:17.944839
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(5)
    lazy = Lazy(lambda: 5)

    assert box.to_lazy() == lazy

