

# Generated at 2022-06-12 04:47:29.226969
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().get() == 5
    assert Box("Hello World!").to_lazy().get() == "Hello World!"
    assert Box((1, 2)).to_lazy().get() == (1, 2)
    assert Box(dict({"a": 5})).to_lazy().get() == dict({"a": 5})
    assert Box(set([1, 2, 3])).to_lazy().get() == set([1, 2, 3])


# Generated at 2022-06-12 04:47:31.573656
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_box = Box(lambda: 1)
    lazy_box = test_box.to_lazy()
    assert lazy_box.value() == 1

# Generated at 2022-06-12 04:47:35.507010
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box(1) != Box(2)
    assert Box(1) != 1

# Generated at 2022-06-12 04:47:42.871819
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1.0) == Box(1.0)
    assert Box('a') == Box('a')
    assert Box((4, 5)) == Box((4, 5))
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box({'a': 1, 'b': 2}) == Box({'a': 1, 'b': 2})
    assert Box({1, 2, 3}) == Box({1, 2, 3})
    assert Box(None) == Box(None)


# Generated at 2022-06-12 04:47:47.083944
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # given
    box_1 = Box(1)
    box_2 = Box(1)
    box_3 = Box(2)
    box_4 = 2
    # then
    assert box_1 == box_2 is True
    assert box_1 == box_3 is False
    assert box_3 == box_4 is False



# Generated at 2022-06-12 04:47:48.990260
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:47:50.633604
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(11) != Box(10)



# Generated at 2022-06-12 04:47:54.630357
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:47:58.906346
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Test to_lazy of class Box.

    :return: None
    :rtype: None
    """
    assert Box(1).to_lazy().value() == 1

# Generated at 2022-06-12 04:48:01.150371
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(0)
    assert Box('A') == Box('A')



# Generated at 2022-06-12 04:48:04.452259
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('foo') == Box('foo')
    assert Box('foo') != Box('bar')



# Generated at 2022-06-12 04:48:09.599148
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    value = {'value': 'python'}
    box = Box(value)

    # when
    lazy = box.to_lazy()

    # than
    assert isinstance(lazy, Lazy)
    assert lazy.is_folded() is False
    assert lazy.get() == value



# Generated at 2022-06-12 04:48:10.888978
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == 1



# Generated at 2022-06-12 04:48:14.663523
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)
    assert not Box(1) == Box(2)
    assert not Box(1) == None
    assert not Box(1) == 'Box[value=1]'


# Generated at 2022-06-12 04:48:17.030713
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box('string') == Box('string')



# Generated at 2022-06-12 04:48:20.200989
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == 'Box(1)')



# Generated at 2022-06-12 04:48:22.422891
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(4) != 2


# Generated at 2022-06-12 04:48:24.582608
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 04:48:28.697114
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.is_folded is False


# Generated at 2022-06-12 04:48:35.223260
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Arrange
    box_1 = Box(1)
    box_2 = Box(1)
    box_3 = Box(2)

    # Act
    result_1 = box_1 == box_2
    result_2 = box_1 == box_3
    result_3 = box_1 == 1

    # Assert
    assert isinstance(result_1, bool)
    assert isinstance(result_2, bool)
    assert isinstance(result_3, bool)
    assert result_1
    assert not result_2
    assert not result_3


# Generated at 2022-06-12 04:48:47.782500
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def g():
        yield 1
        yield 2
        yield 3

    def f():
        return 10

    def h():
        return list(g())

    class A(object):
        def __init__(self, x):
            self.x = x

        def __eq__(self, other):
            return isinstance(other, A) and self.x == other.x

    assert Box(g()) == Box(g())
    assert Box(f) == Box(f)
    assert Box(h) == Box(h)
    assert Box(1) == Box(1)
    assert Box(A(3)) == Box(A(3))
    assert Box(f).to_lazy() == Box(f).to_lazy()
    assert Box(f).to_lazy().value() == 10

# Generated at 2022-06-12 04:48:52.135109
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().map(lambda x: x + 10).get() == 11
    assert Box(1).to_lazy().map(lambda x: x + 10).map(lambda x: x * 10).get() == 110



# Generated at 2022-06-12 04:48:54.328955
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != 1
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:48:58.131306
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box(1)
    box_2 = Box(1)
    box_3 = Box(2)
    assert box_1 == box_2
    assert box_1 != box_3
    assert box_2 != box_3



# Generated at 2022-06-12 04:49:01.703103
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == 'AAA')
    assert not (Box(1) == None)
    assert not (Box(1) == 1)


# Generated at 2022-06-12 04:49:03.516817
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:49:05.299920
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) == Box(1))



# Generated at 2022-06-12 04:49:08.456643
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    x = Box(10)
    y = Box(10)
    z = Box(20)
    assert (x == y) == True
    assert (y == z) == False


# Generated at 2022-06-12 04:49:16.411433
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box[int](1) == Box[int](1)
    assert Box[str]('hello') == Box[str]('hello')
    assert Box[list]([1, 2]) == Box[list]([1, 2])
    assert Box[int](1) != Box[int](2)
    assert Box[int](1) != Box[str]('1')
    assert Box[int](1) != Box[list](['1'])
    assert Box[str]('1') != Box[int](1)
    assert Box[list](['1']) != Box[int](1)


# Generated at 2022-06-12 04:49:18.428462
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box.
    """
    assert Box("Hello") == Box("Hello")


# Generated at 2022-06-12 04:49:27.001157
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)
    assert not (Box(1) == Box(2))



# Generated at 2022-06-12 04:49:29.306504
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(10)
    assert box.to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:49:32.306386
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('a').to_lazy() == Lazy(lambda: 'a')


# Generated at 2022-06-12 04:49:36.470751
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box('test1')
    box2 = Box('test1')

    assert box1 == box2

    box3 = Box('test3')

    assert box1 != box3

    assert box1 == box1
    assert box2 == box2
    assert box3 == box3



# Generated at 2022-06-12 04:49:40.785227
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test of transforming Box into not folded Lazy monad with function returning previous box value.

    :returns: None
    :raises: AssertionError
    """
    assert Box([1, 2, 3]).to_lazy().unpack() == [1, 2, 3]



# Generated at 2022-06-12 04:49:43.513224
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(20)
    assert Box(None) != Box(10)
    assert Box('a') != Box('b')



# Generated at 2022-06-12 04:49:52.295942
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(2).to_lazy() == Lazy(lambda: 2)
    assert Box('pymonet').to_lazy() == Lazy(lambda: 'pymonet')

# Generated at 2022-06-12 04:49:55.516952
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    box = Box(10)
    another_box = Box(10)

    assert box.__eq__(another_box)

    another_box.value = 15

    assert not box.__eq__(another_box)

# Generated at 2022-06-12 04:49:58.152080
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box('string') != Box(5)
    assert Box('string') != Box('another string')


# Generated at 2022-06-12 04:50:01.371575
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box.
    """

    a = Box(1)
    b = Box(1)
    c = Box(2)
    assert(a == b)
    assert(a != c)



# Generated at 2022-06-12 04:50:08.735887
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().value() == 42

# Generated at 2022-06-12 04:50:16.599440
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad
    from pymonet.utils import eq

    assert isinstance(Box(1).to_lazy(), Lazy)
    assert isinstance(Box(1).to_lazy(), Monad)
    assert isinstance(Box(1).to_lazy(), Monad)
    assert eq(Box(1).to_lazy().fold(), Box(1).value)
    assert eq(Box('string').to_lazy().fold(), Box('string').value)


# Generated at 2022-06-12 04:50:20.916835
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for Box#to_lazy method

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-12 04:50:24.934795
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert callable(Box(2).to_lazy().value())
    assert Box(2).to_lazy().value() == 2
    assert Box(2).to_lazy().equals(Box(2).to_lazy())


# Generated at 2022-06-12 04:50:27.939751
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def return_5():
        return 5

    assert Box(return_5).to_lazy() == Lazy(return_5, folded=False)

# Generated at 2022-06-12 04:50:29.460280
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest

    with pytest.raises(AttributeError):
        Box(6).to_lazy()

# Generated at 2022-06-12 04:50:31.363729
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest
    def f():
        return 1

    box = Box(1)
    assert box.to_lazy().unwrap() == f()



# Generated at 2022-06-12 04:50:33.037268
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box.to_lazy(Box(1))._is_folded is False
    assert Box.to_lazy(Box(1))._value()() == 1

# Generated at 2022-06-12 04:50:36.955893
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy

    assert Box(lambda x: x + 1).to_lazy() == Lazy(lambda: lambda x: x + 1)
    assert Box(None).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 04:50:40.029590
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('x').to_lazy().value() == 'x'
    assert Box({'x': 1}).to_lazy().value() == {'x': 1}


# Generated at 2022-06-12 04:50:47.496457
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'a') == Box('a').to_lazy()


# Generated at 2022-06-12 04:50:50.818165
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy_box = Box(1).to_lazy()
    assert lazy_box is not None
    assert isinstance(lazy_box, Lazy)
    assert lazy_box.value() == 1

# Generated at 2022-06-12 04:50:53.245755
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Asserting to_lazy method
    assert Box(3).to_lazy().fold() == 3
    assert Box('3').to_lazy().fold() == '3'

# Generated at 2022-06-12 04:50:55.479059
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    expected = 2
    actual = Box(2).to_lazy().value()
    assert expected == actual



# Generated at 2022-06-12 04:50:57.212175
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold() == 1

# Generated at 2022-06-12 04:51:02.686583
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monoid import Monoid

    b_lazy = Lazy(lambda: Box('foo'))

    assert isinstance(b_lazy.fmap(Box.to_lazy).value, Lazy) and \
           isinstance(b_lazy.fmap(Box.to_lazy).value.value, Callable) and \
           b_lazy.fmap(Box.to_lazy).value.value() == Box(Monoid[str].mempty())


# Generated at 2022-06-12 04:51:04.020256
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    val = 42
    assert Box(val).to_lazy().value() is not val

# Generated at 2022-06-12 04:51:09.111145
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box.to_lazy method
    """
    from pymonet.lazy import Lazy

    f = lambda: 'Hello, world!'

    lazy = Box(f).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == f()
    assert lazy.is_folded is False



# Generated at 2022-06-12 04:51:12.849009
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad import Lazy

    box = Box(1)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: 1)
    assert lazy.is_valuated() is False
    assert lazy.value == 1


# Generated at 2022-06-12 04:51:16.386376
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(5)
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.fold() == box.value

# Generated at 2022-06-12 04:51:28.456291
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('abc').to_lazy() == Lazy(lambda: 'abc')

# Generated at 2022-06-12 04:51:30.693825
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1).to_lazy()
    assert box.f() == 1

# Generated at 2022-06-12 04:51:33.079210
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box monad
    """
    from pymonet.lazy import Lazy

    assert Box('test').to_lazy() == Lazy(lambda: 'test')

# Generated at 2022-06-12 04:51:35.480170
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 04:51:38.493193
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    result = Box(10).to_lazy()

    assert Lazy(lambda: 10) == result

    # This line fails because Lazy was not evaluated yet
    assert 10 == result.value()



# Generated at 2022-06-12 04:51:40.125260
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().evaluate() == 5

# Generated at 2022-06-12 04:51:42.285835
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 42) == Box(42).to_lazy()

# Generated at 2022-06-12 04:51:46.391164
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 42) == Box(42).to_lazy()



# Generated at 2022-06-12 04:51:48.918141
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(1).to_lazy().force() == 1, 'Test failed'



# Generated at 2022-06-12 04:51:50.712943
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:52:17.177479
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest
    from pymonet.lazy import Lazy

    param = 123
    box = Box(param)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == param

# Generated at 2022-06-12 04:52:21.419886
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    box = Box(4)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.value(), int)
    assert lazy.value() == 4

# Generated at 2022-06-12 04:52:23.576802
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    imported_lazy = Box(2).to_lazy()

    assert imported_lazy().value == 2



# Generated at 2022-06-12 04:52:25.542654
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Test Box class"""
    from pymonet.lazy import Lazy

    box = Box(1)

    assert box.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:52:27.237886
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 'a'

    assert Box('a').to_lazy() == Lazy(f)

# Generated at 2022-06-12 04:52:28.455062
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(5)
    assert box.to_lazy().fold() == 5



# Generated at 2022-06-12 04:52:35.173482
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_lazy import MonadLazy

    # Given: some number
    box = Box(2)

    # When: we are converting Box to Lazy
    lazy = box.to_lazy()

    # Then: lazy monad is correct and contains function returning value of box
    MonadLazy.unit_test_assert(
        monad=lazy,
        expected_value=box.value,
        expected_factory=lambda value: Lazy(lambda: value)
    )



# Generated at 2022-06-12 04:52:44.659289
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: no cover
    import pymonet.lazy as lazy

    # Test 1: test if Lazy created by method to_lazy() is lazy
    def f() -> int:
        return 7

    box = Box(f())
    lazy_box = box.to_lazy()
    assert lazy_box != lazy.Lazy(f())

    # Test 2: test if Lazy created by method to_lazy() is not folded and returned value is the same as previous value
    def f() -> str:
        return 'test'

    box = Box(f())
    lazy_box = box.to_lazy()
    assert not hasattr(lazy_box, 'value')
    assert lazy_box.fold(lambda x: x) == box.value

    # Test 3: test if function returned by Lazy created by method to_

# Generated at 2022-06-12 04:52:47.076240
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    test = Lazy(lambda: 1).to_box()
    assert test.value == 1

# Generated at 2022-06-12 04:52:53.115053
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import fold

    # Create some Box
    box = Box(0)

    # Transform Box into Lazy
    lazy = box.to_lazy()

    # Fold Lazy with + operator
    lazy_to_int = fold(lazy, lambda r, l: r + l)

    # Check that result is same as value of box (because only one element in Lazy)
    assert lazy_to_int == box.value



# Generated at 2022-06-12 04:53:48.218545
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(10).to_lazy().value() == 10
    assert Box(None).to_lazy().value() is None

# Generated at 2022-06-12 04:53:50.462781
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold(int) == 1
    assert Box('123').to_lazy().fold(str) == '123'


# Generated at 2022-06-12 04:53:54.941361
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.function import identity

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert identity(Box(1).to_lazy()) == Box(1).to_lazy()


# Generated at 2022-06-12 04:53:59.906633
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test lazy transformation from Box.

    :returns: True if test was successfull and False if not
    :rtype: Bool
    """
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad
    box = Box(4).to_lazy()
    assert Monad.isinstance(box)
    assert Monad.isinstance(Lazy(lambda: 1).value)
    assert isinstance(box.value, Monad)
    assert isinstance(box.value(), int)
    assert 4 == box.value()


# Generated at 2022-06-12 04:54:06.679351
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import LazyMonad
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert isinstance(Box(1).to_lazy(), LazyMonad)
    assert isinstance(Box(1).to_lazy(), Functor)
    assert isinstance(Box(1).to_lazy(), Monad)



# Generated at 2022-06-12 04:54:12.062562
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_test_helpers import evaluator

    assert Lazy(lambda: 10) == Box(10).to_lazy()
    assert Lazy(lambda: 10) == evaluator(Lazy(lambda: 10), Lazy(lambda: 10))

    assert Lazy(lambda: (10, 30)) == Box((10, 30)).to_lazy()
    assert Lazy(lambda: (10, 30)) == evaluator(Lazy(lambda: (10, 30)), Lazy(lambda: (10, 30)))

    assert Lazy(lambda: [10, 20]) == Box([10, 20]).to_lazy()

# Generated at 2022-06-12 04:54:20.761347
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    box = Box(5)
    lazy_result = box.to_lazy()
    assert(isinstance(lazy_result, Lazy))
    assert(lazy_result.is_folded() == False)
    assert(lazy_result.is_callable() == True)
    assert(lazy_result.is_exception() == False)

    lazy_result = lazy_result()
    assert(isinstance(lazy_result, Try))
    assert(lazy_result.is_success == True)
    assert(lazy_result.get() == 5)


# Generated at 2022-06-12 04:54:23.667094
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, LazyValue

    assert Box(3).to_lazy() == Lazy(lambda: 3)
    assert Box(3).to_lazy().get() == LazyValue(3)

# Generated at 2022-06-12 04:54:27.987283
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(5)

    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.fold() == 5

# Generated at 2022-06-12 04:54:29.511849
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().get() == 5, 'Box lazy to lazy test failed'

# Generated at 2022-06-12 04:56:30.099191
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet import lazy
    assert lazy.Box(10).to_lazy().fold(lambda: 10)(()) == 10

# Generated at 2022-06-12 04:56:33.162545
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-12 04:56:35.298103
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy().fold(lambda: None) == 1
    assert isinstance(Box(1).to_lazy(), Lazy)


# Generated at 2022-06-12 04:56:36.948156
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:56:38.101753
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 04:56:39.043589
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:56:40.636033
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(2).to_lazy().fold() == 2


# Generated at 2022-06-12 04:56:41.756727
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().value(None) == 10


# Generated at 2022-06-12 04:56:44.558534
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)
    assert Box('Hello world!').to_lazy() == Lazy(lambda: 'Hello world!')



# Generated at 2022-06-12 04:56:46.559953
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()