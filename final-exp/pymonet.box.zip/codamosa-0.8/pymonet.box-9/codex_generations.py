

# Generated at 2022-06-12 04:47:26.069039
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(Lazy(lambda: 1)).to_lazy() is Lazy(lambda: Lazy(lambda: 1))


# Generated at 2022-06-12 04:47:28.963593
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('abc') == Box('abc'), 'Box __eq__ failed'
    assert Box(123) == Box(123), 'Box __eq__ failed'


# Generated at 2022-06-12 04:47:33.096307
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.list import List
    from pymonet.lazy import Lazy

    f = lambda: List(1, 2).to_box().to_lazy().folded()
    g = lambda: 3
    assert f() == g()

# Generated at 2022-06-12 04:47:35.900182
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy() == Lazy(lambda: 1), "Box(1).to_lazy() != Lazy(lambda: 1)"

# Generated at 2022-06-12 04:47:38.294614
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(0).to_lazy() == Lazy(lambda: 0)


# Unit tests for methods map and bind of class Box

# Generated at 2022-06-12 04:47:39.040000
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    assert Box(5).to_lazy() == Lazy(lambda: 5)  # type: ignore

# Generated at 2022-06-12 04:47:44.792522
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(2) == Box(2).to_lazy(), "Box was not converted to Lazy"
    assert Lazy(lambda: 2) == Box(lambda: 2).to_lazy(), "Box was not converted to Lazy"
    assert Lazy([1, 2, 3]) == Box([1, 2, 3]).to_lazy(), "Box was not converted to Lazy"


# Generated at 2022-06-12 04:47:46.050637
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().get() == 1


# Generated at 2022-06-12 04:47:48.613365
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(42).to_lazy()) == 'Lazy[function=<function to_lazy.<locals>.<lambda> at 0x7fbc30dc07b8>]'

# Generated at 2022-06-12 04:47:50.307231
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Callable == type(Box(5).to_lazy().value)

# Generated at 2022-06-12 04:47:56.548035
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('ab') == Box('ab')
    assert Box(1) != Box(2)
    assert Box('a') != Box('b')



# Generated at 2022-06-12 04:47:58.136648
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('value') == Box('value')



# Generated at 2022-06-12 04:48:04.747719
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(2) != Box('2')
    assert Box(1) != None
    assert Box('1') != '1'
    assert Box([]) == Box([])
    assert Box({}) == Box({})
    assert Box(None) != Box(1)
    assert Box(1) != Box(None)



# Generated at 2022-06-12 04:48:06.117532
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-12 04:48:09.356593
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Box(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force() == 1

# Generated at 2022-06-12 04:48:10.710688
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 04:48:13.429178
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1) is True
    assert Box(1) == Box(2) is False
    assert Box(1) == 1 is False


# Generated at 2022-06-12 04:48:15.348508
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 2



# Generated at 2022-06-12 04:48:21.587634
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.maybe import Maybe

    Box(10).__eq__(Maybe.just(10))
    Box(10).__eq__(Maybe.just('10'))
    Box(10).__eq__(Box(10))
    Box(10).__eq__(Box('10'))
    Box(10).__eq__(Box(None))
    Box(10).__eq__(None)


# Generated at 2022-06-12 04:48:24.257372
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 04:48:26.730988
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().value().run() == 42

# Generated at 2022-06-12 04:48:28.099211
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert (Box(1).to_lazy() == Lazy(lambda: 1))

# Generated at 2022-06-12 04:48:30.240537
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy.unit(10)



# Generated at 2022-06-12 04:48:32.195305
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet import Lazy

    test_value = 3
    assert Box(test_value).to_lazy() == Lazy(lambda: test_value)


# Generated at 2022-06-12 04:48:33.556033
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 04:48:35.140364
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().is_lazy()
    assert Box(1).to_lazy().fold()() == 1


# Generated at 2022-06-12 04:48:40.919114
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box.

    :returns: Nothing
    :rtype: Nothing
    """
    from pymonet.lazy import Lazy
    from pymonet.monad import fold_lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert fold_lazy(Box(1).to_lazy()) == 1



# Generated at 2022-06-12 04:48:45.948047
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    import math

    def square(a):
        return a ** 2

    box = Box(10).to_lazy()
    assert box.value() == 10
    assert box.map(square).value() == 100

    box = Box(math.sqrt(2)).to_lazy().map(square)
    assert box.value() == 2



# Generated at 2022-06-12 04:48:48.050872
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().force() == 2



# Generated at 2022-06-12 04:48:58.655461
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box.unit(5)
    assert box.map(lambda x: x + 10) == Box(15)
    assert box.value == 5

    assert box.bind(lambda x: Box.unit(x + 10)) == Box(15)
    assert box.value == 5

    def add(x):
        def inner(y):
            return x + y

        return Box.unit(inner)

    assert box.ap(add(10)) == Box(15)

    assert box.to_maybe() == Box.unit(5)
    assert box.to_either() == Box.unit(5)
    assert box.to_lazy().value() == 5
    assert box.to_try() == Box.unit(5)
    assert box.to_validation() == Box.unit(5)

# Generated at 2022-06-12 04:49:05.215392
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 04:49:06.602845
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 04:49:09.024804
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    value = 8
    result = Box(value).to_lazy().evaluate()
    assert result == value


# Generated at 2022-06-12 04:49:11.598672
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(1).to_lazy().fold(lambda x: x + 1) == 2

# Generated at 2022-06-12 04:49:13.669390
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import evaluate

    assert evaluate(Box(1).to_lazy()) == 1

# Generated at 2022-06-12 04:49:16.594507
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Given
    box = Box(1)

    # When
    result = box.to_lazy()

    # Then
    assert result.fold() == 1

# Generated at 2022-06-12 04:49:18.567518
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:23.264181
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest

    box = Box(42)
    assert box.to_lazy().fold(lambda: 1, lambda x: x) == 42

    box = Box('asd')
    assert box.to_lazy().fold(lambda: 1, lambda x: x) == 'asd'



# Generated at 2022-06-12 04:49:24.642398
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(6).to_lazy().force() == 6



# Generated at 2022-06-12 04:49:25.655610
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Box(5).to_lazy()

# Generated at 2022-06-12 04:49:33.583841
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(5).to_lazy().get() == 5

# Generated at 2022-06-12 04:49:37.439111
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    from pymonet.lazy import Lazy

    # arrange
    value_box = Box("value")

    # act
    lazy_box = value_box.to_lazy()

    # assert
    assert lazy_box == Lazy(lambda: "value")



# Generated at 2022-06-12 04:49:40.089753
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:49:42.771920
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(2).to_lazy()

    assert isinstance(lazy, Lazy)

    assert lazy.force() == 2



# Generated at 2022-06-12 04:49:45.343628
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    assert Box(1).to_lazy().to_val()() == 1



# Generated at 2022-06-12 04:49:47.332827
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 1

    assert Box(f).to_lazy() == Lazy(f)

# Generated at 2022-06-12 04:49:50.714635
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert (
        Box(2)
        .to_lazy()
        .bind(lambda x: Lazy(lambda: x * x).bind(lambda x: Lazy(lambda: x + 1)))
        .fold(lambda x: x) == 5
    )



# Generated at 2022-06-12 04:49:53.585185
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box("value")
    lazy = box.to_lazy()

    assert lazy == Lazy(lambda: "value")
    assert lazy.value() == "value"


# Generated at 2022-06-12 04:49:56.007357
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:57.872043
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def f():
        return 'Test'

    assert Box(f()).to_lazy()

# Generated at 2022-06-12 04:50:14.782739
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box('I am lazy')
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.evaluate(), str)
    assert lazy.evaluate() == 'I am lazy'

# Generated at 2022-06-12 04:50:16.108700
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('a').to_lazy().value() == 'a'

# Generated at 2022-06-12 04:50:20.217432
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success

    assert Box(lambda x: x + 1).to_lazy() == Lazy(lambda: Success(lambda x: x + 1))
    assert Box(lambda x: x + 1).to_lazy()().value == Lazy(lambda: Success(lambda x: x + 1)()).value

# Generated at 2022-06-12 04:50:23.440517
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 10

    test_data = Box(value)
    expected = Lazy(lambda: value)

    assert test_data.to_lazy() == expected


# Generated at 2022-06-12 04:50:25.700059
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:50:27.492600
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_box = Box(42)

    assert test_box.to_lazy().value() == 42

# Generated at 2022-06-12 04:50:29.386554
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:50:31.020163
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box(42).to_lazy().run() == 42

# Generated at 2022-06-12 04:50:32.882878
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(5).to_lazy().fold() == 5

# Generated at 2022-06-12 04:50:35.670181
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """

    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy.unit(5)

# Generated at 2022-06-12 04:51:03.863360
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    actual = Box(1).to_lazy()
    assert isinstance(actual, Lazy)
    assert actual.value() == 1


# Generated at 2022-06-12 04:51:04.785616
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == 5

# Generated at 2022-06-12 04:51:06.087381
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().fold(lambda: 0) == 5

# Generated at 2022-06-12 04:51:13.342138
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit-test for method to_lazy of class Box.
    """
    from pymonet.monad_try import Try

    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box(42).to_lazy().fold() == 42
    assert Box(Try(42, True)).to_lazy().fold() == Try(42, True)
    assert Box(Try(42, True)).to_lazy().fold().is_success is True


# Generated at 2022-06-12 04:51:20.053889
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

    assert Box(None).to_lazy() == Lazy(lambda: None)

    assert Box(iter([1, 2, 3])).to_lazy() == Lazy(lambda: iter([1, 2, 3]))

    b = Box(10)
    assert b.to_lazy().value == b.to_lazy().value == b.value == 10



# Generated at 2022-06-12 04:51:23.659806
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    r = Box(1).to_lazy()
    assert r._is_folded is False
    assert r._lazy_value() == 1

# Generated at 2022-06-12 04:51:32.286391
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(5).to_maybe() == Maybe.just(5)
    assert Box(5).to_either() == Right(5)
    assert Box(5).to_try() == Try(5, is_success=True)
    assert Box(5).to_validation() == Validation.success(5)



# Generated at 2022-06-12 04:51:35.383438
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Box(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 04:51:37.330896
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(5)
    lazy = box.to_lazy()
    result = lazy.force()
    assert result == 5



# Generated at 2022-06-12 04:51:40.114027
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): #type: ignore
    from pymonet.lazy import Lazy

    assert Box(4).to_lazy() == Lazy(lambda: 4)



# Generated at 2022-06-12 04:52:42.884502
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # type: () -> None
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(5).to_maybe() == Maybe.just(5)
    assert Box(5).to_try() == Try(5, is_success=True)
    assert Box(5).to_validation() == Validation.success(5)
    assert Box(5).to_either() == Right(5)



# Generated at 2022-06-12 04:52:45.190744
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy().value() == Box(1).value

# Generated at 2022-06-12 04:52:47.160333
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy().unfold() == 1

# Generated at 2022-06-12 04:52:49.026965
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-12 04:52:51.137481
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().value == Box(5).value


# Generated at 2022-06-12 04:52:53.572552
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'data') == Box('data').to_lazy()


# Generated at 2022-06-12 04:52:56.839515
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # GIVEN
    box = Box(5)

    # WHEN
    lazy_five_result = box.to_lazy().get()

    # THEN
    assert lazy_five_result == 5



# Generated at 2022-06-12 04:52:58.180021
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().get() == 10


# Generated at 2022-06-12 04:53:02.021343
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(lambda x: x + 1).to_lazy() == Lazy(lambda: lambda x: x + 1)

# Generated at 2022-06-12 04:53:03.780081
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 04:55:11.640329
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    my_box = Box(10)
    my_lazy = my_box.to_lazy()
    assert my_lazy.unwrap() == 10



# Generated at 2022-06-12 04:55:12.649043
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().eval() == 42

# Generated at 2022-06-12 04:55:16.005436
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Input data
    input_value = 10
    # Expected result
    output_value = 10
    # Check
    assert Box(input_value).to_lazy().value() == output_value


# Generated at 2022-06-12 04:55:20.206469
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy_helper import Id

    def value_function():
        return 'value'

    result = Box(value_function).to_lazy()

    assert isinstance(result, Lazy)
    assert isinstance(result.value_computer, Id)
    assert result.value_computer.get_value() == value_function


# Generated at 2022-06-12 04:55:21.629205
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    box = Box(1)
    # when
    lazy = box.to_lazy()
    # then
    assert lazy.value() == 1


# Generated at 2022-06-12 04:55:23.536704
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Box(Lazy(lambda: 1)).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:55:25.381825
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(Lazy(lambda: 5))
    lazy = box.to_lazy()
    assert 5 == lazy.force()

# Generated at 2022-06-12 04:55:27.923460
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def a():
        return 1

    lazy_result = Box(a).to_lazy()

    assert isinstance(lazy_result, type(Box(a).to_lazy()))
    assert lazy_result.value == 1


# Generated at 2022-06-12 04:55:29.252438
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().eval() == 5

# Generated at 2022-06-12 04:55:30.270262
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('value').to_lazy() == Lazy(lambda: 'value')