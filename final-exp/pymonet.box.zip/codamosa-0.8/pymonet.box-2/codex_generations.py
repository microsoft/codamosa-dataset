

# Generated at 2022-06-12 04:47:26.068888
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test when value is not callable
    assert Box(7).to_lazy() == Lazy(lambda: 7)

    # Test when value is callable
    assert Box(lambda: 7).to_lazy() == Lazy(lambda: lambda: 7)


# Generated at 2022-06-12 04:47:28.961579
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(3)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: 3) is True

# Generated at 2022-06-12 04:47:31.110249
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    a_number = 42
    assert Box(a_number).to_lazy().force() == a_number



# Generated at 2022-06-12 04:47:35.851437
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """ Tests if to_lazy method works as expected. """
    #Arrange
    box = Box(1)

    #Act
    lazy = box.to_lazy()
    result = lazy.value

    #Assert
    assert 1 == result



# Generated at 2022-06-12 04:47:39.056660
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box(10)
    box_2 = Box(10)
    box_3 = Box(15)

    assert box_1 == box_2
    assert box_1 != box_3


# Generated at 2022-06-12 04:47:41.648466
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box('1')
    box2 = Box('2')
    box3 = Box('1')
    assert box1 == box3 and not box1 == box2

# Generated at 2022-06-12 04:47:45.472955
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert not Box(1) == None
    assert Box(1) == Box(1)
    assert Box(1) != Box('2')
    assert Box(1) != Box(1.0)
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:47:47.802016
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(13).to_lazy() == Lazy(lambda: 13)



# Generated at 2022-06-12 04:47:49.576983
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(66) == Box(66)
    assert not Box(69) == Box(66)



# Generated at 2022-06-12 04:47:51.018630
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(5) == Box(5)) is True
    assert (Box(7) == Box(8)) is False



# Generated at 2022-06-12 04:48:04.854955
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # (str, str) -> None
    def check_condition(first: str, second: str):
        assert eval(first) == eval(second), \
            '{0} != {1}'.format(first, second)

    conditions = [
        'Box("Hello")',
        'Box("Hello")',
        'Box("Hello") == Box("Hello")',
        'Box("Hello") == Box("World") == False',
        'Box("Hello") == "Hello" == False',
        'Box("Hello") != "Hello" == True',
        'Box("Hello") != Box("Hello") == False'
    ]

    for i in range(0, len(conditions), 2):
        first = conditions[i]
        second = conditions[i + 1]
        yield check_condition, first, second



# Generated at 2022-06-12 04:48:08.898981
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(11)
    assert Box(10) != Box('10')
    assert Box(10) != Try(10)
    assert Box(10) != None



# Generated at 2022-06-12 04:48:11.175897
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 'Box(1)'


# Generated at 2022-06-12 04:48:19.402242
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box('string') == Box('string')
    assert Box(1) == Box(1)
    assert Box(1.0) == Box(1.0)
    assert Box(True) == Box(True)
    assert Box(False) == Box(False)
    assert Box(None) == Box(None)
    assert Box(object()) == Box(object())
    assert Box(1) != object()
    assert Box(False) != Box(True)
    assert Box(None) != Box(1)
    assert Box(1.0) != Box(1)



# Generated at 2022-06-12 04:48:21.916430
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 04:48:25.761648
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # pylint: disable=comparison-with-callable, no-member

    # create box with value 1
    box = Box(1)

    # convert box to lazy monad
    lazy = box.to_lazy()

    # box converted to lazy so it should be Lazy monad
    assert isinstance(lazy, lazy.__class__)

    # check value of converted lazy
    assert lazy.value() == box.value

# Generated at 2022-06-12 04:48:27.053720
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    first_box = Box(2)
    second_box = Box(2)
    assert first_box == second_box



# Generated at 2022-06-12 04:48:28.787794
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:48:31.257624
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    val = Lazy(lambda: 42)
    assert Box(42).to_lazy() == val


# Unit tests for method to_maybe of class Box

# Generated at 2022-06-12 04:48:33.626522
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    result = Box(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.fold() == 1



# Generated at 2022-06-12 04:48:36.870115
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-12 04:48:39.846241
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    box = Box(5)

    # then
    assert box.to_lazy().is_folded() is False

# Generated at 2022-06-12 04:48:47.811423
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_lazy().get_value() == 1
    assert Box(1).to_lazy().get_value() == 1
    assert Box(1).to_lazy().get_value() == 1
    assert Box(1).to_lazy().get_value() == 1
    assert Box(1).to_lazy().get_value() == 1



# Generated at 2022-06-12 04:48:50.138491
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_lazy = Lazy(lambda: 1)
    assert Box(1).to_lazy() == test_lazy


# Generated at 2022-06-12 04:48:57.905707
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Test for Box.to_lazy method.
    """
    box = Box(123)

    lazy = box.to_lazy()
    assert lazy.value() == 123

    maybe = box.to_maybe()
    assert maybe.value == 123

    try_ = box.to_try()
    assert try_.value == 123
    assert try_.is_success is True
    assert try_.is_failure is False

    validation = box.to_validation()
    assert validation.value == 123
    assert validation.valid



# Generated at 2022-06-12 04:48:59.786280
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:49:01.657967
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))


# Generated at 2022-06-12 04:49:07.407623
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Validate to_lazy method
    assert isinstance(Box(5).to_lazy(), Lazy)

    # Validate to_lazy method for Try monad
    assert Try(5, True).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:49:10.689021
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(10)
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 10



# Generated at 2022-06-12 04:49:13.525125
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(123) == Box(123)
    assert Box('abc') == Box('abc')
    assert Box(123) != Box(1234)
    assert Box(123) != Box('1234')



# Generated at 2022-06-12 04:49:18.603171
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-12 04:49:21.758310
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def f(value: int) -> int:
        return value * 2

    box = Box(1).to_lazy().map(f)
    assert f(1) == box.get()

# Generated at 2022-06-12 04:49:22.551602
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')


# Generated at 2022-06-12 04:49:25.051447
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(1)
    b = Box(1)
    c = Box(2)

    assert a == b
    assert a != c


# Generated at 2022-06-12 04:49:26.179802
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)



# Generated at 2022-06-12 04:49:28.026439
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:49:33.198070
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    value1 = 1
    value2 = 2
    box1 = Box[int](value1)
    box2 = Box[int](value1)
    box3 = Box[int](value2)
    assert box1 == box2
    assert box1 != box3
    assert box1 != value1


# Generated at 2022-06-12 04:49:35.986155
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(2).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force() == 2



# Generated at 2022-06-12 04:49:41.702969
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)
    assert Box('Hello') == Box('Hello')
    assert Box([1, 2]) == Box([1, 2])
    assert not Box(1) == Box(2)
    assert not Box(1) == None
    assert not Box(1) == 'Hello'
    assert not Box(1) == Box([1, 2])



# Generated at 2022-06-12 04:49:43.415302
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(10)

    assert (box == Box(10)) is True



# Generated at 2022-06-12 04:49:49.800143
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) != Box(2)
    assert Box(1) == Box(1)
    assert Box(1) != 'asdasda'
    assert Box(1) != None



# Generated at 2022-06-12 04:49:52.749142
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Setup:
    value = 5

    # Exercise:
    result = Box(value).to_lazy()

    # Verify:
    assert result.box.value == value
    assert result.box.value() == value


# Generated at 2022-06-12 04:49:54.742872
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('a') == Box('a') and Box(1) == Box(1)



# Generated at 2022-06-12 04:50:00.209038
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_suite():
        from pymonet.lazy import Lazy

        # test empty lazy
        value = 1
        box = Box(value)
        assert Lazy.unit(value) == box.to_lazy()

        # test alredy exists lazy
        lazy = Lazy(lambda: value)
        assert lazy == box.to_lazy()

    test_suite()



# Generated at 2022-06-12 04:50:02.104599
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != 1



# Generated at 2022-06-12 04:50:06.328176
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    # given
    box = Box(10)
    box_with_same_value = Box(10)
    box_with_diff_value = Box(20)

    # then
    assert box == box
    assert box == box_with_same_value
    assert box != box_with_diff_value



# Generated at 2022-06-12 04:50:09.500216
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-12 04:50:14.098128
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)
    assert Box(5) != 'Box[value=5]'
    assert Box(5) != None
    assert Box(None) == Box(None)
    assert Box(None) != 5


# Generated at 2022-06-12 04:50:15.878047
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(None) == Box(None)



# Generated at 2022-06-12 04:50:17.552619
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:50:25.075093
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert(Box(1) == Box(1))
    assert(Box(1) != Box(2))



# Generated at 2022-06-12 04:50:30.774677
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # given
    string_box_a = Box('a')
    string_box_b = Box('b')
    int_box_a = Box(1)
    string_box_a_dup = Box('a')

    # expect
    assert string_box_a == string_box_a
    assert string_box_a != string_box_b
    assert string_box_a == string_box_a_dup
    assert string_box_a != int_box_a


# Generated at 2022-06-12 04:50:32.184298
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:50:36.920993
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box(12)
    box_2 = Box(12)
    not_box = 1
    assert box_1 == box_2
    assert box_2 == box_1
    assert not box_1 == not_box
    assert not box_2 == not_box
    assert not not_box == box_1
    assert not not_box == box_2



# Generated at 2022-06-12 04:50:38.342226
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().get() == 1

# Generated at 2022-06-12 04:50:39.788175
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:50:42.802051
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): #pragma: no cover
    """
    Test to_lazy method of class Box.
    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Box(10).to_lazy()


# Generated at 2022-06-12 04:50:45.450880
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    value = 2
    # When
    function_get_value = Box(value).to_lazy().force()

    # Then
    assert value == function_get_value()

# Generated at 2022-06-12 04:50:48.509325
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(1)
    b = Box(1)
    c = Box(2)

    assert a == b
    assert a != c
    assert a == 1  # False
    assert a != 1  # True


# Generated at 2022-06-12 04:50:50.212294
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:50:58.460423
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-12 04:51:00.267581
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(1)
    assert box == Box(1)



# Generated at 2022-06-12 04:51:03.043341
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """ Test for method to_lazy of class Box. """

    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-12 04:51:05.807161
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest

    from pymonet.lazy import Lazy

    box = Box(1)
    assert box.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:51:07.636365
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box("1") == Box(1))



# Generated at 2022-06-12 04:51:10.524409
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Should return True
    assert Box(1) == Box(1)

    # Should return False
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:51:11.906863
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('test').to_lazy() == Lazy(lambda: 'test')

# Generated at 2022-06-12 04:51:16.931389
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box(1) != Box(2)
    assert Box('x') == Box('x')
    assert Box('y') != Box('x')
    assert Box('x') != Box('y')



# Generated at 2022-06-12 04:51:19.026521
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    tests to_lazy method
    """
    assert Box(42).to_lazy().fold(lambda: 0) == 42

# Generated at 2022-06-12 04:51:24.234013
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('asd') == Box('asd')
    assert Box(False) == Box(False)
    assert Box(None) == Box(None)
    assert not Box(1) == Box('1')
    assert not Box(1) == Box(2)
    assert not Box(1) == Box(None)
    assert not Box(1) == None
    assert not Box(1) == '1'
    assert not Box(1) == object()
    assert not None == Box(1)
    assert not '1' == Box(1)
    assert not object() == Box(1)



# Generated at 2022-06-12 04:51:38.576488
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(1).to_lazy()

    assert isinstance(result, Lazy)
    assert result.fold(lambda: 0) == 1


# Generated at 2022-06-12 04:51:42.462017
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    mocks = [Box('a'), Box('a'), Box('b')]

    assert mocks[0] == mocks[0]
    assert mocks[0] == mocks[1]
    assert not (mocks[0] == mocks[2])



# Generated at 2022-06-12 04:51:46.221068
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)

    assert box1 == box2
    assert box1 != box3



# Generated at 2022-06-12 04:51:49.619313
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    @do
    def test():
        value = yield Box(5).to_lazy()
        yield Maybe.from_value(value)

    assert isinstance(test(), Maybe)
    assert test().value == 5



# Generated at 2022-06-12 04:51:50.524470
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('value') == Box('value')

# Generated at 2022-06-12 04:51:53.352472
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    value = "abc"
    box = Box(value)
    assert box == box
    assert box == Box(value)
    assert box != "abc"



# Generated at 2022-06-12 04:51:55.719374
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 1



# Generated at 2022-06-12 04:52:01.143167
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Box(10).to_lazy() == Lazy(lambda: 10)
    assert Box(10).to_try() == Try(10, True)
    assert Box(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-12 04:52:04.387394
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    assert Functor.fmap(lambda x: x + 1, Box(1).to_lazy()) == Lazy(lambda: 2)

# Generated at 2022-06-12 04:52:06.328640
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:52:33.185167
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(42)
    lazy = box.to_lazy()
    assert lazy.get() == 42

# Generated at 2022-06-12 04:52:41.987541
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try

    assert not Box(Try(None, is_success=False)) == None
    assert not Box(Try(None, is_success=False)) == 1
    assert not Box(Try(None, is_success=False)) == '1'
    assert not Box(Try(None, is_success=False)) == Box(1)
    assert not Box(Try(None, is_success=False)) == Box(Try(1, is_success=True))

    # check identity
    assert Box(Try(None, is_success=False)) == Box(Try(None, is_success=False))
    assert not Box(Try(1, is_success=True)) == Box(Try(2, is_success=True))



# Generated at 2022-06-12 04:52:44.479502
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()



# Generated at 2022-06-12 04:52:47.589369
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == 1


# Unit tests for the method map of class Box

# Generated at 2022-06-12 04:52:49.447145
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('x').to_lazy() == Lazy(lambda: 'x')



# Generated at 2022-06-12 04:52:59.897045
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Right, Left

    assert Box(1) == Box(1)
    assert Box('hello') == Box('hello')
    assert Box(Right('Right')) == Box(Right('Right'))
    assert Box(Left(['Left'])) == Box(Left(['Left']))
    assert Box(Maybe('Maybe')) == Box(Maybe('Maybe'))
    assert Box(['List']) == Box(['List'])
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box(Box(['Box'])) == Box(Box(['Box']))
    assert Box({'1': 2}) == Box({'1': 2})

# Generated at 2022-06-12 04:53:03.816531
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box('value').to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fold() == 'value'

# Generated at 2022-06-12 04:53:04.968738
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)



# Generated at 2022-06-12 04:53:09.223309
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Test with Box with same value returning True
    result = Box(1) == Box(1)
    assert result is True

    # Test with Box with different value returning False
    result = Box(1) == Box(2)
    assert result is False

    # Test with different type returning False
    result = Box(1) == 1
    assert result is False



# Generated at 2022-06-12 04:53:11.250019
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    value = 'wow'
    box = Box(value)

    assert box.to_lazy().fold() == value


# Generated at 2022-06-12 04:53:46.696436
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) != Box(2)) == True
    assert (Box(1) != Box(1)) == False
    assert (Box(1) == Box(2)) == False
    assert (Box(1) == Box(1)) == True
    assert (Box(1) != 1) == True
    assert (Box(1) == 1) == False
    assert (Box(1) != '1') == True
    assert (Box(1) == '1') == False



# Generated at 2022-06-12 04:53:48.854096
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).map(lambda x: x + 1).to_lazy().map(lambda x: x * 2).value() == 4

# Generated at 2022-06-12 04:53:56.625685
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1) is True
    assert Box('a') == Box('a') is True
    assert Box('a') == Box('b') is False
    assert Box(1) == Box('1') is False
    assert Box(Or[int, str]('1')) == Box(Or[int, str]('1')) is True
    assert Box(Or[int, str]('1')) == Box(Or[int, str](1)) is False
    assert Box(Or[int, str]('1')) == Box(Or[str, int]('1')) is True



# Generated at 2022-06-12 04:54:00.062626
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box.

    """
    assert Box(10) == Box(10)
    assert Box('test') == Box('test')
    assert Box(('a', 'b')) == Box(('a', 'b'))
    assert Box(None) == Box(None)
    assert Box(False) != Box(True)


# Unit tests for method map of class Box

# Generated at 2022-06-12 04:54:04.547566
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 'box'
    assert Box('box') == Box('box')
    assert Box('box') != Box('box1')



# Generated at 2022-06-12 04:54:05.729828
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') != Box('b')

# Generated at 2022-06-12 04:54:08.992134
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from datetime import datetime

    now = datetime.now()
    now2 = datetime.now()

    box = Box(now)
    box2 = Box(now2)
    box3 = Box('string')

    assert box == box2
    assert box != box3
    assert box != None



# Generated at 2022-06-12 04:54:14.038427
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover

    def assertion(value) -> None:
        assert value == Box(value), 'Should be equals'

    values = [None, 0, 1, [], [1], (1,), {1}, {'1': 1}, 'str', b'123']

    for value in values:
        assertion(value)

# Generated at 2022-06-12 04:54:19.102063
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    assert Box(1) == Box(1), 'Boxes with equal values should be equal'
    assert not (Box(1) == Box(2)), 'Boxes with non equal values should not be equal'
    assert not (Box(1) == None), 'Boxes should not equal to None'



# Generated at 2022-06-12 04:54:22.047466
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from .test_lazy import test_Lazy_map

    lazy = Box(1).to_lazy()
    assert isinstance(lazy, Lazy) and test_Lazy_map(lazy)



# Generated at 2022-06-12 04:54:55.261139
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    assert type(Box(1).to_lazy()) == Lazy
    assert Box(1).to_lazy().value() == 1
    assert Box(True).to_lazy().value() is True
    assert Box({'a': 'b'}).to_lazy().value() == {'a': 'b'}


# Generated at 2022-06-12 04:54:57.710076
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(2)
    assert box.to_lazy() == Lazy(lambda: 2)
    assert box.to_lazy().force() == 2


# Generated at 2022-06-12 04:55:00.392604
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    a = Box(123)
    b = a.to_lazy()
    assert b.is_folded == False
    assert b.fold_left(lambda acc, x: acc + x) == 123



# Generated at 2022-06-12 04:55:05.651543
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try
    from pymonet.monad_list import List

    assert Box(3) == Box(3)
    assert Box(3) != Box(4)

    assert Box(3) != 3  # box is not equal to another object
    assert Box(3) != List.pure(3)  # box is not equal to another applicative
    assert Box(3) != Try.success(3)  # box is not equal to another applicative



# Generated at 2022-06-12 04:55:07.645419
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box("") == Box("")
    assert Box("Hello") != Box("World!")
    assert Box("Hello") != Box(10)



# Generated at 2022-06-12 04:55:10.289729
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(42).to_lazy()
    assert isinstance(lazy, pymonet.lazy.Lazy)
    assert not lazy.folded
    assert lazy.evaluate() == 42



# Generated at 2022-06-12 04:55:12.649659
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Box
    """
    test_value = 'test'
    assert Box(test_value).to_lazy().value() == test_value


# Generated at 2022-06-12 04:55:16.541196
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(42) == Box(42)
    assert not (Box(42) == Box(43))
    assert not (Box(42) == Box('42'))
    assert not (Box('42') == Box(42))


# Generated at 2022-06-12 04:55:18.807185
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(True) == Box(True)
    assert Box(False) != Box(True)
    assert Box(False) != []


# Generated at 2022-06-12 04:55:19.727673
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().fold() == 3

# Generated at 2022-06-12 04:56:32.595940
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test method __eq__ of class Box
    """

    assert Box(0) == Box(0)
    assert Box(0) != None



# Generated at 2022-06-12 04:56:34.833268
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().is_value()
    assert not Box(1).to_lazy().is_error()
    assert Box(1).to_lazy().value() == 1



# Generated at 2022-06-12 04:56:36.097798
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert not (Box(3) == Box(4))



# Generated at 2022-06-12 04:56:37.209409
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:56:39.948124
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Given
    box = Box(1)
    box2 = Box(2)

    # When
    result = box == box2

    # Then
    assert (result is False)

    # When
    result = box == box

    # Then
    assert (result is True)


# Generated at 2022-06-12 04:56:42.567830
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """

    assert Box(5).to_lazy() == Box(5).value
    assert Box('Test').to_lazy() == Box('Test').value

# Generated at 2022-06-12 04:56:44.483418
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-12 04:56:53.124968
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Unit test for method to_lazy of class Box."""
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Box(3).to_lazy().unwrap_or(0)() == 3
    assert Box('a').to_lazy().unwrap_or('')() == 'a'

    assert Box(3).to_lazy().to_try() == Try(lambda: 3, is_success=True)
    assert Box(3).to_lazy().to_validation() == Validation.success(lambda: 3)
    assert Box(3).to_lazy().to_maybe() == Maybe.just(lambda: 3)

# Generated at 2022-06-12 04:56:54.229201
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:56:58.221082
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(0)
    assert Box('hello') == Box('hello')
    assert Box([]) == Box([])
    assert Box((0, 1)) == Box((0, 1))
    assert Box({}) == Box({})
    assert Box(None) == Box(None)
    assert Box(0) != Box(1)

