

# Generated at 2022-06-12 04:47:24.366930
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from typing import Callable

    from pymonet.lazy import Lazy

    value = 1
    box = Box(value)
    getter: Callable[[], int] = box.to_lazy().value

    assert getter() == value

# Generated at 2022-06-12 04:47:26.178527
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-12 04:47:27.941593
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('test') == Box('test')



# Generated at 2022-06-12 04:47:29.224952
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert 1 == Box('2').to_lazy().fold(int)

# Generated at 2022-06-12 04:47:31.112601
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-12 04:47:34.116626
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:47:36.489338
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:47:38.870221
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box("hello").to_lazy() == Lazy(lambda: "hello")


# Generated at 2022-06-12 04:47:40.942216
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    __lazy = Box(12).to_lazy()
    assert __lazy.is_same(Lazy(lambda: 12))

# Generated at 2022-06-12 04:47:44.540089
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert not Box(1) == Box(2)



# Generated at 2022-06-12 04:47:49.394295
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')


# Generated at 2022-06-12 04:47:50.698122
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box("str") == Box("str")


# Generated at 2022-06-12 04:47:53.664866
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().value() == 42

# Generated at 2022-06-12 04:47:55.485770
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1.0) == Box(1.0)



# Generated at 2022-06-12 04:47:58.519157
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(0)
    assert Box(0) != Box(1)
    assert Box(0) != None


# Generated at 2022-06-12 04:48:02.445759
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def function():
        return Box(3)

    # Transform Box into Lazy with returning value function
    assert Lazy(function).value() == Box(3)  # type: ignore



# Generated at 2022-06-12 04:48:12.151883
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == None  # pylint: disable=C0123,W0123
    assert not Box(1) == object
    assert not Box(1) == [2]
    assert not Box(1) == (None, None)
    assert Box(None) == Box(None)
    assert not Box(None) == Box(1)
    assert not Box(None) == None  # pylint: disable=C0123,W0123
    assert not Box(None) == object
    assert not Box(None) == [2]
    assert not Box(None) == (None, None)


# Generated at 2022-06-12 04:48:15.404327
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(None) == Box(None)
    assert Box(None) != Box([])



# Generated at 2022-06-12 04:48:21.646336
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure

    # Test: Box to lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1) == Lazy(lambda: Box(1).value)

    # Test: Failure to lazy
    assert Failure('Exception').to_lazy() == Lazy.unit(Failure('Exception'))

# Generated at 2022-06-12 04:48:23.497210
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:48:27.303244
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(1)
    assert Box(1) == Box(1)
    assert not Box(0) == Box('1')



# Generated at 2022-06-12 04:48:28.652460
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:48:32.208583
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('a') != Box('b')
    assert Box(1.0) != Box(1.1)
    assert Box(1) != Box('1')



# Generated at 2022-06-12 04:48:34.180393
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-12 04:48:39.180488
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Box(1).to_lazy().get_value() == Lazy(lambda: 1).get_value()
    assert Box(Maybe.nothing(1)).to_lazy().get_value() == Lazy(lambda: Maybe.nothing(1)).get_value()



# Generated at 2022-06-12 04:48:40.919182
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)



# Generated at 2022-06-12 04:48:47.507711
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(3) == Box(3)
    assert Box(3) != Box(4)
    assert Box(3) != None
    assert Box(3) != 3
    assert Box(None) == Box(None)
    assert Box(None) != Box('None')
    assert Box(None) != None
    assert Box(None) != 'None'
    assert Box('None') == Box('None')
    assert Box('None') != Box(None)
    assert Box('None') != None
    assert Box('None') != 'None'



# Generated at 2022-06-12 04:48:50.234783
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    assert Box(42).to_lazy() == Lazy(Box(42).value)

# Generated at 2022-06-12 04:48:54.430270
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) == Box(1.0)
    assert Box('one') == Box('one')
    assert Box('one') != Box(1)
    assert Box(1) != Box('1')



# Generated at 2022-06-12 04:48:56.785973
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(2) == Box(3)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:49:04.312102
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 100)

    box = Box(100)
    assert box.to_lazy() == lazy

# Generated at 2022-06-12 04:49:07.498025
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    b1 = Box(1)
    b2 = Box(1)
    b3 = Box(2)

    assert b1 == b2
    assert not b1 == b3


# Generated at 2022-06-12 04:49:09.557891
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    assert box.to_lazy().get() == box.value

# Generated at 2022-06-12 04:49:11.737545
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for Box.to_lazy method
    """
    assert Box(1).to_lazy().value() == 1

# Generated at 2022-06-12 04:49:15.249300
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box(1) != Box(2)
    assert Box(2) != Box(1)



# Generated at 2022-06-12 04:49:16.707950
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)


# Generated at 2022-06-12 04:49:18.643829
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().get_value()() == 1
    assert Box(1).to_lazy().fold_value() == 1

# Generated at 2022-06-12 04:49:22.984129
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert None == None
    assert Box(None) == Box(None)
    assert 'a' != 1
    assert Box('a') != Box(1)
    assert Box('a') == Box('a')
    assert Box(1) == Box(1)


# Generated at 2022-06-12 04:49:25.415111
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('abc') != Box(None)



# Generated at 2022-06-12 04:49:28.544717
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    b1 = Box('a')
    b2 = Box('b')
    b3 = Box('a')

    assert (b1 == b2) == False
    assert (b1 == b3) == True

# Generated at 2022-06-12 04:49:44.903703
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(-5).to_lazy() == Lazy(lambda: -5)
    assert Box(1.0).to_lazy() == Lazy(lambda: 1.0)
    assert Box('string').to_lazy() == Lazy(lambda: 'string')
    assert Box({'test': 'test_string'}).to_lazy() == Lazy(lambda: {'test': 'test_string'})
    assert Box([1,2,3,4,5]).to_lazy() == Lazy(lambda: [1,2,3,4,5])

# Generated at 2022-06-12 04:49:49.609832
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy

    assert isinstance(Box('x').to_lazy(), Monad)
    assert isinstance(Box('x').to_lazy(), Lazy)
    assert Box('x').to_lazy().fold() == Box('x').value



# Generated at 2022-06-12 04:49:56.782648
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(2) != Box(2.0)
    assert Box(2) != Box(3)
    assert Box(2) != Box('2')
    assert Box(2) != '2'
    assert Box(2) != {'key': 'value'}
    assert Box(2) != Box({'key': 'value'})
    assert Box(2) != Box([1, 2, 3])
    assert Box(2) != Box({'key': 5})
    assert Box([1, 2, 3]) != Box([1, 2, 3])
    assert Box([1, 2, 3]) != Box([1, 3, 2])
    assert Box([1, 2, 3]) != Box((1, 2, 3))

# Generated at 2022-06-12 04:50:00.079472
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('a')
    assert Box(1) != None



# Generated at 2022-06-12 04:50:02.263721
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:50:05.040420
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    b1 = Box(13)
    # when
    b2 = b1.to_lazy()
    # then
    assert b2.fold() == b1.value



# Generated at 2022-06-12 04:50:10.480224
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    value = 'value'
    assert Box(1) == Box(1)
    assert Box(value) == Box(value)
    assert Box(1) != Box('1')
    assert Box(value) != Box('value')
    assert Box(1) != '1'



# Generated at 2022-06-12 04:50:12.526111
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)



# Generated at 2022-06-12 04:50:17.190960
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    # Test when Boxes contain same values
    assert Box('same-value') == Box('same-value')

    # Test when Boxes contain different values
    assert Box('value') != Box('different-value')

    # Test when values in Boxes are of different types
    assert Box('value') != Box(42)


# Generated at 2022-06-12 04:50:21.201571
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(5).to_lazy()
    assert result.value() == 5
    result = Box(5).to_lazy().bind(lambda x: Lazy(lambda: x + 4))
    assert result.value() == 9


# Generated at 2022-06-12 04:50:41.935933
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    a = Box(1)
    b = Box(1)
    c = Box(2)
    assert a == b
    assert not (a == c)


# Generated at 2022-06-12 04:50:43.488375
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1), 'Box should be equal'



# Generated at 2022-06-12 04:50:49.453516
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('str') == Box('str')
    assert Box(Box(Box(123))) == Box(Box(Box(123)))
    assert Box(Box(Box(123))) == Box(Box(Box(123)))
    assert not Box(Box(Box(123))) == Box(Box(Box(1234)))
    assert not Box(Box(Box(123))) == Box(123)
    assert not Box(Box(Box(123))) == Box([])



# Generated at 2022-06-12 04:50:51.452180
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:50:53.510275
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert type(Box(3).to_lazy()) == Lazy


# Generated at 2022-06-12 04:50:56.694218
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    box = Box(10)

    # when
    lazy = box.to_lazy()

    # then
    assert lazy == lazy.value() == 10

# Generated at 2022-06-12 04:50:59.280912
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: Box(42).value)


# Generated at 2022-06-12 04:51:07.549946
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != Box(5)
    assert Box(3) != Box(5.0)
    assert Box(3) != Box('3')
    assert Box(3) != Box([])
    assert Box(3) != Box({})
    assert Box(3) != Box((3,))
    assert Box([3]) != Box([3, 5])
    assert Box(3) != None

    assert Box(None) == Box(None)
    assert Box([]) == Box([])
    assert Box({}) == Box({})
    assert Box(()) == Box(())
    assert Box([3]) != Box([])



# Generated at 2022-06-12 04:51:09.248641
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().value() == 5

# Generated at 2022-06-12 04:51:11.022169
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(1)
    b = Box(1)
    assert a == b



# Generated at 2022-06-12 04:51:49.216420
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)



# Generated at 2022-06-12 04:51:53.287603
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box('1')
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.is_folded() is False
    assert lazy.value() == '1'

# Generated at 2022-06-12 04:51:54.690901
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-12 04:51:57.034671
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == "1")


# Generated at 2022-06-12 04:51:58.293770
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:52:00.658158
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))



# Generated at 2022-06-12 04:52:09.900493
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # given
    box_1_1 = Box(1)
    box_1_2 = Box(1)
    box_2_1 = Box(2)
    box_2_2 = Box(2)
    box_2_3 = Box(2)
    # then
    assert box_1_1 == box_1_2
    assert box_2_1 == box_2_2
    assert box_2_2 == box_2_3
    assert box_1_1 != box_2_1
    assert box_1_1 != box_2_2
    assert box_1_2 != box_2_2
    assert box_1_2 != box_2_3



# Generated at 2022-06-12 04:52:20.822773
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from .test_lazy import test_Lazy_unit
    from pymonet.monad_try import Try
    from pymonet.monad_list import List
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    test_Lazy_unit(Box(123).to_lazy())
    assert Box(123).to_lazy() == Lazy(lambda: 123)
    assert Box(123).to_lazy() == Lazy(lambda: 123)
    assert Try(123).to_lazy() == Lazy(lambda: Try(123))
    assert Try.failure(123).to_lazy() == Lazy(lambda: Try.failure(123))
    assert List.unit(123).to_lazy() == Lazy(lambda: List.unit(123))


# Generated at 2022-06-12 04:52:22.952988
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(None)
    assert Box([]) != Box(None)
    assert Box(None) == Box(None)
    assert Box(1) != None



# Generated at 2022-06-12 04:52:24.659263
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy_value = Box(5).to_lazy()
    assert lazy_value.value() == 5


# Generated at 2022-06-12 04:53:53.811142
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:53:55.375217
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy().eval()

# Generated at 2022-06-12 04:53:56.770333
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy().map(lambda x: x)

# Generated at 2022-06-12 04:53:58.134987
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box.to_lazy(Box(1))() == 1

# Generated at 2022-06-12 04:54:04.713800
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1), "Box should be equal to Box with same value"
    assert Box(1) != Box(2), "Box should not be equal to Box with another value"
    assert Box(1) != Box('1'), "Box should not be equal to Box with another value"
    assert Box(1) != None, "Box should not be equal to Box with another value"



# Generated at 2022-06-12 04:54:07.005954
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 10
    box = Box(value)
    lazy = box.to_lazy()

    assert value == lazy.value()

# Generated at 2022-06-12 04:54:08.814500
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:54:10.733904
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(100).to_lazy().eval() == 100

# Generated at 2022-06-12 04:54:13.750617
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(10)
    lazy = Lazy(lambda: 10)

    assert box.to_lazy() == lazy

# Generated at 2022-06-12 04:54:14.929956
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('123').to_lazy().fold() == '123'

