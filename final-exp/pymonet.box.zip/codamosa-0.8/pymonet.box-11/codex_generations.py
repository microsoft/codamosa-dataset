

# Generated at 2022-06-12 04:47:28.780634
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)

    assert box1 == box2
    assert box1 != box3



# Generated at 2022-06-12 04:47:34.555710
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """ Testing method to_lazy of class Box """

    from pymonet.lazy import Lazy

    box_with_value = Box(Lazy(lambda: 1)).to_lazy()
    assert box_with_value.value() == 1

    assert Lazy(lambda: Box(1)).to_lazy().value() == 1



# Generated at 2022-06-12 04:47:36.928365
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Box(5).to_lazy()


# Generated at 2022-06-12 04:47:37.904738
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)

    assert box1 == box2


# Generated at 2022-06-12 04:47:40.338053
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Arrange
    left = Box("test")
    right = Box("test")

    # Act
    actual = left == right

    # Assert
    assert actual


# Generated at 2022-06-12 04:47:42.233927
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != Box(2)
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:47:45.814392
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-12 04:47:50.674871
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    # type: (T) -> B

    def f():
        return 100

    assert Box(1).to_lazy() == Box(f()).to_lazy()
    assert Box(1).to_lazy() == Lazy(f)
    assert Box(1).to_lazy().value == Lazy(f).value

# Generated at 2022-06-12 04:47:53.663192
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-12 04:47:57.466580
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_one = Box(1)
    box_two = Box(10)

    assert(box_one != box_two)
    assert(box_one != None)
    assert(box_two != None)
    assert(box_one != 1)



# Generated at 2022-06-12 04:48:05.533154
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box('a').to_lazy() == Lazy(lambda: 'a')
    assert Box(1).to_lazy() != Lazy(lambda: 'a')
    assert Box(1).to_lazy() != Box('a').to_lazy()

# Generated at 2022-06-12 04:48:08.548064
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box.
    """
    assert Box(10) == Box(10)



# Generated at 2022-06-12 04:48:10.574221
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    import pytest
    from tests.monad.test_monad import test_monad_eq

    test_monad_eq(Box, pytest)



# Generated at 2022-06-12 04:48:12.589802
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().fold(lambda: None) == 10


# Generated at 2022-06-12 04:48:14.858603
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)

    assert Box(1) != Box(2)
    assert Box(1) != '123'


# Generated at 2022-06-12 04:48:21.820349
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.exceptions import FoldException

    assert Box(1).to_lazy() == Lazy(lambda: 1)

    try:
        Box(1).to_lazy().fold()
    except FoldException as e:
        pass

    assert Box(1).to_lazy().to_box().value == 1

    assert Box(1).to_lazy().map(lambda x: x + 1).to_box().value == 2

# Generated at 2022-06-12 04:48:23.354398
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:48:33.124096
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy

    def lazy_sum(a, b):
        return Lazy(lambda: a + b)

    functor: Functor[Lazy] = Lazy(lazy_sum).map(lambda a: a + 1)  # Lazy[Function(() -> a + b)]
    monad: Monad[Lazy] = functor.ap(Lazy(lambda: 1))  # Lazy[a + 2]

    assert isinstance(monad, Lazy)
    assert isinstance(monad.value(), int)
    assert monad.value() == 3

# Generated at 2022-06-12 04:48:39.568347
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Box(1) == Box(1)
    assert Box('1') == Box('1')
    assert Box((1, 2, 3)) == Box((1, 2, 3))
    assert Box('a') != Box('')
    assert Box(1) != Box(2)
    assert Box(1) != Box((1,))
    assert Box((1,)) != Box((1, 2))
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box([1, 2, 3]) != Box([1, 2])

# Generated at 2022-06-12 04:48:41.287329
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-12 04:48:45.256372
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box("data").to_lazy() == Lazy(lambda: "data")

# Generated at 2022-06-12 04:48:48.876508
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None



# Generated at 2022-06-12 04:48:51.199975
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy().map(lambda x: x * 2).force() == 20

# Generated at 2022-06-12 04:48:55.201152
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # given
    box1 = Box(1)

    # when
    result1 = box1 == 1
    result2 = box1 == box1
    result3 = box1 == Box(1)

    # then
    assert not result1
    assert result2
    assert result3

# Generated at 2022-06-12 04:49:02.093855
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('text') == Box('text')
    assert Box(None) == Box(None)
    assert Box(1) != Box(None)
    assert Box(1) != Box('text')
    assert Box('text') != Box(1)
    assert Box('text') != Box(None)
    assert Box(None) != Box('text')
    assert Box(1) != Box(2)
    assert Box('text') != Box('other text')
    assert Box(None) != Box(1)


# Generated at 2022-06-12 04:49:05.538863
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    instance = Box(2)
    assert instance.to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 04:49:07.271756
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('abc') == Box('abc')
    assert Box(1) == Box(1)


# Generated at 2022-06-12 04:49:11.315381
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(2)
    a = 1
    assert box1 != box2
    assert box1 != a
    box1 = Box(2)
    box2 = Box(2)
    assert box1 == box2



# Generated at 2022-06-12 04:49:16.773151
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for == method of Box class

    :returns: nothing
    :rtype: None
    """
    box1 = Box(1)
    box2 = Box("some string")
    box3 = Box(None)
    assert box1 == box1
    assert box2 == box2
    assert box3 == box3
    assert box1 != box2
    assert box2 != box3


# Generated at 2022-06-12 04:49:17.982832
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 10) == Box(10).to_lazy()

# Generated at 2022-06-12 04:49:23.393226
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(4).to_lazy() == Lazy(lambda: 4)

# Generated at 2022-06-12 04:49:26.060620
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box(1) != '1'
    assert not Box(1) == Box('1')



# Generated at 2022-06-12 04:49:29.559316
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)
    assert Box(2) != Box('2')
    assert Box([1, 2]) != Box(['1', '2'])


# Generated at 2022-06-12 04:49:32.174424
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:49:34.403228
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-12 04:49:37.992603
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 2
    assert Box(1) != None
    assert Box(None) == Box(None)


# Generated at 2022-06-12 04:49:40.908606
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    first_box = Box(1)
    second_box = Box(2)
    equal_box = Box(1)
    assert first_box == equal_box
    assert first_box != second_box


# Generated at 2022-06-12 04:49:43.278216
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Unit tests for method map of class Box

# Generated at 2022-06-12 04:49:45.985438
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box(1) != Box(2)


# Generated at 2022-06-12 04:49:47.144734
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:49:53.313425
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(20)



# Generated at 2022-06-12 04:49:57.247613
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 2
    assert Box(None) == Box(None)
    assert Box(None) != Box(False)

# Generated at 2022-06-12 04:50:02.166137
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # 1. given
    box_1 = Box(123)
    box_2 = Box(123)
    box_3 = Box(1234)

    # 2. when
    result_1 = box_1 == box_2
    result_2 = box_1 == box_3
    result_3 = box_1 == 'some_string'

    # 3. then
    assert result_1 is True
    assert result_2 is False
    assert result_3 is False



# Generated at 2022-06-12 04:50:03.358146
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('1234').to_lazy().value() == '1234'

# Generated at 2022-06-12 04:50:06.283428
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == object()
    assert Box(1) == Box(1)


# Generated at 2022-06-12 04:50:11.020551
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box('string') != Box('String')
    assert Box((1, 2, 'string')) == Box((1, 2, 'string'))



# Generated at 2022-06-12 04:50:15.649006
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def test_value(value):
        return value

    box = Box("test")
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: "test")
    assert lazy.map(test_value)() == "test"

# Generated at 2022-06-12 04:50:17.677369
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(2) == Box(2)
    assert Box(2) != Box(3)
    assert Box(2) != 2



# Generated at 2022-06-12 04:50:22.516997
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(0)
    assert Box(1) != None  # noqa: E711
    assert Box('test') == Box('test')
    assert Box('test') != Box('another test')



# Generated at 2022-06-12 04:50:25.074254
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().force() == 2
    assert Box(2).to_lazy().map(lambda x: x + 2).force() == 4



# Generated at 2022-06-12 04:50:37.087010
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 04:50:41.413428
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    input_ = 'unit test'
    input_box = Box(input_)
    lazy = input_box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert input_box == Box(lazy.value())



# Generated at 2022-06-12 04:50:42.950590
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)



# Generated at 2022-06-12 04:50:45.992709
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(lambda x: x + 1)
    lazy = box.to_lazy()
    assert lazy.fold()(2) == 3

# Generated at 2022-06-12 04:50:47.718475
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:50:49.883241
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(4).to_lazy() == Lazy(lambda: 4)
    assert Box(4).to_lazy().force() == 4

# Generated at 2022-06-12 04:50:58.398507
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == 'Box[value=1]'
    assert Box('str') == Box('str')
    assert not Box('str') == Box('str2')
    assert not Box('str') == 'Box[value=str]'
    assert not Box(True) == Box(False)
    assert not Box(True) == 'Box[value=True]'
    assert not Box(3.14) == Box(2.7)
    assert not Box(3.14) == 'Box[value=3.14]'



# Generated at 2022-06-12 04:51:00.825806
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Box(5).to_lazy()



# Generated at 2022-06-12 04:51:03.358672
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().a == 10
    assert Lazy(lambda: Box(10)).a == 10


# Generated at 2022-06-12 04:51:06.133954
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box('a') != Box(1)
    assert Box(1) != Box('a')



# Generated at 2022-06-12 04:51:30.196693
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    def count(a):
        return a + 2
    box = Box(10)
    assertion = box.to_lazy().bind(count).bind(count)
    assert 14 == assertion.fold()

# Generated at 2022-06-12 04:51:32.398279
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 1) == Box(1).to_lazy()


# Generated at 2022-06-12 04:51:34.107066
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().take() == 1


# Generated at 2022-06-12 04:51:35.571298
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
# End unit test


# Generated at 2022-06-12 04:51:41.467405
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def inc(x):
        return x + 1

    assert inc(Box(1).value) == 2
    assert (Box(1).map(Lazy(inc).value).value) == 2
    assert Lazy(Box(1).value).map(inc).value == 2
    assert Lazy(Box(1).map(inc).value).value == 2
    assert Lazy(Box(1).value).map(Lazy(inc).value).value == 2
    assert (Box(1).map(Lazy(inc).value).value) == 2
    assert Lazy(Box(1).map(Lazy(inc).value).value).value == 2
    assert Lazy(Box(Lazy(1).value).map(Lazy(inc).value).value).value

# Generated at 2022-06-12 04:51:43.609586
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazyBox = Box(10).to_lazy()
    assert lazyBox.value() == 10


# Generated at 2022-06-12 04:51:46.175461
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) != 5
    assert Box(5) != Box(8)
    assert Box(5) == Box(5)



# Generated at 2022-06-12 04:51:49.846806
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # noqa: E300, E501
    # Test error
    assert Box(1) != Box(2)
    assert Box(1) != True
    assert Box(1) != 0
    assert Box(1) != '1'

    # Test correct
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:51:52.323223
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 'Box[value=1]'

# Generated at 2022-06-12 04:51:54.418783
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:52:39.141372
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 04:52:40.729029
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(100500)

    assert box.to_lazy().value() == 100500

# Generated at 2022-06-12 04:52:43.078680
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-12 04:52:46.076308
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(20) != Box(10)
    assert Box(20) != 10
    assert Box('Hello') == Box('Hello')
    assert Box('World') != Box('World ')
    assert Box('World') != 'World'



# Generated at 2022-06-12 04:52:48.850510
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Check Box->Lazy transformation.
    """

    value = 42
    box = Box(value)
    lazy = box.to_lazy()
    assert lazy.value() == box.value

# Generated at 2022-06-12 04:52:51.887316
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box("1")
    assert Box(1) != 1
    assert Box(1) != None

# Generated at 2022-06-12 04:53:00.176940
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad_try import MonadTry
    from pymonet.monad_validation import MonadValidation
    from pymonet.applicative import Applicative

    assert isinstance(Box(123).to_lazy(), Functor)
    assert isinstance(Box(123).to_lazy(), Monad)
    assert isinstance(Box(123).to_lazy(), Applicative)
    assert isinstance(Box(123).to_lazy(), MonadTry)
    assert isinstance(Box(123).to_lazy(), MonadValidation)


# Generated at 2022-06-12 04:53:02.780434
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:53:05.979669
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Given
    box = Box('test')

    # When
    box2 = Box('test')
    box3 = Box(1)
    box4 = 1

    # Then
    assert box == box2
    assert box != box3
    assert box != box4

# Generated at 2022-06-12 04:53:07.678408
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:54:44.718894
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().value() == 5

# Generated at 2022-06-12 04:54:47.941928
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(2) != Box('2')
    assert Box(1) != 1
    assert Box([]) != []
    assert Box(1) != 1.0



# Generated at 2022-06-12 04:54:51.135566
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not(Box(1) == Box(2))
    assert not(Box(1) == '1')



# Generated at 2022-06-12 04:54:52.923759
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 1

    assert Box(1).to_lazy() == Lazy(f)

# Generated at 2022-06-12 04:54:55.658805
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of Box class.
    """
    from pymonet.lazy import Lazy
    assert Box(33).to_lazy() == Lazy(lambda: 33)



# Generated at 2022-06-12 04:54:57.787196
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box(None) == Box(None)
    assert Box(3) != Box(None)



# Generated at 2022-06-12 04:55:01.498494
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test __eq__ method of Box class.

    :returns: None
    :rtype: None
    """
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box(1) != None
    assert Box(1) != [1]



# Generated at 2022-06-12 04:55:04.464741
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)

    assert box1 == box2
    assert box1 == box1
    assert box2 == box1
    assert not(box2 == Box(2))



# Generated at 2022-06-12 04:55:05.559802
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().force() == 42

# Generated at 2022-06-12 04:55:06.988375
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
