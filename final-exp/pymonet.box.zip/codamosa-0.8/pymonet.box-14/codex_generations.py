

# Generated at 2022-06-12 04:47:23.919794
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:47:28.365401
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().is_foldable() is False
    assert Box(1).to_lazy().get_value()() == 1
    assert Box(1).to_lazy().map(lambda x: x + 1).get_value()() == 2


# Generated at 2022-06-12 04:47:30.372856
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_value = 13

    box = Box(test_value)
    lazy = box.to_lazy()

    assert(lazy.fold() == test_value)



# Generated at 2022-06-12 04:47:33.435115
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)



# Generated at 2022-06-12 04:47:35.851190
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:47:39.007839
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Lazy(lambda: 3).to_box()
    assert box.to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 04:47:40.620479
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)



# Generated at 2022-06-12 04:47:45.674357
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box(1)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: 1)
    assert lazy.__repr__() == Lazy(lambda: 1).__repr__()
    assert lazy.__str__() == Lazy(lambda: 1).__str__()


# Generated at 2022-06-12 04:47:47.663518
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(12) == Box(12)


# Generated at 2022-06-12 04:47:49.228497
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(42) == Box(42)
    assert Box(42) != Box(24)



# Generated at 2022-06-12 04:47:54.544669
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad import bind
    from pymonet.monoid import add_monoid

    x = Box(10).to_lazy()
    assert isinstance(x, Lazy)
    assert x.value() == 10
    assert bind(add_monoid, x).value(100) == 110



# Generated at 2022-06-12 04:47:57.926401
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(10).to_lazy().eval_() == 10



# Generated at 2022-06-12 04:48:00.614500
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-12 04:48:02.821077
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('a')

# Generated at 2022-06-12 04:48:08.454998
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    class Foo:
        pass

    foo = Foo()
    foo.first = 'first'
    foo.second = 'second'

    bar = Foo()
    bar.first = 'first'
    bar.second = 'second'

    first = Box(foo)
    second = Box(bar)

    assert first is not second and first == second



# Generated at 2022-06-12 04:48:12.877001
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_function():  # pragma: no cover
        pass

    lazy_monad = Box(lazy_function).to_lazy()
    assert isinstance(lazy_monad, Lazy)
    assert lazy_monad.fold() == lazy_function



# Generated at 2022-06-12 04:48:15.171053
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    box = Box(3)
    # when
    actual = box.to_lazy()
    # then
    assert actual.value() == 3


# Generated at 2022-06-12 04:48:21.773947
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.utils import identity

    box = Box(123)
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 123
    assert lazy.map(identity).value() == 123
    assert lazy.bind(identity).value() == 123
    assert lazy.apply(Lazy(identity)).value() == 123

# Generated at 2022-06-12 04:48:24.379942
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    from pymonet.lazy import Lazy
    box = Box('123')
    assert box.to_lazy() == Lazy(lambda: '123')

# Generated at 2022-06-12 04:48:28.100103
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(1) == Box(1)

    assert Box(1) != Box(2)

    assert Box(1) != Box('1')



# Generated at 2022-06-12 04:48:33.084663
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:48:35.409457
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(100).to_lazy().force() == 100

    def foo():
        raise Exception('error')

    assert Box(foo).to_lazy().force() == foo



# Generated at 2022-06-12 04:48:39.364267
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # GIVEN
    lazy_value = Box(2).to_lazy()
    # WHEN
    calculated_value = lazy_value.value()
    # THEN
    assert calculated_value == 2, "calculated_value == 2"

# Generated at 2022-06-12 04:48:42.218267
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_a = Box('value')
    box_b = Box('value')

    assert box_a != box_b
    assert box_a == box_a
    assert box_b == box_b


# Generated at 2022-06-12 04:48:49.622731
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    f = lambda a: a + 1
    g = lambda a: a + 2

    b = Box(2)  # Box[int]

    assert b.to_lazy() == Lazy(lambda: 2)  # Lazy[int]
    assert b.to_lazy().map(f).map(g).get() == 5
    assert b.to_lazy().map(lambda a: a + 1).map(lambda a: a * 2).get() == 6
    assert (b.to_lazy()
            .map(lambda a: a + 1)
            .bind(lambda a: Lazy(lambda: a * 2))
            .map(lambda a: a - 1)
            .get()
            ) == 3

# Generated at 2022-06-12 04:48:53.065964
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def func_a(value):
        return value + 1

    assert Box(5).to_lazy().map(func_a).map(func_a).map(func_a).unsafe_eval() == 8

# Generated at 2022-06-12 04:49:02.416862
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(None).to_lazy() == Lazy(lambda: None)
    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box([42, 43]).to_lazy() == Lazy(lambda: [42, 43])
    assert Box((42, 43)).to_lazy() == Lazy(lambda: (42, 43))
    assert Box([[42], [43]]).to_lazy() == Lazy(lambda: [[42], [43]])
    assert Box({"foo": "bar"}).to_lazy() == Lazy(lambda: {"foo": "bar"})
    assert Box("foo").to_lazy() == Lazy(lambda: "foo")


# Generated at 2022-06-12 04:49:05.215319
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert callable(Box(42).to_lazy().value)
    assert Box(42).to_lazy().value() == 42



# Generated at 2022-06-12 04:49:08.411595
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    assert box1 == box2
    assert not box1 == Box(2)
    assert not box1 == object()



# Generated at 2022-06-12 04:49:10.206881
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))



# Generated at 2022-06-12 04:49:18.517577
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    to_test = Box(3)
    assert to_test.to_lazy().force() == 3



# Generated at 2022-06-12 04:49:22.445403
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(7)
    lazy = box.to_lazy()

    assert not lazy.is_evaluated()
    assert lazy.value() == 7
    assert isinstance(lazy, Lazy)

# Generated at 2022-06-12 04:49:24.960752
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(0.1) != Box(1)



# Generated at 2022-06-12 04:49:26.924491
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-12 04:49:28.860344
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Test returns successfull Try monad with previous value
    assert Box(5).to_lazy().get()() == 5

# Generated at 2022-06-12 04:49:30.994367
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 04:49:36.299075
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box(None)
    assert Box(1) != Box('1')
    assert Box(1) != Box(True)
    assert Box(1) != None
    assert Box(1) != '1'
    assert Box(1) != True



# Generated at 2022-06-12 04:49:38.636079
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 1
    box = Box(value)
    assert id(value) == id(box.to_lazy().get_value())

# Generated at 2022-06-12 04:49:40.130583
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:49:42.023487
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    assert Box(666).to_lazy() == Lazy(lambda: 666)

# Generated at 2022-06-12 04:49:56.238267
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 04:49:58.432091
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)
    assert Box(5) != "6"

# Generated at 2022-06-12 04:50:01.554480
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # GIVEN
    from pymonet.lazy import Lazy
    box = Box(2)

    # WHEN
    result = box.to_lazy()

    # THEN
    assert isinstance(result, Lazy)
    assert result.fold() == 2

# Generated at 2022-06-12 04:50:04.237755
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box.to_lazy
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:50:05.601678
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:50:09.907884
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    string_box = Box('string')
    another_string_box = Box('string')
    integer_box = Box(1)

    assert string_box == another_string_box
    assert string_box != integer_box
    assert string_box != 'string'



# Generated at 2022-06-12 04:50:13.742886
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)

    assert lazy.value() == 1



# Generated at 2022-06-12 04:50:17.376413
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().force() == 3
    assert Box('foo').to_lazy().force() == 'foo'
    assert Box(['bar', 'baz']).to_lazy().force() == ['bar', 'baz']


# Generated at 2022-06-12 04:50:19.054224
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:50:23.483746
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for __eq__ method of class Box
    """

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(None) == Box(None)


# Generated at 2022-06-12 04:50:47.539431
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert (Box(1) == Box(1))



# Generated at 2022-06-12 04:50:51.170179
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)
    assert Box(10).to_lazy().unsafe_run() == 10


# Generated at 2022-06-12 04:50:55.242244
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Given
    value = 'abc'
    box1 = Box(value)
    box2 = Box(value)

    # When
    result = box1 == box2

    # Then
    assert result is True, 'The result is wrong.'



# Generated at 2022-06-12 04:50:58.460478
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != None


# Generated at 2022-06-12 04:51:00.269141
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(Box(10)).to_lazy().f() == Box(10)

# Generated at 2022-06-12 04:51:03.041608
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(1).to_lazy().to_maybe() == Box(1).to_maybe()

# Generated at 2022-06-12 04:51:04.739628
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:51:05.991198
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:51:10.102511
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    result = Box(42).to_lazy()
    assert result  # Lazy[A]
    assert result.is_utterly_lazy()
    assert result.is_not_folded()
    assert result.force() == 42

# Generated at 2022-06-12 04:51:11.862760
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:51:59.929332
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import evaluate
    from pymonet.maybe import Maybe

    lazy_maybe = Box(Maybe.just(13)).to_lazy()
    assert evaluate(lazy_maybe) == Maybe.just(13)



# Generated at 2022-06-12 04:52:02.007318
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 04:52:04.220004
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy().fold(lambda: 100) == 1


# Generated at 2022-06-12 04:52:06.573446
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(123).to_lazy() == Lazy(lambda: 123)

# Generated at 2022-06-12 04:52:10.185321
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """

    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')



# Generated at 2022-06-12 04:52:14.496337
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('A') == Box('A')
    assert Box('A') != Box('B')
    assert 1 != Box(1)

# Generated at 2022-06-12 04:52:19.022565
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def test_function(x: int) -> int:
        return x

    lazy_value = Lazy(lambda: 5).bind(test_function)
    assert Box(lazy_value).to_lazy().value() == 5


# Generated at 2022-06-12 04:52:20.542909
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-12 04:52:22.310088
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:52:24.289858
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box('hello') == Box('hello')
# ----------------------------------------------------------------------------------------------------------------------

# Generated at 2022-06-12 04:53:17.388090
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 1000
    box = Box(value)

    assert box.to_lazy() == Lazy(lambda: value)

# Generated at 2022-06-12 04:53:18.774544
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(42) == Box(42)
    assert not (Box(42) == Box(43))



# Generated at 2022-06-12 04:53:19.937882
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('a').to_lazy() == Lazy(lambda: 'a')


# Generated at 2022-06-12 04:53:28.602167
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(123) == Box(123)
    assert Box('abc') == Box('abc')
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box({'a': 1}) == Box({'a': 1})

    assert Box(123) != Box(1234)
    assert Box('abc') != Box('abcd')
    assert Box([1, 2, 3]) != Box([1, 2, 4])
    assert Box({'a': 1}) != Box({'b': 1})

    assert dict({1: Box(123)}) != dict({1: Box(12)})
    assert dict({1: Box(123)}) == dict({1: Box(123)})
    assert dict({1: Box('abc')}) != dict({1: Box('abcd')})

# Generated at 2022-06-12 04:53:34.487335
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    # Test for simple integer value
    assert Box(5).to_lazy() == Lazy(lambda: 5)
    # Test for simple string value
    assert Box('hello').to_lazy() == Lazy(lambda: 'hello')
    # Test for lambda expression
    assert Box(lambda x: x * 2).to_lazy() == Lazy(lambda: lambda x: x * 2)



# Generated at 2022-06-12 04:53:36.393217
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    assert box.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:53:39.378549
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """Unit test for method __eq__ of class Box."""
    # initializing two Boxes with equal values and comparing them
    box1 = Box(1)
    box2 = Box(1)
    assert box1 == box2



# Generated at 2022-06-12 04:53:41.669148
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(None).to_lazy()) == "Lazy[func=<function Box_to_lazy.<locals>.<lambda> at 0x7f50ea2af048>]"



# Generated at 2022-06-12 04:53:44.967722
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 'any value'

    assert Box(value).to_lazy().fold() == value, 'expected {} and got {}'.format(value, Box(value).to_lazy().fold())

# Generated at 2022-06-12 04:53:48.928934
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    from pymonet.monad import Monad

    a = Monad.pure(Box, 1)
    b = Monad.pure(Box, 2)
    c = Monad.pure(Box, 1)
    assert a != b
    assert a == c

# Generated at 2022-06-12 04:55:56.328244
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    box = Box(10)
    assert box.to_lazy() == Lazy(lambda: 10)
    assert box.to_maybe() == Maybe.just(10)
    assert box.to_either() == Right(10)
    assert box.to_try() == Try(10, is_success=True)
    assert box.to_validation() == Validation.success(10)

# Generated at 2022-06-12 04:55:58.478607
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != None


# Generated at 2022-06-12 04:56:04.138848
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Box
    """

    # type: () -> Lazy[Function(() -> Any)]
    lazy_from_box = Box(1).to_lazy()

    # type: () -> Any
    value_from_lazy = lazy_from_box.value()

    # asserts
    assert lazy_from_box
    assert value_from_lazy == 1


# Generated at 2022-06-12 04:56:05.611575
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)



# Generated at 2022-06-12 04:56:07.642772
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy_f = Lazy(lambda: Box(42)).to_lazy().get()
    assert lazy_f() == Box(42)

# Generated at 2022-06-12 04:56:09.018729
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-12 04:56:12.353942
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert (Box(12) == Box(12)) is True
    assert (Box(12) == Box(11)) is False
    assert (Box(12) == str('a')) is False
    assert (Box(12) == None) is False
    assert (Box(12) == Box(None)) is False



# Generated at 2022-06-12 04:56:14.653967
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None

# Generated at 2022-06-12 04:56:16.972018
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 'a') == Box('a').to_lazy()



# Generated at 2022-06-12 04:56:18.965148
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)