

# Generated at 2022-06-23 23:53:49.048067
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('hello world')) == "Box[value='hello world']"


# Generated at 2022-06-23 23:53:55.734705
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('c')) == 'Box[value=c]'



# Generated at 2022-06-23 23:53:57.392070
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    def square(x):
        return x * x

    assert Box(3).bind(square) == 9

# Generated at 2022-06-23 23:53:59.728158
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet import Lazy

    def value_func():
        return 1

    assert Box(Lazy(value_func)).to_lazy() == Lazy(value_func)

# Generated at 2022-06-23 23:54:00.910100
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:54:08.459226
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right, LEFT
    from pymonet.monad_try import Try

    success_box = Box(42).to_either()  # => Right(42)
    fail_box = Box(Try(42, is_success=True)).to_either()  # => Right(42)
    fail_box = Box(Try('error', is_success=False)).to_either()  # => Left(error)

# Generated at 2022-06-23 23:54:09.649303
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('Hello!')) == 'Box[value=Hello!]'

# Generated at 2022-06-23 23:54:11.708401
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:54:15.351029
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for class Box bind method
    """
    def addition(number):
        return Box(number + 1)

    assert Box(3).bind(addition) == 4


# Generated at 2022-06-23 23:54:22.463742
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Left

    assert Box(Maybe.some(23)).to_try() == Try(Maybe.some(23), is_success=True)
    assert Box(Maybe.none()).to_try() == Try(Maybe.none(), is_success=True)
    assert Box(Left(['error'])).to_try() == Try(Left(['error']), is_success=True)

# Generated at 2022-06-23 23:54:24.841561
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe

    maybe_box = Maybe.just(lambda x: x+1)
    box = Box(1)

    assert maybe_box.ap(box).value == 2


# Generated at 2022-06-23 23:54:27.263580
# Unit test for constructor of class Box
def test_Box():
    assert Box(3).value == 3

# Generated at 2022-06-23 23:54:32.898652
# Unit test for method bind of class Box
def test_Box_bind():
    test_value = 1

    binded_value = Box(1).bind(lambda x: x * 2)
    assert isinstance(binded_value, Box)
    assert binded_value.value == test_value * 2



# Generated at 2022-06-23 23:54:39.173604
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    """
    Test case for method to_maybe of class Box.
    """
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() == Maybe.just(2)

    assert Box(2).to_maybe().is_just()
    assert not Box(2).to_maybe().is_nothing()


# Generated at 2022-06-23 23:54:41.940756
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.either import Either

    assert Box(1).to_either() == Right(1)
    assert isinstance(Box(1).to_either(), Either)



# Generated at 2022-06-23 23:54:46.307360
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_maybe()
    assert Box(1).to_maybe() != Box(2).to_maybe()



# Generated at 2022-06-23 23:54:48.609164
# Unit test for method bind of class Box
def test_Box_bind():
    def add(value):
        return value + 1

    box = Box(1)
    res = box.bind(add)
    expected = 2
    assert res == expected

# Generated at 2022-06-23 23:54:50.575291
# Unit test for method bind of class Box
def test_Box_bind():
    def add_1(x): return x + 1
    box = Box(2)
    assert box.bind(add_1) == 3



# Generated at 2022-06-23 23:54:55.471205
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert not Box(1) != Box(1)


# Generated at 2022-06-23 23:54:57.606457
# Unit test for method map of class Box
def test_Box_map():
    box = Box(1)

    assert box.map(lambda x: x + 1).value == 2
    assert box.map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:55:02.218912
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:55:04.401150
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    data = [1, 2, 3]
    actual = Box(data).to_validation()
    expected = Validation.success(data)

    assert actual == expected

# Generated at 2022-06-23 23:55:13.710578
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    """Unit test for method ap of class Box"""

    from pymonet.applicative import Applicative

    class A(Applicative):

        def __init__(self, value):
            self._value = value

        def map(self, mapper):
            return A(mapper(self._value))

        def ap(self, applicative):
            return self.map(applicative._value)

    box_a = Box(3)
    a_with_func = A(lambda x: x + 5)

    assert box_a.ap(a_with_func) == A(8)

# Generated at 2022-06-23 23:55:19.496353
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    # Test case: Box(3).bind(lambda value: Box(value + 1))
    assert Box(3).bind(lambda value: Box(value + 1)) == Box(4)



# Generated at 2022-06-23 23:55:23.741472
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-23 23:55:25.657970
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box(123)) == 'Box[value=123]'


# Generated at 2022-06-23 23:55:34.710431
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)
    assert Box('1').to_validation() == Validation.success('1')
    assert Box([]).to_validation() == Validation.success([])
    assert Box({}).to_validation() == Validation.success({})
    assert Box(True).to_validation() == Validation.success(True)
    assert Box(False).to_validation() == Validation.success(False)
    assert Box(None).to_validation() == Validation.success(None)
    assert Box(object()).to_validation() == Validation.success(object())


# Generated at 2022-06-23 23:55:39.944443
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Nothing

    assert Box(1).to_either() == Right(1)
    assert Box(Nothing()).to_either() == Right(Nothing())

# Generated at 2022-06-23 23:55:41.465316
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)



# Generated at 2022-06-23 23:55:43.963514
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box(None).to_either() == Right(None)
    assert Box(1).to_either() != Right(2)



# Generated at 2022-06-23 23:55:47.012562
# Unit test for method ap of class Box
def test_Box_ap():
    ap_func = lambda x: Box(x ** 2)
    assert Box(3).ap(ap_func) == Box(9)
    assert Box(5).ap(ap_func) == Box(25)

# Generated at 2022-06-23 23:55:48.837403
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:55:55.259898
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1)
    assert Box('Val')


# Unit test of map function of class Box

# Generated at 2022-06-23 23:55:59.704790
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """Unit test for method __eq__ of class Box"""

    # Assert that two boxes with same values are equal
    box = Box(42)
    assert box == Box(42)

    # Assert that two boxes with different values are not equal
    assert box != Box(43)



# Generated at 2022-06-23 23:56:04.831153
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Nothing, Maybe

    assert Box(12).to_maybe() == Maybe.just(12)
    assert Box(12).to_maybe() != Nothing()
    assert Box(12).to_maybe().to_box() == Box(12)


# Generated at 2022-06-23 23:56:09.798246
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    value = 'a'
    box = Box(value)
    assert box.to_try() == Try(value, is_success=True)

# Generated at 2022-06-23 23:56:12.249576
# Unit test for method bind of class Box
def test_Box_bind():
    # Arrange
    value = Box(42).bind(lambda x: x + 1)

    # Act
    # Assert
    assert value == 43

# Generated at 2022-06-23 23:56:16.370748
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert Box('a') == Box('a')
    assert not (Box('a') == Box('b'))
    assert Box(None) == Box(None)
    assert not (Box(None) == Box(False))
    assert Box([1]) == Box([1])
    assert not (Box([1]) == Box([2]))
    assert Box([1, 2]) == Box([1, 2])
    assert not (Box([1, 2]) == Box([1, 1]))
    assert Box([]) == Box([])
    assert not (Box([]) == Box([1]))
    assert Box(True) == Box(True)
    assert not (Box(True) == Box(False))
    assert Box(False) == Box

# Generated at 2022-06-23 23:56:17.932471
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(4).to_either() == Right(4)

# Generated at 2022-06-23 23:56:20.999815
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)


# Generated at 2022-06-23 23:56:23.655957
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as lazy

    maybe = Box(1).to_lazy()
    assert isinstance(maybe, lazy.Lazy)
    assert maybe.is_folded == False
    assert maybe.get_value() == 1


# Generated at 2022-06-23 23:56:25.838830
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(123).to_validation() == Validation.success(123)

# Generated at 2022-06-23 23:56:28.267026
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, fold

    assert fold(Box('Test').to_lazy()) == 'Test'
    assert fold(Box(Lazy('Test')).to_lazy()) == 'Test'
    assert Box(Lazy(Box(3))).to_lazy() == Lazy(Box(3))


# Generated at 2022-06-23 23:56:30.482431
# Unit test for method to_either of class Box
def test_Box_to_either():
    box = Box(2)
    assert isinstance(box.to_either(), Right)
    assert box.to_either().value == 2

# Unit test method to_maybe of class Box

# Generated at 2022-06-23 23:56:32.045757
# Unit test for method map of class Box
def test_Box_map():
    box = Box(1)
    assert box.map(lambda a: a + 1) == Box(2)


# Generated at 2022-06-23 23:56:33.250974
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, fold

    assert fold(Box(1).to_lazy()) == 1

# Generated at 2022-06-23 23:56:36.213342
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def expecting_function():
        return True

    assert Box(expecting_function).to_lazy() == Lazy(expecting_function)


# Generated at 2022-06-23 23:56:40.222174
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    assert Box(123).to_maybe() == Maybe.just(123)
    assert Box(123).to_try() == Try(123, is_success=True)
    assert Box(123).to_either() == Right(123)
    assert Box(123).to_validation() == Validation.success(123)
    assert Box(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-23 23:56:45.356559
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import ExceptionType

    sut = Box(Try(5, is_success=True))
    assert sut.to_try() == Try(5, is_success=True)

    sut = Box(Try(ExceptionType(), is_success=False))
    assert sut.to_try() == Try(ExceptionType(), is_success=False)

# Generated at 2022-06-23 23:56:47.617532
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box(1) != 1


# Generated at 2022-06-23 23:56:51.750363
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Box('test').to_try() == \
        Try('test', is_success=True)

    assert Maybe.just(Box('test')).to_try() == \
        Try(Box('test'), is_success=True)

    assert Maybe.nothing().to_try() == \
        Try(None, is_success=False)


# Generated at 2022-06-23 23:56:53.349947
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-23 23:56:54.523100
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:56:55.621679
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    assert Box(None)



# Generated at 2022-06-23 23:57:00.725630
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-23 23:57:06.204832
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(Try(1, is_success=True)).to_maybe() == Maybe.just(1)
    assert Box(Try(1, is_success=False)).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:57:10.840402
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.either import Left

    left = Left(10)
    box1 = Box(left)
    box2 = Box(left)
    assert box1 == box2



# Generated at 2022-06-23 23:57:17.152304
# Unit test for method to_validation of class Box
def test_Box_to_validation():

    assert Box(4).to_validation() == Validation.success(4)
    assert Box(4.5).to_validation() == Validation.success(4.5)
    assert Box(True).to_validation() == Validation.success(True)
    assert Box(True).to_validation() == Validation.success(True)
    assert Box(None).to_validation() == Validation.success(None)


# Generated at 2022-06-23 23:57:22.467476
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + x).ap(Box(2)) == Box(4)


# Generated at 2022-06-23 23:57:24.105765
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:57:26.532177
# Unit test for constructor of class Box
def test_Box():
    # given
    my_value = 'my value'

    # when
    box = Box(my_value)

    # then
    assert box.value == my_value



# Generated at 2022-06-23 23:57:28.306610
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda a: a ** 2).value == 9



# Generated at 2022-06-23 23:57:29.034901
# Unit test for method bind of class Box
def test_Box_bind():
    assert None is Box(1).bind(lambda x: x)



# Generated at 2022-06-23 23:57:30.178143
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-23 23:57:32.390310
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box
    """
    double = lambda a: 2 * a
    assert Box(5).bind(double) == 10
    assert Box(5).map(double) == Box(10)


# Generated at 2022-06-23 23:57:35.615076
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box('value').to_maybe() == Maybe('value')



# Generated at 2022-06-23 23:57:36.292725
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1


# Generated at 2022-06-23 23:57:38.101454
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(2).bind(lambda x: x * 3) == 6



# Generated at 2022-06-23 23:57:40.471741
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(9).to_either() == Right(9)


# Generated at 2022-06-23 23:57:47.744904
# Unit test for constructor of class Box
def test_Box():
    assert Box(4) == Box(4)
    assert Box(4) != Box('4')
    assert Box(4) != None
    assert 'Box[value=4]' == str(Box(4))
    assert 'Box[value=4]' != str(Box(5))
    assert 'Box[value=4]' != str(None)
    assert 'Box[value=4]' != 4
    assert (Box(2).map(lambda x: x + 3) == Box(5))
    assert (Box(2).bind(lambda x: x + 3) == 5)
    assert (Box(lambda x: x + 3).ap(Box(2)) == Box(5))

# Generated at 2022-06-23 23:57:52.499766
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('Hello')) == 'Box[value=Hello]'



# Generated at 2022-06-23 23:57:55.616990
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method on Box class.
    """
    from pymonet.lazy import Lazy
    value = 1
    box = Box(value)

    assert box.to_lazy() == Lazy(lambda: value)

# Generated at 2022-06-23 23:58:04.894196
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.func import F
    from pymonet.monad_try import Try

    f = F(lambda x: x + 1)
    g = F(lambda x: x * 2)

    # * [x -> x + 1, x -> x * 2]
    fg = f.ap(g)

    m5 = Box(5)

    # 5 * [x -> x + 1, x -> x * 2] = [5 + 1, 5 * 2]
    m6 = m5.ap(fg)

    assert m6.value == Try(11, is_success=True)



# Generated at 2022-06-23 23:58:13.809807
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy as lazy
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative
    from pymonet.monad_transformer import MonadTransformer

    class DummyClass(Functor, Monad, Applicative, MonadTransformer, Lazy):
        pass

    class BoxToLazyTest(object):
        def test_instance(self):
            box = Box(10)
            assert box.to_lazy()
            assert isinstance(box.to_lazy(), lazy.Lazy)

        def test_function(self):
            box = Box(10)
            assert box.to_lazy() == box.value

    return BoxToLazyTest()

# Generated at 2022-06-23 23:58:15.980750
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    assert Box(2).to_either().is_right
    assert Box(2).to_either().right_value == 2

# Generated at 2022-06-23 23:58:18.491390
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Nothing
    from pymonet.maybe import Just

    assert Box(1).to_maybe() == Just(1)
    assert Box(Nothing).to_maybe() == Nothing


# Generated at 2022-06-23 23:58:22.548565
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:58:25.754312
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 3) == Box(5)



# Generated at 2022-06-23 23:58:26.948467
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(2).value == 2
    assert Box(5.5).value == 5.5


# Generated at 2022-06-23 23:58:30.105869
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert Box(1).to_try() == Try(1, is_success=True)


# Unit test to_maybe method of class Box

# Generated at 2022-06-23 23:58:31.209122
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)


# Generated at 2022-06-23 23:58:34.312099
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(123).to_try() == Try(123, is_success=True)
    assert Box('abc').to_try() == Try('abc', is_success=True)

# Generated at 2022-06-23 23:58:36.028048
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1
    assert Box('test').value == 'test'


# Tests for method map of class Box

# Generated at 2022-06-23 23:58:38.561299
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('test').map(lambda x: x.upper() + '!') == Box('TEST!')



# Generated at 2022-06-23 23:58:41.455083
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:58:42.855473
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert Box(1).__str__() == 'Box[value=1]'



# Generated at 2022-06-23 23:58:44.178780
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert str(Box(1)) == "Box[value=1]"

# Generated at 2022-06-23 23:58:45.889580
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('1') == Box('1')


# Generated at 2022-06-23 23:58:47.630039
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)


# Generated at 2022-06-23 23:58:53.355275
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box.

    :returns: None
    :rtype: NoneType
    """
    initial_value = "Hello, "
    initial_applicative = Box(lambda x: x + "World")
    result = initial_applicative.ap(Box(initial_value))
    assert result.value == "Hello, World"

# Generated at 2022-06-23 23:59:01.795859
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_list import List
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Box(42) == Box(42)
    assert Box(42) != 42

    assert Box(Box(42)) == Box(Box(42))
    assert Box(Box(42)) != Box(42)

    assert Box(Try(42)) == Box(Try(42))
    assert Box(Try(42)) != Try(42)

    assert Box(Lazy(lambda: 42)) == Box(Lazy(lambda: 42))
    assert Box(Lazy(lambda: 42)) != Lazy(lambda: 42)


# Generated at 2022-06-23 23:59:09.939496
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either, Left, Right

    assert isinstance(Box(1).to_either(), Either)
    assert isinstance(Box(1).to_either(), Left)
    assert Box(1).to_either().value == 1

    assert isinstance(Box("a").to_either(), Either)
    assert isinstance(Box("a").to_either(), Right)
    assert Box("a").to_either().value == "a"



# Generated at 2022-06-23 23:59:11.382128
# Unit test for method __str__ of class Box
def test_Box___str__(): # pragma: no cover
    box = Box(12)
    assert str(box) == 'Box[value=12]'


# Generated at 2022-06-23 23:59:15.063026
# Unit test for method ap of class Box
def test_Box_ap():
    # Given
    x = Box(3)
    y = Box(lambda z: z + 1)

    # When
    result = x.ap(y)

    # Then
    assert result.value == 4

# Generated at 2022-06-23 23:59:16.603732
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:59:23.089100
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box.
    """
    value = Box(1)
    mapped_value = value.map(lambda x: x + 1)

    assert mapped_value.value == 2


# Generated at 2022-06-23 23:59:35.184988
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for equality of Lazy[Function(() -> A)] and Box[A]. This test checks only the type of monad, and the equality
    of the type of the data stored in the boxed.
    """

    assert isinstance(Box(1).to_lazy(), Box)
    assert Box(1).to_lazy() == Box(lambda: 1)

    assert isinstance(Box(2.3).to_lazy(), Box)
    assert Box(2.3).to_lazy() == Box(lambda: 2.3)

    assert isinstance(Box('hello').to_lazy(), Box)
    assert Box('hello').to_lazy() == Box(lambda: 'hello')

    assert isinstance(Box([1, 2, 3]).to_lazy(), Box)
    assert Box([1, 2, 3]).to

# Generated at 2022-06-23 23:59:36.935189
# Unit test for constructor of class Box
def test_Box():
    x = Box(42)
    assert x
    assert x == Box(42)

# Generated at 2022-06-23 23:59:39.260331
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)


# Generated at 2022-06-23 23:59:44.141655
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('a').to_lazy() == Lazy(lambda: 'a')

# Generated at 2022-06-23 23:59:45.339267
# Unit test for constructor of class Box
def test_Box():
    data = Box('foo')
    assert data.value == 'foo'



# Generated at 2022-06-23 23:59:50.227234
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:59:52.806853
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 'value')
    assert lazy == Box('value').to_lazy()



# Generated at 2022-06-23 23:59:57.092836
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:59:59.578391
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:00:03.781393
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(42).to_lazy()
    assert lazy._value() == 42
    assert lazy._value() == 42

# Generated at 2022-06-24 00:00:05.276742
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: Box(x + 1)) == Box(2)


# Generated at 2022-06-24 00:00:11.928489
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """

    from pymonet.monad_try import Try

    Box(5).to_try() == Try(5)

# Generated at 2022-06-24 00:00:15.427787
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    
    value = Box(10).to_validation()
    assert isinstance(value, Validation)
    assert isinstance(value.value, list)
    assert value.value[0].value == 10


# Generated at 2022-06-24 00:00:17.592186
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box("test_value").to_lazy().value() == "test_value"

# Generated at 2022-06-24 00:00:19.702824
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box('Hi')
    maybe = box.to_maybe()
    assert isinstance(maybe, Maybe)



# Generated at 2022-06-24 00:00:24.541647
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-24 00:00:29.979134
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.either import Right, Left
    from pymonet.maybe import Just, Nothing
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    add = Box(lambda x, y: x + y)
    add_five = add.ap(Right(5))
    assert add_five == Right(10)

    try_add = add.ap(Try(5, True))
    assert try_add == Try(10, True)

    empty = add.ap(Just(None))
    assert empty == Nothing

    empty = add.ap(Lazy(lambda: None))
    assert empty == Nothing

    add_four = add.ap(Left(4))
    assert add_four == Left(4)

    add_four = add.ap(Lazy(lambda: 4))


# Generated at 2022-06-24 00:00:31.948334
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-24 00:00:33.058192
# Unit test for method map of class Box
def test_Box_map():
    assert (
        Box(3).map(lambda x: x + 2) ==
        Box(5)
    )


# Generated at 2022-06-24 00:00:35.452914
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Box(None).to_maybe()
    assert Maybe.just(5) == Box(5).to_maybe()


# Generated at 2022-06-24 00:00:41.498018
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Just, Nothing

    assert Box(1).to_maybe() == Just(1)
    assert Box(None).to_maybe() == Just(None)
    assert Box(Maybe.just(1)).to_maybe() == Just(Maybe.just(1))
    assert Box(Maybe.nothing()).to_maybe() == Just(Maybe.nothing())
    assert Box(Nothing()).to_maybe() == Just(Nothing())


# Generated at 2022-06-24 00:00:46.230645
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    not_value = Box(None)
    value = Box('test')

    assert value.to_maybe() == Maybe.just('test')
    assert not_value.to_maybe() == Maybe.nothing



# Generated at 2022-06-24 00:00:49.566412
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.functor import Functor

    def add(a):
        return a + 1

    test_functor = Functor.lift(add)

    assert Box.unit(1).ap(test_functor) == Box.unit(2)

# Generated at 2022-06-24 00:00:56.289613
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Call ap of Box monad with another box of function.
    """
    from pymonet.either import Left
    from pymonet.validation import Validation

    box = Box(lambda x: x + 1)
    assert box.ap(Box(1)) == Box(2)
    assert box.ap(Left(1)) == Left(1)
    assert box.ap(Validation.success(1)) == Validation.success(2)



# Generated at 2022-06-24 00:01:00.791929
# Unit test for method ap of class Box
def test_Box_ap():
    def box_ap(a, b):
        return Box(lambda x: x + x).ap(Box(a)).bind(b)

    assert Box(2).ap(Box(2)).value == 4
    assert box_ap(1, lambda x: x+1).value == 4
    assert box_ap(1, lambda x: x+x).value == 4
    assert box_ap(2, lambda x: x+1).value == 5
    assert box_ap(2, lambda x: x+x).value == 8

# Generated at 2022-06-24 00:01:05.854595
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # should work with other monads
    assert Box(lambda x: x).ap(Box(Try.pure('a'))) == Try.pure('a')
    assert Box(lambda x: x).ap(Box(Validation.pure('a'))) == Validation.success('a')



# Generated at 2022-06-24 00:01:09.319666
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() == Maybe.just(2)
    assert(isinstance(Box(2).to_maybe(), Maybe))


# Generated at 2022-06-24 00:01:11.392804
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box('value').to_maybe() == Maybe.just('value')



# Generated at 2022-06-24 00:01:14.837344
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box('5') == Box('5')
    assert not (Box(5) == Box('5'))
    assert not (Box(5) == Box(None))
    assert not (Box(None) == Box(5))
    assert Box(None) == Box(None)



# Generated at 2022-06-24 00:01:19.333743
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test Box.to_maybe method.
    """
    from pymonet.maybe import Just, Nothing
    from pymonet.box import Box

    assert Nothing == None
    assert Just(42) == Box(42).to_maybe() == Box(Box(42).value).to_maybe()



# Generated at 2022-06-24 00:01:20.847234
# Unit test for method ap of class Box
def test_Box_ap():
    box = Box(lambda x: x * 100)
    assert box.ap(Box(2)) == Box(200)

# Generated at 2022-06-24 00:01:23.429784
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    assert Left(1) == Box(1).to_either()
    assert Right([]) == Box([]).to_either()
    assert Right('some text') == Box('some text').to_either()

# Generated at 2022-06-24 00:01:24.662438
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(5).to_try() == Try(5, is_success=True)



# Generated at 2022-06-24 00:01:28.466499
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).to_either()
    assert Box(1).to_either() != Box(2).to_either()



# Generated at 2022-06-24 00:01:32.062647
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Test __str__ of class Box
    """
    a = 1

    box = Box(a)

    assert str(box) == 'Box[value=1]'


# Generated at 2022-06-24 00:01:39.060436
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    just = Box(2).to_maybe()
    none = Box(None).to_maybe()
    nothing = Box(Try(None, False)).to_maybe()

    assert isinstance(just, Maybe)
    assert just.value == 2

    assert isinstance(none, Maybe)
    assert none.value is None

    assert isinstance(nothing, Maybe)
    assert nothing.value is None


# Generated at 2022-06-24 00:01:42.900244
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box(-1.0) == Box(-1.0)
    assert Box([1, 2, 3]) == Box([1, 2, 3])

    assert Box(1) != Box('a')
    assert Box(1.0) != Box(1.0)
    assert Box('a') != Box('b')
    assert Box([1, 2]) != Box([1, 2, 3])


# Generated at 2022-06-24 00:01:48.845093
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Success, Failure

    def func(a):
        return a ** 2
    assert Box(1).to_try().bind(func) == Success(1)
    assert Box(1).to_try().bind(func).to_try() == Success(1)
    assert Box(0).to_try().bind(func).to_try() == Success(0)
    assert Box(1).to_try().bind(func).to_try().bind(func) == Success(1)
    # assert Box(1).to_try().map(func) == Success(1) # Null type, map is of type Box[A(B)]
    assert isinstance(Box(1).to_try().bind(func).get_error(), Failure)
    assert Box(1).to_try().bind(func).get_

# Generated at 2022-06-24 00:01:51.839434
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    value = 10
    box = Box(value)
    assert box == box
    assert box == Box(value)
    assert box != Box("10")



# Generated at 2022-06-24 00:01:55.161028
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)
    assert Box('5').to_validation() == Validation.success('5')

# Generated at 2022-06-24 00:02:04.037123
# Unit test for method bind of class Box
def test_Box_bind():
    """
    It tests some operations on class Box.
    """

    def add_one(value: int) -> int:
        """
        Add one to value.

        :param value: value to add
        :type value: int
        :returns: added value
        :rtype: int
        """
        return value + 1

    box = Box(4)
    assert box.bind(add_one) == 5
    assert box.map(add_one) == 5

    box = Box('test')
    assert box.bind(lambda t: t + '2') == 'test2'
    assert box.map(lambda t: t + '2') == 'test2'



# Generated at 2022-06-24 00:02:06.142485
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    from pymonet.monad import Box

    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-24 00:02:07.401936
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover

    def mapper(x):
        return x

    assert Box(1).bind(mapper) == 1

# Generated at 2022-06-24 00:02:12.582100
# Unit test for method to_either of class Box
def test_Box_to_either(): # pragma: no cover
    """
    Case when we have Box with value and we want to transform this value into Either
    :return:
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-24 00:02:18.193449
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Validation.success(3) == Validation.success(3)
    assert Validation.success(3) == Box(3).to_validation()
    assert Validation.success(3) != Validation.success(4)
    assert Validation.success(3) != Box(4).to_validation()



# Generated at 2022-06-24 00:02:19.836605
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)



# Generated at 2022-06-24 00:02:21.637661
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Right(2) == Box(2).to_either()


# Generated at 2022-06-24 00:02:24.953453
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.either import Right
    from pymonet.exceptional import Exceptional

    assert Box(42).bind(lambda x: x + 1) == 43
    assert Box(Exceptional(Right(43))).bind(lambda x: x.value) == Right(43)

# Generated at 2022-06-24 00:02:28.829411
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    from pymonet.lazy import Lazy

    def f(x):
        return Lazy(lambda: x * 2)

    assert Box(2).bind(f) == Lazy(lambda: 4)
    assert Box(2).bind(lambda x: x) == 2
    assert Box(2).bind(lambda x: x + 1) == 3
    assert Box(2).bind(lambda x: x - 1) == 1



# Generated at 2022-06-24 00:02:32.746693
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def return_5():
        return 5

    assert Box(return_5).to_lazy() == Lazy(return_5)


# Generated at 2022-06-24 00:02:36.402823
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for to_either method of class Box
    """
    from pymonet.either import Right

    assert Box('Text').to_either() == Right('Text')


# Generated at 2022-06-24 00:02:40.179559
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Right(10) == Box(10).to_either()



# Generated at 2022-06-24 00:02:42.452103
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * x) == Box(4)



# Generated at 2022-06-24 00:02:48.599087
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)

# Generated at 2022-06-24 00:02:50.695104
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(0).bind(lambda x: x + 10) == 10


# Generated at 2022-06-24 00:02:56.619143
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for method bind of class Box.

    :return: None
    """
    from pymonet.maybe import Maybe

    # Test for box with value
    assert Box(1).bind(lambda x: Maybe(x + 2)) == Maybe(3)

    # Test for empty box
    assert Box(None).bind(lambda x: Maybe(x + 2)) == Maybe(None)

# Generated at 2022-06-24 00:03:00.151555
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.monad_try import Try

    def f(x):
        return Try(f=x + 1)

    assert Box(10).bind(f) == Try(11, is_success=True)



# Generated at 2022-06-24 00:03:01.642655
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:03:04.961210
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box(1)
    box_2 = Box(1)
    box_3 = Box(2)

    assert box_1 == box_2
    assert box_1 != box_3



# Generated at 2022-06-24 00:03:14.332221
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Failure

    assert Failure('error').to_try() == Failure('error')
    assert Box(1).to_try() == Box(1).to_try()
    assert Failure(Exception('error')).to_try() == Failure(Exception('error'))
    assert Failure(Exception('error')).to_try().to_lazy() == Failure(Exception('error')).to_lazy()
    assert Failure(Exception('error')).to_try().to_either() == Failure(Exception('error')).to_either()
    assert Failure(Exception('error')).to_try().to_validation() == Failure(Exception('error')).to_validation()
    assert Failure(Exception('error')).to_try().to_maybe() == Failure(Exception('error')).to_maybe()

# Generated at 2022-06-24 00:03:15.468345
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('1').bind(int) == 1


# Generated at 2022-06-24 00:03:17.535592
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    # Box[A] -> Maybe[A]
    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:03:24.660571
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # When create new Box[A]
    box = Box(3)
    # Then box.to_lazy() if lazy monad
    assert isinstance(box.to_lazy(), Lazy)
    # And returns not folded lazy monad
    assert not box.to_lazy().is_folded
    # And lazy monad contains function returning previous value
    assert box.value == box.to_lazy().value()
test_Box_to_lazy()

# Generated at 2022-06-24 00:03:27.849637
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.just(None)



# Generated at 2022-06-24 00:03:30.221626
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left

    assert Box(10).to_either() == Box(10).to_either()
    assert Box(10).to_either() != Left(10)


# Generated at 2022-06-24 00:03:32.233898
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)

# Generated at 2022-06-24 00:03:42.870388
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Testing method to_maybe of class Box
    """
    from pymonet.maybe import Maybe
    from pymonet.either import Left

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(2).to_maybe().ap(Box(lambda x: x + 4)) == Maybe.just(6)
    assert Box('a').to_maybe().bind(lambda x: Maybe.just(x + x)) == Maybe.just('aa')
    assert Box('a').to_maybe().map(lambda x: x + x) == Maybe.just('aa')
    assert Box('a').to_maybe().join() == Maybe.just('a')
    assert Box(1).to_maybe().join(Box('a').to_maybe()) == Box(1).to_maybe()
    assert Box('a').to_

# Generated at 2022-06-24 00:03:48.728815
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) == Box('1')
    assert Box('1') == Box(1)
    assert Box(1) != Box(2)
    assert Box('1') != Box('2')
    assert Box(None) == Box(None)

