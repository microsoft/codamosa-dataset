

# Generated at 2022-06-23 23:53:53.353002
# Unit test for constructor of class Box
def test_Box():
    value = 53
    test_box = Box(value)
    assert test_box.value == value



# Generated at 2022-06-23 23:53:57.848986
# Unit test for method map of class Box
def test_Box_map():
    # Test identity
    assert Box(1).map(lambda x: x) == Box(1)
    # Test composition
    assert Box(1).map(lambda x: x + 5).map(lambda x: x * 10) == Box(60)
    assert Box(1).map(lambda x: x * 10).map(lambda x: x + 5) == Box(15)

# Generated at 2022-06-23 23:54:00.468414
# Unit test for method map of class Box
def test_Box_map():
    box_result = Box(10).map(lambda x: x * 2)

    assert box_result.value == 20
    assert box_result.value == Box(20).value



# Generated at 2022-06-23 23:54:01.657740
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('Hello')) == 'Box[value=Hello]'



# Generated at 2022-06-23 23:54:06.261131
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    """
    Transform Box into not empty Maybe.
    """
    from pymonet.maybe import Maybe

    assert Box("value").to_maybe() == Maybe.just("value")


# Generated at 2022-06-23 23:54:08.032215
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(1).ap(Box(lambda x: x * 2)) == Box(2)



# Generated at 2022-06-23 23:54:09.626964
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(42).to_either() == Right(42)



# Generated at 2022-06-23 23:54:12.048524
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:54:15.302398
# Unit test for method map of class Box
def test_Box_map():
    box = Box(1)
    inc_box = box.map(lambda x: x + 1)
    assert inc_box.value == 2



# Generated at 2022-06-23 23:54:18.716998
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) == Box(1)) is True
    assert (Box(2) == Box(1)) is False
    assert (Box(1) == 1) is False



# Generated at 2022-06-23 23:54:23.955885
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Test for to_validation method of class Box.

    Throws TypeError if given value is not function
    """
    def given_positive_number_when_mapper_then_return_odd_number():
        """
        Given positive number when use mapper of Box then returns odd number

        :return: None
        :rtype: None
        """
        from pymonet.validation import Validation

        # Given
        initial_value = 42
        expected_value = Validation.success(initial_value + 1)

        # When
        actual_value = Box(initial_value).to_validation()

        # Then
        assert expected_value == actual_value

# Generated at 2022-06-23 23:54:25.205806
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a = Box('value').to_lazy()

    assert a.fold() == 'value'

# Generated at 2022-06-23 23:54:28.269006
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box('Box').to_validation() == Validation.success('Box')


# Generated at 2022-06-23 23:54:37.295841
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for: Box.ap

    :return:
    """
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(2).ap(Box(lambda x: x + 1)) == Box(3)
    assert Box(3).ap(Box(lambda x: x * 2)) == Box(6)
    assert Box(10).ap(Maybe.nothing()) == Maybe.nothing()
    assert Box(10).ap(Box(lambda x: x * 2)) == Box(20)
    assert Box(10).ap(Box(lambda x: x / 2)) == Box(5.0)

# Generated at 2022-06-23 23:54:39.783579
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    # When
    result = Box(42).to_either()

    # Then
    assert result == Right(42)


# Generated at 2022-06-23 23:54:43.674997
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('x')) == 'Box[value=x]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box([])) == 'Box[value=[]]'



# Generated at 2022-06-23 23:54:46.754796
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(3).to_maybe() == Maybe.just(3)



# Generated at 2022-06-23 23:54:49.831895
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: no cover
    assert Box(42).to_lazy().get_or_raise() == 42
    assert Box('42').to_lazy().get_or_raise() == '42'
    assert Box(42).to_lazy().get_or_raise() == 42


# Generated at 2022-06-23 23:54:55.347024
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(123.0)) == 'Box[value=123.0]'
    assert str(Box('test')) == 'Box[value=test]'



# Generated at 2022-06-23 23:54:56.040516
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box('string').ap(Box(len)) == Box(6)

# Generated at 2022-06-23 23:54:57.685539
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:55:03.247665
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(2)
    assert not (Box(1) == Box(3))

# Generated at 2022-06-23 23:55:06.580942
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:55:11.124482
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    @Try
    def fn_to_try():
        return 'Try result'

    assert Box(fn_to_try).to_try() == fn_to_try()

# Generated at 2022-06-23 23:55:14.020396
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert str(Box(10).to_either()) == 'Right(10)'

    assert isinstance(Box(10).to_either(), Right)


# Generated at 2022-06-23 23:55:19.291690
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left

    assert Box(42).to_either() == Right(42)
    assert Box(Left(42)).to_either() == Left(42)


# Generated at 2022-06-23 23:55:21.321030
# Unit test for method bind of class Box
def test_Box_bind():
    base_box = Box(10)
    final_box = base_box.bind(lambda x: x + 5)
    assert final_box == 15


# Generated at 2022-06-23 23:55:32.482973
# Unit test for method __str__ of class Box
def test_Box___str__():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box('abc')) == 'Box[value=abc]'
    assert str(Box(12)) == 'Box[value=12]'
    assert str(Box(False)) == 'Box[value=False]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(Maybe.just(1))) == 'Box[value=Maybe[value=1]]'

# Generated at 2022-06-23 23:55:36.948170
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test to_either method of Box.
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-23 23:55:38.240093
# Unit test for constructor of class Box
def test_Box():
    assert Box("1").value == "1"



# Generated at 2022-06-23 23:55:40.168976
# Unit test for method ap of class Box
def test_Box_ap():
    result = Box(lambda x: x + 1).ap(Box(2))
    assert result == Box(3)



# Generated at 2022-06-23 23:55:41.879714
# Unit test for method ap of class Box
def test_Box_ap():
    box1 = Box(lambda x: x + 1)
    box2 = Box(10)
    assert box1.ap(box2) == Box(11)

# Generated at 2022-06-23 23:55:45.194206
# Unit test for method map of class Box
def test_Box_map():
    empty_list = Box([])

    result = empty_list.map(lambda x: x.append(1)).value

    assert result == [1]


# Generated at 2022-06-23 23:55:49.879975
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Test of method to_validation of class Box.

    :return: None
    """
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)
    assert Box("string").to_validation() == Validation.success("string")
    assert Box(None).to_validation() == Validation.success(None)
    assert Box(True).to_validation() == Validation.success(True)



# Generated at 2022-06-23 23:55:51.269515
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-23 23:55:54.944792
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)

    lazy = box.to_lazy()

    assert isinstance(lazy, Box)
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1



# Generated at 2022-06-23 23:56:01.403883
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(None) == Box(None)
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('a') == Box('a')
    assert Box('a') != Box('1')
    assert Box(0.1) == Box(0.1)
    assert Box(0.1) != Box(0.2)

# Generated at 2022-06-23 23:56:05.363398
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad_identity import identity

    assert(Box(identity(5)).to_validation() == Validation.success(identity(5)))


# Generated at 2022-06-23 23:56:06.949557
# Unit test for constructor of class Box
def test_Box():
    assert Box(10) == Box(10)



# Generated at 2022-06-23 23:56:12.065385
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe

    assert Box(10).bind(lambda x: x + 1) == 11
    assert Box('10').bind(Maybe.just).bind(Maybe.just).bind(lambda x: x + 1) == 11
    assert Box(Just(10)).bind(Maybe.just).bind(Maybe.just).bind(lambda x: x + 1) == 11

# Generated at 2022-06-23 23:56:12.992500
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 10) == 11



# Generated at 2022-06-23 23:56:14.337731
# Unit test for method __str__ of class Box
def test_Box___str__():  # type: () -> None  # pragma: no cover
    assert Box(1).__str__() == 'Box[value=1]'

# Generated at 2022-06-23 23:56:15.664295
# Unit test for method __str__ of class Box
def test_Box___str__():
    m = Box(object())
    assert str(m) == 'Box[value=<object object at 0x7f2eb1490408>]'

# Generated at 2022-06-23 23:56:18.523072
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for ap method of Box class.
    """
    from pymonet.monad_try import Try

    def add_1(x):
        return x + 1
    assert Box(1).ap(Box(add_1)).value == 2
    assert Box(1).ap(Try(add_1)).value == 2



# Generated at 2022-06-23 23:56:21.588423
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    assert Box(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-23 23:56:31.030973
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(4) == Box(4)
    assert Box(6.9) == Box(6.9)
    assert Box('foo') == Box('foo')
    assert Box((1, 2, 3)) == Box((1, 2, 3))
    assert Box({'foo', 'bar'}) == Box({'foo', 'bar'})
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box(set([1, 2, 3])) == Box(set([1, 2, 3]))
    assert Box(dict({'foo': 1, 'bar': 2})) == Box(dict({'foo': 1, 'bar': 2}))
    assert Box(4) != Box(9)
    assert Box(6.9) != Box(8.7)

# Generated at 2022-06-23 23:56:33.402973
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    box = Box(1)

    # when
    actual = box.to_lazy()

    # then
    assert actual.fold() == 1

# Generated at 2022-06-23 23:56:35.681659
# Unit test for method bind of class Box
def test_Box_bind():
    def inc(x: int) -> int:
        return x + 1

    assert Box(0).bind(inc) == 1



# Generated at 2022-06-23 23:56:39.134808
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(42)) == 'Box[value=42]'

# Generated at 2022-06-23 23:56:43.134884
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    func = lambda: 'A'
    lazy = Box('A').to_lazy()
    assert lazy.value == func
    assert lazy.value() == 'A'
    assert lazy == Lazy(func)



# Generated at 2022-06-23 23:56:47.007402
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(20).to_lazy() == Lazy(lambda: 20)


# Generated at 2022-06-23 23:56:49.274501
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Box(0).to_validation() == Validation.success(0)



# Generated at 2022-06-23 23:56:53.709844
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box("123").bind(lambda x: x + "3") == "1233"



# Generated at 2022-06-23 23:56:56.893518
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success

    assert Validation.success(1) == Box(1).to_validation()
    assert Box(1).to_validation() == Success(1)



# Generated at 2022-06-23 23:57:00.552146
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() == Maybe.just(2)


# Generated at 2022-06-23 23:57:02.681858
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # type: () -> None

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-23 23:57:09.314185
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left

    assert Right(42).to_box().to_either() == Right(42)
    assert Right(None).to_box().to_either() == Right(None)
    assert Left(42).to_box().to_either() == Right(42)
    assert Left(None).to_box().to_either() == Right(None)



# Generated at 2022-06-23 23:57:11.556146
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-23 23:57:16.672186
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left

    assert Box(1).to_either() == Right(1)
    assert Box(2).to_either() == Right(2)
    assert Box(Left(1)).to_either() == Left(1)
    assert Box(Left(2)).to_either() == Left(2)



# Generated at 2022-06-23 23:57:22.064451
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-23 23:57:23.983218
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-23 23:57:27.940802
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.functions import identity
    from pymonet.monad_try import Try

    assert Box(42).bind(identity) == 42

    def wrong_mapper(value):
        return value / 0

    assert Box(42).bind(wrong_mapper) == Try(0, is_success=False)

# Generated at 2022-06-23 23:57:29.743638
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)

# Generated at 2022-06-23 23:57:30.957059
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 5).ap(Box(5)) == Box(10)



# Generated at 2022-06-23 23:57:32.709600
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    import pytest
    assert Box(1).to_maybe() == Maybe(1)



# Generated at 2022-06-23 23:57:38.052925
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(10).equals(Box(10).to_validation())
    assert Validation.failure(['test']).equals(Box(ValueError('test')).to_validation())



# Generated at 2022-06-23 23:57:41.820356
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try

    assert Box(1) == Box(1)
    assert Box(Try(1)) == Box(Try(1))
    assert Box(1) != Box(2)



# Generated at 2022-06-23 23:57:47.157883
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box.
    """

    import unittest

    from pymonet.maybe import Nothing, Maybe
    from pymonet.monad_t import m_t

    class TestBox(unittest.TestCase):
        """
        Test class for Box.
        """

        def test_to_maybe(self):
            """
            Test method to_maybe of class Box.
            """

            assert Box("foo").to_maybe() == Maybe("foo")
            assert Box(None).to_maybe() == Maybe(None)
            assert Box(1).to_maybe() == Maybe(1)

            assert m_t(Box("foo")).to_maybe() == Maybe("foo")
            assert m_t(Box(None)).to_maybe() == Maybe(None)
            assert m_

# Generated at 2022-06-23 23:57:55.042411
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    # Create box with integer value
    box = Box(42)

    assert box.value == 42

    # Invoke transformation to lazy
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)

    assert not lazy.is_folded()

    assert lazy.unfold() == 42

    assert lazy.is_folded()

    assert lazy.unfold() == 42



# Generated at 2022-06-23 23:57:59.529052
# Unit test for constructor of class Box
def test_Box():
    assert Box(42).value == 42
    assert Box(None).value is None
    assert Box(True).value is True
    assert Box('test').value == 'test'



# Generated at 2022-06-23 23:58:03.752525
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Try(Box('value').to_lazy().force(), is_success=True) == Try(Lazy(lambda: 'value').force(), is_success=True)

# Generated at 2022-06-23 23:58:06.355812
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left

    assert (Box(1).to_either() == Right(1))

    assert (Box(-1).to_either() == Right(-1))
    assert(Box(-1).to_either() != Left(-1))


# Generated at 2022-06-23 23:58:08.298882
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-23 23:58:10.950462
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Tests method ap of class Box.

    :return: None
    """
    def mapper(x):
        return lambda y: '{}-{}'.format(x, y)

    box = Box(mapper('test'))

    assert box.value('test') == 'test-test'
    assert box.ap(Box('test')) == Box('test-test')
    assert box.ap(Box('test2')) == Box('test-test2')

# Generated at 2022-06-23 23:58:15.291479
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'
    assert str(Box('hello')) == "Box[value=hello]"
    assert str(Box(True)) == "Box[value=True]"



# Generated at 2022-06-23 23:58:16.731580
# Unit test for method bind of class Box
def test_Box_bind():
    res = Box(10).bind(lambda a: a + 1)
    assert res == 11

# Generated at 2022-06-23 23:58:18.213553
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(3)) == 'Box[value=3]'

# Generated at 2022-06-23 23:58:25.435878
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """
    import unittest

    class BoxTest(unittest.TestCase):
        """
        Test cases for method to_try of class Box
        """

        def test_success(self):
            """
            Assert that Box.to_try returns Try with previous value
            """
            try_monad = Box(5).to_try()
            self.assertEqual(try_monad.value, 5)
            self.assertEqual(try_monad.is_success, True)
            self.assertEqual(try_monad.is_failure, False)

    unittest.main()


# Generated at 2022-06-23 23:58:26.638024
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Nothing

    assert Nothing() == Box(1).to_maybe()



# Generated at 2022-06-23 23:58:29.417525
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    assert Box(5).to_maybe() == Maybe.just(5)
    assert Box(5).to_maybe() is not Nothing()

# Generated at 2022-06-23 23:58:31.784185
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Run unit test for method to_either of class Box
    """
    from pymonet.either import Left

    assert Box(1).to_either() == Right(1)
    assert Box('str').to_either() == Right('str')
    # assert Box(RuntimeError()).to_either() == Left(RuntimeError())



# Generated at 2022-06-23 23:58:37.344739
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)



# Generated at 2022-06-23 23:58:39.870242
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 1

    lazy_monad = Box(value).to_lazy()
    assert lazy_monad.is_folded() is False
    assert lazy_monad.value() == value



# Generated at 2022-06-23 23:58:41.300096
# Unit test for constructor of class Box
def test_Box():
    """
    Test constructor for class Box.
    """
    assert Box(3) == Box(3)



# Generated at 2022-06-23 23:58:44.453323
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    # Test function returns Left Either
    assert Box(Left('some error')).to_either() == Left('some error')
    # Test function returns Right Either
    assert Box(Right('test')).to_either() == Right('test')



# Generated at 2022-06-23 23:58:47.058112
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:58:52.482625
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box
    """
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('Hello World!')) == 'Box[value=Hello World!]'


# Generated at 2022-06-23 23:58:54.034636
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x + 1) == Box(4)



# Generated at 2022-06-23 23:58:56.085420
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.box import Box
    from pymonet.either import Right
    assert Box(10).to_either() == Right(10)


# Generated at 2022-06-23 23:58:58.294999
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    box = Box(5)
    assert box.bind(lambda v: v + 1) == 6
    assert box.bind(lambda v: 6) == 6


# Generated at 2022-06-23 23:58:59.555962
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-23 23:59:01.253516
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(3).to_validation() == Validation.success(3)

# Generated at 2022-06-23 23:59:02.555794
# Unit test for method to_either of class Box
def test_Box_to_either():
    try:
        from pymonet.either import Right

        assert Box(3).to_either() == Right(3)
    except:
        pass

# Generated at 2022-06-23 23:59:06.968779
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(7)) == 'Box[value=7]'



# Generated at 2022-06-23 23:59:10.154073
# Unit test for method ap of class Box
def test_Box_ap():
    """
    ap method unit test
    """
    # Given
    x = Box(lambda x: x + 3)
    y = Box(2)

    # When
    result = x.ap(y)

    # Then
    assert result == Box(5)

# Generated at 2022-06-23 23:59:14.679859
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(4)
    assert box == Box(4)
    assert box != Box(3)
    assert box != 1


# Generated at 2022-06-23 23:59:16.816126
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:59:18.297516
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(10).to_maybe() == Box(10)

# Generated at 2022-06-23 23:59:22.238689
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('Python').map(lambda x: x.lower()) == Box('python')
    assert Box(True).map(lambda x: not x) == Box(False)
    assert Box({'name': 'Dmitry', 'age': 23}).map(lambda x: x.items()) == Box(dict(name='Dmitry', age=23).items())



# Generated at 2022-06-23 23:59:24.819058
# Unit test for constructor of class Box
def test_Box():
    assert Box(3) == Box(3)
    assert Box(3) != 3
    assert Box(3).value == 3


# Generated at 2022-06-23 23:59:29.666218
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box.
    """
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:59:34.280644
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.applicative import Applicative

    class FakeApplicative(Applicative):
        def __init__(self, value):
            self.value = value

        def map(self, mapper):
            return FakeApplicative(mapper(self.value))

    assert Box(5).ap(FakeApplicative(lambda value: value * 10)) == FakeApplicative(50)



# Generated at 2022-06-23 23:59:38.846426
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    # Arrange
    expected_lazy = Lazy(lambda: '345').fmap(lambda i: i + 2)
    box = Box(345).to_lazy()

    # Act
    lazy = box.fmap(lambda i: i + 2)

    # Assert
    assert lazy == expected_lazy

# Generated at 2022-06-23 23:59:44.098907
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).bind(lambda x: Maybe.just(x))



# Generated at 2022-06-23 23:59:45.593416
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(4).to_try() == Try(4, is_success=True)


# Generated at 2022-06-23 23:59:50.743872
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)

# Generated at 2022-06-23 23:59:52.544260
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1).value == 2



# Generated at 2022-06-24 00:00:00.440964
# Unit test for method bind of class Box
def test_Box_bind():
    try:
        from pymonet.box import Box
        from pymonet.maybe import Maybe

        assert Box(4).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(5)
        assert Box(4).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    except AssertionError:
        print('AssertionError')
        return False
    else:
        return True



# Generated at 2022-06-24 00:00:02.545054
# Unit test for method map of class Box
def test_Box_map():
    _box = Box(12).map(lambda x: x * 2)
    assert isinstance(_box, Box)
    assert _box.value == 24



# Generated at 2022-06-24 00:00:04.797261
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(42)
    lazy = box.to_lazy()
    assert box == lazy.fold()
    assert box.value == lazy.fold()
    assert Lazy(lambda: box.value) == lazy



# Generated at 2022-06-24 00:00:06.485940
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)



# Generated at 2022-06-24 00:00:09.998993
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    - test_Box_to_validation_success: test success
    """
    # test success
    def test_Box_to_validation_success():
        from pymonet.validation import Validation

        box = Box(1)
        assert box.to_validation() == Validation(1, [])
    test_Box_to_validation_success()


# Generated at 2022-06-24 00:00:11.112846
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:00:12.918033
# Unit test for method bind of class Box
def test_Box_bind():
    """
    >>> Box(1).bind(lambda x: x + 1)
    2
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 00:00:21.235515
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    :returns: Unit test result
    :rtype: bool
    """
    from pymonet.validation import Validation

    value = 1

    validation = Box(value).to_validation()

    is_instance = isinstance(validation, Validation)
    is_success_validation = validation.is_success
    is_validation_value = validation.valid_value == value

    return is_instance and is_success_validation and is_validation_value



# Generated at 2022-06-24 00:00:23.154457
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box('hello world')) == 'Box[value=hello world]'


# Unit tests for method __eq__ of class Box

# Generated at 2022-06-24 00:00:26.377993
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('abc')) == 'Box[value=abc]'
    assert str(Box({'A': 1})) == "Box[value={'A': 1}]"

# Generated at 2022-06-24 00:00:27.261656
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda x: x + 5) == 15

# Generated at 2022-06-24 00:00:32.321322
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 20) == Box(20).to_lazy()


# Generated at 2022-06-24 00:00:33.387027
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:00:35.199229
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try().is_success
    assert isinstance(Box(1).to_try().value, int)


# Generated at 2022-06-24 00:00:40.038041
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert(Box(1).to_try() == Try(1, is_success=True))


# Generated at 2022-06-24 00:00:50.887073
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    assert Box(3).map(lambda x: x * x).value == 9
    assert Box(3).map(lambda x: x + 1).map(lambda y: y * y).value == 16

    assert Box(3).to_maybe().map(lambda x: x * x).value == 9
    assert Box(3).to_maybe().map(lambda x: x + 1).map(lambda y: y * y).value == 16

    assert Box(3).to_lazy().map(lambda x: x * x).value == 9

# Generated at 2022-06-24 00:00:53.091018
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box('test').to_try() == Try(value='test', is_success=True)



# Generated at 2022-06-24 00:00:54.514452
# Unit test for method map of class Box
def test_Box_map():
    assert Box('qwe').map(lambda s: s + s) == Box('qweqwe')



# Generated at 2022-06-24 00:00:55.555500
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().fold() == 10

# Generated at 2022-06-24 00:00:59.064683
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1
    assert Box('test').value == 'test'
    assert Box(1.1).value == 1.1



# Generated at 2022-06-24 00:01:01.962710
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try(2, True) == Box(2).to_try()

# Generated at 2022-06-24 00:01:08.482708
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left

    assert Box(1).to_either() == Right(1)
    assert Box(1).to_either().map(lambda x: x + 1) == Right(2)
    assert Box(1).to_either().ap(Right(lambda x: x + 1)) == Right(2)
    assert Box(1).to_either().bind(lambda x: Right(x + 1)) == Right(2)
    assert Box(1).to_either().to_either() == Right(1)
    assert Box(1).to_either().to_maybe() == Maybe.just(1)
    assert Box(1).to_either().to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_either().to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:01:13.025868
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    box = Box(42)
    lazy = box.to_lazy()

    assert isinstance(lazy, Lazy)

    result = lazy.bind(lambda x: x)
    assert isinstance(result, Try)
    assert result == Try(42, is_success=True)

# Generated at 2022-06-24 00:01:18.045299
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing, Just

    assert Box(12).to_maybe() == Just(12)

    assert Box(None).to_maybe() == Nothing()

    assert Box(12).to_maybe() == Just(12)


# Generated at 2022-06-24 00:01:19.332933
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().fold() == 3


# Generated at 2022-06-24 00:01:21.818928
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(10)
    validation = Validation.success(10)
    assert box.to_validation() == validation



# Generated at 2022-06-24 00:01:22.967505
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 2) == 3

# Generated at 2022-06-24 00:01:24.476572
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)



# Generated at 2022-06-24 00:01:27.807779
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    box = Box(value=1)
    assert str(box) == 'Box[value=1]'



# Generated at 2022-06-24 00:01:30.312381
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-24 00:01:34.086174
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(3).to_maybe() == Maybe.just(3)



# Generated at 2022-06-24 00:01:36.526601
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    """
    Unit test for method bind of class Box
    """
    assert Box(4).bind(lambda x: x * 2) == 8



# Generated at 2022-06-24 00:01:37.747262
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Box(1).to_maybe()


# Generated at 2022-06-24 00:01:40.396012
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).to_either()
    assert Box(1).to_either() != Box('1').to_either()
    assert Box(1).to_either() != Box(0).to_either()
    assert repr(Box(1).to_either()) == "Right[{'value': 1}]"

# Generated at 2022-06-24 00:01:43.169613
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Box's instance method bind test.

    .. code-block:: python

        from pymonet.box import Box

        expected = 'expected'
        box = Box('initial')

        assert box.bind(lambda v: expected) == expected
    """



# Generated at 2022-06-24 00:01:44.536183
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.unit(1).to_validation() == Validation.unit(1)

# Generated at 2022-06-24 00:01:45.818785
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert isinstance(Box(1).to_either(), Right)
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-24 00:01:49.712649
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box.

    :returns: None
    :rtype: None
    """
    from pymonet.maybe import Maybe

    assert Box(lambda x: x + 2).ap(Maybe.just(2)) == Maybe.just(4)

# Generated at 2022-06-24 00:01:51.315955
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either().value == 1


# Generated at 2022-06-24 00:01:56.138971
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Run unit tests for Box[A].to_validation method

    :returns: nothing
    :rtype: None
    """
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)



# Generated at 2022-06-24 00:01:59.762749
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box.

    :returns: nothing
    :rtype: None
    """

    assert Box(1).to_validation() == Validation(1, [])


# Generated at 2022-06-24 00:02:02.098631
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left

    assert Box(123).to_either() == Right(123)


# Generated at 2022-06-24 00:02:06.000682
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.either import Left

    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)
    assert Box(lambda x: x + 1).ap(Left(2)) == Box(None)
    assert Box(2).ap(Box(lambda x: x + 1)) == Box(3)

# Generated at 2022-06-24 00:02:11.399157
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    try_monad = Box(1).to_try()

    assert try_monad == Try(1, is_success=True)


# Generated at 2022-06-24 00:02:13.688613
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box('first').to_validation() == Validation.success('first')

# Generated at 2022-06-24 00:02:16.536274
# Unit test for method bind of class Box
def test_Box_bind():
    def f(x: int) -> int:
        return x * 2

    x: Box[int] = Box(2)
    assert x.bind(f) == 4



# Generated at 2022-06-24 00:02:25.824277
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import unit

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box("test").to_lazy() == Lazy(lambda: "test")
    assert Box("test").to_lazy().bind(lambda x: unit(x + "a")) == Lazy(lambda: "testa")
    assert Box("test").to_lazy().bind(lambda x: unit(x + "a")).bind(lambda x: unit(x + "v")) == Lazy(lambda: "testav")

    lazy = Box("test").to_lazy().map(lambda x: x + "v").map(lambda x: x + "a")
    assert lazy == Lazy(lambda: "testva")

    assert Box(1).to

# Generated at 2022-06-24 00:02:27.431854
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test bind method of Box monad
    """
    from pymonet.maybe import Just

    assert Box(4).bind(lambda x: Just(x ** 2)) == Just(16)


# Unit test to check method map of class Box

# Generated at 2022-06-24 00:02:31.406447
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    """
    If we call method __str__ of class Box, it should return string with stored value
    """
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-24 00:02:35.001230
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert (Box(2).to_either() == Maybe.just(2))



# Generated at 2022-06-24 00:02:36.869442
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box('test') == Box('test')


# Unit testing for checking map method

# Generated at 2022-06-24 00:02:40.284265
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(20).to_either().value == 20


# Generated at 2022-06-24 00:02:43.592508
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test ap method of Box.
    """

    def _(x):
        return x*2

    assert Box(4).ap(Box(_)).value == 8

# Generated at 2022-06-24 00:02:45.731292
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Box(0).to_maybe(), Maybe)
    assert Box(1).to_maybe().value == 1


# Generated at 2022-06-24 00:02:48.703924
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either().is_right == True
    assert Box(1).to_either().value == 1


# Generated at 2022-06-24 00:02:53.198380
# Unit test for method map of class Box
def test_Box_map():
    from random import randint

    def add_five(x: int) -> int:
        return x + 5

    for _ in range(1000):
        x = randint(1, 1000)
        assert Box(x).map(add_five).value == x + 5


# Generated at 2022-06-24 00:03:03.330497
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.lazy import Lazy

    assert Box(1).to_try().value == Try(1, True)
    assert Box(12.0).to_try().value == Try(12.0, True)
    assert Box('test').to_try().value == Try('test', True)
    assert Box(None).to_try().value == Try(None, True)
    assert Box(True).to_try().value == Try(True, True)
    assert str(Box(Lazy(lambda: Lazy(lambda: print('Access lazy')))).to_try().value) == str(Try(Lazy(lambda: Lazy(lambda: print('Access lazy'))), True))



# Generated at 2022-06-24 00:03:05.404426
# Unit test for method to_either of class Box
def test_Box_to_either():
    value = 'Hi'
    box = Box(value)

    assert box.to_either().value == value

# Generated at 2022-06-24 00:03:07.715571
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert(Box(1).to_either() == Right(1))


# Generated at 2022-06-24 00:03:09.781616
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test bind method of class Box.
    """
    assert Box(1).bind(lambda x: x + 1) == 2



# Generated at 2022-06-24 00:03:12.917761
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert not (Box('a') == Box('b'))
    assert not (Box('a') == Box(1))



# Generated at 2022-06-24 00:03:14.370852
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: nocover
    assert Box(1).to_either().is_right


# Generated at 2022-06-24 00:03:16.117612
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(50).to_try() == Try(50, is_success=True)

# Generated at 2022-06-24 00:03:27.126798
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    assert Box(1).to_try().is_success is True
    assert Box(1).to_try().get() == 1
    assert Box(None).to_try().is_success is True
    assert Box(None).to_try().get() is None
    assert Box([]).to_try().is_success is True
    assert Box([]).to_try().get() == []
    assert Box(set()).to_try().is_success is True
    assert Box(set()).to_try().get() == set()
    assert Box({}).to_try().is_success is True
    assert Box({}).to_try().get() == {}
    assert Box({1}).to_try().is_success is True
    assert Box({1}).to_try().get() == {1}

# Generated at 2022-06-24 00:03:30.956489
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    import pytest

    from pymonet.validation import Validation
    from pymonet.validation_failure import ValidationFailure

    # Success case
    assert Box(123).to_validation() == Validation.success(123)

    # Failure case
    assert Box(ValidationFailure.empty()).to_validation() == Validation.failure([])


# Generated at 2022-06-24 00:03:41.779166
# Unit test for method map of class Box
def test_Box_map():
    """
    Test for method map of class Box
    """

    def add2(x: int) -> int:
        """
        :param x: some number
        :type x: int
        :returns: previous number incremented by two
        :rtype: int
        """
        return x + 2

    def square(x: int) -> int:
        """
        :param x: some number
        :type x: int
        :returns: previous number squared
        :rtype: int
        """
        return x * x

    assert Box(0).map(add2).map(square) == Box(0).map(lambda x: square(add2(x)))
    assert Box(2).map(add2).map(square) == Box(2).map(lambda x: square(add2(x)))

# Generated at 2022-06-24 00:03:44.160741
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Test for __str__ method of Box class.
    """

    assert str(Box('hello')) == 'Box[value=hello]'



# Generated at 2022-06-24 00:03:46.969953
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-24 00:03:50.687233
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.box import Box
    assert Box(5).to_validation() == Validation.success(5)

