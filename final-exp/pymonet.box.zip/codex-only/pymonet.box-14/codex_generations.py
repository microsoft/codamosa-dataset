

# Generated at 2022-06-23 23:53:54.730619
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    box = Box(3)
    lazy = box.to_lazy()
    assert lazy.value() == 3


# Generated at 2022-06-23 23:53:55.727383
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:53:57.093828
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 2).ap(Box(2)) == Box(4)



# Generated at 2022-06-23 23:54:00.034085
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:54:01.198422
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 1).value == Box(1).to_lazy().value()

# Generated at 2022-06-23 23:54:02.950251
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('a') == Box('a')
    assert not Box('a') == Box('b')


# Generated at 2022-06-23 23:54:07.117586
# Unit test for method map of class Box
def test_Box_map():
    assert Box(4).map(lambda x: x + 2) == Box(6)
    assert Box(4).map(lambda x: x - 2) == Box(2)


# Generated at 2022-06-23 23:54:08.463683
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'

# Generated at 2022-06-23 23:54:19.229684
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_maybe import Maybe
    from pymonet.funcs import add
    from pymonet.funcs import add_three
    from pymonet.funcs import ident

    assert add_three(3) == 6

    assert Box(3).ap(Box(ident)).ap(Box(add_three)) == Box(add_three(3))
    assert Box(3).ap(Box(add)).ap(Box(3)) == Box(add(3)(3))
    assert Box(3).ap(Box(add)).ap(Box(ident)).ap(Box(3)) == Box(add(3)(ident)(3))
    assert Box(3).ap(Box(add)).ap(Maybe.just(3)) == Box(add(3)(3))

# Generated at 2022-06-23 23:54:26.424592
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    # Given
    from pymonet.monad_try import Try

    box = Box(1)
    expected = Try(1, is_success=True)

    # When
    maybe = box.to_try()

    # Then
    assert maybe == expected

# Generated at 2022-06-23 23:54:32.713907
# Unit test for method to_validation of class Box
def test_Box_to_validation():
        from pymonet.validation import Validation

        assert Box(1).to_validation() == Validation.success(1)
        assert Box(1).to_validation() == Box(1).to_validation()



# Generated at 2022-06-23 23:54:34.035331
# Unit test for constructor of class Box
def test_Box():
    assert Box(10).value == 10



# Generated at 2022-06-23 23:54:38.425326
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Success, Failure

    assert Success(1).to_box().to_try() == Success(1)
    assert Failure(1).to_box().to_try() == Failure(1)


# Generated at 2022-06-23 23:54:40.135671
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x * 2).value == 2


# Generated at 2022-06-23 23:54:43.015250
# Unit test for constructor of class Box
def test_Box():
    """
    Unit test for constructor of class Box.
    """

    def compare(result: Box[int], expected: Box[int]) -> bool:
        return result == expected

    value = 10
    box = Box(value)
    assert(compare(box, Box(value)))



# Generated at 2022-06-23 23:54:48.975171
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:54:50.531311
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-23 23:54:52.342257
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for method bind of class Box.
    """

    assert Box(1).bind(lambda a: a + 1) == 2


# Generated at 2022-06-23 23:54:54.760091
# Unit test for method bind of class Box
def test_Box_bind():
    # Arrange
    box = Box(1)

    # Act
    result = box.bind(lambda x: x+1)

    # Assert
    assert result == 2


# Generated at 2022-06-23 23:54:57.706612
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    __test__ = True

    from pymonet.lazy import Lazy

    box = Box(1)

    assert Lazy(lambda: 1) == box.to_lazy()



# Generated at 2022-06-23 23:55:03.797508
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1) and Box(1) != Box(2)
    assert str(Box(2)) == 'Box[value=2]'



# Generated at 2022-06-23 23:55:15.216663
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_list import MList
    from pymonet.monad_set import MSet
    from pymonet.either import Left

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(Lazy(lambda: 1)).to_try() == Try(Lazy(lambda: 1), is_success=True)
    assert Box(Try(1, is_success=True)).to_try() == Try(Try(1, is_success=True), is_success=True)
    assert Box([3, 1, 2]).to_try() == Try([3, 1, 2], is_success=True)

# Generated at 2022-06-23 23:55:16.767971
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x+1) == Box(2)



# Generated at 2022-06-23 23:55:23.988120
# Unit test for method map of class Box
def test_Box_map():

    assert Box('Hello').map(lambda x: x.lower()) == Box('hello')
    assert Box(42).map(lambda x: x * 2) == Box(84)
    assert Box([1, 2, 3]).map(lambda x: x + [4]) == Box([1, 2, 3, 4])
    assert Box({'a': 1, 'b': 2}).map(lambda x: x['a'] + x['b']) == Box(3)
    assert Box(True).map(lambda x: not x) == Box(False)
    assert Box(False).map(lambda x: not x) == Box(True)



# Generated at 2022-06-23 23:55:27.664043
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    m_box = Box('message')
    print(m_box)
    print(m_box == Box('message'))
    print(m_box == Box('message2'))

    print(m_box.to_maybe())



# Generated at 2022-06-23 23:55:35.392453
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box('test')
    assert Box('test') == Box('test')
    assert not Box('test') == Box('test_2')
    assert not Box({'test': 1}) == Box({'test': 1})
    assert not Box([1, 2, 3]) == Box([1, 2, 3])
    assert not Box((1, 2)) == Box((1, 2))
    assert not Box(1) == (1, 2)
    assert not Box(1) == 'test'
    assert not Box(1) == {}



# Generated at 2022-06-23 23:55:39.597846
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import TryError

    assert Box(42).to_try() == Try(42, is_success=True)
    assert Box(TryError('Error message')).to_try() == Try(TryError('Error message'), is_success=True)

# Generated at 2022-06-23 23:55:41.384413
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-23 23:55:47.383635
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-23 23:55:48.233538
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-23 23:55:51.158827
# Unit test for method to_either of class Box
def test_Box_to_either():
    box = Box(1)
    assert box.to_either().value == 1
    assert box.to_either().is_right()


# Generated at 2022-06-23 23:55:54.450421
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right
    from pymonet.either_test import test_Either_map

    test_Either_map(lambda x: x + 1, Left(123), Right(124))



# Generated at 2022-06-23 23:56:02.695219
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    import pytest
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)
    assert Box(None).to_maybe() == Maybe.nothing()
    assert Box([1, 2, 3]).to_maybe() == Maybe.just([1, 2, 3])
    assert Box({"1": 2, "2": 3}).to_maybe() == Maybe.just({"1": 2, "2": 3})
    assert Box('string').to_maybe() == Maybe.just('string')


# Generated at 2022-06-23 23:56:04.830230
# Unit test for method map of class Box
def test_Box_map():
    assert Box(lambda x: x + 2).map(lambda x: x(2)) == Box(4)



# Generated at 2022-06-23 23:56:08.841282
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert "Box[value=1]" == str(Box(1))



# Generated at 2022-06-23 23:56:10.639570
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-23 23:56:11.643740
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box("Hi").to_validation() == Validation("Hi", [])

# Generated at 2022-06-23 23:56:13.306974
# Unit test for method map of class Box
def test_Box_map():
    assert Box(0).map(lambda x: x + 1) == Box(1)
    assert Box(0).map(lambda x: x) == Box(0)



# Generated at 2022-06-23 23:56:15.271740
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:56:17.965193
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just, Nothing

    assert Box(42).to_maybe() == Just(42)
    assert Box(None).to_maybe() == Just(None)
    assert Box([]).to_maybe() == Just([])



# Generated at 2022-06-23 23:56:22.794230
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # GIVEN
    value = 'value'
    box_value = Box(value)

    # WHEN
    box_value2 = Box(value)
    box_value3 = Box('value2')

    # THEN
    assert box_value == box_value2
    assert box_value != box_value3


# Generated at 2022-06-23 23:56:26.133831
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try().equals(Try.success(1))
    assert Box(1).to_try().is_success
    assert not Box(1).to_try().is_exception


# Generated at 2022-06-23 23:56:29.993919
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 2) == Box(4)
    assert Box(2).map(lambda x: x * 2) == Box(4)
    assert Box(2).map(lambda x: x / 2) == Box(1)
    assert Box(2).map(lambda x: x**2) == Box(4)


# Generated at 2022-06-23 23:56:31.100336
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(2).to_maybe().is_just(), 'Box to Maybe failed'


# Generated at 2022-06-23 23:56:34.181482
# Unit test for constructor of class Box
def test_Box():
    box_one = Box(1)
    box_two = Box(2)

    assert box_one.value == 1
    assert box_two.value == 2

    assert box_one == Box(1)
    assert box_two == Box(2)

    assert box_one.__eq__(1) is False
    assert box_two.__eq__(2) is False

    assert box_one.__eq__(box_one) is True
    assert box_two.__eq__(box_two) is True

# Generated at 2022-06-23 23:56:40.812655
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('str') == Box('str')
    assert Box([1, 2, 3]) == Box([1, 2, 3])

    assert Box(1) != Box(2)
    assert Box('str') != Box('')
    assert Box([1, 2, 3]) != Box([1, 2])


# Generated at 2022-06-23 23:56:43.671881
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(123).to_try() == Try(123, is_success=True)

# Generated at 2022-06-23 23:56:52.074629
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')
    assert Box(None) == Box(None)
    assert Box(None) != Box(False)
    assert Box(list(range(100))) == Box(list(range(100)))
    assert Box(list(range(100))) != Box(list(range(200)))
    assert Box({'a': 1, 'b': 2}) == Box({'a': 1, 'b': 2})
    assert Box({'a': 1, 'b': 2}) != Box({'c': 3, 'd': 4})



# Generated at 2022-06-23 23:56:55.681784
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)

    assert (box1 == box2) is True
    assert (box1 == box3) is False


# Generated at 2022-06-23 23:57:00.379587
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def get_value() -> int:
        return 1

    assert Box(get_value).to_lazy().force() == 1


# Generated at 2022-06-23 23:57:01.824297
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-23 23:57:06.660162
# Unit test for constructor of class Box
def test_Box():
    """
    Test of Box constructor.
    """
    a = Box(2)

    assert a is not None
    assert a.value == 2


# Generated at 2022-06-23 23:57:08.522106
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box("value"))

# Generated at 2022-06-23 23:57:17.105464
# Unit test for method map of class Box
def test_Box_map():
    # given
    def return_empty_string(value):
        return ''

    def return_inc_value(value: int) -> int:
        return value + 1

    box = Box(10)

    # when
    box_mapped_empty_string = box.map(return_empty_string)
    box_mapped_inc_value = box.map(return_inc_value)

    # then
    assert box_mapped_empty_string.value == ''
    assert box_mapped_inc_value.value == 11



# Generated at 2022-06-23 23:57:22.086197
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-23 23:57:24.764452
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    try_: Try[int] = Box(2).to_try()
    assert try_.is_success
    assert try_.value == 2

# Generated at 2022-06-23 23:57:26.855223
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    v = Box('test').to_validation()
    assert isinstance(v, Validation)

# Generated at 2022-06-23 23:57:28.917534
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(2).value == 2
    assert Box(2) == Box(2)


# Generated at 2022-06-23 23:57:30.675928
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box('my value').to_validation() == Validation.success('my value')

# Generated at 2022-06-23 23:57:32.501622
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Validation.success('test') == Box('test').to_validation()


# Generated at 2022-06-23 23:57:36.393044
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() == Maybe.just(2)


# Generated at 2022-06-23 23:57:40.768336
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box.
    """
    def f(x):
        return x + 1

    assert Box(1).bind(f) == f(1)
    assert Box(1).bind(f) == 2


# Generated at 2022-06-23 23:57:45.436085
# Unit test for method bind of class Box
def test_Box_bind():
    f = lambda a: Box(a+1)
    b = Box(1)
    res = b.bind(f)
    assert res == Box(2)


# Generated at 2022-06-23 23:57:47.404301
# Unit test for method map of class Box
def test_Box_map():
    assert Box(5).map(lambda x: str(x)) == Box('5')



# Generated at 2022-06-23 23:57:53.337594
# Unit test for method ap of class Box
def test_Box_ap():
    def add2(x: int) -> int:
        return x + 2

    assert Box(5).ap(Box(add2)) == Box(7)



# Generated at 2022-06-23 23:57:56.449635
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 2
    assert Box(1) != None
    assert Box(None) == Box(None)



# Generated at 2022-06-23 23:58:00.191465
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:58:02.480614
# Unit test for method ap of class Box
def test_Box_ap():
    f = Box(lambda x: x + 1)
    y = 3

    assert f.ap(Box(y)) == Box(4)

# Generated at 2022-06-23 23:58:03.991984
# Unit test for method to_either of class Box
def test_Box_to_either():
    box_ = Box(1)
    assert box_.to_either().unwrap() == 1


# Generated at 2022-06-23 23:58:09.958891
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Nothing

    lazy_1 = Box(Nothing()).to_lazy()
    assert str(lazy_1) == 'Lazy[value=function]'
    assert lazy_1.value == Nothing()
    lazy_2 = Box(Lazy(lambda: 4)).to_lazy()
    assert str(lazy_2) == 'Lazy[value=function]'
    assert lazy_2.value == Lazy(lambda: 4)
    lazy_3 = Box(Lazy(lambda: '1')).to_lazy()
    assert str(lazy_3) == 'Lazy[value=function]'
    assert lazy_3.value == Lazy(lambda: '1')

# Generated at 2022-06-23 23:58:15.328323
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box(42).to_try() == Try(42, True)

# Generated at 2022-06-23 23:58:16.051699
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box("foo").to_lazy(), lazy.Lazy)

# Generated at 2022-06-23 23:58:19.049126
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    # Arrange
    b = Box(5)
    expected_maybe = Maybe.just(5)

    # Act
    result_maybe = b.to_maybe()

    # Assert
    assert result_maybe == expected_maybe


# Generated at 2022-06-23 23:58:22.725604
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    def f():  # pragma: no cover
        return 3
    assert Lazy(f) == Box(f).to_lazy()

# Generated at 2022-06-23 23:58:27.097257
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x * 2) == Box(2)
    assert Box(1).map(lambda x: x / 2) == Box(0.5)



# Generated at 2022-06-23 23:58:29.519484
# Unit test for method bind of class Box
def test_Box_bind():

    def foo(value: int) -> int:
        return value * 2

    assert Box(10).bind(foo) == 20



# Generated at 2022-06-23 23:58:31.874653
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """

    # Given
    box = Box(2)

    # When
    lazy = box.to_lazy()

    # Then
    value = lazy.value()
    assert value == 2
    assert isinstance(value, int)



# Generated at 2022-06-23 23:58:36.408755
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    assert Box(lambda x: x * 2).ap(Box(10)) == Box(20)



# Generated at 2022-06-23 23:58:41.497566
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.either import Validation
    import pytest

    assert Box(10).to_maybe() == 10
    assert Box(Validation.failure(Validation.Errors.EMPTY)).to_maybe() == None
    with pytest.raises(TypeError):
        Box(Validation.failure(Validation.Errors.EMPTY)).to_maybe().map(lambda x: x + 1) == None



# Generated at 2022-06-23 23:58:43.119570
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)


# Generated at 2022-06-23 23:58:46.169183
# Unit test for method map of class Box
def test_Box_map():
    box_string = Box('Test')
    box_new_string = box_string.map(lambda t: '{}...'.format(t))
    assert box_new_string == Box('Test...')



# Generated at 2022-06-23 23:58:48.125721
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:58:51.669611
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-23 23:58:52.934873
# Unit test for constructor of class Box
def test_Box():
    assert Box('test') == Box('test')



# Generated at 2022-06-23 23:59:00.906090
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for bind method in Box monad
    """

    def plus_one_x2(x):
        return (x + 1) * 2

    def power_two(x):
        return x ** 2

    def add_two(x, y):
        return x + y

    assert Box(5).bind(plus_one_x2) == 12
    assert Box(5).bind(power_two) == 25
    assert Box(5).bind(power_two).bind(plus_one_x2) == 26
    assert Box(5).bind(plus_one_x2).bind(power_two) == 100

    assert Box(5).bind(lambda x: add_two(x, 1)) == 11



# Generated at 2022-06-23 23:59:05.458091
# Unit test for constructor of class Box
def test_Box():
    var_x = Box(1)
    assert var_x.value == 1


# Generated at 2022-06-23 23:59:07.005492
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(0).to_maybe() == Maybe(0)


# Generated at 2022-06-23 23:59:13.014314
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(2)
    lazy_box = box.to_lazy()

    assert lazy_box.value() == 2
    assert lazy_box.is_folded() is False



# Generated at 2022-06-23 23:59:16.815825
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda i: i + 2) == 3
    assert Box(3).bind(lambda i: i + 3) == 6
    assert Box(5).bind(lambda i: i + 5) == 10

# Generated at 2022-06-23 23:59:21.061838
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_test import test_to_maybe

    test_to_maybe(lambda value: Box(value), lambda value: Box(value).to_maybe(), lambda value: Maybe.just(value))



# Generated at 2022-06-23 23:59:27.753551
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda x: x + 1) == 4
    assert Box(3).bind(lambda x: x - 1) == 2
    assert Box(3).bind(lambda x: x * 2) == 6
    assert Box(3).bind(lambda x: x / 2) == 1.5
    assert Box(3).bind(lambda x: x ** 2) == 9


# Generated at 2022-06-23 23:59:38.691262
# Unit test for method to_either of class Box
def test_Box_to_either():
    # creates new Box monad
    box = Box(123)
    # box transforms to Right Either monad
    assert box.to_either() == Right(123)
    # creates new Box monad
    box = Box(456)
    # box transforms to Right Either monad
    assert box.to_either() == Right(456)
    # creates new Box monad
    box = Box(None)
    # box transforms to Right Either monad
    assert box.to_either() == Right(None)
    # creates new Box monad
    box = Box(True)
    # box transforms to Right Either monad
    assert box.to_either() == Right(True)
    # creates new Box monad
    box = Box(False)
    # box transforms to Right Either monad
    assert box.to_either() == Right(False)

# Generated at 2022-06-23 23:59:46.803633
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)
    assert Box("error").to_try() == Try("error", is_success=True)
    assert Box([1, 2, 3]).to_try() == Try([1, 2, 3], is_success=True)
    assert Box({1: 2}).to_try() == Try({1: 2}, is_success=True)


# Generated at 2022-06-23 23:59:52.465193
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(2).map(lambda x: x + 1) == Box(3)
    assert Box(3).map(lambda x: x + 1) == Box(4)



# Generated at 2022-06-23 23:59:58.061373
# Unit test for method map of class Box
def test_Box_map():
    # arrange
    expected_box = Box(5)
    box = Box(5)

    # act
    actual_box = box.map(lambda x: x)

    # assert
    assert actual_box == expected_box


# Generated at 2022-06-23 23:59:59.940436
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box('abc').to_either() == Right('abc')



# Generated at 2022-06-24 00:00:02.193763
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda num: num * 2) == 4
    assert Box(5).bind(lambda num: Box(num)) == Box(5)



# Generated at 2022-06-24 00:00:04.298870
# Unit test for method map of class Box
def test_Box_map():
    box = Box(value=3)
    new_box = box.map(lambda x: x * 2)
    assert isinstance(new_box, Box)
    assert new_box.value == 6
    assert box.value == 3



# Generated at 2022-06-24 00:00:05.720448
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().equals(Box(1).to_lazy().evaluate())

# Generated at 2022-06-24 00:00:11.848375
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:00:13.029574
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert(Box('10').to_either() == Right('10'))

# Generated at 2022-06-24 00:00:20.159065
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 2) == Box(4)
    assert Box(1).map(lambda x: -x) == Box(-1)
    assert Box(3).map(lambda x: x ** 3) == Box(27)
    assert Box(0).map(lambda x: 1 / x) == Box(1 / 0)



# Generated at 2022-06-24 00:00:25.313866
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box('a').to_either() == Right('a')



# Generated at 2022-06-24 00:00:26.721590
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-24 00:00:31.773608
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(5).to_either() == Right(5)

# Generated at 2022-06-24 00:00:32.719234
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(3)
    other = Box(3)

    assert box == other



# Generated at 2022-06-24 00:00:33.990374
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(2)) == 'Box[value=2]'



# Generated at 2022-06-24 00:00:36.826517
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(1)
    assert str(box) == 'Box[value=1]'

# Generated at 2022-06-24 00:00:38.762678
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box('1').to_validation() == Validation.success('1')

# Generated at 2022-06-24 00:00:40.032849
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2



# Generated at 2022-06-24 00:00:41.607291
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box = Box("hello")
    assert box.to_validation().value == "hello"

# Generated at 2022-06-24 00:00:43.246355
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box.unit(2).to_lazy().eval() == 2

# Generated at 2022-06-24 00:00:46.513296
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-24 00:00:51.921993
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.list import List
    from pymonet.monad_try import Try

    assert Box(lambda a: a + 1).ap(Box(1)) == Box(2)
    assert Box(lambda a: a + 1).ap(Box('1')) == Box('11')
    assert Box(lambda a: a + 1).ap(List([1, 2])).value == [2, 3]
    assert Box(lambda a: a + 1).ap(Try(2, True)).value == 3
    assert Try(lambda a: a + 1, True).ap(Box(1)).is_success() is True
    assert Try(lambda a: a + '1', True).ap(Box(1)).is_success() is False

# Generated at 2022-06-24 00:00:53.719188
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(6).to_validation() == Validation.success(6)

# Generated at 2022-06-24 00:00:55.101004
# Unit test for method map of class Box
def test_Box_map():
    assert Box(5).map(lambda x: x + 5) == Box(10)


# Generated at 2022-06-24 00:00:56.777095
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)

# Generated at 2022-06-24 00:00:58.175217
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold() == 1

# Generated at 2022-06-24 00:01:01.024775
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    import pytest

    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)
    assert Box("5").to_validation() == Validation.success("5")
    assert Box({"5": 5}).to_validation() == Validation.success({"5": 5})



# Generated at 2022-06-24 00:01:01.905116
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-24 00:01:11.945555
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box.
    """
    from ExpectError import ExpectTypeError

    # Test case: Box with integer value
    assert str(Box(10)) == 'Box[value=10]', 'Fail test case: Box with integer value'

    # Test case: Box with string value
    assert str(Box('str')) == 'Box[value=str]', 'Fail test case: Box with string value'

    # Test case: Box with float value
    assert str(Box(1.1)) == 'Box[value=1.1]', 'Fail test case: Box with float value'

    # Test case: Box with list value
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]', 'Fail test case: Box with list value'

    # Test case:

# Generated at 2022-06-24 00:01:13.734095
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'


# Unit tests for method map of class Box

# Generated at 2022-06-24 00:01:17.687599
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.either import Right

    assert Box('1') == Right('1')
    assert Box('1') == Box('1')
    assert Box('1') != Box(2)



# Generated at 2022-06-24 00:01:19.661647
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box("a") == Box("a")


# Generated at 2022-06-24 00:01:20.907463
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda value: value * value) == 25

# Generated at 2022-06-24 00:01:22.010213
# Unit test for constructor of class Box
def test_Box():
    assert(Box(1).value == 1)



# Generated at 2022-06-24 00:01:24.157271
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test that Box has been successfully translated into Either
    """
    box = Box.__new__(Box, "test")

    assert box.to_either().value == "test"



# Generated at 2022-06-24 00:01:26.493608
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(1)
    assert box.to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:01:30.525711
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(100) == Box(100).to_validation()

# Generated at 2022-06-24 00:01:41.112211
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    # Integer value
    val = 3
    assert Box(val).to_maybe() == Maybe.just(val)

    # Empty string value
    val = ''
    assert Box(val).to_maybe() == Maybe.just(val)

    # Empty list
    val = []
    assert Box(val).to_maybe() == Maybe.just(val)

    # None value
    val = None
    assert Box(val).to_maybe() == Maybe.just(val)

    # One element list
    val = [1]
    assert Box(val).to_maybe() == Maybe.just(val)

    # One Character string
    val = '1'
    assert Box(val).to_maybe() == Maybe.just(val)

   

# Generated at 2022-06-24 00:01:43.265177
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)
    assert Box(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:01:44.690218
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    lazy = Box(3).to_lazy()
    assert lazy.fold() == 3

# Generated at 2022-06-24 00:01:47.828268
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert True == Box(True).to_try() == Try(True, is_success=True)



# Generated at 2022-06-24 00:01:49.295852
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(3)) == "Box[value=3]"


# Generated at 2022-06-24 00:01:52.634135
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    t = Try(1, is_success=True)
    test_value = Box(1).to_try()
    assert t == test_value


# Generated at 2022-06-24 00:01:56.193842
# Unit test for method to_try of class Box
def test_Box_to_try():
    import pytest

    from pymonet.monad_try import Failure

    box_value = Box(1)
    assert isinstance(box_value.to_try(), Failure) is False



# Generated at 2022-06-24 00:01:58.537690
# Unit test for method __str__ of class Box
def test_Box___str__():
    actual = Box('value_1')
    assert actual.__str__() == 'Box[value=value_1]'

# Generated at 2022-06-24 00:02:02.097629
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    validation = Box(1).to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.success == 1


# Generated at 2022-06-24 00:02:03.080684
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(4).bind(lambda x: x * 2) == 8


# Generated at 2022-06-24 00:02:04.293294
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(10).to_try() == Success(10)


# Generated at 2022-06-24 00:02:06.377585
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(4) == Box(4)
    assert Box(3) != Box(4)
    assert Box(3) != Box(None)



# Generated at 2022-06-24 00:02:07.768329
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 1) == Box(1).to_lazy()


# Generated at 2022-06-24 00:02:09.272364
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try.just(1).to_box() == Box(1)



# Generated at 2022-06-24 00:02:10.608123
# Unit test for method bind of class Box
def test_Box_bind():
    box_value = Box('value')
    assert box_value.bind(lambda x: x) == 'value'


# Generated at 2022-06-24 00:02:11.528819
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-24 00:02:15.174589
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)
    assert Try(5, is_success=True) == Box(5).to_try()

# Generated at 2022-06-24 00:02:17.388074
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert 'Box[value=123]' == str(Box(123))
    assert 'Box[value=True]' == str(Box(True))
    assert 'Box[value=False]' == str(Box(False))
    assert "Box[value='string']" == str(Box('string'))


# Generated at 2022-06-24 00:02:18.345619
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'

# Generated at 2022-06-24 00:02:19.689998
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-24 00:02:20.873588
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert isinstance(Box(1).to_either(), Right)



# Generated at 2022-06-24 00:02:23.694668
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just, Maybe

    box_maybe = Box(3).to_maybe()
    assert isinstance(box_maybe, Maybe)
    assert box_maybe == Just(3)

# Generated at 2022-06-24 00:02:25.571516
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) == Box('1')
    assert Box(True) == Box(True)

# Generated at 2022-06-24 00:02:26.656070
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(13).to_lazy().value() == 13



# Generated at 2022-06-24 00:02:30.502979
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    test_value = Box(32).to_try()
    assert isinstance(test_value, Try)
    assert test_value.get() == 32



# Generated at 2022-06-24 00:02:39.357291
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    a = Box(Maybe.from_optional(lambda: 2))
    f = Box(Try(lambda x: x + 1, is_success=True))
    assert f.ap(a).value == Maybe.from_optional(lambda: 3)

    a = Box(Maybe.from_optional(lambda: 2))
    f = Box(Try(lambda x: x + 1, is_success=False))
    assert f.ap(a).value == Maybe.from_optional(lambda: None)

    a = Box(Maybe.from_optional(lambda: None))
    f = Box(Try(lambda x: x + 1, is_success=True))
    assert f.ap(a).value == Maybe.from_optional(lambda: None)

    a

# Generated at 2022-06-24 00:02:42.547700
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-24 00:02:45.998978
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.either import Left
    assert (Box(lambda x: x + 1).ap(Box(2)) == Box(3))
    assert (Box(lambda x: x + 1).ap(Left('error')) == Box(lambda x: x + 1))

# Generated at 2022-06-24 00:02:52.936682
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    assert Box(1).to_either() == Right(1)
    assert Box("Box").to_either() == Right("Box")
    assert Box(ValueError("Box")).to_either() == Right(ValueError("Box"))
    assert Box("Box").to_either().map(lambda x: x + "ss") == Right("Boxss")
    assert Box("Box").to_either().bind(lambda x: x + "ss") == "Boxss"
    assert (Box("Box").to_either().map(lambda x: x + "ss").to_either() ==
            Right("Boxss"))
    assert (Box("Box").to_either().bind(lambda x: x + "ss").to_either() ==
            Right("Boxss"))

# Generated at 2022-06-24 00:02:55.317003
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(3).to_validation() == Validation.success(3)

# Generated at 2022-06-24 00:02:58.538034
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)

    assert box1 == box1
    assert box1 == box2
    assert box1 != None
    assert box1 != 2
    assert box1 != 'Hello'

# Generated at 2022-06-24 00:03:01.337061
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(10)
    box2 = Box(10)
    box3 = Box(5)
    assert box1 == box2
    assert box1 != box3


# Generated at 2022-06-24 00:03:02.826859
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)

# Generated at 2022-06-24 00:03:05.652425
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x ** 2).ap(Box(3)) == Box(9)

    assert Box(3).ap(Box(lambda x: x ** 2)) == Box(9)

# Generated at 2022-06-24 00:03:08.336520
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:03:11.152506
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    result = Box(1).to_maybe()
    assert isinstance(result, Maybe)
    assert result.value == 1



# Generated at 2022-06-24 00:03:13.510348
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)
    assert Box(5).to_either().is_right


# Generated at 2022-06-24 00:03:16.629259
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test method bind of class Box

    :returns: None
    :rtype: None
    """
    def add1(value):
        return value + 1

    box = Box(1)

    assert box.bind(add1) == add1(1), "Wrong call of box bind"


# Generated at 2022-06-24 00:03:22.513584
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit-test for method to_maybe of Box class.

    :return: None
    """
    box = Box(None)

    assert box.to_maybe().is_nothing() == True
    assert box.to_maybe().is_just() == False

    box = Box(1)

    assert box.to_maybe().is_just() == True
    assert box.to_maybe().is_nothing() == False
    assert box.to_maybe().to_box().value == 1


# Generated at 2022-06-24 00:03:27.215479
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    :returns: None
    :rtype: None
    """
    assert Box(42).to_try().is_success
    assert Box(42).to_try().get() == 42


# Generated at 2022-06-24 00:03:29.132628
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5)

# Generated at 2022-06-24 00:03:32.674678
# Unit test for constructor of class Box
def test_Box():
    """
    Test for init of Box class.
    """
    assert Box(1).value == 1 and Box('1').value == '1' and Box(None).value is None


# Generated at 2022-06-24 00:03:38.684242
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(True)) == str(Box(True))
    assert str(Box(True)) != str(Box(False))
    assert str(Box([1, 2])) != str(Box([]))

# Unit tests for method map of class Box

# Generated at 2022-06-24 00:03:48.847401
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.maybe import is_just
    from pymonet.maybe import from_just

    assert is_just(Box(10).to_maybe())
    assert from_just(Box(10).to_maybe()) == 10
    assert is_just(Box('hello!').to_maybe())
    assert from_just(Box('hello!').to_maybe()) == 'hello!'
    assert is_just(Box(10.3).to_maybe())
    assert from_just(Box(10.3).to_maybe()) == 10.3
    assert is_just(Box(True).to_maybe())
    assert from_just(Box(True).to_maybe()) is True
    assert is_just(Box(None).to_maybe())