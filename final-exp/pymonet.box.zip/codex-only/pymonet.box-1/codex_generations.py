

# Generated at 2022-06-23 23:53:48.891968
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box(lambda: 1) # type: Box[Callable]
    assert box.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-23 23:53:50.753297
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda x: x * 2) == Box(20)



# Generated at 2022-06-23 23:54:01.095552
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)

    assert Box(lambda x: x * 5).ap(Box(20)) == Box(100)

    assert Box(lambda x: x[:2]).ap(Box('qwerty')) == Box('qw')

    assert Box(lambda x: True if x > 0 else False).ap(Box(5)) == Box(True)

    assert Box(lambda x: True if x > 0 else False).ap(Box(-5)) == Box(False)

    assert Box(lambda x: x + 1).ap(Box(None)) == Box(None)

    assert Box(None).ap(Box(1)) == Box(None)


# Generated at 2022-06-23 23:54:04.322012
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    value = 1
    box = Box(value)
    from pymonet.validation import Validation
    validation = Validation.success(value)
    assert box.to_validation() == validation


# Generated at 2022-06-23 23:54:08.161739
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Success

    result = Box(1).to_try()
    expected = Success(1)
    assert result == expected


# Generated at 2022-06-23 23:54:16.814196
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe, Just, Nothing
    from pymonet.either import Either, Left, Right

    def f(arg):
        return Just(arg)

    def g(arg):
        return Right(arg)

    assert Box(Maybe._value).bind(f) == Just(Maybe._value)
    assert Box(Maybe._nothing).bind(f) == Nothing()
    assert Box(Either._value).bind(g) == Right(Either._value)
    assert Box(Either._value).bind(g) != Left(Either._value)
    assert Box(Either._nothing).bind(g) == Left(Either._nothing)



# Generated at 2022-06-23 23:54:19.230289
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    result = Box(10).to_validation()

    assert result.is_success() is True and result.value == 10



# Generated at 2022-06-23 23:54:26.049598
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    assert Box(5).to_maybe() == Maybe.just(5)
    assert Box(Nothing).to_maybe() == Maybe.just(Nothing)



# Generated at 2022-06-23 23:54:27.636165
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(42).value == 42, 'Box should have value == 42'

# Generated at 2022-06-23 23:54:33.412048
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]' or str(Box(5)) == 'Box[value=5]'

# Generated at 2022-06-23 23:54:38.620147
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)  # pylint: disable=unneeded-not
    assert Box([1]) != Box([1])
    assert Box({'key': 'value'}) == Box({'key': 'value'})



# Generated at 2022-06-23 23:54:39.356860
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-23 23:54:48.241020
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(1).to_try().map(lambda x: x + 3) == Try(4, is_success=True)
    assert Box(3).to_try().map(lambda x: x / 0) == Failure("division by zero")
    assert Box(3).to_try().map(lambda x: x / 0).map(lambda x: x + 3) == Failure("division by zero")
    assert Box("foo").to_try().map(lambda x: x.strip("f")) == Try("oo", is_success=True)



# Generated at 2022-06-23 23:54:51.267582
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x + 1) == 6
    assert Box(5.5).bind(lambda x: x + 1) == 6.5
    assert Box(True).bind(lambda x: not x) == False

# Generated at 2022-06-23 23:54:54.340568
# Unit test for method bind of class Box
def test_Box_bind():
    def bar(x):
        return x + 1

    def foo(x):
        return Box(x + 2)

    assert Box(1).bind(bar) == 2
    assert Box(1).bind(foo).bind(bar) == 4


# Generated at 2022-06-23 23:54:59.775978
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """Test case for __eq__ method of Box class."""
    assert Box(1) == Box(1)
    assert Box('s') == Box('s')
    assert Box([]) == Box([])
    assert Box({}) == Box({})
    assert Box(None) == Box(None)
    assert not Box(1) == Box('1')
    assert not Box(1) == Box({})
    assert not Box([]) == Box({})
    assert not Box((1, 2)) == Box({1: 2})
    assert not Box(True) == Box(False)


# Generated at 2022-06-23 23:55:02.442893
# Unit test for method ap of class Box
def test_Box_ap():
    """
    g(x) = x + 10
    Box(g) ap Box(10) -> Box(20)
    """
    # given
    box_f = Box(lambda x: x + 10)
    box_x = Box(10)

    # when
    result = box_f.ap(box_x)

    # then
    assert result == Box(20)

# Generated at 2022-06-23 23:55:04.449217
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def lazy_func():
        return 3

    assert Box(lazy_func).to_lazy() == Box(lazy_func()).to_lazy()



# Generated at 2022-06-23 23:55:07.216980
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(3)) == Box(4)

# Generated at 2022-06-23 23:55:16.950431
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    double = lambda x: x * 2
    half = lambda x: x / 2

    assert Box(2).bind(double) == 4
    assert Box(2).bind(half) == 1
    assert Box(None).bind(double) is None

    assert Box(Maybe.just(2)).bind(double).value == Maybe.just(4)
    assert Box(Maybe.nothing()).bind(half).value == Maybe.nothing()

    assert Box(Try.success(2)).bind(double).value == Try.success(4)
    assert Box(Try.failure(Exception('ups'))).bind(double).value == Try.failure(Exception('ups'))


# Generated at 2022-06-23 23:55:21.241192
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.either import Left
    from pymonet.either import Either

    assert Box(None).to_either() == Right(None)
    assert Box(None).to_either().value == None
    assert Box(None).to_either().is_right()
    assert not Box(None).to_either().is_left()
    assert Box(None).to_either().is_instance(Right)
    assert not Box(None).to_either().is_instance(Left)
    assert Box(None).to_either().is_instance(Either)



# Generated at 2022-06-23 23:55:25.888166
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(15).to_try() == Try(15, is_success=True)



# Generated at 2022-06-23 23:55:32.350477
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.monad_list import List
    from pymonet.validation import Validation

    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Box(lambda x, y: x * y).ap(Box(2)).ap(Box(3)) == Box(6)
    assert Box(lambda x: x + 1).ap(List([1, 2])) == List([2, 3])
    assert Box(lambda x: x + 1).ap(Validation.success(1)) == Validation.success(2)

# Generated at 2022-06-23 23:55:38.325962
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_not_implemented_error import MonadNotImplementedError

    assert Lazy(lambda: 4) == Box(4).to_lazy()

    with pytest.raises(MonadNotImplementedError):
        Box('test').to_lazy()



# Generated at 2022-06-23 23:55:40.248700
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:55:43.371320
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(123).to_validation() == Validation.success(123)

# Generated at 2022-06-23 23:55:45.686770
# Unit test for method to_either of class Box
def test_Box_to_either(): # pragma: no cover
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:55:48.046576
# Unit test for method to_try of class Box
def test_Box_to_try():
    box = Box(1)
    try_value = box.to_try()
    assert try_value.value == 1


# Generated at 2022-06-23 23:55:58.993593
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.classes.maybe import Maybe
    from pymonet.classes.either import Left, Right
    from pymonet.classes.lazy import Lazy
    from pymonet.classes.try_class import Try
    from pymonet.classes.validation import Validation

    def dummy_func(val):
        return val

    assert Box(1).ap(Box(dummy_func)) == Box(dummy_func(1))

    assert Box(1).ap(Maybe.just(dummy_func)) == Maybe.just(dummy_func(1))

    assert Box(1).ap(Left(1)) == Left(1)
    assert Box(1).ap(Right(dummy_func)) == Right(dummy_func(1))


# Generated at 2022-06-23 23:56:00.964309
# Unit test for constructor of class Box
def test_Box():
    assert Box('a') == Box('a')



# Generated at 2022-06-23 23:56:06.271569
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.applicative import Applicative

    class TestBox(Applicative, Box):
        pass

    assert TestBox(lambda a, b: a).ap(TestBox(1)).ap(TestBox(2)).value == 1
    assert TestBox(lambda a: a + 10).ap(TestBox(11)).value == 21

# Generated at 2022-06-23 23:56:08.643318
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)

    assert Box(1) != Box(2)

    assert Box(1) != 2



# Generated at 2022-06-23 23:56:10.838231
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """

    assert Box(123).to_try() == Try.just(123)

# Generated at 2022-06-23 23:56:16.484511
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Success, Try

    assert Success(1).to_try() == Try(1, True)
    assert Success('abc').to_try() == Try('abc', True)
    assert Success(object()).to_try() == Try(object(), True)


# Generated at 2022-06-23 23:56:17.898945
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(123).to_validation() == Validation.success(123)

# Generated at 2022-06-23 23:56:20.958069
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(10)
    assert box.to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-23 23:56:23.143814
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('A').map(lambda x: x + 'B') == Box('AB')



# Generated at 2022-06-23 23:56:27.291017
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for function Box.to_maybe
    """
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.just(None)
    assert Box("aaa").to_maybe() == Maybe.just("aaa")



# Generated at 2022-06-23 23:56:28.418946
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:56:29.526176
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold() == 1

# Generated at 2022-06-23 23:56:31.944752
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.mixins import EqualityMixin

    assert isinstance(Box(1).to_maybe(), Maybe)
    assert isinstance(Box(1).to_maybe(), EqualityMixin)



# Generated at 2022-06-23 23:56:33.090813
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:56:35.417296
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)


# Generated at 2022-06-23 23:56:39.850206
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert 'Box[value=1]' == str(Box(1))
    assert 'Box[value="hello world"]' == str(Box('hello world'))


# Generated at 2022-06-23 23:56:41.942569
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:56:45.735135
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1


# Generated at 2022-06-23 23:56:48.433074
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != Box(2)
    assert Box("a") == Box("a")
    assert Box("a") != "a"
    assert Box("a") != Box(1)


# Generated at 2022-06-23 23:56:53.539957
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(5).to_either() == Right(5)


# Generated at 2022-06-23 23:56:55.043823
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2

# Generated at 2022-06-23 23:57:01.871627
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box.

    :returns: nothing
    :rtype: None
    """
    from pymonet.validation import Validation

    assert Validation.success(5) == Box(5).to_validation()


# Generated at 2022-06-23 23:57:12.932307
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('str')) == "Box[value='str']"
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box({None, '1', '2'})) == "Box[value={None, '1', '2'}]"
    assert str(Box(set())) == 'Box[value=set()]'
    assert str(Box((1, 2, None))) == 'Box[value=(1, 2, None)]'
    assert str(Box({1: 1, '2': '2'})) == "Box[value={1: 1, '2': '2'}]"

# Generated at 2022-06-23 23:57:14.554036
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert isinstance(Box(0).to_validation(), Validation)



# Generated at 2022-06-23 23:57:17.755727
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    double_map = Box(lambda x: x * 2)
    box = Box(3).map(double_map.value)
    assert box == Box(6)


# Generated at 2022-06-23 23:57:22.599141
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(10).to_maybe() == Box(10).to_maybe()
    assert Box(10).to_maybe().is_just()
    assert Box(10).to_maybe().value == 10


# Generated at 2022-06-23 23:57:24.811607
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:57:29.716678
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)
    assert Box(lambda x, y: x + y).ap(Box(1)).ap(Box(2)) == Box(3)
    assert Box(lambda x, y, z: x * y * z).ap(Box(1)).ap(Box(2)).ap(Box(3)) == Box(6)



# Generated at 2022-06-23 23:57:30.691071
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:57:31.954688
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(0)) == 'Box[value=0]'



# Generated at 2022-06-23 23:57:36.341275
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1).value == 1
    assert Box('a') != Box('b')



# Generated at 2022-06-23 23:57:37.739024
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:57:41.898319
# Unit test for method map of class Box
def test_Box_map():
    import pytest

    with pytest.raises(KeyError) as error:
        Box('a').map(lambda v: dict(v=1)[v])

    assert Box(1).map(lambda v: v + 1) == Box(2)


# Generated at 2022-06-23 23:57:43.250185
# Unit test for method to_either of class Box
def test_Box_to_either():
    box = Box(7)
    assert isinstance(box.to_either(), Right)
    assert box.to_either().is_right()

# Generated at 2022-06-23 23:57:46.097457
# Unit test for constructor of class Box
def test_Box():
    """
    Box should store any passed value in constructor
    """
    assert Box(1).value == 1
    assert Box('1').value == '1'
    assert Box({'foo': 'bar'}).value == {'foo': 'bar'}

# Generated at 2022-06-23 23:57:48.149336
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-23 23:57:52.152607
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-23 23:57:53.960982
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda element: element + 2) == Box(3)



# Generated at 2022-06-23 23:57:56.561269
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:58:05.998653
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either
    from pymonet.either import Left
    from pymonet.either import Right

    # Box with number
    box = Box(123)

    assert isinstance(box.to_either(), Either)
    assert isinstance(box.to_either(), Right)
    assert box.to_either() == Right(123)

    # Box with string
    box = Box('Hello, World!')

    assert isinstance(box.to_either(), Either)
    assert isinstance(box.to_either(), Right)
    assert box.to_either() == Right('Hello, World!')

    # Box with list
    box = Box([1, 2, 3])

    assert isinstance(box.to_either(), Either)
    assert isinstance(box.to_either(), Right)
    assert box.to

# Generated at 2022-06-23 23:58:09.289084
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box('Hello').to_either().either(lambda x: 'Error', lambda y: y) == 'Hello'



# Generated at 2022-06-23 23:58:17.377864
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.functors import identity

    assert Box(1).map(identity) == Box(1)
    assert Box(1).map(lambda x: x * 2) == Box(2)
    assert Box(identity).map(identity) == Box(identity)
    assert Box(1).map(lambda x: x + 1).map(lambda x: x * x) == Box(4)


# Generated at 2022-06-23 23:58:22.201815
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    value = Box(100)
    assert value.to_validation() == Validation.success(100)


# Generated at 2022-06-23 23:58:26.479215
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box: Box[int] = Box(1)
    assert box.to_either() == Right(1)


# Generated at 2022-06-23 23:58:28.797589
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(lambda: 'value')

    assert box.to_lazy().bind(lambda x: x()) == 'value'

# Generated at 2022-06-23 23:58:29.778924
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either, Right

    assert Either(Box(1)) == Right(1)

# Generated at 2022-06-23 23:58:31.528495
# Unit test for method to_either of class Box
def test_Box_to_either():
    function = Box(lambda x: x * 2)
    assert function.to_either() == Either.success(function.bind)

# Generated at 2022-06-23 23:58:38.117651
# Unit test for constructor of class Box
def test_Box():
    def test_box_constructor_string():
        # Arrange
        # Act
        result = Box('foo')
        # Assert
        assert result == Box('foo')

    def test_box_constructor_integer():
        # Arrange
        # Act
        result = Box(10)
        # Assert
        assert result == Box(10)


# Generated at 2022-06-23 23:58:40.310019
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x * 3) == 6


# Generated at 2022-06-23 23:58:42.633947
# Unit test for method ap of class Box
def test_Box_ap():
    def add(a, b):
        return a + b

    result = Box(add).ap(Box(3)).ap(Box(5)).bind(lambda x: Box(x * 2))

    assert result == Box(16)

# Generated at 2022-06-23 23:58:45.474753
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    >>> a = Box(7)
    >>> a.to_either()
    Right(7)
    """
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:58:48.225473
# Unit test for method to_either of class Box
def test_Box_to_either():

    assert Box(1).to_either() == Right(1)
    assert Box('test').to_either() == Right('test')
    assert Box(None).to_either() == Right(None)


# Generated at 2022-06-23 23:58:51.659198
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:58:53.542862
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:58:59.493604
# Unit test for method bind of class Box
def test_Box_bind():
    """Unit test for bind method of class Box.
    """
    from pymonet.functions import identity
    from pymonet.functions import compose

    # Simple test
    box = Box(10)
    assert box.bind(identity) == 10
    assert box.bind(lambda x: x) == 10

    # Test with function composition
    box = Box(10)
    assert box.bind(compose(identity, identity)) == 10
    assert box.bind(compose(lambda x: x, identity)) == 10

# Generated at 2022-06-23 23:59:01.197629
# Unit test for method map of class Box
def test_Box_map():
    box1 = Box(1)
    assert box1.map(lambda i: i + 2) == Box(3)



# Generated at 2022-06-23 23:59:08.046074
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('1') == Box('1')
    assert Box('1') != Box('2')
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:59:09.441975
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    value = 1
    assert Box(value).to_validation() == Validation.success(value)

# Generated at 2022-06-23 23:59:12.437313
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('test') == Box('test')
    assert Box(1) == Box(1)
    assert Box({'a': 1}) == Box({'a': 1})
    assert Box(1) != Box(2)
    assert Box('a') != Box('b')
    assert Box([1, 2]) != Box([1, 2, 3])


# Generated at 2022-06-23 23:59:14.311278
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box('test').to_either() == Right('test')



# Generated at 2022-06-23 23:59:17.285490
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)



# Generated at 2022-06-23 23:59:19.179844
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1), 'Should create box from value'



# Generated at 2022-06-23 23:59:20.899232
# Unit test for constructor of class Box
def test_Box():
    assert isinstance(Box(10), Box)


# Generated at 2022-06-23 23:59:33.286542
# Unit test for method ap of class Box
def test_Box_ap():
    """Tests for the method ap."""
    from pymonet.applicative import Applicative
    from pymonet.monad_try import Try

    def multiply(x: int) -> int:
        return x * 2

    assert Try(2).to_box().ap(Box(multiply)) == Box(4)
    assert Box(2).ap(Box(multiply)) == Box(4)

    assert Box(-2).ap(Box(lambda x: x + 1)) == Box(-1)
    assert Box(-2).ap(Box(lambda x: x + 1)).ap(Box(lambda x: x + 2)) == Box(1)
    assert Box(-2).ap(Box(lambda x: x + 1)).ap(Box(lambda x: x + 2)) == Box(1)

# Generated at 2022-06-23 23:59:35.934080
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    box: Box[int] = Box(100)

    assert box.to_try() == Try(100, True)

# Generated at 2022-06-23 23:59:42.487674
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(lambda x: x + 2).bind(lambda f: Box(lambda x: f(x) + 2)).bind(lambda f: Box(f(3))).value == 7

    box1 = Box(1)
    assert isinstance(box1.bind(lambda x: x + 2), Box)
    assert box1.bind(lambda x: x + 2).value == 3
    assert isinstance(box1.bind(lambda x: Box(x + 2)), Box)
    assert box1.bind(lambda x: Box(x + 2)).value == 3
    assert isinstance(box1.bind(lambda x: Box(Box(x + 2))), Box)
    assert box1.bind(lambda x: Box(Box(x + 2))).value == 3

# Generated at 2022-06-23 23:59:43.331904
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:59:49.267768
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():   # pragma: no cover
    from pymonet.lazy import Lazy

    b = Box(5)
    l = b.to_lazy()
    r = l.map(lambda x: x * 2).value()
    assert r == 10



# Generated at 2022-06-23 23:59:54.112058
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    actual: Maybe[int] = Box(Nothing()).to_maybe()
    expected: Maybe[int] = Maybe.nothing()

    assert actual == expected

    actual: Maybe[int] = Box(Maybe.just(1)).to_maybe()
    expected: Maybe[int] = Maybe.just(1)

    assert actual == expected


# Generated at 2022-06-23 23:59:56.892484
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)



# Generated at 2022-06-23 23:59:58.964507
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-24 00:00:04.126999
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box
    """
    assert Box(0).to_either().is_right()


# Generated at 2022-06-24 00:00:04.961210
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:00:10.761439
# Unit test for method ap of class Box
def test_Box_ap():
    # Given

    func = lambda x: x * 2
    instance = Box(func)
    box = Box(2)

    # When
    result = instance.ap(box)

    # Then
    assert result == Box(4)


test_Box_ap()

# Generated at 2022-06-24 00:00:12.800935
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box('test string')) == 'Box[value=test string]'


# Generated at 2022-06-24 00:00:14.668837
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('string') == Box('string')

# Generated at 2022-06-24 00:00:18.466099
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test for transformation of Box into either
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-24 00:00:20.232260
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(10).map(lambda x: x + 5) == Box(15)



# Generated at 2022-06-24 00:00:29.772316
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x * 2) == Box(6)
    assert Box(3).map(lambda x: Box(x * 2)) == Box(Box(6))
    assert Box(Box(3)).map(lambda x: x * 2) == Box(6)
    assert Box(Box(Box(3))).map(lambda x: x * 2) == Box(6)
    assert Box(3).map(lambda x: [x * 2]) == Box([6])
    assert Box('3').map(lambda x: [1, 2, x]) == Box([1, 2, '3'])
    assert Box([]).map(lambda x: x + [1, 2]) == Box([1, 2])


# Generated at 2022-06-24 00:00:32.294996
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Try(True, is_success=True) == Box(True).to_try()


# Generated at 2022-06-24 00:00:33.938005
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-24 00:00:38.554317
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    test_box = Box('test')
    result = test_box.to_either()
    assert isinstance(result, Right)
    assert result == Right('test')


# Generated at 2022-06-24 00:00:39.818417
# Unit test for constructor of class Box
def test_Box():
    b = Box(1)

    assert isinstance(b, Box)
    assert b.value == 1


# Generated at 2022-06-24 00:00:41.247687
# Unit test for constructor of class Box
def test_Box():
    # then
    assert Box(5).value == 5



# Generated at 2022-06-24 00:00:44.175536
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.maybe import Maybe

    squared_value = Maybe(5).map(lambda x: x ** 2)

    assert squared_value == Box(25)



# Generated at 2022-06-24 00:00:51.007283
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    # create boxes with different values
    box_one = Box(1)
    box_two = Box('2')

    # transform boxes into validations
    box_one_validation = box_one.to_validation()
    box_two_validation = box_two.to_validation()

    # assert that validations are equal to expected ones
    assert box_one_validation == Validation.success(1)
    assert box_two_validation == Validation.success('2')



# Generated at 2022-06-24 00:00:53.208871
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)

    assert Box(None).to_maybe() == Maybe.just(None)

# Generated at 2022-06-24 00:01:03.352359
# Unit test for method ap of class Box
def test_Box_ap():
    """Unit test for method ap of class Box"""

    from pymonet.func import add

    assert Box(5).ap(Box(add)) == Box(10)
    assert Box(5).ap(Box(add)).value == 10
    assert Box(5).ap(Box(lambda x: add(x, 10))).value == 15
    assert Box(5).to_lazy().ap(Box(add)).value() == Box(10).value
    Box(5).to_lazy().ap(Box(lambda x: add(x, 10))).value() == 15
    assert Box(5).to_try().ap(Box(add)).value == Box(10).value
    assert Box(5).to_try().ap(Box(add)).isSuccess

# Generated at 2022-06-24 00:01:06.508089
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != Box(5)
    assert Box(3) != tuple([3])



# Generated at 2022-06-24 00:01:11.177150
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)

    assert Box(1) == Box(1)

    assert Box([1, 2, 3]) == Box([1, 2, 3])

    assert Box(1) == Box(2) is False

    assert Box([1, 2, 3]) == Box([1, 2]) is False


# Generated at 2022-06-24 00:01:15.884985
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('a')) == 'Box[value=a]'


# Generated at 2022-06-24 00:01:18.457145
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    from pymonet.validation import Validation
    box = Box('value')
    validation = box.to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success()


# Generated at 2022-06-24 00:01:20.846792
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box
    """
    def add_one(arg: int):
        return arg + 1
    assert Box(1).map(add_one).value == 2



# Generated at 2022-06-24 00:01:22.336858
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x+1).ap(Box(1)) == Box(2)


# Generated at 2022-06-24 00:01:24.927941
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    value = 'Box'
    box = Box(value)
    validation = box.to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.value == value

# Generated at 2022-06-24 00:01:26.545291
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(5).to_maybe().value == Box(5).value


# Generated at 2022-06-24 00:01:32.595210
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    value = 1
    box = Box(value)
    assert box.to_try() == Try(value, is_success=True)

    try:
        box.to_try().bind(lambda x: 1 / 0)
        assert False
    except ZeroDivisionError:
        pass


# Generated at 2022-06-24 00:01:34.329052
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(5)) == Box(6)

# Generated at 2022-06-24 00:01:38.343127
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Case: default
    """
    def add(x: int) -> int:
        return x + 2

    arg_1 = Box(add)

    arg_2 = Box(2)
    assert arg_1.ap(arg_2) == Box(add(arg_2.value))

# Generated at 2022-06-24 00:01:41.114312
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test for method to_maybe in Box
    """
    from pymonet.maybe import Maybe

    data = Box('data')
    assert data.to_maybe() == Maybe.just(data.value)


# Generated at 2022-06-24 00:01:43.959236
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(10)

    validation = box.to_validation()

    assert isinstance(validation, Validation) \
        and validation.is_success



# Generated at 2022-06-24 00:01:44.725880
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) is not None



# Generated at 2022-06-24 00:01:46.616991
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(13) == Box(13)


# Generated at 2022-06-24 00:01:51.166479
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)

    assert box1 == box2
    assert box1 != box3
    assert box2 != box3

    # Check for None conditions
    assert not box1 == None # noqa: E711



# Generated at 2022-06-24 00:01:53.028135
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.either import Left

    assert Box(1).to_maybe() == Left(1)


# Generated at 2022-06-24 00:01:57.455399
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    assert Box(1).to_either() == Box(1).to_either().success
    assert Box(2).to_either().is_right
    assert Box(1).to_either() != Box(2).to_either()



# Generated at 2022-06-24 00:02:00.549924
# Unit test for method __str__ of class Box
def test_Box___str__():
    from nose.tools import assert_equal
    from pymonet.monad_test import identity_test

    assert_equal(identity_test(Box('test')), 'Box[value=test]')


# Generated at 2022-06-24 00:02:08.974060
# Unit test for method __str__ of class Box
def test_Box___str__():  # pylint: disable=too-many-locals
    """
    Unit test for method __str__ of class Box.
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.validation import Validation


# Generated at 2022-06-24 00:02:11.674521
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)



# Generated at 2022-06-24 00:02:20.068048
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # Check passing applicative with function to apply function on the Box value
    assert(Box(2).ap(Box(lambda x: x * 2)) == Box(4))

    # Check passing applicative with function to apply function on the Lazy value
    assert(Box(2).ap(Lazy(lambda: lambda x: x * 2)) == Box(4))

    # Check passing applicative with function to apply function on the Box value using bind
    assert(Box(2).bind(lambda x: Box(x * 4)) == Box(8))


# Generated at 2022-06-24 00:02:25.612193
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(1) != Box(2)
    assert Box(1) != Box("2")
    assert Box(1) != 1
    assert Box("1") == Box("1")
    assert Box(1) == Box(1)
    assert Box("1") != None
    assert Box(None) == Box(None)
    assert Box(1.1) == Box(1.1)
    assert Box(1.1) != Box(1.0)



# Generated at 2022-06-24 00:02:27.858133
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pymonet.lazy

    box = Box('abc')
    lazy = box.to_lazy()

    assert isinstance(lazy, pymonet.lazy.Lazy)
    assert lazy.evaluate() == box.value

# Generated at 2022-06-24 00:02:31.702062
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try_ = Box(1).to_try()
    assert isinstance(try_, Try)
    assert try_.is_success is True
    assert try_.value == 1

# Generated at 2022-06-24 00:02:34.500061
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)


# Generated at 2022-06-24 00:02:37.382996
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box
    """
    from pymonet.functor import Functor

    assert isinstance(Box(10).bind(Functor.identity), type(10))
    assert Box(10).bind(Functor.identity) == 10
    assert Box(10).bind(lambda x: x * 2) == 20
    assert Box(10).bind(lambda x: x * x) == 100

# Generated at 2022-06-24 00:02:42.405945
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(5) == Box(5)
    assert Box(5) != Box(4)
    assert Box('string') != Box(4)



# Generated at 2022-06-24 00:02:48.871380
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test for `to_either` method of class Box.
    """

    from pymonet.either import Left

    initial_value = 42
    maybe_monad = Box(initial_value)
    assert maybe_monad.to_either() is not Left(initial_value)

# Generated at 2022-06-24 00:02:53.809578
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('test').map(lambda x: x + x) == Box('testtest')
    assert Box({1, 2, 3}).map(lambda x: x | {4, 5}) == Box({1, 2, 3, 4, 5})



# Generated at 2022-06-24 00:02:59.233075
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    def test_case_1():
        validator = Box(5) == Box(5)
        assert validator

    def test_case_2():
        validator = Box(5) == Box(7)
        assert not validator

    test_case_1()
    test_case_2()


# Generated at 2022-06-24 00:03:09.187250
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    # Tests with string
    value = 'TestValue'
    expected_result = 'Box[value={}]'.format(value)
    assert str(Box(value)) == expected_result
    # Tests with integer
    value = 10
    expected_result = 'Box[value={}]'.format(value)
    assert str(Box(value)) == expected_result
    # Tests with float
    value = 10.0
    expected_result = 'Box[value={}]'.format(value)
    assert str(Box(value)) == expected_result
    # Tests with boolean
    value = True
    expected_result = 'Box[value={}]'.format(value)
    assert str(Box(value)) == expected_result



# Generated at 2022-06-24 00:03:12.949748
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import FailTry

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(FailTry(Exception("Test"), is_success=False)).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:03:14.088468
# Unit test for constructor of class Box
def test_Box():
    value = 'value'
    box = Box(value)

    assert box.value == value

# Generated at 2022-06-24 00:03:15.276242
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:03:16.392465
# Unit test for constructor of class Box
def test_Box():
    assert isinstance(Box(1), Box)



# Generated at 2022-06-24 00:03:17.859541
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    double = lambda x: x * 2
    assert Box(5).bind(double) == 10

# Generated at 2022-06-24 00:03:20.186059
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(10)
    assert box.to_validation() == Validation.success(10)



# Generated at 2022-06-24 00:03:21.502423
# Unit test for constructor of class Box
def test_Box():
    box = Box('value')

    assert box.value == 'value'



# Generated at 2022-06-24 00:03:24.171951
# Unit test for constructor of class Box
def test_Box():
    assert Box(3) == Box(3)


# Generated at 2022-06-24 00:03:27.940503
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1).value == 1
    assert not isinstance(Box(1), Box[str])
    assert isinstance(Box(1), Box[int])

# Generated at 2022-06-24 00:03:29.442285
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(3).ap(Box(lambda x: x + 3)) == Box(6)


# Generated at 2022-06-24 00:03:35.434283
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def value_producer():
        print('hello')
        return 1

    value = Box(value_producer)
    lazy_value = value.to_lazy()
    assert isinstance(lazy_value, Lazy)
    assert lazy_value == Lazy(value_producer)

# Generated at 2022-06-24 00:03:37.859563
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != object()


# Generated at 2022-06-24 00:03:39.089045
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import is_right
    from pymonet.either import is_left

    assert is_right(Box(1).to_either())
    assert is_left(Box(1).to_either().left())



# Generated at 2022-06-24 00:03:40.298463
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x * x) == 25



# Generated at 2022-06-24 00:03:42.505366
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box('test').to_try() == Try('test', is_success=True)

# Generated at 2022-06-24 00:03:44.762035
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test for method to_try of class Box.
    """
    assert Box('value').to_try().to_result() == 'value'

