

# Generated at 2022-06-23 23:53:51.195264
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    from pymonet.applicative import Applicative

    # Given
    box = Box(2)
    # When
    mapped = box.map(lambda x: x + 2)
    # Then
    assert isinstance(mapped, Applicative)
    assert mapped == Box(4)



# Generated at 2022-06-23 23:53:55.730446
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(123)) == 'Box[value=123]'


# Generated at 2022-06-23 23:53:57.692585
# Unit test for method map of class Box
def test_Box_map():
    """
    Test Box.map(mapper) method.
    """
    assert Box(3).map(lambda v: '{} world'.format(v)) == Box('3 world')

# Generated at 2022-06-23 23:53:59.737372
# Unit test for method map of class Box
def test_Box_map():
    """
    Just basic test for map method
    """
    assert Box(3).map(lambda x: x + 1) == Box(4)

# Generated at 2022-06-23 23:54:00.910229
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-23 23:54:02.990225
# Unit test for method to_either of class Box
def test_Box_to_either():
    import operator

    assert Box(2).to_either() == Box(2).to_either().bind(operator.add, 5)



# Generated at 2022-06-23 23:54:08.288780
# Unit test for method bind of class Box
def test_Box_bind():
    b1 = Box(1)
    b2 = b1.bind(lambda x: Box(x + 1))
    assert b1.value == 1 and b2.value == 2, 'The value of the box after the bind should be equal to the value of the previous box plus one'

# Generated at 2022-06-23 23:54:16.915530
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.monad_try import SuccessException

    assert Box("pymonet").to_try() == Try("pymonet", is_success=True)
    assert Box("pymonet").to_try() != Try("pymonet", is_success=False)
    try:
        assert Box("pymonet").to_try() == SuccessException("pymonet")
    except SuccessException as e:
        assert e.value == "pymonet"
    else:
        assert False, 'Should have raised SuccessException'


# Generated at 2022-06-23 23:54:26.337224
# Unit test for constructor of class Box
def test_Box():
    from pymonet.either import Left

    assert Box(1) == Box(1)

    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1).ap(Box(lambda x: x + 1)) == Box(2)

    assert Box(1).to_maybe() == Box(1).to_lazy().to_maybe()
    assert Box(1).to_either() == Box(1).to_lazy().to_either()
    assert Box(1).to_try() == Box(1).to_lazy().to_try()
    assert Box(1).to_validation() == Box(1).to_lazy().to_validation()

# Generated at 2022-06-23 23:54:33.854788
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(Failure(1)).to_try() == Try(Failure(1), is_success=True)

# Generated at 2022-06-23 23:54:39.038827
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def identity(x):
        return x

    assert Lazy(lambda: identity(1)) == Box(identity).to_lazy().value()
    assert Lazy(lambda: identity(1)) == Box(lambda : identity(1)).to_lazy().value()

# Generated at 2022-06-23 23:54:40.346502
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:54:41.747044
# Unit test for method map of class Box
def test_Box_map():
    assert Box(5).map(lambda x: x + 3) == Box(8)


# Generated at 2022-06-23 23:54:45.833050
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(lambda value: value * 2)
    assert box.bind(lambda a: a * 2) == 8


# Generated at 2022-06-23 23:54:49.968922
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box.
    """
    # Assert statements
    assert Box(5).to_either() == Box(5).to_either()
    assert Box(5) != Box(4)
    assert Box(5) == Box(5)
    assert Box(5).to_either().left_value() is None
    assert Box(5).to_either().right_value() == 5

# Generated at 2022-06-23 23:54:54.860712
# Unit test for constructor of class Box
def test_Box():
    assert Box(42) == Box(42)
    assert Box('Foo') == Box('Foo')
    assert Box('Foo') != Box('Foo1')



# Generated at 2022-06-23 23:54:56.581665
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:54:59.138713
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test for method to_try
    """
    from pymonet.monad_try import Try

    box = Box(1)
    assert box.to_try() == Try(box.value, is_success=True)

# Generated at 2022-06-23 23:55:00.408005
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    lazy = Box(1).to_lazy()

    assert lazy.is_folded() is False
    assert lazy.value() == 1


# Generated at 2022-06-23 23:55:01.194586
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x + 5) == 10


# Generated at 2022-06-23 23:55:02.731577
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try_monad = Box('a').to_try()

    assert try_monad == Try('a', is_success=True)


# Generated at 2022-06-23 23:55:04.905651
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    box = Box('Hello, Monad')
    assert str(box) == 'Box[value=Hello, Monad]'


# Generated at 2022-06-23 23:55:08.085925
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == lazy(lambda: 1)



# Generated at 2022-06-23 23:55:17.345817
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe().is_just()
    assert Box(1).to_maybe().bind(lambda x: Maybe.just(x + 2)).is_just()
    assert Box(1).to_maybe().to_either().is_right()
    assert Box(1).to_maybe().to_either().right().value == 1
    assert Box(1).to_maybe().to_lazy().value() == 1
    assert Box(1).to_maybe().to_try().is_success()
    assert Box(1).to_maybe().to_try().get() == 1
    assert Box(1).to_maybe().to_validation().is_success()
    assert Box(1).to_maybe().to_validation().right().value == 1

# Generated at 2022-06-23 23:55:18.925142
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-23 23:55:20.244805
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x + 1) == 6


# Generated at 2022-06-23 23:55:26.473906
# Unit test for method to_either of class Box
def test_Box_to_either():
    value = 'Foo'
    assert Box(value).to_either().is_right()
    assert not Box(value).to_either().is_left()
    assert Box(value).to_either().get_value() == value


# Generated at 2022-06-23 23:55:32.503206
# Unit test for method bind of class Box
def test_Box_bind():
    def half(value: int) -> int:
        return int(value / 2)

    assert Box(10).bind(half) == half(10)

Box.__name__ = 'Box'

# Generated at 2022-06-23 23:55:34.919852
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Right(3) == Box(3).to_either()


# Generated at 2022-06-23 23:55:37.355578
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    value = 12
    box = Box(12)

    assert isinstance(box, Box)
    assert box.value == value


# Generated at 2022-06-23 23:55:39.330082
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-23 23:55:40.545682
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(None) == Box(None)


# Generated at 2022-06-23 23:55:43.673939
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-23 23:55:46.015451
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box('value').to_lazy() == Lazy(lambda: 'value')

# Generated at 2022-06-23 23:55:48.674074
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test for method to_try of class Box
    """
    assert Box(123).to_try() == Try(123, is_success=True)



# Generated at 2022-06-23 23:55:51.976537
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box = Box(None)
    assert(isinstance(box, Box))
    assert(box.value is None)



# Generated at 2022-06-23 23:55:53.710563
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(2).to_either() == Right(2)

# Generated at 2022-06-23 23:55:58.806210
# Unit test for method map of class Box
def test_Box_map():
    # Test example:

    # Our mapper function:
    def mapper_function(value):
        if value == 1:
            return 'One'
        else:
            return 'Not one'

    # Mapped Box
    box_mapped = Box(1).map(mapper_function)
    assert box_mapped == Box('One')


# Generated at 2022-06-23 23:56:00.543355
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert isinstance(Box(3).__str__(), str)

# Generated at 2022-06-23 23:56:03.343165
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(2).to_either() == Right(2)



# Generated at 2022-06-23 23:56:05.942799
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    assert Box(1).to_try() == Try(1)

# Generated at 2022-06-23 23:56:07.877058
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:56:10.150843
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Maybe.just(1) == Box(1).to_maybe()



# Generated at 2022-06-23 23:56:11.080617
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:56:12.752161
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert str(Box(1)) == 'Box[value=1]'


# Unit tests for map method

# Generated at 2022-06-23 23:56:20.604776
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation, ValidationError

    test_value = 5
    box = Box(test_value)
    validation = box.to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.get_value() == test_value
    assert validation.is_failure == False
    assert validation.get_errors() == []
    validation = validation.map(lambda v: v + 1)
    assert validation.get_value() == test_value + 1
    validation = validation.map_errors(lambda e: e + [ValidationError('failure')])
    assert validation.get_errors() == [ValidationError('failure')]
    assert validation.is_success

# Generated at 2022-06-23 23:56:30.929409
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Creating Box(1), Box(2), Box(1), None
    box_a = Box(1)
    box_b = Box(2)
    box_c = Box(1)
    none = None

    # Asserting (Box(1) == Box(1)) == True
    assert (box_a == box_c) == True
    # Asserting (Box(1) == Box(2)) == False
    assert (box_a == box_b) == False
    # Asserting (Box(2) == Box(1)) == False
    assert (box_b == box_c) == False
    # Asserting (Box(1) == Box(2)) == False
    assert (box_b == box_c) == False
    # Asserting (Box(2) == Box(1)) == False
   

# Generated at 2022-06-23 23:56:32.973169
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('value') == Box('value')
    assert Box('value') != Box('other_value')
    assert Box('value') != 'Box[value=value]'



# Generated at 2022-06-23 23:56:36.009145
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(10)
    eith = box.to_either()
    assert isinstance(eith, Right)
    assert eith.value == box.value


# Generated at 2022-06-23 23:56:39.175102
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-23 23:56:41.982994
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(42).to_try() == Try(42, is_success=True)


# Generated at 2022-06-23 23:56:47.577687
# Unit test for method to_try of class Box
def test_Box_to_try():
    # GIVEN
    box_value = 10

    # WHEN
    result = Box(box_value).to_try()

    # THEN
    assert result.value == box_value
    assert result.is_success == True



# Generated at 2022-06-23 23:56:52.328788
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box('foo').to_maybe() == Maybe.just('foo')
    assert Box(None).to_maybe() == Maybe.just(None)
    assert Box([]).to_maybe() == Maybe.just([])
    assert Box({}).to_maybe() == Maybe.just({})
    assert Box((1, 2)).to_maybe() == Maybe.just((1, 2))



# Generated at 2022-06-23 23:56:53.924880
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert 'Box[value=123]' == str(Box(123))

# Generated at 2022-06-23 23:56:56.561521
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    box: Box[int] = Box(10)

    assert box.to_validation() == Validation.success(box.value)

# Generated at 2022-06-23 23:57:00.813787
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1
    assert Box("a").value == "a"
    assert Box(None).value is None


# Generated at 2022-06-23 23:57:06.350239
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(None) == Box(None)
    assert Box(1) == Box(1)
    assert Box('test') == Box('test')
    assert Box([1, 2]) == Box([1, 2])
    assert Box({'foo': 1}) == Box({'foo': 1})
    assert not Box(None) == Box(1)
    assert not Box(1) == Box(None)
    assert not Box('test') == Box(1)



# Generated at 2022-06-23 23:57:07.010871
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:57:12.059885
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1
    assert Box('string').value == 'string'
    assert Box(1.1).value == 1.1
    box = Box('value')
    assert box.value == 'value'

# Generated at 2022-06-23 23:57:14.032339
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    assert isinstance(Box(1).to_either(), Either)


# Generated at 2022-06-23 23:57:16.038957
# Unit test for method ap of class Box
def test_Box_ap():
    f = Box(lambda x: x + 1)
    assert f.ap(Box(1)) == Box(2)

# Generated at 2022-06-23 23:57:18.989871
# Unit test for method __str__ of class Box
def test_Box___str__():
    box_one = Box(1)
    box_two = Box(2)

    assert box_one.__str__() == 'Box[value=1]'
    assert box_two.__str__() == 'Box[value=2]'


# Generated at 2022-06-23 23:57:26.674060
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box("1").map(lambda x: str(int(x) + 1)) == Box("2")
    assert Box([1, 2]).map(lambda x: x + [3]) == Box([1, 2, 3])
    assert Box({1, 2}).map(lambda x: x | {3}) == Box({1, 2, 3})
    assert Box({1: 2, 3: 4}).map(lambda x: {**x, 5: 6}) == Box({1: 2, 3: 4, 5: 6})



# Generated at 2022-06-23 23:57:28.757062
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:57:30.830186
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box("str") == Box("str")
    assert Box("str") != Box("string")
    assert Box("str") != Box(42)



# Generated at 2022-06-23 23:57:32.808626
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.either import Right

    assert Box(2).ap(Right(lambda x: x * 3)) == Box(6)
    assert Box(2).ap(Box(lambda x: x * 3)) == Box(6)



# Generated at 2022-06-23 23:57:36.841403
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try

    lazy = Box(Try(4)).to_lazy()

    assert lazy.get() == 4



# Generated at 2022-06-23 23:57:41.858596
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe

    assert Box(lambda x: x + 1).ap(Box(3)) == Box(4)
    assert Box(lambda x: x + 1).ap(Maybe.just(3)) == Box(4)
    assert Box(lambda x: x + 1).ap(Maybe.nothing()) == Box(None)



# Generated at 2022-06-23 23:57:42.737016
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(6).bind(lambda x: x * x) == 36

# Generated at 2022-06-23 23:57:44.052791
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, is_success

    assert is_success(Box(42).to_try())


# Generated at 2022-06-23 23:57:46.531268
# Unit test for method map of class Box
def test_Box_map():
    """
    Test for method map of class Box
    """
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(1).map(lambda x: x * 2) == Box(2)
    assert Box(1).map(lambda x: pow(x, 2)) == Box(1)



# Generated at 2022-06-23 23:57:49.425946
# Unit test for constructor of class Box
def test_Box():
    box_int = Box(1)
    assert box_int.value == 1

    box_str = Box('test')
    assert box_str.value == 'test'

    box_list = Box([1, 2, 3])
    assert box_list.value == [1, 2, 3]



# Generated at 2022-06-23 23:57:55.859785
# Unit test for method to_try of class Box
def test_Box_to_try():
    import pytest

    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

    # Check that method to_try returns correct successor of class Try
    assert isinstance(Box(1).to_try(), Try)  # pragma: no cover

    with pytest.raises(Exception):
        Box(1).to_try().value

    assert Box(1).to_try().is_success


# Generated at 2022-06-23 23:57:58.510481
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    import pytest

    from pymonet.validation import Validation

    box = Box('abc')

    assert isinstance(box.to_validation(), Validation)
    assert box.value == box.to_validation().value
    assert box.to_validation().failures == []


# Generated at 2022-06-23 23:58:02.780976
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box(1) != Box('a')
    assert Try(1) != Box(1)
    assert Box(Try(1)) != Try(1)



# Generated at 2022-06-23 23:58:04.590739
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(2)
    assert box1 == box2 is False


# Generated at 2022-06-23 23:58:05.418565
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:58:09.533197
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('Hello').map(lambda x: x * 2) == Box('HelloHello')



# Generated at 2022-06-23 23:58:16.311294
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.monad_try import Failure
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)
    assert Box(Failure(1)).to_validation() == Validation.failure(Failure(1).value)

# Generated at 2022-06-23 23:58:22.629905
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    from pymonet.maybe import Maybe
    from .monoid import List

    assert Box(5).to_maybe() == Maybe.just(5)
    assert Box(5).to_maybe().bind(lambda x: Maybe.just(x + 5)) == Maybe.just(10)
    assert Box(5).to_maybe().plus(Maybe.just(10)) == Maybe.just(15)
    assert Box(5).to_maybe().plus(None) == Maybe.just(5)
    assert Box(5).to_maybe().plus(List.empty()) == Maybe.just(5)
    assert Box(5).to_maybe().plus(List.of(10)) == Maybe.just(15)

# Generated at 2022-06-23 23:58:25.428349
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:58:29.417777
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(1).map(lambda x: x * 2) == Box(2)
    assert Box(1).map(lambda x: x ** 2) == Box(1)


# Generated at 2022-06-23 23:58:32.881449
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert Box(1).__str__() == 'Box[value=1]'
    assert Box('test').__str__() == 'Box[value=test]'
    assert Box(True).__str__() == 'Box[value=True]'


# Generated at 2022-06-23 23:58:37.763748
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.monad_try import Try
    
    assert Box(10).bind(lambda v: Try(v * 5)) == Try(50)
    assert Box(0).bind(lambda v: Try(v * 5)) == Try(0)


# Generated at 2022-06-23 23:58:40.887571
# Unit test for method bind of class Box
def test_Box_bind():
    value = 10
    box = Box(value)

    def mapper(x):
        return x + 1

    assert box.bind(mapper) == value + 1



# Generated at 2022-06-23 23:58:43.202907
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1) and not (Box(1) == Box(2)) and not (Box(1) == '1')


# Generated at 2022-06-23 23:58:45.872785
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    @given(integers())
    def test(integer):
        integer_box = Box(integer)

        assert integer_box == Box(integer)

    test()



# Generated at 2022-06-23 23:58:49.113248
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    val = 'test_value'
    box = Box(val)
    try_ = box.to_try()
    assert isinstance(try_, Try)
    assert try_.is_success
    assert try_.value == val


# Generated at 2022-06-23 23:58:52.179289
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test Box to_maybe method.
    """
    from pymonet.maybe import Maybe

    Box('some').to_maybe() == Maybe.just('some')



# Generated at 2022-06-23 23:58:55.311132
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(True) == Box(True)
    assert Box('string') == Box('string')
    assert Box('string') != Box('not equal string')
    assert Box(1) != 2



# Generated at 2022-06-23 23:58:56.838606
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    expected_result = Validation(True, [])
    result = Box(True).to_validation()
    assert result == expected_result


# Generated at 2022-06-23 23:59:03.327909
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda x: x + 10) == 20
    assert Box(10).bind(lambda x: x + 10).bind(lambda x: x + 10) == 30
    assert Box(10).bind(lambda x: x / 2).bind(lambda x: x + 10) == 15
    assert Box(10).bind(lambda x: x ** 2).bind(lambda x: x / 2) == 50
    assert Box(10).bind(lambda x: x + 10) == Box(10).bind(lambda x: x + 10)
    assert Box(10).bind(lambda x: x + 10).bind(lambda x: x + 10) == Box(10).bind(lambda x: x + 10).bind(lambda x: x + 10)

# Generated at 2022-06-23 23:59:07.566748
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    box = Box(1)
    assert str(box) == 'Box[value=1]'



# Generated at 2022-06-23 23:59:10.405213
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(1)
    b = Box(1)
    c = Box(2)
    assert a == b, "Box a and b must be equals"
    assert a != c, "Box a and c must be not equals"



# Generated at 2022-06-23 23:59:18.222915
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure

    assert Box(6).to_try() == Success(6)
    assert Try.unit(6) == Success(6)
    assert Try(6, is_success=True) == Success(6)
    assert Try(6, is_success=False) == Failure(6)

# Generated at 2022-06-23 23:59:19.865256
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(2).to_validation() == Validation.success(2)

# Generated at 2022-06-23 23:59:21.438702
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(10).to_validation() == Validation.success(10)

# Generated at 2022-06-23 23:59:28.148906
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    import unittest

    class BoxToTryTest(unittest.TestCase):
        def test_Box_to_try(self):
            try:
                success_result = Box(5).to_try()
                self.assertEqual(success_result.value, 5)
            except Exception:
                self.fail("Unexpected exception")

    unittest.main()

# Generated at 2022-06-23 23:59:32.413161
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Success

    monad = Box(5)
    result = monad.to_validation()
    assert isinstance(result, Success)
    assert result.value == 5
# End of unit test


# Generated at 2022-06-23 23:59:36.391670
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(1).ap(Box(lambda x: x * 2)) == Box(2)
    assert Box(lambda x: x * 2).ap(Box(1)) == Box(2)
    assert Box(1).ap(Box(lambda x: x)) == Box(1)
    assert Box(lambda x: x).ap(Box(1)) == Box(1)

# Generated at 2022-06-23 23:59:38.778930
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    success_validation = Validation(['error is not empty'], is_success=False)
    box = Box(success_validation)
    assert box.to_validation() == success_validation

# Generated at 2022-06-23 23:59:46.176248
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right, is_right
    from pymonet.box import Box

    assert is_right(Box(10).to_either()) and Right(10) == Box(10).to_either()
    assert is_right(Box(20).to_either()) and Right(20) == Box(20).to_either()



# Generated at 2022-06-23 23:59:50.334591
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    data = 1
    box = Box(data)
    validation = box.to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.value == data



# Generated at 2022-06-23 23:59:51.144172
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box('test').to_validation() == 'test'

# Generated at 2022-06-23 23:59:54.667916
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box

    :returns: None
    :rtype: None
    """
    from pymonet.monad_try import Try
    from pymonet import Monad

    box_monad_try_equal(Try.just(1), Box(1).to_try())



# Generated at 2022-06-23 23:59:57.251977
# Unit test for method ap of class Box
def test_Box_ap():
    box = Box(lambda x: x * x)
    assert box.ap(Box(10)) == Box(100)



# Generated at 2022-06-23 23:59:59.764566
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    from pymonet.validation import Validation
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:00:01.361016
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    result = Box(5).to_lazy().fold()
    assert result == 5

# Generated at 2022-06-24 00:00:03.584072
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Test for method to_validation of class Box.
    """
    # case 1: returns successfull Validation monad
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:00:07.134165
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test that method `to_try` transform Box into successfull Try
    """
    from pymonet.monad_try import Success

    try_: Success[int] = Box(5).to_try()

    assert try_.get() == 5
    assert try_.is_success() is True
    assert try_.is_failure() is False

# Generated at 2022-06-24 00:00:10.901558
# Unit test for method ap of class Box
def test_Box_ap():
    def sum_function(first_int, second_int):
        return first_int + second_int

    # Because sum_function is a curried functions -
    # we need to create new curried functions before we can use ap method
    curried_function_box = curried_function_box = Box(lambda first_int: lambda second_int: sum_function(first_int,
                                                                                                         second_int))
    curried_function_box.ap(Box(2)) == Box(sum_function(2))

# Generated at 2022-06-24 00:00:12.284700
# Unit test for method to_either of class Box
def test_Box_to_either():
    # Assert
    assert isinstance(Box(1).to_either(), Either)



# Generated at 2022-06-24 00:00:15.197530
# Unit test for constructor of class Box
def test_Box():
    """
    Unit test for Box constructor.
    """
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert str(Box(2)) == 'Box[value=2]'

# Generated at 2022-06-24 00:00:18.572566
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def test():
        return 876

    assert Lazy(test) == Box(876).to_lazy()

# Generated at 2022-06-24 00:00:19.638449
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(12).to_maybe() == Some(12)

# Generated at 2022-06-24 00:00:23.346208
# Unit test for constructor of class Box
def test_Box():
    assert Box(10).value == 10
    assert Box('A value').value == 'A value'
    assert Box((1, 2, 3)).value == (1, 2, 3)
    assert Box({'a': 10, 'b': 20}).value == {'a': 10, 'b': 20}
    assert Box(True).value is True


# Generated at 2022-06-24 00:00:26.442680
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test that to_try function transforms Box into successfull Try.

    :returns: assertion results
    :rtype: Bool
    """
    from pymonet.monad_try import Try

    return Try(1, is_success=True) == Box(1).to_try()

# Generated at 2022-06-24 00:00:31.692856
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:00:33.221121
# Unit test for method bind of class Box
def test_Box_bind():
    result = Box(12).bind(lambda x: x + 2)
    assert result == 14



# Generated at 2022-06-24 00:00:35.975168
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test Box.to_try() method.

    Test if Box.to_try() successfully transforms Box into Try.
    """

    value = 42

    box = Box(value)
    try_ = box.to_try()

    assert try_.value == value



# Generated at 2022-06-24 00:00:39.984632
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test that calling to_lazy on Box returns Lazy with previous value.
    """
    from pymonet.lazy import Lazy

    assert Box(12).to_lazy() == Lazy(lambda: 12)
    assert Box(13).to_lazy().eval() == Box(13).value



# Generated at 2022-06-24 00:00:42.171001
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(3).to_either() == Right(3)


# Generated at 2022-06-24 00:00:44.420000
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(1)
    assert box.to_either() == Right(1)


# Generated at 2022-06-24 00:00:47.445766
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box('2').to_either() == Right('2')
    assert Box(str).to_either() == Right(str)



# Generated at 2022-06-24 00:00:50.930895
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box
    """
    assert str(Box(4)) == 'Box[value=4]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'


# Generated at 2022-06-24 00:00:52.158730
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(2).ap(Box(lambda x: x ** 2)) == Box(4)

# Generated at 2022-06-24 00:00:53.332512
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).value



# Generated at 2022-06-24 00:00:54.760515
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)



# Generated at 2022-06-24 00:00:57.487165
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(2).to_try() == Try(2, is_success=True)

# Generated at 2022-06-24 00:01:03.216078
# Unit test for method map of class Box
def test_Box_map():
    @curry
    def add(a: int, b: int) -> int:
        return a + b

    def test_Box_map_function_when_success():
        assert Box(2).map(add(1)) == Box(3)

    def test_Box_map_function_when_fail():
        assert Box(2).map(add(1)) != Box(4)

    test_Box_map_function_when_success()
    test_Box_map_function_when_fail()

# Generated at 2022-06-24 00:01:05.546842
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:01:07.876999
# Unit test for method map of class Box
def test_Box_map():
    """
    Tests map function
    """
    assert Box(2).map(lambda x: x ** 2) == Box(4)



# Generated at 2022-06-24 00:01:11.177950
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)

# Generated at 2022-06-24 00:01:15.880298
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() == Maybe.just(2)
    assert Box(2).map(lambda x: x).to_maybe() == Maybe.just(2)
    assert Box(2).to_maybe() == Box(2).map(Maybe.just).bind(lambda x: x)
    assert Box(2).map(lambda x: x).to_maybe() == Box(2).map(Maybe.just).bind(lambda x: x)


# Generated at 2022-06-24 00:01:18.457343
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('xyz')) == 'Box[value=xyz]'


# Generated at 2022-06-24 00:01:22.787550
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    box = Box(4)
    assert(box.to_either() == Right(4))

    box = Box('test')
    assert(box.to_either() == Right('test'))

    box = Box(['test', 'test1'])
    assert(box.to_either() == Right(['test', 'test1']))



# Generated at 2022-06-24 00:01:25.054351
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    def double(n: int) -> int:
        return n*2

    assert double(1) == Box(1).bind(double)



# Generated at 2022-06-24 00:01:29.406913
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(True).value

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-24 00:01:32.371012
# Unit test for method map of class Box
def test_Box_map():
    box = Box(10)
    mapped_box = box.map(lambda x: x / 5)
    assert isinstance(mapped_box, Box)
    assert mapped_box == Box(2)



# Generated at 2022-06-24 00:01:34.444801
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box("test").to_maybe() == Maybe.just("test")
    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(True).to_maybe() == Maybe.just(True)

# Generated at 2022-06-24 00:01:43.016794
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box('1').to_either() == Box('1').to_either()
    assert Box(True).to_either() == Box(True).to_either()
    assert Box(False).to_either() == Box(False).to_either()
    assert Box(1).to_either() == Box(1).to_either()
    assert Box(1.0).to_either() == Box(1.0).to_either()
    assert Box(1 + 2j).to_either() == Box(1 + 2j).to_either()
    assert Box([1, 2, 3]).to_either() == Box([1, 2, 3]).to_either()
    assert Box(set([1, 2, 3])).to_either() == Box(set([1, 2, 3])).to_either()

# Generated at 2022-06-24 00:01:44.191997
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(2) == Box(2).to_validation()



# Generated at 2022-06-24 00:01:46.574811
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-24 00:01:49.760340
# Unit test for constructor of class Box
def test_Box():
    assert Box(0) == Box(0)
    assert Box(0) != Box(1)
    assert Box(0) != 0
    assert Box(1) == Box(1)



# Generated at 2022-06-24 00:01:51.368317
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"


# Generated at 2022-06-24 00:01:54.395958
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box('hello').ap(Box(lambda x: x + ' world')) == Box('hello world')
    assert Box(1).ap(Box(lambda x: x + 2)) == Box(3)

# Generated at 2022-06-24 00:01:59.056269
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('1')) == 'Box[value=1]'
    assert str(Box([1])) == 'Box[value=[1]]'



# Generated at 2022-06-24 00:02:00.678034
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('hello')) == 'Box[value=hello]'



# Generated at 2022-06-24 00:02:02.979368
# Unit test for method map of class Box
def test_Box_map():
    def square(x):
        return x * x

    assert Box(12).map(square) == Box(144)



# Generated at 2022-06-24 00:02:07.065103
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_list import MonadList

    x = Box(3)
    y = Box(lambda x: x * 2)
    assert x.ap(y) == Box(6)

    y = MonadList(lambda x: x * 2, lambda x: x * 3)
    assert x.ap(y) == MonadList(6, 9)

# Generated at 2022-06-24 00:02:08.630062
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:02:11.220941
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)



# Generated at 2022-06-24 00:02:17.729790
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    """
    Unit test for method __eq__ of class Box
    """
    assert Box(1) == Box(1)
    assert Box(9) == Box(9)
    assert Box('a') == Box('a')
    assert Box(True) == Box(True)
    assert Box(False) == Box(False)
    assert Box(None) == Box(None)
    assert not Box('b') == Box('a')



# Generated at 2022-06-24 00:02:18.406302
# Unit test for constructor of class Box
def test_Box():
    assert Box(10) == Box(10)

# Generated at 2022-06-24 00:02:19.778952
# Unit test for method to_try of class Box
def test_Box_to_try():
    """Unit test for method to_try of class Box"""
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:02:21.993867
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    value = 1
    assert Box(value).to_validation() == Validation.success(value)

# Generated at 2022-06-24 00:02:29.087682
# Unit test for method ap of class Box
def test_Box_ap():

    def add_one(i: int) -> int:
        return i + 1

    box_with_add_one_func = Box(add_one)
    assert box_with_add_one_func.ap(Box(4)).value == 5

    def add_two(i: int) -> int:
        return i + 2

    box_with_add_two_func = Box(add_two)
    assert box_with_add_two_func.ap(Box(4)).value == 6

    assert box_with_add_one_func.ap(box_with_add_two_func).value(4) == 7

    def add_three_and_add_four(x: int, y: int) -> int:
        return x + y

    box_with_add_three_and_add_four_func = Box

# Generated at 2022-06-24 00:02:31.408656
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, True)

# Generated at 2022-06-24 00:02:38.990941
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from unittest import TestCase
    from pymonet.lazy import Lazy

    class Box_to_lazy_Tests(TestCase):
        def test_on_empty_Box(self):
            self.assertEqual(Box(None).to_lazy(), Lazy(lambda: None))

        def test_on_non_empty_Box(self):
            self.assertEqual(Box(42).to_lazy(), Lazy(lambda: 42))

    test_cases = Box_to_lazy_Tests()
    test_cases.test_on_empty_Box()
    test_cases.test_on_non_empty_Box()



# Generated at 2022-06-24 00:02:40.665747
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box

    :returns: nothing
    :rtype: None
    """

    assert Box(4).to_validation() == Validation.success(4)


# Generated at 2022-06-24 00:02:42.454810
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('test')) == 'Box[value=test]'


# Generated at 2022-06-24 00:02:51.500217
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left
    from pymonet.either_either import EitherEither

    assert Box(-1).to_either() == Left(-1)
    assert Box(0).to_either() == Left(0)
    assert Box(1).to_either() == Right(1)
    assert Box([]).to_either() == Left([])
    assert Box([1, 2, 3]).to_either() == Right([1, 2, 3])
    assert Box(EitherEither.left([])).to_either() == Left(EitherEither.left([]))
    assert Box(EitherEither.right([])).to_either() == Right(EitherEither.right([]))


# Generated at 2022-06-24 00:02:54.985936
# Unit test for method ap of class Box
def test_Box_ap():
    # Given
    box = Box(lambda x: x*2)
    applicative = Box(2)

    # When
    result = box.ap(applicative)

    # Then
    assert result == Box(4)

# Generated at 2022-06-24 00:02:56.750297
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).bind(lambda e: e).to_lazy()

# Generated at 2022-06-24 00:03:00.232012
# Unit test for method map of class Box
def test_Box_map():
    # Arrange
    box = Box(10)
    func = lambda x: x + 10

    # Act
    result = box.map(func)

    # Assert
    assert result == Box(func(box.value))


# Generated at 2022-06-24 00:03:00.855106
# Unit test for constructor of class Box
def test_Box():
    assert Box(42).value == 42



# Generated at 2022-06-24 00:03:03.900598
# Unit test for method bind of class Box
def test_Box_bind():
    actual_value = Box("hello_box").bind(lambda value: f"{value}_world")
    expected_value = "hello_box_world"
    assert actual_value == expected_value



# Generated at 2022-06-24 00:03:08.469020
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box(10)
    box_2 = Box(10)
    box_3 = Box(20)
    not_box = [1, 2, 3]

    assert box_1 == box_2
    assert box_1 != box_3
    assert box_1 != not_box



# Generated at 2022-06-24 00:03:09.781845
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).value



# Generated at 2022-06-24 00:03:11.809977
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    value = 3.14

    assert Box(value).to_maybe() == Box(value).to_maybe()


# Generated at 2022-06-24 00:03:13.356805
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just
    assert Box(1).to_maybe() == Just(1)


# Generated at 2022-06-24 00:03:15.852588
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box.
    """
    assert Box(13).to_validation().is_valid(), 'Box to Validator failed'


# Generated at 2022-06-24 00:03:17.668417
# Unit test for method map of class Box
def test_Box_map():
    def f(x): return x+3

    assert Box(3).map(f) == Box(6)


# Generated at 2022-06-24 00:03:20.197960
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(10).to_validation() == Validation.success(10)
    assert Box("test").to_validation() == Validation.success("test")
    assert Box([1, 2, 3]).to_validation() == Validation.success([1, 2, 3])


# Generated at 2022-06-24 00:03:24.939516
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    assert Box(1).to_maybe() == Maybe.just(1)
    assert isinstance(Box(1).to_maybe(), Maybe)



# Generated at 2022-06-24 00:03:26.545460
# Unit test for constructor of class Box
def test_Box():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-24 00:03:27.894758
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Maybe(1) == Box(1).to_maybe()


# Generated at 2022-06-24 00:03:29.092679
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-24 00:03:31.768804
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Empty test case
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))



# Generated at 2022-06-24 00:03:35.986841
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method :meth:`Box.to_lazy`

    :returns: Nothing
    """
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)



# Generated at 2022-06-24 00:03:42.691140
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    import sys

    if sys.version_info[:2] == (3, 4):  # pragma: no cover
        import unittest.mock as mock  # pragma: no cover
    else:  # pragma: no cover
        import unittest.mock as mock  # pragma: no cover

    f = mock.Mock()

    box = Box(1)
    box.map(f)
    f.assert_called_once_with(1)


# Generated at 2022-06-24 00:03:46.830130
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.function import FunctionIO

    assert Box(FunctionIO(lambda i: i + 10)).ap(Box(10)) == Box(20)



# Generated at 2022-06-24 00:03:48.768087
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'