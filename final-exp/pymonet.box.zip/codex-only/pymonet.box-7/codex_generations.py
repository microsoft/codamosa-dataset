

# Generated at 2022-06-23 23:53:50.573434
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.
    """
    def test_method():
        """
        Unnamed function for testing to_lazy method of class Box.
        """
        return 'test'

    box = Box(test_method)
    lazy = box.to_lazy()
    assert lazy.value() == 'test'

# Generated at 2022-06-23 23:53:55.719254
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-23 23:53:57.021142
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:53:59.249921
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda n: n * n).value == 1
    assert Box(3).map(lambda n: n * n).value == 9


# Generated at 2022-06-23 23:54:01.668205
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.box import Box

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:54:06.677336
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    @given(st.lists(elements=st.integers()))
    def test_case(data):
        assert Box(data) == Box(data)

    test_case()



# Generated at 2022-06-23 23:54:08.372433
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(5).to_maybe() == Box(5).to_maybe()



# Generated at 2022-06-23 23:54:10.318856
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(3).to_validation() == Validation.success(3)



# Generated at 2022-06-23 23:54:17.729581
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """Unit test for Box.to_validation method"""

    box: Box[str] = Box('Hello World!')
    validation: Validation = box.to_validation()
    assert isinstance(validation, Validation)
    assert validation.value == 'Hello World!'
    assert isinstance(validation.failures, list)
    assert len(validation.failures) == 0
    assert not validation.is_failure()
    assert validation.is_success()

# Generated at 2022-06-23 23:54:21.354504
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    box = Box(1)
    validation = box.to_validation()
    assert validation == Validation.success(1)


# Generated at 2022-06-23 23:54:23.004491
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Test return successfull validation with previous value
    """
    assert Box('foo').to_validation() == Validation.success('foo')

# Generated at 2022-06-23 23:54:26.151453
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test Case:
    Check that Box transforming to Try monad with value.
    """
    from pymonet.monad_try import Try

    box = Box(1)
    assert isinstance(box.to_try(), Try), "Should be instance of Try"
    assert box.to_try().get(), "Value should be same"


# Generated at 2022-06-23 23:54:32.724009
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    value = 'test'
    box_value = Box(value)
    maybe_value = box_value.to_maybe()
    assert isinstance(maybe_value, Maybe) and maybe_value.value == value



# Generated at 2022-06-23 23:54:39.349680
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(0)
    assert not (Box(0) == Box(1))
    assert not (Box(0) == Box(""))
    assert not (Box(0) == None)
    assert Box("") == Box("")
    assert Box(None) == Box(None)
    assert not (Box("") == None)
    assert not (Box("") == Box("Hello world"))



# Generated at 2022-06-23 23:54:40.083840
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('20').bind(lambda x: int(x)) == 20


# Generated at 2022-06-23 23:54:41.540633
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda a: a + 2) == Box(3)



# Generated at 2022-06-23 23:54:45.651140
# Unit test for method bind of class Box
def test_Box_bind():
    boxed = Box('hello')
    result = boxed.bind(lambda el: el.upper())

    assert result == 'HELLO'


# Generated at 2022-06-23 23:54:48.385049
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not(Box(1) == Box(2))
    assert not(Box(1) == 'Box[value=1]')



# Generated at 2022-06-23 23:54:56.520283
# Unit test for method ap of class Box
def test_Box_ap():
    """ Unit test for method ap of class Box """
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def divide(x, y):
        """
        Divide x on y.

        :param x: first divide operand
        :type x: int
        :param y: second divide operand
        :type y: int
        :returns: result of x on y division
        :rtype: int
        """
        try:
            return x / y
        except ZeroDivisionError:
            return 0

    # Test for apply function to Box with Try
    assert Box(divide).ap(Try(1)).value == Box(1).value
    assert Box(divide).ap(Try(1, is_success=False)).value == Try(0).value

    # Test for apply function

# Generated at 2022-06-23 23:54:58.274516
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != 1
    # Access to value from Box
    assert Box(1).value == 1


test_Box()

# Generated at 2022-06-23 23:54:59.752377
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert Box('A').to_try() == Try('A', is_success=True)



# Generated at 2022-06-23 23:55:02.596123
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x + 1) == 3
    assert Box(Box(2)).bind(lambda x: x.bind(lambda y: y + 1)) == 3
    assert Box(3).bind(lambda x: x).map(lambda x: x + 1) == 4


# Generated at 2022-06-23 23:55:03.938151
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1
    assert Box(2).value == Box(2).value


# Generated at 2022-06-23 23:55:07.059207
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)

# Generated at 2022-06-23 23:55:09.530049
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Unit tests for methods map, ap and bind of class Box

# Generated at 2022-06-23 23:55:11.280062
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-23 23:55:12.681950
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('foo')) == 'Box[value=foo]'


# Generated at 2022-06-23 23:55:19.209794
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.just(None)


# Generated at 2022-06-23 23:55:20.439620
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box('Hello world').to_maybe() == Maybe.just('Hello world')

# Generated at 2022-06-23 23:55:24.893525
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(lambda x: x + 1) == 2



# Generated at 2022-06-23 23:55:26.688286
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-23 23:55:32.410715
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """

    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:55:35.181390
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(42).to_maybe() == Maybe.just(42)



# Generated at 2022-06-23 23:55:41.022484
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success, Failure

    assert Box(1).to_validation() == Validation.success(1)
    assert Box(0).to_validation() == Validation.success(0)
    assert Box(1).to_validation() == Success(1)
    assert Box(0).to_validation() != Failure(0)
    assert Box(1).to_validation() != Failure(1)


# Generated at 2022-06-23 23:55:43.455250
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box('foo').to_either() == Right('foo')

# Generated at 2022-06-23 23:55:47.924079
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    def to_maybe(value):
        return Box(value).to_maybe()

    assert to_maybe(None) == Maybe.nothing()
    assert to_maybe(10) == Maybe.just(10)


# Generated at 2022-06-23 23:55:51.452321
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) == 1
    assert Box(1) != 2



# Generated at 2022-06-23 23:55:53.370599
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    expected = 'Box[value=1]'
    actual = str(Box(1))
    assert expected == actual



# Generated at 2022-06-23 23:55:58.527273
# Unit test for method bind of class Box
def test_Box_bind():
    """
    For given mapper function `f` and Box `value = Box(2)`

    If call `bind(value, f)`

    Then should return `Box(4)`
    """
    value = Box(2)
    mapper = lambda x: x * 2

    result = value.bind(mapper)

    assert result == 4

# Generated at 2022-06-23 23:56:02.988897
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    value = 1000
    box = Box(value)
    result = box.to_validation()

    assert isinstance(result, Validation)
    assert result.success.value == value
    assert result.failure == []



# Generated at 2022-06-23 23:56:04.662416
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-23 23:56:10.917877
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.monad_try import Try

    assert Box(1).to_either() == Right(1)
    assert Box('asd').to_either() == Right('asd')
    assert Box(Try(1, is_success=True)).to_either() == Right(Try(1, is_success=True))



# Generated at 2022-06-23 23:56:15.606558
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1

# Run unit tests
if __name__ == '__main__':  # pragma: no cover
    test_Box_to_lazy()

# Generated at 2022-06-23 23:56:17.233666
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(None).to_try() == Try(None, is_success=True)



# Generated at 2022-06-23 23:56:18.881675
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(123).to_lazy() == Lazy(lambda: 123)
    assert Box('abc').to_lazy() == Lazy(lambda: 'abc')

# Generated at 2022-06-23 23:56:20.741925
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:56:25.129471
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x * 2) == Box(6)


# Generated at 2022-06-23 23:56:27.329280
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(0).to_try() == Try(0, is_success=True)



# Generated at 2022-06-23 23:56:30.086716
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy for Box

    :returns: None
    """
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-23 23:56:32.245977
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    result = Validation.success(123)
    assert Box(123).to_validation() == result

    result = Validation.success('123')
    assert Box('123').to_validation() == result



# Generated at 2022-06-23 23:56:33.462151
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 2) == Box(4)



# Generated at 2022-06-23 23:56:39.205567
# Unit test for method to_either of class Box
def test_Box_to_either():
    def case1():
        from pymonet.either import Right

        assert Box(1).to_either() == Right(1)

    def case2():
        from pymonet.either import Right

        assert Box('asd').to_either() == Right('asd')

    def case3():
        from pymonet.either import Right
        from pymonet.option import Option

        assert Box(Option(None)).to_either() == Right(Option(None))

    def case4():
        from pymonet.either import Right
        from pymonet.maybe import Maybe

        assert Box(Maybe.just(None)).to_either() == Right(Maybe.just(None))

    def case5():
        from pymonet.either import Right
        from pymonet.monad_try import Try


# Generated at 2022-06-23 23:56:43.174368
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    box_from_try = Try(1, is_success=True).to_box()

    assert box_from_try.to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:56:47.006949
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    first = Box(42)
    second = Box(42)
    third = Box(21)

    assert(first == second)
    assert(first != third)


# Generated at 2022-06-23 23:56:48.058190
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)



# Generated at 2022-06-23 23:56:49.274187
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:56:56.232381
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    success_box = Box(True)
    assert success_box.to_try() == Try(True, is_success=True)

    failure_box = Box(False)
    assert failure_box.to_try() == Try(False, is_success=False)

# Generated at 2022-06-23 23:57:01.520160
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, Failure, Success

    def div(a, b):
        if b == 0:
            raise ValueError()
        return a / b

    assert Box(Try(2, True)).to_try() == Try(2, True)
    assert Box(Try(div, True)).to_try() == Try(div, True)
    assert Box(Try(div, False)).to_try() == Try(div, False)
    assert Box(Failure(ValueError())).to_try() == Failure(ValueError())
    assert Box(Success(2)).to_try() == Success(2)
    assert Box(ValueError()).to_try() == Failure(ValueError())
    assert Box(2).to_try() == Success(2)

# Generated at 2022-06-23 23:57:04.557835
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    lazy = Box(10).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 10

# Generated at 2022-06-23 23:57:06.456499
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:57:10.603034
# Unit test for constructor of class Box
def test_Box():
    # Arrange
    value1 = 'test'

    # Act
    result1 = Box(value1)

    # Assert
    assert result1.value == value1


# Generated at 2022-06-23 23:57:13.272736
# Unit test for constructor of class Box
def test_Box():
    assert Box(10) == Box(10)
    assert Box("It works") == Box("It works")
    assert Box((10, 20)) == Box((10, 20))


# Generated at 2022-06-23 23:57:15.782863
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Box(3).to_lazy()



# Generated at 2022-06-23 23:57:22.567980
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.errors import EmptyValidatorError

    try:
        validation = Box(1).to_validation()
        assert isinstance(validation, Validation) and len(validation.value) == 1
    except EmptyValidatorError as e:
        print(e)
        assert False

    try:
        validation = Box(set()).to_validation()
        assert isinstance(validation, Validation) and len(validation.value) == 0
    except EmptyValidatorError as e:
        print(e)
        assert False


# Generated at 2022-06-23 23:57:26.003773
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda x: x * 2) == 6

    assert Box(3).bind(lambda x: x + 2) == 5

    assert Box(3).bind(lambda x: x - 2) == 1


# Generated at 2022-06-23 23:57:29.122573
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test ap method in Box
    """

    def sum_3(x):
        return x * 3

    assert Box(2).ap(Box(sum_3)) == Box(sum_3(2))



# Generated at 2022-06-23 23:57:30.867582
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    maybe = Box(3).to_maybe()

    assert isinstance(maybe, Maybe)


# Generated at 2022-06-23 23:57:32.134218
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:57:37.326301
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:57:40.901442
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box('string').to_lazy()
    isinstance(lazy, Lazy) and lazy.fold(lambda: None) == 'string'



# Generated at 2022-06-23 23:57:45.611004
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(0)
    assert Box(1) != 0
    assert Box(1) != '0'
    assert Box(1) != None
    assert Box(1) != [1]
    assert Box(1) == (1,)
    assert Box(1) != [1, 2]
    assert Box(1) != (1, 2)
    assert Box('str') == Box('str')
    assert Box([]) == Box([])
    assert Box([1, 2]) == Box([1, 2])



# Generated at 2022-06-23 23:57:47.934917
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(2).bind(Maybe.just) == 2


# Generated at 2022-06-23 23:57:53.365823
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """

    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-23 23:57:55.121920
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).to_either()



# Generated at 2022-06-23 23:58:03.765092
# Unit test for constructor of class Box
def test_Box():
    """
    Unit tests for Box constructor

    :return: none
    """

    # when try constructor of class Box
    # then we get instance of object
    assert isinstance(Box(1), Box)
    assert isinstance(Box(None), Box)
    assert isinstance(Box({}), Box)
    assert isinstance(Box([]), Box)
    assert isinstance(Box(()), Box)
    assert isinstance(Box('string'), Box)



# Generated at 2022-06-23 23:58:04.686616
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-23 23:58:07.618914
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:58:10.377159
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1
    assert Box('test').to_lazy().value() == 'test'


# Generated at 2022-06-23 23:58:15.503762
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    @Box.to_try.from_decorator
    def test(param):
        return param

    result = test(1)
    assert isinstance(result, Try)
    assert result.value == 1


# Generated at 2022-06-23 23:58:17.575950
# Unit test for constructor of class Box
def test_Box():
    assert Box('a') == Box('a')
    assert str(Box('a')) == 'Box[value=a]'


# Generated at 2022-06-23 23:58:23.086102
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.maybe import Maybe

    def test_equal_with_own_type_equal_values():
        box1 = Box(1)
        box2 = Box(1)
        assert box1 == box2

    def test_equal_with_own_type_different_values():
        box1 = Box(1)
        box2 = Box(2)
        assert box1 != box2

    def test_equal_with_own_type_different():
        box1 = Box(1)
        box2 = Maybe.just(box1)
        assert box1 != box2

    test_equal_with_own_type_equal_values()
    test_equal_with_own_type_different_values()
    test_equal_with_own_type_different()


# Generated at 2022-06-23 23:58:27.052683
# Unit test for method ap of class Box
def test_Box_ap():
    def add(x):
        def f(y):
            return x + y
        return f

    assert Box(add).ap(Box(1)).value == Box(add(1)).value

# Generated at 2022-06-23 23:58:30.204563
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.maybe import Maybe

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Maybe.nothing()



# Generated at 2022-06-23 23:58:31.572266
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-23 23:58:37.850959
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    >>> test_Box_to_lazy()
    Lazy[fn=<function Box_to_lazy.<locals>.<lambda>.<locals>.<lambda> at 0x108a1a8c8>]
    """

    from pymonet.lazy import Lazy

    print(Box(5).to_lazy())

# Generated at 2022-06-23 23:58:39.393661
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test to_try method of Box class
    """
    assert Box(10).to_try() == 10

# Generated at 2022-06-23 23:58:45.284896
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(5).to_maybe().is_just()
    assert Box(1).to_maybe().is_just()
    assert Box(None).to_maybe().is_just()


# Generated at 2022-06-23 23:58:48.085534
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    :returns: boolean expression of test result
    :rtype: bool
    """
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)



# Generated at 2022-06-23 23:58:51.349685
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(3).to_either().is_right()


# Generated at 2022-06-23 23:58:59.159475
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box.
    """
    from pymonet.list_ import List
    from pymonet.lazy import Lazy
    from pymonet.monad_option import Option

    def plus_one(value: int) -> int:
        """
        Add 1 to given value.

        :param value: value for plus 1
        :type value: Integer
        :returns: value plus one
        :rtype: Integer
        """
        return value + 1

    assert Box(1).bind(plus_one) == 2
    assert Box(1).bind(plus_one).bind(plus_one) == 3

    assert Box(1).bind(lambda x: 2) == 2
    assert Box(1).bind(lambda x: 2).bind(lambda x: 3) == 3


# Generated at 2022-06-23 23:59:01.079991
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left

    to_either_box = Box(10).to_either()

    assert to_either_box == Left(10)

# Generated at 2022-06-23 23:59:05.931878
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box('Hello, world!')

    assert 'Box[value=Hello, world!]' == str(box)



# Generated at 2022-06-23 23:59:10.115424
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test of method to_lazy of Box.
    """
    # Input data
    value = 5

    # Expected result
    expected_result = Lazy(lambda: value)

    # Real result
    real_result = Box(value).to_lazy()

    # Asserts
    assert real_result == expected_result


# Generated at 2022-06-23 23:59:17.677899
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Check that case Box(2) >> to_lazy == Lazy(2).
    """
    from pymonet.lazy import Lazy

    assert Box(2).to_lazy() == Lazy(2), 'Box(2) >> to_lazy == Lazy(2) is not true'


# Generated at 2022-06-23 23:59:19.608114
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)


# Generated at 2022-06-23 23:59:21.140297
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    expected = Try(42)
    actual = Box(42).to_try()
    assert expected == actual

# Generated at 2022-06-23 23:59:26.413422
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test for method to_maybe of class Box.
    """

    from pymonet.maybe import Just, Maybe

    assert Just(1).to_maybe() == Box(1).to_maybe()
    assert Maybe.nothing().to_maybe() == Box(None).to_maybe()


# Generated at 2022-06-23 23:59:28.539588
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert not (Box(1) == Box(2))
    assert Box(1) == Box(1)

# Generated at 2022-06-23 23:59:30.688768
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(1)
    assert box.bind(lambda x: x + 1) == 2

# Generated at 2022-06-23 23:59:34.200793
# Unit test for method to_try of class Box
def test_Box_to_try():
    import pytest  # type: ignore
    from pymonet.monad_try import Try

    assert Box('success_value').to_try() == Try('success_value', is_success=True)
    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:59:35.342497
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda x: x + 5) == 8



# Generated at 2022-06-23 23:59:37.015485
# Unit test for constructor of class Box
def test_Box():
    assert Box("a") == Box("a")
    assert Box("a") != Box("b")



# Generated at 2022-06-23 23:59:38.770338
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try.Success(1) == Box(1).to_try()

# Generated at 2022-06-23 23:59:46.831391
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box([1, 2]) == Box([1, 2])
    assert Box(True) == Box(True)
    assert Box('a') == Box('a')
    assert Box(1.1) == Box(1.1)
    assert Box(None) == Box(None)
    assert Box(1) != Box(2)
    assert Box(None) != Box('1')

# Generated at 2022-06-23 23:59:56.347025
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test of method to_either of class Box
    """

    # Test to_either method of Box with integer value
    assert Box(5).to_either().is_right
    assert Box(5).to_either().right().value == 5

    # Test to_either method of Box with boolean value
    assert Box(True).to_either().is_right
    assert Box(True).to_either().right().value is True

    # Test to_either method of Box with float value
    assert Box(1.0).to_either().is_right
    assert Box(1.0).to_either().right().value == 1.0

    # Test to_either method of Box with None value
    assert Box(None).to_either().is_right
    assert Box(None).to_either().right().value is None

    # Test to

# Generated at 2022-06-23 23:59:58.725549
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('abc').map(lambda x: x[1]) == Box('b')


# Generated at 2022-06-24 00:00:04.887202
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.monad import unit
    assert unit(10).to_either() == Right(10)
    assert unit(None).to_either() == Right(None)



# Generated at 2022-06-24 00:00:06.560639
# Unit test for method ap of class Box
def test_Box_ap():
    box = Box(1)
    new_box = box.ap(Box(lambda x: x + 1))
    assert new_box == Box(2)

# Generated at 2022-06-24 00:00:08.621351
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Box(True).to_maybe() == Maybe.just(True)
    assert Box(None).to_maybe() == Maybe.just(None)


# Generated at 2022-06-24 00:00:11.260642
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box('').to_validation() == Validation.success('')
    assert Box(None).to_validation() == Validation.success(None)
    assert Box(False).to_validation() == Validation.success(False)
    assert Box(0).to_validation() == Validation.success(0)


# Generated at 2022-06-24 00:00:18.623147
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.validation import Validation

    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)
    assert Box(lambda x: x * 2).ap(Box(2)).to_validation() == Validation.success(4)
    assert Box(lambda x: x * 2).ap(Box(2)).to_maybe().to_maybe().__class__.__name__ == 'Just'
    assert Box(lambda x: x * 2).ap(Box(2)).to_maybe().to_maybe().bind(lambda value: value * 2).map(lambda value: value * 2).value == 16
    assert Box(lambda x: x * 2).ap(Box(2)).to_maybe().to_maybe().bind(lambda value: value * 2).map(lambda value: value * 2).to_either() == Box

# Generated at 2022-06-24 00:00:22.929940
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)
    assert Box(5).to_try() != Try(5, is_success=False)
    assert Box(5).to_try() != Try(7, is_success=True)
    assert Box(5).to_try() != Try(7, is_success=False)
    assert Box(5).to_try() == Try(5, is_success=True)
    assert isinstance(Box(5).to_try(), Try)

# Generated at 2022-06-24 00:00:24.686178
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10)



# Generated at 2022-06-24 00:00:27.077706
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(5)
    assert box.to_lazy() == Lazy(lambda: 5)

    box = Box('foo')
    assert box.to_lazy() == Lazy(lambda: 'foo')

# Generated at 2022-06-24 00:00:32.321304
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    box = Box(1)  # type: Box[int]
    assert str(box) == 'Box[value=1]'

# Generated at 2022-06-24 00:00:33.529574
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().fold() == 2



# Generated at 2022-06-24 00:00:35.298162
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-24 00:00:37.947637
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    box = Box(10)
    assert Try(box.value, is_success=True) == box.to_try()


# Generated at 2022-06-24 00:00:48.692408
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.maybe import Maybe

    assert Box(10).map(lambda x: x + 10) == Box(20)
    assert Box(10).map(lambda x: x * 10) == Box(100)
    assert Box(10).map(lambda x: x / 2) == Box(5)
    assert Box(2).map(lambda x: x ** 2) == Box(4)
    assert Box(40).map(lambda x: x / 10) == Box(4)
    assert Box(30).map(lambda x: x - 15) == Box(15)
    assert Box(-10).map(lambda x: x * -1) == Box(10)
    assert Box(-10).map(lambda x: x / -1) == Box(10)

# Generated at 2022-06-24 00:00:50.876801
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box.
    """
    assert Box(2).bind(lambda x: x * 2) == 4

# Generated at 2022-06-24 00:00:52.763600
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:01:00.242918
# Unit test for method bind of class Box
def test_Box_bind():
    def f(x: int) -> int:
        return x % 2

    assert isinstance(Box(4).bind(f), int)
    assert Box(4).bind(f) == 0
    assert isinstance(Box(5).bind(f), int)
    assert Box(5).bind(f) == 1
    assert isinstance(Box(6).bind(f), int)
    assert Box(6).bind(f) == 0
    assert isinstance(Box(7).bind(f), int)
    assert Box(7).bind(f) == 1
    assert isinstance(Box(8).bind(f), int)
    assert Box(8).bind(f) == 0
    assert isinstance(Box(9).bind(f), int)
    assert Box(9).bind(f) == 1


# Generated at 2022-06-24 00:01:01.919532
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(1.1) == Box(1.1)
    assert Box(1.1) != Box(1.2)
    assert Box(1) != None

# Generated at 2022-06-24 00:01:03.538283
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)


# Generated at 2022-06-24 00:01:06.723392
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(1).to_either() == Right(1)
    assert Box('a').to_either() == Right('a')



# Generated at 2022-06-24 00:01:08.338100
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('c')) == 'Box[value=c]'



# Generated at 2022-06-24 00:01:12.287094
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    from pymonet.list import List

    assert Box(3) == Box(3)
    assert Box(3) != Box(None)
    assert Box(3) != List([3])
    assert Box(3) != 3
    assert Box(3) != None



# Generated at 2022-06-24 00:01:16.875736
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)



# Generated at 2022-06-24 00:01:17.817372
# Unit test for constructor of class Box
def test_Box():
    assert Box(None) is not None

# Generated at 2022-06-24 00:01:20.147296
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box("message").to_try() == Try("message", is_success=True)


# Generated at 2022-06-24 00:01:21.321721
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('test') == Box('test')



# Generated at 2022-06-24 00:01:23.007351
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-24 00:01:24.619551
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(5)

    assert box.to_maybe() == Maybe.just(5)



# Generated at 2022-06-24 00:01:28.038246
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:01:31.412964
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(15)
    lazy = box.to_lazy()
    assert lazy.is_folded is False
    assert lazy.value == 15



# Generated at 2022-06-24 00:01:35.213913
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-24 00:01:38.128121
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    f = lambda value: value + 3

    box = Box(4)
    assert box.to_lazy() == Lazy(lambda: f(4))



# Generated at 2022-06-24 00:01:41.721153
# Unit test for method map of class Box
def test_Box_map():
    # Test case [1]
    box = Box('abc')
    assert box.map(lambda x: x.capitalize()) == Box('Abc')

    # Test case [2]
    box = Box(123)
    assert box.map(lambda x: str(x)) == Box('123')

    # Test case [3]
    box = Box([1, 2, 3])
    assert box.map(lambda x: x[0]) == Box(1)



# Generated at 2022-06-24 00:01:47.869669
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(42).to_try() == Try(42, is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)
    assert Box('42').to_try() == Try('42', is_success=True)
    assert Box(42).to_try() == Try(42, is_success=True)
    assert Box([42]).to_try() == Try([42], is_success=True)
    assert Box({'foo': 42}).to_try() == Try({'foo': 42}, is_success=True)
    assert Box((42, )).to_try() == Try((42, ), is_success=True)



# Generated at 2022-06-24 00:01:54.401564
# Unit test for method bind of class Box
def test_Box_bind():
    # GIVEN
    def inc(x: int) -> int:
        return x + 1

    # WHEN
    result = Box(1).bind(inc)

    # THEN
    assert result == 2

    # GIVEN
    def add_str(x: str) -> str:
        return x + " World"

    # WHEN
    result = Box("Hello").bind(add_str)

    # THEN
    assert result == "Hello World"



# Generated at 2022-06-24 00:01:57.347717
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.box import Box

    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-24 00:01:58.858836
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x * 2) == 10


# Generated at 2022-06-24 00:02:07.871560
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"
    assert str(Box(1.1)) == "Box[value=1.1]"
    assert str(Box("str")) == "Box[value=str]"
    assert str(Box(True)) == "Box[value=True]"
    assert str(Box(frozenset([1, 2, 3]))) == "Box[value=frozenset({1, 2, 3})]"
    assert str(Box(set([1, 2, 3]))) == "Box[value=set({1, 2, 3})]"
    assert str(Box(list([1, 2, 3]))) == "Box[value=[1, 2, 3]]"

# Generated at 2022-06-24 00:02:18.413250
# Unit test for method ap of class Box
def test_Box_ap():
    def add(x: int) -> Callable[[int], int]:
        def inner(y: int) -> int:
            return x + y

        return inner

    assert Box(5).ap(Box(add)) == Box(10)
    assert Box(add).ap(Box(5)) == Box(10)
    assert (Box(add(2))).ap(Box(5)) == Box(7)
    assert (Box(add(2))).ap(Box(add(3))) == Box(add(2)(3))
    assert (Box(add(2))).ap(Box(add(3))).ap(Box(5)) == Box(add(2)(add(3)(5)))



# Generated at 2022-06-24 00:02:19.382401
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:02:20.361526
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda a: a * 2) == 20



# Generated at 2022-06-24 00:02:22.514211
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-24 00:02:25.775008
# Unit test for method map of class Box
def test_Box_map():
    # Success test
    assert Box(5).map(lambda x: x * 2) == Box(10)

    # Failure test
    try:
        Box("abc").map(lambda x: x * 2)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 00:02:28.033450
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:02:31.881541
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    result = Box(True).to_try()

    assert isinstance(result, Try)
    assert result.value
    assert result.is_success



# Generated at 2022-06-24 00:02:36.437848
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Failure

    assert Box(1).to_try() is Try(1, is_success=True)
    assert Box(Failure()).to_try() is Try(Failure(),  is_success=False)


# Generated at 2022-06-24 00:02:41.141738
# Unit test for method map of class Box
def test_Box_map():
    expected_value = Box('test_value')
    new_value = expected_value.map(lambda value: value)
    assert expected_value == new_value



# Generated at 2022-06-24 00:02:43.388089
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(100)) == 'Box[value=100]'


# Generated at 2022-06-24 00:02:46.566327
# Unit test for method map of class Box
def test_Box_map():
    first_box = Box(1)
    assert first_box == Box(1)
    assert str(first_box) == 'Box[value=1]'

    second_box = first_box.map(lambda x: x + 1)
    assert second_box == Box(2)



# Generated at 2022-06-24 00:02:49.133164
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    test_value = Box(1)
    assert test_value.value == 1, 'fail'



# Generated at 2022-06-24 00:02:51.451479
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(11)



# Generated at 2022-06-24 00:03:00.432512
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation, _

    assert Validation.success(1) == Box(1).to_validation()
    assert Validation.success(None) == Box(None).to_validation()
    assert Validation.success(True) == Box(True).to_validation()
    assert Validation.success(False) == Box(False).to_validation()
    assert Validation.success(_) == Box(_).to_validation()
    assert Validation.success('x') == Box('x').to_validation()
    assert Validation.success(_) == Box(_).to_validation()

# Generated at 2022-06-24 00:03:02.870735
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Either

    assert isinstance(Box(1).to_either(), Either)



# Generated at 2022-06-24 00:03:06.758017
# Unit test for method to_either of class Box
def test_Box_to_either():
    # given
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    left_either = Left(None)
    failed_try = Try(None, is_success=False)
    failed_validation = Validation.fail(None)

    # when
    left_either_transformed = left_either.to_either()
    failed_try_transformed = failed_try.to_either()
    failed_validation_transformed = failed_validation.to_either()

    # then
    assert left_either_transformed == left_either
    assert failed_try_transformed.left is None
    assert failed_validation_transformed.left is None

# Generated at 2022-06-24 00:03:10.371842
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Left

    assert Box(1).to_either() == Right(1)
    assert Box('abc').to_either() == Right('abc')
    assert Box(Left(1)).to_either() == Left(1)
    assert Box(Left(1).to_either()).to_either() == Left(1)

# Generated at 2022-06-24 00:03:12.079565
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test for transforming box into try
    """
    from pymonet.monad_try import Try
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:03:13.280629
# Unit test for method __str__ of class Box
def test_Box___str__():

    assert Box(1).__str__() == "Box[value=1]"



# Generated at 2022-06-24 00:03:15.728338
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test case for method to_maybe of class Box.
    """
    from pymonet.maybe import Maybe

    assert Box('a').to_maybe() == Maybe.just('a')


# Generated at 2022-06-24 00:03:17.820009
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    box = Box(None)
    assert box.to_try() == Try(None, is_success=True)

# Generated at 2022-06-24 00:03:19.787513
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:03:22.651186
# Unit test for method bind of class Box
def test_Box_bind():
    # arrange
    box = Box(100)

    # act
    bind_result = box.bind(lambda x: x * x)

    # assert
    assert bind_result == 10000



# Generated at 2022-06-24 00:03:32.186356
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """

    assert Box(5).to_try() == Box(5).to_try()

    # Test if to_try works with int
    assert Box(5).to_try() == Try(5)

    # Test if to_try works with float
    assert Box(5.5).to_try() == Try(5.5)

    # Test if to_try works with string
    assert Box('abc').to_try() == Try('abc')

    # Test if to_try works with list
    assert Box([1, 2, 3]).to_try() == Try([1, 2, 3])

    # Test if to_try works with dict
    assert Box({'a': 3}).to_try() == Try({'a': 3})

    # Test if to_try

# Generated at 2022-06-24 00:03:34.522611
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:03:35.786997
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().value == 3

# Generated at 2022-06-24 00:03:38.210025
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() == Maybe.just(2)


# Generated at 2022-06-24 00:03:41.904742
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(0) == Box(0)
    assert Box(0) != Box(1)
    assert type(Box(0)) == Box
    assert str(Box(0)) == 'Box[value=0]'



# Generated at 2022-06-24 00:03:44.921041
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test that method to_lazy of Box return right instance of Lazy
    """
    value = Box('value')
    lazy = value.to_lazy()
    assert lazy.value() == 'value'
