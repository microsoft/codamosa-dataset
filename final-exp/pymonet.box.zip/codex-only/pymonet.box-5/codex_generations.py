

# Generated at 2022-06-23 23:53:51.927257
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    value = 'value'
    box = Box(value)
    try_monad = box.to_try()

    assert isinstance(try_monad, Try)
    assert try_monad.is_success() is True
    assert try_monad.get_value() == value

# Generated at 2022-06-23 23:53:57.557836
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try(123).map(_to_str).to_maybe() == Box('123').to_try().map(_to_str).to_maybe()
    assert Try(123).to_maybe() == Box('123').to_try().to_maybe()
    assert Try().to_maybe() != Box('123').to_try().to_maybe()

# Generated at 2022-06-23 23:54:01.005479
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box
    """
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(123456)) == 'Box[value=123456]'
    assert str(Box('value')) == 'Box[value=value]'



# Generated at 2022-06-23 23:54:02.448429
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"



# Generated at 2022-06-23 23:54:06.157105
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1

# Generated at 2022-06-23 23:54:10.910057
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just
    func = lambda x: x + 1
    box = Box(1).to_maybe().map(func)
    assert type(box) is Just
    assert box.value == 2


# Generated at 2022-06-23 23:54:13.919961
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-23 23:54:16.857756
# Unit test for method map of class Box
def test_Box_map():
    assert Box(lambda x: x + 1).map(lambda x: x(2)) == Box(3)



# Generated at 2022-06-23 23:54:18.371599
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:54:25.802580
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    obj = Box(5)
    assert str(obj) == 'Box[value=5]'
    assert obj.value == 5



# Generated at 2022-06-23 23:54:33.108680
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)
    assert Box(True) != Box(False)
    assert str(Box('test')) == 'Box[value=' + str('test') + ']'


# Generated at 2022-06-23 23:54:36.116609
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)



# Generated at 2022-06-23 23:54:37.537356
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation().is_success()



# Generated at 2022-06-23 23:54:39.277137
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe

    mapper = lambda x: Maybe.just(x * 2)

    assert Box(2).bind(mapper).value == 4
    assert Box(2).bind(lambda x: mapper(x)).value == 4



# Generated at 2022-06-23 23:54:40.878830
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)


# Generated at 2022-06-23 23:54:42.782622
# Unit test for method ap of class Box
def test_Box_ap():
    res = ((lambda x: x + 10) <= Box(1))
    assert res == Box(11)


# Generated at 2022-06-23 23:54:47.206301
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    validation1 = Box(1).to_validation()
    validation2 = Validation.success(1)
    assert validation1 == validation2



# Generated at 2022-06-23 23:54:49.857517
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet import Lazy

    assert Box("Hello").to_lazy() == Lazy(lambda: "Hello")
    assert Box("Hello").to_lazy().value == "Hello"
    assert Box("Hello").to_lazy().value == "Hello"  # check for memoisation

# Generated at 2022-06-23 23:54:52.487886
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda v: v + 1) == 4

# Generated at 2022-06-23 23:54:56.332026
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test method to_either of class Box.

    :returns: None
    :rtype: None
    """
    from pymonet.either import Right

    assert Box(42).to_either() == Right(42), "Box to Right Either Test Failure!"



# Generated at 2022-06-23 23:55:02.290560
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(2).ap(Lazy(lambda: Box(lambda x: x * 3))).value == 6



# Generated at 2022-06-23 23:55:04.221087
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Checks if to_either method convert input value to Right either monad.
    """
    from pymonet.either import Right

    assert Box(10).to_either() == Right(10)



# Generated at 2022-06-23 23:55:07.006655
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(3).ap(Box(lambda x: x * 2)) == Box(6)

# Generated at 2022-06-23 23:55:10.668977
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for Box bind method.

    :returns: None
    :rtype: None
    """
    def mapper(number):
        return number * number

    assert Box(2).bind(mapper) == 4

# Generated at 2022-06-23 23:55:19.465344
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Checks if Box to_try() method returns successfull Try with same value.
    """
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)
    assert Box(5).to_try().to_box() == Box(5)

    assert Box(5).ap(Box(lambda x: x + 5)) == Box(10)

    assert (Box(5)
            .bind(lambda x: x + 5)
            .bind(lambda x: x * 100)) == 800

    assert Box(5).map(lambda x: x + 5).value == 10
    assert Box(5).map(lambda x: x * 2).value == 10
    assert (lambda x: x + 5)(Box(5).value) == 10

# Generated at 2022-06-23 23:55:20.932474
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:55:25.836287
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box('test')) == 'Box[value=test]'



# Generated at 2022-06-23 23:55:28.023740
# Unit test for method map of class Box
def test_Box_map():
    box = Box(2)
    new_box = box.map(lambda x: x * 2)
    assert new_box == Box(4)


# Generated at 2022-06-23 23:55:30.178009
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-23 23:55:31.391523
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    value = 1
    assert Box(value).to_maybe() == Maybe.just(value)

# Generated at 2022-06-23 23:55:35.514337
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import __try__

    with __try__() as x:
        x
    assert Box(42).to_try() == Try(42, is_success=True)  # expected successfull Try

# Generated at 2022-06-23 23:55:43.889854
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda a: a + 5) == Box(15)
    assert Box(10.0).map(lambda a: a * 3.0) == Box(30.0)
    assert Box(10).map(lambda a: '{}'.format(a)) == Box('10')
    assert Box(10).map(lambda a: str(a)) == Box('10')
    assert Box([1, 2, 3]).map(lambda a: a + [4, 5]) == Box([1, 2, 3, 4, 5])
    assert Box([1, 2, 3]).map(lambda a: a * 3) == Box([1, 2, 3, 1, 2, 3, 1, 2, 3])

# Generated at 2022-06-23 23:55:49.188503
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.pymonet_test import value_or_error

    value = "just"
    boxed_value = Box(value)

    assert boxed_value.to_maybe() == Maybe.just(value)

    value = "nothing"
    boxed_value = Box(Maybe.nothing())

    assert boxed_value.to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:55:54.902323
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.functor import Functor

    from pymonet.lazy import Lazy

    from operators.comparator_operators import compare_equality

    def f(x: int) -> int:
        return x ** 2

    assert Functor[Lazy] \
        .fmap(f, Box(2).to_lazy()) \
        .force() \
        | compare_equality(Lazy(4))

# Generated at 2022-06-23 23:55:56.349511
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-23 23:55:57.386521
# Unit test for constructor of class Box
def test_Box():
    assert Box('1') == Box('1')



# Generated at 2022-06-23 23:56:02.577852
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:56:06.937900
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    box = Box(5)

    # Act
    lazy = box.to_lazy()

    # Assert
    assert isinstance(lazy, Lazy)
    assert box.value == lazy.call()

# Generated at 2022-06-23 23:56:09.621585
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:56:16.811448
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test function for to_either of class Box
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box('string').to_either() == Right('string')
    assert Box(None).to_either() == Right(None)
    assert Box(False).to_either() == Right(False)
    assert Box((1, 2, 3)).to_either() == Right((1, 2, 3))
    assert Box([1, 2, 3]).to_either() == Right([1, 2, 3])
    assert Box({'key': 'value'}).to_either() == Right({'key': 'value'})



# Generated at 2022-06-23 23:56:17.798366
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-23 23:56:21.165973
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 'Test'



# Generated at 2022-06-23 23:56:25.456736
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"


# Generated at 2022-06-23 23:56:27.328681
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    box = Box(100)

    assert box.map(lambda a: a + 1) == Box(101)



# Generated at 2022-06-23 23:56:28.458370
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x + 2) == 4



# Generated at 2022-06-23 23:56:29.563044
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(10).to_maybe().value == 10



# Generated at 2022-06-23 23:56:30.600903
# Unit test for method __str__ of class Box
def test_Box___str__():
    b = Box(1)
    assert(str(b) == 'Box[value=1]')



# Generated at 2022-06-23 23:56:31.902928
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-23 23:56:35.732885
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_lazy().map(lambda x: x + 1).run() == 2
    assert Box(1).to_lazy() != Lazy(lambda: 2)

    # Check that value does not change in multiple calls
    assert Maybe(1).to_lazy().run() == 1
    assert Maybe(1).to_lazy().map(lambda x: x + 1).run() == 2



# Generated at 2022-06-23 23:56:39.133412
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1
    assert Box('string').value == 'string'


# Generated at 2022-06-23 23:56:40.783006
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x**2) == Box(1)



# Generated at 2022-06-23 23:56:44.205879
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe

    assert Box(0).bind(lambda x: x + 1) == 1
    assert Box(1).bind(Maybe.just) == Maybe.just(1)


# Generated at 2022-06-23 23:56:47.699396
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either, Left, Right

    assert Box(1).to_either() == Right(1)
    assert Box(1).to_either() == Either.of(1)



# Generated at 2022-06-23 23:56:48.954621
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:56:53.966827
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert(Box(1).to_lazy()) == Lazy(lambda: 1)

# Generated at 2022-06-23 23:56:57.066761
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.maybe import Maybe

    assert Maybe(Box('test').map(lambda x: x + '1')).equals(Maybe('test1'))

    assert Maybe(Box(1).map(lambda x: x + 10)).equals(Maybe(11))



# Generated at 2022-06-23 23:56:59.112811
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.just(None)


# Generated at 2022-06-23 23:57:02.907931
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Pretty print for Box
    """
    assert str(Box(5)) == 'Box[value=5]'
    assert str(Box('test')) == 'Box[value=test]'
    assert str(Box({'a': 10})) == "Box[value={'a': 10}]"

# Generated at 2022-06-23 23:57:06.547275
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.monad import box

    assert box(1).to_validation() == Validation.success(1)
    assert box([]).to_validation() == Validation.success([])
    assert box(1).to_validation() != Validation.success(10)



# Generated at 2022-06-23 23:57:08.239565
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)



# Generated at 2022-06-23 23:57:11.275466
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')



# Generated at 2022-06-23 23:57:15.056436
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)
    assert Box(None).to_validation() == Validation.success(None)


# Generated at 2022-06-23 23:57:18.674282
# Unit test for constructor of class Box
def test_Box():
    assert Box(123) == Box(123)
    assert Box(123) != Box(555)
    assert str(Box('123')) == 'Box[value=123]'
    assert str(Box(123)) == 'Box[value=123]'



# Generated at 2022-06-23 23:57:22.282637
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-23 23:57:24.636461
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 2


# Generated at 2022-06-23 23:57:27.896955
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """

    from pymonet.validation import Validation

    validation = Validation.success('success')
    box = Box('success')

    assert box.to_validation() == validation

# Generated at 2022-06-23 23:57:29.123490
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(10)

# Generated at 2022-06-23 23:57:32.633237
# Unit test for method map of class Box
def test_Box_map():
    """
    Test method map of class Box

    :returns: None
    :rtype: None
    :raises AssertionError: if test failed
    """
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(2).map(lambda x: x * 2) == Box(4)
    assert Box(4).map(lambda x: x * x) == Box(16)



# Generated at 2022-06-23 23:57:37.701544
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    box = Box(3)
    res = box.to_try()
    assert isinstance(res, Try)
    assert res.value == 3



# Generated at 2022-06-23 23:57:44.649776
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, TryError

    assert Box(1).to_try() == Try(1)

    def exception_raise():
        raise Exception('test')

    try:
        exception_raise()
    except Exception as err:
        assert Box(err).to_try() == Try(err)
    try:
        exception_raise()
    except Exception as err:
        assert Box(err).to_try(default=TryError('default')) == TryError('default')
# End of unit test for method to_try of class Box


# Generated at 2022-06-23 23:57:48.114562
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    # When Box is Empty
    assert Box(None).to_maybe() is Maybe.nothing()

    # When Box is not Empty
    assert Box(3).to_maybe() is Maybe.just(3)



# Generated at 2022-06-23 23:57:58.391389
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """Test Box to_maybe method"""
    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(0).to_maybe() == Maybe.just(0)
    assert Box((1, 2)).to_maybe() == Maybe.just((1, 2))
    assert Box([1, 2]).to_maybe() == Maybe.just([1, 2])
    assert Box({'x': 2, 'y': 3}).to_maybe() == Maybe.just({'x': 2, 'y': 3})
    assert Box((lambda x: x ** 2))('Clojure rocks!') == Maybe.just('Clojure rocks!')

    def test_function(x, y):
        return x + y
    assert Box(test_function).to_maybe() == Maybe.just(test_function)


test_Box_to_

# Generated at 2022-06-23 23:58:00.247170
# Unit test for method map of class Box
def test_Box_map():

    # Test if mapping one box return another box with mapped value
    assert Box(5).map(lambda x: x + 1) == Box(6)

# Generated at 2022-06-23 23:58:02.231142
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda a: a + 1).ap(Box(2)) == Box(3)



# Generated at 2022-06-23 23:58:03.435732
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box("test")) == "Box[value=test]"


# Generated at 2022-06-23 23:58:04.873333
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(value=1)
    assert box.to_lazy().get_value() == 1

# Generated at 2022-06-23 23:58:10.292318
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('text')) == 'Box[value=text]'
    assert str(Box([])) == 'Box[value=[]]'
    assert str(Box({})) == 'Box[value={}]'


# Generated at 2022-06-23 23:58:14.055598
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just

    assert Box(42).to_maybe() == Just(42)



# Generated at 2022-06-23 23:58:16.262740
# Unit test for method __str__ of class Box
def test_Box___str__():  # type: ignore
    box = Box(10)

    assert str(box) == 'Box[value=10]'


# Generated at 2022-06-23 23:58:22.121841
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(42).to_try() == Try(val=42, is_success=True)
    assert Box(42).to_try().is_success
    assert isinstance(Box(42).to_try(), Try)


# Generated at 2022-06-23 23:58:27.246980
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test for method to_try of class Box
    """
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:58:30.009476
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(3)
    assert box.to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-23 23:58:32.102464
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)



# Generated at 2022-06-23 23:58:35.838564
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():

    Box(42).to_lazy().bind(lambda x: print(x))

# Generated at 2022-06-23 23:58:38.392452
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for transform Box into Lazy
    """

    box = Box(5)
    lazy_monad = box.to_lazy()

    assert lazy_monad.value() == 5



# Generated at 2022-06-23 23:58:39.908521
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(3).to_either() == Right(3)



# Generated at 2022-06-23 23:58:41.959079
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None

# Generated at 2022-06-23 23:58:44.418942
# Unit test for method bind of class Box
def test_Box_bind():
    # Arrange
    box = Box(1)
    function = lambda x: Box(x + 1)

    # Act
    result = box.bind(function)

    # Assert
    assert result == Box(2)



# Generated at 2022-06-23 23:58:47.878204
# Unit test for constructor of class Box
def test_Box():
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)
    assert Box('foo') != Box(3)
    assert Box(2).value == 2
    assert Box('foo').value == 'foo'

    assert str(Box(2)) == 'Box[value=2]'
    assert str(Box('foo')) == 'Box[value=foo]'



# Generated at 2022-06-23 23:58:51.349552
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2



# Generated at 2022-06-23 23:58:54.509500
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert not Box(2) == Box(3)
    assert not Box(2) == Box('string')
    assert not Box(2) == 'string'
    assert not Box(2) == None



# Generated at 2022-06-23 23:58:56.034988
# Unit test for constructor of class Box
def test_Box():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-23 23:59:00.837957
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation(10, [])



# Generated at 2022-06-23 23:59:07.122551
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    import pytest

    from pymonet.maybe import Maybe

    assert Box(100).to_maybe() == Maybe.just(100)

    with pytest.raises(NotImplementedError):
        Maybe.nothing().to_maybe() == Maybe.just(100)



# Generated at 2022-06-23 23:59:11.278253
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest

    def test():
        return 1

    assert Box(1).to_try() == Try.unit(1)
    assert Box(1).to_lazy() == Lazy(test)
    assert Box(1).to_lazy().value() == 1

    with pytest.raises(Exception):
        assert Box(1).to_lazy().value() == 2



# Generated at 2022-06-23 23:59:15.519326
# Unit test for method ap of class Box
def test_Box_ap():
    f = lambda x: x * 2
    g = Box(f)
    assert Box(4).ap(g) == Box(8)
    assert Box(4).ap(Box(f)) == Box(8)


# Generated at 2022-06-23 23:59:18.648362
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(42) == Box(42)
    assert Box(42) != Box(43)
    assert Box(42) == Box('42')
    assert Box(42) != '42'


# Generated at 2022-06-23 23:59:20.300180
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-23 23:59:23.839199
# Unit test for method ap of class Box
def test_Box_ap():
    # Given
    box = Box(lambda x: x + 5)

    # When
    new_box = box.ap(Box(3))

    # Then
    assert new_box == Box(8)


# Generated at 2022-06-23 23:59:29.763632
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:59:31.691811
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-23 23:59:38.884627
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box
    """
    from pymonet.validation import Validation
    from pymonet.monad_validation import is_validation

    assert is_validation(Box(1).to_validation())
    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:59:40.351588
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(True).to_validation() == Validation.success(True)



# Generated at 2022-06-23 23:59:42.170478
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for Box.to_maybe method
    """
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-23 23:59:43.252403
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:59:45.226808
# Unit test for method to_try of class Box
def test_Box_to_try():
    result = Box('test').to_try()

    assert(result.is_success)
    assert(result.value == 'test')

# Generated at 2022-06-23 23:59:53.494241
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != 3
    assert Box(3) != Box(4)
    assert Box(3) != Box(4.0)
    assert Box(4.0) == Box(4.0)
    assert Box(None) == Box(None)
    assert Box(object()) != Box(object())
    assert Box(object()) != object()


# Generated at 2022-06-23 23:59:57.123287
# Unit test for constructor of class Box
def test_Box():
    assert Box(5) == Box(5)



# Generated at 2022-06-24 00:00:04.887854
# Unit test for method map of class Box
def test_Box_map():
    """
    Tests for method map in Box class

    :return: None
    :rtype: None
    """
    from pymonet.either import Left
    from pymonet.maybe import Nothing
    from pymonet.validation import Validation

    value = Box(1).map(lambda x: x + 1)

    assert value.value == 2

    value = Box(Box(1)).map(lambda x: x.map(lambda y: y + 1))

    assert isinstance(value.value, Box)
    assert value.value.value == 2

    value = Box(Nothing()).map(lambda x: x.map(lambda y: y + 1))

    assert isinstance(value.value, Nothing)

    value = Box(Left(1)).map(lambda x: x.map(lambda y: y + 1))


# Generated at 2022-06-24 00:00:06.519689
# Unit test for method ap of class Box
def test_Box_ap():
    box_f = Box(lambda x: x + 1)
    box_v = Box(1)
    assert box_f.ap(box_v) == Box(2)

# Generated at 2022-06-24 00:00:12.028383
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    val = Validation(0, ['error'])
    assert Box(0).to_validation() == val


# Generated at 2022-06-24 00:00:16.948930
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    def f(x):
        return Box(x + 1)

    box = Box(f)
    assert box.ap(Validation.success(1)) == Validation.success(2)
    assert box.ap(Validation.failure([])) == Validation.failure([])
    assert box.ap(Try(1)) == Try(2)



# Generated at 2022-06-24 00:00:19.318390
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test case for method to_maybe of class Box.

    """
    from pymonet.maybe import Maybe

    m = Box(10).to_maybe()

    assert m.is_just() and m.from_just() == 10, "Should be valid!"



# Generated at 2022-06-24 00:00:21.599931
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Box(123).to_lazy() == Lazy.unit(123)

    assert Maybe.just(2).to_box().to_lazy() == Lazy.unit(2)

# Generated at 2022-06-24 00:00:24.565102
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test ap method of Box class.

    :returns: True if test passed, False if not
    :rtype: bool
    """
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)
    return True



# Generated at 2022-06-24 00:00:26.251723
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box.

    :return: None
    """
    assert 0 == Box(1).bind(lambda v: v - 1).value


# Generated at 2022-06-24 00:00:27.387361
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    See documentation for this method
    """
    assert 'Box[value=x]' == str(Box('x'))

# Generated at 2022-06-24 00:00:31.687436
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(41).bind(lambda x: x + 1) == 42

# Generated at 2022-06-24 00:00:33.990804
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from .test_either import test_to_box

    assert test_to_box(Right) is True


# Generated at 2022-06-24 00:00:36.827635
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)

# Generated at 2022-06-24 00:00:40.168795
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() is None


# Generated at 2022-06-24 00:00:43.194092
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert str(Box(1)) == 'Box[value=1]'
    assert Box(1).value == 1


# Generated at 2022-06-24 00:00:44.494885
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box(3) != Box(4)



# Generated at 2022-06-24 00:00:47.209727
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad_list import MonadList
    assert Box('str').to_validation() == Validation('str', MonadList())



# Generated at 2022-06-24 00:00:48.094489
# Unit test for constructor of class Box
def test_Box():
    assert Box(42).value == 42


# Generated at 2022-06-24 00:00:54.619466
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(3).to_try() == Try(3, is_success=True)
    assert Box(3).to_try().is_success() is True
    assert Box(3).to_try().is_failure() is False
    assert Box(3).to_try().get_or_else(4) == 3


# Generated at 2022-06-24 00:00:57.710057
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(123).to_either() == Right(123)


# Generated at 2022-06-24 00:01:00.099191
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    value = 1
    assert Box(value).to_validation() == Validation.success(value)

# Generated at 2022-06-24 00:01:01.241720
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box('value')
    assert box == Box('value')



# Generated at 2022-06-24 00:01:02.065603
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)

# Generated at 2022-06-24 00:01:05.135388
# Unit test for method ap of class Box
def test_Box_ap():
    g = Box(lambda x: x * 2)
    a = Box(2)
    assert g.ap(a).value == 4
    assert g.ap(a) == Box(4)
    another = Box('function')
    assert g.ap(another) == Box('function')


# Generated at 2022-06-24 00:01:06.923796
# Unit test for method ap of class Box
def test_Box_ap():
    def plus(x):
        return lambda y: x + y

    assert (Box(plus).ap(Box(3)).bind(lambda plus: plus(5)) == Box(8)).value

# Generated at 2022-06-24 00:01:08.920434
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-24 00:01:16.700998
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    # Test for Box(5) to Maybe(5)
    assert Maybe.just(5) == Box(5).to_maybe()

    # Test for Box(True) to Maybe(True)
    assert Maybe.just(True) == Box(True).to_maybe()

    # Test for Box(2.718) to Maybe(2.718)
    assert Maybe.just(2.718) == Box(2.718).to_maybe()

    # Test for Box('Hello') to Maybe('Hello')
    assert Maybe.just('Hello') == Box('Hello').to_maybe()

    # Test for Box([1, 2, 3, 4, 5]) to Maybe([1, 2, 3, 4, 5])
    assert Maybe.just([1, 2, 3, 4, 5])

# Generated at 2022-06-24 00:01:18.713530
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:01:20.309776
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x * 2).value == 6


# Generated at 2022-06-24 00:01:22.384367
# Unit test for method ap of class Box
def test_Box_ap():
    return Assert.deepEqual(
        Box.of(lambda a: a + 1).ap(Box.of(1)),
        Box.of(2)
    )

# Generated at 2022-06-24 00:01:24.427055
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(10) == Box(10)
    assert Box(20) != Box(10)
    assert Box(20) != 10

# Generated at 2022-06-24 00:01:29.559379
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    def f(x: int) -> str:
        return str(x) + '!'

    box_int = Box(2)

    assert f(2) == box_int.bind(f)



# Generated at 2022-06-24 00:01:36.706302
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(None) == Box(None)
    assert Box(True) == Box(True)
    assert Box(False) == Box(False)
    assert Box('test') == Box('test')
    assert Box(2) == Box(2)
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box({'a': 1}) == Box({'a': 1})

    assert Box(None) != Box(True)
    assert Box(True) != Box(False)
    assert Box(False) != Box('test')
    assert Box('test') != Box(2)
    assert Box(2) != Box([1, 2, 3])
    assert Box([1, 2, 3]) != Box({'a': 1})
    assert Box({'a': 1}) != Box(None)

# Unit

# Generated at 2022-06-24 00:01:38.621810
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # given
    left_box = Box(3)
    right_box = Box('3')

    # when
    result = left_box == right_box
    # then
    assert not result

    # given
    left_box = Box(3)
    right_box = Box(3)

    # when
    result = left_box == right_box
    # then
    assert result



# Generated at 2022-06-24 00:01:39.981915
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    validation = Box(1).to_validation()
    assert validation == Validation.success(1)

# Generated at 2022-06-24 00:01:42.142451
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Success, Failure

    assert Success('foo').to_box() == Box('foo')
    assert Failure(None).to_box() == Box(None)


# Generated at 2022-06-24 00:01:43.414170
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:01:47.103191
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.validation import Validation
    from pymonet.box import Box

    assert Box(2).ap(Box(lambda x: x + 1)) == Box(3)

    def plus(value):
        return value + 1

    f = Box(plus)
    g = Box(3)

    assert f.ap(g) == Box(4)

    assert Validation.success(plus).ap(g) == Validation.success(4)

# Generated at 2022-06-24 00:01:50.183929
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(10) == Box(10)
    assert Box('test') != Box(10)
    assert Box([1, 2, 3]) != Box('test')



# Generated at 2022-06-24 00:01:51.840113
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:01:53.955687
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:01:56.874410
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:02:00.792798
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box(3) != Box(2)
    assert Box(4) != Box(2)
    assert Box(5) == Box(5)



# Generated at 2022-06-24 00:02:03.786978
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box

    :return: no return value
    """
    assert str(Box(True)) == "Box[value=True]"



# Generated at 2022-06-24 00:02:05.922274
# Unit test for method map of class Box
def test_Box_map():
    """Unit test for method map of class Box"""
    def increment(x):
        return x + 1

    assert Box(1).map(increment) == Box(2)



# Generated at 2022-06-24 00:02:07.100633
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(42)) == 'Box[value=42]'


# Generated at 2022-06-24 00:02:08.143227
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)



# Generated at 2022-06-24 00:02:12.051843
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box_value = Box(3)
    assert box_value.to_maybe() == Maybe.just(3)



# Generated at 2022-06-24 00:02:13.054000
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-24 00:02:17.900380
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    from pymonet.validation import Validation

    assert Box(5).bind(lambda x: x * 2) == 10
    assert Box(5).bind(lambda x: str(x)) == '5'
    assert Box(5).bind(lambda x: Validation.success(x)).value == 5



# Generated at 2022-06-24 00:02:19.878785
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(10)
    result = str(box)
    expected = 'Box[value=10]'
    assert result == expected


# Generated at 2022-06-24 00:02:22.741599
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(1)
    result = box.to_validation()
    expected = Validation.success(1)

    assert result == expected



# Generated at 2022-06-24 00:02:24.343096
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(1)
    assert box.bind(lambda x: x + 2) == 3



# Generated at 2022-06-24 00:02:25.852661
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:02:26.770077
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 'value') == Box('value').to_lazy()


# Generated at 2022-06-24 00:02:29.464762
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:02:38.811024
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box(None).to_either() == Right(None)
    assert Box([]).to_either() == Right([])
    assert Box('').to_either() == Right('')
    assert Box(tuple()).to_either() == Right(tuple())
    assert Box(set()).to_either() == Right(set())
    assert Box(dict()).to_either() == Right(dict())
    assert Box(False).to_either() == Right(False)
    assert Box(5).to_either() == Right(5)
    assert Box('foo').to_either() == Right('foo')



# Generated at 2022-06-24 00:02:41.570756
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)

# Generated at 2022-06-24 00:02:47.852533
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    from pymonet.functor import Functor

    f = Functor.identity  # Identity functor

    # Test when given functor argument is Identity functor
    test_map_id = Box('test').map(f)
    assert isinstance(test_map_id, Box)  # Test if result is instance of Box
    assert test_map_id.value == 'test'  # Test if result has mapped value

    # Test when given functor argument is constant
    test_map_constant = Box('test').map(f.constant('test2'))
    assert test_map_constant.value == 'test2'



# Generated at 2022-06-24 00:02:49.482202
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    box = Box(1)
    assert(box.to_try() == Try(1, is_success=True))


# Generated at 2022-06-24 00:02:51.725645
# Unit test for method to_try of class Box
def test_Box_to_try():
    box = Box(123)
    assert box.to_try() == Try(123, is_success=True)

# Generated at 2022-06-24 00:02:53.669035
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(True).to_maybe() == Maybe.just(True)



# Generated at 2022-06-24 00:02:57.828443
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(3).to_lazy()
    assert result.is_folded() == False
    assert result.unwrap()() == 3
    assert result.unwrap()() == 3


# Generated at 2022-06-24 00:02:59.860965
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation().value == [1]
    assert Box("a").to_validation().value == ["a"]

# Generated at 2022-06-24 00:03:01.082278
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-24 00:03:07.257748
# Unit test for method __str__ of class Box
def test_Box___str__():
    from pymonet.monad_try import Try

    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(1).map(lambda x: x + 1)) == 'Box[value=2]'
    assert str(Box('abc')) == 'Box[value=abc]'
    assert str(Box(Try.unit(1)).map(lambda x: x + 1)) == 'Box[value=2]'



# Generated at 2022-06-24 00:03:08.613575
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(10).to_maybe() == Maybe(10)


# Generated at 2022-06-24 00:03:12.421374
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Tests Box to_validation method.
    """
    assert Box[int](5).to_validation().is_success()
    assert Box[int](5).to_validation().is_failure() is not True
    assert Box[int](5).to_validation().value == 5

# Generated at 2022-06-24 00:03:17.949559
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Failure
    from pymonet.validation import Failure as ValidationFailure

    b1 = Box(1)
    b2 = Box(1)
    b3 = Box(2)
    b4 = Try(1, is_success=True)
    b5 = Failure('test')
    b6 = ValidationFailure('test')

    assert b1 == b2
    assert b1 != b3
    assert b1 != b4
    assert b1 != b5
    assert b1 != b6



# Generated at 2022-06-24 00:03:19.574677
# Unit test for method map of class Box
def test_Box_map():
    result = Box(4).map(lambda x: x ** 2)

    assert result == Box(16)



# Generated at 2022-06-24 00:03:20.873501
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:03:24.882602
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:03:30.188063
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    box1 = Box(1)
    box2 = Box(2)

    assert box1 != box2
    assert box1 != 1
    assert box1 != None
    assert box1 != Try(1)
    assert box1 != Validation.success(1)
    assert box1 == Box(1)
    assert box1 == box1



# Generated at 2022-06-24 00:03:32.612481
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-24 00:03:40.829366
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box('abc') == Box('abc')
    assert Box(1) != Box(2)
    assert Box(2) != Box(2.0)
    assert Box(2) != Box('abc')
    assert Box('abc') != Box(True)
    assert Box(True) != Box('True')
    assert Box(False) == Box(False)
    assert Box(None) == Box(None)
    assert Box(False) != Box(True)
    assert Box(None) != Box('None')
    assert Box(None) != Box(False)



# Generated at 2022-06-24 00:03:43.750301
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(42).bind(lambda x: x + 1) == 43
    assert Box('42').bind(lambda x: int(x) + 1) == 43



# Generated at 2022-06-24 00:03:46.550355
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box = Box(1)
    assert box.value == 1


# Generated at 2022-06-24 00:03:50.652636
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box('cat')

    def mapper(value: str) -> str:
        return '{} {}'.format(value, value)

    assert box.bind(mapper) == 'cat cat'

