

# Generated at 2022-06-23 23:53:50.788817
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1, 'Box have to be created with value 1'  # pragma: no cover


# Generated at 2022-06-23 23:54:01.769115
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.maybe import Nothing
    import pytest

    assert Box(1).to_either() == Right(1)
    assert Box('abc').to_either() == Right('abc')
    assert Box(None).to_either() == Right(None)
    assert Box([]).to_either() == Right([])
    assert Box(True).to_either() == Right(True)
    assert Box(Try(ValueError('bad'))).to_either() == Right(Try(ValueError('bad'), is_success=False))

# Generated at 2022-06-23 23:54:03.636453
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * x) == Box(4)


# Generated at 2022-06-23 23:54:09.035417
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    print('Test for method __eq__ in class Box')
    box1 = Box(3)
    box2 = Box(3)

    print('Box1: {}'.format(box1))
    print('Box2: {}'.format(box2))

    assert box1 == box2



# Generated at 2022-06-23 23:54:15.115324
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    test_box = Box(1)
    assert test_box.to_maybe() == Box(1).to_either()
    assert test_box.to_maybe() == Box(1).to_lazy()
    assert test_box.to_maybe() == Box(1).to_try()
    assert test_box.to_maybe() == Box(1).to_validation()


# Generated at 2022-06-23 23:54:16.887349
# Unit test for method __str__ of class Box
def test_Box___str__():
    value = Box(5)
    assert str(value) == 'Box[value=5]'


# Generated at 2022-06-23 23:54:18.762749
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(3)) == 'Box[value=3]'  # pragma: no cover

# Generated at 2022-06-23 23:54:25.386849
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(2).bind(lambda x: x ** 2) == 4

# Generated at 2022-06-23 23:54:31.384307
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box("Hello").to_either() == "Hello"

# Generated at 2022-06-23 23:54:40.970011
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    class A():
        def __init__(self, a):
            self.a = a

        def __eq__(self, other):
            if isinstance(other, A):
                return self.a == other.a
            return False

        def __call__(self):
            return self.a

    assert Box(A(2)).ap(Right(lambda x: A(x + 1))) == Right(A(3))
    assert Box(A(2)).ap(Maybe.just(lambda x: A(x + 1))) == Maybe.just(A(3))



# Generated at 2022-06-23 23:54:42.792787
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box = Box(4)

    assert box.value == 4


# Generated at 2022-06-23 23:54:46.335507
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)



# Generated at 2022-06-23 23:54:48.882600
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)
    assert Box(1) != 1
    assert Box(1) != Box(0)



# Generated at 2022-06-23 23:54:52.057666
# Unit test for method map of class Box
def test_Box_map():
    """
    Test Box class method map.
    """
    map_box = Box(lambda value: value * 2)
    box = Box(1)
    new_box = box.map(map_box.value)
    assert new_box == Box(2)


# Generated at 2022-06-23 23:54:59.270845
# Unit test for method bind of class Box
def test_Box_bind():
    # Initialize Box's list
    boxes = [Box('test_Box_bind'), Box('test_Box_bind'), Box(''), Box(None)]

    # Check that length of all boxes is equal
    assert list(map(len, boxes)) == list(map(lambda box: box.bind(len), boxes))

    # Check that bool of all boxes is equal
    assert list(map(bool, boxes)) == list(map(lambda box: box.bind(bool), boxes))

    # Check that reversed values of all boxes is equal
    assert list(map(lambda x: x[::-1], boxes)) == list(map(lambda box: box.bind(lambda x: x[::-1]), boxes))

    # Check that reversed values of all boxes is equal

# Generated at 2022-06-23 23:55:03.551005
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().value() == 5
    assert Box('Hello').to_lazy().value() == 'Hello'


# Generated at 2022-06-23 23:55:07.434334
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    value = 42
    box = Box(value)
    assert box.to_validation() == Validation.success(value)

# Generated at 2022-06-23 23:55:09.883081
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    # Should return successfull Validation monad with previous value
    assert Box('Hello').to_validation() == Validation('Hello', [])

# Generated at 2022-06-23 23:55:13.573090
# Unit test for method ap of class Box
def test_Box_ap():
    assert (
        Box(lambda x: x + 4)
        .ap(Box(3))
        .value == 7
    )

    assert (
        Box(lambda x: x * 3)
        .ap(Box(4))
        .value == 12
    )



# Generated at 2022-06-23 23:55:14.849488
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box('foo').to_either() == Right('foo')



# Generated at 2022-06-23 23:55:22.450104
# Unit test for method map of class Box
def test_Box_map():
    """
    Test for map method on Box monad
    """
    assert Box(1).map(lambda x: x + 2) == Box(3)
    assert Box(2).map(lambda x: x * 3) == Box(6)
    assert Box(-2).map(lambda x: x * 3) == Box(-6)
    assert Box(5).map(lambda x: x / 2) == Box(2.5)
    assert Box(1).map(lambda x: x + 2).value == 3
    assert Box(2).map(lambda x: x * 3).value == 6
    assert Box(-2).map(lambda x: x * 3).value == -6
    assert Box(5).map(lambda x: x / 2).value == 2.5



# Generated at 2022-06-23 23:55:31.260177
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(12)) == 'Box[value=12]'
    assert str(Box(2.2)) == 'Box[value=2.2]'
    assert str(Box('hello')) == "Box[value=hello]"
    assert str(Box(lambda x: x ** x)) == "Box[value=<function <lambda> at 0x7f8a1b1a3378>]"  # noqa
    assert str(Box(True)) == "Box[value=True]"
    assert str(Box((1, 2, 3))) == "Box[value=(1, 2, 3)]"


# Unit tests for method __eq__ of class Box

# Generated at 2022-06-23 23:55:35.060179
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.nothing import Nothing

    assert Box(42).to_maybe() == Maybe(42)
    assert Box(None).to_maybe() == Nothing

# Unit test to_lazy of class Box

# Generated at 2022-06-23 23:55:38.180364
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy_box = box.to_lazy()
    assert lazy_box == Lazy(lambda: 1)
    assert lazy_box.force() == 1


# Generated at 2022-06-23 23:55:45.753005
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation

    assert Lazy.unit(Box(42)).unit() == Lazy.unit(42).unit()
    assert Lazy.unit(Box(42)).bind(lambda x: x + 1) == Lazy.unit(42).bind(lambda x: x + 1)
    assert Lazy.unit(Box(42)).bind(lambda x: x + 1).bind(lambda x: x + 1) == \
        Lazy.unit(42).bind(lambda x: x + 1).bind(lambda x: x + 1)

    assert Lazy.unit(Box(42)).to_maybe() == Maybe.just(42)
    assert Lazy.unit(Box(42)).to_either() == Either.right(42)
    assert Lazy

# Generated at 2022-06-23 23:55:48.090959
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(42).to_validation() == Validation.success(42)


# Generated at 2022-06-23 23:55:58.992705
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(2).bind(lambda x: x ** 2) == 4
    assert Box(2).bind(lambda x: x ** 2).bind(lambda x: x + 1) == 5
    assert Box(3).bind(lambda x: x ** 3).bind(lambda x: x + 2).bind(lambda x: x * 2) == 156
    assert Box(2).bind(lambda x: x ** 2).bind(lambda x: Maybe.just(x + 2)).bind(lambda x: x * 2) == Maybe.just(12)
    assert Box(3).bind(lambda x: x ** 3).bind

# Generated at 2022-06-23 23:56:00.966078
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(4)) == 'Box[value=4]'


# Generated at 2022-06-23 23:56:02.524904
# Unit test for constructor of class Box
def test_Box():
    assert Box('hello') == Box('hello')

# Coverage test for class Box

# Generated at 2022-06-23 23:56:09.816495
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(None).to_maybe() == Maybe(None)
    assert Box(None).to_maybe() == Maybe.none()
    assert Box(None).to_maybe() != Maybe.just(None)
    assert Box(1).to_maybe() == Maybe(1)
    assert Box(1).to_maybe() != Maybe.just(1)
    assert Box(1).to_maybe() != Maybe.none()



# Generated at 2022-06-23 23:56:19.203258
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Test for __str__ method in class Box.

    :returns: None
    :rtype: None
    :raises AssertionError: if test failed
    """

    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('asd')) == 'Box[value=asd]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(3.14)) == 'Box[value=3.14]'
    assert str(Box([1, 2])) == 'Box[value=[1, 2]]'
    assert str(Box({'a': 1, 'b': 2})) == "Box[value={'a': 1, 'b': 2}]"


# Unit test

# Generated at 2022-06-23 23:56:25.281777
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x+1).ap(Box(1)) == Box(2)
    assert Box(lambda x: x+1).ap(Box(0)) == Box(1)


# Generated at 2022-06-23 23:56:27.807763
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    assert Box(1).to_either() == Left(1)
    assert Box('foo').to_either() == Right('foo')


# Generated at 2022-06-23 23:56:37.535566
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(True).to_either() == Right(True)
    assert Box(False).to_either() == Right(False)
    assert Box(1).to_either() == Right(1)
    assert Box('a').to_either() == Right('a')
    assert Box(1.1).to_either() == Right(1.1)
    assert Box([1, 2]).to_either() == Right([1, 2])
    assert Box({'a': 1}).to_either() == Right({'a': 1})
    assert Box((1,)).to_either() == Right((1,))



# Generated at 2022-06-23 23:56:44.037430
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, Failure

    try_from_box = Box(4).to_try()
    try_failure = Failure(ValueError('some error'))

    assert isinstance(try_from_box, Try)
    assert try_from_box == Try(4, is_success=True)
    assert try_from_box != Try(4, is_success=False)
    assert try_from_box != try_failure

# Generated at 2022-06-23 23:56:49.536455
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)
    assert Box(lambda x: x * 2).ap(Box(3)) == Box(6)
    assert Box(lambda x: x * 2).ap(Box(4)) == Box(8)
    assert Box(lambda x: x * 2).ap(Box(5)) == Box(10)



# Generated at 2022-06-23 23:56:54.413715
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    box1 = Box(lambda x: x + 1)
    box2 = Box(1)

    assert box1.ap(box2) == Box(2)

# Generated at 2022-06-23 23:57:00.402976
# Unit test for method map of class Box
def test_Box_map():
    def mapper(value):
        return (value + 10)

    box = Box(10)
    assert box.map(mapper) == Box(20), 'test Box map - not equal'



# Generated at 2022-06-23 23:57:03.657849
# Unit test for method ap of class Box
def test_Box_ap():
    test_box = Box(lambda x: x + 1)
    another_box = Box(100)
    result = test_box.ap(another_box)
    expected = Box(101)

    assert result == expected

# Generated at 2022-06-23 23:57:08.138534
# Unit test for method to_try of class Box
def test_Box_to_try():
    box = Box(4)
    result = box.to_try()

    assert isinstance(result, Try)
    assert result.is_success()



# Generated at 2022-06-23 23:57:11.719478
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:57:14.500194
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box

    """
    assert Box('test').to_either() == Box('test').to_maybe().to_either()

# Generated at 2022-06-23 23:57:18.039701
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test Box.to_either method.
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box(None).to_either() == Right(None)



# Generated at 2022-06-23 23:57:22.892333
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    value = 7
    actual_result = Box(value).to_maybe()
    expected_result = Maybe.just(value)

    assert actual_result == expected_result


# Generated at 2022-06-23 23:57:27.205479
# Unit test for method map of class Box
def test_Box_map():
    """
    Test for method map of class Box
    """
    from pymonet.monad_try import Try

    assert Box(5).map(lambda x: x * x) == Box(25)
    assert Box(5).map(lambda x: x + 10) == Box(15)
    assert Box(5).map(lambda x: Try(x * x)) == Box(Try(25))


# Generated at 2022-06-23 23:57:28.219463
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-23 23:57:30.636449
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Checks if Box is converted to successfull Try.
    """
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:57:31.880650
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:57:35.241342
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:57:39.181523
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    def add(a):
        return lambda b: a + b

    assert Box(2).ap(Box(10)).value == 12
    assert Box(add).ap(Box(1)).ap(Box(2)).value == 3

# Generated at 2022-06-23 23:57:40.927630
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x+1) == Box(2)
    assert Box('1').map(lambda x: x+'A') == Box('1A')
    assert Box(1).map(lambda x: x+'A') == Box('1A')



# Generated at 2022-06-23 23:57:43.379392
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe

    assert Box(lambda x: x + 1).ap(Maybe(5)).value == Maybe(5).bind(lambda x: Maybe(lambda x: x + 1).value(x))

# Generated at 2022-06-23 23:57:47.451483
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.try_ import Try

    assert isinstance(Box(1).bind(lambda value: value + 1), int)
    assert Box(1).bind(lambda value: value + 1) == 2
    assert isinstance(Box(1).bind(lambda value: Try(value + 1, is_success=True)), Try)



# Generated at 2022-06-23 23:57:57.002026
# Unit test for constructor of class Box
def test_Box():
    from pymonet.test_utils import assert_equal
    from pymonet.test_utils import assert_true
    from pymonet.test_utils import assert_false

    assert_equal(str(Box(1)), 'Box[value=1]')
    assert_equal(Box(1), Box(1))
    assert_true(Box(1) == Box(1))
    assert_false(Box(1) != Box(1))
    assert_false(Box(1) == Box(2))
    assert_true(Box(1) != Box(2))


# Unit tests for map function of class Box

# Generated at 2022-06-23 23:57:59.089888
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy()



# Generated at 2022-06-23 23:58:01.971947
# Unit test for constructor of class Box
def test_Box():
    x = Box('some_value')
    assert x.value == 'some_value'

    assert x == Box('some_value')

    assert str(x) == 'Box[value=some_value]'



# Generated at 2022-06-23 23:58:06.276728
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    try:
        lazy = Box(1).to_lazy()
        assert isinstance(lazy, Lazy)
        assert isinstance(lazy.value(), Try)
        assert lazy.value().value == 1
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-23 23:58:09.186346
# Unit test for method to_try of class Box
def test_Box_to_try():
    value = 3
    bx = Box(value)

    assert bx.to_try() == Try(value)

# Generated at 2022-06-23 23:58:16.226890
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    def test(x: object, y: object) -> None:
        assert Box(x).to_validation() == Validation.success(y)

    test(None, None)
    test(1, 1)
    test((1,2), (1,2))
    test([1,2], [1,2])
    test(1.0, 1.0)
    test(Validation.success(1), Validation.success(1))


# Generated at 2022-06-23 23:58:22.049947
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).to_either()
    assert Box('a').to_either() == Box('a').to_either()
    assert Box(1).to_either() != Box('a').to_either()



# Generated at 2022-06-23 23:58:27.616913
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test either to_try method.
    """
    assert Box(True).to_try().bind_failure(lambda _: False) == True
    assert Box(False).to_try().bind_failure(lambda _: True) == True


# Generated at 2022-06-23 23:58:29.564877
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda x: x * 2) == Box(20)



# Generated at 2022-06-23 23:58:30.157265
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().value() == 42


# Generated at 2022-06-23 23:58:30.955732
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either
    assert Box(99).to_either() == Either.right(99)

# Generated at 2022-06-23 23:58:35.983323
# Unit test for method ap of class Box
def test_Box_ap():
    """ Unit test for method ap of class Box """
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Box(lambda x: x + 1).ap(Box(1)).value == 2
    assert Box(lambda x: x + 1).ap(Box(Maybe(1))).value == Maybe(2)
    assert Box(lambda x: x + 1).ap(Try(1)).value == Try(2, is_success=True)



# Generated at 2022-06-23 23:58:37.497689
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:58:40.147573
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    result = Box(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 1



# Generated at 2022-06-23 23:58:45.479916
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    l = Box('a').to_lazy()

    assert isinstance(l, Lazy)

    assert l.is_folded is False

    assert l.value() == 'a'



# Generated at 2022-06-23 23:58:47.295487
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 2) == Box(4)



# Generated at 2022-06-23 23:58:51.273307
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert 'Box[value=42]' == str(Box(42))


# Generated at 2022-06-23 23:58:54.114457
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Tests method bind of Box class.

    :returns: Nothing
    :rtype: None
    """
    x = Box(5)
    assert x.bind(lambda v: v + 3) == 8


# Generated at 2022-06-23 23:58:59.704278
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for __str__ method of class Box

    :returns: nothing
    :rtype: None
    """
    from typing import Callable

    from pymonet.monad import identity

    # Tested method
    func: Callable[[Box[int]], str] = Box.__str__

    # Tested object
    obj: Box[int] = Box(1)

    # Expected result
    expected: str = 'Box[value=1]'

    # Actual result
    actual = func(obj)

    assert actual == expected, \
        'Expected {}, but got {}'.format(expected, actual)


# Generated at 2022-06-23 23:59:02.218146
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    '''
    Test method to_validation of class Box.
    '''

    # Given
    box = Box(10)

    # When
    validation = box.to_validation()

    # Then
    assert validation._success == [10]
    assert validation._failure == []


# Generated at 2022-06-23 23:59:08.210741
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: no cover
    """
    Test to_lazy method of class Box.
    """
    x = Box(1).to_lazy().map(
        lambda x: x + 2
    ).get()

    assert x == 3


# Generated at 2022-06-23 23:59:09.303061
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-23 23:59:11.064061
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(10).to_maybe().is_just() == True

    assert Box('hello').to_maybe().is_just() == True


# Generated at 2022-06-23 23:59:14.312006
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.just(None)



# Generated at 2022-06-23 23:59:17.707839
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.just(None)



# Generated at 2022-06-23 23:59:19.606660
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, True)

# Generated at 2022-06-23 23:59:21.709677
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Right(1) == Box(1).to_either()

# Generated at 2022-06-23 23:59:24.430377
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-23 23:59:26.869816
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-23 23:59:31.606232
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(11).to_either() == Right(11)
    assert Box(11).to_either() != Right(23)
    assert Box(11).to_either() != 'Right(11)'


# Generated at 2022-06-23 23:59:34.070684
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('Test') == Box('Test')
    assert Box('Test') != 'Test'
    assert str(Box('Test')) == 'Box[value=Test]'


# Generated at 2022-06-23 23:59:35.834423
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-23 23:59:37.556613
# Unit test for method bind of class Box
def test_Box_bind():
    value = Box(42)
    assert value.bind(lambda x: x + 1) == 43



# Generated at 2022-06-23 23:59:40.770406
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """

    assert Lazy(lambda: 1) == Box(1).to_lazy()
    assert Lazy(lambda: 'hello') == Box('hello').to_lazy()
    assert Lazy(lambda: 1.2) == Box(1.2).to_lazy()


# Generated at 2022-06-23 23:59:41.674614
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1)

# Generated at 2022-06-23 23:59:42.543842
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('123')) == 'Box[value=123]'

# Generated at 2022-06-23 23:59:48.638958
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import EmptyError
    from pymonet.monad_try import TypeError

    assert Box(1).to_try() == Try(1)
    assert Box(None).to_try() == Try(None)
    assert Box(1).to_try() != Try(None)
    assert Box(None).to_try() != Try(1)

    assert Box(1).to_try() != Try(1, is_success=False)
    assert Box(None).to_try() != Try(None, is_success=False)
    assert Box(1).to_try() != Try(None, is_success=False)
    assert Box(None).to_try() != Try(1, is_success=False)


# Generated at 2022-06-23 23:59:51.547497
# Unit test for method to_try of class Box
def test_Box_to_try():
    value = 'hello world!'
    box = Box(value)
    assert box.to_try() == Try(value, is_success=True)


# Generated at 2022-06-23 23:59:58.026833
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)

    assert box1.__eq__(box2) is True
    assert box1.__eq__(box3) is False
    assert box1.__eq__(None) is False


# Generated at 2022-06-24 00:00:00.964697
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(3).to_maybe() == Maybe.just(3)
    assert Box('string').to_maybe() == Maybe.just('string')


# Generated at 2022-06-24 00:00:02.431168
# Unit test for method ap of class Box
def test_Box_ap():
    def sum(a):
        return a + 1

    assert Box(sum).ap(Box(5)) == Box(6)

# Generated at 2022-06-24 00:00:04.118687
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1).bind(lambda x: x + 2) == 3

# Generated at 2022-06-24 00:00:11.842133
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box(1.0) == Box(1.0)
    assert Box((1, 2, 3)) == Box((1, 2, 3))
    assert Box({1, 2, 1}) == Box({1, 2, 1})
    assert Box({'a': 1, 'b': 2}) == Box({'a': 1, 'b': 2})



# Generated at 2022-06-24 00:00:17.063228
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)
    assert Box(-10).to_try() == Try(-10, is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)
    assert Box("").to_try() == Try("", is_success=True)
    assert Box("text").to_try() == Try("text", is_success=True)

# Generated at 2022-06-24 00:00:19.255059
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box_value = Box[object](object)
    assert box_value.to_either() is Right(object)


# Generated at 2022-06-24 00:00:26.756048
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.exceptions import MonetValueError

    assert Box(3).to_try() == Try(3, is_success=True)

    assert Box(3).map(lambda x: 1 / x).to_try() == \
        Try(1 / 3, is_success=True)

    assert Box(3).map(
        lambda x: (1 / x) if x != 0 else raise_(MonetValueError('division by zero'))
    ).to_try() == Try(1 / 3, is_success=True)


# Generated at 2022-06-24 00:00:31.767398
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-24 00:00:36.461109
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    boxes_1 = [Box(1), Box(2), Box(3), Box("a"), Box("b"), Box("c"), Box("a")]
    boxes_2 = [Box(1), Box(2), Box(3), Box("a"), Box("b"), Box("c"), Box("a")]

    assert boxes_1 == boxes_2
    assert not (boxes_1 == Box("a"))

    boxes_1.append(Box("d"))

    assert boxes_1 != boxes_2



# Generated at 2022-06-24 00:00:40.968561
# Unit test for method map of class Box
def test_Box_map():
    import random

    random_value = random.randint(1, 10)
    box = Box(random_value)
    multiplied_value = box.map(lambda x: x * 2)

    assert box == Box(random_value)
    assert multiplied_value == Box(2 * random_value)


# Generated at 2022-06-24 00:00:46.180830
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(42)) == 'Box[value=42]'
    assert str(Box([1, 2, 3, 4])) == 'Box[value=[1, 2, 3, 4]]'
    assert str(Box('hello')) == 'Box[value=hello]'



# Generated at 2022-06-24 00:00:48.924469
# Unit test for constructor of class Box
def test_Box():
    from pymonet.maybe import Maybe

    assert Box(Maybe.just(1)) == Box(Maybe.just(1))
    assert Box(Maybe.nothing()) != Box(Maybe.just(1))



# Generated at 2022-06-24 00:00:52.045324
# Unit test for method map of class Box
def test_Box_map():
    test_data = (1, 2, 3)

    def square(num):
        return num ** 2
    actual = Box(2).map(square)
    expected = Box(4)

    assert actual == expected


# Generated at 2022-06-24 00:00:55.311934
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    value = 'string'
    box = Box(value)
    assert isinstance(box.to_try(), Try)
    assert isinstance(box.to_try().value, str)
    assert box.to_try().value == value


# Generated at 2022-06-24 00:00:56.971175
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:00:59.065127
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-24 00:01:01.843175
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box.
    """
    from pymonet.monad_try import Try

    assert Box(100).to_try() == Try(100, is_success=True)



# Generated at 2022-06-24 00:01:05.477396
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x ** 2).ap(Box(2)) == Box(4)
    assert Box(lambda x: x ** 2).ap(Box(3)) == Box(9)
    assert Box(lambda x: x ** 2).ap(Box(4)) == Box(16)
    assert Box(lambda x: x ** 2).ap(Box(5)) == Box(25)

# Generated at 2022-06-24 00:01:08.201709
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(2).to_try() == Try(2, is_success=True)



# Generated at 2022-06-24 00:01:09.617865
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().get() == 42

# Generated at 2022-06-24 00:01:11.690801
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-24 00:01:13.804019
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(True) == Box(True)
    assert Box(True) != Box(False)
    assert Box(True) != Box('True')


# Generated at 2022-06-24 00:01:18.094286
# Unit test for method ap of class Box
def test_Box_ap():
    # Given
    box = Box(lambda x: x * 2)
    box_1 = Box(10)

    # When
    result = box.ap(box_1)

    # Then
    assert result == Box(20)

# Generated at 2022-06-24 00:01:20.700580
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    init_box = Box(lambda x: x + 1)
    test_box = Box(3)
    assert init_box.ap(test_box) == Box(4)

# Generated at 2022-06-24 00:01:21.392466
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box("test").to_lazy().value() == "test"

# Generated at 2022-06-24 00:01:23.636152
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box('abc').to_maybe() == Maybe.just('abc')
    assert Maybe.just('abc') == Box('abc').to_maybe()



# Generated at 2022-06-24 00:01:29.977155
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import is_right
    from pymonet.either import Right
    from pymonet.either import fold_right

    assert is_right(Box(0).to_either())
    assert fold_right(lambda a: lambda: a + 5, 0, Box(0).to_either()) == 5  # type: ignore



# Generated at 2022-06-24 00:01:36.539726
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test for method ap of class Box
    """
    from pymonet.functor import Functor

    def plus(x):
        return lambda y: x + y

    def minus(x):
        return lambda y: x - y

    value_1 = Box(1)
    value_2 = Box(2)
    function_1 = Box(plus)

    assert Functor.ap(value_1, function_1).value == 3
    assert value_1.ap(function_1).value == 3
    assert function_1.ap(value_1).value == 3

    function_2 = Box(minus)
    assert value_1.ap(function_2).value == -1
    assert value_2.ap(function_2).value == 0

# Generated at 2022-06-24 00:01:37.343289
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    assert Box(1).to_maybe() == Just.unit(1)


# Generated at 2022-06-24 00:01:39.906211
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != Box('1')
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) == Box(1)


# Generated at 2022-06-24 00:01:44.830127
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    val1 = 1
    assert Box(val1).to_either() == Right(val1), "Incorrect result of Box(1).to_either()"
    val2 = 'foo'
    assert Box(val2).to_either() == Right(val2), "Incorrect result of Box('foo').to_either()"
    val3 = Left('bar')
    assert Box(val3).to_either() == Right(val3), "Incorrect result of Box(Left('bar')).to_either()"
    val4 = Right(1)
    assert Box(val4).to_either() == Right(val4), "Incorrect result of Box(Right(1)).to_either()"



# Generated at 2022-06-24 00:01:47.828091
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    box = Box(123)

    # when
    lazy = box.to_lazy()

    # then
    assert lazy.value() == box.value

# Generated at 2022-06-24 00:01:50.598501
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(42)
    result_box = box.bind(lambda i: Box(i + 1))
    assert result_box.value == 43



# Generated at 2022-06-24 00:01:52.286258
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box('x').to_lazy().value() == 'x'

# Generated at 2022-06-24 00:01:57.929542
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(5) == Box(5)
    assert Box('5') == Box('5')
    assert Box(5) != Box(3)
    assert Box('5') != Box('3')
    assert 'Box[value=3]' == str(Box(3))
    assert 'Box[value="3"]' == str(Box('3'))

# Generated at 2022-06-24 00:02:01.783515
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for ap method for Box class.
    """

    assert Box(lambda a: a*2).ap(Box(2)) == Box(4)
    assert Box(lambda a: a*2).ap(Box(2)) != Box(5)



# Generated at 2022-06-24 00:02:02.745467
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(True).bind(lambda x: x).value == True


# Generated at 2022-06-24 00:02:03.952381
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().value() == 10

# Generated at 2022-06-24 00:02:05.135967
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    arg = Box(1)
    assert arg == Box(1)



# Generated at 2022-06-24 00:02:06.565148
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-24 00:02:09.424361
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-24 00:02:11.453142
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    assert box.to_maybe() == Maybe.just(1)

    box = Box(None)
    assert box.to_maybe().is_nothing()


# Generated at 2022-06-24 00:02:14.705312
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    value = 'Hello'
    box = Box(value)
    assert box.__str__() == 'Box[value={}]'.format(value)


# Generated at 2022-06-24 00:02:17.033737
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)

# Generated at 2022-06-24 00:02:23.045196
# Unit test for method to_try of class Box
def test_Box_to_try():
    from unittest import TestCase, main

    from pymonet.monad_try import Try

    assert isinstance(Box(1).to_try(), Try)
    assert Box(1).to_try().value == 1

    assert isinstance(Box(1).to_try(), Try)
    assert Box(None).to_try().value is None

    class SomeClass:
        def __eq__(self, other):
            return True

    instance_of_some_class = SomeClass()
    assert isinstance(Box(instance_of_some_class).to_try(), Try)
    assert Box(instance_of_some_class).to_try().value is instance_of_some_class

    assert isinstance(Box(list()).to_try(), Try)
    assert Box(list()).to_try().value == []

   

# Generated at 2022-06-24 00:02:25.292420
# Unit test for method map of class Box
def test_Box_map():
    box = Box(1)
    result = box.map(lambda x: x + 1)
    assert isinstance(result, Box)
    assert result == Box(2)


# Generated at 2022-06-24 00:02:26.689957
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)


# Generated at 2022-06-24 00:02:29.399355
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:02:31.188601
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:02:32.896170
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x * 3) == 3



# Generated at 2022-06-24 00:02:34.744118
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1



# Generated at 2022-06-24 00:02:36.128253
# Unit test for constructor of class Box
def test_Box():
    b = Box(5)
    assert b.value == 5


# Generated at 2022-06-24 00:02:46.385036
# Unit test for method ap of class Box
def test_Box_ap():
    import pymonet.validation as validate
    import pymonet.either as either

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    assert Box(add_one).ap(Box(1)) == Box(2)

    assert Box(add_two).ap(validate.Validation.success(1)).value == 3

    assert Box(add_three).ap(either.Right(1)).value == 4

    # assert Box(add_four).ap(Lazy(lambda: 1)).value == 5

# Generated at 2022-06-24 00:02:53.050094
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda el: el + 2).ap(Box(2)).value == 4
    import pymonet.maybe as May
    assert May.just(lambda el: el + 2).ap(May.just(2)).value == 4
    import pymonet.lazy as Laz
    assert Laz.eval(Laz.just(lambda el: el + 2).ap(Laz.just(2))) == 4
    import pymonet.either as Eit
    assert Eit.Left(lambda el: el + 2).ap(Eit.Left(2)).value == 4
    import pymonet.monad_try as Tr
    assert Tr.Try(lambda el: el + 2, is_success=True).ap(Tr.Try(2, is_success=True)).value == 4
    import pymonet.validation as Val
    assert Val

# Generated at 2022-06-24 00:02:55.020231
# Unit test for method map of class Box
def test_Box_map():

    assert Box(2).map(lambda x: x * x) == Box(4)


# Generated at 2022-06-24 00:02:56.859133
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    x = 1  # type: int
    lazy = Box(x).to_lazy()  # type: Lazy[Callable[[], int]]

    assert lazy.is_done() is not True
    assert lazy.map(lambda x: x + 2).value() == 3

# Generated at 2022-06-24 00:03:02.053937
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(True).to_try() == Try(True, is_success=True)
    assert Box(2).to_try() == Try(2, is_success=True)
    assert Box('3').to_try() == Try('3', is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)


# Generated at 2022-06-24 00:03:06.073984
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x + 1) == Box(4)
    assert Box(6).map(lambda x: x + 1) == Box(7)
    assert Box('hello').map(lambda x: x + '!') == Box('hello!')



# Generated at 2022-06-24 00:03:08.289121
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(42).value == 42
    assert Box('string').value == 'string'



# Generated at 2022-06-24 00:03:09.997211
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) is not Box(1)


# Generated at 2022-06-24 00:03:12.367849
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:03:14.089976
# Unit test for method map of class Box
def test_Box_map():
    def inc(x: int) -> int:
        return x + 1

    assert Box(0).map(inc) == Box(1)



# Generated at 2022-06-24 00:03:16.193993
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:03:18.928959
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('2') == Box('2')
    assert Box([3]) == Box([3])

    assert Box(1) != Box(2)
    assert Box('2') != Box('3')
    assert Box([3]) != Box([4])



# Generated at 2022-06-24 00:03:20.232117
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(4).bind(lambda x: x + 1) == 5


# Generated at 2022-06-24 00:03:26.399548
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(lambda x: x + 1).bind(10) == 11
    assert Box(lambda x: x + 1).bind(-1) == 0
    assert Box(lambda x: x * 2).bind(2) == 4
    assert Box(lambda x: x * 2).bind(0.5) == 1



# Generated at 2022-06-24 00:03:28.816829
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    maybe: Maybe[int] = Box(100).to_maybe()
    assert maybe.value == 100



# Generated at 2022-06-24 00:03:31.452408
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method Box.bind
    """
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:03:33.387921
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-24 00:03:38.908711
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box
    """

    # Arrange
    test_value = 1
    box = Box(test_value)
    mapper = lambda value: value * 2

    # Act
    result = box.map(mapper)

    # Assert
    assert result.value == mapper(test_value)



# Generated at 2022-06-24 00:03:40.916399
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Test method __str__ of Box class.
    """
    assert str(Box(2)) == 'Box[value=2]'



# Generated at 2022-06-24 00:03:43.129319
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(10).to_validation() == Validation.success(10)


# Generated at 2022-06-24 00:03:44.681499
# Unit test for method bind of class Box
def test_Box_bind():
    a = Box(1)
    assert a.bind(lambda x: x + 1) == 2



# Generated at 2022-06-24 00:03:48.807014
# Unit test for method map of class Box
def test_Box_map():
    f = lambda x: x * 2
    x: Box[int] = Box(2)
    assert x.map(f) == Box(f(x.value))
