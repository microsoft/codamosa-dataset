

# Generated at 2022-06-23 23:53:51.078106
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try_success = Box(12).to_try()

    assert try_success == Try(12, is_success=True)

# Generated at 2022-06-23 23:53:52.928072
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """Unit test for method to_validation of class Box."""
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)

# Generated at 2022-06-23 23:53:56.153596
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Testing Box type ap method.
    """
    def add(x: int) -> int:
        return x + 1

    assert Box(add).ap(Box(1)).value == 2



# Generated at 2022-06-23 23:54:00.114778
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(0) == Box(0)
    assert Box(1) == Box(1)
    assert Box(0.0) == Box(0.0)
    assert Box('1') == Box('1')

    assert Box(0) != Box(1)
    assert Box(1) != Box(0)
    assert Box(0.0) != Box(1.1)
    assert Box('1') != Box('2')



# Generated at 2022-06-23 23:54:02.143785
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(10).to_box() == Box(10)



# Generated at 2022-06-23 23:54:06.628923
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.validation import Validation

    box = Box(lambda x: x ** 2)
    assert box.ap(Validation.success(5)) == Validation.success(25)



# Generated at 2022-06-23 23:54:09.261504
# Unit test for method to_try of class Box
def test_Box_to_try():
    value = 'value'
    box = Box(value)
    try_instance = box.to_try()
    assert try_instance.is_success()
    assert try_instance.get() == value

# Generated at 2022-06-23 23:54:11.964423
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-23 23:54:14.332022
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:54:16.456149
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).to_either()

# Generated at 2022-06-23 23:54:18.718781
# Unit test for method ap of class Box
def test_Box_ap():
    a = Box(1)
    b = Box(lambda x: x + 1)
    assert a.ap(b) == Box(2)

# Generated at 2022-06-23 23:54:21.781783
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Box.ap method unit test.
    """
    Box(Box(lambda x: x + 1)).ap(Box(Box(10))).value.value == 11


# Generated at 2022-06-23 23:54:22.875829
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(10).to_either() == Rig

# Generated at 2022-06-23 23:54:27.084068
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # arrange
    value1 = 'Some value 1'
    value2 = 'Some value 2'
    box1 = Box(value1)
    box2 = Box(value2)

    # act
    result1 = (box1 == box1)
    result2 = (box1 == box2)
    result3 = (box1 == value1)
    result4 = (box1 == value2)

    # assert
    assert result1
    assert not result2
    assert not result3
    assert not result4


# Generated at 2022-06-23 23:54:31.728577
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import *
    from pymonet.lazy import Lazy

    box = Box(1)
    val = box.to_lazy()

    assert isinstance(val, Lazy)
    assert val.is_folded() is False
    assert val.__value__() == 1
    assert val.fold(lambda: 2) == 1



# Generated at 2022-06-23 23:54:34.838074
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(None)
    assert box.to_validation() == Validation.success(None)



# Generated at 2022-06-23 23:54:38.732148
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():

    from pymonet.maybe import Maybe

    value = [1, 2]

    assert Box(value).to_maybe().bind(lambda x: Maybe.just(x)) == Maybe.just(value)



# Generated at 2022-06-23 23:54:41.888159
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for method bind of class Box.
    """
    assert Box(4).bind(lambda x: x + 1) == 5



# Generated at 2022-06-23 23:54:45.945035
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert (Box(100).to_maybe()) == Maybe.just(100)


# Generated at 2022-06-23 23:54:47.336910
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('foo') == Box('foo')

# Generated at 2022-06-23 23:54:49.046303
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(10).map(lambda x: x + 1) == Box(11)



# Generated at 2022-06-23 23:54:50.942177
# Unit test for method map of class Box
def test_Box_map():
    actual = Box('hello').map(lambda x: x + ' world')
    expected = Box('hello world')
    assert actual == expected


# Generated at 2022-06-23 23:54:53.718146
# Unit test for method to_try of class Box
def test_Box_to_try():
    import pytest

    from pymonet.monad_try import Try

    try_val = Try(10, is_success=True)
    box = Box(10)
    assert box.to_try() == try_val


# Generated at 2022-06-23 23:54:55.132744
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 2) == Box(4)



# Generated at 2022-06-23 23:54:57.279284
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box.to_lazy() method
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-23 23:54:58.213561
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:54:59.703555
# Unit test for constructor of class Box
def test_Box():
    """
    Test for constructor of class Box.

    :return: nothing
    :rtype: None
    """
    assert Box('1') == Box('1')



# Generated at 2022-06-23 23:55:02.860096
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(None).bind(lambda x: x) == None
    assert Box(3).bind(lambda x: x) == 3

# Generated at 2022-06-23 23:55:03.976287
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:55:06.680814
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value is 1


# Generated at 2022-06-23 23:55:09.724692
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(0)) == 'Box[value=0]'
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(2)) == 'Box[value=2]'
    assert str(Box('a')) == 'Box[value=a]'
    assert str(Box('b')) == 'Box[value=b]'
    assert str(Box('c')) == 'Box[value=c]'


# Generated at 2022-06-23 23:55:13.446020
# Unit test for method map of class Box
def test_Box_map():
    result = Box(1) \
        .map(lambda x: x + 1) \
        .map(lambda x: x * 2) \
        .map(lambda x: 'result is {}'.format(x))
    assert result == Box('result is 4')


# Generated at 2022-06-23 23:55:21.631692
# Unit test for method map of class Box
def test_Box_map():
    """Unit test for map method of class Box."""

    from pymonet.maybe import Maybe

    assert Box(42).map(lambda x: x + 1) == Box(43)
    assert Box(42).map(Maybe.just) == Maybe.just(42)
    assert Box(42).map(Maybe.nothing) == Maybe.nothing()

    assert Maybe.just(42).map(lambda x: x + 1) == Maybe.just(43)
    assert Maybe.just(42).map(Maybe.just) == Maybe.just(42)
    assert Maybe.just(42).map(Maybe.nothing) == Maybe.nothing()

    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.nothing().map(Maybe.just) == Maybe.nothing()

# Generated at 2022-06-23 23:55:24.657546
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == None)



# Generated at 2022-06-23 23:55:27.768326
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left

    assert Box(0).to_either() == Right(0)

    assert Box(0).bind(lambda a: Left(str(a))).to_either() == Left(str(0))


# Generated at 2022-06-23 23:55:32.953473
# Unit test for method ap of class Box
def test_Box_ap():
    def adder(x):
        def inner(y):
            return x + y
        return inner

    assert Box(adder).ap(Box(1)) == Box(2)
    assert Box(adder).ap(Box(1.0)) == Box(2.0)
    assert Box(adder).ap(Box("1")) == Box("11")
    assert Box(adder).ap(Box("1.0")) == Box("11.0")

# Generated at 2022-06-23 23:55:36.947950
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-23 23:55:38.105379
# Unit test for method map of class Box
def test_Box_map():
    assert Box(True).map(lambda x: not x) == Box(False)



# Generated at 2022-06-23 23:55:39.142293
# Unit test for constructor of class Box
def test_Box():
    """Test constructor of Box monad"""

    assert Box(1).value == 1


# Generated at 2022-06-23 23:55:42.942874
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    """
    test method bind for class Box
    """
    my_box = Box('test').bind(lambda x: x + '123')
    assert my_box == Box('test123')



# Generated at 2022-06-23 23:55:45.193433
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(3).to_validation().is_success == True
    assert Box(3).to_validation().value == 3



# Generated at 2022-06-23 23:55:47.460393
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test for to_either method.
    """
    from pymonet.either import Left, Right

    assert Box(1).to_either() == Right(1)
    assert Box(1).map(lambda x: Left(x)).to_either() == Left(1)



# Generated at 2022-06-23 23:55:53.445285
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.either import Right
    from pymonet.maybe import Just
    from pymonet.validation import Validation

    def f(x):
        return x * x

    assert Box(f).ap(Box(5)) == Box(f(5))
    assert Box(f).ap(Right(5)) == Right(f(5))
    assert Box(f).ap(Just(5)) == Just(f(5))
    assert Box(f).ap(Validation(5)) == Validation(f(5))



# Generated at 2022-06-23 23:55:55.282713
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-23 23:55:56.371136
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-23 23:56:02.486509
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box.
    """

    import unittest

    class TestBox(unittest.TestCase):
        """
        Class for unit test.
        """

        def test_mul_by_two(self) -> None:
            """
            Test method bind on multiplying current value by two.

            :returns: None
            :rtype: None
            """
            value = 5
            expected = 10
            assert expected == Box(value).bind(lambda x: x * 2)

        def test_add_one_and_return_self(self) -> None:
            """
            Test method bind on adding one to current value and return self.

            :returns: None
            :rtype: None
            """
            value = Box(5)
            expected = Box(5)

# Generated at 2022-06-23 23:56:06.831298
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Box(Right(42)).to_maybe() == Maybe(Right(42))
    assert Box(Right(42)).to_maybe() == Maybe.just(Right(42))


# Generated at 2022-06-23 23:56:08.746109
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(4)) == Box(5)



# Generated at 2022-06-23 23:56:12.597414
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('test') == Box('test')
    assert Box(['a', 1]) == Box(['a', 1])
    assert Box(('a', 1)) == Box(('a', 1))



# Generated at 2022-06-23 23:56:13.732858
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda value: value * 2) == Box(2)



# Generated at 2022-06-23 23:56:15.069611
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x ** 2) == 25


# Generated at 2022-06-23 23:56:18.383601
# Unit test for method to_either of class Box
def test_Box_to_either():
    # Given
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # When
    box = Box(1)

    # Then
    assert Right(1) == box.to_either()
    assert Try(1, is_success=True) == box.to_try()
    assert Validation.success(1) == box.to_validation()


# Generated at 2022-06-23 23:56:19.568742
# Unit test for method to_maybe of class Box
def test_Box_to_maybe(): # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:56:25.045420
# Unit test for method map of class Box
def test_Box_map():
    box = Box(2)
    assert box == box.map(lambda n: n)



# Generated at 2022-06-23 23:56:26.604888
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:56:32.534738
# Unit test for method bind of class Box
def test_Box_bind():
    def func(value):
        return value * 5

    assert Box(100).bind(func) == 500



# Generated at 2022-06-23 23:56:34.227327
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()


# Generated at 2022-06-23 23:56:39.719758
# Unit test for constructor of class Box
def test_Box():
    assert Box(2) == Box(2)
    assert Box(2) != Box(1)
    assert str(Box(2)) == 'Box[value=2]'

# Generated at 2022-06-23 23:56:45.796919
# Unit test for method to_either of class Box
def test_Box_to_either():
    import pymonet
    from pymonet.maybe import Maybe

    def maybe_to_either_case_success(x):
        return pymonet.Box(0).to_maybe().to_either()

    def maybe_to_either_case_fail(x):
        return pymonet.Box(Maybe.nothing()).to_maybe().to_either()

    assert maybe_to_either_case_success('') == pymonet.Right(0)
    assert maybe_to_either_case_fail('') == pymonet.Left(Maybe.nothing())



# Generated at 2022-06-23 23:56:47.472831
# Unit test for method to_try of class Box
def test_Box_to_try():
    print(Box(1).to_try())
    print(Box(lambda x, y: x + y).to_try())

# Generated at 2022-06-23 23:56:54.094360
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert Box('Hello, World!').__str__() == 'Box[value=Hello, World!]'
    assert Box(10).__str__() == 'Box[value=10]'
    assert Box(10.5).__str__() == 'Box[value=10.5]'
    assert Box([10, 20, 30]).__str__() == 'Box[value=[10, 20, 30]]'
    assert Box((10, 20, 30)).__str__() == 'Box[value=(10, 20, 30)]'
    assert Box({'a': 10, 'b': 20, 'c': 30}).__str__() == 'Box[value={\'a\': 10, \'b\': 20, \'c\': 30}]'

# Generated at 2022-06-23 23:56:55.870917
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:56:57.184447
# Unit test for method bind of class Box
def test_Box_bind():
    def double(x):
        return x * 2

    box = Box(5)

    result = box.bind(double)

    assert result == 10

# Generated at 2022-06-23 23:57:00.205941
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    assert isinstance(Box(1).to_either(), Either)



# Generated at 2022-06-23 23:57:02.002539
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)



# Generated at 2022-06-23 23:57:04.961981
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).to_either().map(lambda x: x + 2).value == 3
    assert Box(1).to_either().fmap(lambda x: x + 2) == 3



# Generated at 2022-06-23 23:57:08.523467
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test that Box transform to Try monad with value and without errors
    """
    from pymonet.monad_try import Try
    assert Test.assert_equals(Box(1).to_try(), Try(1))

# Generated at 2022-06-23 23:57:18.709441
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.maybe import Nothing
    from pymonet.box import Box

    def assert_nothing(actual):
        assert isinstance(actual, Nothing)
        assert actual == Nothing()

    def assert_just(actual, expected_value):
        assert isinstance(actual, Maybe)
        assert actual.is_just()
        assert actual.value == expected_value

    assert_just(Box(None).to_maybe(), None)
    assert_just(Box('test').to_maybe(), 'test')
    assert_just(Box(123).to_maybe(), 123)
    assert_just(Box(['test']).to_maybe(), ['test'])



# Generated at 2022-06-23 23:57:22.160428
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    from pymonet.monad_maybe import Maybe

    def mapper(x):  # type: (int) -> int
        return x + 1

    assert Box(1).map(mapper) == Box(2)
    assert Box(1).map(lambda x: x + 1) == Box(2)

    assert Maybe.just(1).map(mapper) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)



# Generated at 2022-06-23 23:57:24.152776
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1  # assert that constructor stored value properly


# Generated at 2022-06-23 23:57:34.325365
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    box = Box(5)
    validation = box.to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.value == box.value

    box = Box(Try.success(5))
    validation = box.to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.value == box.value.value.value

    box = Box(Try.failure(ZeroDivisionError('Ooops!')))
    validation = box.to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_failure
    assert len(validation.errors) == 1

# Generated at 2022-06-23 23:57:37.700835
# Unit test for method ap of class Box
def test_Box_ap():
    def ap_function(arg):
        return lambda x: x - arg

    box_with_function = Box(ap_function(5))
    assert box_with_function.ap(Box(10)).value == 5

# Generated at 2022-06-23 23:57:39.666864
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box('abc').bind(len) == 3

# Generated at 2022-06-23 23:57:46.683118
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Tests "bind" method of class "Box".

    tests:
    BIND_TEST_CASES = [
        ('test_Box_bind return new Box', Box(2),
            lambda x: Box(x + 5), Box(7)),
        ('test_Box_bind return new Box with mapped value of inner Box', Box(Box(4)),
            lambda x: Box(x.value + 5), Box(9)),
    ]
    """
    from pymonet.test_utils import (
        assert_monad_test_cases
    )


# Generated at 2022-06-23 23:57:48.517002
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:57:53.326546
# Unit test for method ap of class Box
def test_Box_ap():
    def add(first_value):
        def add_to_value(second_value):
            return first_value + second_value

        return add_to_value

    assert Box(add).ap(Box(10)) == Box(20)

# Generated at 2022-06-23 23:57:57.925914
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test ap of Box

    >>> from pymonet.box import Box
    >>> from pymonet.functor import Functor
    >>> print(Box(2).ap(Box(lambda x: x * x)))
    Box[value=4]
    >>> print(Box(2).ap(Box(3)))
    Traceback (most recent call last):
    ...
    TypeError: ap: Applicative must contains function
    """
    pass

# Generated at 2022-06-23 23:57:58.730334
# Unit test for constructor of class Box
def test_Box():
    box = Box(1)

    assert(box == Box(1))

# Generated at 2022-06-23 23:58:00.411836
# Unit test for method bind of class Box
def test_Box_bind():
    def foo(x: int) -> bool:
        return x % 2 == 0

    assert Box(2).bind(foo) == True
    assert Box(3).bind(foo) == False



# Generated at 2022-06-23 23:58:04.627564
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success
    from pymonet.validation import Success, Failure
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation(Success(1))

    # Unit test for method to_validation of class Box


# Generated at 2022-06-23 23:58:07.524283
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:58:14.619695
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    # Positive cases

    # Positive case: from box with int value returns Validation with success and int value
    value = Box(1)
    result = value.to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert isinstance(result.success, Box)
    assert result.success.value == 1

    # Positive case: from box with float value returns Validation with success and float value
    value = Box(1.0)
    result = value.to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert isinstance(result.success, Box)
    assert result.success.value == 1.0

    # Positive case: from box with str value returns Validation with success and str value

# Generated at 2022-06-23 23:58:16.502575
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == "Box[value=1]"


# Generated at 2022-06-23 23:58:25.746979
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box

    :returns: None
    :rtype: NoneType
    """
    from pymonet import Box
    from pymonet.lazy import Lazy


    def add(first: int, second: int) -> int:
        return first + second


    def append(first: str, second: str) -> str:
        return first + second


    def sum(x: [int]) -> int:
        return sum(x)


    assert Box(lambda x: add(x, 2)).ap(Box(1)).value == 3
    assert Box(lambda f: lambda x: f(x)).ap(Box(add)).ap(Box(2)).ap(Box(3)).value == 5

# Generated at 2022-06-23 23:58:32.956499
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(12)) == 'Box[value=12]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box((2, 3, 1, 3))) == 'Box[value=(2, 3, 1, 3)]'
    assert str(Box('hello')) == 'Box[value=hello]'
    assert str(Box({1: 1, 2: 2, 3: 3})) == 'Box[value={1: 1, 2: 2, 3: 3}]'



# Generated at 2022-06-23 23:58:34.342391
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(10)) == 'Box[value=10]'

# Generated at 2022-06-23 23:58:36.062404
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:58:38.267709
# Unit test for constructor of class Box
def test_Box():
    assert Box('s') == Box('s')
    assert Box('s').value == 's'
    assert str(Box('s')) == 'Box[value=s]'


# Generated at 2022-06-23 23:58:40.104757
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)

# Generated at 2022-06-23 23:58:41.227293
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(0).to_either() == Right(0)



# Generated at 2022-06-23 23:58:43.493059
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(3).to_either() == Right(3)
    assert Box('Foo').to_either() == Right('Foo')



# Generated at 2022-06-23 23:58:45.022909
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda x: x * 2) == 6


# Generated at 2022-06-23 23:58:47.590498
# Unit test for method __str__ of class Box
def test_Box___str__():
    """Test for method __str__ of class Box"""
    assert str(Box(1)) == 'Box[value=1]', '__str__ of Box class failed'

# Generated at 2022-06-23 23:58:51.310897
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:58:56.605892
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Box(lambda x, y: x + y).ap(Box(2)).ap(Box(1)) == Box(3)
    assert Box(lambda x, y: x + y).ap(Box(1)).ap(Box(2)) == Box(3)
    assert Box(lambda x, y: x + y).ap(Box(1)).ap(Box(2)).ap(Box(3)) == Box(3)



# Generated at 2022-06-23 23:59:02.730684
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.validation import Validation, is_even
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Box(2).map(lambda x: x + 1) == Box(3)
    assert Box(2).map(lambda x: x * 2) == Box(4)

    assert Box(2).map(is_even).to_validation() == Validation.success(True)

    try:
        assert Box(2).map(lambda x: x / 0).to_try() == Try(2, is_success=True)
    except ZeroDivisionError:
        assert False

    assert Box(6).to_maybe().map(lambda x: x / 2) == Maybe.just(3)


# Generated at 2022-06-23 23:59:08.087736
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(10) == Box(10)
    assert Box('a') == Box('a')
    assert Box([1, 2]) == Box([1, 2])
    assert Box({'a': 10}) == Box({'a': 10})



# Generated at 2022-06-23 23:59:09.970170
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(3).to_validation() == Validation(3, [])

# Generated at 2022-06-23 23:59:10.700994
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(10).to_either().value == 10

# Generated at 2022-06-23 23:59:11.470540
# Unit test for method __str__ of class Box
def test_Box___str__():
    obj = Box(10)
    assert str(obj) == 'Box[value=10]'

# Generated at 2022-06-23 23:59:13.665014
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def compute():
        return 2 + 2

    assert Box(compute).to_lazy().eval() == 4

# Generated at 2022-06-23 23:59:16.170744
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Testing method to_maybe of class Box
    """

    assert Box(True).to_maybe() == True



# Generated at 2022-06-23 23:59:18.503892
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-23 23:59:21.061914
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-23 23:59:23.663268
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert (Box(1).to_try() == Try(1, is_success=True)) is True

# Generated at 2022-06-23 23:59:25.946702
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(2) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert not Box(1) == 1



# Generated at 2022-06-23 23:59:28.726915
# Unit test for constructor of class Box
def test_Box():
    assert Box(None).value is None
    assert Box(1).value == 1
    assert Box(2.2).value == 2.2
    assert Box('3').value == '3'
    assert Box([1, 2, 3]).value == [1, 2, 3]



# Generated at 2022-06-23 23:59:31.677559
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box('test').to_maybe() == Maybe.just('test')


# Generated at 2022-06-23 23:59:33.402534
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    box = Box('test')
    assert box.to_either() == Either.right('test')



# Generated at 2022-06-23 23:59:35.833428
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box
    """
    box = Box(3)
    assert box.map(lambda x: x * 2) == Box(6)



# Generated at 2022-06-23 23:59:39.906881
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def add_one(value):
        return value + 1

    def add_n(n, value):
        return value + n

    box = Box(1)
    box_lazy = box.to_lazy()
    assert box_lazy.fold()(add_one) == box.value
    assert box_lazy.fold()(add_n)(2) == box.value + 2

# Generated at 2022-06-23 23:59:40.809058
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda a: a + 1) == 2


# Generated at 2022-06-23 23:59:44.654570
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(5)).value == 6
    assert Box(lambda x: x + 1).ap(Box(None)).value == 1

# Generated at 2022-06-23 23:59:45.761529
# Unit test for constructor of class Box
def test_Box():
    b = Box(5)
    assert b.value == 5


# Generated at 2022-06-23 23:59:51.937458
# Unit test for method map of class Box
def test_Box_map():
    # GIVEN
    box_data = Box(5).map(lambda x: x * 17)

    # WHEN
    mapped_box_data = Box(85)

    # THEN
    assert mapped_box_data == box_data

# Generated at 2022-06-23 23:59:59.247666
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    """
    Test for method bind for Box class

    """
    from pymonet.maybe import Maybe

    assert Box(10).bind(lambda x: Maybe.just(x + 10)) == Maybe.just(20)
    assert Box(10).bind(lambda x: x + 10) == 20


# Generated at 2022-06-24 00:00:06.167417
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box(1.0)) == 'Box[value=1.0]'
    assert str(Box('Foo')) == 'Box[value=Foo]'
    assert str(Box(None)) == 'Box[value=None]'


# Generated at 2022-06-24 00:00:07.514771
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(10).to_lazy().__eq__(Lazy(lambda: 10))

# Generated at 2022-06-24 00:00:12.526221
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    value = 10

    result = Box(value).to_validation()

    assert isinstance(result, Validation)
    assert result.value[0] == value


# Generated at 2022-06-24 00:00:14.405905
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box = Box(1)
    assert box.value == 1


# Generated at 2022-06-24 00:00:17.687911
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    b1 = Box([1, 2, 3])
    b2 = Box([1, 2, 3])
    b3 = Box([1, 2, 4])
    b4 = Box(1)
    b5 = Box(None)
    assert b1 == b2
    assert b1 != b3
    assert b1 != b4
    assert b1 != b5


# Generated at 2022-06-24 00:00:18.765529
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x + 1) == Box(4)


# Generated at 2022-06-24 00:00:24.183946
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Left
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Try.just(lambda x: x + 1).ap(Box(3)) == Try.just(4)
    assert Maybe.just(lambda x: x + 1).ap(Box(3)) == Maybe.just(4)
    assert Left(lambda x: x + 1).ap(Box(3)) == Left(lambda x: x + 1)
    assert Lazy(lambda: lambda x: x + 1).ap(Box(3)) == Lazy(lambda: 4)
    assert Validation.success(lambda x: x + 1).ap(Box(3)) == Validation.success(4)

# Generated at 2022-06-24 00:00:25.582601
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:00:26.756010
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box = Box(10)
    assert box.to_validation() == Validation.success(10)

# Generated at 2022-06-24 00:00:33.179974
# Unit test for method map of class Box
def test_Box_map():
    # Arrange
    mapper_func = lambda x: x + 1
    box_value = Box(1)
    expected_box_value = Box(2)

    # Act
    result_box_value = box_value.map(mapper_func)

    # Assert
    assert result_box_value == expected_box_value


# Generated at 2022-06-24 00:00:34.459587
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(4).bind(lambda x: x + 1) == 5


# Generated at 2022-06-24 00:00:37.509591
# Unit test for method bind of class Box
def test_Box_bind():
    def mapper(value):
        return value + 1

    box = Box(1).bind(mapper)
    assert box == 2

# Generated at 2022-06-24 00:00:41.166513
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(True) == Box(True)
    assert Box(True) != Box(False)
    assert Box(True) != Box(None)
    assert Box(True) != None
    assert Box(None) == Box(None)
    assert Box(None) != None


# Generated at 2022-06-24 00:00:43.343469
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(3).to_try() == Try(3, is_success=True)



# Generated at 2022-06-24 00:00:53.289710
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test ap method of class Box
    """
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.maybe import Maybe

    def add(value: int) -> Functor:
        def add_inner(value_inner: int) -> int:
            return value + value_inner
        return Functor(add_inner)

    def add_applicative(value: int) -> Applicative:
        def add_applicative_inner(value_inner: int) -> int:
            return value + value_inner
        return Applicative(add_applicative_inner)

    box_int = Box(1)
    assert box_int.ap(add(2)) == Box(3)
    assert box_int.ap(add_applicative(2))

# Generated at 2022-06-24 00:00:56.382964
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)
    assert Box(False).to_validation() == Validation.success(False)
    assert Box('last').to_validation() == Validation.success('last')
#

# Generated at 2022-06-24 00:00:58.138410
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(1)
    assert box.__str__() == 'Box[value=1]'



# Generated at 2022-06-24 00:00:59.570131
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:01:02.405355
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(2) != Box('two')


# Generated at 2022-06-24 00:01:04.681081
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box('test')
    assert box.to_either() == Right('test')
    assert box.to_either().value == 'test'



# Generated at 2022-06-24 00:01:06.776097
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x * 2) == Box(2)



# Generated at 2022-06-24 00:01:08.389199
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().fold() == 42

# Generated at 2022-06-24 00:01:10.194454
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box('a').map(str.upper) == Box('A')



# Generated at 2022-06-24 00:01:11.850110
# Unit test for method map of class Box
def test_Box_map():
    assert Box('foo').map(lambda x: x + ' bar') == Box('foo bar')



# Generated at 2022-06-24 00:01:13.943814
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    result = Box(0).bind(lambda x: x + 1).bind(lambda x: x * 2)

    assert result == 2



# Generated at 2022-06-24 00:01:16.784654
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(lambda x: x + 1) == 2



# Generated at 2022-06-24 00:01:19.163350
# Unit test for method map of class Box
def test_Box_map():
    assert Box(4).map(lambda x: x + 2) == Box(6)
    assert Box(3).map(lambda x: x + 2) == Box(5)


# Generated at 2022-06-24 00:01:20.692316
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(2).ap(Box(lambda x: x * 2)) == Box(4)



# Generated at 2022-06-24 00:01:21.859796
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == 1



# Generated at 2022-06-24 00:01:23.296963
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    assert Box(42).to_either() == Right(42)



# Generated at 2022-06-24 00:01:25.016305
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(3)) == 'Box[value=3]'
    assert str(Box('test')) == 'Box[value=test]'


# Generated at 2022-06-24 00:01:29.405036
# Unit test for method map of class Box
def test_Box_map():
    """ test Box map """
    method_test_Box_map_defined()
    assert Box(1).map(lambda x: x + 1).value == 2


# Generated at 2022-06-24 00:01:34.084891
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe

    box = Box(True)

    def mapper(value):
        return Maybe.just(value)

    assert box.bind(mapper).bind(lambda x: x) is Maybe.just(True)

# Generated at 2022-06-24 00:01:40.672803
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    assert Box(1).to_either() == Right(1)

    assert Box([]).to_either() == Right([])

    assert Box(None).to_either() == Right(None)

    assert Box('').to_either() == Right('')

    assert Box('test').to_either() == Right('test')

    assert Box(Left(1)).to_either() == Right(Left(1))

    assert Box(Right(1)).to_either() == Right(Right(1))


# Generated at 2022-06-24 00:01:41.906350
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-24 00:01:43.203952
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box('str')) == 'Box[value=str]'


# Generated at 2022-06-24 00:01:44.337661
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-24 00:01:49.902867
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda x: x + 10) == 20
    assert Box('hello').bind(lambda x: x + ' world') == 'hello world'
    assert Box([1, 2, 3]).bind(lambda x: x + [4, 5, 6]) == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-24 00:01:52.790185
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(1)
    assert box.to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:01:54.529055
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)


# Generated at 2022-06-24 00:01:57.888568
# Unit test for method map of class Box
def test_Box_map():
    def add_one(x: int) -> int:
        return x + 1

    assert Box(2).map(add_one) == Box(3)



# Generated at 2022-06-24 00:01:59.810897
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert isinstance(Box(42).to_either(), Right)



# Generated at 2022-06-24 00:02:01.618778
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)



# Generated at 2022-06-24 00:02:02.538643
# Unit test for constructor of class Box
def test_Box():
    assert Box('a').value == 'a'


# Generated at 2022-06-24 00:02:04.454030
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-24 00:02:06.056922
# Unit test for method bind of class Box
def test_Box_bind():
    f = lambda x: Box("hello: " + x)
    assert Box("world!").bind(f) == f("world!")

# Generated at 2022-06-24 00:02:08.309659
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test to_maybe method of class Box
    """

    assert Box('test').to_maybe().just == 'test'
    assert Box('test').to_maybe().nothing is None


# Generated at 2022-06-24 00:02:11.489211
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, True)

# Generated at 2022-06-24 00:02:14.361665
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(None).to_try() == Box(None).to_try()
    assert str(Box(None).to_try()) == 'Success[None]'

# Generated at 2022-06-24 00:02:16.687525
# Unit test for method __str__ of class Box
def test_Box___str__():
    value = 'Value in box'
    box = Box(value)

    assert str(box) == "Box[value=Value in box]"


# Generated at 2022-06-24 00:02:20.680223
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box([]) == Box([])
    assert not Box('a') == 1
    assert not Box(1) == Box('a')
    assert not Box('a') == Box([])


# Generated at 2022-06-24 00:02:22.836154
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box.
    """
    assert Box(2).bind(lambda n: n * 8) == 16

# Generated at 2022-06-24 00:02:24.750480
# Unit test for constructor of class Box
def test_Box():
    assert Box(2) == Box(2)
    assert Box(2).value == 2
    assert str(Box(2)) == 'Box[value=2]'

# Generated at 2022-06-24 00:02:25.507450
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)

# Generated at 2022-06-24 00:02:37.566705
# Unit test for method to_either of class Box
def test_Box_to_either():
    # Test when Box contains integer
    assert Box(1).to_either().is_right()

    # Test when Box contains float
    assert Box(1.1).to_either().is_right()

    # Test when Box contains boolean
    assert Box(True).to_either().is_right()

    # Test when Box contains string
    assert Box('str').to_either().is_right()

    # Test when Box contains list
    assert Box([]).to_either().is_right()

    # Test when Box contains tuple
    assert Box(()).to_either().is_right()

    # Test when Box contains set
    assert Box(set()).to_either().is_right()

    # Test when Box contains dictionary
    assert Box({}).to_either().is_right()

    # Test when Box contains None

# Generated at 2022-06-24 00:02:42.452744
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.lazy import Lazy

    def add(x):
        return lambda y: x + y

    val = Box(add).ap(Lazy(lambda: 2)).run()
    assert val == 4

# Generated at 2022-06-24 00:02:48.198418
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.applicative import Applicative

    box = Box(lambda x: x + 1)
    assert Applicative.ap(box, Box(1)) == Box(2)



# Generated at 2022-06-24 00:02:53.375517
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('hello')) == 'Box[value=hello]'
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(Box(1))) == 'Box[value=Box[value=1]]'


# Generated at 2022-06-24 00:02:56.045374
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(2).to_maybe() == Box(2).to_maybe()
    assert Box(2).to_maybe() != Box(3).to_maybe()


# Generated at 2022-06-24 00:02:58.539881
# Unit test for method ap of class Box
def test_Box_ap():
    def add_func(a, b):
        return a + b

    assert Box(add_func).ap(Box(1)).ap(Box(2)).value == 3

# Generated at 2022-06-24 00:03:00.750709
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)



# Generated at 2022-06-24 00:03:02.894738
# Unit test for method to_try of class Box
def test_Box_to_try():                            # pragma: no cover
    from pymonet.monad_try import Success

    assert Success(1) == Box(1).to_try()



# Generated at 2022-06-24 00:03:06.532656
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Assert that Box[1] is equal to it self
    assert Box(1) == Box(1)

    # Assert that Box[2] is not equal to Box[3]
    assert not Box(2) == Box(3)


# Generated at 2022-06-24 00:03:08.738617
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:03:10.051198
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-24 00:03:11.374383
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:03:17.067000
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    number = 123
    box_validation = Box(Validation.success(number))
    box_either_left = Box(Left('error'))
    box_either_right = Box(Right(number))

    assert box_validation.to_either() == Right(Validation.success(number))
    assert box_either_left.to_either() == Left('error')
    assert box_either_right.to_either() == Right(number)



# Generated at 2022-06-24 00:03:18.998874
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try().is_success
    assert Box(1).to_try().value == 1



# Generated at 2022-06-24 00:03:20.998072
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Box(1).to_maybe()


# Generated at 2022-06-24 00:03:22.433060
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(2) == Box(2)

# Generated at 2022-06-24 00:03:27.850169
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert (Box(1) == Box(1)) == True
    assert (Box(1) == Box(2)) == False
    assert (Box(1) == Box('1')) == False
    assert (Box(1) == None) == False



# Generated at 2022-06-24 00:03:28.674914
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda x: x * 10) == 100

# Generated at 2022-06-24 00:03:31.665807
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box(1).to_either() != Right(2)


# Generated at 2022-06-24 00:03:33.220409
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    assert Box("1").to_either().is_right

# Generated at 2022-06-24 00:03:37.338952
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box("1")) == 'Box[value=1]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'



# Generated at 2022-06-24 00:03:43.491490
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test case for Box#to_either method.

    :returns: Nothing
    :rtype: None
    """

    from pymonet.either import Right

    # Test for converting box with integer value
    assert Box(42).to_either() == Right(42), 'Test for converting box with integer value'

    # Test for converting box with string value
    assert Box('string').to_either() == Right('string'), 'Test for converting box with string value'


# Generated at 2022-06-24 00:03:48.330359
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for `Box.to_either`
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-24 00:03:52.181609
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(100)
    box2 = Box(100)
    box3 = Box(200)

    assert box1 == box2
    assert not box1 == box3
