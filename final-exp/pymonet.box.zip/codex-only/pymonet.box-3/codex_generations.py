

# Generated at 2022-06-23 23:53:53.731321
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-23 23:53:56.404118
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(42).to_maybe() == Box(None).to_maybe() == \
        Box(None).to_maybe() == Box(42).to_maybe()



# Generated at 2022-06-23 23:53:57.489519
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: 2 * x) == 2



# Generated at 2022-06-23 23:53:59.844234
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(True).to_try() == Try(True, is_success=True)

# Generated at 2022-06-23 23:54:03.355118
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('1') == Box('1')
    assert Box('1') != Box('2')



# Generated at 2022-06-23 23:54:07.034145
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)


# Generated at 2022-06-23 23:54:08.997229
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert Box(1).__str__() == 'Box[value=1]', 'Box[value=1] should be returned'


# Generated at 2022-06-23 23:54:11.059513
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for bind of class Box

    """

    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-23 23:54:14.352818
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(2).to_either() == Right(2)
    assert Box(None).to_either() == Right(None)
    assert Box(1).to_either().value == 1


# Generated at 2022-06-23 23:54:17.150699
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Nothing

    assert Box(None).to_maybe() is Nothing
    assert Box(1).to_maybe() == Box(1).to_maybe()



# Generated at 2022-06-23 23:54:19.142077
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(4).to_either() == Right(4)

# Generated at 2022-06-23 23:54:26.204355
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)
    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:54:31.692279
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    assert isinstance(Box(1).to_try(), Try)


# Generated at 2022-06-23 23:54:38.911669
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.functor import Functor

    class A(Functor):
        source = None

        def __init__(self, source) -> None:
            self.source = source

        def map(self, func):
            return A(func(self.source))

    result = Box(lambda x: x + 1).ap(A(3))

    assert isinstance(result, A) and result.source == 4


# Generated at 2022-06-23 23:54:41.189499
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)
    assert Box(1).map(lambda x: x + 2) != Box(2)



# Generated at 2022-06-23 23:54:44.826087
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:54:49.509505
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_throwable import throw_exception

    assert Box('ok').to_try() == Try('ok', is_success=True)

    with pytest.raises(RuntimeError):
        Box(throw_exception(RuntimeError())).to_try()



# Generated at 2022-06-23 23:54:55.167492
# Unit test for method __str__ of class Box
def test_Box___str__():
    from nose.tools import assert_equals

    assert_equals(str(Box(1)), 'Box[value=1]')
    assert_equals(str(Box("a")), 'Box[value=a]')
    assert_equals(str(Box(None)), 'Box[value=None]')
    assert_equals(str(Box(object)), 'Box[value=<class \'object\'>]')
    assert_equals(str(Box(object())), 'Box[value=<object object at 0x0>]')


# Generated at 2022-06-23 23:55:04.514523
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.function import Function
    from pymonet.validation import Validation

    assert Box(Function.add(1)).ap(Box(1)).value == 2

    add2 = Function.add(2)
    val = Box(add2).ap(Box(1))
    assert val.value == 3
    assert isinstance(val, Box)

    div_by_five = Function.divide_by(5)
    assert Box(div_by_five).ap(Box(10)).value == 2.0

    val10 = Box(10)
    assert Box(div_by_five).ap(val10).value == 2.0
    assert val10 == Box(10)

    assert Box(add2).ap(Box('1')).value == 3.0

# Generated at 2022-06-23 23:55:14.524468
# Unit test for method ap of class Box
def test_Box_ap():
    # pylint: disable=missing-docstring
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(lambda x: x + 2).ap(Box(5)) == Box(7)
    assert Box(lambda x: x + 2).ap(Maybe.just(5)) == Maybe.just(7)
    assert Box(lambda x: x + 2).ap(Lazy(lambda: 5)) == Lazy(lambda: 7)
    assert Box(lambda x: x + 2).ap(Try(5, is_success=True)) == Try(7, is_success=True)

# Generated at 2022-06-23 23:55:24.310823
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def inc(x: int) -> int:
        return x + 1

    assert Box(0).bind(inc) == 1
    assert Box(1).bind(inc) == 2
    assert Box(1).bind(inc).bind(inc) == 3
    assert Box(1).bind(inc).bind(inc).bind(inc) == 4
    assert Box(Try(1)).bind(lambda x: Try(inc(x), is_success=True)).value == Maybe.just(2).value
    assert Box(Try(1, is_success=False)).bind(lambda x: Try(inc(x), is_success=True)).value == Maybe.nothing().value

# Generated at 2022-06-23 23:55:26.604500
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(2).to_try() == Try(2, is_success=True)

# Generated at 2022-06-23 23:55:28.022087
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(1)
    assert str(box) == 'Box[value=1]'



# Generated at 2022-06-23 23:55:31.677139
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 4).ap(Box(3)) == Box(7)



# Generated at 2022-06-23 23:55:38.405394
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box.unit(666).to_maybe() == Maybe.just(666)
    assert Box.unit(None).to_maybe() == Maybe.just(None)

    # Test with string
    assert Box.unit('test').to_maybe() == Maybe.just('test')

    # Test with list
    assert Box.unit([1, 2, 3]).to_maybe() == Maybe.just([1, 2, 3])


# Generated at 2022-06-23 23:55:40.333190
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(0).to_lazy() == Lazy(lambda: 0)

# Generated at 2022-06-23 23:55:41.456302
# Unit test for method ap of class Box
def test_Box_ap():
    assert (Box(lambda x: x).ap(Box(2)) == Box(2))

# Generated at 2022-06-23 23:55:42.876926
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)


# Generated at 2022-06-23 23:55:44.681052
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:55:45.629744
# Unit test for constructor of class Box
def test_Box():
    box = Box(3)
    assert box.value == 3

# Generated at 2022-06-23 23:55:49.265330
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)
    box4 = Box(1.0)

    assert box1 == box2
    assert box1 != box3
    assert box1 != box4



# Generated at 2022-06-23 23:55:51.517189
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box("1"))
    assert not (Box(1) == 1)



# Generated at 2022-06-23 23:55:54.308991
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box_m = Box(Right(5))
    either_m = box_m.to_either()
    assert isinstance(either_m, Right) and either_m.value == 5


# Generated at 2022-06-23 23:55:56.968794
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert not Box(1) == Box(2)
    assert not Box(1) == 2


# Generated at 2022-06-23 23:55:57.981106
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(2).to_validation().is_success

# Generated at 2022-06-23 23:56:02.799119
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_list import List

    assert Box(List([1, 2, 3])).to_lazy().map(lambda x: x).get_or_else(None) == [1, 2, 3]

# Generated at 2022-06-23 23:56:06.313707
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(5).map(lambda x: x * 2).map(lambda x: x - 4) == Box(6)


#Unit test for method bind of class Box

# Generated at 2022-06-23 23:56:10.170397
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:56:11.380434
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-23 23:56:16.844763
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(2).map(lambda x: x + 2) == Box(4)
    assert Box(2).map(lambda x: x * 2) == Box(4)
    assert Box(2).map(lambda x: 'returned value') == Box('returned value')


# Generated at 2022-06-23 23:56:19.098232
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != Box(4)
    assert Box("asdf") == Box("asdf")

# Generated at 2022-06-23 23:56:24.774292
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x * x) == 4


# Generated at 2022-06-23 23:56:26.690023
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.monad_box import Box

    assert Box(4).to_either() == Right(4)

# Generated at 2022-06-23 23:56:32.284480
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2

# Generated at 2022-06-23 23:56:33.785575
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test method to_either of class Box.
    """
    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:56:36.378523
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box('test')
    lazy = box.to_lazy()

    assert lazy.is_not_folded()



# Generated at 2022-06-23 23:56:38.295313
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try1 = Try(1, is_success=True)

    assert try1.to_box().to_try() == try1
    try2 = Try(Exception('test'), is_success=False)
    assert try2.to_box().to_try() == try2

# Generated at 2022-06-23 23:56:40.344348
# Unit test for method map of class Box
def test_Box_map():
    assert isinstance(Box(True).map(bool), Box)
    assert Box(True).map(bool).value is True


# Generated at 2022-06-23 23:56:43.867976
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.maybe import Maybe

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Maybe.just(1)



# Generated at 2022-06-23 23:56:46.733671
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()

# Generated at 2022-06-23 23:56:49.663563
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    box = Box(3)
    actual = box.to_try()
    expected = Try(3, is_success=True)
    assert expected == actual

# Generated at 2022-06-23 23:56:51.217178
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-23 23:56:52.353217
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(2).to_either() == Right(2)

# Generated at 2022-06-23 23:56:54.312460
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert 'Box[value=5]' == str(Box(5))

# Generated at 2022-06-23 23:56:59.926548
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)

# Generated at 2022-06-23 23:57:00.813841
# Unit test for constructor of class Box
def test_Box():
    pass



# Generated at 2022-06-23 23:57:02.270177
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'


# Generated at 2022-06-23 23:57:08.823965
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box.to_lazy() method.
    """
    # GIVEN value
    value = 3

    # WHEN Box is transformed into Lazy
    lazy_value = Box(value).to_lazy()

    # THEN lazy value equals value
    assert value == lazy_value.get()

# Generated at 2022-06-23 23:57:11.562510
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:57:14.344934
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def test_function():
        print("this is test")
    assert Box(test_function).to_lazy().run() == test_function



# Generated at 2022-06-23 23:57:19.292653
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy() == Lazy(lambda: 2)
    assert Box('a').to_lazy() == Lazy(lambda: 'a')
    assert Box(Box('b')).to_lazy() == Lazy(lambda: Box('b'))
    assert Box([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])

# Generated at 2022-06-23 23:57:20.950601
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_maybe import Maybe

    box = Box(15)
    maybe_box = Maybe.just(15).to_box()
    assert box == maybe_box


# Generated at 2022-06-23 23:57:24.246776
# Unit test for constructor of class Box
def test_Box():  # type:ignore
    assert (Box(1) == Box(1)) == True
    assert (Box(1) == Box(2)) == False
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:57:26.320855
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(12)
    assert box.to_maybe() == Maybe.just(12)



# Generated at 2022-06-23 23:57:28.430334
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)

# Generated at 2022-06-23 23:57:29.743086
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda v: v + 1) == 4
    assert Box('test').bind(lambda v: v + 'test') == 'testtest'



# Generated at 2022-06-23 23:57:31.348370
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(None)) == 'Box[value=None]'



# Generated at 2022-06-23 23:57:37.683962
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().get() == 1

# Generated at 2022-06-23 23:57:45.477141
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Tests bind method of class Box
    """
    assert Box(10).bind(lambda value: value) == 10
    assert Box(10).bind(lambda value: value + 1) == 11
    assert Box(10).bind(lambda value: value - 1) == 9
    assert Box(10).bind(lambda value: value * 2) == 20
    assert Box(10).bind(lambda value: value / 2) == 5
    assert Box(10).bind(lambda value: value % 2) == 0
    assert Box(10).bind(lambda value: value // 2) == 5
    assert Box(10).bind(lambda value: value ** 2) == 100



# Generated at 2022-06-23 23:57:47.824617
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(1)
    result = box.bind(lambda x: x + 1)

    assert result == 2


# Generated at 2022-06-23 23:57:51.705205
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box('test').to_either() == Right('test')


# Generated at 2022-06-23 23:57:53.415596
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:57:54.247386
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(lambda: 1)

# Generated at 2022-06-23 23:57:58.467412
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-23 23:58:01.685870
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    r = "test"

    x = Box(r)
    lazy = x.to_lazy()

    assert isinstance(lazy, Lazy)
    assert not lazy.is_lazy
    assert lazy.get() == r

# Generated at 2022-06-23 23:58:07.572507
# Unit test for constructor of class Box
def test_Box():
    assert Box(7).value == 7
    assert Box('sdfs').value == 'sdfs'
    assert Box([1, 2, 3]).value == [1, 2, 3]



# Generated at 2022-06-23 23:58:09.633275
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)



# Generated at 2022-06-23 23:58:16.731713
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Exception

    value = 2
    monad = Box(value)
    result = monad.to_try()

    assert isinstance(result, Try)
    assert result.is_success
    assert result.get_or_raise() == value

# Generated at 2022-06-23 23:58:22.835532
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for Box.ap method

    """
    from .maybe import Maybe
    from .either import Right
    from .lazy import Lazy
    from .monad_try import Try
    from .validation import Validation

    # Test for Box[A] when A is Integer type
    res1 = Box(lambda a: a * 2).ap(Box(10))
    assert isinstance(res1, Box)
    assert res1.value == 20

    # Test for Box[A] when A is Function type and type of value is Integer
    res2 = Box(lambda a: lambda b: a * b).ap(Box(2)).ap(Box(10))
    assert isinstance(res2, Box)
    assert res2.value == 20

    # Test for Box[A] when A is Function type and type of value is String

# Generated at 2022-06-23 23:58:29.767305
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    # First element of tuple is lazy monad initializer, second element
    # is expected result
    input_output_cases = (
        (lambda: Lazy(lambda: box.value), 1)
    )
    for lazy_monad_initializer, expected_result in input_output_cases:
        assert lazy_monad_initializer().evaluate() == expected_result



# Generated at 2022-06-23 23:58:33.144588
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet import Box

    box = Box(None)
    maybe = box.to_maybe()

    assert isinstance(maybe, Maybe)
    assert maybe.value is None


# Generated at 2022-06-23 23:58:35.951466
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"

# Generated at 2022-06-23 23:58:38.139334
# Unit test for method map of class Box
def test_Box_map():
    box = Box(1)
    new_box = box.map(lambda x: x + 1)
    assert (new_box.value == 2)


# Generated at 2022-06-23 23:58:41.314108
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)
    assert Box(1).map(str) == Box('1')


# Generated at 2022-06-23 23:58:44.080864
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.applicative import Applicative

    def plus_3(x):
        return x + 3

    assert Box(3).ap(Box(plus_3)) == Box(6)

    assert Box(3).ap(Applicative(plus_3)) == Box(6)

# Generated at 2022-06-23 23:58:47.749586
# Unit test for method map of class Box
def test_Box_map():

    def mult_by_two(x):
        return x * 2

    assert Box(1).map(mult_by_two) == Box(2)
    assert Box(2).map(mult_by_two) == Box(4)


# Generated at 2022-06-23 23:58:48.912379
# Unit test for method map of class Box
def test_Box_map():
    value = lambda x: x + 2
    assert Box(1).map(value) == Box(3)



# Generated at 2022-06-23 23:58:49.790733
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x + 1) == 3


# Generated at 2022-06-23 23:58:51.676895
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(123).to_lazy() == Lazy(lambda: 123)

# Generated at 2022-06-23 23:58:53.542896
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box('1')
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:58:56.531139
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(0)) == 'Box[value=0]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box('Hello')) == 'Box[value=Hello]'



# Generated at 2022-06-23 23:58:57.652572
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:59:00.660932
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    value = "value"
    box = Box(value)
    is_equal = box.__eq__(Box(value))
    assert is_equal

    is_equal = box.__eq__(Box(123))
    assert not is_equal



# Generated at 2022-06-23 23:59:11.677708
# Unit test for method to_try of class Box
def test_Box_to_try():
    import pytest
    from pymonet.monad_try import Try

    assert Box('abc').to_try() == Try('abc', is_success=True)
    assert isinstance(Box('abc').to_try(), Try)
    assert Box(None).to_try() == Try(None, is_success=True)
    assert isinstance(Box(None).to_try(), Try)
    with pytest.raises(TypeError):
        assert Box('').to_try() == Try('', is_success=True)
    assert isinstance(Box('').to_try(), Try)
    assert Box(True).to_try() == Try(True, is_success=True)
    assert isinstance(Box(True).to_try(), Try)

# Generated at 2022-06-23 23:59:13.763890
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:59:25.496684
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.either import Left
    from pymonet.monad_try import Try

    def add(a):
        return a + 1

    test_lhs = Box(add)
    test_rhs = Box(1)
    expected_result = Box(2)

    result = test_lhs.ap(test_rhs)

    assert result == expected_result

    test_lhs = Box('a')
    test_rhs = Box(1)
    expected_result = Box('a')

    result = test_lhs.ap(test_rhs)

    assert result == expected_result

    test_lhs = Box(add)
    test_rhs = None
    expected_result = Box(1)

    result = test_lhs.ap(test_rhs)

    assert result == expected_

# Generated at 2022-06-23 23:59:30.292549
# Unit test for method map of class Box
def test_Box_map():

    # [Given]
    box = Box(5)
    add_two = lambda x: x + 2
    expected = Box(7)

    # [When]
    result = box.map(add_two)

    # [Then]
    assert result == expected



# Generated at 2022-06-23 23:59:32.255954
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box("1")) == 'Box[value=1]'



# Generated at 2022-06-23 23:59:36.614314
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-23 23:59:38.457316
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert Box(5).to_try() == Try(5, is_success=True)



# Generated at 2022-06-23 23:59:45.377560
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test.

    :return: None
    """
    # check map function
    assert Box(3).map(lambda x: x * x) == Box(9)

    # check that original value not changed
    assert Box(3).value == 3



# Generated at 2022-06-23 23:59:49.367987
# Unit test for method to_either of class Box
def test_Box_to_either():
    box = Box(1)
    either = box.to_either()
    assert either.is_right() and either.value == 1



# Generated at 2022-06-23 23:59:53.906536
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe

    assert Box(2).bind(lambda x: Box(x * x)) == Box(4)
    assert Box('message').bind(lambda x: Box(x + '1')) == Box('message1')
    assert Box(2).bind(lambda x: Maybe.just(x * x)) == Maybe.just(4)


# Generated at 2022-06-23 23:59:57.560752
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1), 'Box should store value'
    assert Box(1) != Box(2), 'Box with different raw values should be different'

# Generated at 2022-06-23 23:59:59.721569
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)

# Generated at 2022-06-24 00:00:01.326101
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 4).value == 6


# Generated at 2022-06-24 00:00:04.395156
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.

    :return: None
    """
    test_string = 'Hello'
    lazy_box = Box(test_string).to_lazy()
    assert test_string == lazy_box.eval()


#######################################################################################################################
# FUNCTIONS
#######################################################################################################################

# Generated at 2022-06-24 00:00:08.080523
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) == Box(1.0)
    assert Box(1) is not Box(1)
    assert Box(1.0) is not Box(1)
    assert Box(None) is not Box(1)

    assert str(Box(1)) == "Box[value=1]"

# Generated at 2022-06-24 00:00:10.204160
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    b = Box(5)
    assert isinstance(b.to_validation(), Validation)
    assert b.to_validation() == Validation(5, [])



# Generated at 2022-06-24 00:00:12.061626
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != object()



# Generated at 2022-06-24 00:00:15.265717
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)
    assert Box(-2).to_validation() == Validation.success(-2)


# Generated at 2022-06-24 00:00:16.228634
# Unit test for constructor of class Box
def test_Box():
    box = Box('test')
    assert box == Box('test')

# Generated at 2022-06-24 00:00:17.770736
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    box = Box(5)
    assert box.to_try() == Try(5, is_success=True)



# Generated at 2022-06-24 00:00:25.706470
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.maybe import Just, NoneType
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Box(Try('Just')).map(lambda m: m.get_or_die()) == Box(Try(NoneType, is_success=False))
    assert Box(Right('Right')).map(lambda m: m.value) == Box(Right('Right'))
    assert Box('Box').map(lambda m: m * 2) == Box('BoxBox')
    assert Box(Just('Just')).map(lambda m: m.value) == Box(Just('Just'))
    assert Box(NoneType()).map(lambda m: m) == Box(NoneType())

# Generated at 2022-06-24 00:00:26.376574
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:00:31.075129
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def test_mapper(value: str) -> Maybe[str]:
        return Maybe.just(value)

    assert Box('foo').bind(test_mapper) == Maybe.just('foo')

    def test_mapper_2(value: str) -> Try[str]:
        return Try(value, is_success=True)

    assert Box('foo').bind(test_mapper_2) == Try.success('foo')

    def test_mapper_3(value: str) -> Try[str]:
        return Try(value, is_success=False)


# Generated at 2022-06-24 00:00:32.609783
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))


# Generated at 2022-06-24 00:00:33.860288
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:00:39.199839
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """TestBoxToLazy"""
    from pymonet.lazy import Lazy

    value = True
    result = Box(value).to_lazy()

    assert isinstance(result, Lazy)
    assert not result.is_value_computed
    assert result.eval() == value


# Generated at 2022-06-24 00:00:42.121505
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box("1") == Box("1")
    assert Box("2") != Box("1")


# Generated at 2022-06-24 00:00:42.736256
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:00:46.036941
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    import pytest

    expected = Box(1).to_validation()
    actual = "Validation[1, []]"
    assert expected.__str__() == actual


# Generated at 2022-06-24 00:00:47.618147
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-24 00:00:48.818842
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = Box(3).to_lazy()
    assert value.value() == 3

# Generated at 2022-06-24 00:00:50.572115
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(5)
    assert box.bind(lambda x: x * 2) == 10



# Generated at 2022-06-24 00:00:51.807705
# Unit test for method to_either of class Box
def test_Box_to_either():

    assert Box(2).to_either() == Right(2)

# Generated at 2022-06-24 00:00:55.101253
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Tests for to_lazy method of Box class.
    """
    # When we take Box[3] and want to transform into Lazy
    _lazy = Box(3).to_lazy()

    # Expect Lazy[() -> 3]
    assert _lazy.value() == 3



# Generated at 2022-06-24 00:00:56.173453
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box('foo').to_maybe() == Just('foo')



# Generated at 2022-06-24 00:00:58.550005
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == None)



# Generated at 2022-06-24 00:01:01.046953
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for bind method.
    """
    # unit test for bind method with string
    assert Box(1).bind(lambda x: x + 1) == 2, 'Must return 2'

    # unit test for bind method with int
    assert Box('1').bind(lambda x: int(x) + 1) == 2, 'Must return 2'

# Generated at 2022-06-24 00:01:05.621079
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(42).to_maybe() == Maybe.just(42)
    assert Box(42).to_either() == Right(42)
    assert Box(42).to_lazy() == Lazy(lambda: 42)
    assert Box(42).to_try() == Try(42)



# Generated at 2022-06-24 00:01:09.121215
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)



# Generated at 2022-06-24 00:01:11.222148
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    x = Box(1)
    y = x.to_lazy()

    assert y.value() == x.value


# Generated at 2022-06-24 00:01:13.358540
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box: Box[int] = Box(1)
    result = box.to_validation()
    expected = Validation.success(1)
    assert result == expected

# Generated at 2022-06-24 00:01:14.251591
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-24 00:01:17.056411
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(True).to_try() == Try(True, is_success=True)

# Generated at 2022-06-24 00:01:19.189739
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Either

    assert isinstance(Box(1).to_either(), Either)
    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-24 00:01:20.417616
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)



# Generated at 2022-06-24 00:01:23.439220
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test `ap` method of class `Box`.
    """
    def add_five_to_self(n):
        return n + 5

    assert (Box(1).to_lazy().ap(Box(add_five_to_self)).value)() == 6

# Generated at 2022-06-24 00:01:30.206479
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def function_to_check_lazy_with_box(lazy_val: Lazy) -> bool:
        return lazy_val.folded  # Lazy should be not folded at returning

    assert function_to_check_lazy_with_box(Box(42).to_lazy())



# Generated at 2022-06-24 00:01:32.872373
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box_value = Box(1)
    maybe_monad = box_value.to_maybe()

    assert maybe_monad == Maybe.just(1)


# Generated at 2022-06-24 00:01:35.124918
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:01:36.842403
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-24 00:01:37.816999
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:01:39.391847
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)


# Generated at 2022-06-24 00:01:41.442964
# Unit test for method bind of class Box
def test_Box_bind():
    def func(x: int) -> float:
        return x / 2

    result = Box(4).bind(func)
    assert result == 2.0


# Generated at 2022-06-24 00:01:43.665777
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box = Box(1).to_validation()
    assert box.is_success()
    assert isinstance(box, Box)
    assert box.value == 1


# Generated at 2022-06-24 00:01:45.223505
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Left
    box = Box(1)
    assert box.to_either() == Left(box.value)


# Generated at 2022-06-24 00:01:50.088853
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    class Test:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return isinstance(other, Test) and self.value == other.value

    value = Test('test')
    validation = Box(value).to_validation()

    assert validation == Validation.success(value)

# Generated at 2022-06-24 00:01:51.694645
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(123).to_either() == Right(123)

# Generated at 2022-06-24 00:01:54.062649
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Unit
    from pymonet.box import Box

    assert Right(Box(1)).fmap(lambda box: box.value) == Right(1)
    assert Right(Box(Unit())).fmap(lambda box: box.value) == Right(Unit())



# Generated at 2022-06-24 00:01:56.966277
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-24 00:01:59.712368
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    # Given
    some_box = Box(1)

    # When
    result = some_box.to_maybe()

    # Then
    assert result.value == 1



# Generated at 2022-06-24 00:02:01.201775
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)

# Generated at 2022-06-24 00:02:04.118145
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    test_box = Box(1)

    # When
    lazy = test_box.to_lazy()

    # Then
    assert(lazy.get() == 1)



# Generated at 2022-06-24 00:02:04.969484
# Unit test for constructor of class Box
def test_Box():
    assert Box(None).value == None


# Generated at 2022-06-24 00:02:08.538283
# Unit test for method to_either of class Box
def test_Box_to_either():

    assertBox = Box(None)

    result = assertBox.to_either()

    assert result.is_right() is True
    assert result.is_left() is False
    assert result.get_value() is None


# Generated at 2022-06-24 00:02:14.607449
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box.
    """
    assert Box(5).map(lambda value: value + 1) == Box(6)
    assert Box(5).map(lambda value: 'some string') == Box('some string')
    assert Box(0).map(lambda value: None) == Box(None)


# Generated at 2022-06-24 00:02:17.363607
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:02:18.661245
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2

# Generated at 2022-06-24 00:02:21.160993
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    box = Box(8)

    # When
    lazy = box.to_lazy()

    # When
    assert lazy.value() == 8

# Generated at 2022-06-24 00:02:24.953150
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box("box_value") == Box("box_value")
    assert not (Box("box_value") == Box("other_box_value"))
    assert not (Box("box_value") == "this is not Box")
    assert Box("box_value") == Box("box_value")


# Generated at 2022-06-24 00:02:29.464397
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """Unit test for method __eq__ of class Box
    """
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == 1)



# Generated at 2022-06-24 00:02:33.119955
# Unit test for method map of class Box
def test_Box_map():
    def plus1(x):
        return x + 1

    assert Box(10).map(plus1) == Box(11)
    assert Box('Hello, ').map(plus1) is None



# Generated at 2022-06-24 00:02:35.066724
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1
    assert Box('2').value == '2'
    assert Box([3]).value == [3]
    assert Box({'4': 4}).value == {'4': 4}
    assert Box({5}).value == {5}


# Generated at 2022-06-24 00:02:41.092005
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """Test for method to_validation() of Box class."""
    from pymonet.validation import Validation

    validation = Validation.success(0)
    b = Box(0)
    assert validation == b.to_validation()

# Generated at 2022-06-24 00:02:44.514294
# Unit test for method map of class Box
def test_Box_map():
    test_data = [1, 'test', 123]
    for data in test_data:
        assert Box(data).map(lambda x: x + 1) == Box(data + 1)



# Generated at 2022-06-24 00:02:48.523038
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box('Hello').to_validation() == Validation.success('Hello')


# Generated at 2022-06-24 00:02:56.826282
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import TryException

    # given
    try_value1 = Try(1, is_success=True)
    try_value2 = Try(TryException('Some error occurred'), is_success=False)
    box1 = Box(1)
    try_result1 = box1.to_try()

    # then
    assert try_value1 == try_result1
    assert try_value2 != try_result1



# Generated at 2022-06-24 00:03:00.681559
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try_ = Box(1).to_try()

    assert isinstance(try_, Try)
    assert try_.is_success
    assert try_.get_or_else(None) == 1



# Generated at 2022-06-24 00:03:05.253882
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test bind method of class Box. Should return new Box with mapped value.
    """
    def add5(x: int) -> int:
        return x + 5

    box = Box(12)
    new_box = box.bind(add5)
    assert new_box == Box(17)



# Generated at 2022-06-24 00:03:07.919287
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: 2 * x) == 2
    assert Box("").bind(lambda x: x + "1") == "1"


# Generated at 2022-06-24 00:03:09.645005
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 'some string'
    assert Box(value).to_lazy().value() == value


# Generated at 2022-06-24 00:03:11.330197
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(17).to_lazy().is_instance_of(Box)



# Generated at 2022-06-24 00:03:13.568598
# Unit test for method __str__ of class Box
def test_Box___str__():
    test_case = Box(1)

    expected_result = Box(1)

    assert str(test_case) == str(expected_result)


# Generated at 2022-06-24 00:03:15.024181
# Unit test for constructor of class Box
def test_Box():
    box = Box(5)
    assert isinstance(box, Box)
    assert box.value == 5


# Generated at 2022-06-24 00:03:17.140778
# Unit test for method ap of class Box
def test_Box_ap():
    def f(x: str) -> str:
        return "Hello " + x

    assert Box(f).ap(Box("World")) == Box(f(Box("World").value))


# Generated at 2022-06-24 00:03:19.078932
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) != 10
    assert Box(10) != Box(20)
    assert Box(10) == Box(10)



# Generated at 2022-06-24 00:03:21.092750
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)
    assert Box(1).to_validation().isSuccess() is True

# Generated at 2022-06-24 00:03:24.103763
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 2) == Box(4)



# Generated at 2022-06-24 00:03:27.531407
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    value = 'abc'
    box1 = Box(value)
    box2 = Box(value)
    box3 = Box(123)
    assert box1 == box2
    assert box1 != box3

# Generated at 2022-06-24 00:03:30.265484
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test Box#ap method.
    """

    contains_function = Box(lambda x: x + x)
    contains_argument = Box(2)

    result = contains_function.ap(contains_argument)

    assert result.value == 4

# Generated at 2022-06-24 00:03:34.472332
# Unit test for method ap of class Box
def test_Box_ap():
    box = Box(lambda x: x + 1)

    assert box.ap(Box(1)) == Box(2)
    assert box.ap(Box(0)) == Box(1)
    assert box.ap(Box(-1)) == Box(0)

# Generated at 2022-06-24 00:03:38.775370
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box('5')
    assert Box(5) != Box(10)
    assert Box('5') != Box(10)
    assert Box((5, 10)) != Box([5, 10])


# Generated at 2022-06-24 00:03:41.193285
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    value = 'foo'
    box = Box(value)

    either = box.to_either()

    assert either == Right(value)

# Generated at 2022-06-24 00:03:46.053761
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('something') == Box('something')
    assert Box(1) == Box(1)
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box({'key': 'value'}) == Box({'key': 'value'})
    assert Box(Box({'key': 'value'})) == Box(Box({'key': 'value'}))



# Generated at 2022-06-24 00:03:48.232311
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    validation = Box('test').to_validation()

    assert validation.value == ['test']

# Generated at 2022-06-24 00:03:53.664819
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test Box.ap method.
    """

    def adder(x: int) -> Callable[[int], int]:
        return lambda a: a + x
    
    assert Box(adder(10)).ap(Box(10)) == Box(20)

    def add_and_divide(a: int, b: int) -> float:
        return a / b

    assert Box(add_and_divide).ap(Box(10)).ap(Box(2)) == Box(5)