

# Generated at 2022-06-23 23:53:48.402475
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1
    assert Box(1.0).value == 1.0
    assert Box('1').value == '1'
    assert Box(True).value == True
    assert Box(False).value == False
    assert Box(None).value is None



# Generated at 2022-06-23 23:53:50.925584
# Unit test for constructor of class Box
def test_Box():
    box_test = Box(1)
    assert box_test.value == 1
    assert box_test.map(lambda x: x * 2).value == 2


# Generated at 2022-06-23 23:53:51.834367
# Unit test for method to_validation of class Box
def test_Box_to_validation():

	assert Box("test").to_validation() == Validation.success("test")

# Generated at 2022-06-23 23:53:56.797205
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # GIVEN
    box = Box('test-data')

    # WHEN
    lazy = box.to_lazy()

    # THEN
    assert lazy == Lazy(lambda: 'test-data')

# Generated at 2022-06-23 23:54:00.641396
# Unit test for method map of class Box
def test_Box_map():
    assert str(Box(1).map(lambda x: x ** 2)) == 'Box[value=1]'
    assert str(Box(2).map(lambda x: x ** 2)) == 'Box[value=4]'
    assert str(Box(3).map(lambda x: x ** 2)) == 'Box[value=9]'



# Generated at 2022-06-23 23:54:02.363613
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)



# Generated at 2022-06-23 23:54:05.886767
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert(Box(1).to_lazy() == Lazy(lambda: 1))

# Generated at 2022-06-23 23:54:07.758056
# Unit test for method to_either of class Box
def test_Box_to_either():
    result = Box("true").to_either()
    assert isinstance(result, Right)
    assert result == Right("true")

# Generated at 2022-06-23 23:54:10.673941
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """
    from pymonet.monad_try import Try

    value = 1
    expected = Try(value, is_success=True)

    box = Box(value)
    actual = box.to_try()

    assert actual == expected

# Generated at 2022-06-23 23:54:12.198206
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(1)

    assert str(box) == 'Box[value=1]'

# Generated at 2022-06-23 23:54:16.956601
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    assert Box(1) == Box(1)
    assert Box('one') == Box('one')
    assert Box(None) == Box(None)
    assert not (Box(1) == Box(2))


# Generated at 2022-06-23 23:54:19.661799
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(100).to_try() == Try(100, is_success=True)



# Generated at 2022-06-23 23:54:22.072908
# Unit test for method bind of class Box
def test_Box_bind():
    def double(value):
        return value * 2

    assert Box(2).bind(double) == 4



# Generated at 2022-06-23 23:54:24.830382
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test function for Box class

    :returns: Nothing
    """
    box_int = Box(5)
    box_add_1 = Box(lambda x: x + 1)

    assert box_int.ap(box_add_1) == Box(6)

# Generated at 2022-06-23 23:54:31.691807
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x * 2) == Box(2)



# Generated at 2022-06-23 23:54:41.848706
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(False) == Box(False)
    assert Box(1.1) == Box(1.1)
    assert Box({'value': 1}) == Box({'value': 1})
    assert Box(1) != Box(2)
    assert Box(False) != Box(True)
    assert Box(1.1) != Box(2.2)
    assert Box({'value': 1}) != Box({'value': 2})
    assert Box(1) is not Box(1)
    assert Box(False) is not Box(False)
    assert Box(1.1) is not Box(1.1)
    assert Box({'value': 1}) is not Box({'value': 1})



# Generated at 2022-06-23 23:54:52.106839
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box([1, 2, 3]) != Box([1, 2])
    assert Box((1, 2, 3)) == Box((1, 2, 3))
    assert Box((1, 2, 3)) != Box((1, 2))
    assert Box({1, 2, 3}) == Box({1, 2, 3})
    assert Box({1, 2, 3}) != Box({1, 2})
    assert Box({'a': 1, 'b': 2, 'c': 3}) == Box({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-23 23:54:53.632052
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)



# Generated at 2022-06-23 23:54:58.065572
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Create a function that takes a value and puts it in a box, creating a box.
    Then use map to do something with the value and add it again to the box.

    :return: Monad[A, B]
    :rtype: Box[A]
    """
    def func(x: A) -> B:
        return x ** 2

    box = Box['int'](10).map(func)
    assert type(box) == Box
    assert box.value == 100

# Generated at 2022-06-23 23:55:04.267345
# Unit test for method bind of class Box
def test_Box_bind():
    def return_plus_one(x):
        return x+1

    assert Box(1).bind(return_plus_one) == 2
    assert Box(-232).bind(return_plus_one) == -231
    assert Box('a').bind(return_plus_one) == 'a1'



# Generated at 2022-06-23 23:55:10.160366
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(None).bind(lambda v: v) is None
    assert Box(None).bind(lambda v: Box(v)) is None
    assert Box('aa').bind(lambda v: v) == 'aa'
    assert Box('aa').bind(lambda v: Box(v)) == Box('aa')



# Generated at 2022-06-23 23:55:11.929027
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1).value == 1


# Generated at 2022-06-23 23:55:12.682699
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-23 23:55:18.899091
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(5)
    assert isinstance(box.bind(lambda x: x * 2), int)



# Generated at 2022-06-23 23:55:21.835819
# Unit test for method __str__ of class Box
def test_Box___str__():
    # Given: Box with integer value
    box = Box(10)
    # When: call __str__ method
    string = box.__str__()
    # Then: string is equal 'Box[value=10]'
    assert string == "Box[value=10]"



# Generated at 2022-06-23 23:55:26.977919
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    """
    Test of method to_try of class Box.
    """
    assert Box(1).to_try() == Box(1).to_maybe().to_try()
    assert Box('1').to_try() == Box('1').to_try()

# Generated at 2022-06-23 23:55:32.487138
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('Python')) == "Box[value=Python]"


# Generated at 2022-06-23 23:55:36.028629
# Unit test for method bind of class Box
def test_Box_bind(): # pragma: no cover
    from pymonet.functors.tests.test_maybe import test_Just_bind

    def add(x: int) -> int:
        return x + 4

    test_Just_bind(Box)

# Generated at 2022-06-23 23:55:38.002734
# Unit test for method ap of class Box
def test_Box_ap():
    b = Box(lambda x: x + 1)
    assert b.ap(Box(2)) == Box(3)

# Generated at 2022-06-23 23:55:40.297634
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    box = Box(1)
    assert box.to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:55:46.255309
# Unit test for method to_try of class Box
def test_Box_to_try():
    # AssertionError: assert Try(True, is_success=True) == Try(False, is_success=True)
    assert Box(True).to_try() == Try(True, is_success=True)
    # AssertionError: assert Try(True, is_success=True) == Try(1, is_success=True)
    assert Box(True).to_try() == Try(1, is_success=True)
    # AssertionError: assert Try(True, is_success=True) == Try(1 + 2, is_success=True)
    assert Box(True).to_try() == Try(1 + 2, is_success=True)



# Generated at 2022-06-23 23:55:47.349811
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x + 2) == Box(5)



# Generated at 2022-06-23 23:55:49.620501
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(5)
    mapper = lambda x: x * 2

    assert box.bind(mapper) == mapper(5)



# Generated at 2022-06-23 23:55:50.793222
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'


# Generated at 2022-06-23 23:55:52.269546
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(2)) == 'Box[value=2]'


# Generated at 2022-06-23 23:55:53.694109
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:55:55.947231
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    box = Box(3)
    assert box.to_either() == Right(3)


# Generated at 2022-06-23 23:55:56.978339
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().value() == 42

# Generated at 2022-06-23 23:55:59.025109
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(3).to_validation().is_success
    assert Box(3).to_validation().value == 3
    assert Box(3).to_validation() == Validation.success(3)


# Generated at 2022-06-23 23:56:00.964479
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(5).to_try().get_value() == 5

# Generated at 2022-06-23 23:56:05.359025
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    box = Box('foo')

    # Act
    lazy = box.to_lazy()

    # Assert
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 'foo'
    assert lazy.get() == 'foo'

# Generated at 2022-06-23 23:56:07.774047
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    box = Box(10)
    assert str(box) == 'Box[value=10]'


# Generated at 2022-06-23 23:56:10.799461
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box to Lazy monad.
    """
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-23 23:56:14.500272
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def to_lazy_test_func():
        return 1

    assert Box(1).to_lazy() == Lazy(to_lazy_test_func)



# Generated at 2022-06-23 23:56:16.318684
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.list_ import List

    assert List(Box(1), Box(2), Box(3)).bind(lambda value: value).to_lazy().fold()() == 3



# Generated at 2022-06-23 23:56:17.692413
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:56:20.742003
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)



# Generated at 2022-06-23 23:56:30.963113
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.lazy import Lazy

    assert Box(1).bind(lambda x: x + 2) == 3
    assert Box({'a': 'b'}).bind(lambda x: x['a']) == 'b'
    assert Box((1, 2, 3)).bind(lambda x: x[1]) == 2
    assert Box(Lazy(lambda: 1)).bind(lambda x: x()) == 1
    assert Box(Lazy(lambda: Lazy(lambda: 1))).bind(lambda x: x().bind(lambda y: y)) == 1
    assert Box(Lazy(lambda: Lazy(lambda: Lazy(lambda: 1)))).bind(lambda x: x().bind(lambda y: y.bind(lambda z: z()))) == 1

# Generated at 2022-06-23 23:56:32.912215
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(0).to_either() == Right(0)
    assert Box('test').to_either() == Right('test')
    assert Box(False).to_either() == Right(False)
    assert Box([]).to_either() == Right([])



# Generated at 2022-06-23 23:56:34.231049
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert Box(1).to_try() == Try(1, True)

# Generated at 2022-06-23 23:56:39.719130
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(11).to_try() is Try(11, is_success=True)



# Generated at 2022-06-23 23:56:41.817382
# Unit test for method bind of class Box
def test_Box_bind():
    def double(x):
        return x * 2

    assert Box(4).bind(double) == 8


# Generated at 2022-06-23 23:56:46.855815
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation().is_success
    assert Box(1).to_validation().value == 1


# Generated at 2022-06-23 23:56:48.774490
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box("foo").to_either() == Right("foo")

# Generated at 2022-06-23 23:56:54.312473
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert str(Box(1)) == "Box[value=1]"



# Generated at 2022-06-23 23:56:55.400876
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1).value == 2



# Generated at 2022-06-23 23:57:00.676754
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    result = Box(42).to_either()
    assert isinstance(result, Right)
    assert result.value == 42



# Generated at 2022-06-23 23:57:02.143782
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(123).to_either() == Right(123)

# Generated at 2022-06-23 23:57:03.780293
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-23 23:57:05.936506
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Nothing

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Nothing().to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:57:12.109756
# Unit test for method to_try of class Box
def test_Box_to_try():
    def f(x):  # pragma: no cover
        return 1 / x

    try_box = Box(0, 0).to_try()
    try:
        try_box.get()
        assert False
    except ZeroDivisionError:
        assert True

    print(Box(0, 0).map(f).to_try())

# Generated at 2022-06-23 23:57:13.719607
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-23 23:57:16.140676
# Unit test for method map of class Box
def test_Box_map():
    box = Box(3.14)
    assert box.map(lambda x: str(x)) == Box('3.14')


# Generated at 2022-06-23 23:57:16.909228
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:57:24.807204
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    just_box = Box(Maybe.just(3))
    nothing_box = Box(Maybe.nothing())

    assert just_box.to_try() == Try(3, is_success=True)
    assert nothing_box.to_try() == Try(None, is_success=False)



# Generated at 2022-06-23 23:57:27.731391
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-23 23:57:29.967031
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(Box(1).value)

# Generated at 2022-06-23 23:57:33.358463
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Box applicatives is working correctly.
    """
    assert Box(lambda x: x + 2).ap(Box(10)) == Box(12)
    assert Box(lambda x: x * 2).ap(Box(10)) == Box(20)
    assert Box(lambda x: x / 2).ap(Box(10)) == Box(5)



# Generated at 2022-06-23 23:57:37.031897
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda value: 2 * value) == 20



# Generated at 2022-06-23 23:57:39.830487
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, True)


# Generated at 2022-06-23 23:57:45.380210
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box = Box('foo')
    value = box.to_validation()

    assert value.is_valid
    assert value.get_value() == 'foo'

# Generated at 2022-06-23 23:57:48.009657
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('test')) == 'Box[value=test]'


# Generated at 2022-06-23 23:57:56.835865
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(42).to_either() == Right(42)
    assert Box("Hello").to_either() == Right("Hello")
    assert Box(True).to_either() == Right(True)

    # Asserting floats
    assert Box(3.14).to_either() == Right(3.14)
    assert Box(0.0).to_either() == Right(0.0)
    assert Box(345.6e-7).to_either() == Right(345.6e-7)


# Generated at 2022-06-23 23:58:00.224352
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box([1])
    assert Box(1) != 1

# Generated at 2022-06-23 23:58:02.193466
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:58:05.218852
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)
    assert Box('hello').to_try() == Try('hello')
    assert Box(False).to_try() == Try(False)


# Generated at 2022-06-23 23:58:09.294164
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(Box(1)) == Box(Box(1))

# Generated at 2022-06-23 23:58:14.320938
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(1).map(lambda x: x + 1) == Box(2)


# Generated at 2022-06-23 23:58:16.550361
# Unit test for method ap of class Box
def test_Box_ap():
    result = Box(lambda x: x * x).ap(Box(4))
    assert result == Box(16)


# Generated at 2022-06-23 23:58:22.347777
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:58:24.912722
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(5) == Box(5)



# Generated at 2022-06-23 23:58:26.257858
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-23 23:58:28.979008
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box('Hello, World!').to_lazy().fold(lambda: 1) == 'Hello, World!'

# Generated at 2022-06-23 23:58:31.146944
# Unit test for constructor of class Box
def test_Box():
    assert(Box('') == Box(''))
    assert(str(Box('x')) == "Box[value=x]")



# Generated at 2022-06-23 23:58:34.673056
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for bind method.

    Side effects:
        - test for bind when arg is lambda with square
        - test for bind when arg is lambda with cube
    """
    assert Box(2).bind(lambda x: x ** 2) == 4
    assert Box(3).bind(lambda x: x ** 3) == 27

# Generated at 2022-06-23 23:58:36.398025
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:58:37.920927
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)



# Generated at 2022-06-23 23:58:40.420780
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Tests Box.to_lazy() method
    """

    assert Box(2).to_lazy().value is None
    assert Box(2).to_lazy()._eval() == Box(2).value

# Generated at 2022-06-23 23:58:41.844604
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)



# Generated at 2022-06-23 23:58:43.181076
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)



# Generated at 2022-06-23 23:58:45.440993
# Unit test for method to_validation of class Box
def test_Box_to_validation():
	from pymonet.validation import Validation
	box = Box(42)
	assert (Validation.success(42) == box.to_validation())

# Generated at 2022-06-23 23:58:48.193064
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1



# Generated at 2022-06-23 23:58:52.434707
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box('a').to_maybe().is_just()


# Generated at 2022-06-23 23:58:53.993616
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_maybe()



# Generated at 2022-06-23 23:58:57.986013
# Unit test for method to_try of class Box
def test_Box_to_try():
    # When
    try_monad = Box(5).to_try()

    # Then
    assert try_monad.is_success is True
    assert try_monad.value == 5
    assert try_monad.failure == None


# Generated at 2022-06-23 23:59:01.440680
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(1)
    validation = box.to_validation()
    assert validation == Validation.success(1)



# Generated at 2022-06-23 23:59:05.584583
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:59:07.122962
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:59:08.986964
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box('a').to_either() == Right('a')



# Generated at 2022-06-23 23:59:14.600817
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-23 23:59:16.763687
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == "Box[value=1]"



# Generated at 2022-06-23 23:59:18.238727
# Unit test for constructor of class Box
def test_Box():
    b = Box(100)
    assert b.value == 100



# Generated at 2022-06-23 23:59:21.222373
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    """
    Unit test for method bind of class Box
    """
    assert Box(4).bind(lambda value: value / 2) == 2


# Generated at 2022-06-23 23:59:22.766187
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    first_box = Box(1)

    assert first_box == Box(1)
    assert first_box != Box(2)



# Generated at 2022-06-23 23:59:27.592615
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Try

    assert Box(10) == Box(10)
    assert not Try(10, is_success=True) == Box(10)
    assert not Try(10, is_success=True) == Try(1, is_success=True)

# Generated at 2022-06-23 23:59:30.176168
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('one') == Box('one')
    assert Box('one').value == 'one'



# Generated at 2022-06-23 23:59:34.399456
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe
    from pymonet.tuple import Tuple2

    assert Box(lambda x, y: x + y).ap(Maybe.just(Tuple2(1, 2))) == Maybe.just(3)
    assert Box(lambda x, y: x + y).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-23 23:59:37.566969
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(Box(1)).bind(lambda x: x.value + 1) == 2
    assert Box(Box(Box(1))).bind(lambda x: x.value.value + 1) == 2


# Generated at 2022-06-23 23:59:42.872555
# Unit test for method map of class Box
def test_Box_map():
    # GIVEN
    try:
        from pymonet.maybe import Maybe
        from pymonet.either import Right, Left
    except ImportError:  # pragma: no cover
        return

    # WHEN/THEN
    assert Box(10).map(lambda x: x + 1) == Box(11)
    assert Box(Maybe.just(10)).map(lambda x: x + 1) == Box(Maybe.just(11))
    assert Box(Right(10)).map(lambda x: x + 1) == Box(Right(11))
    assert Box(Left(10)).map(lambda x: x + 1) == Box(Left(10))



# Generated at 2022-06-23 23:59:44.087684
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(5).to_maybe() == (5)
    assert Box('abc').to_maybe() == 'abc'


# Generated at 2022-06-23 23:59:45.859029
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box('42').to_try() == Try('42', is_success=True)

# Generated at 2022-06-23 23:59:50.303475
# Unit test for method to_either of class Box
def test_Box_to_either():
    box: Box[int] = Box(1)
    assert box.to_either().value == 1



# Generated at 2022-06-23 23:59:52.582854
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-23 23:59:56.396243
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(1)
    assert str(box) == 'Box[value=1]'

# Generated at 2022-06-23 23:59:59.896765
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    assert Box(1).to_try() == Try(1)
    assert Box(Failure('failure')).to_try() == Failure('failure')


# Generated at 2022-06-24 00:00:04.999552
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    boxed_try = Box(1).to_try()
    assert isinstance(boxed_try, Try)
    assert boxed_try == Try(1, is_success=True)


# Generated at 2022-06-24 00:00:06.712001
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-24 00:00:09.761062
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Test for method __str__ of class Box
    """

    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(10)) == 'Box[value=10]'


# Generated at 2022-06-24 00:00:11.608577
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-24 00:00:14.406439
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe(42).to_box().to_maybe() == Maybe(42)
    assert Maybe.empty().to_box().to_maybe() == Maybe.empty()


# Generated at 2022-06-24 00:00:16.546335
# Unit test for method bind of class Box
def test_Box_bind():
    """ Unit test for bind method """
    box = Box(1)
    var = box.bind(int).bind(str).bind(str.capitalize)

    assert box.value == 1
    assert var == '1'

# Generated at 2022-06-24 00:00:18.541601
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-24 00:00:20.273400
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    # Arrange
    box = Box(1)

    # Act
    validation = box.to_validation()

    # Assert
    assert validation.value == 1

# Generated at 2022-06-24 00:00:25.069621
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda v: v * 10) == 20



# Generated at 2022-06-24 00:00:26.005704
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-24 00:00:27.360126
# Unit test for constructor of class Box
def test_Box():
    box_ = Box(2)
    assert box_.value == 2
    assert box_ == Box(2)


# Generated at 2022-06-24 00:00:33.029952
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Left

    assert Box(123).to_validation() == Validation(success=Left(123), fail=Left([]))


# Generated at 2022-06-24 00:00:35.645333
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.monad_try import Failure

    assert Box(42).to_either() == Right(42)
    assert Box(Failure()).to_either() == Right(Failure())



# Generated at 2022-06-24 00:00:37.049095
# Unit test for method map of class Box
def test_Box_map():
    box: Box[int] = Box(1)
    result = box.map(lambda x: x + 1)
    assert type(result) == Box
    assert result.value == 2


# Generated at 2022-06-24 00:00:38.697466
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x*x) == Box(4)


# Generated at 2022-06-24 00:00:42.317332
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test of to_either method of Box class
    """
    from pymonet.either import Left

    assert Box(1).to_either() == Right(1)
    assert Box(Left(1)).to_either() == Left(1)

# Generated at 2022-06-24 00:00:45.226903
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != 1
    assert not Box(1) == Box(2)



# Generated at 2022-06-24 00:00:48.031746
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    box = Box('test_value')
    assert box.to_try() == Try(box.value, is_success=True)


# Generated at 2022-06-24 00:00:50.214767
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box('Hello, world!')

    assert str(box) == 'Box[value=Hello, world!]'


# Generated at 2022-06-24 00:00:53.095599
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-24 00:00:59.961218
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Either
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box([1]) != Box([1])
    assert Box(Maybe.nothing()) == Box(Maybe.nothing())
    assert Box(Maybe.just(1)) != Box(Maybe.just(2))
    assert Box(Try.success(1)) != Box(Try.success(2))
    assert Box(Try.failure('some')) == Box(Try.failure('some'))
    assert Box(Either.left('some')) == Box(Either.left('some'))
   

# Generated at 2022-06-24 00:01:02.980070
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)
    assert Box("test").to_validation() == Validation.success("test")



# Generated at 2022-06-24 00:01:05.249048
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_functors import unit

    assert repr(unit(2).to_lazy()) == repr(Lazy(lambda: 2))

# Generated at 2022-06-24 00:01:08.550436
# Unit test for method bind of class Box
def test_Box_bind():
    def multiply(x):
        return x * 2

    assert Box(2).bind(multiply) == 4

    def raised_exception(x):
        raise Exception('Test exception')

    try:
        Box(2).bind(raised_exception)
    except Exception as e:
        assert e.args[0] == 'Test exception'
    else:
        raise AssertionError('add more tests here')



# Generated at 2022-06-24 00:01:11.131576
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)
    assert Box(5) == 5
    assert Box(5) != 6


# Generated at 2022-06-24 00:01:14.411893
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """Unit test for method to_validation of class Box"""

    from pymonet.validation import Validation

    validation = Box(42).to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.value == 42



# Generated at 2022-06-24 00:01:17.094354
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Box(1) == Box(1)
    assert (Box(1) == Box(1))

    # Box(1) != Box(2)
    assert (Box(1) != Box(2))

    # Box(1) == 1
    assert (Box(1) != 1)



# Generated at 2022-06-24 00:01:18.946276
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(4)
    assert Box(5) != '5'


# Generated at 2022-06-24 00:01:20.869770
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-24 00:01:23.997687
# Unit test for method bind of class Box
def test_Box_bind():
    result1 = Box(lambda a: a*2).bind(lambda x: x(2))
    result2 = Box(lambda a: a*3).bind(lambda x: x(3))
    assert result1 == 4
    assert result2 == 9



# Generated at 2022-06-24 00:01:25.850618
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(True) == Box(True)


# Generated at 2022-06-24 00:01:33.604330
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert Box(1).__str__() == 'Box[value=1]', 'Box contains 1. __str__() should return Box[value=1]'
    assert Box('value').__str__() == 'Box[value=value]', 'Box contains value. __str__() should return Box[value=value]'
    assert Box(Box(1)).__str__() == 'Box[value=Box[value=1]]', 'Box contains box. __str__() should return Box[value=Box[value=1]]'


# Generated at 2022-06-24 00:01:35.969221
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:01:37.778690
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-24 00:01:40.291686
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box_var = Box(1)
    from pymonet.validation import Validation
    assert box_var.to_validation().value == Validation(1, []).value


# Generated at 2022-06-24 00:01:45.194991
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def test_method(value):
        # Test method on Lazy type
        assert isinstance(value, Box[int].to_lazy(), Lazy)
        assert value.get() == 1
        assert not value.is_folded()

        # Test method on Try type
        assert isinstance(value, Box[int].to_try(), Try)
        assert value.is_success()
        assert value.get() == 1

    return test_method



# Generated at 2022-06-24 00:01:47.914668
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)


# Generated at 2022-06-24 00:01:49.901279
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-24 00:01:51.504823
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Try.unit(10) == Box(10).to_try()



# Generated at 2022-06-24 00:02:00.161390
# Unit test for constructor of class Box
def test_Box():
    from test.test_utils import print_header_for_test, print_footer_for_test
    from pymonet.lazy import Lazy

    print_header_for_test("Test constructor of class Box")

    assert str(Box(5)) == "Box[value=5]"
    assert repr(Box(5)) == "Box[value=5]"
    assert isinstance(Box(5), Box)
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)
    assert Box(5) != 5

    print_footer_for_test()



# Generated at 2022-06-24 00:02:02.144247
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(10).to_validation() == Box(10).to_try().to_validation()


# Generated at 2022-06-24 00:02:04.704010
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    Box(1).map(str) == Box('1')


# Generated at 2022-06-24 00:02:10.364369
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for to_maybe method of Box class.
    """
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Maybe.just(3).to_box() == Box(3)
    assert Maybe.nothing().to_box() == None


# Generated at 2022-06-24 00:02:12.046521
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert Box(123).__str__() == 'Box[value=123]'

# Generated at 2022-06-24 00:02:16.243563
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test Box.bind()
    """

    def foo(value: int) -> str:
        return str(value)

    box = Box(1).bind(foo)

    assert str(box) == 'Box[value=1]'



# Generated at 2022-06-24 00:02:19.394667
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.monad_maybe import Maybe

    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(Maybe.just(1)).bind(lambda x: x * 2) == Maybe.just(2)



# Generated at 2022-06-24 00:02:20.622851
# Unit test for method map of class Box
def test_Box_map():
    assert type(Box(1).map(lambda x: x + 1)) == Box



# Generated at 2022-06-24 00:02:22.428991
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)



# Generated at 2022-06-24 00:02:24.709898
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(10)
    box2 = Box(10)
    box3 = Box(11)

    assert box1 == box2
    assert box1 != box3

# Generated at 2022-06-24 00:02:27.490664
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    # Test with empty box
    assert Box(None).to_validation() == Validation.success(None)

    # Test with filled box
    assert Box("test").to_validation() == Validation.success("test")


# Generated at 2022-06-24 00:02:30.985618
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_value = 5
    box = Box(test_value)
    lazy_value = box.to_lazy()

    assert lazy_value.get_value() == test_value

# Generated at 2022-06-24 00:02:36.507976
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test for Box.ap method.
    """
    from pymonet.functor import Functor
    from pymonet.lazy import Lazy

    functor = Functor(lambda x: x + 1)
    lazy_num = Lazy(lambda: 1)

    assert lazy_num.ap(functor).value() == 2

# Generated at 2022-06-24 00:02:40.286076
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box("value").to_lazy().unfold() == "value"


# Generated at 2022-06-24 00:02:44.671895
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)
    assert Box(1).map(lambda x: x * 2) == Box(2)
    assert Box(2).map(lambda x: x ** 2) == Box(4)



# Generated at 2022-06-24 00:02:48.597733
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(1).map(lambda x: x + 1) == Box(2)


# Generated at 2022-06-24 00:02:53.160184
# Unit test for method bind of class Box
def test_Box_bind():
    def greater_then_two(value):
        return Box(value > 2)

    assert Box(1).bind(greater_then_two) == Box(False)
    assert Box(3).bind(greater_then_two) == Box(True)


# Generated at 2022-06-24 00:02:58.047373
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(4)) == Box(5)
    assert Box((lambda x: x + 1)).bind(lambda x: x(4)) == 5
    assert Box(lambda x: x + 1).ap(Box(4)) == Box(5)

# Generated at 2022-06-24 00:02:59.233403
# Unit test for constructor of class Box
def test_Box():
    assert Box(5).value == 5


# Generated at 2022-06-24 00:03:00.814066
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(42)) == 'Box[value=42]'



# Generated at 2022-06-24 00:03:02.827782
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)

    assert not (Box(1) == Box(2))



# Generated at 2022-06-24 00:03:04.864866
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)

# Generated at 2022-06-24 00:03:06.742517
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    assert isinstance(Box(1).to_either(), Either)



# Generated at 2022-06-24 00:03:10.361250
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x + 10) == 15
    assert Box(5).bind(lambda x: x + 5) == 10
    assert Box("abcdefg").bind(lambda x: x[2:]) == "cdefg"



# Generated at 2022-06-24 00:03:14.908108
# Unit test for method map of class Box
def test_Box_map():
    box = Box(2)
    assert isinstance(box.map(lambda x: x * 2), Box)  # result of map is instance of Box class
    assert box.map(lambda x: x * 2).value == 4  # result of map is instance of Box class
    assert box.map(lambda x: x * 2) == Box(4)  # result of map is instance of Box class



# Generated at 2022-06-24 00:03:16.269787
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Right(2).equals(Box(2).to_either())

# Generated at 2022-06-24 00:03:18.063981
# Unit test for method map of class Box
def test_Box_map():
    def f(x):
        return x + 1

    assert Box(1).map(f) == Box(2)



# Generated at 2022-06-24 00:03:19.310067
# Unit test for method to_lazy of class Box

# Generated at 2022-06-24 00:03:21.688458
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)



# Generated at 2022-06-24 00:03:26.821808
# Unit test for method bind of class Box
def test_Box_bind():
    def add_five(value: int) -> int:
        return value + 5

    assert Box(10).bind(add_five) == 15
    assert Box(str).bind(str)(10) == '10'


# Generated at 2022-06-24 00:03:28.816927
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-24 00:03:32.298939
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    test_value = 42
    box_value = Box(test_value)

    assert box_value.to_either() == Right(box_value.value)


# Generated at 2022-06-24 00:03:34.622175
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:03:36.242102
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box("str").bind(str.upper()) == "STR"


# Generated at 2022-06-24 00:03:38.684742
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert isinstance(Box("hello").to_try(), Try)


# Generated at 2022-06-24 00:03:44.119805
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('1') == Box('1')
    assert Box({'value': 'str'}) == Box({'value': 'str'})
    assert Box(1) != Box('1')
    assert Box(1) != Box({'value': 'str'})
    assert Box('1') != Box(1)
    assert Box('1') != Box({'value': 'str'})



# Generated at 2022-06-24 00:03:46.919662
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x + 3) == Box(6)

