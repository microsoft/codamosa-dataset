

# Generated at 2022-06-23 23:53:57.498917
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    # Arrange
    class A(Functor, Applicative):
        def __init__(self, value):
            self._value = value

        def __eq__(self, other):
            return isinstance(other, A) and self.value == other.value

        def __str__(self):
            return "A[value={}]".format(self.value)

        @property
        def value(self):
            return self._value

        def map(self, mapper):
            return A(mapper(self.value))

        @staticmethod
        def pure(value):
            return A(value)

        def ap(self, applicative):
            return (self.value(applicative.value))

    box1

# Generated at 2022-06-23 23:53:59.141142
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(5).to_either() == Right(5)


# Generated at 2022-06-23 23:54:00.607471
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-23 23:54:08.162110
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right
    assert Box(2).to_either() == Right(2)
    assert Box(1).to_either() == Right(1)
    assert Box(3).to_either() == Right(3)
    assert Box(5).to_either() == Right(5)
    try:
        assert Box(6).to_either() == Left(6)
    except AssertionError:
        return
    raise AssertionError

# Generated at 2022-06-23 23:54:11.033125
# Unit test for method __str__ of class Box
def test_Box___str__():
    from pymonet.monadtype import assert_equal
    assert_equal(str(Box(10)), 'Box[value=10]')

# Generated at 2022-06-23 23:54:13.889245
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.test_utils import eq_test

    eq_test(Box(1), Box(1), 'Box eq test')



# Generated at 2022-06-23 23:54:17.270485
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    assert Box(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-23 23:54:19.952432
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('2')) == 'Box[value=2]'


# Generated at 2022-06-23 23:54:25.979063
# Unit test for method map of class Box
def test_Box_map():
    """
    Test Box map function.

    If map function works well it should return Box with mapped value.
    """
    assert Box(2).map(lambda val: val * 2).value == 4



# Generated at 2022-06-23 23:54:28.277829
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test bind method of Box class
    """
    assert Box(10).bind(lambda x: x * 2) == 20



# Generated at 2022-06-23 23:54:29.309735
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:54:33.620462
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Box('Hello').to_validation() == Validation.success('Hello')


# Generated at 2022-06-23 23:54:37.632600
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 5).ap(Box(10)) == Box(15)
    assert Box(10).ap(Box(lambda x: x + 5)) == Box(15)



# Generated at 2022-06-23 23:54:39.355291
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 1
    box = Box(value)

    assert box.to_lazy().run() == value

# Generated at 2022-06-23 23:54:41.262441
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(3).map(lambda x: x + 1) == Box(4)



# Generated at 2022-06-23 23:54:45.737541
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try(1, is_success=True) == Box(1).to_try()



# Generated at 2022-06-23 23:54:48.459949
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('str') == Box('str')
    assert not Box(1) == Box('str')
    assert not Box(1) == {}


# Generated at 2022-06-23 23:54:50.401538
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-23 23:54:55.002955
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-23 23:54:55.704184
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(2)

    assert box.to_lazy().value() == 2

# Generated at 2022-06-23 23:54:56.816947
# Unit test for method to_either of class Box
def test_Box_to_either():
    """ Unit testing for toEither method of class Box
    """
    assert Box(1).to_either() == Box(1).bind(lambda value: Box(value).to_either())

# Generated at 2022-06-23 23:54:58.274150
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_try import Try

    assert Try(lambda x: x + 1).ap(Box(2)) == Try(3)

# Generated at 2022-06-23 23:55:00.036812
# Unit test for method __str__ of class Box
def test_Box___str__():
    # given
    box = Box(1)

    # when
    actual = str(box)

    # then
    assert actual == 'Box[value=1]'

# Generated at 2022-06-23 23:55:01.559793
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:55:03.082639
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(5).to_try() == Box(5).value, 'test_Box_to_try failed'


# Generated at 2022-06-23 23:55:08.133787
# Unit test for method ap of class Box
def test_Box_ap():
    def add(a):
        return lambda b: a + b

    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)
    assert Box(2).ap(Box(add)) == Box(Box(2).bind(add))



# Generated at 2022-06-23 23:55:13.532105
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.validation import ValidationSuccess

    initial_value = 'str'
    validation_success_func = lambda value: ValidationSuccess('validation_success_func {}'.format(value))

    binded_box = Box(initial_value).bind(validation_success_func)

    assert binded_box.value == 'validation_success_func {}'.format(initial_value)



# Generated at 2022-06-23 23:55:15.811035
# Unit test for method __str__ of class Box
def test_Box___str__():
    value = 'value'
    box = Box(value)

    assert str(box) == 'Box[value={}]'.format(value)



# Generated at 2022-06-23 23:55:19.209772
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(1).map(lambda x: x + 2) == Box(3)



# Generated at 2022-06-23 23:55:23.532534
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)


# Generated at 2022-06-23 23:55:24.758540
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:55:28.148006
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box([])) == "Box[value=[]]"
    assert str(Box(2)) == "Box[value=2]"
    assert str(Box(Box(Box('1')))) == "Box[value=Box[value=Box[value='1']]]"


# Generated at 2022-06-23 23:55:33.787198
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    # Success case
    value = 10
    maybe = Box(10).to_lazy()
    assert isinstance(maybe, Lazy)
    assert maybe.fold() == value

    # Fail case
    maybe = Box(Maybe.nothing()).to_lazy()
    assert isinstance(maybe, Lazy)
    assert maybe.fold() is None


# Generated at 2022-06-23 23:55:39.450167
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a = Box(42).to_lazy()
    assert a.value() == 42



# Generated at 2022-06-23 23:55:40.430653
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(5).to_either() == 5


# Generated at 2022-06-23 23:55:46.480521
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test of unit test method to_maybe of class Box
    """
    from pymonet.maybe import Just, Maybe

    just_box = Box(1)
    unit_test_result = just_box.to_maybe()
    assert isinstance(unit_test_result, Maybe)
    assert unit_test_result == Just(1)



# Generated at 2022-06-23 23:55:48.347536
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-23 23:55:50.501121
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(3).to_validation() == Validation.success(3)

# Generated at 2022-06-23 23:55:54.162344
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    r = Box("test_string").to_validation()

    assert isinstance(r, Validation)
    assert r.is_success() == True
    assert r.success_value == "test_string"


# Generated at 2022-06-23 23:55:56.411094
# Unit test for constructor of class Box
def test_Box():
    test_value = 'test'
    box = Box(test_value)

    assert box.value == test_value



# Generated at 2022-06-23 23:55:58.220242
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-23 23:56:01.964322
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """Unit tests for method __eq__ of class Box."""
    # then
    assert Box(5) == Box(5)
    assert not (Box(5) == Box("5"))



# Generated at 2022-06-23 23:56:04.552646
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(10)
    assert Maybe.just(10) == box.to_maybe()



# Generated at 2022-06-23 23:56:06.571315
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(0).to_lazy() == Lazy(lambda: 0)



# Generated at 2022-06-23 23:56:11.715677
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('a').map(lambda x: x + 'b') == Box('ab')
    assert Box(True).map(lambda x: not x) == Box(False)
    assert Box(1.1).map(lambda x: x + 0.2) == Box(1.3)


# Generated at 2022-06-23 23:56:13.109053
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(1) | 'to_either' | 'get_value' == 1



# Generated at 2022-06-23 23:56:15.080938
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_option import MonadOption
    from pymonet.lazy import Lazy

    box_lazy = Box(Lazy(lambda: 2))
    box_monad_option = Box(MonadOption.just(2))
    assert box_lazy.ap(box_monad_option).value() == 4

# Generated at 2022-06-23 23:56:16.448190
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)



# Generated at 2022-06-23 23:56:18.187765
# Unit test for constructor of class Box
def test_Box():
    assert Box(5) == Box(5)
    assert Box('5') == Box('5')
    assert Box([5]) == Box([5])



# Generated at 2022-06-23 23:56:22.142844
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    # When
    try_ = Box(3).to_try()

    # Then
    assert Try(3, is_success=True) == try_


# Generated at 2022-06-23 23:56:26.083201
# Unit test for method bind of class Box
def test_Box_bind():
    """Unit test for using Box monad"""
    # pylint: disable=unused-argument
    def add_five(value: int) -> int:
        """
        Function to add five to value.

        :param value: value to add five
        :type value: int
        :returns: value + 5
        :rtype: int
        """
        return value + 5

    assert Box(0).bind(add_five) == 5

    assert Box(10).bind(add_five) == 15

    # pylint: enable=unused-argument



# Generated at 2022-06-23 23:56:26.900653
# Unit test for constructor of class Box
def test_Box():
    box = Box(10)
    assert box == Box(10)

# Generated at 2022-06-23 23:56:29.764845
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(3).to_maybe() == Maybe.just(3)


# Generated at 2022-06-23 23:56:34.933343
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    my_box = Box(11)

    assert my_box.to_try() == Try(11, is_success=True)
    assert my_box.to_try() == Box(Try(11, is_success=True)).to_try()
    assert my_box.to_validation() == Validation.success(11)
    assert my_box.to_validation() == Box(Validation.success(11)).to_validation()
    assert my_box.to_lazy() == Lazy(lambda: 11)
    assert my_box.to_lazy() == Box(Lazy(lambda: 11)).to_lazy()



# Generated at 2022-06-23 23:56:38.691886
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert 'Box[value={}]'.format(123) == str(Box(123))

# Generated at 2022-06-23 23:56:40.697610
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    actual = Box(5).to_either()
    expected = Right(5)
    assert actual == expected

# Generated at 2022-06-23 23:56:43.858677
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5) == Box(5)
    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-23 23:56:47.782640
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != 2
    assert Box('1') != Box(1)



# Generated at 2022-06-23 23:56:51.725877
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left

    assert Box(1).to_either() == Right(1)
    assert Box('').to_either() == Right('')
    assert Box(None).to_either() == Right(None)
    assert Box(False).to_either() == Right(False)
    assert Box(True).to_either() == Right(True)



# Generated at 2022-06-23 23:56:53.044913
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)



# Generated at 2022-06-23 23:56:56.865483
# Unit test for method bind of class Box
def test_Box_bind():
    assert not Box(1).bind(lambda x: x == 2)
    assert Box(1).bind(lambda x: x == 2) is False
    assert Box(2).bind(lambda x: x == 2) is True
    assert Box(3).bind(lambda x: 2 * x) == 6


# Generated at 2022-06-23 23:57:00.547616
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(1).to_lazy().get() == 1

# Generated at 2022-06-23 23:57:03.032773
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('hello world') == Box('hello world')
    assert str(Box(123)) == 'Box[value=123]'



# Generated at 2022-06-23 23:57:08.861271
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box({'a', 'b'}) == Box({'b', 'a'})
    assert Box(['a', 'b']) == Box(['a', 'b'])
    assert Box(2) == Box(2.0)


test_Box___eq__()

# Generated at 2022-06-23 23:57:11.226988
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    assert Box(True) == Box(True).to_try()

# Generated at 2022-06-23 23:57:20.888467
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.either import Left

    assert Box('foo').to_either() == Right('foo')
    assert Box(None).to_either() == Right(None)

    assert Box(Left(1)).to_either() == Left(1)
    assert Box(Right(1)).to_either() == Right(1)


# Generated at 2022-06-23 23:57:25.194966
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1) is True
    assert Box(1) == Box(2) is False
    assert Box(1) != Box(1) is False
    assert Box(1) != Box(2) is True
    assert Box(1) != Box('1') is True



# Generated at 2022-06-23 23:57:27.280896
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('some value')) == 'Box[value=some value]'

# Generated at 2022-06-23 23:57:29.914511
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just, NoneMonad

    assert Box(1).to_maybe() == Just(1)
    # assert Box(None).to_maybe() == NoneMonad()



# Generated at 2022-06-23 23:57:31.180632
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:57:33.173586
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-23 23:57:38.106485
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, Failure

    assert Try.just(5).to_box() == Box(5)
    assert Failure(ValueError('error message')).to_box() == Box(ValueError('error message'))


# Generated at 2022-06-23 23:57:40.134710
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).value


# Generated at 2022-06-23 23:57:42.415736
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box.
    """

    assert Box(2).to_try() == Try(2, is_success=True)

# Generated at 2022-06-23 23:57:44.722839
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest

    from pymonet.monad_try import Try

    assert Try.unit(Box(1).to_lazy()).to_maybe().bind(lambda lazy: lazy.eval()).value == 1

# Generated at 2022-06-23 23:57:49.600690
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.monad_try import Try

    assert Box(1).to_either() == Right(1)
    assert Box(1).to_either().bind(lambda x: Right(x + 1)) == Right(2)

    try:
        assert Box(1).to_either().bind(lambda x: Right(x())) == Right(2)
        assert False, 'Box.to_either should raises TypeError'
    except TypeError:
        assert True



# Generated at 2022-06-23 23:57:53.534095
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_result import MonadResult

    assert Box(1).to_try() == Try(result=1, is_success=True)
    assert Box(1).to_try() == Try(result=1, is_success=True)
    assert Box(1).to_try() is not Box(1).to_try()
    assert Box(1).to_try() is not Box(1).to_try()
    assert Box(1).to_try() == MonadResult.success(1)
    assert Box(1).to_try() == MonadResult.success(1)
    assert Box(1).to_try() is not MonadResult.success(1)
    assert Box(1).to_try() is not MonadResult.success(1)

# Generated at 2022-06-23 23:57:54.627729
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda v: v * 2) == Box(20)



# Generated at 2022-06-23 23:58:00.171040
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(5).value == 5
    assert str(Box(5)) == 'Box[value=5]'
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)



# Generated at 2022-06-23 23:58:02.482289
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    test_Box = Box(1)
    assert test_Box.to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:58:05.184688
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)
    assert Box(Exception()).to_try() == Try(Exception(), is_success=True)


# Generated at 2022-06-23 23:58:07.477740
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation() == Validation.success(5)



# Generated at 2022-06-23 23:58:11.775361
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    value = 15
    #: test case 1:
    assert Box(value).to_validation() == Validation.success(value)
    #: test case 2:
    assert Box(value).to_validation().failures == []


# Generated at 2022-06-23 23:58:15.388808
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box('foo')
    box2 = Box('foo')
    box3 = Box('bar')

    assert box1 == box2
    assert box1 != box3


# Generated at 2022-06-23 23:58:17.168853
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-23 23:58:20.226866
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.validation import Validation
    adder = lambda a: lambda b: a + b
    box_with_adder = Box(adder)
    assert Validation.success(5).ap(Validation.success(adder)) == Validation.success(5).ap(box_with_adder)

# Generated at 2022-06-23 23:58:21.562054
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(str) == '1'



# Generated at 2022-06-23 23:58:23.461962
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:58:33.751737
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Success

    empty_box = Box(1)
    success = Try.success(1)
    failure = Try.failure(Exception('Value'))

    assert empty_box.to_try() == success
    assert empty_box.map(_).to_try() == success
    assert empty_box.map(lambda x: Failure(Exception('Value'))).to_try() == failure
    assert empty_box.map(lambda x: Success(x)).to_try() == success
    assert empty_box.map(lambda x: Failure(Exception('Value'))).to_try() == failure


# Generated at 2022-06-23 23:58:35.568187
# Unit test for method ap of class Box
def test_Box_ap():
    def _function(value):
        return value * 2

    assert Box(1).ap(Box(_function)) == Box(_function(1))



# Generated at 2022-06-23 23:58:38.048949
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Check transformation of Box to Maybe.
    """
    from pymonet.maybe import Maybe

    assert Maybe.just(42) == Box(42).to_maybe()



# Generated at 2022-06-23 23:58:41.522952
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    maybe = box.to_maybe()

    assert isinstance(maybe, Maybe)
    assert maybe.value == box.value


# Generated at 2022-06-23 23:58:43.145775
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for Box.__str__
    """
    assert str(Box(10)) == 'Box[value=10]'


# Generated at 2022-06-23 23:58:44.200110
# Unit test for method to_either of class Box
def test_Box_to_either():
    box = Box(1)
    assert box.to_either().value == 1

# Generated at 2022-06-23 23:58:46.710087
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:58:52.175126
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda num: num + 3) == 5


# Generated at 2022-06-23 23:58:56.233968
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('str')) == 'Box[value=str]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(1.0)) == 'Box[value=1.0]'
    assert str(Box(None)) == 'Box[value=None]'

# Generated at 2022-06-23 23:58:57.880634
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    value = 'test'
    box = Box(value)

    assert box.value == value



# Generated at 2022-06-23 23:59:00.738397
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(10)) == Box(11)



# Generated at 2022-06-23 23:59:05.362807
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(5).ap(Box(lambda x: x * x)) == Box(25)



# Generated at 2022-06-23 23:59:06.137784
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(2)) == 'Box[value=2]'


# Generated at 2022-06-23 23:59:08.948437
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('a')) == 'Box[value=a]'
    assert str(Box(1.0)) == 'Box[value=1.0]'


# Generated at 2022-06-23 23:59:14.392450
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box = Box(1)
    assert box.to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:59:16.170100
# Unit test for constructor of class Box
def test_Box():
    test = Box('test')
    assert test.value == 'test'



# Generated at 2022-06-23 23:59:18.082643
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)



# Generated at 2022-06-23 23:59:21.493531
# Unit test for method ap of class Box
def test_Box_ap():
    def ap_function(value):
        return value ** 2
    box = Box(ap_function)
    box_ap = box.ap(Box(4))
    assert box_ap == Box(16)


# Generated at 2022-06-23 23:59:23.201900
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('value')) == 'Box[value=value]'


# Generated at 2022-06-23 23:59:25.804311
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    box = Box(4)
    assert box.to_maybe() == Maybe.just(4)



# Generated at 2022-06-23 23:59:35.046325
# Unit test for method map of class Box
def test_Box_map():
    from pymonet import applicative_composition
    from pymonet.lazy import Lazy

    def test_mapper(x):
        return x * 10

    assert applicative_composition(Box(1), Box(10)).map(lambda x, y: x + y) == Box(11)
    assert Box(2).map(test_mapper) == Box(20)
    assert Box(3).map(lambda x: x * 10) == Box(30)
    assert Box(4).map(Lazy(lambda: lambda x: x * 10)) == Box(40)



# Generated at 2022-06-23 23:59:36.748463
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:59:38.328351
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert isinstance(Box(1).to_maybe(), Maybe)
    assert not Box(1).to_maybe().is_defined


# Generated at 2022-06-23 23:59:47.335054
# Unit test for method map of class Box
def test_Box_map():
    method = Box(1).map
    assert method(lambda x: x + 1) == Box(2)
    assert method(lambda x: x + 1).map(lambda x: x+2) == Box(3)
    assert method(lambda x: x + 1).map(lambda x: x+2).map(lambda x: x-2) == Box(1)
    assert method(lambda x: Box(x+1)) == Box(2)
    assert method(lambda x: Box(x+1)).map(lambda x: Box(x+2)) == Box(3)
    assert method(lambda x: Box(x+1)).map(lambda x: Box(x+2)).map(lambda x: Box(x-2)) == Box(1)

# Generated at 2022-06-23 23:59:51.408308
# Unit test for method map of class Box
def test_Box_map():
    mapper = lambda v: v * v

    expected_box = Box(2)

    assert expected_box.map(mapper) == Box(4)



# Generated at 2022-06-23 23:59:59.388033
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.either import Left

    assert Box(3).to_either() == Right(3)
    assert Box(None).to_either() == Right(None)
    assert Box([]).to_either() == Right([])
    assert Box(()).to_either() == Right(())
    assert Box(False).to_either() == Right(False)
    assert Box('').to_either() == Right('')
    assert Box(0).to_either() == Right(0)



# Generated at 2022-06-24 00:00:02.614689
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Testing method to_either of class Try.

    :returns: None
    :rtype: None
    """
    from pymonet.either import Right
    value = 1
    assert Box(value).to_either() == Right(value)


# Generated at 2022-06-24 00:00:04.009644
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-24 00:00:05.835510
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1


# Generated at 2022-06-24 00:00:08.008430
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    test_Box = Box(3)
    assert Box(3) == test_Box
    assert Box(3) == 3
    assert test_Box == Box(3)
    assert test_Box == 3


# Generated at 2022-06-24 00:00:09.474627
# Unit test for method bind of class Box
def test_Box_bind():
    """
    >>> assert Box(10).bind(lambda v: v * 2) == 20
    """
    pass


# Generated at 2022-06-24 00:00:11.571170
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(3).to_try() == Try(3, is_success=True)



# Generated at 2022-06-24 00:00:13.761035
# Unit test for method ap of class Box
def test_Box_ap():
    box1 = Box(lambda a: a + 1)
    box2 = Box(10)
    assert box1.ap(box2) == Box(11)

# Generated at 2022-06-24 00:00:19.785762
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box.
    """
    from pymonet.monad_try import Try

    assert Box(3).bind(lambda x: x + 2) == 5
    assert Box(3).bind(lambda _: Try(2, is_success=False)).is_failure()
    assert Box(3).bind(lambda x: Try(x + 2, is_success=True)).value == 5


# Generated at 2022-06-24 00:00:29.590575
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Positive tests: test class Box definition
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box(1.5) == Box(1.5)
    assert Box(2.5) == Box(2.5)
    assert Box('qwerty') == Box('qwerty')

    # Negative tests: test class Box definition
    assert Box(1) != Box(2)
    assert Box(2) != Box(1)
    assert Box(1.5) != Box(2.5)
    assert Box(2.5) != Box(1.5)
    assert Box('qwerty') != Box('asdfgh')



# Generated at 2022-06-24 00:00:32.241299
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    assert Box(123).to_maybe().get_value() == 123



# Generated at 2022-06-24 00:00:34.189891
# Unit test for method to_either of class Box
def test_Box_to_either():
    box = Box('foo')
    either = box.to_either()
    assert either.value == 'foo'


# Generated at 2022-06-24 00:00:39.975929
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == 1



# Generated at 2022-06-24 00:00:43.344087
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test for method to_maybe of class Box
    """
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:00:48.076597
# Unit test for method map of class Box
def test_Box_map():
    """
    Test for method map of class Box.

    :returns: always True
    :rtype: bool
    """
    def add_1(x: int) -> int:
        return x + 1

    assert Box(1).map(add_1) == Box(2)
    return True



# Generated at 2022-06-24 00:00:54.618926
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either
    from pymonet.either import is_left, is_right

    assert is_right(Box(1).to_either())
    assert is_left(Box('Error').to_either())
    assert is_right(Box(Either.left('Error')).to_either())
    assert is_left(Box(Either.right('Success')).to_either())


# Generated at 2022-06-24 00:00:57.145075
# Unit test for method bind of class Box
def test_Box_bind():
    @is_type(int)
    def function(arg):
        return arg + 1

    assert Box(1).bind(function) == 2
    assert Box(1).bind(function).__class__ == int



# Generated at 2022-06-24 00:00:59.484789
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:01:02.219104
# Unit test for method ap of class Box
def test_Box_ap():

    def add(a, b):
        return a + b

    box_with_function = Box(add)
    result = box_with_function.ap(Box(1))
    assert result.value == 2



# Generated at 2022-06-24 00:01:08.658174
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 2).ap(Box(1)) == Box(3)
    assert Box(lambda x: x + 2).ap(Box(lambda x: x * x)) == Box(lambda x: x + 2)(lambda x: x * x)
    assert Box(lambda x: x + 2).ap(Box(lambda x: x * x)).ap(Box(1)) == Box(3)
    assert Box(lambda x: Box(x + 2)).ap(Box(1)).bind(lambda x: x.value) == Box(3).value
    assert Box(lambda x: Box(x + 2)).ap(Box(lambda x: x * x)).ap(Box(1)).bind(lambda x: x.value) == Box(3).value

# Generated at 2022-06-24 00:01:10.489375
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-24 00:01:12.447241
# Unit test for method bind of class Box
def test_Box_bind():
    def mapper(value):
        return value + 1

    assert Box(20).bind(mapper) == 21


# Generated at 2022-06-24 00:01:16.923259
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box_value = Box('test_value')
    assert box_value == box_value.to_validation()

# Generated at 2022-06-24 00:01:18.585168
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-24 00:01:20.186327
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-24 00:01:21.734149
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    value = 1

    box = Box(value)

    try_monad = box.to_try()

    assert try_monad == Try(value, is_success=True)


# Generated at 2022-06-24 00:01:23.115985
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(42)) == 'Box[value=42]'



# Generated at 2022-06-24 00:01:27.861881
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test method ap of class Box.
    """
    assert Box(lambda x: x + 5).ap(Box(3)) == Box(8)
    assert Box(lambda x: x + 5).ap(Box(3)) != Box(7)


# Generated at 2022-06-24 00:01:32.561700
# Unit test for constructor of class Box
def test_Box():
    v = Box(1)
    assert v.value == 1
    assert v.bind(lambda x: x + 1) == 2
    assert v.map(lambda x: x + 1) == Box(2)
    assert v.ap(Box(lambda x: x + 1)) == Box(2)

# Generated at 2022-06-24 00:01:35.074354
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:01:38.343754
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(3).value == 3
    assert Box('a').value == 'a'
    box = Box({'a': 1})
    assert box.value == {'a': 1}


# Generated at 2022-06-24 00:01:41.081827
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert(Box(5).to_maybe() == Maybe.just(5))
    assert(Box(None).to_maybe() == Maybe.nothing())
    assert(Box(Try(5)).to_maybe() == Maybe.just(5))



# Generated at 2022-06-24 00:01:42.981914
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(3)) == Box(6)
    assert Box(lambda x: x * 3).ap(Box(7)) == Box(21)

# Generated at 2022-06-24 00:01:46.258862
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert(Box.to_either(Box(1)).bind(lambda x: Box(x + 1)).value == 2)
    assert(Box.to_either(Box(-1)).bind(lambda x: Box(x + 1)).value == 0)
    assert(Box.to_either(Box(True)).bind(lambda x: Box(x)).value)
    assert(not Box.to_either(Box(False)).bind(lambda x: Box(x)).value)

# Generated at 2022-06-24 00:01:53.956462
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_lazy import monad_lazy

    def add1(x):
        return x + 1

    def double(x):
        return x * 2

    @monad_lazy()
    def add1_double(x):
        return add1(x) | double

    @monad_lazy()
    def double_add1(x):
        return double(x) | add1

    assert Box(5).to_lazy() | add1_double | double_add1 | double == 42

# Generated at 2022-06-24 00:01:58.075295
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)

    assert box1 == box1
    assert box1 == box2
    assert box1 != box3


# Generated at 2022-06-24 00:01:59.959491
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box('test')) == 'Box[value=test]'



# Generated at 2022-06-24 00:02:03.080816
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(10).to_either() == Box(10).to_either()
    assert Box(10).to_either() == Box(10).to_either()

    assert Box(10).to_either().value == Box(10).to_either().value
    assert Box(10).to_either().value != Box(20).to_either().value


# Generated at 2022-06-24 00:02:03.717374
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1


# Generated at 2022-06-24 00:02:08.195225
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test for method ap of class Box.
    """
    from pymonet.monad_try import Try

    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Box(lambda x: x + 1).ap(Try(1, is_success=True)) == Box(2)



# Generated at 2022-06-24 00:02:19.687708
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) == "1"
    assert Box(1) != 2
    assert Box("1") == Box("1")
    assert Box("1") != Box("2")
    assert Box(1.0) == Box(1.0)
    assert Box(1.0) != Box(2.0)
    d1 = {"key1": 1, "key2": 2}
    d2 = {"key1": 1, "key2": 2}
    assert Box(d1) == Box(d2)
    assert Box(d1) != {"key1": 1, "key2": 2}
    assert Box(d1) != Box({"key1": 1, "key2": 3})


# Generated at 2022-06-24 00:02:26.981934
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    from pymonet.monad_list import List
    from pymonet.identity import Identity
    from random import randint

    for _ in range(100):
        value_ = randint(0, 100)
        f = lambda x: x + 5
        m = Box(f)
        assert m.ap(Box(value_)) == Box(f(value_))
        assert m.ap(List(value_)) == List(f(value_))
        assert m.ap(Identity(value_)) == Identity(f(value_))

# Generated at 2022-06-24 00:02:35.173119
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box({'a': 2, 'b': 'b'})) == "Box[value={'a': 2, 'b': 'b'}]"
    assert str(Box(Box(1))) == 'Box[value=Box[value=1]]'



# Generated at 2022-06-24 00:02:37.468120
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either().is_right()
    assert Box(1).to_either().is_left() is False
    assert Box(1).to_either().get_right() == 1


# Generated at 2022-06-24 00:02:41.946135
# Unit test for method map of class Box
def test_Box_map():
    box = Box(23)
    box_map = box.map(lambda x: x + 3)

    assert box_map.value == 26


# Generated at 2022-06-24 00:02:46.156876
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    # Test with success
    box = Box(1)
    validation = box.to_validation()
    assert(isinstance(validation, Validation))
    assert(validation.is_success)
    assert(validation.value == 1)
    assert(validation.errors == [])

# Generated at 2022-06-24 00:02:47.271605
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().fold()() == 3

# Generated at 2022-06-24 00:02:48.263191
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Lazy(lambda: 1) == Box(1).to_lazy()

# Generated at 2022-06-24 00:02:52.171321
# Unit test for method map of class Box
def test_Box_map():
    """Unit test for method map of class Box."""
    def square(value: int) -> int:
        return value * value
    assert Box(2).map(square) == Box(4)



# Generated at 2022-06-24 00:03:00.294401
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test for method to_try of class Box.
    """
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)
    assert Box(Exception()).to_try() == Try(Exception(), is_success=True)
    assert Box({1, 2}).to_try() == Try({1, 2}, is_success=True)
    assert Box(Box(1)).to_try() == Try(Box(1), is_success=True)



# Generated at 2022-06-24 00:03:04.699702
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(0)) == "Box[value=0]"
    assert str(Box(1)) == "Box[value=1]"
    assert str(Box('a')) == "Box[value=a]"
    assert str(Box(False)) == "Box[value=False]"
    assert str(Box(None)) == "Box[value=None]"
    assert str(Box([])) == "Box[value=[]]"
    assert str(Box([1])) == "Box[value=[1]]"
    assert str(Box(['a'])) == "Box[value=['a']]"
    assert str(Box({})) == "Box[value={}]"
    assert str(Box({'a': 0})) == "Box[value={'a': 0}]"

# Generated at 2022-06-24 00:03:09.645176
# Unit test for constructor of class Box
def test_Box():
    # with unittest.mock.patch('pymonet.data_classes.box.Box.__init__', return_value=None):
    #     assert Box(None)

    assert Box(None) == Box(None)

    assert Box(None) != Box(2)

    assert str(Box(2)) == 'Box[value=2]'



# Generated at 2022-06-24 00:03:12.350355
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_try import Try
    
    def function(a):
        return a + a

    value = Try(11)
    box_with_function = Box(function)
    box_with_value = Box(10)

    assert box_with_value.ap(box_with_function).value == 20



# Generated at 2022-06-24 00:03:13.415944
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"


# Generated at 2022-06-24 00:03:15.581125
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(5)
    assert box.to_validation() == Validation(5, [])



# Generated at 2022-06-24 00:03:19.393153
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_box import Box

    assert (Box(1).to_lazy() == Lazy(lambda: 1)), "Incorrect to_lazy transformation"



# Generated at 2022-06-24 00:03:20.688365
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(10).to_validation() == Box(10)

# Generated at 2022-06-24 00:03:26.881706
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1).bind(lambda x: None) is None
    assert Box('1').bind(lambda x: '2') == '2'
    assert Box([1, 2, 3]).bind(lambda x: x[0]) == 1



# Generated at 2022-06-24 00:03:30.429571
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(2).bind(lambda x: x / 0) == 0

    assert Lazy(lambda: Box(5).bind(lambda x: x / 2)).fold() == Box(2.5)
    assert Try(10, is_success=True).bind(lambda x: x / 0) == Try.failure()
    assert Try(10, is_success=False).bind(lambda x: x + 2) == Try.failure()

# Generated at 2022-06-24 00:03:36.342856
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Tests for method ap of class Box.
    """

    def f(value: int) -> int:
        """
        :param value: some integer
        :type value: int
        :returns: double value
        :rtype: int
        """
        return value + value

    assert Box(f).ap(Box(3)) == Box(f(3))

# Generated at 2022-06-24 00:03:39.530153
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box([1]).bind(lambda xs: xs + [2]) == [1, 2]



# Generated at 2022-06-24 00:03:43.180045
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test transform Box into Right either

    :returns: None
    :rtype: None
    """
    # given
    box = Box(42)

    # when
    either = box.to_either()

    # then
    assert either.value == 42



# Generated at 2022-06-24 00:03:45.807774
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == Box(1.0)
    assert not Box(1) == Box('1')



# Generated at 2022-06-24 00:03:48.184171
# Unit test for constructor of class Box
def test_Box():
    res = Box(None)
    assert res.value is None

