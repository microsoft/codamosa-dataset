

# Generated at 2022-06-23 23:53:50.346325
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    import pytest

    from pymonet.maybe import Just
    from pymonet.monad_try import Try

    box = Try('some_value', is_success=True).to_box()
    assert box.to_maybe() == Just('some_value')


# Generated at 2022-06-23 23:53:54.322621
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:53:56.413829
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)

# Generated at 2022-06-23 23:54:03.265195
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box.

    :returns: nothing
    :rtype: None
    """
    from pymonet.either import Right
    from pymonet.list import List
    from pymonet.maybe import Just
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(2).ap(Box(lambda x: x + 1)) == Box(3)
    assert Box(2).ap(List([lambda x: x + 1, lambda x: x - 1])) == List([3, 1])
    assert Box(2).ap(Right(lambda x: x + 1)) == Right(3)
    assert Box(2).ap(Just(lambda x: x + 1)) == Just(3)

# Generated at 2022-06-23 23:54:07.329702
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.utils import eq

    assert eq(Box('value').to_validation(), Validation.success('value'))

# Generated at 2022-06-23 23:54:11.043060
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)

    assert Box('a').map(lambda x: x + 'b') == Box('ab')

    assert Box('a').map(lambda x: len(x)) == Box(1)



# Generated at 2022-06-23 23:54:14.557398
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Test that Box.to_validation transforms Box of value into successfull Validation
    """
    from pymonet.validation import Validation

    assert Validation.success(5) == Box(5).to_validation()


# Generated at 2022-06-23 23:54:18.717141
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just, Maybe
    from pymonet.monad_list import List

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:54:21.802531
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:54:22.902298
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:54:25.469227
# Unit test for method ap of class Box
def test_Box_ap():
    data = [1, 2, 3, 4, 5]
    box_inc = Box(lambda x: x + 1)
    result = box_inc.ap(Box(data))
    assert result == Box([2, 3, 4, 5, 6])



# Generated at 2022-06-23 23:54:32.226524
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1.2)) == 'Box[value=1.2]'
    assert str(Box('hello')) == 'Box[value=hello]'



# Generated at 2022-06-23 23:54:36.684386
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1)  != Box(2)
    assert Box(1)  == Box(1)
    assert Box('a') != Box('b')
    assert Box('a') == Box('a')


# Generated at 2022-06-23 23:54:43.588142
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    try_value: Try[int] = Box(1).to_try()
    assert(isinstance(try_value, Try))
    try_value_value: int = try_value.get_result()
    assert(try_value_value == 1)

    try_value: Try[int] = Failure(1).to_try()
    assert(isinstance(try_value, Try))
    try_value_value: int = try_value.get_result()
    assert(try_value_value == 1)



# Generated at 2022-06-23 23:54:50.404335
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(1).ap(Box(lambda x: x + 1)) == Box(2)
    assert Box(1).ap(Box(lambda x: x * 2)) == Box(2)
    assert Box('hello').ap(Box(lambda x: x.capitalize())) == Box('Hello')
    assert Box(1).ap(Box(lambda x, y: x + y)) == Box(2)
    assert Box(1).ap(Box(lambda x, y: x * y)) == Box(2)

# Generated at 2022-06-23 23:54:53.837202
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box('str').to_maybe() == Maybe.just('str')
    assert Box(1.5).to_maybe() == Maybe.just(1.5)


# Generated at 2022-06-23 23:54:56.950965
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    from pymonet.maybe import Maybe

    value = 1
    box = Box(value)
    assert box.to_maybe() == Maybe.just(value)



# Generated at 2022-06-23 23:54:58.401520
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(
        Box(1)) == 'Box[value=1]', 'Incorrect __str__ implementation'



# Generated at 2022-06-23 23:55:03.504703
# Unit test for method map of class Box
def test_Box_map():
    """Test for method map of class Box"""
    assert Box('abc').map(lambda x: x.upper()) == Box('ABC')



# Generated at 2022-06-23 23:55:07.326969
# Unit test for constructor of class Box
def test_Box():
    assert Box('abc') == Box('abc')
    assert Box('abc') != Box('cbd')
    assert str(Box('abc')) == "Box[value='abc']"

# Generated at 2022-06-23 23:55:10.202355
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    assert Box(lambda x: x * 3).ap(Box(2)) == Box(6)



# Generated at 2022-06-23 23:55:11.576753
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().evaluate() == 1

# Generated at 2022-06-23 23:55:13.359240
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x ** 2).ap(Box(4)) == Box(16)



# Generated at 2022-06-23 23:55:17.189126
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert "Box[value={'a': 1}]" == str(Box({'a': 1}))  # pragma: no cover

# Generated at 2022-06-23 23:55:17.912209
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(None) == Box(1)



# Generated at 2022-06-23 23:55:20.727368
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box.
    """
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)


# Generated at 2022-06-23 23:55:24.937121
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 3) == Box(5)



# Generated at 2022-06-23 23:55:28.642882
# Unit test for method ap of class Box
def test_Box_ap():
    def square(x):
        return x * x

    box = Box(3).map(square)
    assert box.value == 9

    boxed_square = Box(square)
    assert boxed_square.ap(box).value == 81

    assert Box(square).ap(Box(1)).value == 1


# Generated at 2022-06-23 23:55:30.463872
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(1)

# Generated at 2022-06-23 23:55:33.127555
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == "Box[value={}]".format(1))



# Generated at 2022-06-23 23:55:35.181672
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(str) == Box('1')



# Generated at 2022-06-23 23:55:37.274201
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-23 23:55:39.215349
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, force

    box = Box(5)

    assert isinstance(box.to_lazy(), Lazy)
    assert force(box.to_lazy()) == box.value


# Generated at 2022-06-23 23:55:41.349382
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('test') == Box('test')
    assert Box('test') is not Box('test')
    assert Box('test') != Box('test 2')



# Generated at 2022-06-23 23:55:50.261462
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]', 'Should be Box(1) '
    assert str(Box(1.0)) == 'Box[value=1.0]', 'Should be Box[value=1.0]'
    assert str(Box('Hello')) == 'Box[value=Hello]', 'Should be Box[value=Hello]'
    assert str(Box(True)) == 'Box[value=True]', 'Should be Box[value=True]'
    assert str(Box((1, 'Hello'))) == 'Box[value=(1, Hello)]', 'Should be Box[value=(1, Hello)]'



# Generated at 2022-06-23 23:55:51.594540
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert repr(Box(10)) == 'Box[value=10]'

# Generated at 2022-06-23 23:55:56.438109
# Unit test for constructor of class Box
def test_Box():

    @pytest.mark.parametrize(('a', 'expected_value'), [
        ('1', '1'),
        ([1, 2, 3], [1, 2, 3]),
        (1, 1)
    ])
    def test_box_construction(a, expected_value):
        box = Box(a)
        assert isinstance(box, Box)

        assert box.value == expected_value

    test_box_construction()


# Generated at 2022-06-23 23:56:00.582479
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(2).to_maybe() == Maybe.just(2)
    assert Box(3).to_maybe() == Maybe.just(3)

# Generated at 2022-06-23 23:56:03.802717
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.list import List

    assert Box(lambda x: x + 1).ap(List(Box(10), Box(20))).value == [11, 21]  # type: ignore

# Generated at 2022-06-23 23:56:05.411028
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box("foo") == Box("foo")


# Generated at 2022-06-23 23:56:06.937927
# Unit test for constructor of class Box
def test_Box():
    assert Box(2) == Box(2)



# Generated at 2022-06-23 23:56:16.522222
# Unit test for method bind of class Box
def test_Box_bind():
    def add_one(value: int) -> int:
        """
        :param value: value
        :type value: int
        :returns: value + 1
        :rtype: int
        """
        return value + 1

    # Test positive value
    assert Box(1).bind(add_one) == 2
    assert Box(2).bind(add_one) == 3
    assert Box(3).bind(add_one) == 4

    # Test negative value
    assert Box(-1).bind(add_one) == 0
    assert Box(-2).bind(add_one) == -1
    assert Box(-3).bind(add_one) == -2



# Generated at 2022-06-23 23:56:17.691575
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:56:19.911375
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:56:28.397424
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.list import List
    from pymonet.maybe import Just

    assert Box(lambda x: x ** 2).ap(Box(3)) == Box(3 ** 2)
    assert Box(lambda x: x ** 2).ap(List.empty()) == Box([])
    assert Box(lambda x: x ** 2).ap(List.of(1, 2, 3)) == Box([1, 4, 9])
    assert Box(lambda x: x ** 2).ap(Just(100)) == Box(100 ** 2)



# Generated at 2022-06-23 23:56:34.286572
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_reader import Reader
    from pymonet.monad_state import State
    def add_with_state(x: int) -> State[int, int]:
        return State(lambda s: (lambda a: (a, s + 1))(x + s))

    def add_with_reader(x: int) -> Reader[int, int]:
        return Reader(lambda r: x + r)

    assert Box(add_with_state(1)).ap(Box(State.unit(2))).run(0) == (3, 1)
    assert Box(add_with_reader(1)).ap(Box(Reader.unit(2))).run(0) == (3)

# Generated at 2022-06-23 23:56:41.942775
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    # Check to_try method of class Box with positive case
    assert Box('test').to_try() == Try('test', True)
    # Check to_try method of class Box with negative case
    assert Box('test').to_try() != Try('test', False)


# Generated at 2022-06-23 23:56:46.872312
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    value = "test value"
    box = Box(value)
    assert (box.to_either() == Right(value))

# Generated at 2022-06-23 23:56:49.154420
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    v = 1
    b = Box(v)
    assert b.to_try() == Try(v)

# Generated at 2022-06-23 23:56:53.083160
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-23 23:56:55.205921
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import is_left, is_right

# Generated at 2022-06-23 23:57:06.712926
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just, Nothing
    from pymonet.monad_try import Try
    from pymonet.validation import Validation, Success

    assert Box(True).to_maybe() == Just(True)
    assert Box(None).to_maybe() == Nothing
    assert Box(Try(1, True)).to_maybe() == Nothing
    assert Box(Try(None, False)).to_maybe() == Nothing
    assert Box(Validation('Error', 'Error')).to_maybe() == Nothing
    assert Box(Validation(1, 'Error')).to_maybe() == Just(1)
    assert Box(Success(1)).to_maybe() == Just(1)
    assert Box(Success(None)).to_maybe() == Nothing


# Generated at 2022-06-23 23:57:18.684640
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.list import List
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Box(lambda x: x + 1).ap(Box(1)).value == 2

    assert Box(lambda x: List([x])).ap(Box(1)).value == List([1])
    assert Box(lambda x: List([x])).ap(Box(1)).bind(lambda l: l.head).value == 1

    assert Box(lambda x: Right(x)).ap(Box(1)).value == Right(1)
   

# Generated at 2022-06-23 23:57:21.320577
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.maybe import Maybe

    a = Box(25)
    b = Box(6)

    assert Maybe.just(25).map(lambda x: x * 4) == a.map(lambda x: x * 4)
    assert Maybe.just(25).map(lambda x: x * 4) == b.map(lambda x: x * 4)



# Generated at 2022-06-23 23:57:24.978210
# Unit test for method ap of class Box
def test_Box_ap():
    import operator

    assert Box(operator.add).ap(Box(1)).ap(Box(2)) == Box(3)
    assert Box(operator.add).ap(Box(1)).ap(Box(2)).ap(Box(3)) == Box(6)


# Generated at 2022-06-23 23:57:30.527130
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    box = Box(1)
    try_monad = Try(1, is_success=True)

    assert box.to_try() == try_monad

# Generated at 2022-06-23 23:57:32.598456
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert str(Box(1).to_validation()) == 'Success(1)'

    assert str(Box('test').to_validation()) == 'Success(test)'



# Generated at 2022-06-23 23:57:37.519997
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2 + 2) == Box(2 + 2).to_lazy()


# Generated at 2022-06-23 23:57:40.313621
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:57:42.213330
# Unit test for constructor of class Box
def test_Box():
    assert Box(42) == Box(42)
    assert str(Box('test')) == "Box[value='test']"



# Generated at 2022-06-23 23:57:44.240177
# Unit test for method ap of class Box
def test_Box_ap():
    box = Box(lambda x: x * 2)
    assert box.ap(Box(3)) == Box(6)


# Unit tests for method to_lazy of class Box

# Generated at 2022-06-23 23:57:46.973093
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box
    """

    value = 'value'
    assert 'Box[value={}]'.format(value) == str(Box(value))



# Generated at 2022-06-23 23:57:51.611796
# Unit test for constructor of class Box
def test_Box():
    # Should create new Box with value 1
    box = Box(1)

    assert box.value == 1



# Generated at 2022-06-23 23:57:55.829215
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box

    :return: None
    :rtype: None
    """
    assert Box(lambda x: x + 4).ap(Box(2)) == Box(6)
    assert Box(lambda x: x + 4).ap(Box(None)) == Box(None)



# Generated at 2022-06-23 23:57:59.932118
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0).__eq__(Box(0))
    assert not Box(0).__eq__(Box(1))
    assert not Box(0).__eq__(1)



# Generated at 2022-06-23 23:58:01.850113
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-23 23:58:03.441056
# Unit test for method __str__ of class Box
def test_Box___str__():
    print(Box(5))
    print(Box('test'))
    print(Box(None))

# Generated at 2022-06-23 23:58:05.648496
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)
    assert Box("A").to_validation() == Validation.success("A")
    assert Box(None).to_validation() == Validation.success(None)


# Generated at 2022-06-23 23:58:06.512907
# Unit test for constructor of class Box
def test_Box():
    assert Box(42) == Box(42)



# Generated at 2022-06-23 23:58:10.863444
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box

    :returns: nothing
    :rtype: None
    """
    box = Box(3)
    assert str(box) == 'Box[value=3]'



# Generated at 2022-06-23 23:58:14.841897
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x ** 2) == 4
    assert Box('n').bind(lambda x: x * 3) == 'nnn'


# Generated at 2022-06-23 23:58:16.998121
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:58:21.937655
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box("123").to_either() == Right("123")


# Generated at 2022-06-23 23:58:23.758201
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try().is_success() is True
    assert Box(1).to_try().get_error() is None
    assert Box(1).to_try().get_value() == 1

# Generated at 2022-06-23 23:58:30.064388
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(1).to_try() is not Try(1, is_success=True)


# Generated at 2022-06-23 23:58:31.431806
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(2).to_maybe().is_just



# Generated at 2022-06-23 23:58:36.371423
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)


# Generated at 2022-06-23 23:58:37.920779
# Unit test for constructor of class Box
def test_Box():
    assert Box(10) == Box(10)
    assert Box(10) != Box('10')


# Generated at 2022-06-23 23:58:47.709638
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    @st.composite
    def boxes(draw, elements=st.one_of(st.integers(), st.floats(), st.booleans())):
        return Box(draw(elements))

    @st.composite
    def rights(draw, elements=st.one_of(st.integers(), st.floats(), st.booleans())):
        return Right(draw(elements))

    @given(boxes())
    def test_Box_to_either_invariant(box):
        assert box.to_either() == Right(box.value)

    @given(st.tuples(boxes(), rights()))
    def test_Box_to_either_invariant_with_either(box_and_right):
        box, right = box_and_

# Generated at 2022-06-23 23:58:51.311045
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().is_folded() is False

# Generated at 2022-06-23 23:58:54.470009
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box('foo')) == 'Box[value=foo]'
    assert str(Box(Box('inside'))) == 'Box[value=Box[value=inside]]'



# Generated at 2022-06-23 23:58:58.228316
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe

    box = Box(lambda value: Maybe.just(value))
    maybe = Maybe.just(1)
    assert box.ap(maybe) == Maybe.just(1)

    box = Box(lambda value: Maybe.just(value))
    maybe = Maybe.nothing()
    assert box.ap(maybe) == Maybe.nothing()



# Generated at 2022-06-23 23:58:59.224083
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold() == 1

# Generated at 2022-06-23 23:59:00.370028
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)


# Generated at 2022-06-23 23:59:04.489680
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-23 23:59:07.680550
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-23 23:59:08.720460
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5)

# Generated at 2022-06-23 23:59:14.022069
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Box(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-23 23:59:18.292098
# Unit test for method __str__ of class Box
def test_Box___str__(): # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(2.0)) == 'Box[value=2.0]'
    assert str(Box('3')) == 'Box[value=3]'


# Generated at 2022-06-23 23:59:22.993720
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    def mapper(value: int) -> int:
        return value * 100

    assert Box(mapper).ap(Box(10)) == Box(1000)



# Generated at 2022-06-23 23:59:25.552194
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try
    assert Box(1).to_try() == Try(1, True)

# Generated at 2022-06-23 23:59:32.058423
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, Failure

    assert Box(1).to_try() == Try(1, is_success=True)
    assert type(Box(1).to_try()) == Try
    assert Box(1).to_try().is_success == True
    assert Box(1).to_try().is_failure == False



# Generated at 2022-06-23 23:59:33.823818
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:59:37.672733
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.test_utils import assert_equals_monad_test

    assert_equals_monad_test(
        monad=Box(2),
        monad_method_name='map',
        expected_monad_class=Box,
        expected_monad_value=4,
        mapper=lambda x: x + x)



# Generated at 2022-06-23 23:59:40.871796
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.maybe import Maybe

    assert Box(1).map(lambda x: x + 10) == Box(11)
    assert Box(Maybe.nothing()).map(lambda x: Maybe.just(10)) == Maybe.nothing()
    assert Maybe.just(Box(1)).map(lambda x: x.map(lambda x: x + 10)) == Maybe.just(Box(11))



# Generated at 2022-06-23 23:59:41.891826
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(3).to_try() == Try(3)

# Generated at 2022-06-23 23:59:45.665850
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation, Failure

    assert Box(1).to_validation() == Validation(1, [])
    assert Box(Failure('error')).to_validation() == Validation('error', ['error'])


# Generated at 2022-06-23 23:59:54.078751
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.either import Either

    assert type(Box('').to_either()) == Either
    assert Box('').to_either() == Right('')
    assert type(Box('123').to_either()) == Either
    assert Box('123').to_either() == Right('123')
    assert type(Box(123).to_either()) == Either
    assert Box(123).to_either() == Right(123)


# Generated at 2022-06-23 23:59:59.480181
# Unit test for method to_try of class Box
def test_Box_to_try():

    def test_box_to_try():
        from pymonet.monad_try import Try

        assert isinstance(Box(1).to_try(), Try)

        try_ = Box(1).to_try()
        assert try_.is_success
        assert try_.get_value() == 1

    test_box_to_try()



# Generated at 2022-06-24 00:00:04.265446
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet import Box

    box = Box(2)
    assert box.to_try() == Try(2, True)

# Generated at 2022-06-24 00:00:06.265545
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Box(2).to_lazy()

    assert isinstance(lazy, Lazy)



# Generated at 2022-06-24 00:00:09.915387
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation(1, [])

# Generated at 2022-06-24 00:00:12.056724
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == (Try(1, is_success=True))


# Generated at 2022-06-24 00:00:13.677707
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(0)) == 'Box[value=0]'



# Generated at 2022-06-24 00:00:18.042238
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box
    """
    assert Box(1).bind(lambda x: x * 2) == 2



# Generated at 2022-06-24 00:00:19.819374
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)



# Generated at 2022-06-24 00:00:30.049723
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for Box.map method.
    """
    from pymonet.monad_try import Try

    def mapper(value):
        return value * 2

    result = Box(1).map(mapper)
    assert result.value == 2

    def mapper(value):
        return Try(value / 2, is_success=True)

    result = Box(1).map(mapper)
    assert isinstance(result, Box) and result.value == Try(0.5, is_success=True)

    def mapper(value):
        return value / 0

    result = Box(1).map(mapper)
    assert isinstance(result, Box) and result.value == Try(ZeroDivisionError(), is_success=False)


# Generated at 2022-06-24 00:00:32.282677
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert_that(Box(1).to_maybe(), equal_to(Maybe.just(1)))



# Generated at 2022-06-24 00:00:33.492288
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:00:37.513941
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('a')) == 'Box[value=a]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box([])) == 'Box[value=[]]'
    assert str(Box({})) == 'Box[value={}]'
    assert str(Box(dict(a=1))) == 'Box[value={a: 1}]'


# Generated at 2022-06-24 00:00:39.162507
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert str(Box(10).to_lazy().eval()) == str(10)


# Generated at 2022-06-24 00:00:42.484636
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == None)
    assert Box(1) != None
    assert Box(1) != Box(2)


# Generated at 2022-06-24 00:00:46.912639
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # type: () -> None
    """
    Unit test for method __eq__ of class Box

    :return: None
    :rtype: None
    """
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-24 00:00:50.173215
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe

    assert Box(2).bind(lambda x: x + 2) == 4
    assert Box(2).bind(lambda x: Maybe.just(x + 2)).get() == 4



# Generated at 2022-06-24 00:00:52.683306
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    In this test we testing that __str__ method return same result.

    :returns: nothing
    :rtype: None
    """
    assert str(Box(5)) == '5'


# Generated at 2022-06-24 00:00:53.831520
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-24 00:00:56.313919
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Test to_validation method in Box class

    :returns: Nothing
    :rtype: None
    """
    from pymonet.validation import Validation

    assert Box('a').to_validation() == Validation.success('a')

# Generated at 2022-06-24 00:01:01.011701
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(3).ap(Box(lambda x: x + 1)).value == 4
    assert Box(3).ap(Box(lambda x: Box(x + 1))).value.value == 4
    assert Box(3).map(Box).ap(Box(lambda x: x + 1)).value.value == 4
    assert Box(3).map(None).ap(Box(lambda x: x + 1)).value.value == 4
    assert Box(3).map(Box).ap(Box(None)).value.value == None



# Generated at 2022-06-24 00:01:02.656133
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    validation = Validation.success(1)
    box = Box(1).to_validation()
    assert box == validation

# Generated at 2022-06-24 00:01:05.497727
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    validation = Box('hi').to_validation()
    assert isinstance(validation, Validation)
    assert validation.value == 'hi'

# Generated at 2022-06-24 00:01:07.185962
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('test_value')) == 'Box[value=test_value]'

# Generated at 2022-06-24 00:01:10.338133
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(1).to_maybe() != Maybe.nothing()



# Generated at 2022-06-24 00:01:11.648514
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy() == Box(42).to_lazy()

# Generated at 2022-06-24 00:01:13.142050
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(10) == Box(10)



# Generated at 2022-06-24 00:01:19.820547
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test case for method ap of class Box monad.
    """
    from pymonet.lazy import Lazy

    # TODO: remove this
    box_lazy: Lazy[Callable[[], int]] = Box(2).to_lazy()
    box_func: Box[Callable[[int], int]] = Box(lambda x: x ** 2)

    assert box_lazy.ap(box_func).get() == 4

# Generated at 2022-06-24 00:01:20.966817
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-24 00:01:23.535406
# Unit test for method ap of class Box
def test_Box_ap():
    m = Box(lambda x: x + 10)
    m2 = Box(100)
    assert m.ap(m2) == Box(110)
    assert m2.ap(m) == Box(110)



# Generated at 2022-06-24 00:01:26.649808
# Unit test for method bind of class Box
def test_Box_bind():
    # Given
    box = Box(1)

    # When
    map_value = box.bind(lambda v: v + 1)

    # Then
    assert map_value == 2



# Generated at 2022-06-24 00:01:31.706947
# Unit test for method to_either of class Box
def test_Box_to_either():
    # Given
    from pymonet.either import Right

    value = 1
    box = Box[int](value)

    # When
    result = box.to_either()

    # Then
    assert result == Right(value)



# Generated at 2022-06-24 00:01:34.409081
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda a: 2 * a).ap(Box(3)) == Box(6)


# Generated at 2022-06-24 00:01:37.021813
# Unit test for method __str__ of class Box
def test_Box___str__():
    from pymonet.test.tools import assert_equal
    from pymonet.box import Box

    assert_equal(str(Box(3)), 'Box[value=3]')

# Generated at 2022-06-24 00:01:38.297727
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(add_one) == 2



# Generated at 2022-06-24 00:01:39.828406
# Unit test for method map of class Box
def test_Box_map():
    assert Box('Hello').map(lambda value: value.lower()) == Box('hello')



# Generated at 2022-06-24 00:01:40.634535
# Unit test for constructor of class Box
def test_Box():
    assert Box("hello") is not None

# Generated at 2022-06-24 00:01:42.775276
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    box = Box(True)
    new_box = box.to_validation()
    assert new_box == Validation.success(True)

# Generated at 2022-06-24 00:01:48.764881
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, Failure

    assert Box(0).to_try().get_or_else(lambda e: e) == success_try_0
    assert Box(0).to_try() == success_try_0
    assert Box('x').to_try().get_or_else(lambda e: e) == success_try_x
    assert Box('x').to_try() == success_try_x
    assert Box(None).to_try() == Try(None)
    assert Box(None).to_try().get_or_else(lambda e: e) == None
    error = RuntimeError()
    assert Box(error).to_try() == Try(error, is_success=False)
    assert Box(error).to_try().get_or_else(lambda e: e) == error
   

# Generated at 2022-06-24 00:01:53.326705
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    # Arrange
    box = Box(1)

    # Act
    result = box.to_try()

    # Assert
    assert(isinstance(result, Try))
    assert(result.is_success)
    assert(result.value == 1)



# Generated at 2022-06-24 00:01:56.910849
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    # given
    box = Box(10)

    # when
    either = box.to_either()

    # then
    assert either == Right(10)



# Generated at 2022-06-24 00:01:58.923145
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: Box(1).value)

# Generated at 2022-06-24 00:02:02.482476
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right, Left

    assert Box(1).to_either() == Right(1)
    assert Box(None).to_either() == Right(None)



# Generated at 2022-06-24 00:02:03.639668
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(3)) == Box(6)



# Generated at 2022-06-24 00:02:04.857880
# Unit test for method map of class Box
def test_Box_map():
    assert Box('123').map(int) == Box(123)



# Generated at 2022-06-24 00:02:11.309904
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(lambda x: x * 2).bind(lambda x: x(21)) == 42
    assert Box(lambda x: x * 2).bind(lambda x: x(21)).bind(lambda x: x * 2) == 84
    assert Box('Hello, World!').bind(lambda s: s.split(' ')).bind(lambda x: x[1][-1]) == 'd'

# Generated at 2022-06-24 00:02:13.586949
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    result = Box(10).to_lazy().get()()

    assert result == 10



# Generated at 2022-06-24 00:02:16.056880
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(1)
    assert box.to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:02:17.505464
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)



# Generated at 2022-06-24 00:02:19.879422
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.tests.helpers import assert_maybe

    assert_maybe(Maybe.just(123), Box(123).to_maybe())

# Generated at 2022-06-24 00:02:21.203847
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(0).to_validation() == Validation.success(0)

# Generated at 2022-06-24 00:02:24.994536
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    """
    Unit test of method bind in Box class
    """
    assert Box(10).map(lambda x: x * 2).bind(lambda x: x // 3) == Box(20).bind(lambda x: x * 2).bind(lambda x: x // 3)


# Generated at 2022-06-24 00:02:28.513027
# Unit test for method ap of class Box
def test_Box_ap():
    def add(value):
        return value + 10

    boxA = Box(30)
    boxB = Box(7)

    assert boxB.ap(boxA) == Box(37)

# Generated at 2022-06-24 00:02:31.888185
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    value = Try.unit(42)
    assert Box(value).to_try() == Try.unit(value)

# Generated at 2022-06-24 00:02:39.834406
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.monad_func import Func
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left
    from pymonet.validation import Success, Validation

    def test_monad():
        return Box(20)

    def test_try_monad():
        return Try(20)

    def test_right_either_monad():
        return Right(20)

    def test_left_either_monad():
        return Left(20)

    def test_success_validation_monad():
        return Success(20)

    def test_func_monad():
        return Func(lambda x: x + 10)

    # Box[int] should be apply Func[int, int]

# Generated at 2022-06-24 00:02:45.864787
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    value = 'World'
    lazy = Lazy(lambda: value)
    box = Box(value)
    assert box.to_lazy() == lazy

    try_ = Try(value, is_success=True)
    box = Box(try_)
    assert box.to_lazy() == lazy


# Generated at 2022-06-24 00:02:48.971790
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:02:51.290312
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(10).to_try() == Try(10, is_success=True)

# Generated at 2022-06-24 00:02:53.339831
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(10).value == 10
    assert Box(True).value == True



# Generated at 2022-06-24 00:02:55.997424
# Unit test for constructor of class Box
def test_Box():
    assert str(Box(10)) == 'Box[value=10]'
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)



# Generated at 2022-06-24 00:02:58.120382
# Unit test for method bind of class Box
def test_Box_bind():
    boxed_data = Box(1)
    assert boxed_data.bind(lambda x: x*2) == 2



# Generated at 2022-06-24 00:03:01.600781
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Try(1, is_success=True) == Box(1).to_try()

# Generated at 2022-06-24 00:03:08.516787
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    from hypothesis import given, settings, seed
    from hypothesis.strategies import integers, characters

    @given(integers(), integers())
    @settings(max_examples=100, deadline=None, verbosity=10)
    def test(first_value, second_value):
        assert (Box(first_value) == Box(first_value)) is True
        assert (Box(first_value) == Box(second_value)) is False

    seed(1)
    test()



# Generated at 2022-06-24 00:03:09.824763
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"

# Generated at 2022-06-24 00:03:11.162653
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x * 2) == 10



# Generated at 2022-06-24 00:03:12.742200
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe(1)



# Generated at 2022-06-24 00:03:14.215854
# Unit test for method ap of class Box
def test_Box_ap():
    f = lambda x: x + 1

    assert Box(f).ap(Box(1)) == Box(2)

# Generated at 2022-06-24 00:03:16.001809
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(42).to_maybe() == Box(42).to_maybe(), 'Value should be the same'



# Generated at 2022-06-24 00:03:18.474357
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    assert isinstance(box.to_maybe(), Maybe)
    assert box.to_maybe().value == 1



# Generated at 2022-06-24 00:03:25.602288
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 3).value == 6
    assert Box(2).map(lambda x: x ** 0) == Box(1)
    assert Box(2).map(lambda x: x * 2) == Box(4)
    assert Box(2).map(lambda x: x % 2) == Box(0)
    assert Box(2).map(lambda x: x * 0) == Box(0)


# Generated at 2022-06-24 00:03:29.975014
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box([])) == 'Box[value=[]]'
    assert str(Box('s')) == 'Box[value=s]'
    assert str(Box(False)) == 'Box[value=False]'
    assert str(Box(None)) == 'Box[value=None]'


# Generated at 2022-06-24 00:03:31.931231
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-24 00:03:34.272952
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:03:36.341226
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box('test').to_maybe() == Box('test').map(Maybe.just)


# Generated at 2022-06-24 00:03:38.342737
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(2).to_validation() == Validation.success(2)


# Generated at 2022-06-24 00:03:39.740309
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(5).to_either() == Box(5).value


# Generated at 2022-06-24 00:03:40.901821
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda v: v + 1) == 2

# Generated at 2022-06-24 00:03:45.067189
# Unit test for method ap of class Box
def test_Box_ap():
    ls = Box([1,2,3])
    ls2 = Box([4,5,6])
    plus = lambda xs: sum(xs)
    assert Box(plus).ap(ls).value == 6
    result = Box(plus).ap(ls).ap(ls2)
    assert result.value == 21

test_Box_ap()

# Generated at 2022-06-24 00:03:50.578362
# Unit test for constructor of class Box
def test_Box():
    # Test for initialization
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

    # Test for __str__ method
    assert str(Box(1)) == 'Box[value=1]'