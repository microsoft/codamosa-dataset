

# Generated at 2022-06-23 23:53:54.597533
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    """
    Unit test for method map of class Box.

    :returns: None
    :rtype: None
    """
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('1').map(lambda x: x + '1') == Box('11')


# Generated at 2022-06-23 23:53:56.656105
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:53:58.110767
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x ** 2) == Box(4)



# Generated at 2022-06-23 23:54:00.118016
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(42)
    assert box.to_either() == Right(42)

# Generated at 2022-06-23 23:54:01.627602
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x ** 2) == Box(4)



# Generated at 2022-06-23 23:54:03.034051
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x * 2) == 2


# Generated at 2022-06-23 23:54:05.886383
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)



# Generated at 2022-06-23 23:54:08.422041
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None



# Generated at 2022-06-23 23:54:14.749173
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.validation import Validation

    assert Box(4).to_either() == Right(4)
    assert Box('test').to_either() == Right('test')

    validation = Box(4).to_either().to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.value == 4



# Generated at 2022-06-23 23:54:16.829866
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:54:18.763055
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1), 'Box is not equal to another Box with same value'


# Generated at 2022-06-23 23:54:23.225729
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1).bind(Maybe.just) is Maybe.just(1)
    assert Box(1).bind(Maybe.nothing) is Maybe.nothing()



# Generated at 2022-06-23 23:54:24.511273
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * x) == Box(4)



# Generated at 2022-06-23 23:54:32.481430
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(5)
    box2 = Box(6)
    box3 = Box(5)
    assert box1 == box1
    assert box1 != box2
    assert box1 == box3

# Generated at 2022-06-23 23:54:36.422037
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    lazy: Lazy[int] = Box(10).to_lazy()
    assert Lazy(lambda: 10) == lazy

# Generated at 2022-06-23 23:54:38.095704
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).to_either()
    assert Box(1).to_either() == Box(1).to_either()
    assert Box(1).to_either() == Box(1).to_either()


# Generated at 2022-06-23 23:54:40.526136
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test Box to Either transformation.
    """
    from pymonet.either import Right
    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:54:42.384729
# Unit test for method map of class Box
def test_Box_map():
    box = Box(1)
    result_box = box.map(lambda x: x + 1)
    assert result_box == Box(2)



# Generated at 2022-06-23 23:54:47.428137
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, fold
    from pymonet.box import Box

    assert Lazy(lambda: 5) == Box(5).to_lazy()
    assert fold(Box(5).to_lazy()) == 5


# Generated at 2022-06-23 23:54:49.109902
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(2)
    assert box.to_either() == Right(2)


# Generated at 2022-06-23 23:54:52.577076
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Transform box with value 7 into lazy which returned this value

    :returns: assertion error if it not working
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert Box(7).to_lazy() == Lazy(lambda: 7)


# Generated at 2022-06-23 23:54:54.686455
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert str(Box('a')) == 'Box[value=a]'



# Generated at 2022-06-23 23:54:55.793789
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert (Box(1) == Box(2)) is False
    assert (Box(1) == 1) is False



# Generated at 2022-06-23 23:54:57.639630
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('1') == Box('1')
    assert Box('1') != Box('2')
    assert Box('1') != object
    assert Box('1') != 123


# Generated at 2022-06-23 23:55:03.034094
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('a').bind(lambda x: x + 'b') == 'ab'

# Generated at 2022-06-23 23:55:05.102028
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    box = Box(15)
    assert box.bind(int.__add__).value == 30



# Generated at 2022-06-23 23:55:08.721693
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:55:10.157802
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:55:11.919012
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
# End of unit test

# Generated at 2022-06-23 23:55:19.152349
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    # 1. Check map method of Maybe monad
    assert Maybe.just(2).bind(lambda x: Box(x + 2)).value == 4
    assert Maybe.nothing().bind(lambda x: Box(x + 2)).value is None

    # 2. Check is instance of Maybe
    assert isinstance(Maybe.just(2), Maybe)
    assert isinstance(Maybe.nothing(), Maybe)
    assert isinstance(Maybe.just(2).bind(lambda x: Box(x + 2)), Maybe)
    assert isinstance(Maybe.nothing().bind(lambda x: Box(x + 2)), Maybe)


# Generated at 2022-06-23 23:55:20.961287
# Unit test for method map of class Box
def test_Box_map():
    box10 = Box(10)
    assert box10.map(lambda value: value + 1) == Box(11)



# Generated at 2022-06-23 23:55:29.133773
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert isinstance(Box(1), Box)
    assert isinstance(Box(1.0), Box)
    assert isinstance(Box(None), Box)
    assert isinstance(Box(True), Box)
    assert isinstance(Box(False), Box)
    assert isinstance(Box('str'), Box)
    assert isinstance(Box([]), Box)
    assert isinstance(Box({}), Box)
    assert isinstance(Box(()), Box)


# Generated at 2022-06-23 23:55:30.967006
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert Box(10).__str__() == 'Box[value=10]'



# Generated at 2022-06-23 23:55:32.908437
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)



# Generated at 2022-06-23 23:55:36.112092
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(4).bind(lambda x: x + 1) == 5
    assert Box(4).bind(lambda x: Box(x + 1)) == Box(5)


# Generated at 2022-06-23 23:55:38.089453
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(42) == Box(42)
    assert Box(42) != Box(43)


# Generated at 2022-06-23 23:55:39.370881
# Unit test for method ap of class Box
def test_Box_ap():

    assert Box(5).ap(Box(lambda x: x * 2)) == Box(10)

# Generated at 2022-06-23 23:55:40.351134
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:55:42.334016
# Unit test for constructor of class Box
def test_Box():
    assert Box('hello') == Box('hello')



# Generated at 2022-06-23 23:55:44.000677
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'


# Generated at 2022-06-23 23:55:47.647447
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    def double(x: int) -> int:
        return x * 2

    box = Box(3).bind(double)
    assert isinstance(box, Box)
    assert box.value == 6



# Generated at 2022-06-23 23:55:58.910057
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    test_boxes = [
        Box(5),
        Box(5),
        Box([1, 2, 3]),
        Box('ABC'),
        Box(5),
        Box({'a': 123, 'b': 456})
    ]

    assert all([
        Box(5) == Box(5),
        Box(5) != Box('ABC'),
        Box([1, 2, 3]) != Box('ABC'),
        Box(5) != Box(10)
    ])

    assert all([test_boxes[0] == test_boxes[1]])
    assert all([test_boxes[1] == test_boxes[4]])
    assert all([test_boxes[2] != test_boxes[3]])
    assert all([test_boxes[3] != test_boxes[5]])

# Generated at 2022-06-23 23:56:01.795392
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:56:06.208423
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.applicative import Applicative
    from pymonet.alter import Alter
    from pymonet.lazy import Lazy
    
    lazy = Lazy(lambda: 2)
    print(Box(lambda x: x * 2).ap(lazy))  # 4

# Generated at 2022-06-23 23:56:08.734848
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-23 23:56:15.947427
# Unit test for method map of class Box
def test_Box_map():
    """Unit test for method map of class Box"""

    assert Box(10).map(lambda x: x + 2) == Box(12)
    assert Box(10).map(lambda x: x * x) == Box(100)
    assert Box({'key': 'value'}).map(lambda x: x['another_key']) == Box('value')
    assert Box([]).map(lambda x: x + [1]) == Box([1])
    assert Box(None).map(lambda x: x * 10) == Box(None)
    assert Box(True).map(lambda x: x and False) == Box(False)



# Generated at 2022-06-23 23:56:16.749090
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1



# Generated at 2022-06-23 23:56:18.639507
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    def some_function(value):
        return 2 * value

    box = Box(1)
    assert box.bind(some_function) == 2



# Generated at 2022-06-23 23:56:21.919221
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing
    assert Box(42).to_maybe() == Maybe.just(42)
    assert Nothing().to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:24.594459
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-23 23:56:25.794027
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'  # type: ignore

# Generated at 2022-06-23 23:56:28.222298
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('str') == Box('str')
    assert Box({'key': 'value'}) == Box({'key': 'value'})



# Generated at 2022-06-23 23:56:32.967662
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(10).to_lazy(), Lazy)

# Generated at 2022-06-23 23:56:35.316463
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for to_lazy method of Box.
    """

    assert Box(5).to_lazy().value() == 5

# Generated at 2022-06-23 23:56:39.090437
# Unit test for constructor of class Box
def test_Box():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)



# Generated at 2022-06-23 23:56:40.783292
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    box = Box(42)
    assert str(box) == 'Box[value=42]'

# Generated at 2022-06-23 23:56:45.100838
# Unit test for method to_try of class Box
def test_Box_to_try():
    value = 'value'
    box = Box(value)

    from pymonet.monad_try import Try

    try_ = box.to_try()

    assert try_ is not None
    assert isinstance(try_, Try)
    assert try_.is_success is True
    assert try_.value == value


# Generated at 2022-06-23 23:56:49.573343
# Unit test for method ap of class Box
def test_Box_ap():
    import pytest

    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Box(lambda x, y: x + y).ap(Box(1)) == Box(lambda y: 1 + y)

    with pytest.raises(TypeError):
        Box('some').ap(Box(1))


# Generated at 2022-06-23 23:56:54.412297
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)

    value = box.to_maybe()

    assert value == Maybe.just(1)



# Generated at 2022-06-23 23:57:00.561376
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    # GIVEN
    from pymonet.either import Right
    box = Box(1)

    # WHEN
    result = box.to_either()

    # THEN
    assert result == Right(1)

# Generated at 2022-06-23 23:57:06.309367
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    class TestClass(object):
        pass

    test_class = TestClass()
    number = 10
    string = 'test_string'
    boolean = True
    list_test = [10, 20]
    tuple_test = (10, 'test', None)
    dict_test = {'key': None}
    none_value = None

    assert Box(test_class) == Box(test_class)
    assert Box(number) == Box(number)
    assert Box(string) == Box(string)
    assert Box(boolean) == Box(boolean)
    assert Box(list_test) == Box(list_test)
    assert Box(tuple_test) == Box(tuple_test)
    assert Box(dict_test) == Box(dict_test)

# Generated at 2022-06-23 23:57:10.883103
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test for ap method of Box monad
    """

    from pymonet.utils import compose, identity

    unary = lambda x: x * 2
    binary = lambda x, y: x + y
    compose_binary = compose(binary)
    compose_unary = compose(compose_binary, unary)

    assert Box(compose_unary).ap(Box(unary)).ap(Box(2)).bind(identity) == Box(compose_unary(unary, 2)).bind(identity)



# Generated at 2022-06-23 23:57:16.816781
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)
    assert Box(1).map(lambda x: x) == Box(1)
    assert Box('a').map(lambda x: len(x)) == Box(1)
    assert Box('a').map(lambda x: x + 'b') == Box('ab')


# Unit tests for method bind of class Box

# Generated at 2022-06-23 23:57:22.547433
# Unit test for constructor of class Box
def test_Box():
    """
    Unit test for constructor of class Box
    """
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)
    assert Box(2) != "test"



# Generated at 2022-06-23 23:57:23.720378
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * x) == Box(4)



# Generated at 2022-06-23 23:57:30.127851
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try.unit(1)

# Generated at 2022-06-23 23:57:31.734302
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:57:36.936992
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box("foo").to_either() == Right("foo")


# Generated at 2022-06-23 23:57:41.573915
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box('Data')) == 'Box[value=Data]'
    assert str(Box(None)) == 'Box[value=None]'


# Generated at 2022-06-23 23:57:43.164989
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-23 23:57:44.451829
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:57:45.718004
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-23 23:57:47.936105
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-23 23:57:53.367133
# Unit test for method bind of class Box
def test_Box_bind():
    # Given
    def add_1(x: int) -> int:
        return x + 1

    box = Box(0)

    # When
    result = box.bind(add_1)

    # Then
    assert result == 1

# Generated at 2022-06-23 23:57:54.787637
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:58:02.608930
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box('Hello, World!')) == 'Box[value=Hello, World!]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box([1, 2, 3, 4, 5])) == 'Box[value=[1, 2, 3, 4, 5]]'



# Generated at 2022-06-23 23:58:08.776883
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy
    from pymonet.functions import fold_composition_left

    assert isinstance(Box(1).to_lazy(), Lazy)

    assert Functor(Box(1).to_lazy(), Box(1).to_lazy()).map(
        lambda a: a + 1).fold()() == 2
    assert Applicative(Box(1).to_lazy(), Box(lambda a: a + 1).to_lazy()).ap().fold()() == 2
    assert Monad(Box(1).to_lazy()).bind(lambda a: Box(a + 1).to_lazy()).fold()() == 2



# Generated at 2022-06-23 23:58:15.436281
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    from pymonet.monad_try import Failure

    assert Box('test') == Box('test')
    assert Box('test') != Box('another test')
    assert Box('test') != Box(Failure(ValueError('test error')))

# Generated at 2022-06-23 23:58:22.190562
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    # Given
    test_box = Box[int](1)
    expected_either = Right(1)

    # When
    actual_either = test_box.to_either()

    # Then
    assert (actual_either == expected_either)

    # Given
    test_box = Box[int](0)
    expected_either = Right(0)

    # When
    actual_either = test_box.to_either()

    # Then
    assert (actual_either == expected_either)

    # Given
    test_box = Box[int](-1)
    expected_either = Right(-1)

    # When
    actual_either = test_box.to_either()

    # Then

# Generated at 2022-06-23 23:58:33.643867
# Unit test for method ap of class Box
def test_Box_ap():
    assert (Box(lambda x: x + 3).ap(Box(3)) == Box(6))
    assert (Box(lambda x: x + 3).ap(Box("a")) == Box("aa"))
    assert (Box("a").ap(Box("b")) == Box("a"))
    assert (Box("a").ap(Box(lambda x: x + "b")) == Box("ab"))
    assert (Box(lambda x: x + 3).ap(Box("a")) == Box("aa"))
    assert (Box(lambda x: x + 3).ap(Box("")) == Box(""))
    assert (Box(lambda x: x + 3).ap(Box(None)) == Box(None))
    assert (Box(lambda x: x + 3).ap(Box(True)) == Box(True))

# Generated at 2022-06-23 23:58:35.458508
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()



# Generated at 2022-06-23 23:58:37.759803
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert isinstance(Box(1).to_try(), Try)

# Generated at 2022-06-23 23:58:40.618650
# Unit test for method ap of class Box
def test_Box_ap():
    box = Box(lambda x: x + 1)
    assert Box(2).ap(box) == Box(3)



# Generated at 2022-06-23 23:58:45.501316
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    res = Box(10).to_validation()
    assert type(res) is Validation
    assert res.is_success
    assert res.value == 10
    assert res.errors == []

# Generated at 2022-06-23 23:58:47.295615
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda item: item + 1) == Box(2)



# Generated at 2022-06-23 23:58:51.274116
# Unit test for constructor of class Box
def test_Box():
    assert str(Box(42)) == 'Box[value=42]'



# Generated at 2022-06-23 23:58:52.775222
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    Box(1).to_try() == Try(1)

# Generated at 2022-06-23 23:58:54.931882
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(True) == Box(True)
    assert Box(True) != Box(False)
    assert Box(True) != False
    assert Box(False) != True


# Generated at 2022-06-23 23:59:00.205852
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation() == Validation.success(5)


# Generated at 2022-06-23 23:59:03.890243
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Nothing, Maybe  # pylint: disable=cyclic-import

    # Check that Box(None) is converted to Nothing
    assert Box(None).to_maybe() == Nothing()

    # Check that Box(12) is converted to Just
    assert Box(12).to_maybe() == Maybe.just(12)

# Generated at 2022-06-23 23:59:10.439998
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_try import Try
    from pymonet.either import Either

    def test_ap(a, b):
        return a + b

    box = Box(test_ap)
    first = box.ap(Box(1)).value
    second = box.ap(Either.right(1)).value
    third = box.ap(Try.success(1)).value

    assert first == 2
    assert second.value == 2
    assert third.value == 2



# Generated at 2022-06-23 23:59:15.442440
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test for method ap of class Box.

    :returns: Unit
    :rtype: None
    """
    from pymonet.validation import Validation, Success

    assert Success(1).ap(Box(lambda x: 2 * x)) == Validation.success(2)



# Generated at 2022-06-23 23:59:17.387142
# Unit test for method __str__ of class Box
def test_Box___str__():
    value = 'value'
    assert str(Box(value)) == 'Box[value=value]'



# Generated at 2022-06-23 23:59:19.283420
# Unit test for method map of class Box
def test_Box_map():
    box = Box(1).map(lambda x: x + 1)

    assert box == Box(2)

# Generated at 2022-06-23 23:59:23.838930
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    box = Box(10)
    try_result = box.to_try()
    assert isinstance(try_result, Try)
    assert try_result == Try(10, is_success=True)



# Generated at 2022-06-23 23:59:29.279120
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('string').bind(lambda _: 'value') == 'value'


# Generated at 2022-06-23 23:59:31.986241
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def returning_function():
        return 'Box: Hello'

    assert Box('Box: Hello').to_lazy() == Lazy(returning_function)



# Generated at 2022-06-23 23:59:33.746534
# Unit test for method ap of class Box
def test_Box_ap():
    new_box = Box(lambda x: x * 2).ap(Box(5))
    assert new_box == Box(10)



# Generated at 2022-06-23 23:59:37.313759
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    assert Either.from_box(Box(10)) == Either.from_box(Box(10))
    assert Either.from_box(Box(10)) != Either.from_box(Box(20))
    assert Either.from_box(Box(10)) != Either.from_box(Box("10"))


# Generated at 2022-06-23 23:59:38.578513
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda value: value + 1) == 2



# Generated at 2022-06-23 23:59:43.285971
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:59:45.263454
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:59:49.880014
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(3)) == 'Box[value=3]'

# Generated at 2022-06-23 23:59:53.668227
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert repr(Box(1)) == "Box[value=1]"
    assert str(Box(1)) == "Box[value=1]"



# Generated at 2022-06-23 23:59:59.808537
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('abc') == Box('abc')
    assert Box(2.2) == Box(2.2)

    assert not Box(1) == Box(2)
    assert not Box('abc') == Box('cba')
    assert not Box(2.2) == Box(2.1)



# Generated at 2022-06-24 00:00:01.108709
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(42).to_lazy().evaluate() == 42

# Generated at 2022-06-24 00:00:04.835828
# Unit test for method to_maybe of class Box
def test_Box_to_maybe(): # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)

    assert Box(None).to_maybe() == Maybe.just(None)


# Generated at 2022-06-24 00:00:05.932885
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('value')) == 'Box[value=value]'


# Generated at 2022-06-24 00:00:07.544479
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box('3').to_maybe() == Maybe.just('3')


# Generated at 2022-06-24 00:00:09.457926
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-24 00:00:10.650110
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"

# Generated at 2022-06-24 00:00:11.755508
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-24 00:00:13.294421
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.box import Box

    number: Box[int] = Box(0)

    isinstance(number.to_either(), Right)


# Generated at 2022-06-24 00:00:18.996757
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    boxed_value = Box.unit(10)
    either_value = boxed_value.to_either()

    assert isinstance(either_value, Right)
    assert either_value.value == boxed_value.value



# Generated at 2022-06-24 00:00:20.563930
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box.
    """

    assert Box(10).to_validation() == Validation(10, [])



# Generated at 2022-06-24 00:00:25.785101
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-24 00:00:28.006689
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.monad_try import Try

    assert Box(7).map(lambda x: x ** 2) == Box(49)
    assert Box(Try(7, True)).map(lambda x: x.value ** 2) == Box(Try(49, True))

    # Unit test for method bind of class Box

# Generated at 2022-06-24 00:00:32.067403
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Success
    assert Success(10).to_box() == Box(10)

# Generated at 2022-06-24 00:00:34.030854
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:00:39.939857
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda x: x + 10) == Box(20)
    assert Box(11).map(lambda x: x - 2) == Box(9)
    assert Box("test").map(lambda x: x + " Foo") == Box("test Foo")
    assert Box(10).map(lambda x: x + 1) == Box(11)


# Generated at 2022-06-24 00:00:45.646569
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    value = 'some value in Box'
    box = Box(value)
    try_ = box.to_try()
    assert isinstance(try_, Try)
    assert try_.value == value
    assert try_.is_success


# Generated at 2022-06-24 00:00:48.733248
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test Box.to_either() method.
    """

    from pymonet.either import Right, Either

    right: Either[int, int] = Right(1)
    assert Box(1).to_either() == right



# Generated at 2022-06-24 00:00:50.215073
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold(lambda s: s) == 1

# Generated at 2022-06-24 00:00:51.045418
# Unit test for constructor of class Box
def test_Box():
    assert Box(0) == Box(0)

# Generated at 2022-06-24 00:00:54.954721
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box([1,2,3])) == 'Box[value=[1, 2, 3]]'

# Generated at 2022-06-24 00:00:59.175526
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Tests for bind method of class Box
    """
    from pymonet.monad_try import Try

    box_value = Box(1)
    assert box_value.bind(lambda x: x + 1) == 2
    assert box_value.bind(Try.mapp) == Try(1, False)
    assert box_value.bind(lambda x: str(x)) == '1'



# Generated at 2022-06-24 00:01:01.963324
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.lazy import Lazy

    def bind_method(value: int) -> Lazy:
        return Lazy(lambda: value + 100)
    assert Box(2).bind(bind_method) == 102


# Generated at 2022-06-24 00:01:03.318194
# Unit test for constructor of class Box
def test_Box():
    for i in range(-1, 2):
        assert Box(i) == Box(i)


# Generated at 2022-06-24 00:01:04.985606
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(3).to_validation() == Validation.success(3)

# Generated at 2022-06-24 00:01:07.440965
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test to_either return either.

    :returns: Nothing
    :rtype: Nothing
    """

    from pymonet.either import either

    assert(either(lambda x: x, lambda x: x, Box('1').to_either()) == '1')

# Generated at 2022-06-24 00:01:08.500972
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)



# Generated at 2022-06-24 00:01:16.784464
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('a')) == 'Box[value=a]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box([])) == 'Box[value=[]]'
    assert str(Box(['a'])) == 'Box[value=[a]]'
    assert str(Box((1, 2))) == 'Box[value=(1, 2)]'
    assert str(Box({'a': 1, 'b': 2})) == 'Box[value={a: 1, b: 2}]'



# Generated at 2022-06-24 00:01:18.291395
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)


# Generated at 2022-06-24 00:01:20.908885
# Unit test for constructor of class Box
def test_Box():
    assert Box(2)
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)
    assert str(Box('hello')) == 'Box[value=hello]'


# Generated at 2022-06-24 00:01:23.332780
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(2) == Box(2).to_maybe()
    assert Maybe.just(None) == Box(None).to_maybe()


# Generated at 2022-06-24 00:01:24.854719
# Unit test for method map of class Box
def test_Box_map():
    assert Box('value').map(lambda v: '{}1'.format(v)) == Box('value1')



# Generated at 2022-06-24 00:01:32.670346
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(Box(lambda x: x + 2)).ap(Box(5)) == Box(7)
    assert Box(lambda x: x).ap(Box(5)) == Box(5)
    assert Box(Box(lambda x: x + 2)).map(lambda x: x).ap(Box(Box(4))) == Box(Box(6))
    assert Box(Box(lambda x: x + 2)).map(lambda x: x).ap(Box(3)) == Box(5)

# Generated at 2022-06-24 00:01:37.046738
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda value: value + 1) == 2
    assert Box(4).bind(lambda value: value + 1) == 5
    assert Box(5.5).bind(lambda value: value + 1) == 6.5
    assert Box(5).bind(lambda value: value ** 2) == 25
    assert Box('hello, ').bind(lambda value: value + 'world!') == 'hello, world!'
    assert Box(['one', 'two', 'three']).bind(lambda value: value + ['four']) == \
           ['one', 'two', 'three', 'four']



# Generated at 2022-06-24 00:01:42.637915
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(2).map(lambda x: x + 2) == Box(4)
    assert Box(3).map(lambda x: x + 3) == Box(6)
    assert Box(4).map(lambda x: x + 4) == Box(8)
    assert Box(5).map(lambda x: x + 5) == Box(10)
    assert Box(6).map(lambda x: x + 6) == Box(12)


# Generated at 2022-06-24 00:01:43.593862
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda x: x ** 2) == 9



# Generated at 2022-06-24 00:01:49.106054
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box("1")
    assert Box(1) != None
    assert Box(None) != Box(1)
    assert Box(None) == Box(None)
    assert Box(1) == 1
    assert Box(1) == "1"
    assert Box(1) != False
    assert Box(1) != {1}
    assert Box(1) != [1]
    assert Box(1) != (1,)
    assert Box("1") == "1"
    assert Box("1") != 1
    assert Box("1") != None
    assert Box("1") != False
    assert Box("1") != {1}
    assert Box("1") != [1]

# Generated at 2022-06-24 00:01:50.640716
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'



# Generated at 2022-06-24 00:01:54.994883
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Box('abc').to_maybe() == Maybe.of('abc')
    assert Box('abc').to_maybe() != Maybe.nothing()
    assert Box(None).to_maybe() == Maybe.nothing()
    assert Box(None).to_maybe() != Maybe.of('abc')
    assert Box(Try(1, is_success=True)).to_maybe() == Maybe.of(Try(1, is_success=True))
    assert Box(Try(1, is_success=True)).to_maybe() != Maybe.nothing()



# Generated at 2022-06-24 00:01:57.507436
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()

# Generated at 2022-06-24 00:01:59.814281
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-24 00:02:02.187432
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # This test case shows that two Box objects with same value are equal
    assert Box(1) == Box(1)



# Generated at 2022-06-24 00:02:04.377519
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()

# Generated at 2022-06-24 00:02:06.453717
# Unit test for method ap of class Box
def test_Box_ap():
    def add(a):
        return lambda b: a + b

    assert Box(10).ap(Box(add).ap(Box(1))) == Box(11)



# Generated at 2022-06-24 00:02:08.913222
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert not (Box(1) == Box(2))
    assert not (Box('a') == Box('b'))


# Generated at 2022-06-24 00:02:11.308886
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'


# Generated at 2022-06-24 00:02:14.165548
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)


# Generated at 2022-06-24 00:02:18.065788
# Unit test for method bind of class Box
def test_Box_bind():
    def mapper(value: int) -> bool:
        return value > 0

    assert Box(1).bind(mapper)

    def mapper(value: int) -> bool:
        return value < 0

    assert not Box(1).bind(mapper)



# Generated at 2022-06-24 00:02:24.503502
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    def _test(v: int, w: int) -> None:
        assert Box(v) == Box(w) == v == w
        assert Box(v) == Box(v)
        assert Box(v) != Box(w)
        assert Box(v) != w
    _test(1, 2)
    _test('1', '2')
    _test([], [1])
    _test([], [])
    _test({}, {1: 1})
    _test({}, {})



# Generated at 2022-06-24 00:02:29.905336
# Unit test for method map of class Box
def test_Box_map():
    assert Box(True).map(lambda x: x).value is True
    assert Box(1).map(lambda x: x + 1).value == 2
    assert Box('A').map(lambda x: x + 'B').value == 'AB'
    assert Box([1]).map(lambda x: x + [2]).value == [1, 2]


# Generated at 2022-06-24 00:02:31.603485
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x ** 2) == 4



# Generated at 2022-06-24 00:02:34.834086
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for Box.__str__ method
    """
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-24 00:02:38.980106
# Unit test for constructor of class Box
def test_Box():
    # test without passing any variable
    assert str(Box(None)) == "Box[value=None]"
    # test with passing variable
    assert str(Box(1)) == "Box[value=1]"
    # check functions
    assert Box(1).map(lambda x: x).value == 1
    assert Box(1).bind(lambda x: x) == 1
    assert Box(1).ap(Box(lambda x: x*2)).value == 2


# Generated at 2022-06-24 00:02:39.761193
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-24 00:02:46.134565
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('abc')) == "Box[value=abc]"
    assert str(Box(123)) == "Box[value=123]"
    assert str(Box([1, 2, 3])) == "Box[value=[1, 2, 3]]"
    assert str(Box({'a': 1, 'b': 2, 'c': 3})) == "Box[value={'a': 1, 'b': 2, 'c': 3}]"



# Generated at 2022-06-24 00:02:48.872993
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:02:51.219489
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-24 00:02:53.620790
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(None).to_either() == Box(None).to_either()
    assert (Box(None)).to_either() == (Box(None)).to_either()


# Generated at 2022-06-24 00:02:56.501375
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)



# Generated at 2022-06-24 00:02:59.730643
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    maybe = Box(3).to_maybe()
    assert(type(maybe) == Maybe)
    assert(maybe == Maybe.just(3))


# Generated at 2022-06-24 00:03:02.461381
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe().is_just()
    assert Box(10).to_maybe().value == 10


# Generated at 2022-06-24 00:03:05.642930
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for Box.bind method.
    """
    box_value = Box(5)

    assert box_value.bind(lambda value: value ** 2) == 25



# Generated at 2022-06-24 00:03:09.102006
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(10) != Box(11)
    assert Box(10) != 11
    assert Box(10) == Box(10)
    assert Box(10) != ['a', 'b']



# Generated at 2022-06-24 00:03:12.539230
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(1).map(lambda x: x) == Box(1)
    assert Box(1).map(lambda x: 'box') == Box('box')


# Generated at 2022-06-24 00:03:14.641842
# Unit test for method to_either of class Box
def test_Box_to_either():
    value = 'value'
    box = Box(value)
    either = box.to_either()

    assert(isinstance(either, Right))
    assert(either.value == value)

# Generated at 2022-06-24 00:03:17.065889
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.validation import Validation

    def add(v):
        return v + 1

    assert Box(add).ap(Box(1)) == Validation.success(2)


# Generated at 2022-06-24 00:03:18.994282
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-24 00:03:24.171707
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    value = object()
    assert Box(value).to_maybe() == Maybe.just(value)
    assert Box(Lazy(lambda: value)).to_maybe() == Maybe.just(value)



# Generated at 2022-06-24 00:03:27.575890
# Unit test for constructor of class Box
def test_Box():
    assert Box(None) == Box(None)
    assert Box(None) != Box(1)
    assert Box('Hello World') != Box(1)
    assert Box(Box(1)) != Box(1)



# Generated at 2022-06-24 00:03:29.443354
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:03:32.234289
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    def test_function():
        return 2 + 2

    assert Box(test_function).to_lazy().get() == 4

# Generated at 2022-06-24 00:03:33.762656
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:03:37.438431
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test function
    """
    # GIVEN
    def add(x):
        return lambda y: x + y
    box = Box(add)

    # THEN
    assert box.ap(Box(20)) == Box(30)

# Generated at 2022-06-24 00:03:40.156908
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(lambda: 42).to_lazy().value == Lazy(lambda: lambda: 42).value



# Generated at 2022-06-24 00:03:45.595117
# Unit test for method __str__ of class Box
def test_Box___str__():
    # Empty Box object
    assert str(Box(None)) == 'Box[value=None]'

    # Filled Box object
    assert str(Box(5)) == 'Box[value=5]'

    # List in Box object
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'

    # Box of Box
    assert str(Box(Box(5))) == 'Box[value=Box[value=5]]'



# Generated at 2022-06-24 00:03:54.732727
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert (Box(1).bind(lambda x: x + 1)) == 2
    assert (Box(1).bind(lambda x: Maybe.just(x + 1))) == Maybe.just(2)
    assert (Box(1).bind(lambda x: Right(x + 1))) == Right(2)
    assert (Box(1).bind(lambda x: Lazy(lambda: x + 1))) == Lazy(lambda: 2)
    assert (Box(1).bind(lambda x: Try(x + 1, True))) == Try(2, True)