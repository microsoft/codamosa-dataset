

# Generated at 2022-06-23 23:53:50.472518
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda a: a**2) == Box(9)



# Generated at 2022-06-23 23:53:55.110717
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(2).map(lambda x: x ** 2) == Box(4)


# Generated at 2022-06-23 23:53:56.444695
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(42).to_maybe() == Just(42)



# Generated at 2022-06-23 23:53:57.783772
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation().bind(lambda x: Validation.success(5 + x)).value == 10

# Generated at 2022-06-23 23:54:00.685509
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(2).map(lambda x: x + 1) == Box(3)
    assert Box(5).map(lambda x: x * 2) == Box(10)

# Generated at 2022-06-23 23:54:02.448853
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(10).to_either() == Right(10)


# Generated at 2022-06-23 23:54:10.745634
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(5).map(lambda x: x + 5) == Box(10)
    assert Box(5).map(lambda _: 3) == Box(3)
    assert Box(False).map(lambda x: x) == Box(False)
    assert Box(0).map(lambda x: x) == Box(0)
    assert Box('str').map(lambda x: x) == Box('str')
    assert Box('str').map(lambda x: len(x)) == Box(3)
    assert Box([1, 2, 3]).map(lambda x: x) == Box([1, 2, 3])


# Generated at 2022-06-23 23:54:14.956508
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(None) == Box(None)
    assert Box('string') == Box('string')
    assert Box(1) != Box('1')
    assert Box(1) != None

# Unit tests for methods of class Box

# Generated at 2022-06-23 23:54:17.800958
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x + 5) == Box(8)
    assert Box(3).map(lambda x: x * 5) == Box(15)
    assert Box(3).map(lambda x: x / 3) == Box(1.0)


# Generated at 2022-06-23 23:54:22.829111
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box('1') != 1
    assert Box(1) != object
    assert Box(object) == Box(object)
    assert Box(1) != []
    assert Box([]) == Box([])



# Generated at 2022-06-23 23:54:24.389667
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe(1, is_just=True)


# Generated at 2022-06-23 23:54:30.560316
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(1).map(lambda x: x * 2) == Box(2)
    assert Box(1.1).map(lambda x: x + 1) == Box(2.1)
    assert Box("1").map(lambda x: x + "1") == Box("11")



# Generated at 2022-06-23 23:54:32.119605
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:54:36.266630
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box({1, 2})) == 'Box[value={1, 2}]'



# Generated at 2022-06-23 23:54:37.681362
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('Test')) == 'Box[value=Test]'



# Generated at 2022-06-23 23:54:39.039014
# Unit test for constructor of class Box
def test_Box():
    assert Box('value') == Box('value')


# Generated at 2022-06-23 23:54:41.261032
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:54:46.065304
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('a') == Box('a')
    assert Box('a') != Box(2)
    assert Box('a') != 't'
    assert Box('a') != None


# Generated at 2022-06-23 23:54:47.810210
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:54:49.671095
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(0).to_maybe() == Maybe.just(0)


# Generated at 2022-06-23 23:54:51.227621
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:54:53.995272
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe

    mapper = Maybe.just(lambda a: a + 1)
    value = Box(1)
    result = value.ap(mapper)
    assert result.value == 2


# Generated at 2022-06-23 23:54:57.117909
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    def _to_validation():
        validation = Box(Validation.success('Box')).to_validation()
        assert validation.is_success
        assert validation.errors == []
        assert validation.value == 'Box'

    _to_validation()



# Generated at 2022-06-23 23:55:02.474095
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(4) == Box(4)
    assert Box(4) != Box(3)
    assert Box(4) != 1



# Generated at 2022-06-23 23:55:03.465981
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert(Box(0).to_either() == Right(0))


# Generated at 2022-06-23 23:55:06.908881
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test for to_either method of class Box
    """
    assert Box(1).to_either() == 1


# Generated at 2022-06-23 23:55:11.326798
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1.0) == Box(1.0)
    assert Box('1') == Box('1')
    assert Box(1.0) != Box("1.0")
    assert Box(1.0) != Box(1)
    assert Box(1) != Box("1")


# Generated at 2022-06-23 23:55:14.186459
# Unit test for method ap of class Box
def test_Box_ap():
    import pytest

    box = Box(lambda a: a + 1)
    assert box.ap(Box(1)) == Box(2)
    with pytest.raises(TypeError):
        box.ap(1)

# Generated at 2022-06-23 23:55:16.400035
# Unit test for method map of class Box
def test_Box_map():
    value = 0
    box = Box(value)
    new_value = box.map(lambda x: x + 1)
    assert new_value.value == value + 1


# Generated at 2022-06-23 23:55:19.445212
# Unit test for method map of class Box
def test_Box_map():
    # GIVEN
    identity = lambda value: value
    box = Box(5)

    # WHEN
    result = box.map(identity)

    # THEN
    assert result == Box(5)



# Generated at 2022-06-23 23:55:24.182978
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.maybe import Maybe

    assert Box(1) == Box(1)
    assert Box(2) == Box(2)

    assert Box(1) != Box(2)
    assert Box(2) != Box(1)

    assert Box(1) != Maybe.just(1)
    assert Box(1) != Maybe.nothing()
    assert Box(1) != None
    assert Box(1) != 1


# Generated at 2022-06-23 23:55:25.172260
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(123).to_try() == Try(123, is_success=True)



# Generated at 2022-06-23 23:55:26.561359
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-23 23:55:32.503107
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # given
    box = Box(1)

    # when
    lazy = box.to_lazy()

    # then
    assert isinstance(lazy, Box)
    assert lazy.value == 1

# Generated at 2022-06-23 23:55:33.776686
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == 1



# Generated at 2022-06-23 23:55:39.924548
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.tests.helpers import assert_equal

    assert_equal(Box(1).to_maybe(), Maybe.just(1))


# Generated at 2022-06-23 23:55:41.096785
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert "{}".format(Box(2)) == "Box[value=2]"

# Generated at 2022-06-23 23:55:44.785416
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box('10').to_try() == Try('10', is_success=True)


# Generated at 2022-06-23 23:55:47.012913
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1)
    assert Box(1).to_try().is_success is True


# Generated at 2022-06-23 23:55:49.149957
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(12) \
        .to_maybe() == Maybe.just(12)



# Generated at 2022-06-23 23:55:55.678681
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box('10') == Box('10')
    assert Box(10) != Box('10')
    assert None != Box('10') is True


# Generated at 2022-06-23 23:55:57.550750
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)

# Generated at 2022-06-23 23:56:02.216153
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(5).to_lazy().fold(lambda: 0) == 5

# Generated at 2022-06-23 23:56:05.737752
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for transformation Box into Lazy with returning value function
    """
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)



# Generated at 2022-06-23 23:56:06.530457
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)



# Generated at 2022-06-23 23:56:10.445188
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit testing for Box.to_either method.
    """
    # pylint: disable=no-member

    assert Box(1).to_either().is_right()
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-23 23:56:15.666168
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.validation import Validation

    class Test:
        def __init__(self):
            pass

        def first(self):
            return 'first'

        def second(self):
            return 'second'

        def third(self):
            return 'third'

        def fourth(self):
            return 'fourth'

    test = Test()

    assert Box(test).bind(Test.first) == 'first'
    assert Box(test).bind(Test.second) == 'second'
    assert Box(test).bind(Test.third) == 'third'
    assert Box(test).bind(Test.fourth) == 'fourth'


# Generated at 2022-06-23 23:56:17.864919
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:56:20.917046
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(2).map(lambda x: x * 2) == Box(4)



# Generated at 2022-06-23 23:56:24.364742
# Unit test for constructor of class Box
def test_Box():
    assert Box(2) == Box(2)
    assert Box('hello') == Box('hello')


# Generated at 2022-06-23 23:56:25.574687
# Unit test for constructor of class Box
def test_Box():
    box = Box(1)
    assert box.value == 1

# Generated at 2022-06-23 23:56:28.077197
# Unit test for constructor of class Box
def test_Box():
    assert Box(123) == Box(123)
    assert Box('abc') == Box('abc')
    assert Box(123) != Box('123')
    assert Box('abc') != Box('def')


# Generated at 2022-06-23 23:56:29.168592
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:56:30.338472
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(None)) == 'Box[value=None]'


# Generated at 2022-06-23 23:56:32.800819
# Unit test for method map of class Box
def test_Box_map():
    assert Box(42).map(lambda x: x + 1) == Box(43)



# Generated at 2022-06-23 23:56:35.145619
# Unit test for constructor of class Box
def test_Box():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)
    assert Box(5) != 5



# Generated at 2022-06-23 23:56:39.090790
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(1)
    assert box == Box(1)
    assert box != Box('2')



# Generated at 2022-06-23 23:56:41.493667
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe

    assert Box(lambda x: x * 2).ap(Maybe.just(1)) == Maybe.just(2)

# Generated at 2022-06-23 23:56:47.348868
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    from pymonet.validation import Validation
    validation = Box('test').to_validation()
    assert isinstance(validation, Validation) and validation.is_success()



# Generated at 2022-06-23 23:56:51.884617
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"
    assert str(Box([1, 2, 3, 4, 5])) == "Box[value=[1, 2, 3, 4, 5]]"
    assert str(Box({"a": 1, "b": 2, "c": 3})) == "Box[value={'a': 1, 'b': 2, 'c': 3}]"
    assert str(Box("test")) == "Box[value=test]"

# Generated at 2022-06-23 23:56:54.918984
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 2) == Box(4)
    assert Box(2).map(lambda x: x + 2) == Box(4)



# Generated at 2022-06-23 23:57:03.657409
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1
    assert Box('test_data').value == 'test_data'
    assert Box(True).value is True
    assert Box((1, 2)).value == (1, 2)
    assert Box({'a': 1, 'b': 2}).value == {'a': 1, 'b': 2}
    assert Box(['a', 'b']).value == ['a', 'b']



# Generated at 2022-06-23 23:57:05.506709
# Unit test for method ap of class Box
def test_Box_ap():
    def return_x(x):
        return x

    assert Box(2).ap(Box(return_x)) == Box(2)

# Generated at 2022-06-23 23:57:07.653413
# Unit test for method map of class Box
def test_Box_map():
    assert Box('2').map(int) == Box(2)


# Generated at 2022-06-23 23:57:11.597786
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(10).map(lambda x: x + 10).value == 20
    assert Box('test').map(len).value == 4



# Generated at 2022-06-23 23:57:13.994813
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1).bind(lambda x: x * 5) == 5

# Generated at 2022-06-23 23:57:17.332505
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    import pytest
    from pymonet.maybe import Just

    x = Box(1)
    assert x.to_maybe() == Just(1)



# Generated at 2022-06-23 23:57:22.478263
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test method to_try of class Box
    """
    from pymonet.monad_try import Try
    assert Box(True).to_try() == Try(True)

# Generated at 2022-06-23 23:57:25.779792
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x ** 2) == Box(9)

    assert Box(6).map(lambda s: s + "123") == Box("6123")

    assert Box(True).map(lambda b: not b) == Box(False)


# Generated at 2022-06-23 23:57:27.071968
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(True).to_either().isRight()


# Generated at 2022-06-23 23:57:29.123679
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)


# Generated at 2022-06-23 23:57:32.169786
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('hi')) == 'Box[value=hi]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(None)) == 'Box[value=None]'



# Generated at 2022-06-23 23:57:37.594678
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Box(5).to_either() == Right(5)
    assert Box(5).to_either() == Box(5).to_maybe().to_either()

# Generated at 2022-06-23 23:57:40.412296
# Unit test for method bind of class Box
def test_Box_bind():
    def add_one(value):
        return value + 1

    assert Box(1).bind(add_one) == 2


# Generated at 2022-06-23 23:57:43.230292
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import fold

    assert fold(Box(1).to_lazy()) == 1
    assert fold(Box(10).to_lazy()) == 10
    assert fold(Box(100).to_lazy()) == 100

# Generated at 2022-06-23 23:57:46.342754
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monoid import SumMonoid
    from pymonet.lazy import Lazy

    assert isinstance(Box(1).to_lazy(), Lazy)
    assert Box(1).to_lazy().fold(SumMonoid()) == 1



# Generated at 2022-06-23 23:57:47.743968
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box('Test')
    assert str(box) == 'Box[value=Test]'

# Generated at 2022-06-23 23:57:56.777056
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda x: x + 10) == Box(20)
    assert Box(10).map(lambda x: x * 10) == Box(100)
    assert Box(10).map(lambda x: x // 10) == Box(1)
    assert Box(10).map(lambda x: x % 10) == Box(0)
    assert Box(10).map(lambda x: str(x)) == Box('10')
    assert Box(10).map(lambda x: [x, x, x]) == Box([10, 10, 10])


# Generated at 2022-06-23 23:58:04.431088
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    GIVEN: Box with some value
    WHEN: Call to_try method
    THEN: Check that returned result is a Try instance and is_success is True
    """
    from pymonet.monad_try import Try, Failure

    value = 10
    box = Box(value)

    try_ = box.to_try()

    assert isinstance(try_, Try)
    assert isinstance(box.to_try().to_failure(), Failure)
    assert box.to_try().is_success
    assert box.to_try().value == value

# Generated at 2022-06-23 23:58:06.513106
# Unit test for constructor of class Box
def test_Box():
    assert Box('foo').value == 'foo'

# Test for map function in class Box

# Generated at 2022-06-23 23:58:09.874784
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.monad_maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:58:15.522319
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    result = Box(1).to_try()

    assert isinstance(result, Try)
    assert result.value == 1
    assert result.is_success



# Generated at 2022-06-23 23:58:17.251935
# Unit test for method bind of class Box
def test_Box_bind():
    def double(value):
        return value * 2

    assert Box(10).bind(double) == 20



# Generated at 2022-06-23 23:58:22.634049
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.lazy import Lazy

    # Lazy monad for storing function
    f = Lazy(lambda: lambda x: x + 1)

    ret = Box(10).ap(f)

    assert ret == Box(11)



# Generated at 2022-06-23 23:58:25.856580
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box('some value').to_maybe() == Box('some value').value


# Generated at 2022-06-23 23:58:29.417732
# Unit test for method bind of class Box
def test_Box_bind():
    # arrange
    box = Box(5)

    # act
    box_with_applied_function = box.bind(lambda val: val * 2)

    # assert
    assert box_with_applied_function == 10


# Generated at 2022-06-23 23:58:32.567009
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_list import monad_list

    assert Box(lambda a: a + 1).ap(monad_list([1, 2, 3, 4])) == monad_list([2, 3, 4, 5])



# Generated at 2022-06-23 23:58:37.215376
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-23 23:58:39.434129
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    b = Box(5).to_maybe()
    assert isinstance(b, Maybe)
    assert b.value == 5



# Generated at 2022-06-23 23:58:45.587747
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_lazy import Lazy

    box = Box(lambda x: x + 1)
    assert box.ap(Lazy(lambda: 5)) == Box(6)
    assert box.ap(Lazy(lambda: 'lol')) == Box('lol1')

# Generated at 2022-06-23 23:58:47.714577
# Unit test for method ap of class Box
def test_Box_ap():
    """
    >>> b = Box(lambda x: x + 1)
    >>> assert b.ap(Box(1)).value == 2
    """
    pass

# Generated at 2022-06-23 23:58:52.722447
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(3) == Box(3)
    assert Box(3) != Box(4)
    assert Box('test') == Box('test')
    assert str(Box('test')) == 'Box[value=test]'



# Generated at 2022-06-23 23:58:55.491488
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Try.unit(1).equals(Box(1).to_try())



# Generated at 2022-06-23 23:58:57.209132
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(1)
    assert isinstance(box.to_either(), Right)



# Generated at 2022-06-23 23:58:58.294866
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    pass
    # Add unit test

# Generated at 2022-06-23 23:59:01.669242
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy
    assert Box(42).to_lazy() == Lazy(lambda: 42)



# Generated at 2022-06-23 23:59:12.127948
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert isinstance(Box(1).to_maybe(), Maybe)
    assert (Box(1).to_maybe() == Maybe.just(1))
    assert not (Box(1).to_maybe() == Maybe.nothing())
    assert isinstance(Box(1).to_either(), Right)
    assert (Box(1).to_either() == Right(1))
    assert isinstance(Box(1).to_lazy(), Lazy)
    assert (Box(1).to_lazy().fold(lambda: 1) == 1)
    assert isinstance(Box(1).to_try(), Try)

# Generated at 2022-06-23 23:59:14.363325
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(1)
    assert box == Box(1)
    assert box != Box(2)
    assert box != object()


# Generated at 2022-06-23 23:59:23.782090
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('Hello').bind(lambda x: x + ' world') == 'Hello world'
    assert Box(5).bind(lambda x: x + 3) == 8
    assert Box(5).bind(lambda x: x / 8) == 0.625
    assert Box(5).bind(lambda x: x ** 2) == 25
    assert Box(5).bind(lambda x: x < 3) is False
    assert Box([1, 2, 3, 4]).bind(len) == 4
    assert Box({"one": 1, "two": 2}).bind(lambda x: [x]) == [{"one": 1, "two": 2}]



# Generated at 2022-06-23 23:59:25.917329
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(10).to_maybe().__str__() == 'Maybe[value=10]'



# Generated at 2022-06-23 23:59:28.597074
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(100)
    lazy = box.to_lazy()
    assert lazy.value() == 100
    assert lazy == Lazy(lambda: 100)
    assert box.to_lazy() == Lazy(lambda: 100)


# Generated at 2022-06-23 23:59:30.747392
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(5)
    assert box.bind(lambda x: x + 10) == 15



# Generated at 2022-06-23 23:59:32.997389
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-23 23:59:35.809266
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try_ = Try(1)  # type: Try[int]
    box = Box(1)  # type: Box[int]

    assert box.to_try() == try_


# Generated at 2022-06-23 23:59:39.773041
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(2)) == 'Box[value=2]'
    assert str(Box(3)) == 'Box[value=3]'
    assert str(Box('a')) == 'Box[value=a]'
    assert str(Box('b')) == 'Box[value=b]'
    assert str(Box('c')) == 'Box[value=c]'



# Generated at 2022-06-23 23:59:40.709820
# Unit test for constructor of class Box
def test_Box():
    box = Box(1)
    assert box.value == 1



# Generated at 2022-06-23 23:59:44.946748
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for `bind` method of class `Box`

    """
    box = Box(1)

    def mapper(value):
        return value + 1

    assert box.bind(mapper) == 2

# Generated at 2022-06-23 23:59:48.764902
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-23 23:59:53.805685
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.writer import Writer

    assert Box(lambda x: x + 1).ap(Writer(0, lambda _: [])) == Writer(1, lambda _: [])
    assert Box(lambda x, y: x + y).ap(Writer(0, lambda _: [])).ap(Writer(1, lambda _: [])) == \
        Writer(1, lambda _: ['Add 0 to 1'])

# Generated at 2022-06-23 23:59:56.238857
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    """
    Test method to_maybe of Box class.
    """
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Box(1).to_maybe()
    assert Maybe.just("hi") == Box("hi").to_maybe()



# Generated at 2022-06-24 00:00:00.487383
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(42)

    assert box.to_lazy().get_val().get_val() == Lazy(lambda: 42).get_val().get_val()

if __name__ == '__main__':  # pragma: no cover
    test_Box_to_lazy()

# Generated at 2022-06-24 00:00:04.037380
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != Box(4)
    assert Box('value') == Box('value')
    assert Box('value') != Box('other value')
    assert Box(None) == Box(None)
    assert Box(None) != Box('value')
    assert Box(None) != Box(3)



# Generated at 2022-06-24 00:00:05.426603
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(5).bind(lambda x: x + 5) == 10



# Generated at 2022-06-24 00:00:12.176528
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box("test") == Box("test")
    assert Box("test") != Box("test2")

__all__ = ["Box"]

# Generated at 2022-06-24 00:00:14.667414
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)
    lazy = box.to_lazy()
    assert lazy.is_instance_of(lazy.__class__)
    assert lazy.value() == 1

# Generated at 2022-06-24 00:00:18.160945
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(20).to_lazy() == Lazy(lambda: 20)


# Generated at 2022-06-24 00:00:19.664892
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation() == Validation.success(5)


# Generated at 2022-06-24 00:00:24.955202
# Unit test for method ap of class Box
def test_Box_ap():
    x = Box(lambda x: x + 1)
    x_ = x.ap(Box(1))
    assert isinstance(x_, Box)
    assert x_ == Box(2)

# Generated at 2022-06-24 00:00:27.076491
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box([]) == Box([])
    assert Box(dict()) == Box(dict())
    assert Box(None) == Box(None)



# Generated at 2022-06-24 00:00:37.329604
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test of method to_validation of class Box
    """
    from pymonet.validation import Validation, Fail

    assert Box(None).to_validation() == Validation.success(None)
    assert Box(5).to_validation() == Validation.success(5)
    assert Box(True).to_validation() == Validation.success(True)
    assert Box(False).to_validation() == Validation.success(False)
    assert Box('a').to_validation() == Validation.success('a')
    assert Box([1, 2, 3]).to_validation() == Validation.success([1, 2, 3])

# Generated at 2022-06-24 00:00:38.676244
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(10).to_either() == Right(10)

# Generated at 2022-06-24 00:00:40.309300
# Unit test for constructor of class Box
def test_Box():
    box = Box(3)

    assert box
    assert box.value == 3



# Generated at 2022-06-24 00:00:42.893279
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() is Maybe.just(2)



# Generated at 2022-06-24 00:00:45.384061
# Unit test for method ap of class Box
def test_Box_ap():
    from .functor import test_Functor_ap
    test_Functor_ap(Box)

# Generated at 2022-06-24 00:00:47.459513
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-24 00:00:49.107884
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda value: value + 2) == Box(3)



# Generated at 2022-06-24 00:00:52.573086
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 2) == Box(4)



# Generated at 2022-06-24 00:00:54.327139
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()


# Generated at 2022-06-24 00:01:00.242516
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.maybe import Nothing, Just

    assert Box(None).to_maybe() == Maybe.nothing()
    assert Box(2).to_maybe() == Maybe.just(2)
    assert Box(3).to_maybe() == Just(3)
    assert Box(4).to_maybe() != Nothing
    assert Box(4).to_maybe() != Maybe.just(4)
    assert Box(4).to_maybe() != Just(4)
    assert Box(4).to_maybe() != Maybe.nothing()
    assert Box(4).to_maybe() != Nothing


# Generated at 2022-06-24 00:01:01.812996
# Unit test for constructor of class Box
def test_Box():
    assert Box(2) == Box(2)
    assert Box('str') == Box('str')
    assert str(Box('str')) == 'Box[value=str]'

# Generated at 2022-06-24 00:01:03.181431
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('Hello').bind(lambda x: x.upper()) == 'HELLO'



# Generated at 2022-06-24 00:01:05.904290
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10)


# Generated at 2022-06-24 00:01:08.972663
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda x: x * 2) == 6
    assert Box('abcd').bind(lambda x: x + 'efgh') == 'abcdefgh'



# Generated at 2022-06-24 00:01:10.943868
# Unit test for constructor of class Box
def test_Box():
    def inc(x):
        return x + 1

    assert Box(inc(7)) == Box(inc(7))
    assert Box(7) != Box(inc(7))
    assert str(Box(7)) == 'Box[value=7]'

# Generated at 2022-06-24 00:01:14.460515
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:01:21.649919
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    val = Box('value')
    m1 = val.to_maybe()
    m2 = val.to_maybe()

    assert m1 == m2
    assert not (m1 is m2)

    assert (
        val.to_lazy().bind(lambda a: Box(a * 2)) ==
        val.to_lazy().bind(lambda a: Box(a * 2))
    )

    assert not (
        val.to_lazy().bind(lambda a: Box(a * 2)) is
        val.to_lazy().bind(lambda a: Box(a * 2))
    )


# Generated at 2022-06-24 00:01:23.328444
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:01:25.806131
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box('value')

    assert Validation.success('value') == box.to_validation()


# Generated at 2022-06-24 00:01:32.482900
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    """
    Unit test for method bind of class Box
    """
    from pymonet.const import Const

    test_values = (1, 'a', None, [], {}, True, False)
    for test_value in test_values:
        assert Box(test_value).bind(lambda x: Const(x)).value == test_value



# Generated at 2022-06-24 00:01:35.833161
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Check correctness result of bind method.
    """
    assert Box(3).bind(lambda x: x) == 3
    assert Box(3).bind(lambda x: x + 1) == 4


# Generated at 2022-06-24 00:01:37.641961
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box = Box(value=5)
    assert box.value == 5

# Generated at 2022-06-24 00:01:41.980104
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Box(None).to_maybe(), Maybe)
    assert Box(1).to_maybe().is_just() == True
    assert Box(None).to_maybe().is_just() == False
    assert Box(1).to_maybe().get_just() == 1
    assert Box(None).to_maybe().get_just() == None


# Generated at 2022-06-24 00:01:44.509529
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != object()


# Generated at 2022-06-24 00:01:46.520804
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(lambda x: Box(x + 1)).value == 2
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1).bind(lambda x: 2 * x).value == 2



# Generated at 2022-06-24 00:01:48.799437
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    b = Box(1)
    assert b.to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:01:54.057597
# Unit test for method to_try of class Box
def test_Box_to_try():
    import types

    obj = object()
    try_return = Box(obj).to_try()
    assert try_return is not None
    assert isinstance(try_return, object)
    assert isinstance(try_return, types.ModuleType)

    assert try_return.is_success
    assert try_return.is_failure is False


# Generated at 2022-06-24 00:01:58.230061
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Just

    assert Try.unit(Just(None).to_try().get_or_else(None)) == Try.unit(None)

# Generated at 2022-06-24 00:02:02.980760
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    # equal value
    a1 = Box(1)
    a2 = Box(1)

    assert (a1 == a2) is True

    # not equal value
    a3 = Box(2)
    a4 = Box(3)

    assert (a3 == a4) is False


# Generated at 2022-06-24 00:02:04.759388
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    result = Box(42).to_try()
    assert isinstance(result, Try)
    assert result.is_success()
    assert result.value == 42


# Generated at 2022-06-24 00:02:07.172716
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box
    """
    box1 = Box(3)
    assert box1.map(lambda a: a + 10) == Box(13)


# Generated at 2022-06-24 00:02:10.948189
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1
    assert Box('a').value == 'a'



# Generated at 2022-06-24 00:02:18.866691
# Unit test for method map of class Box
def test_Box_map():
    """
    Only for doctest.
    """
    box = Box(2)

    # Test for normal usage
    assert box.map(lambda x: x ** 2) == Box(4)

    # Test for chained usage
    assert box.map(lambda x: x ** 2).map(lambda x: x ** 3) == Box(16)

    # Test for empty input
    assert box.map(lambda x: None) == Box(None)

    # Test for input with multiple values
    square = lambda x: x ** x
    assert box.map(square).map(square) == Box(65536)



# Generated at 2022-06-24 00:02:27.519603
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box('Test').to_maybe() == Maybe.just('Test')
    assert Box(123).to_maybe() == Maybe.just(123)
    assert Box(20.3).to_maybe() == Maybe.just(20.3)

    assert Box(None).to_maybe() == Maybe.just(None)
    assert Box([]).to_maybe() == Maybe.just([])
    assert Box(()).to_maybe() == Maybe.just(())

    assert Box(Right(1)).to_maybe() == Maybe.just(Right(1))


# Generated at 2022-06-24 00:02:29.904993
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * x) == Box(4)



# Generated at 2022-06-24 00:02:31.613576
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Just(1)



# Generated at 2022-06-24 00:02:38.052928
# Unit test for method map of class Box
def test_Box_map():
    # arrange
    value = 10
    string_value = 'abc'
    box = Box(value)

    # act
    result = box.map(lambda x: x * 2)
    # result = box.map(lambda x: str(x))
    # result = box.map(lambda x: string_value)

    # assert
    assert result == Box(value * 2)
    # assert result == Box(string_value)
    # assert result == Box(str(value))



# Generated at 2022-06-24 00:02:41.778006
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:02:48.795302
# Unit test for method ap of class Box
def test_Box_ap():
    """
    >>> test_Box_ap()
    >>>

    """

    class IncBox(Generic[U]):
        """
        Inc function Box
        """

        def __init__(self, func: Callable[[U], U]) -> None:
            """
            :param func: inc function
            :type func: Function[[U], U]
            """
            self.func = func

        def __eq__(self, other: object) -> bool:
            return isinstance(other, IncBox) and self.func == other.func


# Generated at 2022-06-24 00:02:51.218980
# Unit test for method map of class Box
def test_Box_map():
    box = Box(1).map(lambda x: x + 1)
    assert box == Box(2)



# Generated at 2022-06-24 00:02:52.679078
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)

# Generated at 2022-06-24 00:03:00.336829
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).bind(lambda x: x) == 1
    assert Box(1).map(lambda x: x) == Box(1)
    assert Box(lambda x: x).ap(Box(1)) == Box(1)
    assert Box(1).to_maybe() == Box(1).value
    assert Box(1).to_either() == Box(1).value
    assert Box(1).to_try() == Box(1).value
    assert Box(1).to_validation() == Box(1).value
    assert Box(1).to_lazy().get() == Box(1).value

# Generated at 2022-06-24 00:03:02.793313
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either
    assert Either.right(1).to_box().to_either() == Either.right(1)

# Generated at 2022-06-24 00:03:08.650075
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, lazy

    returned_lazy = Lazy(lambda: 7).to_box()
    # Box(Lazy(<function _lambda.<locals>.<lambda> at 0x1093b2d90>)).value.get()
    assert returned_lazy.value.value() == 7

    test_lazy = lazy(lambda: Box(7))
    # Box(Lazy(<function _lambda.<locals>.<lambda> at 0x1093b2d90>)).value.get()
    assert test_lazy.value.value() == 7

# Generated at 2022-06-24 00:03:11.068239
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:03:12.661568
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-24 00:03:13.829218
# Unit test for constructor of class Box
def test_Box():
    assert Box("a")

# Unit tests for method map of class Box

# Generated at 2022-06-24 00:03:14.947530
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().get_value() == 1

# Generated at 2022-06-24 00:03:17.019382
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    # Test conversion Box to Validation
    assert Box(100).to_validation() == Validation(100, [])



# Generated at 2022-06-24 00:03:18.220572
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try(10, True) == Box(10).to_try()

# Generated at 2022-06-24 00:03:25.100158
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, Success, Failure

    success_try = Try(1, is_success=True)
    failure_try = Try(1, is_success=False)

    assert Box(1).to_try() == Success(1)
    assert Box(failure_try).to_try() == failure_try
    assert Box(success_try).to_try() == success_try



# Generated at 2022-06-24 00:03:27.126563
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    assert Box(1).to_either().value == 1



# Generated at 2022-06-24 00:03:28.407207
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-24 00:03:39.484636
# Unit test for method bind of class Box

# Generated at 2022-06-24 00:03:41.635457
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-24 00:03:42.998719
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'



# Generated at 2022-06-24 00:03:47.203698
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    In this unit test we will demonstrate transformation of Box into Lazy monad.
    We create new Box with value 1.
    We create new Lazy monad with function returning previous value.
    We fold lazy monad and check that result is equal to stored value.
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_lazy().fold() == 1


# Generated at 2022-06-24 00:03:51.760884
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(23).to_box() == Box(23)
    assert Maybe.nothing().to_box() == Box(None)
