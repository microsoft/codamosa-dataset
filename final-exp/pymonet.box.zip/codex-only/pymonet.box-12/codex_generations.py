

# Generated at 2022-06-23 23:53:48.080983
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:53:54.358047
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.monad_try import Failure, Try
    from pymonet.validation import Validation, Failure as ValidationFailure

    assert Box(Try(1, is_success=True)) != Box(Failure(1))
    assert Box(Try(1, is_success=True)) == Box(Try(1, is_success=True))
    assert Box(Try(1, is_success=True)) != Box(Try(2, is_success=True))

    assert Box(Validation.success(1)) != Box(ValidationFailure(1))
    assert Box(Validation.success(1)) == Box(Validation.success(1))
    assert Box(Validation.success(1)) != Box(Validation.success(2))


# Generated at 2022-06-23 23:53:56.444845
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:53:58.720694
# Unit test for constructor of class Box
def test_Box():
    b = Box(1)

    assert isinstance(b, Box) and b.value == 1
    assert Box(0) == Box(0)


# Generated at 2022-06-23 23:54:00.546974
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1



# Generated at 2022-06-23 23:54:02.273943
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:54:05.054912
# Unit test for method map of class Box
def test_Box_map():
    result = Box(3).map(lambda x: x + 1)
    expected = Box(4)

    assert result == expected



# Generated at 2022-06-23 23:54:11.779611
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.functor import Functor

    class Container(Functor):
        def __init__(self, value):
            self.value = value

        def map(self, mapper):
            return Container(mapper(self.value))

    box_with_function = Box(lambda x: x + 1)
    container_applicative = Container(3)
    assert box_with_function.ap(container_applicative) == Container(4)

# Generated at 2022-06-23 23:54:13.796308
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().fold() == 10



# Generated at 2022-06-23 23:54:17.029457
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(2)) == 'Box[value=2]'


# Generated at 2022-06-23 23:54:20.806047
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert str(Box(1)) == 'Box[value=1]'
    assert Box(1).value == 1

    

# Generated at 2022-06-23 23:54:26.328496
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(5).bind(lambda value: value + 1) == 6



# Generated at 2022-06-23 23:54:32.874254
# Unit test for method map of class Box
def test_Box_map():
    """
    Test mapping function on Box.
    """
    def square(value):
        return value ** 2

    assert Box(10).map(square) == Box(100)
    assert Box(-1).map(square) == Box(1)



# Generated at 2022-06-23 23:54:36.422377
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(42).to_maybe() == Maybe.just(42)



# Generated at 2022-06-23 23:54:38.620111
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = box1

    assert box1 == box2
    assert box2 == box1



# Generated at 2022-06-23 23:54:41.779600
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1) == Box(1)

    box = Box(1)

    assert box.to_validation().value == 1, \
        'box: {}, valid: {}'.format(box.to_validation(), box.to_validation().value)

# Generated at 2022-06-23 23:54:46.781009
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() is 1



# Generated at 2022-06-23 23:54:48.048807
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1
    assert Box(1).value == 1

# Generated at 2022-06-23 23:54:51.979024
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for Box bind method
    """

    value = 10
    value_mapped = 100

    def mapper(v):
        return v * 10

    box = Box(value)
    box_mapped = box.bind(mapper)

    assert box_mapped == Box(value_mapped)



# Generated at 2022-06-23 23:54:53.474951
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-23 23:54:54.611313
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(2)) == 'Box[value=2]'



# Generated at 2022-06-23 23:54:57.344662
# Unit test for method ap of class Box
def test_Box_ap():
    # Test case data
    function = Box(lambda x: x * 2)
    value = Box(2)

    # Expected result
    expected = Box(4)

    # Actual result
    actual = function.ap(value)

    # Assert
    assert(expected == actual)

# Generated at 2022-06-23 23:54:58.515553
# Unit test for constructor of class Box
def test_Box():
    box = Box(123)
    assert box.value == 123
    assert 'Box[value=123]' == str(box)

# Generated at 2022-06-23 23:55:04.131873
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(20)
    assert Box(20) != Box(10)
    assert Box(10) != 10
    assert 10 != Box(10)
    assert Box(10) != '10'
    assert '10' != Box(10)
    assert Box(10) == Box(10)



# Generated at 2022-06-23 23:55:08.320650
# Unit test for constructor of class Box
def test_Box():
    assert Box('') == Box('')
    assert str(Box('')) == 'Box[value=]'
    assert Box('') != 'a'



# Generated at 2022-06-23 23:55:10.202833
# Unit test for constructor of class Box
def test_Box():
    assert isinstance(Box(1), Box)
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:55:12.402719
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:55:15.811174
# Unit test for method ap of class Box
def test_Box_ap():
    # given
    box_value = Box(lambda x: x + 5)
    some_box = Box(6)
    # when
    result = box_value.ap(some_box)
    # then
    assert result.value == 11
    assert result == Box(11)

# Generated at 2022-06-23 23:55:18.193571
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:55:19.791748
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(10).to_either() == Right(10)



# Generated at 2022-06-23 23:55:21.443540
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    from pymonet.functool import identity

    assert Box(1).bind(identity) == 1



# Generated at 2022-06-23 23:55:25.030264
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(1)
    assert str(box) == 'Box[value=1]'


# Generated at 2022-06-23 23:55:27.661251
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)

    assert Box(1).map(lambda x: x + 2) == Box(3)


# Generated at 2022-06-23 23:55:32.574856
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Nothing
    from pymonet.maybe import Just

    assert Box(None).to_maybe() == Nothing()
    assert Box(2).to_maybe() == Just(2)


# Generated at 2022-06-23 23:55:37.906385
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    # Create new instance of Box[int]
    assert str(Box(1)) == 'Box[value=1]'
    
    # Create new instance of Box[str] 
    assert str(Box('1')) == 'Box[value=1]'


# Generated at 2022-06-23 23:55:45.568379
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x * 2) == 4
    assert Box(lambda x: x * x).bind(lambda x: x(2)) == 4
    assert Box(lambda x: x ** 2).bind(lambda x: x(2)) == 4
    assert Box([]).bind(lambda x: x[2]) == IndexError
    assert Box([1, 2, 3]).bind(lambda x: x[2]) == 3
    assert Box(1).bind(None) == 1
    assert Box(2).bind(lambda x: x * 2) == 4
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(3).bind(lambda x: x + 2) == 5
    assert Box(1).bind(lambda x: x - 1) == 0

# Generated at 2022-06-23 23:55:53.032534
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(12).to_either() == Right(12)
    assert Box(13.13).to_either() == Right(13.13)
    assert Box('123').to_either() == Right('123')
    assert Box([1,2,3]).to_either() == Right([1,2,3])
    assert Box({'a': 1, 'b': 2}).to_either() == Right({'a': 1, 'b': 2})
    assert Box(set([1,2,3])).to_either() == Right(set([1,2,3]))


# Generated at 2022-06-23 23:55:57.694789
# Unit test for constructor of class Box
def test_Box():
    from pymonet.test_helpers import compare_with_builtin

    # Test success
    compare_with_builtin(Box, 1 == 1)
    compare_with_builtin(Box, False)
    compare_with_builtin(Box, '123')
    compare_with_builtin(Box, 1 if True else 0)



# Generated at 2022-06-23 23:56:03.088186
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1
    assert Box('test').value == 'test'
    assert Box({'key': 'test'}).value == {'key': 'test'}
    assert Box(None).value is None
    assert Box([1, 2, 3]).value == [1, 2, 3]



# Generated at 2022-06-23 23:56:09.520128
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(2)) == 'Box[value=2]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box('test')) == 'Box[value=test]'
    assert str(Box(['a', 'b', 'c'])) == 'Box[value=[a, b, c]]'



# Generated at 2022-06-23 23:56:10.818755
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:56:15.325381
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    maybe = Maybe.just(1)

    assert maybe == box.to_maybe()


# Generated at 2022-06-23 23:56:16.414210
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda a: a + 2) == 12



# Generated at 2022-06-23 23:56:17.550564
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda v: v + 1) == Box(2)



# Generated at 2022-06-23 23:56:20.062306
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('Some value').bind(lambda v: v == 'Some value')


# Generated at 2022-06-23 23:56:26.079812
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(None) == Box(None)
    assert Box({'a': 1}) == Box({'a': 1})



# Generated at 2022-06-23 23:56:28.797477
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(3).to_maybe() == Maybe.just(3)
    assert Box(None).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:30.963514
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Nothing, Just

    assert Box(0).to_maybe() == Just(0)
    assert Box(Nothing()).to_maybe() == Nothing()

# Generated at 2022-06-23 23:56:32.219092
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    assert Box(lambda x: x + 1).ap(Box(3)) == Box(4)

# Generated at 2022-06-23 23:56:37.482359
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Box(2).to_either() == Right(2)

    assert Box('').to_either() == Right('')

    assert Box([]).to_either() == Right([])

    assert Box(()).to_either() == Right(())

    assert Box({}).to_either() == Right({})

    assert Box(Maybe.nothing).to_either() == Right(Maybe.nothing)

    assert Box(Left('left error')).to_either() == Right(Left('left error'))

    assert Box(Right('right value')).to_either() == Right(Right('right value'))

    assert Box(2).to_either().left_map(lambda l: 10) == Right(2)

    assert Box('').to

# Generated at 2022-06-23 23:56:39.001943
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1), \
        'Box.__eq__(..) should be return True if boxes ar equals, otherwise False'


# Unit tests for method __str__ of class Box

# Generated at 2022-06-23 23:56:43.013953
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box(2)

    assert box1 is not box2
    assert box1 == box2
    assert box1 != box3



# Generated at 2022-06-23 23:56:46.740951
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Box(1).to_maybe()

# Generated at 2022-06-23 23:56:48.355874
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:56:51.645445
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box
    """
    from pymonet.either import Left, Right

    assert Left('left') != Right('right')
    assert Right('right') == Right('right')

    assert Right('right') != Box('right')
    assert Box('right').to_either() == Right('right')



# Generated at 2022-06-23 23:57:00.075298
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Checks method ap of class Box.
    """
    from pymonet.either import Left

    # Case: both Boxes contain function.
    assert Box(lambda x: x + 1).ap(Box(lambda y: y + 1)).value == 3
    assert Box(lambda x: x + 1).ap(Box(lambda x: x + 2)).value == 4
    assert Box(lambda y: y * y).ap(Box(lambda y: y ** 3)).value == 8
    assert Box(lambda y: y - 8).ap(Box(lambda y: y / 2)).value == 0
    assert Box(lambda y: y / 2).ap(Box(lambda y: y - 8)).value == 3

    # Case: first Box contains function and second one contains non function value.

# Generated at 2022-06-23 23:57:02.228722
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-23 23:57:10.843976
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_list import List
    from pymonet.monad_try import Try

    assert Box(2).ap(Box(lambda x: x ** 2)) == Box(lambda x: x ** 2)(2)
    assert Box(2).ap(List.of(3, 4)) == List.of(3, 4).ap(Box(lambda x: x ** 2))
    assert Box(2).ap(Try(lambda x: x ** 2, is_success=True)) == Try(lambda x: x ** 2, is_success=True).ap(Box(2))

# Generated at 2022-06-23 23:57:14.500015
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)

    assert Box(None).to_try() == Try(None, is_success=True)



# Generated at 2022-06-23 23:57:16.615900
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-23 23:57:22.531161
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert isinstance(Box('a').to_validation(), Validation)
    assert Box('a').to_validation().is_success
    assert str(Box('a').to_validation().value) == "a"

# Generated at 2022-06-23 23:57:31.621005
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success, Failure

    assert Box(1).to_validation() == Validation.success(1)
    assert Box(Validation.success(1)).to_validation() == Validation.success(1)
    assert Box(Validation.failure([1])).to_validation() == Validation.failure([1])

    # Test composition rules
    assert Box(Validation.success(1)).to_validation().to_validation().to_validation() == Validation.success(1)
    assert Box(Validation.failure([1])).to_validation().to_validation().to_validation() == Validation.failure([1])

# Generated at 2022-06-23 23:57:36.689500
# Unit test for method map of class Box
def test_Box_map():
    assert Box(lambda x, y: x + y).map(lambda x: x(1, 2)).value == 3, 'Mapper should return new box with mapped value.'


# Generated at 2022-06-23 23:57:38.482800
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 2) == Box(4)


# Generated at 2022-06-23 23:57:41.201138
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box
    """
    assert Box(2).bind(lambda x: x + 1) == 3



# Generated at 2022-06-23 23:57:45.494351
# Unit test for method __str__ of class Box
def test_Box___str__():
    from pymonet.monoid import string_mappend
    from pymonet.string import String

    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box('abc')) == 'Box[value=abc]'
    assert str(Box(string_mappend)) == 'Box[value=<function string_mappend at 0x10cee2158>]'
    assert str(Box(String('abc'))) == 'Box[value=abc]'



# Generated at 2022-06-23 23:57:47.120744
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-23 23:57:51.215048
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: 3*x).ap(Box(3)).value == 9

# Generated at 2022-06-23 23:57:53.828489
# Unit test for method ap of class Box
def test_Box_ap():
    def increment(a):
        return a + 1

    result = Box(increment).ap(Box(5))
    assert result == Box(6)


# Generated at 2022-06-23 23:57:55.393739
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:57:58.587395
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe().value == 1


# Generated at 2022-06-23 23:58:00.097901
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(5).bind(lambda x: x * 2) == 10

# Generated at 2022-06-23 23:58:04.371505
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """

    # equal test
    assert True is Box(1) == Box(1)

    # non equal test
    assert False is Box(1) == Box(2)

    # non equal with other class
    assert False is Box(1) == 1



# Generated at 2022-06-23 23:58:07.840378
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(3)
    assert box.to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-23 23:58:09.819855
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:58:14.361446
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(100).to_maybe() == Maybe.just(100)


# Generated at 2022-06-23 23:58:17.620419
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != None
    assert Box(1) != True


# Generated at 2022-06-23 23:58:18.698755
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().evaluate() == 1

# Generated at 2022-06-23 23:58:23.183052
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)
    assert Box(2).to_validation() == Validation.success(2)
    assert Box(None).to_validation() == Validation.success(None)
    assert Box(object()).to_validation() == Validation.success(object())


# Generated at 2022-06-23 23:58:34.159586
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for class Box.

    :returns: None
    :rtype: None
    """
    def add_one(number):
        return number + 1

    def add_two(number):
        return number + 2

    box_one = Box(add_one)
    box_two = Box(add_two)

    assert (box_one.ap(Box(5)) == Box(add_one(5)))
    assert (box_one.ap(Box(5)) != box_one)
    assert (box_two.ap(Box(5)) == Box(add_two(5)))
    assert (box_two.ap(Box(5)) != box_two)
    assert (box_one.ap(Box(box_two)) == box_one.ap(Box(box_two.value)))

# Generated at 2022-06-23 23:58:39.631448
# Unit test for method bind of class Box
def test_Box_bind():
    # Given
    value_1 = 1
    value_2 = 2
    func = lambda x: x + 1
    box_1 = Box(value_1)
    box_2 = Box(value_2)

    # When
    actual_1 = box_1.bind(func)
    actual_2 = box_2.map(func)

    # Then
    assert actual_1 == Box(value_1 + 1)
    assert actual_2 == Box(value_2 + 1)


# Generated at 2022-06-23 23:58:41.075489
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box('x').to_either() == Right('x')


# Generated at 2022-06-23 23:58:44.666311
# Unit test for method to_validation of class Box
def test_Box_to_validation():

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:58:46.313161
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda x: x * 2) == Box(20)

# Generated at 2022-06-23 23:58:48.475599
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box
    """
    assert Box(2).map(lambda value: value * 2) == Box(4)



# Generated at 2022-06-23 23:58:51.387180
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"


# Generated at 2022-06-23 23:58:52.551253
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)


# Generated at 2022-06-23 23:58:54.741589
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    assert Box(lambda x: 2 * x - 2).ap(Box(2)) == Box(2)

# Generated at 2022-06-23 23:59:01.643457
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    def identity_functor(value):
        return Functor(value)

    assert Box('value').to_lazy() == Lazy(identity_functor, 'value')

# Generated at 2022-06-23 23:59:08.712198
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')
    assert Box(12345) != 12345
    assert Box(12345) != None
    assert Box(12345) != True
    assert Box(12345) != False



# Generated at 2022-06-23 23:59:13.883139
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test for method to_maybe of class Box.

    :return:
    """
    from pymonet.maybe import Maybe, Nothing
    from pymonet.either import Right, Left
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(1).to_maybe().flat_map(lambda x: x + 1) == Maybe.just(2)
    assert Box(1).to_maybe().flat_map(lambda x: Nothing) == Nothing()
    assert Box(1).to_maybe().map(lambda x: x + 1) == Maybe.just(2)

# Generated at 2022-06-23 23:59:16.008927
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-23 23:59:22.664859
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box.
    """
    assert Box(1).map(lambda x: x + 2) == Box(3)



# Generated at 2022-06-23 23:59:24.368495
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-23 23:59:29.141770
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(2).to_either() == Box(2).to_either()

# Generated at 2022-06-23 23:59:30.804252
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)

# Generated at 2022-06-23 23:59:34.422351
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    assert Box(1).to_either() == Right(1)
    assert Box(Left(1)).to_either() == Left(Left(1))


# Generated at 2022-06-23 23:59:36.748972
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Given
    value = 10
    box1 = Box(value)
    box2 = Box(value)

    # Then
    assert box1 == box2, 'Should be true'



# Generated at 2022-06-23 23:59:40.365982
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert 1 == Box(1)
    assert 1 != Box(2)
    assert Box(2) != 1
    assert Box(1) == 1
    assert 1 == Box(1)
    assert Box(2) == 2
    assert 2 == Box(2)



# Generated at 2022-06-23 23:59:41.734743
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(True).to_try() == Try(True, is_success=True)

# Generated at 2022-06-23 23:59:44.061673
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(4).to_try() == Try(4)

# Generated at 2022-06-23 23:59:45.558929
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-23 23:59:56.285125
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe, just
    from pymonet.either import Either, Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try, success
    from pymonet.validation import Validation, Success

    assert Box(None).bind(lambda x: x) == None
    assert Box(None).bind(lambda x: Box(x)) == Box(None)
    assert Box(None).bind(lambda x: maybe_fn()) == Maybe.nothing()
    assert Box(None).bind(lambda x: maybe_fn()).bind(lambda x: Box(x)) == Box(Maybe.nothing())
    assert Box('data').bind(lambda x: maybe_fn()) == Maybe.just('data')

# Generated at 2022-06-23 23:59:58.334615
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)

# Generated at 2022-06-24 00:00:04.261381
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try_box = Box(1).to_try()
    assert try_box == Try(1, is_success=True)

# Generated at 2022-06-24 00:00:10.795273
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(100).to_try() == Try(100, is_success=True)

    try:
        Box(100).to_try().bind(lambda x: x/0)
    except ZeroDivisionError as e:
        assert not isinstance(e, Exception)
        assert isinstance(e, ValueError)

    assert Box(100).to_try().bind(lambda x: x + 5) == Try(105, is_success=True)
    assert Box(100).to_try().bind(lambda x: Try.success(x + 5)) == Try(105, is_success=True)
    assert Box(100).to_try().bind(lambda x: Try.failure(Exception('err'))) == Try(Exception('err'), is_success=False)


# Unit test

# Generated at 2022-06-24 00:00:16.516965
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit tests for method __eq__ of class Box.
    """
    import unittest

    class BoxEqualityTestSuite(unittest.TestCase):
        """
        Test cases for equality of Box.
        """

        def test_equality_with_same_value(self):
            """
            Tests for checking equality of Box with same values.
            """
            self.assertTrue(Box(1) == Box(1))

        def test_equality_with_different_values(self):
            """
            Tests for checking equality of Box with different values.
            """
            self.assertFalse(Box(1) == Box(2))

        def test_equality_with_different_types(self):
            """
            Tests for checking equality of Box with different types.
            """

# Generated at 2022-06-24 00:00:18.072464
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)



# Generated at 2022-06-24 00:00:19.857816
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box('a').to_validation() == Validation.success('a')


# Generated at 2022-06-24 00:00:21.776703
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(123).to_try() == Try(123, is_success=True)



# Generated at 2022-06-24 00:00:25.865754
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box({}).to_try() == Try({}, is_success=True)



# Generated at 2022-06-24 00:00:26.705226
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(42)) == 'Box[value=42]'



# Generated at 2022-06-24 00:00:27.938080
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(1)
    b = Box(1)

    assert a == b
    assert a != 1



# Generated at 2022-06-24 00:00:32.729271
# Unit test for method map of class Box
def test_Box_map():
    def add1(x: int) -> int:
        return x + 1

    assert Box(1).map(add1) == Box(2)



# Generated at 2022-06-24 00:00:35.199232
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Arrange
    left = Box(5)
    right = Box(5)

    # Act
    result = left == right

    # Assert
    assert result is True



# Generated at 2022-06-24 00:00:41.606014
# Unit test for method map of class Box
def test_Box_map():
    assert Box(3).map(lambda x: x * 2) == Box(6)
    assert Box("test").map(lambda x: x.capitalize()) == Box("Test")
    assert Box("test").map(lambda x: x.replace("t", "a")) == Box("aesa")
    assert Box("123").map(lambda x: int(x)) == Box(123)



# Generated at 2022-06-24 00:00:43.246108
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(123).bind(lambda a: a == 123)

# Generated at 2022-06-24 00:00:45.791818
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Box(10).to_lazy()



# Generated at 2022-06-24 00:00:50.132650
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box.
    """

    assert Box(123).to_either() == Box(123).to_either()
    assert Box(123).to_either() == Box(123).to_either()
    assert str(Box(123).to_either()) == 'Right[result=123]'


# Generated at 2022-06-24 00:00:51.689224
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(45)) == "Box[value=45]"


# Generated at 2022-06-24 00:00:52.843786
# Unit test for constructor of class Box
def test_Box():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-24 00:00:56.012748
# Unit test for constructor of class Box
def test_Box():

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1).value == 1
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-24 00:00:57.655235
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(True).to_either().is_right()
    assert Box(True).to_either().unwrap()


# Generated at 2022-06-24 00:01:00.017904
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try(2, is_success=True) == Box(2).to_try()

# Generated at 2022-06-24 00:01:02.368657
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(5)) == Box(6)
    assert Box(lambda x: x * 2).ap(Box(5)) == Box(10)



# Generated at 2022-06-24 00:01:04.357017
# Unit test for method __str__ of class Box
def test_Box___str__(): # pragma: no cover
    assert str(Box(10)) == 'Box[value=10]', 'Method __str__ of class Box is failed'


# Generated at 2022-06-24 00:01:06.863228
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 6) == Box(6).to_lazy()

# Generated at 2022-06-24 00:01:14.293248
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    res = Box(1).to_lazy()
    # Check if res is Monad.
    assert isinstance(res, Monad)
    # Check if res is Functor.
    assert isinstance(res, Functor)
    # Check if res is Lazy.
    assert isinstance(res, Lazy)
    # Check if res is Box.
    assert isinstance(res, Box)
    # Check res value.
    assert res.value() == 1



# Generated at 2022-06-24 00:01:17.102134
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert str(Box(123).to_try()) == "Success(result=123)"



# Generated at 2022-06-24 00:01:18.409708
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().fold() == 1

# Generated at 2022-06-24 00:01:22.416032
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert not (Box(5) == Box(3))
    assert not (Box(5) == None)
    assert Box('asd') == Box('asd')
    assert not (Box('asd') == Box('asd2'))
    assert not (Box('asd') == None)


# Generated at 2022-06-24 00:01:23.960137
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-24 00:01:27.469950
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box
    """
    assert Box(1).to_lazy().value() == 1


# Generated at 2022-06-24 00:01:32.704899
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('1')) == 'Box[value=1]'
    assert str(Box([1])) == 'Box[value=[1]]'
    assert str(Box({'1': 1})) == 'Box[value={1: 1}]'


# Generated at 2022-06-24 00:01:35.277092
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert not (Box(1) == Box(2))
    assert not (Box(1) == Box('str'))
    assert not (Box(1) == 1)
    assert Box(1) == Box(1)
    assert Box('str') == Box('str')



# Generated at 2022-06-24 00:01:41.953932
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(3).to_either() == Right(3)
    assert Box(3.5).to_either() == Right(3.5)
    assert Box('a').to_either() == Right('a')
    assert Box(['a', 'b']).to_either() == Right(['a', 'b'])
    assert Box((1, 2)).to_either() == Right((1, 2))
    assert Box(set()).to_either() == Right(set())
    assert Box(True).to_either() == Right(True)
    assert Box(None).to_either() == Right(None)

# Generated at 2022-06-24 00:01:43.705267
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(2).to_try() == Try(2, is_success=True)


# Generated at 2022-06-24 00:01:47.846731
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.monad import Monad
    from pymonet.maybe import Maybe

    maybe_monad = Box('test').to_maybe()

    assert isinstance(maybe_monad, Maybe)
    assert isinstance(maybe_monad, Monad)
    assert maybe_monad.is_just()
    assert maybe_monad == Maybe.just('test')
    assert maybe_monad == Just('test')
    assert not maybe_monad.is_nothing()
    assert maybe_monad != Nothing()


# Generated at 2022-06-24 00:01:49.808779
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    assert isinstance(Box(1).to_either(), Either)



# Generated at 2022-06-24 00:01:51.418800
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)



# Generated at 2022-06-24 00:01:53.325993
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-24 00:01:59.909060
# Unit test for constructor of class Box
def test_Box():
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)
    assert Box([1]) != Box([1])

    assert str(Box(2)) == 'Box[value=2]'
    assert str(Box([])) == 'Box[value=[]]'
    assert str(Box([1])) == 'Box[value=[1]]'
    assert str(Box('foo')) == 'Box[value=foo]'



# Generated at 2022-06-24 00:02:01.326141
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('text')) == "Box[value=text]"


# Generated at 2022-06-24 00:02:04.896029
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    input_object = 1
    input_box = Box(input_object)

    assert input_box == Box(1)
    assert input_box == input_box
    assert input_box != Box(2)
    assert input_box != object()



# Generated at 2022-06-24 00:02:10.678667
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) == Box(1.0)
    assert Box(1) != Box(2)
    assert Box(None) == Box(None)
    assert Box(1) != 1
    assert Box(1) != 'A'


# Generated at 2022-06-24 00:02:11.998529
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(5).value == 5



# Generated at 2022-06-24 00:02:14.893073
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    value = 123

    result = Box(value).to_either()

    assert result == Right(value)

# Generated at 2022-06-24 00:02:18.372103
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(0).to_either() == Box(0).to_either()
    assert Box(1).to_either().value == 1
    assert Box(1).to_either().is_right
    assert not Box(1).to_either().is_left

# Generated at 2022-06-24 00:02:22.323773
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1)
    assert Box(lambda x, y: x + y).to_try() == Try(lambda x, y: x + y)
    assert Box([]).to_try() == Try([])
    assert Box({}).to_try() == Try({})
    assert Box(A()).to_try() == Try(A())
    assert Box(Exception()).to_try() == Try(Exception(), is_success=True)



# Generated at 2022-06-24 00:02:25.301561
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test Case for method __eq__ of class Box.
    """
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box('string') != Box(1)



# Generated at 2022-06-24 00:02:28.460532
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == "Box[value=10]"
    assert str(Box("abc")) == "Box[value=abc]"



# Generated at 2022-06-24 00:02:30.874781
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(1).to_lazy().force() == 1



# Generated at 2022-06-24 00:02:35.420461
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Box can be converted to not folded Lazy.

    :return: None
    :rtype: None
    """
    box = Box(1)
    lazy = box.to_lazy()

    assert lazy.value() == 1

# Generated at 2022-06-24 00:02:38.659741
# Unit test for method map of class Box
def test_Box_map():
    def t1(a: int) -> str:
        return str(a)

    res1 = Box(1).map(t1)

    def t2(a: int) -> int:
        return a + 1

    res2 = Box(1).map(t2)

    assert res1.value == '1'
    assert res2.value == 2


# Generated at 2022-06-24 00:02:42.405605
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(21).to_maybe().is_just

    assert Box(21).to_maybe() == Maybe.just(21)



# Generated at 2022-06-24 00:02:49.349735
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box.

    :returns: True if test passed else False
    :rtype: bool
    """
    from pymonet.maybe import Maybe

    is_test_passed = Maybe.just(1) == Box(1).to_maybe()
    return is_test_passed


# Generated at 2022-06-24 00:02:52.508641
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)

# Generated at 2022-06-24 00:02:54.972844
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:02:57.836019
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    box = Box(value=1)
    expected = Try(value=1, is_success=True)

    assert box.to_try() == expected



# Generated at 2022-06-24 00:03:00.024235
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-24 00:03:01.502134
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe().is_just()



# Generated at 2022-06-24 00:03:09.518053
# Unit test for constructor of class Box
def test_Box():
    triple = lambda x : x * 3

    assert Box(2) == Box(2)
    assert Box(2).value == 2
    assert Box(2).map(triple) == Box(6)
    assert Box(2).map(triple).value == 6
    assert Box(2).bind(triple) == 6
    assert Box(triple).ap(Box(2)) == Box(6)
    assert Box(triple).ap(Box(2)).value == 6
    assert Box(2).to_maybe().value.value == 2
    assert Box(2).to_either().value == 2
    assert box_to_lazy(Box(2))() == 2
    assert Box(2).to_try().value.value == 2
    assert Box(2).to_validation().value.value == 2


# Generated at 2022-06-24 00:03:12.241964
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box(1).map(lambda x: x * 2) == Box(2)

# Generated at 2022-06-24 00:03:15.276320
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either, Right

    assert Box(1).to_either() == (Right(1),)
    assert isinstance(Box(1).to_either(), Either)
    assert Box(1).to_either() == Box(1).to_either().unit()

# Generated at 2022-06-24 00:03:17.335325
# Unit test for method bind of class Box
def test_Box_bind():
    def g(x):
        return x + 5

    # Should return Box with value 10
    assert Box(5).bind(g) == Box(10)


# Generated at 2022-06-24 00:03:19.269188
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None



# Generated at 2022-06-24 00:03:24.662866
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    box = Box(5)
    try_ = box.to_try()
    assert isinstance(try_, Try)
    assert (try_.value, try_.is_success) == (box.value, True)



# Generated at 2022-06-24 00:03:26.692181
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)

# Generated at 2022-06-24 00:03:27.947553
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Success

    value = 10
    box = Box(value)
    try_monad = box.to_try()

    assert try_monad == Success(value)

# Generated at 2022-06-24 00:03:29.762210
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert not Box(10) == Box(20)
    assert not Box(10) == 'str'



# Generated at 2022-06-24 00:03:33.067874
# Unit test for constructor of class Box
def test_Box():
    assert Box(10) == Box(10)
    assert Box('Hello World') == Box('Hello World')
    assert Box(10) != Box('Hello World')



# Generated at 2022-06-24 00:03:37.810920
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert(isinstance(Box(1).to_lazy(), Lazy))
    assert(Box(1).to_lazy() == Lazy(lambda: 1))
    assert(Box(1).to_lazy().get() == Box(1).value)



# Generated at 2022-06-24 00:03:40.334973
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(100).to_try() == Try(100, is_success=True)



# Generated at 2022-06-24 00:03:42.554969
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(1)
    result = box.bind(lambda x: x + 2)
    assert result == 3


# Generated at 2022-06-24 00:03:44.821468
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)
    assert Box('hi').to_either() == Right('hi')



# Generated at 2022-06-24 00:03:48.232040
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    x = Box(5)
    assert x.to_lazy().force() == 5
