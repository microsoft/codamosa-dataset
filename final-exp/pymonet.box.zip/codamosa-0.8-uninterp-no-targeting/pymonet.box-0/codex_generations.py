

# Generated at 2022-06-21 18:54:56.431929
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box

    :return: nothing
    :rtype: None
    """
    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:54:58.417044
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import is_right

    assert is_right(Box(1).to_either())



# Generated at 2022-06-21 18:55:03.189156
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.validation import Validation

    box = Box(10)
    either = box.to_either()

    assert isinstance(either, Right)
    assert either.value == 10

# Generated at 2022-06-21 18:55:06.111919
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(4)) == 'Box[value=4]'
    assert str(Box('a')) == 'Box[value=a]'
    assert str(Box(None)) == 'Box[value=None]'

# Generated at 2022-06-21 18:55:08.427288
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box.
    """

    assert Box('1').bind(lambda x: x + '2') == '12'



# Generated at 2022-06-21 18:55:12.023995
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(1).to_either()

    assert isinstance(box, Right)
    assert box == Right(1)


# Generated at 2022-06-21 18:55:20.261313
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Box(1).to_either() == Right(1)
    assert Box(Lazy(lambda: 1)).to_either() == Right(Lazy(lambda: 1))

    assert Box(None).to_either() == Right(None)
    assert Box(None) == Right(None)  # in fact False



# Generated at 2022-06-21 18:55:23.798636
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(True).bind(lambda x: x).value
    assert Box('hello').bind(lambda x: x).value == 'hello'

# Generated at 2022-06-21 18:55:28.197904
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('a') != Box(2)
    assert Box(2) != 'a'



# Generated at 2022-06-21 18:55:36.560602
# Unit test for method ap of class Box
def test_Box_ap():
    try:
        assert Box(lambda a: a + 1).ap(Box(1)) == Box(2)
        assert Box(lambda a: a + 1).ap(Box(2)) == Box(3)
        assert Box(lambda a: a + 1).ap(Box(3)) == Box(4)
        assert Box(lambda a: a + 1).ap(Box(4)) == Box(5)
        assert Box(lambda a: a + 1).ap(Box(5)) == Box(6)
    except AssertionError:
        print('Assertion error in method ap of class Box')
        raise AssertionError



# Generated at 2022-06-21 18:55:43.413053
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.functor import FunctorTestClass

    assert Box(5).map(lambda x: x + 3) == Box(8)
    assert Box(FunctorTestClass(10)).map(lambda x: x.value + 5) == Box(FunctorTestClass(15))



# Generated at 2022-06-21 18:55:47.460199
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box(1) != Box(2)
    assert Box('a') != Box('b')
    assert Box(1) != 1


# Unit tests for method __str__ of class Box

# Generated at 2022-06-21 18:55:49.861205
# Unit test for method ap of class Box
def test_Box_ap():
    def fun(x):
        return x + 2

    assert Box(fun).ap(Box(2)) == Box(4)



# Generated at 2022-06-21 18:55:51.464541
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x + 3) == 5



# Generated at 2022-06-21 18:55:52.894204
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(2).to_either() == Right(2)

# Generated at 2022-06-21 18:55:54.697959
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:55:57.347141
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert Box(2).to_try() == Try(2, is_success=True)

# Generated at 2022-06-21 18:55:59.595319
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation().is_success
    assert Box(1).to_validation().value == 1



# Generated at 2022-06-21 18:56:03.135858
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(lambda it: it * 2) == 2
    assert Box(2).bind(lambda it: it * 2) == 4


# Generated at 2022-06-21 18:56:04.537112
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x ** 2) == 25


# Generated at 2022-06-21 18:56:17.807764
# Unit test for method map of class Box
def test_Box_map():
    """
    Test of unit Box class

    :returns: nothing
    """
    from pymonet.monad_validation import Validation
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_either import Right
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    def _square(x: int) -> int: return x**2

    def _even(x: int) -> int: return x % 2 == 0

    def _allow(x: int) -> int: return x > 10

    assert Box(5).map(_square) == Box(_square(5))
    assert Box(5).map(_square).map(_even) == Box(_even(_square(5)))
    assert Box(5).map(_square).map(_even).map

# Generated at 2022-06-21 18:56:18.928787
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    assert Box(1).to_either().value == 1
    assert Box("some string").to_either().value == "some string"

# Generated at 2022-06-21 18:56:20.432281
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-21 18:56:26.912691
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    from pymonet.monad_try import Try

    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box(Try(1))) == 'Box[value=Try[value=1]]'
    assert str(Box(Try(10, is_success=False))) == 'Box[value=Try[value=10, is_success=False]]'


# Generated at 2022-06-21 18:56:28.599038
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(42)) == 'Box[value=42]'

# Generated at 2022-06-21 18:56:35.192080
# Unit test for method bind of class Box
def test_Box_bind():
    """Unit test for method bind of class Box"""

    from pymonet.monad_try import Try

    value = Box(1).bind(lambda x: x+2)
    success_try = Try(3, is_success=True)
    assert isinstance(value, type(success_try)), "{1} is not instance of {0}".format(type(success_try), type(value))
    assert value == success_try, "{1} is not equal to {0}".format(success_try, value)



# Generated at 2022-06-21 18:56:36.835348
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Box(3).to_maybe() == Maybe.just(3)



# Generated at 2022-06-21 18:56:41.805643
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x ** 2) == Box(1) ** 2
    assert Box(1).map(lambda x: x * 2) == Box(2)
    assert Box(None).map(lambda x: Box(1)) == Box(1)



# Generated at 2022-06-21 18:56:48.203156
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    @Lazy
    def long_process():
        return 1 + 2

    box = Box(1).to_lazy()
    assert box == Lazy(lambda: 1)

    assert box.value() == 1
    assert box.map(lambda x: x + 1).value() == 2
    assert box.ap(Lazy(lambda: 1)).value() == 2
    assert box.ap(Lazy(long_process)).value() == 2

# Generated at 2022-06-21 18:56:52.126113
# Unit test for method ap of class Box
def test_Box_ap():
    assert (Box(lambda x: x + 1) * Box(lambda x: x * 10)).value == 11
    assert (Box(lambda x: x * 2) * Box(2)).value == 4
    assert (Box(lambda x: x + 1) * Box(3)).value == 4

# Generated at 2022-06-21 18:57:02.314808
# Unit test for constructor of class Box
def test_Box():
    assert Box(3) == Box(3)
    assert Box("3") == Box("3")
    assert str(Box("3")) == "Box[value=3]"
    assert str(Box(3)) == "Box[value=3]"



# Generated at 2022-06-21 18:57:05.705264
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 18:57:12.098923
# Unit test for method ap of class Box
def test_Box_ap():
    import pytest

    func_lambda = lambda x: x + 1
    box_func = Box(func_lambda)
    box_value = Box(1)
    result = box_value.ap(box_func)
    assert isinstance(result, Box)
    assert result.value == Box(2).value

    with pytest.raises(TypeError):
        assert Box(1).ap(None)

# Generated at 2022-06-21 18:57:13.952874
# Unit test for constructor of class Box
def test_Box():
    assert Box(True) == Box(True)
    assert Box(False) != Box(True)

# Generated at 2022-06-21 18:57:25.772737
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(0)
    assert str(Box(1)) == 'Box[value=1]'
    assert repr(Box(1)) == 'Box[value=1]'
    assert Box(1).map(lambda x: x * 2) == Box(2)
    assert Box(1).bind(lambda x: Box(x * 2)) == Box(2)
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)
    assert Box(1).to_maybe() == Box(1).to_maybe()
    assert Box(1).to_either() == Box(1).to_either()
    assert Box(1).to_lazy() == Box(1).to_lazy()

# Generated at 2022-06-21 18:57:28.925270
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()



# Generated at 2022-06-21 18:57:30.988688
# Unit test for method bind of class Box
def test_Box_bind():
    def f(value): return value + 1

    assert Box(1).bind(f) == f(1)



# Generated at 2022-06-21 18:57:32.331959
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(5)) == Box(6)



# Generated at 2022-06-21 18:57:35.803250
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(42).to_either() == Right(42)
    assert Box(42).to_either().get() == 42

# Generated at 2022-06-21 18:57:38.074435
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x * 2) == 2
    assert Box(2).bind(lambda x: x * 3) == 6

# Generated at 2022-06-21 18:57:48.095918
# Unit test for method map of class Box
def test_Box_map():
    """
    Test Box.map method.
    """
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 18:57:49.413426
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(2).to_either() == 2


# Generated at 2022-06-21 18:57:50.966325
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(42).to_either().is_right()


# Generated at 2022-06-21 18:57:53.981637
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box(1) != Box('a')
    assert Box({}) != Box([])
    assert Box(Box(1)) != Box(1)


# Generated at 2022-06-21 18:58:01.775566
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test to_either conversion from Box to Either.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.either import Right

    # Test to_either with string value
    assert Box('Test').to_either() == Right('Test')

    # Test to_either with number value
    assert Box(123).to_either() == Right(123)

    # Test to_either with boolean value
    assert Box(True).to_either() == Right(True)

# Generated at 2022-06-21 18:58:10.271262
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    from pymonet.maybe import Maybe, Nothing

    assert Nothing() == Box(None).to_maybe()
    assert Maybe.just(1) == Box(1).to_maybe()
    assert Maybe.just('foo') == Box('foo').to_maybe()
    assert Maybe.just({'foo': 'bar'}) == Box({'foo': 'bar'}).to_maybe()
    assert Maybe.just(1.0) == Box(1.0).to_maybe()
    assert Maybe.just([1, 2, 3]) == Box([1, 2, 3]).to_maybe()


# Generated at 2022-06-21 18:58:12.411124
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'

# Generated at 2022-06-21 18:58:17.423726
# Unit test for method ap of class Box
def test_Box_ap():
    """Test for method ap of class Box."""
    from pymonet.maybe import Maybe

    assert (
        Box(lambda x: x * 5)
        .ap(Box(5))
        .bind(lambda x: Maybe.just(x))
        .value == 25
    )



# Generated at 2022-06-21 18:58:20.615741
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(5).to_lazy().fold() == 5


# Generated at 2022-06-21 18:58:24.024649
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1).value == 1



# Generated at 2022-06-21 18:58:41.308002
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    # GIVEN
    value = 1

    # WHEN
    actual_value = Box(value).to_validation().value

    # THEN
    assert actual_value == value

# Generated at 2022-06-21 18:58:45.225697
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_test_helper import f_maybe

    assert Box(10).to_maybe() == Maybe.just(10)
    assert Box(10).to_maybe().bind(f_maybe) == Maybe.just(11)



# Generated at 2022-06-21 18:58:47.046301
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(42).to_validation() == Validation.success(42)


# Generated at 2022-06-21 18:58:50.661008
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.just(None)
    assert Box(True).to_maybe() == Maybe.just(True)
    assert Box('str').to_maybe() == Maybe.just('str')
    assert Box('Hello World').to_maybe() == Maybe.just('Hello World')



# Generated at 2022-06-21 18:58:51.712255
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-21 18:58:52.966548
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(str) == '1'


# Generated at 2022-06-21 18:58:55.849065
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)
    assert Box(2).map(type) == Box(int)



# Generated at 2022-06-21 18:59:01.362561
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    class A:
        pass
    a = A()
    b_1 = Box(a)
    b_2 = Box(a)
    assert b_1 == b_2
    assert id(b_1) != id(b_2)
    assert b_1 is not b_2
    assert b_1 == b_1


# Generated at 2022-06-21 18:59:06.644012
# Unit test for method ap of class Box
def test_Box_ap():
    """Unit test for ap of class Box."""

    assert Box(lambda x: x+1).ap(Box(1)) == Box(2)
    assert Box(lambda x: x*2).ap(Box(3)) == Box(6)
    assert Box(lambda a, b, c: a+b+c).ap(Box(1)).ap(Box(2)).ap(Box(3)) == Box(6)



# Generated at 2022-06-21 18:59:07.824884
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(7).to_either() == Right(7)


# Generated at 2022-06-21 18:59:25.506263
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('value').value == 'value'
    assert Box(1).value == 1
    assert Box(None).value is None
    assert Box(True).value is True


# Generated at 2022-06-21 18:59:27.069791
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert (
        Box(10).to_lazy() ==
        Box(lambda: 10).map(lambda f: f())
    )

# Generated at 2022-06-21 18:59:30.219515
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    from pymonet.test_utils import assertEqual
    assertEqual(Box(3) == Box(3), True)

# Generated at 2022-06-21 18:59:35.192615
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box
    """
    def add(value):
        """
        Return square of the value

        :param value: value to square
        :return: square of the value
        :rtype: int
        """
        return value + 1
    assert Box(5).bind(add) == 6



# Generated at 2022-06-21 18:59:41.715465
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test that Box with any type of value transform into right either.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.either import Right
    from pymonet.either import Either

    for value in [None, "My test value", 42, True, 1.0, [], ["test"], ["test", 2, False], {}]:
        assert Box(value).to_either() == Right(Box(value).value)
        assert isinstance(Box(value).to_either(), Either)

# Generated at 2022-06-21 18:59:44.824665
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Simple unit test for ap method of class Box.
    Test if a value is applied by a function to the Box through ap method.
    """

# Generated at 2022-06-21 18:59:47.645046
# Unit test for constructor of class Box
def test_Box():
    import pymonet.test_utils as t

    value = 'test'
    box = Box(value)

    t.assert_is_instance(box, Box)
    t.assert_equals(box.value, value)



# Generated at 2022-06-21 18:59:50.127333
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:59:53.220346
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box(10)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 10


# Generated at 2022-06-21 18:59:55.238378
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-21 19:00:10.892397
# Unit test for constructor of class Box
def test_Box():
    assert Box(3) == Box(3)
    assert Box(3) != Box(4)

# Generated at 2022-06-21 19:00:14.964630
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.utils import identity
    import pymonet.maybe as Maybe
    assert Maybe.just(2) == Box(2).to_maybe()



# Generated at 2022-06-21 19:00:16.940526
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)

# Generated at 2022-06-21 19:00:20.680038
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation, Failure

    assert Box(1).to_validation() == Validation.success(1)
    assert Box(Failure(['failed'])).to_validation() == Validation.failure(['failed'])



# Generated at 2022-06-21 19:00:26.821440
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    # Given
    box: Box[int] = Box(10)

    # When
    actual: Maybe[int] = box.to_maybe()

    # Then
    assert actual == Maybe.just(10)


# Generated at 2022-06-21 19:00:29.101246
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)

# Generated at 2022-06-21 19:00:30.936930
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('test') == Box('test')



# Generated at 2022-06-21 19:00:38.231945
# Unit test for method ap of class Box
def test_Box_ap():
    def mm(x):
        return x + 1

    def mb(x):
        return Box(x + 1)

    assert Box(mm).ap(Box(1)) == Box(2)
    assert Box(mm).ap(Box(mb(1))) == Box(2)
    assert Box(mb).ap(Box(1)) == Box(2)
    assert Box(mb).ap(Box(mb(1))) == Box(2)

# Generated at 2022-06-21 19:00:40.502919
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box('1') == Box('1')



# Generated at 2022-06-21 19:00:51.418998
# Unit test for constructor of class Box
def test_Box():

    # Create box with int value
    box = Box(1)

    # Check that value is stored
    assert box.value == 1

    # Create box with float value
    box = Box(1.1)

    # Check that value is stored
    assert box.value == 1.1

    # Create box with string value
    box = Box('str')

    # Check that value is stored
    assert box.value == 'str'

    # Create box with list value
    box = Box([1, 2, 3])

    # Check that value is stored
    assert box.value == [1, 2, 3]

    # Create box with tuple value
    box = Box((1, 2, 3))

    # Check that value is stored
    assert box.value == (1, 2, 3)

    # Create box with dict value

# Generated at 2022-06-21 19:01:24.107233
# Unit test for constructor of class Box
def test_Box():
    assert Box(5) == Box(5)
    assert Box(5).value == 5
    assert Box(()).value == ()
    assert Box(None).value is None



# Generated at 2022-06-21 19:01:29.342071
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.functor import Functor
    from pymonet.monad_try import Try
    from pymonet.functions import identity

    def succ(x):
        return Try(x + 1, is_success=True)

    assert Box(identity).ap(Box(1)).value == 1
    assert Box(succ).ap(Box(1)).value.get() == 2
    assert Box(Functor.map).ap(Box(Functor(1))).value.value == 1

# Generated at 2022-06-21 19:01:30.705748
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(42).to_maybe() is Box(42).value


# Generated at 2022-06-21 19:01:33.451590
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)



# Generated at 2022-06-21 19:01:35.763687
# Unit test for method map of class Box
def test_Box_map():
    val = Box(3).map(lambda x: x + 2)
    assert val == Box(5)
    assert val.value == 5


# Generated at 2022-06-21 19:01:39.806279
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation, Success
    from pymonet.box import Box

    box = Box(5)
    assert box.to_validation() == Success(5)
    assert box.to_validation() is Validation.success(5)


# Generated at 2022-06-21 19:01:42.895768
# Unit test for method bind of class Box
def test_Box_bind():
    # Given
    box = Box(1)

    # When
    result = box.bind(lambda x: str(x))

    # Then
    assert result == '1'



# Generated at 2022-06-21 19:01:45.537364
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 19:01:46.670976
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:01:47.640626
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:02:56.195367
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Either
    from pymonet.monad_try import Try, Success

    assert Box(1).to_either() == Right(1)
    assert Box(1).to_either() == 1
    assert isinstance(Box(1).to_either(), Either)
    assert isinstance(Box(1).to_either(), Right)
    assert Box(1).to_either().to_try() == Success(1)
    assert isinstance(Box(1).to_either().to_try(), Try)

# Generated at 2022-06-21 19:02:58.519881
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for method bind of class Box.
    """
    assert Box(2).bind(lambda a: 4 * a) == Box(8)



# Generated at 2022-06-21 19:03:01.514767
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:03:05.226357
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * x) == Box(4)
    assert Box(3).map(lambda x: x + 5) == Box(8)
    assert Box(4).map(lambda x: 2 * x).map(lambda x: x / 2) == Box(4)



# Generated at 2022-06-21 19:03:09.560829
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('value')) == 'Box[value=value]'
    assert str(Box([])) == 'Box[value=[]]'
    assert str(Box({'key': 'value'})) == "Box[value={'key': 'value'}]"



# Generated at 2022-06-21 19:03:10.856998
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)



# Generated at 2022-06-21 19:03:17.037514
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda v: v + 1) == 2
    assert Box([1, 2, 3]).bind(lambda v: v + [1]) == [1, 2, 3, 1]
    assert Box('test').bind(lambda v: v + 'test') == 'testtest'
    assert Box({1: 2}).bind(lambda v: v[1] == 2) is True



# Generated at 2022-06-21 19:03:20.935670
# Unit test for method bind of class Box
def test_Box_bind():
    # Given
    class TestClass:
        def __str__(self):
            return 'TestClass'

    obj = TestClass()

    # When
    result = Box(obj).bind(lambda o: o.__str__())

    # Then
    assert result == 'TestClass'



# Generated at 2022-06-21 19:03:27.517758
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    assert Box(lambda a: a * 2).ap(Box(1)) == Box(2)
    assert Box(lambda a: a * 2).ap(Box(1)).to_try() == Try(2, is_success=True)
    assert Box(lambda a: a * 2).ap(Box(1)).to_validation() == Validation.success(2)

# Generated at 2022-06-21 19:03:31.751310
# Unit test for method ap of class Box
def test_Box_ap():
    def double(x):
        return x * 2

    def add(x):
        return x + 1

    box_double = Box(double)
    box_add = Box(add)

    assert box_double.map(add) == Box(add(double))
    assert box_double.ap(box_add) == Box(add(double))

# Generated at 2022-06-21 19:04:39.875602
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('test')



# Generated at 2022-06-21 19:04:41.346446
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda a: a + 1) == Box(2)



# Generated at 2022-06-21 19:04:42.933467
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 2) == Box(4)



# Generated at 2022-06-21 19:04:45.583932
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 3).ap(Box(7)) == Box(10)
    assert Box(lambda x: x * 3).ap(Box(7)) == Box(21)

# Generated at 2022-06-21 19:04:48.335711
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)).value == 2
    assert Box(lambda s: s * 2).ap(Box('aa')).value == 'aaaa'



# Generated at 2022-06-21 19:04:49.657702
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda x: x ** 2) == Box(100)


# Generated at 2022-06-21 19:04:51.282579
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    return str(Box[int](1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:04:52.898205
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box('value').to_validation() == Validation.success('value')
