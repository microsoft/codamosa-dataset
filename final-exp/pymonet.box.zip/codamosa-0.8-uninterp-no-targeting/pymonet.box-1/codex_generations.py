

# Generated at 2022-06-21 18:54:54.376220
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(1)
    assert str(box) == 'Box[value=1]'



# Generated at 2022-06-21 18:54:55.377172
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('hello')) == 'Box[value=hello]'

# Generated at 2022-06-21 18:54:57.234297
# Unit test for method map of class Box
def test_Box_map():
    box = Box('value')
    box_mapped = box.map(lambda _: 'mapped')

    assert Box('mapped') == box_mapped

# Generated at 2022-06-21 18:54:59.803842
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)

# Generated at 2022-06-21 18:55:05.622098
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import TryError

    class MyError(TryError):
        pass

    assert Box(5).to_try() == Try(5, is_success=True)
    assert Box(MyError()).to_try() == Try(MyError(), is_success=False)


# Generated at 2022-06-21 18:55:07.679787
# Unit test for method ap of class Box
def test_Box_ap():
    def multiply_two(a):
        return a * 2

    assert (Box(multiply_two).ap(Box(4))).value == 8



# Generated at 2022-06-21 18:55:16.855010
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """Unit test for method to_validation of class Box."""
    from typing import Any
    from pymonet.validation import Validation

    box_with_int: Box[int] = Box(3)
    box_with_str: Box[str] = Box('test')
    box_with_any: Box[Any] = Box('test')

    assert box_with_int.to_validation() == Validation.success(3)
    assert box_with_str.to_validation() == Validation.success('test')
    assert box_with_any.to_validation() == Validation.success('test')



# Generated at 2022-06-21 18:55:23.641429
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)
    assert Box('str').to_either() == Right('str')
    assert Box(True).to_either() == Right(True)

# Generated at 2022-06-21 18:55:25.455445
# Unit test for constructor of class Box
def test_Box():
    """
    Test constructor of Box.
    """
    assert Box('test') is not None


# Generated at 2022-06-21 18:55:30.451640
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Box(1).to_either() == Right(1)
    assert Box(Left(1)).to_either() == Left(1)
    assert Box(Right(1)).to_either() == Right(1)


# Generated at 2022-06-21 18:55:33.946137
# Unit test for method to_either of class Box
def test_Box_to_either():
    t = Box(1)
    assert t.to_either() == int, 'Should be int'



# Generated at 2022-06-21 18:55:35.451105
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-21 18:55:36.606221
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().value() == 1



# Generated at 2022-06-21 18:55:38.276535
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('str').bind(str.upper) == 'STR'

# Generated at 2022-06-21 18:55:40.133065
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-21 18:55:43.205914
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(2).to_either() == Right(2)

# Generated at 2022-06-21 18:55:44.878621
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 10) == Box(11)



# Generated at 2022-06-21 18:55:47.772183
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 18:55:51.976146
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    from pymonet.lazy import Lazy

    box = Box(10)
    expected = Lazy(lambda: 10)
    # When
    actual = box.to_lazy()
    # Then
    assert actual == expected



# Generated at 2022-06-21 18:55:53.818010
# Unit test for constructor of class Box
def test_Box():
    assert Box(10) == Box(10)
    assert Box(10) != Box(11)



# Generated at 2022-06-21 18:56:01.485067
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.test_utils import assert_eq
    from pymonet.test_utils import is_true
    from pymonet.test_utils import is_false

    assert_eq(Box(1), Box(1))
    assert_eq(Box('str'), Box('str'))

    is_false(Box(1) == Box(2))
    is_false(Box('str1') == Box('str2'))

    is_true(Box(1) == Box(1))
    is_true(Box('str') == Box('str'))



# Generated at 2022-06-21 18:56:03.436194
# Unit test for method map of class Box
def test_Box_map():
    # given

    box = Box('test')
    mapper = lambda x: '{} - mapped'.format(x)

    # when
    result = box.map(mapper)

    # then
    assert isinstance(result, Box)
    assert result.value == 'test - mapped'


# Generated at 2022-06-21 18:56:06.596153
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box({}).to_maybe().is_nothing is False
    assert Box(42).to_maybe().is_nothing is False
    assert Box([]).to_maybe().is_nothing is False



# Generated at 2022-06-21 18:56:08.777534
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-21 18:56:11.544457
# Unit test for constructor of class Box
def test_Box():
    """
    Unit test for constructor of class Box.
    """
    assert Box(1).value == 1

# Generated at 2022-06-21 18:56:13.256342
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box("1").to_validation() == Validation("1", [])


# Generated at 2022-06-21 18:56:15.886776
# Unit test for method map of class Box
def test_Box_map():
    number_box = Box(3)
    number_to_string = number_box.map(lambda number: str(number))
    assert number_to_string == Box('3')



# Generated at 2022-06-21 18:56:20.811115
# Unit test for method map of class Box
def test_Box_map():
    """
    Method map of class Box should take function (A) -> b and applied this function on current box value and
    returns new box with mapped value.
    """
    mapper = lambda value: value * 2
    box = Box(1)
    result = box.map(mapper)
    assert result == Box(mapper(box.value))


# Generated at 2022-06-21 18:56:22.996904
# Unit test for method bind of class Box
def test_Box_bind():
    # run
    result = Box(1).bind(lambda x: x + 1)
    # assert
    assert result == 2


# Generated at 2022-06-21 18:56:32.211382
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    assert Box(lambda x: x + 1).ap(Box(1)).value == 2
    assert Box(lambda x: x + 1).ap(Box(5)).value == 6
    assert Box(lambda x: 100 / x).ap(Box(5)).value == 20
    assert Box(lambda x: x / 100).ap(Box(5)).value == 0.05
    assert Box(lambda x: x / x).ap(Box(4)).value == 1
    assert Box(lambda x: x - 1).ap(Box(0)).value == -1

# Generated at 2022-06-21 18:56:36.260914
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 18:56:37.460961
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_maybe()



# Generated at 2022-06-21 18:56:39.511917
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-21 18:56:49.725517
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    # test with boolean
    assert Box(False).to_maybe() == Maybe.just(False)
    assert Box(True).to_maybe() == Maybe.just(True)

    # test with number
    assert Box(0).to_maybe() == Maybe.just(0)
    assert Box(1).to_maybe() == Maybe.just(1)

    # test with string
    assert Box('').to_maybe() == Maybe.just('')
    assert Box('abc').to_maybe() == Maybe.just('abc')

    # test with list
    assert Box([1, 2, 3]).to_maybe() == Maybe.just([1, 2, 3])
    assert Box([]).to_maybe() == Maybe.just([])

    # test with dict
    assert Box({}).to_maybe() == Maybe.just({})
   

# Generated at 2022-06-21 18:56:52.029879
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Success(1), 'Box must be transformed into Success Try monad.'


# Generated at 2022-06-21 18:56:57.676041
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    from pymonet.maybe import Maybe, Nothing

    # Test correct conversion
    assert Box(5).to_maybe() == Maybe.just(5)

    # Test incorrect conversion
    try:
        Box(None).to_maybe()
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-21 18:56:59.059526
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)



# Generated at 2022-06-21 18:57:00.372682
# Unit test for method __str__ of class Box
def test_Box___str__():
    res = str(Box(10))
    assert res == 'Box[value=10]'


# Generated at 2022-06-21 18:57:02.365355
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 18:57:05.753171
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) == Box(1)) is True
    assert (Box(2) == Box(1)) is False



# Generated at 2022-06-21 18:57:18.166213
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """
    from pymonet.monad_try import Try
    from pymonet.monad_try import SuccessTry
    from pymonet.monad_try import FailureTry

    box = Box(1)
    try_box = box.to_try()
    assert isinstance(try_box, Try)
    assert isinstance(try_box, SuccessTry)
    assert not isinstance(try_box, FailureTry)
    assert try_box.value == 1


# Generated at 2022-06-21 18:57:23.409381
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert 'Box[value=1]' == str(Box(1))
    assert 'Box[value=2.4]' == str(Box(2.4))
    assert 'Box[value=False]' == str(Box(False))
    assert 'Box[value=None]' == str(Box(None))

# Generated at 2022-06-21 18:57:26.233410
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def add(x, y):
        return x + y
    box = Box(add)

    assert box.to_lazy().eval()(1, 2) == 3



# Generated at 2022-06-21 18:57:28.881889
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(True) == Box(True)
    assert Box(True) != Box(False)
    assert Box(True) != None


# Generated at 2022-06-21 18:57:31.137563
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda x: x * 2) == 20
    assert Box(10).bind(lambda x: x / 2) == 5


# Generated at 2022-06-21 18:57:32.677195
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Box(10).to_lazy()

# Generated at 2022-06-21 18:57:35.010154
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-21 18:57:38.359740
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
        Testing method __eq__ of class Box
    """
    assert Box(10) == Box(10)
    assert Box(10) != Box(20)
    assert Box(10) != 20



# Generated at 2022-06-21 18:57:39.738183
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    _test_Box___eq__([Box(1), Box(1)])



# Generated at 2022-06-21 18:57:41.163624
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 18:57:51.256646
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().value() == 10


# Generated at 2022-06-21 18:57:55.850205
# Unit test for method ap of class Box
def test_Box_ap():
    def add_one_to_number(number: int) -> int:
        return number + 1

    box: Box[Callable[[int], int]] = Box(add_one_to_number)
    assert box.ap(Box(1)) == Box(2), 'Apply function from Box on Box value'

    lazy: Lazy[Callable[[int], int]] = Lazy(add_one_to_number)
    assert box.ap(lazy) == Box(2), 'Apply function from Lazy on Box value'



# Generated at 2022-06-21 18:57:59.021217
# Unit test for method bind of class Box
def test_Box_bind():
    x = lambda t: Box(t.value + 1)

    assert Box(1).bind(x).value == 2

# Generated at 2022-06-21 18:58:00.620996
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)
    assert Box(1).map(lambda x: x - 2) == Box(-1)



# Generated at 2022-06-21 18:58:02.704347
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map
    """
    assert Box(1).map(lambda x: x + 1) == Box(2)


# Generated at 2022-06-21 18:58:06.787884
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    boxed_maybe_just = Box('A').to_maybe()
    boxed_maybe_nothing = Box(None).to_maybe()

    assert boxed_maybe_just == Maybe.just('A')
    assert boxed_maybe_nothing == Maybe.nothing()


# Generated at 2022-06-21 18:58:09.618535
# Unit test for method ap of class Box
def test_Box_ap():
    x = Box(8)
    y = Box(lambda a: a + 1)

    z = x.ap(y)

    assert z.value == 9


# Generated at 2022-06-21 18:58:11.202115
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-21 18:58:12.816726
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None


# Generated at 2022-06-21 18:58:18.965785
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.just(None)
    assert Box(Nothing).to_maybe() == Maybe.just(Nothing)
    assert Box(Maybe.just(1)).to_maybe() == Maybe.just(Maybe.just(1))


# Generated at 2022-06-21 18:58:39.710290
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(3)) == 'Box[value=3]'
    assert str(Box(True)) == 'Box[value=True]'



# Generated at 2022-06-21 18:58:42.194659
# Unit test for constructor of class Box
def test_Box():
    assert Box(5) == Box(5)
    assert str(Box(5)) == 'Box[value=5]'
    assert Box(5).value == 5

# Generated at 2022-06-21 18:58:44.378890
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).map(add_one).value == 11
    assert Box(10).map(lambda x: x + 1).value == 11


# Generated at 2022-06-21 18:58:46.587445
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(0)
    assert not Box(0) == Box(1)
    assert Box(1) == Box(1)


# Generated at 2022-06-21 18:58:48.275204
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box('str').to_try() == Try('str', is_success=True)

# Generated at 2022-06-21 18:58:49.477181
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('1') != Box(1)



# Generated at 2022-06-21 18:58:55.260152
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box
    """
    assert Box(3).to_either() == Box(3).to_lazy().to_either()

    from pymonet.either import Right

    assert Box(3).to_either() == Right(3)

    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)

    from pymonet.maybe import Nothing

    assert Box(3).to_lazy().to_maybe() == Just(3)

    from pymonet.monad_try import Try

    assert Box(3).to_lazy().to_try() == Try(3, is_success=True)

    from pymonet.validation import Validation

    assert Box(3).to_lazy().to_validation

# Generated at 2022-06-21 18:58:56.830315
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(12).to_either() == Box(12).to_lazy().to_either()



# Generated at 2022-06-21 18:58:58.144881
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1

# Generated at 2022-06-21 18:59:02.284029
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.either import Left

    assert Box(1).bind(lambda x: Left(x)) == Left(1)
    assert Box(1).bind(lambda x: Box(x + 1)) == Box(2)



# Generated at 2022-06-21 18:59:44.642443
# Unit test for method bind of class Box
def test_Box_bind():
    # Test with number
    assert Box(1).bind(lambda value: value + 1) == 2

    # Test with string
    assert Box("Hello World").bind(lambda value: value + "!!!") == "Hello World!!!"



# Generated at 2022-06-21 18:59:50.926834
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(2).map(lambda x: [x]) == Box([2])
    assert Box(3).map(lambda x: {'name': x}) == Box({'name': 3})
    assert Box(4).map(lambda x: {x: 'name'}) == Box({4: 'name'})
    assert Box(5).map(lambda x: x ** 2 + 1) == Box(26)



# Generated at 2022-06-21 18:59:52.871876
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Right(10).equals(Box(10).to_either())


# Generated at 2022-06-21 18:59:54.906544
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-21 18:59:57.190069
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    box = Box(4)
    assert box.to_validation() == Validation.success(4)


# Generated at 2022-06-21 19:00:01.553873
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)
    assert Box(False).to_validation() == Validation.success(False)
    assert Box('a').to_validation() == Validation.success('a')


# Generated at 2022-06-21 19:00:04.797528
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Tests that when we call `bind` method and pass function
    to it, the function will be called with function.
    """
    box = Box(5)
    assert box.bind(lambda x: x + 1) == 6



# Generated at 2022-06-21 19:00:16.255859
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(0)) == 'Box[value=0]'
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(1.1)) == 'Box[value=1.1]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box((1, 2, 3))) == 'Box[value=(1, 2, 3)]'
    assert str(Box({'a': 'b'})) == "Box[value={'a': 'b'}]"
    assert str(Box('ab')) == "Box[value='ab']"


# Generated at 2022-06-21 19:00:21.192508
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box
    """
    def mapper(value):
        return value + '-modified'

    assert Box(5).bind(mapper) == '5-modified'
    assert Box('foo').bind(mapper) == 'foo-modified'
    assert Box({'a': 'b'}).bind(mapper) == {'a': 'b'}-modified



# Generated at 2022-06-21 19:00:24.637949
# Unit test for method bind of class Box
def test_Box_bind():
    value = Box(5).map(lambda x: x + 1)

    assert value == Box(6)

# Generated at 2022-06-21 19:01:56.449555
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    """
    Testing to_try method of Box class.

    :returns: True if test passes
    :rtype: bool
    """
    from pymonet.monad_try import Try

    val = 10
    assert Box(val).to_try() == Try(val, is_success=True)
    return True



# Generated at 2022-06-21 19:02:02.650454
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing
    from pymonet.lazy import Lazy

    assert Box(2).to_maybe() == Maybe.just(2)

    assert Nothing.to_box().to_maybe() == Nothing
    assert Box(Nothing).to_maybe() == Nothing

    assert Lazy(lambda: 2).to_box().to_maybe() == Maybe.just(2)


# Generated at 2022-06-21 19:02:11.210061
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_list import List

    assert Maybe.just(1).to_box().to_maybe() == Maybe.just(1)

    assert Maybe.nothing().to_box().to_maybe() == Maybe.nothing()

    assert List.unit(1).to_box().to_maybe() == Maybe.just(List.unit(1).value)

    assert List.unit(2).to_box().to_maybe() == Maybe.just(List.unit(2).value)

    assert List.unit([]).to_box().to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:02:13.290830
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('test').bind(lambda x: x + ' OK') == 'test OK'



# Generated at 2022-06-21 19:02:14.327094
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    result = Box(42).to_lazy()
    assert(result.value() == 42)
# Test function ends


# Generated at 2022-06-21 19:02:16.945831
# Unit test for method map of class Box
def test_Box_map():
    assert Box(100).map(lambda val: val + 1) == Box(101)
    assert Box(100).map(lambda val: val + 100000) == Box(100100)


# Generated at 2022-06-21 19:02:18.043408
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(42)) == 'Box[value=42]'


# Generated at 2022-06-21 19:02:19.770030
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation().is_success()
    assert Box(5).to_validation().value() == Validation.success(5).value()

# Generated at 2022-06-21 19:02:24.775250
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != 1
    assert Box(1) != Box(2)
    assert not Box(1).__eq__(1)


# Unit Test for method map of class Box

# Generated at 2022-06-21 19:02:29.670344
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Test that Box can be transformed into Lazy monad.

    :returns: no return
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()

    assert Lazy(lambda: 1) != Lazy(lambda: 2)

# Generated at 2022-06-21 19:04:23.879174
# Unit test for method ap of class Box
def test_Box_ap(): # pragma: no cover
    from pymonet.applicative import Applicative
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Success

    assert (
        Box(lambda x: x + 1)
        .ap(Box(1))
        .value == 2
    )

    assert (
        Box(lambda x, y: x + y)
        .ap(Box(1))
        .ap(Box(2))
        .value == 3
    )

    assert (
        Box(lambda x, y: x + y)
        .ap(Box(1))
        .ap(Box(2))
        .ap(Box(3))
        .value == 6
    )


# Generated at 2022-06-21 19:04:29.977944
# Unit test for method map of class Box
def test_Box_map():
    assert Box('test').map(lambda x: x + '_').value == 'test_'    # type: ignore
    assert Box(5).map(lambda x: x * 2).value == 10                # type: ignore
    assert Box(5).map(lambda x: x * 2).value == 10                # type: ignore
    assert Box(5).map(lambda x: x * 2).value == 10                # type: ignore
    assert Box(5).map(lambda x: x * 2).value == 10                # type: ignore
    assert Box(5).map(lambda x: x * 2).value == 10                # type: ignore
    assert Box(5).map(lambda x: x * 2).value == 10                # type: ignore
    assert Box(5).map(lambda x: x * 2).value == 10                # type: ignore

# Unit

# Generated at 2022-06-21 19:04:34.425448
# Unit test for method map of class Box
def test_Box_map():
    # Given
    box = Box(1)
    f = lambda x: x + 3

    # When
    result = box.map(f)

    # Then
    assert result == Box(4)


# Generated at 2022-06-21 19:04:40.780090
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box(1)
    box_2 = Box(1)
    box_3 = Box(2)
    assert(box_1 == box_2)
    assert(box_1 != box_3)
    assert(box_2 == box_1)
    assert(box_2 != box_3)
    assert(box_3 != box_1)
    assert(box_3 != box_2)



# Generated at 2022-06-21 19:04:44.107303
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test Box.to_maybe method
    """

    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Box(5).to_maybe() == Maybe.just(5)

    assert Maybe.nothing().to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:04:48.220754
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monads import Box
    from pymonet.lazy import Lazy

    lazy_box = Box(2).to_lazy()
    assert isinstance(lazy_box, Lazy)
    assert lazy_box.fold() == 2


# Generated at 2022-06-21 19:04:50.126597
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(2).to_try() == Try(2, is_success=True)

# Generated at 2022-06-21 19:04:51.190121
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box([1, 2])) == 'Box[value=[1, 2]]'

