

# Generated at 2022-06-21 18:54:54.881071
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test for method to_maybe of class Box
    """
    assert Box(42).to_maybe() == Maybe.just(42)


# Generated at 2022-06-21 18:55:00.680873
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box('test')) == 'Box[value=test]'
    assert str(Box((1, 2, 3))) == 'Box[value=(1, 2, 3)]'
    assert str(Box({'a': 1, 'b': 2})) == "Box[value={'a': 1, 'b': 2}]"



# Generated at 2022-06-21 18:55:02.371849
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(123) == Box(123)

# Generated at 2022-06-21 18:55:04.658599
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Box(3).to_lazy()

# Generated at 2022-06-21 18:55:06.366782
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 18:55:07.619854
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)

# Generated at 2022-06-21 18:55:09.553629
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 18:55:10.801275
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda value: value + 1) == 6



# Generated at 2022-06-21 18:55:16.808083
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)
    assert Box(lambda x: x + 1).ap(Box(None)) == Box(None)
    assert Box(lambda x: x + 1).ap(Box(2)) != Box(2)


# Generated at 2022-06-21 18:55:23.032878
# Unit test for method ap of class Box
def test_Box_ap():
    # given
    f = Box(lambda x: x * 2)
    x = Box(3)

    # when
    y = x.ap(f)

    # then
    assert y.value == 6

# Generated at 2022-06-21 18:55:31.715095
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.monad_lists import List

    assert Box(1).to_either() == List.from_iterable([1])



# Generated at 2022-06-21 18:55:34.745587
# Unit test for method bind of class Box
def test_Box_bind():
    # GIVEN
    b = Box(1)

    # WHEN
    result = b.bind(lambda v: v + 1)

    # THEN
    assert result == 2



# Generated at 2022-06-21 18:55:36.780115
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(42).to_validation() == Validation.success(42)

# Generated at 2022-06-21 18:55:39.256132
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:55:43.205683
# Unit test for method map of class Box
def test_Box_map():
    value = 1
    actual = Box(value).map(lambda x: x + 1)
    expected = Box(value + 1)
    assert actual == expected, 'Error in test_Box_map'


# Generated at 2022-06-21 18:55:44.545359
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('value')) == 'Box[value=value]'


# Generated at 2022-06-21 18:55:55.321290
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure

    assert Box(True).to_lazy() == Lazy(lambda: True)
    assert Box(False).to_lazy() == Lazy(lambda: False)

    assert Box(True).to_lazy().map(lambda x: not x).eval() == False
    assert Box(False).to_lazy().map(lambda x: not x).eval() == True

    assert Box(True).to_lazy().flat_map(lambda x: Lazy(lambda: not x)).eval() == False
    assert Box(False).to_lazy().flat_map(lambda x: Lazy(lambda: not x)).eval() == True

    assert Box(True).to_lazy().flat_map(lambda x: Failure(x)).eval()

# Generated at 2022-06-21 18:55:58.894467
# Unit test for method bind of class Box
def test_Box_bind():
    result = Box(2).bind(lambda x: x * 2)
    assert result == 4

    result = Box(2).bind(lambda x: Box(x * 2))
    assert result == 4



# Generated at 2022-06-21 18:56:03.608736
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    # Arrange
    value = '123'
    expected = Validation.success(value)
    box = Box(value)

    # Act
    actual = box.to_validation()

    # Assert
    assert expected == actual



# Generated at 2022-06-21 18:56:05.025870
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)

# Generated at 2022-06-21 18:56:17.460897
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1).bind(lambda x: x - 1) == 0
    assert Box(1).bind(lambda x: x * 2) == 2
    assert Box(1).bind(lambda x: x / 2) == 0.5


# Generated at 2022-06-21 18:56:18.923022
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(4)) == 'Box[value=4]'



# Generated at 2022-06-21 18:56:24.870285
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box.
    """

    # Create some boxes
    b1 = Box('box')
    b2 = Box(15)
    b3 = Box(None)

    # Transform boxes into either
    e1 = b1.to_either()
    e2 = b2.to_either()
    e3 = b3.to_either()

    # Check that left part of either is None
    assert e1.is_right()
    assert e2.is_right()
    assert e3.is_right()

    # Check that right part of either is original value
    assert e1.bind(lambda x: x.value) == 'box'
    assert e2.bind(lambda x: x.value) == 15

# Generated at 2022-06-21 18:56:27.381318
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(2).map(lambda x: x * x) == Box(4)


# Generated at 2022-06-21 18:56:30.336583
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-21 18:56:32.040984
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert isinstance(Box(1).to_try(),
                      Try)

# Generated at 2022-06-21 18:56:33.868886
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert(Maybe.just(1) == Box(1).to_maybe())



# Generated at 2022-06-21 18:56:34.947067
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-21 18:56:37.621369
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    import pymonet.validation as validation
    from pymonet.box import Box

    assert validation.Validation.success('foo') == Box('foo').to_validation()

# Generated at 2022-06-21 18:56:42.146640
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test Box.to_lazy method
    """
    from pymonet.monad import test_monad_to_lazy_with_value
    test_monad_to_lazy_with_value(lambda a: Box(a), 1)

# Generated at 2022-06-21 18:57:05.804461
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(5).to_either() == Right(5)
    assert Box(5).to_either() != Right(6)
    assert Box(5).to_either() != Left(5)
    assert Box(5).to_either() != Left(6)


# Generated at 2022-06-21 18:57:11.216625
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()
    assert Validation.success('a') == Box('a').to_validation()
    assert Validation.success([1, 2, 3]) == Box([1, 2, 3]).to_validation()



# Generated at 2022-06-21 18:57:12.034835
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == "Box[value=1]"


# Generated at 2022-06-21 18:57:13.910487
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(2)) == 'Box[value=2]'


# Generated at 2022-06-21 18:57:25.717602
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.monad_maybe import Maybe

    # Testing is identity map
    assert Box(1).map(lambda x: x) == Box(1)
    # Testing is Box map applied on result of Maybe map and Maybe bind
    mapper = Maybe(2).map(lambda x: x * 3).bind(lambda x: Maybe(x + 2))
    assert Box(2).map(lambda x: x * 3).bind(lambda x: Box(x + 2)) == Box(mapper.value)
    # Testing is Box map applied on result of Maybe ap
    mapper = Maybe(lambda x: x * 3).ap(Maybe(2))
    assert Box(lambda x: x * 3).ap(Box(2)) == Box(mapper.value)
    # Testing is Box map applied on result of Maybe ap for negative value
    mapper = Maybe

# Generated at 2022-06-21 18:57:28.501743
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either, Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 18:57:30.121733
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(7).to_either() == Right(7)



# Generated at 2022-06-21 18:57:36.013435
# Unit test for constructor of class Box
def test_Box():
    """
    Test for constructor of class Box
    """
    from pymonet.monad_try import Try

    assert Box('a') == Box('a')
    assert Box('a') != Box('b')

    assert Box(1).value == 1
    assert Box(Try(1)).value == Try(1)



# Generated at 2022-06-21 18:57:47.237479
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe, nothing
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try, Failure
    from pymonet.validation import Validation, Success

    assert Box(lambda value: value + 10).ap(Box(2)) == Box(12)
    assert Box(lambda value: value + 10).ap(nothing()) == nothing()
    assert Box(lambda value: value + 10).ap(Left('error')) == Left('error')
    assert Box(lambda value: value + 10).ap(Right(2)) == Right(12)
    assert Box(lambda value: value + 10).ap(Lazy(lambda: 2)) == Box(12)

# Generated at 2022-06-21 18:57:49.326792
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-21 18:58:28.792242
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Nothing

    assert Box(1).to_maybe() == Box(1)
    assert Box(1).to_maybe() == Just(1)
    assert Box(1).to_maybe() != Nothing()


# Generated at 2022-06-21 18:58:30.990582
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1


# Generated at 2022-06-21 18:58:33.127259
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-21 18:58:36.676569
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 18:58:39.748565
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe().equals(Box(1).to_maybe())
    assert not Box(1).to_maybe().equals(Box(2).to_maybe())

# Generated at 2022-06-21 18:58:40.529187
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-21 18:58:42.713207
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-21 18:58:44.849005
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(10)

    assert isinstance(box.to_maybe(), Maybe) and box.value == 10

# Generated at 2022-06-21 18:58:47.318014
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    string_box = Box('ab')

    assert string_box.to_validation() == Validation.success(string_box.value)


# Generated at 2022-06-21 18:58:50.362490
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left
    box = Box('a')
    assert box.to_either() == Right('a')
    box = Box(1)
    assert box.to_either() == Right(1)
    box = Box({'a': 1})
    assert box.to_either() == Right({'a': 1})


# Generated at 2022-06-21 19:00:15.832675
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(42).to_try() == Try(42, is_success=True)


# Generated at 2022-06-21 19:00:17.756307
# Unit test for method map of class Box
def test_Box_map():
    assert Box('Hello').map(lambda x: x.upper()) == Box('HELLO')


# Generated at 2022-06-21 19:00:19.011753
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 19:00:21.608940
# Unit test for constructor of class Box
def test_Box():
    """
    Test for constructor of class Box.
    """
    assert Box(2).value == 2, 'Box should have 2 as value'


# Generated at 2022-06-21 19:00:26.245433
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box('string') == Box('string')
    assert Box(None) == Box(None)
    assert Box(3) != Box('string')



# Generated at 2022-06-21 19:00:27.647214
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 19:00:29.485064
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box('value')

    assert box.__str__() == 'Box[value=value]'



# Generated at 2022-06-21 19:00:32.140510
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 19:00:36.623033
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box('Input')
    expected = Validation.success('Input')
    actual = box.to_validation()

    assert expected == actual



# Generated at 2022-06-21 19:00:38.399596
# Unit test for method bind of class Box
def test_Box_bind():
    x = Box(1)
    y = x.bind(lambda a: a + 1)
    assert y == 2


# Generated at 2022-06-21 19:02:16.505264
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(42).to_maybe() == Box(42).to_maybe()
    assert Box(42).to_maybe() != Box(1).to_maybe()



# Generated at 2022-06-21 19:02:18.969621
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    assert Box(5).to_maybe() == Box(5).value
    assert Box('test').to_maybe() == Box('test').value



# Generated at 2022-06-21 19:02:19.879678
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1


# Generated at 2022-06-21 19:02:25.351545
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    # GIVEN
    box = Box(2)

    # WHEN
    mapper = lambda x: x * x
    result = box.map(mapper)

    # THEN
    assert result == Box(4)


# Generated at 2022-06-21 19:02:27.535047
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box = Box("Text")
    assert box.value == "Text"



# Generated at 2022-06-21 19:02:31.822603
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """

    from pymonet.validation import Validation

    def test_method():
        """
        Internal function for unit test
        """

        box = Box(1)
        assert box.to_validation() == Validation.success(1)

    test_method()


# Generated at 2022-06-21 19:02:34.132825
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy()
    assert Box(1).to_lazy() != Box(2).to_lazy()



# Generated at 2022-06-21 19:02:44.321862
# Unit test for method ap of class Box
def test_Box_ap():
    # 1 + 2
    value = Box(1).ap(Box(lambda x: x + 1)).value
    assert value == 2, "Box.ap not working"

    # 1 + 2 + 3 + 4
    value = Box(1).ap(Box(lambda x: x + 1)).ap(Box(lambda x: x + 2)).ap(Box(lambda x: x + 3)).value
    assert value == 10, "Box.ap not working"

    # 1 + 2 + 3 + 4 + 5
    value = Box(1).ap(Box(lambda x: x + 1)).ap(Box(lambda x: x + 2)).ap(Box(lambda x: x + 3)).ap(Box(lambda x: x + 4)).value
    assert value == 15, "Box.ap not working"


# Generated at 2022-06-21 19:02:45.989606
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(123)) == "Box[value=123]"



# Generated at 2022-06-21 19:02:47.635101
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either().is_right
    assert Box(1).to_either().value == 1


# Generated at 2022-06-21 19:04:23.841276
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.validation import Validation
    class Just(Box):
        def __init__(self, value):
            self.value = value
    def add_one(x):
        return x + 1

    assert (Just(add_one).ap(Just(5)) == Just(6))
    assert (Just(add_one).ap(Just(5)).value == 6)

    assert (Just(add_one).ap(Validation.success(5)) == Validation.success(6))
    assert (Just(add_one).ap(Validation.success(5)).success() == 6)



# Generated at 2022-06-21 19:04:24.752423
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(10).to_maybe() == Box(10).value



# Generated at 2022-06-21 19:04:30.555052
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.exceptions import WrappedException
    from pymonet.monad_maybe import Nothing
    from pymonet.monad_try import Try

    def addition(x: int, y: int) -> int:
        return x + y

    value1 = Box(42)
    value2 = Box(7)
    value3 = Box(0)
    value4 = Box(Nothing)

    assert(Try.of(lambda: addition(value1.value, value2.value)) == value1.to_try().bind(lambda x: value2.to_try().map(lambda y: addition(x, y))))

# Generated at 2022-06-21 19:04:31.887614
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(333) == Box(333)


# Generated at 2022-06-21 19:04:43.399244
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(3)) == Box(6)
    assert Box(lambda x, y: x + y).ap(Box(3)).ap(Box(4)) == Box(7)
    assert Box(lambda x, y: x + y).ap(Box(3)).ap(Box(4)).ap(Box(5)) == Box(12)
    assert Box(lambda x, y, z: x + y + z).ap(Box(3)).ap(Box(4)).ap(Box(5)) == Box(12)

    assert Box(2).map(lambda x: x * 2) == Box(4)
    assert Box(2).map(lambda x: x * 2).map(lambda x: x * 2) == Box(8)


# Generated at 2022-06-21 19:04:44.403156
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(100).bind(lambda x: x * 2) == 200


# Generated at 2022-06-21 19:04:48.393565
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # GIVEN
    test_x = Box(2)
    test_y = Box(2)
    # WHEN
    test_z = test_x.__eq__(test_y)
    # THEN
    assert test_z is True


# Generated at 2022-06-21 19:04:51.443379
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(lambda x: x + 2).bind(lambda x: x(1)) == 3
    assert Box('Lorem').bind(lambda x: x.upper()) == 'LOREM'
    assert Box(1).bind(lambda x: x) == 1

