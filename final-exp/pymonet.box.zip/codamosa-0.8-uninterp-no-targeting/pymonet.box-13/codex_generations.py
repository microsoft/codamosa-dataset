

# Generated at 2022-06-21 18:54:53.695506
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().value() == 2


# Generated at 2022-06-21 18:54:54.922373
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'

# Generated at 2022-06-21 18:54:56.638536
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Test that Boxes with same values are equal
    """

    box_a = Box(-1)
    box_b = Box(-1)

    assert box_a == box_b


# Generated at 2022-06-21 18:54:59.493767
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 18:55:04.251603
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.tests.utils import get_string

    box: Box[str] = Box(get_string())

    assert box.to_lazy() == Lazy(get_string)



# Generated at 2022-06-21 18:55:07.457023
# Unit test for method map of class Box
def test_Box_map():
    """
    Test for method map of class Box

    :raises AssertionError: if test does not passed
    """
    def square(value):
        return value * value

    assert Box(3).map(square).value == 9

# Generated at 2022-06-21 18:55:12.129738
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    import hypothesis.strategies as st
    from hypothesis import given

    @given(st.integers(), st.integers())
    def test(first, second):
        assert Box(first + second).map(lambda x: x * 2).value == (first + second) * 2

    test()


# Generated at 2022-06-21 18:55:18.169866
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    value = 3.0
    box_value = Box(value)
    assert box_value.to_either() == Right(value)

test_Box_to_either()



# Generated at 2022-06-21 18:55:20.534405
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(2)) == 'Box[value=2]'

# Generated at 2022-06-21 18:55:26.694526
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(Try(1, is_success=True)).to_lazy() == Lazy(lambda: Try(1, is_success=True))



# Generated at 2022-06-21 18:55:33.000541
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(200)) == 'Box[value=200]'
    assert str(Box(200.1)) == 'Box[value=200.1]'
    assert str(Box('str')) == 'Box[value=str]'
    assert str(Box([])) == 'Box[value=[]]'



# Generated at 2022-06-21 18:55:34.830934
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-21 18:55:36.374265
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(123) == Box(123)
    assert Box('abc') == Box('abc')
    assert Box(()) == Box(())



# Generated at 2022-06-21 18:55:40.239467
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe

    box = Box(lambda value: value * 2)
    number = Box(2)
    assert box.ap(number) == Box(4)

    maybe = Maybe.just(2)
    assert maybe.ap(box) == Box(4)

    maybe = Maybe.just(lambda value: value * 2)
    assert box.ap(maybe) == Box(4)



# Generated at 2022-06-21 18:55:45.442647
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    test_data = [
        {
            'input': 0,
            'expected': lambda: 0,
        },
        {
            'input': None,
            'expected': lambda: None
        }
    ]

    for test in test_data:
        assert Box(test['input']).to_lazy().get() == test['expected']()

# Generated at 2022-06-21 18:55:46.341534
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box("Some").to_try() == True

# Generated at 2022-06-21 18:55:57.084840
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.identity import Identity

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box('b').to_maybe() == Maybe.just('b')
    assert Box(1.2).to_maybe() == Maybe.just(1.2)
    assert Box(True).to_maybe() == Maybe.just(True)
    assert Box([]).to_maybe() == Maybe.just([])
    assert Box({}).to_maybe() == Maybe.just({})
    assert Box(()).to_maybe() == Maybe.just(())
    assert Box(Identity(3)).to_maybe() == Maybe.just(Identity(3))


# Generated at 2022-06-21 18:55:59.032683
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    box = Box("abc")
    assert isinstance(box.map(lambda x: 1), Box)
    assert box.map(lambda x: 1) == Box(1)


# Generated at 2022-06-21 18:56:00.890593
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).to_maybe().to_either()


# Generated at 2022-06-21 18:56:03.185337
# Unit test for method map of class Box
def test_Box_map():
    assert Box(5).map(lambda x: x + 2) == Box(7)



# Generated at 2022-06-21 18:56:06.491854
# Unit test for method __str__ of class Box
def test_Box___str__():

    box: Box[int] = Box(1)
    assert str(box) == 'Box[value=1]'

# Generated at 2022-06-21 18:56:13.526606
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    import pytest
    from pymonet.lazy import Lazy

    def should_return_object_same_as_Box_value():
        box = Box(100)
        assert box.to_lazy() == Lazy(lambda: 100)

    test_to_lazy = [should_return_object_same_as_Box_value]

    for test in test_to_lazy:
        test()



# Generated at 2022-06-21 18:56:15.809095
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(5)

    assert box.to_validation() == Validation.success(5)



# Generated at 2022-06-21 18:56:21.527562
# Unit test for constructor of class Box
def test_Box():
    x = Box(10)
    assert x.value == Box(10).value and Box(10).value == 10
    assert x.to_maybe().value == Box(10).value
    assert x.to_lazy().value() == Box(10).value
    assert x.to_try().value == Box(10).value
    assert x.to_validation().value == Box(10).value
    assert x.to_either().value == Box(10).value



# Generated at 2022-06-21 18:56:26.761373
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """
    box = Box(2)
    try_val = box.to_try()
    assert isinstance(try_val, Try)
    assert try_val.value == 2
    assert try_val.is_success == True


# Generated at 2022-06-21 18:56:31.868967
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_test import maybe_test_functions

    Maybe.set_test_functions(maybe_test_functions)

    box = Box('Something')

    assert box.to_maybe().get_value() == 'Something'  # type: ignore



# Generated at 2022-06-21 18:56:34.774973
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(123)) == 'Box[value=123]'
    assert str(Box('qwerty')) == 'Box[value=qwerty]'


# Generated at 2022-06-21 18:56:39.621002
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda x: x ** 2) == 9
    assert Box("Hello, ").bind(
        lambda x: Box("World!").bind(lambda y: x + y)
    ) == Box(Box("Hello, ").value + Box("World!").value)



# Generated at 2022-06-21 18:56:41.601225
# Unit test for constructor of class Box
def test_Box():
    assert isinstance(Box(None), Box)
    assert Box(None) == Box(None)


# Generated at 2022-06-21 18:56:46.253859
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Check correctness of Box.to_try() method
    """
    assert Box(2).to_try() == Try(2).to_box()
    assert Box('abc').to_try() == Try('abc').to_box()
    assert Box(10).to_try() == Try(10).to_box()


# Generated at 2022-06-21 18:56:58.135113
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.validation import Validation

    assert Box(me).to_maybe() == Maybe.just(me)
    assert Box(me).to_maybe() == Maybe.from_value(me)
    assert Box(me).to_either().to_maybe() == Maybe.just(me)
    assert Box(me).to_validation().to_maybe() == Maybe.just(me)
    assert Box(me).to_try().to_maybe() == Maybe.just(me)

    assert Box(None) != Maybe.nothing()
    assert Box(None).to_maybe() != Maybe.nothing()
    assert Box(None).to_either().to_maybe() != Maybe.nothing()
    assert Box(None).to_validation().to_maybe

# Generated at 2022-06-21 18:57:09.827145
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    from pymonet.utils import assert_equals

    # Check box with string
    assert_equals('Box[value=string]', str(Box('string')))

    # Check box with integer
    assert_equals('Box[value=1]', str(Box(1)))

    # Check box with list
    assert_equals('Box[value=[1, 2, 3]]', str(Box([1, 2, 3])))

    # Check box with dictionary
    assert_equals('Box[value={1: 2, 3: 4}]', str(Box({1: 2, 3: 4})))

    # Check box with function
    assert_equals('Box[value=<function Box.<lambda>>]', str(Box(lambda x: x)))

# Generated at 2022-06-21 18:57:12.690928
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(5).to_either() == Box(5).to_lazy().to_maybe().to_try().to_validation().to_either()

# Generated at 2022-06-21 18:57:18.110861
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for Box.to_lazy method.
    """
    from pymonet.lazy import Lazy
    box = Box(0)

    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force() == 0
    assert lazy.force() == 0
    assert lazy.force() == 0

# Generated at 2022-06-21 18:57:22.441045
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    assert isinstance(Box(1).ap(Box(lambda x: x + 1)), Box)
    assert Box(1).ap(Box(lambda x: x + 1)).value == 2

# Generated at 2022-06-21 18:57:25.716817
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    :return: None
    :rtype: None
    """
    data = Box(1)
    assert data.to_try().value == 1
    assert data.to_try().is_success

# Generated at 2022-06-21 18:57:28.120591
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * x) == Box(4)



# Generated at 2022-06-21 18:57:29.810191
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(3)) == Box(6)


# Generated at 2022-06-21 18:57:32.451158
# Unit test for constructor of class Box
def test_Box():
    assert Box(10).value == 10
    assert Box('test').value == 'test'

# Unit tests for method map of class Box

# Generated at 2022-06-21 18:57:37.955506
# Unit test for method ap of class Box
def test_Box_ap():
    # setup
    box_fn = Box(lambda x: x * 2)
    box_val = Box(1)

    # action
    actual_box = box_fn.ap(box_val)

    # assert
    assert isinstance(actual_box, Box)
    assert actual_box.value == 2


# Generated at 2022-06-21 18:57:48.228240
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test correct transformation of Box into Maybe monad.
    """

    from pymonet.maybe import Maybe

    test_value = 25
    test_box = Box(test_value)
    assert Maybe.just(test_value) == test_box.to_maybe()


# Generated at 2022-06-21 18:57:50.110129
# Unit test for method bind of class Box
def test_Box_bind():
    f = lambda x: x ** 2
    assert Box(2).bind(f) == f(2)



# Generated at 2022-06-21 18:57:52.054581
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert (Box(1).to_maybe() == Maybe.just(1))



# Generated at 2022-06-21 18:57:54.037946
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box("") == Box("")
    assert Box(Box("")) == Box("")
    assert Box(1) != Box("")

# Generated at 2022-06-21 18:57:55.633806
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert isinstance(Box(1).to_lazy(), Lazy)



# Generated at 2022-06-21 18:57:57.926725
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)


# Generated at 2022-06-21 18:58:00.405457
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert(Box(5).to_lazy()._fold()() == 5)



# Generated at 2022-06-21 18:58:02.124537
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box = Box(True)
    assert box.to_validation() == Validation.success(True)

# Generated at 2022-06-21 18:58:05.810811
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box.
    """

    from pymonet.either import Right, Either

    assert isinstance(Box('text').to_either(), Either)
    assert Box('text').to_either() == Right('text')


# Generated at 2022-06-21 18:58:10.774133
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for method bind of class Box.
    """
    from pymonet.functor import Functor

    functor = Functor(Box(5))

    result1 = functor.bind(lambda value: Box(value + 2))
    result2 = functor.map(lambda value: value + 2)

    assert result1.value == 7
    assert result2.value == 7

# Generated at 2022-06-21 18:58:22.379739
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fold() == 1


# Generated at 2022-06-21 18:58:24.468496
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)



# Generated at 2022-06-21 18:58:26.802757
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation


# Generated at 2022-06-21 18:58:30.927264
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box("monad")) == 'Box[value=monad]'



# Generated at 2022-06-21 18:58:33.899430
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Try.success(1) == Box(1).to_try()
    assert Try.failure(1) == Box(1).to_try()


# Generated at 2022-06-21 18:58:40.943465
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test that to_try method doesn't throw any exceptions and
    create results of successful try monad.

    :return: None
    :rtype: None
    """
    from pymonet.monad_try import Try

    result = Box(1).to_try()

    assert isinstance(result, Try)
    assert result.is_success == True
    assert result.value == 1



# Generated at 2022-06-21 18:58:43.672332
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just

    assert Box(0).to_maybe().is_just()
    assert Box(0).to_maybe() == Just(0)



# Generated at 2022-06-21 18:58:44.734554
# Unit test for constructor of class Box
def test_Box():
    assert isinstance(Box(1), Box)



# Generated at 2022-06-21 18:58:46.216962
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1
    assert Box(1) == Box(1)

# Generated at 2022-06-21 18:58:47.659521
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box('test').to_either() == Right('test')



# Generated at 2022-06-21 18:59:02.883001
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box('Hello, World!').to_either() == Right('Hello, World!')
    assert Box(True).to_either() == Right(True)

# Generated at 2022-06-21 18:59:04.602344
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:59:09.456652
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    _ = Lazy(lambda: 10).map(lambda x: x + 10)
    assert _.fold() == 20
    _ = _.map(lambda x: x + 10)
    assert _.fold() == 30
    _ = _.map(lambda x: x + 10)
    assert _.fold() == 40
    _ = _.map(lambda x: x + 10)
    assert _.fold() == 50

# Generated at 2022-06-21 18:59:11.095337
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)



# Generated at 2022-06-21 18:59:13.129395
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box('data').to_validation() == ['data']

# Generated at 2022-06-21 18:59:19.504067
# Unit test for constructor of class Box
def test_Box():
    assert Box(0) == Box(0)
    assert Box(0) != Box(1)
    assert Box([]) == Box([])
    assert Box({}) == Box({})
    assert (Box({}).value == {})
    assert (Box([42, 43]).value == [42, 43])
    assert (Box({"key": "value"}).value == {"key": "value"})



# Generated at 2022-06-21 18:59:24.145860
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    """
    Unit test for method __eq__ of class Box.
    """
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box([1, 2]) == Box([1, 2])
    assert Box(1) != 1



# Generated at 2022-06-21 18:59:32.398916
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test for Box.to_maybe method
    """
    assert Box(True).to_maybe() == Maybe.just(True)
    assert Box(False).to_maybe() == Maybe.just(False)
    assert Box(123).to_maybe() == Maybe.just(123)
    assert Box("abc").to_maybe() == Maybe.just("abc")
    assert Box([1, 2, 3]).to_maybe() == Maybe.just([1, 2, 3])
    assert Box({"a": 1, "b": 2}).to_maybe() == Maybe.just({"a": 1, "b": 2})


# Generated at 2022-06-21 18:59:37.320225
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method 'to_lazy' of class 'Box'.
    """
    from pymonet.lazy import Lazy

    box = Box(1)
    assert box.to_lazy() == Lazy(lambda: 1), ('Box.to_lazy() should return Lazy ' +
                                              'monad with function returning previous value')

# Generated at 2022-06-21 18:59:38.208713
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert False == Box("test")

# Generated at 2022-06-21 19:00:05.207253
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-21 19:00:08.932700
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(1)
    assert box.bind(lambda x: x + 1) == 2
    assert box.bind(lambda x: x + 1) == 2
    assert box.map(lambda x: x + 1) == Box(2)

# Generated at 2022-06-21 19:00:09.997171
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(7) == Box(7)



# Generated at 2022-06-21 19:00:11.392212
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().value() == 10

# Generated at 2022-06-21 19:00:13.518115
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1

# Generated at 2022-06-21 19:00:15.996405
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Tests for ap method of Box monad
    """
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)



# Generated at 2022-06-21 19:00:19.111975
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(42)
    expected_result = Lazy(lambda: 42)

    assert box.to_lazy() == expected_result

# Generated at 2022-06-21 19:00:24.575986
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_maybe().map(lambda x: x)
    assert Box(1).to_maybe() == Box(1).to_maybe().bind(lambda x: x)


# Generated at 2022-06-21 19:00:27.791161
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet import Box, Try

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box('a').to_try() == Try('a', is_success=True)

# Generated at 2022-06-21 19:00:29.567822
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 19:01:24.562281
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, fold_lazy

    # When
    lazy = Box(10).to_lazy()

    # Then
    assert lazy == Lazy(lambda: 10)
    assert fold_lazy(lazy) == 10



# Generated at 2022-06-21 19:01:27.790179
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.algebra import Algebra, functor
    from pymonet.maybe import Maybe

    algebra = Algebra[Box]
    box = Box(1)

    assert algebra.to_maybe.value(box) == algebra.maybe.just(1)



# Generated at 2022-06-21 19:01:29.341458
# Unit test for method bind of class Box
def test_Box_bind():
    def f(v):
        return v + ' world'

    assert Box('hello').bind(f) == 'hello world'



# Generated at 2022-06-21 19:01:32.839359
# Unit test for method map of class Box
def test_Box_map():
    # Given
    value = Box('test')
    # When
    result = value.map(lambda x: x + '_value')
    # Then
    assert isinstance(result, Box)
    assert result == Box('test_value')



# Generated at 2022-06-21 19:01:34.651406
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert str(Box(2)) == 'Box[value=2]'

# Generated at 2022-06-21 19:01:37.153200
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    assert isinstance(Box(0).to_either(), Either)

# Generated at 2022-06-21 19:01:39.096311
# Unit test for constructor of class Box
def test_Box():
    box = Box(3)
    assert box.value == 3
    assert str(box) == 'Box[value=3]'



# Generated at 2022-06-21 19:01:43.993803
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box
    """
    def add_one(a: int) -> int:
        return a + 1

    assert Box(1).map(add_one) == Box(2)
    assert Box('a').map(lambda x: x * 2) == Box('aa')



# Generated at 2022-06-21 19:01:45.158973
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box('text').to_maybe() == Maybe.just('text')



# Generated at 2022-06-21 19:01:47.238151
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    value = 'test_value'
    box = Box(value)
    lazy = box.to_lazy()

    assert lazy.value() == value



# Generated at 2022-06-21 19:03:47.479524
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    assert Box('abc').to_maybe() == Maybe.just('abc')
    assert Maybe.nothing().to_box() == Maybe.just(Box.empty()).to_box().value

# Generated at 2022-06-21 19:03:50.935749
# Unit test for method map of class Box
def test_Box_map():
    # GIVEN
    box = Box(6)

    # WHEN
    starts_with_6 = box.map(lambda x: str(x)[0] == '6')

    # THEN
    assert starts_with_6 == Box(True)

# Generated at 2022-06-21 19:03:53.891527
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box.
    """
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)

# Generated at 2022-06-21 19:03:58.090566
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(2)
    box3 = Box(1)
    assert box1 == box3
    assert box1 != box2


# Generated at 2022-06-21 19:04:01.859503
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(2)
    b = Box(2)
    assert a == b, "Two different boxes with equals value should be equal"

    c = Box("foo")
    assert c != b, "Two boxes with different values should not be equal"
    assert c != 2, "Box should not be equal to other type"



# Generated at 2022-06-21 19:04:04.658005
# Unit test for method ap of class Box
def test_Box_ap():
    a = Box(lambda x: x+1)
    b = Box(3)
    assert b.ap(a).value == 4

# Generated at 2022-06-21 19:04:06.518441
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Validation.success(1) == Box(1).to_validation()



# Generated at 2022-06-21 19:04:09.448127
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box('value').to_try() == Try('value', is_success=True)



# Generated at 2022-06-21 19:04:12.518146
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x * 2) == 2
    assert Box(3).bind(lambda x: x * 2) == 6
    assert Box(5).bind(lambda x: x * 2) == 10
    assert Box(7).bind(lambda x: x * 2) == 14

# Generated at 2022-06-21 19:04:14.482258
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)

