

# Generated at 2022-06-21 18:54:55.205713
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-21 18:54:57.413651
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    assert Box(5).to_lazy() == Lazy(lambda: 5)

    # Unit test for method to_try of class Box

# Generated at 2022-06-21 18:55:00.033252
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 2



# Generated at 2022-06-21 18:55:02.169439
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda x: x * 2) == 20


# Generated at 2022-06-21 18:55:04.475848
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    box = Box(4)
    assert box.to_either() == Right(4)

# Generated at 2022-06-21 18:55:10.071736
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    add_1 = lambda x: x + 1
    add_2 = lambda x: x + 2
    assert Box(add_1).ap(Box(1)).value == 2
    assert Box(add_1).ap(Try(1, is_success=True)).value == 2
    assert Box(add_1).ap(Validation.success(1)).value == 2


# Generated at 2022-06-21 18:55:18.332075
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box_1 : Box[int] = Box(12)
    box_2 : Box[str] = Box('pymonet')
    box_3 : Box[dict] = Box({'key1': 'value1', 'key2': 'value2'})

    assert box_1.value == 12
    assert box_2.value == 'pymonet'
    assert box_3.value == {'key1': 'value1', 'key2': 'value2'}



# Generated at 2022-06-21 18:55:21.005037
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert Box(2).__str__() == "Box[value=2]"
    assert str(Box(2)) == "Box[value=2]"


# Generated at 2022-06-21 18:55:24.951020
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(0).bind(lambda x: x + 5) == 5


# Generated at 2022-06-21 18:55:28.133121
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try.unit(1).to_box() == Box(1)


# Test for method to_maybe of class Box

# Generated at 2022-06-21 18:55:31.815148
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box('hello').to_try().failure is None and Box('hello').to_try().success == 'hello'

# Generated at 2022-06-21 18:55:34.957720
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(7).to_maybe() == Just(7)
    assert Box('7').to_maybe() == Just('7')
    assert Box(7).to_maybe().bind(lambda x: Box(x * 2)).to_maybe() == Just(14)



# Generated at 2022-06-21 18:55:36.789335
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('test')) == 'Box[value=test]'
    assert str(Box(12)) == 'Box[value=12]'


# Generated at 2022-06-21 18:55:40.089485
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    result = Box(Maybe.just(1)).to_either()
    assert result == Right(Maybe.just(1))



# Generated at 2022-06-21 18:55:45.040777
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box.
    """
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box("hello")) == 'Box[value=hello]'
    assert str(Box(None)) == 'Box[value=None]'



# Generated at 2022-06-21 18:55:46.743898
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 18:55:49.500540
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:55:54.746539
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda a: a + 10) == Box(20), 'Box(10).map(lambda a: a + 10) == Box(20)'

# Generated at 2022-06-21 18:55:57.803842
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.functions import id

    maybe = Box(1).to_lazy()
    assert maybe.to_maybe().bind(id).value == maybe.value()

# Generated at 2022-06-21 18:55:59.248842
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy().value == 10


# Generated at 2022-06-21 18:56:03.276275
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)



# Generated at 2022-06-21 18:56:06.865833
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1), \
        'Box(1) should be equal Validation.success(1)'




# Generated at 2022-06-21 18:56:10.547115
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Box(lambda x: x).ap(Box(1)) == Box(1)

# Generated at 2022-06-21 18:56:12.557631
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('string').bind(lambda v: v.upper()) == 'STRING'



# Generated at 2022-06-21 18:56:15.279970
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 'Box(1)'



# Generated at 2022-06-21 18:56:17.645965
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    def add(a, b):
        return a + b

    assert Box(add).ap(Box(1)).ap(Box(2)).value == 3


# Generated at 2022-06-21 18:56:20.662175
# Unit test for method to_either of class Box
def test_Box_to_either():
    class TestClass:
        pass

    value = TestClass()
    box = Box(value)

    result = box.to_either()

    assert result.is_right
    assert result.value == value



# Generated at 2022-06-21 18:56:27.628338
# Unit test for method to_either of class Box
def test_Box_to_either():
    import pytest
    from pymonet.either import Right

    assert Box(100) == Box(100)
    assert Box('test str') == Box('test str')

    assert Box(100).to_either() == Right(100)
    assert Box('test str').to_either() == Right('test str')

    with pytest.raises(AttributeError):
        Box(100).to_either(None)



# Generated at 2022-06-21 18:56:30.957532
# Unit test for method ap of class Box
def test_Box_ap():
    # given
    func = Box(lambda x: x + 10)
    number = Box(10)

    # when
    result = func.ap(number)

    # then
    assert result == Box(20)

# Generated at 2022-06-21 18:56:33.650825
# Unit test for constructor of class Box
def test_Box():
    box = Box(10)

    assert isinstance(box, Box) == True
    assert box.value == 10
    assert box.map(lambda x: x * x).value == 100


# Generated at 2022-06-21 18:56:41.709424
# Unit test for method ap of class Box
def test_Box_ap():
    """
    method ap of Box
    """

    def add(a, b):
        return a + b

    box = Box(add)

    result = box.ap(Box(1)).ap(Box(2))

    assert result == Box(3)


# Generated at 2022-06-21 18:56:44.629148
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x * 2) == 4

    assert Box("a").bind(lambda x: x + "b") == "ab"



# Generated at 2022-06-21 18:56:46.594018
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:56:47.869549
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(5)) == Box(10)

# Generated at 2022-06-21 18:56:49.352228
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-21 18:56:51.481014
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)

# Generated at 2022-06-21 18:56:54.529071
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)
    assert Box(None).to_either() == Right(None)
    assert Box("").to_either() == Right("")


# Generated at 2022-06-21 18:57:00.784683
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert Box(2).bind(lambda x: x * 20) == 40

    assert Functor[Box].map(Box(2), lambda x: x * 20) == Box(40)
    assert Functor[Box].fmap(Box(2), lambda x: x * 20) == Box(40)

    assert Monad[Box].bind(Box(2), lambda x: Box(x * 20)) == Box(40)
    assert Monad[Box].mbind(Box(2), lambda x: Box(x * 20)) == Box(40)

# Generated at 2022-06-21 18:57:04.082497
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: x + 1) == 6
    assert Box(5).bind(lambda x: x + 1) != 5


# Generated at 2022-06-21 18:57:06.827945
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 18:57:21.764055
# Unit test for method bind of class Box
def test_Box_bind():
    def increment(value: int) -> int:
        return value + 1
    assert Box(0).bind(increment) == 1
    assert Box(1).bind(increment) == 2
    assert Box(10).bind(increment) == 11
    assert Box(25).bind(increment) == 26
    assert Box(120).bind(increment) == 121
    assert Box('test').bind(lambda v: v + '2') == 'test2'

    class Test:
        pass

    test = Test()
    assert Box(test).bind(lambda v: test) == test


# Generated at 2022-06-21 18:57:25.215159
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    m = Box(10)
    r = m.to_either()

    assert isinstance(r, Right)
    assert r.value == m.value



# Generated at 2022-06-21 18:57:29.893713
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Box(lambda x: x ^ 2).ap(Box(3)) == Box(9)



# Generated at 2022-06-21 18:57:34.357184
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box("number").to_either() == Right("number")
    assert Box(object).to_either() == Right(object)



# Generated at 2022-06-21 18:57:36.597089
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')



# Generated at 2022-06-21 18:57:38.857016
# Unit test for method to_either of class Box
def test_Box_to_either():
    import pytest

    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 18:57:42.794262
# Unit test for method map of class Box
def test_Box_map():
    box_zero = Box(0)
    box_one = Box(1)
    box_two = Box(2)

    assert box_zero.map(lambda x: x + 1) == box_one
    assert box_one.map(lambda x: x + 1) == box_two



# Generated at 2022-06-21 18:57:46.594872
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(Validation.success(1)).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:57:54.200497
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Nothing, Maybe

    assert Box('').to_maybe() == Nothing()
    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(2).to_maybe() == Maybe.just(2)
    assert Box(3).to_maybe() == Maybe.just(3)
    assert Box(4).to_maybe() == Maybe.just(4)
    assert Box(5).to_maybe() == Maybe.just(5)
    assert Box({}).to_maybe() == Nothing()
    assert Box({'a': 1}).to_maybe() == Maybe.just({'a': 1})



# Generated at 2022-06-21 18:57:56.817101
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(0).to_either().is_right
    assert Box(0).to_either().right.value == 0


# Generated at 2022-06-21 18:58:09.449047
# Unit test for constructor of class Box
def test_Box():
    assert Box('value') == Box('value')

# Generated at 2022-06-21 18:58:11.026942
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)


# Generated at 2022-06-21 18:58:14.697098
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for Box class to_lazy method.
    """
    from pymonet.monad_try import Try

    try_value = Try("it's ok", True)
    box_value = Box(try_value)

    # Test if box contains expected value and to_lazy called on it returns expected value...
    assert box_value.value == try_value
    assert box_value.to_lazy().value() == try_value


# Generated at 2022-06-21 18:58:24.684896
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    def return_something(_):
        return 'Something'

    assert Box('Something').to_maybe() == Maybe.just('Something')
    assert Box(None).to_maybe() == Maybe.just(None)

    assert Box('Something').to_maybe().map(return_something) == Maybe.just(return_something('Something'))
    assert Box(None).to_maybe().map(return_something) == Maybe.just(return_something(None))

    assert Box('Something').to_maybe().bind(return_something) == return_something('Something')
    assert Box(None).to_maybe().bind(return_something) == return_something(None)


# Generated at 2022-06-21 18:58:27.058586
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-21 18:58:32.982286
# Unit test for method ap of class Box
def test_Box_ap():
    # Setup
    f = lambda x: x + 5
    box = Box(f)

    # Exercise
    box_result = box.ap(Box(5))

    # Verify
    assert box_result is not None
    assert box_result.value == 10

    # Teardown

# Generated at 2022-06-21 18:58:35.641554
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)


# Generated at 2022-06-21 18:58:40.583936
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_maybe().just(1)
    assert Box(1).to_maybe() != Box(1).to_maybe().nothing()
    assert Box(1).to_maybe() != Box(2).to_maybe().just(1)


# Generated at 2022-06-21 18:58:42.104550
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(25)) == 'Box[value=25]'



# Generated at 2022-06-21 18:58:49.136902
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure

    assert Box(5).to_try() == Success(5)
    assert Box("started").to_try() == Success("started")
    assert Box(["hi", "hello"]).to_try() == Success(["hi", "hello"])
    assert Box("fail").to_try() != Failure("fail")
    assert Box(7).to_try() != Failure(7)
    assert Box("fail").to_try() != Success("done")
    assert Box("fail").to_try() != Failure("done")

# Generated at 2022-06-21 18:59:15.750875
# Unit test for method map of class Box
def test_Box_map():
    assert Box(42).map(lambda x: x + 1) == Box(43)
    assert Box('hello').map(lambda x: x + ' world!') == Box('hello world!')



# Generated at 2022-06-21 18:59:18.155486
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]' == str(Box(True)) == 'Box[value=True]'

# Generated at 2022-06-21 18:59:23.605466
# Unit test for method map of class Box
def test_Box_map():
    """
    Test method map of class Box.

    :returns: None
    :rtype: None
    """
    from pymonet.maybe import Maybe

    box = Box(1)
    assert box.map(lambda x: x + 1) == Box(2)
    assert box.map(lambda x: x.to_maybe()) == Maybe.just(1)


# Generated at 2022-06-21 18:59:27.097638
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(2).to_try() == Try(2, is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)


# Generated at 2022-06-21 18:59:29.825532
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box("j") == Box("j")
    assert Box("Python") == Box("Python")



# Generated at 2022-06-21 18:59:32.591840
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_lazy().bind(lambda x: x).to_maybe()


# Generated at 2022-06-21 18:59:34.735981
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    box = Box(10)
    assert box.to_maybe() == Maybe(10)



# Generated at 2022-06-21 18:59:37.752250
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)
    assert Box(lambda x: x + 3).ap(Box(2)) == Box(5)


# Generated at 2022-06-21 18:59:40.116765
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    # Test converting Box to Validation
    assert Box(2).to_validation() == Validation.success(2)


# Generated at 2022-06-21 18:59:42.490430
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(123).map(lambda x: x * 2) == Box(246)



# Generated at 2022-06-21 19:00:37.067272
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(123).to_either() == Right(123)

# Generated at 2022-06-21 19:00:38.858282
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(123)
    assert box.to_either() == Right(123)


# Generated at 2022-06-21 19:00:40.437000
# Unit test for method ap of class Box
def test_Box_ap():
    box = Box(lambda x: x ** 2)

    assert box.ap(Box(2)) == Box(2 ** 2)

# Generated at 2022-06-21 19:00:45.487454
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('str')) == 'Box[value=str]'
    assert str(Box({'dictionary': 'is'})) == "Box[value={'dictionary': 'is'}]"
    assert str(Box(['list'])) == 'Box[value=[\'list\']]'



# Generated at 2022-06-21 19:00:50.185347
# Unit test for constructor of class Box
def test_Box():
    assert Box(3) == Box(3)
    assert Box("Hello") == Box("Hello")
    assert Box(True) == Box(True)
    assert Box(None) == Box(None)
    assert Box([]) == Box([])
    assert Box({}) == Box({})


# Generated at 2022-06-21 19:00:54.504166
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    empty_list_box = Box([])
    empty_list_box_duplicate = Box([])
    empty_list_box_not_equals = Box(['value'])

    assert empty_list_box == empty_list_box_duplicate
    assert empty_list_box != empty_list_box_not_equals



# Generated at 2022-06-21 19:00:58.878165
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:01:03.421421
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import success

    is_equal = success(1).fmap(lambda x: x + 1) == Box(1).to_try().fmap(lambda x: x + 1)
    assert is_equal

# Generated at 2022-06-21 19:01:05.199828
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('text').bind(lambda x: x + '_two') == 'text_two'

# Generated at 2022-06-21 19:01:08.575203
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Either

    assert isinstance(Box(1).to_either(), Either)
    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 19:03:18.214788
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-21 19:03:20.635350
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) == Box(1)


# Generated at 2022-06-21 19:03:29.182632
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    '''
    Unit test for testing correctness of method __eq__ of Box
    '''

    assert Box(2) == Box(2)
    assert Box('Hello') == Box('Hello')
    assert Box(Box('test')) == Box(Box('test'))
    assert not Box(2) == Box(3)
    assert not Box('Hello') == Box('World')
    assert not Box(Box('test')) == Box('test')
    assert not Box(Box('test')) == Box(True)
    assert not Box(Box('test')) == Box(2)
    assert not Box(True) == Box(False)



# Generated at 2022-06-21 19:03:35.061608
# Unit test for constructor of class Box
def test_Box():
    assert Box(None) == Box(None)
    assert Box(True) == Box(True)
    assert Box(False) == Box(False)
    assert Box(1) == Box(1)
    assert Box(1.2) == Box(1.2)
    assert Box(1 + 2j) == Box(1 + 2j)
    assert Box('foo') == Box('foo')
    assert Box(['foo', 123, True]) == Box(['foo', 123, True])

# Generated at 2022-06-21 19:03:37.419404
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Just, Maybe

    assert Just(1).to_maybe() == Maybe(Just(1))



# Generated at 2022-06-21 19:03:39.575301
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 2).ap(Box(1)) == Box(3)

# Generated at 2022-06-21 19:03:41.182255
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_maybe().just(1)



# Generated at 2022-06-21 19:03:47.491798
# Unit test for method map of class Box
def test_Box_map():
    import pytest

    box = Box(value=10)
    assert box.map(lambda x: x + 1) == Box(value=11)

    box = Box(value=1)
    assert box.map(lambda x: x + 1).map(lambda x: x * 10) == Box(value=20)

    box = Box(value=(1, 2))
    assert box.map(lambda x: (1, 2, 3)) == Box(value=(1, 2, 3))

    box = Box(value=1)
    assert box.map(lambda x: (1, 2)) == Box(value=(1, 2))

    with pytest.raises(ValueError):
        box.map(lambda x: x(10))



# Generated at 2022-06-21 19:03:50.101628
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)



# Generated at 2022-06-21 19:03:51.137236
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)

