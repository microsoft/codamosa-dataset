

# Generated at 2022-06-21 18:54:54.498892
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for bind method of Box
    """
    # Box[5]
    assert Box(5) == Box(5)
    # Box[6]
    assert Box(6) == Box(6)
    # Box[11]
    assert Box(11) == Box(11)
    # Box[15]
    assert Box(15).map(lambda value: value + 5) == Box(20)



# Generated at 2022-06-21 18:54:56.045299
# Unit test for method map of class Box
def test_Box_map():
    assert Box('hello').map(str.upper) == Box('HELLO')



# Generated at 2022-06-21 18:55:02.371753
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # ARRANGE
    boxes = (Box(1), Box(2), Box(3), Box(4), Box(5), Box(6), Box(7), Box(8), Box(9), Box(10))

    # ACT
    result = reduce(lambda x, y: x + y.value, map(lambda x: x.to_lazy().fold(), boxes), 0)

    # ASSERT
    assert result == 55

# Generated at 2022-06-21 18:55:06.913208
# Unit test for constructor of class Box
def test_Box():
    """
    Test for constructor of class Box

    :returns: assert for current test
    :rtype: Assert
    """
    from pymonet.test_utils import _TestUtils

    return _TestUtils.test_constructor(Box, one_of=_TestUtils.ONE_OF_TYPES)



# Generated at 2022-06-21 18:55:08.769407
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-21 18:55:09.945791
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:55:14.043806
# Unit test for constructor of class Box
def test_Box():
    assert Box(2) == Box(2)
    assert Box(2) != Box(3)
    assert Box(2).value == 2

# Unit tests for map method of the class Box

# Generated at 2022-06-21 18:55:20.144693
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe() == Maybe(10)
    assert Box(None).to_maybe() == Maybe.nothing()
    assert Box(Try(10, is_success=True)).to_maybe() == Maybe(10)
    assert Box(Try([], is_success=False)).to_maybe() == Maybe.nothing()
    assert Box(True).to_maybe() == Maybe(True)
    assert Box(False).to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 18:55:23.641345
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()
    

# Generated at 2022-06-21 18:55:25.258275
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(42)) == 'Box[value=42]'



# Generated at 2022-06-21 18:55:32.019617
# Unit test for method bind of class Box
def test_Box_bind():
    def adder(val):
        return val + 1
    """
    Execute bind method of Box and return value of bind operation.

    :returns: result of bind method
    :rtype: Number
    """
    bind_res = Box(5).bind(adder)

    assert bind_res == 6



# Generated at 2022-06-21 18:55:33.459247
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)

# Generated at 2022-06-21 18:55:35.973842
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box((1, 2)) == Box((1, 2))

# Generated at 2022-06-21 18:55:37.749619
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)


# Generated at 2022-06-21 18:55:39.542679
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 2) == Box(4)


# Generated at 2022-06-21 18:55:45.200753
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Box(1).to_either() == Right(1)
    assert Box(None).to_either() == Right(None)

    def error_func():
        raise ValueError("error message")

    assert Box(error_func()).to_either() == Right(error_func())


# Generated at 2022-06-21 18:55:49.909987
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # when
    result_of_equal_boxes = Box(5) == Box(5)
    result_of_non_equal_boxes = Box(5) == Box(6)

    # then
    assert result_of_equal_boxes
    assert not result_of_non_equal_boxes



# Generated at 2022-06-21 18:55:51.562553
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box("Hello, world!") == Box("Hello, world!")



# Generated at 2022-06-21 18:55:55.378023
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.validation import Validation

    v_1 = Box(12)
    v_2 = Box((lambda x, y: x * y))

    assert v_1.ap(v_2) == Validation.success(144)



# Generated at 2022-06-21 18:55:58.894120
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('Monet')) == 'Box[value=Monet]'
    assert str(Box(2)) == 'Box[value=2]'
    assert str(Box(True)) == 'Box[value=True]'

# Generated at 2022-06-21 18:56:02.903764
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-21 18:56:05.025824
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box('Hello World')) == 'Box[value=Hello World]'


# Generated at 2022-06-21 18:56:07.586634
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(2).map(lambda x: x * 2) == Box(4)



# Generated at 2022-06-21 18:56:10.704075
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 18:56:11.822797
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-21 18:56:14.579115
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad import Box

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:56:21.850498
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box([]).to_lazy() == Lazy(lambda: [])
    assert Box('test').to_lazy() == Lazy(lambda: 'test')
    assert Box([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])
    assert Box({'name': 'John'}).to_lazy() == Lazy(lambda: {'name': 'John'})



# Generated at 2022-06-21 18:56:24.987735
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-21 18:56:27.484913
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box('test').to_validation() == Validation.success('test')



# Generated at 2022-06-21 18:56:31.282052
# Unit test for method to_either of class Box
def test_Box_to_either():
    # given
    value = 1
    box = Box(value)

    # when
    result = box.to_either()

    # then
    assert isinstance(result, Result)
    assert result.isRight()
    assert result.getRight() == value

# Generated at 2022-06-21 18:56:36.859158
# Unit test for method to_validation of class Box
def test_Box_to_validation():

    from pymonet.validation import Validation
    from pymonet.validation import Success

    value = '123'
    box = Box(value)

    assert isinstance(box.to_validation(), Validation)
    assert box.to_validation() == Success(value)



# Generated at 2022-06-21 18:56:41.452940
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    assert Either.right(10).to_either() == Either.right(10).to_box()
    assert Either.left('error').to_either() == Either.left('error').to_box()


# Generated at 2022-06-21 18:56:45.786296
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None
    assert Box(1) != object()
    assert Box(1) != object
    assert Box(1) != Box


# Generated at 2022-06-21 18:56:49.416029
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    # Arrange
    obj = Box(42)

    # Act
    res = obj.to_validation()

    # Assert
    assert res == Validation.success(42)



# Generated at 2022-06-21 18:56:55.077929
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    test_value = -1
    box = Box(test_value)

    # Act
    lazy = box.to_lazy()

    # Assert
    assert isinstance(lazy, Lazy), 'Expected Lazy type.'
    assert test_value == lazy.get(), 'Expected lazy to be {}.'.format(test_value)


# Generated at 2022-06-21 18:56:57.537922
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-21 18:57:01.443025
# Unit test for method ap of class Box
def test_Box_ap():
    # Arrange
    applicative = Box(lambda x: x + 1)
    # Act
    result = Box(2).map(lambda x: x + 1).ap(applicative)
    # Assert
    assert result == Box(4)

# Generated at 2022-06-21 18:57:04.082459
# Unit test for method __str__ of class Box
def test_Box___str__(): # pragma: no cover
    assert str(Box(True)) == 'Box[value=True]'

# Unit tests for method map of class Box

# Generated at 2022-06-21 18:57:07.241844
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(3).to_validation() == Validation.success(3)



# Generated at 2022-06-21 18:57:09.823700
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 18:57:17.485943
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('abc') == Box('abc')
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box({'name': 'John'}) == Box({'name': 'John'})



# Generated at 2022-06-21 18:57:21.356303
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).map(lambda i: i * 2).to_validation() == Validation.success(2)
    assert Box('2').map(lambda s: int(s)).to_validation() == Validation.success(2)

# Generated at 2022-06-21 18:57:28.021214
# Unit test for method map of class Box
def test_Box_map():
    # Arrange
    box_int = Box(5)
    box_str = Box('test')

    # Act
    res_int = box_int.map(lambda x: 2 * x)
    res_str = box_str.map(lambda x: x + ' str')

    # Assert
    assert res_int == Box(10)
    assert res_str == Box('test str')



# Generated at 2022-06-21 18:57:31.338513
# Unit test for method map of class Box
def test_Box_map():
    """
    Simple test for method map of class Box

    :returns: None
    :rtype: None
    """

    # Positive test
    assert Box('1').map(lambda x: int(x) * 2) == Box(2)


# Generated at 2022-06-21 18:57:33.429167
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box([1, 2, 3]).to_validation() == Validation.success([1, 2, 3])

    # Unit test for method to_lazy of class Box

# Generated at 2022-06-21 18:57:38.809057
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Success

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.nothing()
    assert Box(Success(1)).to_maybe() == Maybe.just(Success(1))


# Generated at 2022-06-21 18:57:40.180455
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left

    assert Box(1).to_either() == Right(1)
    assert Box(Left(1)).to_either() == Left(1)


# Generated at 2022-06-21 18:57:42.651747
# Unit test for method to_try of class Box
def test_Box_to_try():
    result = Box(2).to_try()

    assert result.value == 2
    assert result.is_success
    assert not result.is_failure
    assert repr(result) == 'Success(2)'

# Generated at 2022-06-21 18:57:45.351906
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(42).to_either() == Right(42)

# Generated at 2022-06-21 18:57:48.138033
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(12)
    validation = box.to_validation()
    assert(validation == Validation.success(box.value))

# Generated at 2022-06-21 18:58:01.731397
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    """
    __str__(...) method unit test
    """

    # Basic usage
    assert str(Box(0)) == 'Box[value=0]'
    assert str(Box('hello')) == 'Box[value=hello]'



# Generated at 2022-06-21 18:58:03.069697
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)



# Generated at 2022-06-21 18:58:04.967809
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 18:58:08.033861
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try.just(1).equal(Box(1).to_try())
    assert Try.error(1).equal(Box(1).to_try(is_success=False))



# Generated at 2022-06-21 18:58:10.773709
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    val = Box(1).to_validation()

    assert val == Validation.success(1)

# Generated at 2022-06-21 18:58:12.747929
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(None) == Box(None)



# Generated at 2022-06-21 18:58:16.481403
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(5)) == Box(10)
    assert Box(lambda x: x).ap(Box(lambda x: x)) == Box(lambda x: x)

# Generated at 2022-06-21 18:58:17.575899
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation().is_success

# Generated at 2022-06-21 18:58:22.994782
# Unit test for method map of class Box
def test_Box_map():
    def mapper(a: int) -> int:
        return 2 * a

    assert Box(2).map(mapper) == Box(4)
    assert Box(2).map(mapper).map(mapper) == Box(8)
    assert Box(2).map(mapper).map(mapper).map(mapper) == Box(16)


# Generated at 2022-06-21 18:58:26.713259
# Unit test for method to_either of class Box
def test_Box_to_either():  # type: () -> None
    """
    Check that Box.to_either transform Box into Right either.
    """
    from pymonet.either import Right

    assert Right(3) == Box(3).to_either()



# Generated at 2022-06-21 18:58:46.525366
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box('test_val')
    assert str(box) == 'Box[value=test_val]'


# Generated at 2022-06-21 18:58:49.261704
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    one_box = Box(1)
    lazy_box = one_box.to_lazy()
    assert isinstance(lazy_box, Lazy)
    assert lazy_box.value() == 1


# Generated at 2022-06-21 18:58:50.994638
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(12)) == 'Box[value=12]'



# Generated at 2022-06-21 18:58:53.175201
# Unit test for constructor of class Box
def test_Box():
    assert Box(0) == Box(0)
    assert Box(0) != Box(1)
    assert Box(0) == Box("0")


# Generated at 2022-06-21 18:59:00.456888
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    # Box and Maybe
    assert Box(123).map(Maybe.just) == Maybe.just(123)

    # Box and Either
    assert Box(123).map(Right) == Right(123)

    # Box and Lazy
    assert Box(123).map(Lazy) == Lazy(lambda: 123)



# Generated at 2022-06-21 18:59:05.158515
# Unit test for constructor of class Box
def test_Box():
    import pymonet.either as either

    # Box(A) = Box[A] => Box(A) == Box[A]
    assert Box(1) == Box[int](1)
    assert Box('abc') == Box[str]('abc')
    assert Box(either.Right(1)) == Box[either.Right[int]](either.Right(1))



# Generated at 2022-06-21 18:59:06.761549
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-21 18:59:08.256549
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(10).to_maybe() == Box(10).bind(lambda v: Maybe.just(v))



# Generated at 2022-06-21 18:59:11.533993
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    def to_either_test():
        assert Box('').to_either() == Right('')

    to_either_test()



# Generated at 2022-06-21 18:59:14.666166
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(2).to_validation() == Box(2).to_validation() == Validation.success(2)



# Generated at 2022-06-21 19:00:00.106304
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box

    :returns: nothing
    :rtype: None
    """
    from nose.tools import eq_
    from pymonet.validation import Validation

    eq_(Box(42).to_validation(), Validation.success(42))



# Generated at 2022-06-21 19:00:02.241086
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)
    assert Box("a").map(lambda x: x + "b") == Box("ab")
    assert Box(None).map(lambda x: x is None) == Box(True)



# Generated at 2022-06-21 19:00:04.506833
# Unit test for method to_either of class Box
def test_Box_to_either():
    import pymonet.either
    assert Box(2).to_either() == pymonet.either.Right(2)



# Generated at 2022-06-21 19:00:05.812470
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(3).to_either() == 3


# Generated at 2022-06-21 19:00:08.282412
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-21 19:00:10.999676
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(2).to_try() == Try(2, is_success=True)


# Generated at 2022-06-21 19:00:13.517780
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 19:00:15.270204
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:00:18.433109
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box = Box(42)
    validation = box.to_validation()

    assert validation.is_success
    assert validation.success == 42
    assert validation.failure == []


# Generated at 2022-06-21 19:00:20.067519
# Unit test for method bind of class Box
def test_Box_bind(): # pragma: no cover
    assert Box(2).bind(lambda a: a + 3) == 5



# Generated at 2022-06-21 19:01:53.538663
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Tests converting Box to Right Either
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 19:01:55.212494
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    a = Box(1)
    b = Box(1)
    assert a == a
    assert a == b
    assert a != 1



# Generated at 2022-06-21 19:01:58.614394
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(1).to_try().value == 1
    assert Box(1).to_try().error is None
    assert Box(1).to_try().is_success is True
    assert Box(1).to_try().is_failure is False


# Generated at 2022-06-21 19:02:02.841849
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_try import Try

    assert Box(lambda x: x).ap(Box(3)) == Box(3)
    assert Box(lambda x: x).ap(Try(3, is_success=True)).value == Try(3, is_success=True)


# Generated at 2022-06-21 19:02:07.052520
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    assert Box(2).to_either() == Either(2, [])
    assert Box(-50).to_either() == Either(-50, [])
    assert Box(None).to_either() == Either(None, [])
    assert Box('Some value').to_either() == Either('Some value', [])

# Generated at 2022-06-21 19:02:10.256160
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:02:12.007639
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('test') == Box('test')
    assert Box('test') is not Box('test')



# Generated at 2022-06-21 19:02:13.329438
# Unit test for method to_try of class Box
def test_Box_to_try():

    # when
    box = Box(1)
    result = box.to_try()

    # then
    assert result.is_success == True

# Generated at 2022-06-21 19:02:13.903101
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(3)) == 'Box[value=3]'

# Generated at 2022-06-21 19:02:18.298658
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda n: n + 1) == Box(2)
    assert Box('1').map(lambda c: c + c) == Box('11')
    assert Box([1, 2]).map(lambda cs: cs + [3]) == Box([1, 2, 3])
    assert Box({1: 1}).map(lambda d: d[1] + 1) == Box(2)

