

# Generated at 2022-06-21 18:54:54.802788
# Unit test for method map of class Box
def test_Box_map():
    box_string = Box('string')
    assert box_string.map(len) == Box(6)

    box_list = Box([1, 2, 3])
    assert box_list.map(lambda x: x + 1) == Box([2, 3, 4])


# Generated at 2022-06-21 18:54:57.728411
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(5)
    validation = box.to_validation()

    assert isinstance(validation, Validation)
    assert validation == Validation.success(5)



# Generated at 2022-06-21 18:55:03.629015
# Unit test for method to_try of class Box
def test_Box_to_try():
    """Unit test for method to_try of class Box"""

    from pymonet.monad_try import Try

    assert Box(1).to_try().is_success is True
    assert isinstance(Box(1).to_try(), Try)
    assert Try(1, is_success=True) == Box(1).to_try()


# Generated at 2022-06-21 18:55:05.850854
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('1')) == 'Box[value=1]'

# Generated at 2022-06-21 18:55:08.182358
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    value = 1
    validation = Box(value).to_validation()
    assert isinstance(validation, Box)
    assert validation.value == (value, [])


# Generated at 2022-06-21 18:55:11.293554
# Unit test for constructor of class Box
def test_Box():
    box = Box(1)

    assert box.value == 1
    assert isinstance(box, Box)
    assert box.__str__() == 'Box[value=1]'
    assert box.__eq__(Box(1))
    assert not box.__eq__(Box(2))



# Generated at 2022-06-21 18:55:14.236915
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    import pytest

    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 18:55:16.373834
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 3).value == 6



# Generated at 2022-06-21 18:55:19.857891
# Unit test for method ap of class Box
def test_Box_ap():
    def mapper(value): return value + 1

    box = Box(1)
    box_of_mapper = Box(mapper)
    assert box_of_mapper.ap(box) == Box(2)



# Generated at 2022-06-21 18:55:21.519109
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    result = Box(0).to_maybe()

    assert type(result) == Maybe
    assert result == Maybe.just(0)

# Generated at 2022-06-21 18:55:25.009650
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('foo').value == 'foo'

# Generated at 2022-06-21 18:55:36.020489
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # When === should return True
    assert Box(2) == Box(2)
    assert Box(2) == Box(2.0)
    assert Box(2.0) == Box(2)
    assert Box(2.0) == Box(2.0)
    # When === should return False
    assert Box(2) != Box(3)
    assert Box(2) != Box(2.2)
    assert Box(2) != Box(2.0)
    assert Box(2.0) != Box(2.2)

    assert Box("s") == Box("s")
    assert Box("s") == Box("S")  # for str it's false, for tuple it's true
    assert Box("S") == Box("s")
    assert Box("S") == Box("S")
    # When === should return False

# Generated at 2022-06-21 18:55:39.008857
# Unit test for constructor of class Box
def test_Box():
    # Test for constructor of Box
    assert Box(100) == Box(100)

    # Test for str representation
    assert str(Box(100)) == 'Box[value=100]'



# Generated at 2022-06-21 18:55:40.445330
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x ** 2) == 1


# Generated at 2022-06-21 18:55:42.682847
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(12).to_lazy() == Lazy(lambda: 12)

# Generated at 2022-06-21 18:55:45.125012
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test ap method of Box.
    """
    assert Box.ap(Box(lambda x: x + 5), Box(2)) == Box(7)


# Generated at 2022-06-21 18:55:48.066023
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_maybe()
    assert Box(1).to_maybe() != Box(2).to_maybe()



# Generated at 2022-06-21 18:55:57.086891
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Defines unit test for method to_maybe of class Box.
    """
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    box = Box(True)

    assert box.to_maybe().is_just

    box = Box(Right(True))

    assert box.to_maybe().value.is_just

    box = Box(Try.success(True))

    assert box.to_maybe().value.is_success

    box = Box(Validation.success(True))

    assert box.to_maybe().value.is_success


# Generated at 2022-06-21 18:56:03.461135
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(10) == Box(10)
    assert Box('Hello') == Box('Hello')
    assert Box([]) == Box([])
    assert Box(None) == Box(None)
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box('Test')) == 'Box[value=Test]'



# Generated at 2022-06-21 18:56:05.668586
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-21 18:56:11.837027
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 18:56:14.622146
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    b = Box(1)
    l = b.to_lazy()

    assert l == Lazy(lambda: 1)


# Generated at 2022-06-21 18:56:23.193080
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left
    assert Left(10).to_either() == Left(10), "Left(10).to_either() should be Left(10)"
    assert Left('10').to_either() == Left('10'), "Left('10').to_either() shoud be Left('10')"
    assert Left([]).to_either() == Left([]), "Left([]).to_either() shoud be Left([])"
    assert Left(['a']).to_either() == Left(['a']), "Left(['a']).to_either() shoud be Left(['a'])"
    assert Left([1, 2, 3]).to_either() == Left([1, 2, 3]), "Left([1, 2, 3]).to_either() shoud be Left([1, 2, 3])"
    assert Left

# Generated at 2022-06-21 18:56:34.425121
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for to_lazy method of class Box.
    """

    def test_assertions(box):
        """
        Function with assertions.

        :param box: Box[A]
        :type box: Box[A]
        """
        from pymonet.lazy import Lazy

        assert box.to_lazy() == Lazy(lambda: box.value)

    test_objects = [
        Box(None),
        Box(1),
        Box(1.0),
        Box(lambda x: x),
        Box(True),
        Box('A'),
        Box({'a': 1}),
        Box({'a': 1, 'b': 2, 'c': 3}),
        Box([1]),
        Box([1, 2, 3])
    ]


# Generated at 2022-06-21 18:56:37.130955
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert True is Box('value1') == Box('value1')
    assert False is Box('value1') == Box('value2')
    assert False is Box('value1') == 'value1'



# Generated at 2022-06-21 18:56:44.769893
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    def check(result: bool, expected: bool):  # pragma: no cover
        assert result == expected, 'expected: {} but got: {}'.format(expected, result)

    print('Test Box.__eq__')

    box_a = Box(5)
    box_b = Box(5)
    box_c = Box(4)

    check(box_a == box_b, True)
    check(box_b == box_c, False)


# Generated at 2022-06-21 18:56:45.777460
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(5).to_try() == Try(5, is_success=True)

# Generated at 2022-06-21 18:56:48.619916
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Test for method to_validation of class Box
    """
    from pymonet.validation import Validation

    assert Box(3).to_validation() == Validation.success(3)


# Generated at 2022-06-21 18:56:52.031517
# Unit test for constructor of class Box
def test_Box():
    assert Box(7) == Box(7)
    assert Box('hello') != Box(7)
    assert Box(7) != 7
    assert 'Box[value=hello]' == str(Box('hello'))



# Generated at 2022-06-21 18:56:54.837859
# Unit test for method to_either of class Box
def test_Box_to_either():
    box = Box(1)

    assert box.to_either().is_right()
    assert box.to_either().value == 1



# Generated at 2022-06-21 18:57:03.545594
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(500) == Box(500)
    assert Box(1.) == Box(1.)
    assert Box(1.) != Box(2.)
    assert Box(1.) != Box('1')
    assert Box(1) != Box([1, 2, 3])



# Generated at 2022-06-21 18:57:08.021966
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != object()
    assert Box(1) != None



# Generated at 2022-06-21 18:57:09.121775
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_box().to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 18:57:13.171533
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    # positive case
    box: Box[int] = Box(2)
    assert box.to_try() == Try(0, is_success=False)



# Generated at 2022-06-21 18:57:14.786113
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box("test")) == 'Box[value=test]'



# Generated at 2022-06-21 18:57:17.233359
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # when
    actual_value = Box(1) == Box(1)
    # then
    assert actual_value



# Generated at 2022-06-21 18:57:22.733362
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.monad_try import Try

    # GIVEN
    value = 5
    box = Box(value)

    # WHEN
    result = box.to_either()

    # THEN
    assert isinstance(result, Right)
    assert result.get_value() == value


# Generated at 2022-06-21 18:57:29.280547
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test to check transformation of Box into successful Try

    :return: none
    """
    import pytest
    from pymonet.monad_try import Try

    assert Box('value').to_try() == Try('value', is_success=True)
    assert Box([]).to_try() == Try([], is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)



# Generated at 2022-06-21 18:57:31.796485
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.funcs import add_one, add_two

    assert Box(2).bind(add_one).bind(add_two) == Box(3).bind(add_two).bind(add_one)

# Generated at 2022-06-21 18:57:34.615106
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)


# Generated at 2022-06-21 18:57:40.631337
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(value=3)) == 'Box[value=3]'


# Generated at 2022-06-21 18:57:46.551165
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.functor_class import FunctorClass

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert FunctorClass.fmap(lambda x: x + 1, Box(1)).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-21 18:57:49.414297
# Unit test for method bind of class Box
def test_Box_bind():
    # given
    value = Box(100)
    mapper = lambda x: x * 10

    # when
    result = value.bind(mapper)

    # then
    assert result == mapper(value.value)

# Generated at 2022-06-21 18:57:51.297077
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-21 18:57:52.791994
# Unit test for method ap of class Box
def test_Box_ap():
    def f(x):
        return x + 2

    assert Box(f).ap(Box(2)) == Box(4)

# Generated at 2022-06-21 18:57:53.593759
# Unit test for constructor of class Box
def test_Box():
    assert Box('value') == Box('value')

# Generated at 2022-06-21 18:57:57.473446
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 18:58:04.263132
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test method ap of class Box.
    """

    # Test on some function (A) -> B
    def test_function(value: str) -> int:
        """
        Function for testing Box in ap method.

        :param value: test string value
        :type value: str
        :returns: test integer value
        :rtype: int
        """
        return len(value)

    assert Box('test').ap(Box(test_function)) == Box(4)

# Generated at 2022-06-21 18:58:12.994702
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    def add1_function(value: int) -> int:
        return value + 1

    add1_box = Box(add1_function)
    assert add1_box.ap(Box(1)) == Box(2)

    def add2_function(value: int) -> int:
        return value + 2

    add2_box = Box(add2_function)
    assert add2_box.ap(Box(1)) == Box(3)

    def divide_by_function(value: int) -> Callable[[int], float]:
        return lambda x: x / float(value)

    divide_by_box = Box(divide_by_function)
    assert divide_by_box.ap(Box(2)) == Box(0.5)

# Generated at 2022-06-21 18:58:15.229418
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(123).to_either() == Right(123)



# Generated at 2022-06-21 18:58:26.139160
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    b = Box(5)
    assert b.to_maybe() == Maybe.just(5)



# Generated at 2022-06-21 18:58:28.725522
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    from pymonet.maybe import Maybe
    assert Box(3).to_maybe() == Maybe.just(3)


# Generated at 2022-06-21 18:58:32.631157
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    def mapper(value):
        return value + 1

    result = Box(1).map(mapper)

    assert result == Box(2)



# Generated at 2022-06-21 18:58:34.490512
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-21 18:58:36.625144
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:58:39.701764
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)
    assert Box(5).map(lambda x: x * 2) == Box(10)



# Generated at 2022-06-21 18:58:42.150837
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box
    """
    assert Box(2).to_lazy().force() == 2


# Generated at 2022-06-21 18:58:44.608678
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:58:46.477460
# Unit test for method bind of class Box
def test_Box_bind():
    z = lambda x: Box(x + 1)
    assert Box(1).bind(z) == z(1)

# Generated at 2022-06-21 18:58:48.722453
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box("Hello").to_maybe() == Maybe("Hello")
    assert Box(None).to_maybe() == Maybe("Hello")



# Generated at 2022-06-21 18:59:09.105772
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert repr(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-21 18:59:10.596900
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    case = Box(1234)
    assert case.value == 1234

# Generated at 2022-06-21 18:59:13.027471
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 18:59:14.939510
# Unit test for constructor of class Box
def test_Box():
    box = Box(1)
    assert box.value == 1


# Generated at 2022-06-21 18:59:16.465648
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:59:18.493935
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x*x).ap(Box(3)).value == 9



# Generated at 2022-06-21 18:59:19.614997
# Unit test for constructor of class Box
def test_Box():
    assert Box(5) == Box(5)

# Generated at 2022-06-21 18:59:20.526312
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x+1) == 3, 'Method bind transform value of box'

# Generated at 2022-06-21 18:59:21.689549
# Unit test for method map of class Box
def test_Box_map():
    assert Box(lambda x: x + 1).map(lambda f: f(2)) == Box(3)



# Generated at 2022-06-21 18:59:23.766144
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    
    assert Box(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-21 19:00:09.323723
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box.
    """
    from pymonet.either import Right

    assert Right(1) == Box(1).to_either()
    assert Right('test') == Box('test').to_either()
    assert Right((1, 2)) == Box((1, 2)).to_either()

# Generated at 2022-06-21 19:00:11.196414
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(value=1)

    assert str(box) == "Box[value=1]"

# Generated at 2022-06-21 19:00:14.538381
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).map(lambda value: value).to_either()



# Generated at 2022-06-21 19:00:22.241288
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box([1, 2, 3]) == Box([1, 2, 3])
    assert Box([1, 2, 3]) != Box([1, 2, None])
    assert Box({'a': 1, 'b': 2, 'c': 3}) == \
           Box({'a': 1, 'b': 2, 'c': 3})
    assert Box((i for i in range(0, 10))) == \
           Box((i for i in range(0, 10)))
    assert Box(3.14) == Box(3.14)
    assert Box('abc') == Box('abc')
    assert Box('abc') != Box('cba')



# Generated at 2022-06-21 19:00:25.064839
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-21 19:00:28.726841
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('abc')) == 'Box[value=abc]'
    assert str(Box(1.5)) == 'Box[value=1.5]'



# Generated at 2022-06-21 19:00:37.718088
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # GIVEN box with value 1
    box1 = Box(1)
    # AND second box with the same value 1
    box2 = Box(1)
    # AND third box with value 2
    box3 = Box(2)

    # WHEN first box compares with second
    result1 = box1 == box2
    # AND first box compares with third
    result2 = box1 == box3

    # THEN first box == second box must be True
    assert result1 == True
    # AND first box == third box must be False
    assert result2 == False

# Generated at 2022-06-21 19:00:38.706535
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)

# Generated at 2022-06-21 19:00:39.944853
# Unit test for constructor of class Box
def test_Box():
    assert Box(0) == Box(0)


# Generated at 2022-06-21 19:00:42.570740
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """

    from pymonet.maybe import Maybe

    assert Box('a').to_maybe() == Maybe.just('a')



# Generated at 2022-06-21 19:02:20.182584
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.monad_try import MonadException, Try
    from pymonet.lazy import Lazy

    box = Box(123)
    assert box.bind(lambda x: x) == 123
    assert box.bind(lambda x: x ** 2) == 15129
    assert box.bind(lambda x: x.to_string('')) == '123'

    def divide(a, b):
        return a / b

    def divide_with_try(a, b):
        return Try(lambda: a / b)

    assert box.bind(lambda x: divide(x, 1)) == 123
    assert box.bind(lambda x: divide(x, 2)) == 61.5
    assert box.bind(lambda x: divide(x, 0)) == 0


# Generated at 2022-06-21 19:02:23.904768
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    assert box.to_maybe() == Maybe.just(1)

# Generated at 2022-06-21 19:02:28.595932
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    # Given
    initial_value = Box(lambda x: x + 1)
    value = 2

    # When
    result = initial_value.ap(Box(value))

    # Then
    assert 3 == result.value


# Generated at 2022-06-21 19:02:30.338809
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()


# Generated at 2022-06-21 19:02:33.575803
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """Unit test for Box.to_valadation method."""
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation(), "Box.to_validation should return successfull Validation"


# Generated at 2022-06-21 19:02:38.554020
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.either import Left
    from pymonet.maybe import Nothing

    # Test for Box[Value] and Box[Function() -> _]
    assert Box(lambda x: x**2).ap(Box(3)) == Box(9)

    # Test for Box[Value] and Nothing
    assert Box(lambda x: x**2).ap(Nothing()) == Nothing()

    # Test for Box[Value] and Left[Value]
    assert Box(lambda x, y: x**y).ap(Left(2)) == Left(2)

    # Test for Box[Value] and Box[None]
    assert Box(lambda x, y: x**y).ap(Box(None)) == Box(None)

    # Test for Box[Value] and Box[Right[Value]]

# Generated at 2022-06-21 19:02:41.882312
# Unit test for method map of class Box
def test_Box_map():

    def double(x):
        return x * 2

    box = Box(2)
    assert box.map(double) == Box(4)


# Generated at 2022-06-21 19:02:43.648669
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(None).to_validation() == Validation.success(None) is not None

# Generated at 2022-06-21 19:02:52.572577
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    """
    Unit test for constructor of class Box

    :returns: nothing
    :rtype: None
    """
    from pymonet.exceptions import EmptyBoxError
    box = Box(2)

    if (isinstance(box, Box)):
        print('Constructor of Box class is correct')
    else:
        print('Constructor of Box class is incorrect')

    if (box.value == 2):
        print('Box class stores value')
    else:
        print('Box class doesn\'t store value')

    try:
        box.value = 5
        print('Box can be changed')
    except AttributeError:
        print('Box can\'t be changed')


# Generated at 2022-06-21 19:02:53.754768
# Unit test for constructor of class Box
def test_Box():
    assert(Box(1) == Box(1))

