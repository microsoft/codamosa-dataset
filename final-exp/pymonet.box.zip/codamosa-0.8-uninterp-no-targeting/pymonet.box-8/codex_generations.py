

# Generated at 2022-06-21 18:54:49.609575
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    t = Box('test').to_try()
    assert isinstance(t, Try)
    assert t.is_success() == True
    assert t.get_value() == 'test'


# Generated at 2022-06-21 18:54:58.318058
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')
    assert Box({'a': 1}) == Box({'a': 1})
    assert Box({'a': 1}) != Box({'a': 2})
    assert Box(None) == Box(None)
    assert Box(1) != None  # noqa: WPS421
    assert Box(None) != None  # noqa: WPS421
    assert Box([]) != None  # noqa: WPS421
    assert Box(None) != True  # noqa: WPS421, E721
    assert Box(None) != False  # noqa: WPS421, E721
    assert Box(None) != []  # no

# Generated at 2022-06-21 18:55:02.570107
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box('a').bind(lambda x: x + 'b') == 'ab'
    asser

# Generated at 2022-06-21 18:55:04.062665
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(True).to_maybe() == Box(True).to_maybe()

# Generated at 2022-06-21 18:55:06.516547
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(2).to_try() == Try(2, is_success=True)


# Generated at 2022-06-21 18:55:08.769366
# Unit test for method to_try of class Box
def test_Box_to_try(): # pragma: no cover
    from pymonet.monad_try import Try

    result = Box(42).to_try()

    assert result == Try(42, True)


# Generated at 2022-06-21 18:55:11.106332
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)
    assert Box(3).map(lambda x: x - 2) == Box(1)
    assert Box('string').map(lambda x: x[:2]) == Box('st')


# Generated at 2022-06-21 18:55:13.501879
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-21 18:55:19.579190
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)
    identity_lambda = lambda x: x
    assert Box(identity_lambda).ap(Box(2)) == Box(2)
    assert Box(identity_lambda).ap(Box(identity_lambda)).ap(Box(identity_lambda)) == Box(identity_lambda)



# Generated at 2022-06-21 18:55:21.363418
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 18:55:25.884581
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)



# Generated at 2022-06-21 18:55:28.736578
# Unit test for constructor of class Box
def test_Box():
    assert Box('foo') == Box('foo')
    assert str(Box('foo')) == "Box[value='foo']"



# Generated at 2022-06-21 18:55:30.660413
# Unit test for method map of class Box
def test_Box_map():
    assert Box('a').map(lambda x: x.upper()) == Box('A')


# Generated at 2022-06-21 18:55:38.591783
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.is_success(Box('test').to_validation())
    assert Validation.is_success(Box(1).to_validation())
    assert Validation.is_success(Box(1.1).to_validation())
    assert Validation.is_success(Box([1]).to_validation())
    assert Validation.is_success(Box(['a']).to_validation())
    assert Validation.is_success(Box({'a': 1}).to_validation())
    assert Validation.is_success(Box(set([1])).to_validation())


# Generated at 2022-06-21 18:55:45.745848
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    def to_int(value: str) -> int:
        return int(value)

    box = Box('123')
    assert isinstance(box, Functor)
    assert isinstance(box, Applicative)

    assert box.ap(Box(to_int)) == Box(123)

    assert box.ap(Box(to_int).map(lambda v: v * 2)) == Box(246)

# Generated at 2022-06-21 18:55:47.612384
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(0)) == 'Box[value=0]'



# Generated at 2022-06-21 18:55:50.444635
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test to_either method of Box.
    """
    from pymonet.either import Right

    assert Box(100).to_either() == Right(100)



# Generated at 2022-06-21 18:55:52.029287
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).value

# Generated at 2022-06-21 18:55:55.428387
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:55:57.295203
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:56:04.641553
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test case for method bind of class Box
    :return: None
    """
    def map_function(value):
        return value - 1
    box_1 = Box(4)
    assert box_1.bind(map_function) == 3


# Generated at 2022-06-21 18:56:13.818354
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.identity import Identity

    assert Box(2).ap(Box(lambda x: x + 1)) == Box(3)

    assert Box(2).map(lambda x: x + 1) == Box(3)

    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)

    assert Box(2).ap(Box(lambda x: x * 10)) == Box(20)

    assert Box(lambda x: Identity(lambda y: x + y)).ap(Box(2)).bind(
        lambda x: x.ap(Box(3))) == Box(5)


# Generated at 2022-06-21 18:56:15.116894
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == "Box[value=1]"

# Generated at 2022-06-21 18:56:17.347756
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) != Box(1.0)
    assert Box(1) == Box(1)



# Generated at 2022-06-21 18:56:24.118794
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.int import Int, add, mul

    assert Box(add).ap(Box(Int(1))).ap(Box(Int(2))) == Box(Int(3))
    assert Box(mul).ap(Box(Int(1))).ap(Box(Int(2))) == Box(Int(2))
    assert Box(mul).ap(Box(1)).ap(Box(2)) == Box(2)
    assert Box(add).ap(Box(1)).ap(Box(2)) == Box(3)
    assert Box(add).ap(Box(-1)).ap(Box(-2)) == Box(-3)
    assert Box(add).ap(Box(1.1)).ap(Box(2.2)) == Box(3.3)

# Generated at 2022-06-21 18:56:25.845252
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from assertions import assertEqual

    assertEqual(Box(1) == Box(1), True)
    assertEqual(Box(1) == Box(2), False)
    assertEqual(Box(1) == object(), False)



# Generated at 2022-06-21 18:56:29.877888
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    assert Box(lambda a: a + 10).ap(Box(2)) == Box(12)
    assert Box(lambda a: a ** 2).ap(Box(3)) == Box(9)


# Generated at 2022-06-21 18:56:34.967043
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just, Maybe

    assert Box(1).to_maybe() == Just(1)
    assert Box(None).to_maybe() == Just(None)
    assert Box('string').to_maybe() == Just('string')
    assert Box([]).to_maybe() == Just([])
    assert Box({}).to_maybe() == Just({})
    assert Box(Maybe).to_maybe() == Just(Maybe)

# Generated at 2022-06-21 18:56:40.000843
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box({'name': 'john'}).bind(lambda x: x['name'].title()) == 'John'
    assert Box([1, 2, 3]).bind(lambda x: x[-1] + 1) == 4



# Generated at 2022-06-21 18:56:41.503884
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(2).to_try() == Try(2, True)

# Generated at 2022-06-21 18:56:47.992257
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try1 = Box(True).to_try()
    try2 = Box(True)
    assert isinstance(try1, Try) and try1.is_success is True and try1.value is True
    assert isinstance(try2, Try) and try2.is_success is True and try2.value is True



# Generated at 2022-06-21 18:56:50.542245
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)



# Generated at 2022-06-21 18:56:56.772307
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Nothing, Maybe
    from pymonet.monad_try import Try

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(Nothing()).to_maybe() == Nothing()

    t1 = Try(1, is_success=True)
    t2 = Try(2, is_success=False)

    assert Box(t1).to_maybe() == Maybe.just(1)
    assert Box(t2).to_maybe() == Nothing()



# Generated at 2022-06-21 18:56:58.447061
# Unit test for method bind of class Box
def test_Box_bind():
    number = Box(10)
    result = number.bind(lambda x: x * 2)
    assert result == 20



# Generated at 2022-06-21 18:57:02.213773
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test for method to_maybe of class Box
    """

    from pymonet.maybe import Just, Nothing

    box = Box(1)
    assert box.to_maybe() == Just(1)
    assert Box(None).to_maybe() == Nothing()



# Generated at 2022-06-21 18:57:06.431756
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != Box(4)
    assert Box(4) != None
    assert Box(4) != [1, 2, 3]

# Generated at 2022-06-21 18:57:09.232544
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: nocover
    assert Box(4) == Box(4)
    assert not Box(4) == Box(8)



# Generated at 2022-06-21 18:57:12.136313
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 18:57:13.714350
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(2).ap(Box(lambda x: x * x)) == Box(4)

# Generated at 2022-06-21 18:57:17.233466
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    # Given
    value = 1
    box = Box(value)

    # When
    result = box.to_validation()

    # Then
    assert result.is_success
    assert result.value == value

# Generated at 2022-06-21 18:57:25.663739
# Unit test for method to_either of class Box
def test_Box_to_either():
    import pytest

    from pymonet.monad_maybe import Maybe
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box(Maybe(1)).to_either().is_instance(Right)


# Generated at 2022-06-21 18:57:29.894582
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    t = Try(12)
    l = Box(12).to_lazy()
    assert isinstance(l, Lazy)
    assert l.value() == 12



# Generated at 2022-06-21 18:57:31.999446
# Unit test for method bind of class Box
def test_Box_bind():
    add10 = lambda x: x + 10
    assert Box(10).bind(add10) == 20
    assert Box(10).bind(add10).bind(add10) == 30

# Generated at 2022-06-21 18:57:42.877156
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box('a') == Box('a')
    assert Box(1) == Box(1)
    assert Box(['a', 'b']) == Box(['a', 'b'])
    assert Box((1, 'a')) == Box((1, 'a'))
    assert Box({1, 'a'}) == Box({1, 'a'})
    assert Box({'a': 1}) == Box({'a': 1})
    assert Box(lambda: 1) == Box(lambda: 1)
    assert Box(None) == Box(None)

    assert not (Box('a') != Box('a'))
    assert not (Box(1) != Box(1))
    assert not (Box(['a', 'b']) != Box(['a', 'b']))

# Generated at 2022-06-21 18:57:47.089487
# Unit test for method to_try of class Box
def test_Box_to_try():
    value = Box("2")
    new_value = value.to_try()
    assert isinstance(new_value, Try)
    assert new_value.equals(Try("2", True))


# Generated at 2022-06-21 18:57:48.439218
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2



# Generated at 2022-06-21 18:57:51.390644
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box("2")



# Generated at 2022-06-21 18:57:54.037745
# Unit test for constructor of class Box
def test_Box():
    assert Box(4) == Box(4)
    assert Box(4) != Box(5)
    assert Box(4) != 4
    assert Box(5).value == 5
    assert str(Box(5)) == 'Box[value=5]'

# Generated at 2022-06-21 18:57:57.203964
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    """
    Test for method Box.__str__.
    """

    box = Box(1)
    print(box)



# Generated at 2022-06-21 18:57:59.435374
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 18:58:10.808419
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    box = Box(10)
    maybe = box.to_maybe()

    assert maybe == Maybe.just(10)



# Generated at 2022-06-21 18:58:12.505938
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Test method __str__ of class Box.
    """
    assert str(Box(123)) == 'Box[value=123]'

# Generated at 2022-06-21 18:58:14.205988
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    def mapper(value: int) -> str:
        return '{}!'.format(value)

    assert Box(10).bind(mapper) == '10!'

# Generated at 2022-06-21 18:58:18.025032
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(False).to_lazy() == Lazy(lambda: False)


# Generated at 2022-06-21 18:58:22.333789
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x) == Box(1)
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(1).map(lambda x: x * x + 1).map(lambda x: x * x + 2) == Box(5)


# Generated at 2022-06-21 18:58:25.857912
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    :param: None
    :returns: None
    """
    from pymonet.either import Right
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:58:29.581798
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Failure

    success = Box(1).to_try()
    failure = Box(Failure(Exception('test'))).to_try()
    assert success.is_success()
    assert success.get() == 1
    assert not failure.is_success()
    assert failure.get() == Failure(Exception('test'))

# Generated at 2022-06-21 18:58:33.086145
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # type: () -> None
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import is_lazy

    box = Box(4)
    box = box.to_lazy()

    assert is_lazy(box)
    assert box.value() == 4



# Generated at 2022-06-21 18:58:36.677667
# Unit test for method to_validation of class Box
def test_Box_to_validation():  # pragma: no cover
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)



# Generated at 2022-06-21 18:58:40.751587
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test to_lazy method of Box class.
    """
    from pymonet.lazy import Lazy

    box = Box(1)

    assert box.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 18:58:51.930975
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Box(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-21 18:59:03.062739
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda a: a * 2).ap(Box(0)) == Box(0)
    assert Box(lambda a: a * 2).ap(Box(2)) == Box(4)
    assert Box(lambda a: a * 2).ap(Box(3)) == Box(6)
    assert Box(lambda a: a * 2).ap(Box(5)) == Box(10)
    assert Box(lambda a: a ** 2).ap(Box(0)) == Box(0)
    assert Box(lambda a: a ** 2).ap(Box(1)) == Box(1)
    assert Box(lambda a: a ** 2).ap(Box(2)) == Box(4)
    assert Box(lambda a: a ** 2).ap(Box(3)) == Box(9)

# Generated at 2022-06-21 18:59:06.107064
# Unit test for method to_either of class Box
def test_Box_to_either():
    # Arrange
    from pymonet.either import Left, Right
    from pymonet import Box

    # Act
    box = Box(1)
    result = box.to_either()

    # Assert
    assert result == Right(1)

# Generated at 2022-06-21 18:59:07.616663
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-21 18:59:10.042503
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 18:59:14.009517
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box.
    """
    assert Box('a').map(str.upper) == Box('A')
    assert Box(1).map(lambda a: a + 1) == Box(2)



# Generated at 2022-06-21 18:59:24.022985
# Unit test for method ap of class Box
def test_Box_ap():
    """
    >>> test_Box_ap()
    Unit test for method ap of class Box
    [30]
    [5, 6, 7]
    """
    print('Unit test for method ap of class Box')

    def times_two(x):
        return x * 2

    box = Box(2)
    assert box.ap(Box(times_two)) == Box(times_two(box.value))

    def sum_list(list_to_sum):
        return sum(list_to_sum)

    print(box.ap(Box(sum_list)).value)
    print([1, 2, 3, 4, 5].map(Box).ap(Box(sum_list)).value)



# Generated at 2022-06-21 18:59:25.503111
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Box('v').to_maybe() == Maybe.just('v')


# Generated at 2022-06-21 18:59:27.944478
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.just(None)
    assert Box('Value').to_maybe() == Maybe.just('Value')



# Generated at 2022-06-21 18:59:29.823749
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)



# Generated at 2022-06-21 18:59:45.574020
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test for method to_maybe of class Box.
    """
    assert Box(1).to_maybe() == Box(1).to_try().to_maybe() == Box(1).to_either().to_maybe() == Box(1).to_lazy().to_maybe() == Box(1).to_validation().to_maybe()


# Generated at 2022-06-21 18:59:46.742535
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:59:47.970360
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    assert Box(42).to_try() == Try(42, is_success=True)

# Generated at 2022-06-21 18:59:50.571620
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """

    assert Box(42).to_maybe() == Maybe.just(42)

# Generated at 2022-06-21 18:59:52.923848
# Unit test for method ap of class Box
def test_Box_ap():
    # Given
    box = Box("foo")
    # When
    result = box.ap(Box(len))
    # Then
    assert Box(3) == result



# Generated at 2022-06-21 18:59:55.278800
# Unit test for method map of class Box
def test_Box_map():
    """
    Test method map of class Box

    :return: None
    """
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 19:00:00.110181
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """
    from pymonet.monad_try import Try
    from pymonet.just import Just

    assert Box(3).to_try() == Try(3, is_success=True)
    assert Box(Just(3)).to_try() == Try(Just(3), is_success=True)



# Generated at 2022-06-21 19:00:01.252067
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == "Box[value=1]"

# Generated at 2022-06-21 19:00:05.896046
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(16)) == Box(32)
    assert Box(lambda x: x + 2).ap(Box(6)) == Box(8)
    assert Box(lambda x: x - 2).ap(Box(6)) == Box(4)
    assert Box(lambda x: x / 2).ap(Box(16)) == Box(8)

# Generated at 2022-06-21 19:00:09.269341
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(1)
    lazy = box.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1

# Generated at 2022-06-21 19:00:31.497599
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # When:
    lazy_monad = Box(1).to_lazy()

    # Then:
    assert lazy_monad.fold() == 1



# Generated at 2022-06-21 19:00:35.754941
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left

    assert Box(2).to_either().equals(Right(2))
    assert Box(2).to_either() != Left(2)



# Generated at 2022-06-21 19:00:39.089501
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(42).to_either() == Right(42)  # type: ignore
    assert Box(42).to_either() == Right(42)  # type: ignore



# Generated at 2022-06-21 19:00:40.612353
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(5)
    assert box.bind(lambda x: x + 1) == 6


# Generated at 2022-06-21 19:00:42.608290
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(3).to_maybe() == Maybe.just(3)


# Generated at 2022-06-21 19:00:44.852815
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(1)

    assert box.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 19:00:46.223677
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:00:51.838279
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(2) == Box(2)
    assert Box('value') != Box(2)
    assert Box(100) != Box('100')

    assert str(Box(2)) == 'Box[value=2]'
    assert repr(Box(2)) == 'Box(2)'



# Generated at 2022-06-21 19:00:53.543295
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:00:57.779529
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(5).to_either().is_left() is False
    assert Box(5).to_either().is_right() is True
    assert Box(5).to_either().right() == 5



# Generated at 2022-06-21 19:01:46.042396
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert (Box('foo').to_validation() == Validation('foo', []))


# Generated at 2022-06-21 19:01:49.284754
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box([1, 2, 3]).to_either() == Right([1, 2, 3])
    assert Box((1, 2, 3)).to_either() == Right((1, 2, 3))



# Generated at 2022-06-21 19:01:51.703259
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Given
    box = Box(value=12)

    # When
    lazy = box.to_lazy()

    # Then
    assert lazy.is_folded is False
    assert lazy.get()() == 12

# Generated at 2022-06-21 19:01:53.684364
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1
    assert Box("a").value == "a"



# Generated at 2022-06-21 19:02:04.610123
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)
    assert Box(5) != Box('6')
    assert Box(5) != None
    assert Box(6) == Box(6)
    assert Box(6) != None
    assert Box(6) != Box('6')
    assert Box('6') != Box(6)
    assert Box('6') != None
    assert Box('6') == Box('6')
    assert Box(None) != None
    assert Box(None) == Box(None)
    assert Box(5) != Box(None)
    assert Box(5) != Box('6')
    assert Box(5) != None
    assert Box(6) != None
    assert Box(6) != None
    assert Box('6') != None

# Generated at 2022-06-21 19:02:05.917945
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box('str') == Box('str')

# Generated at 2022-06-21 19:02:16.170577
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.either import Left

    assert (Box(1).ap(Box(lambda a: a + 1))) == Box(2)
    assert (Box(lambda a: a + 1).ap(Box(1))) == Box(2)
    assert (Box(lambda a: a + 1).ap(Box(lambda a: a + 1))) == Box(lambda x: x + 2)

    assert (Box(1).ap(Box(lambda a: Left(a + 1)))) == Box(Left(2))
    assert (Box(lambda a: a + 1).ap(Box(1))) == Box(2)
    assert (Box(lambda a: a + 1).ap(Box(lambda a: Left(a + 1)))) == Box(lambda x: Left(x + 2))

# Generated at 2022-06-21 19:02:19.201351
# Unit test for constructor of class Box
def test_Box():
    assert Box(2) == Box(2)
    assert Box(2) != Box(2.0)
    assert Box(2) == Box(2)

    assert Box('hello').value == 'hello'

    assert str(Box('hello')) == 'Box[value=hello]'


# Generated at 2022-06-21 19:02:22.429508
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: Box(x)) == Box(1)
    assert Box('test').bind(lambda x: Box(str(x) + '1')) == Box('test1')
    assert Box("One").bind(lambda x: Box(str(x) + "1")).bind(lambda x: Box(str(x) + "2")) == Box("One12")



# Generated at 2022-06-21 19:02:24.891833
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 19:04:12.111831
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.monad_try import Maybe, just

    assert Maybe.just(1) == Box(1).to_maybe()
    assert Maybe.pure(1) == Box(1).to_maybe()
    assert just(1) == Box(1).to_maybe()


# Generated at 2022-06-21 19:04:14.647447
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Success

    value = Box(1).to_try()
    assert isinstance(value, Success)

# Generated at 2022-06-21 19:04:16.518587
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation, Success

    assert Validation.success(10) == Box(10).to_validation()

# Generated at 2022-06-21 19:04:19.943975
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(42).to_try() == Try(42, is_success=True)

# Generated at 2022-06-21 19:04:22.127779
# Unit test for constructor of class Box
def test_Box():

    assert Box(1) == Box(1)
    assert Box(1) != Box('a')

    assert Box(1).value == 1
    assert Box('a').value == 'a'



# Generated at 2022-06-21 19:04:26.703044
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.monad_try import Try

    # Given
    a = Right(5)

    # When
    b = a.to_either()

    # Then
    assert isinstance(b, Box)

    assert isinstance(b.value, Try)

    assert b.value.is_success is True

    assert b.value.value == 5

# Generated at 2022-06-21 19:04:29.487487
# Unit test for method __str__ of class Box
def test_Box___str__():  # type: () -> None
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:04:37.010341
# Unit test for method ap of class Box
def test_Box_ap():

    # Box(a).ap(Box(f)) -> Box(f(a))
    # Box(5).ap(Box(lambda a: a + 3))
    assert Box(5).ap(Box(lambda a: a + 3)).value == 8

    # Box(a).ap(Box(f)) -> Box(f(a))
    # Box(5).ap(Box(lambda a: a - 3))
    assert Box(5).ap(Box(lambda a: a - 3)).value == 2



# Generated at 2022-06-21 19:04:43.537020
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

    assert Box('a') == Box('a')
    assert Box('a') != Box('b')

    assert Box(1) != 1
    assert Box('a') != 'a'
    assert Box(1) != [1, 2]
    assert Box(1) != {'a': 1}
    assert Box(1) != ('a', 1)



# Generated at 2022-06-21 19:04:45.622860
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x * 2) == Box(2)

