

# Generated at 2022-06-21 18:54:54.717064
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)
    assert Box("test").to_either() == Right("test")

# Generated at 2022-06-21 18:54:56.231877
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)


# Generated at 2022-06-21 18:55:00.242818
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1) == Box(1)
    assert not Box(1) == Box(None)
    assert not Box(1) == Box(2)
    assert Box(1).value == 1


# Generated at 2022-06-21 18:55:02.875735
# Unit test for method map of class Box
def test_Box_map():
    assert Box(5).map(lambda a: a * 10) == Box(50)



# Generated at 2022-06-21 18:55:05.070753
# Unit test for constructor of class Box
def test_Box():
    box = Box(1)

    assert box.value == 1
    assert str(box) == 'Box[value=1]'



# Generated at 2022-06-21 18:55:06.244018
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:55:07.538821
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-21 18:55:18.210485
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('1') == Box('1')
    assert Box(None) == Box(None)
    assert Box(None) != Box(1)
    assert Box(False) != Box(True)
    assert Box(1) != Box('1')
    assert Box(True) != Box(False)
    assert Box(1.0) != Box(1)
    assert Box(1) != Box(1.0)
    assert Box(1) != Box(Box(1))
    assert Box([]) != Box([])
    assert Box(()) != Box(())
    assert Box({}) != Box({})
    assert Box(1.0) != None
    assert Box(1) != None



# Generated at 2022-06-21 18:55:23.641332
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    """
    Test for method to_try of class Box
    """
    from pymonet.monad_try import Try

    assert Box(3).to_try() == Try(3, True)


# Generated at 2022-06-21 18:55:25.668292
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda x: x + 5) == Box(15).bind(lambda x: x + 5)



# Generated at 2022-06-21 18:55:29.059350
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy().value() == 3

# Generated at 2022-06-21 18:55:36.606398
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    def double(num):
        return num * 2

    assert Box(1).map(double) == Box(2)
    assert Box(2).map(double) == Box(4)
    assert Box(3).map(double) == Box(6)

    def stringify(num):
        return str(num)

    assert Box(1).map(stringify) == Box('1')
    assert Box(2).map(stringify) == Box('2')
    assert Box(3).map(stringify) == Box('3')



# Generated at 2022-06-21 18:55:38.386961
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for Box bind method
    """

    assert Box(1).bind(lambda x: x+1) == 2

# Generated at 2022-06-21 18:55:40.646586
# Unit test for method bind of class Box
def test_Box_bind():
    def add(a):
        return a + 1

    assert Box(1).bind(add) == add(1)



# Generated at 2022-06-21 18:55:45.746073
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either
    from pymonet.either import Left
    from pymonet.either import Right

    box = Box(2)
    either = box.to_either()

    assert isinstance(either, Either)
    assert isinstance(either, Right)
    assert either.value == box.value



# Generated at 2022-06-21 18:55:47.560149
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x * 2) == 4



# Generated at 2022-06-21 18:55:51.360886
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Just
    from pymonet.maybe import Nothing

    assert Box(1).to_maybe() == Just(1)

    # None is value of Nothing
    assert Box(None).to_maybe() == Nothing()


# Generated at 2022-06-21 18:55:53.198032
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box = Box(2)
    assert box.value == 2



# Generated at 2022-06-21 18:55:57.448781
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for bind function of Box monad.
    """
    def mapper(value):
        return value * 2

    assert Box(2).bind(mapper) == 4
    assert Box('2').bind(mapper) == '22'


# Generated at 2022-06-21 18:55:58.945870
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-21 18:56:02.316717
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 2) == Box(4)


# Generated at 2022-06-21 18:56:07.750217
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Test for method __str__ of class Box
    """

    assert str(Box(0)) == 'Box[value=0]', 'Unit test for __str__ of Box method failed'
    assert str(Box('string')) == 'Box[value=string]', 'Unit test for __str__ of Box method failed'


# Unit tests for method map of class Box

# Generated at 2022-06-21 18:56:10.856686
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-21 18:56:12.316494
# Unit test for method to_try of class Box
def test_Box_to_try():
    # Should be successfull Try
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-21 18:56:15.033272
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Box(1).to_maybe()
    assert Maybe.nothing == Box(None).to_maybe()



# Generated at 2022-06-21 18:56:18.269257
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet import Lazy

    result = Lazy(lambda: 9)

    assert Box(9).to_lazy() == result



# Generated at 2022-06-21 18:56:20.433127
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-21 18:56:22.749126
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()



# Generated at 2022-06-21 18:56:26.710484
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # GIVEN
    value = 'value'
    lazy = Box(value).to_lazy()

    # WHEN
    result = lazy()

    # THEN
    assert result == value


# Generated at 2022-06-21 18:56:29.927974
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    x = Lazy(lambda: 3).box()
    assert x.to_lazy().value() == 3



# Generated at 2022-06-21 18:56:33.692100
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    result = Box(1).to_validation()
    expected = 'Success(value=1)'
    assert str(result) == expected, 'should return {} but returned {}'.format(expected, str(result))

# Generated at 2022-06-21 18:56:37.564773
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation().is_success
    assert Box(1).to_validation().value == 1
    assert Box('test').to_validation().value == 'test'
    assert Box(['test1', 100]).to_validation().value == ['test1', 100]
    assert Box({'test1': 100}).to_validation().value == {'test1': 100}



# Generated at 2022-06-21 18:56:47.619832
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box

    :return: None
    """
    from pymonet.exceptions import MonetException
    from pymonet.monad_maybe import Maybe

    def add_x(x):
        return Maybe.just(x + 1)

    box_value = Box(5)
    result_box = box_value.bind(add_x)
    assert result_box == Maybe.just(6)

    result_box = box_value.bind(lambda _: Maybe.nothing())
    assert result_box == Maybe.nothing()

    result_box = box_value.bind(lambda _: MonetException('Error'))
    assert result_box == MonetException('Error')


# Generated at 2022-06-21 18:56:49.820068
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 18:56:51.174660
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:56:54.267970
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try_from_box = Box(1).to_try()

    assert try_from_box == Try(1, is_success=True)



# Generated at 2022-06-21 18:56:57.436389
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    def add_five(x: int) -> int:
        return 5 + x

    result = Box(add_five).ap(Box(5))

    assert result == Box(10)


# Generated at 2022-06-21 18:57:00.754358
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    :returns: True if test passed successfully and False if not
    :rtype: bool
    """
    from pymonet.validation import Validation

    value = 1
    box = Box(value)
    validation = box.to_validation()

    return isinstance(validation, Validation) and validation.value == value

# Generated at 2022-06-21 18:57:03.492480
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box("foo").to_validation() == Validation.success("foo")


# Generated at 2022-06-21 18:57:07.190334
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    def f():
        return Box(3)
    box = f()
    assert box.to_try() == Try.pure(3)

# Generated at 2022-06-21 18:57:09.828384
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 18:57:14.349548
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    import pytest

    box = Box(1)
    lazy = box.to_lazy()
    assert lazy.eval() == 1
    # test immutability
    assert box.value == 1
    assert lazy.value == box.value



# Generated at 2022-06-21 18:57:16.931534
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert_that(Box('1').to_try(), equal_to(Try('1', is_success=True)))



# Generated at 2022-06-21 18:57:18.705854
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(5)) == 'Box[value=5]'

# Unit tests for method map of class Box

# Generated at 2022-06-21 18:57:24.863625
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test that correctly apply from Box applicative to Box function

    :returns: true if test passed, otherwise false
    :rtype: bool
    """
    box_value = Box(10)
    box_add_one = Box(lambda x: x + 1)
    return box_value.ap(box_add_one) == Box(11)


# Generated at 2022-06-21 18:57:31.611380
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for bind method of Box class.
    """
    from pymonet.monad_try import Try

    def mapper(value):
        return value ** 2

    assert Box(4).bind(mapper) == 16
    assert (Box(4) >> mapper).value == 16
    assert Box(4).bind(lambda value: Try(value)).value.value == 4

# Generated at 2022-06-21 18:57:33.424873
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 18:57:36.339256
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-21 18:57:38.221008
# Unit test for method ap of class Box
def test_Box_ap():

    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)



# Generated at 2022-06-21 18:57:40.854731
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of Box.
    """
    assert Box(lambda x: x ** 2).ap(Box(3)) == Box(9)


# Generated at 2022-06-21 18:57:49.002330
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy, thunk_evaluator

    assert Box(10).to_lazy() == Lazy(lambda: 10)
    assert thunk_evaluator(Box(10).to_lazy()) == 10
    assert thunk_evaluator(Box(10).to_lazy().map(lambda x: x + 10)) == 20



# Generated at 2022-06-21 18:57:51.970056
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box_value = Box(1)
    validation = Validation.success(1)

    assert box_value.to_validation() == validation



# Generated at 2022-06-21 18:57:54.704732
# Unit test for method to_try of class Box
def test_Box_to_try():
    # Given
    from pymonet.monad_try import Try

    # When
    try_ = Box(1).to_try()

    # Then
    assert type(try_) == Try
    assert try_.is_success
    assert try_.get() == 1

# Generated at 2022-06-21 18:57:58.302602
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('abc').map(lambda x: 'B' + x) == Box('Babc')



# Generated at 2022-06-21 18:58:02.526677
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Test to_validation method of class Box.

    :returns: nothing
    :rtype: None
    """
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:58:04.433256
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert not (Box(2) == Box(3))



# Generated at 2022-06-21 18:58:13.324986
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test case for functional to_maybe

    Modules used:
        - pymonet.box: Box class definition
        - pymonet.maybe: Maybe class definition
        - pymonet.utils: is_nothing method definition
        - pymonet.utils: is_just method definition
        - pymonet.utils: just_value method definition

    TESTS:
        - box: Box
        - maybe: Just
        - is_just(maybe) == True
        - is_nothing(maybe) == False
        - just_value(maybe) == 'value'

    """
    # Modules
    from pymonet.maybe import Maybe
    from pymonet.utils import is_just, is_nothing, just_value

    # Test data
    box = Box('value')
    maybe = box.to_maybe()

   

# Generated at 2022-06-21 18:58:16.481279
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 18:58:19.460143
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    import pytest

    assert Box(42).to_validation() == Validation.success(42)
    assert Box(42).to_validation() == Validation(True, 42, [])



# Generated at 2022-06-21 18:58:21.937575
# Unit test for method __str__ of class Box
def test_Box___str__():
    from pymonet.monad_identity import Identity

    assert Identity(1).__str__() == "Identity[value=1]"



# Generated at 2022-06-21 18:58:26.089580
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(10).to_try() == Try(10, is_success=True), 'Box is transformed to Try without exceptions'

# Generated at 2022-06-21 18:58:30.714460
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.either import Left
    from pymonet.validation import Validation

    def f(x: int) -> int:
        return x + 1

    applicative_b = Box(f)
    assert applicative_b.ap(Box(5)) == Box(6)
    assert applicative_b.ap(Left(5)) == Box(f)
    assert applicative_b.ap(Validation.success(5)) == Box(6)



# Generated at 2022-06-21 18:58:33.009873
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.validation import Validation

    def f(x): return x + 3

    assert Box(f).ap(Validation.success(4)).value == 7



# Generated at 2022-06-21 18:58:42.153040
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """Unit test for method __eq__ of class Box
    """
    assert Box(1) == Box(1)
    assert Box(2) != Box(1)
    assert Box('1') == Box('1')
    assert Box('2') != Box('1')
    assert Box([1, 2]) == Box([1, 2])
    assert Box([1, 2]) != Box([1, 2, 3])
    assert Box({1: 2}) == Box({1: 2})
    assert Box({1: 2}) != Box({1: 2, 2: 3})



# Generated at 2022-06-21 18:58:44.971671
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box('2') == Box('2')
    assert Box('2') != Box(2)



# Generated at 2022-06-21 18:58:47.428660
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad import Id

    assert Validation.success(Id(3)) == Box(3).to_validation()


# Generated at 2022-06-21 18:58:54.817703
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(True) == Box(True) is True
    assert Box(False) == Box(False) is True
    assert Box(0) == Box(0) is True
    assert Box(1) == Box(1) is True
    assert Box(1.0) == Box(1.0) is True
    assert Box(1.0) == Box(2.0) is False

    assert Box('1') == Box('1') is True
    assert Box('1') == Box('2') is False

    assert Box([]) == Box([]) is True
    assert Box([]) == Box([1.0]) is False

    assert Box({}) == Box({}) is True
    assert Box({}) == Box({1.0}) is False



# Generated at 2022-06-21 18:58:56.010946
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda x: x * 5) == 50


# Generated at 2022-06-21 18:59:01.171367
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    box = Box(1)
    assert box.to_try() == Try(1, is_success=True)
    box = Box("test")
    assert box.to_try() == Try("test", is_success=True)


# Generated at 2022-06-21 18:59:02.563454
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'


# Generated at 2022-06-21 18:59:11.510564
# Unit test for method ap of class Box
def test_Box_ap():
    """
    JSON is a language-independent data format. It was derived from JavaScript, but as of 2017 many
    programming languages include code to generate and parse JSON-format data. The official Internet
    media type for JSON is application/json. JSON filenames use the extension .json.
    """
    from pymonet import Box, BoxBuilder


# Generated at 2022-06-21 18:59:13.892978
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(1)
    assert box.bind(lambda x: x + 1) == 2

# Generated at 2022-06-21 18:59:15.789768
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box("foo").to_lazy().value() == "foo"


# Generated at 2022-06-21 18:59:18.247445
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None


# Generated at 2022-06-21 18:59:24.277340
# Unit test for method map of class Box
def test_Box_map():
    """
    Test method map for class Box.
    """
    source_box = Box(1)
    assert source_box.map(lambda x: x + 1) == Box(2)
    assert source_box.map(lambda x: x * 2) == Box(2)
    assert source_box.map(str) == Box("1")
    assert source_box.map(lambda x: (x, x)) == Box((1, 1))

# Generated at 2022-06-21 18:59:25.244971
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(42)) == 'Box[value=42]'


# Generated at 2022-06-21 18:59:27.090894
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(10).to_either() == Right(10)


# Generated at 2022-06-21 18:59:33.434659
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('1') == Box('1')
    assert Box(['1']) == Box(['1'])

    assert Box(1) != Box(2)
    assert Box('1') != Box('2')
    assert Box(['1']) != Box(['2'])
    assert Box(1) != '1'
    assert Box('1') != 1


# Generated at 2022-06-21 18:59:35.239621
# Unit test for method to_validation of class Box
def test_Box_to_validation():

    assert Box("Hello world").to_validation().value == "Hello world"


# Generated at 2022-06-21 18:59:36.818758
# Unit test for constructor of class Box
def test_Box():
    assert Box(5) == Box(5)


# Generated at 2022-06-21 18:59:45.117853
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    result = Box(1).to_try()
    assert isinstance(result, Try)
    assert result.is_success()
    assert result.get() == 1



# Generated at 2022-06-21 18:59:52.335578
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.monad_list import List
    from pymonet.monad_maybe import Maybe

    assert Box(lambda x: x * 2).to_list().ap(List([1, 2, 3])).value == [1, 2, 2, 4, 6]
    assert Box(lambda x: x * 2).to_maybe().ap(Maybe(2)).value == 4
    assert Box(lambda x: x * 2).ap(Maybe(None)).value == List([])
    assert Box(lambda x: x * 2).ap(List([])).value == List([])

# Generated at 2022-06-21 18:59:53.758498
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x ** 2).ap(Box(5)) == Box(25)

# Generated at 2022-06-21 18:59:55.358649
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box = Box(1)

    assert box.to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:59:58.704267
# Unit test for method ap of class Box
def test_Box_ap():
    # Given
    box = Box(lambda x: x + 1)
    box2 = Box(2)

    # When
    result = box.ap(box2)

    # Then
    assert isinstance(result, Box)
    assert result.value == 3



# Generated at 2022-06-21 19:00:01.360510
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(2)
    result = box.bind(lambda x: x * 2)
    assert result == 4



# Generated at 2022-06-21 19:00:03.880675
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """

    assert Box(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-21 19:00:06.344506
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Just test for Box.to_either method
    """
    from pymonet.either import Left

    assert Box(5).to_either() == Left(5)

# Generated at 2022-06-21 19:00:07.674102
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x * 2) == 4


# Generated at 2022-06-21 19:00:12.345988
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    lazy_value = Lazy(lambda: 'lazy value')
    success_try_value = Try('success value', is_success=True)
    success_validation_value = Validation.success('validation value')

    assert Box('box value').to_lazy() == Lazy(lambda: 'box value')
    assert Box('box value').to_maybe() == Maybe.just('box value')
    assert Box('box value').to_either() == Either.left('box value')
    assert Box('box value').to_try() == Try('box value', is_success=True)

# Generated at 2022-06-21 19:00:24.761495
# Unit test for method map of class Box
def test_Box_map():
    assert Box("1").map(lambda x: x + "2") == Box("12")


# Generated at 2022-06-21 19:00:26.768134
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 19:00:28.261390
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:00:32.301550
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test case for to_either method of Box class.

    Tested method should transform current Box into either with previous value and Right type.

    Test success if result matches expected.
    """
    original_value = 1
    box = Box(original_value)

    result = box.to_either()

    assert isinstance(result, Right)
    assert result.success_value() == original_value



# Generated at 2022-06-21 19:00:36.934082
# Unit test for method ap of class Box
def test_Box_ap():
    # GIVEN
    box = Box(1)
    applicative = Box(lambda x: x**2)

    # WHEN
    result = box.ap(applicative)

    # THEN
    assert result.value == 1**2



# Generated at 2022-06-21 19:00:39.181024
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Test for Box.__str__ method

    :return: Nothing
    :rtype: None
    """
    assert str(Box(5)) == "Box[value=5]"



# Generated at 2022-06-21 19:00:46.320810
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box
    """

    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('test')) == 'Box[value=test]'
    assert str(Box({1, 2, 3})) == 'Box[value={1, 2, 3}]'
    assert str(Box(lambda x: x)) == 'Box[value=<function <lambda> at 0x000001BCE2C1EF28>]'
    assert str(Box(None)) == 'Box[value=None]'


# Generated at 2022-06-21 19:00:49.926102
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(1)
    result = box.to_validation()

    expected = Validation(1, [])
    assert result == expected

# Generated at 2022-06-21 19:00:53.373581
# Unit test for method ap of class Box
def test_Box_ap():
    def add(a):
        def add_b(b):
            return a + b
        return add_b

    b1 = Box(10)
    b2 = Box(add)

    assert b1.ap(b2) == Box(20)

# Generated at 2022-06-21 19:00:55.461095
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().evaluate() == 1

# Generated at 2022-06-21 19:01:21.283361
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Tests method bind of class Box

    :returns: nothing

    >>> test = Box(1)
    >>> test.bind(lambda x: x)
    1
    """


# Generated at 2022-06-21 19:01:24.333094
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('string')) == 'Box[value=string]'



# Generated at 2022-06-21 19:01:25.660030
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)

# Generated at 2022-06-21 19:01:26.850967
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:01:32.340071
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    def _eq_test(v1: T, v2: T) -> bool:
        return Box(v1) == Box(v2)

    assert _eq_test(1, 1) == True
    assert _eq_test(1, 2) == False
    assert _eq_test([1], [1]) == True
    assert _eq_test([1], [2]) == False
    assert _eq_test({"a": 1}, {"a": 1}) == True
    assert _eq_test({"a": 1}, {"a": 2}) == False
    assert _eq_test('str', 'str') == True
    assert _eq_test('str', 'str2') == False
    assert _eq_test(None, None) == True
    assert _eq_test(None, "") == False


# Generated at 2022-06-21 19:01:35.728989
# Unit test for method to_try of class Box
def test_Box_to_try():
    # GIVEN
    from pymonet.monad_try import Try

    # WHEN
    actual = Box(42).to_try()

    # THEN
    assert isinstance(actual, Try)
    assert actual.value == 42



# Generated at 2022-06-21 19:01:37.728290
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:01:39.324517
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    addition_to_box = lambda x: x + 3
    box_with_function = Box(addition_to_box)
    box_with_number = Box(3)
    res = box_with_number.ap(box_with_function)
    assert res == Box(6)

# Generated at 2022-06-21 19:01:42.084732
# Unit test for constructor of class Box
def test_Box():
    from pymonet.monad_maybe import Maybe

    box = Box[Maybe](Maybe.just(10))
    assert box.value.value == 10



# Generated at 2022-06-21 19:01:44.073959
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 19:02:09.558794
# Unit test for method map of class Box
def test_Box_map():
    def mapper(value: int) -> int:
        return value + 1
    assert Box(1).map(mapper) == Box(2)


# Generated at 2022-06-21 19:02:10.813561
# Unit test for constructor of class Box
def test_Box():
    one = Box(1)
    assert 1 == one.value



# Generated at 2022-06-21 19:02:13.876950
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    value = Try(1, is_success=True)

    assert Box(1).to_try() == value

# Generated at 2022-06-21 19:02:19.595625
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    actual_1 = Box(10).to_try()
    expected_1 = Try(10, is_success=True)
    assert actual_1 == expected_1

    actual_2 = Box('abc').to_try()
    expected_2 = Try('abc', is_success=True)
    assert actual_2 == expected_2

    actual_3 = Box({1, 2, 3}).to_try()
    expected_3 = Try({1, 2, 3}, is_success=True)
    assert actual_3 == expected_3

# Generated at 2022-06-21 19:02:24.892453
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda v: v + 1) == Box(3)
    assert Box(3).bind(lambda v: v + 2) == Box(5)
    assert Box(4).bind(lambda v: v + 3) == Box(7)



# Generated at 2022-06-21 19:02:29.167828
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for Box.ap method
    """
    input_box = Box(lambda x: x + 1)
    input_result_box = Box(2)

    result = input_box.ap(input_result_box)

    assert result == Box(3)


# Generated at 2022-06-21 19:02:32.288879
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left

    right_box = Box(10)
    left_box = Box(None)
    assert right_box.to_either() == Right(10)
    assert left_box.to_either() == Right(None)



# Generated at 2022-06-21 19:02:36.645432
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('Hello, World!')) == 'Box[value=Hello, World!]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box(Box(None))) == 'Box[value=Box[value=None]]'
    assert str(Box(Box([1, 2, 3, 4]))) == 'Box[value=Box[value=[1, 2, 3, 4]]]'



# Generated at 2022-06-21 19:02:42.993719
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test Box.to_maybe

    :return: None
    """

    def test_case_success():
        from pymonet.maybe import Maybe

        assert Maybe.just(42).to_box() == Box(42)

    def test_case_failure():
        from pymonet.maybe import Maybe

        assert Maybe.nothing().to_box() is not Box(None)

    test_case_success()
    test_case_failure()


# Generated at 2022-06-21 19:02:47.822403
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    assert Box(1) == Box(1)
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box(2)
    assert Box(1) != 2
    assert Box(1) != 2
    assert 1 != Box(2)
    assert 1 != Box(2)



# Generated at 2022-06-21 19:03:37.383573
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 19:03:40.929936
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Box(1).to_maybe()
    assert Box(None).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:03:43.189749
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:03:46.081962
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)

    unit_test_assert(box.to_maybe(), Maybe.just(1))



# Generated at 2022-06-21 19:03:49.298604
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box('a') != Box('b')



# Generated at 2022-06-21 19:03:51.771627
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    maybe = box.to_maybe()
    assert isinstance(maybe, Maybe)
    assert maybe.is_just()
    assert maybe.value == 1


# Generated at 2022-06-21 19:04:03.178962
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either, Left, Right
    from pymonet.validation import Validation

    assert Box(1).to_either() == Right(1)
    assert Box(Validation.success(1)).to_either() == Right(Validation.success(1))
    assert Box(Validation.success(1)).to_validation() == Validation.success(Validation.success(1))
    assert Box(Validation.failure(['Failed'])) == Box(Validation.failure(['Failed']))
    assert Box(Validation.failure(['Failed'])).to_either() == Right(Validation.failure(['Failed']))

# Generated at 2022-06-21 19:04:04.931039
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right as wrap

    assert Box(1).to_either() == wrap(1)



# Generated at 2022-06-21 19:04:09.227504
# Unit test for method bind of class Box
def test_Box_bind():
    # Arrange
    source_box = Box(5)
    mapper = lambda value: value - 1

    # Act
    result_box = source_box.bind(mapper)

    # Assert
    assert result_box == 4


# Generated at 2022-06-21 19:04:13.302426
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Just

    box_1 = Box(2)
    box_2 = Box(lambda x: x * 2)
    result = box_1.ap(box_2)
    assert result == Box(4)

    result = box_2.ap(box_1)
    assert result == Box(4)
    assert box_1.ap(Just(lambda x: x * 2)) == Just(4)