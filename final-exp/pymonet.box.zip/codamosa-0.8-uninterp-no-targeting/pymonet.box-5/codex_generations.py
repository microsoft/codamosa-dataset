

# Generated at 2022-06-21 18:54:56.430023
# Unit test for method map of class Box
def test_Box_map():
    assert isinstance(Box(1).map(lambda x: x + 1), Box)
    assert Box(3).map(lambda x: x + 1) == Box(4)
    assert Box('Hello').map(lambda x: x.lower()) == Box('hello')


# Generated at 2022-06-21 18:55:02.933179
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box([1, 2, 3]).to_try() == Try([1, 2, 3], is_success=True)
    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(None).to_try() == Try(None, is_success=True)
    assert Box(Exception).to_try() == Try(Exception, is_success=True)


# Generated at 2022-06-21 18:55:05.109599
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(2).to_validation() == Validation.success(2)

# Generated at 2022-06-21 18:55:08.806586
# Unit test for method to_either of class Box
def test_Box_to_either():
    first_box = Box(1)
    second_box = Box('test')
    third_box = Box(True)

    assert first_box.to_either().value == 1
    assert second_box.to_either().value == 'test'
    assert third_box.to_either().value is True



# Generated at 2022-06-21 18:55:13.501422
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(3) == Box(3)
    assert Box('hello') == Box('hello')
    assert Box(None) == Box(None)
    assert Box(False) == Box(False)


# Generated at 2022-06-21 18:55:22.621329
# Unit test for method bind of class Box
def test_Box_bind():
    from pytest import raises

    # Case 1
    assert Box(1).bind(lambda x: Box(x + 1)) == Box(2)

    # Case 2
    assert Box(1).bind(lambda x: Box(x + 2)) == Box(3)

    # Case 3
    with raises(TypeError):
        assert Box("1").bind(lambda x: Box(x + 2)) == Box("3")

    # Case 4
    with raises(TypeError):
        assert Box(1).bind(lambda x: Box("2")) == Box("2")

    # Case 5
    assert Box(1).bind(lambda x: Box("2")) == Box("2")

    # Case 6
    assert Box("1").bind(lambda x: Box("2")) == Box("2")

    # Case 7

# Generated at 2022-06-21 18:55:26.030668
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.either import Right
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 18:55:28.356914
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-21 18:55:29.912965
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda a: a + 1).ap(Box(5)) == Box(6)

# Generated at 2022-06-21 18:55:32.225761
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:55:37.809661
# Unit test for method bind of class Box
def test_Box_bind():
    def square(x):
        return x * x

    assert Box(2).bind(square) == 4

# Generated at 2022-06-21 18:55:43.703026
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    """
    Test of method str of class Box
    """
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box('10')) == 'Box[value=10]'


# Test for method __eq__ of class Box

# Generated at 2022-06-21 18:55:45.594038
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet import Lazy
    assert Box(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-21 18:55:47.846153
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x+1) == Box(2)


# Generated at 2022-06-21 18:55:50.713342
# Unit test for constructor of class Box
def test_Box():
    b = Box(1)
    assert b.value is 1
    assert str(b) == 'Box[value=1]'


# Unit tests for Box.map function

# Generated at 2022-06-21 18:55:52.232024
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-21 18:55:59.759529
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    box = Box(Maybe.just(1))
    assert box.to_maybe() == Maybe.just(Maybe.just(1))
    assert box.to_maybe().bind(lambda m: m) == Maybe.just(1)

    box = Box(Maybe.nothing())
    assert box.to_maybe() == Maybe.just(Maybe.nothing())
    assert box.to_maybe().bind(lambda m: m) == Maybe.nothing()


# Generated at 2022-06-21 18:56:02.908289
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Arrange
    expected = True
    # Act
    result = Box(1) == Box(1)
    # Assert
    assert result == expected


# Generated at 2022-06-21 18:56:05.086343
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(True).to_try() == Try(True, is_success=True)

# Generated at 2022-06-21 18:56:11.184080
# Unit test for method __str__ of class Box
def test_Box___str__():
    numb_box = Box(1)
    assert str(numb_box) == 'Box[value=1]'

    string_box = Box('1')
    assert str(string_box) == 'Box[value=1]'

    bool_box = Box(True)
    assert str(bool_box) == 'Box[value=True]'



# Generated at 2022-06-21 18:56:15.568904
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:56:17.440888
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)



# Generated at 2022-06-21 18:56:20.814119
# Unit test for method bind of class Box
def test_Box_bind():
    # Given
    def mapper(value: str) -> int:
        return len(value)

    # When
    box = Box('test')
    result = box.bind(mapper)

    # Then
    assert result == 4


# Generated at 2022-06-21 18:56:24.051045
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == None)



# Generated at 2022-06-21 18:56:25.603487
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Unit test for method to_lazy of class Box.

    :returns: Nothing
    :rtype: Nothing
    """
    assert Box(42).to_lazy().run() == 42



# Generated at 2022-06-21 18:56:28.177442
# Unit test for method bind of class Box
def test_Box_bind():
    result = Box(1)\
        .bind(lambda x: Box(x + 1))\
        .bind(lambda x: Box(x + 1))\
        .bind(lambda x: Box(x + 1))\
        .bind(lambda x: Box(x + 1))\
        .bind(lambda x: Box(x + 1))
    assert result == Box(6)


# Generated at 2022-06-21 18:56:30.689311
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


test_Box___eq__()



# Generated at 2022-06-21 18:56:32.385064
# Unit test for method ap of class Box
def test_Box_ap():
    """Test Box.ap method."""
    assert Box(lambda x: x * 2).ap(Box(2)).value == 4

# Generated at 2022-06-21 18:56:35.552997
# Unit test for method ap of class Box
def test_Box_ap():
    from nose.tools import assert_equal, assert_is_instance

    box = Box(lambda x: x ** 2)
    result = box.ap(Box(3))

    assert_is_instance(result, Box)
    assert_equal(result.value, 9)

# Generated at 2022-06-21 18:56:36.888980
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(2).to_validation() == Box(2).bind(Box.to_validation)


# Generated at 2022-06-21 18:56:42.295416
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(5).to_try() == Success(5)


# Generated at 2022-06-21 18:56:44.770235
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 18:56:46.044661
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == 1


# Generated at 2022-06-21 18:56:50.871526
# Unit test for method bind of class Box
def test_Box_bind():
    # Check bind functionality
    result_box = Box(5).bind(lambda val: Box(val + 3))
    assert isinstance(result_box, Box)
    assert result_box == Box(8)

    # Check bind with lambda function
    result_box = Box(5).bind(lambda val: val + 3)
    assert isinstance(result_box, int)
    assert result_box == 8



# Generated at 2022-06-21 18:56:53.214167
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Validation.success("Hello") == Box("Hello").to_validation()

# Generated at 2022-06-21 18:56:54.916575
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))



# Generated at 2022-06-21 18:56:56.825497
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 18:56:58.251071
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(10).bind(lambda x: x * 2) == 20



# Generated at 2022-06-21 18:56:59.858510
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation(1, [])

# Unit test to check using Box as pure function

# Generated at 2022-06-21 18:57:01.751140
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 3) == Box(6)



# Generated at 2022-06-21 18:57:09.128961
# Unit test for method map of class Box
def test_Box_map():
    box = Box(2)
    new_box = box.map(lambda x: x * 2)
    assert new_box == Box(4)


# Generated at 2022-06-21 18:57:11.111244
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad import Box

    assert Box(1).to_try().get() == 1


# Generated at 2022-06-21 18:57:13.695303
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    box = Box(0)
    assert box.to_lazy() == Lazy(lambda:0)

# Generated at 2022-06-21 18:57:16.403830
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(100).to_maybe() == Maybe.just(100)



# Generated at 2022-06-21 18:57:18.568785
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    box = Box(5)
    assert box.bind(lambda x: x + 1) == 6



# Generated at 2022-06-21 18:57:23.039893
# Unit test for method map of class Box
def test_Box_map():
    assert Box(lambda value: value * 2).map(lambda adder: adder(2)) == Box(4)
    assert Box(lambda value: value * 2).map(lambda adder: adder(3)) == Box(6)


# Generated at 2022-06-21 18:57:31.181424
# Unit test for method to_either of class Box
def test_Box_to_either():
    def calculate(number):
        if number == 0:
            raise ZeroDivisionError('Division by zero')

        return Box(5 / number)

    assert Box(0).to_either().is_left()
    assert Box(0).to_either().fold(lambda _: True, lambda _: False)
    assert calculate(5).to_either().is_right()
    assert calculate(5).to_either().fold(lambda _: False, lambda _: True)
    assert calculate(5).to_either().get_value() == 1
    assert calculate(0).to_either().get_value() == None


# Generated at 2022-06-21 18:57:33.000716
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda a: a + 1).ap(Box(3)).value == 4

# Generated at 2022-06-21 18:57:41.575841
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)
    assert Box('1').to_either() == Right('1')
    assert Box([1]).to_either() == Right([1])
    assert Box((1, 2, 3)).to_either() == Right((1, 2, 3))
    assert Box({'one': 1}).to_either() == Right({'one': 1})
    assert Box(set([1, 2, 3])).to_either() == Right(set([1, 2, 3]))
    assert Box(1.0).to_either() == Right(1.0)


# Generated at 2022-06-21 18:57:43.588406
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 18:57:56.756284
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    x = Box("test")
    y = x.to_validation()

    assert isinstance(y, Validation)
    assert y.is_success is True
    assert y.value == x.value



# Generated at 2022-06-21 18:58:00.170421
# Unit test for method ap of class Box
def test_Box_ap():
    m = Box(lambda x: x + 1)
    mx = m.ap(Box(2))
    assert mx.value == 3



# Generated at 2022-06-21 18:58:03.540561
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    box = Box(5)
    try_ = box.to_try()
    assert isinstance(try_, Try)
    assert try_.is_success()
    assert try_.get_value() == 5

# Generated at 2022-06-21 18:58:12.791354
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10) == Box.unit(10)
    assert Box(10) == Box(10)
    assert Box(Box(10).value + 10) == Box(10).map(lambda x: x + 10)
    assert Box(11) == Box(10).bind(lambda x: Box(x + 1))
    assert Box(10) == Lazy(lambda: Box(10)).force()
    assert 10 == Box(10).value
    assert Lazy(lambda: 11) == Box(10).to_lazy().map(lambda x: x + 1)
    assert Lazy(lambda: Box(11)) == Box(10).to_lazy().map(lambda x: Box(x + 1))
    assert Box(10) == Box(10).to_maybe()

# Generated at 2022-06-21 18:58:16.530374
# Unit test for method ap of class Box
def test_Box_ap():
    def func_for_ap(x):
        return x * 2

    box_with_function = Box(func_for_ap)

    assert box_with_function.ap(Box(2)) == Box(4)

# Generated at 2022-06-21 18:58:22.142663
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box.
    """
    from .lazy import Lazy

    assert Box(2) == Box(2)
    assert Box(2) != Box(3)
    assert Box(Lazy(lambda: 2)) == Box(Lazy(lambda: 2))
    assert Box(Lazy(lambda: 2)) != Box(Lazy(lambda: 3))



# Generated at 2022-06-21 18:58:26.516426
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Test to_lazy method of Box.
    """
    box = Box(5)
    lazy = box.to_lazy()
    assert lazy.is_folded() is False
    assert lazy.value() == 5


# Generated at 2022-06-21 18:58:28.392069
# Unit test for method to_try of class Box
def test_Box_to_try():
    # Box.to_try()
    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 18:58:30.726523
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 18:58:34.777038
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.either import Left
    from pymonet.try_ import Failure

    assert Box(lambda x: x + 1).ap(Box(2)).value == 3
    assert Box(lambda x: x + 1).ap(Left('Test')).value == 'Test'
    assert Box(lambda x: x + 1).ap(Failure('Test')).failure == 'Test'

# Generated at 2022-06-21 18:58:55.808982
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(42).to_validation() == Validation.success(42)

# Generated at 2022-06-21 18:58:57.041671
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:58:59.351130
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy().run() == 1


# Generated at 2022-06-21 18:59:02.378749
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)


# Generated at 2022-06-21 18:59:04.802967
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit-tests for Box.to_validation() method.
    """
    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:59:06.335485
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    box = Box(2)
    result = box.map(lambda x: x + 2)
    assert result == Box(4)



# Generated at 2022-06-21 18:59:07.582538
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(1).to_either().equals(Right(1))


# Generated at 2022-06-21 18:59:09.677890
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either, Left, Right

    assert Box(1).to_either() == Either.right(1)

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:59:10.517165
# Unit test for constructor of class Box
def test_Box():
    assert Box('value') == Box('value')

# Generated at 2022-06-21 18:59:15.882300
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) == Box(1.0)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != 1.0



# Generated at 2022-06-21 18:59:38.418498
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(1).map(lambda x: x + 2) == Box(3)
    assert Box(1).map(lambda x: x + 3) == Box(4)


# Generated at 2022-06-21 18:59:41.865885
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(0)
    assert Box(True) == Box(True)
    assert Box('Hello World') == Box('Hello World')
    assert Box(12.0) == Box(12.0)



# Generated at 2022-06-21 18:59:43.274090
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(add(2)) == Box(3)



# Generated at 2022-06-21 18:59:45.242937
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(42).to_maybe() == Maybe.just(42)


# Generated at 2022-06-21 18:59:47.719822
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != Box('3')
    assert Box(3) != 3
    assert Box(3) != '3'


# Generated at 2022-06-21 18:59:50.244753
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(1234) == Box(1234).to_either()


# Generated at 2022-06-21 18:59:51.224531
# Unit test for constructor of class Box
def test_Box():
    assert Box(10).value == 10


# Generated at 2022-06-21 18:59:53.552370
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    def square(number: int) -> int:
        return number * number

    assert Box(3).bind(square) == 9



# Generated at 2022-06-21 18:59:55.477654
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-21 18:59:56.715795
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-21 19:00:19.168656
# Unit test for method to_try of class Box
def test_Box_to_try():
    box = Box('test')

    expected = box.to_try()
    actual = Try('test', is_success=True)

    assert expected == actual

# Generated at 2022-06-21 19:00:20.675855
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('1') == Box('1')
    assert Box('1') != Box('2')

# Generated at 2022-06-21 19:00:24.575545
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)



# Generated at 2022-06-21 19:00:26.586082
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('value').bind(lambda x: x + '1') == 'value1'



# Generated at 2022-06-21 19:00:33.364834
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    # pylint: disable=unused-variable
    from pymonet.validation import Validation

    @pytest.fixture
    def test_number() -> int:
        return 42

    @pytest.fixture
    def box_number(test_number: int) -> Box:
        return Box(test_number)

    @pytest.fixture
    def validation_number(box_number: Box) -> Validation:
        return box_number.to_validation()

    def test_validation_number_is_success(validation_number: Validation):
        assert validation_number.is_success

    def test_validation_number_value(validation_number: Validation):
        assert validation_number.value == 42

# Generated at 2022-06-21 19:00:38.965258
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import raise_if

    value = 10
    box = Box(value)

    try_monad = box.to_try()

    assert isinstance(try_monad, Try)
    assert try_monad.value == value
    assert try_monad.is_success


# Generated at 2022-06-21 19:00:40.806325
# Unit test for method ap of class Box
def test_Box_ap():
    box = Box(lambda x: x * 2)
    assert box.ap(Box(2)) == Box(4)



# Generated at 2022-06-21 19:00:43.705073
# Unit test for method to_try of class Box
def test_Box_to_try():
    import pytest

    from pymonet.monad_try import Try

    assert Box(10.0).to_try() == Try(10.0, is_success=True)



# Generated at 2022-06-21 19:00:52.424511
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    assert Box(10).to_maybe() == Maybe(10)
    assert Box(None).to_maybe() == Maybe(None)
    assert Box('abc').to_maybe() == Maybe('abc')
    assert Box([]).to_maybe() == Maybe([])
    assert Box({}).to_maybe() == Maybe({})
    assert Box(Just(10).map(lambda a: a*2)).to_maybe() == Just(20)
    assert Box(10).to_maybe() != Maybe(20)
    assert Box(Nothing).to_maybe() == Nothing


# Generated at 2022-06-21 19:00:56.168856
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(5) == Box(5)
    assert Box(5) != Box(6)
    assert Box(5) != Box('5')


# Generated at 2022-06-21 19:01:25.660043
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing
    from pymonet.lazy import Lazy

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(Nothing()).to_maybe() == Maybe.nothing()
    assert Box(Lazy(lambda: 1)).to_maybe() == Maybe.just(1)
    assert Box(Lazy(lambda: Nothing())).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:01:28.086148
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    """
    Test that Box to_either method function correctly
    """
    box = Box(1)
    assert box.to_either() == box.value


# Generated at 2022-06-21 19:01:30.484508
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(42).to_maybe() == Maybe.just(42)



# Generated at 2022-06-21 19:01:37.806422
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Box(lambda x: x + 1).ap(Box("abc")) == Box("abc1")
    assert Box("abc").ap(Box("def")) == Box("abcdef")
    assert Box(1).ap(Box([2, 3, 4])) == Box([2, 3, 4, 1])
    assert Box([2, 3, 4]).ap(Box(1)) == Box([2, 3, 4, 1])

# Generated at 2022-06-21 19:01:39.764784
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    assert box.to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 19:01:43.954290
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(2).bind(lambda x: x ** 2) == 4
    assert Box(1).bind(lambda x: x * 10) == 10



# Generated at 2022-06-21 19:01:47.391188
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(7)) == 'Box[value=7]'
    assert str(Box('abc')) == 'Box[value=abc]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(None)) == 'Box[value=None]'



# Generated at 2022-06-21 19:01:48.324905
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)


# Generated at 2022-06-21 19:01:49.426464
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(2).to_lazy().fold() == 2

# Generated at 2022-06-21 19:01:56.223149
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)
    assert Box("String").to_either() == Right("String")
    assert Box(["a", "b", "c"]).to_either() == Right(['a', 'b', 'c'])
    assert Box(("a", "b", "c")).to_either() == Right(('a', 'b', 'c'))
    assert Box({"a": "b"}).to_either() == Right({'a': 'b'})
    assert Box({"a": "b", "c": "d"}).to_either() == Right({'a': 'b', 'c': 'd'})


# Generated at 2022-06-21 19:02:47.066051
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    """
    Unit test for method to_maybe of class Box
    """
    from pymonet.maybe import Maybe

    assert Box(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-21 19:02:49.927606
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(10).bind(lambda x: x + 1) == 11
    assert Box(10).bind(lambda x: x - 1) == 9


# Generated at 2022-06-21 19:02:51.128269
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('test')) == 'Box[value=test]'



# Generated at 2022-06-21 19:02:52.740104
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: Box(x + 2)) == Box(3)



# Generated at 2022-06-21 19:02:54.235355
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(5).to_either() == Right(5)



# Generated at 2022-06-21 19:02:56.253034
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(123).to_either() == Box(123).to_either()

    assert Box(123).to_either() != Box('123').to_either()



# Generated at 2022-06-21 19:02:58.194793
# Unit test for constructor of class Box
def test_Box():
    assert Box(3) == Box(3)
    assert isinstance(Box(3), Box)

# Unit tests for map method of Box class

# Generated at 2022-06-21 19:03:01.565242
# Unit test for method bind of class Box
def test_Box_bind():
    """
    All test cases for map method of class Box.
    """
    def func(value):
        return value + 1

    box = Box(1)

    assert box.bind(func) == 2

# Generated at 2022-06-21 19:03:04.969805
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # Given
    box_1 = Box(10)
    box_2 = Box(10)
    box_3 = Box(20)

    # When & Then
    assert box_1 == box_2
    assert not box_1 == box_3


# Generated at 2022-06-21 19:03:09.867753
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Lazy(lambda: 1) == Lazy(lambda: 1)
    assert Lazy(lambda: 1) != Lazy(lambda: 2)
    assert Lazy(lambda: 1) == Box(1).to_lazy()
    assert Lazy(lambda: 1) != Box(2).to_lazy()

# Generated at 2022-06-21 19:04:52.430329
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.list import List
    from pymonet.maybe import Maybe

    assert Box(inc).ap(List([1, 2, 3])) == List([2, 3, 4])
    assert Box(inc).ap(Maybe.just(1)) == Maybe.just(2)
    assert Box(inc).ap(Maybe.nothing()) == Maybe.nothing()
