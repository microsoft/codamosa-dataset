

# Generated at 2022-06-21 18:54:56.028187
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    maybe = box.to_maybe()
    assert maybe == Maybe.just(1)


# Generated at 2022-06-21 18:54:58.002711
# Unit test for constructor of class Box
def test_Box():
    box = Box(10)

    assert isinstance(box, Box)
    assert type(box) == Box


# Generated at 2022-06-21 18:55:02.667190
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left
    from pymonet.either import Right

    assert Left(2).to_either() == Right(Left(2))
    assert Box(3).to_either() != Left(3)


# Generated at 2022-06-21 18:55:04.475509
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 18:55:08.017588
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box('some value')
    validation = box.to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.get_value() == 'some value'



# Generated at 2022-06-21 18:55:09.618155
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(10) == Box(10).to_validation()



# Generated at 2022-06-21 18:55:14.034248
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1
    assert Box('foo').value == 'foo'
    assert Box([1]).value == [1]
    assert Box((1,)).value == (1,)



# Generated at 2022-06-21 18:55:15.244650
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:55:17.084736
# Unit test for method ap of class Box
def test_Box_ap():
    assert isinstance(Box(lambda a: a + 1).ap(Box(1)), Box)


# Generated at 2022-06-21 18:55:20.817709
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 18:55:27.612457
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try(1, is_success=True) == Box(1).to_try()



# Generated at 2022-06-21 18:55:36.696395
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_int import MonadInt
    from pymonet.monad_func import MonadFunc
    from pymonet.lazy import Lazy

    a = MonadInt(2)

    def f(x):
        return x * x

    func = MonadFunc(f)

    def g(x):
        if x == 4:
            return MonadInt(x)
        else:
            return MonadInt(-1)

    func_g = MonadFunc(g)
    lazy = Lazy(lambda: func.ap(a))

    assert g(lazy.value) == func_g.ap(a)



# Generated at 2022-06-21 18:55:40.403860
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(10)
    assert __str__(box) == "Box[value=10]"
    assert str(box) == "Box[value=10]"
    assert box.__str__() == "Box[value=10]"



# Generated at 2022-06-21 18:55:43.880584
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)


# Generated at 2022-06-21 18:55:45.746071
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Right(2).equals(Box(2).to_either())


# Generated at 2022-06-21 18:55:49.760323
# Unit test for method map of class Box
def test_Box_map():
    func = lambda x: x + 1

    assert Box(1).map(func) == Box(2)
    assert Box('1').map(func) == Box('11')
    assert Box([]).map(func) == Box([1])


# Generated at 2022-06-21 18:55:53.818066
# Unit test for method ap of class Box
def test_Box_ap():
    # - Given -
    box_before = Box(lambda x: x * 2)
    box_after = Box(10)

    # - When -
    result = box_before.ap(box_after)

    # - Then -
    assert result.value == 20

# Generated at 2022-06-21 18:55:58.492913
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 2).ap(Box(2)) == Box(4)
    assert Box(lambda x: x * 2).ap(Box(5)) == Box(10)
    assert Box(lambda x: x + 2).ap(Box(lambda x: x + 5)) == Box(2)


# Generated at 2022-06-21 18:56:00.789084
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    """
    Unit test for method to_either of class Box
    """
    # TODO: Write test
    assert True

# Generated at 2022-06-21 18:56:02.709985
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).bind(lambda x: 2 * x) == 10

# Generated at 2022-06-21 18:56:08.676394
# Unit test for method __str__ of class Box
def test_Box___str__():
    # Test if Box repr is ok
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:56:12.981696
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    # Given
    box = Box(1)

    # When
    maybe = box.to_maybe()

    # Then
    assert maybe == Maybe.just(1)



# Generated at 2022-06-21 18:56:14.621718
# Unit test for method bind of class Box
def test_Box_bind():
    def add(x):
        return x + 1

    assert Box(2).bind(add) == add(2)

# Generated at 2022-06-21 18:56:18.710268
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try(2, is_success=True) == Box(2).to_try()
    assert Try(Exception(), is_success=False) == Box(Exception()).to_try()



# Generated at 2022-06-21 18:56:21.088192
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_box() == Box.unit(1)

    assert Maybe.nothing().to_box() == Box.nothing()

# Generated at 2022-06-21 18:56:25.432695
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-21 18:56:28.749565
# Unit test for method ap of class Box
def test_Box_ap():
    # arrange
    box = Box(1)
    # act
    new_box = box.ap(Box(lambda x: x + 2))
    # assert
    assert new_box == Box(3)

# Generated at 2022-06-21 18:56:32.579977
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right, Either
    from pymonet.monad_try import Try

    assert Box(1).to_either() == Right(1)
    assert Box(1).to_either().is_right()
    assert Try(1, is_success=True).to_either() == Right(1)
    assert type(Box(1).to_either()) == Either
    assert type(Try(1, is_success=True).to_either()) == Either


# Generated at 2022-06-21 18:56:34.774484
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

    assert str(Box(1)) == 'Box[value=1]'

# Generated at 2022-06-21 18:56:37.039594
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:56:43.709140
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of Box class.
    """

    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:56:46.086096
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Maybe.just('Hello') == Box('Hello').to_maybe()


# Generated at 2022-06-21 18:56:49.303610
# Unit test for method ap of class Box
def test_Box_ap():
    # Arrange
    box = Box(lambda x: x * 2)
    box2 = Box(2)
    # Act
    result = box.ap(box2)
    # Assert
    assert result.value == 4


# Generated at 2022-06-21 18:56:52.374855
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box('hello').bind(lambda x: x[::-1]) == 'olleh'
    assert Box(100).bind(lambda x: str(x)) == '100'


# Generated at 2022-06-21 18:56:56.340831
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """

    # assert Box(5).to_validation() == Validation.success(5)

    assert Box(5).to_validation().to_box().value == 5

# Generated at 2022-06-21 18:56:57.511489
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'

# Generated at 2022-06-21 18:56:59.400112
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2



# Generated at 2022-06-21 18:57:01.700147
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    value = 3
    assert Box(value).to_maybe() == Maybe.just(value)


# Generated at 2022-06-21 18:57:06.329317
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.list import List

    box_value = Box(lambda x: x + 1)
    list_values = List(x for x in range(0, 5))
    result = box_value.ap(list_values)
    print(result)

# Generated at 2022-06-21 18:57:08.714095
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == 1

test_Box_to_maybe()



# Generated at 2022-06-21 18:57:25.162228
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(4)) == 'Box[value=4]'
    assert str(Box(1.1)) == 'Box[value=1.1]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box('text')) == 'Box[value=text]'
    assert str(Box({'a': 1, 'b': 2})) == "Box[value={'a': 1, 'b': 2}]"
    assert str(Box(['a', 1, 2])) == "Box[value=['a', 1, 2]]"


# Unit tests for method __eq__ of class Box

# Generated at 2022-06-21 18:57:27.223337
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(42).bind(lambda x: x * 2) == 84



# Generated at 2022-06-21 18:57:30.014160
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just('test').to_box() == Box('test')
    assert Maybe.nothing().to_box() != Box('test')



# Generated at 2022-06-21 18:57:31.791748
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:57:36.961610
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Testing to_lazy method of Box class

    Actual result: Box(1).to_lazy() -> Lazy(function returning 1)
    """
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-21 18:57:39.589054
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'
    assert str(Box('test')) == 'Box[value=test]'


# Generated at 2022-06-21 18:57:41.087337
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    actual = Box(1).to_lazy()
    expected = Lazy(lambda: 1)

    assert actual == expected

# Generated at 2022-06-21 18:57:42.830647
# Unit test for constructor of class Box
def test_Box():
    assert Box(10) == Box(10)
    assert str(Box('hello')) == 'Box[value=hello]'


# Generated at 2022-06-21 18:57:46.175322
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1)


# Generated at 2022-06-21 18:57:47.381365
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box('its-a-me, Mario').to_either() == Right('its-a-me, Mario')


# Generated at 2022-06-21 18:58:00.130231
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(10)) == 'Box[value=10]'

# Generated at 2022-06-21 18:58:01.824461
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(2).to_maybe() == Box(2).to_maybe()


# Generated at 2022-06-21 18:58:03.720702
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 2) == Box(4)


# Generated at 2022-06-21 18:58:07.221761
# Unit test for constructor of class Box
def test_Box():
    assert Box(100) == Box(100)
    assert Box('test') == Box('test')

    assert str(Box(100)) == 'Box[value=100]'
    assert str(Box('test')) == 'Box[value=test]'



# Generated at 2022-06-21 18:58:12.540475
# Unit test for method map of class Box
def test_Box_map():
    """
    Tests Box map method.

    :returns: None
    """
    def add3(x: int) -> int:
        """
        Function returns sum of argument and 3.

        :param x: integer to sum
        :type x: int
        :returns: sum of argument and 3
        :rtype: int
        """
        return x + 3

    assert Box(1).map(add3) == Box(4)



# Generated at 2022-06-21 18:58:15.594188
# Unit test for method bind of class Box
def test_Box_bind():

    # Given
    a = Box(5)

    # When
    b = a.bind(lambda x: x + 1)

    # Then
    assert b == 6



# Generated at 2022-06-21 18:58:17.828000
# Unit test for method map of class Box
def test_Box_map():
    f = lambda a: a + 1
    assert Box(1).map(f) == Box(2)



# Generated at 2022-06-21 18:58:28.430519
# Unit test for method __str__ of class Box
def test_Box___str__():
    import pytest

    from pymonet.monad import Box

    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('test')) == 'Box[value=test]'
    assert str(Box(['1', '2'])) == 'Box[value=[1, 2]]'
    assert str(Box((1, 2))) == 'Box[value=(1, 2)]'
    assert str(Box({1, 2})) == 'Box[value={1, 2}]'
    assert str(Box({'1': 1, '2': 2})) == 'Box[value={1: 1, 2: 2}]'

    test_func = lambda x: x ** 2

    assert str(Box(test_func)) == 'Box[value={}]'.format(test_func)



# Generated at 2022-06-21 18:58:32.489615
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box
    """
    assert Box(33).to_either() == Box(33).bind(lambda v: Box(v).to_either())



# Generated at 2022-06-21 18:58:35.432047
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(5).to_maybe() == Box(5).bind(lambda v: Maybe.just(v))



# Generated at 2022-06-21 18:59:03.325893
# Unit test for method bind of class Box
def test_Box_bind():
    def add_one(value: int) -> Box[int]:
        return Box(value + 1)

    assert Box(1).bind(add_one) == Box(2)

    def add_two(value: int) -> int:
        return value + 2

    assert Box(1).bind(add_two) == 3



# Generated at 2022-06-21 18:59:04.999467
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(42).to_either() == Right(42)


# Generated at 2022-06-21 18:59:11.543736
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Right, Left
    from pymonet.lazy import Lazy

    assert Box(15) == Box(15)
    assert Box(15) == Maybe.just(15)
    assert Box(15) == Try.success(15)
    assert Box(15) == Validation.success(15)
    assert Box(15) == Right(15)
    assert Box(15) == Lazy(lambda : 15)
    assert Box(15) != Maybe.just(18)
    assert Box(15) != Try.success(18)
    assert Box(15) != Validation.success(18)
    assert Box(15) != Right

# Generated at 2022-06-21 18:59:14.836830
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(4) == Box(4)
    assert Box(4) != Box(5)
    assert Box(4) != 4



# Generated at 2022-06-21 18:59:17.496469
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box('abc').to_maybe() == Maybe.just('abc')



# Generated at 2022-06-21 18:59:20.771316
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box
    """
    assert Box(1).to_either() == Box(1).to_maybe().to_either()



# Generated at 2022-06-21 18:59:23.020896
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:59:25.244493
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method 'ap' of class Box.
    """

    result = Box(lambda x: x + 3).ap(Box(3))
    assert result == Box(6)

# Generated at 2022-06-21 18:59:27.091590
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box('test')) == 'Box[value=test]'



# Generated at 2022-06-21 18:59:29.824450
# Unit test for constructor of class Box
def test_Box():
    """
    Unit test for constructor of class Box
    """

    assert Box(1).value == 1
    assert Box(1) == Box(1)


# Generated at 2022-06-21 19:00:26.443391
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('some_value') == Box('some_value')
    assert Box(None) == Box(None)
    assert Box(None) != Box('value')
    assert Box(False) != Box(True)


# Generated at 2022-06-21 19:00:28.457832
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: Box(1)) == Box(1).to_lazy()
    assert Lazy(lambda: Box(True)) == Box(True).to_lazy()


# Generated at 2022-06-21 19:00:30.607592
# Unit test for method to_try of class Box
def test_Box_to_try():
    value = 'test'
    assert Box(value).to_try() == Try(value, is_success=True)

# Generated at 2022-06-21 19:00:38.792222
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box('').to_maybe() == Maybe('')
    assert Box(()).to_maybe() == Maybe(())
    assert Box([]).to_maybe() == Maybe([])
    assert Box({}).to_maybe() == Maybe({})
    assert Box(1).to_maybe() == Maybe(1)
    assert Box(True).to_maybe() == Maybe(True)
    assert Box(None).to_maybe() == Maybe(None)



# Generated at 2022-06-21 19:00:43.663015
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left

    assert Box(1).to_either() == Right(1)
    assert Box(None).to_either() == Right(None)
    assert Box(1).to_either().to_maybe() == Right(1).to_maybe()
    assert Box(None).to_either().to_maybe() == Right(None).to_maybe()



# Generated at 2022-06-21 19:00:46.505776
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    result = Box(4).to_maybe()
    assert isinstance(result, Maybe)
    assert result.value == 4


# Generated at 2022-06-21 19:00:54.227294
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Just

    def plus_one(x):
        return x + 1

    box_plus_one = Box(plus_one)

    lazy_two = Lazy(lambda: 2)
    box_two = Box(2)

    assert box_plus_one.ap(lazy_two) == 3
    assert box_plus_one.ap(Just(2)) == 3
    assert box_plus_one.ap(box_two) == 3


# Generated at 2022-06-21 19:00:57.152558
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda v: v + 1) == Box(2)



# Generated at 2022-06-21 19:00:59.326608
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    Box(5).map(lambda x: x + 5) == Box(10)



# Generated at 2022-06-21 19:01:10.458375
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert (Box(42) == Box(42)) is True
    assert (Box(42) == Box(1)) is False
    assert (Box('abc') == Box('abc')) is True
    assert (Box('abc') == Box('1')) is False
    assert (Box([1, 2]) == Box([1, 2])) is True
    assert (Box([1, 2]) == Box([1])) is False
    assert (Box((1, 2)) == Box((1, 2))) is True
    assert (Box((1, 2)) == Box((1))) is False
    assert (Box(set([1, 2])) == Box(set([1, 2]))) is True
    assert (Box(set([1, 2])) == Box(set([1]))) is False

# Generated at 2022-06-21 19:02:27.692280
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))

# Generated at 2022-06-21 19:02:31.077417
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)
    assert Box('passed').to_validation() == Validation.success('passed')
    assert Box(bool).to_validation() == Validation.success(bool)

# Generated at 2022-06-21 19:02:33.737290
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    box = Box(123)
    result = box.to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 123

# Generated at 2022-06-21 19:02:37.807804
# Unit test for method map of class Box
def test_Box_map():
    """
    test_Box_map() -> None
    Test function for Box.map
    """
    a = lambda x: x + 10
    box = Box(10)

    assert box.map(a).value == 20



# Generated at 2022-06-21 19:02:41.744538
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Success, Failure

    assert Success(0).to_box().to_try() == Success(0)
    assert Failure(0).to_box().to_try() == Success(Failure(0))



# Generated at 2022-06-21 19:02:43.218727
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box('test').map(str.upper) == Box('TEST')

# Generated at 2022-06-21 19:02:44.808168
# Unit test for method to_either of class Box
def test_Box_to_either():
    b = Box(lambda x: x+2)
    e = b.to_either()
    assert e.right(3) == 5


# Generated at 2022-06-21 19:02:47.820503
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.maybe import MaybeNot

    assert (Box(1).to_maybe() == Maybe(1))
    assert (Box(None).to_maybe() == MaybeNot())



# Generated at 2022-06-21 19:02:51.909795
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_failure import Failure

    assert Box('success').to_try() == Try('success', is_success=True)
    assert Failure(Exception('failure')).to_box().to_try() == Try(Exception('failure'), is_success=False)



# Generated at 2022-06-21 19:02:54.041237
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    check correct working of to_maybe method
    """
    assert Box(42).to_maybe() == Maybe.just(42)


# Generated at 2022-06-21 19:04:20.577710
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-21 19:04:27.969120
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class `Box`
    """
    box_1 = Box('a')
    box_2 = Box('a')
    assert box_1 == box_2

    box_1 = Box('a')
    box_2 = Box('b')
    assert not (box_1 == box_2)

    box_1 = Box('a')
    box_2 = Box(1)
    assert not (box_1 == box_2)

    box_1 = Box(1)
    box_2 = Box(1)
    assert box_1 == box_2

    box_1 = Box(1)
    box_2 = Box(2)
    assert not (box_1 == box_2)



# Generated at 2022-06-21 19:04:35.603471
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    def add(x):
        def add_to(y):
            return x + y
        return add_to

    def mul(x):
        def mul_with(y):
            return x * y
        return mul_with

    assert Box(8).ap(Box(add(5))).ap(Box(10)).value == 23
    assert Box(8).ap(Box(mul(5))).ap(Box(10)).value == 80


# Generated at 2022-06-21 19:04:39.669035
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Map function (A) -> B
    and applied this function on current box value returns new box with mapped value.
    """
    assert Box(1).bind(lambda x: x + 2) == 3


# Generated at 2022-06-21 19:04:41.489777
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(5).to_validation() == Validation.success(5)

# Generated at 2022-06-21 19:04:45.546916
# Unit test for method ap of class Box
def test_Box_ap():
    def mapper(x: int) -> int:
        return x + 1

    assert Box(mapper).ap(Box(1)) == Box(2) and \
           Box(None).ap(Box(1)) == Box(None) and \
           Box(lambda x: x).ap(Box(1)) == Box(1)

# Generated at 2022-06-21 19:04:48.267329
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    # Given
    value = 10
    box = Box(value)
    expected_result = Right(value)

    # When
    result = box.to_either()

    # Then
    assert result == expected_result


# Generated at 2022-06-21 19:04:52.485676
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert not Box(10) == 10
    assert not Box(10) == None
    assert Box(10) == Box(10)
    assert Box(10) == Box(10)
    assert Box((10, 20)) == Box((10, 20))
    assert not Box((10, 20)) == Box((10, 21))
    assert not Box((10, 20)) == Box((11, 20))