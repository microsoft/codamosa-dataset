

# Generated at 2022-06-21 18:54:57.878638
# Unit test for method map of class Box
def test_Box_map():
    assert Box(0).map(lambda value: value + 1) == Box(1)
    assert Box(True).map(lambda value: not value) == Box(False)
    assert Box('test').map(lambda value: value + 's') == Box('tests')
    assert Box(None).map(lambda value: 'value') == Box('value')



# Generated at 2022-06-21 18:55:04.982213
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)
    assert Box('test').to_try() == Try('test', is_success=True)
    assert Box([]).to_try() == Try([], is_success=True)
    assert Box({}).to_try() == Try({}, is_success=True)


# Generated at 2022-06-21 18:55:09.470446
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    print('Test for method to_maybe of class Box')

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(1).to_maybe().to_try() == Try.unit(1)


# Generated at 2022-06-21 18:55:13.145647
# Unit test for method to_try of class Box
def test_Box_to_try():
    """

    """
    from pymonet.monad_try import Try

# Generated at 2022-06-21 18:55:16.664350
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 18:55:23.641024
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either

    assert isinstance(Box(10).to_either(), Either)
    assert Box(10).to_either().is_right()
    assert Box(10).to_either().get_right() == 10



# Generated at 2022-06-21 18:55:26.101836
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-21 18:55:28.492412
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:55:30.872136
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(1)

    assert box.to_either() == Right(1)

# Generated at 2022-06-21 18:55:32.714024
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(3).to_either() == Right(3)


# Generated at 2022-06-21 18:55:35.773832
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right
    assert Box(10).to_either() == Right(10)


# Generated at 2022-06-21 18:55:37.887962
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(2).to_validation() == Validation.success(2)


# Generated at 2022-06-21 18:55:40.545860
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    box = Box(2)
    assert Validation.success(2) == box.to_validation()


# Generated at 2022-06-21 18:55:42.792772
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(2)) == 'Box[value=2]'



# Generated at 2022-06-21 18:55:44.235748
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:55:45.438320
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('1') == Box('1')



# Generated at 2022-06-21 18:55:47.613109
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda value: value + 1) == Box(2)



# Generated at 2022-06-21 18:55:57.906084
# Unit test for method bind of class Box
def test_Box_bind():

    class A(object):
        def __init__(self, number: int) -> None:
            self.number = number
        def pow(self, number: int) -> 'A':
            self.number = self.number ** number
            return self
        def __eq__(self, other: object) -> bool:
            return isinstance(other, A) and self.number == other.number
        def __str__(self) -> str:  # pragma: no cover
            return 'A[number={}]'.format(self.number)

    a = A(2)
    b = Box(a)

    assert b.bind(lambda x: x.pow(3)) == a.pow(3)


# Generated at 2022-06-21 18:56:00.615904
# Unit test for constructor of class Box
def test_Box():
    """
    Unit test for constructor of Box.
    """
    box = Box(1)
    assert box.value == 1



# Generated at 2022-06-21 18:56:06.209196
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """Unit test for method to_validation of class Box"""

    value = 123
    b = Box(value)
    b_validation = b.to_validation()
    assert isinstance(b_validation, Validation)
    assert b_validation.is_success
    assert b_validation.value == value
    assert b_validation.errors == []

# Generated at 2022-06-21 18:56:12.026972
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(5)) == Box(6)



# Generated at 2022-06-21 18:56:14.444742
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover

    from pymonet.monad_try import Try

    try_ = Try.failure(Exception())

    assert Box(try_).to_try() == try_

# Generated at 2022-06-21 18:56:16.001055
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != 10



# Generated at 2022-06-21 18:56:17.394174
# Unit test for constructor of class Box
def test_Box():
    value = 10
    assert Box(value).value == value



# Generated at 2022-06-21 18:56:20.151291
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet import Box

    assert Box(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-21 18:56:25.593008
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test to_maybe method of Box class.
    """
    from pymonet.maybe import Maybe

    assert Maybe.just(10).to_maybe() == Box(10).to_maybe()
    assert Maybe.nothing().to_maybe() == Box(None).to_maybe()



# Generated at 2022-06-21 18:56:28.654951
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    input_1 = Box(1)
    assert input_1 == input_1.to_maybe().to_box()

    input_2 = Box(None)
    assert input_2 == input_2.to_maybe().to_box()

    input_3 = Box(False)
    assert input_3 == input_3.to_maybe().to_box()

    input_4 = Box('hello')
    assert input_4 == input_4.to_maybe().to_box()



# Generated at 2022-06-21 18:56:31.140166
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    test_box = Box(1)
    assert test_box.value == 1



# Generated at 2022-06-21 18:56:33.098403
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # given
    box = Box(4)

    # then
    assert box == box
    assert Box(2) != box



# Generated at 2022-06-21 18:56:43.656328
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    try_value = Try(True, is_success=False)

    # Test for true value
    box_value = Box(True)
    try_value_from_box = box_value.to_try()
    assert try_value_from_box == Try(True, is_success=True)

    # Test for false value
    box_value = Box(False)
    try_value_from_box = box_value.to_try()
    assert try_value_from_box == Try(False, is_success=True)

    # Test for None
    box_value = Box(None)
    try_value_from_box = box_value.to_try()
    assert try_value_from_box == Try(None, is_success=True)

    # Test

# Generated at 2022-06-21 18:56:48.887485
# Unit test for constructor of class Box
def test_Box():
    # Given
    value = 10

    # When
    box = Box(value)

    # Then
    assert box.value == value



# Generated at 2022-06-21 18:56:54.267637
# Unit test for method to_try of class Box
def test_Box_to_try():                       # pragma: no cover
    """
    Unit test for method to_try of class Box
    """
    # Arrange
    from pymonet.monad_try import Try

    # Act
    result = Box(1).to_try()

    # Assert
    assert isinstance(result, Try)
    assert result.is_success()
    assert result.value == 1


# Generated at 2022-06-21 18:56:56.718488
# Unit test for constructor of class Box
def test_Box():
    box_int = Box(1)
    box_str = Box('text')

    assert box_int.value == 1
    assert box_str.value == 'text'



# Generated at 2022-06-21 18:56:58.508584
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(5) == Box(5)
    assert Box("A") == Box("A")



# Generated at 2022-06-21 18:57:00.515703
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1).value == 1


# Generated at 2022-06-21 18:57:03.268611
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(1).map(lambda i: i + 1) == Box(2)
    assert Box(1).map(lambda i: i + 1).value == 2
    assert Box(2).map(lambda i: i + 1).value == 3
    assert Box(1).map(lambda i: i + 1).map(lambda i: i - 1) == Box(2)


# Generated at 2022-06-21 18:57:06.019973
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(123) == Box(123)
    assert Box(123) != Box(321)

# Generated at 2022-06-21 18:57:17.855981
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('')) == 'Box[value=]'
    assert str(Box('Hello')) == 'Box[value=Hello]'
    assert str(Box(())) == 'Box[value=()]'
    assert str(Box([])) == 'Box[value=[]]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box({})) == 'Box[value={}]'
    assert str(Box({'a': 1, 'b': 2})) == "Box[value={'a': 1, 'b': 2}]"
    assert str(Box(Box(1))) == 'Box[value=Box[value=1]]'


# Generated at 2022-06-21 18:57:19.674565
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')


# Generated at 2022-06-21 18:57:25.982124
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test to_try method of Box.
    """

    from pymonet.monad_try import Failure

    assert Failure(ValueError) == Box(5).to_try()
    assert Failure(ValueError) == Box('a').to_try()
    assert Failure(ValueError) == Box([]).to_try()
    assert Failure(ValueError) == Box({}).to_try()


# Generated at 2022-06-21 18:57:35.057675
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(2).to_try() == Try(2, is_success=True)


# Generated at 2022-06-21 18:57:37.153896
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    dut = Box(123)

    assert dut.value == 123



# Generated at 2022-06-21 18:57:39.400687
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Success
    assert Box(1).to_try() == Success(1)



# Generated at 2022-06-21 18:57:40.266014
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(1) == Box((lambda x: x)(1))

# Generated at 2022-06-21 18:57:43.388731
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(12).to_lazy() == Lazy(lambda: 12)
    assert Box(12).to_lazy().run() == 12
    assert Box(12).to_lazy().map(lambda x: x + 1).run() == 13


# Generated at 2022-06-21 18:57:46.073129
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert Box(1).__str__() == 'Box[value=1]', '__str__()'

# Generated at 2022-06-21 18:57:48.336750
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(10).to_validation() == Validation.success(10)


# Generated at 2022-06-21 18:57:49.890984
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)



# Generated at 2022-06-21 18:57:52.069176
# Unit test for method ap of class Box
def test_Box_ap():
    first_box = Box(lambda x: x * 3)  # Box[Function(A) -> B]
    second_box = Box(2)  # Box[A]
    assert first_box.ap(second_box) == Box(6)  # assert Box(A(B)) == Box[6]

# Generated at 2022-06-21 18:57:59.488391
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    class Squarer(object):
        def __init__(self, factor):
            self.factor = factor

        def square(self, x):
            return x * x

    def test_box_squarer(x):
        boxed_squarer = Box(Squarer(3))
        return boxed_squarer.bind(lambda sq: Box(sq.square(x))).value

    assert test_box_squarer(2) == 12



# Generated at 2022-06-21 18:58:12.226167
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-21 18:58:14.013234
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    box = Box(1)
    try_ = box.to_try()
    assert try_ == Try(1, is_success=True)

# Generated at 2022-06-21 18:58:15.597116
# Unit test for constructor of class Box
def test_Box():
    assert Box('hello world') == Box('hello world')


# Generated at 2022-06-21 18:58:22.333741
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x+1).ap(Box(1)) == Box(2)
    assert Box(lambda x: x+1).ap(Box(1)) != Box(1)
    assert Box(lambda x: x+1).ap(Box(1)) == Box(1).ap(Box(lambda x: x+1))
    assert Box(lambda x: x+1).ap(Box(1)) != Box(1).ap(Box(lambda x: x+2))



# Generated at 2022-06-21 18:58:25.479953
# Unit test for method to_try of class Box
def test_Box_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Box(42).to_try() == Try(42, is_success=True)



# Generated at 2022-06-21 18:58:28.508841
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 18:58:32.536813
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(2)
    assert box1 == box1
    assert box1 != box2
    assert box1 != 1
    assert box1 != "1"


# Generated at 2022-06-21 18:58:36.727488
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test for Box class method ap of Box class
    """
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3), 'Lambda add one not applied on number'



# Generated at 2022-06-21 18:58:39.173394
# Unit test for method map of class Box
def test_Box_map():
    box = Box(1)
    assert box.map(lambda x: x + 1) == Box(2)


# Generated at 2022-06-21 18:58:42.283290
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 1) == Box(3)
    assert Box(2).map(lambda x: x * 2) == Box(4)



# Generated at 2022-06-21 18:59:07.179294
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    box = Box(1)
    assert str(box) == 'Box[value=1]'

# Generated at 2022-06-21 18:59:09.267767
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 18:59:11.283618
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-21 18:59:13.231785
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(None) == Box(None)



# Generated at 2022-06-21 18:59:15.554305
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box("foo") == Box("foo")
    assert not (Box("foo") == Box("bar"))



# Generated at 2022-06-21 18:59:18.508207
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()


# Generated at 2022-06-21 18:59:19.962320
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-21 18:59:22.285613
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == 1)

# Generated at 2022-06-21 18:59:24.314505
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 2) == Box(4), 'Mapping function does not work'



# Generated at 2022-06-21 18:59:27.244464
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Passing test for method to_either of class Box
    """
    from pymonet.either import Right
    from pymonet.box import Box

    assert Box(10).to_either() == Right(10)


# Generated at 2022-06-21 18:59:47.242011
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box = Box(1)
    assert box.value == 1

# Generated at 2022-06-21 18:59:48.473480
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1



# Generated at 2022-06-21 18:59:53.460931
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    def get_five() -> int:
        """
        Return 5 as integer.

        :returns: 5 as integer
        :rtype: int
        """
        return 5

    # test with function
    assert Box(get_five).to_lazy().get_value() == 5

    # test with integer
    assert Box(5).to_lazy().get_value() == 5

# Generated at 2022-06-21 18:59:55.158509
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert str(Box(0)) == 'Box[value=0]'


# Generated at 2022-06-21 19:00:04.986151
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Method test for class Box

    ap :: Applicative f => f (a -> b) -> f a -> f b
    ap x y = do { f <- x; y' <- y; return (f y') }
    """

    from pymonet.lazy import Lazy

    def mapper(value: int) -> str:
        """
        :param value: value to map
        :type value: int
        :returns: value converted to string
        :rtype: str
        """
        return '{}'.format(value)

    assert Box(1).ap(Box(mapper)) == Box(mapper(1))
    assert Box(2).ap(Box(mapper)) == Box(mapper(2))
    assert Box(2).ap(Lazy(lambda: mapper)) == Box(mapper(2))

# Generated at 2022-06-21 19:00:08.674642
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:00:11.390328
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(2).bind(lambda x: x + 1) == 3
    assert Box(2).bind(lambda x: Box(x + 1)) == Box(3)



# Generated at 2022-06-21 19:00:15.821103
# Unit test for method bind of class Box
def test_Box_bind():
    # given
    box = Box(5)
    mapper = lambda value: 2 * value
    expected = 10

    # when
    actual = box.bind(mapper)

    # then
    assert actual == expected



# Generated at 2022-06-21 19:00:20.879695
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test to_try method of Box.
    """

    # Given
    box = Box(100)

    # When
    result = box.to_try()

    # Then
    testTypes.assert_test_case(
        success=True,
        status='Passed',
        errors=[],
        test_name='test_Box_to_try'
    )



# Generated at 2022-06-21 19:00:28.869248
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for to_either method of Box class

    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box(1).to_either() != Right(2)
    assert Box(1).to_either() != Right(0)
    assert Box(1).to_either() != Right()
    assert Box(1).to_either() != Right(None)


# Generated at 2022-06-21 19:01:09.788797
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)



# Generated at 2022-06-21 19:01:11.788997
# Unit test for method map of class Box
def test_Box_map():
    # GIVEN
    box = Box("test")

    # WHEN
    mapped = box.map(lambda x: x.upper())

    # THEN
    assert mapped.value == "TEST"



# Generated at 2022-06-21 19:01:19.991156
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.test.testmonad import test_eq
    from pymonet.test.testmonad import test_not_eq

    test_eq(Box(1), Box(1))
    test_eq(Box('str'), Box('str'))
    test_eq(Box(False), Box(False))
    test_eq(Box(None), Box(None))

    test_not_eq(Box(1), Box(2))
    test_not_eq(Box(1), Box('1'))
    test_not_eq(Box(1), Box(1.0))
    test_not_eq(Box('a'), Box('b'))


# Generated at 2022-06-21 19:01:27.036597
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.either import Left

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(None).to_maybe() == Maybe.nothing()
    assert Box(Left(1)).to_maybe() == Maybe.nothing()

    from pymonet.monad_try import Try

    assert Box(Try.success(1)).to_maybe() == Maybe.just(1)
    assert Box(Try.failure(None)).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:01:29.908993
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test for method ap of class Box
    """
    assert Box(2).to_lazy().ap(Box(lambda x: x + 2)) == Box(4)
    assert Box('str').ap(Box(lambda x: x.upper())) == Box('STR')



# Generated at 2022-06-21 19:01:31.436419
# Unit test for constructor of class Box
def test_Box():
    box = Box([])
    assert isinstance(box, Box)



# Generated at 2022-06-21 19:01:32.879291
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(5).to_lazy().eval() == 5

# Generated at 2022-06-21 19:01:34.650169
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert(str(Box(1)) == 'Box[value=1]')


# Generated at 2022-06-21 19:01:39.929724
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for `to_either` method of class Box.
    """

    # Test scenario 1
    # Test data
    value = "value"

    # Action under test
    result = Box(value).to_either()

    # Assertions
    assert isinstance(result, Either)
    assert result.is_right()
    assert result.right == value



# Generated at 2022-06-21 19:01:42.315205
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:03:19.101007
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]' and str(Box('a')) == 'Box[value=a]' and str(Box(None)) == 'Box[value=None]', \
        'test_Box___str__ is failed'



# Generated at 2022-06-21 19:03:21.075937
# Unit test for method ap of class Box
def test_Box_ap():
    add_one = lambda x: x + 1
    assert Box(add_one).ap(Box(10)) == Box(11)



# Generated at 2022-06-21 19:03:26.219828
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    assert Box(3).map(lambda x: x + 2) == Box(5)
    assert Box(Try(Failure(TypeError('Wrong type')))).map(lambda x: x + 2) == Box(Try(Failure(TypeError('Wrong type'))))


# Generated at 2022-06-21 19:03:30.019801
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(123).to_maybe() == Maybe.just(123)
    assert Box("hello").to_maybe() == Maybe.just("hello")
    assert Box(None).to_maybe() == Maybe.just(None)



# Generated at 2022-06-21 19:03:31.789414
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_either().to_maybe()


# Generated at 2022-06-21 19:03:36.519410
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test to_maybe method of class Box

    :return: nothing
    """
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 19:03:39.264577
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_box() == Box(1)



# Generated at 2022-06-21 19:03:41.616995
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(42) == Box(42)
    assert not Box(42) == Box(43)
    assert not Box(42) == None


# Generated at 2022-06-21 19:03:45.501086
# Unit test for method __str__ of class Box
def test_Box___str__():
    # Given
    box = Box(10)

    # When
    result = str(box)

    # Then
    assert result == 'Box[value=10]'


# Generated at 2022-06-21 19:03:51.267073
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for Box.bind method

    :returns: Unit test result
    :rtype: bool
    """

    def mapper(value: str) -> int:
        return len(value)

    def test_expression(test_value: str) -> bool:
        return Box('test').bind(mapper) == Box(test_value).bind(mapper)

    return test_expression('test')

