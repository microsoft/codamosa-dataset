

# Generated at 2022-06-21 18:54:56.408427
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box[int](1)) == 'Box[value=1]'
    assert str(Box[str]('Test')) == 'Box[value=Test]'
    assert str(Box[list]([1, 2, 3])) == 'Box[value=[1, 2, 3]]'



# Generated at 2022-06-21 18:54:57.617129
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: Box(str(x))) == Box('1')

# Generated at 2022-06-21 18:54:59.027277
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:55:01.206884
# Unit test for method map of class Box
def test_Box_map():
    assert (Box(2).map(lambda x: x * 2)) == Box(4)



# Generated at 2022-06-21 18:55:03.920355
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(10).to_try() == Try(10, is_success=True)

# Generated at 2022-06-21 18:55:08.468015
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box.
    """
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box('test')) == 'Box[value=test]'


# Generated at 2022-06-21 18:55:10.372112
# Unit test for method map of class Box
def test_Box_map():
    def add_5(value):
        return value + 5
    assert Box(5).map(add_5) == Box(10)


# Generated at 2022-06-21 18:55:13.780179
# Unit test for method to_validation of class Box
def test_Box_to_validation():

    value = {'a': 1, 'b': 2}
    assert Box(value).to_validation() == Validation.success(value)

# Generated at 2022-06-21 18:55:16.267596
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box("value").to_maybe() == Maybe.just("value")



# Generated at 2022-06-21 18:55:18.331837
# Unit test for method ap of class Box
def test_Box_ap():
    from operator import add

    assert Box(add).ap(Box(1)).ap(Box(2)).value == 3



# Generated at 2022-06-21 18:55:25.600444
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    zero = Box(0)

    assert zero.to_try() == Try(0, is_success=True)


# Generated at 2022-06-21 18:55:28.904298
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    value = 10
    box = Box(value)
    assert box.to_validation() == Validation.success(value)

# Generated at 2022-06-21 18:55:30.819405
# Unit test for method map of class Box
def test_Box_map():
    assert Box(5).map(lambda x: x + 10) == Box(15)



# Generated at 2022-06-21 18:55:33.898132
# Unit test for constructor of class Box
def test_Box():
    assert Box(3) == Box(3)
    assert Box(3) != Box(2)
    assert Box('string') == Box('string')
    assert Box('string') != Box(2)



# Generated at 2022-06-21 18:55:35.704780
# Unit test for method to_validation of class Box
def test_Box_to_validation(): # pragma: no cover
    from pymonet.validation import Validation

    assert Box('value').to_validation() == Validation.success('value')


# Generated at 2022-06-21 18:55:37.066544
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)

# Generated at 2022-06-21 18:55:40.336182
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(1).to_maybe() != Maybe.nothing()


# Generated at 2022-06-21 18:55:43.402429
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:55:46.849782
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    lazy = Box(Try(10, is_success=True)).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == Try(10, is_success=True)



# Generated at 2022-06-21 18:55:52.688326
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert Box(-1) == Box(-1)
    assert Box(3.1) == Box(3.1)
    assert Box(2.5) == Box(2.5)
    assert Box('qwerty') == Box('qwerty')
    assert Box('123456') == Box('123456')



# Generated at 2022-06-21 18:56:06.701069
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Box(10).ap(Box(lambda x: x + 10)) == Box(20)
    assert Box(10).ap(Box(lambda x: "a" * x)) == Box("aaaaaaaaaa")
    assert Box(10).ap(Box(lambda x: [1] * x)) == Box([1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
    assert Box(10).ap(Box(lambda x: Right(x + 10))) == Box(Right(20))
    assert Box(10).ap(Box(lambda x: Left("Error"))) == Box(Left("Error"))

# Generated at 2022-06-21 18:56:08.911481
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(2).bind(lambda x: x ** 2) == 4


# Generated at 2022-06-21 18:56:13.526359
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 10).ap(Box(40)) == Box(50)
    assert Box(lambda x: x + 10).ap(Box("a")) == Box("a10")
    assert Box("test").ap(Box(lambda x: x + "ing")) == Box("testing")

# Generated at 2022-06-21 18:56:17.146976
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-21 18:56:20.847383
# Unit test for method bind of class Box
def test_Box_bind():
    f = lambda x: x + 4
    b = Box(5)
    b1 = b.bind(f)

    assert isinstance(b1, int)

    assert b1 == 9

    assert b1 == b.bind(f)



# Generated at 2022-06-21 18:56:21.813944
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1



# Generated at 2022-06-21 18:56:24.925139
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert isinstance(Box(42).to_validation(), Validation)


# Generated at 2022-06-21 18:56:35.114914
# Unit test for constructor of class Box
def test_Box(): # pragma: no cover
    assert Box(2) == Box(2)
    assert str(Box(3)) == 'Box[value=3]'
    assert str(Box(3.3)) == 'Box[value=3.3]'
    assert str(Box('string')) == 'Box[value=string]'
    assert str(Box([1,2,3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box((1,2,3))) == 'Box[value=(1, 2, 3)]'
    assert str(Box({1,2,3})) == 'Box[value={1, 2, 3}]'
    assert str(Box({1:1,2:2,3:3})) == 'Box[value={1: 1, 2: 2, 3: 3}]'



# Generated at 2022-06-21 18:56:38.105853
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    assert Box(1).to_either() == Right(1)
    assert Box(Left('a')).to_either() == Right(Left('a'))
    assert Box(1).to_either() != Left(1)
    assert Box(Left('a')).to_either() != Left(1)


# Generated at 2022-06-21 18:56:40.671730
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box('Hello')

    assert box.bind(lambda x: x + ' World!') == 'Hello World!'


# Generated at 2022-06-21 18:56:50.787589
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.functor import Functor
    from pymonet.either import Left, Right

    def test_int_box():
        box = Box(3)
        assert Functor.test_functor(box, lambda a: a * a, 9)

    def test_box_left():
        box = Box(Left(3))
        assert Functor.test_functor(box, lambda a: a ** a, Left(27))

    def test_box_right():
        box = Box(Right(3))
        assert Functor.test_functor(box, lambda a: a ** a, Right(27))

    test_int_box()
    test_box_left()
    test_box_right()


# Generated at 2022-06-21 18:56:53.954223
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.validation import Validation

    box = Box(2)
    validation = Validation(lambda x: x + 2)
    assert Box(4) == box.ap(validation)



# Generated at 2022-06-21 18:56:55.544965
# Unit test for method __str__ of class Box
def test_Box___str__():
    box = Box(1)

    assert str(box) == 'Box[value=1]'


# Generated at 2022-06-21 18:57:01.300239
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Tests for Box.ap.
    """
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.monad_dict import Dict
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    # Box
    assert Box(Box(lambda x: x + 3)).ap(Box(2)) == Box(5)

    # Lazy
    assert Box(Box(lambda x: x + 3)).ap(Lazy(lambda: 2)) == Box(5)

    # Try
    assert Box(Box(lambda x: x + 3)).ap(Try(2, is_success=True)) == Box(5)

    # Validation

# Generated at 2022-06-21 18:57:10.795998
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # Test for lazy with not empty box
    result = Box('test').to_lazy()
    assert(isinstance(result, Lazy))
    assert(result.is_value())
    assert(result.value() == 'test')

    # Test for lazy with empty box
    result = Box(None).to_lazy()
    assert(isinstance(result, Lazy))
    assert(result.is_value())
    assert(result.value() is None)


# Generated at 2022-06-21 18:57:16.244251
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box("hello").to_maybe() == Maybe.just("hello")
    assert Maybe.just("hello").to_maybe() == Maybe.just("hello")
    assert Maybe.nothing().to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:57:18.427035
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:57:24.495218
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    This function unit testing method to_either of class Box.

    :returns: None
    :rtype: NoneType
    """
    from pymonet.either import Right

    value = Box(r'hello')
    result = value.to_either()

    assert isinstance(result, Right)
    assert result.value == r'hello'



# Generated at 2022-06-21 18:57:29.331341
# Unit test for method to_try of class Box
def test_Box_to_try():
    value = 'value'
    box = Box(value)
    assert box.to_try().get() == value
    assert box.to_try().get_or_else('not') == value
    assert box.to_try().is_success is True
    assert box.to_try().is_failure is False

# Generated at 2022-06-21 18:57:34.173879
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test for method ap of class Box

    :return: None
    :rtype: None
    """
    assert Box(lambda x: x + 1).ap(Box(5)) == Box(6)
    assert Box(5).ap(Box(lambda x: x + 1)) == Box(6)

# Generated at 2022-06-21 18:57:40.520428
# Unit test for constructor of class Box
def test_Box():
    assert Box('test') == Box('test')  # True
    assert Box(1) != Box('test')  # True
    assert str(Box('test')) == 'Box[value=test]'  # True
    assert Box('test').value == 'test'  # True



# Generated at 2022-06-21 18:57:45.353579
# Unit test for method to_either of class Box
def test_Box_to_either():
    # GIVEN
    number_box = Box(10)
    string_box = Box('pymonet')

    # WHEN & THEN
    assert number_box.to_either() == Right(10)
    assert string_box.to_either() == Right('pymonet')



# Generated at 2022-06-21 18:57:50.189976
# Unit test for method ap of class Box
def test_Box_ap():
    # given
    box_value = 2
    box = Box(box_value)
    box_with_mapped_value = Box(lambda x: x * 2)

    # when
    result = box.ap(box_with_mapped_value)

    # then
    assert result.value == box_value * 2

# Generated at 2022-06-21 18:57:54.200183
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert Box('asd') == Box('asd')
    # noinspection PyTypeHints
    assert not (Box('asd') == [1, 2, 3])
    assert Box([1, 2]) == Box([1, 2])



# Generated at 2022-06-21 18:58:01.172458
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Box(1).to_either() == Right(1)
    assert Box(Try.success(1)).to_either().right.value == 1
    assert Box(Maybe.just(1)).to_either().right.value == 1
    assert Box(None).to_either() == Right(None)



# Generated at 2022-06-21 18:58:03.823064
# Unit test for method ap of class Box
def test_Box_ap():
    def add(num: int):
        return lambda x: x + num

    assert Box(1).ap(Box(add(2))) == Box(3)


# Generated at 2022-06-21 18:58:05.854510
# Unit test for method map of class Box
def test_Box_map():
    box = Box(2)
    assert box.map(lambda x: x * 2) == Box(4)



# Generated at 2022-06-21 18:58:09.796964
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad import identity

    assert Box(3).to_try() == Try(3, True)
    assert Box(None).to_try().bind(identity) == Try(None, True)

# Generated at 2022-06-21 18:58:13.242804
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(2) == Box(2)
    assert Box(3) == Box(3)
    assert not Box(1) == Box(2)
    assert not Box(1) == Box(3)
    assert not Box(2) == Box(3)



# Generated at 2022-06-21 18:58:24.730613
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(1).ap(Box(lambda x: x + 1)).value == 2
    assert Box(2).ap(Box(lambda x: x * 2)).value == 4
    assert Box(lambda x: x + 1).ap(Box(1)).value == 2
    assert Box(Try(lambda x: x + 1, is_success=True)).ap(Box(1).to_try()).value == 2
    assert Box(Validation.success(lambda x: x + 1)).ap(Box(1).to_validation()).value == 2

# Generated at 2022-06-21 18:58:31.867193
# Unit test for method bind of class Box
def test_Box_bind():
    add_one = lambda x: x + 1
    result = Box(0).bind(add_one)
    expected_result = 1
    assert result == expected_result



# Generated at 2022-06-21 18:58:33.416786
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    assert Box(lambda x: x ** 2).ap(Box(2)) == Box(4)

# Generated at 2022-06-21 18:58:37.725268
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    assert Box(42).to_either() == Right(42)
    assert Right(42).to_either() == Right(42)
    assert Left(42).to_either() == Left(42)

# Generated at 2022-06-21 18:58:40.231430
# Unit test for method to_either of class Box
def test_Box_to_either():
    # When use - Then
    assert Box(123).to_either() == Either.right(123)

# Generated at 2022-06-21 18:58:44.106969
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(3) == Box(3)
    assert Box(3) != Box(4)
    assert Box("hello") == Box("hello")
    assert Box("hello") != Box("hello2")
    assert Box("hello") != Box(3)



# Generated at 2022-06-21 18:58:48.341330
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    """
    Test for __str__ method of Box class.
    """
    box = Box(12)
    assert str(box) == 'Box[value=12]'

    box = Box('string')
    assert str(box) == 'Box[value=string]'

    box = Box([])
    assert str(box) == 'Box[value=[]]'



# Generated at 2022-06-21 18:58:50.456194
# Unit test for constructor of class Box
def test_Box():
    value = Box('test')
    assert 'test' == value.value



# Generated at 2022-06-21 18:58:52.396328
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box
    """

    # Test with empty box
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 18:58:54.985689
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    assert box.to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 18:58:56.190930
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-21 18:59:02.702286
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    from pymonet.maybe import Maybe

    box = Box(1)
    actual = box.to_maybe()
    expected = Maybe.just(1)
    assert actual == expected


# Generated at 2022-06-21 18:59:03.629547
# Unit test for constructor of class Box
def test_Box():
    assert Box(1).value == 1


# Generated at 2022-06-21 18:59:06.582882
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    box = Box(5)
    assert box.to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-21 18:59:07.733173
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(12)) == 'Box[value=12]'


# Generated at 2022-06-21 18:59:09.569498
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(10).to_maybe() == Box(10).to_maybe() == \
        Box('test').to_maybe() == Box('test').to_maybe()


# Generated at 2022-06-21 18:59:13.029091
# Unit test for method ap of class Box
def test_Box_ap():
    def append_a(string: str):
        return string + 'a'

    box = Box(append_a)
    assert box.ap(Box('b')).value == 'ba'



# Generated at 2022-06-21 18:59:18.974001
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.lazy import Lazy

    def power2(x):
        return x ** 2

    result = Box(2).bind(power2)
    assert isinstance(result, int)
    assert result == 4

    result = Box(Lazy(lambda: 2)).bind(power2)
    assert isinstance(result, int)
    assert result == 4



# Generated at 2022-06-21 18:59:22.088001
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box("string").bind(lambda x: len(x)) == 6
    assert Box("Hello, world!").bind(lambda x: x.split(" ")) == ['Hello,', 'world!']
    assert Box(["list", "of", "values"]).bind(lambda x: " ".join(x)) == "list of values"
    assert Box({"key": "value"}).bind(lambda x: x["key"]) == 'value'



# Generated at 2022-06-21 18:59:23.518867
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-21 18:59:25.656622
# Unit test for method __str__ of class Box
def test_Box___str__():
    value = 'test'
    box = Box(value)
    assert str(box) == 'Box[value={}]'.format(value)



# Generated at 2022-06-21 18:59:33.312796
# Unit test for constructor of class Box
def test_Box():
    assert Box(3) == Box(3)
    assert str(Box(3)) == 'Box[value=3]'
    assert str(Box(3.5)) == 'Box[value=3.5]'
    assert str(Box('hello')) == 'Box[value=hello]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'

# Generated at 2022-06-21 18:59:36.196790
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test function mapping Box to Try.
    """
    from pymonet.monad_try import Try

    assert Box(3).to_try() == Try(3, is_success=True)


# Generated at 2022-06-21 18:59:42.667578
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    assert Box(42).to_maybe() == Maybe.just(42)
    assert Box("42").to_maybe() == Maybe.just("42")
    assert Box([1,2,3,4]).to_maybe() == Maybe.just([1,2,3,4])
    assert Box(set("hello")).to_maybe() == Maybe.just(set("hello"))
    assert Box({1,2}).to_maybe() == Maybe.just({1,2})


# Generated at 2022-06-21 18:59:43.998498
# Unit test for method to_either of class Box
def test_Box_to_either():
    box = Box(1)
    assert box.to_either().is_right



# Generated at 2022-06-21 18:59:45.613731
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(5)).value == 10


# Generated at 2022-06-21 18:59:47.448570
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(5) == Box(5).to_validation()

# Generated at 2022-06-21 18:59:48.764870
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-21 18:59:51.562954
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Tests for method bind of class Box
    """

    assert Box(1).bind(lambda value: value + 1) == 2, "bind method of Box should apply function on value of Box"

# Generated at 2022-06-21 18:59:54.045268
# Unit test for method ap of class Box
def test_Box_ap():
    """
    :returns: None
    :rtype: NoneType
    """
    assert Box(lambda x: x + 2).ap(Box(4)) == Box(4 + 2)

# Generated at 2022-06-21 18:59:56.639247
# Unit test for method ap of class Box
def test_Box_ap():
    functor = Box(lambda x: str(x).upper())
    applicative = Box('Please convert me')

    assert functor.ap(applicative) == Box('PLEASE CONVERT ME')


# Generated at 2022-06-21 19:00:05.369705
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test for method ap of class Box
    """
    def mapper(a):
        return a + 1

    assert Box(2).ap(Box(mapper)) == Box(mapper(2))

# Generated at 2022-06-21 19:00:07.490478
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Box(1000).to_validation() == Validation(1000, [])


# Generated at 2022-06-21 19:00:09.795831
# Unit test for method map of class Box
def test_Box_map():
    result = Box(3).map(lambda x: x + 1)

    assert result == Box(4)



# Generated at 2022-06-21 19:00:11.196185
# Unit test for constructor of class Box
def test_Box():
    box = Box(1)
    assert box.value == 1



# Generated at 2022-06-21 19:00:19.570173
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)
    assert Box(Validation.failure(1)).to_validation() == Validation.failure(1)
    assert Box(Validation.failure([1, 2])).to_validation() == Validation.failure([1, 2])
    assert Box(Validation.failure(Validation.failure(1))).to_validation() == Validation.failure(Validation.failure(1))



# Generated at 2022-06-21 19:00:26.191759
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Left, Right

    def f():
        return Box(3).to_either()

    assert Right(3) == f()
    assert f() == f()

    def f():
        return Box(Left(3)).to_either()

    assert f() == f()



# Generated at 2022-06-21 19:00:28.056276
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(3).to_either() == \
        Right(3)


# Generated at 2022-06-21 19:00:30.034495
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(5)
    assert box.to_either() == Right(5)



# Generated at 2022-06-21 19:00:32.244945
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-21 19:00:38.917277
# Unit test for method map of class Box
def test_Box_map():
    """
    Test for `map` method of Box
    """
    def mapper(val):
        return val + 1

    assert Box(1).map(mapper) == Box(2)
    assert Box(None).map(mapper) == Box(None)
    assert Box(100).map(mapper) == Box(101)
    assert Box('string').map(mapper) == Box('string')


# Generated at 2022-06-21 19:00:48.319423
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))
    assert not (Box(1) == None)
    assert not (Box(1) == 'a')



# Generated at 2022-06-21 19:00:51.637968
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    # given
    box = Box(1)

    # when
    validation = box.to_validation()

    # then
    assert Validation.success(1) == validation


# Generated at 2022-06-21 19:00:54.537351
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(1).map(lambda x: Box(x)) == Box(Box(1))
    assert Box('2').map(lambda x: x + '3') == Box('23')



# Generated at 2022-06-21 19:00:58.077219
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(2).map(lambda x: x + 2) == Box(4)



# Generated at 2022-06-21 19:01:00.549814
# Unit test for constructor of class Box
def test_Box():
    assert Box(10).value == 10 and Box(10) == Box(10)
    assert type(Box(10)) is Box


# Generated at 2022-06-21 19:01:02.573739
# Unit test for method bind of class Box
def test_Box_bind():
    assert(Box(2).bind(lambda x: x * 2) == 4)

# Generated at 2022-06-21 19:01:12.036618
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try1 = Box(10).to_try()
    assert try1.is_success
    assert Try(10, is_success=True) == try1

    try2 = Box(None).to_try()
    assert try2.is_success
    assert Try(None, is_success=True) == try2

    try3 = Box([1, 2, 3]).to_try()
    assert try3.is_success
    assert Try([1, 2, 3], is_success=True) == try3

    try4 = Box('Hello World').to_try()
    assert try4.is_success
    assert Try('Hello World', is_success=True) == try4


# Generated at 2022-06-21 19:01:13.730273
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # type: () -> None
    assert Box(2) == Box(2)
    assert Box(2) != Box(1)



# Generated at 2022-06-21 19:01:18.567483
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Unit test for method __str__ of class Box

    :returns: nothing
    :rtype: None
    """

    assert str(Box('str')) == 'Box[value=str]'
    assert str(Box(8)) == 'Box[value=8]'


# Generated at 2022-06-21 19:01:23.242946
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    def get_first_n_chars(value):
        return value[:1]

    assert Box('123').bind(get_first_n_chars) == '1'


# Generated at 2022-06-21 19:01:42.732124
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Value, TypeError
    from pymonet.box import Box

    b = Box(Value(1))
    validation = b.to_validation()

    assert validation == Validation.success(Value(1))
    assert validation.fold(lambda failure: failure, lambda value: value) == Value(1)

    b = Box(TypeError('TypeError'))
    validation = b.to_validation()

    assert validation == Validation.success(TypeError('TypeError'))
    assert validation.fold(lambda failure: failure, lambda value: value) == TypeError('TypeError')

# Generated at 2022-06-21 19:01:47.576818
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    # Create new Box
    x = Box(1)

    # Convert to Maybe
    y = x.to_maybe()

    # Check type of result
    assert isinstance(y, Maybe)

    # Check if result is just
    assert y.is_just() is True

    # Check value in result
    assert y.value == 1


# Generated at 2022-06-21 19:01:50.827716
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy_1 = Box(5).to_lazy()
    lazy_2 = Box(5).to_lazy()

    assert lazy_1 == lazy_2
    assert lazy_1.value() == 5

# Generated at 2022-06-21 19:01:53.150890
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(1).map(lambda x: str(x)) == Box("1")


# Generated at 2022-06-21 19:01:59.552549
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.monad_try import failure

    assert Box(lambda x: x).bind(lambda x: x(4)) == 4
    assert Box(lambda x: x * x).bind(lambda f: f(Box(2).value)) == 4
    assert Box(10).bind(lambda _: Box(False)) == Box(False)
    assert Box((1, 2)).bind(lambda _: Box(False)) == Box(False)
    assert Box([]).bind(lambda _: Box(False)) == Box(False)
    assert Box({}).bind(lambda _: Box(False)) == Box(False)
    assert Box(10).bind(lambda _: failure('s')) == failure('s')
    assert Box((1, 2)).bind(lambda _: failure('s')) == failure('s')

# Generated at 2022-06-21 19:02:01.206889
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(2).to_either() == Right(2)

# Generated at 2022-06-21 19:02:06.529916
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    # GIVEN: Box with some test values
    value = "test value"
    box = Box(value)

    # WHEN: to_validation method is called
    result = box.to_validation()

    # THEN: validation monad with success should be returned
    assert isinstance(result, Validation)
    assert result.is_success() == True
    assert result.value == value
    assert result.errors == []



# Generated at 2022-06-21 19:02:10.081499
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    box = Box(3)
    assert box.value == 3 and isinstance(box, Box)

# Unit tests for methods of class Box

# Generated at 2022-06-21 19:02:11.377357
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)


# Generated at 2022-06-21 19:02:15.093794
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Pytest function for test
    """
    from pymonet.maybe import Maybe
    assert Maybe(1).to_maybe() == Maybe.just(1)
    assert Maybe(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:02:42.782837
# Unit test for method bind of class Box
def test_Box_bind():
    # Given
    box = Box(3)
    # When
    result = box.bind(lambda x: x + 1)
    # Then
    assert result == 4


# Generated at 2022-06-21 19:02:44.459914
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 19:02:46.123721
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)



# Generated at 2022-06-21 19:02:47.782551
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box('foo').to_validation() == Validation('foo')



# Generated at 2022-06-21 19:02:48.953735
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(2).to_validation() == Validation.success(2)



# Generated at 2022-06-21 19:02:57.093676
# Unit test for method map of class Box
def test_Box_map():
    assert Box(0).map(lambda x: x + 1.1) == Box(1.1)
    assert Box(0).map(lambda x: x / 2) == Box(0)
    assert Box(1).map(lambda x: x ** 20) == Box(1)
    assert Box(20).map(lambda x: x + 1) == Box(21)
    assert Box(1.1).map(lambda x: x // 2) == Box(0)
    assert Box(0).map(lambda x: str(x)) == Box('0')
    assert Box('world').map(lambda x: 'hello {}'.format(x)) == Box('hello world')
    assert Box([1, 2, 3]).map(lambda x: [i * 2 for i in x]) == Box([2, 4, 6])


# Generated at 2022-06-21 19:02:58.738995
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda a: a + 1).ap(Box(1)) == Box(2)


# Generated at 2022-06-21 19:03:00.654031
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1) and not (Box(1) == Box(2))



# Generated at 2022-06-21 19:03:02.566025
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 3).ap(Box(4)) == Box(4 + 3)

# Generated at 2022-06-21 19:03:06.622445
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box
    """
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box(2).map(lambda x: x + 2) == Box(4)
    assert Box(3).map(lambda x: x + 3) == Box(6)



# Generated at 2022-06-21 19:03:58.132767
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(2)

    new_box = box.bind(lambda x: x + 3)

    assert new_box == 5



# Generated at 2022-06-21 19:04:04.128563
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    success_val_1 = Try.success('Success')
    success_val_2 = Try.success(True)
    success_val_3 = Try.success(1)

    assert Try.is_success(Box(success_val_1).to_try())
    assert Try.is_success(Box(success_val_2).to_try())
    assert Try.is_success(Box(success_val_3).to_try())

# Generated at 2022-06-21 19:04:06.617447
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    # Arrange
    box = Box("Hello")

    # Act
    string = str(box)

    # Assert
    assert string == 'Box[value=Hello]'



# Generated at 2022-06-21 19:04:11.690792
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit tests for method to_maybe of class Box

    """
    from pymonet.maybe import Maybe

    maybe = Box(1).to_maybe()
    assert maybe == Maybe.just(1)
    assert maybe.is_just
    assert maybe != Maybe.nothing()
    assert maybe.is_nothing is False



# Generated at 2022-06-21 19:04:13.112831
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try().is_success() == True
    assert Box("hello").to_try().is_success() == True


# Generated at 2022-06-21 19:04:14.813980
# Unit test for method map of class Box
def test_Box_map():
    assert Box(5).map(lambda x: x + 5) == Box(10)


# Generated at 2022-06-21 19:04:18.693297
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) == Box(1)) == True
    assert (Box(1) == Box(2)) == False
    assert (Box(1) == 1) == False



# Generated at 2022-06-21 19:04:20.397447
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda a: a*a) == Box(4)



# Generated at 2022-06-21 19:04:22.826514
# Unit test for method ap of class Box
def test_Box_ap():
    def func(a): return a ** 2
    new_Box = Box(func).ap(Box(3))

    assert new_Box.value == 9, 'Box.ap test fails'



# Generated at 2022-06-21 19:04:24.132349
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('string')) == 'Box[value=string]'