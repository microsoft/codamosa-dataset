

# Generated at 2022-06-21 18:54:49.765718
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box("test")) == "Box[value=test]"



# Generated at 2022-06-21 18:54:51.550316
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 18:54:54.547153
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box(3)
    box_2 = Box(3)
    box_3 = Box(4)

    assert box_1 == box_2
    assert not box_1 == box_3



# Generated at 2022-06-21 18:54:55.504361
# Unit test for constructor of class Box
def test_Box():
    box = Box(True)
    assert box.value is True



# Generated at 2022-06-21 18:54:58.132302
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box('Hello').to_maybe() == Maybe.just('Hello')


# Generated at 2022-06-21 18:55:00.025645
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(2)) == Box(4)

# Generated at 2022-06-21 18:55:03.923931
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    assert Maybe.just(1) == Box(1).to_maybe()
    assert Nothing() == Box(None).to_maybe()



# Generated at 2022-06-21 18:55:05.665730
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.maybe import Maybe

    assert Box(lambda x: x + 1).ap(Maybe(2)).value == 3

# Generated at 2022-06-21 18:55:07.516310
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 18:55:10.001887
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Unit test for method bind of class Box

    :returns: None
    :rtype: None
    """

    def inc(a):  # pragma: no cover
        return a + 1

    assert Box(1).bind(inc) == 2



# Generated at 2022-06-21 18:55:13.961904
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation() == Validation.success(5)


# Generated at 2022-06-21 18:55:16.674291
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    class SubClass(Box):
        pass

    a = Box(1)
    b = SubClass(1)

    assert a == b

# Generated at 2022-06-21 18:55:20.260114
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(123).to_validation() == Validation.success(123)

# Generated at 2022-06-21 18:55:25.502722
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Test Box to_validation method.

    :returns: nothing
    :rtype: None
    """
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:55:27.502787
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 18:55:31.561050
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Unit test for method to_either of class Box

    :returns: nothing
    :rtype: None
    """
    from pymonet.either import Right

    assert Box('test').to_either() == Right('test')


# Generated at 2022-06-21 18:55:34.235602
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(5).to_validation() == Validation.success(5)
    assert Box(5).to_validation() != Validation.fail([5])


# Generated at 2022-06-21 18:55:36.292198
# Unit test for method ap of class Box
def test_Box_ap():
    def multiply(a): return a * 2

    Box(multiply).ap(Box(3)).to_either().value == 6


# Generated at 2022-06-21 18:55:39.454684
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box('test').to_either() == Right('test')
    assert Box(lambda x: x).to_either() == Right(lambda x: x)



# Generated at 2022-06-21 18:55:48.035203
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box
    """
    from pymonet.applicative import Applicative
    from pymonet.lazy import Lazy

    assert Box(1).ap(Box(lambda x: x + 1)).value == 2
    assert Box(1).ap(Lazy(lambda: 2)).value == 2

    class SomeClass(Applicative[int]):
        """
        Class for testing method ap of class Box
        """

        def __init__(self, value: int) -> None:
            """
            :param value: value to store in SomeClass
            :type value: int
            """
            self.value = value

        def __eq__(self, other: object) -> bool:
            return isinstance(other, SomeClass) and self.value == other.value


# Generated at 2022-06-21 18:55:54.268800
# Unit test for constructor of class Box
def test_Box():
    assert Box(1) == Box(1)
    assert repr(Box(1)) == "Box[value=1]"
    assert Box(1).bind(lambda x: x) is 1
    assert Box(1).map(lambda x: x) == Box(1)
    assert Box(1).ap(Box(lambda x: x + 2)) == Box(3)

# Generated at 2022-06-21 18:55:58.155139
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of Box class
    """
    assert Box(1) == Box(1)
    assert Box(1) != Box(0)
    assert Box(1) != 0



# Generated at 2022-06-21 18:56:01.399582
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('2')) == 'Box[value=2]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(True)) == 'Box[value=True]'



# Generated at 2022-06-21 18:56:03.607435
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x * 2).ap(Box(4)) == Box(8)


# Generated at 2022-06-21 18:56:08.270419
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Failure

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(Failure(ValueError('test'))).to_try() == Try(Failure(ValueError('test')), is_success=True)


# Generated at 2022-06-21 18:56:13.776505
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(2).bind(lambda x: x + 2) == 4
    assert Box(2).map(lambda x: x + 2) == Box(4)
    assert Box(2).map(lambda x: x + 2).bind(lambda x: x - 2) == Box(2)



# Generated at 2022-06-21 18:56:18.270316
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test method ap of class Box.

    .. code-block:: python
       :linenos:

       from pymonet.monad import Box

       # Create Box which contains function
       Box(lambda a: a * 2)
        .ap(Box(2))
       # Result: Box(4)
    """
    from pymonet.box import Box

    assert Box(lambda a: a * 2).ap(Box(2)) == Box(4)



# Generated at 2022-06-21 18:56:20.433536
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Box(5).to_lazy()

# Generated at 2022-06-21 18:56:26.514663
# Unit test for method map of class Box
def test_Box_map():
    """
    Unit test for method map of class Box

    :returns: Nothing
    :rtype: None
    :raises AssertionError: if test failed
    """
    def mapper(value):
        return value

    assert Box('text').map(mapper) == Box('text')
    assert Box(15).map(mapper) == Box(15)



# Generated at 2022-06-21 18:56:29.331887
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)



# Generated at 2022-06-21 18:56:36.500438
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box.
    """
    # pylint: disable=W0612
    @given(integers(), integers())
    def test_impl(x: int, y: int):
        """
        Test implementation.
        """
        assert_that(Box(x).ap(Box(y)), equal_to(Box(x(y))))
    test_impl()

# Generated at 2022-06-21 18:56:39.250095
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 18:56:44.726430
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    # Test case: when Box instance is empty
    box = Box(None)
    assert box.to_validation() == Validation.success(None)

    # Test case: when Box instance is not empty
    box = Box(2)
    assert box.to_validation() == Validation.success(2)



# Generated at 2022-06-21 18:56:49.723065
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left

    assert Box(10).to_either() == Right(10)
    assert Box(None).to_either() == Right(None)
    assert Box([]).to_either() == Right([])
    assert Box({}).to_either() == Right({})
    assert Box(Left(10)).to_either() == Right(Left(10))



# Generated at 2022-06-21 18:56:51.074033
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:56:54.280052
# Unit test for constructor of class Box
def test_Box():
    box = Box(2)
    assert isinstance(box, Box)
    assert box.value == 2



# Generated at 2022-06-21 18:56:56.421228
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test suite for Box#bind

    """
    assert Box(3).bind(lambda x: x + 2) == 5


# Generated at 2022-06-21 18:57:01.202468
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(None) == Box(None)
    assert not Box(None) == Box(1)
    assert not Box(None) == False
    assert not Box(None) == True
    assert not Box(None) == 1
    assert not Box(None) == 1.1
    assert not Box(None) == ''
    assert not Box(None) == b''
    assert not Box(None) == ()
    assert not Box(None) == []
    assert not Box(None) == {}


# Generated at 2022-06-21 18:57:02.673835
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-21 18:57:05.705264
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box('test')) == 'Box[value=test]'

# Generated at 2022-06-21 18:57:14.460206
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box('a').to_either() == Right('a')
    assert Box([1, 3]).to_either() == Right([1, 3])
    assert Box({'a': 1}).to_either() == Right({'a': 1})



# Generated at 2022-06-21 18:57:17.777036
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    # Arrange
    lazy_box = Lazy(lambda: Box(2)).to_box()

    # Act
    result = lazy_box.to_lazy()

    # Assert
    assert isinstance(result, Lazy)
    assert result.fold(lambda: Box(2)) == lazy_box



# Generated at 2022-06-21 18:57:19.241271
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert_that(Box(1).to_validation(), equal_to(Validation.success(1)))

# Generated at 2022-06-21 18:57:23.888465
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Case: test method to_maybe of class Box
    Expected: return non empty Maybe monad with previous value
    """
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 18:57:28.021241
# Unit test for method map of class Box
def test_Box_map():
    # Arrange
    box = Box(5)
    mapper = lambda number: number + 1

    # Act
    mapped_box = box.map(mapper)

    # Assert
    assert mapped_box == Box(6)


# Generated at 2022-06-21 18:57:29.804249
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(2).to_maybe() == Maybe.just(2)


# Generated at 2022-06-21 18:57:32.197053
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Failure

    assert Box(5).to_try() == Try.success(5)
    assert Box(Failure(5)).to_try() == Failure(5)



# Generated at 2022-06-21 18:57:35.656034
# Unit test for method map of class Box
def test_Box_map():
    result = Box(10).map(lambda x: x ** 2)
    assert isinstance(result, Box)
    assert result.value == 100


# Generated at 2022-06-21 18:57:40.353786
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    assert Box(3).to_maybe() == Maybe.just(3)
    assert Box(0).to_maybe() == Maybe.just(0)
    assert Box(None).to_maybe() == Maybe.just(None)
    assert isinstance(Box(None).to_maybe(), Maybe)



# Generated at 2022-06-21 18:57:43.375339
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.either import Left

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(Left(1)).to_lazy() == Lazy(lambda: Left(1))


# Generated at 2022-06-21 18:57:52.144281
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x ** 2) == Box(4)
    assert Box("hello").map(lambda word: word.capitalize()) == Box("Hello")



# Generated at 2022-06-21 18:57:53.234218
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(3).to_either() == Box(3).to_lazy().run()

# Generated at 2022-06-21 18:57:55.407625
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)

    assert not Box(1) == Box(None)



# Generated at 2022-06-21 18:57:59.983945
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Box(10).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 10


# Generated at 2022-06-21 18:58:10.016624
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    assert Box(1).to_maybe() == Maybe.just(1)
    assert type(Box(1).to_maybe()) == Maybe
    assert type(Box(1).to_maybe()) == Maybe
    assert isinstance(Box(1).to_maybe().value, int)
    assert Box('a').to_maybe() == Maybe.just('a')
    assert type(Box('a').to_maybe().value) == str
    assert Box([]).to_maybe() == Maybe.just([])
    assert type(Box([]).to_maybe().value) == list
    assert Box(Nothing()).to_maybe() == Maybe.just(Nothing())
    assert type(Box(Nothing()).to_maybe()) == Maybe
    assert type(Box(Nothing()).to_maybe().value) == Nothing

# Generated at 2022-06-21 18:58:21.624880
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(2) == Box(2)
    assert not Box(2) == Box(3)
    assert not Box(2) == None
    assert not Box(7) == {}
    assert not Box("hello") == Box("world")
    assert not Box([1, 2]) == 1
    assert not Box({"key": "value"}) == "value"
    assert Box(9.0) == Box(9.0)
    assert not Box(15) == Box(42)
    assert not Box("15") == Box(15)
    assert not Box("15") == Box(True)
    assert Box(True) == Box(True)
    assert not Box(None) == Box(True)
    assert Box(8) == Box(8)

# Generated at 2022-06-21 18:58:23.400632
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(4).bind(lambda x: x * 2) == 8


# Generated at 2022-06-21 18:58:27.060127
# Unit test for method map of class Box
def test_Box_map():
    assert isinstance(Box(10).map(lambda x: x + 1), Box)
    assert Box(10).map(lambda x: x + 1).value == 11
    assert Box(10).map(lambda x: x + 1) != Box(11)

# Generated at 2022-06-21 18:58:34.062364
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    def test_success():
        value = 5
        box = Box(value)
        maybe = box.to_maybe()

        assert maybe.is_just()
        assert maybe.value() == value

    def test_fail():
        box = Box(None)
        maybe = box.to_maybe()

        assert maybe.is_nothing()

    test_success()
    test_fail()



# Generated at 2022-06-21 18:58:37.082587
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-21 18:58:50.552799
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert(Box(3).to_lazy() == Box(3).to_lazy())

# Generated at 2022-06-21 18:58:52.225711
# Unit test for constructor of class Box
def test_Box():
    assert Box(123) == Box(123)
    assert Box(123).value == 123


# Unit tests for method map of class Box

# Generated at 2022-06-21 18:58:56.482407
# Unit test for method map of class Box
def test_Box_map():
    assert Box(8).map(lambda x: x ** 2) == Box(64)
    assert Box(8).map(lambda x: 'abc') == Box('abc')
    assert Box([1, 2, 3]).map(lambda x: x[:2]) == Box([1, 2])



# Generated at 2022-06-21 18:59:06.724625
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Right

    assert Box(lambda a: a * 2).ap(Box(2)) == Box(4)
    assert Box(lambda a: a * 2).ap(Maybe(2)) == Maybe(4)
    assert Box(lambda a: a * 2).ap(Right('2')) == Right(4)
    assert Box(lambda a: a * 2).ap(Functor(lambda a: a * 2)) == Functor(4)
    assert Box(lambda a: a * 2).ap(Applicative(lambda a: a * 2, 2)) == Applicative(4, 2)


# Generated at 2022-06-21 18:59:09.513587
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    value = 123
    box = Box(value)
    assert box.value == 123

    lazy = box.to_lazy()
    assert type(lazy) == Lazy

    assert lazy.force() == 123



# Generated at 2022-06-21 18:59:13.401974
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box

    :return:
    :rtype:
    """
    def add(arg):
        return arg + 2

    assert Box(add).ap(Box(1)) == Box(3)

# Generated at 2022-06-21 18:59:24.526972
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.exceptions import MonadException
    from pymonet.maybe import Maybe

    # Test for: Case: Success, When: Return non empty Maybe
    assert Maybe(1).map(lambda x: x + 1) == Maybe(2)

    # Test for: Case: Success, When: Return empty Maybe
    assert Maybe(1).map(lambda x: None) == Maybe.empty()
    assert Maybe(None).map(lambda x: None) == Maybe.empty()

    # Test for: Case: Success, When: Return None
    assert Maybe(1).map(lambda x: None) == Maybe.empty()

    # Test for: Case: Failure, When: Return MonadException
    with pytest.raises(MonadException):
        Maybe(1).map(None)

    # Test for: Case: Success, When: Return Box


# Generated at 2022-06-21 18:59:25.826571
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Right(1) == Box(1).to_either()

# Generated at 2022-06-21 18:59:28.285939
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box_1 = Box('abc')
    box_2 = Box('abc')
    assert box_1 == box_2

# Generated at 2022-06-21 18:59:30.930851
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    value = 'foo'
    box = Box(value)
    assert str(box) == 'Box[value={}]'.format(value)



# Generated at 2022-06-21 19:00:02.736162
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def returning_value(value: int) -> int:  # pragma: no cover
        return value

    assert Lazy(lambda: 1).fold(returning_value) == Box(1).to_lazy().fold(returning_value)

# Generated at 2022-06-21 19:00:05.374844
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, True)


# Unit tests for method ap of class Box

# Generated at 2022-06-21 19:00:07.490809
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(100).to_validation() == Validation.success(100)


# Generated at 2022-06-21 19:00:10.591814
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Unit test for method ap of class Box.
    """
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(lambda x: x + 1)(1)

# Generated at 2022-06-21 19:00:11.998743
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either().right == 1



# Generated at 2022-06-21 19:00:17.027409
# Unit test for method map of class Box
def test_Box_map():

    assert Box(2).map(lambda x: x*2) == Box(4)
    assert Box('world').map(lambda x: 'hello {}'.format(x)) == Box('hello world')
    assert Box(1).map(lambda x: x**2 - x) == Box(0)


# Generated at 2022-06-21 19:00:21.902820
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test for method bind of class Box
    """

    def add_num(a: int) -> int:
        """
        Function add to param 2 numbers.

        :param a: number to add 2
        :type a: int
        :returns: a + 2
        :rtype: int
        """
        return a + 2

    box = Box(1)

    assert box.bind(add_num) == 3


# Generated at 2022-06-21 19:00:30.111364
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.monad_list import MonadList
    from pymonet.maybe import Maybe
    def add_one(x: int) -> int:
        return x + 1

    assert Box(2).bind(add_one) == 3

    assert Box(2).bind(lambda x: Box(x + 1)) == Box(3)

    assert Box(2).bind(lambda x: Maybe.just(x + 1)) == 3

    assert Box(2).bind(lambda x: MonadList([x + 1])) == [3]


# Generated at 2022-06-21 19:00:35.665368
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, Failure

    assert Box(10).to_try() == Try(10, is_success=True)

    failure = Failure(ValueError('Error'))
    assert Box(failure).to_try() == failure


# Generated at 2022-06-21 19:00:41.274514
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)
    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box('a').to_maybe() == Maybe.just('a')
    assert Box(True).to_maybe() == Maybe.just(True)


# Perform unit tests with pytest
if __name__ == "__main__":
    import pytest

    pytest.main()

# Generated at 2022-06-21 19:01:46.125103
# Unit test for method to_try of class Box
def test_Box_to_try():
    try:
        assert Box("Hello") == Box("Hello").to_try().to_box()
        assert Box("World").to_try().to_box() == Box("World")
    except AssertionError:
        print("Test failed!")


# Generated at 2022-06-21 19:01:48.075506
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either, Right

    box = Box(10)
    assert isinstance(box.to_either(), Either)
    assert isinstance(box.to_either(), Right)
    assert box.to_either().value == box.value



# Generated at 2022-06-21 19:01:49.774660
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))



# Generated at 2022-06-21 19:01:51.268853
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)


# Generated at 2022-06-21 19:01:52.935816
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not (Box(1) == Box(2))


# Generated at 2022-06-21 19:01:54.963103
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit test of to_lazy method of class Box.
    """
    assert Box(1).to_lazy().fold() == 1

# Generated at 2022-06-21 19:01:58.435914
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    assert hasattr(Box, 'bind')
    assert callable(Box.bind)
    assert isinstance(Box.bind, Monad)
    assert isinstance(Box.bind, Applicative)
    assert isinstance(Box.bind, Functor)



# Generated at 2022-06-21 19:01:59.864222
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: Box(x + 1)) == Box(2)

# Generated at 2022-06-21 19:02:01.825565
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(value='value')
    assert box.to_lazy().value() == box.value

# Generated at 2022-06-21 19:02:04.992600
# Unit test for method to_lazy of class Box
def test_Box_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy

    def func():
        return 42

    lazy = Lazy(func)

    box = Box(42)

    assert box.to_lazy() == lazy

# Generated at 2022-06-21 19:03:18.298649
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(5).value == 5
    assert Box('5').value == '5'



# Generated at 2022-06-21 19:03:19.981134
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    assert Box(1).to_either() == Right(1)

# Generated at 2022-06-21 19:03:24.234459
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box('1')
    assert Box(1) != Box(2)
    assert Box(1) != Box(None)
    assert Box(None) == Box(None)



# Generated at 2022-06-21 19:03:30.646892
# Unit test for method bind of class Box
def test_Box_bind():
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    name = Box('Harry')
    age = Box(12)
    result = name.bind(lambda name: age.bind(lambda age: Maybe.just(name + ' ' + str(age))))

    assert result == Maybe.just('Harry 12')

    result = name.bind(lambda name: age.bind(lambda age: Right(name + ' ' + str(age))))

    assert result == Right('Harry 12')

# Generated at 2022-06-21 19:03:33.491632
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Box(1).to_lazy()


# Generated at 2022-06-21 19:03:37.229429
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    x = Box(1)
    y = x.to_validation()
    assert y == Validation(1, [])

# Generated at 2022-06-21 19:03:39.694187
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 19:03:43.785354
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    To test to_lazy() method of Box class.
    """
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-21 19:03:45.597810
# Unit test for constructor of class Box
def test_Box():
    assert Box(3) == Box(3)



# Generated at 2022-06-21 19:03:47.523197
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    my_box = Box(10)
    assert my_box.to_maybe() == Maybe.just(10)
