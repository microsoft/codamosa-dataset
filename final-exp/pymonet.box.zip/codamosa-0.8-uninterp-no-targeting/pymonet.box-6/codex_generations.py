

# Generated at 2022-06-21 18:54:56.042003
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def to_lazy_test():
        boxlist = Box([1, 2, 3, 4])
        assert boxlist.to_lazy() == Lazy(lambda: [1, 2, 3, 4])

        return 'to_lazy_test done'

    assert to_lazy_test() == 'to_lazy_test done'


# Generated at 2022-06-21 18:54:56.972701
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box('abc').ap(Box(lambda x: 3 * x)) == Box('abcabcabc')



# Generated at 2022-06-21 18:54:59.478264
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(42).to_maybe() == Maybe.just(42)


# Generated at 2022-06-21 18:55:04.984887
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('test') == Box('test')
    assert Box(1) == Box(1)
    assert Box(1.0) == Box(1.0)
    assert Box(None) == Box(None)
    assert Box(1) != Box('test')
    assert Box(1) != Box(1.0)



# Generated at 2022-06-21 18:55:07.415763
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad import identity

    result = Box(1).to_try().value
    expected = identity(1)

    assert result == expected



# Generated at 2022-06-21 18:55:09.683198
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert not Box(10) == Box(11)
    assert not Box(10) == 10


# Generated at 2022-06-21 18:55:11.206286
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-21 18:55:14.604431
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('hello')) == 'Box[value=hello]', 'Box(hello).__str__() should be equal to Box[value=hello]'



# Generated at 2022-06-21 18:55:17.084459
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Box(1).to_either() != Box(2).to_either()


# Generated at 2022-06-21 18:55:24.040274
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    Unit test for method __eq__ of class Box
    """
    assert Box(10) == Box(10)
    assert Box(10) != Box(20)
    assert Box(10) != 10
    assert Box(10) != None


# Generated at 2022-06-21 18:55:29.422963
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)
    assert not Box(1) == None


# Generated at 2022-06-21 18:55:31.775544
# Unit test for constructor of class Box
def test_Box():
    assert Box(4) == Box(4)
    assert Box(4) != Box('4')
    assert Box(4) != None


# Generated at 2022-06-21 18:55:33.647194
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Right(1) == Box(1).to_either()


# Generated at 2022-06-21 18:55:35.377689
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(1).bind(lambda x: x + 1) == 2



# Generated at 2022-06-21 18:55:40.133162
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 1) == Box(2)
    assert Box('example').map(lambda x: x + 'string') == Box('examplestring')
    assert Box({'example': 1, 'example2': 2}).map(
        lambda x: x['example'] + 1) == Box(2)



# Generated at 2022-06-21 18:55:43.205990
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()

# Generated at 2022-06-21 18:55:45.089525
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 1



# Generated at 2022-06-21 18:55:53.199507
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.box import Box
    def check_value():
        assert Box(5).to_validation() == Validation(5, [])
        assert Box(None).to_validation() == Validation(None, [])
        assert Box('').to_validation() == Validation('', [])
        assert Box(0).to_validation() == Validation(0, [])
        assert Box((0, 0)).to_validation() == Validation((0, 0), [])
    check_value()



# Generated at 2022-06-21 18:55:54.998514
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 18:55:59.759467
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    from pymonet.utils import test_eq_operator

    test_eq_operator(
        Box(1),
        [
            Box(1),
            Box('1'),
        ],
        [
            Box(2),
            Box('2'),
        ]
    )



# Generated at 2022-06-21 18:56:04.624899
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """

    from pymonet.validation import Validation

    assert Validation.success(1) == Box(1).to_validation()



# Generated at 2022-06-21 18:56:06.158430
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, True)

# Generated at 2022-06-21 18:56:07.798758
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(2)) == "Box[value=2]"


# Generated at 2022-06-21 18:56:10.495948
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:56:12.888250
# Unit test for method bind of class Box
def test_Box_bind():
    def inc(x: int) -> int:
        return x + 1

    assert Box(1).bind(inc) == inc(1)



# Generated at 2022-06-21 18:56:14.189079
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2


# Generated at 2022-06-21 18:56:22.234130
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) == Box(1).to_validation()
    assert Validation.success(1) == Box('1').to_validation()
    assert Validation.success(1) == Box(1).to_validation()
    assert Validation.success(1) == Box(True).to_validation()
    assert Validation.success(1) == Box(1.0).to_validation()
    assert Validation.success(1) != Box(2).to_validation()
    assert Validation.success(1) != Box('2').to_validation()
    assert Validation.success(1) != Box(2).to_validation()

# Generated at 2022-06-21 18:56:26.663558
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    from pymonet.test_utils import test_value_and_type

    test_value_and_type(Box, 'value', [1, 2.0, 'a'])


# Generated at 2022-06-21 18:56:28.333233
# Unit test for constructor of class Box
def test_Box():
    result = Box('something')
    assert result.value == 'something'

# Generated at 2022-06-21 18:56:31.598744
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box('value').to_either() == Box(1).to_either() == Box(None).to_either() == Box(False).to_either() == \
           Box(True).to_either()

# Generated at 2022-06-21 18:56:36.109584
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    """
    Unit test for method __str__ of class Box.
    """

    assert str(Box(True)) == 'Box[value=True]'

# Generated at 2022-06-21 18:56:37.541833
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None



# Generated at 2022-06-21 18:56:41.358378
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert Box('foo').__str__() == 'Box[value=foo]'
    assert Box(1).__str__() == 'Box[value=1]'


# Generated at 2022-06-21 18:56:43.855574
# Unit test for method to_either of class Box
def test_Box_to_either():  # pragma: no cover
    from pymonet.either import Right

    assert Box(7).to_either() == Right(7)



# Generated at 2022-06-21 18:56:45.511413
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)



# Generated at 2022-06-21 18:56:48.710789
# Unit test for method ap of class Box
def test_Box_ap():
    # Given
    box = Box('42')
    applicative = Box(lambda a: a * 4)
    expected = '4242'

    # When
    result = box.ap(applicative)

    # Then
    assert result == expected

# Generated at 2022-06-21 18:56:54.795592
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box.

    :returns: None
    :raises: AssertionError
    """

    from typing import Any

    from pymonet.maybe import Maybe
    from pymonet.monad import Monad

    assert isinstance(Box(Any).to_maybe(), Monad)
    assert Box(1).to_maybe() == Maybe(1)
    assert Box(None).to_maybe() == Maybe(None)


# Generated at 2022-06-21 18:56:59.368431
# Unit test for method ap of class Box
def test_Box_ap():
    square = lambda x: x ** 2
    double = lambda x: x * 2
    triple = lambda x: x * 3
    box_square = Box(square)
    box_double = Box(5).ap(box_square).ap(Box(double))
    box_triple = Box(5).ap(box_square).ap(Box(triple))
    assert box_double.value == 50
    assert box_triple.value == 75

# Generated at 2022-06-21 18:57:02.057367
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: lambda y: x + y).ap(Box(1)).ap(Box(2)) == Box(3)

test_Box_ap()

# Generated at 2022-06-21 18:57:06.833365
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    """
    Unit testing for Box.to_lazy()
    """
    from pymonet.lazy import Lazy

    assert Box('a').to_lazy() == Lazy(lambda: 'a')

# Generated at 2022-06-21 18:57:16.099505
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Tests to_validation method of Box class.
    """
    from pymonet.validation import Validation
    box = Box(1)
    assert(isinstance(box.to_validation(), Validation))
    assert(Validation.success(1) == box.to_validation())


# Generated at 2022-06-21 18:57:22.506843
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.either import Either
    from pymonet.maybe import Maybe

    assert Box(None).value is None
    assert Box(1).value == 1
    assert Box(1.0).value == 1.0
    assert Box('Hi').value == 'Hi'
    assert Box([]).value == []
    assert Box([1, 2, 3]).value == [1, 2, 3]
    assert Box({}).value == {}
    assert Box({'a': 1}).value == {'a': 1}
    assert Box(Try.of(None)).value == Try.of(None)

# Generated at 2022-06-21 18:57:27.173920
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test convertion Box to Lazy.

    :returns: the assert check
    :rtype: Bool
    """
    from pymonet.lazy import Lazy
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 18:57:30.341842
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Box(3).to_lazy()

    assert lazy.fold(lambda x: x) == 3
    assert isinstance(lazy, Lazy)



# Generated at 2022-06-21 18:57:31.492192
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:57:33.375499
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(5).to_maybe() == Box(5).bind(lambda x: x)

# Generated at 2022-06-21 18:57:39.545463
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Box('A').to_maybe() == Maybe('A')
    assert Box('').to_maybe() == Maybe('')
    assert Box(1).to_maybe() == Maybe(1)
    assert Box(Try(1, is_success=True)).to_maybe() == Maybe(1)


# Generated at 2022-06-21 18:57:41.243054
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 18:57:43.581167
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert(Box(1).to_try() == Try.just(1))


# Generated at 2022-06-21 18:57:47.089284
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box
    """
    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 18:57:59.859760
# Unit test for method bind of class Box
def test_Box_bind():
    result = Box(1).bind(lambda x: Box(x + 1))

    assert isinstance(result, Box)
    assert result.value == 2


# Generated at 2022-06-21 18:58:01.215756
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(10).bind(lambda x: x * x) == 100



# Generated at 2022-06-21 18:58:02.887862
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    _Box = Box(100).to_lazy()
    assert _Box == Box(100)

# Generated at 2022-06-21 18:58:05.498810
# Unit test for method to_try of class Box
def test_Box_to_try():
    try_from_box_monad = Box('1').to_try()
    assert '1' == try_from_box_monad.value


# Generated at 2022-06-21 18:58:06.830307
# Unit test for constructor of class Box
def test_Box():
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:58:09.662902
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(10) == Box(10)
    assert Box(10) != Box(10.0)
    assert Box(10) != Box('10')



# Generated at 2022-06-21 18:58:10.896624
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(42)) == 'Box[value=42]'

# Generated at 2022-06-21 18:58:19.645172
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def lazy_value():
        return 2

    assert Box(lazy_value).to_lazy() == Lazy(lazy_value)
    assert Box(lambda: 2).to_lazy().get() == 2
    assert Box(2).to_lazy().get() == 2
    assert Box(Try(2, is_success=True)).to_lazy().get() == 2
    assert Box(Try(None, is_success=False)).to_lazy().get() == None

# Generated at 2022-06-21 18:58:21.710036
# Unit test for constructor of class Box
def test_Box():
    assert Box("test") == Box("test")
    assert Box("test") != Box("test1")


# Generated at 2022-06-21 18:58:25.428990
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Box(lambda x: x + 1).ap(Box(2)) == Box(3)


# Generated at 2022-06-21 18:58:45.741367
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    v = Validation.failure('Error message')
    assert Validation == v.to_box().to_validation().__class__


# Generated at 2022-06-21 18:58:47.064628
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try().is_success() == True
    assert Box(1).to_try().get() == 1

# Generated at 2022-06-21 18:58:50.912409
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(True)) == 'Box[value=True]'



# Generated at 2022-06-21 18:58:52.686518
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    assert Box(123).to_lazy() == Lazy(lambda: 123)

# Generated at 2022-06-21 18:58:57.592768
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: 1 + x) == 2
    assert Box(4).bind(lambda x: 1 + x) == 5
    assert Box('1').bind(lambda x: x + '2') == '12'
    assert Box('1').bind(lambda x: x + '2') == '12'



# Generated at 2022-06-21 18:59:00.647576
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    actual = Box("123").to_either()

    assert actual == Right("123")



# Generated at 2022-06-21 18:59:03.194305
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(1)
    assert box == box
    assert box == Box(1)
    assert box != Box(2)
    assert box != None


# Generated at 2022-06-21 18:59:04.560885
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda i: i + 1) == 2

# Generated at 2022-06-21 18:59:06.106985
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 2) == Box(4)



# Generated at 2022-06-21 18:59:07.382117
# Unit test for method map of class Box
def test_Box_map():
    unit = Box(1).map(lambda x: x)
    assert unit.value == 1 and isinstance(unit, Box)



# Generated at 2022-06-21 18:59:27.127300
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box("some string").to_either().is_right() is True
    assert Box("some string").to_either().is_left() is False

# Generated at 2022-06-21 18:59:36.135351
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert Box(10).__str__() == "Box[value=10]"  # pragma: no cover
    assert Box(10.5).__str__() == "Box[value=10.5]"  # pragma: no cover
    assert Box("10").__str__() == "Box[value=10]"  # pragma: no cover
    assert Box([1, 2, 3]).__str__() == "Box[value=[1, 2, 3]]"  # pragma: no cover
    assert Box({"a": 1, "b": 2}).__str__() == "Box[value={'a': 1, 'b': 2}]"  # pragma: no cover

# Generated at 2022-06-21 18:59:39.415518
# Unit test for method ap of class Box
def test_Box_ap():
    box_of_function = Box(lambda x: x ** 2)
    box_of_number = Box(10)
    assert box_of_function.ap(box_of_number) == Box(100)



# Generated at 2022-06-21 18:59:41.348227
# Unit test for method bind of class Box
def test_Box_bind():  # pragma: no cover
    assert Box(2).bind(lambda value: value ** 3) == 8


# Generated at 2022-06-21 18:59:43.839996
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box("foo").bind(lambda x: x + "bar") == "foobar"


# Generated at 2022-06-21 18:59:46.742464
# Unit test for method map of class Box
def test_Box_map():
    assert Box(10).map(lambda x: x + 2) == Box(12)
    assert Box(10).map(lambda x: "test") == Box("test")
    assert Box(10).map(lambda x: None) == Box(None)

# Generated at 2022-06-21 18:59:48.822134
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box('test')) == 'Box[value=test]'
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box({})) == 'Box[value={}]'



# Generated at 2022-06-21 18:59:50.926928
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 18:59:54.735420
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(True) == Box(True)
    assert Box('s') == Box('s')
    assert not (Box(1) == Box(True))

    # ToDo: It's bug?
    #assert Box(None) == Box(None)



# Generated at 2022-06-21 18:59:57.752794
# Unit test for constructor of class Box
def test_Box():
    """Unit test for constructor of class Box."""

    assert Box(5) == Box(5)
    assert not Box(2) == Box(5)

    assert str(Box(5)) == 'Box[value=5]'



# Generated at 2022-06-21 19:00:45.986685
# Unit test for method to_try of class Box
def test_Box_to_try():

    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    assert Box(1).to_try() == Try(1, is_success=True)
    assert Box(1).to_try() != Try(1, is_success=False)
    assert Box(1).to_try() != Try(2, is_success=True)
    assert Box(1).to_try() != Try(2, is_success=False)
    assert Box(1).to_try() != Try(1, is_success=True, e=Failure(ValueError))
    assert Box(1).to_try() != Try(1, is_success=False, e=Failure(ValueError))

# Generated at 2022-06-21 19:00:50.310326
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).to_maybe()
    assert Box(1).to_maybe() == Box(1).bind(lambda x: Maybe.just(x))
    assert Box(Maybe.empty()).to_maybe() == Maybe.empty()



# Generated at 2022-06-21 19:00:57.235733
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """
    from pymonet.validation import Validation
    from pymonet.validation_error import ValidationError

    assert Box(3).to_validation() == Validation.success(3)
    assert Box(3).to_validation().is_success
    assert Box(3).to_validation().is_failure is False
    assert Box(3).to_validation().value == 3
    assert Box(3).to_validation().errors == []

    assert Box("3").to_validation() == Validation.success("3")
    assert Box("3").to_validation().is_success
    assert Box("3").to_validation().is_failure is False
    assert Box("3").to_validation().value == "3"


# Generated at 2022-06-21 19:01:00.157889
# Unit test for method map of class Box
def test_Box_map():
    def plus_one(x: int) -> int:
        return x + 1

    assert Box(1).map(plus_one) == Box(2)



# Generated at 2022-06-21 19:01:02.865244
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 19:01:04.988837
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """
    assert Box(42).to_validation() == Validation(42, [])

# Generated at 2022-06-21 19:01:08.321843
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    box = Box(1)

    validation = box.to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.value == 1



# Generated at 2022-06-21 19:01:11.670165
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.monad import Box

    f = Box(1).to_either()

    assert isinstance(f, Right)
    assert f.value == 1



# Generated at 2022-06-21 19:01:17.330674
# Unit test for method map of class Box
def test_Box_map():
    from pymonet.maybe import is_just, is_nothing
    from pymonet.either import is_left, is_right
    from pymonet.lazy import is_forced, is_lazy
    from pymonet.monad_try import is_success, is_failure
    from pymonet.validation import is_success as is_success_validation, is_failure as is_failure_validation
    from pymonet.list import is_list, is_nil
    from pymonet.set import is_set
    from pymonet.dict import is_dict, is_empty_dict

    assert str(Box(5).map(lambda x: x ** 2)) == 'Box[value=25]'
    assert is_just(Box(5).map(lambda x: x ** 2).to_maybe())


# Generated at 2022-06-21 19:01:19.941355
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert isinstance(Box(1).to_validation(), Validation)



# Generated at 2022-06-21 19:02:57.278119
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either().is_right
    assert Box((1, 2)).to_either().right == (1, 2)


# Generated at 2022-06-21 19:02:58.908643
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert not Box(1) == Box(2)


# Generated at 2022-06-21 19:03:01.562720
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(2).map(lambda x: x ** 2) == Box(4)



# Generated at 2022-06-21 19:03:03.198294
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    a = Box(1)
    assert type(a.to_lazy()) == Lazy


# Generated at 2022-06-21 19:03:05.499179
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.either import Left

    assert Box(1).to_either() == Right(1)
    assert Box(None).to_either() == Right(None)

# Generated at 2022-06-21 19:03:09.507786
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    from hamcrest.core.assert_that import assert_that
    from hamcrest.core.core.isequal import equal_to
    from hamcrest.library.collection.haslength import has_length

    numbers = Box(1000)
    assert_that(
        numbers,
        equal_to(Box(1000)))
    assert_that(
        numbers.bind(lambda x: str(x)),
        equal_to("1000"))


# Generated at 2022-06-21 19:03:11.065241
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    box = Box(1)

    assert box.to_either() == Right(1)



# Generated at 2022-06-21 19:03:12.098851
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 2).ap(Box(3)) == Box(5)



# Generated at 2022-06-21 19:03:13.472590
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1).ap(Box(1)) == Box(2)

# Generated at 2022-06-21 19:03:15.727950
# Unit test for method ap of class Box
def test_Box_ap():
    def f(x):
        return x + 1

    assert Box(2).ap(Box(f)).value == 3