

# Generated at 2022-06-21 18:54:53.572426
# Unit test for method __eq__ of class Box
def test_Box___eq__():  # pragma: no cover
    assert Box(None) == Box.unit(None)
    assert not (Box(None) == Box(None).map(bool))
    assert Box(None) != Box(None).map(bool)
    assert not (Box(None) != Box(None))



# Generated at 2022-06-21 18:54:55.165517
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x + 3) == Box(5)



# Generated at 2022-06-21 18:54:58.451814
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Unit test for method to_maybe of class Box
    """
    assert Box(1).to_maybe() == Maybe.just(1)
    assert Box(1).to_maybe().just() == 1
    assert Box(1).to_maybe().nothing() == None



# Generated at 2022-06-21 18:55:02.719955
# Unit test for method map of class Box
def test_Box_map():
    box_int = Box(1)
    box_left_int = box_int.map(lambda x: x + 1)
    assert box_left_int.value == 2


# Generated at 2022-06-21 18:55:04.519964
# Unit test for method map of class Box
def test_Box_map():
    # Assert
    assert Box(1).map(lambda x: x + 1) == Box(2)



# Generated at 2022-06-21 18:55:06.278754
# Unit test for method bind of class Box
def test_Box_bind():
    assert \
        Box(2).bind(lambda x: x / 2) == Box(1)

# Generated at 2022-06-21 18:55:07.580978
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('value')) == 'Box[value=value]'


# Generated at 2022-06-21 18:55:09.111063
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(42).to_validation() == Validation.success(42)


# Generated at 2022-06-21 18:55:13.907413
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try_funcs import run_try

    val = Box(42).to_try()
    assert isinstance(val, Try)
    assert run_try(val) == 42



# Generated at 2022-06-21 18:55:15.177791
# Unit test for constructor of class Box
def test_Box():
    assert str(Box(2)) == 'Box[value=2]'



# Generated at 2022-06-21 18:55:19.507948
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    box = Box(1)
    assert isinstance(box.to_maybe(), Maybe)
    assert box.to_maybe().to_box().value == box.value


# Generated at 2022-06-21 18:55:21.117839
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(1).map(lambda x: x * 2) == Box(2)



# Generated at 2022-06-21 18:55:23.759888
# Unit test for method __str__ of class Box
def test_Box___str__():
    t = Box("test")
    assert str(t) == 'Box[value=test]'

# Generated at 2022-06-21 18:55:27.449904
# Unit test for method bind of class Box
def test_Box_bind():
    new_box = Box(5).map(lambda x: x + 10)
    assert new_box.value == 15, "Box bind function is wrong"


# Generated at 2022-06-21 18:55:33.944241
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('string') == Box('string')
    assert Box((1, 2)) == Box((1, 2))
    assert Box([1, 2]) == Box([1, 2])
    assert Box(set((1, 2, 3))) == Box(set((1, 2, 3)))
    assert Box({'key': 'value'}) == Box({'key': 'value'})



# Generated at 2022-06-21 18:55:44.054873
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe, Nothing
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Box(10).to_maybe() == Maybe.just(10)
    assert Box(10).to_maybe().map(lambda x: x ** 2) == Maybe.just(100)
    assert Box(10).to_maybe().bind(lambda x: Maybe.just(x ** 2)) == Maybe.just(100)
    assert Box(10).to_maybe().ap(Maybe.just(lambda x: x ** 2)) == Maybe.just(100)
    assert Box(10).to_maybe().to_either() == Maybe.just(10).to_either()
    assert Box(10).to_maybe().to_lazy() == Maybe

# Generated at 2022-06-21 18:55:45.890098
# Unit test for method __str__ of class Box
def test_Box___str__():
    # arrange / act
    actual = str(Box(1))

    # assert
    assert actual == 'Box[value=1]'

# Generated at 2022-06-21 18:55:50.936384
# Unit test for method map of class Box
def test_Box_map():
    assert Box(1).map(lambda x: x + 2) == Box(3)
    assert Box('foo').map(lambda x: x + 'bar') == Box('foobar')
    assert Box(1.3).map(lambda x: x + 3j) == Box(1.3 + 3j)



# Generated at 2022-06-21 18:55:53.616774
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)
    assert Box('str').to_either() == Right('str')



# Generated at 2022-06-21 18:55:54.651628
# Unit test for constructor of class Box
def test_Box():
    assert Box(10).value == 10



# Generated at 2022-06-21 18:56:03.364644
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either
    from pymonet.either import (Right, Left)

    assert Box(100).to_either() == Right(100)
    assert Box('abc').to_either() == Right('abc')
    assert Box('123').to_either().bind(lambda x: Either.failure(int(x))) == Left(123)
    assert Box([1, 2, 3]).to_either().bind(lambda x: Either.success(type(x))) == Right(list)


# Generated at 2022-06-21 18:56:08.375246
# Unit test for method __str__ of class Box
def test_Box___str__():
    """
    Python unittest for Box[A] class.
    """
    class TestClass:
        def __init__(self):
            self.a = 'a'

    box = Box(TestClass())
    assert (str(box) == 'Box[value={}]'.format(TestClass()))


# Generated at 2022-06-21 18:56:13.163477
# Unit test for method to_either of class Box
def test_Box_to_either():

    from pymonet.either import Right, Either

    assert Box(1).to_either() == Right(1)
    assert Box(1).to_either() != Right(11)
    assert isinstance(Box(1).to_either(), Either)



# Generated at 2022-06-21 18:56:14.818999
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    assert str(Box(3)) == 'Box[value=3]'



# Generated at 2022-06-21 18:56:20.433056
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test Box#ap method.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.utils import identity, compose

    assert Box(identity).ap(Box(10)) == Box(10)
    assert Box(compose).ap(Box(identity)).ap(Box(10)) == Box(10)



# Generated at 2022-06-21 18:56:21.911571
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy()

# Generated at 2022-06-21 18:56:25.901581
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    box = Box(3)
    validation = box.to_validation()
    assert Validation.success(3) == validation



# Generated at 2022-06-21 18:56:28.387066
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:56:31.997993
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    def test_value_func():
        return 'hello world'

    assert Box(test_value_func).to_lazy() == Lazy(test_value_func)


# Generated at 2022-06-21 18:56:34.879462
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1).value == 1
    assert Box('1').value == '1'
    assert Box(True).value is True

    def func():
        pass

    assert Box(func).value is func


# Generated at 2022-06-21 18:56:37.040162
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box('test')) == "Box[value=test]"



# Generated at 2022-06-21 18:56:39.467270
# Unit test for method bind of class Box
def test_Box_bind():

    assert Box(2).bind(lambda value: value + 2) == 4


# Generated at 2022-06-21 18:56:42.246773
# Unit test for method map of class Box
def test_Box_map():
    assert Box(2).map(lambda x: x * 2) == Box(4)
    assert Box('1').map(len) == Box(1)



# Generated at 2022-06-21 18:56:44.726287
# Unit test for method bind of class Box
def test_Box_bind():
    """
    Test method bind of class Box
    """
    assert Box(1).bind(lambda x: x + 2) == 3


# Generated at 2022-06-21 18:56:47.407431
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    assert Box(lambda x: x * 3).ap(Box(2)) == Box(6)
    assert Box(lambda x: x ** 2).ap(Box(7)) == Box(49)

# Generated at 2022-06-21 18:56:49.200170
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(1)
    assert box.bind(lambda x: x + 1) == 2

# Generated at 2022-06-21 18:56:50.496024
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 3) == 4

# Generated at 2022-06-21 18:56:53.680871
# Unit test for method map of class Box
def test_Box_map():
    assert Box(5).map(lambda x: x + 5).value == 10
    assert Box(5).map(lambda x: x + 1).bind(lambda x: x + 1).value == 7



# Generated at 2022-06-21 18:56:54.956442
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2

# Generated at 2022-06-21 18:56:57.198830
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Test method to_lazy(self) of class Box"""

    assert Box(42).to_lazy().value() == 42

# Generated at 2022-06-21 18:57:01.492750
# Unit test for method bind of class Box
def test_Box_bind():
    box = Box(1)
    add_one = lambda x: x + 1
    assert box.bind(add_one) == 2

# Generated at 2022-06-21 18:57:09.128112
# Unit test for method __str__ of class Box
def test_Box___str__(): # pragma: no cover
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('a')) == 'Box[value=a]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(Exception())) == 'Box[value=Exception()]'

# Unit tests for method __eq__ of class Box

# Generated at 2022-06-21 18:57:14.406192
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Box(1).to_lazy()
    assert Box(1).to_lazy().fold() == 1
    assert Box("test").to_lazy() != Box("test2").to_lazy()
    assert Box("test").to_lazy().fold() == "test"


# Generated at 2022-06-21 18:57:18.522918
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    # GIVEN
    box_1 = Box(1)
    box_2 = Box(2)
    box_3 = Box(1)

    # THEN
    assert not (box_1 == box_2)
    assert box_1 == box_3


# Generated at 2022-06-21 18:57:21.759956
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Box('something').to_maybe() == Maybe.just('something')



# Generated at 2022-06-21 18:57:30.061621
# Unit test for constructor of class Box
def test_Box():
    assert Box('test').value == 'test'
    assert Box(4).value == 4
    assert Box(4.5).value == 4.5
    assert Box(False).value is False
    assert Box([1, 2, 3]).value == [1, 2, 3]
    assert Box((4, 5, 6)).value == (4, 5, 6)
    assert Box({'name': 'python'}).value == {'name': 'python'}
    assert Box({'py', 'mon', 'et'}).value == {'py', 'mon', 'et'}



# Generated at 2022-06-21 18:57:32.100488
# Unit test for method to_either of class Box
def test_Box_to_either():
    """
    Test to_either method of Box
    """
    from pymonet.either import Right

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:57:34.457538
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, True)

# Generated at 2022-06-21 18:57:37.007187
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(10).to_validation() == Validation.success(10)

# Generated at 2022-06-21 18:57:39.636768
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 18:57:49.923836
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation_message import StringMessage

    assert Box(1).to_validation() == Validation.success(1)
    assert Box('Hello, world').to_validation() == Validation.success('Hello, world')
    assert Box(StringMessage('Hello, world')).to_validation() == Validation.success(StringMessage('Hello, world'))

# Generated at 2022-06-21 18:57:52.521924
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert (Box(1) == Box(1)) == True
    assert (Box(1) == Box(2)) == False
    assert (Box(1) == 1) == False



# Generated at 2022-06-21 18:57:54.097002
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'



# Generated at 2022-06-21 18:57:59.025558
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    """
    Test function for Box.
    """
    assert Box('value') == Box('value')
    assert Box(1) == Box(1)
    assert Box([1, 2]) == Box([1, 2])



# Generated at 2022-06-21 18:58:02.601456
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.monad_try import Try

    a = Box(lambda x: x ** 2)
    b = Try(2).to_box()
    c = a.ap(b)

    assert c.value == 4
    assert a.ap(Try(3).to_box()).value == 9

    assert Box(lambda x: x + 2).ap(Box(7)).value == 9
    assert Box(lambda x: x ** 2).ap(Box(3)).value == 9



# Generated at 2022-06-21 18:58:04.834693
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:58:07.227543
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    try_box = Try(42)

    assert try_box.to_try() == Try(42)



# Generated at 2022-06-21 18:58:08.406747
# Unit test for method __str__ of class Box
def test_Box___str__():  # pragma: no cover
    a = Box(1)
    assert str(a) == 'Box[value=1]'

# Generated at 2022-06-21 18:58:10.190609
# Unit test for method map of class Box
def test_Box_map():  # pragma: no cover
    assert Box(5).map(lambda x: x + 3) == Box(8)



# Generated at 2022-06-21 18:58:14.457986
# Unit test for method bind of class Box
def test_Box_bind():
    """ Test Box.bind method
    Test scenario:
    1. Create some function
    2. Apply this function to value in Box and verify that new box is returned.
    """
    def mapper(x) -> int:
        """ Mapper function
        :param x: parameter for function
        :type x: int
        :returns: value that is multiplied by 2
        :rtype: int
        """
        return x * 2

    assert Box(5).bind(mapper) == 10


# Generated at 2022-06-21 18:58:28.269795
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left

    # Create Box[2], transform to Either and check instance and content
    assert Box(2).to_either() == Right(2)

    # Create Box[1], transform to Either and check instance and content
    assert Box(1).to_either() == Right(1)

    # Create Box["string"], transform to Either and check instance and content
    assert Box('string').to_either() == Right('string')

    # Create Box[Left(1)], transform to Either and check instance and content
    assert Box(Left(1)).to_either() == Left(1)

    # Create Box[Left("string")], transform to Either and check instance and content
    assert Box(Left('string')).to_either() == Left('string')

# Generated at 2022-06-21 18:58:35.571746
# Unit test for method __str__ of class Box
def test_Box___str__():
    assert str(Box(1)) == 'Box[value=1]'
    assert str(Box('1')) == 'Box[value=1]'
    assert str(Box([1, 2, 3])) == 'Box[value=[1, 2, 3]]'
    assert str(Box((1, 2, 3))) == 'Box[value=(1, 2, 3)]'
    assert str(Box(None)) == 'Box[value=None]'
    assert str(Box(True)) == 'Box[value=True]'
    assert str(Box(False)) == 'Box[value=False]'


# Generated at 2022-06-21 18:58:38.691463
# Unit test for method ap of class Box
def test_Box_ap():  # pragma: no cover
    """
    Unit test for method ap of class Box.
    """
    assert Box(2).ap(Box(lambda x: x + 1)) == Box(3)



# Generated at 2022-06-21 18:58:40.544496
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    value = "some text"
    box1 = Box(value)
    box2 = Box(value)

    assert box1 != 0
    assert box1 == box2

# Generated at 2022-06-21 18:58:42.754460
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    """
    unit test for method __eq__
    """
    assert Box(1) == Box(1)



# Generated at 2022-06-21 18:58:50.339054
# Unit test for method ap of class Box
def test_Box_ap():
    from pymonet.iterable import Iterable
    from pymonet.list import List
    from pymonet.tuple import Tuple

    res = Box(10)\
        .ap(Box(lambda x: x + 2))\
        .ap(Box(lambda x: x * 3))\
        .bind(lambda x: x - 2)\
        .map(lambda x: x / 2)\
        .value

    assert res == 15


# Generated at 2022-06-21 18:58:52.825174
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    """
    Unit test for method to_validation of class Box
    """
    from pymonet.validation import Validation

    assert Box(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:58:55.768179
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right
    from pymonet.either import Left

    assert Box(1).to_either() == Right(1)


# Generated at 2022-06-21 18:59:02.791896
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.either import Left

    box = Box(Try.raise_error('error'))

    assert isinstance(box.to_either(), Right)

    box = Box(Try(3, True))

    assert box.to_either() == Right(3)

    box = Box(Try(2, False))

    assert isinstance(box.to_either(), Left)

# Generated at 2022-06-21 18:59:04.516976
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert str(Box(42)) == 'Box[value=42]'

# Generated at 2022-06-21 18:59:15.157034
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(1).to_either() == Either.right(1)


# Generated at 2022-06-21 18:59:17.919318
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """Unit test for method to_lazy of class Box"""

    assert Box(5).to_lazy() == Box(5).to_lazy().value()


# Generated at 2022-06-21 18:59:20.681479
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.test.EitherTest import test_to_either

    assert test_to_either(Box(1))


# Generated at 2022-06-21 18:59:22.903379
# Unit test for method map of class Box
def test_Box_map():
    def double(number):
        return number * 2

    assert Box(5).map(double) == Box(10)



# Generated at 2022-06-21 18:59:25.117445
# Unit test for constructor of class Box
def test_Box():  # pragma: no cover
    assert Box(1) == Box(1)
    assert str(Box(1)) == 'Box[value=1]'


# Generated at 2022-06-21 18:59:35.737435
# Unit test for method ap of class Box
def test_Box_ap():
    assert Box(lambda x: x + 1) ^ Box(1) == Box(2)
    assert Box(lambda x, y: x + y) ^ Box(1) ^ Box(2) == Box(3)
    assert Box(lambda x, y, z: x + y + z) ^ Box(1) ^ Box(2) ^ Box(3) == Box(6)
    assert Box(lambda x, y, z, w: x + y + z + w) ^ Box(1) ^ Box(2) ^ Box(3) ^ Box(4) == Box(10)
    assert Box(lambda x, y, z, w, a: x + y + z + w + a) ^ Box(1) ^ Box(2) ^ Box(3) ^ Box(4) ^ Box(5) == Box(15)

# Generated at 2022-06-21 18:59:38.328462
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(5).to_try() == Try(5, is_success=True)


# Generated at 2022-06-21 18:59:46.708677
# Unit test for method map of class Box
def test_Box_map():
    assert isinstance(Box(100).map(lambda x: x + 100).value, int)
    assert Box(100).map(lambda x: x + 100).value == 200
    assert isinstance(Box('hello').map(lambda x: '{} world'.format(x)).value, str)
    assert Box('hello').map(lambda x: '{} world'.format(x)).value == 'hello world'
    assert isinstance(Box([1, 2, 3]).map(lambda x: x + [4, 5]).value, list)
    assert Box([1, 2, 3]).map(lambda x: x + [4, 5]).value == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 18:59:48.715988
# Unit test for constructor of class Box
def test_Box():
    value = 'test_value'
    box = Box(value)

    assert box.value == value, \
        'Check constructor of Box'

# Generated at 2022-06-21 18:59:50.828024
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:00:14.442819
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(1).bind(lambda x: x + 1) == 2
    assert Box(1).bind(lambda x: Box(x)).value == 1
    assert Box(1).bind(lambda x: None) is None

# Generated at 2022-06-21 19:00:16.464569
# Unit test for method to_either of class Box
def test_Box_to_either():
    assert Box(10).to_either() == Box(10).bind(lambda x: Box(x).to_either())


# Generated at 2022-06-21 19:00:19.950407
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box = Box(3)
    not_box = Box(3)
    assert box == not_box
    assert box == Box(3)
    assert Box(3) == box
    assert not box == Box('foo')



# Generated at 2022-06-21 19:00:21.698821
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 19:00:32.252234
# Unit test for method to_either of class Box
def test_Box_to_either():
    # success
    assert Box(None).to_either() == Box(None).to_maybe().to_either()
    assert Box(None).to_either() == Box(None).to_maybe().to_either()

    # failed
    assert Box(None).to_either() != Box(None).to_maybe().to_either().to_try()
    assert Box(None).to_either() != Box(None).to_maybe().to_either().to_try()
    assert Box(None).to_either() != Box(None).to_maybe().to_either().to_try()
    assert Box(None).to_either() != Box(None).to_maybe().to_either().to_try()

    # success

# Generated at 2022-06-21 19:00:38.186065
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    def do_test(value):
        box = Box(value)
        validation = box.to_validation()
        assert validation.is_success
        assert validation.value == value

    do_test(True)
    do_test(1)
    do_test('string')
    do_test(None)
    do_test(['list'])

# Generated at 2022-06-21 19:00:41.348832
# Unit test for method to_try of class Box
def test_Box_to_try():
    assert Box(42).to_try() == Box(42).to_try()
    assert Box(42).to_try() != Box('42').to_try()
    assert Box(42).to_try() != Box(13).to_try()


# Generated at 2022-06-21 19:00:43.990777
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 19:00:47.873288
# Unit test for constructor of class Box
def test_Box():
    from pymonet.either import Right

    box = Box(Right(1))
    assert isinstance(box, Box)
    assert callable(box.map)


# Main monad method `map`

# Generated at 2022-06-21 19:00:49.925987
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():  # type: ignore
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Box(1).to_maybe()


# Generated at 2022-06-21 19:01:12.284590
# Unit test for constructor of class Box
def test_Box():
    assert Box(123) == Box(123)



# Generated at 2022-06-21 19:01:15.131210
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Either
    from pymonet.monad_either import Right

    box = Box(1)
    either = box.to_either()
    assert isinstance(either, Either)
    assert isinstance(either, Right)
    assert either == Right(1)



# Generated at 2022-06-21 19:01:25.531475
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Test that to_try method will return Try monad with None if value of Box is None.
    Test that to_try method will return Try monad with raises exception, if value of Box is exception.
    Test that to_try method will return Try monad with variable value, if value of Box is variable.
    """
    from pymonet.monad_try import Try

    assert Box(None).to_try() == Try(None, is_success=True)

    try:
        raise ValueError('SomeError')
    except ValueError:
        assert Box(ValueError).to_try() == Try(ValueError, is_success=True)

    assert Box(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-21 19:01:27.676470
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    box = Box(2)
    assert isinstance(box.to_lazy(), Box)
    assert box.to_lazy().value() == 2


# Generated at 2022-06-21 19:01:29.223216
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    from pymonet.maybe import Maybe

    assert Box(5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-21 19:01:33.801342
# Unit test for method __eq__ of class Box
def test_Box___eq__():

    from pymonet.identity import Identity

    assert Box(2) == Box(2)
    assert Box(2) == Identity(2)
    assert Identity(2) == Box(2)
    assert Box(2) != Box(3)
    assert Box(2) != 1
    assert 2 != Box(2)



# Generated at 2022-06-21 19:01:44.611204
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    box1 = Box(1)
    box2 = Box(1)
    box3 = Box('1')
    box4 = Box(2)

    assert box1 == box1
    assert box1 == box2
    assert box1 != box3
    assert box1 != box4
    assert box1 != None

    assert box2 == box1
    assert box2 == box2
    assert box2 != box3
    assert box2 != box4
    assert box2 != None

    assert box3 != box1
    assert box3 != box2
    assert box3 == box3
    assert box3 != box4
    assert box3 != None

    assert box4 != box1
    assert box4 != box2
    assert box4 != box3
    assert box4 == box4
    assert box4 != None



# Generated at 2022-06-21 19:01:47.682048
# Unit test for method to_either of class Box
def test_Box_to_either():
    from pymonet.either import Right, Left

    assert Box(42).to_either() == Right(42)

    assert Box(42).to_either() != Left(42)

    assert Box(42).to_either() == Box(42).to_either()

# Generated at 2022-06-21 19:01:50.138203
# Unit test for method ap of class Box
def test_Box_ap():
    """
    Test ap function of Box monad.
    """

    addTwo = lambda x: x + 2
    testBox = Box(addTwo)
    assert testBox.ap(Box(3)) == Box(5)

# Generated at 2022-06-21 19:01:51.312482
# Unit test for method bind of class Box
def test_Box_bind():
    assert Box(3).bind(lambda x: x + 1) == 4


# Generated at 2022-06-21 19:02:41.142419
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():  # pragma: no cover
    import pymonet.lazy as lazy
    box = Box(2)
    lazy_lazy = box.to_lazy()
    def add_1(x): return x + 1
    lazy_lazy.map(add_1)
    assert lazy_lazy == Lazy(lambda: 3)

# Generated at 2022-06-21 19:02:43.326175
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Try(Box(10).value, is_success=True) == Box(10).to_try()


# Generated at 2022-06-21 19:02:48.152515
# Unit test for method bind of class Box
def test_Box_bind():
    def mapper(value: str) -> int:
        return int(value)

    assert(Box('1').bind(mapper) == 1)
    assert(Box('2').bind(mapper) == 2)
    assert(Box('3').bind(mapper) == 3)
    assert(Box('4').bind(mapper) == 4)
    assert(Box('5').bind(mapper) == 5)



# Generated at 2022-06-21 19:02:49.408342
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box('test') == Box('test')



# Generated at 2022-06-21 19:02:50.665654
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    assert Box(1).to_maybe() == Box(1).value



# Generated at 2022-06-21 19:02:57.854119
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(0) == Box(0)
    assert Box(0) != Box(1)
    assert Box(0) != Box({})
    assert Box(0) != Box(None)
    assert Box(0) != 0
    assert Box(None) == Box(None)
    assert Box(None) != 0
    assert Box(None) != object()
    assert Box(0) != Box(None)
    assert Box(None) != Box(0)
    assert Box(object()) == Box(object())
    assert Box(object()) != Box(1)
    assert Box(object()) != Box(None)
    assert Box(object()) != object()
    assert Box(object()) != Box(object())
    assert Box(object()) == Box(object())
    assert Box(None) != Box(object())
    assert Box(object())

# Generated at 2022-06-21 19:03:01.206989
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try, Failure

    assert Try(1).to_box() == Box(1)
    assert Failure().to_box() == Box(None)



# Generated at 2022-06-21 19:03:03.943071
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    """
    Test to_maybe functionality of Box
    """
    from pymonet.maybe import Maybe

    assert (Box('test').to_maybe() == Maybe.just('test'))



# Generated at 2022-06-21 19:03:07.632641
# Unit test for method to_maybe of class Box
def test_Box_to_maybe():
    import pymonet.maybe as Maybe
    from pymonet.monad_try import Try

    # Expected a successfull Try monad
    assert Box(1).to_try() == Try(1, is_success=True)
    # Expected a failed Try monad
    assert Box(None).to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:03:09.285902
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-21 19:04:46.198910
# Unit test for method to_try of class Box
def test_Box_to_try():
    """
    Unit test for method to_try of class Box.
    """

    from pymonet.monad_try import Try

    def test_func(value: int) -> int:
        return value

    try_box = Box(3).to_try().bind(test_func)
    assert isinstance(try_box, Try)
    assert try_box.value == 3
    assert try_box.is_success


# Generated at 2022-06-21 19:04:47.177375
# Unit test for method to_validation of class Box
def test_Box_to_validation():
    assert Box(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:04:49.454779
# Unit test for method to_try of class Box
def test_Box_to_try():
    from pymonet.monad_try import Try

    assert Box(1).to_try() == Try(1, is_success=True)

