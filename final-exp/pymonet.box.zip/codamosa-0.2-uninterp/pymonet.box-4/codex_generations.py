

# Generated at 2022-06-18 01:14:23.538557
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-18 01:14:25.800661
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:14:28.605245
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:14:33.628845
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(Try(1, is_success=True)).to_lazy() == Lazy(lambda: Try(1, is_success=True))

# Generated at 2022-06-18 01:14:38.745744
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != '1'
    assert Box(1) != None
    assert Box(1) != Box(1.0)
    assert Box(1.0) == Box(1.0)
    assert Box(1.0) != Box(2.0)
    assert Box(1.0) != 1.0
    assert Box(1.0) != '1.0'
    assert Box(1.0) != None
    assert Box(1.0) != Box(1)
    assert Box('1') == Box('1')
    assert Box('1') != Box('2')
    assert Box('1') != 1
    assert Box('1') != '1'
    assert Box

# Generated at 2022-06-18 01:14:41.329063
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:14:43.450437
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:14:47.428464
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1


# Generated at 2022-06-18 01:14:49.657443
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:14:52.926869
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None



# Generated at 2022-06-18 01:15:00.543207
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(2).to_lazy() == Lazy(lambda: 2)
    assert Box(3).to_lazy() == Lazy(lambda: 3)
    assert Box(4).to_lazy() == Lazy(lambda: 4)
    assert Box(5).to_lazy() == Lazy(lambda: 5)
    assert Box(6).to_lazy() == Lazy(lambda: 6)
    assert Box(7).to_lazy() == Lazy(lambda: 7)
    assert Box(8).to_lazy() == Lazy(lambda: 8)
    assert Box(9).to_lazy() == Lazy(lambda: 9)
    assert Box(10).to

# Generated at 2022-06-18 01:15:04.355373
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 1



# Generated at 2022-06-18 01:15:05.238684
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:15:07.462286
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:15:09.540595
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:15:12.347328
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:15:15.923860
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:15:19.768735
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:15:21.718271
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:15:24.581399
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:15:32.664844
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1


# Generated at 2022-06-18 01:15:35.209144
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-18 01:15:38.049061
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:15:41.156091
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:15:43.839364
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:15:44.892600
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:15:46.662187
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-18 01:15:48.381432
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:15:50.223244
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:15:52.091342
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:16:04.716598
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:16:07.617411
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:16:10.309013
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:16:12.385582
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:16:14.646990
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:16:16.632694
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-18 01:16:18.512040
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1



# Generated at 2022-06-18 01:16:20.298114
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:16:22.241463
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:16:25.236094
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 1


# Generated at 2022-06-18 01:16:47.557782
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    """
    Test for method to_lazy of class Box
    """
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:16:49.690317
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:16:52.185569
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:16:54.288661
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:16:56.143372
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:16:59.092249
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 1


# Generated at 2022-06-18 01:17:02.051401
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:17:11.838617
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != None
    assert Box(1) != '1'
    assert Box(1) != [1]
    assert Box(1) != {'1': 1}
    assert Box(1) != {1}
    assert Box(1) != (1,)
    assert Box(1) != 1.0
    assert Box(1) != True
    assert Box(1) != False
    assert Box(1) != b'1'
    assert Box(1) != bytearray(b'1')
    assert Box(1) != memoryview(b'1')
    assert Box(1) != range(1)

# Generated at 2022-06-18 01:17:14.697667
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 1


# Generated at 2022-06-18 01:17:16.883920
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None


# Generated at 2022-06-18 01:18:03.579995
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:18:05.738198
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:18:09.157970
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 1


# Generated at 2022-06-18 01:18:11.905605
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1



# Generated at 2022-06-18 01:18:14.175463
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:18:15.855102
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:18:19.045312
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:18:24.172447
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box('a') == Box('a')
    assert Box(1) != Box(2)
    assert Box('a') != Box('b')
    assert Box(1) != Box('a')
    assert Box('a') != Box(1)
    assert Box(1) != None
    assert Box('a') != None
    assert Box(1) != 1
    assert Box('a') != 'a'


# Generated at 2022-06-18 01:18:26.583838
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 1


# Generated at 2022-06-18 01:18:29.010645
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != None
    assert Box(1) != 1


# Generated at 2022-06-18 01:20:07.413211
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:20:11.510226
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != None
    assert Box(1) != '1'
    assert Box(1) != [1]
    assert Box(1) != {'1': 1}


# Generated at 2022-06-18 01:20:13.009083
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:20:15.769282
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1


# Generated at 2022-06-18 01:20:17.117845
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:20:21.658987
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != Box('1')
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:20:23.268065
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-18 01:20:25.040133
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None


# Generated at 2022-06-18 01:20:27.135367
# Unit test for method __eq__ of class Box
def test_Box___eq__():
    assert Box(1) == Box(1)
    assert Box(1) != Box(2)
    assert Box(1) != 1
    assert Box(1) != None



# Generated at 2022-06-18 01:20:29.051617
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:24:22.216802
# Unit test for method to_lazy of class Box
def test_Box_to_lazy():
    from pymonet.lazy import Lazy

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Box(1).to_lazy().value() == 1
