

# Generated at 2022-06-18 06:11:54.145505
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField

    reg = Register(name="test_reg", address=0x00, width=8)
    bit = Bit(name="test_bit", offset=0, width=1)
    bitfield = BitField(name="test_bitfield", offset=0, width=4)

    reg.add_bit(bit)
    reg.add_bitfield(bitfield)

    mute(reg, bit, bitfield)

    assert reg.muted
    assert bit.muted
    assert bitfield.muted



# Generated at 2022-06-18 06:12:01.551897
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitArray
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumField
    from .primitive import EnumArray
    from .primitive import Flag
    from .primitive import FlagField
    from .primitive import FlagArray
    from .primitive import Pointer
    from .primitive import PointerArray
    from .primitive import PointerField
    from .primitive import PointerBitField
    from .primitive import PointerEnumField
    from .primitive import PointerFlagField
    from .primitive import PointerBitArray
    from .primitive import PointerEnumArray

# Generated at 2022-06-18 06:12:10.156895
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import ArrayField
    from .primitive import Enum
    from .primitive import EnumField
    from .primitive import MappedRegister
    from .primitive import MappedRegisterField
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedArrayField
    from .primitive import MappedEnum
    from .primitive import MappedEnumField

    # Test Register
    reg = Register(name="reg", address=0x00, width=8, reset=0x00)
    mute(reg)
    assert reg.muted is True
    unmute(reg)

# Generated at 2022-06-18 06:12:15.822609
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute.
    """
    # Create a register object
    reg = Register(name="reg", width=8, init_val=0)
    # Mute the register
    mute(reg)
    # Check if the register is muted
    assert reg.muted
    # Unmute the register
    unmute(reg)
    # Check if the register is unmuted
    assert not reg.muted


# Generated at 2022-06-18 06:12:26.143068
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumField
    from .primitive import Flag
    from .primitive import FlagField
    from .primitive import RegisterField
    from .primitive import RegisterArray
    from .primitive import RegisterEnum
    from .primitive import RegisterEnumField
    from .primitive import RegisterFlag
    from .primitive import RegisterFlagField
    from .primitive import RegisterFieldArray
    from .primitive import RegisterFieldEnum
    from .primitive import RegisterFieldEnumField
    from .primitive import RegisterFieldFlag
    from .primitive import RegisterFieldFlagField

    # Test mute() with Register

# Generated at 2022-06-18 06:12:36.112672
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import ArrayField
    from .primitive import EnumField
    from .primitive import EnumBitField
    from .primitive import EnumArrayField
    from .primitive import EnumBit
    from .primitive import EnumArray
    from .primitive import EnumRegister
    from .primitive import EnumArrayRegister


# Generated at 2022-06-18 06:12:45.889278
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Mute
    from .primitive import Unmute
    from .primitive import MuteError
    from .primitive import UnmuteError
    from .primitive import MuteWarning
    from .primitive import UnmuteWarning
    from .primitive import MuteInfo
    from .primitive import UnmuteInfo
    from .primitive import MuteDebug
    from .primitive import UnmuteDebug
    from .primitive import MuteTrace
    from .primitive import UnmuteTrace
    from .primitive import MuteAll
    from .primitive import UnmuteAll
    from .primitive import MuteNone
    from .primitive import UnmuteNone
    from .primitive import MuteAllExcept
    from .primitive import UnmuteAllExcept


# Generated at 2022-06-18 06:12:56.610206
# Unit test for function unmute
def test_unmute():
    """
    Unit test for function unmute.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Word

    reg = Register(name="test_reg", width=8)
    reg.add_bit(name="bit0", width=1, offset=0)
    reg.add_bit(name="bit1", width=1, offset=1)
    reg.add_bit(name="bit2", width=1, offset=2)
    reg.add_bit(name="bit3", width=1, offset=3)
    reg.add_bit(name="bit4", width=1, offset=4)
    reg.add_bit(name="bit5", width=1, offset=5)

# Generated at 2022-06-18 06:13:05.041830
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitVector
    from .primitive import BitMatrix
    from .primitive import BitArray
    from .primitive import BitRegister
    from .primitive import BitFieldRegister
    from .primitive import BitVectorRegister
    from .primitive import BitMatrixRegister
    from .primitive import BitArrayRegister

    # Test Bit
    bit = Bit()
    bit.mute()
    assert bit.muted == True
    unmute(bit)
    assert bit.muted == False

    # Test BitField
    bitfield = BitField(width=4)
    bitfield.mute()
    assert bitfield.muted == True
    unmute(bitfield)
    assert bitfield.muted == False

   

# Generated at 2022-06-18 06:13:15.310755
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitArray
    from .primitive import Enum
    from .primitive import Array
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedBitArray
    from .primitive import MappedEnum
    from .primitive import MappedArray

    # Test mute() on Register
    reg = Register(0x00, "reg", 0x00, 0xFF)
    mute(reg)
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

    # Test mute() on Bit