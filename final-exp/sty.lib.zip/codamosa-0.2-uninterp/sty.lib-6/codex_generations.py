

# Generated at 2022-06-18 06:11:55.320867
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Bitfield
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitfield
    from .primitive import MappedArray
    from .primitive import MappedEnum

    reg = Register(name="reg", address=0x00, width=8, mute=True)
    bit = Bit(name="bit", offset=0, width=1, mute=True)
    bitfield = Bitfield(name="bitfield", offset=0, width=4, mute=True)
    array = Array(name="array", address=0x00, width=8, count=4, mute=True)

# Generated at 2022-06-18 06:12:02.522432
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import MappedRegister
    from .primitive import RegisterMap
    from .primitive import RegisterFile
    from .primitive import RegisterFileMap
    from .primitive import RegisterFileArray
    from .primitive import RegisterFileMapArray

    # Register
    reg = Register(name="reg", address_offset=0x00, width=8, access="RW")
    assert reg.mute_count == 0
    reg.mute()
    assert reg.mute_count == 1
    unmute(reg)
    assert reg.mute_count == 0

    # Bit
    bit = Bit(name="bit", offset=0, width=1, access="RW")

# Generated at 2022-06-18 06:12:11.380381
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU

    # Test for Register
    reg = Register(8)
    reg.mute()
    assert reg.muted == True
    reg.unmute()
    assert reg.muted == False

    # Test for Wire
    wire = Wire(8)
    wire.mute()
    assert wire.muted == True
    wire.unmute()
    assert wire.muted == False

    # Test for Not

# Generated at 2022-06-18 06:12:22.066382
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import BitField
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitStruct
    from .primitive import BitUnion
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import FlagGroup
    from .primitive import MappedRegister
    from .primitive import RegisterMap
    from .primitive import SubRegister
    from .primitive import SubRegisterMap
    from .primitive import SubBitField
    from .primitive import SubBitStruct
    from .primitive import SubBitUnion
    from .primitive import SubEnum
    from .primitive import SubFlag
    from .primitive import SubFlagGroup
    from .primitive import SubMapped

# Generated at 2022-06-18 06:12:30.156016
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Constant
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import Dmux
    from .primitive import DMux4Way
    from .primitive import DMux8Way
    from .primitive import Not16
    from .primitive import And16
    from .primitive import Or16
    from .primitive import Mux16
    from .primitive import Or8Way
    from .primitive import Mux4Way16
    from .primitive import Mux8Way16
    from .primitive import DMux4Way16
    from .primitive import DMux8Way16

# Generated at 2022-06-18 06:12:41.230917
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire

    a = Register(name="a", width=1)
    b = Register(name="b", width=1)
    c = Register(name="c", width=1)

    a.d(0)
    b.d(0)
    c.d(0)

    a.q(b.d)
    b.q(c.d)
    c.q(a.d)

    mute(a, b, c)

    a.d(1)
    b.d(1)
    c.d(1)

    assert a.q == 0
    assert b.q == 0
    assert c.q == 0

    unmute(a, b, c)

    a.d(0)
    b.d(0)
    c

# Generated at 2022-06-18 06:12:48.802487
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord

    # Test mute() with a Bit object
    bit = Bit(name="bit")
    mute(bit)
    assert bit.muted is True

    # Test mute() with a Byte object
    byte = Byte(name="byte")
    mute(byte)
    assert byte.muted is True

    # Test mute() with a Word object
    word = Word(name="word")
    mute(word)
    assert word.muted is True

    # Test mute() with a DoubleWord object
    dword = DoubleWord(name="dword")
    mute(dword)

# Generated at 2022-06-18 06:12:52.308824
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(name="test_reg")
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.muted


# Generated at 2022-06-18 06:13:02.545177
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import Dff
    from .primitive import Adder
    from .primitive import Subtractor
    from .primitive import Incrementer
    from .primitive import ALU
    from .primitive import Ram
    from .primitive import ProgramCounter
    from .primitive import InstructionDecoder
    from .primitive import ControlUnit
    from .primitive import RegisterFile
    from .primitive import DataMemory
    from .primitive import Processor

    # Test for Register
    reg = Register(4)
    reg.mute()
    assert reg.muted == True
    reg

# Generated at 2022-06-18 06:13:13.226647
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import Dmux
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import RegisterFile
    from .primitive import Memory
    from .primitive import ProgramCounter
    from .primitive import ALU
    from .primitive import CPU
    from .primitive import Clock
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import RAM64K
    from .primitive import ROM64K

    # Test the mute()