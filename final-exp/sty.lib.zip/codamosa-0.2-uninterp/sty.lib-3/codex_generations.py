

# Generated at 2022-06-18 06:11:57.302619
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitVector
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumField
    from .primitive import EnumVector
    from .primitive import EnumArray
    from .primitive import EnumBitField
    from .primitive import EnumBitVector
    from .primitive import EnumBitArray
    from .primitive import EnumBitFieldVector
    from .primitive import EnumBitFieldArray
    from .primitive import EnumBitVectorArray
    from .primitive import EnumBitVectorField
    from .primitive import EnumBitVectorFieldArray
    from .primitive import EnumBitVectorFieldVector
    from .primitive import EnumBitVectorArray

# Generated at 2022-06-18 06:12:03.772469
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import RegisterFile
    from .primitive import Memory
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import RegisterArray
    from .primitive import RegisterFileArray
    from .primitive import MemoryArray
    from .primitive import RAMArray
    from .primitive import ROMArray

    reg = Register(8)
    reg_file = RegisterFile(8, 4)
    mem = Memory(8, 4)
    ram = RAM(8, 4)
    rom = ROM(8, 4)
    reg_arr = RegisterArray(8, 4)
    reg_file_arr = RegisterFileArray(8, 4, 4)
    mem_arr = MemoryArray(8, 4, 4)
    ram_arr = RAMArray(8, 4, 4)


# Generated at 2022-06-18 06:12:13.211799
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute.
    """
    from .primitive import Register
    from .primitive import Bus
    from .primitive import Wire
    from .primitive import Port
    from .primitive import InPort
    from .primitive import OutPort
    from .primitive import InOutPort
    from .primitive import PortList

    # Test for Register
    reg = Register(name="reg", width=8)
    assert reg.mute_state == False
    mute(reg)
    assert reg.mute_state == True
    unmute(reg)
    assert reg.mute_state == False

    # Test for Bus
    bus = Bus(name="bus", width=8)
    assert bus.mute_state == False
    mute(bus)
    assert bus.mute_state == True
    unm

# Generated at 2022-06-18 06:12:23.920131
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU
    from .primitive import PC
    from .primitive import InstructionMemory
    from .primitive import DataMemory
    from .primitive import CPU

    # Create a register
    reg = Register(8)
    # Create a wire
    wire = Wire(8)
    # Create a not gate
    not_gate = Not()
    # Create an and gate
    and_gate = And()
    # Create an or gate
    or_gate = Or()


# Generated at 2022-06-18 06:12:33.284029
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import WireVector
    from .primitive import Bit
    from .primitive import Const
    from .primitive import concat
    from .primitive import UInt
    from .primitive import SInt
    from .primitive import UIntVector
    from .primitive import SIntVector
    from .primitive import Array
    from .primitive import ArrayProxy
    from .primitive import ArrayProxyVector
    from .primitive import ArrayProxySlice
    from .primitive import ArrayProxySliceVector
    from .primitive import ArrayProxySliceSingle
    from .primitive import ArrayProxySliceSingleVector
    from .primitive import ArrayProxySliceSingleSingle
    from .primitive import ArrayProxySliceSingleSingleVector
    from .primitive import ArrayProxySliceSingleSingleSingle

# Generated at 2022-06-18 06:12:44.433045
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import BitField
    from .primitive import Bit
    from .primitive import MappedRegister
    from .primitive import MappedBitField
    from .primitive import MappedBit
    from .primitive import MappedRegisterArray
    from .primitive import MappedBitFieldArray
    from .primitive import MappedBitArray

    # Test unmute() with Register
    reg = Register(name="reg", address=0x0, width=8, mute=True)
    unmute(reg)
    assert reg.mute == False

    # Test unmute() with BitField
    bitfield = BitField(name="bitfield", register=reg, offset=0, width=8, mute=True)

# Generated at 2022-06-18 06:12:55.315669
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU
    from .primitive import CPU
    from .primitive import ProgramCounter
    from .primitive import InstructionRegister
    from .primitive import InstructionDecoder
    from .primitive import ControlUnit
    from .primitive import RegisterFile
    from .primitive import DataMemory
    from .primitive import ALUControl
    from .primitive import SignExtend
    from .primitive import ShiftLeft2
    from .primitive import Adder

# Generated at 2022-06-18 06:13:04.271232
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import DFF
    from .primitive import Xor
    from .primitive import And
    from .primitive import Or
    from .primitive import Not
    from .primitive import Mux
    from .primitive import DMux
    from .primitive import Not16
    from .primitive import And16
    from .primitive import Or16
    from .primitive import Mux16
    from .primitive import Or8Way
    from .primitive import Mux4Way16
    from .primitive import Mux8Way16
    from .primitive import DMux4Way
    from .primitive import DMux8Way
    from .primitive import PC
    from .primitive import RAM8
    from .primitive import RAM64

# Generated at 2022-06-18 06:13:14.563689
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord
    from .primitive import OctWord
    from .primitive import HexWord
    from .primitive import BitField
    from .primitive import ByteField
    from .primitive import WordField
    from .primitive import DoubleWordField
    from .primitive import QuadWordField
    from .primitive import OctWordField
    from .primitive import HexWordField
    from .primitive import Array
    from .primitive import ArrayField
    from .primitive import ArrayRegister
    from .primitive import ArrayRegisterField
    from .primitive import EnumRegister
    from .primitive import EnumRegisterField
    from .primitive import En

# Generated at 2022-06-18 06:13:24.947476
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import RegisterMap
    from .primitive import RegisterFile
    from .primitive import RegisterFileMap
    from .primitive import RegisterFileArray
    from .primitive import RegisterFileArrayMap
    from .primitive import RegisterFileMapArray
    from .primitive import RegisterFileMapArrayMap
    from .primitive import RegisterFileArrayMapArray
    from .primitive import RegisterFileArrayMapArrayMap

    # Test mute() with a Register object