

# Generated at 2022-06-18 06:11:59.508292
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import RegisterFile
    from .primitive import RegisterArray
    from .primitive import RegisterMap

    reg = Register(name="reg", width=8, init_val=0xFF)
    reg_file = RegisterFile(name="reg_file", width=8, init_val=0xFF, num_regs=4)
    reg_array = RegisterArray(name="reg_array", width=8, init_val=0xFF, num_regs=4)
    reg_map = RegisterMap(name="reg_map", width=8, init_val=0xFF, num_regs=4)

    mute(reg, reg_file, reg_array, reg_map)
    assert reg.mute_status == True

# Generated at 2022-06-18 06:12:07.817776
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import BitField
    from .primitive import Bit
    from .primitive import MappedRegister
    from .primitive import MappedBitField
    from .primitive import MappedBit
    from .primitive import MappedRegisterArray
    from .primitive import MappedBitFieldArray
    from .primitive import MappedBitArray


# Generated at 2022-06-18 06:12:18.157194
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumField
    from .primitive import EnumArray
    from .primitive import EnumBitField
    from .primitive import EnumBitFieldArray
    from .primitive import EnumBitFieldArrayEntry
    from .primitive import EnumBitFieldEntry
    from .primitive import EnumEntry
    from .primitive import EnumFieldEntry
    from .primitive import EnumArrayEntry
    from .primitive import EnumBitFieldArrayEntry
    from .primitive import EnumBitFieldEntry
    from .primitive import EnumEntry
    from .primitive import Enum

# Generated at 2022-06-18 06:12:27.476393
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import BitField
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitStruct
    from .primitive import BitUnion
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import MappedRegister
    from .primitive import RegisterArray
    from .primitive import RegisterBitfield
    from .primitive import RegisterBit
    from .primitive import RegisterBitArray
    from .primitive import RegisterBitStruct
    from .primitive import RegisterBitUnion
    from .primitive import RegisterEnum
    from .primitive import RegisterFlag
    from .primitive import RegisterMap
    from .primitive import RegisterStruct
    from .primitive import RegisterUnion
    from .primitive import RegisterValue
    from .primitive import Register

# Generated at 2022-06-18 06:12:32.235743
# Unit test for function mute
def test_mute():
    from .primitive import Register
    reg = Register(name="reg", width=8)
    mute(reg)
    assert reg.mute_value == 0xFF
    assert reg.mute_mask == 0xFF
    assert reg.mute_enable == True
    assert reg.mute_disable == False


# Generated at 2022-06-18 06:12:44.432971
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU
    from .primitive import PC
    from .primitive import InstructionMemory
    from .primitive import DataMemory
    from .primitive import CPU

    a = Register(8)
    b = Register(8)
    c = Register(8)
    d = Register(8)
    e = Register(8)
    f = Register(8)
    g = Register(8)
    h = Register(8)
    i = Register(8)
   

# Generated at 2022-06-18 06:12:55.316163
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Field
    from .primitive import RegisterArray
    from .primitive import RegisterFile
    from .primitive import RegisterMap
    from .primitive import RegisterCluster
    from .primitive import RegisterClusterArray
    from .primitive import RegisterFileArray
    from .primitive import RegisterMapArray

    reg = Register(name="reg", description="register", address_offset=0x00, size=8, fields=[])
    reg.mute()
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

    bit = Bit(name="bit", description="bit", bit_offset=0, bit_width=1, reset_value=0)
    bit.mute

# Generated at 2022-06-18 06:13:01.426299
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute()
    """
    # Create a register object
    reg = Register(name="test_reg", size=8, init_val=0x00)
    # Mute the register object
    mute(reg)
    # Check if the register object is muted
    assert reg.muted == True
    # Unmute the register object
    unmute(reg)
    # Check if the register object is unmuted
    assert reg.muted == False


# Generated at 2022-06-18 06:13:12.217952
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DWord
    from .primitive import QWord
    from .primitive import Array
    from .primitive import Struct
    from .primitive import Union
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import BitUnion
    from .primitive import BitEnum
    from .primitive import BitFlag
    from .primitive import BitArray
    from .primitive import BitStructArray
    from .primitive import BitUnionArray
    from .primitive import BitEnumArray
    from .primitive import BitFlag

# Generated at 2022-06-18 06:13:16.140963
# Unit test for function mute
def test_mute():
    """
    Test the mute function.
    """
    # Create a register object
    reg = Register(name="test_register", width=8)
    # Mute the register
    mute(reg)
    # Check if the register is muted
    assert reg.is_muted()
