

# Generated at 2022-06-18 06:11:57.371507
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import RegisterMap
    from .primitive import RegisterMapArray
    from .primitive import RegisterMapBit
    from .primitive import RegisterMapBitField
    from .primitive import RegisterMapMappedRegister
    from .primitive import RegisterMapMappedBit
    from .primitive import RegisterMapMappedBitField
    from .primitive import RegisterMapMappedArray
    from .primitive import RegisterMapRegister
    from .primitive import RegisterMapRegisterArray
    from .primitive import RegisterMapRegisterBit

# Generated at 2022-06-18 06:12:05.518283
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import Mask
    from .primitive import MappedRegister
    from .primitive import RegisterBit
    from .primitive import RegisterBitField
    from .primitive import RegisterBitStruct
    from .primitive import RegisterEnum
    from .primitive import RegisterFlag
    from .primitive import RegisterMask
    from .primitive import RegisterMeta
    from .primitive import RegisterMapping
    from .primitive import RegisterMeta
    from .primitive import RegisterMapping
    from .primitive import RegisterMeta
    from .primitive import RegisterMapping
    from .primitive import RegisterMeta
    from .primitive import Register

# Generated at 2022-06-18 06:12:14.346468
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitFieldGroup
    from .primitive import BitGroup
    from .primitive import BitMatrix
    from .primitive import BitVector
    from .primitive import RegisterArray
    from .primitive import RegisterFile
    from .primitive import RegisterFileArray
    from .primitive import RegisterFileGroup
    from .primitive import RegisterGroup

    # Test Bit
    bit = Bit(name="bit", width=1, offset=0, description="")
    bit.mute()
    assert bit.muted == True
    unmute(bit)
    assert bit.muted == False

    # Test BitField
    bitfield = BitField(name="bitfield", width=1, offset=0, description="")
    bit

# Generated at 2022-06-18 06:12:25.149517
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import ALU
    from .primitive import PC
    from .primitive import Memory
    from .primitive import InstructionMemory
    from .primitive import DataMemory
    from .primitive import ControlUnit
    from .primitive import CPU
    from .primitive import ProgramCounter
    from .primitive import InstructionRegister
    from .primitive import RegisterFile
    from .primitive import ALUControl
    from .primitive import Multiplexer
    from .primitive import SignExtend
    from .primitive import ShiftLeft2
    from .primitive import Adder
    from .primitive import And
    from .primitive import Or
    from .primitive import Not

# Generated at 2022-06-18 06:12:34.262009
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedBit
    from .primitive import MappedRegister
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedBit
    from .primitive import MappedRegister
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedBit
   

# Generated at 2022-06-18 06:12:44.470917
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitFieldGroup
    from .primitive import BitGroup
    from .primitive import BitGroupArray
    from .primitive import BitGroupField
    from .primitive import BitGroupFieldArray
    from .primitive import BitGroupFieldGroup
    from .primitive import BitGroupFieldGroupArray
    from .primitive import BitGroupGroup
    from .primitive import BitGroupGroupArray
    from .primitive import BitGroupGroupField
    from .primitive import BitGroupGroupFieldArray
    from .primitive import BitGroupGroupFieldGroup
    from .primitive import BitGroupGroupFieldGroupArray
    from .primitive import BitGroupGroupGroup
    from .primitive import BitGroupGroupGroupArray
    from .primitive import BitGroupGroup

# Generated at 2022-06-18 06:12:47.648753
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(name='test', width=8)
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.muted


# Generated at 2022-06-18 06:12:59.189185
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import Integer
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumField
    from .primitive import Flag
    from .primitive import FlagField
    from .primitive import Float
    from .primitive import String
    from .primitive import Struct
    from .primitive import Union
    from .primitive import Pointer
    from .primitive import Void

    # Create a register
    reg = Register("reg", 0x00, 0x00)
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

    # Create a register with a value
    reg

# Generated at 2022-06-18 06:13:06.178931
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitVector
    from .primitive import BitVectorField
    from .primitive import BitVectorArray
    from .primitive import BitVectorArrayField
    from .primitive import BitVectorArrayFieldEntry
    from .primitive import BitVectorArrayFieldEntryField
    from .primitive import BitVectorArrayFieldEntryFieldEntry
    from .primitive import BitVectorArrayFieldEntryFieldEntryField
    from .primitive import BitVectorArrayFieldEntryFieldEntryFieldEntry
    from .primitive import BitVectorArrayFieldEntryFieldEntryFieldEntryField
    from .primitive import BitVectorArrayFieldEntryFieldEntryFieldEntryFieldEntry
    from .primitive import BitVectorArrayFieldEntryFieldEntryFieldEntryFieldEntryField
    from .primitive import BitVectorArrayField

# Generated at 2022-06-18 06:13:16.841114
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord
    from .primitive import OctWord
    from .primitive import HexWord

    # Test mute() with Bit
    bit = Bit()
    mute(bit)
    assert bit.muted == True
    unmute(bit)
    assert bit.muted == False

    # Test mute() with Byte
    byte = Byte()
    mute(byte)
    assert byte.muted == True
    unmute(byte)
    assert byte.muted == False

    # Test mute() with Word
    word = Word()
    mute(word)
    assert word.muted == True
    unmute(word)
    assert word.m