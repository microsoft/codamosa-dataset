

# Generated at 2022-06-18 06:11:58.437769
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import ROM
    from .primitive import RAM
    from .primitive import ALU
    from .primitive import PC
    from .primitive import InstructionMemory
    from .primitive import DataMemory
    from .primitive import CPU

    # Test for Register
    reg = Register(8)
    reg.mute()
    assert reg.muted == True
    reg.unmute()
    assert reg.muted == False

    # Test for Wire
    wire = Wire(8)
    wire.mute()
    assert wire.m

# Generated at 2022-06-18 06:12:07.063187
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord

    # Test mute() on register-objects
    reg = Register(name="test_reg", width=8)
    mute(reg)
    assert reg.muted == True

    # Test mute() on bit-objects
    bit = Bit(name="test_bit", width=1)
    mute(bit)
    assert bit.muted == True

    # Test mute() on word-objects
    word = Word(name="test_word", width=16)
    mute(word)
    assert word.muted == True

    # Test mute() on doubleword-objects
    dword = DoubleWord(name="test_dword", width=32)

# Generated at 2022-06-18 06:12:16.414657
# Unit test for function mute
def test_mute():
    """
    Test the mute function.
    """
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Constant
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import Dff
    from .primitive import Adder
    from .primitive import Subtractor
    from .primitive import Incrementer
    from .primitive import ALU
    from .primitive import Ram
    from .primitive import Rom
    from .primitive import ProgramCounter
    from .primitive import StackPointer
    from .primitive import InstructionMemory
    from .primitive import DataMemory
    from .primitive import RegisterFile
    from .primitive import ControlUnit

# Generated at 2022-06-18 06:12:26.661389
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import Float
    from .primitive import Integer
    from .primitive import Pointer
    from .primitive import String
    from .primitive import UnsignedInteger
    from .primitive import UnsignedIntegerArray
    from .primitive import UnsignedIntegerField
    from .primitive import UnsignedIntegerStruct

    # Test with a single object
    reg = Register(name="reg", address=0x0, width=8, access="RW")
    reg.mute()
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

# Generated at 2022-06-18 06:12:37.086790
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitVector
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumBitField
    from .primitive import EnumBitVector
    from .primitive import EnumArray
    from .primitive import EnumRegister
    from .primitive import EnumRegisterBitField
    from .primitive import EnumRegisterBitVector
    from .primitive import EnumRegisterArray

    # Test mute() with a Register object
    reg = Register(name="reg", address=0x0, width=8, default=0x0)
    mute(reg)
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

    # Test mute

# Generated at 2022-06-18 06:12:41.512082
# Unit test for function unmute
def test_unmute():
    """
    This function tests the unmute() function.
    """
    from .primitive import Register
    reg = Register(name="test")
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.muted


# Generated at 2022-06-18 06:12:48.966813
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU
    from .primitive import Adder
    from .primitive import Subtractor
    from .primitive import Incrementer
    from .primitive import Comparator
    from .primitive import Multiplier
    from .primitive import Divider
    from .primitive import Modulo
    from .primitive import Shifter
    from .primitive import Rotator
    from .primitive import Decoder
    from .primitive import Encoder

# Generated at 2022-06-18 06:13:00.297703
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import FlagArray
    from .primitive import FlagField
    from .primitive import FlagStruct
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitArray
    from .primitive import MappedBitField
    from .primitive import MappedBitStruct
    from .primitive import MappedEnum
    from .primitive import MappedFlag
    from .primitive import MappedFlagArray
    from .primitive import MappedFlagField
    from .primitive import MappedFlagStruct

# Generated at 2022-06-18 06:13:06.754677
# Unit test for function unmute
def test_unmute():
    """
    Unit test for function unmute.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord
    from .primitive import OctWord
    from .primitive import HexWord
    from .primitive import BitField
    from .primitive import ByteField
    from .primitive import WordField
    from .primitive import DoubleWordField
    from .primitive import QuadWordField
    from .primitive import OctWordField
    from .primitive import HexWordField

    # Test unmute() with a single object
    obj = Register(name="test_reg", address=0x1000, width=32)
    obj.mute()
    assert obj.is_muted()

# Generated at 2022-06-18 06:13:10.896512
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(name="test_reg", width=8)
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.muted
