

# Generated at 2022-06-18 06:11:58.571114
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import FlagGroup
    from .primitive import Integer
    from .primitive import IntegerArray
    from .primitive import IntegerField
    from .primitive import IntegerStruct
    from .primitive import Pointer
    from .primitive import PointerArray
    from .primitive import PointerField
    from .primitive import PointerStruct
    from .primitive import RegisterArray
    from .primitive import RegisterField
    from .primitive import RegisterStruct
    from .primitive import String
    from .primitive import StringArray
    from .primitive import StringField

# Generated at 2022-06-18 06:12:01.500834
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(name='test_reg')
    reg.mute()
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False


# Generated at 2022-06-18 06:12:06.761103
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute().
    """
    # Create a register-object
    reg = Register(name="Test register",
                   address=0x00,
                   bitmask=0x01,
                   reset_value=0x00,
                   access="rw",
                   description="Test register")

    # Mute the register-object
    mute(reg)

    # Check that the register-object is muted
    assert reg.muted == True



# Generated at 2022-06-18 06:12:09.640313
# Unit test for function mute
def test_mute():
    from .primitive import Register

    reg = Register(0x00, 0x00)
    reg.mute()
    assert reg.muted == True
    reg.unmute()
    assert reg.muted == False


# Generated at 2022-06-18 06:12:20.169852
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Bit
    from .primitive import Register
    from .primitive import RegisterFile

    # Create a register file
    regfile = RegisterFile()

    # Create a register
    reg = Register(name="reg", width=8, access="RW", reset=0x00)

    # Create a bit
    bit = Bit(name="bit", width=1, access="RW", reset=0x00)

    # Add the register to the register file
    regfile.add_register(reg)

    # Add the bit to the register
    reg.add_bit(bit)

    # Mute the register
    reg.mute()

    # Unmute the register
    unmute(reg)

    # Check if the register is unmuted
    assert reg.m

# Generated at 2022-06-18 06:12:28.924187
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import DFF
    from .primitive import And
    from .primitive import Or
    from .primitive import Not
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import Adder
    from .primitive import Subtractor
    from .primitive import Incrementer
    from .primitive import Decrementer
    from .primitive import Comparator
    from .primitive import ALU
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import Counter
    from .primitive import ShiftRegister
    from .primitive import ProgramCounter
    from .primitive import InstructionRegister
    from .primitive import ControlUnit
    from .primitive import RegisterFile

# Generated at 2022-06-18 06:12:39.824364
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedFlag

    reg = Register(0x00, "reg")
    bit = Bit(0x00, 0, "bit")
    bf = BitField(0x00, 0, 1, "bf")
    arr = Array(0x00, 0, 1, "arr")

# Generated at 2022-06-18 06:12:48.185121
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Bitfield
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumBitfield
    from .primitive import EnumArray
    from .primitive import EnumBit
    from .primitive import EnumBitfieldBit
    from .primitive import EnumArrayBit
    from .primitive import EnumArrayBitfield
    from .primitive import EnumArrayBitfieldBit

    # Test unmute() on a Register object
    reg = Register(name="reg", address=0x00, width=8, reset=0x00)
    reg.unmute()
    assert reg.mute_state == False

    # Test unmute() on a Bit object

# Generated at 2022-06-18 06:12:59.837674
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord
    from .primitive import OctWord

    # Test mute() with register-objects
    reg = Register(name="reg", width=8)
    mute(reg)
    assert reg.muted is True

    # Test mute() with bit-objects
    bit = Bit(name="bit", width=1)
    mute(bit)
    assert bit.muted is True

    # Test mute() with byte-objects
    byte = Byte(name="byte", width=8)
    mute(byte)
    assert byte.muted is True

    # Test mute() with word-objects
    word = Word(name="word", width=16)

# Generated at 2022-06-18 06:13:10.463876
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import BitField
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitStruct
    from .primitive import BitUnion
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import MappedRegister
    from .primitive import MappedBitField
    from .primitive import MappedBit
    from .primitive import MappedBitArray
    from .primitive import MappedBitStruct
    from .primitive import MappedBitUnion
    from .primitive import MappedEnum
    from .primitive import MappedFlag
    from .primitive import MappedRegisterArray
    from .primitive import MappedBitFieldArray
    from .primitive import M