

# Generated at 2022-06-18 06:11:51.897341
# Unit test for function mute
def test_mute():
    """
    Test the mute function.
    """
    from .primitive import Register

    reg = Register(name="test_mute", width=8)
    mute(reg)
    assert reg.muted == True



# Generated at 2022-06-18 06:12:00.729493
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedRegisterArray
    from .primitive import MappedBitArray
    from .primitive import MappedBitFieldArray
    from .primitive import MappedEnumArray
    from .primitive import MappedRegisterArray
    from .primitive import MappedBitArray
    from .primitive import MappedBitFieldArray
    from .primitive import MappedEnum

# Generated at 2022-06-18 06:12:09.276774
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import MappedRegister
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedBit
    from .primitive import MappedRegisterArray
    from .primitive import MappedBitFieldArray
    from .primitive import MappedBitArray

    # Test unmute() with a Register object
    reg = Register(name="reg", address=0x00, bit_width=8)
    reg.mute()
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

    # Test unmute() with a Bit object


# Generated at 2022-06-18 06:12:14.455674
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    # Create a register object
    reg = Register(name="test_register", width=8)
    # Mute the register
    mute(reg)
    # Check if the register is muted
    assert reg.is_muted()
    # Unmute the register
    unmute(reg)
    # Check if the register is unmuted
    assert not reg.is_muted()



# Generated at 2022-06-18 06:12:25.275560
# Unit test for function mute
def test_mute():
    """
    Test the mute function.
    """
    from .primitive import Register
    from .primitive import Signal
    from .primitive import Wire

    # Create a register
    reg = Register(name="reg", width=8)
    # Create a signal
    sig = Signal(name="sig", width=8)
    # Create a wire
    wire = Wire(name="wire", width=8)

    # Mute the register
    mute(reg)
    # Check if the register is muted
    assert reg.muted == True

    # Mute the signal
    mute(sig)
    # Check if the signal is muted
    assert sig.muted == True

    # Mute the wire
    mute(wire)
    # Check if the wire is muted
    assert wire.muted == True

    # Unmute the register

# Generated at 2022-06-18 06:12:27.948683
# Unit test for function unmute
def test_unmute():
    """
    Test function unmute.
    """
    from .primitive import Register
    from .primitive import Mute

    reg = Register(Mute())
    assert reg.is_muted()
    unmute(reg)
    assert not reg.is_muted()


# Generated at 2022-06-18 06:12:39.300137
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitArray
    from .primitive import Enum
    from .primitive import EnumField
    from .primitive import EnumArray
    from .primitive import Flag
    from .primitive import FlagField
    from .primitive import FlagArray
    from .primitive import Pointer
    from .primitive import PointerField
    from .primitive import PointerArray
    from .primitive import Array
    from .primitive import ArrayField
    from .primitive import ArrayArray
    from .primitive import RegisterArray
    from .primitive import RegisterField
    from .primitive import RegisterArrayField
    from .primitive import RegisterArrayArray
    from .primitive import RegisterArrayArrayField

# Generated at 2022-06-18 06:12:48.185155
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import ArrayField
    from .primitive import EnumField
    from .primitive import EnumBitField
    from .primitive import EnumArrayField
    from .primitive import EnumBit
    from .primitive import EnumArray
    from .primitive import EnumRegister
    from .primitive import EnumArrayRegister
    from .primitive import EnumBitRegister
    from .primitive import EnumBitFieldRegister
    from .primitive import EnumArrayFieldRegister
    from .primitive import EnumFieldRegister
    from .primitive import Flag
    from .primitive import FlagField

# Generated at 2022-06-18 06:12:59.841337
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Bit
    from .primitive import Bus
    from .primitive import Bus8
    from .primitive import Bus16
    from .primitive import Bus32
    from .primitive import Bus64
    from .primitive import Bus128
    from .primitive import Bus256
    from .primitive import Bus512
    from .primitive import Bus1024
    from .primitive import Bus2048
    from .primitive import Bus4096
    from .primitive import Bus8192
    from .primitive import Bus16384
    from .primitive import Bus32768
    from .primitive import Bus65536
    from .primitive import Bus131072
    from .primitive import Bus262144
    from .primitive import Bus524288

# Generated at 2022-06-18 06:13:10.453625
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Word
    from .primitive import Byte
    from .primitive import HalfWord
    from .primitive import DoubleWord
    from .primitive import QuadWord
    from .primitive import OctWord
    from .primitive import HexWord
    from .primitive import BitField
    from .primitive import WordField
    from .primitive import ByteField
    from .primitive import HalfWordField
    from .primitive import DoubleWordField
    from .primitive import QuadWordField
    from .primitive import OctWordField
    from .primitive import HexWordField

    reg1 = Register(name="reg1", width=8)
    reg2 = Register(name="reg2", width=16)