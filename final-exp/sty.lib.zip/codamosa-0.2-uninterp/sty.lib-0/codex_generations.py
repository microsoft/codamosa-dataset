

# Generated at 2022-06-18 06:11:49.328661
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(0x00, 0x00)
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.muted


# Generated at 2022-06-18 06:11:58.463766
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedRegisterArray
    from .primitive import MappedBitArray
    from .primitive import MappedBitFieldArray
    from .primitive import MappedEnumArray

    # Create a register

# Generated at 2022-06-18 06:12:07.053268
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Word
    from .primitive import Byte
    from .primitive import HalfWord
    from .primitive import DoubleWord
    from .primitive import QuadWord

    # Test for Bit
    bit = Bit(name="bit", width=1)
    mute(bit)
    assert bit.is_muted()

    # Test for Word
    word = Word(name="word", width=16)
    mute(word)
    assert word.is_muted()

    # Test for Byte
    byte = Byte(name="byte")
    mute(byte)
    assert byte.is_muted()

    # Test for HalfWord
    halfword = HalfWord(name="halfword")
    mute(halfword)
    assert halfword.is_muted

# Generated at 2022-06-18 06:12:16.415884
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import RegisterFile
    from .primitive import RegisterArray
    from .primitive import RegisterMap
    from .primitive import RegisterField
    from .primitive import RegisterFieldArray
    from .primitive import RegisterFieldMap
    from .primitive import RegisterFieldMapArray
    from .primitive import RegisterFieldStruct
    from .primitive import RegisterFieldStructArray
    from .primitive import RegisterFieldStructMap
    from .primitive import RegisterFieldStructMapArray
    from .primitive import RegisterFieldUnion
    from .primitive import RegisterFieldUnionArray
    from .primitive import RegisterFieldUnionMap
    from .primitive import RegisterFieldUnionMapArray
    from .primitive import RegisterFieldUnionStruct
    from .primitive import RegisterFieldUnionStructArray
    from .primitive import RegisterFieldUnionStructMap
   

# Generated at 2022-06-18 06:12:26.660635
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord
    from .primitive import OctWord
    from .primitive import HexWord
    from .primitive import BitField
    from .primitive import ByteField
    from .primitive import WordField
    from .primitive import DoubleWordField
    from .primitive import QuadWordField
    from .primitive import OctWordField
    from .primitive import HexWordField
    from .primitive import BitArray
    from .primitive import ByteArray
    from .primitive import WordArray
    from .primitive import DoubleWordArray
    from .primitive import QuadWordArray
    from .primitive import OctWordArray
    from .primitive import Hex

# Generated at 2022-06-18 06:12:32.331829
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    # Create a register object
    reg = Register(name="TestRegister", address=0x00, bit_width=8, reset_value=0x00)

    # Mute the register object
    reg.mute()

    # Test the unmute() function
    unmute(reg)

    # Check if the register object is unmuted
    assert reg.muted == False



# Generated at 2022-06-18 06:12:44.434112
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitArray
    from .primitive import BitStruct
    from .primitive import Enum
    from .primitive import EnumBitField
    from .primitive import EnumBitArray
    from .primitive import EnumBitStruct
    from .primitive import EnumArray
    from .primitive import EnumStruct
    from .primitive import EnumRegister
    from .primitive import EnumRegisterArray
    from .primitive import EnumRegisterStruct
    from .primitive import RegisterArray
    from .primitive import RegisterStruct
    from .primitive import RegisterFile
    from .primitive import RegisterFileArray
    from .primitive import RegisterFileStruct
    from .primitive import RegisterFileArrayStruct

# Generated at 2022-06-18 06:12:46.972211
# Unit test for function mute
def test_mute():
    from .primitive import Register
    reg = Register(name="test_reg", width=8)
    reg.mute()
    assert reg.mute_state == True


# Generated at 2022-06-18 06:12:57.929864
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import BitField
    from .primitive import Bit
    from .primitive import MappedRegister
    from .primitive import MappedBitField
    from .primitive import MappedBit
    from .primitive import Memory
    from .primitive import MemoryBitField
    from .primitive import MemoryBit
    from .primitive import MemoryMap
    from .primitive import MemoryMapBitField
    from .primitive import MemoryMapBit
    from .primitive import MemoryMapRegister
    from .primitive import MemoryMapBitFieldRegister
    from .primitive import MemoryMapBitRegister
    from .primitive import MemoryMapRegisterBitField
    from .primitive import MemoryMapRegisterBit
    from .primitive import MemoryMapRegisterBitFieldRegister
    from .primitive import MemoryMapRegisterBitRegister

# Generated at 2022-06-18 06:13:04.165474
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg1 = Register(0, 'reg1')
    reg2 = Register(0, 'reg2')
    reg3 = Register(0, 'reg3')
    reg1.mute()
    reg2.mute()
    reg3.mute()
    assert reg1.muted
    assert reg2.muted
    assert reg3.muted
    unmute(reg1, reg2, reg3)
    assert not reg1.muted
    assert not reg2.muted
    assert not reg3.muted
