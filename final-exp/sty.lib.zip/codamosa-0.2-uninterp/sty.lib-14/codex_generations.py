

# Generated at 2022-06-18 06:11:55.070415
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import RegisterArray
    from .primitive import RegisterFile
    from .primitive import RegisterMap
    from .primitive import RegisterCluster
    from .primitive import RegisterFileArray
    from .primitive import RegisterMapArray
    from .primitive import RegisterClusterArray

    # Test unmute() with Register
    reg = Register()
    reg.mute()
    unmute(reg)
    assert reg.mute_count == 0

    # Test unmute() with Bit
    bit = Bit()
    bit.mute()
    unmute(bit)
    assert bit.mute_count == 0

    # Test unmute() with BitField
    bitfield = BitField()
    bitfield.mute()


# Generated at 2022-06-18 06:11:56.920419
# Unit test for function mute
def test_mute():
    from .primitive import Register
    reg = Register(0)
    mute(reg)
    assert reg.muted == True


# Generated at 2022-06-18 06:12:03.549901
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import ArrayField
    from .primitive import EnumField
    from .primitive import EnumBitField
    from .primitive import EnumArrayField
    from .primitive import EnumBit
    from .primitive import EnumArray
    from .primitive import EnumRegister
    from .primitive import EnumBitRegister
    from .primitive import EnumArrayRegister
    from .primitive import Flag
    from .primitive import FlagRegister
    from .primitive import FlagArray
    from .primitive import FlagArrayRegister
    from .primitive import FlagBit
    from .primitive import FlagBitRegister
    from .primitive import FlagBitArray
    from .primitive import FlagBit

# Generated at 2022-06-18 06:12:13.014763
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitArray
    from .primitive import EnumField
    from .primitive import EnumBitField
    from .primitive import EnumBitArray
    from .primitive import EnumRegister
    from .primitive import EnumArrayRegister
    from .primitive import ArrayRegister
    from .primitive import ArrayBitField
    from .primitive import ArrayBitArray
    from .primitive import ArrayEnumField
    from .primitive import ArrayEnumBitField
    from .primitive import ArrayEnumBitArray
    from .primitive import ArrayEnumRegister
    from .primitive import ArrayEnumArrayRegister
    from .primitive import ArrayRegister
    from .primitive import ArrayBitField

# Generated at 2022-06-18 06:12:23.677609
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import RegisterFile
    from .primitive import RegisterArray
    from .primitive import RegisterBitfield
    from .primitive import RegisterBit
    from .primitive import RegisterBitArray
    from .primitive import RegisterBitfieldArray

    # Register
    reg = Register(name="reg", address=0x0, width=32, reset=0x0, access="RW")
    reg.mute()
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

    # RegisterFile
    regfile = RegisterFile(name="regfile", address=0x0, width=32, reset=0x0, access="RW")
    regfile.mute()
    assert regfile.muted == True
    unmute(regfile)
    assert reg

# Generated at 2022-06-18 06:12:31.008449
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import Dff

    # Test for Register
    a = Register(1)
    b = Register(0)
    mute(a, b)
    assert a.value == 0
    assert b.value == 0

    # Test for Wire
    a = Wire(1)
    b = Wire(0)
    mute(a, b)
    assert a.value == 0
    assert b.value == 0

    # Test for Not
    a = Not(1)
    b = Not(0)
    mute(a, b)
    assert a.value == 0

# Generated at 2022-06-18 06:12:42.026015
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Signal
    from .primitive import Wire
    from .primitive import InPort
    from .primitive import OutPort
    from .primitive import InOutPort
    from .primitive import Const
    from .primitive import Mux
    from .primitive import Demux
    from .primitive import Decoder
    from .primitive import Encoder
    from .primitive import Adder
    from .primitive import Subtractor
    from .primitive import Incrementer
    from .primitive import Decrementer
    from .primitive import Comparator
    from .primitive import ALU
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import Counter
    from .primitive import ShiftRegister
    from .primitive import RegisterFile

# Generated at 2022-06-18 06:12:52.927301
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import Float
    from .primitive import Integer
    from .primitive import Pointer
    from .primitive import String
    from .primitive import UnsignedInteger
    from .primitive import UnsignedIntegerArray
    from .primitive import UnsignedIntegerField
    from .primitive import UnsignedIntegerStruct

    # Test unmute() with a single object
    reg = Register(name="reg", address=0x1000, width=32, description="Test register")
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.m

# Generated at 2022-06-18 06:13:03.010590
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedRegisterArray
    from .primitive import MappedBitArray
    from .primitive import MappedBitFieldArray
    from .primitive import MappedEnumArray

    # Test Register
    reg = Register(name="reg", address=0x00, width=8)
    mute(reg)
    assert reg.muted == True

# Generated at 2022-06-18 06:13:13.725111
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import BitField
    from .primitive import Bit
    from .primitive import MappedRegister
    from .primitive import MappedBitField
    from .primitive import MappedBit
    from .primitive import MappedRegisterArray
    from .primitive import MappedBitFieldArray
    from .primitive import MappedBitArray

    reg = Register(0x00, 0x00, 0x00)
    bitfield = BitField(0x00, 0x00, 0x00, 0x00, 0x00)
    bit = Bit(0x00, 0x00, 0x00, 0x00)
    mreg = MappedRegister(0x00, 0x00, 0x00, 0x00)