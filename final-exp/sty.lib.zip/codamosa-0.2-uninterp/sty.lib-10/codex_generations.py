

# Generated at 2022-06-18 06:11:57.193681
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord
    from .primitive import OctWord
    from .primitive import HexWord
    from .primitive import BitField
    from .primitive import ByteField
    from .primitive import WordField
    from .primitive import DoubleWordField
    from .primitive import QuadWordField
    from .primitive import OctWordField
    from .primitive import HexWordField

    # Test mute() with a Bit object
    bit = Bit(name="bit", width=1, offset=0)
    mute(bit)
    assert bit.mute_state == True

    # Test mute()

# Generated at 2022-06-18 06:12:00.877683
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    # Create a register object
    reg = Register(name="test_register", width=1)
    # Mute the register
    reg.mute()
    # Unmute the register
    unmute(reg)
    # Check if the register is unmuted
    assert reg.is_muted() == False


# Generated at 2022-06-18 06:12:09.380406
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumField
    from .primitive import EnumArray
    from .primitive import EnumBitField
    from .primitive import EnumBitFieldArray
    from .primitive import EnumBitFieldArrayEntry
    from .primitive import EnumBitFieldEntry
    from .primitive import EnumEntry
    from .primitive import EnumFieldEntry
    from .primitive import EnumFieldArrayEntry
    from .primitive import EnumFieldArray
    from .primitive import EnumFieldArrayEntry
    from .primitive import EnumFieldEntry
    from .primitive import Enum

# Generated at 2022-06-18 06:12:19.826275
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.

    :return: True if the test passed, False otherwise.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import RegisterMap
    from .primitive import RegisterFile
    from .primitive import RegisterFileMap
    from .primitive import RegisterFileArray
    from .primitive import RegisterFileMapArray
    from .primitive import RegisterFileMapArrayEntry
    from .primitive import RegisterFileMapEntry
    from .primitive import RegisterMapEntry
    from .primitive import RegisterMapArrayEntry
    from .primitive import RegisterMapArray
    from .primitive import RegisterFileMapArrayEntry

# Generated at 2022-06-18 06:12:23.155894
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(name='test', width=8)
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.muted


# Generated at 2022-06-18 06:12:26.853033
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register

    reg = Register(name="test_register")
    reg.mute()
    assert reg.is_muted()
    unmute(reg)
    assert not reg.is_muted()



# Generated at 2022-06-18 06:12:37.221938
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Word
    from .primitive import DWord
    from .primitive import QWord
    from .primitive import Array
    from .primitive import Struct
    from .primitive import Union
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import EnumFlag
    from .primitive import BitStruct
    from .primitive import BitUnion
    from .primitive import BitEnum
    from .primitive import BitFlag
    from .primitive import BitEnumFlag

    # Test mute() with a single object

# Generated at 2022-06-18 06:12:46.676366
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute.
    """
    from .primitive import Register
    from .primitive import RegisterFile
    from .primitive import RegisterArray
    from .primitive import RegisterBit
    from .primitive import RegisterBitfield
    from .primitive import RegisterBitfieldArray

    reg = Register("reg", 32)
    regfile = RegisterFile("regfile", 32, 2)
    regarray = RegisterArray("regarray", 32, 2)
    regbit = RegisterBit("regbit", 32, 0)
    regbitfield = RegisterBitfield("regbitfield", 32, 0, 4)
    regbitfieldarray = RegisterBitfieldArray("regbitfieldarray", 32, 0, 4, 2)

    mute(reg, regfile, regarray, regbit, regbitfield, regbitfieldarray)

    assert reg.m

# Generated at 2022-06-18 06:12:57.601345
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DWord
    from .primitive import QWord
    from .primitive import Array
    from .primitive import Struct
    from .primitive import Union
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import Pointer
    from .primitive import Const
    from .primitive import Alias
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import BitUnion
    from .primitive import BitEnum
    from .primitive import BitFlag
    from .primitive import BitPointer
    from .primitive import BitConst
    from .primitive import BitAlias
    from .primitive import BitArray

# Generated at 2022-06-18 06:13:01.073431
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(0, 0, 0, 0)
    reg.mute()
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False
