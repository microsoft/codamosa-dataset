

# Generated at 2022-06-18 06:11:57.631066
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import MemoryMap
    from .primitive import RegisterMap
    from .primitive import RegisterFile
    from .primitive import RegisterFileMap
    from .primitive import RegisterFileArray
    from .primitive import RegisterFileArrayMap
    from .primitive import RegisterFileArrayMapArray
    from .primitive import RegisterFileArrayMapArrayMap
    from .primitive import RegisterFileArrayMapArrayMapArray
    from .primitive import RegisterFileArrayMapArrayMapArrayMap
    from .primitive import RegisterFileArrayMapArrayMapArrayMapArray
    from .primitive import RegisterFileArrayMapArrayMapArrayMapArrayMap

# Generated at 2022-06-18 06:12:06.036127
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Bit
    from .primitive import Constant
    from .primitive import Port
    from .primitive import Bus
    from .primitive import BusSlice
    from .primitive import BusExtract
    from .primitive import BusConcatenate
    from .primitive import BusReplicate
    from .primitive import BusZeroExtend
    from .primitive import BusSignExtend
    from .primitive import BusArithmeticRightShift
    from .primitive import BusLogicalRightShift
    from .primitive import BusLeftShift
    from .primitive import BusAdd
    from .primitive import BusSubtract
    from .primitive import BusMultiply
    from .primitive import BusDivide
    from .primitive import BusModulo

# Generated at 2022-06-18 06:12:08.990867
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    r = Register(name="test_register")
    r.mute()
    assert r.muted == True
    unmute(r)
    assert r.muted == False


# Generated at 2022-06-18 06:12:19.286466
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import ArrayField
    from .primitive import EnumField
    from .primitive import EnumBitField
    from .primitive import EnumArrayField
    from .primitive import EnumBit
    from .primitive import EnumArray
    from .primitive import EnumRegister
    from .primitive import EnumArrayRegister
    from .primitive import Flag
    from .primitive import FlagField
    from .primitive import FlagArray
    from .primitive import FlagArrayField
    from .primitive import FlagRegister
    from .primitive import FlagArrayRegister
    from .primitive import Pointer
    from .primitive import PointerRegister
    from .primitive import PointerArray


# Generated at 2022-06-18 06:12:23.348777
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute.
    """
    from .primitive import Register
    reg = Register(name="test_register")
    assert reg.muted == False
    mute(reg)
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

# Generated at 2022-06-18 06:12:30.863381
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DWord
    from .primitive import QWord
    from .primitive import Array
    from .primitive import Struct
    from .primitive import Union

    # Test for Register
    reg = Register(name="reg", width=8)
    reg.mute()
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

    # Test for Bit
    bit = Bit(name="bit", width=1)
    bit.mute()
    assert bit.muted == True
    unmute(bit)
    assert bit.muted == False

    # Test for Byte
    byte = Byte(name="byte")
    byte.mute

# Generated at 2022-06-18 06:12:41.837694
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitVector
    from .primitive import Enum
    from .primitive import EnumBitField
    from .primitive import EnumBitVector
    from .primitive import EnumField
    from .primitive import EnumVector
    from .primitive import Field
    from .primitive import Vector
    from .primitive import RegisterArray
    from .primitive import RegisterBitArray
    from .primitive import RegisterBitFieldArray
    from .primitive import RegisterBitVectorArray
    from .primitive import RegisterEnumArray
    from .primitive import RegisterEnumBitFieldArray
    from .primitive import RegisterEnumBitVectorArray
    from .primitive import RegisterEnumFieldArray
    from .primitive import RegisterEn

# Generated at 2022-06-18 06:12:49.145561
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord

    # Test mute() with a Bit object
    bit = Bit(name="bit")
    mute(bit)
    assert bit.muted is True

    # Test mute() with a Byte object
    byte = Byte(name="byte")
    mute(byte)
    assert byte.muted is True

    # Test mute() with a Word object
    word = Word(name="word")
    mute(word)
    assert word.muted is True

    # Test mute() with a DoubleWord object
    double_word = DoubleWord(name="double_word")
    mute(double_word)
    assert double_word.muted is True

# Generated at 2022-06-18 06:13:00.337541
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU
    from .primitive import PC
    from .primitive import InstructionMemory
    from .primitive import DataMemory
    from .primitive import ControlUnit
    from .primitive import RegisterFile
    from .primitive import CPU

    # Test for Register
    reg = Register(8)
    reg.write(0xFF)
    assert reg.read() == 0xFF
    mute(reg)
    reg.write(0x00)
    assert reg.read() == 0xFF
    unmute(reg)
    reg.write(0x00)

# Generated at 2022-06-18 06:13:11.311429
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire

    a = Register(8, "a")
    b = Register(8, "b")
    c = Register(8, "c")
    d = Register(8, "d")

    w = Wire(8, "w")

    a.d(b)
    b.d(c)
    c.d(d)
    d.d(w)

    a.mute()
    b.mute()
    c.mute()
    d.mute()

    a.i(1)
    b.i(2)
    c.i(3)
    d.i(4)

    assert w.o() == 0

    a.unmute()
    b.unmute()
    c.unmute()