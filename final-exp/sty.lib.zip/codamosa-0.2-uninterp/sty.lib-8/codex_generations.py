

# Generated at 2022-06-18 06:11:59.033549
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU
    from .primitive import CPU
    from .primitive import Adder
    from .primitive import Subtractor
    from .primitive import Incrementer
    from .primitive import ALUControl
    from .primitive import ProgramCounter
    from .primitive import InstructionMemory
    from .primitive import DataMemory
    from .primitive import RegisterFile
    from .primitive import ControlUnit
    from .primitive import Multiplexer

# Generated at 2022-06-18 06:12:07.454381
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import ArrayField
    from .primitive import RegisterFile
    from .primitive import RegisterFileArray
    from .primitive import RegisterFileField
    from .primitive import RegisterFileArrayField

    reg = Register(name="reg", width=16)
    bit = Bit(name="bit", width=1)
    bitfield = BitField(name="bitfield", width=4)
    array = Array(name="array", width=16, count=4)
    arrayfield = ArrayField(name="arrayfield", width=4, count=4)
    regfile = RegisterFile(name="regfile", width=16, count=4)

# Generated at 2022-06-18 06:12:17.608682
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute().
    """
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import Dmux
    from .primitive import Dff
    from .primitive import Adder
    from .primitive import ALU
    from .primitive import Ram
    from .primitive import PC
    from .primitive import Screen
    from .primitive import Keyboard
    from .primitive import Memory
    from .primitive import CPU

    # Test for Register
    reg = Register(16)
    reg.in_ = Wire(0)
    reg.load = Wire(0)

# Generated at 2022-06-18 06:12:20.958160
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(name="test", width=8)
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.muted


# Generated at 2022-06-18 06:12:29.418889
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Word
    from .primitive import Byte
    from .primitive import HalfWord
    from .primitive import DoubleWord
    from .primitive import QuadWord
    from .primitive import OctWord
    from .primitive import HexWord
    from .primitive import BitField
    from .primitive import WordField
    from .primitive import ByteField
    from .primitive import HalfWordField
    from .primitive import DoubleWordField
    from .primitive import QuadWordField
    from .primitive import OctWordField
    from .primitive import HexWordField

    # Test for Bit
    a = Bit()
    mute(a)
    assert a.mute_state == True
    unmute(a)

# Generated at 2022-06-18 06:12:33.113096
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(name='test')
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.muted


# Generated at 2022-06-18 06:12:44.432818
# Unit test for function unmute
def test_unmute():
    """
    This function tests the unmute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import MappedRegister
    from .primitive import RegisterArray
    from .primitive import RegisterField
    from .primitive import RegisterStruct
    from .primitive import RegisterUnion
    from .primitive import SubRegister
    from .primitive import SubRegisterArray
    from .primitive import SubRegisterField
    from .primitive import SubRegisterStruct
    from .primitive import SubRegisterUnion
    from .primitive import SubRegisterBit
    from .primitive import SubRegisterBitArray

# Generated at 2022-06-18 06:12:55.316811
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import FlagGroup
    from .primitive import MappedRegister
    from .primitive import RegisterMap
    from .primitive import RegisterStruct
    from .primitive import RegisterUnion
    from .primitive import RegisterView
    from .primitive import RegisterViewMap
    from .primitive import RegisterViewStruct
    from .primitive import RegisterViewUnion
    from .primitive import RegisterViewArray
    from .primitive import RegisterViewArrayMap
    from .primitive import RegisterViewArrayStruct
    from .primitive import RegisterViewArrayUnion

# Generated at 2022-06-18 06:13:04.271199
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitArray
    from .primitive import Enum
    from .primitive import EnumField
    from .primitive import EnumArray
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedBitArray
    from .primitive import MappedEnum
    from .primitive import MappedEnumField
    from .primitive import MappedEnumArray

    # Register
    reg = Register(name="reg", address=0x00, width=8, default=0x00)
    reg.mute()
    assert reg.muted is True
    unmute(reg)
    assert reg.muted

# Generated at 2022-06-18 06:13:14.564711
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import Dff
    from .primitive import Adder
    from .primitive import Inc
    from .primitive import ALU
    from .primitive import Ram
    from .primitive import Rom
    from .primitive import Counter
    from .primitive import ShiftRegister
    from .primitive import FullAdder
    from .primitive import HalfAdder
    from .primitive import RippleCarryAdder
    from .primitive import RippleCarryAdder16
    from .primitive import RippleCarryAdder32
    from .primitive import RippleCarryAdder64