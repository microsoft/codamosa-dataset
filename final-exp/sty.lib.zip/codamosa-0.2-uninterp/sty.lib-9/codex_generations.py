

# Generated at 2022-06-18 06:11:56.048221
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU
    from .primitive import PC
    from .primitive import InstructionMemory
    from .primitive import DataMemory
    from .primitive import CPU

    a = Register(8)
    b = Register(8)
    c = Register(8)
    d = Register(8)
    e = Register(8)
    f = Register(8)
    g = Register(8)
    h = Register(8)
    i = Register(8)
   

# Generated at 2022-06-18 06:12:02.094814
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitField
    from .primitive import BitStruct
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import FlagArray
    from .primitive import FlagField
    from .primitive import FlagStruct
    from .primitive import MaskedRegister
    from .primitive import Pointer
    from .primitive import PointerArray
    from .primitive import PointerField
    from .primitive import PointerStruct
    from .primitive import RegisterArray
    from .primitive import RegisterField
    from .primitive import RegisterStruct
    from .primitive import Subregister
    from .primitive import SubregisterArray
    from .primitive import SubregisterField
    from .primitive import Sub

# Generated at 2022-06-18 06:12:03.930823
# Unit test for function mute
def test_mute():
    from .primitive import Register
    reg = Register(name="test", width=8)
    mute(reg)
    assert reg.muted == True


# Generated at 2022-06-18 06:12:13.417679
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DWord
    from .primitive import QWord
    from .primitive import DQWord
    from .primitive import Array
    from .primitive import Struct
    from .primitive import Union
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import BitField
    from .primitive import Pointer
    from .primitive import Function
    from .primitive import FunctionPointer
    from .primitive import ArrayPointer
    from .primitive import PointerPointer
    from .primitive import FunctionPointerPointer
    from .primitive import ArrayPointerPointer
    from .primitive import PointerArray
    from .primitive import Function

# Generated at 2022-06-18 06:12:24.157153
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import BitField
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitStruct
    from .primitive import BitUnion
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import Mask
    from .primitive import MappedRegister
    from .primitive import RegisterArray
    from .primitive import RegisterBit
    from .primitive import RegisterBitArray
    from .primitive import RegisterBitStruct
    from .primitive import RegisterBitUnion
    from .primitive import RegisterEnum
    from .primitive import RegisterFlag
    from .primitive import RegisterMap
    from .primitive import RegisterStruct
    from .primitive import RegisterUnion
    from .primitive import RegisterValue
    from .primitive import RegisterValueArray

# Generated at 2022-06-18 06:12:26.661401
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    reg = Register(name='test_reg', width=4, init_val=0)
    reg.mute()
    assert reg.mute_status == True
    unmute(reg)
    assert reg.mute_status == False


# Generated at 2022-06-18 06:12:37.086532
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Signal
    from .primitive import Wire
    from .primitive import Const
    from .primitive import Mux
    from .primitive import Slice
    from .primitive import Concat
    from .primitive import Replicate
    from .primitive import ZeroExtend
    from .primitive import SignExtend
    from .primitive import ArithLogic
    from .primitive import ShiftRotate
    from .primitive import Memory
    from .primitive import ROM
    from .primitive import RAM
    from .primitive import RAM_ST
    from .primitive import RAM_DT
    from .primitive import RAM_ST_1R_1W
    from .primitive import RAM_ST_1R_1W_BYTE
    from .primitive import RAM_ST_1

# Generated at 2022-06-18 06:12:46.620220
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute.
    """
    # Test if the function raises an error if the object is not a register
    with pytest.raises(ValueError):
        mute(1)

    # Test if the function raises an error if the object is not a register
    with pytest.raises(ValueError):
        mute(1, 2, 3)

    # Test if the function raises an error if the object is not a register
    with pytest.raises(ValueError):
        mute(1, 2, 3, 4, 5)

    # Test if the function raises an error if the object is not a register
    with pytest.raises(ValueError):
        mute(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    # Test if the function raises an error if the object is not a

# Generated at 2022-06-18 06:12:57.432328
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import MappedRegister
    from .primitive import MappedArray
    from .primitive import MappedBitField
    from .primitive import MappedBit
    from .primitive import MappedRegister
    from .primitive import MappedArray
    from .primitive import MappedBitField
    from .primitive import MappedBit
    from .primitive import MappedRegister
    from .primitive import MappedArray
    from .primitive import MappedBitField
    from .primitive import MappedBit
    from .primitive import MappedRegister
    from .primitive import MappedArray
    from .primitive import MappedBitField
    from .primitive import MappedBit

# Generated at 2022-06-18 06:13:05.474759
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import ArrayField
    from .primitive import RegisterFile
    from .primitive import RegisterFileField
    from .primitive import RegisterMap
    from .primitive import RegisterMapField
    from .primitive import RegisterMapArray
    from .primitive import RegisterMapArrayField
    from .primitive import RegisterMapArrayFieldEntry
    from .primitive import RegisterMapArrayFieldEntryField
    from .primitive import RegisterMapArrayFieldEntryArray
    from .primitive import RegisterMapArrayFieldEntryArrayField

    # Test for Register