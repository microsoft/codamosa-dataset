

# Generated at 2022-06-18 06:11:55.053311
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Bitfield
    from .primitive import BitfieldGroup
    from .primitive import BitGroup
    from .primitive import BitGroupArray
    from .primitive import BitArray
    from .primitive import BitfieldArray
    from .primitive import BitfieldGroupArray
    from .primitive import BitGroupArray
    from .primitive import BitGroupArrayArray
    from .primitive import BitArrayArray
    from .primitive import BitfieldArrayArray
    from .primitive import BitfieldGroupArrayArray
    from .primitive import BitGroupArrayArray
    from .primitive import BitGroupArrayArrayArray
    from .primitive import BitArrayArrayArray
    from .primitive import BitfieldArrayArrayArray
    from .primitive import BitfieldGroupArrayArrayArray

# Generated at 2022-06-18 06:12:02.229111
# Unit test for function unmute
def test_unmute():
    from . import register
    from . import primitive
    from . import register_file
    from . import memory
    from . import memory_file
    from . import memory_map
    from . import memory_map_file
    from . import bus
    from . import bus_file
    from . import bus_map
    from . import bus_map_file
    from . import interface
    from . import interface_file
    from . import interface_map
    from . import interface_map_file
    from . import device
    from . import device_file
    from . import device_map
    from . import device_map_file
    from . import system
    from . import system_file
    from . import system_map
    from . import system_map_file
    from . import system_map_file_parser
    from . import system_map

# Generated at 2022-06-18 06:12:09.071679
# Unit test for function unmute
def test_unmute():
    """
    This function tests the unmute() function.
    """
    from .primitive import Register
    from .primitive import Mute
    from .primitive import Unmute
    from .primitive import MuteError

    reg = Register(name="reg", width=8)
    mute(reg)
    assert isinstance(reg.mute_state, Mute)
    unmute(reg)
    assert isinstance(reg.mute_state, Unmute)
    try:
        unmute(reg)
    except MuteError:
        pass
    else:
        raise Exception("MuteError not raised")

# Generated at 2022-06-18 06:12:19.385765
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU
    from .primitive import PC
    from .primitive import InstructionMemory
    from .primitive import DataMemory
    from .primitive import ControlUnit
    from .primitive import CPU
    from .primitive import InstructionDecoder
    from .primitive import InstructionRegister
    from .primitive import ProgramCounter
    from .primitive import ProgramCounterIncrementer
    from .primitive import ProgramCounterIncrementerMux
    from .primitive import ProgramCounterMux

# Generated at 2022-06-18 06:12:24.645721
# Unit test for function mute
def test_mute():
    from .primitive import Register
    reg = Register(name="test_register", width=8)
    reg.mute()
    assert reg.mute_state == True
    mute(reg)
    assert reg.mute_state == True
    unmute(reg)
    assert reg.mute_state == False
    reg.unmute()
    assert reg.mute_state == False

# Generated at 2022-06-18 06:12:33.394864
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DWord
    from .primitive import QWord
    from .primitive import Array
    from .primitive import Struct
    from .primitive import Union
    from .primitive import Enum
    from .primitive import Flag
    from .primitive import BitField
    from .primitive import Pointer
    from .primitive import Function
    from .primitive import FunctionPointer
    from .primitive import String
    from .primitive import ArrayPointer
    from .primitive import ArrayPointerPointer
    from .primitive import ArrayPointerPointerPointer
    from .primitive import ArrayPointerPointerPointerPointer
    from .primitive import ArrayPointerPointerPo

# Generated at 2022-06-18 06:12:44.434049
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumBitField
    from .primitive import EnumArray
    from .primitive import EnumBit
    from .primitive import EnumBitField
    from .primitive import EnumArray
    from .primitive import EnumBit
    from .primitive import EnumBitField
    from .primitive import EnumArray
    from .primitive import EnumBit
    from .primitive import EnumBitField
    from .primitive import EnumArray
    from .primitive import EnumBit
    from .primitive import EnumBitField
    from .primitive import EnumArray
    from .primitive import EnumBit

# Generated at 2022-06-18 06:12:55.373338
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedRegisterCollection
    from .primitive import MappedBitCollection
    from .primitive import MappedBitFieldCollection
    from .primitive import MappedArrayCollection
    from .primitive import MappedEnumCollection
    from .primitive import RegisterCollection
    from .primitive import BitCollection
    from .primitive import BitFieldCollection
    from .primitive import ArrayCollection
    from .primitive import EnumCollection
   

# Generated at 2022-06-18 06:13:04.334444
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import RegisterFile
    from .primitive import RegisterArray
    from .primitive import RegisterBit
    from .primitive import RegisterBitfield

    reg = Register(name="reg")
    reg_file = RegisterFile(name="reg_file")
    reg_array = RegisterArray(name="reg_array", size=4)
    reg_bit = RegisterBit(name="reg_bit")
    reg_bitfield = RegisterBitfield(name="reg_bitfield", size=4)

    reg.mute()
    reg_file.mute()
    reg_array.mute()
    reg_bit.mute()
    reg_bitfield.mute()


# Generated at 2022-06-18 06:13:14.603424
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitVector
    from .primitive import Array
    from .primitive import Enum
    from .primitive import EnumBitField
    from .primitive import EnumBitVector
    from .primitive import EnumArray
    from .primitive import EnumRegister
    from .primitive import EnumBit
    from .primitive import EnumRegisterBit
    from .primitive import EnumRegisterBitField
    from .primitive import EnumRegisterBitVector
    from .primitive import EnumRegisterArray
    from .primitive import EnumRegisterField
    from .primitive import EnumRegisterVector
    from .primitive import EnumRegisterFieldVector
    from .primitive import EnumRegisterFieldArray