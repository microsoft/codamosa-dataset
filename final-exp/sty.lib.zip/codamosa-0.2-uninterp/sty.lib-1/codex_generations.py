

# Generated at 2022-06-18 06:11:59.603788
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Field
    from .primitive import RegisterArray
    from .primitive import RegisterFile
    from .primitive import RegisterMap

    # Test unmute() with a Register object
    reg = Register(name='reg', width=8, offset=0x00, reset_value=0x00)
    reg.unmute()
    assert reg.mute_state == False

    # Test unmute() with a Bit object
    bit = Bit(name='bit', offset=0, width=1, reset_value=0)
    bit.unmute()
    assert bit.mute_state == False

    # Test unmute() with a BitField object

# Generated at 2022-06-18 06:12:07.903704
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Bit
    from .primitive import BitArray
    from .primitive import BitVector
    from .primitive import BitRegister
    from .primitive import BitArrayRegister
    from .primitive import BitVectorRegister
    from .primitive import BitField
    from .primitive import BitArrayField
    from .primitive import BitVectorField
    from .primitive import BitFieldRegister
    from .primitive import BitArrayFieldRegister
    from .primitive import BitVectorFieldRegister
    from .primitive import BitFieldArray
    from .primitive import BitArrayFieldArray
    from .primitive import BitVectorFieldArray
    from .primitive import BitFieldArrayRegister
    from .primitive import BitArrayFieldArrayRegister
    from .primitive import BitVectorFieldArrayRegister


# Generated at 2022-06-18 06:12:18.156672
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import BitArray
    from .primitive import BitStruct
    from .primitive import Enum

    # Test unmute() with Register
    reg = Register(name="reg", addr=0x0, bitwidth=8, reset=0x0, access="RW")
    reg.unmute()
    assert reg.mute_count == 0

    # Test unmute() with Bit
    bit = Bit(name="bit", offset=0, bitwidth=1, reset=0, access="RW")
    bit.unmute()
    assert bit.mute_count == 0

    # Test unmute() with BitField

# Generated at 2022-06-18 06:12:27.477206
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import BitField
    from .primitive import Array
    from .primitive import Enum
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
    from .primitive import MappedRegister
    from .primitive import MappedBit
    from .primitive import MappedBitField
    from .primitive import MappedArray
    from .primitive import MappedEnum
   

# Generated at 2022-06-18 06:12:38.443498
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Wire
    from .primitive import Not
    from .primitive import And
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Mux
    from .primitive import DFF
    from .primitive import RAM
    from .primitive import ROM
    from .primitive import ALU
    from .primitive import CPU
    from .primitive import Adder
    from .primitive import Subtractor
    from .primitive import Incrementer
    from .primitive import Decrementer
    from .primitive import Comparator
    from .primitive import Multiplier
    from .primitive import Divider
    from .primitive import Modulo
    from .primitive import Shifter


# Generated at 2022-06-18 06:12:48.185398
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DoubleWord
    from .primitive import QuadWord
    from .primitive import OctWord
    from .primitive import HexWord
    from .primitive import BitField
    from .primitive import ByteField
    from .primitive import WordField
    from .primitive import DoubleWordField
    from .primitive import QuadWordField
    from .primitive import OctWordField
    from .primitive import HexWordField

    reg = Register(name='reg', width=8, mute=True)
    bit = Bit(name='bit', width=1, mute=True)
    byte = Byte(name='byte', width=8, mute=True)

# Generated at 2022-06-18 06:12:59.835131
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    from .primitive import Register
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word
    from .primitive import DWord
    from .primitive import QWord
    from .primitive import Int
    from .primitive import UInt
    from .primitive import Float
    from .primitive import Double
    from .primitive import String

    # Test mute() with Bit
    bit = Bit(name="bit")
    mute(bit)
    assert bit.muted == True

    # Test mute() with Byte
    byte = Byte(name="byte")
    mute(byte)
    assert byte.muted == True

    # Test mute() with Word
    word = Word(name="word")
    mute(word)

# Generated at 2022-06-18 06:13:10.219939
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import RegisterFile
    from .primitive import RegisterArray
    from .primitive import RegisterBitfield
    from .primitive import RegisterBit
    from .primitive import RegisterEnum
    from .primitive import RegisterEnumEntry
    from .primitive import RegisterEnumEntryBitfield
    from .primitive import RegisterEnumEntryBit
    from .primitive import RegisterEnumEntryEnum
    from .primitive import RegisterEnumEntryEnumEntry
    from .primitive import RegisterEnumEntryEnumEntryBitfield
    from .primitive import RegisterEnumEntryEnumEntryBit
    from .primitive import RegisterEnumEntryEnumEntryEnum
    from .primitive import RegisterEnumEntryEnumEntryEnumEntry
    from .primitive import RegisterEnumEntryEnumEntryEnumEntryBit

# Generated at 2022-06-18 06:13:11.832307
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register

    reg = Register(name="test", width=1)
    reg.mute()
    assert reg.muted
    unmute(reg)
    assert not reg.muted



# Generated at 2022-06-18 06:13:22.389063
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute() function.
    """
    from .primitive import Register
    from .primitive import Mute
    from .primitive import Unmute
    from .primitive import MuteError

    # Create a register object
    reg = Register(name="test_register")

    # Create a mute object
    mute_obj = Mute(register=reg)

    # Create an unmute object
    unmute_obj = Unmute(register=reg)

    # Mute the register
    mute_obj.execute()

    # Unmute the register
    unmute_obj.execute()

    # Check if the register is muted
    assert not reg.is_muted()

    # Mute the register
    mute_obj.execute()

    # Try to unmute the register