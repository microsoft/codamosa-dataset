

# Generated at 2022-06-21 23:55:15.746325
# Unit test for function unmute
def test_unmute():
    """
    This module tests if the unmute() method is working.
    """
    print("testing unmute() ... ", end="")
    r1 = Register(lbls=["x", "y", "z"],
                  vals=[1, 2, 3],
                  steps=1,
                  mute_others=True)
    r2 = Register(lbls=["a", "b", "c"],
                  vals=[4, 5, 6],
                  steps=1,
                  mute_others=True)
    mute(r1, r2)
    assert r1.muted
    assert r2.muted
    unmute(r1, r2)
    assert not r1.muted
    assert not r2.muted
    print("passed!")



# Generated at 2022-06-21 23:55:19.955621
# Unit test for function unmute
def test_unmute():

    from .primitive import DRegister
    from .primitive import TRegister
    
    a = DRegister()
    b = TRegister()
    mute(a, b)
    unmute(a, b)



# Generated at 2022-06-21 23:55:23.843043
# Unit test for function mute
def test_mute():
    from .primitive import Bit
    A = Bit(0)
    C = Bit(0)
    mute(A, C)
    assert A.state == "X"
    assert C.state == "X"



# Generated at 2022-06-21 23:55:24.192278
# Unit test for function unmute
def test_unmute():
    pass



# Generated at 2022-06-21 23:55:27.987842
# Unit test for function unmute
def test_unmute():
    a = Register(4)
    assert a.muted == False, "Error in unmute() method."
    a.mute()
    assert a.muted == True, "Error in unmute() method."
    unmute(a)
    assert a.muted == False, "Error in unmute() method."

# Generated at 2022-06-21 23:55:32.735419
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute().
    """
    from .primitive import Register

    # Create a dummy register
    test_reg = Register()

    # Mute the register
    mute(test_reg)

    # Verify that the register is muted
    assert test_reg.qo.muted is True




# Generated at 2022-06-21 23:55:42.055695
# Unit test for function mute
def test_mute():
    """
    Test the mute function.
    """
    from .register import Register
    from .bit import Bit

    r1 = Register(name="Register", width=10, reset=0, mute_state=True)
    b1 = Bit(name="Bit", width=1, reset=0, bit_offset=1, mute_state=False)
    r1.add_bits(b1)

    mute(r1)

    assert isinstance(r1, Register)
    assert isinstance(b1, Bit)
    assert r1.mute_state is True
    assert b1.mute_state is True



# Generated at 2022-06-21 23:55:44.149362
# Unit test for function mute
def test_mute():
    """ Test to see if the mute() function works as intended. """
    pass


# Generated at 2022-06-21 23:55:46.360513
# Unit test for function mute
def test_mute():
    foo = Register(0b11110000)
    mute(foo)
    assert foo.mutemask == 0b00001111


# Generated at 2022-06-21 23:55:52.695895
# Unit test for function mute
def test_mute():
    from .primitive import Const
    from .primitive import Register
    from .primitive import RegisterFile

    # Create a register file
    reg = RegisterFile(width=16, depth=8, init_file="test_files/test.hex")

    # Check if the file is read correctly and all registers are initialized
    assert reg.all_registers[1].value == 0x01
    assert reg.all_registers[3].value == 0x03
    assert reg.all_registers[6].value == 0x06

    # Create new register
    reg2 = Register(16, init_value=0x55)

    # Create const
    C = Const(16, value=0xAA, name="C")
