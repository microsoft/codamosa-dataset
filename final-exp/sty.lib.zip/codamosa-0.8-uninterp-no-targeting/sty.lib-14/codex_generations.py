

# Generated at 2022-06-21 23:55:16.305742
# Unit test for function unmute
def test_unmute():
    class TestClass(Register):
        def __init__(self):
            self.muted = True

        def mute(self) -> None:
            self.muted = True

        def unmute(self) -> None:
            self.muted = False

        def test_state(self):
            return self.muted

    # Test correct usage
    a = TestClass()
    b = TestClass()
    unmute(a, b)
    assert not a.test_state() and not b.test_state()

    # Test incorrect usage
    def dummy():
        unmute(object())
        unmute([object()])
        unmute({object(), object()})
        unmute(a, object())

# Generated at 2022-06-21 23:55:21.129412
# Unit test for function mute
def test_mute():
    x = Register(4, mute=True)
    y = Register(4, mute=False)
    z = Register(4, mute=False)
    mute(x, y, z)
    assert x.muted == True
    assert y.muted == True
    assert z.muted == True


# Generated at 2022-06-21 23:55:22.916441
# Unit test for function unmute
def test_unmute():
    assert unmute is not None

# Generated at 2022-06-21 23:55:24.595473
# Unit test for function mute
def test_mute():
    r = Register('r')
    mute(r)
    assert r.is_muted()



# Generated at 2022-06-21 23:55:35.180000
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Primitive
    from .macro import Connection
    from .helpers import Output
    from .helpers import Input

    out1 = Output(1, 1)
    out2 = Output(1, 1)
    inp = Input(1, 1)

    reg1 = Register(1, 1, initial_value=8, name='reg1')
    reg2 = Register(1, 1, initial_value=0, name='reg2')
    reg3 = Register(1, 1, initial_value=1, name='reg3')
    reg4 = Register(1, 1, initial_value=2, name='reg4')

    conn1 = Connection(reg1.outports[0], reg2.inports[0])

# Generated at 2022-06-21 23:55:41.629691
# Unit test for function mute
def test_mute():
    from .primitive import Register

    reg1 = Register("Register1", 8)
    reg2 = Register("Register2", 8)
    mute(reg1, reg2)
    assert reg1.state == False
    assert reg2.state == False
    assert reg1.get_state_as_str() == "Muted"
    assert reg2.get_state_as_str() == "Muted"


# Generated at 2022-06-21 23:55:46.409691
# Unit test for function unmute
def test_unmute():
    a = BitRegister(32)
    b = BitRegister(16)
    c = BitRegister(64)
    mute(a, b, c)
    unmute(a, b, c)
    assert a.is_muted == False
    assert b.is_muted == False
    assert c.is_muted == False

# Generated at 2022-06-21 23:55:50.513202
# Unit test for function mute
def test_mute():

    # Creating registers
    r1 = Register(0, 0)
    r2 = Register(0, 0)

    # Checking before muting
    assert r1.Q == 0
    assert r2.Q == 0

    # Muting the registers
    mute(r1, r2)

    # Checking after muting
    assert r1.Q == None
    assert r2.Q == None


# Generated at 2022-06-21 23:55:59.096563
# Unit test for function unmute
def test_unmute():
    class Cls1(Register):
        def __init__(self):
            super().__init__(name="test", fg="blue")

    class Cls2(Register):
        def __init__(self):
            super().__init__(name="test", fg="blue")

    register1 = Cls1()
    register1.mute()
    assert not register1.muted

    unmute(register1, Cls2())
    assert register1.muted


# Generated at 2022-06-21 23:56:03.343447
# Unit test for function mute
def test_mute():
    a = Register(1)
    b = Register(2)
    a.mute()
    mute(b)

    assert a.muteStatus and b.muteStatus == True
