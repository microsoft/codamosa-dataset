

# Generated at 2022-06-21 23:55:19.107057
# Unit test for function unmute
def test_unmute():
    import unittest
    import unittest.mock
    from .primitive import BitField
    reg = BitField(0, 'testreg', size=1)
    reg.unmute = unittest.mock.Mock()
    unmute(reg)
    reg.unmute.assert_called_once()


# Generated at 2022-06-21 23:55:29.655015
# Unit test for function unmute
def test_unmute():
    from .primitive import normal_uniform_psi_0
    from .primitive import normal_uniform_psi_0_dag
    from .primitive import pauli_matrix_gate

    x = pauli_matrix_gate(angle=3.1416, axis="x")
    y = pauli_matrix_gate(angle=3.1416, axis="y")
    z = pauli_matrix_gate(angle=3.1416, axis="z")
    h = normal_uniform_psi_0()
    h_dag = normal_uniform_psi_0_dag()
    err = ValueError(
        "The unmute() method can only be used with objects that inherit "
        "from the 'Register class'."
    )

    x.mute()


# Generated at 2022-06-21 23:55:41.773469
# Unit test for function unmute
def test_unmute():
    from .connector import Connector
    from .register import RegBit
    from .utils import NameMapping, Node

    class NodeA(Node):
        """First node class for testing purpose"""

        a = RegBit()

    class NodeB(Node):
        """Second node class for testing purpose"""

        b = RegBit()

    class Test(Connector):
        """Third node class for testing purpose"""

        a = NodeA()
        b = NodeB()

        def __init__(self):
            """Constructor for the testing class"""
            super().__init__()
            NameMapping(self)

    test = Test()

    assert (
        not test.a.a.mute
    ), "Mute was defined as false but was somehow set to True."

# Generated at 2022-06-21 23:55:43.452575
# Unit test for function mute
def test_mute():
    reg = Register()
    assert reg.mute()


# Generated at 2022-06-21 23:55:47.519633
# Unit test for function unmute
def test_unmute():
    if __name__ == '__main__':
        # Create a register with a mute state of True
        reg = Register(0x80, 0xFF, 'test_reg', mute=True)

        # Unmute it
        unmute(reg)

        # Assert
        assert reg.mute is False

# Generated at 2022-06-21 23:56:00.200208
# Unit test for function mute
def test_mute():
    from .primitive import Bit
    from .simple import Inverter
    from .parser import Parser

    a = Inverter(name="a", inp=Bit(name="inp", default=0))
    b = Inverter(name="b", inp=Bit(name="inp", default=0))
    c = Inverter(name="c", inp=Bit(name="inp", default=0))

    parser = Parser()

    mute(a,b,c)
    assert a.muted is True
    assert a.__repr__(parser) == "Muted( Inverter )"
    assert a.color == parser.color_muted
    assert c.muted is True
    assert c.color == parser.color_muted


# Generated at 2022-06-21 23:56:04.826872
# Unit test for function unmute
def test_unmute():
    a = Register('a')
    b = Register('b')
    a.mute()
    b.mute()
    unmute(a, b)
    assert not a.muted_out
    assert not b.muted_out



# Generated at 2022-06-21 23:56:09.586416
# Unit test for function unmute
def test_unmute():
    global mb
    if mb is not None:
        global status
        status = "Pass"
        print("Function unmute tested.")
        mb.close()
    else:
        status = "Fail"
        print("Unable to run test for function unmute.")


# Generated at 2022-06-21 23:56:10.729008
# Unit test for function mute
def test_mute():
    reg = Register(is_muted=False)
    mute(reg)
    assert reg.is_muted == True


# Generated at 2022-06-21 23:56:22.491138
# Unit test for function mute
def test_mute():
    """
    This is a unit-test to check that the mute-function works as
    it is intended. To run this test, use the following command:
        python3 -m pytest register/functions/test_mute.py
    """
    print(">>>>> Testing mute() function >>>>>")
    r = Register(name='test', pins=[10, 11, 12, 13], number_of_bits=4)
    print("Register created successfully.")
    print("Muting register...")
    mute(r)
    print("Mute status:", r.mute_status)
    if r.mute_status:
        print("Muting register succeeded.")
    else:
        print("Muting register failed.")
    print("<<<<< Testing mute() function <<<<<")

