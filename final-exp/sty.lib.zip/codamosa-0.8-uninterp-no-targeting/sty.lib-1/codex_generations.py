

# Generated at 2022-06-21 23:55:13.369337
# Unit test for function mute
def test_mute():
    import numpy as np
    from pymarc import MarcRegister

    register = MarcRegister(value=0b11011)
    mute(register)
    assert str(register) == "0"



# Generated at 2022-06-21 23:55:24.681081
# Unit test for function unmute
def test_unmute():
    """
    Test function unmute
    """
    r1 = Register(6)
    r2 = Register(4)
    r3 = Register(4)

    assert r1.is_muted() == False
    assert r2.is_muted() == False
    assert r3.is_muted() == False

    mute(r1, r2, r3)

    assert r1.is_muted() == True
    assert r2.is_muted() == True
    assert r3.is_muted() == True

    unmute(r1, r2, r3)

    assert r1.is_muted() == False
    assert r2.is_muted() == False
    assert r3.is_muted() == False



# Generated at 2022-06-21 23:55:30.017048
# Unit test for function unmute
def test_unmute():
    reg0 = Register(15)
    reg1 = Register(0)
    reg0.mute()
    reg1.mute()
    assert reg0.get_mute_state() == True
    assert reg1.get_mute_state() == True
    #
    unmute(reg0, reg1)
    #
    assert reg0.get_mute_state() == False
    assert reg1.get_mute_state() == False

# Generated at 2022-06-21 23:55:42.143934
# Unit test for function unmute
def test_unmute():
    from .subsystem import Subsystem
    from .primitive import Register
    from .subscriber import Subscriber

    class TestSubscriber(Subscriber):
        def log(self, message):
            print("TestSubscriber: " + str(message))

    class TestRegister(Register):
        def __init__(self, name=""):
            super().__init__(name)
            self.subscribers.append(TestSubscriber("subscriber"))

        def notify(self, message):
            super().notify(message)

    class TestSubsystem(Subsystem):
        def __init__(self, name=""):
            super().__init__(name)
            self.mute_all()

    # Initialize Tester-Classes
    register1 = TestRegister("unmute_register1")
    register

# Generated at 2022-06-21 23:55:43.188002
# Unit test for function unmute
def test_unmute():
    mute(unmute())

# Generated at 2022-06-21 23:55:44.218429
# Unit test for function mute
def test_mute():
    reg = Register(24)
    reg.mute()
    assert reg.__str__() == '*'


# Generated at 2022-06-21 23:55:51.106044
# Unit test for function unmute
def test_unmute():
    register = Register()
    register2 = Register()
    register3 = 'test'
    register4 = register2
    assert register.is_muted == False
    assert register2.is_muted == False
    mute(register, register2, register3, register4)
    assert register.is_muted == True
    assert register2.is_muted == True
    unmute(register, register2, register3, register4)
    assert register.is_muted == False
    assert register2.is_muted == False
    assert register2.is_muted != register.is_muted
    register.unmute()
    assert register.is_muted == False



# Generated at 2022-06-21 23:56:02.339069
# Unit test for function unmute
def test_unmute():
    from .primitive import register, dregister
    from .compound import concatenate

    r1 = register(bitwidth=2)
    r2 = register(bitwidth=4)
    d1 = dregister(bitwidth=3)

    c = concatenate(r1, r2, d1)

    # Testing before
    assert r1.mute is True
    assert r2.mute is True
    assert d1.mute is True
    assert c.mute is True
    assert c.overall_mute is True

    # Testing after
    unmute(r1, r2, d1, c)
    assert r1.mute is False
    assert r2.mute is False
    assert d1.mute is False
    assert c.mute is False
    assert c.overall_m

# Generated at 2022-06-21 23:56:08.633889
# Unit test for function mute
def test_mute():
    obj = Register(0)
    mute(obj)
    assert obj.muted == True, "Muting of one register did not work."
    mute(obj, obj)
    assert obj.muted == True, "Muting of two registers did not work."
    assert obj.muted == True, "Muting of three registers did not work."
    mute(obj, obj, obj)


# Generated at 2022-06-21 23:56:14.598708
# Unit test for function unmute
def test_unmute():
    import pytest
    from .primitive import Register

    r1 = Register()
    r2 = Register()
    r3 = Register()
    unmute(r1, r2)
    for r in [r1, r2]:
        assert r.muted is False
    with pytest.raises(ValueError):
        unmute(r1, r2, 'a')
    unmute(r1, r2, r3)
    for r in [r1, r2, r3]:
        assert r.muted is False

