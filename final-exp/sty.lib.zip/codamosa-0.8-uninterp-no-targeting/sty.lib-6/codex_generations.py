

# Generated at 2022-06-21 23:55:09.624792
# Unit test for function mute
def test_mute():
    v = Register(1)
    assert v.value == 1, "value should be 1"
    v.mute()
    v.value = 2
    assert v.value == 1, "value should be 1"



# Generated at 2022-06-21 23:55:14.670089
# Unit test for function mute
def test_mute():
    from .primitive import Bool, BoolArray
    r1 = Bool("r1")
    r2 = Bool("r2")
    r3 = Bool("r3")
    r4 = Bool("r4")
    mute(r1, r2, r3, r4)
    assert r1.muted
    assert r2.muted
    assert r3.muted
    assert r4.muted



# Generated at 2022-06-21 23:55:26.433510
# Unit test for function unmute
def test_unmute():
    from .digit import Digit
    from .gpio import GPIO, PinMode
    from .color import Color
    from .segment import Segment
    from .display import Display
    from .element import Segment7

    GPIO.setmode(GPIO.BOARD)

    a = Segment7(Digit.A, PinMode.BCM)
    b = Segment7(Digit.B, PinMode.BCM)
    c = Segment7(Digit.C, PinMode.BCM)
    d = Segment7(Digit.D, PinMode.BCM)
    e = Segment7(Digit.E, PinMode.BCM)
    f = Segment7(Digit.F, PinMode.BCM)
    g = Segment7(Digit.G, PinMode.BCM)
    d

# Generated at 2022-06-21 23:55:31.576346
# Unit test for function unmute
def test_unmute():
    i2c = I2C(0)
    stepup_tran = StepUpTranslator(i2c, True)
    smps = SMPS(i2c, stepup_tran, 0)
    smps.output.mute()
    assert smps.output.muted == True
    unmute(smps.output)
    assert smps.output.muted == False


# Generated at 2022-06-21 23:55:43.915862
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute.
    """
    from .basic import DigitalSignal

    def _test(sig: DigitalSignal, expected: bool) -> None:
        if sig.mute_state is not expected:
            raise NotImplementedError("Test failed.")

    # Create a Digital Signal object
    signal = DigitalSignal("DO")

    # Test that the mute method is working correctly
    signal.mute()
    _test(signal, True)
    signal.unmute()
    _test(signal, False)
    mute(signal)
    _test(signal, True)
    unmute(signal)
    _test(signal, False)

    # Test that the exception is raised correctly
    class TestClass:
        pass

    test_obj = TestClass()

    error = None

# Generated at 2022-06-21 23:55:49.398680
# Unit test for function unmute
def test_unmute():
    import mido
    input1 = mido.open_input("Enigma:Enigma MIDI 1 20:0")
    input2 = mido.open_input("Enigma:Enigma MIDI 1 20:1")
    output = mido.open_output("Enigma:Enigma MIDI 1 20:0")
    note = Register("C4",0,input1,output,True)
    note.mute()
    unmute(note)
    assert not note.muted
    

# Generated at 2022-06-21 23:55:57.530041
# Unit test for function mute
def test_mute():
    from .primitive import Register

    # Create a single register object and mute it
    reg = Register("test")
    reg.mute()

    # Create a second register object normally, then use 'mute' to mute
    # both of these objects
    reg2 = Register("test2")
    mute(reg, reg2)

    # Ensure that both objects have now been muted
    assert reg.is_muted()
    assert reg2.is_muted()



# Generated at 2022-06-21 23:56:04.592762
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import BinaryRegister
    from .primitive import DecimalRegister
    reg = Register(slice(8, 0))
    dreg = DecimalRegister(slice(8, 0))
    breg = BinaryRegister(slice(8, 0))

    reg.set(1)
    dreg.set(1)
    breg.set(1)

    assert reg.get() == 1
    assert dreg.get() == 1
    assert breg.get() == 1

    mute(reg, dreg, breg)

    reg.set(0)
    dreg.set(0)
    breg.set(0)

    assert reg.get() == 1
    assert dreg.get() == 1
    assert breg.get() == 1


# Generated at 2022-06-21 23:56:13.460978
# Unit test for function unmute
def test_unmute():
    from . import Register
    from . import peripheral

    class test_class:
        tval = 0
        dval = 0

        def tset(self, value):
            self.tval = value

        def tget(self):
            self.tget_called = self.tval
            return self.tval

        def dset(self, value):
            self.dval = value

        def dget(self):
            self.dget_called = self.dval
            return self.dval

    test = test_class()

    test_reg = Register(0x00,
                        access="rw",
                        description=("Description",
                                     "Description 2"),
                        bitwidth=32,
                        test=test.tset)


# Generated at 2022-06-21 23:56:24.071396
# Unit test for function mute
def test_mute():
    import unittest

    class TestMute(unittest.TestCase):
        def test_mute_input(self):
            self.input = Register()

            with self.assertRaises(Exception):
                mute(self.input, self.input)
            with self.assertRaises(ValueError):
                mute(self.input, self.input, self.input)
            with self.assertRaises(ValueError):
                mute(self.input, self.input, self.input)
            with self.assertRaises(ValueError):
                mute(self.input, self.input, self.input)
            with self.assertRaises(ValueError):
                mute(self.input, self.input, self.input)
            # This is the correct way to use the function
            mute(self.input)

    unittest