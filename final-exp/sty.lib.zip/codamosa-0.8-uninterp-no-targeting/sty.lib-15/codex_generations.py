

# Generated at 2022-06-21 23:55:14.042154
# Unit test for function mute
def test_mute():
    
    class testObj(Register):
        def __init__(self, size=0, r_or_w="r", format="bool"):
            self.size = size
            self.r_or_w = r_or_w
            self.format = format

        def read(self):
            return 0x0

        def write(self, data):
            pass

    obj_1 = testObj()
    obj_2 = testObj()

    mute(obj_1)
    mute(obj_2)

    assert obj_1.muted is True
    assert obj_2.muted is True



# Generated at 2022-06-21 23:55:25.769355
# Unit test for function unmute
def test_unmute():
    """
    Function to test the unmute() method.
    """
    from .primitive import Bit
    from .primitive import Byte
    from .primitive import Word

    # Test Bit-register with unmute()
    b = Bit()
    b.mute()
    if not b.muted:
        print("Error in unmute()")
    unmute(b)
    if b.muted:
        print("Error in unmute()")

    # Test Byte-register with unmute()
    bb = Byte()
    bb.mute()
    if not bb.muted:
        print("Error in unmute()")
    unmute(bb)
    if bb.muted:
        print("Error in unmute()")

    # Test Word-register with unmute()
    w = Word()
   

# Generated at 2022-06-21 23:55:36.482970
# Unit test for function mute
def test_mute():
    from .primitive import Signal, Simulator
    from .conversions import bus2int, int2bus
    sig1 = Signal(8)
    sig2 = Signal(8)
    reg1 = Register(8, init=0)
    reg2 = Register(8, init=0)
    sig1.drive(4)
    reg1.d.drive(4)
    sig1.connect(reg1)
    reg1.connect(reg2)
    reg2.connect(sig2)
    mute(reg1)
    sim = Simulator()
    sim.add(sig1, reg1, reg2, sig2)
    sim.run(20)
    assert sig1.read() == 4
    assert reg1.read() == 0
    assert reg2.read() == 0
    assert sig2.read() == 0


# Generated at 2022-06-21 23:55:47.808720
# Unit test for function unmute
def test_unmute():
    # test if function unmutes a list of objects
    register_list = [Register(), Register(), Register()]
    err = ValueError(
        "The unmute() method can only be used with objects that inherit "
        "from the 'Register class'."
    )
    for reg in register_list:
        reg.mute()
    unmute(*register_list)
    for reg in register_list:
        assert reg.pubsub.subscribers == {}

    # test if function throws  error if a list-element is not a register-object
    register_list = [Register(), str(), Register()]
    for reg in register_list:
        reg.mute()
    # test to throw error:

# Generated at 2022-06-21 23:55:49.682800
# Unit test for function unmute
def test_unmute():
    """Test unmute() method."""
    assert True

# Generated at 2022-06-21 23:55:55.768014
# Unit test for function mute
def test_mute():
    class TestRegister(Register):
        def __init__(self):
            self._mute = False

    obj = TestRegister()
    assert obj._mute == False
    mute(obj)
    assert obj._mute == True
    unmute(obj)
    assert obj._mute == False

# Generated at 2022-06-21 23:55:58.819629
# Unit test for function unmute
def test_unmute():
    reg_obj = Register(0,0)
    reg_obj.mute()
    assert reg_obj.q == 0

    unmute(reg_obj)
    assert reg_obj.q == 1

# Generated at 2022-06-21 23:56:04.286777
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .registers import reglist
    from .registers import r0

    reg = Register(16)
    reg.state = 0
    reg.mute()
    assert reg.muted == True
    unmute(reg)
    assert reg.muted == False

    reglist.mute(0b11111111)
    assert reglist.mutemask == 0b11111111
    unmute(reglist)
    assert reglist.mutemask == 0b00000000
    assert reglist.muted == False

    unmute(r0)
    assert r0.muted == False



# Generated at 2022-06-21 23:56:09.713427
# Unit test for function unmute
def test_unmute():
    import ucc.gui.register_gui as gui
    a, b = gui.create_registers(2, 0)
    unmute(a, b)
    if not a.is_unmuted:
        raise Exception("Unmute failed")
    if not b.is_unmuted:
        raise Exception("Unmute failed")

# Generated at 2022-06-21 23:56:13.231381
# Unit test for function unmute
def test_unmute():
    """Tests that unmute correctly unmutes the registers it is passed"""
    regs = [Register() for _ in range(3)]
    for r in regs:
        r.mute()
    mute(*regs)
    for r in regs:
        assert r.muted
    unmute(*regs)
    for r in regs:
        assert not r.muted
