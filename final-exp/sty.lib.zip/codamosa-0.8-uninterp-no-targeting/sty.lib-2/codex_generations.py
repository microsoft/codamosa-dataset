

# Generated at 2022-06-21 23:55:24.288433
# Unit test for function unmute
def test_unmute():
    from .primitive import Bit, Flag, FlagRegister
    from .primitive import Byte, ByteRegister
    from .primitive import Word, WordRegister

    class Device(Device):
        flag = Flag()
        flr = FlagRegister(8)
        byte = Byte()
        br = ByteRegister(8)
        word = Word(16)
        wr = WordRegister(8, 16)

    d = Device()
    mute(d.flr.flag[0], d.flr.flag[1], d.br.byte[3], d.br.byte[4],
         d.wr.word[0].byte[0], d.wr.word[1].byte[1])

    assert d.flr.flag[0].mute
    assert d.flr.flag[1].mute

# Generated at 2022-06-21 23:55:29.257244
# Unit test for function unmute
def test_unmute():

    class Test:
        pass

    t = Test()
    t.mute = True
    t2 = Test()
    t2.mute = True

    assert t.mute and t2.mute
    mute(t, t2)
    assert t.mute and t2.mute
    unmute(t, t2)
    assert not t.mute and not t2.mute

# Generated at 2022-06-21 23:55:30.194138
# Unit test for function unmute
def test_unmute():
    assert unmute(0) == None


# Generated at 2022-06-21 23:55:38.216270
# Unit test for function unmute
def test_unmute():
    from .primitive import Register

    reg1 = Register()
    reg2 = Register()
    reg3 = Register()

    reg1.mute()
    reg2.mute()

    assert reg1.mutated is True
    assert reg2.mutated is True
    assert reg3.mutated is False

    unmute(reg1, reg2, reg3)

    assert reg1.mutated is False
    assert reg2.mutated is False
    assert reg3.mutated is False

# Generated at 2022-06-21 23:55:42.941654
# Unit test for function mute
def test_mute():
    r1 = Register(0)
    r2 = Register(1)
    r3 = Register(2)
    r1.mute()
    mute(r2, r3)
    assert r1.is_muted()
    assert r2.is_muted()
    assert r3.is_muted()


# Generated at 2022-06-21 23:55:47.922855
# Unit test for function mute
def test_mute():
    a = Register("A")
    b = Register("B")
    c = Register("C")
    mute(a, b, c)
    assert a.value == "0" and a.muted is True
    assert b.value == "0" and b.muted is True
    assert c.value == "0" and c.muted is True
    return


# Generated at 2022-06-21 23:55:50.811750
# Unit test for function mute
def test_mute():
    global G
    reg = G.output_register(1)
    reg.mute()
    assert reg.is_muted == True


# Generated at 2022-06-21 23:55:56.647715
# Unit test for function unmute
def test_unmute():
    import ESSM.all_registers as reg
    # unmute every register except MPC_READ
    unmute(reg.MPC_READ)
    # check if unmuted register has been muted
    assert reg.MPC_READ.isset('mute')



# Generated at 2022-06-21 23:55:59.578427
# Unit test for function mute
def test_mute():
    dummy = Register(0x00)

    assert dummy.value == 0x00
    muted = mute(dummy)
    assert muted is None
    assert dummy.value == 0x00


# Generated at 2022-06-21 23:56:04.697742
# Unit test for function unmute
def test_unmute():
    """
    Unit-test for the function unmute().
    """
    reg = Register(RegisterSize.SIZE_8, flag=True)
    assert reg.is_muted()
    unmute(reg)
    assert not reg.is_muted()

