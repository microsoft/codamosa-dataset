

# Generated at 2022-06-21 23:55:14.377325
# Unit test for function mute
def test_mute():
    mute()



# Generated at 2022-06-21 23:55:26.152052
# Unit test for function unmute
def test_unmute():
    from .primitive import Primitive
    from .array import Array
    from .interface import Interface
    from .memory import Memory

    reg_1 = Primitive(name="reg_1", addr_width=4, data_width=8)
    reg_2 = Primitive(name="reg_2", addr_width=6, data_width=2)
    reg_3 = Primitive(name="reg_3", addr_width=8, data_width=3)
    reg_4 = Primitive(name="reg_4", addr_width=10, data_width=1)
    reg_5 = Primitive(name="reg_5", addr_width=12, data_width=11)
    reg_6 = Primitive(name="reg_6", addr_width=14, data_width=4)
    reg_7 = Primitive

# Generated at 2022-06-21 23:55:37.859740
# Unit test for function mute
def test_mute():
    """
    Test if function mute() works properly
    """
    import re
    import numpy as np
    import Test_primitive
    Test_primitive.fieldx.mute()
    assert re.search(r'', str(Test_primitive.fieldx)) is None
    Test_primitive.mute(Test_primitive.fieldx)
    assert re.search(r'', str(Test_primitive.fieldx)) is None
    with pytest.raises(ValueError) as err:
        Test_primitive.mute(np.array([1, 2]))
    assert 'Register' in str(err.value)
    with pytest.raises(ValueError) as err:
        Test_primitive.mute(2)
    assert 'Register' in str(err.value)

# Generated at 2022-06-21 23:55:40.182098
# Unit test for function unmute
def test_unmute():
   register = Register(7)
   assert register.unmute() == [1, 1, 1, 1, 1, 1, 1]


# Generated at 2022-06-21 23:55:42.845615
# Unit test for function unmute
def test_unmute():
    r = Register(name = "r")
    r.mute()
    r.unmute()
    assert r.is_enabled() is True


# Generated at 2022-06-21 23:55:51.301669
# Unit test for function mute
def test_mute():
    import copy
    from .primitive import Register
    from ...utils.state import State

    state = State()
    register = Register(name='my_register', width=4, state=state)
    register.next = copy.copy(register.value)

    state.assign_value('state_0', [0,0,0,0,0])
    state.assign_value('state_1', [1,1,0,0,0])
    state.assign_value('next_0', [0,0,0,0,0])
    state.assign_value('next_1', [1,0,0,0,0])

    mute(register)

    #print(state.table)


# Generated at 2022-06-21 23:56:00.241279
# Unit test for function mute
def test_mute():
    """
    Function that executes the unit test for the 'mute' function.
    """
    reg = Register(name="Test Register 1", width=8)
    reg.mute()
    try:
        reg.write(0b00010001)
    except WriteError:
        pass
    else:
        raise ValueError("Test failed")

    mute(reg)
    try:
        reg.write(0b00010001)
    except WriteError:
        pass
    else:
        raise ValueError("Test failed")


# Generated at 2022-06-21 23:56:03.005991
# Unit test for function mute
def test_mute():
    mute(Register(0xFFFF, 0xF000), Register(0xAA00, 0xA000))

# Generated at 2022-06-21 23:56:07.908771
# Unit test for function unmute
def test_unmute():
    """
    Test if a Register-object can be muted.
    """
    r = Register(0, 0)
    assert r.is_muted() == False

    unmute(r)
    assert r.is_muted() == True



# Generated at 2022-06-21 23:56:10.121198
# Unit test for function mute
def test_mute():
    # Create register object and mute it
    my_register = Register(name='my_register', length=8, value=0x0,
                           comment='Register for testing')
    assert my_register.mute_me is False
    mute(my_register)
    assert my_register.mute_me is True

