

# Generated at 2022-06-21 23:55:16.698027
# Unit test for function mute
def test_mute():
    from .register import Register as reg
    from .memory import Memory as Mem
    from .mux import Mux as mux

    reg1 = reg()
    reg2 = reg()
    reg3 = reg()

    reg1.connect_bus(Mem(Mem.Size.BIT_8))
    reg2.connect_bus(Mem(Mem.Size.BIT_8))
    reg3.connect_bus(Mem(Mem.Size.BIT_8))

    mux1 = mux()
    mux1.connect(reg1)
    mux1.connect(reg2)
    mux1.connect(mem)

    def test_(reg_a, reg_b):
        reg_a.write(1)
        reg_a.unmute()
        reg_b.unmute()
        assert reg_b.read

# Generated at 2022-06-21 23:55:22.694006
# Unit test for function unmute
def test_unmute():
    print("Testing function unmute")
    bits = [1, 0, 1, 0, 1, 0, 1, 0]
    name = "test_name"
    reg = Register(bits, name)
    assert reg.mute() == reg.muted, "Error in mute() method"

# Generated at 2022-06-21 23:55:24.765688
# Unit test for function mute
def test_mute():
    obj = Register(0x00, 1)
    obj.mute()
    assert obj._muted == True


# Generated at 2022-06-21 23:55:35.330903
# Unit test for function mute
def test_mute():
    from .primitive import ByteRegister
    from .primitive import WordRegister
    from .primitive import LongRegister
    from .primitive import FloatRegister
    from .primitive import DoubleRegister

    # Test ByteRegister
    reg1 = ByteRegister(0x00, "byte_register1")
    reg2 = ByteRegister(0x01, "byte_register2")
    reg3 = ByteRegister(0x02, "byte_register3")
    reg4 = ByteRegister(0x03, "byte_register4")
    mute(reg1, reg2, reg3, reg4)
    assert reg1.muted == True
    assert reg2.muted == True
    assert reg3.muted == True
    assert reg4.muted == True

    # Test WordRegister

# Generated at 2022-06-21 23:55:41.771821
# Unit test for function mute
def test_mute():
    """
    Function to test the mute() and unmute() methods.
    """
    temp = ADC(0, 0, "/sys/bus/iio/devices/iio:device0", "mute")
    mute(temp)
    assert temp.is_muted()
    unmute(temp)
    assert not temp.is_muted()


if __name__ == "__main__":
    test_mute()

# Generated at 2022-06-21 23:55:48.299525
# Unit test for function mute
def test_mute():
    """
    Function mute is not callable, so we'll have to create a class for it to be
    able to test the functionality.
    """
    from .primitive import Register
    from .utils import add_debug_methods
    class Foo(Register):
        _bits = 16
    add_debug_methods(Foo)
    a = Foo()
    mute(a)
    assert a.muted
    a.debug_force_readable()
    assert not a.muted



# Generated at 2022-06-21 23:55:55.611341
# Unit test for function mute
def test_mute():
    import warnings
    warnings.filterwarnings("ignore")
    try:
        mute()
    except:
        pass
    else:
        print(
            "\033[93m"
            + "Unit-test 'test_mute()' in module 'mlogger.utility.tools'"
            + "\033[0m"
        )


# Generated at 2022-06-21 23:55:59.407911
# Unit test for function unmute
def test_unmute():
    # Create a register
    reg = Register("r1", value=0)
    # mute the register
    mute(reg)
    assert reg.muted == True
    # unmute the register
    unmute(reg)
    assert reg.muted == False


# Generated at 2022-06-21 23:56:11.449885
# Unit test for function mute
def test_mute():
    """Check the proper functioning of the mute() function"""
    def print_unmute_err(obj):
        print(
            "Mute failed for register object: " + obj.name
            + "\n"
            + "   Old value: " + str(obj.value)
            + "\n"
            + "   New value: " + str(obj.value)
        )

    name = "Test"
    address = 0x00
    register = Register(name, address)
    assert register.is_muted() == False, "Register is muted at creation."

    mute(register)
    assert register.is_muted() == True, "Register is not muted."

    register.value = 0xF0
    assert register.value == None, "Value is not muted."

    unmute(register)
    assert register.is_

# Generated at 2022-06-21 23:56:15.091515
# Unit test for function unmute
def test_unmute():
    assert(unmute.__name__ == "unmute")
    obj = Register()
    assert(obj.mute() == True)
    assert(obj.unmute() == True)