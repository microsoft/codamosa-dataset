

# Generated at 2022-06-21 23:55:27.229815
# Unit test for function mute
def test_mute():
    from .primitive import Statusregister

    class Testregister(Statusregister, bits=4, silent=True):
        def __init__(self):
            super().__init__(
                mute = self.mute,
                unmute = self.unmute,
            )
            self.muted = True
            self.mute()

        def mute(self):
            self.muted = True

        def unmute(self):
            self.muted = False

    reg2 = Testregister()
    mutereg = Testregister()
    unmutereg = Testregister()

    # Test mute function with one register only
    mute(reg2)
    assert reg2.muted == True

    # Test mute function with multiple registers
    mute(mutereg, unmutereg)
    assert mutereg.muted == True


# Generated at 2022-06-21 23:55:28.881410
# Unit test for function mute
def test_mute():
    r = Register(0, 0)
    mute(r)
    assert r.muted



# Generated at 2022-06-21 23:55:34.683308
# Unit test for function unmute
def test_unmute():
    from .example_setups import Test

    # Create register objects
    x = Test()

    # Check that mute does what it is expected to do
    assert x.mute_state == False
    mute(x)
    assert x.mute_state == True

    # Check that unmute does what it is expected to do
    unmute(x)
    assert x.mute_state == False

# Generated at 2022-06-21 23:55:40.810176
# Unit test for function mute
def test_mute():
    from . import init
    from . import set
    from . import select

    obj = set("Test object for muting")
    init(obj)
    select(obj)
    mute(obj)
    assert obj.is_muted()
    unmute(obj)
    assert not obj.is_muted()


if __name__ == "__main__":
    test_mute()

# Generated at 2022-06-21 23:55:49.296691
# Unit test for function unmute
def test_unmute():
    reg1 = Register(8, 'reg1', 'reg1', 0x06, addr = 0x00)
    reg2 = Register(8, 'reg2', 'reg2', 0x06, addr = 0x01)
    reg3 = Register(8, 'reg3', 'reg3', 0x06, addr = 0x02)
    test_list = [reg1, reg2, reg3]
    mute(reg1, reg2)
    assert reg1.muted == True and reg2.muted == True and reg3.muted == False
    unmute(reg1, reg2)
    assert reg1.muted == False and reg2.muted == False and reg3.muted == False

# Generated at 2022-06-21 23:56:01.036099
# Unit test for function unmute
def test_unmute():
    from .primitive import UIntRegister

    def test_mutable(obj):
        assert not obj.is_muted
        assert obj.val == 1

    def test_immutable(obj):
        with pytest.raises(ValueError):
            obj.val = 2

    # Single object
    obj = UIntRegister(5, formatter='{:02d}', mute=True, val=1)
    test_immutable(obj)

    unmute(obj)
    test_mutable(obj)

    # Iterable
    obj2 = UIntRegister(5, formatter='{:02d}', mute=True, val=1)
    test_immutable(obj2)

    unmute(obj, obj2)
    test_mutable(obj)
    test_mutable(obj2)


# Unit

# Generated at 2022-06-21 23:56:10.436499
# Unit test for function mute
def test_mute():
    def callback(register):
        print("State of register '" + register.name + "' was changed")

    r1 = Register("r1", 4, callback)
    r2 = Register("r2", 4, callback)

    print("Before:")
    print("\tr1 = " + str(r1))
    print("\tr2 = " + str(r2))
    print()

    mute(r1, r2)

    r1.set_value(7)
    r2.set_value(12)

    print("After:")
    print("\tr1 = " + str(r1))
    print("\tr2 = " + str(r2))

# Generated at 2022-06-21 23:56:14.615048
# Unit test for function unmute
def test_unmute():
    regs = [
        Register(0, 10), 
        Register(1, 10),
        Register(2, 10)
    ]
    for reg in regs:
        reg.mute()
    assert regs[0].mute_state == True
    assert regs[1].mute_state == True
    assert regs[2].mute_state == True
    unmute(regs[0], regs[1], regs[2])
    assert regs[0].mute_state == False
    assert regs[1].mute_state == False
    assert regs[2].mute_state == False


# Generated at 2022-06-21 23:56:22.123559
# Unit test for function mute
def test_mute():
    from .primitive import Counter

    register_1 = Counter()
    register_2 = Register()
    register_3 = Counter(muted=True)

    assert register_1.muted == False
    assert register_2.muted == False
    assert register_3.muted == True

    mute(register_1, register_2, register_3)

    assert register_1.muted == True
    assert register_2.muted == True
    assert register_3.muted == True


# Generated at 2022-06-21 23:56:24.398729
# Unit test for function unmute
def test_unmute():
    # Create some dummy registers
    r1 = Register(4,1,1)
    r2 = Register(4,2,2)
    r1.val = 3
    r2.val = 3
    # Test that unmute changes the mute attribute
    unmute(r1, r2)
    assert r1.mute == False
    assert r2.mute == False
    # Test that unmute doesn't change the value of the registers
    assert r1.val == 3
    assert r2.val == 3
