

# Generated at 2022-06-21 23:55:19.647774
# Unit test for function unmute
def test_unmute():
    from .primitive import Bit

    bit_a = Bit()
    bit_b = Bit()
    unmute(bit_a, bit_b)

    assert bit_a.muted == False, "Failed to unmute bit"
    assert bit_b.muted == False, "Failed to unmute bit"



# Generated at 2022-06-21 23:55:29.742099
# Unit test for function unmute
def test_unmute():
    print('========== Test for function unmute ==========')
    from bitstring import ConstBitStream, BitArray
    from .primitive import Register

    reg_1 = Register(width=16)
    reg_2 = Register(width=8)
    reg_3 = Register(width=3)

    mute(reg_1, reg_2, reg_3)
    unmute(reg_1, reg_2, reg_3)

    result_1 = reg_1.is_muted()
    result_2 = reg_2.is_muted()
    result_3 = reg_3.is_muted()
    assert all([result_1, result_2, result_3]) == False

    print('Test passed!')
    print('========== End of test ==========\n')

# Generated at 2022-06-21 23:55:33.988512
# Unit test for function mute
def test_mute():
    register_a = Register(0)
    register_b = Register(0)
    mute(register_a, register_b)
    assert(register_a.muted)
    assert(register_b.muted)



# Generated at 2022-06-21 23:55:36.221927
# Unit test for function unmute
def test_unmute():
    reg_obj = Register(0.0, 1)
    unmute(reg_obj)
    assert reg_obj.muted == False

# Generated at 2022-06-21 23:55:42.377865
# Unit test for function mute
def test_mute():
    """
    Tests if the mute function returns a value.
    """
    from .primitive import Register
    from .primitive import decode_register
    for _ in range(10):
        number = random.randint(0, 2 ** 5 - 1)
        register = Register(number, mute=True)
        mute(register)
    assert decode_register(register) == number



# Generated at 2022-06-21 23:55:44.707268
# Unit test for function unmute
def test_unmute():
    assert unmute(4, 5, "string")
    assert unmute()
    assert unmute(4)



# Generated at 2022-06-21 23:55:45.720757
# Unit test for function mute
def test_mute():
    pass


# Generated at 2022-06-21 23:55:50.328543
# Unit test for function unmute
def test_unmute():
    from .utils import DataBitsMock
    from . import MemoryTypes

    register = Register(
        name="Register",
        address_width=1,
        data_width=32,
        memory_type=MemoryTypes.RAM,
        data_bits=DataBitsMock()
    )

    register.mute()
    assert register._muted == True
    unmute(register)
    assert register._muted == False



# Generated at 2022-06-21 23:56:01.797035
# Unit test for function mute
def test_mute():
    """
    Unit-test function for function mute
    """
    reg1 = Register('Register 1', 8)
    reg2 = Register('Register 2', 8)
    reg3 = Register('Register 3', 8)
    reg4 = Register('Register 4', 8)

    reg1.set_value(0xA5)
    reg2.set_value(0xA5)
    reg3.set_value(0xA5)
    reg4.set_value(0xA5)

    mute(reg1, reg2, reg3, reg4)
    assert reg1.is_muted() == True, "Mute failed for reg1"
    assert reg2.is_muted() == True, "Mute failed for reg2"

# Generated at 2022-06-21 23:56:11.875421
# Unit test for function mute
def test_mute():
    class TestRegister(Register):
        def __init__(self, *, initial_value=0):
            super().__init__(
                bit_width=16, initial_value=initial_value
            )

    test_data = [0x0000, 0xF000, 0x0FF0, 0xF00F, 0xA555]
    for i in range(len(test_data)):
        reg = TestRegister(initial_value=test_data[i])
        mute(reg)
        reg.store(test_data[i])
        if test_data[i+1] == test_data[i]:
            print("Error: Wrong value stored in register after mute()")
        mute(reg)
        reg.store(test_data[i+1])