

# Generated at 2022-06-21 23:55:19.394890
# Unit test for function mute
def test_mute():
    rst = Register(name="test_register", width=8)
    assert not rst.muted
    mute(rst)
    assert rst.muted



# Generated at 2022-06-21 23:55:21.328850
# Unit test for function mute
def test_mute():
    a = Register(8)
    mute(a)

    # Unit test for function unmute

# Generated at 2022-06-21 23:55:22.643540
# Unit test for function unmute
def test_unmute():
    pass

# Generated at 2022-06-21 23:55:29.509484
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .register_file import RegisterFile
    from .tristate_buffer import TristateBuffer

    rf = RegisterFile(1, 1)
    rf.write(0, 1, True)
    r1 = Register(3, 4)
    r2 = Register(0, 0)
    tsb = TristateBuffer(rf.read(0, 1), 1, 1)
    rf.write(0, 0, True)

    mute(r1, r2, tsb)
    assert r1.muted and r2.muted and tsb.muted
    unmute(r1, r2, tsb)
    assert not r1.muted and not r2.muted and not tsb.muted



# Generated at 2022-06-21 23:55:39.528540
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .primitive import MemRegister
    from .primitive import AluRegister
    from .primitive import Input
    from .primitive import Output
    from .primitive import Ybus
    from .primitive import CSR
    import inspect

    test = [(mem, 8), (alu, 8), (Input, 8), (Output, 8), (Ybus, 8)]
    for obj, size in test:
        try:
            reg = obj(size)
        except TypeError:
            reg = obj()
        unmute(reg)
        assert reg.check_mute() == 0, reg.name
    return



# Generated at 2022-06-21 23:55:42.143790
# Unit test for function mute
def test_mute():
    from .primitive import ByteRegister

    reg = ByteRegister(0x00, name="ExampleRegister")
    mute(reg)
    assert reg.muted_p


# Generated at 2022-06-21 23:55:44.520239
# Unit test for function unmute
def test_unmute():
    a = Register(name='a', value=False)
    unmute(a)
    assert a.value == True


# Generated at 2022-06-21 23:55:50.806765
# Unit test for function mute
def test_mute():
    # Test simple object
    dut = Register('dut')
    mute(dut)
    assert dut.is_muted == True
    # Test complex object
    reg_a = Register('REG_A')
    reg_b = Register('REG_B')
    reg_c = Register('REG_C')

    reg_a <= reg_b
    reg_b <= reg_c

    mute(reg_a)
    assert reg_a.is_muted == True
    assert reg_b.is_muted == True
    assert reg_c.is_muted == True


# Generated at 2022-06-21 23:55:57.080569
# Unit test for function mute
def test_mute():
    a = Reg8(12)
    assert a == 12
    mute(a)
    a += 2
    assert a == 14
    unmute(a)
    a += 2
    assert a == 0
    mute(a)
    a += 2
    assert a == 2


# Generated at 2022-06-21 23:56:00.285275
# Unit test for function unmute
def test_unmute():
    """
    Unit test for function unmute.
    """
    from .byte import Byte
    from .word import Word

    assert unmute(0) == None
    assert unmute(Byte) == None
    assert unmute(Word) == None

