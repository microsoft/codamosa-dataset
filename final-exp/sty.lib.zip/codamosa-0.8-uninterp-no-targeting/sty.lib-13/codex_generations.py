

# Generated at 2022-06-21 23:55:19.395197
# Unit test for function mute
def test_mute():
    from .primitive import BitRegister
    reg = BitRegister(0x0001)
    mute(reg)
    assert(reg.muted)


# Generated at 2022-06-21 23:55:27.302669
# Unit test for function unmute
def test_unmute():
    """
    Test whether the function unmute() actually unmutes passed register-objects.
    """
    from ._helper import TestRegister
    r1 = TestRegister()
    r2 = TestRegister()
    r3 = TestRegister()
    mute(r1, r2, r3)
    assert r1.muted
    assert r2.muted
    assert r3.muted
    unmute(r1, r2, r3)
    assert not r1.muted
    assert not r2.muted
    assert not r3.muted



# Generated at 2022-06-21 23:55:36.486516
# Unit test for function mute
def test_mute():
    import numpy as np

    # Create a 4-bit register
    reg = Register(4, is_signed=True, is_resizable=True, is_mutable=True)
    # Make it full of ones
    reg.reg[:] = np.ones(4)

    assert reg.signed_value == -1  # assert that it is -1 (all 1s)
    mute(reg)  # mute the register
    assert reg.signed_value == 1  # assert that it is 1 (all 0s)
    unmute(reg)  # unmute it
    assert reg.signed_value == -1  # assert that it is -1 again

# Run the test
test_mute()

# Generated at 2022-06-21 23:55:40.955951
# Unit test for function mute
def test_mute():
    reg = Register("reg", "A test register", 0x100, 8)
    reg.mute()
    assert reg.mute_status == True
    mute(reg)
    assert reg.mute_status == True



# Generated at 2022-06-21 23:55:42.797673
# Unit test for function mute
def test_mute():
    reg = Register()
    mute(reg)
    assert reg.is_muted()



# Generated at 2022-06-21 23:55:45.921689
# Unit test for function unmute
def test_unmute():
    """
    Unit test for function unmute.
    """

    mute_obj = Register(5, mute=True)
    unmute(mute_obj)
    assert not mute_obj.is_muted

# Generated at 2022-06-21 23:55:47.962337
# Unit test for function unmute
def test_unmute():
    ra = Register(0, 10)
    rb = Register(0, 10)
    rc = Register(0, 10)
    mut

# Generated at 2022-06-21 23:55:59.186294
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute.
    """
    from .primitive import Const
    const1 = Const(0, bit=10)
    const2 = Const(0, bit=10)
    mute(const1, const2)
    assert const1.mute_clk == 0
    assert const2.mute_clk == 0
    assert const1.bit == 10
    assert const2.bit == 10
    unmute(const1, const2)
    assert const1.mute_clk == -1
    assert const2.mute_clk == -1
    assert const1.bit == 10
    assert const2.bit == 10



# Generated at 2022-06-21 23:56:11.199792
# Unit test for function mute
def test_mute():
    """ Unit test for function mute. """
    import numbapro
    from .primitive import Register

    print('Unit test for function mute - start')

    # Create two (mutable) registers
    a = Register()
    b = Register()

    # Same as before, but this time use the mute() function to mute both
    # register-objects at once
    mute(a, b)

    # The following line will result in type error, because we cannot
    # assign a value to a previously muted object
    with numbapro.jit():
        c = a * b * 2.0

    # Unmute a and b again
    unmute(a, b)

    # The following line will finish without any error.
    with numbapro.jit():
        c = a * b * 2.0

    # Clean up
    del a
   

# Generated at 2022-06-21 23:56:22.901406
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .build_components import Driver
    from . import monitors

    reg_a = Register("reg_a")
    reg_b = Register("reg_b")
    reg_c = Register("reg_c")
    reg_d = Register("reg_d")
    reg_e = Register("reg_e")
    reg_f = Register("reg_f")

    driver = Driver("driver")
    driver.write_dependency.add(reg_a)
    driver.write_dependency.add(reg_b)
    driver.write_dependency.add(reg_c)
    driver.write_dependency.add(reg_d)
    driver.write_dependency.add(reg_e)
    driver.write_dependency.add(reg_f)

    # mute all registers