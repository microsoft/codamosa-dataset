

# Generated at 2022-06-21 23:55:27.553633
# Unit test for function mute
def test_mute():
    """
    Test that the mute() function works.
    """
    import pytest
    from .registers import Register
    from .registers import RegisterByte

    r = Register(6)
    r[0] = True
    r[3] = True

    assert r.get() == 0b010100
    assert r.get(mute=False) == 0b010100

    mute(r)

    assert r.get() == 0b000000
    assert r.get(mute=False) == 0b010100

    unmute(r)

    assert r.get() == 0b010100
    assert r.get(mute=False) == 0b010100

    r.mute()

    assert r.get() == 0b000000
    assert r.get(mute=False) == 0b010100


# Generated at 2022-06-21 23:55:39.390831
# Unit test for function unmute
def test_unmute():
    from .primitive import DReg, DFF, TFF
    clk, d, q1, q2, q3 = "clk", "d", "q1", "q2", "q3"
    dff1 = DFF(clk, d, q1)
    dff2 = DFF(clk, d, q2)
    tff = TFF(d, q3)
    dreg = DReg(clk, q1, q3)
    dff1.mute()
    dff2.mute()
    tff.mute()
    dreg.mute()

# Generated at 2022-06-21 23:55:47.766346
# Unit test for function unmute
def test_unmute():
    from .primitive import GPR,CR,FPR
    r = GPR(0)
    r.mute()
    assert r.is_muted == True
    unmute(r)
    assert r.is_muted == False

    r = CR(0)
    r.mute()
    assert r.is_muted == True
    unmute(r)
    assert r.is_muted == False

    r = FPR(0)
    r.mute()
    assert r.is_muted == True
    unmute(r)
    assert r.is_muted == False



# Generated at 2022-06-21 23:55:56.345914
# Unit test for function mute
def test_mute():
    # Create registers
    m = Register()
    n = Register()
    # Create variables to check
    a = m.is_muted
    b = n.is_muted
    assert a is False
    assert b is False
    mute(m, n)
    # Create variables to test
    c = m.is_muted
    d = n.is_muted
    assert c is True
    assert d is True


# Generated at 2022-06-21 23:55:58.961053
# Unit test for function mute
def test_mute():
    mute(R1, R2)
    assert R1.current_mute == "MUTE"
    assert R2.current_mute == "MUTE"



# Generated at 2022-06-21 23:56:02.690469
# Unit test for function mute
def test_mute():
    """
    Unit test of the mute/unmute functions
    """
    class TestObject(Register):
        @staticmethod
        def _test():
            pass

    test_obj = TestObject()
    mute(test_obj)
    assert test_obj._muted is True
    unmute(test_obj)
    assert test_obj._muted is False

# Generated at 2022-06-21 23:56:08.633583
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute().
    """
    test_data = {
        'type': 'float',
        'field': 'voltage',
        'description': 'Voltage',
        'unit': 'V'
    }
    test_register = Register(test_data)
    mute(test_register)
    assert test_register.enabled == False


# Generated at 2022-06-21 23:56:10.475543
# Unit test for function mute
def test_mute():
    a = Register()
    b = Register()
    mute(a, b)
    assert a.muted
    assert b.muted


# Generated at 2022-06-21 23:56:22.408239
# Unit test for function mute
def test_mute():
    import random
    import subprocess
    import time

    # Call project file to create random register-object
    register, register_name = subprocess.getstatusoutput("./test.sh")
    register = eval(register)

    # Set initial value to the register
    initial_value = random.randint(0, 30)
    register.set(initial_value)
    print("Initial value: %s\n" % initial_value)

    # Set new value to the register
    new_value = random.randint(31, 50)
    register.set(new_value)
    print("New value: %s\n" % new_value)

    # Mute the register-object
    mute(register)

    # Check if the register is muted
    assert register.is_muted()

    # Set a third value to the register

# Generated at 2022-06-21 23:56:24.545089
# Unit test for function mute
def test_mute():
    test_reg = Register(name="test", size=1, bit=0)
    test_reg.mute()
    assert test_reg.muted == True
