

# Generated at 2022-06-21 23:55:24.211817
# Unit test for function unmute
def test_unmute():
    r1 = Register(4, init_value=[0,0,0,0], cell_type = 'latch')
    r2 = Register(4, init_value=[1,1,1,1], cell_type = 'latch')
    r3 = Register(4, init_value=[0,0,0,0], cell_type = 'latch')
    r1.mute()
    r2.mute()
    r3.mute()
    r1.set_next(r1+1)
    r2.set_next(r2+1)
    r3.set_next(r3+1)
    r1.clock(1)
    r2.clock(1)
    r3.clock(1)
    assert(str(r1) == "[0, 0, 0, 0]")

# Generated at 2022-06-21 23:55:29.522925
# Unit test for function unmute
def test_unmute():
    reg1 = Register(name="out1", width=4)
    reg2 = Register(name="out2", width=4)

    mute(reg1, reg2)
    assert reg1.mute_n == 1
    assert reg2.mute_n == 1
    unmute(reg1, reg2)
    assert reg1.mute_n == 0
    assert reg2.mute_n == 0



# Generated at 2022-06-21 23:55:37.965604
# Unit test for function mute
def test_mute():
    # Test multiple objects
    from .custom import Register16
    r1 = Register16()
    r2 = Register16()
    r3 = Register16()
    r4 = Register16()
    mute(r1, r2, r3, r4)
    assert(r1.is_muted() and r2.is_muted()
            and r3.is_muted() and r4.is_muted())
    unmute(r1, r2, r3, r4)


# Generated at 2022-06-21 23:55:46.019134
# Unit test for function unmute
def test_unmute():
    # Check for TypeError
    with pytest.raises(ValueError):
        unmute(1)

    # Create dummies
    reg1 = Register()
    reg2 = Register()

    # Create a thread that calls
    # the unmute function
    thread = Thread(target=unmute, args=(reg1, reg2))
    thread.daemon = True
    thread.start()

    # Check to see if the unmute
    # function worked
    thread.join()
    assert reg1.is_unmuted() == True
    assert reg2.is_unmuted() == True



# Generated at 2022-06-21 23:55:51.429735
# Unit test for function mute
def test_mute():
    from .mock_objects import MockRegister
    reg1 = MockRegister(name='test1', address=1)
    reg2 = MockRegister(name='test2', address=2)
    reg3 = MockRegister(name='test3', address=3)
    mute(reg1, reg2, reg3)
    assert reg1._mute is True
    assert reg2._mute is True
    assert reg3._mute is True
    for i in [reg1, reg2, reg3]:
        assert i.meta_attrs['mute'] is True


# Generated at 2022-06-21 23:55:56.978092
# Unit test for function unmute
def test_unmute():
    from zero.primitive import IntegerRegister

    x = IntegerRegister(16, name="x", init=1)

    mute(x)
    assert x.muted == True

    unmute(x)
    assert x.muted == False

# Generated at 2022-06-21 23:56:02.457054
# Unit test for function mute
def test_mute():
    class Test(Register):
        """
        If a test fails, the object will not be instantiated and the mute()
        function will not be called.
        """
        def __init__(self):
            super().__init__(3)
            self._state = True
            self._value = 0
            self._mute_count = 0

        def mute(self):
            self._mute_count += 1

    mute(Test())
    assert Test._mute_count == 1



# Generated at 2022-06-21 23:56:05.499052
# Unit test for function mute
def test_mute():
    # Testing the mute() method
    class TestClass(Register):
        name = "test"

    test_obj = TestClass()
    test_obj.mute()
    mute(test_obj)
    assert test_obj.muted == True



# Generated at 2022-06-21 23:56:11.658263
# Unit test for function mute
def test_mute():
    mock_object = Register()
    assert not mock_object.muted
    mute(mock_object)
    assert mock_object.muted
    unmute(mock_object)
    assert not mock_object.muted
    try:
        mute(1)
    except ValueError:
        pass

if __name__ == "__main__":
    # Run only unit test
    test_mute()

# Generated at 2022-06-21 23:56:18.643212
# Unit test for function unmute
def test_unmute():
    # create 2 registers
    reg1 = Register(4)
    reg2 = Register(8)
    # mute them
    reg1.mute()
    reg2.mute()
    # unmute them
    unmute(reg1, reg2)
    # check if unmute worked
    assert reg1.muted is False
    assert reg2.muted is False