

# Generated at 2022-06-21 23:55:23.126392
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute().
    """
    from .primitive import BitField
    from .primitive import BitFieldRegister

    class RegClass(BitFieldRegister):
        def __init__(self, name: str, address: int, bit_field: BitField):
            super().__init__(name, address, bit_field)


    reg = RegClass("foo", 0x1234, BitField(0, 0, 1))
    mute(reg)


# Generated at 2022-06-21 23:55:24.424710
# Unit test for function mute
def test_mute():
    raise NotImplementedError("To be implemented")



# Generated at 2022-06-21 23:55:29.011236
# Unit test for function unmute
def test_unmute():
    # Create register object
    a = Register(1, 0)
    # Register should be unmuted
    assert a.is_muted is False
    # Mute the register
    a.mute()
    assert a.is_muted is True
    # Unmute the register
    a.unmute()
    assert a.is_muted is False


# Generated at 2022-06-21 23:55:39.390357
# Unit test for function mute
def test_mute():
    obj1 = Register(name="obj1", bits=8)
    obj2 = Register(name="obj2", bits=8)
    obj3 = Register(name="obj3", bits=8)
    obj4 = Register(name="obj4", bits=8)
    obj5 = Register(name="obj5", bits=8)

    mute(obj1, obj2, obj3, obj4, obj5)
    assert obj1.muted == True and \
           obj2.muted == True and \
           obj3.muted == True and \
           obj4.muted == True and \
           obj5.muted == True


# Unit tests for function unmute

# Generated at 2022-06-21 23:55:40.522519
# Unit test for function mute
def test_mute():
    assert mute(Register()) is None


# Generated at 2022-06-21 23:55:46.067619
# Unit test for function mute
def test_mute():
    r1 = Register(1)
    r2 = Register(2)
    mute(r1, r2)
    assert r1.state == 0
    assert r2.state == 0

    r3 = Register(3)
    r4 = Register(4)
    unmute(r3, r4)
    assert r3.state == 1
    assert r4.state == 1



# Generated at 2022-06-21 23:55:51.246103
# Unit test for function unmute
def test_unmute():
    from .primitive import Register

    r1 = Register('r1')
    r2 = Register('r2')
    r3 = Register('r3')
    r1.mute()
    r3.mute()
    assert r1.muted
    assert r2.muted == False
    assert r3.muted
    unmute(r1, r2, r3)
    assert r1.muted == False
    assert r2.muted == False
    assert r3.muted == False


# Generated at 2022-06-21 23:55:59.096662
# Unit test for function mute
def test_mute():
    # Create a simple _Bit object.
    class _Register(Register):
        def __init__(self):
            self._reg = 0x00
            self._mute = True

    # Create a register object.
    reg = _Register()

    # Mute the two objects.
    mute(reg)
    mute(reg)

    # Check the mute status is unmute.
    assert reg.is_muted() is True



# Generated at 2022-06-21 23:56:02.804797
# Unit test for function mute
def test_mute():
    class testRegister(Register):
        def __init__(self):
            super().__init__()

        @property
        def muted(self):
            return self.__muted

    test1 = testRegister()
    test2 = testRegister()
    mute(test1, test2)
    assert test1.muted and test2.muted



# Generated at 2022-06-21 23:56:05.164073
# Unit test for function mute
def test_mute():
    a = Register(1)
    b = Register(2)
    mute(a, b)
    assert a.mute == True
    assert b.mute == True
