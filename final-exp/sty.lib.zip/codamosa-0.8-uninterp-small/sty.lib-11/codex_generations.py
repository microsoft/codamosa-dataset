

# Generated at 2022-06-26 04:19:27.730528
# Unit test for function mute
def test_mute():
    """Testing the mute() function."""
    set_log_level("ERROR")
    # Test the mute() function
    p1 = Pulse(gen_name="p1")
    p2 = Pulse(gen_name="p2")
    p3 = Pulse(gen_name="p3")
    p4 = Pulse(gen_name="p4")
    p5 = Pulse(gen_name="p5")

    mute(p3, p4)
    p5.delay(5e-6)
    p5.mute()

    p1.delay(5e-6)
    p2.delay(5e-6)

    p1.delay(5e-6)
    p2.delay(5e-6)

    p1.delay(5e-6)
    p2.delay(5e-6)

# Generated at 2022-06-26 04:19:29.133579
# Unit test for function unmute
def test_unmute():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 04:19:39.586174
# Unit test for function mute
def test_mute():
    # Testing mute method and unmute method
    print("Testing mute and unmute function...")
    led_r = sync_pulse_generator(0, 1)
    led_g = sync_pulse_generator(0, 1)
    led_b = sync_pulse_generator(0, 1)

    # Mute led_r, led_g and led_b
    mute(led_r, led_g, led_b)
    # Assert that these objects have been muted
    assert led_r.is_muted
    assert led_g.is_muted
    assert led_b.is_muted

    # Unmute all the objects and assert that the equal to
    # default values
    unmute(led_r, led_g, led_b)
    assert not led_r.is_m

# Generated at 2022-06-26 04:19:42.545499
# Unit test for function unmute
def test_unmute():
    print()
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 04:19:45.221651
# Unit test for function unmute
def test_unmute():
    unmute()



# Generated at 2022-06-26 04:19:55.098775
# Unit test for function mute
def test_mute():
    '''
    Mute multiple registers
    '''
    @block
    def testbench():
        b = Bus(width=16)
        c = Bus(width=16)
        d = Bus(width=16)
        a = Register(b, c)
        e = Register(d, a)
        mute(a, e)
        return a, e

    a, e = testbench()
    a.write(0x7fff)
    a.write(0)
    assert a.read() == 0x7fff, "Mute() doesn't work"
    return



# Generated at 2022-06-26 04:20:03.529292
# Unit test for function unmute
def test_unmute():
    """
    Tests the unmute() function with the example type-0.
    """
    mock_value = Register()
    mock_value.unmute()
    assert mock_value.return_value() == "0"  # State = 'unmuted'
    unmute(mock_value)
    assert mock_value.return_value() == "0"  # State = 'unmuted'



# Generated at 2022-06-26 04:20:12.496919
# Unit test for function mute
def test_mute():
    unmute()
    print("Testing mute()")
    print("*" * 80)
    print("Expected output:")
    print("*" * 80)
    print("Formatted Register:  t2_fmt")
    print("Register name:       t2")
    print("Unformatted Register:t2")
    print("Value:               0")
    print("Mute:                False")
    print("Mute:                False")
    print("Mute:                True")
    print("Mute:                True")
    print("*" * 80)
    print("Actual output:")
    print("*" * 80)
    t2 = Register("t2", 0, size=32)
    t2_fmt = Register("t2", 0, size=32, fmt="x")

# Generated at 2022-06-26 04:20:17.997390
# Unit test for function mute
def test_mute():
    """
    Use this test-case to check the functionality of the
    mute() method.
    """
    mute()
    # Create a register
    register = Register()
    # Write the value 0x1 to the register
    register.write(0x1)
    # Check if 0x1 can be read from the register
    assert(register.read() == 0x1)
    # Check if the hex string representation of the register
    # is equal to the string "0x1"
    assert(hex(register) == "0x1")


# Generated at 2022-06-26 04:20:26.484002
# Unit test for function mute
def test_mute():
    class CustomRegister(Register):
        def __init__(self, name, width=8, initval=None):
            super().__init__(name, width, initval)
            self.add_output('o_%s' % (name, ))

    f = CustomRegister('foo')
    g = CustomRegister('bar')
    mute(f, g)
    f.add_output('o_foo')
    f.add_output('o_bar')
    assert not f.outputs
    assert not g.outputs
