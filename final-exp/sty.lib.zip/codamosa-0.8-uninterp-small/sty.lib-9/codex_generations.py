

# Generated at 2022-06-26 04:19:17.882930
# Unit test for function unmute
def test_unmute():
    unmute()
    assert (not current_assumption) 
    mute()
    assert current_assumption 



# Generated at 2022-06-26 04:19:27.326026
# Unit test for function mute
def test_mute():
    """
    This unit test checks out the 'mute' function.
    """
    r0 = Register(4)
    r1 = Register(4)
    r2 = Register(4)
    r0.output()
    r1.output()
    r2.output()

    r0.write(1)
    r1.write(2)
    r2.write(3)
    print()

    r1.mute()
    r0.write(4)
    r1.write(5)
    r2.write(6)
    print()

    r0.unmute()
    r1.unmute()
    r2.unmute()

    r0.write(7)
    r1.write(8)
    r2.write(9)
    print()


# Generated at 2022-06-26 04:19:33.726651
# Unit test for function unmute
def test_unmute():
    testreg = Register(3)
    assert testreg.read() == 0x7, "testreg.read() == 0x7"

    mute(testreg)
    assert testreg.read() == 0x0, "testreg.read() == 0x0"

    unmute(testreg)
    assert testreg.read() == 0x7, "testreg.read() == 0x7"


# Generated at 2022-06-26 04:19:37.562809
# Unit test for function mute
def test_mute():
    global test_mute
    mute(test_mute, test_case_0)
    assert test_mute.status == "Muted"


# Generated at 2022-06-26 04:19:48.327142
# Unit test for function unmute
def test_unmute():
    """
    Test to make sure all registers unmute properly.
    """
    test_case_0()
    # Test register a
    if a.muted == False:
        a.unmute()
        assert (a.muted == False)
    else:
        a.mute()
        assert (a.muted == True)
        a.unmute()
        assert (a.muted == False)
    # Test register b
    if b.muted == False:
        b.unmute()
        assert (b.muted == False)
    else:
        b.mute()
        assert (b.muted == True)
        b.unmute()
        assert (b.muted == False)
    # Test register c
    if c.muted == False:
        c.unm

# Generated at 2022-06-26 04:19:52.260941
# Unit test for function mute
def test_mute():
    reg = Register(intbv(0)[16:])
    reg.next = 0xF0F0
    reg.mute()
    reg.next = 0x0F0F
    assert reg._val == 0xF0F0


# Generated at 2022-06-26 04:19:58.576385
# Unit test for function unmute
def test_unmute():
    class TestRegister0(Register):
        pass

    class TestRegister1(Register):
        pass

    class TestRegister2(Register):
        pass

    test_reg0 = TestRegister0()
    test_reg1 = TestRegister1()
    test_reg2 = TestRegister2()

    test_reg0.mute()
    test_reg1.mute()
    test_reg2.mute()

    unmute(test_reg0, test_reg1, test_reg2)
    assert test_reg0.is_muted == False
    assert test_reg1.is_muted == False
    assert test_reg2.is_muted == False



# Generated at 2022-06-26 04:20:01.084357
# Unit test for function unmute
def test_unmute():
    r = Register(width=4, monitor=True)
    r.unmute()
    assert r.monitor == True
    r.mute()
    assert r.monitor == False
    r.unmute()
    assert r.monitor == True


# Generated at 2022-06-26 04:20:07.784304
# Unit test for function unmute
def test_unmute():

    class TestRegister(Register):
        unmute()

    mute()
    err = ValueError(
        "The mute() method can only be used with objects that inherit from "
        "the 'Register class'."
    )
    with pytest.raises(err):
        mute(TestRegister)

    mute(TestRegister)
    assert TestRegister.is_muted()

    unmute()
    assert not TestRegister.is_muted()

    unmute(TestRegister)
    assert not TestRegister.is_muted()

    mute()
    with pytest.raises(err):
        unmute(TestRegister)



# Generated at 2022-06-26 04:20:12.651314
# Unit test for function mute
def test_mute():
    a = Register()
    b = Register()
    c = Register()

    a.name = "a"
    b.name = "b"
    c.name = "c"

    assert a.name == "a"
    assert b.name == "b"
    assert c.name == "c"

    assert a.muted == False
    assert b.muted == False
    assert c.muted == False

    mute(a, b, c)

    assert a.name == "a"
    assert b.name == "b"
    assert c.name == "c"

    assert a.muted == True
    assert b.muted == True
    assert c.muted == True

