

# Generated at 2022-06-26 04:19:19.773434
# Unit test for function unmute
def test_unmute():
    """
    Call the unmute function
    """
    unmute()


# Generated at 2022-06-26 04:19:22.364158
# Unit test for function mute
def test_mute():
    mute()


# Generated at 2022-06-26 04:19:28.534732
# Unit test for function mute
def test_mute():
    r = Register(name='r')
    assert r.mute() is None
    assert r.unmute() is None
    mute(r)
    assert r.is_mute is True
    unmute(r)
    assert r.is_mute is False



# Generated at 2022-06-26 04:19:36.275232
# Unit test for function mute
def test_mute():
    r = Register(0, 0, 0, "r")
    s = Register(0, 0, 0, "s")
    t = Register(0, 0, 0, "t")
    r.mute()
    s.mute()
    t.mute()
    assert r.muted == True
    assert s.muted == True
    assert t.muted == True
    r.unmute()
    s.unmute()
    t.unmute()
    assert r.muted == False
    assert s.muted == False
    assert t.muted == False


# Generated at 2022-06-26 04:19:37.705716
# Unit test for function mute
def test_mute():
    test_case_0()



# Generated at 2022-06-26 04:19:39.494739
# Unit test for function unmute
def test_unmute():
    mute()
    unmute()


# Generated at 2022-06-26 04:19:40.457365
# Unit test for function mute
def test_mute():
    mute()
    from .primitive import numobj
    assert numobj == 0



# Generated at 2022-06-26 04:19:44.413019
# Unit test for function mute
def test_mute():
    x = Register(1, dims = (3,3))
    y = Register(2, dims = (3,3), mute_level = 2)
    z = Register(3, dims = (3,3), mute_level = 1)
    mute(x, y, z)
    assert(x.mute_level == 1) and (y.mute_level == 2) and (z.mute_level == 1)



# Generated at 2022-06-26 04:19:52.298424
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute
    """
    # print("Test mute function started...")
    simulator.reset()
    x = Register()
    a = Register()
    b = Register()
    c = Register()
    mute(a, b, c)
    simulate(1)
    assert int(c.read()) == 0, "c should be zero"
    assert int(b.read()) == 0, "b should be zero"
    assert int(a.read()) == 0, "a should be zero"
    assert int(x.read()) == 0, "x should be zero"
    # print("Test mute function completed successfully!")



# Generated at 2022-06-26 04:19:53.691199
# Unit test for function mute
def test_mute():
    # Nothing should be printed
    test_case_0()