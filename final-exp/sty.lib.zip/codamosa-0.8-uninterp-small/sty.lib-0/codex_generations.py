

# Generated at 2022-06-26 04:19:26.900766
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .systems import System

    class My_testbench(System):
        def __init__(self):
            self.inst = Register(width = 8)
            self.in_clk = put()
            self.in_rst = put()
            self.out = get()

        def elaborate(self):
            @instance
            def behaviour():
                while True:
                    yield self.in_clk.posedge, self.in_rst.posedge

                    if self.in_rst:
                        self.inst.clear()
                    else:
                        self.inst.set_data( self.in_clk.val )
                        yield self.in_clk
                        mute( self.inst )
                        self.inst.set_data( ~self.inst.get_data() )
                       

# Generated at 2022-06-26 04:19:28.931787
# Unit test for function mute
def test_mute():
    mute()
    assert not get_muted()


# Generated at 2022-06-26 04:19:34.582031
# Unit test for function unmute
def test_unmute():
    a = Register(1, name="a")
    b = Register(1, name="b")
    x = a | b
    assert x._unmuted_value == 0
    assert x._muted_value == 3
    unmute(a, b)
    assert x._unmuted_value == 0
    assert x._muted_value == 0


# Generated at 2022-06-26 04:19:41.496027
# Unit test for function mute
def test_mute():
    print()
    print("test_mute:")
    test_case_0()
    print("test_mute: PASSED")

test_mute()



# Generated at 2022-06-26 04:19:43.247300
# Unit test for function unmute
def test_unmute():
    test_case_0()


if __name__ == '__main__':
    test_unmute()

# Generated at 2022-06-26 04:19:44.334266
# Unit test for function unmute
def test_unmute():
    with pytest.raises(ValueError):
        unmute()

# Generated at 2022-06-26 04:19:46.050107
# Unit test for function mute
def test_mute():
    register = Register()
    mute(register)
    assert bool(register) == False



# Generated at 2022-06-26 04:19:56.576100
# Unit test for function unmute
def test_unmute():
    reg1 = Register(0, [0, 1, 0, 1, 1, 1, 1, 0],
                    name="This is my register!",
                    verbose=False)
    reg2 = Register(1, [1, 0, 1, 1, 0, 0, 1, 0])

    mute(reg1, reg2)
    assert reg1.get() == [0, 0, 0, 0, 0, 0, 0, 0]
    assert reg2.get() == [0, 0, 0, 0, 0, 0, 0, 0]

    unmute(reg1, reg2)
    assert reg1.get() == [0, 1, 0, 1, 1, 1, 1, 0]
    assert reg2.get() == [1, 0, 1, 1, 0, 0, 1, 0]

# Generated at 2022-06-26 04:20:06.111755
# Unit test for function mute
def test_mute():
    data_register = Register(8, "data_register", reset_value=0)
    instruction_register = Register(8, "instruction_register", reset_value=0)
    address_register = Register(8, "address_register", reset_value=0)

    assert data_register.muted == False
    assert instruction_register.muted == False
    assert address_register.muted == False

    mute(data_register, instruction_register, address_register)

    assert data_register.muted == True
    assert instruction_register.muted == True
    assert address_register.muted == True



# Generated at 2022-06-26 04:20:10.367435
# Unit test for function unmute
def test_unmute():
    write_obj = Register(0xFF)
    write_obj.write(0x11)
    assert(write_obj.read() == 0xFF)
    unmute(write_obj)
    write_obj.write(0x11)
    assert(write_obj.read() == 0x11)
    mute(write_obj)
