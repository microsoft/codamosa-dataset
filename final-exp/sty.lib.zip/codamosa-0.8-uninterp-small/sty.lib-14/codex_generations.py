

# Generated at 2022-06-26 04:19:22.256267
# Unit test for function unmute
def test_unmute():
    unmute()


# Generated at 2022-06-26 04:19:32.306026
# Unit test for function unmute
def test_unmute():
    with Patch('modular.primitive.Register.unmute') as mock_unmute:
        unmute()
        assert mock_unmute.call_count == 0

    from .primitive import Register
    _ = Register()
    with Patch('modular.primitive.Register.unmute') as mock_unmute:
        unmute(_)
        assert mock_unmute.call_count == 1
        assert mock_unmute.call_args == ((), {})


# Generated at 2022-06-26 04:19:34.121987
# Unit test for function mute
def test_mute():
    test_case_0()



# Generated at 2022-06-26 04:19:41.088690
# Unit test for function unmute
def test_unmute():
    a = Register()
    mute(a)
    unmute(a)
    assert not a.is_muted()


# Generated at 2022-06-26 04:19:41.871914
# Unit test for function mute
def test_mute():
    assert mute() == None


# Generated at 2022-06-26 04:19:42.846566
# Unit test for function unmute
def test_unmute():
    pass


# Generated at 2022-06-26 04:19:54.660315
# Unit test for function unmute
def test_unmute():
    # Create a list of objects that inherit from the Register class
    obj_list = [
        BoolRegister(0),
        TristateRegister(0),
        TimerRegister(0),
        ByteRegister(0),
        UIntRegister(0),
        IntRegister(0),
        Float32Register(0),
        Float64Register(0),
    ]
    # Mute all objects
    mute(*obj_list)
    # Unmute all objects
    unmute(*obj_list)

    # Check if all objects are muted
    for obj in obj_list:
        assert not obj.muted



# Generated at 2022-06-26 04:20:06.597670
# Unit test for function mute
def test_mute():
    import numpy as np
    from pycqed.analysis_v2.single_qubit.single_qubit_readout import SingleQubit_Readout
    # Create data object
    exp_path = '../data/'
    am_demod_freq = 2e6
    meas_file_name = 'test_meas.h5'
    ro = SingleQubit_Readout(
        exp_path, meas_file_name, am_demod_freq)
    # Create register objects
    freq_obj = ro.frequency_sweep()
    ro_obj = ro.readout_pulses()
    trigger_obj = ro.trigger_pulses()
    # Test mute function
    mute(freq_obj, ro_obj)
    assert(freq_obj.muted)


# Generated at 2022-06-26 04:20:11.282323
# Unit test for function unmute
def test_unmute():
    r1 = Register()
    r2 = Register()
    r3 = Register()

    r1.mute()
    r2.mute()
    assert r1.is_muted() and r2.is_muted() and not r3.is_muted()
    unmute(r1, r2)
    assert not r1.is_muted() and not r2.is_muted() and not r3.is_muted()



# Generated at 2022-06-26 04:20:14.635176
# Unit test for function mute
def test_mute():
    # Tests if mute() function can be called without an error using the dummy device
    mute()

    # Reset the dummy device before next test
    d = DummyDevice(output_interface=None)
    d.reset()
