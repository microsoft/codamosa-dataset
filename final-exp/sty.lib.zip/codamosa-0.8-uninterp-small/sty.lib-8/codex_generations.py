

# Generated at 2022-06-26 04:19:17.139602
# Unit test for function unmute
def test_unmute():
    mute()
    assert True
    unmute()
    assert True



# Generated at 2022-06-26 04:19:22.398459
# Unit test for function unmute
def test_unmute():
    """
    The code below should run silently,
    i.e. no warnings or errors should be printed.
    """
    mute()
    unmute()


# Generated at 2022-06-26 04:19:35.443574
# Unit test for function mute
def test_mute():
    from .primitive import Register, Input
    from .asyncio import AsyncRegister

    reg = Register(default='bar')
    inp = Input(default='foo')

    mute(reg, inp)
    assert reg.value == 'bar'
    assert inp.value == 'foo'
    reg.set('baz')
    inp.set('qux')
    assert reg.value == 'bar'
    assert inp.value == 'foo'

    # check if manually resetting the muting works
    reg.unmute()
    reg.set('baz')
    reg.mute()

    # Test that muting multiple registers works
    reg1 = Register(default='foo')
    reg2 = Register(default='bar')
    inp1 = Input()
    inp2 = Input()

# Generated at 2022-06-26 04:19:39.274558
# Unit test for function unmute
def test_unmute():
    return unmute()


# Generated at 2022-06-26 04:19:43.323483
# Unit test for function mute
def test_mute():
    """
    Test for function mute()
    """
    # TODO: Should this be a unit test?
    mute(reg)
    assert reg.muted, "Problem with function mute()"
    unmute(reg)
    assert not reg.muted, "Problem with function unmute()"
    # Test standard usage
    mute()


# Generated at 2022-06-26 04:19:44.716550
# Unit test for function mute
def test_mute():
    reg = Register(0)
    assert reg.muted == False
    mute(reg)
    asse

# Generated at 2022-06-26 04:19:56.129128
# Unit test for function unmute
def test_unmute():
    
    class TestRegister(Register):
        def __init__(self, reg, bit_no, mutable, width=1):
            super(TestRegister, self).__init__(reg, bit_no, mutable, width)
            self.mute_cnt = 0
            self.unmute_cnt = 0
    
        def _mute(self):
            self.mute_cnt += 1
    
        def _unmute(self):
            self.unmute_cnt += 1
    
    a = TestRegister(0, 0, True)
    b = TestRegister(0, 0, True)
    c = TestRegister(0, 0, False)
    
    unmute(a, b, c)
    assert a.unmute_cnt == 1
    assert b.unmute

# Generated at 2022-06-26 04:20:04.197666
# Unit test for function unmute
def test_unmute():
    """
    Tests the unmute method, by creating a new register, setting the mute
    attribute to true and then calling the unmute() method.
    """
    try:
        r = Register()
        r.mute = True
        r.unmute()
        assert not r.mute

    except Exception as e:
        assert False, "Error: " + str(e)



# Generated at 2022-06-26 04:20:05.374170
# Unit test for function mute
def test_mute():
    assert mute


# Generated at 2022-06-26 04:20:10.266922
# Unit test for function mute
def test_mute():
    from .primitive import Register, Memory

    reg1 = Register()
    reg2 = Register()
    mem = Memory(1)

    mute(reg1, reg2, mem)
    assert reg1.mute is True and reg2.mute is True and mem.mute is True

    unmute(reg1, reg2, mem)

