

# Generated at 2022-06-26 04:19:25.130009
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    a = Register(name="a", width=4, init_val=0b1101, mute_all=True)
    b = Register(name="b", width=4, init_val=0b1101, mute_all=True)
    mute(a, b)
    unmute(a, b)
    assert a.mute_all is False
    assert b.mute_all is False

# Generated at 2022-06-26 04:19:27.452153
# Unit test for function unmute
def test_unmute():
    # test_0
    unmute()


# Generated at 2022-06-26 04:19:37.896744
# Unit test for function unmute
def test_unmute():
    mute_all = [r"C:\AudioEdit\reference_wav\OMG_mute.wav", r"C:\AudioEdit\reference_wav\BMM_mute.wav"]
    unmute_all = [r"C:\AudioEdit\reference_wav\OMG_unmute.wav", r"C:\AudioEdit\reference_wav\BMM_unmute.wav"]

    audio_paths = [r"C:\AudioEdit\test_cases\test_case_wav\OMG.wav", r"C:\AudioEdit\test_cases\test_case_wav\BMM.wav"]

# Generated at 2022-06-26 04:19:48.502202
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .mode import Mode

    reg_0 = Register(name='reg_0', mode=Mode.read_only)
    reg_1 = Register(name='reg_1', mode=Mode.write_only)
    reg_2 = Register(name='reg_2', mode=Mode.read_write)

    mute(reg_0, reg_1, reg_2)
    assert reg_0.mode == Mode.read_only
    assert reg_1.mode == Mode.write_only
    assert reg_2.mode == Mode.read_write

    unmute(reg_0, reg_1, reg_2)
    assert reg_0.mode == Mode.read_only
    assert reg_1.mode == Mode.write_only
    assert reg_2.mode == Mode.read_write




# Generated at 2022-06-26 04:19:51.117961
# Unit test for function mute
def test_mute():
    mute(test_case_0.__globals__['test_case_0'])



# Generated at 2022-06-26 04:19:58.709182
# Unit test for function mute
def test_mute():
    def test_dummy_function_0():
        pass

    def test_dummy_function_1():
        pass

    @mute
    def test_dummy_function_2():
        pass

    @mute
    def test_dummy_function_3():
        pass

    # Test case 0
    test_case_0()

    # Test case 1
    mute()
    mute()

    # Test case 2
    mute(test_dummy_function_0)
    mute(test_dummy_function_1)

    # Test case 3
    mute(test_dummy_function_0, test_dummy_function_1)

    # Test case 4
    mute(test_dummy_function_2, test_dummy_function_3)

    # Test case 5

# Generated at 2022-06-26 04:19:59.752682
# Unit test for function mute
def test_mute():
    test_case_0()



# Generated at 2022-06-26 04:20:03.823757
# Unit test for function unmute
def test_unmute():
    r = Register()
    r.mute()
    assert r._muted == True
    r.unmute()
    assert r._muted == False



# Generated at 2022-06-26 04:20:15.752624
# Unit test for function unmute
def test_unmute():
    print("\nTest unmute()\n")
    print("Setting test_register_1 and test_register_2 as mute")
    test_register_1.mute()
    test_register_2.mute()
    print(f"Muted status of test_register_1: {test_register_1.is_muted}")
    print(f"Muted status of test_register_2: {test_register_2.is_muted}")
    print("\nUnmute test_register_1")
    test_register_1.unmute()
    print(f"Muted status of test_register_1: {test_register_1.is_muted}")
    print(f"Muted status of test_register_2: {test_register_2.is_muted}")
    print

# Generated at 2022-06-26 04:20:17.177723
# Unit test for function mute
def test_mute():
    # Test mute
    mute()
