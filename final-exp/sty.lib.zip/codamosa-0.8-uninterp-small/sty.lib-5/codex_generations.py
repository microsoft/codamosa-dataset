

# Generated at 2022-06-26 04:19:17.463934
# Unit test for function unmute
def test_unmute():
    unmute()



# Generated at 2022-06-26 04:19:27.277193
# Unit test for function unmute
def test_unmute():
    reg = Register(init_vals=[1, 2, 3], init_val_states=['-', 'X', 'X'])
    mock = reg.mock()
    assert reg.value == [1, 2, 3]
    assert reg.value_state() == ['-', 'X', 'X']
    reg[1] <= 5
    assert reg.value == [1, 5, 3]
    assert reg.value_state() == ['-', 'V', 'X']
    reg[2] <= 8
    assert reg.value == [1, 5, 8]
    assert reg.value_state() == ['-', 'V', 'V']
    assert mock.call_count == 0
    reg.unmute()
    assert reg.value == [1, 5, 8]
    assert mock.call_count == 1
   

# Generated at 2022-06-26 04:19:31.754259
# Unit test for function unmute
def test_unmute():
    r = Register(name='Test')
    r.mute()
    assert r.mute_register == True
    unmute(r)
    assert r.mute_register == False



# Generated at 2022-06-26 04:19:37.214568
# Unit test for function mute
def test_mute():
    """
    Unit test for the mute() function.
    """
    a = Register()
    b = Register()
    mute(a, b)
    assert a.is_muted and b.is_muted


# Generated at 2022-06-26 04:19:41.959376
# Unit test for function unmute
def test_unmute():
    reg = Register(3, "reg")
    test_case_0()
    assert not reg.muted
    unmute()
    assert not reg.muted


# Generated at 2022-06-26 04:19:43.886695
# Unit test for function unmute
def test_unmute():
    r0 = Register(0)
    r1 = Register(1)
    r0.mute()
    r1.mute()
    test_case_0()
    assert not r0.is_muted and not r1.is_muted

# Generated at 2022-06-26 04:19:54.337025
# Unit test for function mute
def test_mute():
    '''
    Creates multiple objects that inherit from the Register class,
    then calls the mute function on them.
    '''
    print('\n---Test 1--- Mute---')
    p = GPIO(name='p', port=Port.Port0)
    q = GPIO(name='q', port=Port.Port1, pin=Pin.Pin10)
    r = GPIO(name='r', port=Port.Port1, pin=Pin.Pin11)

    assert (isinstance(p, Register))
    assert (isinstance(q, Register))
    assert (isinstance(r, Register))

    mute(p, q, r)

    assert (p.is_muted() == True)
    assert (q.is_muted() == True)
    assert (r.is_muted() == True)


# Generated at 2022-06-26 04:20:01.550275
# Unit test for function unmute
def test_unmute():
    assert mute.__doc__ == "Use this function to mute multiple register-objects at once.\n\n:param objects: Pass multiple register-objects to the function."
    assert unmute.__doc__ == "Use this function to unmute multiple register-objects at once.\n\n:param objects: Pass multiple register-objects to the function."



# Generated at 2022-06-26 04:20:09.552087
# Unit test for function unmute
def test_unmute():
    reg_a = Register()
    reg_b = Register()

    arr = [reg_a, reg_b]
    unmute(reg_a)
    for reg in arr:
        assert not reg.is_muted


# Generated at 2022-06-26 04:20:15.631579
# Unit test for function unmute
def test_unmute():
    unmute()

    r1 = Register("Register 1")
    r2 = Register("Register 2")

    r1.mute()
    r2.mute()

    assert r1.mute_flag is True
    assert r2.mute_flag is True

    unmute(r1, r2)

    assert r1.mute_flag is False
    assert r2.mute_flag is False

