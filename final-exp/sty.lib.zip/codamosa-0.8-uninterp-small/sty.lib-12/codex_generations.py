

# Generated at 2022-06-26 04:19:26.823320
# Unit test for function unmute
def test_unmute():
    import spidev

    unmute()

    r1 = Register(0x1234, init_val=0xFF00, word_size=16,
                  name='R1', mute=True)
    r2 = Register(0x1234, init_val=0xFF00, word_size=16,
                  name='R2', mute=True)
    r3 = Register(0x1234, init_val=0xFF00, word_size=16,
                  name='R3', mute=False)
    r4 = Register(0x1234, init_val=0xFF00, word_size=16,
                  name='R4', mute=True)

# Generated at 2022-06-26 04:19:33.145111
# Unit test for function mute
def test_mute():
    dut = Register(8, signed=False, reset_value=0x01)
    mute(dut)
    dut.d = 0x08
    dut.d = 0x09
    dut.clk_i.next = 0
    dut.clk_i.next = 1
    assert dut.d == 0x01


# Generated at 2022-06-26 04:19:41.409935
# Unit test for function mute
def test_mute():
    reset()
    # Create registers
    reg_a = Register(12)
    reg_b = Register(3)
    # Mute register
    reg_a.mute()
    reg_b.mute()
    # Assert muted
    assert (reg_a.value == None)
    assert (reg_b.value == None)


# Generated at 2022-06-26 04:19:49.138699
# Unit test for function mute
def test_mute():
    x = Register(0)
    y = Register(1)
    z = Register(2)
    mute(x, y, z)

    assert not x.is_muted
    assert not y.is_muted
    assert not z.is_muted

    assert x.value == 0
    assert y.value == 1
    assert z.value == 2

    x.value = 99
    y.value = 88
    z.value = 77

    assert not x.is_muted
    assert not y.is_muted
    assert not z.is_muted

    assert x.value == 99
    assert y.value == 88
    assert z.value == 77


# Generated at 2022-06-26 04:19:57.717849
# Unit test for function mute
def test_mute():
    from .primitive import UnaryOp
    from .gates import X
    from .quantum_register import QuantumRegister
    from .quantum_circuit import QuantumCircuit

    qc = QuantumCircuit(2)
    qc.mute([0, 1], [1, 0])

    assert isinstance(qc._qregs[1], QuantumRegister)
    assert isinstance(qc._qregs[1][1], UnaryOp)
    assert isinstance(qc._qregs[1][1]._gate, X)
    assert qc._qregs[1][1]._qubits == [0]
    assert qc._qregs[0][0]._qubits == [1]



# Generated at 2022-06-26 04:19:58.928385
# Unit test for function unmute
def test_unmute():
    test_case_0()

# Generated at 2022-06-26 04:20:03.794631
# Unit test for function mute
def test_mute():
    x = Register()
    assert x.mute_count == 0
    mute()
    assert x.mute_count == 1
    assert x.muted
    assert x.check_mute
    unmute()
    assert x.mute_count == 0
    assert not x.muted
    assert not x.check_mute


# Generated at 2022-06-26 04:20:04.966994
# Unit test for function unmute
def test_unmute():
    unmute()



# Generated at 2022-06-26 04:20:09.434480
# Unit test for function unmute
def test_unmute():
    """Whitebox test."""
    test_case_0()

    # Test if default register was unmuted
    if not Register._is_muted:
        raise ValueError("The default register was not unmuted.")



# Generated at 2022-06-26 04:20:14.347111
# Unit test for function mute
def test_mute():
    i2c = I2CBus()
    err = ValueError(
        "The mute() method can only be used with objects that inherit "
        "from the 'Register class'."
    )
    with pytest.raises(err):
        mute(i2c)
