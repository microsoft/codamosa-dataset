

# Generated at 2022-06-26 04:19:26.195508
# Unit test for function mute
def test_mute():
    """
    Test to make sure that the mute() function works as expected.
    """
    from .decorator import mute

    @mute
    def test_case_1(arg1: int, arg2: int, arg3: int = 3) -> int:
        """
        Test case 1.

        :param arg1: Integer argument.
        :param arg2: Integer argument.
        :param arg3: Optional integer argument.
        :return: Integer.
        """
        return arg1 + arg2 + arg3

    assert test_case_1(1, 2) == 6



# Generated at 2022-06-26 04:19:31.472206
# Unit test for function mute
def test_mute():
    """
    Unit test for the function mute()
    """
    s = Singleton.getInstance()
    s.clear()
    test_case_0()
    assert s.last_line() == "mute"



# Generated at 2022-06-26 04:19:33.954120
# Unit test for function mute
def test_mute():
    assert(test_case_0() == None)


# Generated at 2022-06-26 04:19:39.212545
# Unit test for function mute
def test_mute():
    test_case_0()

# Generated at 2022-06-26 04:19:44.343947
# Unit test for function unmute
def test_unmute():
    # Setup
    obj_a = Register('A')
    obj_b = Register('B')

    # Execute
    mute(obj_a, obj_b)
    # Verify
    assert obj_a.mute_flag == True
    assert obj_b.mute_flag == True

    # Execute
    unmute(obj_a, obj_b)
    # Verify
    assert obj_a.mute_flag == False
    assert obj_b.mute_flag == False



# Generated at 2022-06-26 04:19:48.223686
# Unit test for function mute
def test_mute():
    Input = Register("Input", [1, 1, 1])
    Output = Register("Output", [1, 1, 1])
    Output.assign(Input)
    Input.assign(1)
    assert Output == 1
    mute(Output)
    Input.assign(0)
    assert Output == 1



# Generated at 2022-06-26 04:19:49.564129
# Unit test for function unmute
def test_unmute():
    mute()
    unmute()

# Generated at 2022-06-26 04:19:54.336647
# Unit test for function unmute
def test_unmute():

    reg = Register(8)
    reg.toggle_enable(4)
    assert reg.value_dec == 4

    reg.unmute()
    reg.toggle_enable(4)
    assert reg.value_dec == 0



# Generated at 2022-06-26 04:19:57.788604
# Unit test for function mute
def test_mute():
    mute()
    assert True



# Generated at 2022-06-26 04:19:59.479995
# Unit test for function mute
def test_mute():
    dut = Module('Test')
    test_case_0()