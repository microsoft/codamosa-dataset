

# Generated at 2022-06-26 04:19:26.663852
# Unit test for function mute
def test_mute():
    reset()
    register_a = Register(name='A', width=8, has_enable=True)
    register_b = Register(name='B', width=8, has_enable=True)
    register_c = Register(name='C', width=8, has_enable=True)

    # Test 0
    test_case_0()
    assert not register_a.is_muted()
    assert not register_b.is_muted()
    assert not register_c.is_muted()

    # Test 1
    mute(register_a)
    mute(register_b, register_c)
    assert register_a.is_muted()
    assert register_b.is_muted()
    assert register_c.is_muted()

    # Test 2

# Generated at 2022-06-26 04:19:31.754177
# Unit test for function mute
def test_mute():
    a = Cable()
    b = Cable()
    c = Cable()
    a.connect(b)
    b.connect(c)

    a.mute()
    assert b.value is None
    assert c.value is None



# Generated at 2022-06-26 04:19:37.214192
# Unit test for function unmute
def test_unmute():
    """
    Test the unmute function.
    """
    sub_test_case_0()
    sub_test_case_1()
    sub_test_case_2()


# Full unit test of unmute (writing to internal register)

# Generated at 2022-06-26 04:19:41.959067
# Unit test for function mute
def test_mute():
    r = Register(name="r", width=8)
    mute(r)
    assert r.mute == True
    r.unmute()



# Generated at 2022-06-26 04:19:43.166063
# Unit test for function mute
def test_mute():
    with pytest.raises(ValueError):
        mute()



# Generated at 2022-06-26 04:19:43.927381
# Unit test for function unmute
def test_unmute():
    test_case_0()


# Generated at 2022-06-26 04:19:48.393593
# Unit test for function mute
def test_mute():
    x = Signal(bool(0))
    y = Signal(bool(0))
    register = Register(x, y)

    x.next = 0
    register.update_signal()

    test_case_0()

    assert y.read() == 0

    mute(register)
    x.next = 1
    register.update_signal()

    assert y.read() == 0



# Generated at 2022-06-26 04:19:51.989728
# Unit test for function unmute
def test_unmute():
    r = Register()
    r.mute()
    assert r.is_muted() is True
    unmute(r)
    assert r.is_muted() is False


# Generated at 2022-06-26 04:19:55.040328
# Unit test for function mute
def test_mute():
    reg_check = Register()
    mute(reg_check)
    assert reg_check.is_mute is True
    unmute(reg_check)


# Generated at 2022-06-26 04:20:06.772960
# Unit test for function mute
def test_mute():
    """
    This unit test will test the mute function
    :return:
    """
    r0 = Register(0x0) #0b0
    r1 = Register(0x1) #0b1
    r2 = Register(0x2) #0b10
    r3 = Register(0x3) #0b11
    r4 = Register(0x4) #0b100
    r5 = Register(0x5) #0b101
    r6 = Register(0x6) #0b110
    r7 = Register(0x7) #0b111

    mute(r0)
    assert r0.val == 0x0

    mute(r1)
    assert r1.val == 0x0

    mute(r2)
    assert r2.val == 0x0
