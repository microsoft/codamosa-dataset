

# Generated at 2022-06-26 04:19:19.713093
# Unit test for function mute
def test_mute():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False



# Generated at 2022-06-26 04:19:22.604005
# Unit test for function unmute
def test_unmute():
    mute()
    unmute()
    assert True



# Generated at 2022-06-26 04:19:35.517033
# Unit test for function mute
def test_mute():

    # ToDo: Complete unit test.
    # Creating a test set
    test_set = set()
    # Creating a test instance of the class BaseRegister
    test_reg = BaseRegister()
    # Creating a test instance of the class BooleanRegister
    b_reg = BooleanRegister()
    # Creating a test instance of the class FloatRegister
    f_reg = FloatRegister()
    # Creating a test instance of the class IntegerRegister
    i_reg = IntegerRegister()
    # Creating a test instance of the class StringRegister
    s_reg = StringRegister()
    # Creating a test instance of the class UIntegerRegister
    ui_reg = UIntegerRegister()
    # Creating a test instance of the class UShortRegister
    us_reg = UShortRegister()

    # Adding instances to the test_set

# Generated at 2022-06-26 04:19:41.156426
# Unit test for function unmute
def test_unmute():
    register_object_0 = Register()

    unmute(register_object_0)

    assert register_object_0.output == False



# Generated at 2022-06-26 04:19:42.010090
# Unit test for function mute
def test_mute():
    test_case_0()


# Generated at 2022-06-26 04:19:44.147521
# Unit test for function unmute
def test_unmute():
    err = ValueError(
        "Unable to call 'unmute()' on an object that doesn't inherit from the "
        "'Register' class."
    )
    try:
        test_case_0()
    except ValueError as e:
        assert e == err

# Generated at 2022-06-26 04:19:54.637444
# Unit test for function mute
def test_mute():
    """
    Test for the mute function.
    """
    class DummyRegister(Register): pass
    class TestRegister(Register): pass
    class TestRegister2(Register): pass
    TestRegister.mute()
    TestRegister2.mute()
    Test = TestRegister(0x00, name="TestRegister", mute=False)
    Test2 = TestRegister2(0x00, name="TestRegister2", mute=False)
    Test3 = DummyRegister(0x00, name="DummyRegister", mute=False)
    # assert True when TestRegister is muted
    assert TestRegister.muted() is True
    # assert True when TestRegister2 is muted
    assert TestRegister2.muted() is True
    # assert False when DummyRegister is not muted
    assert DummyRegister.muted() is False
    # assert True when

# Generated at 2022-06-26 04:19:59.718863
# Unit test for function unmute
def test_unmute():
    unmute()


if __name__ == "__main__":
    print("Primitive wrapper test functions")
    test_case_0()
    test_unmute()

# Generated at 2022-06-26 04:20:03.823399
# Unit test for function unmute
def test_unmute():
    reg = Register(1, 1, 'r')
    reg.unmute()
    test_unmute.assertEqual(reg.muted, False)
    
    

# Generated at 2022-06-26 04:20:06.773659
# Unit test for function mute
def test_mute():
    test_case_0()
