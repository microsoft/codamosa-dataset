

# Generated at 2022-06-26 04:19:22.123615
# Unit test for function unmute
def test_unmute():
    unmute()
    assert 'unmute' in globals()


# Generated at 2022-06-26 04:19:29.050506
# Unit test for function unmute
def test_unmute():
    """ Test unmute() function with one register. """
    test_register = Register(0, "Test register", "UserDefined")
    if test_register.mute_state == 0:
        print("Test case 1 passed!\n")
    else:
        print("Test case 1 failed!\n")



# Generated at 2022-06-26 04:19:34.619554
# Unit test for function unmute
def test_unmute():
    r0 = Register("r0", 32)
    r1 = Register("r1", 64)
    r2 = Register("r2", 128)

    unmute()

    for obj in [r0, r1, r2]:
        print("Testing if {} is unmuted".format(obj.name))
        assert not obj.is_muted



# Generated at 2022-06-26 04:19:44.271750
# Unit test for function unmute
def test_unmute():
    mute(verbose, debug, info, warning, error)
    unmute()

    assert verbose.muted == False
    assert debug.muted == False
    assert info.muted == False
    assert warning.muted == False
    assert error.muted == False

    mute()
    unmute(verbose, debug, info, warning, error)

    assert verbose.muted == False
    assert debug.muted == False
    assert info.muted == False
    assert warning.muted == False
    assert error.muted == False


# Generated at 2022-06-26 04:19:54.782523
# Unit test for function mute
def test_mute():
    from .test_utils import sizeof_bits

    # Create the registers that can be used for testing
    reg_a = Register(name="a", bit_size=8)
    reg_b = Register(name="b", bit_size=32)
    reg_c = Register(name="c", bit_size=64)

    # Set some initial register values
    reg_a.next = 1
    reg_b.next = 2
    reg_c.next = 3

    # simulate and check the default values
    test_case_0()
    test_case_0()
    assert reg_a.value == 1
    assert reg_b.value == 2
    assert reg_c.value == 3


# Generated at 2022-06-26 04:20:06.658125
# Unit test for function mute
def test_mute():
    """
    Unit test for mute()
    """
    counter = Register(name="counter")
    reg_0 = Register(name="reg_0")
    reg_1 = Register(name="reg_1")
    reg_2 = Register(name="reg_2")
    assert reg_0.is_muted() == False
    assert reg_1.is_muted() == False
    assert reg_2.is_muted() == False

    mute(reg_0, reg_1, reg_2)
    assert reg_0.is_muted() == True
    assert reg_1.is_muted() == True
    assert reg_2.is_muted() == True
    
    unmute(reg_1, reg_2)
    assert reg_0.is_muted() == True
    assert reg_1

# Generated at 2022-06-26 04:20:11.096389
# Unit test for function mute
def test_mute():
    name = "my_register"
    width = 16
    register = Register(name, width)
    mute(register)
    assert register.is_muted()



# Generated at 2022-06-26 04:20:11.762814
# Unit test for function unmute
def test_unmute():
    test_case_0()

# ------------------------------------------------------------------------------



# Generated at 2022-06-26 04:20:20.027033
# Unit test for function mute
def test_mute():
    print("===test_mute()===")
    a = Register(0, range(4))

    b = Register(1, range(4))

    c = Register(2, range(4))

    a.next = b.out
    b.next = a.out

    a.out.next = c.in_

    def stimulus_0(t):
        mute(a, b)
        if t < 1:
            a.in_.next = 3
            b.in_.next = 2
        else:
            a.in_.next = None
            b.in_.next = None

    a.sim(stimulus_0)

    def stimulus_1(t):
        unmute(a, b)
        if t < 1:
            a.in_.next = 3
            b.in_.next = 2

# Generated at 2022-06-26 04:20:22.248699
# Unit test for function unmute
def test_unmute():
    unmute()
    while True:
        A = dut.A
        B = dut.B
        C = dut.C
        C_ = A & ~B
        assert C == C_
        yield
