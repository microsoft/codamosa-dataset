

# Generated at 2022-06-24 04:49:26.585422
# Unit test for function mute
def test_mute():
    """ 
    Use this function to test the mute()-function.
    """
    # create register
    reg = Register(name = "reg", width = 8)

    # mute the register
    mute(reg)

    # check if muted
    assert reg.muted



# Generated at 2022-06-24 04:49:30.751169
# Unit test for function unmute
def test_unmute():
    from ..ports import Port
    from ..utility import RegisterEditor

    port = Port('A')
    regs = RegisterEditor(
        [
         Register('reg1', addr=0x0000, bitwidth=8, port=port)
        ]
    )
    mute(regs.reg1)
    unmute(regs.reg1)

# Generated at 2022-06-24 04:49:39.297079
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .protocols.protocol import Protocol
    from .protocols.step_protocol import StepProtocol

    class ProtocolTest(Protocol):
        def __init__(self):
            super().__init__()
            self.pulse_time = 1
            self.pulse_interval = 1
            self.number_of_pulses = 10
            self.muted_registers = []
            self.current_muted_registers = []
            self.all_register_objects = []
            self.step_protocol = StepProtocol()

            self.register1 = Register(0)
            self.register2 = Register(1)
            self.register3 = Register(2)

        def set(self, register: Register, value: int) -> None:
            pass

   

# Generated at 2022-06-24 04:49:47.036201
# Unit test for function unmute
def test_unmute():
    from . import Primitives
    from .primitive import Register, Memory
    from .clock import Clock
    from .sim import sim
    import random

    clk = Clock()
    reg = Register(width=10, clk=clk)

    assert reg.muted

    unmute(reg)

    assert not reg.muted

    clk.tick()
    reg.wr_data.value = 0b1100111010

    sim()

    assert reg.out == 0b1100111010


# Generated at 2022-06-24 04:49:54.437465
# Unit test for function mute
def test_mute():
    """
    Test the mute function, if it mutes all the passed
    register-objects.
    """

    # Test, if the passed argument is not of type Register.
    with pytest.raises(ValueError):
        mute(-1)
    with pytest.raises(ValueError):
        mute((1,))
    # Test, if multiple register objects can be muted with the
    # mute function.
    r1 = Register()
    r2 = Register()
    r3 = Register()
    r4 = Register()
    mute(r1, r2, r3, r4)
    for r in (r1, r2, r3, r4):
        assert r.muted



# Generated at 2022-06-24 04:50:00.924410
# Unit test for function mute
def test_mute():
    """
    This is a unit test for the function mute().
    """
    class TestRegister(Register):
        """
        A register class that can be used by the mute() function.
        """
        pass

    reg = TestRegister("reg", size=4)
    assert reg.is_muted() is False
    mute(reg)
    assert reg.is_muted() is True


# Generated at 2022-06-24 04:50:07.588274
# Unit test for function unmute
def test_unmute():
    import os
    import pytest

    this_dir = os.path.dirname(__file__)
    yaml_dir = os.path.join(this_dir, "test_configs")
    param_dir = os.path.join(this_dir, "test_params")
    pytest.main(["-s", os.path.join(this_dir, "test_unmute.py")])

# Generated at 2022-06-24 04:50:12.705254
# Unit test for function mute
def test_mute():
    name = 'myReg'
    width = 8
    reset_value = 0
    myReg = Register(name, width, reset_value)
    myReg.mute()
    assert myReg.is_muted() is True


# Generated at 2022-06-24 04:50:20.731487
# Unit test for function unmute
def test_unmute():
    from .primitive import BasicRegister, Register
    reg = BasicRegister(8, prefix='register')
    assert reg.bits == 'ZZZZZZZZ'
    reg << '10101010'
    assert reg.bits == '10101010'
    reg.mute()
    reg << '01010101'
    assert reg.bits == '10101010'
    unmute(reg)
    reg << '01010101'
    assert reg.bits == '01010101'


# Generated at 2022-06-24 04:50:29.067835
# Unit test for function unmute
def test_unmute():
    old_fit_plot = 'altair'

# Generated at 2022-06-24 04:50:31.176834
# Unit test for function mute
def test_mute():
    assert mute(1) == ValueError("The mute() method can only be used with objects that inherit from the 'Register class'.")



# Generated at 2022-06-24 04:50:37.643860
# Unit test for function unmute
def test_unmute():
    """
    Unit test for function unmute.
    This will not work properly if the I2C bus isn't properly set up.
    """
    a1 = Register(0x00, 'A', write=True)
    a2 = Register(0x00, 'B', write=True)
    a3 = Register(0x00, 'C', write=True)
    reg = [a1, a2, a3]
    mute(*reg)
    unmute(*reg)
    assert all([obj.muted==False for obj in reg])

# Generated at 2022-06-24 04:50:41.163358
# Unit test for function unmute
def test_unmute():
    w = Register('w')
    x = Register('x')

    assert x.muted is False and w.muted is False

    mute(x, w)
    assert x.muted is True and w.muted is True

    unmute(x, w)
    assert x.muted is False and w.muted is False



# Generated at 2022-06-24 04:50:44.627740
# Unit test for function mute
def test_mute():
    reg = Register(rw=True, name='mute_test_register')
    reg.mute_state
    mute(reg)
    assert reg.mute_state == True


# Generated at 2022-06-24 04:50:55.143691
# Unit test for function unmute
def test_unmute():
    import busio
    uart = busio.UART(tx=0, rx=1)
    r1 = Register(0x0001, 8, "r1", uart)
    r2 = Register(0x0002, 16, "r2", uart)
    r3 = Register(0x0003, 4, "r3", uart)

    mute(r1, r2, r3)
    assert r1.muted is True
    assert r2.muted is True
    assert r3.muted is True

    unmute(r1, r2, r3)
    assert r1.muted is False
    assert r2.muted is False
    assert r3.muted is False

# Generated at 2022-06-24 04:50:56.042951
# Unit test for function mute
def test_mute():
    obj = Register()
    assert obj.muted is False
    mute(obj)
    assert obj.muted is True


# Generated at 2022-06-24 04:51:05.376406
# Unit test for function unmute
def test_unmute():
    class A(Register):
        """
        Child-class of Register
        """
        def __init__(self) -> None:
            super().__init__()
            return

        def _update(self) -> None:
            """
            Overwritten method of register-class
            """
            self.value = self.__class__.__name__

    # Create local instances
    a = A()
    assert(a.muted)
    assert(a.value == a.__class__.__name__)
    unmute(a)
    assert(a.muted is False)
    assert(a.value == a.__class__.__name__)



# Generated at 2022-06-24 04:51:15.387973
# Unit test for function unmute
def test_unmute():
    from .primitive import Register
    from .utils import parse
    from .factory import Factory
    from .backend import BasicBackend

    # Create a new register object and connect to a TestBackend
    backend = BasicBackend("sim")
    reg = Register("test_value")
    backend.connect(reg)

    # Create a new factory to parse the value
    fac = Factory("parse", backend)

    # Call the unmute() function
    unmute(reg)

    # Read the register
    x = parse("test_value")
    print("Unit test unmute():", x)
    assert x == 0
    print("")


# Generated at 2022-06-24 04:51:25.089587
# Unit test for function unmute
def test_unmute():
    from ucb import main, trace, interact
    from .primitive import Register

    a = Register()
    b = Register()
    c = Register()
    a.set_contents(5)
    b.set_contents(6)
    c.set_contents(7)
    a.mute()
    b.mute()
    c.mute()
    assert a.get_contents() == None
    assert b.get_contents() == None
    assert c.get_contents() == None
    unmute(a, b, c)
    assert a.get_contents() == 5
    assert b.get_contents() == 6
    assert c.get_contents() == 7

# Generated at 2022-06-24 04:51:29.030391
# Unit test for function unmute
def test_unmute():
    """Testing the unmute function"""
    objs = [Register("r1"), Register("r2")]
    mute(*objs)
    unmute(*objs)
    for i in objs:
        assert not i.muted

# Generated at 2022-06-24 04:51:34.679788
# Unit test for function mute
def test_mute():
    print(str(mute.__doc__))
    o1 = Register()
    o2 = Register()
    o3 = Register()
    mute(o1, o2, o3)
    assert o1.is_muted() and o2.is_muted() and o3.is_muted()
    err = ValueError(
        "The mute() method can only be used with objects that inherit "
        "from the 'Register class'."
    )
    try:
        mute(err)
    except ValueError:
        pass



# Generated at 2022-06-24 04:51:46.233794
# Unit test for function mute
def test_mute():
    import pytest
    from .primitive import BitRegister
    br = BitRegister(value=0, width=5, mute=True)
    assert br.value == 0
    br.value = 10
    assert br.value == 0
    br.mute(False)
    br.value = 10
    assert br.value == 10
    mute(br)
    assert br.value == 0
    unmute(br)
    br.value = 12
    assert br.value == 12
    mute(br)
    with pytest.raises(ValueError):
        mute(br, 1)
    with pytest.raises(ValueError):
        unmute(br, 1)

if __name__ == "__main__":
    test_mute()

# Generated at 2022-06-24 04:51:58.709521
# Unit test for function unmute
def test_unmute():
    mute_obj = Register()
    mute_obj.mute()
    assert mute_obj._muted == 1
    unmute_obj = Register()
    unmute_obj.unmute()
    assert unmute_obj._muted == 0
    unmute(unmute_obj, mute_obj)
    assert unmute_obj._muted == 0, mute_obj._muted == 0
    mute(unmute_obj, mute_obj)
    assert unmute_obj._muted == 1, mute_obj._muted == 1
    unmute(unmute_obj)
    assert unmute_obj._muted == 0
    mute(mute_obj)
    assert mute_obj._muted == 1
    unmute()
    assert mute_obj._muted == 0
    return True

# Generated at 2022-06-24 04:52:04.604978
# Unit test for function mute
def test_mute():
    from .primitive import Int
    a = Int()
    b = Int()
    mute(a, b)
    a.add(2)
    b.add(2)
    assert a.mute_request
    assert b.mute_request

    unmute(a, b)
    a.add(2)
    b.add(2)
    assert (a.value == 4 and b.value == 4)

# Generated at 2022-06-24 04:52:13.578754
# Unit test for function mute
def test_mute():
    """
    Unit test function for function mute()
    Check if objects passed to mute are muted
    """
    # Check if mute works on I2C registers
    r = pyfaclient.register_i2c.I2CRegister(0x00, 0x00, "I2C", 0x00, 0xFF, 0x00, 0x00, 0x00)
    mute(r)
    assert r.muted == True

    # Check if mute works on SPI registers
    r = pyfaclient.register_spi.SPIRegister(0x00, 0x00, "SPI", 0x00, 0xFF, 0x00, 0x00, 0x00)
    mute(r)
    assert r.muted == True

    # Check if mute works on UDP registers

# Generated at 2022-06-24 04:52:20.946221
# Unit test for function mute
def test_mute():
    """
    A simple test method to verify if mute() is working as expected.
    """
    # Initialise some register and a file to do testing on
    reg1 = Register(
        name="test1",
        is_active=True,
        file=["test_mute.txt"],
    )

    reg2 = Register(
        name="test2",
        is_active=False,
        file=["test_mute.txt"],
    )

    reg3 = Register(
        name="test3",
        is_active=True,
        file=["test_mute.txt"],
    )

    # Clean-up if 'test_mute.txt' is already there
    try:
        os.remove("test_mute.txt")
    except:
        pass

    # Append some data to the file


# Generated at 2022-06-24 04:52:29.765086
# Unit test for function mute
def test_mute():
    # Arrange
    mock_register_1 = Register(
        name="TEST",
        address=0x00,
        bitmask=constants.ONE_BYTE_MASK,
        type=constants.UNSIGNED_INT_8,
        reset_value=0xFF,
        set_value=0x00,
        description="Test Register"
    )
    mock_register_2 = Register(
        name="TEST 2",
        address=0x01,
        bitmask=constants.ONE_BYTE_MASK,
        type=constants.UNSIGNED_INT_8,
        reset_value=0xFF,
        set_value=0x00,
        description="Test Register 2"
    )
    mute(mock_register_1, mock_register_2)
    # Act

# Generated at 2022-06-24 04:52:39.303361
# Unit test for function mute
def test_mute():
    """
    This high-order function will be used as a unit test for the mute() method.

    Returns:
        Returns a unit test for the mute method.
    """
    env = simpy.Environment()
    adc_clock = simpy.Store(env)
    adc_data = simpy.Store(env)
    adc_wait = simpy.Store(env)
    adc_done = simpy.Store(env)
    adc_out = simpy.Store(env)
    adc = adc_simulator(env, [adc_data, adc_wait, adc_done], adc_clock, adc_out)

    adc_clock_pin = simpy.Container(env)
    adc_data_pin = simpy.Container(env)

# Generated at 2022-06-24 04:52:49.740012
# Unit test for function mute
def test_mute():
    import os
    import pathlib
    import shutil
    import sys
    import tempfile
    import wave

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    import register_primitive as rp

    # Create a temporary folder
    temp_dir = tempfile.gettempdir()
    temp_dir = pathlib.Path(temp_dir) / "test_mute"
    temp_dir = temp_dir.resolve()
    temp_dir.mkdir(exist_ok=True)
    os.chdir(temp_dir)

    # Mute a single object
    r1 = rp.Register("r1")
    assert r1.muted == False
    mute(r1)
    assert r1

# Generated at 2022-06-24 04:52:57.040007
# Unit test for function unmute
def test_unmute():
    # test that unmute function runs without error
    unmute(c)

    # test that an error gets thrown when an unsupported object is
    # passed to the function
    err = ValueError(
        "The unmute() method can only be used with objects that inherit "
        "from the 'Register class'."
    )
    with pytest.raises(err.__class__) as excinfo:
        unmute(4)
    assert excinfo.value.args[0] == err.args[0]
    assert str(excinfo.traceback[-1].line) == (
        "    with pytest.raises(err.__class__) as excinfo:"
    )

# Generated at 2022-06-24 04:53:03.132260
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute.
    """
    encoder = simple_register.Encoder(name="test")
    xor = simple_register.Xor(encoder)
    shift = simple_register.Shift(encoder)
    mute(xor, shift)
    assert xor.muted
    assert shift.muted


# Generated at 2022-06-24 04:53:12.195781
# Unit test for function mute
def test_mute():
    import random
    from .primitive import UInt
    from .primitive import SInt
    from .primitive import Bool
    from .primitive import Enum
    from .primitive import Slice
    from .primitive import Concat
    from .primitive import Hex

    import sys
    test_types = [UInt, SInt, Bool, Enum, Slice, Concat, Hex]
    test_widths = [i for i in range(1, 16)]
    test_widths.extend([i for i in range(256, 4096, 256)])
    test_widths.extend([i for i in range(65536, 1048576, 65536)])

    for random_test in range(1000):
        random.shuffle(test_types)
        random.shuffle(test_widths)



# Generated at 2022-06-24 04:53:18.276113
# Unit test for function unmute
def test_unmute():
    r = Register(name="unmute_test")
    assert r.muted == False
    r.mute()
    assert r.muted == True
    unmute(r)
    assert r.muted == False
    r.unmute()
    assert r.muted == False
    r.mute()
    assert r.muted == True
    unmute(r, r, r)
    assert r.muted == False

# Generated at 2022-06-24 04:53:27.963680
# Unit test for function mute
def test_mute():
    from .primitive import BitFieldReg
    from .primitive import Register

    class Mock(Register):
        def __init__(self, *args, **kwargs):
            super(Mock, self).__init__(*args, **kwargs)
            self.muted = False

        def mute(self):
            self.muted = True

        def unmute(self):
            self.muted = False

    reg = Mock(width=32)
    bf = BitFieldReg(reg, 4, 3)
    mute(reg, bf)
    assert reg.muted == True
    assert bf.muted == True



# Generated at 2022-06-24 04:53:37.383505
# Unit test for function unmute
def test_unmute():
    a = Register(0x01)
    b = Register(0x02)
    c = Register(0x03)
    # Check if function runs without error
    unmute(a, b, c)

    d = Register(0x04, mute=True)
    e = Register(0x05, mute=True)
    unmute(d, e)
    assert d.muted is False
    assert e.muted is False
    try:
        unmute(a, b, c, d, e)
    except ValueError:
        pass
    # Check if unmute() accepts multiple arguments
    else:
        raise ValueError


# Generated at 2022-06-24 04:53:48.284000
# Unit test for function unmute
def test_unmute():

    from .hierarchical import Rig
    from .grouped import Taps, TapsSection
    from .primitive import Pad, Pin, IO
    from .primitive import Register, RegisterFile, ShiftRegister
    from .primitive import SIPO, SIPO_Taps, PISO
    from .primitive import ROM, ROM_Taps
    from .primitive import Counter
    from .primitive import Ramp

    # Create a Rig instance, which is the root of the hierarchy.
    rig = Rig()

    # Create an address register to drive the memory.
    address = Register(name="Address_Register", width=2)

    # Create some primitive data types to use as memory.
    ram0 = Register(name="RAM_0")
    ram1 = Register(name="RAM_1")
    ram2 = Register(name="RAM_2")

# Generated at 2022-06-24 04:53:59.645435
# Unit test for function mute
def test_mute():
    class TestRegister(Register):
        def __init__(self, name: str, value: int) -> None:
            super().__init__(name)
            self.value = value

        @property
        def value(self) -> int:
            return self.__value

        @value.setter
        def value(self, value: int) -> None:
            if self.is_muted():
                raise ValueError("Trying to set a muted register's value.")
            self.__value = value

    reg = TestRegister("test", 42)
    reg.value = 43
    mute(reg)
    try:
        reg.value = 44
    except ValueError as e:
        assert str(e) == "Trying to set a muted register's value."
    finally:
        unmu

# Generated at 2022-06-24 04:54:09.043680
# Unit test for function unmute
def test_unmute():
    from .primitive import BitRegister, ConstantRegister
    a = BitRegister('a', 0, 4)
    b = BitRegister('b', 4, 8)
    c = ConstantRegister('c', 0, 0x80)
    mute(a, b, c)
    assert a.mute and b.mute and c.mute
    unmute(a, b, c)
    assert not a.mute and not b.mute and not c.mute
    mute(a, b, c)
    assert a.mute and b.mute and c.mute
    

# Generated at 2022-06-24 04:54:16.181495
# Unit test for function unmute
def test_unmute():
    # Test with a single object
    x = Register(5)
    unmute(x)
    assert x._Register__mute == False

    # Test with multiple objects
    x = Register(5)
    y = Register(10)
    z = Register(15)
    unmute(x, y, z)
    assert x._Register__mute == False
    assert y._Register__mute == False
    assert z._Register__mute == False

    # Test with non-register objects
    x = 5
    y = 10
    try:
        unmute(x, y)
    except ValueError:
        return True
    assert False


# Generated at 2022-06-24 04:54:23.943074
# Unit test for function mute
def test_mute():
    """
    Here we test the functionality of the mute() function.
    """
    try:
        mute()
    except ValueError:
        pass
    else:
        raise AssertionError("Expected 'ValueError' in mute().")

    class Object():
        """
        This is a non-register-object that does not inherit from the
        register-class. We want to raise a 'ValueError' for this object.
        """
        def __init__(self):
            pass

    try:
        mute(Object())
    except ValueError:
        pass
    else:
        raise AssertionError("Expected 'ValueError' in mute().")

    class Register(Object):
        """
        This is a register-class object that can be used with mute().
        """
        def __init__(self):
            self.m

# Generated at 2022-06-24 04:54:34.193655
# Unit test for function mute
def test_mute():
    """
    Unit test for the module-level function mute().
    """
    test_reg = Register(name="test_reg", n_bits=4, init_val=0)
    test_reg2 = Register(name="test_reg2", n_bits=4, init_val=0)
    assert test_reg.muted is False
    mute(test_reg, test_reg2)
    assert test_reg.muted is True
    assert test_reg2.muted is True
    unmute(test_reg, test_reg2)
    assert test_reg.muted is False
    assert test_reg2.muted is False
    try:
        mute(test_reg, [])
    except ValueError:
        pass



# Generated at 2022-06-24 04:54:36.816157
# Unit test for function mute
def test_mute():
    pass



# Generated at 2022-06-24 04:54:40.552857
# Unit test for function mute
def test_mute():
    obj_1 = Primitive()
    obj_2 = Primitive()
    mute(obj_1, obj_2)
    assert obj_1._muted and obj_2._muted
    unmute(obj_1, obj_2)



# Generated at 2022-06-24 04:54:45.046661
# Unit test for function unmute
def test_unmute():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self._muted = False

        def mute(self):
            self._muted = True

        def unmute(self):
            self._muted = False

    registers = [TestRegister(), TestRegister()]
    mute(*registers)
    assert all(obj._muted for obj in registers)
    unmute(*registers)
    assert all(not obj._muted for obj in registers)



# Generated at 2022-06-24 04:54:54.912672
# Unit test for function unmute
def test_unmute():
    # Create a bunch of register objects
    reg0 = Register("0", 4, False)
    reg1 = Register("1", 4, False)
    reg2 = Register("2", 4, False)
    reg3 = Register("3", 4, False)
    reg4 = Register("4", 4, False)
    reg5 = Register("5", 4, False)
    reg6 = Register("6", 4, False)
    reg7 = Register("7", 4, False)

    # Mute them
    mute(reg0, reg1, reg2, reg3, reg4, reg5, reg6, reg7)

    # Assert that all the registers should be muted
    assert reg0.is_muted()
    assert reg1.is_muted()
    assert reg2.is_muted()
    assert reg3.is_

# Generated at 2022-06-24 04:55:04.016349
# Unit test for function unmute
def test_unmute():
    # Create 3 registers
    v0 = Register()
    v1 = Register()
    v2 = Register()

    # Mute each register
    mute(v0, v1, v2)

    # Assert that every register is muted
    assert v0.is_mute
    assert v1.is_mute
    assert v2.is_mute

    # Unmute the registers
    unmute(v0, v1, v2)

    # Assert that every register is unmuted
    assert not v0.is_mute
    assert not v1.is_mute
    assert not v2.is_mute


# Generated at 2022-06-24 04:55:07.786170
# Unit test for function mute
def test_mute():
    """Unit test for method 'mute'."""
    # Create a register
    reg1 = Register(16)
    # Create a second register
    reg2 = Register(16)
    # Mute both registers
    mute(reg1, reg2)
    # Check if both registers are muted
    assert reg1.muted and reg2.muted


# Generated at 2022-06-24 04:55:11.562907
# Unit test for function mute
def test_mute():
    reg1 = Register(0x0F)
    reg2 = Register(0x07)
    mute(reg1, reg2)
    assert reg1.is_muted() and reg2.is_muted()


# Generated at 2022-06-24 04:55:15.918973
# Unit test for function mute
def test_mute():
    from .simulation import creat_basic_setup

    sig, vdd, gnd = creat_basic_setup()
    reg = Register(sig=sig, vdd=vdd, gnd=gnd)
    assert reg.state == "0b0000000000000000"
    mute(reg)
    assert reg.state == "0b0000000000000000"
    reg.en = 1
    assert reg.state == "0b0000000000000000"



# Generated at 2022-06-24 04:55:21.949976
# Unit test for function mute
def test_mute():
    # create register-object
    sdo = Register(0x1234, 0x5678, 0x9abc, 0xdef0, 1, 'sdo')

    # check
    assert sdo.mute_status() == False, "must be False"

    # mute it
    mute(sdo)

    # check
    assert sdo.mute_status() == True, "must be True"



# Generated at 2022-06-24 04:55:26.929873
# Unit test for function unmute
def test_unmute():
    mock_port = type('serial.Serial', (), {'write': Mock()})
    # initialize register
    r1 = Register(1, mock_port, 'test')
    assert r1.state == 0

    # set some values
    r1.open()
    r1.input([0, 1])
    r1.state = 127
    assert r1.state == 127

    # mute and check that state is zero
    r1.mute()
    assert r1.state == 0

    # unmute and check that old state is available again
    # for now, only the first sub-function of unmute is tested
    r1.unmute()
    assert r1.state == 127


# Generated at 2022-06-24 04:55:27.751997
# Unit test for function unmute
def test_unmute():
    assert unmute() == None


# Generated at 2022-06-24 04:55:31.104475
# Unit test for function mute
def test_mute():
    from .primitive import Register
    reg1 = Register(mute=True)
    reg2 = Register(mute=False)
    mute(reg1, reg2)
    assert reg1.muted == True
    assert reg2.muted == True



# Generated at 2022-06-24 04:55:38.062231
# Unit test for function unmute
def test_unmute():
    from .connections import DB

    class TestRegister(Register):
        target = 2
        source = DB.test_table.test_boolean_field
        description = "Test register"
        upper_limit = 1
        lower_limit = 0
        mute_after_cycles = 5
        cycle_time = 1

    a = TestRegister()
    mute(a, a)
    a.unmute()
    assert a.muted == False
    assert a.iterations_left_for_mute == 0



# Generated at 2022-06-24 04:55:42.315478
# Unit test for function mute
def test_mute():
    try:
        mute(5)
    except ValueError:
        pass
    except Exception:
        assert False
    else:
        assert False
    try:
        mute(Register(5, 5))
    except ValueError:
        assert False
    except Exception:
        assert False
    else:
        pass

# Generated at 2022-06-24 04:55:43.215322
# Unit test for function unmute
def test_unmute():
    assert True

# Generated at 2022-06-24 04:55:51.414604
# Unit test for function unmute
def test_unmute():
    """
    Tests the function 'unmute()' function.

    :return: None
    """
    # test if function works on registers that are already muted
    r1 = Register(value=0x25)
    r2 = Register(value=0x00)
    mute(r1, r2)
    assert r1.mute == True
    assert r2.mute == True
    unmute(r1, r2)
    assert r1.mute == False
    assert r2.mute == False
    # test if function works on registers that are already not muted
    unmute(r1, r2)
    assert r1.mute == False
    assert r2.mute == False


# Generated at 2022-06-24 04:55:57.906308
# Unit test for function mute
def test_mute():
    from . import register
    from . import phase_mask

    reg_01 = phase_mask.PhaseMask()
    mute(reg_01)
    assert reg_01.muted == 1

    reg_02 = register.Register(length=5, label="Test")
    mute(reg_01, reg_02)
    assert reg_01.muted == 1
    assert reg_02.muted == 1



# Generated at 2022-06-24 04:55:59.937040
# Unit test for function unmute
def test_unmute():
    reg = Register(2, False, False)
    reg.unmute()
    assert reg.unmuted is True

# Generated at 2022-06-24 04:56:04.369373
# Unit test for function mute
def test_mute():
    import itertools
    mock = Mock()

    mute(mock)
    mock.mute.assert_called_once_with()

    unmute(mock)
    mock.unmute.assert_called_once_with()

    # check that the mute/unmute functions works with
    # multiple objects too
    for i in range(1, 5):
        mock = [Mock() for _ in range(i)]
        mute(*mock)
        for m in mock:
            m.mute.assert_called_once_with()

        unmute(*mock)
        for m in mock:
            m.unmute.assert_called_once_with()

    with pytest.raises(ValueError):
        mute(itertools.count())

# Generated at 2022-06-24 04:56:06.709689
# Unit test for function unmute
def test_unmute():
    r = Register(2, 4)
    assert r.muted
    unmute(r)
    assert not r.muted



# Generated at 2022-06-24 04:56:17.141720
# Unit test for function unmute
def test_unmute():
    import pytest
    from .primitive import BinaryRegister
    from .primitive import BinaryRegisterArray
    from .primitive import IntegerRegister
    from .primitive import IntegerRegisterArray
    from .primitive import IndexedRegister

    reg = BinaryRegister(
        register_type='R',
        register_address=0,
        register_subaddress=1,
        label='test',
        bit_length=2,
        internal_storage=False,
        storage_register_data_type='uint8'
    )


# Generated at 2022-06-24 04:56:21.466932
# Unit test for function mute
def test_mute():
    from .library import Library
    from .pad import Pad
    from .register import Register

    # Create an empty library
    lib = Library("Test Library")
    reg = Register(lib, "Test Register")

    # Mute the register and check that the pads are muted too
    mute(reg)
    assert reg.mute_value == True
    for pad in lib.pads.values():
        assert pad.mute_value == True



# Generated at 2022-06-24 04:56:27.765556
# Unit test for function mute
def test_mute():
    """
    Test the mute() function.
    """
    # Test with multiple IntRegister objects
    int_registers = [IntRegister(0) for _ in range(10)]
    mute(*int_registers)
    for obj in int_registers:
        assert obj.is_muted()

    # Test with multiple BoolRegister objects
    bool_registers = [BoolRegister() for _ in range(10)]
    mute(*bool_registers)
    for obj in bool_registers:
        assert obj.is_muted()

    # Test with a mixture of IntRegister and BoolRegister objects
    registers = int_registers + bool_registers
    mute(*registers)
    for obj in registers:
        assert obj.is_muted()

    # Test with other objects that do not inherit from the Register class
    err

# Generated at 2022-06-24 04:56:38.711476
# Unit test for function mute
def test_mute():
    """
    This is a test for the mute() function.
    """
    from .primitive import ByteRegister, ByteField
    from .devices import MidiDevice

    def toggle_byte_field(port: MidiDevice, field: ByteField):
        """
        A simple function for toggling a field.
        """
        print(f"Toggling {field.name} field.")
        if field.muted:
            field.unmute(port)
        else:
            field.mute(port)

    port: MidiDevice = MidiDevice(None)
    register_a: ByteRegister = ByteRegister('A', 0x10, port)
    register_b: ByteRegister = ByteRegister('B', 0x20, port)
    register_c: ByteRegister = ByteRegister('C', 0x30, port)
   

# Generated at 2022-06-24 04:56:39.686723
# Unit test for function unmute
def test_unmute():
    assert unmute.__doc__ is not None

# Generated at 2022-06-24 04:56:47.094701
# Unit test for function unmute
def test_unmute():
    from .primitive import ControlWord
    from .primitive import MuxRegister
    from .primitive import Register

    a = Register(4, "a", 0x00)
    b = ControlWord(4, "b", 0x01, [a])
    c = MuxRegister(4, "c", 0x02, [b], {0: 0, 1: 1, 2: 2, 3: 3})
    d = ControlWord(4, "d", 0x03, [c])

    a_muted = False
    b_muted = False
    c_muted = False
    d_muted = False

    def mute_a():
        nonlocal a_muted
        a_muted = True

    def mute_b():
        nonlocal b_muted
        b_muted = True


# Generated at 2022-06-24 04:56:52.682450
# Unit test for function mute
def test_mute():
    a = Register(1)
    b = Register(sys.maxsize)
    c = Register(a.value + b.value)
    mute(a, b, c)
    assert a.exclude == b.exclude == c.exclude == True
    unmute(a, b, c)


# Generated at 2022-06-24 04:56:53.171557
# Unit test for function mute
def test_mute():
    pass

# Generated at 2022-06-24 04:56:59.752447
# Unit test for function unmute
def test_unmute():
    from .primitive import Bit
    from .primitive import Interconnect
    from .primitive import Register
    from .primitive import RegisterFile

    vcc = Bit(1)
    gnd = Bit(0)

    class MyRegister(Register):

        bit = Bit
        interconnect = Interconnect
        register = Register
        registerfile = RegisterFile

        def __init__(self, name="Test"):
            super().__init__(name, width=8)
            self.add_pin("Q", "output")
            self.add_pin("D", "input")
            self.add_pin("Clk", "input")
            self.add_pin("M", "input")

            self.add_pin("Q2", "output")
            self.add_pin("D2", "input")
            self.add_pin

# Generated at 2022-06-24 04:57:10.000353
# Unit test for function mute
def test_mute():
    from .attributes import Conversions
    from .primitive import Register

    data = [1, 2, 3]
    attr = Conversions({'bit_order': 'lsb-first', 'byte_order': 'little-endian'})

    test_reg1 = Register(data=data, attr=attr)
    test_reg2 = Register(data=data, attr=attr)

    assert test_reg1.mute_flag
    assert test_reg2.mute_flag

    mute(test_reg1, test_reg2)

    assert test_reg1.mute_flag
    assert test_reg2.mute_flag

    try:
        mute(test_reg1, test_reg2, 'test')
    except ValueError:
        pass



# Generated at 2022-06-24 04:57:18.263482
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from nmigen import *
    from nmigen.sim import *

    m = Module()
    r0 = Register(name="r0", width=8, init=0)
    r1 = Register(name="r1", width=8, init=0)
    r2 = Register(name="r2", width=8, init=0)
    r3 = Register(name="r3", width=8, init=0)
    m.submodules.r0 = r0
    m.submodules.r1 = r1
    m.submodules.r2 = r2
    m.submodules.r3 = r3


# Generated at 2022-06-24 04:57:26.574240
# Unit test for function mute
def test_mute():
    mute(A, B, C, D)
    assert A.muted == True
    assert B.muted == True
    assert C.muted == True
    assert D.muted == True

    # Test if the function throws an error
    # if the wrong object type is passed
    try:
        mute(1)
    except ValueError as e:
        assert str(e) == expected_err_msg
    except Exception as e:
        raise AssertionError(
            "An unexpected type of exception was found: {}".format(e)
        )
    else:
        raise AssertionError(
            "mute() didn't throw an error, even though the passed object "
            "type was wrong."
        )


# Generated at 2022-06-24 04:57:29.189755
# Unit test for function mute
def test_mute():
    test_reg = Reg16()
    mute(test_reg)
    assert test_reg._mute == True

    unmute(test_reg)
    assert test_reg._mute == False

# Generated at 2022-06-24 04:57:30.042467
# Unit test for function unmute
def test_unmute():
    pass


# Generated at 2022-06-24 04:57:38.304450
# Unit test for function unmute
def test_unmute():

    from .event import Event

    class CustomRegister(Register):
        def on_register_change(self, event: Event):
            print(
                "I'm a custom register-class and my value changed to {}!".format(
                    event.new
                )
            )

    obj = CustomRegister(name="CustomRegister", size=8, reset=0)
    obj.mute()
    obj.value = 1
    unmute(obj)
    obj.value = 2

    # Run the test:
    #   python3 -m pyccel.stdlib.registers test_unmute

# Generated at 2022-06-24 04:57:41.803248
# Unit test for function mute
def test_mute():
    obj1 = Register(0x75, 1, "name")
    obj2 = Register(0x74, 1, "name")
    mute(obj1, obj2)
    assert obj1.muted is True
    assert obj2.muted is True



# Generated at 2022-06-24 04:57:45.475721
# Unit test for function mute
def test_mute():
    test_obj = register()
    test_obj.mute()
    assert test_obj.muted is True


# Generated at 2022-06-24 04:57:51.122943
# Unit test for function mute
def test_mute():
    class Test(Register):
        def __init__(self):
            super().__init__()
            self.q.next = 1
    a = Test()
    mute(a)
    a.q.next = 0
    assert a.q == 1
    unmute(a)
    a.q.next = 0
    assert a.q == 0


if __name__ == "__main__":
    test_mute()

# Generated at 2022-06-24 04:57:54.533530
# Unit test for function mute
def test_mute():
    a = Register(49)
    b = Register(50)
    assert a.get() == 49
    assert b.get() == 50
    mute(a, b)
    assert a.get() == 0
    assert b.get() == 0



# Generated at 2022-06-24 04:57:57.802664
# Unit test for function mute
def test_mute():
    r = Register(name="r", size=8, value=0b01010101)
    r.mute()
    assert r.muted
    mute(r)
    assert r.muted


# Generated at 2022-06-24 04:58:05.134892
# Unit test for function unmute
def test_unmute():
    """
    Unit testing for the unmute(...) function.
    """
    # Construct one register to be muted
    try:
        reg = Register(
            name="mutable",
            addr=0,
            bit_size=8,
            bit_offset=0,
            mode="both",
            value=0
        )

        print(
            "Testing unmute(...) function...\n"
            "Register data:\n" + reg.__str__()
        )
    except ValueError as err:
        print(
            "The test for the unmute(...) function has failed.\n"
            "Reason: %s" % err
        )
        return -1

    #  Mute the register

# Generated at 2022-06-24 04:58:08.487701
# Unit test for function mute
def test_mute():
    a = ByteRegister(0)
    mute(a)
    assert a.mute()
    assert a.enable()



# Generated at 2022-06-24 04:58:17.719579
# Unit test for function mute
def test_mute():
    from random import randint
    from math import ceil

    from .dimensions import Distance
    from .data import Data
    from .primitive import Register

    class MyRegister(Register):

        def __init__(self, *arg):
            Register.__init__(self, *arg)

        @property
        def x(self):
            return self.data.get('x')

    x = MyRegister([
        {'x': Distance(m=1)},
        {'x': Distance(m=2)},
        {'x': Distance(m=3)},
        {'x': Distance(m=4)},
        {'x': Distance(m=5)}
    ])
    mute(x)
    assert x.muted
    unmute(x)
    assert not x.muted

# Generated at 2022-06-24 04:58:20.078647
# Unit test for function unmute
def test_unmute():
    # Arrange
    r = Register("class mute")
    # Act
    mute(r)
    unmute(r)
    # Assert
    assert r._muted == False

# Generated at 2022-06-24 04:58:23.620140
# Unit test for function unmute
def test_unmute():
    unmute(*[Register(name="bla", number_of_bits=10, init_val=0),
             Register(name="bla2", number_of_bits=10, init_val=0),
             Register(name="bla3", number_of_bits=10, init_val=0),
             ])

# Generated at 2022-06-24 04:58:30.187188
# Unit test for function unmute
def test_unmute():
    regs = [Register(nibbles=1), Register(nibbles=2)]
    mute(*regs)
    unmute(*regs)
    assert regs[0].mute_state == False
    assert regs[1].mute_state == False


if __name__ == "__main__":
    test_unmute()

# Generated at 2022-06-24 04:58:40.204085
# Unit test for function unmute
def test_unmute():
    from .primitive import Register

    r1 = Register.Register(name="register1")
    r2 = Register.Register(name="register2")
    r3 = Register.Register(name="register3")
    r4 = Register.Register(name="register4")

    mute(r1, r2)
    assert r1.is_muted() == True
    assert r2.is_muted() == True
    assert r3.is_muted() == False
    assert r4.is_muted() == False

    unmute(r1, r2, r3)
    assert r1.is_muted() == False
    assert r2.is_muted() == False
    assert r3.is_muted() == False
    assert r4.is_muted() == False

# Generated at 2022-06-24 04:58:40.900642
# Unit test for function unmute
def test_unmute():
    assert unmute() == None


# Generated at 2022-06-24 04:58:46.290670
# Unit test for function mute
def test_mute():
    from .primitive import Register

    reg = Register(0, "reg")
    assert not reg.is_muted
    mute(reg)
    assert reg.is_muted



# Generated at 2022-06-24 04:58:50.840980
# Unit test for function mute
def test_mute():
    r = Register(0)
    r.enable_mute_mode()
    mute(r)
    assert(r.mute)


# Generated at 2022-06-24 04:59:01.269384
# Unit test for function unmute
def test_unmute():
    """
    Silly unit test for the unmute() function.
    """
    from .basic import Int8
    from .parallel import Registers

    reg1 = Int8()
    reg2 = Int8()
    reg3 = Int8()

    reg_list = Registers(reg1, reg2, reg3)

    reg_list.mute()

    assert all(reg.mute_value == reg.value for reg in reg_list)

    unmute(reg1, reg2, reg3)

    assert reg1.mute_value != reg1.value
    assert reg2.mute_value != reg2.value
    assert reg3.mute_value != reg3.value



# Generated at 2022-06-24 04:59:02.192444
# Unit test for function unmute
def test_unmute():
    try:
        unmute(1)
    except Exception as e:
        assert type(e) == ValueError

# Generated at 2022-06-24 04:59:05.465733
# Unit test for function mute
def test_mute():
    """
    Unit test for function 'mute'.
    """
    obj = []
    for i in range(20):
        obj.append(Register("reg{}".format(i), 0, 0, 1024))

    mute(*obj)
    for i in range(20):
        assert obj[i].is_muted == True



# Generated at 2022-06-24 04:59:16.038809
# Unit test for function unmute
def test_unmute():
    from .primitive import Digit
    from .primitive import Digit_10
    from .primitive import Reg_8
    from .primitive import Reg_16
    from .primitive import Ram
    from .primitive import Ram_8
    from .primitive import Ram_16
    from .primitive import Flag
    from .primitive import Flag_8
    from .primitive import Cpu
    from .primitive import Cpu_8
    from .primitive import Cpu_16
    from .primitive import Port
    from .primitive import Port_8
    from .primitive import Port_16
    from .primitive import Led
    from .primitive import Led_8
    from .primitive import Led_16
    from .primitive import Register


# Generated at 2022-06-24 04:59:24.785186
# Unit test for function unmute
def test_unmute():
    """Unit tests for the function unmute."""
    class Test(Register):
        def __init__(self, mute=None):
            super().__init__(mute)
    a = Test()
    b = Test(mute=False)
    unmute(a, b)
    assert a.is_muted() is False
    assert b.is_muted() is False
    a.mute()
    b.mute()
    assert a.is_muted() is True
    assert b.is_muted() is True