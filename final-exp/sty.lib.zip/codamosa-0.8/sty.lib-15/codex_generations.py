

# Generated at 2022-06-12 09:37:40.170603
# Unit test for function mute
def test_mute():
    from .primitive import Register

    reg = Register(0, 0)
    reg.mute()
    assert reg.isMuted()



# Generated at 2022-06-12 09:37:46.750710
# Unit test for function mute
def test_mute():
    """
    Test that it can mute objects that inherit from the 'Register' class.
    """
    class MockRegister(Register):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    reg1 = MockRegister("reg1", 0, 0, 0)
    reg2 = MockRegister("reg2", 0, 0, 0)
    mute(reg1, reg2)

    assert reg1.mute_status == True, "mute() did not mute the register object."
    assert reg2.mute_status == True, "mute() did not mute the register object."



# Generated at 2022-06-12 09:37:52.713465
# Unit test for function unmute
def test_unmute():
    import numpy as np
    from .primitive import Register
    from .setup import setup
    from .gate import H, CNOT

    def test_one_qbit(q_0 : Register) -> np.ndarray:
        """
        Test function to check if the unmute function works properly.

        :param q_0: q_0 is the register-object to be used.
        :return: Returns the state of the register.
        """
        q_0.mute()

        q_0.H()
        q_0.CNOT(ctr=0, tgt=1)
        q_0.CNOT(ctr=1, tgt=0)
        q_0.CNOT(ctr=0, tgt=1)

        # Check if the register is still muted

# Generated at 2022-06-12 09:38:01.530278
# Unit test for function unmute
def test_unmute():
    from ratcave import WavefrontReader
    from .primitive import register
    from .material import PhongMaterial

    # Load in some objects
    obj_path = "tests/wavefront/teapot.obj"
    obj_reader = WavefrontReader(obj_path, scale=.5)

    # Create a shader for the objects
    shaders = """
        #version 330 core
        uniform mat4 projection;
        uniform mat4 modelview;
        
        in vec3 position;
        in vec3 normal;
        
        out vec3 fragNormal;
        out vec3 fragPosition;
        
        void main(){
            fragNormal = normal;
            fragPosition = position;
            gl_Position = projection * modelview * vec4(position, 1.);
        }
        """

# Generated at 2022-06-12 09:38:04.376036
# Unit test for function unmute
def test_unmute():
    # create register
    test_reg = Register(0, 'test_reg', 0, 2**8)

    unmute(test_reg)
    assert test_reg.muted == False, 'Register was not unmuted'



# Generated at 2022-06-12 09:38:06.426344
# Unit test for function mute
def test_mute():
    reg = Register(constant = True, value = 123)
    mute(reg)
    assert reg.muted



# Generated at 2022-06-12 09:38:07.454015
# Unit test for function mute
def test_mute():
    from .primitive import Register
    reg = Register()
    mute(reg)


# Generated at 2022-06-12 09:38:08.954624
# Unit test for function mute
def test_mute():
    obj = Register(0)
    mute(obj)
    assert obj.muted == True



# Generated at 2022-06-12 09:38:14.847009
# Unit test for function unmute
def test_unmute():
    """
    Not testing that the object is muted, as this is done in the unit test by
    the object itself, so if it fails there, no point in testing it here.
    """
    # Mute a register
    test_reg = Register(name="test_register")
    test_reg.mute()
    # Unmute the register
    unmute(test_reg)
    assert not test_reg.muted


# Generated at 2022-06-12 09:38:18.659690
# Unit test for function mute
def test_mute():
    a0 = Register(test=True)
    a1 = Register(test=True)

    mute(a0, a1)
    assert not a0._enabled
    assert not a1._enabled

    unmute(a0, a1)
    assert a0._enabled
    assert a1._enabled