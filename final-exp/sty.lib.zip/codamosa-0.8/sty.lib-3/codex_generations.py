

# Generated at 2022-06-12 09:37:43.371783
# Unit test for function mute
def test_mute():
    r1 = Register()
    r2 = Register()
    r3 = Register()
    r1.value = 1
    r2.value = 2
    r3.value = 3
    mute(r1, r2, r3)
    assert isinstance(r1.mute_value, int)
    assert r1.mute_value == 1
    assert r1.value == 0
    assert isinstance(r2.mute_value, int)
    assert r2.mute_value == 2
    assert r2.value == 0
    assert isinstance(r3.mute_value, int)
    assert r3.mute_value == 3
    assert r3.value == 0


# Generated at 2022-06-12 09:37:46.088337
# Unit test for function unmute
def test_unmute():
    """Test for unmute method."""
    obj = Register("Test object", 11)
    assert obj.muted is False
    obj.mute()
    assert obj.muted is True
    unmute(obj)
    assert obj.muted is False

# Generated at 2022-06-12 09:37:52.545992
# Unit test for function unmute
def test_unmute():
    class TestRegister(Register):
        def __init__(self, *args):
            super().__init__(*args)
            self.zero_check = 0

        def write(self, value):
            self.zero_check ^= value

    tr1 = TestRegister(0)
    tr2 = TestRegister(0)
    tr3 = TestRegister(0)
    assert tr1.muted == False
    assert tr2.muted == False
    assert tr3.muted == False
    mute(tr1, tr2, tr3)
    assert tr1.muted == True
    assert tr2.muted == True
    assert tr3.muted == True
    tr1.write(1)
    tr2.write(0x0F)
    tr3.write(1)
    assert tr1.zero_check

# Generated at 2022-06-12 09:37:58.260535
# Unit test for function mute
def test_mute():
    from .math import DRegister
    reg_1 = DRegister(3, -5)
    reg_2 = DRegister(1, 4)
    reg_3 = DRegister(2, -2)
    
    mute(reg_2, reg_3)
    
    assert str(reg_2) == 'Mute'
    assert str(reg_3) == 'Mute'
    assert str(reg_1) == '3.0 -5.0'
    

# Generated at 2022-06-12 09:37:58.909430
# Unit test for function unmute
def test_unmute():
    pass

# Generated at 2022-06-12 09:38:06.339425
# Unit test for function mute
def test_mute():
    # This register is muted
    reg = Register(16, "test_mute", "test_mute", (0, 1), True)
    assert reg.muted == True

    # This register is unmuted
    reg = Register(16, "test_mute", "test_mute", (0, 1), False)
    assert reg.muted == False
    
    # This register is muted
    reg = Register(16, "test_mute", "test_mute", (0, 1))
    assert reg.muted == False
    mute(reg)
    assert reg.muted == True
    
    # These registers are muted
    reg1 = Register(16, "test_mute", "test_mute", (0, 1))

# Generated at 2022-06-12 09:38:13.549401
# Unit test for function mute
def test_mute():
    import pytest

    def test_mute_1():
        r = Register(name='test', max=10, min=0, default=5)
        assert not r.is_muted
        mute(r)
        assert r.is_muted

    def test_mute_2():
        r = Register(name='test', max=10, min=0, default=5)
        assert not r.is_muted
        mute(r)
        with pytest.raises(ValueError):
            mute(6)
        assert r.is_muted

    def test_mute_3():
        r = Register(name='test', max=10, min=0, default=5)
        assert not r.is_muted
        mute(r)
        r.mute()
        assert r.is_m

# Generated at 2022-06-12 09:38:16.686200
# Unit test for function mute
def test_mute():
    r = Register([0, 1, 0, 1, 0], name="test_mute")
    r.mute()
    assert r.is_muted()
    mute(r)
    assert r.is_muted()


# Generated at 2022-06-12 09:38:19.056047
# Unit test for function unmute
def test_unmute():
    """
    Test for function unmute.
    """
    reg = Register(4, 0)
    mute(reg)
    unmute(reg)
    assert reg.mute() == False

# Generated at 2022-06-12 09:38:21.772470
# Unit test for function unmute
def test_unmute():
    test_register = Register(10)
    mute(test_register)
    unmute(test_register)
    assert not test_register.mute_state
