

# Generated at 2022-06-12 09:37:40.334326
# Unit test for function mute
def test_mute():
    """Test the mute() function."""
    from .primitive import Register
    reg = Register()
    assert reg.value == 0
    reg.value = 1
    assert reg.value == 0
    mute(reg)
    reg.value = 1
    assert reg.value == 1


# Generated at 2022-06-12 09:37:42.789682
# Unit test for function mute
def test_mute():
    assert_raises(ValueError, mute, 5)
    assert_raises(ValueError, mute, 'Hello')
    assert_raises(ValueError, mute, None)



# Generated at 2022-06-12 09:37:43.683991
# Unit test for function mute
def test_mute():
    assert mute


# Generated at 2022-06-12 09:37:46.042683
# Unit test for function unmute
def test_unmute():
    """
    Tests whether the unmute() function works correctly.
    """
    from .hardware import Gate
    m = Gate()
    m.mute()
    unmute(m)


# Generated at 2022-06-12 09:37:47.314687
# Unit test for function mute
def test_mute():
    pass


# Generated at 2022-06-12 09:37:48.965699
# Unit test for function unmute
def test_unmute():
    """
    This function tests the functionality of the unmute() function.
    """
    if not unmute():
        print("OK")
    else:
        print("ERROR")

# Generated at 2022-06-12 09:37:57.664456
# Unit test for function unmute
def test_unmute():
    from .primitive import Register as R
    # Test unmute() with two instances of type Register
    data = R(8, "data")
    status = R(8, "status")
    assert data.muted is False
    assert status.muted is False
    mute(data)
    mute(status)
    assert data.muted is True
    assert status.muted is True
    unmute(data)
    unmute(status)
    assert data.muted is False
    assert status.muted is False
    # Test unmute() with one register and one wrong instance
    mute(data)
    try:
        unmute(data, 2)
    except ValueError:
        pass
    else:
        assert False
    assert data.muted is True
    unmute(data)
    assert data.muted is False

# Generated at 2022-06-12 09:38:05.545238
# Unit test for function mute
def test_mute():
    from .primitive import Input, Output
    from .primitive import UInt, SInt
    for width in range(1, 5):
        inputobj = Input(width=width)
        outputobj = Output(width=width)
        for obj in (inputobj, outputobj):
            assert obj.muted == False
        assert inputobj.value is None
        assert inputobj() is None
        assert outputobj.value is None
        assert outputobj() is None

        assert inputobj.set_value(1) is None
        assert inputobj.value == 1
        assert inputobj() == 1

        mute(inputobj, outputobj)

        assert inputobj.muted == True
        assert inputobj.set_value(0) is None
        assert inputobj.value == 0
        assert inputobj() == 1
        assert outputobj.muted

# Generated at 2022-06-12 09:38:07.207198
# Unit test for function mute
def test_mute():
    reg = Register()
    mute(reg)
    assert reg.is_muted()



# Generated at 2022-06-12 09:38:14.565455
# Unit test for function unmute
def test_unmute():
    class Test(Register):
        def __init__(self, name, mute, value=0):
            Register.__init__(self, name, mute, value)

        def get_value(self):
            return self._value

        def set_value(self, value):
            self._value = value

    BOOL = Test("bit1", True, 1)
    BOOL2 = Test("bit2", True, 1)
    unmute(BOOL, BOOL2)

    assert(not BOOL.get_muted())
    assert(not BOOL2.get_muted())
