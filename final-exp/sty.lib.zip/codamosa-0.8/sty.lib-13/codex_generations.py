

# Generated at 2022-06-12 09:37:38.656481
# Unit test for function mute
def test_mute():
    from .primitive import UnitTest
    mute(UnitTest())
    assert UnitTest().is_muted


# Generated at 2022-06-12 09:37:41.509643
# Unit test for function mute
def test_mute():
    """
    If a register-object is not muted, the mute() function shall mute it.
    """
    r = Register()
    assert not r.is_muted()
    mute(r)
    assert r.is_muted()



# Generated at 2022-06-12 09:37:44.047044
# Unit test for function mute
def test_mute():
    obj = Register(name='foo', default=False)
    assert not obj.muted
    obj.mute()
    assert obj.muted
    mute(obj)
    assert obj.muted



# Generated at 2022-06-12 09:37:51.280417
# Unit test for function mute
def test_mute():
    from .primitive import Bit, Int

    a = Int(16)
    b = Int(16)

    mute(a)

    assert a.value == 0
    assert b.value == 0

    a.value = 7

    assert a.value == 7
    assert b.value == 0
    assert a.active == False

    b.value = 9

    assert a.value == 7
    assert b.value == 9
    assert b.active == False

    unmute(a, b)

    assert a.value == 7
    assert b.value == 9
    assert a.active == True
    assert b.active == True

    a.value = 0

    assert a.value == 0
    assert b.value == 9
    assert a.active == True
    assert b.active == True

    b.value = 0


# Generated at 2022-06-12 09:37:56.530727
# Unit test for function unmute
def test_unmute():
    """
    This function tests if the unmute function works.
    """
    reg1 = Register(name = "reg1")
    reg2 = Register(name = "reg2")

    reg1.mute()
    reg2.mute()

    unmute(reg1, reg2)

    assert reg1.mute_counter == 0
    assert reg2.mute_counter == 0


# Generated at 2022-06-12 09:38:01.399468
# Unit test for function mute
def test_mute():
    """
    Test whether the function mute() works correctly.

    :return: None.
    """
    from .address import Address
    from .bit_vector import BitVector

    test = BitVector(block_name="Test", width=16)
    addr = Address(width=8, block_name="Test")

    mute(addr)
    mute(test)

    assert(addr.is_muted() == 1)
    assert(test.is_muted() == 1)

# Generated at 2022-06-12 09:38:04.630381
# Unit test for function unmute
def test_unmute():
    print("test_unmute()")
    print("==============")
    objects = unmute(Register(0), Register(1), Register(2))
    assert objects == [True, False, True]
    print("=============")
    print(" ")
    
    

# Generated at 2022-06-12 09:38:11.633134
# Unit test for function unmute
def test_unmute():
    register = Register(8, signed=False)
    register[0] = 0
    register[1] = 1
    register[2] = 0
    register[3] = 1
    register[4] = 0
    register[5] = 1
    register[6] = 0
    register[7] = 1

    result = register.int()
    assert result == 0b10101010, "Incorrect result from function unmute()."
    unmute(register)
    result = register.int()
    assert result == 0b10101010, "Incorrect result from function unmute()."
    assert register.unmuted, "Incorrect result from function unmute()."



# Generated at 2022-06-12 09:38:16.310535
# Unit test for function unmute
def test_unmute():
    """Test case for unmute()"""
    from .tests.TestRegister import TestRegister
    tr = TestRegister()
    mute(tr)
    if not tr.isMuted():
        raise ValueError("Mute failed.")
    unmute(tr)
    if tr.isMuted():
        raise ValueError("Unmute failed.")



# Generated at 2022-06-12 09:38:19.335257
# Unit test for function unmute
def test_unmute():
    from .primitive import SimpleRegister
    x = SimpleRegister()
    mute(x)
    assert x.is_muted() is True
    unmute(x)
    assert x.is_muted() is False

