

# Generated at 2022-06-12 09:37:44.287619
# Unit test for function mute
def test_mute():
    from .primitive import BitField, BitFieldRegister
    from .primitive import UIntVal

    # Create the test objects
    class Reg0(BitFieldRegister):

        field_0 = BitField(0, 4)
        field_1 = BitField(5, 7)

    class Reg1(BitFieldRegister):

        field_0 = BitField(0, 5)
        field_1 = BitField(5, 7)

    reg0 = Reg0(0x0)
    reg1 = Reg1(0x1)

    # Test mute()
    mute(reg0, reg1)

    assert reg0.is_muted()
    assert reg1.is_muted()

    # Test unmute()
    unmute(reg0, reg1)

    assert not reg0.is_muted()
    assert not reg1

# Generated at 2022-06-12 09:37:47.695221
# Unit test for function mute
def test_mute():
    err = "The mute() method can only be used with objects that inherit " \
          "from the 'Register class'."
    reg = Register(0x00, 0x00)
    reg.mute()
    mute(None)
    assert reg.is_muted() == True


# Generated at 2022-06-12 09:37:52.368830
# Unit test for function unmute
def test_unmute():
    # Create a new register-object
    reg = Register(
        name="TestRegister",
        width=8,
        offset=0x1000,
        description="This is a test register"
    )
    # check whether the register is actually muted after muted function
    # has been called
    assert reg.is_muted is False
    reg.mute()
    assert reg.is_muted is True
    reg.unmute()
    assert reg.is_muted is False



# Generated at 2022-06-12 09:37:55.708329
# Unit test for function unmute
def test_unmute():
    s = Register(bits=8, autoreset=False, init=0b11111111, mute=True)
    unmute(s)
    assert (not s.mute)


# Generated at 2022-06-12 09:38:00.361462
# Unit test for function unmute
def test_unmute():
    # Create a register-object for testing
    reg = Register('TestRegister')
    reg.register_frame(frame_id='foo')

    # Mute the register
    mute(reg)

    # Check if the mute-attribute is set
    assert reg.mute_level == 1

    # Unmute the register
    unmute(reg)

    # Check if the mute-attribute is set again
    assert reg.mute_level == 0

# Generated at 2022-06-12 09:38:04.626751
# Unit test for function mute
def test_mute():
    """
    Unit test for function mute
    """
    p = Register(name = 'p', value = 0x8)
    q = Register(name = 'q', value = 0x0)
    p.mute()
    assert p.muted() == True
    mute(q)
    assert q.muted() == True



# Generated at 2022-06-12 09:38:12.627236
# Unit test for function mute
def test_mute():
    # simple test that values are set as expected
    # start with list of registers
    reg1 = Register(
        name='Turn Signal',
        address=0x100,
        bit_layout=BitLayout(
            Bit(name='Right',  address=0x100, bit_num=0),
            Bit(name='Left',   address=0x100, bit_num=1),
            Bit(name='Rear',   address=0x100, bit_num=2),
            Bit(name='Front',  address=0x100, bit_num=3),
            Bit(name='Center', address=0x100, bit_num=4),
        ),
    )

# Generated at 2022-06-12 09:38:17.231768
# Unit test for function mute
def test_mute():
    from . import register
    from .primitive import Register

    a = register(1,5)
    b = Register(1,5)
    c = Register(1,5)
    mute(a,b,c)
    assert a.muted, "Not muted."
    assert b.muted, "Not muted."
    assert c.muted, "Not muted."


# Generated at 2022-06-12 09:38:21.107221
# Unit test for function unmute
def test_unmute():
    from .primitive import REG16
    from .primitive import ValError

    reg_a = REG16("pca", 0x02)
    reg_a.unmute()

    try:
        reg_a.set_value(0xFFFF)
        assert False

    except ValError:
        assert True

    except:
        assert False

# Generated at 2022-06-12 09:38:27.896702
# Unit test for function unmute
def test_unmute():
    from .primitive import SQR1
    from .primitive import TRISB
    from .primitive import OSCCONbits
    assert OSCCONbits.IRCF == 0b111
    assert TRISB == 0b11111111
    assert SQR1 == 0b11000000
    mute(OSCCONbits.IRCF, TRISB, SQR1)
    assert OSCCONbits.IRCF == 0
    assert TRISB == 0
    assert SQR1 == 0
    unmute(OSCCONbits.IRCF, TRISB, SQR1)
    assert OSCCONbits.IRCF == 0b111
    assert TRISB == 0b11111111
    assert SQR1 == 0b11000000