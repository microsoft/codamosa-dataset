

# Generated at 2022-06-12 09:37:40.056934
# Unit test for function unmute
def test_unmute():
    from . import register
    import pytest
    from .primitive import Register

    reg = register(4, mute=True)
    unmute(reg)

    assert reg.muted == False

    with pytest.raises(ValueError):
        unmute(Register.Register(4, mute=True))

# Generated at 2022-06-12 09:37:48.354204
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import And
    from .primitive import Mux
    from .primitive import Not
    from .primitive import Or
    from .primitive import Xor
    from .primitive import Decoder
    reg_a = Register("a")
    reg_b = Register("b")
    reg_c = Register("c")
    reg_d = Register("d")
    gate1 = And("and")
    gate2 = Or("or")
    gate3 = Xor("xor")
    gate4 = Not("not")
    gate5 = Mux("mux")
    decoder = Decoder("decoder")
    reg_a.connect(gate1, gate1)
    reg_b.connect(gate1, gate1)
    reg_c.connect(gate1, gate1)


# Generated at 2022-06-12 09:37:56.854452
# Unit test for function mute
def test_mute():
    with pyspi.Emulator() as py:
        a = py.create_register()
        b = py.create_register()
        # Call mute() on all register objects.
        mute(a, b)
        assert a._muted
        assert b._muted
        assert not a.output
        assert not b.output
        # Call unmute() on all register objects.
        unmute(a, b)
        assert not a._muted
        assert not b._muted
        assert a.output
        assert b.output
        # Call mute() on a single register object.
        a.mute()
        assert a._muted
        assert not a.output
        # Call unmute() on a single register object.
        a.unmute()
        assert not a._muted
        assert a.output

# Generated at 2022-06-12 09:38:00.022235
# Unit test for function mute
def test_mute():
    obj1 = Register(name="reg1")
    obj2 = Register(name="reg2")
    obj1.mute()
    obj2.mute()
    mute(obj1, obj2)
    assert obj1.muted
    assert obj2.muted



# Generated at 2022-06-12 09:38:04.544006
# Unit test for function mute
def test_mute():
    from .primitive import GPIO

    # Test mute() with a valid input
    obj = GPIO('GPIO', 0, 'OUTPUT')
    mute(obj)
    assert obj.muted is True

    # Test mute() with an invalid input
    try:
        mute(1)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-12 09:38:12.102449
# Unit test for function mute
def test_mute():
    # Test for error message if wrong value is given
    r = Register(0)
    try:
        mute(r, 1)
    except ValueError:
        pass
    else:
        raise AssertionError("Wrong value given to mute() should raise error")
    # Test if multiple objects are muted properly
    r1 = Register(0)
    r2 = Register(0)
    r3 = Register(0)
    mute(r1, r2, r3)
    assert r1.muted, "Objects not muted properly by mute()"
    assert r2.muted, "Objects not muted properly by mute()"
    assert r3.muted, "Objects not muted properly by mute()"


# Generated at 2022-06-12 09:38:16.685536
# Unit test for function unmute
def test_unmute():
    from . import register, constant
    from . import least_significant_bit as lsb

    # Define registers
    reg = register.Register()

    # Define constants
    zero = constant.Constant(value=0b0)
    one = constant.Constant(value=0b1)

    # Define wires
    # Wire 1
    wire_1 = lsb.LeastSignificantBit(object_1=reg, object_2=one)

    # Wire 2
    wire_2 = lsb.LeastSignificantBit(object_1=reg, object_2=zero)

    # Test the unmute() method
    reg.set(value=0b0)
    reg.unmute()
    reg.put(0b1)
    assert reg.get() == 0b1


# Generated at 2022-06-12 09:38:18.782918
# Unit test for function mute
def test_mute():
    a = Register(name="a")
    b = Register(name="b")
    mute(a, b)

    assert (not a.is_triggered) and (not b.is_triggered)



# Generated at 2022-06-12 09:38:27.995787
# Unit test for function unmute
def test_unmute():
	# Setup
	a = Register(name="a")
	b = Register(name="b")
	c = Register(name="c")
	a.mute()
	b.mute()
	c.mute()
	print('Should be muted:')
	print(f'a: {a.is_muted}')
	print(f'b: {b.is_muted}')
	print(f'c: {c.is_muted}')
	print('')
	# Test
	unmute(a,b,c)
	print('Should be unmuted:')
	print(f'a: {a.is_muted}')
	print(f'b: {b.is_muted}')
	print(f'c: {c.is_muted}')

# Generated at 2022-06-12 09:38:39.073509
# Unit test for function unmute
def test_unmute():
    from .primitive import Register, DUMMY
    from .parameters import Parameter
    from .backend import mock

    obj1 = Register(name="foo")
    obj2 = Register(name="bar")
    assert obj1.is_muted()
    assert obj2.is_muted()

    assert mock.call_stack == []

    unmute(obj1, obj2)
    assert not obj1.is_muted()
    assert not obj2.is_muted()
    assert mock.call_stack == [
        ("unmute", obj1),
        ("unmute", obj2),
    ]

    # unmute() also works with already unmuted objects.
    unmute(obj1, obj2)
    assert not obj1.is_muted()
    assert not obj2.is_muted()