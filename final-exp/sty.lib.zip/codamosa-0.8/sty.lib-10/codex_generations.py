

# Generated at 2022-06-12 09:37:44.535471
# Unit test for function unmute
def test_unmute():
    from .basic import Register_with_Constant

    obj1 = Register_with_Constant(1)
    obj2 = Register_with_Constant(1)

    mute(obj1, obj2)
    assert obj1.is_muted() == True
    assert obj2.is_muted() == True
    unmute(obj1, obj2)
    assert obj1.is_muted() == False
    assert obj2.is_muted() == False



# Generated at 2022-06-12 09:37:51.558502
# Unit test for function unmute
def test_unmute():
    '''
    This function is used to test the unmute function.
    '''
    import random
    from .configuration import config
    from .adcdevice import ADCdevice
    from .basicdevices import BasicDevice, ClockLine
    from .digitaldevice import DigitalDevice
    from .conversions import serial_packet_to_binary
    from .serial_device import ADCSerialDevice
    from .multidevice import MultiRegisterDevice
    from .primitive import Register

    r = Register('test_unmute', address=7)
    dev = ADCdevice(
        'ADC',
        configuration=config,
        address=0,
        clock_line=ClockLine(name='CLK')
    )
    d = DigitalDevice('test_unmute', address=0)

# Generated at 2022-06-12 09:37:53.092941
# Unit test for function unmute
def test_unmute():
    """Test the unmute() function."""
    assert unmute(Register(2, 3))


# Generated at 2022-06-12 09:38:01.892033
# Unit test for function unmute
def test_unmute():
    # Test for wrong input type
    class TestReg(Register):
        def __init__(self, init_value: int = 0, length: int = 1,
                     name: str = "", bit_order: str = "msb0",
                     description: str = "", register_type: str = "rw"):
            super().__init__(init_value, length, name, bit_order,
                             description, register_type)

    with pytest.raises(ValueError):
        mute(TestReg(), TestReg(), 42, TestReg())

    with pytest.raises(ValueError):
        unmute(TestReg(), TestReg(), 42, TestReg())

    # Test for functionality of mute()
    reg = TestReg()
    reg.mute()
    assert reg.muted is True
    unmute(reg)


# Generated at 2022-06-12 09:38:04.958092
# Unit test for function unmute
def test_unmute():
    reg = Register(1)
    assert reg.status == 1, "Register is empty."
    reg.mute()
    assert reg.status == 0, "Register is not muted."
    unmute(reg)
    assert reg.status == 1, "Register is muted."


# Generated at 2022-06-12 09:38:12.734413
# Unit test for function mute
def test_mute():
    a = Register(name='a', bitwidth=8)

    # Test mute method
    if a.unmuted:
        mute(a)
        assert a.muted
    else:
        mute(a)
        assert a.muted

    # Test unmute method
    if a.muted:
        unmute(a)
        assert a.unmuted
    else:
        unmute(a)
        assert a.unmuted

    # Test unmute method with multiple register
    a = Register(name='a', bitwidth=8)
    b = Register(name='b', bitwidth=8)
    if a.unmuted:
        mute(a)
        assert a.muted
    if b.unmuted:
        mute(b)
        assert b.muted

# Generated at 2022-06-12 09:38:21.739507
# Unit test for function mute
def test_mute():
    '''
    Test the mute function:
    '''
    from .primitive import SR, Flipflop
    dut = SR().name('Test DUT')
    dut.activate(mutable=True, mutex=True)
    mute(dut)
    assert dut.muted, "The mute function did not mute the object. "
    mute(dut)
    assert dut.muted, "The mute function did not mute the already muted object. "
    unmute(dut)
    assert not dut.muted, "The unmute function did not unmute the object. "
    unmute(dut)
    assert not dut.muted, "The unmute function did not unmute the already unmuted object. "
    # Test as context manger

# Generated at 2022-06-12 09:38:23.831428
# Unit test for function mute
def test_mute():
    r1 = Register(16, "r1")
    r2 = Register(16, "r2")
    r3 = Register(16, "r3")
    mute(r1, r2, r3)

    assert r1.muted
    assert r2.muted
    assert r3.muted



# Generated at 2022-06-12 09:38:26.028599
# Unit test for function mute
def test_mute():
    test_register = Register()

    test_register.mute()
    assert(test_register.is_muted())

    mute(test_register)
    assert (test_register.is_muted())

# Generated at 2022-06-12 09:38:33.129713
# Unit test for function mute
def test_mute():
    from .register import Reg
    from .address import Address, AddressMode
    from .state import State

    addr = Address(0x0000, AddressMode.ABSOLUTE)
    reg = Reg(addr, 3, State.READABLE_AND_WRITABLE)
    assert reg.state == State.READABLE_AND_WRITABLE
    mute(reg)
    assert reg.state == State.WRITABLE
    unmute(reg)
    assert reg.state == State.READABLE_AND_WRITABLE