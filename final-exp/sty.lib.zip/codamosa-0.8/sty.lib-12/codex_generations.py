

# Generated at 2022-06-12 09:37:43.257157
# Unit test for function mute
def test_mute():
    reg1 = Register(5, 12, 'register1')
    reg2 = Register(5, 12, 'register2')
    reg1.value = 240
    reg2.value = 240

    assert reg1.muted is False
    assert reg2.muted is False
    mute(reg1, reg2)

    assert reg1.muted is True
    assert reg2.muted is True


# Generated at 2022-06-12 09:37:48.044027
# Unit test for function unmute
def test_unmute():
    class TestRegister(Register):
        def __init__(self):
            super().__init__(width=32, initval=0xFF0000AA, name='Muted register')
    r = TestRegister()
    assert not r.is_default_muted()
    mute(r)
    assert r.is_default_muted()
    unmute(r)
    assert not r.is_default_muted()


# Generated at 2022-06-12 09:37:52.495176
# Unit test for function unmute
def test_unmute():
    class T(Register):
        def __init__(self):
            super().__init__(name='test', width=8)

    t = T()
    t.mute()
    if not t.is_muted:
        raise RuntimeError("mute() did not set 'is_muted' correctly")

    unmute(t)

    if t.is_muted:
        raise RuntimeError("unmute() did not set 'is_muted' correctly")


# Generated at 2022-06-12 09:37:59.906332
# Unit test for function unmute
def test_unmute():
    reg = Register(0)
    mute(reg)
    assert reg.value == 0
    assert reg.mute_value is not None
    unmute(reg)
    assert reg.value == 0
    assert reg.mute_value is None
    reg += 1
    assert reg.mute_value is None
    assert reg.value == 1
    mute(reg)
    assert reg.value == 1
    assert reg.mute_value == 1
    reg += 1
    assert reg.mute_value == 1
    assert reg.value == 2
    unmute(reg)
    assert reg.value == 2
    assert reg.mute_value is None

# Generated at 2022-06-12 09:38:02.730674
# Unit test for function mute
def test_mute():
    import numpy as np
    r = Register(bits=4, val=0b0100)
    mute(r)
    assert r.val == 0b0000, "Register value is not zero."
    

# Generated at 2022-06-12 09:38:06.092688
# Unit test for function unmute
def test_unmute():
    """Unmutes one or more registers."""
    # Verify that the function runs without errors
    obj1 = Register()
    obj2 = Register()
    obj3 = Register()
    mute(obj1, obj2, obj3)
    unmute(obj1, obj2, obj3)

# Generated at 2022-06-12 09:38:09.052990
# Unit test for function mute
def test_mute():
    # noise() needs to be globally declared
    global noise
    noise = DummyRegister()

    mute(noise)
    assert noise.mute_state
    unmute(noise)
    assert not noise.mute_state



# Generated at 2022-06-12 09:38:14.659196
# Unit test for function unmute
def test_unmute():
    """
    Function returns an error if an object other than Register is passed to the
    function.
    """
    reg = Register()
    err = ValueError(
        "The unmute() method can only be used with objects that inherit "
        "from the 'Register class'."
    )
    with pytest.raises(err):
        unmute("Register")
    assert not reg.muted



# Generated at 2022-06-12 09:38:22.121105
# Unit test for function unmute
def test_unmute():
    # Create two registers
    reg1 = Register(10, "reg1")
    reg2 = Register(20, "reg2")

    # Create a list with the two registers
    reg_list = [reg1, reg2]

    # Try to mute the registers in the list
    mute(reg_list)

    # Check if both registers are set to mute
    assert(reg1.is_muted and reg2.is_muted)

    # Try to unmute the registers in the list
    unmute(reg_list)

    # Check if the mute-attribute is not set for both registers
    assert(not reg1.is_muted and not reg2.is_muted)

# Generated at 2022-06-12 09:38:26.823404
# Unit test for function unmute
def test_unmute():
    """Unit test for function unmute."""
    from cryptolib.tests.test_primitive import RegisterTest
    from cryptolib.primitive import Register

    class Test(RegisterTest):
        def __init__(self, data: list, bits: int, name: str) -> None:
            super().__init__(data, bits, name)

    test_reg = Test([0, 1, 2], 3, "test register")
    assert test_reg.mute() is None
    assert test_reg.unmute() is None
    test_reg.data = [1, 2, 4]
