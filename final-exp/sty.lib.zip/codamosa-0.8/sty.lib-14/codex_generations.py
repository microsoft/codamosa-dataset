

# Generated at 2022-06-12 09:37:41.959574
# Unit test for function unmute
def test_unmute():
    a = Register(0)
    a.mute()
    unmute(a)
    assert not a.mute_state, "Function unmute works incorrect"



# Generated at 2022-06-12 09:37:46.873400
# Unit test for function unmute
def test_unmute():
    """
    Unit test for function unmute().
    """
    from .db import lookup
    from .constants import TOP_LEVEL_MUTE_BIT
    from .register import MappedRegister
    from .constants import Pin

    pin = Pin.GPIO_01
    addr = lookup(pin)
    reg = MappedRegister(addr)
    unmute(reg)
    assert not reg.value & TOP_LEVEL_MUTE_BIT
    return



# Generated at 2022-06-12 09:37:51.398502
# Unit test for function mute
def test_mute():
    """Test if the mute() method works."""
    from .primitive import sr_flipflop

    D = Register(1)
    Q, = sr_flipflop(D, enable=True)

    Q(0)
    assert Q.value == 0

    D(1)
    assert Q.value == 0

    mute(D)
    D(0)
    assert Q.value == 0

    unmute(D)
    D(1)
    assert Q.value == 1


# Generated at 2022-06-12 09:37:57.482240
# Unit test for function mute
def test_mute():

    class TestRegisters(Register):
        def __init__(self):
            super(TestRegisters, self).__init__("test register")
            self.__status = False

        def set(self):
            self.__status = True

        def mute(self):
            self.__status = False

    test_register = TestRegisters()
    test_register.set()

    assert test_register.__status

    mute(test_register)

    assert not test_register.__status


# Generated at 2022-06-12 09:37:58.298073
# Unit test for function unmute
def test_unmute():
    assert unmute(1) == None

# Generated at 2022-06-12 09:38:05.989255
# Unit test for function mute
def test_mute():
    """
    Unit test for the mute() function.
    """
    import unittest
    from .primitive import Bus
    from .primitive import BusType

    class TestCase(unittest.TestCase):
        def test_mute_function(self):
            """
            Tests the mute() function.
            """
            # Create new object
            Bus(8, BusType.INPUT, name="bus_1")

            class BusObj:
                bus_2 = Bus(8, BusType.INPUT, name="bus_2")

            c = BusObj()

            # Check if objects are not muted
            self.assertEqual(Bus.registries["bus_1"].mute_status, False)
            self.assertEqual(Bus.registries["bus_2"].mute_status, False)

            # M

# Generated at 2022-06-12 09:38:13.364169
# Unit test for function mute
def test_mute():
    from . import SettingRegister
    from .exceptions import RegisterMutedWarning

    class TestRegister(SettingRegister):
        def __init__(self) -> None:
            super().__init__(0)

    reg1 = TestRegister()
    reg2 = TestRegister()
    reg3 = TestRegister()

    mute(reg1, reg2, reg3)
    assert reg1.get() == 0
    assert reg2.get() == 0
    assert reg3.get() == 0

    reg1.set(10)
    reg2.set(20)
    reg3.set(30)
    assert reg1.get() == 0
    assert reg2.get() == 0
    assert reg3.get() == 0

    with pytest.warns(RegisterMutedWarning):
        reg1.set(10)
        reg2

# Generated at 2022-06-12 09:38:16.851158
# Unit test for function mute
def test_mute():
    data = np.arange(0, 8, 1)
    init_data = data.copy()
    reg = Register(data, "test")
    mute(reg)
    assert data.all() == init_data.all(), "Failed to mute register"



# Generated at 2022-06-12 09:38:19.216367
# Unit test for function unmute
def test_unmute():
    _reg = Register(name='test_register')
    _reg.mute()
    assert _reg.visible == False
    unmute(_reg)
    assert _reg.visible == True

# Generated at 2022-06-12 09:38:20.802026
# Unit test for function unmute
def test_unmute():
    pass