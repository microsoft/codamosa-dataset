

# Generated at 2022-06-12 09:37:46.610214
# Unit test for function mute
def test_mute():
    # Various of muteable objects
    TV = TV()
    HomeTheater = HomeTheater()
    Computer = Computer()
    Radio = Radio()
    # Mute all
    mute(TV, HomeTheater, Computer, Radio)
    # Check if all are muted
    assert (TV.is_muted == True)
    assert (HomeTheater.is_muted == True)
    assert (Computer.is_muted == True)
    assert (Radio.is_muted == True)
    # Unmute all
    unmute(TV, HomeTheater, Computer, Radio)
    # Check if all are unmuted
    assert (TV.is_muted == False)
    assert (HomeTheater.is_muted == False)
    assert (Computer.is_muted == False)

# Generated at 2022-06-12 09:37:49.346206
# Unit test for function unmute
def test_unmute():
    from .primitive import Bool
    a = Bool(name="a")
    b = Bool(name=".a")
    mute(a, b)
    assert a.muted
    assert b.muted
    unmute(a, b)
    assert not a.muted
    assert not b.muted

# Generated at 2022-06-12 09:37:49.755309
# Unit test for function mute
def test_mute():
    mute(1)

# Generated at 2022-06-12 09:37:54.059310
# Unit test for function unmute
def test_unmute():
    """
    This function does not work, since the behaviour of unmute is currently
    unclear
    """
    class MockRegister(Register):
        def __init__(self):
            super().__init__(name='MockRegister')
            self._muted = True
            self._value = 3
            self._right_shift = 3
            self._mask = 0b111
    
    obj = MockRegister()
    unmute(obj)
    assert obj.get_muted() == False
    obj.set_value(0)
    assert (obj.get_value() == 0) and (obj.get_muted() == True)

# Generated at 2022-06-12 09:37:58.311544
# Unit test for function unmute
def test_unmute():
    """
    This function tests if the function 'unmute' raises an error when a wrong
    object is passed.
    """
    class Bla(object):
        def __init__(self):
            pass

    obj = Bla()
    # Expect ValueError, because obj is not a Register-Object
    with pytest.raises(ValueError):
        unmute(obj)

# Generated at 2022-06-12 09:38:00.212748
# Unit test for function unmute
def test_unmute():
    r = Register()
    assert r.mapped_value == r.value, "unmute() has not worked properly"


# Generated at 2022-06-12 09:38:04.501448
# Unit test for function unmute
def test_unmute():
    from unittest.mock import Mock
    from .primitive import Register

    reg_1 = Register(Mock)
    reg_2 = Register(Mock)
    unmute(reg_1, reg_2)

    assert reg_1.is_muted() == False
    assert reg_2.is_muted() == False


# Generated at 2022-06-12 09:38:09.540473
# Unit test for function unmute
def test_unmute():
    obj = Register("test")
    obj.write(1)
    assert obj.value == 1  # check write
    obj.mute()
    assert obj.muted == True  # check mute
    obj.write(0)
    assert obj.value == 1  # check mute
    obj.unmute()
    assert obj.muted == False  # check unmute
    obj.write(0)
    assert obj.value == 0  # check unmute

# Generated at 2022-06-12 09:38:14.937929
# Unit test for function unmute
def test_unmute():

    class _TestClass(Register):
        _size = 1

    a = _TestClass(name="test")
    assert a.read() == 0
    a.mute()
    a.write(1)
    assert a.read() == 0
    unmute(a)
    a.write(1)
    assert a.read() == 1


# Generated at 2022-06-12 09:38:17.684697
# Unit test for function mute
def test_mute():
    reg1, reg2 = Reg(), Reg()
    mute(reg1, reg2)
    assert reg1.status() == "mute"
    assert reg2.status() == "mute"

