

# Generated at 2022-06-12 09:37:39.350635
# Unit test for function unmute
def test_unmute():
    rs = Register(4)
    assert rs.mute()
    assert rs.unmute()
    assert not rs.mute()



# Generated at 2022-06-12 09:37:39.873620
# Unit test for function unmute
def test_unmute():
    pass

# Generated at 2022-06-12 09:37:41.665198
# Unit test for function mute
def test_mute():
    with pytest.raises(ValueError):
        mute("Register class")
    assert mute(None) is None



# Generated at 2022-06-12 09:37:49.450850
# Unit test for function unmute
def test_unmute():
    from . import pin, board

    board.mute_all()
    pin1 = pin.DigitalOutput(num=1)
    pin2 = pin.DigitalOutput(num=2)
    pin3 = pin.DigitalOutput(num=3)
    pin4 = pin.DigitalOutput(num=4)
    pin5 = pin.DigitalOutput(num=5)
    pin6 = pin.DigitalOutput(num=6)
    pin7 = pin.DigitalOutput(num=7)
    pin8 = pin.DigitalOutput(num=8)

    mute(pin1, pin3, pin5, pin7)
    unmute(pin2, pin4, pin6, pin8)
    assert(
        board.get_reg_status() ==
        0b01010101
    )

# Generated at 2022-06-12 09:37:58.377439
# Unit test for function unmute
def test_unmute():
    from .primitive import Register

    r1 = Register("r1")
    r1.set_value(5)
    r2 = Register("r2")
    r2.set_value(4)
    r3 = Register("r3")
    r3.set_value(3)
    r4 = Register("r4")
    r4.set_value(2)
    r5 = Register("r5")
    r5.set_value(1)
    r6 = Register("r6")
    r6.set_value(0)
    mute(r1, r2, r3, r4, r5, r6)
    unmute(r1, r3, r5)
    assert not r1.is_muted() and r3.is_muted() and not r5.is_muted

# Generated at 2022-06-12 09:37:59.983527
# Unit test for function unmute
def test_unmute():
    m = Register(0)
    unmute(m)
    assert m.muted == False



# Generated at 2022-06-12 09:38:09.053831
# Unit test for function unmute
def test_unmute():
    import silica as si
    from silica.bitutil import clog2, BitType, BitVector, Bit
    import inspect
    import ast

    def reg(dout, din):
        return si.m(name="dut",
                   interface=si.Interface(dout=si.Out(BitType(32)),
                                          din=si.In(dout.dtype)),
                   mod=si.ModuleDef(body=[dout(din)],
                                    ast=inspect.getsource(lambda self: din)))

    f = reg(si.reg(BitVector[32](0)),
            si.as_bits(BitVector[32](0)))

    f = si.compile(f)

    assert f(din=1) == 1
    assert f(din=1) == 1

# Generated at 2022-06-12 09:38:10.522546
# Unit test for function mute
def test_mute():
    """
    Unit test to check that the mute() function works properly.
    """
    return 0


# Generated at 2022-06-12 09:38:17.731042
# Unit test for function mute
def test_mute():
    """
    This function tests if the register-objects are muted or not.
    """
    reg1 = Register(0x01)
    reg2 = Register(0x02)
    assert reg1._mute == 0
    assert reg2._mute == 0
    mute(reg1, reg2)
    assert reg1._mute == 1
    assert reg2._mute == 1
    unmute(reg1, reg2)
    assert reg1._mute == 0
    assert reg2._mute == 0


# Generated at 2022-06-12 09:38:21.993477
# Unit test for function unmute
def test_unmute():
    """
    Unit-test for function unmute.

    :return: True
    """
    print("Testing function unmute")
    r = Register(name="test")
    r.mute()
    r.unmute()
    assert not r.is_muted
    print("End of function unmute test\n")
    return True
