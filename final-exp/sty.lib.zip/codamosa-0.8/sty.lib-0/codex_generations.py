

# Generated at 2022-06-12 09:37:37.908788
# Unit test for function mute
def test_mute():
    reg = Register(4)
    reg.write("1010")
    mute(reg)
    assert reg.value is None



# Generated at 2022-06-12 09:37:45.819705
# Unit test for function unmute
def test_unmute():
    h = Register("A")
    x = Register("B")
    y = Register("C")
    z = Register("D")

    mute(h, x, y, z)  # mute all registers
    unmute(x, z)  # unmute only two registers

    if h.is_muted() == False:
        raise AssertionError("Method unmute is not working properly.")
    if x.is_muted() == True:
        raise AssertionError("Method unmute is not working properly.")
    if y.is_muted() == False:
        raise AssertionError("Method unmute is not working properly.")
    if z.is_muted() == True:
        raise AssertionError("Method unmute is not working properly.")



# Generated at 2022-06-12 09:37:48.844728
# Unit test for function mute
def test_mute():
    try:
        mute(1)
    except ValueError as e:
        assert e.message == \
            "The mute() method can only be used with objects that inherit from the 'Register class'."
    else:
        raise AssertionError("mute should raise ValueError")


# Generated at 2022-06-12 09:37:57.426108
# Unit test for function unmute
def test_unmute():
    from .primitive import Binary
    from .primitive import Octal
    from .primitive import Hexadecimal
    from .primitive import BCD
    from .primitive import GrayCode
    mute(Binary(0),Octal(0),Hexadecimal(0),BCD(0),GrayCode(0))
    assert Binary.muted == True
    assert Octal.muted == True
    assert Hexadecimal.muted == True
    assert BCD.muted == True
    assert GrayCode.muted == True
    unmute(Binary(0),Octal(0),Hexadecimal(0),BCD(0),GrayCode(0))
    assert Binary.muted == False
    assert Octal.muted == False
    assert Hexadecimal.muted == False
    assert BCD.m

# Generated at 2022-06-12 09:38:02.185648
# Unit test for function mute
def test_mute():
    """
    Tests function mute.
    """
    from .primitive import I2CSlaveRegister
    from .secure import SecureRegister

    i2c_reg = I2CSlaveRegister(1, 2, 4, 8)
    sec_reg = SecureRegister(4, 6, 8)
    mute(i2c_reg)
    assert i2c_reg.value == 0
    mute(sec_reg)
    assert sec_reg.value == 0



# Generated at 2022-06-12 09:38:07.074644
# Unit test for function mute
def test_mute():
    print("testing mute()")
    r1 = Register(9)
    r2 = Register(99)

    assert r1.get_value() == 9
    assert r2.get_value() == 99

    mute(r1, r2)

    assert r1.get_value() == 0
    assert r2.get_value() == 0

    r1.auto_load = False
    r2.auto_load = False

    assert r1.get_value() == 0
    assert r2.get_value() == 0


# Generated at 2022-06-12 09:38:16.515795
# Unit test for function mute
def test_mute():
    # test_register.py already takes care of testing the register class.
    # unit_test.py requires the mute() function.
    # This test tests multiple functionalities at once.
    # TODO: Move this test to test_register.py
    # TODO: check if we can use pytest
    # TODO: Add @unittest.mock to the tests (https://stackoverflow.com/questions/26467576)
    # (probably not possible because it doesn't support unittest.mock)
    from pymodelica import compile_fmu
    from pyfmi import load_fmu
    from .primitive import Register

    # Model with two input-objects (u1, u2).
    # Both objects are connected to the same register-object.
    # The register-object is connected to two output-objects (y

# Generated at 2022-06-12 09:38:20.441915
# Unit test for function mute
def test_mute():
    from umodbus import conf
    conf.SIGNED_VALUES = False
    a = Register(value=0, number=1, name="a")
    b = Register(value=0, number=2, name="b")
    mute(a, b)
    assert a.muted and b.muted

# Uunit test for function unmute

# Generated at 2022-06-12 09:38:28.109198
# Unit test for function unmute

# Generated at 2022-06-12 09:38:34.357039
# Unit test for function mute
def test_mute():
    from .namedregister import NamedRegister
    r = NamedRegister("my_register", width=4)

    assert not r.is_muted
    mute(r)
    r.set() # attempt to set register
    assert r.is_muted
    assert not r.value
    unmute(r)
    assert not r.is_muted
    r.set()
    assert r.value