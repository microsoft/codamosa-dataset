

# Generated at 2022-06-12 09:37:45.410362
# Unit test for function mute
def test_mute():
    from . import model as m
    from . import signal as s

    import numpy as np
    
    # Create signal to write to register
    data = np.arange(0,10)
    signal = s.Signal(data)

    # Create register-object
    reg = m.Register(10)

    # Assert that signal is not muted before calling mute()
    assert not signal.muted

    mute(reg)
    reg.write(signal)

    # Assert that signal is muted after calling mute()
    assert signal.muted
    
    

# Generated at 2022-06-12 09:37:46.608852
# Unit test for function unmute
def test_unmute():
    pass



# Generated at 2022-06-12 09:37:52.619206
# Unit test for function mute
def test_mute():
    import unit_tester as ut

    m0 = Register(name="Mute Test 0", width=1, mute=False)
    m1 = Register(name="Mute Test 1", width=1, mute=True)
    m2 = Register(name="Mute Test 2", width=1, mute=False)
    m3 = Register(name="Mute Test 3", width=1, mute=True)
    m4 = Register(name="Mute Test 4", width=1, mute=False)
    m5 = Register(name="Mute Test 5", width=1, mute=True)

    mute(m0, m1, m2, m3, m4, m5)
    expected = [True, True, True, True, True, True]

# Generated at 2022-06-12 09:38:01.466104
# Unit test for function mute
def test_mute():
    num_regs = 3
    regs = []
    for i in range(num_regs):
        regs.append(Register(i, 0))

    # Mute all registers
    mute(*regs)
    for reg in regs:
        assert reg.is_muted, f"{reg.identifier} not muted."
    # Unmute all registers
    unmute(*regs)
    for reg in regs:
        assert not reg.is_muted, f"{reg.identifier} still muted."
    
    # Mute one register
    mute(regs[0])
    assert regs[0].is_muted
    assert not regs[1].is_muted
    assert not regs[2].is_muted
    # Unmute one register

# Generated at 2022-06-12 09:38:07.948015
# Unit test for function unmute
def test_unmute():
    class TestRegister(Register):
        def __init__(self):
            Register.__init__(self, 'test')
    obj1, obj2, obj3 = TestRegister(), TestRegister(), TestRegister()
    mute(obj1, obj2, obj3)
    unmute(obj1, obj2, obj3)
    assert obj1.muted == False, "obj1 is still muted"
    assert obj2.muted == False, "obj2 is still muted"
    assert obj3.muted == False, "obj3 is still muted"



# Generated at 2022-06-12 09:38:17.824694
# Unit test for function unmute
def test_unmute():
    r1 = Register()
    r2 = Register()
    r3 = Register()
    r4 = Register()

    r1.amplitude = 0.17
    r2.amplitude = 0.35
    r3.amplitude = 0.53
    r4.amplitude = 0.71

    mute(r1)
    mute(r2)
    mute(r3)
    mute(r4)

    expect(r1.amplitude.to_dBFS()).to(be_below(0))
    expect(r2.amplitude.to_dBFS()).to(be_below(0))
    expect(r3.amplitude.to_dBFS()).to(be_below(0))

# Generated at 2022-06-12 09:38:21.258460
# Unit test for function unmute
def test_unmute():
    reg = Register(1, True)
    mute(reg)
    assert not reg.is_muted
    mute(reg)
    assert reg.is_muted
    unmute(reg)
    assert not reg.is_muted
    unmute(reg)
    assert not reg.is_muted

# Generated at 2022-06-12 09:38:22.857614
# Unit test for function mute
def test_mute():
    r = Register(1)
    mute(r)
    assert r.get_value() == 0



# Generated at 2022-06-12 09:38:25.422952
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .magic import MagicRegister
    reg = Register(32)
    reg.mute()
    assert reg.muted
    mute(reg)
    assert reg.muted



# Generated at 2022-06-12 09:38:31.164256
# Unit test for function mute
def test_mute():
    from .primitive import Register
    from .primitive import Pin
    from .primitive import Mux
    from .primitive import DFF

    pin_a = Pin(name='pin_a')
    pin_b = Pin(name='pin_b')
    pin_c = Pin(name='pin_c')
    pin_d = Pin(name='pin_d')
    pin_e = Pin(name='pin_e')

    A = Register(name='A')
    B = Register(name='B')
    C = Register(name='C')
    D = Register(name='D')
    E = Register(name='E')

    mux1 = Mux(name='mux1')
    mux2 = Mux(name='mux2')

    DFF1 = DFF(name='DFF1')
