

# Generated at 2022-06-12 01:51:38.057215
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('\n' + 'test_Cryptographic_hash()')
    t = Cryptographic().hash()
    print(t)
    assert isinstance(t, str)


# Generated at 2022-06-12 01:51:38.998421
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()


# Generated at 2022-06-12 01:51:47.675787
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('\n==== test_Cryptographic_hash() ====')
    instance: Cryptographic = Cryptographic(seed=42)

    obj: Algorithm = Algorithm.MD5
    res1: str = instance.hash(obj)
    print(res1)
    
    obj: Algorithm = Algorithm.SHA256
    res2: str = instance.hash(obj)
    print(res2)
    
    obj: Algorithm = Algorithm.SHA512
    res3: str = instance.hash(obj)
    print(res3)
    
    obj: Algorithm = Algorithm.BLAKE2B
    res4: str = instance.hash(obj)
    print(res4)
    
    obj: Algorithm = Algorithm.BLAKE2S
    res5: str = instance.hash(obj)
   

# Generated at 2022-06-12 01:51:50.047951
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    output = c.hash()
    assert type(output) == str


# Generated at 2022-06-12 01:51:52.091903
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == \
       c.hash()

# Generated at 2022-06-12 01:51:55.740086
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    h = Cryptographic()._seed(12345)
    h.hash(Algorithm.SHA1) == 'c2b2e7bfe8c8e585e3d1c00b988694e8c8dfe732'

# Generated at 2022-06-12 01:52:01.818110
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    result = Cryptographic().hash()

    print(result)
    # '6c7e6dbd076f357e6a939f3c4d74d4ee'

    result = Cryptographic().hash(algorithm=Algorithm.BLAKE2B)

    print(result)
    # '62c037f06a98bf1a8d7632d6984a902c5f5d5b5fc5b52a1bcc90c0d0f6bdc8e9'

    result = Cryptographic().hash(algorithm=Algorithm.SHA64)

    print(result)
    # '859e957f95c4b4d1ee4c3dddc0b712ac7b79ba16d995c72348

# Generated at 2022-06-12 01:52:09.198986
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    s_seed='30'
    print('\nstart testing method hash of class Cryptographic,seed=' + s_seed)
    provider = Cryptographic(s_seed)
    for v in [Algorithm.MD4, Algorithm.MD5, Algorithm.SHA1, Algorithm.SHA224, Algorithm.SHA256, Algorithm.SHA384, Algorithm.SHA512, Algorithm.BLAKE2S, Algorithm.BLAKE2B, Algorithm.SHA3_224, Algorithm.SHA3_256, Algorithm.SHA3_384, Algorithm.SHA3_512]:
        print('method hash the algorithm=' + v.name + ' result=' + provider.hash(v))
    print('end testing method hash of class Cryptographic,seed=' + s_seed)


# Generated at 2022-06-12 01:52:11.476142
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    encrypt = crypto.hash()
    assert isinstance(encrypt, str)


# Generated at 2022-06-12 01:52:14.914769
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    assert a.hash() != ''
    assert a.hash() != None
    assert a.hash() != []
    assert a.hash() != {}


# Generated at 2022-06-12 01:53:15.072271
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for Cryptographic.hash() method."""
    # Default algorithm
    hash_value = Cryptographic.hash()
    assert hash_value

    # SHA1
    hash_value = Cryptographic.hash(Algorithm.SHA1)  # type: ignore
    assert hash_value

    # SHA224
    hash_value = Cryptographic.hash(Algorithm.SHA224)  # type: ignore
    assert hash_value

    # SHA256
    hash_value = Cryptographic.hash(Algorithm.SHA256)  # type: ignore
    assert hash_value

    # SHA384
    hash_value = Cryptographic.hash(Algorithm.SHA384)  # type: ignore
    assert hash_value

    # SHA512
    hash_value = Cryptographic.hash(Algorithm.SHA512)  # type: ignore
    assert hash_value

# Generated at 2022-06-12 01:53:16.594745
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic('faker')
    assert getattr(hashlib, cr.hash())


# Generated at 2022-06-12 01:53:18.525675
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():  # noqa: D400, D401
    provider = Cryptographic('en')
    hash = provider.hash(Algorithm.MD5)
    assert hash is not None
    assert len(hash) == 32



# Generated at 2022-06-12 01:53:19.823527
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    key = Algorithm.SHA1
    cryptographic = Cryptographic()
    assert cryptographic.hash(key).isdigit()


# Generated at 2022-06-12 01:53:28.311298
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '9df9e7c8d6db11f27dae0eccb93a8b118e39d76478b3896b2fc621c0b2d4bfd7'
    assert Cryptographic().hash(Algorithm.SHA512) == '9df9e7c8d6db11f27dae0eccb93a8b118e39d76478b3896b2fc621c0b2d4bfd7'
    assert Cryptographic().hash(Algorithm.SHA256) == '9df9e7c8d6db11f27dae0eccb93a8b118e39d76478b3896b2fc621c0b2d4bfd7'

# Generated at 2022-06-12 01:53:34.784260
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash(): # noqa: D102
    c = Cryptographic()
    h = c.hash(Algorithm.SHA256)
    assert h == 'b8f9b9d9f75a1b23ab7ed68dba5e702d463cdcbc5bc272948c80202da9e9e66c'
    assert isinstance(h, str) is True
    assert len(h) == 64



# Generated at 2022-06-12 01:53:41.056182
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Seed : 2722012487342190512983690699011150260147837140076
    # Hash : a82d29a8791697db5fb5d5c3699d02f8a96a2f2d1f7d90a0
    hash_result = "a82d29a8791697db5fb5d5c3699d02f8a96a2f2d1f7d90a0"
    assert hash_result == Cryptographic(2722012487342190512983690699011150260147837140076).hash()

# Generated at 2022-06-12 01:53:43.251348
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    hashAlgorithm = c.hash()
    print("Hash algorithm is " + hashAlgorithm)
    print("******** ********")
    print(hashAlgorithm)
    print("\n")



# Generated at 2022-06-12 01:53:46.581197
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    print(crypto.hash())


if __name__ == "__main__":
    # Test for Cryptographic
    test_Cryptographic_hash()

# Generated at 2022-06-12 01:53:48.925078
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    assert obj.hash() != obj.hash()



# Generated at 2022-06-12 01:56:06.028999
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("Test: <class Cryptographic> method hash.")
    cr = Cryptographic()
    print("Should not raise the exception.")
    hash = cr.hash()
    assert hash is not None


# Generated at 2022-06-12 01:56:10.354086
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    
    assert len(c.hash(algorithm=Algorithm.MD5)) == 32 
    assert len(c.hash(algorithm=Algorithm.SHA1)) == 40 
    assert len(c.hash(algorithm=Algorithm.SHA224)) == 56 
    assert len(c.hash(algorithm=Algorithm.SHA256)) == 64 
    assert len(c.hash(algorithm=Algorithm.SHA384)) == 96 
    assert len(c.hash(algorithm=Algorithm.SHA512)) == 128 


# Generated at 2022-06-12 01:56:11.684054
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    result = c.hash()
    assert(isinstance(result, str))

# Generated at 2022-06-12 01:56:15.417676
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import hashlib
    hasher = hashlib.md5()
    hasher.update(b'Hello, world!')
    return hasher.hexdigest()

# Generated at 2022-06-12 01:56:20.450045
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash()
    assert crypto.hash(algorithm=Algorithm.MD5)
    assert crypto.hash(algorithm=Algorithm.SHA_224)
    assert crypto.hash(algorithm=Algorithm.SHA_256)
    assert crypto.hash(algorithm=Algorithm.SHA_384)
    assert crypto.hash(algorithm=Algorithm.SHA_512)


# Generated at 2022-06-12 01:56:26.701930
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic(seed=12345)
    b = Cryptographic(seed=12345)

    assert a.uuid() != b.uuid()
    assert a.uuid() != b.uuid()
    assert a.uuid() != b.uuid()
    assert a.uuid() != b.uuid()
    assert a.uuid() != b.uuid()

    assert a.hash() != b.hash()
    assert a.hash() != b.hash()
    assert a.hash() != b.hash()
    assert a.hash() != b.hash()
    assert a.hash() != b.hash()


# Generated at 2022-06-12 01:56:31.390479
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    one = Cryptographic.hash()
    two = Cryptographic.hash()
    assert (one != two)
    assert (Cryptographic.hash(Algorithm.MD5) !=
            Cryptographic.hash(Algorithm.MD5))
    assert (len(Cryptographic.hash(Algorithm.SHA1)) ==
            len(Cryptographic.hash(Algorithm.SHA256)))
    assert(Cryptographic.hash(Algorithm.MD5))


# Generated at 2022-06-12 01:56:32.292490
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()

# Generated at 2022-06-12 01:56:33.174624
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic.hash()) == 64


# Generated at 2022-06-12 01:56:34.504067
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  assert(isinstance(Cryptographic.hash(), str))

# Generated at 2022-06-12 02:01:16.157128
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    assert provider.hash(Algorithm.MD5)



# Generated at 2022-06-12 02:01:17.895968
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    result = Cryptographic().hash(Algorithm.SHA256)
    assert len(result) == 64
