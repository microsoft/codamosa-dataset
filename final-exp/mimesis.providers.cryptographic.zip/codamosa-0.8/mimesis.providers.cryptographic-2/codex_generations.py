

# Generated at 2022-06-12 01:51:34.205187
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    assert len(a.hash(Algorithm.SHA1)) == 40
    assert type(a.hash(Algorithm.SHA256)) == str
    assert a.hash(Algorithm.SHA1).isalpha() == False
    assert a.hash(Algorithm.SHA256).isalnum() == True


# Generated at 2022-06-12 01:51:36.368869
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    assert provider.hash() == provider.hash()


# Generated at 2022-06-12 01:51:39.425990
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic(seed=42)
    assert crypto.hash() == '81b16a654a9c9aed0116e024908e9cf8'

# Generated at 2022-06-12 01:51:44.589923
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # mocking method parameters
    algorithm = Algorithm.MD5
    # mocking method behavior
    hashed_value = "dffed2b8896aa9eb9e5815a8d45fbe0b"
    
    cryptographic = Cryptographic()
    
    
    # assert call
    assert cryptographic.hash(algorithm) == hashed_value



# Generated at 2022-06-12 01:51:49.261470
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    # Generate a random hash from SHA512 hash algorithm
    my_hash = Cryptographic().hash(Algorithm.SHA512)

    assert isinstance(my_hash, str)
    assert len(my_hash) == 128


# Generated at 2022-06-12 01:51:58.151618
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # generate a random hash from an enum of algorithms
    # check if the hash is properly created
    assert len(Cryptographic.hash(Algorithm.SHA1)) == 40
    assert len(Cryptographic.hash()) == 32
    assert len(Cryptographic.hash(Algorithm.SHA224)) == 56
    assert len(Cryptographic.hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic.hash(Algorithm.SHA384)) == 96
    assert len(Cryptographic.hash(Algorithm.SHA512)) == 128
    assert len(Cryptographic.hash(Algorithm.MD5)) == 32
    assert len(Cryptographic.hash(Algorithm.BLAKE2B)) == 128


# Generated at 2022-06-12 01:52:01.067390
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic('es')
    value = obj.hash()
    assert isinstance(value, str) is True
    

# Generated at 2022-06-12 01:52:09.063344
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    algos = ['blake2b', 'blake2s', 'md5', 'sha1', 'sha224', 'sha256', 'sha384',
             'sha3_224', 'sha3_256', 'sha3_384', 'sha3_512', 'shake_128',
             'shake_256', 'sha512', 'sha512_224', 'sha512_256', 'shake_128',
             'shake_256']
    assert len(Cryptographic().hash(Algorithm[algos[0]])) == 128
    assert len(Cryptographic().hash(Algorithm[algos[1]])) == 64
    assert len(Cryptographic().hash(Algorithm[algos[2]])) == 32
    assert len(Cryptographic().hash(Algorithm[algos[3]])) == 40

# Generated at 2022-06-12 01:52:12.183984
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cp = Cryptographic()
    assert cp.hash() == '735827e6e2d6bab0f75980f6f1ac9b2c'


# Generated at 2022-06-12 01:52:15.446583
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    answer = Cryptographic('en').hash(Algorithm.MD5)
    assert isinstance(answer, str)
    assert len(answer) == 32
    assert answer[0:2] == 'a5'


# Generated at 2022-06-12 01:52:28.040901
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test the method hash of class Cryptographic."""

    x = Cryptographic.hash()
    assert type(x) == str
    assert len(x) == 64

# Generated at 2022-06-12 01:52:28.861207
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    tester = Cryptographic()
    tester.hash()

# Generated at 2022-06-12 01:52:38.983828
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    hash_list = list()
    hash_list.append(crypto.hash(Algorithm.BLAKE2s))
    assert hash_list[0] == '2713a640a6302b9a7ce42b2c1d7cb88e0c35fe0d79919f3fe6e38cc1a8e903d4'
    hash_list.append(crypto.hash(Algorithm.BLAKE2b))
    assert hash_list[1] == 'd97c19e7b838bd8d6a0f6e70f84e82e9a9d99b87ebd62e5c5b5f5c876885d1c2'
    hash_list.append(crypto.hash(Algorithm.SHA1))

# Generated at 2022-06-12 01:52:42.200747
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    result = cr.hash(Algorithm.SHA1)
    assert type(result) == str
    assert len(result) == 40


# Generated at 2022-06-12 01:52:48.602438
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    alg = Algorithm
    test = Cryptographic()
    h1 = test.hash()
    h2 = test.hash(alg.MD5)
    h3 = test.hash(alg.SHA224)
    assert h1 != h2
    assert h1 != h3
    assert h2 != h3

# Generated at 2022-06-12 01:52:50.038554
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA256)


# Generated at 2022-06-12 01:52:52.966322
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('Running unit test on method hash() of class Cryptographic')
    cr = Cryptographic()
    cr.seed(1234)
    print(cr.hash(Algorithm.MD5))

# Generated at 2022-06-12 01:52:55.282945
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    c.hash(algorithm=Algorithm.SHA1)
    # c.hash(algorithm=Algorithm.SHA512)

# test_Cryptographic_hash()

# Generated at 2022-06-12 01:52:56.967530
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    message=Cryptographic().hash()
    assert message is not None


# Generated at 2022-06-12 01:53:04.880253
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Arrange
    crypto_provider = Cryptographic()
    crypto_provider.attrs = {'seed': 12345}
    expected_value = '1f8b08000000000000ff659d310e4b70fcb4e839d4b1e3b1a0d3a4342969e17fdda6e2664cdc86f844cd0cc380cf71e9dffeb1e8b8f157894c2d41a840097524e1897'

    # Act
    act_value = crypto_provider.hash()

    # Assert
    assert act_value == expected_value

# Generated at 2022-06-12 01:54:38.216985
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # assert Cryptographic().hash()
    print("\n"+"test_Cryptographic_hash:   "+"Cryptographic().hash()"+"\n")
    print("result: "+str(Cryptographic().hash())+"\n")
    # assert Cryptographic().hash(Algorithm.MD5)
    print("\n" + "test_Cryptographic_hash:   " + "Cryptographic().hash(Algorithm.MD5)" + "\n")
    print("result: " + str(Cryptographic().hash(Algorithm.MD5)) + "\n")
    # assert Cryptographic().hash(Algorithm.SHA3_256)
    print("\n" + "test_Cryptographic_hash:   " + "Cryptographic().hash(Algorithm.SHA3_256)" + "\n")

# Generated at 2022-06-12 01:54:39.657126
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic('en')
    assert provider.hash(Algorithm.SHA256) != None


# Generated at 2022-06-12 01:54:42.057664
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert '9e9d4e4de4f4fb4b82e4b4d8e4be4er4u4' == Cryptographic().hash('md5')

# Generated at 2022-06-12 01:54:44.958139
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    # Assert whether the result is hash
    assert crypto.hash() == 'a323e8f8d3fae7cb3db3e20dae03a8a51a7a381c'


# Generated at 2022-06-12 01:54:47.451913
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    hash = crypto.hash()
    assert isinstance(hash, str) is True, "Hash is not a instance of str."

# Generated at 2022-06-12 01:54:56.512153
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c1 = Cryptographic()
    c2 = Cryptographic()
    c3 = Cryptographic()
    c4 = Cryptographic()
    c5 = Cryptographic()
    c6 = Cryptographic()
    c7 = Cryptographic()
    c8 = Cryptographic()
    c9 = Cryptographic()

    t = str(c1.hash())
    t1 = t.replace('a', 'b')
    t2 = t.replace('b', 'a')
    t3 = t.replace('c', 'd')
    t4 = t.replace('d', 'c')
    t5 = t.replace('e', 'f')
    t6 = t.replace('f', 'e')
    t7 = t.replace('g', 'h')
    t8 = t.replace('h', 'g')

# Generated at 2022-06-12 01:55:03.149365
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'b2b1b7c121349e0d7c4b855cf0a7a4d2'
    assert crypto.hash(
        Algorithm.SHA256) == 'f7a39b6f37278bc74efd65adc914f3a97e0e04f24e2f8a740d2a2a87f7bdabf6'

# Generated at 2022-06-12 01:55:10.875173
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    result = a.hash(Algorithm.SHA1)
    assert(len(result) == 40 )
    result = a.hash(Algorithm.SHA224)
    assert(len(result) == 56 )
    result = a.hash(Algorithm.SHA256)
    assert(len(result) == 64 )
    result = a.hash(Algorithm.SHA384)
    assert(len(result) == 96 )
    result = a.hash(Algorithm.SHA512)
    assert(len(result) == 128 )
    result = a.hash(Algorithm.MD5)
    assert(len(result) == 32 )
    result = a.hash(Algorithm.SHA3_224)
    assert(len(result) == 56 )
    result = a.hash(Algorithm.SHA3_256)

# Generated at 2022-06-12 01:55:15.282774
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() != crypto.hash()

    # Test for supported hash algorithms
    assert crypto.hash(Algorithm.SHA1) != crypto.hash(Algorithm.SHA224)
    assert crypto.hash(Algorithm.SHA256) != crypto.hash(Algorithm.SHA384)
    assert crypto.hash(Algorithm.SHA512) != crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.BLAKE2B) != crypto.hash(Algorithm.BLAKE2S)

    # Test for unsupported hash algorithm
    from mimesis.exceptions import NonEnumerableError
    with pytest.raises(NonEnumerableError):
        crypto.hash('some-hash-algorithm')



# Generated at 2022-06-12 01:55:18.184988
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    answer = obj.hash()
    assert answer == 'a6acb00d5d402f8f5e8960b46f1ea7d8c40defb5'


# Generated at 2022-06-12 01:59:31.346437
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    # seed = 'e6a8d6dcff9e5f379e4cd4c4a1a68a07687d6b8369f98a8bf70f35d3dc9e14a3'
    # crypto = Cryptographic(seed=seed)
    crypto = Cryptographic()
    algorithm = crypto._validate_enum(None, Algorithm)
    assert len(crypto.hash(algorithm)) == 64


# Generated at 2022-06-12 01:59:33.289362
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """
    Test method hash of class Cryptographic
    """
    c = Cryptographic()
    s = c.hash(Algorithm.MD5)
    assert len(s) == 32

# Generated at 2022-06-12 01:59:42.585830
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import string

    from mimesis.meta import Meta
    from mimesis.enums import Algorithm

    cr = Cryptographic('en')
    res = cr.hash(Algorithm.SHA1)
    assert (len(res) == 40)
    assert (isinstance(res, str))

    for sym in res:
        assert (sym in string.hexdigits)

    res = cr.hash(Algorithm.MD5)
    assert (len(res) == 32)
    assert (isinstance(res, str))

    for sym in res:
        assert (sym in string.hexdigits)

    res = cr.hash(Algorithm.SHA224)
    assert (len(res) == 56)
    assert (isinstance(res, str))

    for sym in res:
        assert (sym in string.hexdigits)

# Generated at 2022-06-12 01:59:44.596188
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # The test only checks that the method is called and returns value.
    assert Cryptographic().hash().isalnum()

# Generated at 2022-06-12 01:59:46.623125
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    return Cryptographic().hash(Algorithm.SHA512)


# Generated at 2022-06-12 01:59:52.196916
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Random hash generation
    random_hash = Cryptographic().hash()
    assert isinstance(random_hash, str)
    assert len(random_hash) == 64

    # With algorithm
    for algorithm in Algorithm:
        if hasattr(hashlib, algorithm.value):
            hash_algorithm = Cryptographic().hash(algorithm=algorithm)
            assert isinstance(hash_algorithm, str)
            assert len(hash_algorithm) == 64

# Generated at 2022-06-12 01:59:55.465333
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic('en')
    assert crypto.hash()
    # When hashing algorithm is not supported
    # check that appropriate error is raised
    try:
        crypto.hash(Algorithm.RIPEMD160)
        assert False
    except Exception:
        assert True


# Generated at 2022-06-12 01:59:58.022872
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hsh = Cryptographic(seed=0).hash()
    assert hsh == '4f4b4e4a4def9c4cdc53578f20c7ece3'


# Generated at 2022-06-12 02:00:00.160326
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    this = Cryptographic()
    result = this.hash(Algorithm.SHA512)

    assert isinstance(
        result, str,
    )

# Generated at 2022-06-12 02:00:04.965300
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():  # noqa: N802
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm

    a = Cryptographic()
    x = a.hash(algorithm=Algorithm.MD5)
    assert isinstance(x, str)
    y = a.hash(algorithm=Algorithm.SHA1)
    assert isinstance(y, str)
    z = a.hash(algorithm=Algorithm.SHA256)
    assert isinstance(z, str)
    pass
