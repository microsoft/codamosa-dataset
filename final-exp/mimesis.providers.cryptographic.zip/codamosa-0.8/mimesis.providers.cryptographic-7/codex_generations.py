

# Generated at 2022-06-12 01:53:27.473951
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  c = Cryptographic()
  assert c.hash() not in ["",None]


# Generated at 2022-06-12 01:53:29.063366
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Checking the functionality of method hash."""
    assert Cryptographic().hash() == '2f391292a0fbf1e778968f7ccb4a78e8'

# Generated at 2022-06-12 01:53:36.248941
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic(seed=12345)
    assert c.hash(Algorithm.MD5) == '7d329e14c4a032b44f8d93f0e54a4168'
    assert c.hash(Algorithm.SHA1) == 'c7678ef3e3907d7fcf8069ce56bc81f9e30b54b7'


# Generated at 2022-06-12 01:53:38.353498
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    result = Cryptographic().hash()
    assert len(result) == 40
    assert result
    assert isinstance(result, str)

#Unit test for method token_bytes of class Cryptographic

# Generated at 2022-06-12 01:53:41.241275
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Should return hash
    obj1 = Cryptographic()
    possible_hash = obj1.hash()
    assert isinstance(possible_hash, str)
    print(possible_hash) # 793b9240faf7f74f0ae3c3d1c6e3e7c89d6f40bf3c3b4f4ba7ce9eeee6c27c01



# Generated at 2022-06-12 01:53:42.947838
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = Cryptographic()
    hash_val = data.hash()
    assert isinstance(hash_val, str)
    assert len(hash_val) > 0


# Generated at 2022-06-12 01:53:43.749863
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    t = Cryptographic()
    t.seed(0)
    


# Generated at 2022-06-12 01:53:46.381973
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    print(crypto.hash())


# Generated at 2022-06-12 01:53:55.011460
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    c=Cryptographic()
    md5_hash = c.hash(Algorithm.MD5)
    assert len(md5_hash) == 32
    assert md5_hash.isalnum()
    sha256_hash = c.hash(Algorithm.SHA256)
    assert len(sha256_hash) == 64
    assert sha256_hash.isalnum()
    sha512_hash = c.hash(Algorithm.SHA512)
    assert len(sha512_hash) == 128
    assert sha512_hash.isalnum()
    sha3_224_hash = c.hash(Algorithm.SHA3_224)
    assert len(sha3_224_hash) == 56
    assert sha3

# Generated at 2022-06-12 01:53:57.685061
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    s = cr.hash()
    s_true = '3d3b89df23e73e7168b1e1445b2f6c0d2e7d0019b9b09812aee1d0726e63a642'
    assert s == s_true

# Generated at 2022-06-12 01:54:53.791053
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    for _ in range(10):
        data = Cryptographic().hash(algorithm=Algorithm.MD5)
        assert isinstance(data, str)
        assert len(data) == 32

    for _ in range(10):
        data = Cryptographic().hash(algorithm=Algorithm.SHA1)
        assert isinstance(data, str)
        assert len(data) == 40

    for _ in range(10):
        data = Cryptographic().hash(algorithm=Algorithm.SHA224)
        assert isinstance(data, str)
        assert len(data) == 56

    for _ in range(10):
        data = Cryptographic().hash(algorithm=Algorithm.SHA256)
        assert isinstance(data, str)
        assert len(data) == 64


# Generated at 2022-06-12 01:55:01.209341
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cp = Cryptographic()
    assert cp.hash(Algorithm.SHA_256) == '2d6e3c6a3ccb3ce03867d8f0fe9e3bacd20500b1ecde0b8bea09aab0e5d5d5c5'

# Generated at 2022-06-12 01:55:09.230300
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(algorithm=Algorithm.MD5) == '005fe21c2f7e0d9b69069d798960c169'
    assert Cryptographic().hash(algorithm=Algorithm.SHA1) == 'd5b5f5d3f5c5127b909fd180fd91af78fce564c1'
    assert Cryptographic().hash(algorithm=Algorithm.SHA224) == 'c6ebb0d7f451cca0c39e7ff6d1a611759b638f4ca2b723e43566d332'

# Generated at 2022-06-12 01:55:11.372410
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()
    assert Cryptographic().hash(Algorithm.MD5) != Cryptographic().hash(Algorithm.SHA1)
    assert Cryptographic().hash(Algorithm.SHA256) != Cryptographic().hash(Algorithm.SHA512)


# Generated at 2022-06-12 01:55:18.391728
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == '7e73a5c5f5d44b0f1a499a1180fd9c97d8fd2b33'  # noqa: E501
    assert c.hash(Algorithm.SHA1) == 'dd90d5af5f5c5a5e5b4d4b4a4a4a4a4a4a4a4a4a4a4a4a4a4a4a4a4a4a4a4a4a4a4a'  # noqa: E501

# Generated at 2022-06-12 01:55:26.475000
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from enum import Enum
    from mimesis.types import Algorithm
    assert Cryptographic().hash()
    assert Cryptographic().hash(4)
    assert Cryptographic().hash(Algorithm.SHA1)
    assert Cryptographic().hash(Algorithm.SHA224)
    assert Cryptographic().hash(Algorithm.SHA256)
    assert Cryptographic().hash(Algorithm.SHA384)
    assert Cryptographic().hash(Algorithm.SHA512)
    assert Cryptographic().hash(Algorithm.MD5)
    assert Cryptographic().hash(0)

# Generated at 2022-06-12 01:55:28.421000
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    
    # Check if the length is 128 bits
    assert len(crypto.hash()) == 128


# Generated at 2022-06-12 01:55:30.307381
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    result = c.hash()
    print(result)
    assert len(result) == 40
    assert result.isalnum()


# Generated at 2022-06-12 01:55:31.742085
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    h = c.hash()
    assert len(h) == 32

# Generated at 2022-06-12 01:55:34.006795
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    round = 0
    while round < 50:
        algorithm = Algorithm.values(crypto)[round]
        assert crypto.hash(algorithm) == crypto.hash(algorithm)
        round += 1

# Generated at 2022-06-12 01:57:23.079568
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print(Cryptographic().hash())


# Generated at 2022-06-12 01:57:25.354064
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA512)


# Generated at 2022-06-12 01:57:29.421291
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    result = Cryptographic(seed=42).hash(Algorithm.SHA1)
    assert result == 'b6d7d8230d9f9c82d823c1f7d0e56df6c0f6bdfb'
    assert isinstance(result, str)


# Generated at 2022-06-12 01:57:30.420592
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    cr = Cryptographic()
    print(cr.hash())



# Generated at 2022-06-12 01:57:32.961865
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    hash = provider.hash(Algorithm.MD5)
    assert len(hash) == 32
    assert isinstance(hash, str)



# Generated at 2022-06-12 01:57:42.277135
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic(seed=12345)
    assert a.hash(Algorithm.SHA512) == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12b0b27'
    assert a.hash(Algorithm.SHA256) == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    assert a.hash(Algorithm.SHA224) == 'd14a028c2a3a2bc9476102bb288234c415a2b01f828ea62ac5b3e42f'

# Generated at 2022-06-12 01:57:45.828876
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    seed = 42
    crypto = Cryptographic(seed)
    assert crypto.hash() == '58f5c743af9bdc9b34d054c4ea4ed4eb6b3d6d29e6df06e6e79f1b9c6b9d6e70'

# Generated at 2022-06-12 01:57:52.206738
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test hash() method in class Cryptographic"""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    assert c.hash(algorithm = Algorithm.MD5) == 'ad0c0b8a545a2fa556e48d62b0a071b9'
    assert c.hash(algorithm = Algorithm.SHA1) == 'a08f88e45d30cacb8a9e150d0b7a2f710a72f8da'
    assert c.hash(algorithm = Algorithm.SHA224) == '75e40fcd6b423be1cebc8c25f4a4010264462467df6f9d6e8dc63639'

# Generated at 2022-06-12 01:57:53.645262
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    v = Cryptographic().hash(Algorithm.MD5)
    assert len(v) == 32



# Generated at 2022-06-12 01:57:55.610369
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Create provider and test method hash for correct input."""
    cr = Cryptographic()
    assert isinstance(cr.hash(Algorithm.MD5), str)
