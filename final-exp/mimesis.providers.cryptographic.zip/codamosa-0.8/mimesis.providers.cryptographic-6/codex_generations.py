

# Generated at 2022-06-12 01:52:19.868813
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Samples of method hash of class Cryptographic."""
    crypto_provider = Cryptographic(seed=1337)
    for _ in range(3):
        crypto_provider.hash(Algorithm.SHA512)
    # '68da98a9b636ab8ed538fce49e2288ef58c436ebd2ca3c3f3cc9b9c48bcf8cc8f7a36c2a64a1eee2f1b8d7caf9af75e79c0a0ab8b5a5c5a5bdc39f50c4d42d4c'
    # '1f1327bf2b6f3d6f3e449e7c6d8fd6c7acb102cf44f90683762e2a8d3e31

# Generated at 2022-06-12 01:52:26.434967
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("Testing method 'hash' of class Cryptographic")
    obj = Cryptographic()
    
    hash = obj.hash()
    assert len(hash) == 32
    assert isinstance(hash, str)
    print("Passed basic test")
    
    hash = obj.hash(Algorithm.SHA384)
    assert len(hash) == 96
    assert isinstance(hash, str)
    print("Passed hash code length test")
    
    hash = obj.hash(Algorithm.MD5)
    assert isinstance(hash, str)
    print("Passed hash code type test")


# Generated at 2022-06-12 01:52:36.706308
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Case 1
    c = Cryptographic()
    hash = c.hash(Algorithm.SHA512)
    assert isinstance(hash, str) and len(hash) == 128

    # Case 2
    hash = c.hash(Algorithm.MD5)
    assert isinstance(hash, str) and len(hash) == 32

    # Case 3
    hash = c.hash(Algorithm.SHA256)
    assert isinstance(hash, str) and len(hash) == 64

    # Case 4
    hash = c.hash(Algorithm.SHA1)
    assert isinstance(hash, str) and len(hash) == 40

    # Case 5
    hash = c.hash(Algorithm.SHA3_224)
    assert isinstance(hash, str) and len(hash) == 56

    # Case 6

# Generated at 2022-06-12 01:52:44.920934
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()
    c.hash()


# Generated at 2022-06-12 01:52:48.046642
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40


# Generated at 2022-06-12 01:52:51.128081
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    _hash = Cryptographic().hash(Algorithm.SHA512)
    assert _hash is not None

# Generated at 2022-06-12 01:52:52.739884
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    res = cr.hash()
    assert len(res) == 128

# Generated at 2022-06-12 01:52:56.503951
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    algorithm = Algorithm.MD5
    assert provider.hash(algorithm) in [
        '900150983cd24fb0d6963f7d28e17f72',
        'e10adc3949ba59abbe56e057f20f883e',
    ]

# Generated at 2022-06-12 01:52:58.250309
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypt = Cryptographic()
    rslt = crypt.hash(Algorithm.SHA256)
    assert isinstance(rslt, str)


# Generated at 2022-06-12 01:53:05.414049
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    seed = 123456789
    cr = Cryptographic(seed)

    # Check for algorithm md4
    hash_md4 = cr.hash(algorithm=Algorithm.MD4)
    assert hash_md4 == '01a8a7a97b768d1f'
    assert isinstance(hash_md4, str)

    # Check for algorithm md5
    hash_md5 = cr.hash(algorithm=Algorithm.MD5)
    assert hash_md5 == '614e8789b3c3af3a'
    assert isinstance(hash_md5, str)

    # Check for algorithm sha1
    hash_sha1 = cr.hash(algorithm=Algorithm.SHA1)

# Generated at 2022-06-12 01:53:25.755989
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print()
    print('Testing Cryptographic hash method')
    c = Cryptographic()
    print(c.hash(Algorithm.MD5))
    print(c.hash(Algorithm.SHA1))
    print(c.hash(Algorithm.SHA224))
    print(c.hash(Algorithm.SHA256))
    print(c.hash(Algorithm.SHA384))
    print(c.hash(Algorithm.SHA512))
    print(c.hash())



# Generated at 2022-06-12 01:53:28.373758
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cp = Cryptographic()
    assert cp.hash() != cp.hash()
    assert cp.hash() != cp.hash(Algorithm.MD5)

    try:
        cp._validate_enum('MD5123', Algorithm) # Force raise exception
        assert False
    except:
        assert True

# Generated at 2022-06-12 01:53:29.263458
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    print(provider.hash())


# Generated at 2022-06-12 01:53:34.465533
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(1) == 'b0e39e02de968b25630e5fc9e5bb5d5e5cbf5cab43ba03b19e83b2d2b16e15e9'



# Generated at 2022-06-12 01:53:36.564847
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()

    assert crypto.hash()
    assert crypto.hash(algorithm=Algorithm.SHA256)
    assert crypto.hash(algorithm=Algorithm.SHA512)

# Generated at 2022-06-12 01:53:43.853921
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    m = Cryptographic()
    assert isinstance(m.hash(Algorithm.MD5), str)
    assert isinstance(m.hash(Algorithm.SHA1), str)
    assert isinstance(m.hash(Algorithm.SHA224), str)
    assert isinstance(m.hash(Algorithm.SHA256), str)
    assert isinstance(m.hash(Algorithm.SHA384), str)
    assert isinstance(m.hash(Algorithm.SHA3_224), str)
    assert isinstance(m.hash(Algorithm.SHA3_256), str)
    assert isinstance(m.hash(Algorithm.SHA3_384), str)
    assert isinstance(m.hash(Algorithm.SHA3_512), str)
    assert isinstance(m.hash(Algorithm.SHA512), str)
    assert isinstance

# Generated at 2022-06-12 01:53:52.907224
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    algorithm = Algorithm()
    from_higher_level = cr.hash()
    cr._seed = 1
    from_lower_level = cr.hash(algorithm)
    assert from_higher_level and from_lower_level
    assert isinstance(from_higher_level, str)
    assert isinstance(from_lower_level, str)
    assert len(from_higher_level) == 64
    assert len(from_lower_level) == 64
    assert from_lower_level != from_higher_level
    # raise NonEnumerableError when algorithm is unsupported
    cr.hash(Algorithm.__members__['GOST_R_34_11'])



# Generated at 2022-06-12 01:53:55.256659
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash = Cryptographic().hash(Algorithm.SHA3_224)
    assert isinstance(hash, str)
    assert len(hash) == 28

# Generated at 2022-06-12 01:54:00.279758
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash."""
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.BLAKE2B)
    assert crypto.hash(Algorithm.BLAKE2S)
    assert crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA224)
    assert crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA384)
    assert crypto.hash(Algorithm.SHA512)
    assert crypto.hash(algorithm=Algorithm.SHA3_224)
    assert crypto.hash(algorithm=Algorithm.SHA3_256)
    assert crypto.hash(algorithm=Algorithm.SHA3_384)
    assert crypto.hash(algorithm=Algorithm.SHA3_512)

# Generated at 2022-06-12 01:54:00.918825
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != ''

# Generated at 2022-06-12 01:54:36.053900
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash(): # noqa: N802
    """Check the working of the method hash."""
    obj = Cryptographic(seed=42)
    assert obj.hash(Algorithm.SHA1) == 'e7d8d2227f7a6a66b52db2d9b449a9b2a1a33f03'


# Generated at 2022-06-12 01:54:37.365134
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic(seed=100500)
    x = cr.hash()
    print(x)

# Generated at 2022-06-12 01:54:39.308334
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    value = Hash.generate()
    result = Hash.is_valid(value)
    assert result == True

# Generated at 2022-06-12 01:54:41.337870
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    print(c.hash())
    print(c.hash(Algorithm.SHA1))


# Generated at 2022-06-12 01:54:43.249616
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()

    # check length of hash created by method hash
    s = c.hash()
    print(s)
    assert len(s) > 0


# Generated at 2022-06-12 01:54:44.709560
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    x = c.hash()
    assert isinstance(x, str)


# Generated at 2022-06-12 01:54:47.929607
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    hashes = []
    for i in range(10):
        hashes.append(cr.hash(Algorithm.SHA256))
    # Check that all hashes are different
    assert len(set(hashes)) == 10



# Generated at 2022-06-12 01:54:52.264361
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    print(Algorithm.SHA3_512)
    print(crypto.hash(algorithm=Algorithm.SHA3_512))
    print(crypto.hash())


# Generated at 2022-06-12 01:54:53.252406
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1)

# Generated at 2022-06-12 01:54:58.527381
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash('md5').isalnum()
    assert c.hash('sha1').isalnum()
    assert c.hash('sha224').isalnum()
    assert c.hash('sha256').isalnum()
    assert c.hash('sha384').isalnum()
    assert c.hash('sha512').isalnum()
    assert c.hash('blake2b').isalnum()
    assert c.hash('blake2s').isalnum()

# Generated at 2022-06-12 01:56:57.461671
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    h = Cryptographic()
    p = h.hash()
    assert p is not None

# Generated at 2022-06-12 01:57:01.604614
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic(seed=123)
    x = c.hash(algorithm=Algorithm['SHA3_512'])
    y = c.hash(algorithm=Algorithm['SHA3_512'])
    assert x == y
    assert '-' in x
    assert len(x) == 128
    assert '-' in y
    assert len(y) == 128


# Generated at 2022-06-12 01:57:03.078676
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cry = Cryptographic()
    cry.hash()


# Generated at 2022-06-12 01:57:07.666606
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()

    assert crypto.hash() != crypto.hash()
    assert crypto.hash().isalnum() is True
    assert crypto.hash(Algorithm.SHA512) != crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA512).isalnum() is True


# Generated at 2022-06-12 01:57:09.484295
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryp = Cryptographic()
    cryp.hash(algorithm=Algorithm.BLAKE2B)

# Generated at 2022-06-12 01:57:11.882340
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test to test the method 'hash' of class Cryptographic."""
    cryptographic = Cryptographic()

    assert cryptographic.hash() == cryptographic.hash()



# Generated at 2022-06-12 01:57:17.234904
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryp = Cryptographic()
    assert cryp.hash(algorithm=Algorithm.MD5).startswith('a')
    assert cryp.hash(algorithm=Algorithm.SHA1).startswith('a')
    assert cryp.hash(algorithm=Algorithm.SHA224).startswith('a')
    assert cryp.hash(algorithm=Algorithm.SHA256).startswith('a')
    assert cryp.hash(algorithm=Algorithm.SHA384).startswith('a')
    assert cryp.hash(algorithm=Algorithm.SHA512).startswith('a')
    assert cryp.hash(algorithm=Algorithm.SHA3_224).startswith('a')
    assert cryp.hash(algorithm=Algorithm.SHA3_256).startswith('a')
    assert cry

# Generated at 2022-06-12 01:57:19.016417
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    # print(provider.hash(Algorithm.SHA_512))
    assert isinstance(provider.hash(Algorithm.SHA_512), str)

# Generated at 2022-06-12 01:57:19.944142
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    x = Cryptographic()
    assert(x.hash().isalnum())


# Generated at 2022-06-12 01:57:21.720341
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic(16).hash(), str)