

# Generated at 2022-06-12 01:51:34.994820
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(), str)
    assert len(Cryptographic().hash()) == 128
    assert isinstance(Cryptographic().hash(Algorithm.SHA3_224), str)
    assert len(Cryptographic().hash(Algorithm.SHA3_224)) == 56
    assert isinstance(Cryptographic().hash(Algorithm.BLAKE2S), str)
    assert len(Cryptographic().hash(Algorithm.BLAKE2S)) == 64


# Generated at 2022-06-12 01:51:36.951285
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    res = crypto.hash()
    assert type(res) == str


# Generated at 2022-06-12 01:51:39.834768
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Arrange
    Crypto = Cryptographic("en")
    assert callable(Crypto.hash)
    assert type(Crypto.hash()) == str


# Generated at 2022-06-12 01:51:41.366517
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA3_512)

# Generated at 2022-06-12 01:51:43.176443
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-12 01:51:48.378972
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test of method hash of class Cryptographic"""
    crypto = Cryptographic()
    algos = [
        "md5", "sha1", "sha224", "sha256", "sha384",
        "sha512", "blake2b", "blake2s", "sha3_224",
        "sha3_256", "sha3_384", "sha3_512", "shake_128",
        "shake_256",
    ]
    for algo in algos:
        assert len(crypto.hash(getattr(Algorithm, algo.upper()))) == int(algo.replace('sha', '')) * 2


# Generated at 2022-06-12 01:51:55.240185
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic(seed=123)
    assert c.hash() == '8b09d623474755e5f5cd5bcf8e2e9111'
    assert c.hash(Algorithm.SHA224) == 'b1bd0bceeabedfc06b358e3f3d12b7ac1c0e842b5d1c5a5e5b5a2b5'


# Generated at 2022-06-12 01:51:56.869342
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    hash = cr.hash()
    assert isinstance(hash, str)


# Generated at 2022-06-12 01:52:06.163370
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != ''
    assert len(c.hash()) == 64
    assert c.hash(Algorithm.SHA1) != ''
    assert len(c.hash(Algorithm.SHA1)) == 40
    assert c.hash(Algorithm.SHA256) != ''
    assert len(c.hash(Algorithm.SHA256)) == 64
    assert c.hash(Algorithm.SHA384) != ''
    assert len(c.hash(Algorithm.SHA384)) == 96
    assert c.hash(Algorithm.SHA512) != ''
    assert len(c.hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-12 01:52:09.959959
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    crypto = Cryptographic()
    algo = crypto.random.choice(list(Algorithm))
    hash = crypto.hash(algo)

    print('Hash: ' + hash + '  Algorithm: ' + algo.value)



# Generated at 2022-06-12 01:52:18.739951
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(), str)

# Generated at 2022-06-12 01:52:22.042765
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    crypto = Cryptographic()
    result = crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.MD5) == result

# Generated at 2022-06-12 01:52:28.521412
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test Cryptographic hash."""
    crypto = Cryptographic()
    assert crypto.hash().isalnum()
    assert crypto.hash(Algorithm.MD5).isalnum()
    assert crypto.hash(Algorithm.SHA3_224).isalnum()
    assert crypto.hash(Algorithm.SHA3_256).isalnum()
    assert crypto.hash(Algorithm.SHA3_384).isalnum()
    assert crypto.hash(Algorithm.SHA3_512).isalnum()
    assert crypto.hash(Algorithm.BLAKE2B).isalnum()
    assert crypto.hash(Algorithm.BLAKE2S).isalnum()
    assert crypto.hash(Algorithm.SHA1).isalnum()
    assert crypto.hash(Algorithm.SHA224).isalnum()
    assert crypto.hash(Algorithm.SHA256).isalnum()

# Generated at 2022-06-12 01:52:38.651474
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    x = Cryptographic(seed=0)
    x.seed(0)
    assert x.hash(Algorithm.MD5) == 'a9e47c1575f910c828ca0f638904373f'
    assert x.hash(Algorithm.SHA1) == '9d2bd112c90e3f3b82c7b22f091e5d5f63237150'
    assert x.hash(Algorithm.SHA224) == 'e7c593483ffe0d7fd11ad2f955f9c0ae698d744e2876c1f7e1327d31'

# Generated at 2022-06-12 01:52:45.966605
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    import base64

    c = Cryptographic()
    m = hashlib.md5(b'Hello world').hexdigest()
    sha1 = hashlib.sha1(b'Hello world').hexdigest()
    sha2 = hashlib.sha224(b'Hello world').hexdigest()
    sha3_256 = hashlib.sha3_256(b'Hello world').hexdigest()
    b64 = base64.b64encode(b'Hello world')

    assert c.hash(Algorithm.MD5) == m
    assert c.hash(Algorithm.SHA1) == sha1
    assert c.hash(Algorithm.SHA224) == sha2
    assert c.hash(Algorithm.SHA3_256) == sha3_256
    assert c.hash(Algorithm.BASE64)

# Generated at 2022-06-12 01:52:48.697063
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("---- Test 1 ----")
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-12 01:52:50.345917
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    result = crypto.hash(Algorithm.SHA1)
    assert len(result) == 40

# Generated at 2022-06-12 01:52:53.266724
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	assert set([]) == set(['sha224', 'sha384', 'sha1', 'sha256', 'sha512', 'md5']) - set(Cryptographic()._data)  # type: ignore


# Generated at 2022-06-12 01:52:55.086110
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    for i in range(10):
        assert Cryptographic().hash(Algorithm.MD5) != Cryptographic().hash(Algorithm.MD5)

# Generated at 2022-06-12 01:52:57.388626
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    print('Method hash:', Cryptographic().hash(Algorithm.SHA256))


# Generated at 2022-06-12 01:53:24.888112
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    import hashlib
    data = '079f0dac-a8e3-4f3e-9b5e-b5d6c537768f'

    assert Cryptographic().hash(Algorithm.SHA512) == hashlib.sha512(data.encode()).hexdigest()


# Generated at 2022-06-12 01:53:27.313980
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import pytest
    c = Cryptographic()
    with pytest.raises(ValueError):
        print(c.hash(Algorithm.BASE64))
    print(c.hash(Algorithm.SHA1))

# Generated at 2022-06-12 01:53:32.406538
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cp = Cryptographic()
    h = cp.hash(Algorithm.SHA384)
    assert h == '5a5e5b6a5d357dbe85e7bf8eb77f518f46a64660c1f63a9fae976e1180c4ceae1941ff4db8e29dfc2a1e0e235da3e065'

# Generated at 2022-06-12 01:53:35.075458
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	from mimesis.enums import Algorithm
	assert Algorithm.MD5.value in Cryptographic().hash(Algorithm.MD5)


# Generated at 2022-06-12 01:53:38.044567
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print()
    print("---------------TESTING CryptoGraph.hash() method------------------")
    g = Cryptographic()
    print("This is an example of the hash data generated by default: ")
    print(g.hash())
    print("This is a hash data generated in md5 algorithm: ")
    print(g.hash(Algorithm.MD5))

# Generated at 2022-06-12 01:53:41.904805
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash()
    assert Cryptographic.hash(Algorithm.SHA256)
    assert Cryptographic.hash(Algorithm.SHA512)
    assert Cryptographic.hash(Algorithm.SHA384)
    assert Cryptographic.hash(Algorithm.SHA224)
    assert Cryptographic.hash(Algorithm.MD5)


# Generated at 2022-06-12 01:53:42.831584
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash().isalnum()

# Generated at 2022-06-12 01:53:52.589446
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    result = hashlib.sha256(Cryptographic().uuid().encode()).hexdigest()
    # Note: Gecko-Lorem generates the same hash
    # even when seeding, which makes it cryptographically unsafe.
    assert Cryptographic().hash(Algorithm.SHA256) == result
    assert Cryptographic().hash(Algorithm.SHA256) == Cryptographic().hash(Algorithm.SHA256)
    assert Cryptographic().hash(Algorithm.SHA256) != Cryptographic().hash(Algorithm.SHA512)
    assert Cryptographic().hash(Algorithm.SHA256) != Cryptographic().hash(Algorithm.SHA3_224)
    assert Cryptographic().hash(Algorithm.SHA256) != Cryptographic().hash(Algorithm.MD5)

# Generated at 2022-06-12 01:53:54.654761
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic(seed=str(10))
    h = c.hash()

    print(h)

# Generated at 2022-06-12 01:53:58.306371
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    assert isinstance(provider.hash(), str)
    assert isinstance(provider.hash(Algorithm.SHA1), str)
    assert isinstance(provider.hash(Algorithm.SHA256), str)
    assert isinstance(provider.hash(Algorithm.SHA512), str)
    assert isinstance(provider.hash(Algorithm.MD5), str)


# Generated at 2022-06-12 01:57:04.476562
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for the method hash of class Cryptographic."""
    cr = Cryptographic()

# Generated at 2022-06-12 01:57:07.065946
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    output = provider.hash(Algorithm.MD5)
    assert len(output) == 32


# Generated at 2022-06-12 01:57:14.725930
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    x = Cryptographic(seed=123)
    y = Cryptographic(seed=123)
    assert x.hash() == y.hash()
    assert x.hash() == 'dae4f4d44aaeffbb6ee8fe6c8553e3d5'
    assert x.hash(Algorithm(5)) == 'fd22fdc5a8e9a2530fc52d0a5e5e5dbe'

# Generated at 2022-06-12 01:57:17.427957
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash(Algorithm.MD5) == '3f3b74ae3fc8d263cebc87b87c7a76f5'


# Generated at 2022-06-12 01:57:19.709826
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():  # noqa: N802
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    a = c.hash()  # noqa: F841
    assert type(a) == str
    assert len(a) == 32


# Generated at 2022-06-12 01:57:23.597370
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash_result = Cryptographic().hash(Algorithm.SHA512)
    # print(hash_result)
    assert len(hash_result) == 128


# Generated at 2022-06-12 01:57:25.636328
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    value = Cryptographic().hash()
    assert value
    assert isinstance(value, str)


# Generated at 2022-06-12 01:57:35.943041
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    crypto = Cryptographic()
    assert crypto.hash() is not None
    assert crypto.hash(algorithm=Algorithm.BLAKE2S) is not None
    assert crypto.hash(Algorithm.SHA3_224) is not None
    assert crypto.hash(Algorithm.SHA512) is not None
    assert crypto.hash(Algorithm.SHA224) is not None
    assert crypto.hash(Algorithm.SHA1) is not None
    assert crypto.hash(Algorithm.SHA3_384) is not None
    assert crypto.hash(Algorithm.SHA3_256) is not None
    assert crypto.hash(Algorithm.SHA384) is not None
    assert crypto.hash(Algorithm.SHA256) is not None
    assert crypto.hash(Algorithm.SHA3_512)

# Generated at 2022-06-12 01:57:37.355269
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    print(c.hash())


# Generated at 2022-06-12 01:57:38.771178
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(), str)
