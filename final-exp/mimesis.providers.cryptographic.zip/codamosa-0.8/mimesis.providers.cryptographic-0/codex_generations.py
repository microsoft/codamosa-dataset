

# Generated at 2022-06-12 01:58:56.316768
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash('md5') == '6bdbc6f7a6d1fd6b7f3dcdea47c39a74'
    assert Cryptographic().hash('sha1') == 'f1d0d23a8573e5e4430c6d0e2e9d6b1a6b9c451d'
    assert Cryptographic().hash('sha256') == 'b265383b88f9d13a7e4e4c6a7a2c2d8bb726b0c53d02da72ecb55ece849e2a2f'

# Generated at 2022-06-12 01:59:00.705960
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryp = Cryptographic()
    assert cryp.hash(Algorithm.MD5)


# Generated at 2022-06-12 01:59:08.689479
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = Cryptographic()
    assert len(data.hash(Algorithm.MD5)) == 32
    assert len(data.hash(Algorithm.SHA1)) == 40
    assert len(data.hash(Algorithm.SHA224)) == 56
    assert len(data.hash(Algorithm.SHA256)) == 64
    assert len(data.hash(Algorithm.SHA384)) == 96
    assert len(data.hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-12 01:59:14.640590
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # for i in range(0, 10000):
    print(Cryptographic().hash())

if __name__ == '__main__':
    test_Cryptographic_hash()

# Generated at 2022-06-12 01:59:23.755763
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.MD4)) == 32
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40
    assert len(Cryptographic().hash(Algorithm.SHA224)) == 56
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA384)) == 96
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-12 01:59:28.767153
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    m = Cryptographic()
    hashes = []
    for _ in range(10):
        hashes.append(m.hash(Algorithm.SHA1))
    assert len(hashes) == 10
    assert len(set(hashes)) == 10


# Generated at 2022-06-12 01:59:31.028936
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    pass

# Generated at 2022-06-12 01:59:42.548036
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == 'a51569d1f68f8fe8c96486e0d23f4742'
    assert crypto.hash(Algorithm.SHA1) == 'dab0051e4c9a1e2a6d806e6a8a1fcfcccb3e5981'
    assert crypto.hash(Algorithm.SHA256) == '6e0e06a0dc493e04c90ed3faf909d8fd8b9f964d61187df6c5518ded859c85f0'

# Generated at 2022-06-12 01:59:45.752754
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() != crypto.hash()


# Generated at 2022-06-12 01:59:50.974141
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    _hash_ = Cryptographic().hash()
    assert len(_hash_) == 64
    assert isinstance(_hash_, str)
