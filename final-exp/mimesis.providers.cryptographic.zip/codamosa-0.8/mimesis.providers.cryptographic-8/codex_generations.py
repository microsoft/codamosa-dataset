

# Generated at 2022-06-12 01:51:33.993838
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    '''
    Test
    :return:
    '''
    a = Cryptographic()

    assert(isinstance(a.hash(), str))

    return 0


# Generated at 2022-06-12 01:51:42.574168
# Unit test for method hash of class Cryptographic

# Generated at 2022-06-12 01:51:44.164248
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    random = Cryptographic()
    random.hash(algorithm='md5')



# Generated at 2022-06-12 01:51:46.211779
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    print (provider.hash(Algorithm.SHA3_256))


# Generated at 2022-06-12 01:51:50.588570
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import hashlib
    testseed = 123
    c = Cryptographic(seed = testseed)
    assert c.hash(Algorithm.SHA_256) == hashlib.sha256(c.uuid().encode()).hexdigest()


# Generated at 2022-06-12 01:51:54.692271
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    assert isinstance(provider.hash(Algorithm.MD5), str)
    assert isinstance(provider.hash(Algorithm.SHA256), str)
    assert isinstance(provider.hash(Algorithm.SHA512), str)


# Generated at 2022-06-12 01:52:00.063466
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    # Python 2.6 compatibility
    try:
        import hashlib
        _hash = hashlib.md5
    except ImportError:
        import md5
        _hash = md5.new

    import mimesis.builtins
    salt = mimesis.builtins.Cryptographic.uuid()

    result = mimesis.builtins.Cryptographic.hash(
        algorithm=mimesis.builtins.Algorithm.MD5)

    assert result == _hash(salt).hexdigest()

# Generated at 2022-06-12 01:52:06.242648
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    data = [
        Algorithm.SHA224,
        Algorithm.SHA256,
        Algorithm.SHA384,
        Algorithm.SHA512,
        Algorithm.SHA3_224,
        Algorithm.SHA3_256,
        Algorithm.SHA3_384,
        Algorithm.SHA3_512,
    ]

    for algorithm in data:
        assert Cryptographic().hash(algorithm=algorithm) is not None

# Generated at 2022-06-12 01:52:08.351335
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    result = c.hash()
    assert isinstance(result, str)


# Generated at 2022-06-12 01:52:13.843769
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash() == Cryptographic.hash()
# if __name__ == '__main__':
#     print(Cryptographic.hash())
#     print(Cryptographic.token_hex())
#     print(Cryptographic.token_bytes())
#     print(Cryptographic.token_urlsafe())
#     print(Cryptographic.mnemonic_phrase())

# Generated at 2022-06-12 01:52:22.632567
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA1)



# Generated at 2022-06-12 01:52:24.402119
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    print(provider.hash())

if __name__ == '__main__':
    test_Cryptographic_hash()

# Generated at 2022-06-12 01:52:25.605171
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    assert obj.hash().__len__() > 0


# Generated at 2022-06-12 01:52:29.402525
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test the method 'hash' of class Cryptographic."""
    from mimesis.enums import Algorithm

    algorithm = Algorithm.SHA1
    crypto = Cryptographic()
    result = crypto.hash(algorithm=algorithm)
    assert len(result) == 40
    assert isinstance(result, str)

# Generated at 2022-06-12 01:52:34.122727
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    alg = Algorithm.BLAKE2B
    c = Cryptographic()
    hash_obj = c.hash(alg)
    print(hash_obj)
    print(len(hash_obj))

if __name__ == "__main__":
    test_Cryptographic_hash()

# Generated at 2022-06-12 01:52:40.827792
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    import hashlib
    algorithm = Algorithm.SHA256
    crypto = Cryptographic()
    result = crypto.hash(algorithm)
    real_hash = hashlib.sha256(crypto.uuid(as_object=True).bytes).hexdigest()
    assert result == real_hash

# Generated at 2022-06-12 01:52:42.411836
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-12 01:52:48.506662
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(Algorithm.MD5), str)
    assert isinstance(Cryptographic().hash(Algorithm.SHA1), str)
    assert isinstance(Cryptographic().hash(Algorithm.SHA256), str)
    assert isinstance(Cryptographic().hash(Algorithm.SHA512), str)

# Generated at 2022-06-12 01:52:53.955606
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    import random
    import sys

    print('Testing method hash of class Cryptographic')

    crypto = Cryptographic()

    # NB: Test case 'algs' contains algorithm names from standart lib 'hashlib'.
    algs = [x for x in dir(hashlib) if x.islower()]
    alg_enum = [x.value for x in Algorithm]

    # Main part of unit test for method 'hash'
    for alg in random.sample(alg_enum, min(10, len(alg_enum))):
        hash_ = crypto.hash(alg)
        # NB: Validation by lenght
        assert len(hash_) == 64

    # Additional part of unit test (based on algorithm list)

# Generated at 2022-06-12 01:52:56.221486
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """
    Unit test for method hash of class Cryptographic
    """
    cr = Cryptographic()
    cr.hash("MD5")


# Generated at 2022-06-12 01:53:18.299063
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = Cryptographic.hash()
    assert(len(data) >= 32)
    assert isinstance(data, str)


# Generated at 2022-06-12 01:53:20.984479
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cp = Cryptographic()
    assert cp.hash() != ""

# Generated at 2022-06-12 01:53:26.282462
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic"""
    print("Testing method hash of class Cryptographic")
    cr = Cryptographic()
    print("Asserting return type")
    assert(isinstance(cr.hash(), str))
    print("Asserting that return value is not None")
    assert(cr.hash() is not None)
    print("Asserting that return value is not empty")
    assert(cr.hash() != "")


# Generated at 2022-06-12 01:53:36.039778
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()

    assert crypto.hash().__class__ == 'str'
    assert len(crypto.hash()) == 40
    assert crypto.hash(Algorithm.MD5).__class__ == 'str'
    assert len(crypto.hash(Algorithm.MD5)) == 32
    assert crypto.hash(Algorithm.SHA1).__class__ == 'str'
    assert len(crypto.hash(Algorithm.SHA1)) == 40
    assert crypto.hash(Algorithm.SHA224).__class__ == 'str'
    assert len(crypto.hash(Algorithm.SHA224)) == 56
    assert crypto.hash(Algorithm.SHA256).__class__ == 'str'
    assert len(crypto.hash(Algorithm.SHA256)) == 64
    assert crypto.hash(Algorithm.SHA384).__class

# Generated at 2022-06-12 01:53:36.816304
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()

# Generated at 2022-06-12 01:53:37.883209
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-12 01:53:39.726622
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = Cryptographic().hash(Algorithm.SHA512)
    assert len(data) == 128



# Generated at 2022-06-12 01:53:41.090208
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    x = c.hash()
    assert len(x) > 0



# Generated at 2022-06-12 01:53:42.094521
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cpt = Cryptographic()
    cpt.hash()



# Generated at 2022-06-12 01:53:46.819131
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # 20 characters long
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32

    # 40 characters long
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40

    # 64 characters long
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64

    # 128 characters long
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-12 01:54:29.595450
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryp = Cryptographic()
    a = cryp.hash()


# Generated at 2022-06-12 01:54:31.277718
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()



# Generated at 2022-06-12 01:54:36.031449
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of Cryptographic class."""

    obj = Cryptographic('en')
    value = obj.hash(Algorithm.SHA512)
    assert isinstance(value,str)
    assert type(value) == str
    assert len(value) == 128
    assert Algorithm.SHA512.value not in value


# Generated at 2022-06-12 01:54:44.096816
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    words = mimesis.Cryptographic.hash()
    mimesis.Cryptographic.hash(algorithm=Algorithm.SHA224)
    mimesis.Cryptographic.hash(algorithm=Algorithm.SHA256)
    mimesis.Cryptographic.hash(algorithm=Algorithm.SHA384)
    mimesis.Cryptographic.hash(algorithm=Algorithm.SHA512)
    mimesis.Cryptographic.hash(algorithm=Algorithm.MD5)
    mimesis.Cryptographic.hash(algorithm=Algorithm.BLAKE2B)
    mimesis.Cryptographic.hash(algorithm=Algorithm.BLAKE2S)
    mimesis.Cryptographic.hash(algorithm=Algorithm.SHA3_224)

# Generated at 2022-06-12 01:54:53.453771
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()

    # Unit test for method hash of class Cryptographic with default hash algorithm
    hash = crypto.hash()
    assert isinstance(hash, str)
    assert len(hash) == 40

    # Unit test for method hash of class Cryptographic with md5 hash algorithm
    hash = crypto.hash(Algorithm.MD5)
    assert isinstance(hash, str)
    assert len(hash) == 32

    # Unit test for method hash of class Cryptographic with sha1 hash algorithm
    hash = crypto.hash(Algorithm.SHA1)
    assert isinstance(hash, str)
    assert len(hash) == 40

    # Unit test for method hash of class Cryptographic with sha224 hash algorithm
    hash = crypto.hash(Algorithm.SHA224)
    assert isinstance(hash, str)
    assert len(hash)

# Generated at 2022-06-12 01:54:55.581470
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test_hash = Cryptographic().hash(Algorithm.SHA_1)
    assert len(test_hash) == 40


# Generated at 2022-06-12 01:55:02.437635
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
        # Check if hash returns not-empty string
        assert Cryptographic().hash() != ''
        # Check if hash returns string with the default length
        assert len(Cryptographic().hash()) == 64
        # Check if hash returns proper hash
        assert Cryptographic().hash(Algorithm.md5) == 'cfcc08f75fd8ace2d2c3b3ea3ac42ac0'
        assert Cryptographic().hash(Algorithm.sha1) == 'e8b5fbeb7fc531c43e7b82687390121ad1a98c52'
        assert Cryptographic().hash(Algorithm.sha224) == '2ffb8f9d4f3a6d03c6cee4a8c72d7848f6ea4e6c1d6e9bd41f9a9a7'

# Generated at 2022-06-12 01:55:03.350977
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    a = Algorithm.SHA3_512
    assert isinstance(cr.hash(algorithm=a), str) == True

# Generated at 2022-06-12 01:55:04.784300
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  obj = Cryptographic()
  print (obj.hash())


# Generated at 2022-06-12 01:55:05.749672
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != None
    