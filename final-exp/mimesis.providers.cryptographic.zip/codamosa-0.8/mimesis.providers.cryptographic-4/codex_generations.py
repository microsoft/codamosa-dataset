

# Generated at 2022-06-12 01:51:27.836995
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    result = c.hash()
    assert result is not None


# Generated at 2022-06-12 01:51:29.588884
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    result = c.hash()
    assert result is not None
    assert len(result) == 64

# Generated at 2022-06-12 01:51:40.131354
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    seed = 10000
    c = Cryptographic(seed=seed)

    result = c.hash(algorithm=Algorithm.MD5)
    assert result == '3d3c3e3d3e3c3d3e3d3c3f3e3d3c3e3d', "Cryptographic.hash(algorithm=Algorithm.MD5) failed"

    result = c.hash(algorithm=Algorithm.SHA1)
    assert result == 'e1e2e1e2e2e1e2e1e2e2e1e2e1e1e1e1', "Cryptographic.hash(algorithm=Algorithm.SHA1) failed"

    result = c.hash(algorithm=Algorithm.SHA224)

# Generated at 2022-06-12 01:51:43.090643
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypt = Cryptographic()
    hash1 = crypt.hash(Algorithm.SHA256)
    print(hash1)
    assert hash1 != None


# Generated at 2022-06-12 01:51:49.122653
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    c = Cryptographic()
    # base64
    h1 = c.hash(Algorithm.BASE64)
    assert (h1 == 'QlVVTklTU3lYVzZCbkZOUVd4MXR0MW1VNWtiVDh0Y1VHV0JXcWVzZDBybHQxVzFw');
    # md5
    h2 = c.hash(Algorithm.MD5)
    assert (h2 == 'fa6d59fbf19dccc0beb96e11d9e8ac1f');
    # sha1
    h3 = c.hash(Algorithm.SHA1)

# Generated at 2022-06-12 01:51:51.409278
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic"""
    crypto = Cryptographic()
    assert crypto.hash() != crypto.hash()


# Generated at 2022-06-12 01:52:00.169141
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("------ unit test for method hash of class Cryptographic ------")
    print(Cryptographic().hash())
    print(Cryptographic().hash(Algorithm.MD5))
    print(Cryptographic().hash(Algorithm.SHA1))
    print(Cryptographic().hash(Algorithm.SHA224))
    print(Cryptographic().hash(Algorithm.SHA256))
    print(Cryptographic().hash(Algorithm.SHA384))
    print(Cryptographic().hash(Algorithm.SHA512))
    print(Cryptographic().hash(Algorithm.BLAKE2B))
    print(Cryptographic().hash(Algorithm.BLAKE2S))
    print(Cryptographic().hash(Algorithm.SHA3_224))
    print(Cryptographic().hash(Algorithm.SHA3_256))

# Generated at 2022-06-12 01:52:02.311120
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash_function = Cryptographic.Meta.name + '.hash'
    assert isinstance(eval(hash_function)(), str)

# Generated at 2022-06-12 01:52:03.369082
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(), str)

# Generated at 2022-06-12 01:52:04.730234
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    result = Cryptographic.hash()
    print(result)


# Generated at 2022-06-12 01:52:18.016038
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) is not None


# Generated at 2022-06-12 01:52:21.313243
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert len(crypto.hash()) == 40
    assert len(crypto.hash(Algorithm.SHA512)) == 128

# Generated at 2022-06-12 01:52:24.436884
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """."""
    # Initialization of class Cryptographic
    cp = Cryptographic()

    # Get the result of method cp.hash()
    result = cp.hash()

    # Check the result
    assert isinstance(result, str)
    assert len(result) == 32


# Generated at 2022-06-12 01:52:26.585510
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    hash_value = cr.hash()
    assert isinstance(hash_value, str)
    assert len(hash_value) == 32


# Generated at 2022-06-12 01:52:29.038446
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1) == '540d5b56f1b1918f0d2091a7a9a555a972cd67ed'

# Generated at 2022-06-12 01:52:33.510135
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    #assert Cryptographic().hash() == '38b060a751ac96384cd9327eb1b1e36a21fdb71114be07434c0cc7bf63f6e1da274edebfe76f65fbd51ad2f14898b95b'
    assert True

# Generated at 2022-06-12 01:52:36.139211
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    assert Cryptographic().hash(Algorithm.SHA224).__len__() == 56

# Generated at 2022-06-12 01:52:38.283429
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    hash_ = c.hash(Algorithm.SHA384)
    print(hash_)
    assert len(hash_) == 96



# Generated at 2022-06-12 01:52:41.865628
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of Cryptographic class."""
    crp = Cryptographic()
    ans = crp.hash()
    assert ans, True
    assert len(ans), 40


# Generated at 2022-06-12 01:52:51.815457
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    c = Cryptographic()

    # This tests are not so good for testing,
    # because in different implementations hashing algorithm
    # can be different.
    # But for now it can be useful.
    assert c.hash()
    assert c.hash(algorithm = Algorithm.SHA1)
    assert c.hash(algorithm = Algorithm.SHA224)
    assert c.hash(algorithm = Algorithm.SHA256)
    assert c.hash(algorithm = Algorithm.SHA384)
    assert c.hash(algorithm = Algorithm.SHA512)
    assert c.hash(algorithm = Algorithm.MD5)

# Generated at 2022-06-12 01:53:15.979665
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(Algorithm.MD5) == "7e8a4d4a4fefd38cdfe6f827483b1408"


# Generated at 2022-06-12 01:53:20.832344
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.providers.cryptographic import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.enums import Algorithm as Alg
    from mimesis.enums import CustomAlgorithm

    provider = Cryptographic()

    assert type(provider.hash()) is str
    assert 32 <= len(provider.hash()) <= 128
    assert 32 <= len(provider.hash(Alg.SHA)) <= 128
    assert 32 <= len(provider.hash(Algorithm.SHA256)) <= 128
    assert 32 <= len(provider.hash(CustomAlgorithm.SHA512)) <= 128



# Generated at 2022-06-12 01:53:22.579985
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    result = Cryptographic.hash()
    assert isinstance(result, str)


# Generated at 2022-06-12 01:53:26.349781
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Method hash should generate hash
    # with needed algorithm
    assert Cryptographic().hash(Algorithm.SHA256)
    
    # Method hash should raise NonEnumerableError
    # with unsupported algorithm
    try:
        Cryptographic().hash("hello")
        assert False
    except:
        assert True


# Generated at 2022-06-12 01:53:36.110321
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic(seed = 42)
    assert obj.hash(Algorithm.MD5) == 'fd0f2e2dafbf7e8f890ced0f7b0caa64'
    assert obj.hash(Algorithm.SHA1) == '6f983df8e310a487fda6d1d0b7e944ec707d9c4d'
    assert obj.hash(Algorithm.SHA224) == 'd595acbac50b3f924f53cc32b5f5b43a5e5a5f5e580095d5d5f4933e'

# Generated at 2022-06-12 01:53:37.533648
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    assert provider.hash()!=''
    assert provider.hash()!=None

# Generated at 2022-06-12 01:53:44.436983
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == '2e6e358f4a4262c4b4d0dfd98a7fa00eba4d1ed2b9c0a8ac15b22d561a4c0a1e'
    assert crypto.hash() == '76d7a9a9bf20bc7d6dd0eddb5cbe10e412f79ae7bde72d12dffaf9b9e8e2d204'
    assert crypto.hash(Algorithm.SHA224) == '6a4765b0d95818763c8dc228b6e44e1c2e6a59f8cb8d96882a6d0366'

# Generated at 2022-06-12 01:53:47.165923
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of Cryptographic class."""
    crypto = Cryptographic()
    result = crypto.hash()
    assert isinstance(result, str) is True

# Generated at 2022-06-12 01:53:51.435764
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()

    # Default algorithm
    hash = provider.hash()

    # Check for a given algorithm
    for key in Algorithm:
        hash = provider.hash(key)

    # Check for a unsupported algorithm
    hash = provider.hash('foo')

# Generated at 2022-06-12 01:53:57.062674
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('<@test_Cryptographic_hash>')
    c = Cryptographic()
    print(type(c.hash()))
    print(c.hash())
    print(c.hash(Algorithm.SHA1))
    print(c.hash(Algorithm.SHA256))
    print(c.hash(Algorithm.SHA512))


# Generated at 2022-06-12 01:54:26.509255
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5)
    assert Cryptographic().hash(Algorithm.SHA1)
    assert Cryptographic().hash(Algorithm.SHA224)
    assert Cryptographic().hash(Algorithm.SHA256)
    assert Cryptographic().hash(Algorithm.SHA384)
    assert Cryptographic().hash(Algorithm.SHA512)


# Generated at 2022-06-12 01:54:34.150337
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    c = Cryptographic()
    res = c.hash(Algorithm.SHA3_512)
    assert isinstance(res, str), f'Expected <class \'str\'>, got {type(res)}.'
    assert len(res) == 128, f'Expected {128}, got {len(res)}.'



# Generated at 2022-06-12 01:54:35.209619
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    hash = provider.hash()
    print(hash)
    assert len(hash) == 32

# Generated at 2022-06-12 01:54:38.596686
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    instance = Cryptographic()

    assert instance.hash()
    assert isinstance(instance.hash(Algorithm.MD5), str)
    assert isinstance(instance.hash(Algorithm.SHA256), str)
    assert isinstance(instance.hash(Algorithm.SHA1), str)


# Generated at 2022-06-12 01:54:46.454328
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    m = Cryptographic()
    assert isinstance(m.hash(Algorithm.MD5), str)
    assert isinstance(m.hash(Algorithm.SHA1), str)
    assert isinstance(m.hash(Algorithm.SHA224), str)
    assert isinstance(m.hash(Algorithm.SHA256), str)
    assert isinstance(m.hash(Algorithm.SHA384), str)
    assert isinstance(m.hash(Algorithm.SHA512), str)
    assert isinstance(m.hash(Algorithm.BLAKE2S), str)
    assert isinstance(m.hash(Algorithm.BLAKE2B), str)
    assert isinstance(m.hash(Algorithm.SHA3_224), str)
    assert isinstance(m.hash(Algorithm.SHA3_256), str)

# Generated at 2022-06-12 01:54:49.788361
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash = 'f79aa58750742d4886bb11d7e1bfc6819f26f1adad5b8a0f05e5c4297c9d88e9'
    assert hash == Cryptographic.hash()

# Generated at 2022-06-12 01:54:51.937598
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash(Algorithm.MD5) == Cryptographic.hash(Algorithm.MD5)


# Generated at 2022-06-12 01:54:56.991810
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic.__new__(Cryptographic)
    provider.uuid = lambda *args, **kwargs: '7df38c62-a4a4-4c4d-bb96-2c43aaf578c9'
    algorithm = 'md5'
    algorithm_type = Algorithm[algorithm].value
    assert provider.hash(algorithm_type) == '6e661bb6a190622b1c8a309997fcfb6e'

# Generated at 2022-06-12 01:54:57.918759
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    print(c.hash())


# Generated at 2022-06-12 01:55:04.817817
# Unit test for method hash of class Cryptographic

# Generated at 2022-06-12 01:58:06.177484
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Create object
    obj = Cryptographic()
    # Create hash
    hash_result = obj.hash()
    print('Hash:',hash_result)


# Generated at 2022-06-12 01:58:14.739611
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initialize a provider with default seed
    provider = Cryptographic()
    # Generate a hash using default method sha384
    h = provider.hash()
    # Output: b'd5e547a60f1373c5d0ee9b5f4bbf47e2',
    # print(h)
    # Generate a hash using algorithm blake2b
    h = provider.hash(algorithm=Algorithm.BLAKE2B)
    # Output:
    # b'3aa431bd2b248e9985cd8f868d3c0ce2ec9c05d34d6f0cc1f2665dafe46c637b',
    # print(h)
    return



# Generated at 2022-06-12 01:58:16.875293
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    print(crypto.hash())
    print(crypto.hash('sha256'))


# Generated at 2022-06-12 01:58:18.369083
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    instance = Cryptographic()

    #test
    assert instance.hash()
    #test
    assert instance.hash(algorithm = Algorithm.MD5)

# Generated at 2022-06-12 01:58:22.499153
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic(seed=42)
    b = Cryptographic(seed=42)
    assert(a.hash() == b.hash())
    c = Cryptographic(seed=43)
    assert(a.hash() != c.hash())


# Generated at 2022-06-12 01:58:23.817001
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 32
    assert Cryptographic().hash().isalnum()


# Generated at 2022-06-12 01:58:25.686014
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    result = crypto.hash()
    assert type(result) == str


# Generated at 2022-06-12 01:58:27.444795
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    x = Cryptographic()
    y = Cryptographic()
    assert x.hash() != y.hash()


# Generated at 2022-06-12 01:58:29.101460
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    md5 = crypto.hash(Algorithm.MD5)
    assert isinstance(md5, str)


# Generated at 2022-06-12 01:58:31.287408
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    hash = a.hash()
    assert isinstance(hash, str) == True
    assert len(hash) == 32
