

# Generated at 2022-06-12 01:51:40.972582
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crpg = Cryptographic()
    assert isinstance(crpg.hash(),str)
    assert isinstance(crpg.hash(Algorithm.MD5),str)
    assert isinstance(crpg.hash(Algorithm.SHA1),str)
    assert isinstance(crpg.hash(Algorithm.SHA224),str)
    assert isinstance(crpg.hash(Algorithm.SHA256),str)
    assert isinstance(crpg.hash(Algorithm.SHA384),str)
    assert isinstance(crpg.hash(Algorithm.SHA512),str)


# Generated at 2022-06-12 01:51:45.585478
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.uuid() == 'b1d6b095-5a5a-4ef0-9feb-791a4bd4f7be'
    assert crypto.hash(algorithm=Algorithm.MD5) == 'f84c7f1420cbf8b7baf5c0c788c05402'

# Generated at 2022-06-12 01:51:49.400591
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    Cryptographic().hash(algorithm=Algorithm.SHA1)


# Generated at 2022-06-12 01:51:55.293788
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()

    # Tests algorithm.
    assert crypto.hash(algorithm=Algorithm.SHA_1) == 'd7fcbf45c8efb7fafbc59e1b715d2d8a7b0a75e6'

    # Tests errors.
    with pytest.raises(NonEnumerableError):
        crypto.hash(algorithm='UNKNOWN_HASH')

# Generated at 2022-06-12 01:51:56.910303
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    answer = provider.hash(Algorithm.SHA256)
    assert len(answer) == 64

# Generated at 2022-06-12 01:52:01.384080
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    expected = '4812e7e8d84b6dd7f3a2d68c00b8af44'
    assert (Cryptographic().hash(Algorithm.MD5) == expected)
    return 


# Generated at 2022-06-12 01:52:09.181822
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    result = crypto.hash(Algorithm.MD5)
    print("MD5 hash generated: " + result)

    # result = crypto.hash(Algorithm.SHA224)
    # print("SHA224 hash generated: " + result)
    #
    # result = crypto.hash(Algorithm.SHA256)
    # print("SHA256 hash generated: " + result)
    #
    # result = crypto.hash(Algorithm.SHA384)
    # print("SHA384 hash generated: " + result)
    #
    # result = crypto.hash(Algorithm.SHA512)
    # print("SHA512 hash generated: " + result)
    #
    # result = crypto.hash(Algorithm.SHA3_224)
    # print("SHA3

# Generated at 2022-06-12 01:52:11.476143
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    result = c.hash()
    assert len(result) == 32

# Generated at 2022-06-12 01:52:14.527107
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic().hash(Algorithm.MD5)
    b = Cryptographic().hash(Algorithm.SHA256)
    assert a != b


# Generated at 2022-06-12 01:52:24.403395
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from random import seed
    from mimesis.enums import Algorithm
    seed(0)
    a = Cryptographic().hash(Algorithm.SHA224)

# Generated at 2022-06-12 01:52:47.187773
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import mimesis.enums as enums
    from mimesis.builtins import Cryptographic

    algorithm = enums.Algorithm.shake_128
    Crypto = Cryptographic(seed=12345)
    print(Crypto.hash(algorithm))
    assert (len(Crypto.hash(algorithm)) >= 0)


# Generated at 2022-06-12 01:52:49.423070
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    assert len(provider.hash()) == 32


# Generated at 2022-06-12 01:52:58.654449
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('Method hash of class Cryptographic')
    m = Cryptographic()
    print(m.hash())
    print(m.hash(Algorithm.SHA1))
    print(m.hash(Algorithm.SHA224))
    print(m.hash(Algorithm.SHA384))
    print(m.hash(Algorithm.SHA256))
    print(m.hash(Algorithm.SHA512))
    print(m.hash(Algorithm.SHA3_224))
    print(m.hash(Algorithm.SHA3_256))
    print(m.hash(Algorithm.SHA3_384))
    print(m.hash(Algorithm.SHA3_512))
    print(m.hash(Algorithm.BLAKE2S))
    print(m.hash(Algorithm.BLAKE2B))

# Generated at 2022-06-12 01:53:01.083377
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    hash = provider.hash()
    print(hash)



# Generated at 2022-06-12 01:53:04.880405
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    result = crypto.hash()
    assert isinstance(result, str)
    assert len(result) == 48

    crypto = Cryptographic('a')
    result1 = crypto.hash()
    result2 = crypto.hash()
    assert result1 != result2
    assert 'SHA1' in result1
    assert 'SHA1' in result2
    assert result1 != result2


# Generated at 2022-06-12 01:53:07.649070
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    h = Cryptographic()
    result = h.hash(Algorithm.SHA1)
    assert isinstance(result, str)

# Generated at 2022-06-12 01:53:09.132440
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA3_224) != None

# Generated at 2022-06-12 01:53:13.238000
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash('md5')
    assert c.hash('sha1')
    assert c.hash('sha224')
    assert c.hash('sha256')
    assert c.hash('sha384')
    assert c.hash('sha512')


# Generated at 2022-06-12 01:53:19.850359
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic"""
    c = Cryptographic()
    assert c.hash() == '8f5a6be924d9d735c5a1ea5c6c1bde5f5d2e8b75a6e9ef624d9f0df218e8e160'
    assert c.hash(algorithm='sha3_512') == '982b0a9e7c81e8f0c749e27b2d204b8c8e97e1de9a1c89dcb7e3bd8d3e90c71d88d4434dbe065b67a198ec4d4b4a4f2a8f55450b7a9e1f9c89f8d846c74d3e3d'

# Generated at 2022-06-12 01:53:23.162364
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    res = obj.hash()
    assert isinstance(res, str)
    assert len(res) == 40
    assert res.startswith("8dad")



# Generated at 2022-06-12 01:53:50.558567
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 32 * 2

# Generated at 2022-06-12 01:53:51.630888
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic('en')
    print(c.hash())

# Generated at 2022-06-12 01:53:55.785154
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    print(crypto.hash(Algorithm.SHA))
    print(crypto.hash(Algorithm.SHA256))
    print(crypto.hash(Algorithm.SHA512))



# Generated at 2022-06-12 01:53:57.062879
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()



# Generated at 2022-06-12 01:53:57.588939
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    pass

# Generated at 2022-06-12 01:53:59.046501
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    pass
    # c = Cryptographic()
    # c.hash(Algorithm(0))



# Generated at 2022-06-12 01:54:01.926992
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()

    # Input: algorithm = None
    _hash = cr.hash()
    assert isinstance(_hash, str) and len(_hash) == 40

    # Input: algorithm = Algorithm.SHA224
    _hash = cr.hash(algorithm=Algorithm.SHA224)
    assert isinstance(_hash, str) and len(_hash) == 56



# Generated at 2022-06-12 01:54:06.492543
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	crypto = Cryptographic()
	assert crypto.hash(Algorithm.MD5) == "ca6a2fe0b0d871f90c15eb08ecde09a6"

# Generated at 2022-06-12 01:54:07.397221
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    new_Cryptographic = Cryptographic()
    assert new_Cryptographic.hash() is not None



# Generated at 2022-06-12 01:54:12.145236
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert c.hash(Algorithm.SHA1) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert c.hash(Algorithm.SHA256) == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'