

# Generated at 2022-06-12 01:51:40.254297
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm

    assert Cryptographic().hash() == Cryptographic().hash()
    assert Cryptographic().hash(algorithm=Algorithm.MD5) == Cryptographic().hash(algorithm=Algorithm.MD5)


# Generated at 2022-06-12 01:51:42.414492
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    try:
        assert Cryptographic.hash()
    except NotImplementedError:
        assert False


# Generated at 2022-06-12 01:51:44.004198
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    f = Cryptographic()
    print(f.hash(algorithm=Algorithm.MD5))


# Generated at 2022-06-12 01:51:48.014821
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = Cryptographic().hash(Algorithm.SHA224)
    assert data == '00671e53d470d668a1b13a755224f9d7fce6f37c9067f8e170c2b7'

# Generated at 2022-06-12 01:51:52.188092
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    assert Cryptographic().hash(Algorithm.MD5) == '89d9a9e7e0f7b5d5c1977f846a85b710'


# Generated at 2022-06-12 01:51:53.513145
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-12 01:51:56.356070
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
   c1 = Cryptographic()
   c2 = c1.hash()
   assert isinstance(c2,str)
   assert len(c2) == 32


# Generated at 2022-06-12 01:51:59.620070
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    enums = crypto._validate_enum(Algorithm)
    for enum in enums:
        hash_ = crypto.hash(enum)
        assert hash_ is not None, "Failed to generate hash"
        assert isinstance(hash_, str), "Failed to generate hash value as str"


# Generated at 2022-06-12 01:52:03.855514
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()

    # Get the string of hash using sha3_512 hashing algorithm.
    result = provider.hash(Algorithm.SHA3_512)

    assert isinstance(result, str)
    assert len(result) == 128



# Generated at 2022-06-12 01:52:05.154020
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    print(crypto.hash())


# Generated at 2022-06-12 01:53:04.901315
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic.hash()) == 40



# Generated at 2022-06-12 01:53:09.457961
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash(Algorithm.SHA1) != None
    assert Cryptographic.hash(Algorithm.SHA224) != None
    assert Cryptographic.hash(Algorithm.SHA256) != None
    assert Cryptographic.hash(Algorithm.SHA384) != None
    assert Cryptographic.hash(Algorithm.SHA512) != None


# Generated at 2022-06-12 01:53:10.317378
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64
    assert Cryptographic().hash().isalnum()


# Generated at 2022-06-12 01:53:12.229925
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    hash_str = provider.hash()
    assert len(hash_str) == 64


# Generated at 2022-06-12 01:53:13.697821
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    result = obj.hash()
    assert result is not 0


# Generated at 2022-06-12 01:53:16.785436
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic(seed=12345)
    result = c.hash(algorithm=Algorithm.SHA256)
    assert result == '4449f26cb883c89219d8ebc9a9a2abca17b20c8542cfd8d190f6723a1f0392c8'

# Generated at 2022-06-12 01:53:19.432390
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    # Check if it is hashing string
    hash_string = c.hash()
    assert hash_string

    # Change hashing algorithm, for example by MD5
    hash_string_md5 = c.hash(Algorithm.MD5)
    assert hash_string_md5

# Generated at 2022-06-12 01:53:23.149691
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    assert  str(a.hash())=="5c6ccd50b02c84773eaa6d2ec0863f7f"



# Generated at 2022-06-12 01:53:27.838061
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    h1 = crypto.hash(Algorithm.SHA256)
    h2 = crypto.hash()
    assert len(h1) == 64, 'cryptographic.hash(SHA256) failed'
    assert len(h2) == 40, 'cryptographic.hash(SHA1) failed'


# Generated at 2022-06-12 01:53:29.114037
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash() is not None
    assert len(Cryptographic.hash()) > 0


# Generated at 2022-06-12 01:55:09.918412
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash() != Cryptographic.hash()

# Generated at 2022-06-12 01:55:10.976776
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test Cryptographic's method hash."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 01:55:15.823072
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test_Cryptographic = Cryptographic()
    assert test_Cryptographic.hash() != test_Cryptographic.hash()
    assert test_Cryptographic.hash(Algorithm.SHA256) != test_Cryptographic.hash()
    assert 'sha256' in test_Cryptographic.hash(Algorithm.SHA256)
    assert len(test_Cryptographic.hash(Algorithm.SHA256)) == 64


# Generated at 2022-06-12 01:55:19.719959
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # UUID are unique, so test is passed if generated UUID is unique
    assert Cryptographic().uuid() == 'b78e64fe-a0c8-4fae-aacd-9b6eab8c8a7d'



# Generated at 2022-06-12 01:55:23.647227
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.SHA512)
    assert c.hash(Algorithm.SHA1) != c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA1) != c.hash(Algorithm.SHA256)

# Generated at 2022-06-12 01:55:29.476625
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    provider = Cryptographic()
    assert provider.hash(algorithm=Algorithm.MD5) == "cbd65a1f49d36e9e32a9e9a8f11b66c1"
    assert provider.hash(algorithm=Algorithm.SHA1) == "7818ed9c15f8278a1942b75f00d1f99e713e8c24"
    assert provider.hash(algorithm=Algorithm.SHA224) == "ebad1a713a0a573e7324cc64c6b186fea83f39cf9bd8b1c1dc1353d7"

# Generated at 2022-06-12 01:55:32.102366
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initialize the class
    cryp = Cryptographic()

    # Call method hash
    hash_ = cryp.hash(Algorithm.SHA3_256)

    # Check the function output
    assert isinstance(hash_, str)
    assert len(hash_) == 64


# Generated at 2022-06-12 01:55:37.623516
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test the method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from .general import SHA1, SHA224, SHA256, SHA384, SHA512, MD5
    assert Cryptographic.hash(Algorithm.SHA1) == SHA1
    assert Cryptographic.hash(Algorithm.SHA224) == SHA224
    assert Cryptographic.hash(Algorithm.SHA256) == SHA256
    assert Cryptographic.hash(Algorithm.SHA384) == SHA384
    assert Cryptographic.hash(Algorithm.SHA512) == SHA512
    assert Cryptographic.hash(Algorithm.MD5) == MD5



# Generated at 2022-06-12 01:55:41.141981
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic(seed=123)
    assert c.hash() == 'b59565f3a3fd6d67c12fd90f6a7b6c16'

# Generated at 2022-06-12 01:55:43.129478
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()
    assert Cryptographic().hash(Algorithm.MD5)
    assert Cryptographic().hash(Algorithm.SHA384)
    assert Cryptographic().hash(Algorithm.SHA1)
