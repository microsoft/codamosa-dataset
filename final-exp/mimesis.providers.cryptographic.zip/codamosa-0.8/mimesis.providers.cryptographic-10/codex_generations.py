

# Generated at 2022-06-12 01:51:33.958512
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    assert cr.hash()


# Generated at 2022-06-12 01:51:35.716667
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    assert isinstance(a.hash(), str)

# Generated at 2022-06-12 01:51:38.138575
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    for _ in range(100):
        print(Cryptographic().hash(Algorithm.MD5))


# Generated at 2022-06-12 01:51:41.392043
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    # Create a Cryptographic instance
    crypto = Cryptographic('en')
    # assert callable(crypto.hash)
    # Check for incorrect value of parameter
    assert crypto.hash(Algorithm.SHA224) == crypto.hash(Algorithm.SHA224)

# Generated at 2022-06-12 01:51:48.613877
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash(): 
    cryptographic = Cryptographic()
    assert cryptographic.hash(algorithm=Algorithm.MD5) == '8a15a8916d607dde2a1c44e947ffb64a'
    assert cryptographic.hash(algorithm=Algorithm.SHA1) == '69bc0bc5539c9abd3f0c84b7e0b6732414b7f3bf'
    assert cryptographic.hash(algorithm=Algorithm.SHA224) == 'bded2b1ac85c8f6a5617d70b7c50433c6290c7b29d323d1483a0f23'

# Generated at 2022-06-12 01:51:57.889983
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    print(cr.hash())
    print(cr.hash(Algorithm.MD5))
    print(cr.hash(Algorithm.SHA3_512))
    print(cr.hash(Algorithm.SHA256))
    print(cr.hash(Algorithm.SHA1))
    print(cr.hash(Algorithm.SHA512))
    print(cr.hash(Algorithm.BLAKE2b))
    print(cr.hash(Algorithm.BLAKE2s))
    print(cr.hash(Algorithm.SHA3_256))
    print(cr.hash(Algorithm.SHA3_384))
    print(cr.hash(Algorithm.SHA224))


# Generated at 2022-06-12 01:52:01.688777
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cpt = Cryptographic()
    expected_output = '31d6cfe0d16ae931b73c59d7e0c089c0'

    assert cpt.hash() == expected_output

# Generated at 2022-06-12 01:52:04.306531
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    m = Cryptographic()
    assert m.hash(Algorithm.SHA3_512)
    assert m.hash(Algorithm.SHA384)



# Generated at 2022-06-12 01:52:08.690817
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(c.Algorithm.SHA3_256) is not None
    assert c.hash(c.Algorithm.SHA3_384) is not None
    assert c.hash(c.Algorithm.SHA3_512) is not None
    assert c.hash(c.Algorithm.BLAKE2B) is not None
    assert c.hash(c.Algorithm.BLAKE2S) is not None



# Generated at 2022-06-12 01:52:19.605929
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method Cryptographic.hash().
    """
    c = Cryptographic()
    for i in range(100):
        assert c.hash(Algorithm.MD5) != c.hash(Algorithm.MD5)
        assert c.hash(Algorithm.SHA1) != c.hash(Algorithm.SHA1)
        assert c.hash(Algorithm.SHA224) != c.hash(Algorithm.SHA224)
        assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA256)
        assert c.hash(Algorithm.SHA384) != c.hash(Algorithm.SHA384)
        assert c.hash(Algorithm.SHA512) != c.hash(Algorithm.SHA512)

# Generated at 2022-06-12 01:52:53.372703
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Testing the first use case
    criterion_1 = Cryptographic('en').hash()
    assert isinstance(criterion_1,str)
    assert len(criterion_1) > 0
    print('Testing the first use case: {}'.format(criterion_1))

    # Testing the second use case
    criterion_2 = Cryptographic('en').hash("MD5")
    assert isinstance(criterion_2,str)
    assert len(criterion_2) > 0
    print('Testing the second use case: {}'.format(criterion_2))

    # Testing the third use case
    criterion_3 = Cryptographic('en').hash("SHA3_256")
    assert isinstance(criterion_3,str)
    assert len(criterion_3) > 0

# Generated at 2022-06-12 01:52:57.818142
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    for _ in range(1, 10):
        b = a.hash(Algorithm.BLAKE2B)
        if not isinstance(b, str) or len(b) < 5:
            raise Exception("Error: test_Cryptographic_hash() failed. Returned {}, instead of an str of length >= 5.".format(b))


# Generated at 2022-06-12 01:53:05.187688
# Unit test for method hash of class Cryptographic

# Generated at 2022-06-12 01:53:08.130971
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("Test method hash of class Cryptographic")
    cr = Cryptographic()
    hash = cr.hash()
    print(hash)


if __name__ == '__main__':
    test_Cryptographic_hash()

# Generated at 2022-06-12 01:53:14.141480
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    c = Cryptographic()
    c.hash(Algorithm.MD5)
    c.hash(Algorithm.SHA1)
    c.hash(Algorithm.SHA224)
    c.hash(Algorithm.SHA256)
    c.hash(Algorithm.SHA384)
    c.hash(Algorithm.SHA512)
    c.hash(Algorithm.BLAKE2B)
    c.hash(Algorithm.BLAKE2S)


# Generated at 2022-06-12 01:53:16.296815
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    h = Cryptographic.hash()
    assert isinstance(h, str)


# Generated at 2022-06-12 01:53:21.334679
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    provider = Cryptographic()
    generated_hash = provider.hash(Algorithm.MD5)
    assert isinstance(generated_hash, str)
    assert len(generated_hash) == 32
    assert generated_hash.isalnum()


# Generated at 2022-06-12 01:53:29.049194
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    hash_code_md5 = crypto.hash(Algorithm.MD5)
    hash_code_sha1 = crypto.hash(Algorithm.SHA1)
    hash_code_sha224 = crypto.hash(Algorithm.SHA224)
    hash_code_sha256 = crypto.hash(Algorithm.SHA256)
    hash_code_sha384 = crypto.hash(Algorithm.SHA384)
    hash_code_sha512 = crypto.hash(Algorithm.SHA512)
    assert hash_code_md5
    assert len(hash_code_md5) == 32
    assert hash_code_sha1
    assert len(hash_code_sha1) == 40
    assert hash_code_sha224
    assert len(hash_code_sha224) == 56
    assert hash_code_sha256


# Generated at 2022-06-12 01:53:32.074405
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test = Cryptographic()
    hash = test.hash()
    assert len(hash) == 64

# Generated at 2022-06-12 01:53:38.472102
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # empty string
    text = ''
    # init Cryptographic class
    Cryp = Cryptographic(seed=123)
    # get hash
    hash_text = Cryp.hash(algorithm=Algorithm.MD5)
    # if empty string
    if text == '':
        # try
        try:
            # get hash
            hash_text = Cryp.hash(Algorithm.MD5)
        # except NonEnumerableError
        except:
            # raise NonEnumerableError
            raise NonEnumerableError
    # return hash
    return hash_text


# Generated at 2022-06-12 01:54:08.614814
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.cryptographic import Cryptographic
    cry = Cryptographic()
    cry.hash()
    cry.hash(Algorithm.MD5)
    cry.hash(Algorithm.SHA1)
    cry.hash(Algorithm.SHA256)

    print(cry.hash())
    print(cry.hash(Algorithm.MD5))
    print(cry.hash(Algorithm.SHA1))
    print(cry.hash(Algorithm.SHA256))

# Generated at 2022-06-12 01:54:11.266357
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    dummy_cryptographic_provider = Cryptographic()
    actual_result = dummy_cryptographic_provider.hash(Algorithm.MD5)
    expected_result = hashlib.md5(dummy_cryptographic_provider.uuid().encode()).hexdigest()
    assert actual_result == expected_result


# Generated at 2022-06-12 01:54:12.921112
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import mimesis
    x = mimesis.Cryptographic()
    print(x.hash())



# Generated at 2022-06-12 01:54:14.236139
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    result = Text('en')._data.get('words', {})

    print(result)



# Generated at 2022-06-12 01:54:16.701278
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("test_Cryptographic_hash")

    provider = Cryptographic()

    hash = provider.hash()
    assert hash



# Generated at 2022-06-12 01:54:18.554445
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash = Cryptographic.hash()
    assert(len(hash) == 32)

# Generated at 2022-06-12 01:54:20.465142
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    r = Cryptographic()
    assert r.hash() == r.hash()
    assert isinstance(r.hash(), str)


# Generated at 2022-06-12 01:54:28.018670
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.structures import Hash
    from mimesis.enums import Algorithm

    crypto = Cryptographic()
    # set random seed    
    crypto.seed(8)

    # when algorithm is not set
    hash_ = crypto.hash()
    assert isinstance(hash_, str)
    # value should be of the length that Hash.MAX_LENGTH
    assert len(hash_) == Hash.MAX_LENGTH

    # when algorithm is set
    # get all values of enum Algorithm
    algorithms = Algorithm.values
    # iterate all of them
    for algo in algorithms:
        # prepare hash algorithm
        hash_algo = crypto.hash(algorithm=algo)
        # and get its length
        hash_length = len(hash_algo)
        # the value's length should match the length inside

# Generated at 2022-06-12 01:54:30.148594
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    d = Cryptographic()
    hash = d.hash()
    print(hash)


# Generated at 2022-06-12 01:54:35.224293
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.SHA256) == 'f2c8ed7b9adb6e64e6d64b6f8b6cdf89bcb1197b40e6ae8f6ce922fcee82d764'

