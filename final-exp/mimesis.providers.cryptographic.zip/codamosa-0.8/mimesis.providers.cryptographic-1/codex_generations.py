

# Generated at 2022-06-12 01:54:32.641183
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash."""
    crypto = Cryptographic(seed=42)
    h = crypto.hash()
    assert 'a2e8c87d87e9c9a9f342cd3f3d3d3aec' == h

# Generated at 2022-06-12 01:54:35.221232
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == "5d5ae9bcf9fc07579e75f0e5ae87d2f7"


# Generated at 2022-06-12 01:54:36.405851
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash(): 
    x = Cryptographic()
    print(x.hash())

# Generated at 2022-06-12 01:54:38.592570
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    cr.hash()

# Generated at 2022-06-12 01:54:41.119161
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    me = Cryptographic()
    #print(me.hash(Algorithm.SHA256))
    assert isinstance(me.hash(Algorithm.SHA256), str)

# Generated at 2022-06-12 01:54:50.565463
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    # For test repeatability
    a.seed(0)
    assert a.hash(Algorithm.MD5) == "ecca74cfa48d6f7e35ace9a8cdc15bcb"
    assert a.hash(Algorithm.SHA224) == "d2870d37ae6b9c8f45a25d77a0c90adc78294a8eeb12f1af2f75aa25"
    assert a.hash(Algorithm.SHA256) == "e34a8a292eee0a0dec2d735d98815aae7a74d919f787b97a3b8f61c64a8619e3"

# Generated at 2022-06-12 01:54:53.366119
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test the hash method of class Cryptographic."""
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-12 01:55:01.212099
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.uuid() != c.uuid()
    assert c.uuid().isalnum() is True
    assert c.uuid().isalnum() is True
    assert c.uuid().isdigit() is False
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.MD5).isalnum() is True
    assert c.hash(Algorithm.MD5).isalnum() is True
    assert c.hash(Algorithm.MD5).isdigit() is False
    assert c.uuid() != c.hash(Algorithm.MD5)
    assert "md5" in c.hash(Algorithm.MD5).lower()
    assert "md4" in c.hash(Algorithm.MD4).lower()


# Generated at 2022-06-12 01:55:02.996343
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	assert len(Cryptographic().hash(Algorithm.SHA256)) == 64



# Generated at 2022-06-12 01:55:10.929115
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    metadata = Cryptographic.Meta
    cr = Cryptographic(seed=0)
    assert cr.hash(Algorithm.SHA224) == 'c16d7a6a8cc2216bc13bc1e6901b90a981c8b86951a3c8848b7f666'
    assert len(cr.hash(Algorithm.SHA224)) == 56
    assert len(cr.hash(Algorithm.MD5)) == 32
    assert len(cr.hash(Algorithm.MD5)) == 32
    assert len(cr.hash()) == 32
    assert cr.hash(Algorithm.MD5) == 'a877f6c814f2d57d9c9de981507cac71'