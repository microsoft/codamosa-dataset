

# Generated at 2022-06-12 01:52:58.565253
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    crypto = Cryptographic()
    for _ in range(10):
        crypto.hash(algorithm = Algorithm.SHA1)
    for _ in range(10):
        crypto.hash(algorithm = Algorithm.SHA256)
    for _ in range(10):
        crypto.hash(algorithm = Algorithm.SHA512)
    for _ in range(10):
        crypto.hash(algorithm = Algorithm.SHA3_224)
    for _ in range(10):
        crypto.hash(algorithm = Algorithm.SHA3_256)
    for _ in range(10):
        crypto.hash(algorithm = Algorithm.SHA3_384)
    for _ in range(10):
        crypto.hash(algorithm = Algorithm.SHA3_512)

# Generated at 2022-06-12 01:52:59.855319
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != ""


# Generated at 2022-06-12 01:53:04.898812
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    # Test with proper value
    assert len(Cryptographic.hash(Algorithm.MD5)) == 32
    # Test with other value / Expected - TypeError
    try:
        Cryptographic.hash('dummy_algorithm')
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-12 01:53:06.797556
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hashlib.md5("Hello")
    assert (Cryptographic().hash())

# Generated at 2022-06-12 01:53:08.115084
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto_provider = Cryptographic()
    crypto_provider.hash()

# Generated at 2022-06-12 01:53:12.453271
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method Cryptographic.hash."""
    provider = Cryptographic()
    hash1 = provider.hash(Algorithm.BLAKE2B)
    hash2 = provider.hash(Algorithm.BLAKE2B)
    assert hash1 == hash2
    assert isinstance(hash1, str)

# Generated at 2022-06-12 01:53:15.663069
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'a7a8f6e507055e36d91a33f927e5e2c5b5f5b5e325715a5f5c3f3d3d2c1b9e64'



# Generated at 2022-06-12 01:53:17.132555
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != None  # Noqa


# Generated at 2022-06-12 01:53:18.058540
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()

# Generated at 2022-06-12 01:53:22.837860
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash().__class__ == crypto.hash().__class__
    assert crypto.hash(Algorithm.SHA512).__class__ == crypto.hash(Algorithm.SHA512).__class__


# Generated at 2022-06-12 01:54:15.646892
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Create an instance
    obj_1 = Cryptographic()
    # Get hash

    # Create an instance
    obj_2 = Cryptographic()
    # Get hash

    # Create an instance
    obj_3 = Cryptographic()
    # Get hash

    # Create an instance
    obj_4 = Cryptographic()
    # Get hash

# Generated at 2022-06-12 01:54:20.861285
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """
    This method is to test the hash method of class Cryptographic
    """
    crypto = Cryptographic()
    str_hash = crypto.hash()
    assert len(str_hash) == 40, "The length of hash {} is not 40".format(str_hash)
    assert isinstance(str_hash, str), "The hash {} is not a string".format(str_hash)


# Generated at 2022-06-12 01:54:21.812065
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert type(Cryptographic().hash()) == str


# Generated at 2022-06-12 01:54:24.697392
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() != crypto.hash()


# Generated at 2022-06-12 01:54:27.533741
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # This seed is used for only testing
    seed = "8ed74c4c4e4d11e89b8d49f3c39ef943"
    crypto = Cryptographic(seed)
    assert crypto.hash(Algorithm.MD5) == "3d1c9f2d146f7cc8d824a7aee63b33e1"



# Generated at 2022-06-12 01:54:30.696948
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    res = crypto.hash().__str__()
    assert len(res) == 32
    assert isinstance(res, str)


# Generated at 2022-06-12 01:54:34.788260
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    b = a.hash(Algorithm.SHA512)
    print(b)
    c = len(b)
    print(c)
    d = 128
    assert c==d

# Generated at 2022-06-12 01:54:41.268444
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic(seed = 234)
    assert provider.hash(Algorithm.SHA512) == '3b9124b1767b0ee18a3e1c41f580a38089d60b98df44b3287c3c7b967e0b1ee3a1f2cad7f69d89eef8f6044c9e13f1426a1d2a6049b8eaf234a4b4f4d68b0a30'
    assert provider.hash(Algorithm.MD5) == '25d55ad283aa400af464c76d713c07ad'


# Generated at 2022-06-12 01:54:43.650446
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("Generated hash: ", Cryptographic().hash())
    print("Generated hash: ", Cryptographic().hash("Algorithm.SHA3_512"))

if __name__ == "__main__":
    test_Cryptographic_hash()

# Generated at 2022-06-12 01:54:47.760090
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm  # noqa: WPS433
    assert Cryptographic().hash(Algorithm.MD5)
    assert Cryptographic().hash(Algorithm.SHA256)
    assert Cryptographic().hash(Algorithm.SHA1)
    assert Cryptographic().hash(Algorithm.SHA512)

# Generated at 2022-06-12 01:55:22.995027
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test_vec = [
        {'algorithm': Algorithm.MD5,
         'expected': '2c140f296a2dbd7e8e0d1d6b9f6b2900'},
    ]
    for v in test_vec:
        res = Cryptographic().hash(v['algorithm'])
        assert res == v['expected']
        assert type(res) == str
    print('Test finished')

if __name__ == '__main__':
    test_Cryptographic_hash()

# Generated at 2022-06-12 01:55:29.172688
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    def run(algorithm):
        return Cryptographic().hash(algorithm)

    assert run(Algorithm.BLAKE2B) is not None
    assert run(Algorithm.BLAKE2S) is not None
    assert run(Algorithm.MD5) is not None
    assert run(Algorithm.SHA1) is not None
    assert run(Algorithm.SHA224) is not None
    assert run(Algorithm.SHA256) is not None
    assert run(Algorithm.SHA384) is not None
    assert run(Algorithm.SHA512) is not None
    try:
        run(Algorithm.SHA777)
    except:
        None


# Generated at 2022-06-12 01:55:30.082301
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    tmp = Cryptographic().hash()
    assert len(tmp) == 40


# Generated at 2022-06-12 01:55:31.239164
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic('en')
    assert c.hash() is not None


# Generated at 2022-06-12 01:55:35.593859
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # When no algo is provided
    algo = "sha1"
    rand_hash = Cryptographic().hash()
    assert(len(rand_hash) == 40)
    assert(rand_hash.isalnum())

    # When an algo is provided
    rand_hash = Cryptographic().hash('sha1')
    assert(len(rand_hash) == 40)
    assert(rand_hash.isalnum())
    assert(Cryptographic().hash(algo) == rand_hash)



# Generated at 2022-06-12 01:55:36.808138
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    '''Tests method hash of class Cryptographic'''
    assert len(Cryptographic().hash()) == 40
    

# Generated at 2022-06-12 01:55:39.028080
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()

    hash_ = provider.hash(Algorithm.SHA256)
    assert len(hash_) == 64
    assert hash_.isalnum()
    assert hash_.isascii()

# Generated at 2022-06-12 01:55:41.152816
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    print()
    print("Hash:",a.hash())

# Generated at 2022-06-12 01:55:41.905631
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()

# Generated at 2022-06-12 01:55:43.567794
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    h = c.hash(algorithm=Algorithm.MD5)
    assert len(h) == 32, "hash() always has 32 symbols"
