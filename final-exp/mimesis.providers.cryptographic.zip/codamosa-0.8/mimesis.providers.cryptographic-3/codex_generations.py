

# Generated at 2022-06-12 01:52:04.444844
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    words = Text('en')._data.get('words', {})
    crypto = Cryptographic()

    for _ in range(100):
        crypto.hash()
        crypto.uuid()
        crypto.token_bytes(32)
        crypto.token_hex(32)
        crypto.token_urlsafe(32)
        crypto.mnemonic_phrase()

        words_generator = (crypto.random.choice(words) for _ in range(12))
        ''.join(words_generator)

# Generated at 2022-06-12 01:52:05.360750
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()

# Generated at 2022-06-12 01:52:08.352297
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    print(Cryptographic().hash(algorithm=Algorithm.MD5))




# Generated at 2022-06-12 01:52:09.808650
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-12 01:52:14.855168
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.providers.cryptographic import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    algorithm = list(Algorithm)[0]
    print(algorithm)
    hash1 = Cryptographic.hash(algorithm)
    print(hash1)

test_Cryptographic_hash()

# Generated at 2022-06-12 01:52:16.629808
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    if not Cryptographic().hash():
        print("Empty hash")
        return False
    return True


# Generated at 2022-06-12 01:52:18.482154
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    x = Cryptographic() 
    print(x.hash(Algorithm.MD5))


# Generated at 2022-06-12 01:52:26.906817
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    # Check default algorithm
    assert re.match(r'\w{32}', Cryptographic().hash())

    # Check SHA1 algorithm
    assert re.match(r'\w{40}', Cryptographic().hash('sha1'))

    # Check MD5 algorithm
    assert re.match(r'\w{32}', Cryptographic().hash('md5'))

    # Check SHA224 algorithm
    assert re.match(r'\w{56}', Cryptographic().hash('sha224'))

    # Check SHA256 algorithm
    assert re.match(r'\w{64}', Cryptographic().hash('sha256'))

    # Check SHA384 algorithm
    assert re.match(r'\w{96}', Cryptographic().hash('sha384'))

    # Check SHA512 algorithm

# Generated at 2022-06-12 01:52:36.951039
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    res = crypto.hash()
    assert len(res) == 40 or res == 58 or res == 128 or res == 64 or res == 32 or res == 96 or res == 160 or res == 64 or res == 56 or res == 72 or res == 32 or res == 96 or res == 256 or res == 224 or res == 88 or res == 88 or res == 128 or res == 128 or res == 128 or res == 128 or res == 128 or res == 128 or res == 128 or res == 128 or res == 160 or res == 160 or res == 160 or res == 160 or res == 160 or res == 160 or res == 160 or res == 160 or res == 224 or res == 224 or res == 224 or res == 224 or res == 224 or res == 224 or res == 224 or res == 224 or res == 256 or res == 256 or res == 256 or res == 256 or res == 256

# Generated at 2022-06-12 01:52:43.822849
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    x = Cryptographic()
    assert type(x.hash()) == str
    assert len(x.hash()) == 64
    assert type(x.hash(Algorithm.SHA256)) == str
    assert len(x.hash(Algorithm.SHA256)) == 64
    assert type(x.hash(Algorithm.SHA384)) == str
    assert len(x.hash(Algorithm.SHA384)) == 96
    assert type(x.hash(Algorithm.SHA512)) == str
    assert len(x.hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-12 01:53:02.261486
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    for _ in range(10):
        a = c.hash(Algorithm.MD5)
        assert(type(a) == str)
        assert(len(a) == 32)

if __name__ == '__main__':
    # Unit tests
    test_Cryptographic_hash()

# Generated at 2022-06-12 01:53:04.880223
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic(seed=None)
    result = provider.hash(algorithm=Algorithm.SHA512)
    assert isinstance(result, str)

# Generated at 2022-06-12 01:53:08.940521
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    val = ['md5', 'sha1', 'sha224', 'sha256', 'sha384', 'sha512']
    for i in val:
        c = Cryptographic()
        hash = c.hash(Algorithm[i])
        assert isinstance(hash, str)

# Generated at 2022-06-12 01:53:11.336173
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash = Cryptographic().hash(Algorithm.SHA3_512)
    assert len(hash) == 128


# Generated at 2022-06-12 01:53:12.912373
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic('en')
    hashed_string = c.hash(Algorithm.SHA1)
    assert isinstance(hashed_string, str)
    assert len(hashed_string) == 40


# Generated at 2022-06-12 01:53:14.355559
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic('en')
    assert c.hash(Algorithm.SHA256) is not None

# Generated at 2022-06-12 01:53:16.065539
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hasher = Cryptographic()
    h = hasher.hash()
    assert(isinstance(h, str))
    assert(len(h) > 5)


# Generated at 2022-06-12 01:53:20.359744
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic().hash(Algorithm.MD5)
    assert len(a) == 32 and isinstance(a, str)

    a = Cryptographic().hash(Algorithm.SHA256)
    assert len(a) == 64 and isinstance(a, str)

    a = Cryptographic().hash(Algorithm.SHA512)
    assert len(a) == 128 and isinstance(a, str)

    a = Cryptographic().hash(Algorithm.SHA1)
    assert len(a) == 40 and isinstance(a, str)


# Generated at 2022-06-12 01:53:22.887272
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    test_str = cryptographic.hash(algorithm=Algorithm.SHA1)
    assert len(test_str) == 40


# Generated at 2022-06-12 01:53:29.766321
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic(seed=42)
    assert crypto.hash(Algorithm.MD5) == "2326c19d986835e85efb7973b3618a83"
    assert crypto.hash(Algorithm.SHA1) == "b73e3f613664f7a38024bca3ee9a5737d8f73753"
    assert crypto.hash(Algorithm.SHA224) == "4e4b4a396f3fd8adf48db04f56a3875c43d5f8bafc350562959a6a88"

# Generated at 2022-06-12 01:54:05.702970
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    result = Cryptographic().hash(Algorithm.SHA1)
    assert result is not None


# Generated at 2022-06-12 01:54:06.461634
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash().startswith("e5")

# Generated at 2022-06-12 01:54:07.372147
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    temp = Cryptographic()
    result = temp.hash(Algorithm.SHA256)
    assert len(result) == 64

# Generated at 2022-06-12 01:54:09.018032
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Arrange
    password = 'test-mimesis'
    algorithm = 'MD5'
    # Act
    passwd = Cryptographic().hash(algorithm)
    # Assert
    assert passwd is not None
    
    


# Generated at 2022-06-12 01:54:10.222760
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("Test for method hash of class Cryptographic")
    crypto = Cryptographic()
    print(crypto.hash())


# Generated at 2022-06-12 01:54:12.116729
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test = Cryptographic('en')
    assert test.hash() != test.hash()

# Generated at 2022-06-12 01:54:13.925059
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1).isalnum()


# Generated at 2022-06-12 01:54:24.325403
# Unit test for method hash of class Cryptographic

# Generated at 2022-06-12 01:54:27.714123
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.generic import Generic
    from mimesis.providers.cryptographic import Cryptographic

    g = Generic('en')
    c = Cryptographic('en')
    alg = Algorithm(g.random.randint(0, len(Algorithm)-1))
    print(alg)
    print(c.hash(algorithm=alg))



# Generated at 2022-06-12 01:54:37.009361
# Unit test for method hash of class Cryptographic