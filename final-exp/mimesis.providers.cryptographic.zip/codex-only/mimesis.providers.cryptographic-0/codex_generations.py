

# Generated at 2022-06-23 21:08:59.878128
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    assert len(provider.token_bytes()) == 32


# Generated at 2022-06-23 21:09:01.924754
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex() == secrets.token_hex()



# Generated at 2022-06-23 21:09:03.492980
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    token = crypto.token_urlsafe()
    print('token_urlsafe(): %s' % token)
    print(len(token))


# Generated at 2022-06-23 21:09:05.051481
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    instance_=Cryptographic()
    instance_.token_bytes()
    return True


# Generated at 2022-06-23 21:09:08.153386
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypt = Cryptographic(seed=12345)
    assert crypt.hash(Algorithm.SHA256) == '1b29ea6b33980a8fc3f992fada3a34f2deebf9b64a53cae99ffd90ea1c69ab1a'

# Generated at 2022-06-23 21:09:09.257098
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64

# Generated at 2022-06-23 21:09:09.866314
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
   assert (len(Cryptographic().hash()) == 64)

# Generated at 2022-06-23 21:09:15.150292
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    import unittest
    from mimesis.providers.cryptographic import Cryptographic
    print(Cryptographic().mnemonic_phrase())
    print(Cryptographic().mnemonic_phrase(length=17))
    print(Cryptographic().mnemonic_phrase(length=11))
    print(Cryptographic().mnemonic_phrase(separator=', '))
    print(Cryptographic().mnemonic_phrase(separator=', ').split(', '))
    print(Cryptographic().mnemonic_phrase(length=17, separator=', '))
    class TestCryptographicMnemonicPhrase(unittest.TestCase):
        def test_mnemonic_phrase(self):
            phrase = Cryptographic().mnemonic_phrase()
            self.assertEqual(len(phrase.split()), 12)

# Generated at 2022-06-23 21:09:22.242664
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test Cryptographic method mnemonic_phrase using pytest-cov."""
    result = ' '.join(
        set(
            Cryptographic().mnemonic_phrase(
                length=12,
                separator='-',
            ).split('-')
        )
    )

    assert result == ' '.join(
        set(
            Cryptographic().mnemonic_phrase(
                length=12,
                separator='-',
            ).split('-')
        )
    )

# Generated at 2022-06-23 21:09:25.214649
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():  # noqa: N802
    """Unit test for method token_bytes of class Cryptographic."""
    result = Cryptographic.token_bytes()
    assert type(result) == bytes
    assert len(result) == 32


# Generated at 2022-06-23 21:09:27.101646
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid(as_object=True).version == 4


# Generated at 2022-06-23 21:09:29.689189
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex()
    print(token)
    assert len(token) == 64
test_Cryptographic_token_hex()

# Generated at 2022-06-23 21:09:35.108272
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Test with no parameters
    result = Cryptographic.token_bytes()
    assert result
    assert type(result) is bytes
    assert len(result) == 32
    # Test with parameter entropy = 10
    result = Cryptographic.token_bytes(10)
    assert result
    assert type(result) is bytes
    assert len(result) == 10


# Generated at 2022-06-23 21:09:37.145546
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Unit test for constructor of class Cryptographic"""
    cr = Cryptographic()
    assert isinstance(cr, Cryptographic)


# Generated at 2022-06-23 21:09:37.807904
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c)

# Generated at 2022-06-23 21:09:39.017770
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(Cryptographic().token_hex(32))


# Generated at 2022-06-23 21:09:40.712711
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    print(crypto.token_urlsafe())
    assert crypto.token_urlsafe()
    assert crypto.token_urlsafe(1)


# Generated at 2022-06-23 21:09:42.319595
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    print(cr.uuid())
    print(cr.uuid(as_object=True))


# Generated at 2022-06-23 21:09:52.689870
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    plain_text = crypto.uuid()
    assert len(plain_text) == 36
    assert plain_text[14] == '4'
    assert plain_text[9] in ('8', '9', 'a', 'b')
    assert plain_text[19] == '-'
    assert plain_text[24] == '-'
    assert plain_text[:8] == '3afbc5d5'
    assert plain_text[10:15] == '8ac2a'
    assert plain_text[15:19] == 'b0ea'
    assert plain_text[20:24] == 'f7d0'
    assert plain_text[25:] == 'b7d9db1b50aa'


# Generated at 2022-06-23 21:09:55.121708
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    nbytes = 32
    token = Cryptographic().token_urlsafe(nbytes)
    assert len(token) == nbytes * 2

# Generated at 2022-06-23 21:09:57.814608
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-23 21:10:04.349715
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic"""

    c = Cryptographic()

    for _ in range(10):
        c.mnemonic_phrase()

    for _ in range(10):
        c.mnemonic_phrase(separator = '-')

    for _ in range(10):
        c.mnemonic_phrase(length = 24)


# Generated at 2022-06-23 21:10:08.074297
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cp = Cryptographic()
    assert cp.token_urlsafe() is not None  # Check if it returns a valid value
    assert cp.token_urlsafe(1) is not None  # Check if it doesn't return None

# Generated at 2022-06-23 21:10:11.715978
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test method token_bytes"""
    expected = b'\x0eo\xc9\xaf\xb8\xa0\x04\x00\x93\xad\x8f\xca\xc1\xed\xf0\x84\x10\x94\x83\xfb\xfb\xd1N\x9f\xf0\x9f\x10\xbd\xde\x1c\x8a\x95\x15\x9b'
    actual = Cryptographic.token_bytes(32)
    assert actual == expected


# Generated at 2022-06-23 21:10:17.734268
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method ``hash`` of class ``Cryptographic``."""
    algorithmes = [Algorithm.MD5, Algorithm.SHA1, Algorithm.SHA256]
    print('testing Cryptographic.hash')
    for algorithme in algorithmes:
        hash = Cryptographic().hash(algorithme)
        print(f'hash {algorithme}: {hash}')
        assert len(hash) > 0

# Generated at 2022-06-23 21:10:21.329047
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(), str)
    assert len(Cryptographic().hash()) == 32
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64


# Generated at 2022-06-23 21:10:24.485149
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic(seed=1)
    assert c.hash() == '5b76fb28b9c720cb8fcd7a62234fafd7'

# Generated at 2022-06-23 21:10:25.883567
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    _obj = Cryptographic()
    _obj.token_hex()


# Generated at 2022-06-23 21:10:27.310198
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    print(crypto.token_hex())



# Generated at 2022-06-23 21:10:31.471601
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Create a new instance of Cryptographic
    c = Cryptographic()
    # Get the token_bytes with the number of bytes of 16
    token_bytes = c.token_bytes(16)
    print("Token bytes: {}".format(token_bytes))


# Generated at 2022-06-23 21:10:39.121384
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.text import Text
    from mimesis.typing import Seed
    SEED = Seed(1000)
    cr = Cryptographic(SEED)
    # print(cr.uuid())
    # print(cr.uuid(as_object=1))
    # print(cr.mnemonic_phrase())
    # print(cr.mnemonic_phrase(length=24, separator='-'))
    # print(cr.hash(Algorithm.SHA224))
    # print(cr.hash())



# Generated at 2022-06-23 21:10:40.737859
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash = Cryptographic().hash(Algorithm.SHA256)
    assert isinstance(hash, str)


# Generated at 2022-06-23 21:10:46.089159
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    assert len(provider.token_hex()) == 64
    assert len(provider.token_hex()) == 64
    assert len(provider.token_hex()) == 64
    assert len(provider.token_hex()) == 64
    assert len(provider.token_hex()) == 64
    assert len(provider.token_hex()) == 64


# Generated at 2022-06-23 21:10:52.235684
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	print(Cryptographic.uuid())
	print(Cryptographic.uuid(True))
	print(Cryptographic.hash())
	print(Cryptographic.hash(Algorithm.SHA512))
	print(Cryptographic.token_bytes())
	print(Cryptographic.token_hex())
	print(Cryptographic.token_urlsafe())
	print(Cryptographic.mnemonic_phrase())
	print(Cryptographic.mnemonic_phrase(5,' '))

# Run the test
test_Cryptographic()

# Generated at 2022-06-23 21:10:53.567991
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-23 21:10:57.302985
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
  provider = Cryptographic(seed=123)
  provider.random.seed(123)
  result = provider.uuid(as_object=False)
  assert (result == '4a8b3e1a-5d5f-4f9e-b7f6-e5b44e79b1a5')


# Generated at 2022-06-23 21:10:59.506043
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    for i in range(1,10):
        print(Cryptographic().mnemonic_phrase(i))

# Generated at 2022-06-23 21:11:02.082971
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    actual = obj.uuid(as_object = True)
    assert actual == UUID(actual)


# Generated at 2022-06-23 21:11:02.741148
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-23 21:11:04.561539
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    data_provider = Cryptographic()
    assert data_provider.hash() != ''



# Generated at 2022-06-23 21:11:06.105586
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.seed == c._seed()


# Generated at 2022-06-23 21:11:10.115571
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cryptoClass = Cryptographic()
    cryptoClass.mnemonic_phrase(12)


# Generated at 2022-06-23 21:11:12.259566
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'a0a775f746dbf53b0a7b5e5a7cc9d8fe'



# Generated at 2022-06-23 21:11:14.881429
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    assert Cryptographic().hash(algorithm=Algorithm.MD5).isalnum()


# Generated at 2022-06-23 21:11:16.803101
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cl = Cryptographic()
    res=cl.mnemonic_phrase()
    assert res != None


# Generated at 2022-06-23 21:11:19.254191
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=0)
    output = c.mnemonic_phrase(7)
    assert output == 'training close brick gravity patient'

# Generated at 2022-06-23 21:11:21.677999
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Example for property token_bytes
    print(Cryptographic().token_bytes(8))



# Generated at 2022-06-23 21:11:24.766466
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    unit = Cryptographic()
    unit.hash()
    unit.mnemonic_phrase()
    unit.token_bytes()
    unit.token_hex()
    unit.token_urlsafe()
    unit.uuid()

# Generated at 2022-06-23 21:11:30.278536
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    def token_bytes_test(cg, entropy, **kwargs):
        assert len(cg.token_bytes(**kwargs)) == entropy

    cg = Cryptographic()
    entropy = 32
    token_bytes_test(cg, entropy)
    entropy = 16
    token_bytes_test(cg, entropy, entropy=16)
    entropy = 12
    token_bytes_test(cg, entropy, entropy=12)


# Generated at 2022-06-23 21:11:32.687985
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic(seed=123)
    phrase = crypto.mnemonic_phrase(length=5, separator=',')
    assert phrase == 'loving,beautiful,mammal,slate,furniture'

# Generated at 2022-06-23 21:11:35.553058
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid().__class__.__name__ == 'str'
    assert Cryptographic().uuid(True).__class__.__name__ == 'UUID'

# Generated at 2022-06-23 21:11:36.913782
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test method token_hex of class Cryptographic."""
    crypt = Cryptographic()
    assert len(crypt.token_hex()) is 64

# Generated at 2022-06-23 21:11:43.800011
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    example_token = Cryptographic.token_urlsafe()
    if (example_token=="sdgffsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsd"):
        print("Test successfully passed!")
    else:
        print("Test failed!")

test_Cryptographic_token_urlsafe()

# Generated at 2022-06-23 21:11:48.691048
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic(seed=42)
    answer = provider.hash(Algorithm.SHA1)
    assert answer == "8d7a5b06dd5c2b12a5a9e7feece23d1e40c8e201"


# Generated at 2022-06-23 21:11:51.245214
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    a = Cryptographic.token_bytes(32)
    assert isinstance(a, bytes)
    assert len(a) == 32

# Generated at 2022-06-23 21:11:53.901195
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp = Cryptographic()

    words = cp.mnemonic_phrase()
    assert words is not None
    assert isinstance(words, str)
    assert len(words) > 0


# Generated at 2022-06-23 21:12:01.835959
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print("Cryptographic:")
    cryp = Cryptographic()
    print('UUID: {}'.format(cryp.uuid()))
    print('Hash: {}'.format(cryp.hash()))
    print('Token in bytes: {}'.format(cryp.token_bytes()))
    print('Token in hex: {}'.format(cryp.token_hex()))
    print('Token URL safe: {}'.format(cryp.token_urlsafe()))
    print('Mnemonic phrase: {}'.format(cryp.mnemonic_phrase()))

if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:12:02.961834
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    m = Cryptographic()
    print(m.token_hex())


# Generated at 2022-06-23 21:12:07.268180
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=0)
    x = c.mnemonic_phrase(length=5, separator='-')
    assert x == 'STOIC-PRODUCTION-WIFI-TRADITIONAL-PARDON'


# Generated at 2022-06-23 21:12:16.401464
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    try:
        from pytest import raises
    except ImportError:
        print("pytest is not installed!")
        print("To install it: `pip install pytest`")
        return 0
    except Exception as e:
        print("Exception:", e)
        return 0

    crypto = Cryptographic()
    token = crypto.token_urlsafe()

    assert len(token) == 44

    with raises(TypeError):
        crypto.token_urlsafe('aa')

    with raises(TypeError):
        crypto.token_urlsafe(['aa'])

    with raises(TypeError):
        crypto.token_urlsafe((1,))

    with raises(TypeError):
        crypto.token_urlsafe({'a': 1})

# Generated at 2022-06-23 21:12:18.189581
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto_data = Cryptographic()
    assert isinstance(crypto_data.token_urlsafe(), str)

# Generated at 2022-06-23 21:12:22.411240
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert(isinstance(Cryptographic().uuid(), str))
    assert(isinstance(Cryptographic().uuid(as_object=True), UUID))
    assert(len(Cryptographic().uuid()) == 36)


# Generated at 2022-06-23 21:12:27.398256
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    assert isinstance(phrase, str)
    assert phrase
    assert len(phrase.split()) == 12
    phrase = crypto.mnemonic_phrase(separator='-')
    assert isinstance(phrase, str)
    assert phrase
    assert len(phrase.split('-')) == 12

# Generated at 2022-06-23 21:12:30.076618
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    test = Cryptographic()
    assert re.match(r"^[a-f0-9]{8}-([a-f0-9]{4}-){3}[a-f0-9]{12}$", test.uuid())

# Generated at 2022-06-23 21:12:33.408853
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # method Cryptographic.token_hex is working correctly
    assert type(Cryptographic.token_hex(entropy = 4)) == str


# Generated at 2022-06-23 21:12:39.816876
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    test_cryptographic = Cryptographic()
    assert b'\xc6\x0e\xfe\xb3\x7b\x24\x9f\x9d\x1d\x3e\xc2\x19\x74\xe7\x80' \
           b'\x5b\x2a\x5d\x99\xa4\x4c\x04\xfd\xc3\xfd\xa1\x3e\x2c\x15\xa2' \
           b'\x58\xcf' == test_cryptographic.token_bytes()

# Generated at 2022-06-23 21:12:44.468576
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for Cryptographic.mnemonic_phrase method."""
    cp = Cryptographic()
    #mnemonic_phrase = cp.mnemonic_phrase()
    #print(mnemonic_phrase)  # something like "during minute develop feature next"
    print(cp.uuid())
    print(cp.uuid(as_object=True))

# Generated at 2022-06-23 21:12:45.409575
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    Cryptographic().token_urlsafe()

# Generated at 2022-06-23 21:12:50.401496
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    assert crypto.token_urlsafe()
    assert crypto.token_urlsafe(32)
    assert crypto.token_urlsafe(1)
    assert crypto.token_urlsafe(300)
    assert crypto.token_urlsafe(1)
    assert crypto.token_urlsafe(1)
    assert crypto.token_urlsafe(1)


# Generated at 2022-06-23 21:12:51.907335
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    result = provider.token_bytes()
    assert isinstance(result, bytes)


# Generated at 2022-06-23 21:12:53.841780
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    data = crypto.token_bytes()
    assert type(data) is bytes
    data = crypto.token_bytes(8)
    assert len(data) is 8

# Generated at 2022-06-23 21:12:54.986229
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert crypto.uuid() is not None


# Generated at 2022-06-23 21:12:56.844593
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    CK = Cryptographic()
    m = CK.mnemonic_phrase()
    assert(m) == "decade under capable place uniform"

# Generated at 2022-06-23 21:12:58.504475
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str)


# Generated at 2022-06-23 21:13:01.056895
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.__class__.__name__ == 'Cryptographic'


# Generated at 2022-06-23 21:13:02.898275
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != 0
    assert c.hash() != c.hash()

# Generated at 2022-06-23 21:13:05.751272
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    uuid = crypto.uuid()
    assert(len(str(uuid)) == 36)
    assert(str(uuid).count('-') == 4)


# Generated at 2022-06-23 21:13:06.588644
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    _Cryptographic = Cryptographic()
    _Cryptographic.token_hex(20)


# Generated at 2022-06-23 21:13:12.246525
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic.uuid() == '4f75a8f4-4b4a-4c93-9d8f-26a3a3f6c95d'
    assert Cryptographic.uuid(as_object=True) == UUID('4f75a8f4-4b4a-4c93-9d8f-26a3a3f6c95d')


# Generated at 2022-06-23 21:13:17.968655
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c)
    print(c.seed)
    c.__init__(seed=42)
    c.__init__(seed=42, locale='en')
    c.__init__(seed=42, locale='en', datetime=None)
    c.__init__(seed=42, locale='en', datetime=None, random=None)


# Generated at 2022-06-23 21:13:19.058330
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64



# Generated at 2022-06-23 21:13:20.146819
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic('seed')
    print(obj.hash())


# Generated at 2022-06-23 21:13:22.142940
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid()
    assert Cryptographic().uuid(as_object=True)


# Generated at 2022-06-23 21:13:26.322081
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64

    assert len(Cryptographic().token_hex(256)) == 512

    assert Cryptographic().token_hex(254) == 'b55c67f94cc1bff7bd3e9b2e93a2f61f23161c3c8eaddb6f90e2d21b6f079f9f'


# Generated at 2022-06-23 21:13:29.174719
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for uuid method of class Cryptographic."""
    crp = Cryptographic()
    assert crp.uuid() == str(UUID(hex=crp.uuid()))
    assert crp.uuid(as_object=True) == UUID(hex=crp.uuid())



# Generated at 2022-06-23 21:13:31.039463
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c


# Generated at 2022-06-23 21:13:32.844666
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.mnemonic_phrase())

test_Cryptographic()

# Generated at 2022-06-23 21:13:34.551298
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():  # noqa: N802
    assert len(Cryptographic.token_hex(entropy=32)) == 64

# Generated at 2022-06-23 21:13:39.425513
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print("Testing method token_hex of class Cryptographic")
    c=Cryptographic()
    tokenHex=c.token_hex()
    print("tokenHex: " + str(tokenHex))
    string = "0123456789abcdef"
    print("string: " + str(string))
    assert (any([True for i in tokenHex for j in string if i==j]))



# Generated at 2022-06-23 21:13:41.041148
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase() != ''

# Generated at 2022-06-23 21:13:43.721268
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider_data_cryptographic = Cryptographic(seed=42)
    result = provider_data_cryptographic.mnemonic_phrase()
    assert result == 'crouched'


# Generated at 2022-06-23 21:13:47.724979
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    #    The string has ``entropy`` random bytes, each byte
    #    converted to two hex digits.
    token = Cryptographic.token_bytes(16)
    assert isinstance(token, bytes)
    assert len(token) == 16
    assert int(token.hex(), 0) >= 0



# Generated at 2022-06-23 21:13:49.397352
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Run
    result = Cryptographic().mnemonic_phrase()
    # Assert
    assert isinstance(result, str)

# Generated at 2022-06-23 21:13:52.378461
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic"""
    c = Cryptographic()
    mnemonic_phrase = c.mnemonic_phrase()

    assert isinstance(mnemonic_phrase, str)
    assert len(mnemonic_phrase.split()) == 12

# Generated at 2022-06-23 21:14:00.193959
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == Cryptographic().hash()
    assert Cryptographic().hash(Algorithm.SHA256) == '5db8e3d46a2e5f5ee5a5a0a99d5f52789c9f4452ce4f8c342e79d4c24e3e7643'
    assert Cryptographic().hash(Algorithm.BLAKE2B) == 'e0eabeb95c06a7aa3561e418d865f1a54c902b2a77a8a8f0d76c336e5413ff37'


# Generated at 2022-06-23 21:14:03.973205
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    cr = Cryptographic()
    for i in range(10):
        assert i < cr.hash(Algorithm.SHA1).__len__()

# Generated at 2022-06-23 21:14:04.921026
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic().token_urlsafe())

# Generated at 2022-06-23 21:14:06.468944
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto

# Generated at 2022-06-23 21:14:17.823923
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'fdc7e6feb09f5c5b5af5e65d5f9cfc3f'
    assert c.hash() == 'e3d8a7f109e33be520d711ae5e9b8c38'
    assert c.hash() == 'ae5c204eaa05a3437b8885d9d9e6c52a'
    assert c.hash() == 'fa0c898f6b44a6dcadc1d9fdd865bd1b'
    assert c.hash() == 'e3d8a7f109e33be520d711ae5e9b8c38'

# Generated at 2022-06-23 21:14:19.308175
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    random = Cryptographic()
    random.token_hex()
    random.token_hex(8)

# Generated at 2022-06-23 21:14:21.448390
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  print(Cryptographic.token_hex())


# Generated at 2022-06-23 21:14:23.308229
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    result = crypto.token_hex()
    assert len(result) == 64


# Generated at 2022-06-23 21:14:31.053683
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    n = 10
    length = 12
    for i in range(n):
        mnemo = Cryptographic.mnemonic_phrase(length)
        assert isinstance(mnemo, str)
        if len(mnemo) == length:
            return 1

if __name__ == '__main__':
    for i in range(5):
        assert test_Cryptographic_mnemonic_phrase() == 1
        print(Cryptographic.mnemonic_phrase(length=12))
        print(Cryptographic.uuid())
        print(Cryptographic.uuid(as_object=True))
        print(Cryptographic.hash(Algorithm.MD5))
        print(Cryptographic.hash(Algorithm.SHA1))
        print(Cryptographic.hash(Algorithm.SHA224))
        print(Cryptographic.hash(Algorithm.SHA256))


# Generated at 2022-06-23 21:14:34.036088
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.builtins import RussiaSpecProvider
    # Create provider
    provider = RussiaSpecProvider()
    # Get mnemonic phrase for 12 and 23 words
    for n in [12, 23]:
        words = provider.cryptographic.mnemonic_phrase(n)
        print('Mnemonic phrase of {} words: {}'.format(n, words))

# Generated at 2022-06-23 21:14:36.178213
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic().token_hex()

# Generated at 2022-06-23 21:14:46.000331
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    result = provider.hash()
    assert isinstance(result, str)
    assert len(result) == 40

    result = provider.hash(Algorithm.MD5)
    assert isinstance(result, str)
    assert len(result) == 32

    result = provider.hash(Algorithm.SHA1)
    assert isinstance(result, str)
    assert len(result) == 40

    result = provider.hash(Algorithm.SHA224)
    assert isinstance(result, str)
    assert len(result) == 56

    result = provider.hash(Algorithm.SHA256)
    assert isinstance(result, str)
    assert len(result) == 64

    result = provider.hash(Algorithm.SHA384)
    assert isinstance(result, str)
    assert len(result) == 96



# Generated at 2022-06-23 21:14:49.052217
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    key = Cryptographic()
    assert isinstance(key.uuid(), str)
    assert key.hash()
    assert key.token_bytes()
    assert key.token_hex()
    assert key.token_urlsafe()
    assert key.mnemonic_phrase()

# Generated at 2022-06-23 21:14:50.136722
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    print(c.hash())

# Generated at 2022-06-23 21:14:58.857885
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40
    assert len(Cryptographic().hash(Algorithm.SHA224)) == 56
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA384)) == 96
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128
    assert len(Cryptographic().hash(Algorithm.BLAKE2B)) == 128
    assert len(Cryptographic().hash(Algorithm.BLAKE2S)) == 64

    assert len(Cryptographic().token_hex()) == 64
    assert len(Cryptographic().token_hex(16)) == 32
    assert len(Cryptographic().token_hex(32)) == 64
    assert len

# Generated at 2022-06-23 21:15:00.257212
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert str(Cryptographic.token_bytes())


# Generated at 2022-06-23 21:15:02.320299
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5)

# Generated at 2022-06-23 21:15:04.398635
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 36
    assert Cryptographic().uuid(as_object=True).version == 4


# Generated at 2022-06-23 21:15:05.730151
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Arrange
    entropy = 32
    # Act
    result = Cryptographic().token_urlsafe(entropy)
    # Assert
    assert len(result) == entropy+1


# Generated at 2022-06-23 21:15:09.709668
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Test with given entropy value
    tester_hex = Cryptographic().token_hex(entropy=32)
    assert len(tester_hex) == 64
    hex_bytes = tester_hex.encode()
    assert len(hex_bytes) == 32
    assert isinstance(hex_bytes, bytes)

# Generated at 2022-06-23 21:15:15.388110
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test the correctness of method token_urlsafe of class Cryptographic."""
    print('Testing the correctness of method token_urlsafe of class Cryptographic.')
    m = Cryptographic()
    key = m.token_urlsafe()
    print('token_urlsafe:', key)
    assert True
    print('Method token_urlsafe of class Cryptographic test is pass.')


# Generated at 2022-06-23 21:15:24.054565
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Testing method mnemonic_phrase"""
    assert len(Cryptographic().mnemonic_phrase()) == 12
    assert len(Cryptographic().mnemonic_phrase(15)) == 15
    assert len(Cryptographic().mnemonic_phrase(20)) == 20
    assert len(Cryptographic().mnemonic_phrase(separator='-')) == 12
    assert len(Cryptographic().mnemonic_phrase(15, separator='-')) == 15
    assert len(Cryptographic().mnemonic_phrase(20, separator='-')) == 20


# Generated at 2022-06-23 21:15:25.461803
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    u = Cryptographic()
    assert isinstance(u.hash(), str)

# Generated at 2022-06-23 21:15:28.955404
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
  cr = Cryptographic()
  cr.uuid()
  cr.hash()
  cr.token_bytes()
  cr.token_hex()
  cr.token_urlsafe()
  cr.mnemonic_phrase()


# Generated at 2022-06-23 21:15:31.327884
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    assert isinstance(Cryptographic.uuid(), (str, type(None)))



# Generated at 2022-06-23 21:15:33.182879
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert isinstance(Cryptographic().mnemonic_phrase(24), str)
    assert len(Cryptographic().mnemonic_phrase(24)) == 24

# Generated at 2022-06-23 21:15:33.991109
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert Cryptographic().token_urlsafe() != ""

# Generated at 2022-06-23 21:15:39.052448
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    seeder.add_provider(Cryptographic)
    seeder.add_entity(Cryptographic, '_mnemonic_phrase')
    data = seeder.execute()
    assert data[0]['_mnemonic_phrase'] == 'dipiudipiudipi'

# Generated at 2022-06-23 21:15:45.308861
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    from mimesis.exceptions import NonEnumerableError
    from mimesis.utils import remove_whitespaces
    from mimesis.providers.cryptographic import Cryptographic

    cr = Cryptographic()

    for _ in range(10):
        phrase = cr.mnemonic_phrase()
        assert phrase is not None
        assert isinstance(phrase, str)
        assert len(phrase.split()) == 12
        assert len(remove_whitespaces(phrase)) == 12 * 3
        assert len(phrase) == 12 * 4 - 1

    phrase = cr.mnemonic_phrase(length=24, separator='-')
    assert phrase is not None
    assert isinstance(phrase, str)
    assert len(phrase.split('-')) == 24

# Generated at 2022-06-23 21:15:48.387495
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for method token_hex of class Cryptographic"""
        
    default = Cryptographic().token_hex()
    assert len(default) == 64

    ten = Cryptographic().token_hex(10)
    assert len(ten) == 20



# Generated at 2022-06-23 21:15:55.202658
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(32) == 'd1b9cc63f90d1ddb6a31d637f97c749c'
    assert c.token_hex(32) == '5b5163bf0dbe5d5e5f98519e440e1b16'
    assert c.token_hex(32) == 'b3c7d8dde17648b1cbb20155f09e16c8'
    assert c.token_hex(32) == '8d1d18508fa36e13eacb5f27a879d0fe'
    assert c.token_hex(32) == 'afb7c37b1f25bbedf8bbd9a92859b69a'


# Generated at 2022-06-23 21:15:56.407378
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    x = c.token_bytes()
    assert(type(x)==bytes)


# Generated at 2022-06-23 21:15:58.095902
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    u = Cryptographic.uuid()
    assert isinstance(u, str)


# Generated at 2022-06-23 21:16:00.392511
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crp = Cryptographic()
    token = crp.token_hex(32)
    assert token.isalnum() == True
    assert len(token) == 64

# Generated at 2022-06-23 21:16:10.666584
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    import pytest
    import six
    from mimesis.enums import Algorithm
    from mimesis.enums import CharacterSet
    from mimesis.enums import CryptoType
    from mimesis.enums import UnitSize
    from mimesis.providers import Cryptographic
    from mimesis.providers.crypto import LENGTHS

    # Test token_bytes method
    crypt = Cryptographic()
    assert isinstance(crypt.token_bytes(), six.binary_type)
    assert crypt.token_bytes().decode(encoding='UTF-8') == ''
    assert isinstance(crypt.token_bytes(10), six.binary_type)
    assert len(crypt.token_bytes(10)) == 10
    assert isinstance(crypt.token_bytes(16), six.binary_type)

# Generated at 2022-06-23 21:16:13.235226
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    tester = Cryptographic()
    result = tester.token_hex(6)
    assert type(result) == str
    assert len(result) == 12


# Generated at 2022-06-23 21:16:16.991480
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """
    Doctest for method token_hex in class Cryptographic

    Example:
    >>> Cryptographic().token_hex()
    'd6e0b6a4f4d4bd4a0b0e4a6d4ef2c9b6eb8b6c407a6e0c6a0d6e8c6e4b6a0b2e9'
    """
    print('test_Cryptographic_token_hex passed')


# Generated at 2022-06-23 21:16:21.618580
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    token = crypto.token_hex()
    assert(isinstance(token, str))
    assert(len(token) == 64)



# Generated at 2022-06-23 21:16:24.578404
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # This is a method of Cryptographic class
    c = Cryptographic()
    token = c.token_urlsafe()
    assert token is not None


# Generated at 2022-06-23 21:16:30.670223
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from Mimesis.data.locales import English
    from Mimesis.classes import Global

    global_ = Global()
    global_.random.set_random_state()

    crypto = Cryptographic(English) 
    token = crypto.token_urlsafe(8)
    assert len(token) == 22
    #assert token in crypto.token_urlsafe.__defaults__ and crypto.token_urlsafe.__defaults__[0] == 32

# Generated at 2022-06-23 21:16:33.966546
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
   global t, object_name, entropy
   t = Cryptographic()
   object_name = t.token_urlsafe(8)
   entropy = 16
   assert (object_name != entropy)


# Generated at 2022-06-23 21:16:41.659010
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.enums import Algorithm
    passphrase = Cryptographic.mnemonic_phrase()
    assert type(passphrase) == str
    assert type(Cryptographic.uuid()) == str
    u = Cryptographic.uuid(as_object=True)
    assert type(u) == UUID
    assert type(Cryptographic.token_hex()) == str
    assert type(Cryptographic.token_urlsafe()) == str
    assert type(Cryptographic.token_bytes()) == bytes
    hash = Cryptographic.hash(algorithm=Algorithm.MD5)
    assert type(hash) == str
    assert len(hash)==32

# Generated at 2022-06-23 21:16:43.534610
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto is not None

# Generated at 2022-06-23 21:16:49.255338
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a = 1
    print("test mt token_hex of class cryptographic")
    a += 1
    print("test mt token_hex of class cryptographic")
    print("test mt token_hex of class cryptographic")
    print("test mt token_hex of class cryptographic")
    a += 1
    print("test mt token_hex of class cryptographic")
    return a

# Generated at 2022-06-23 21:16:54.711076
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Arrange
    crypto_object = Cryptographic(seed='mimesis')
    # Act
    hash_result = crypto_object.hash(Algorithm.SHA256)
    # Assert
    assert hash_result == '09b1fab27c9f9a2a24b44d80b36e7b0dbf8115c51d86a1453329eab17b791e83'

# Generated at 2022-06-23 21:16:59.646849
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a=Cryptographic(seed=1234567890)
    b=a.token_hex(entropy=32)
    assert b == '1d04f55d8b47e41bfd098835e03b8760' or b == 'f944e22b87be5e3df5d5c5ed737a195f' or b == '8b32d25f7bfccdd46c4025aab8d1c2e7'


# Generated at 2022-06-23 21:17:02.356619
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=9834567)            
    result = c.mnemonic_phrase()
    assert result == 'anxiety september decade afternoon furniture origin duchess weekday british century escape'

# Generated at 2022-06-23 21:17:03.297979
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert (len(Cryptographic().token_hex()) == 64)

# Generated at 2022-06-23 21:17:05.164639
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic(seed=2345678)
    token = c.token_urlsafe()
    print(type(token))
    print(len(token))


# Generated at 2022-06-23 21:17:10.746657
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    cryp = Cryptographic()
    cryp.token_bytes(32)
    cryp.token_bytes(32)
    cryp.token_bytes(32)
    cryp.token_bytes(32)


# Generated at 2022-06-23 21:17:13.083151
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
  crypto = Cryptographic()
  assert crypto.mnemonic_phrase()

# Generated at 2022-06-23 21:17:16.143497
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    #print(Cryptographic.mnemonic_phrase())
    #print(Cryptographic.mnemonic_phrase())
    print(Cryptographic().mnemonic_phrase())
    print(Cryptographic().mnemonic_phrase())


# Generated at 2022-06-23 21:17:20.944848
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic(seed=12345)
    tb = c.token_bytes()
    assert tb != b'\xbb\xd4\x0f\x15\xec\x01\x0c\x8f\x1a=\xb5\xce\xa5\x12\xaf\xcd\x11\xd1\x8a\x97\xa3\x9e\x1e;\x84\x1d\x1c\xad2\xca\xcb\xe2\x9a'


# Generated at 2022-06-23 21:17:21.902188
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    result = Cryptographic().uuid()
    assert type(result) is str
    assert len(result) == 36


# Generated at 2022-06-23 21:17:30.361583
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # test constructor
    c = Cryptographic()
    assert c.token_hex(10) == "ed4c6513f7a4b2c0"
    assert c.token_urlsafe() == 'EI1aDlO_6Uwq3L-aOz5f8g'
    assert c.uuid() == '0b4ba0f4-fe4a-4e25-bd52-f36d9dcb1f78'
    assert c.hash() == 'dd55a03a292af7c05f64f8d1c60a3d3e79c3d3a8b7f2c2f86f7a44a022e93888'
    assert c.mnemonic_phrase() == 'baby beaver stool study'

# Generated at 2022-06-23 21:17:39.902990
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    # UUID with default parameters
    uuid1 = Cryptographic().uuid()
    assert isinstance(uuid1, str)
    assert len(uuid1) == 36
    assert uuid1.split('-')[0] == 'b2ea6610'

    # UUID with as_object=True parameter
    uuid2 = Cryptographic().uuid(as_object=True)
    assert isinstance(uuid2, UUID)
    assert isinstance(uuid2.hex, str)
    assert len(uuid2.hex) == 32
    assert uuid2.hex.startswith('b9d07e99')


# Generated at 2022-06-23 21:17:40.889936
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 36

# Generated at 2022-06-23 21:17:44.291050
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test method token_urlsafe of class Cryptographic."""
    txt = Cryptographic().token_urlsafe(5)
    assert len(txt) == 11
    assert type(txt) == str


# Generated at 2022-06-23 21:17:45.572215
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    assert a.mnemonic_phrase()

# Generated at 2022-06-23 21:17:46.759566
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-23 21:17:55.327632
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.uuid() == 'd0d85dd7-a9f9-4b3d-a3c3-52e2c12a8e07'
    assert c.hash() == '4f4bf7f2d1735d16a23e6e909f8b1f19a96d4bff70cef9a8f0a6fcb903f5a01d'

# Generated at 2022-06-23 21:18:02.471094
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c1 = Cryptographic()
    c2 = Cryptographic()
    c3 = Cryptographic()
    c4 = Cryptographic()
    c5 = Cryptographic()
    c6 = Cryptographic()


    assert isinstance(c1.uuid(), str)
    assert isinstance(c2.uuid(), str)
    assert isinstance(c3.uuid(), str)
    assert isinstance(c4.uuid(), str)
    assert isinstance(c5.uuid(), str)
    assert isinstance(c6.uuid(), str)




# Generated at 2022-06-23 21:18:03.568027
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
  Cryptographic().mnemonic_phrase()

# Generated at 2022-06-23 21:18:08.932273
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # test_multiple_same_results_for_different_seeds
    c1 = Cryptographic('1')
    c2 = Cryptographic('2')
    assert c1.mnemonic_phrase() != c2.mnemonic_phrase()
    assert c1.mnemonic_phrase() == c1.mnemonic_phrase()
    assert c2.mnemonic_phrase() == c2.mnemonic_phrase()


# Generated at 2022-06-23 21:18:16.090724
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic(seed=0).uuid() == Cryptographic(seed=0).uuid()
    assert Cryptographic(seed=0).hash() != Cryptographic(seed=1).hash()
    assert Cryptographic(seed=0).token_bytes() != Cryptographic(seed=1).token_bytes()
    assert Cryptographic(seed=0).token_hex() != Cryptographic(seed=1).token_hex()
    assert Cryptographic(seed=0).token_urlsafe() != Cryptographic(seed=1).token_urlsafe()
    assert Cryptographic(seed=0).mnemonic_phrase() == Cryptographic(seed=0).mnemonic_phrase()


# Generated at 2022-06-23 21:18:18.706313
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print("\nTest: uuid of Cryptographic")
    print("Result " + Cryptographic().uuid())


# Generated at 2022-06-23 21:18:21.626747
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test instance of class Cryptographic."""
    obj = Cryptographic()
    assert isinstance(obj, Cryptographic)



# Generated at 2022-06-23 21:18:24.061545
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == c.hash(Algorithm.SHA224) == c.hash(Algorithm.SHA1)

# Generated at 2022-06-23 21:18:30.018710
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    x = Cryptographic(seed=42)
    print(x.uuid())
    print(x.uuid())
    print(x.uuid())
    print(x.uuid())
    print(x.hash(algorithm=Algorithm.SHA256))
    print(x.hash(algorithm=Algorithm.SHA256))
    print(x.hash(algorithm=Algorithm.SHA256))
    print(x.hash(algorithm=Algorithm.SHA256))



# Generated at 2022-06-23 21:18:32.098312
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for token_urlsafe method of the class Cryptographic"""
    data = Cryptographic()
    assert len(data.token_urlsafe()) == 44

# Generated at 2022-06-23 21:18:33.771396
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) > 0


# Generated at 2022-06-23 21:18:38.002701
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    for length, wanted in (4, 'alpine awkward kettle frosty'), (12, 'diligent dull toxic baby skilful tall mini alpine pink orange gesture'):
        result = Cryptographic().mnemonic_phrase(length)
        assert len(result) == len(wanted)
        assert result == wanted

# Generated at 2022-06-23 21:18:44.031426
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Test uuid as string
    context_1 = Cryptographic()
    try:
        UUID(context_1.uuid())
    except Exception as e:
        assert False

    # Test uuid as object
    context_2 = Cryptographic()
    try:
        uuid_2 = context_2.uuid(as_object=True)
        assert isinstance(uuid_2, UUID)
    except Exception as e:
        assert False


# Generated at 2022-06-23 21:18:47.446384
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from string import punctuation
    phrase = Cryptographic().mnemonic_phrase(length=12)
    assert isinstance(phrase, str)
    for i in phrase:
        assert i.isalpha() or i in punctuation

# Generated at 2022-06-23 21:18:58.021116
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.providers.cryptographic import Cryptographic
    cr = Cryptographic('en')
    assert cr.token_urlsafe() in ['eOJ7uvZhQmPRByeiUG_BtSBoBbGNyDLin1g6Ugz9XU8', 'jAuJaU1F6nMf8rWKjTleT2zRC9xA57lXOhbixcLtgjk', 'eCpwD8n1EqyOKksIyj_mje_X9bMfZ0UhKZRdFgffpYY', 'Jq-IKqeJbN6xJU6mXU6FpjZzVIa6JwU_rBgYQBaiTQQ']
    assert cr.token_urlsafe(10)