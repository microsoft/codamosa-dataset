

# Generated at 2022-06-23 21:09:03.217389
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    result1 = crypto.mnemonic_phrase()
    result2 = crypto.mnemonic_phrase()
    assert(result1 != result2)

# Generated at 2022-06-23 21:09:06.436186
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # given
    mnemonic_phrase_len = 12
    expected = '{}'.format(' ').join([words[random_num] for random_num in _random_numbers])
    
    crypto = Cryptographic()
    crypto.random.randint = _randint
    crypto.random.uniform = _uniform
    crypto.random.choice = _choice
    
    # when
    actual = crypto.mnemonic_phrase(mnemonic_phrase_len)
    
    # then
    assert actual == expected

# Generated at 2022-06-23 21:09:07.941814
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
  # Initialize and set seed
  random.seed(0)

  # Set expected value and check result
  assert Cryptographic().mnemonic_phrase() == 'only best shed'

# Generated at 2022-06-23 21:09:10.367492
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    algo = Algorithm.SHA512
    result = c.hash(algo)

    assert isinstance(result, str)
    assert len(result) > 0

# Generated at 2022-06-23 21:09:18.183608
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.uuid())
    print(c.hash())
    print(c.token_bytes(10))
    print(c.token_hex(8))
    print(c.token_urlsafe(10))
    print(c.mnemonic_phrase(length=1, separator='+'))
    print(c.mnemonic_phrase(length=3, separator='+'))
    print(c.mnemonic_phrase(length=12, separator='+'))
    pass


# Generated at 2022-06-23 21:09:20.382942
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    r = Cryptographic()
    result = r.token_hex(10)
    assert len(result) == 20


# Generated at 2022-06-23 21:09:22.063699
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    m = c.mnemonic_phrase()
    assert type(m) == str

# Generated at 2022-06-23 21:09:29.884007
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """
    Test for Class Cryptographic
    """
    crypto = Cryptographic()
    # crypto.mnemonic_phrase(0)
    # crypto.mnemonic_phrase("string")
    # crypto.mnemonic_phrase("string", 0)
    # crypto.mnemonic_phrase("string", 0, 0)
    crypto.mnemonic_phrase()
    crypto.mnemonic_phrase(separator=None)
    crypto.mnemonic_phrase(length=7)
    crypto.mnemonic_phrase(length=8)


# Generated at 2022-06-23 21:09:35.340105
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    ans = cr.hash()
    print (type(ans))
    print (len(ans))
    print (ans)
    # <class 'str'>
    # 40
    # d7da1e4bf09d7ff2c5870f4c4a4e4df1d9e9aac8


# Generated at 2022-06-23 21:09:38.028438
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic"""
    assert len(Cryptographic.token_bytes()) > 0
    assert isinstance(Cryptographic.token_bytes(), bytes)



# Generated at 2022-06-23 21:09:38.864899
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    s = Cryptographic()
    assert isinstance(s.token_bytes(), bytes)

# Generated at 2022-06-23 21:09:39.441180
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    Crypto = Cryptographic()
    Crypto.token_bytes()

# Generated at 2022-06-23 21:09:43.377264
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.enums import Algorithm

    provider = Cryptographic()

    assert isinstance(provider, Cryptographic)
    assert provider.hash(Algorithm.MD5)
    assert provider.mnemonic_phrase()
    assert isinstance(provider.token_hex(), str)
    assert isinstance(provider.token_urlsafe(), str)
    assert isinstance(provider.token_bytes(), bytes)
    assert isinstance(provider.uuid(), str)
    assert isinstance(provider.uuid(True), UUID)

# Generated at 2022-06-23 21:09:48.653559
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    print(crypto.uuid())
    print(crypto.hash(Algorithm.SHA256))  # noqa: A003
    print(crypto.token_bytes())
    print(crypto.token_hex())
    print(crypto.token_urlsafe())
    print(crypto.mnemonic_phrase())

# Generated at 2022-06-23 21:09:51.011896
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    mnemonic_phrase = c.mnemonic_phrase()
    print("Mnemonic phrase:", mnemonic_phrase)


# Generated at 2022-06-23 21:09:55.190698
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    assert len(provider.token_hex()) == 64
    assert len(provider.token_hex(4)) == 8
    #assert provider.token_hex(4) == '9b3d3a3a' # "Uncomment this line and it works"


# Generated at 2022-06-23 21:09:57.170427
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    a = Cryptographic()
    assert isinstance(a.token_urlsafe(), str)

# Generated at 2022-06-23 21:09:59.376474
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test the Cryptographic.token_urlsafe method."""
    c = Cryptographic(seed='')
    token = c.token_urlsafe()
    assert token

# Generated at 2022-06-23 21:10:00.644715
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # print(Cryptographic().mnemonic_phrase())
    return

# Generated at 2022-06-23 21:10:02.217804
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert type(Cryptographic().hash().encode()) == bytes


# Generated at 2022-06-23 21:10:04.890189
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    test_Cryptographic = Cryptographic()
    # Test
    assert (len(test_Cryptographic.token_hex()) == 64)

# Generated at 2022-06-23 21:10:07.352540
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
	token_urlsafe = Cryptographic().token_urlsafe(10)
	print(type(token_urlsafe))


# Generated at 2022-06-23 21:10:11.467282
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    c.uuid()
    # c.hash()
    c.token_bytes()
    c.token_hex()
    c.token_urlsafe()
    # c.mnemonic_phrase()


if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:10:14.815252
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    data = Cryptographic()
    assert data.mnemonic_phrase()
    assert data.mnemonic_phrase(length=24)
    assert data.mnemonic_phrase(separator="$")
    assert data.mnemonic_phrase(length=24, separator="$")

# Generated at 2022-06-23 21:10:18.629829
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    test = c.uuid()
    assert len(test) == len('00000000-0000-0000-0000-000000000000')
    assert len(test.split('-')) == 5


# Generated at 2022-06-23 21:10:29.752281
# Unit test for constructor of class Cryptographic
def test_Cryptographic():

    # Create object Cryptographic
    cr = Cryptographic()

    #test generate hash
    print(cr.hash())
    print(cr.hash(Algorithm.SHA256))
    print(cr.hash(Algorithm.SHA512))
    #test generate uuid
    print(cr.uuid())
    print(cr.uuid(True))
    #test generate token_bytes
    print(cr.token_bytes())
    print(cr.token_bytes(64))
    # test generate token_hex
    print(cr.token_hex())
    print(cr.token_hex(64))
    # test generate token_urlsafe
    print(cr.token_urlsafe())
    print(cr.token_urlsafe(64))
    # test generate mnemonic_phrase
    print(cr.mnemonic_phrase())
    print

# Generated at 2022-06-23 21:10:32.507368
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    expected = "Pyramid impinge duelly digitize longboard bauxite"
    result = Cryptographic().mnemonic_phrase()
    assert result == expected


# Generated at 2022-06-23 21:10:35.980630
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Create a provider for testing
    c = Cryptographic()
    to = c.token_urlsafe(entropy=32)
    assert (type(to) is str)
    to = c.token_urlsafe(entropy=64)
    assert (type(to) is str)
test_Cryptographic_token_urlsafe()


# Generated at 2022-06-23 21:10:38.288641
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic(seed=12345)
    c.uuid()
    c.uuid(as_object=False)


# Generated at 2022-06-23 21:10:46.982554
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    import secrets
    import random
    import pytest

    SEED = random.randrange(100)
    c = Cryptographic(seed=SEED)
    bytes_length = random.randrange(100)
    bytes_or_token = c.token_urlsafe(bytes_length)
    bytes_or_token_actual = secrets.token_urlsafe(bytes_length)
    assert bytes_or_token == bytes_or_token_actual
    assert not isinstance(bytes_or_token, bytes)
    c2 = Cryptographic(seed=SEED)
    bytes_or_token2 = c2.token_urlsafe(bytes_length)
    assert bytes_or_token2 == bytes_or_token
    c3 = Cryptographic(seed=SEED)

# Generated at 2022-06-23 21:10:47.916289
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid()


# Generated at 2022-06-23 21:10:49.633201
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    a = crypto.hash()
    b = crypto.hash()
    assert (a != b)

# Generated at 2022-06-23 21:10:55.147297
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.builtins import Cryptographic
    from uuid import UUID
    crypto = Cryptographic('en')
    uuid_str = crypto.uuid()
    assert isinstance(uuid_str, str)
    uuid_obj = crypto.uuid(as_object=True)
    assert isinstance(uuid_obj, UUID)


# Generated at 2022-06-23 21:11:00.042454
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # test default functionality
    x = Cryptographic()
    assert isinstance(x.uuid(), str)

    # test when as_object is True
    assert isinstance(x.uuid(as_object=True), UUID)

# Unit tests for method hash of class Cryptographic

# Generated at 2022-06-23 21:11:01.390797
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    pass


# Generated at 2022-06-23 21:11:08.479137
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print(Cryptographic().uuid())
    print('UUID is:', Cryptographic().uuid(True))
    print('SHA3-512 is:', Cryptographic().hash())
    print('Entropy is:', Cryptographic().token_bytes())
    print('Token is:', Cryptographic().token_hex())
    print('URL-safe token is:', Cryptographic().token_urlsafe())
    print('Mnemonic phrase is:', Cryptographic().mnemonic_phrase())
    print('The end')


if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-23 21:11:13.981680
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cryp = Cryptographic(seed=None)
    assert Cryp.uuid() is not None
    assert Cryp.mnemonic_phrase(length=1) is not None
    assert Cryp.mnemonic_phrase(length=2) is not None
    assert Cryp.mnemonic_phrase(length=3) is not None
    assert Cryp.mnemonic_phrase(length=4) is not None

# Generated at 2022-06-23 21:11:16.885811
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == 'c3958e1f-8c29-484a-a66c-d717d8f00109'


# Generated at 2022-06-23 21:11:22.574552
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """ Test for method token_bytes of class Cryptographic
    """
    obj = Cryptographic()
    token = obj.token_bytes()
    assert isinstance(token, bytes)
    assert len(token) == 32

    token = obj.token_bytes(16)
    assert isinstance(token, bytes)
    assert len(token) == 16



# Generated at 2022-06-23 21:11:29.205949
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cr = Cryptographic(seed=666)
    assert cr.token_bytes() == b'\xae\xac\xa6\x87\x84\x9f\x1a\xe8N\x1e\x11\x0f\x0e\x17\r\xbe\xcf\x07\x8b\x1d\xf5\x07P\n\xe6\r:\xb9\x97\xcb\x1c{'


# Generated at 2022-06-23 21:11:30.939420
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    mn = Cryptographic()
    print("Method:", mn.token_urlsafe())

# Generated at 2022-06-23 21:11:33.519441
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic"""
    assert len(Cryptographic().uuid(as_object=True)) != 0
    assert len(Cryptographic().uuid(as_object=False)) != 0


# Generated at 2022-06-23 21:11:35.944065
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic"""
    c = Cryptographic()
    assert c.hash() is not None



# Generated at 2022-06-23 21:11:40.469497
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    result = provider.token_urlsafe()
    assert result == "ZWU1ZDk5NTI1YmE0NDQ2NzdiYzc4Zjg4ZDc0ZTA4NWFlZmM3NTM3YmJjMzhlYmQ5NDQzMWNjZjU5ZDU5NzA5OA"

# Generated at 2022-06-23 21:11:45.988036
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert len(crypto.token_hex()) == 64
    assert crypto.token_hex(entropy=16) == crypto.token_hex(entropy=16)
    assert len(crypto.token_hex(entropy=16)) == 32
    assert crypto.token_hex(entropy=0) == ''


# Generated at 2022-06-23 21:11:48.246149
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test Cryptographic constructor."""
    obj = Cryptographic()

    assert isinstance(obj, Cryptographic)


# Generated at 2022-06-23 21:11:49.686553
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  for _ in range(10):
    print(Cryptographic().token_urlsafe())


# Generated at 2022-06-23 21:11:51.354375
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    secret = Cryptographic.token_bytes()
    print(secret)
    pass


# Generated at 2022-06-23 21:11:52.787724
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash().__len__() is 40


# Generated at 2022-06-23 21:11:54.124287
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print(Cryptographic().mnemonic_phrase())

# Generated at 2022-06-23 21:12:01.624732
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Testing Cryptographic.mnemonic_phrase()."""
    from mimesis import Cryptographic
    from mimesis.enums import Algorithm

    mnemonic_1 = Cryptographic.mnemonic_phrase(separator=' ', length=12)
    mnemonic_2 = Cryptographic.mnemonic_phrase(separator=' ', length=12)

    assert isinstance(mnemonic_1, str)
    assert isinstance(mnemonic_2, str)
    assert mnemonic_1 != mnemonic_2


if __name__ == '__main__':
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:12:04.036471
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Given
    crypt = Cryptographic() # Initialization Cryptographic

    # When
    result = crypt.uuid() # Calling method uuid
    # Then
    assert isinstance(result, str) # Check results
    assert isinstance(crypt.uuid(as_object=True), UUID) # Check results


# Generated at 2022-06-23 21:12:06.975613
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    my_uuid = c.uuid()
    print(my_uuid)
    assert my_uuid is not None



# Generated at 2022-06-23 21:12:08.806277
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    token = c.token_urlsafe()
    print(token)


# Generated at 2022-06-23 21:12:11.964120
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    mnemonic1 = Cryptographic().hash()
    mnemonic2 = Cryptographic().hash()
    assert mnemonic1[0:30] == mnemonic2[0:30]


# Generated at 2022-06-23 21:12:15.987775
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test for class Cryptographic"""
    c_object = Cryptographic(seed=1234)
    assert c_object.uuid() == '2b6f7b34-05d6-4f3c-92f1-8a123d9d948f'
    assert c_object.uuid() == 'fa7c6fa1-6f7e-480c-9e9c-caa6f0b61632'
    assert c_object.uuid() != '1234'
    assert c_object.hash() == '127f78fb8bfecfda0ffc3d3b3a79d8ed5a9f60a5f5ffee5e5a8be4e4d4bbf2c4'

# Generated at 2022-06-23 21:12:17.373971
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    actual = Cryptographic().hash()
    assert isinstance(actual, str)


# Generated at 2022-06-23 21:12:21.276489
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic.token_bytes()
    assert len(token) == 32
    token = Cryptographic.token_bytes(24)
    assert len(token) == 24



# Generated at 2022-06-23 21:12:23.543519
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase())


# Generated at 2022-06-23 21:12:26.535846
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # setup
    length = 1
    # exercise
    c = Cryptographic()
    phrase = c.mnemonic_phrase(length)
    print(phrase)
    assert len(phrase.split(' ')) == length

# Generated at 2022-06-23 21:12:31.277399
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test the function Cryptographic._uuid."""
    test_uuid = UUID('bd7a5cf5-9168-4f3b-9a7e-053a777a0bf8')
    crypto = Cryptographic()
    assert crypto.uuid(as_object=True) == test_uuid


# Generated at 2022-06-23 21:12:37.386615
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj1 = Cryptographic()
    obj2 = Cryptographic()

    u1 = obj1.uuid()
    u2 = obj2.uuid()

    assert isinstance(u1, str)
    assert isinstance(u2, str)
    assert len(u1) > 0
    assert len(u2) > 0



# Generated at 2022-06-23 21:12:38.433725
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()

    assert c.__class__.__name__ == 'Cryptographic'

# Generated at 2022-06-23 21:12:39.719777
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase() is not None



# Generated at 2022-06-23 21:12:40.825214
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic()

# Unit tests for function uuid

# Generated at 2022-06-23 21:12:43.423678
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token_bytes = crypto.token_bytes()
    assert token_bytes is not None


# Generated at 2022-06-23 21:12:49.581801
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    it = 100
    separators = [' ', ',', '_', 'а', '+', '-']
    for i in range(it):
        for separator in separators:
            mnemonic_phrase = c.mnemonic_phrase(separator=separator)
            assert len(mnemonic_phrase) == 12 * (len(separator) + 1)
            assert mnemonic_phrase.count(separator) == 11


# Generated at 2022-06-23 21:12:52.114496
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Arrange
    c = Cryptographic()
    # Act
    result = c.uuid()
    # Assert
    assert len(result) == 36

test_Cryptographic()


# Generated at 2022-06-23 21:12:53.182219
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cry=Cryptographic()
    cry.mnemonic_phrase()

# Generated at 2022-06-23 21:12:55.672404
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex(32)) == 64
    assert len(Cryptographic.token_hex()) == 64
    assert len(Cryptographic.token_hex(48)) == 96
    assert len(Cryptographic.token_hex(1)) == 2

# Generated at 2022-06-23 21:12:56.641931
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print(Cryptographic().token_bytes(entropy=32))


# Generated at 2022-06-23 21:12:57.823816
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic"""
    assert type(Cryptographic().token_urlsafe()) == str

# Generated at 2022-06-23 21:13:04.149895
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.general import General
    crypto = Cryptographic(seed=456)
    gen = General(seed=789)
    for key in Algorithm:
        assert crypto.hash(key) != crypto.hash(key)
        assert crypto.hash(key) != gen.uuid()


# Generated at 2022-06-23 21:13:07.392876
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    text = c.token_hex()
    isinstance(text, str) == True
    len(text) == 64

# Generated at 2022-06-23 21:13:08.994277
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.__class__.__name__ == 'Cryptographic'


# Generated at 2022-06-23 21:13:09.567948
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cryptographic()

# Generated at 2022-06-23 21:13:12.412739
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    custom_seed = 123454321
    p = Cryptographic(seed=custom_seed)
    assert p.seed == custom_seed


# Generated at 2022-06-23 21:13:14.275613
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    assert len(Cryptographic().token_urlsafe()) >= 22

# Generated at 2022-06-23 21:13:17.769582
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert crypto.uuid() == crypto.uuid()
    assert crypto.uuid() != crypto.uuid()
    

# Generated at 2022-06-23 21:13:18.573423
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  assert len(Cryptographic.token_hex()) == 64

# Generated at 2022-06-23 21:13:21.556874
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('Method hash')
    object_ = Cryptographic()
    object_.hash(Algorithm.SHA256)
    object_.hash(Algorithm.SHA512) 
    object_.hash(Algorithm.SHA_256)
    object_.hash(Algorithm.SHA_512)
    print('OK.') 


# Generated at 2022-06-23 21:13:22.531928
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass


# Generated at 2022-06-23 21:13:23.753240
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    pass


# Generated at 2022-06-23 21:13:27.059709
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    p = Cryptographic()
    for _ in range(100):
        _phrase = p.mnemonic_phrase(length=24)
        assert _phrase
        assert len(_phrase.split(' ')) == 24

# Generated at 2022-06-23 21:13:28.808238
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cr = Cryptographic()
    assert len(cr.token_bytes()) == 32


# Generated at 2022-06-23 21:13:31.694357
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """
    test for Cryptographic constructor
    """
    p = Cryptographic('seed')
    assert p.__class__.__name__ == "Cryptographic"

# Generated at 2022-06-23 21:13:35.663585
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test for method hash of class Cryptographic
    # initialize an instance varibale _random of class Random
    _cryptographic = Cryptographic()
    _algorithm = Algorithm.SHA1
    _hash = _cryptographic.hash(_algorithm)
    assert len(_hash) == 40


# Generated at 2022-06-23 21:13:39.464664
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe of class Cryptographic."""
    # 0. Token
    token = Cryptographic().token_urlsafe()
    assert isinstance(token, str)
    assert len(token) != 0
    assert '/' not in token
    assert '+' not in token
    assert '=' not in token

# Generated at 2022-06-23 21:13:42.199081
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # invoke token_bytes with a require argument
    # verify the output of the method
    assert len(Cryptographic.token_bytes(45)) == 45

# Generated at 2022-06-23 21:13:45.296350
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypt=Cryptographic()
    print(crypt.mnemonic_phrase(20))
    print(crypt.uuid())

if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:13:46.641968
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-23 21:13:51.296297
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test method token_hex of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    crypto = Cryptographic()
    _token = crypto.token_hex(32)
    assert isinstance(_token, str) and len(_token) == 64
    assert crypto.hash(Algorithm.SHA256)


# Generated at 2022-06-23 21:13:53.068743
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex(32)
    assert len(token) == 64
    assert isinstance(token, str)



# Generated at 2022-06-23 21:13:54.032249
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    pass



# Generated at 2022-06-23 21:14:02.205082
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase() == 'eye review comet distance step', 'wrong mnemonic_phrase'
    assert crypto.hash() == 'f08b35a9eaf37567ff12d15f85a7ea66'
    assert crypto.hash(Algorithm.MD5) == '6c934f7b090aecb1dae2cb27f3ce55f3'
    assert crypto.hash(Algorithm.SHA1) == '67ffd1953d32be7087e0cdf56ed7b0637c5ba6ea'

# Generated at 2022-06-23 21:14:04.021562
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for Cryptographic.uuid()"""
    c_uuid = Cryptographic()
    uid = c_uuid.uuid()
    assert type(uid) == str


# Generated at 2022-06-23 21:14:05.295264
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Test should pass without any errors
    assert Cryptographic().uuid() is not None

# Generated at 2022-06-23 21:14:08.036890
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print('\n---- testing Cryptographic Class Constructor')
    foo = Cryptographic()
    assert True == True

# Generated at 2022-06-23 21:14:09.915275
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    #Test the execution of the function
    c = Cryptographic()
    assert c.token_hex(32) == secrets.token_hex(32)

# Generated at 2022-06-23 21:14:13.530063
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    with Cryptographic() as crypto:
        print(crypto.uuid())
        print(crypto.token_hex())
        print(crypto.token_bytes())
        print(crypto.token_urlsafe())
        print(crypto.hash())

# Generated at 2022-06-23 21:14:14.876491
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    p = Cryptographic()
    assert p is not None

# Generated at 2022-06-23 21:14:17.489812
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic.token_urlsafe())

if __name__ == "__main__":
    test_Cryptographic_token_urlsafe()

# Generated at 2022-06-23 21:14:19.615147
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert crypto.token_hex(32) == '9d9a28c2f6ad333a6a8f6d3f3e106e6a'

# Generated at 2022-06-23 21:14:22.977353
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid().__class__.__name__ == 'str'
    assert len(c.uuid()) >= 32



# Generated at 2022-06-23 21:14:24.226240
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    Cryptographic.token_bytes(32)


# Generated at 2022-06-23 21:14:26.082818
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    Crypto = Cryptographic()
    res: str = Crypto.mnemonic_phrase()
    assert res == "skinny samba hazard eight couch glimpse"

# Generated at 2022-06-23 21:14:33.880076
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit tests for method hash of class Cryptographic."""
    # This method is working because it's random. But,
    # we can test that it only returns hexadecimal values
    # and that hashing algorithm is supported
    # by hashlib library.
    algorithm = Algorithm.MD5
    ch = Cryptographic()
    h = ch.hash(algorithm)

    assert len(h) == 32

    result = True
    try:
        int(h, 16)
    except ValueError:
        result = False

    assert result


# Generated at 2022-06-23 21:14:37.782307
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    mnemonic_phrase = crypto.mnemonic_phrase()
    assert len(mnemonic_phrase.split()) == 12


# Generated at 2022-06-23 21:14:39.994801
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    print(c.hash(Algorithm.SHA256))


# Generated at 2022-06-23 21:14:44.772984
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Test for method mnemonic_phrase of class Cryptographic
    """
    Test for method mnemonic_phrase of class Cryptographic
    :return: str
    """
    obj = Cryptographic()
    result = obj.mnemonic_phrase(length=3)
    print(result)
    # Exceptions
    #test_Cryptographic_mnemonic_phrase(Cryptographic)


# Generated at 2022-06-23 21:14:46.669561
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cryptographic = Cryptographic()
    assert cryptographic.uuid() == cryptographic.uuid()


# Generated at 2022-06-23 21:14:47.791737
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    assert a


# Generated at 2022-06-23 21:14:49.211476
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    tok = Cryptographic('en').token_hex(512)
    print(tok)



# Generated at 2022-06-23 21:14:50.624240
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    Crypto = Cryptographic()
    assert len(Crypto.token_bytes()) == 32

# Generated at 2022-06-23 21:14:52.623243
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    data = Cryptographic.token_bytes()
    assert len(data) == 32
    

# Generated at 2022-06-23 21:15:00.287872
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import mimesis.enums
    objects = dict()
    objects['algorithm'] = mimesis.enums.Algorithm

    def create_mock_hashlib(shash: Optional[str] = None):
        def getattr(key: str) -> Optional[str]:
            if key == 'sha256':
                return shash
            return None
        return getattr

    mock_hashlib = create_mock_hashlib('sha256')

    def create_mock_cryptographic(mock_hashlib):
        def get_hash(self: 'Cryptographic', algorithm: Optional[str]) -> str:
            if algorithm is None:
                algorithm = Algorithm.SHA256
            if hasattr(hashlib, algorithm):
                fn = getattr(hashlib, algorithm)

# Generated at 2022-06-23 21:15:04.171066
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
	m = Cryptographic(seed=1)
	assert m.mnemonic_phrase(length=12, separator=' ') == 'jumbo sheaf astride thick-kneed score nine-spot ageratum brazilian tipsy glaswegian jewel-case'

# Generated at 2022-06-23 21:15:08.209463
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Generate UUID
    uuid = Cryptographic.uuid()
    # Normal assertion
    assert isinstance(uuid, str) # docstring: Returns UUID.
    uuid_object = Cryptographic.uuid(as_object=True)
    assert isinstance(uuid_object, UUID) # docstring: Returns UUID.


# Generated at 2022-06-23 21:15:10.033400
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method Cryptographic.uuid."""
    result = Cryptographic.uuid()
    assert isinstance(result, str)
    assert len(result) == 36


# Generated at 2022-06-23 21:15:13.518106
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    token = provider.token_urlsafe(32)
    assert len(token) == 43
    assert provider.token_urlsafe(56) != token

# Generated at 2022-06-23 21:15:15.795361
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    data = Cryptographic()
    assert type(data.token_hex(10)) is str
    assert len(data.token_hex(10)) == 22


# Generated at 2022-06-23 21:15:19.554998
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    instance = Cryptographic()
    assert isinstance(instance, Cryptographic)

# Unit test get_random_bytes

# Generated at 2022-06-23 21:15:20.786868
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic() != None


# Generated at 2022-06-23 21:15:22.817496
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert Cryptographic().mnemonic_phrase()  # noqa: WPS433



# Generated at 2022-06-23 21:15:24.796991
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    result = Cryptographic.token_bytes()
    assert isinstance(result, bytes)
    assert len(result) == 32


# Generated at 2022-06-23 21:15:33.183153
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    ###
    # Generate pseudo mnemonic phrase
    crypto = Cryptographic(seed=123)
    mnemonic_phrase = crypto.mnemonic_phrase(length=10)
    print("mnemonic_phrase: %s" % mnemonic_phrase)
    assert mnemonic_phrase == 'wander'
    ###
    # Generate pseudo mnemonic phrase with a separator
    crypto = Cryptographic(seed=123)
    mnemonic_phrase = crypto.mnemonic_phrase(length=10, separator='|')
    print("mnemonic_phrase_with_separator: %s" % mnemonic_phrase)
    assert mnemonic_phrase == 'wander'
    ###

# Generated at 2022-06-23 21:15:35.450572
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert Cryptographic().token_urlsafe() != Cryptographic().token_urlsafe()

# Generated at 2022-06-23 21:15:41.842596
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    assert len(obj.uuid()) == 36
    assert len(obj.hash(Algorithm.SHA1)) == 40
    assert len(obj.token_hex(6)) == 12
    assert len(obj.token_bytes(6)) == 6
    assert len(obj.token_urlsafe(6)) == 6
    assert len(obj.mnemonic_phrase()) == 24

test_Cryptographic()

# Generated at 2022-06-23 21:15:42.880059
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32

# Generated at 2022-06-23 21:15:45.318640
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    crypto = Cryptographic()
    assert isinstance(crypto.uuid(), str)



# Generated at 2022-06-23 21:15:45.947502
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic.token_hex()



# Generated at 2022-06-23 21:15:47.625674
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Constructor of class Cryptographic
    cryptographic = Cryptographic()
    assert cryptographic


# Generated at 2022-06-23 21:15:49.480954
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    phrase = c.mnemonic_phrase()
    assert isinstance(phrase, str) and len(phrase) > 0

# Generated at 2022-06-23 21:15:52.904105
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    provider = Cryptographic()
    for _ in range(100):
        assert len(provider.token_bytes(20)) == 20



# Generated at 2022-06-23 21:15:56.216357
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    # crypto.random.seed(1)
    print("0x"+crypto.token_bytes().hex())


# Generated at 2022-06-23 21:16:05.436543
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic(seed = 42)
    #test for uuid
    assert c.uuid() == 'e4fa4657-ec4c-4a9e-9c6a-2d1b4006dfad'
    assert c.uuid(as_object=True).hex == 'e4fa4657ec4c4a9e9c6a2d1b4006dfad'
    assert c.uuid(as_object=True).int == 23621214106035809859124748254896191044
    # test for hash
    assert c.hash(algorithm = Algorithm.MD5) == '8355c12545702d3cbb9b2ea8b8f15d47'

# Generated at 2022-06-23 21:16:15.247197
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.providers.cryptographic import Cryptographic
    from base64 import b64encode
    from binascii import unhexlify
    from fractions import gcd
    from random import SystemRandom
    from secrets import choice
    from typing import Callable

    rng = SystemRandom()
    def test(nbytes):
        result = Cryptographic().token_bytes(nbytes)
        return len(result) == nbytes

    res = test(0)
    assert res
    res = test(1)
    assert res
    res = test(10)
    assert res
    res = test(100)
    assert res
    res = test(1000)
    assert res

    def is_multiple(nbytes: int, size: int = 1) -> bool:
        """Ensure that returned value is multiple of size."""


# Generated at 2022-06-23 21:16:16.709194
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    # print("UUID returned by crypto.uuid:", crypto.uuid())
    # print("Mnemonic phrase returned by crypto.mnemonic_phrase:", crypto.mnemonic_phrase())

# Generated at 2022-06-23 21:16:20.793502
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
  crypto = Cryptographic()
  result = crypto.mnemonic_phrase()
  print(result)
  assert len(result) == 12


# Generated at 2022-06-23 21:16:23.353464
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic(seed=12345)
    hash = crypto.hash()
    assert hash
    assert isinstance(hash, str)

# Generated at 2022-06-23 21:16:28.125573
# Unit test for method uuid of class Cryptographic

# Generated at 2022-06-23 21:16:29.433684
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crp = Cryptographic()
    assert crp.token_bytes()


# Generated at 2022-06-23 21:16:32.477643
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    res = provider.token_urlsafe(48)
    assert len(res) == 66
    assert res[-1] != '='
    assert res[-2] != '='


# Generated at 2022-06-23 21:16:38.530760
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('Testing Cryptographic.hash')
    # Initializing the provider
    random = Cryptographic()
    assert random.hash(Algorithm.SHA512) == random.hash(Algorithm.SHA512)
    assert random.hash(Algorithm.SHA512) != random.hash(Algorithm.SHA256)
    assert isinstance(random.hash(Algorithm.SHA256), str)
    print('Done')



# Generated at 2022-06-23 21:16:41.112269
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    m = Cryptographic()
    x = m.mnemonic_phrase(3)
    assert isinstance(x, str)

# Generated at 2022-06-23 21:16:52.772950
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    def test_uuid_1():
        import string
        import random
        uuid_template = '{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}'
        int_part = uuid_template.format(*[random.randint(0, 9) for i in range(32)])
        str_part = uuid_template.format(*[random.choice(string.ascii_letters) for i in range(32)])
        return int(str_part + int_part)

    assert type(Cryptographic.uuid(as_object=False)) == str
    assert type(Cryptographic.uuid(as_object=True)) == UUID
    assert len(str(Cryptographic.uuid(as_object=True))) == 36

# Generated at 2022-06-23 21:16:55.744155
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe()
    try:
        assert len(token) == 43
        assert type(token) == str
    except AssertionError:
        print("token_urlsafe(entropy=32) returns a string of 43 characters")

# Generated at 2022-06-23 21:16:56.836843
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    token = c.token_bytes()
    assert token is not None

# Generated at 2022-06-23 21:16:58.627987
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    result = Cryptographic().token_hex(length=32)
    assert len(result) == 32
    assert isinstance(result, str)



# Generated at 2022-06-23 21:17:00.096332
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cg = Cryptographic()
    result = cg.token_urlsafe(16)
    print(result)

# Generated at 2022-06-23 21:17:02.256138
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    entropy = crypto.token_urlsafe()
    print(entropy)
    print(type(entropy))
    assert len(entropy) == 44


# Generated at 2022-06-23 21:17:04.016948
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=474747)
    assert c.mnemonic_phrase() == 'horror sudden drink market toast'
    assert c.mnemonic_phrase(length=14) == 'finger zone fair dial sarah float man rail object acid quick'

# Generated at 2022-06-23 21:17:05.348842
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    # Test normal words
    print(c.mnemonic_phrase())

# Test UUID

# Generated at 2022-06-23 21:17:10.935762
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test that method mnemonic_phrase does not return anything."""
    from os import environ

    environ['MIMESIS_SEED'] = '666'
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase(length=50) != ' '
    """
    The phrase should not be empty.
    """

# Generated at 2022-06-23 21:17:13.189774
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    print(c.token_hex())

# Generated at 2022-06-23 21:17:20.899402
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid(as_object=True) is UUID
    assert type(c.uuid(as_object=True)) is UUID
    assert c.uuid(as_object=False) is str
    assert type(c.uuid(as_object=False)) is str
    assert type(c.uuid(as_object=True)) is UUID
    assert type(c.uuid(as_object=False)) is str
    assert type(c.uuid(as_object=True)) is UUID
    assert type(c.uuid(as_object=False)) is str
    assert type(c.uuid(as_object=True)) is UUID
    assert type(c.uuid(as_object=False)) is str

# Generated at 2022-06-23 21:17:22.584830
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic() is not None


# Generated at 2022-06-23 21:17:25.402182
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 36
    assert type(Cryptographic().uuid()) == str
    assert type(Cryptographic().uuid(as_object=True)) == UUID


# Generated at 2022-06-23 21:17:27.506441
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    if(len(Cryptographic().token_bytes())==32):
       return True
    else:
       return False


# Generated at 2022-06-23 21:17:31.814392
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """test_Cryptographic_hash"""
    cryptographic = Cryptographic(seed=12345)
    assert cryptographic.hash() == '66a3e3f11d59a7a1a55e3f7b1f933f41e68fa99b'

# Generated at 2022-06-23 21:17:42.387076
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  assert Cryptographic.token_urlsafe(32) == 'mEZ_e8Uf47JXd4G4OpF6W5hDzvf5KjSx'
  assert Cryptographic.token_urlsafe(32) == 'jnRf1zG2hc_Am-kxqfCdArmy95ZT2jYT'
  assert Cryptographic.token_urlsafe(32) == 'BhRJH7sx_cKZV7l8eCpPn7JljKrZV7A8'
  assert Cryptographic.token_urlsafe(32) == 'AEjB6Q4_1if5TE5PB5StNzNjEk0NxhZb'

# Generated at 2022-06-23 21:17:44.867333
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    result = cr.hash(Algorithm.MD5)
    print(result)
    assert result is not None


# Generated at 2022-06-23 21:17:47.028974
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(32) == 'u4myVLG4WZuN7Q1aS6Nk7NdD6M8'

# Generated at 2022-06-23 21:17:49.624234
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'a7b87a39c1568eb4b3ce4d4b39f1bdf6'


# Generated at 2022-06-23 21:17:51.743485
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex(): # noqa
    c = Cryptographic()
    assert c.token_hex(0) == ''
    c.token_hex(100)

# Generated at 2022-06-23 21:17:54.849877
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for method token_bytes of class Cryptographic."""
    seed = 0
    crypto = Cryptographic(seed=seed)
    token_bytes = crypto.token_bytes()
    token_bytes1 = crypto.token_bytes()
    if seed == 0:
        assert token_bytes == token_bytes1


# Generated at 2022-06-23 21:18:00.741643
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic(seed=12345)
    token = crypto.token_urlsafe(64)
    assert token == "Q0T0TldTZTk2OUZ6U2Z6U0Z6U2Z6U0Z6U0Z6U0Z6U0Z6U0Z6U0Z6U0Z6U0Y"

# Generated at 2022-06-23 21:18:04.703567
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    token = crypto.mnemonic_phrase(16)
    assert type(token) == str
    assert len(token.split(' ')) == 16
    print(token)



# Generated at 2022-06-23 21:18:09.841887
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    
    # test for SHA256
    for i in range(0, 1000):
        h = c.hash(Algorithm.SHA256)
        assert(len(h) == 64)
    
    # test for SHA512
    for i in range(0, 1000):
        h = c.hash(Algorithm.SHA512)
        assert(len(h) == 128)


# Generated at 2022-06-23 21:18:11.433060
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid = Cryptographic().uuid()
    assert isinstance(uuid, str)


# Generated at 2022-06-23 21:18:13.687522
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    z = Cryptographic()
    assert len(z.uuid()) == 36
    assert len(z.uuid(as_object=True).hex) == 32
    assert len(Cryptographic.uuid(as_object=True).hex) == 32


# Generated at 2022-06-23 21:18:16.328907
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    actual = crypto.uuid()
    assert isinstance(actual, str)
    assert len(actual) == 36
    assert crypto.uuid(as_object=True).version == 4


# Generated at 2022-06-23 21:18:19.163994
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()

    result = c.token_bytes()
    assert isinstance(result, bytes)


# Generated at 2022-06-23 21:18:25.368941
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.uuid()
    assert c.uuid(True)
    assert c.mnemonic_phrase()
    assert c.mnemonic_phrase(6)
    assert c.hash()
    assert c.hash(Algorithm.BLAKE2B)
    assert c.token_bytes()
    assert c.token_hex()
    assert c.token_urlsafe()

# Generated at 2022-06-23 21:18:28.265387
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic(seed=42)
    result = provider.uuid()
    assert result == '6b1a876b-965b-4ac7-a27b-8bd7e09a95d3'


# Generated at 2022-06-23 21:18:30.935667
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    result = c.token_urlsafe()
    assert type(result) == str

# Generated at 2022-06-23 21:18:32.915438
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    result = Cryptographic.token_urlsafe()
    assert isinstance(result, str)
    assert len(result) >= 32

# Generated at 2022-06-23 21:18:38.033414
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.mnemonic_phrase() is not None
    assert c.token_bytes() is not None
    assert c.token_hex() is not None
    assert c.token_urlsafe() is not None
    assert c.hash() is not None
    assert c.uuid() is not None
    assert isinstance(c, Cryptographic)

# Generated at 2022-06-23 21:18:40.903435
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=12345)
    print(c.mnemonic_phrase(length=12))

if __name__ == '__main__':
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:18:43.630601
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cryptographic = Cryptographic()
    assert cryptographic.uuid() != cryptographic.uuid()
    assert cryptographic.uuid(as_object=True).version == 4



# Generated at 2022-06-23 21:18:45.557291
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    result = provider.token_hex()
    print(result)

# Generated at 2022-06-23 21:18:50.982229
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():      # noqa: D103
    provider = Cryptographic(seed=1234567)
    for i in range(10):
        assert provider.token_urlsafe() == "EuxV7TcTfLY1li7jNgO6zvU0_RcNRzpN8O-j6lDd6Qk"

# Generated at 2022-06-23 21:18:53.544872
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe())
    assert len(Cryptographic().token_urlsafe(100)) == 100

# Generated at 2022-06-23 21:18:55.540831
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    print(c.hash(Algorithm.SHA256))

if __name__ == '__main__':
    test_Cryptographic_hash()

# Generated at 2022-06-23 21:19:02.031201
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # 1. Check the token
    token = Cryptographic.token_urlsafe()
    print(token)
    assert '-' in token
    assert '_' in token
    assert '=' not in token

    # 2. Check the token with entropy
    token = Cryptographic.token_urlsafe(5)
    print(token)
    assert '=' not in token
    assert len(token) == 8

    # 3. Check the token with entropy
    token = Cryptographic.token_urlsafe(6)
    print(token)
    assert '=' in token
    assert len(token) == 12

