

# Generated at 2022-06-23 21:09:01.227111
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  assert type(Cryptographic().token_hex(16)) == str

# Generated at 2022-06-23 21:09:02.487779
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    assert len(provider.token_hex()) == 64

# Generated at 2022-06-23 21:09:04.759886
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic"""

    for _ in range(100):
        assert len(Cryptographic().uuid()) == 36



# Generated at 2022-06-23 21:09:10.593463
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic."""
    c = Cryptographic(seed=123)
    # test for random bytes
    u = c.uuid()
    assert len(u) == 36
    first = u[:9]
    second = u[13:18]
    third = u[23:36]
    assert first.isdigit()
    assert second.isdigit()
    assert third.isalnum()
    assert u[9] == '-'
    assert u[14] == '-'
    assert u[18] == '-'
    assert u[19] == '4'



# Generated at 2022-06-23 21:09:12.685169
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    h = Cryptographic().hash()
    assert h is not None
    assert len(h) == 40


# Generated at 2022-06-23 21:09:15.353711
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryp = Cryptographic()
    cryp.hash(Algorithm.MD5)


# Generated at 2022-06-23 21:09:17.178702
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    x = Cryptographic()
    assert isinstance(x.uuid(), str)



# Generated at 2022-06-23 21:09:18.709332
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cryptographic(seed=1)

# Generated at 2022-06-23 21:09:29.538016
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    obj = Cryptographic()
    data = [obj.uuid(as_object=False), obj.uuid(as_object=True)]
    assert len(data) == 2
    assert isinstance(data[1], UUID)
    assert len(obj.hash()) == 32
    assert obj.hash(algorithm=Algorithm.MD5) == 'afbb8ff77e69afd9e1e9a9f6a8782f5f'
    assert isinstance(obj.hash(), str)
    assert isinstance(obj.hash(algorithm=Algorithm.MD5), str)
    assert len(obj.mnemonic_phrase()) == 96

# Generated at 2022-06-23 21:09:39.454742
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # create instance with random seed
    random, seed = 42, 42
    my_obj = Cryptographic(random, seed)
    
    # check existence of the attribute uuid
    assert hasattr(my_obj, 'uuid')
    # check the type of the attribute uuid
    assert isinstance(getattr(my_obj, 'uuid'),
                      classmethod)
    
    # random, seed = 42, 42
    # my_obj = Cryptographic(random, seed)
    # assert isinstance(my_obj.uuid(), str)
    # assert '-' in my_obj.uuid()
    # assert len(my_obj.uuid().split('-')) == 5
    # assert isinstance(my_obj.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:09:50.801705
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
	from mimesis.enums import Algorithm
	from mimesis.exceptions import NonEnumerableError

	cryptographic = Cryptographic()
	token = cryptographic.token_hex()
	assert token == cryptographic.token_hex()
	assert len(token) == 64

	token_128 = cryptographic.token_hex(entropy=128)
	assert len(token_128) == 256

	token_bytes = cryptographic.token_bytes(entropy=128)
	assert token_bytes == cryptographic.token_bytes(entropy=128)

	token_urlsafe = cryptographic.token_urlsafe()
	assert token_urlsafe == cryptographic.token_urlsafe()
	assert len(token_urlsafe) == 44

	token_urlsafe_128 = cryptographic.token_urlsafe(entropy=128)

# Generated at 2022-06-23 21:09:52.407097
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic(seed = 1234)
    assert obj is not None

# Generated at 2022-06-23 21:09:54.557192
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp = Cryptographic()
    value = cp.mnemonic_phrase()
    assert isinstance(value, str) and len(value.split()) == 12

# Generated at 2022-06-23 21:09:59.880571
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase of class Cryptographic."""
    # Create the cryptographic object
    c1 = Cryptographic()
    c2 = Cryptographic(seed=0)
    # Test the method of the cryptographic object
    phrase1 = c1.mnemonic_phrase()
    phrase2 = c2.mnemonic_phrase()
    assert phrase1 == 'fate call thought neither lot process'
    assert phrase2 == 'fate call thought neither lot process'

# Generated at 2022-06-23 21:10:01.776289
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
	x = Cryptographic().token_urlsafe()
	assert isinstance(x,str)


# Generated at 2022-06-23 21:10:05.241749
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()

    # test 'uuid' method
    assert type(provider.uuid() != str)
    assert type(provider.uuid(as_object=True)) == UUID

# Generated at 2022-06-23 21:10:14.452540
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    import random
    import string
    import sys
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    a = Cryptographic('en')
    actual = [a.token_bytes() for i in range(1000)]

# Generated at 2022-06-23 21:10:15.911778
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr = Cryptographic()
    cr.token_hex()
    assert True

# Generated at 2022-06-23 21:10:18.413742
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    instance = Cryptographic()
    assert instance is not None
    assert isinstance(instance, Cryptographic)


# Generated at 2022-06-23 21:10:29.569629
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))  # noqa
    from seed.test_helper import seed

    with seed(1):
        c = Cryptographic()
        assert c.token_urlsafe() == 'r5fIgXbUX1uSKt1Gx7x-Iw'
        assert c.token_urlsafe(10) == 'EU33X_7Vn0w'
        assert c.token_urlsafe() == '_0q3pUnHsPs8WJg9Y0b6UQ'
        assert c.token_urlsafe(10) == 'cS0SJf93W0'

# Generated at 2022-06-23 21:10:34.082310
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test token_bytes of class Cryptographic"""
    crypt_ = Cryptographic()
    assert len(crypt_.token_bytes()) == 32
    assert len(crypt_.token_bytes(10)) == 20
    # The bytes object can be serialized as a string
    assert isinstance(crypt_.token_bytes().decode(), str)


# Generated at 2022-06-23 21:10:35.440525
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    assert len(provider.token_hex()) == 64


# Generated at 2022-06-23 21:10:40.694559
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.enums import Algorithm
    import re
    test_token = Cryptographic.token_urlsafe()
    assert re.fullmatch(r'[A-Za-z0-9_\-]{32}', test_token)
    test_sha1 = Cryptographic.hash(algorithm=Algorithm.SHA_1)
    assert re.fullmatch(r'[a-f0-9]{40}', test_sha1)

# Generated at 2022-06-23 21:10:42.900934
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    res = Cryptographic().token_urlsafe(24)
    assert isinstance(res, str)

# Generated at 2022-06-23 21:10:47.246685
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Arrange
    crypto = Cryptographic()
    n = 5
    sep = "space"
    expected = len(sep) * (n - 1) + n * 13
    # Act
    actual = len(crypto.mnemonic_phrase(n, sep))
    # Assert
    assert actual == expected, "actual = {0}, expected = {1}".format(actual, expected)


# Generated at 2022-06-23 21:10:48.974083
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    a = Cryptographic()
    assert isinstance(a.token_bytes(), bytes)


# Generated at 2022-06-23 21:10:51.472879
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token_bytes = crypto.token_bytes()
    assert isinstance(token_bytes, bytes)
    assert len(token_bytes) == 32


# Generated at 2022-06-23 21:10:53.263599
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cryptographic = Cryptographic()
    assert isinstance(str(cryptographic.uuid()), str)


# Generated at 2022-06-23 21:10:55.288785
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str)
    assert isinstance(Cryptographic(seed=12345).uuid(), str)


# Generated at 2022-06-23 21:10:58.432653
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    a = c.hash()
    b = c.hash()
    assert(a != b)


# Generated at 2022-06-23 21:11:02.682264
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    p = Cryptographic()
    assert type(p.uuid()) == str
    assert str(uuid4()) == str(uuid4())
    assert type(p.uuid(True)) == UUID
    assert str(uuid4()) != p.uuid()


# Generated at 2022-06-23 21:11:08.245804
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    mnemonic_phrase = c.mnemonic_phrase()
    assert isinstance(mnemonic_phrase, str)
    tokens = [c.token_urlsafe(16), c.token_urlsafe(32), c.token_urlsafe(64), c.token_urlsafe(128)]
    for token in tokens:
        assert isinstance(token, str)
        assert len(token) == len(tokens[2])

# Generated at 2022-06-23 21:11:10.192238
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    data = Cryptographic().mnemonic_phrase()
    n = data.split(" ")
    assert len(n) == 12, "Cannot generate a list of 12 words"



# Generated at 2022-06-23 21:11:16.088142
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print("Running unit test for method token_urlsafe of class Cryptographic")
    cr = Cryptographic()
    assert(len(cr.token_urlsafe(0)) == 0)
    assert(len(cr.token_urlsafe(1)) > 0)
    assert(len(cr.token_urlsafe()) == 44)
    print("PASS")


# Generated at 2022-06-23 21:11:18.647486
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # The function for unit test of method token_hex of class Cryptographic
    assert Cryptographic().token_hex(3) == '7c658f8b34'

# Generated at 2022-06-23 21:11:21.770646
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
  c = Cryptographic()
  b = c.token_bytes()
  assert b != c.token_bytes()
  assert len(b) == 32


# Generated at 2022-06-23 21:11:23.107411
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert isinstance(Cryptographic().token_bytes(), bytes)


# Generated at 2022-06-23 21:11:26.349663
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    obj = Cryptographic()
    token = obj.token_urlsafe(1)
    assert isinstance(token, str) and len(token) == len(obj.token_hex(1))/2

# Generated at 2022-06-23 21:11:28.162670
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    assert len(str(obj.uuid())) > 0



# Generated at 2022-06-23 21:11:31.139990
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    try:
        c.__seed = "some-seed"
        assert c.uuid() != c.uuid()
    except:
        assert True
    else:
        assert False



# Generated at 2022-06-23 21:11:32.575602
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    h = c.hash()
    assert isinstance(h, str)


# Generated at 2022-06-23 21:11:36.121318
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    assert len(crypto.token_urlsafe(64)) == 86
    assert len(crypto.token_urlsafe(128)) == 172
    assert len(crypto.token_urlsafe(256)) == 344


# Generated at 2022-06-23 21:11:37.299538
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    size = 64 # default parameter
    t = Cryptographic()
    assert len(t.token_hex(size)) == size

# Generated at 2022-06-23 21:11:39.152599
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Check if two values are equal
    assert Cryptographic.token_hex(16) == Cryptographic.token_hex(16)


# Generated at 2022-06-23 21:11:41.762064
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    obj.mnemonic_phrase()
    obj.hash()
    obj.uuid()
    obj.token_bytes()
    obj.token_hex()
    obj.token_urlsafe()
    assert obj is not None

# Generated at 2022-06-23 21:11:44.325947
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    Crypto = Cryptographic()
    mnemonic_phrase = Crypto.mnemonic_phrase()
    assert mnemonic_phrase is not None


# Generated at 2022-06-23 21:11:53.541531
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    from mimesis.enums import HashAlgorithm
    from mimesis.providers.cryptographic import Cryptographic

    seed = '8e8c41a0-e48c-4d80-8cc2-9fb924eb7019'
    c = Cryptographic(seed=seed)

    assert c.token_urlsafe() == c.token_urlsafe()
    assert len(c.token_urlsafe()) == 43
    assert c.token_urlsafe(0) == c.token_urlsafe(0)
    assert len(c.token_urlsafe(0)) == 0
    assert c.token_urlsafe(10) != c.token_urlsafe(10)

# Generated at 2022-06-23 21:11:58.269399
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.uuid().__class__.__name__ == 'str'
    assert c.uuid(as_object=True).__class__.__name__ == 'UUID'
    assert c.mnemonic_phrase(length=6).__class__.__name__ == 'str'
    assert c.mnemonic_phrase(length=6, separator='|').__class__.__name__ == 'str'
    assert c.hash(algorithm=Algorithm.MD5).__class__.__name__ == 'str'

# Generated at 2022-06-23 21:12:02.518357
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()

    # Test for:
    # * seed = True
    # * as_object = True
    # * algorithm = Algorithm.MD5

    hash_value = c.hash(algorithm=Algorithm.MD5)
    assert isinstance(hash_value, str)



# Generated at 2022-06-23 21:12:05.089473
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    gen = Cryptographic()
    assert isinstance(gen.mnemonic_phrase(), str)

# Generated at 2022-06-23 21:12:07.709118
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    import uuid
    assert isinstance(Cryptographic().uuid(False), str)
    assert isinstance(Cryptographic().uuid(True), uuid.UUID)

# Generated at 2022-06-23 21:12:16.440143
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm

    assert Cryptographic().token_hex() == '47f77c0d8a8839ee633fbd6acb558a9c'
    assert Cryptographic().hash(algorithm=Algorithm.SHA512) == '5c0ff3f3cb9f19e0a5dcd3f7b3e3c398d91f8ea8dbc7a2e4dd4c7235d8caed33b25a78b32e1c737e2ea2c26f4746f980'
    assert Cryptographic().hash() == '93bd5767e0f0d7d2a89211c7e61e181f'

# Generated at 2022-06-23 21:12:19.275436
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():

    cryp = Cryptographic('en')
    result = cryp.mnemonic_phrase(12)
    assert type(result) == str


# Generated at 2022-06-23 21:12:29.928890
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method Cryptographic.token_urlsafe."""
    assert len(Cryptographic.token_urlsafe(0)) > 0, 'Implicit default should return value'
    assert len(Cryptographic.token_urlsafe(32)) == 64, '32 bytes should encode to 64 ASCII chars'
    assert len(Cryptographic.token_urlsafe(16)) == 32, '16 bytes should encode to 32 ASCII chars'
    assert len(Cryptographic.token_urlsafe(31)) == 62, '31 bytes should encode to 62 ASCII chars'
    assert len(Cryptographic.token_urlsafe(32)) == 64, '32 bytes should encode to 64 ASCII chars'
    assert len(Cryptographic.token_urlsafe(33)) == 66, '33 bytes should encode to 66 ASCII chars'

# Generated at 2022-06-23 21:12:33.691695
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Arrange
    obj = Cryptographic()
    
    # Act
    result = obj.token_bytes()

    # Assert
    assert result is not None

# Generated at 2022-06-23 21:12:35.318647
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print(Cryptographic.token_bytes())
    print(Cryptographic.token_bytes(10))


# Generated at 2022-06-23 21:12:36.437072
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64

# Generated at 2022-06-23 21:12:39.631991
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
	import mimesis.builtins
	builtins = mimesis.builtins.Cryptographic(seed = 0)
	assert builtins.token_hex() == 'c7d19de2a820968e3b9a63d4e4b4c8fa'


# Generated at 2022-06-23 21:12:44.794847
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypt = Cryptographic()
    print(crypt.hash(Algorithm.SHA256))
    print(crypt.hash(Algorithm.SHA512))
    print(crypt.hash(Algorithm.SHA384))
    print(crypt.hash(Algorithm.SHA1))
    print(crypt.hash(Algorithm.SHA224))
    print(crypt.hash(Algorithm.MD5))



# Generated at 2022-06-23 21:12:46.122150
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str)


# Generated at 2022-06-23 21:12:47.140449
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid()


# Generated at 2022-06-23 21:12:49.492388
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crp = Cryptographic()
    print(crp.uuid())
    print(crp.uuid(as_object=True))


# Generated at 2022-06-23 21:12:50.121297
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 22

# Generated at 2022-06-23 21:12:51.642086
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	# Initialize attributes.
	seed = 'test'
	cryptographic = Cryptographic(seed)

	# Assertions
	assert cryptographic.seed == seed

# Generated at 2022-06-23 21:12:53.254128
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Test that the length of the returned string is 32 bytes
    assert len(Cryptographic().token_hex(32)) == 64



# Generated at 2022-06-23 21:12:55.933910
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    '''
    This test tests whether the class constructor is working properly or not
    '''
    cp = Cryptographic(seed=100)
    assert isinstance(cp, Cryptographic),\
        "Object creation failed"


# Generated at 2022-06-23 21:12:56.449559
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    return Cryptographic().uuid()


# Generated at 2022-06-23 21:13:07.045602
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    myCrypto = Cryptographic()
    assert (myCrypto.uuid() != myCrypto.uuid())
    assert (myCrypto.uuid() != myCrypto.uuid())
    assert (myCrypto.uuid() != myCrypto.uuid())

    myCrypto = Cryptographic()
    assert (myCrypto.hash(Algorithm.MD5) != myCrypto.hash(Algorithm.MD5))
    assert (myCrypto.hash(Algorithm.MD5) != myCrypto.hash(Algorithm.MD5))
    assert (myCrypto.hash(Algorithm.MD5) != myCrypto.hash(Algorithm.MD5))

    myCrypto = Cryptographic()
    assert (myCrypto.hash(Algorithm.SHA1) != myCrypto.hash(Algorithm.SHA1))

# Generated at 2022-06-23 21:13:09.389525
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    assert isinstance(provider.uuid(), str)
    assert isinstance(provider.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:13:15.478231
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print('testing Cryptographic class')
    # testing constructor
    obj = Cryptographic()
    print(obj.uuid())
    print(obj.uuid(as_object=True))
    print(obj.hash())
    print(obj.hash(Algorithm.SHA512))
    print(obj.token_bytes())
    print(obj.token_hex())
    print(obj.token_urlsafe())
    print(obj.mnemonic_phrase())

test_Cryptographic()

# Generated at 2022-06-23 21:13:17.648081
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Unit test for constructor of class Cryptographic."""
    assert isinstance(Cryptographic(), Cryptographic)

# Generated at 2022-06-23 21:13:19.609156
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    print(c.token_hex(entropy=32))
    print(c.token_hex(entropy=64))


# Generated at 2022-06-23 21:13:23.632176
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    result = Cryptographic().token_urlsafe()
    assert result == b'8tKFcYdkJBwddvOT5W5x8lX0ZD2-kdvJAOt_0FA0'

# Generated at 2022-06-23 21:13:24.747153
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic().__class__.__name__ == 'Cryptographic'

# Generated at 2022-06-23 21:13:26.663153
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    s = c.hash()
    assert isinstance(s, str)
    l = len(s)
    assert l == 40 or l == 64

# Generated at 2022-06-23 21:13:27.950226
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    assert type(obj.uuid()) == str


# Generated at 2022-06-23 21:13:30.803693
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    if type(Cryptographic.token_hex(entropy = 5)) == str:
        return True
    else:
        return False


# Generated at 2022-06-23 21:13:39.999885
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.enums import Gender
    from mimesis.builtins import Datetime

    seed = 'seed'
    locale = 'en'
    gender = Gender.FEMALE

    provider = Cryptographic(locale=locale, seed=seed, gender=gender)

    assert provider.mnemonic_phrase()

    # Test with custom separator
    assert provider.mnemonic_phrase(separator=',')

    # Test with custom length
    assert provider.mnemonic_phrase(length=5)

    assert provider.uuid()
    assert provider.uuid(as_object=True)
    assert provider.uuid(as_object=True).hex

# Generated at 2022-06-23 21:13:42.429517
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    crypto = Cryptographic()
    assert crypto.token_urlsafe() == crypto.token_urlsafe()


# Generated at 2022-06-23 21:13:44.723426
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    for i in range(1000):
        output = Cryptographic.token_bytes()
        assert isinstance(output, bytes)


# Generated at 2022-06-23 21:13:48.671113
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic

    """
    # '1e0e79c3f3c892e80b16a7bfe9cd1621cf98b1917d654ac7cec1545c05ab357d'
    print(Cryptographic().token_hex())

# Generated at 2022-06-23 21:13:55.897791
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test method token_urlsafe
    of class Cryptographic.
    """
    test_object = Cryptographic()
    assert len(test_object.token_urlsafe(1)) == 1 #NOQA
    assert len(test_object.token_urlsafe(2)) == 2 #NOQA
    assert len(test_object.token_urlsafe(3)) == 3 #NOQA
    assert len(test_object.token_urlsafe(4)) == 4 #NOQA
    assert len(test_object.token_urlsafe(5)) == 5 #NOQA
    assert len(test_object.token_urlsafe(6)) == 6 #NOQA
    assert len(test_object.token_urlsafe(7)) == 7 #NOQA
    assert len(test_object.token_urlsafe(8)) == 8

# Generated at 2022-06-23 21:13:57.285203
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    assert obj is not None


# Generated at 2022-06-23 21:13:58.761706
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    C = Cryptographic()
    assert isinstance(C.token_bytes(), bytes)


# Generated at 2022-06-23 21:14:01.470600
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto_provider = Cryptographic()
    hash_string = crypto_provider.hash()
    assert (len(hash_string) == 40)


# Generated at 2022-06-23 21:14:04.923122
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 43
    assert len(Cryptographic().token_urlsafe(8)) == 16


# Generated at 2022-06-23 21:14:12.548639
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # seed = 5
    # cryptographic_1 = Cryptographic(seed=seed)
    # cryptographic_2 = Cryptographic(seed=seed)
    cryptographic_1 = Cryptographic()
    cryptographic_2 = Cryptographic()
    uuid_1 = cryptographic_1.uuid()
    uuid_2 = cryptographic_2.uuid()
    UUID(uuid_1, version=4)
    UUID(uuid_2, version=4)
    assert uuid_1 != uuid_2


# Generated at 2022-06-23 21:14:13.580751
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    Cryptographic.token_urlsafe()

# Generated at 2022-06-23 21:14:15.316478
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    mcp = Cryptographic()
    assert mcp.token_bytes()

# Generated at 2022-06-23 21:14:23.343323
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic.
    """
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    cp = Cryptographic()
    bytes_ = cp.token_hex(32)
    assert isinstance(bytes_, str)
    assert len(bytes_) == 64

    hash_ = cp.hash(algorithm=Algorithm.SHA3_256)
    assert isinstance(hash_, str)
    assert len(hash_) == 64

    hash_ = cp.hash(algorithm=Algorithm.SHA1)
    assert isinstance(hash_, str)
    assert len(hash_) == 40

    hash_ = cp.hash(algorithm=Algorithm.SHA3_384)
    assert isinstance(hash_, str)

# Generated at 2022-06-23 21:14:24.555020
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert(len(Cryptographic.token_bytes()) == 32)


# Generated at 2022-06-23 21:14:27.090558
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()

    hash1 = crypto.hash()
    assert(hash1 and len(hash1) > 0)

    hash2 = crypto.hash()
    assert(hash1 != hash2)


# Generated at 2022-06-23 21:14:28.409115
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto != None

# Generated at 2022-06-23 21:14:32.620265
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()

    # Tests default value of length
    assert len(crypto.mnemonic_phrase()) == 12

    # Tests default value of separator
    assert any(word in crypto.mnemonic_phrase(length=1) for word in crypto._data['words']['normal'])

# Generated at 2022-06-23 21:14:36.639375
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from uuid import uuid4
    from mimesis.builtins import Crypto
    from mimesis.enums import Algorithm

    crypto = Crypto('en')
    uuid = uuid4()
    hash = crypto.hash(algorithm=Algorithm.SHA1)
    phrase = crypto.mnemonic_phrase()

    assert len(phrase.split(' ')) == 12

# Generated at 2022-06-23 21:14:39.280410
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    result = crypto.token_bytes(5)
    assert type(result) == bytes and len(result) == 5

# Generated at 2022-06-23 21:14:43.269775
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic"""
    c = Cryptographic()
    print(f'test_Cryptographic_hash: {c.hash(Algorithm.SHA256)}')
    
if __name__ == '__main__':
    test_Cryptographic_hash()

# Generated at 2022-06-23 21:14:46.083482
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert not Cryptographic().token_hex(1) is None
    assert len(Cryptographic().token_hex()) == 64



# Generated at 2022-06-23 21:14:49.054196
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    bytes_string = secrets.token_urlsafe(32)
    assert bytes_string is b'5_8W4zVznZjKX9pVgJKjthrU1H6U0-6pYaj6ZfjdA0s'

# Generated at 2022-06-23 21:14:52.624301
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    print(provider.mnemonic_phrase())
    print(provider.mnemonic_phrase(length=6))
    print(provider.mnemonic_phrase(length=6, separator='-'))


# Generated at 2022-06-23 21:14:55.506977
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == '0a580f3a1c60e87d3e3b2a3b946f8c71784e83ee'

# Generated at 2022-06-23 21:15:00.113771
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    ex = obj.Algorithm.MD5
    h = obj.hash()
    assert len(h) == 32
    assert isinstance(h, str)
    h = obj.hash(ex)
    assert len(h) == 32
    assert isinstance(h, str)



# Generated at 2022-06-23 21:15:04.398217
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic(seed=12345)
    _token_hex = crypto.token_hex()
    if _token_hex == "aea51b2f02c1327bbaab40253a1f948b":
        return True
    return False


# Generated at 2022-06-23 21:15:05.973973
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypt = Cryptographic()
    result = crypt.token_urlsafe()
    assert type(result) == str

# Generated at 2022-06-23 21:15:07.071612
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    print(crypto.uuid)


# Generated at 2022-06-23 21:15:08.176002
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    result = Cryptographic().mnemonic_phrase()
    assert type(result) == str

# Generated at 2022-06-23 21:15:11.763728
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    obj = c.uuid(as_object=True)
    assert isinstance(obj, UUID)
    assert isinstance(obj, str)
    assert len(obj) == 5
    assert isinstance(c.uuid(as_object=False), str)
    assert isinstance(c.uuid(as_object=False), UUID)


# Generated at 2022-06-23 21:15:19.039889
# Unit test for constructor of class Cryptographic
def test_Cryptographic():

    assert(str(Cryptographic().uuid()).split('-')[0].strip() == "a6aa75c4b74e4c4d8fe4d4f4ff6b0a6c") 
    assert(Cryptographic().uuid().__repr__() == 'a6aa75c4b74e4c4d8fe4d4f4ff6b0a6c')
    assert(type(Cryptographic().uuid()) == type(uuid.UUID))
    assert(Cryptographic().uuid().variant == uuid.RFC_4122)
    assert(Cryptographic().uuid().version == 4)


# Generated at 2022-06-23 21:15:21.100463
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe()
    assert type(token) is str

# unit test for method mnemonic_phrase of class Cryptographic

# Generated at 2022-06-23 21:15:26.336626
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  crypt = Cryptographic()
  assert crypt.token_hex(4) == "d7b4e4c3bb1e4d27f0ce7b2bfdc8cc7f"

# Generated at 2022-06-23 21:15:28.516775
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cp = Cryptographic()
    b = cp.token_hex()
    assert isinstance(b, str)


# Generated at 2022-06-23 21:15:31.623232
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic('en', seed=42).uuid() == '3e20c1cc-2d7a-4e84-854c-e4b4f19d4ed4'


# Generated at 2022-06-23 21:15:33.143771
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    x = Cryptographic()
    assert isinstance(x.uuid(), str)


# Generated at 2022-06-23 21:15:33.953958
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:15:35.957104
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto

# Generated at 2022-06-23 21:15:40.974814
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    seed = '22fe2a2a-a8d8-40f9-9e87-c3f3df0c8e0c'
    provider = Cryptographic(seed=seed)
    result = provider.uuid()
    assert result != seed

# Generated at 2022-06-23 21:15:42.377636
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cp = Cryptographic()
    assert cp.hash() !=cp.hash()

# Generated at 2022-06-23 21:15:44.852222
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    with Cryptographic() as cr:
        result = cr.mnemonic_phrase()
    print(result)
    assert isinstance(result, str)
    assert len(result.split()) == 12


# Generated at 2022-06-23 21:15:46.181988
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    x = Cryptographic('en')
    x.mnemonic_phrase()

# Generated at 2022-06-23 21:15:47.839663
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Unit test for constructor of class Cryptographic."""
    prov = Cryptographic()
    assert prov
    prov.hash()

# Generated at 2022-06-23 21:15:51.491864
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    '''
    Test Cryptographic token_bytes method
    '''
    token = Cryptographic().token_bytes(entropy = 50)
    print("The token is {}".format(token))
    print("The type of the token is {}".format(str(type(token))))
    assert isinstance(token,bytes)



# Generated at 2022-06-23 21:15:55.891407
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print("............................Test Unit for method token_urlsafe of class Cryptographic")
    print("Input:")
    print("Entropy: 32")
    print("Expected Output: String")
    print("Actual Output:", Cryptographic.token_urlsafe())

# Generated at 2022-06-23 21:15:56.855253
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test class"""
    assert Cryptographic.uuid()

# Generated at 2022-06-23 21:16:05.944862
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    # Default entropy
    assert len(crypto.token_hex()) == 64
    assert len(crypto.token_hex(6)) == 12
    assert len(crypto.token_hex(16)) == 32
    assert len(crypto.token_hex(32)) == 64
    assert len(crypto.token_hex(64)) == 128
    # Entropy is None
    assert len(crypto.token_hex(None)) == 64
    # Invalid entropy
    assert crypto.token_hex(0) == ''
    assert len(crypto.token_hex(-256)) == 64
    # Seed is None
    crypto = Cryptographic(seed=None)
    assert len(crypto.token_hex()) == 64
    assert len(crypto.token_hex(6)) == 12

# Generated at 2022-06-23 21:16:07.007852
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic.token_urlsafe())

# Generated at 2022-06-23 21:16:14.556378
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase of class Cryptographic
    Returns:
        bool: Test result
    """
    def run(seed=None):
        if seed is not None:
            return str(Cryptographic(seed=seed).mnemonic_phrase())
        else:
            return str(Cryptographic().mnemonic_phrase())
    tests = ['monograph','chaff','bulkhead','syndicate','infirm','frenetic',
             'reflection','automaton','waxy','voyager']
    return any((run(seed=x) == y for x,y in zip(tests, tests)))

# Generated at 2022-06-23 21:16:16.633846
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():

    cr = Cryptographic()
    url_safe_token = cr.token_urlsafe()

    assert isinstance(url_safe_token, str)


# Generated at 2022-06-23 21:16:18.002348
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    result = provider.token_bytes()
    assert result is not None

# Generated at 2022-06-23 21:16:23.628608
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    
    # Test 1
    seed = 1
    entropy = 4
    cr = Cryptographic(seed=seed)
    assert cr.token_urlsafe(entropy) == "8VuD"

    # Test 2
    seed = 1
    entropy = 32
    cr = Cryptographic(seed=seed)
    assert cr.token_urlsafe(entropy) == "8VuDk-u5o0DPkd5v5geV1WY5TwD7VLyXo0vAUKA_"

    # Test 3
    seed = 1
    entropy = 50
    cr = Cryptographic(seed=seed)

# Generated at 2022-06-23 21:16:26.915083
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid1 = Cryptographic().uuid()
    uuid2 = Cryptographic().uuid()
    assert len(uuid1) == 36
    assert len(uuid2) == 36
    assert uuid1 != uuid2


# Generated at 2022-06-23 21:16:29.082762
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    for _ in range(1000):
        assert type(c.token_hex()) == str, c.token_hex()

# Generated at 2022-06-23 21:16:37.468973
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit-test Cryptographic class method mnemonic_phrase."""
    seed = 666
    crypto = Cryptographic(seed=seed)
    # if this test fails, method mnemonic_phrase from class Cryptographic
    # changed without updating checksum
    assert crypto.mnemonic_phrase() == "weaken slip assign"
    crypto.random.seed(seed)
    assert crypto.mnemonic_phrase() == "weaken slip assign"
    assert crypto.mnemonic_phrase() == "weaken slip assign"
    assert crypto.mnemonic_phrase() == "weaken slip assign"
    assert crypto.mnemonic_phrase() == "weaken slip assign"
    crypto.random.seed(seed)
    assert crypto.mnemonic_phrase() == "weaken slip assign"
    # assert that separator is always the same and equal to " "

# Generated at 2022-06-23 21:16:39.768283
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(40)) == 40



# Generated at 2022-06-23 21:16:46.779076
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    cr = Cryptographic(seed=12345)
    s = cr.hash(Algorithm.SHA1)
    assert isinstance(s, str)
    assert len(s) == 40
    assert s == 'a7b6c51411ec39dc0cd0c47591d7e77665c3d113'



# Generated at 2022-06-23 21:16:49.221090
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cry = Cryptographic()
    assert cry.mnemonic_phrase(length=5) == 'prevent away juice policy comfort'
# End test

# Generated at 2022-06-23 21:16:54.033541
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic"""
    x = Cryptographic()
    assert(isinstance(x.hash(), str))
    assert(isinstance(x.hash(x.enums.Algorithm.MD5), str))
    assert(isinstance(x.hash(x.enums.Algorithm.SHA256), str))


# Generated at 2022-06-23 21:16:55.893276
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    Cryptographic.token_urlsafe()
    assert crypto.token_urlsafe() == '16 bytes'

# Generated at 2022-06-23 21:16:57.687387
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(4) == '4b4c4d4e'

# Generated at 2022-06-23 21:16:59.743067
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(Cryptographic.token_hex())

# Below code is for test only.
if __name__ == '__main__':
    test_Cryptographic_token_hex()

# Generated at 2022-06-23 21:17:02.727586
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex(): 
    c = Cryptographic()
    assert c.token_hex() == "8dbd2aad3cecc3a98e3b47e0f268c976"
    assert len(c.token_hex(20)) == 40


# Generated at 2022-06-23 21:17:05.414705
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    crypto = Cryptographic()
    mnemonic_phrase_res = crypto.mnemonic_phrase()
    assert isinstance(mnemonic_phrase_res, str)
    assert len(mnemonic_phrase_res.split(' ')) == 12


# Generated at 2022-06-23 21:17:07.745583
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64
    assert type(Cryptographic().token_hex()) is str

# Generated at 2022-06-23 21:17:11.924544
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    for i in range(10):
        c.reset_seed()
        val = c.uuid()
        assert isinstance(val, str)


# Generated at 2022-06-23 21:17:20.329160
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Test 1 - Default argument values
    from mimesis import Cryptographic
    from mimesis.enums import Algorithm

    cryptographic = Cryptographic()
    # cryptographic.seed('Mimesis')

    phrase = cryptographic.mnemonic_phrase()
    print(phrase)
    assert (
        phrase == 'bend top sleep science cluster coffee payment chief ten stay'
    )

    # Test 2 - Setting separator
    from mimesis import Cryptographic
    from mimesis.enums import Algorithm

    cryptographic = Cryptographic()
    # cryptographic.seed('Mimesis')

    phrase = cryptographic.mnemonic_phrase(separator=', ')
    print(phrase)

# Generated at 2022-06-23 21:17:23.630267
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj = Cryptographic()
    assert isinstance(obj.token_bytes(), bytes)
    assert len(obj.token_bytes(entropy=32)) == 32


# Generated at 2022-06-23 21:17:26.521919
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method Cryptographic.uuid."""
    items = [Cryptographic().uuid() for _ in range(10)]
    assert items
    assert len(items[0]) == 36


# Generated at 2022-06-23 21:17:28.382814
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic"""
    assert 32 == len(Cryptographic.token_bytes())

# Generated at 2022-06-23 21:17:33.063524
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    full = []
    for _ in range(128):
        item = Cryptographic().token_urlsafe()
        assert len(item) == 43
        full.append(item)
    assert len(set(full)) == len(full)  # All token unique


# Generated at 2022-06-23 21:17:36.175471
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Initialize Cryptographic object
    instance = Cryptographic()
    assert instance.__class__.__name__ == "Cryptographic"
    assert str(instance) == "<Cryptographic>"


# Generated at 2022-06-23 21:17:37.962501
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    C = Cryptographic()
    r = C.hash(Algorithm.SHA1)
    print(r)

# Generated at 2022-06-23 21:17:40.939178
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Assert that object has correct type
    assert isinstance(Cryptographic.uuid(), str)
    # Assert that the length of object is correct
    assert len(Cryptographic.uuid()) == 36


# Generated at 2022-06-23 21:17:42.489633
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe(256)) == 360

# Generated at 2022-06-23 21:17:44.958402
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print(Cryptographic().token_bytes())
    print(Cryptographic().token_bytes(entropy=16))


# Generated at 2022-06-23 21:17:48.583512
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    # Case when we need string UUID
    assert isinstance(Cryptographic.uuid(), str)

    # Case when we need UUID object
    assert isinstance(Cryptographic.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:17:51.310154
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Arrange
    c = Cryptographic()

    # Act
    result = c.token_urlsafe()

    # Assert
    assert isinstance(result, str)

# Generated at 2022-06-23 21:18:02.178282
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cryptographic = Cryptographic(seed=47)
    assert cryptographic.mnemonic_phrase(length=12, separator=' ') == \
           'upon hair eight agree cactus hazard open novel rude'
    assert cryptographic.uuid() == 'dd31e012-6c83-4a5c-86bf-00c5f5a5da5e'
    assert cryptographic.hash(algorithm=Algorithm.SHA512) == 'd3b3a9a9a19667a57deaa0822e7f13b41c8b7e8c66f0d7c84c947c2b2a0f580f7d13da08cb20c7b8f47c0d7b50f4974c9b2a5814c2bf0ed2dee1c52b7a878d3c'

# Generated at 2022-06-23 21:18:04.188855
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert isinstance(Cryptographic.token_urlsafe(entropy=32), str)


# Generated at 2022-06-23 21:18:05.242547
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cryptographic()


# Generated at 2022-06-23 21:18:07.787297
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash()
    assert c.hash(algorithm=Algorithm.MD5)

# Generated at 2022-06-23 21:18:10.534190
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test class Cryptographic method token_urlsafe."""
    token = Cryptographic.token_urlsafe()
    assert isinstance(token, str)
    assert len(token) == 43


# Generated at 2022-06-23 21:18:15.101525
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    provider = Cryptographic('en')
    assert provider.hash()
    assert provider.hash(algorithm=Algorithm.SHA1)
    assert provider.hash(algorithm=Algorithm.SHA256)
    assert provider.hash(algorithm=Algorithm.SHA512)
    assert provider.hash(algorithm=Algorithm.BLAKE2B)

# Generated at 2022-06-23 21:18:17.902165
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test for Cryptographic.

    This is a Unit Test for the class Cryptographic
    """
    obj = Cryptographic()
    assert type(obj) == Cryptographic


# Generated at 2022-06-23 21:18:20.865395
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    pwd = cr.hash()
    assert len(pwd) == 64
    #print(pwd)

# Generated at 2022-06-23 21:18:22.429446
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    print("Hash: ", crypto.hash())

# Generated at 2022-06-23 21:18:24.755362
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Print a random hex string."""
    c = Cryptographic()
    print(c.token_hex())


# Generated at 2022-06-23 21:18:25.769837
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    return c

# Generated at 2022-06-23 21:18:29.519776
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    print(Cryptographic().token_urlsafe(entropy=5))


# Generated at 2022-06-23 21:18:30.536027
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:18:31.906565
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    result = obj.uuid()
    assert result is not None

# Generated at 2022-06-23 21:18:41.020528
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic(seed=11)
    provider.uuid()
    provider.uuid()
    provider.uuid()
    provider.uuid()
    provider.uuid()
    assert provider.uuid() == 'd21de18a-7e79-4310-9c3e-91960f6e3cd6'
    assert provider.uuid() == 'dd7e0ebe-a01f-4848-9a27-bc335935bc64'
    assert provider.uuid() == '5b5e5c5d-ba5c-4a86-8bcf-b7f0b3aa3e39'

# Generated at 2022-06-23 21:18:44.029341
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic(seed=1)
    assert c.token_hex(entropy=32) == 'f6ae8e4a15a68bcb86080a3a0bf8c7b3'

# Generated at 2022-06-23 21:18:52.996317
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  assert Cryptographic.token_hex(entropy=1) == "62"
  assert Cryptographic.token_hex(entropy=2) == "c66d"
  assert Cryptographic.token_hex(entropy=3) == "98fa3"
  assert Cryptographic.token_hex(entropy=4) == "c8a299"
  assert Cryptographic.token_hex(entropy=5) == "1e6b2ff"
  assert Cryptographic.token_hex(entropy=6) == "4e4d7f81"


# Generated at 2022-06-23 21:18:55.303528
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA224) is not None
    assert len(Cryptographic().hash(Algorithm.SHA224)) == 56


# Generated at 2022-06-23 21:18:58.603713
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print(Cryptographic().mnemonic_phrase())
    print(Cryptographic().mnemonic_phrase(length=3))
    print(Cryptographic().mnemonic_phrase(separator=","))
    print(Cryptographic().mnemonic_phrase(length=3, separator=","))


# Generated at 2022-06-23 21:19:00.587721
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    data = Cryptographic().token_urlsafe()
    assert data is not None
    assert isinstance(data, str)
