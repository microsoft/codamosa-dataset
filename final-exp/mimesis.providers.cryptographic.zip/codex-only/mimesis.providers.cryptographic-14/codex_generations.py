

# Generated at 2022-06-23 21:08:59.644073
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32


# Generated at 2022-06-23 21:09:03.173060
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic(seed=12345)
    hash_value = cryptographic.hash()
    assert hash_value == 'd5a1b76a5c086b9d3b3e3ff7ad2c2f78'


# Generated at 2022-06-23 21:09:07.334414
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import datetime
    c = Cryptographic()
    # If this test fails, please rerun. 
    # Randomness obtained from the first run may have been compromised by the time of the second run.
    output = c.hash()
    assert(output is not None)
    assert(isinstance(output, str))
    assert(len(output) in range(0,100))


# Generated at 2022-06-23 21:09:11.841173
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(6) == 'a5e5e5f5f5c5c5d5d5'
    assert c.token_hex(6) == '8787878787878787878787878787'



# Generated at 2022-06-23 21:09:14.937968
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():

    tb = Cryptographic().token_bytes()
    assert isinstance(tb, bytes)
    assert len(tb) != 0



# Generated at 2022-06-23 21:09:19.482634
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method uuid of class Cryptographic."""
    seed = 42
    expected_uuid = '8f4761b0-34f2-4a2d-8f5a-2f96332a891a'
    cryptographic = Cryptographic(seed=seed)
    uuid_result = cryptographic.uuid()
    assert uuid_result == expected_uuid


# Generated at 2022-06-23 21:09:30.325883
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.uuid() == '7c76dfd4-4a4f-44b3-a3a1-e0fe7d0aba92'
    assert crypto.hash(Algorithm.SHA256) == '862a0e0a-9c1d-46ea-af0f-b6f0d6c7a8a2'

# Generated at 2022-06-23 21:09:32.115591
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
	method_result = Cryptographic.token_hex()
	assert isinstance(method_result, str)


# Generated at 2022-06-23 21:09:36.159242
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonic_phrase = Cryptographic('en').mnemonic_phrase(5)
    # print(key)
    assert len(mnemonic_phrase.split(' ')) == 5
    assert len(mnemonic_phrase) == len(' '.join(mnemonic_phrase.split(' ')))

# Generated at 2022-06-23 21:09:37.466479
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():

    crypto = Cryptographic()
    result = crypto.token_hex()
    assert result is not None
    assert len(result) == 64


# Generated at 2022-06-23 21:09:43.319326
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    CRYPTO = Cryptographic()
    sep = "-"
    words = CRYPTO.mnemonic_phrase(length=6, separator=sep)
    print(words)
    words = CRYPTO.mnemonic_phrase(length=6, separator=sep)
    print(words)
    words = CRYPTO.mnemonic_phrase(length=6, separator=sep)
    print(words)
    words = CRYPTO.mnemonic_phrase(length=6, separator=sep)
    print(words)
    words = CRYPTO.mnemonic_phrase(length=6, separator=sep)
    print(words) 
    words = CRYPTO.mnemonic_phrase(length=6, separator=sep)
    print(words)
    words = CRYPTO.mnemonic

# Generated at 2022-06-23 21:09:47.819323
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    import mimesis
    test_data = {}
    c = Cryptographic('ru')
    test_data['passphrase'] = c.mnemonic_phrase(12)

    assert test_data['passphrase'] != None # Assert function mnemonic_phrase returned not None


# Generated at 2022-06-23 21:09:49.946652
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic."""
    result = Cryptographic().uuid()
    assert len(result) == 36


# Generated at 2022-06-23 21:09:52.207247
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """ Unit test for method uuid of class Cryptographic """
    assert (isinstance(Cryptographic().uuid(), UUID))


# Generated at 2022-06-23 21:09:54.379916
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic.uuid()) == 36
    assert len(Cryptographic.uuid(True)) == 4


# Generated at 2022-06-23 21:09:55.873136
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    x = Cryptographic()
    obs = x.token_hex(entropy=32)
    assert type(obs) == str

# Generated at 2022-06-23 21:10:00.056989
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    token = crypto.token_urlsafe(5)
    print(token)
    hash = crypto.hash(Algorithm.SHA256)
    print(hash)
    uuid = crypto.uuid(True)
    print(uuid)
    phrase = crypto.mnemonic_phrase(5)
    print(phrase)


# Generated at 2022-06-23 21:10:02.315066
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes(): 
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(20)) == 40


# Generated at 2022-06-23 21:10:12.749221
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c != None
    assert c.uuid() != c.uuid()
    assert c.uuid() != None
    assert c.uuid() != c.token_bytes()
    assert c.uuid() != c.token_hex()
    assert c.uuid() != c.token_urlsafe()
    assert c.uuid() != c.mnemonic_phrase()
    assert c.token_bytes() != c.token_hex()
    assert c.token_bytes() != c.token_urlsafe()
    assert c.token_bytes() != c.mnemonic_phrase()
    assert c.token_hex() != c.token_urlsafe()
    assert c.token_hex() != c.mnemonic_phrase()
    assert c.token_urlsafe() != c.mnemonic_phrase

# Generated at 2022-06-23 21:10:14.480216
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    assert len(obj.uuid()) == 36

# Test case for method token_urlsafe of class Cryptographic

# Generated at 2022-06-23 21:10:26.179366
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    doctest1 = Cryptographic(seed=42)
    doctest2 = Cryptographic(seed=42)
    doctest3 = Cryptographic(seed=42)
    doctest4 = Cryptographic(seed=42)
    doctest5 = Cryptographic(seed="42")
    doctest6 = Cryptographic(seed="42")
    doctest7 = Cryptographic(seed="42")
    doctest8 = Cryptographic(seed="42")
    doctest9 = Cryptographic(seed="42")
    doctest10 = Cryptographic(seed=42)
    doctest11 = Cryptographic(seed=42)
    doctest12 = Cryptographic(seed=42)
    doctest13 = Cryptographic(seed=42)
    doctest14 = Cryptographic(seed=42)
    doctest15 = Cryptographic(seed=42)
    doctest16

# Generated at 2022-06-23 21:10:36.146017
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    cryptographic = Cryptographic()
    mnemonic_phrase = cryptographic.mnemonic_phrase()
    assert mnemonic_phrase != "", "Failed to generate mnemonic_phrase"
    # assert cryptographic.hash(Algorithm(None)) != "", "Failed to generate hash"
    # assert cryptographic.hash(Algorithm.SHA1) != "", "Failed to generate hash"
    # assert cryptographic.hash(Algorithm.SHA256) != "", "Failed to generate hash"
    # assert cryptographic.hash(Algorithm.SHA512) != "", "Failed to generate hash"
    # assert cryptographic.token_bytes() != b'', "Failed to generate token_bytes"
    # assert cryptographic.token_hex() !=

# Generated at 2022-06-23 21:10:38.812380
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider, Cryptographic)

# Unit test of method Cryptographic.uuid

# Generated at 2022-06-23 21:10:40.778860
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonic_phrase = Cryptographic().mnemonic_phrase()
    assert isinstance(mnemonic_phrase, str)


# Generated at 2022-06-23 21:10:42.707498
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic('en')
    assert crypto.mnemonic_phrase() != ''

# Generated at 2022-06-23 21:10:44.759119
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    obj = Cryptographic()
    number = 10
    phrase = obj.mnemonic_phrase(number)
    assert len(phrase.split(' ')) == number

# Generated at 2022-06-23 21:10:46.885959
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert(len(Cryptographic().token_hex()) == 64)

# Generated at 2022-06-23 21:10:52.761539
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # type: () -> None
    """Test for Cryptographic.hash"""
    # data = {'algorithm': 'sha3_512', 'seed': 'test'}
    # result = '9ab4e6b2a2c8f79ed3f3d3a3de536e4e69a4bc9a9bab6d537b6ce8c6f28169df'
    # method = Cryptographic(**data).hash()
    # assert method == result
    pass


# Generated at 2022-06-23 21:10:56.942620
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print("test_Cryptographic_token_bytes()")
    # Test length of token
    token = Cryptographic.token_bytes()
    print(len(token))
    assert(len(token) == 32)
    # Test binary format of token
    token = Cryptographic.token_bytes()
    print(type(token))
    assert(type(token) == bytes)


# Generated at 2022-06-23 21:11:00.953720
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = Cryptographic()
    
    hash = None
    try:
        hash = data.hash()
    except:
        hash = 'Exception raised'
        return hash

    print(hash) # print on screen
    return hash


# Generated at 2022-06-23 21:11:10.193031
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.providers.enums import Algorithm
    crypto = Cryptographic(seed='test')
    assert crypto.hash(Algorithm.MD5) == 'e6a39bc6bc8b8fc65f0cacf5d7ff4913'
    assert crypto.uuid() == '1752d4dd-de8f-4977-a42a-bdace698eb35'
    assert crypto.mnemonic_phrase(3, '-') == 'oversupply-amsterdam-understand'

# Generated at 2022-06-23 21:11:12.034619
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    PROVIDER = Cryptographic()
    value = PROVIDER.hash(Algorithm.MD5)
    assert len(value) == 32

# Generated at 2022-06-23 21:11:14.360605
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    maker = Cryptographic()
    assert maker.hash() == '00000000000000000000000000000000'


# Generated at 2022-06-23 21:11:16.926885
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    ans = cr.mnemonic_phrase()
    assert type(ans) == type('a')
    assert len(ans.split()) == 12



# Generated at 2022-06-23 21:11:27.880974
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.enums import Locale
    c = Cryptographic(Locale.EN)
    assert isinstance(c.hash(Algorithm.MD5), str)
    assert len(c.hash(Algorithm.MD5)) == 32
    assert isinstance(c.hash(Algorithm.SHA1), str)
    assert len(c.hash(Algorithm.SHA1)) == 40
    assert isinstance(c.hash(Algorithm.SHA224), str)
    assert len(c.hash(Algorithm.SHA224)) == 56
    assert isinstance(c.hash(Algorithm.SHA256), str)
    assert len(c.hash(Algorithm.SHA256)) == 64

# Generated at 2022-06-23 21:11:28.855898
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert isinstance(crypto.uuid(), str)


# Generated at 2022-06-23 21:11:30.712928
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    result = provider.mnemonic_phrase()
    assert result and isinstance(result, str)

    result = provider.mnemonic_phrase(separator='-')
    assert result and isinstance(result, str)
    assert '-' in result


# Generated at 2022-06-23 21:11:32.436162
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Assign
    instance = Cryptographic()

    # Act
    result = instance.hash()

    # Assert
    assert result



# Generated at 2022-06-23 21:11:34.087781
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    x = Cryptographic().token_bytes()
    assert len(x) == 32


# Generated at 2022-06-23 21:11:37.573304
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    Crypto = Cryptographic()
    assert isinstance(Crypto.token_hex(), str)
    assert len(Crypto.token_hex(32)) == 64
    assert len(Crypto.token_hex(entropy=64)) == 128


# Generated at 2022-06-23 21:11:39.479485
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(entropy=20)
    assert len(str(c)) > 20

# Generated at 2022-06-23 21:11:49.234621
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import random
    import mimesis.enums
    c = Cryptographic(seed=random.randint(0, 100))
    # assert c.hash() == "dbbe0fb1d8f41a64eafb64dcf90d5c93173e1c27831419e31df5e5fd00c59326"
    assert c.hash(mimesis.enums.Algorithm.BLAKE2B) == "ac0c57b78a6b64e884040d9e306a930327beabb0e8072f73a370b8c17e87b6a9"


# Generated at 2022-06-23 21:11:50.910659
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    result = Cryptographic().mnemonic_phrase()
    assert len(result.split(' ')) == 12

# Generated at 2022-06-23 21:11:54.696582
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Case 1: Test a "default" value
    assert len(Cryptographic.token_bytes()) == 32

    # Case 2: Test a specific value
    assert len(Cryptographic.token_bytes(16)) == 32

    # Case 3: Test an absurd value
    assert len(Cryptographic.token_bytes(4096)) == 8192


# Generated at 2022-06-23 21:11:57.825384
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cryp = Cryptographic()
    uuid_ = cryp.uuid()

    assert type(uuid_) == str
    assert len(uuid_) == 36
    assert uuid_ == 'b1be3d6c-6080-4ad5-9d5d-e6df4b6cdab4'


# Generated at 2022-06-23 21:12:05.533793
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm

    crypt = Cryptographic()

    assert len(crypt.token_hex()) == 64
    assert len(crypt.token_hex(50)) == 100

# Generated at 2022-06-23 21:12:06.479551
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32

# Generated at 2022-06-23 21:12:07.941251
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    print(crypto.hash())

test_Cryptographic()

# Generated at 2022-06-23 21:12:17.867445
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # unit test for constructor of class Cryptographic
    # Constructor
    crypto = Cryptographic()
    # to_dict()
    data = crypto.raw()
    # repr()
    repr(crypto)
    # __repr__()
    crypto.__repr__()
    # str()
    str(crypto)
    # __str__()
    crypto.__str__()
    # verify hashes
    keys = data['cryptographic'].keys()
    for key in keys:
        assert isinstance(data['cryptographic'][key](), str)
    for i in range(0, 10):
        assert isinstance(crypto.hash(), str)
    # verify uuid
    assert isinstance(crypto.uuid(), str)
    assert isinstance(crypto.uuid(as_object=True), UUID)

# Generated at 2022-06-23 21:12:21.427933
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test Cryptographic.token_urlsafe() method."""
    c = Cryptographic()
    result = c.token_urlsafe()
    assert result is not None


# Generated at 2022-06-23 21:12:23.732530
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    obj = Cryptographic()
    x = obj.token_hex()
    assert x is not None


# Generated at 2022-06-23 21:12:27.157538
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    x = Algorithm.MD5.value
    y = cr.hash(Algorithm.MD5)
    print(x,y)
    assert y != None
    assert len(y) == 32


# Generated at 2022-06-23 21:12:33.566248
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import string
    import random
    from mimesis.providers.cryptographic import Cryptographic

    c = Cryptographic('en')
    allchar = string.ascii_letters + string.digits + "-_"
    allchar = list(allchar)
    random.shuffle(allchar)
    allchar = ''.join(allchar)

    for i in range(0, 5):
        token = c.token_urlsafe(random.randint(10, 100))
        assert not all(char not in allchar for char in token)

# Generated at 2022-06-23 21:12:41.678594
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():

    # Test 1 Case: length = 12, separator = None
    assert Cryptographic().mnemonic_phrase(12, None) == "tailor educate door song culture certain peanut crisp neither face author spend"

    # Test 2 Case: length = 24, separator = None
    assert Cryptographic().mnemonic_phrase(24, None) == "tailor educate door song culture certain peanut crisp neither face author spend family economy rebel drag insist kite joy plot awkward initial"

    # Test 3 Case: length = 12, separator = ' '
    assert Cryptographic().mnemonic_phrase(12, ' ') == "tailor educate door song culture certain peanut crisp neither face author spend"

    # Test 4 Case: length = 12, separator = '-'

# Generated at 2022-06-23 21:12:44.915450
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    c.hash(Algorithm.MD5)
    c.hash(Algorithm.SHA256)
    c.hash(Algorithm.SHA384)
    c.hash(Algorithm.SHA512)
    c.hash(Algorithm.SHA224)
    c.hash(Algorithm.SHA1)


# Generated at 2022-06-23 21:12:48.104744
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64
    assert len(Cryptographic().token_hex(128)) == 256
    assert isinstance(Cryptographic().token_hex(), str)


# Generated at 2022-06-23 21:12:49.931494
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    assert isinstance(obj.uuid(), str)


# Generated at 2022-06-23 21:12:50.632039
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert provider is not None

# Generated at 2022-06-23 21:12:51.789607
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert provider.__words



# Generated at 2022-06-23 21:12:57.190963
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    crypto = Cryptographic('en')
    print(crypto.hash(Algorithm.SHA1))
    print(crypto.hash(Algorithm.SHA224))
    print(crypto.hash(Algorithm.SHA256))
    print(crypto.hash(Algorithm.SHA384))
    print(crypto.hash(Algorithm.SHA512))
    print(crypto.hash(Algorithm.MD5))


# Generated at 2022-06-23 21:13:00.098508
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Arguments for constructor
    args = ('Seed',)
    # Keyword arguments for constructor
    kwargs = {'seed': 'Seed'}
    # Call of method
    obj = Cryptographic(*args, **kwargs)
    # And check the result
    assert obj is not None

# Generated at 2022-06-23 21:13:08.631815
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) == '570e6fa0b0186bcafbc41de81689e2b9'
    assert c.hash(Algorithm.SHA1) == '96bacd13b10a7a8b0dfb7d1b9a30b7beb8a2b420'
    assert c.hash(Algorithm.SHA224) == '9ca19d425d47f7fe8f449993b45785f398b11d1351ec7e86baf5d72ba'

# Generated at 2022-06-23 21:13:11.414042
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    expected = "tomorrow bayard quick golden iowa cindy that river ohio"
    assert str(Cryptographic().mnemonic_phrase()) == expected

# Generated at 2022-06-23 21:13:16.458068
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """
    Test method token_bytes of class Cryptographic.
    """
    # Test 1
    bs = Cryptographic.token_bytes()
    assert type(bs) == bytes

    # Test 2
    bs = Cryptographic.token_bytes(entropy = 4)
    assert type(bs) == bytes


# Generated at 2022-06-23 21:13:18.124713
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token = crypto.token_bytes()
    assert type(token) == bytes



# Generated at 2022-06-23 21:13:19.759213
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    C = Cryptographic()
    uid = C.uuid()
    assert len(uid) == 36

# Generated at 2022-06-23 21:13:24.062214
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test token_urlsafe method."""
    import re
    u = Cryptographic().token_urlsafe()
    print("TOKEN URLSAFE: " + u)
    assert isinstance(u, str)
    assert re.match("^[a-zA-Z0-9_-]{0,22}$", u)

# Generated at 2022-06-23 21:13:25.795220
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto is not None

# Generated at 2022-06-23 21:13:27.026656
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  c = Cryptographic(seed=10)
  c.hash()

# Generated at 2022-06-23 21:13:28.426333
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    print(c.mnemonic_phrase())


# Generated at 2022-06-23 21:13:32.495504
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cryptographic = Cryptographic()
    result = cryptographic.token_bytes(32)
    first = result[0]
    second = result[1]
    assert (first * second) + first == first * (second + 1)
    

# Generated at 2022-06-23 21:13:35.966139
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    alg = Algorithm.SHA256
    cr = Cryptographic()
    r = cr.hash(algorithm=alg)
    assert isinstance(r, str)
    assert len(r) == 64


# Generated at 2022-06-23 21:13:38.015797
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash = Cryptographic.hash()
    len(hash)
    assert hash


# unit test for method uuid of class Cryptographic

# Generated at 2022-06-23 21:13:39.208106
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Testing Cryptographic.hash()"""
    assert Cryptographic().hash()

# Generated at 2022-06-23 21:13:40.098760
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass

# Generated at 2022-06-23 21:13:44.222289
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic(seed=123)
    assert provider.hash() == '6ddb0a8be2d48a35e0c3abf86cd6c63d6e1b9f9d634f05c749b6fe52caa7f510'


# Generated at 2022-06-23 21:13:45.087012
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert len(c.token_urlsafe()) == 22

# Generated at 2022-06-23 21:13:45.904237
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert provider.mnemonic_phrase() is not ""

# Generated at 2022-06-23 21:13:51.696727
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert crypto.uuid() is not None
    assert len(str(crypto.uuid())) == 36
    assert len(str(crypto.uuid(as_object=False))) == 36
    assert len(str(crypto.uuid(as_object=True))) == 36
    assert type(crypto.uuid(as_object=False)) is str
    assert type(crypto.uuid(as_object=True)) is UUID


# Generated at 2022-06-23 21:13:53.061457
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert c.token_bytes()
    assert c.token_bytes(100)

# Generated at 2022-06-23 21:13:54.973614
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    _cg = Cryptographic()
    print("\n# Unit test for method token_urlsafe of class Cryptographic")
    print("token_urlsafe =", _cg.token_urlsafe())

# Generated at 2022-06-23 21:13:57.561158
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cr = Cryptographic()
    url_safe_token = cr.token_urlsafe(32)
    assert len(url_safe_token) == 44
    assert url_safe_token != cr.token_urlsafe(32)

# Generated at 2022-06-23 21:13:59.998881
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  Secret = Cryptographic()
  assert len(Cryptographic.token_hex(20)) == 40
  #assert Secret.token_hex(size=20) == Cryptographic.token_hex(size=20)

# Generated at 2022-06-23 21:14:04.427572
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    # Set tests values
    tests_values = [  # type: list
        # Each tuple contains a testing value and its expected result
        ("md5", 32),
        ("sha1", 40),
        ("sha224", 56),
        ("sha256", 64),
        ("sha384", 96),
        ("sha512", 128),
    ]
    # Check if all values are correct
    for test in tests_values:
        _, value = test
        assert len(crypto.hash(Algorithm[test[0]])) == value

# Generated at 2022-06-23 21:14:07.207291
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initialization of a provider
    provider = Cryptographic()
    # Generate a SHA-512 hash
    my_hash = provider.hash(Algorithm.SHA512)
    assert len(my_hash) == 128



# Generated at 2022-06-23 21:14:15.512527
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print("\n Test of Cryptographic : \n")
    a = Cryptographic()
    print(" UUID of the given string : " ,a.uuid())
    print(" Hash of the given string : ", a.hash())
    print(" Token in bytes of the given string : ",a.token_bytes())
    print(" Token in hex of the given string :" ,a.token_hex())
    print(" Token Url Safe of the given string : ", a.token_urlsafe())
    print(" Mnemonic Phrase of the given string : " , a.mnemonic_phrase())
    print("\n")

#test_Cryptographic()

# Generated at 2022-06-23 21:14:17.404417
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert Cryptographic().token_bytes() == Cryptographic().token_bytes()

# Generated at 2022-06-23 21:14:20.053781
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    a = Cryptographic()
    phrase = a.mnemonic_phrase()
    assert isinstance(phrase, str)


# Generated at 2022-06-23 21:14:22.637511
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
	for i in range(1, 100):
		print(Cryptographic().token_urlsafe())

# Generated at 2022-06-23 21:14:24.086267
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    i = 0
    while i < 10:
        obj.hash()
        i = i + 1
    return True

# Generated at 2022-06-23 21:14:25.953599
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    for _ in range(10):
        assert len(provider.hash(Algorithm.MD5)) == 32


# Generated at 2022-06-23 21:14:28.498927
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cryptographic = Cryptographic()
    token_bytes = cryptographic.token_bytes()
    assert isinstance(token_bytes, bytes)


# Generated at 2022-06-23 21:14:30.716406
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a = Cryptographic().token_hex()
    b = Cryptographic().token_hex()
    assert a != b
    assert isinstance(a, str)
    assert isinstance(b, str)

# Generated at 2022-06-23 21:14:32.175903
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    x = Cryptographic()
    phrase = print(x.mnemonic_phrase())
    try:
        assert type(phrase) == str
        print("Test Passed")
    except AssertionError:
        print("Test Failed")



# Generated at 2022-06-23 21:14:34.625310
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Arrange
    cr = Cryptographic()

    # Act
    phrase = cr.mnemonic_phrase(length=50)

    # Assert
    assert isinstance(phrase, str)

# Generated at 2022-06-23 21:14:37.072124
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    constructor = Cryptographic()
    assert constructor.__class__.__name__ == 'Cryptographic'



# Generated at 2022-06-23 21:14:41.366003
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import re
    token = Cryptographic().token_urlsafe(4)
    assert type(token) is str
    assert len(token) == 8
    assert re.match(r'^[A-Za-z0-9]*$', token) is not None

# Generated at 2022-06-23 21:14:43.269728
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    assert obj.provider == 'cryptographic'



# Generated at 2022-06-23 21:14:46.399966
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test method token_bytes of class Cryptographic."""

    from mimesis import Cryptographic

    c=Cryptographic()
    assert c.token_bytes(16)

# Generated at 2022-06-23 21:14:47.826889
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    result = crypto.token_hex()
    assert len(result) == 64


# Generated at 2022-06-23 21:14:49.258245
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), type(uuid4()))


# Generated at 2022-06-23 21:14:54.787336
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Arrange
    mnemonic_word= ('Cryptographic',)
    # Act
    mnemonic_word = Cryptographic().hash()
    # Assert
    assert('a895030c7f1e494f877b7e04b957d919dab5e5e40dc5efb4d8e7a23545ed1036' ==  mnemonic_word)


# Generated at 2022-06-23 21:14:56.743344
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
  assert Cryptographic().uuid() == "7c6ebf88-2607-42d8-8479-7c2d34b053a3"


# Generated at 2022-06-23 21:14:59.833602
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Get cryptografic provider
    cg = Cryptographic()

    # Check that the returned string is 32 characters long
    assert len(cg.token_urlsafe()) == 43

# Generated at 2022-06-23 21:15:06.202516
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic."""
    c1 = Cryptographic()
    c2 = Cryptographic(seed='test')

    c1.seed_random(c1.token_hex())
    c2.seed_random(c2.token_hex())
    c3 = Cryptographic(seed='test')

    assert c1.token_hex() == c2.token_hex()
    assert c2.token_hex() == c3.token_hex()

# Generated at 2022-06-23 21:15:08.289107
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cryptographic = Cryptographic()
    assert cryptographic.token_bytes()


# Generated at 2022-06-23 21:15:10.935307
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # for _ in range(10):
    #     print(Cryptographic().token_urlsafe(32))
    assert len(Cryptographic().token_urlsafe(32)) == 63
    assert isinstance(Cryptographic().token_urlsafe(32), str)


# Generated at 2022-06-23 21:15:16.091906
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=1)
    assert c.mnemonic_phrase() == "acdabf fecbcf afcdda cbcfdd bccdac ccccac bdcddb dcdacf ebbabd cbfbfb"
    assert c.mnemonic_phrase(length=3) == "cacfdd cccbdb cedfdb"


# Generated at 2022-06-23 21:15:21.105174
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    m = Cryptographic("en")
    a = m.token_urlsafe()
    b = m.token_urlsafe()
    assert a != b
    assert len(a) == len(b)
    assert type(a) == type(b)


# Generated at 2022-06-23 21:15:27.507660
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    ####
    # Test correct creation of uuid object
    uuid_obj = Cryptographic().uuid(as_object=True)
    assert str(uuid_obj).isalnum()
    assert isinstance(uuid_obj, UUID)

    ####
    # Test correct creation of uuid string
    uuid_str = Cryptographic().uuid()
    assert isinstance(uuid_str, str)
    assert str(uuid_str).isalnum()



# Generated at 2022-06-23 21:15:36.815461
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Test with set seed
    c = Cryptographic(seed=1)
    assert c.uuid() == '1dca8d19-e3f0-4c37-a32d-9d7a35b0e1a7'
    assert c.uuid() == '2b2c0a7a-a944-44b3-a3b3-7c0ca8e438a7'
    assert c.uuid() == 'f1d48ed1-19f6-4c8c-b12d-c1ecdd650187'
    assert c.uuid() == '72b5c5b5-f34d-4e20-aa3a-3de7a9d510f9'

# Generated at 2022-06-23 21:15:41.555567
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test method token_bytes of class Cryptographic
    We use token_bytes() to generate random bytes.
    For example, we can use random bytes to create an encryption key."""
    cryptographic = Cryptographic()
    result = cryptographic.token_bytes()
    print(result)



# Generated at 2022-06-23 21:15:44.452381
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid(as_object=False) == '59f8ff7c-2591-44d9-80e9-05ec3498b1ae'


# Generated at 2022-06-23 21:15:47.228567
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    CRYP = Cryptographic('en')
    assert len(CRYP.mnemonic_phrase(10)) > 10
    assert CRYP.mnemonic_phrase(10).split() == CRYP.mnemonic_phrase(10).split()

# Generated at 2022-06-23 21:15:49.165855
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    i=0
    while i<5:
        print(Cryptographic.token_bytes())
        i+=1
        

# Generated at 2022-06-23 21:16:00.232954
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print('\nIn function "test_Cryptographic_token_bytes()"')

    import sys
    import datetime
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.tools import parse_seed

    # Create object "provider" of class "Cryptographic"
    provider = Cryptographic()

    # Flag for successful test
    test_success = True

    # Test #1
    print('\nTest #1')
    print('provider.token_bytes() =', provider.token_bytes())

    # Test #2
    print('\nTest #2')
    print('provider.token_bytes(entropy = 16) =', provider.token_bytes(entropy = 16))

    # Test #3
    print('\nTest #3')

# Generated at 2022-06-23 21:16:02.013439
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    res=c.token_urlsafe()
    assert(isinstance(res, str))

# Generated at 2022-06-23 21:16:03.391918
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    assert isinstance(cr, BaseProvider)


# Generated at 2022-06-23 21:16:05.278950
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    a = Cryptographic()
    assert len(a.token_bytes()) == 32


# Generated at 2022-06-23 21:16:09.156093
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto
    assert crypto.uuid()
    assert crypto.hash()
    assert crypto.hash(Algorithm.MD5)
    assert crypto.token_hex()
    assert crypto.token_urlsafe()
    assert crypto.mnemonic_phrase()

# Generated at 2022-06-23 21:16:10.665969
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    for i in range(1):
        print(Cryptographic().hash())

# Generated at 2022-06-23 21:16:12.120931
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash().isalnum()


# Generated at 2022-06-23 21:16:19.945736
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    from mimesis.pretty import pretty_constructor

    algo = Algorithm
    crypto = Cryptographic()

    print("\nUnit test for method mnemonic_phrase of class Cryptographic")
    print("*" * 20)
    print("Method: {}".format(pretty_constructor(crypto.mnemonic_phrase)))
    print("-" * 20)

    print("\nCase 1")
    print("Input: crypto.mnemonic_phrase()")
    print("Output: {}\n".format(crypto.mnemonic_phrase()))

    print("\nCase 2")
    print("Input: crypto.mnemonic_phrase(length = 18, separator = \", \")")

# Generated at 2022-06-23 21:16:30.177208
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crp = Cryptographic()
    # with default parameters
    mnemp = crp.mnemonic_phrase()
    print(mnemp)
    print('[%s]' % ' '.join(mnemp.split(' ')[0:5]))
    # with parameter length: 24
    mnemp = crp.mnemonic_phrase(length=24)
    print(mnemp)
    print('[%s]' % ' '.join(mnemp.split(' ')[0:5]))
    # with parameter separator: ','
    mnemp = crp.mnemonic_phrase(separator=',')
    print(mnemp)
    print('[%s]' % ' '.join(mnemp.split(',')[0:5]))
    # with parameter separator: ''
   

# Generated at 2022-06-23 21:16:32.520098
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    word = crypto.token_hex()
    assert isinstance(word, str)
    assert len(word) == 64


# Generated at 2022-06-23 21:16:33.435044
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cry = Cryptographic()
    cry.hash()

# Generated at 2022-06-23 21:16:36.352374
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == hashlib.md5(crypto.uuid().encode()).hexdigest()

# Generated at 2022-06-23 21:16:38.578688
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test for Cryptographic class."""
    c= Cryptographic()
    assert c.uuid()



# Generated at 2022-06-23 21:16:40.831398
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    p1 = Cryptographic()
    token_bytes = p1.token_bytes()
    assert token_bytes != p1.token_bytes()


# Generated at 2022-06-23 21:16:49.433429
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    from mimesis.exceptions import NonEnumerableError
    provider = Cryptographic(seed=42)
    ## This method is dangerous, so I will check some examples manually
    assert provider.token_urlsafe(entropy=8) == "OQoTak34"

    assert provider.token_urlsafe() == "znyMx6Ajw6b8hs6TQ-LbSU42dhgEjK8Y"


# Generated at 2022-06-23 21:16:52.199009
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print("Test token_bytes() of class Cryptographic")

    # generate a random number
    random_number = Cryptographic.token_bytes(10)
    print("Random Number (Bytes) :" , random_number)



# Generated at 2022-06-23 21:16:55.128302
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    mnemonic_phrase = crypto.mnemonic_phrase(length=12)
    assert isinstance(mnemonic_phrase, str)

# Generated at 2022-06-23 21:16:56.012634
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    s = Cryptographic()
    assert len(s.token_urlsafe()) == 44

# Generated at 2022-06-23 21:16:57.117655
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # check if token_hex is valid  
    assert len(Catalog().cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:17:00.390358
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    _uuid =  Cryptographic().uuid(as_object=True)
    if not isinstance(_uuid, UUID):
        raise AssertionError("UUID should be UUID type but "
                             "is {}".format(type(_uuid)))


# Generated at 2022-06-23 21:17:02.255869
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    test_object = Cryptographic()
    result = test_object.token_bytes()
    assert(isinstance(result, bytes))
    
    

# Generated at 2022-06-23 21:17:03.927031
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=100)
    print(c.mnemonic_phrase(length=12, separator='-'))


# Generated at 2022-06-23 21:17:09.695243
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  """Unit test for method token_urlsafe of class Cryptographic"""
  import random
  import time

  class Crypto(Cryptographic):
    def __init__(self, seed):
      self.seed = seed

  # create a random seed
  seed = random.randint(1, 1000000)
  print("seed = %d" % seed)
  # create a Cryptographic object
  crypto = Crypto(seed)
  # save the random token
  token = crypto.token_urlsafe()
  print("token = %s" % token)
  # wait
  time.sleep(1)
  # create another Cryptographic object (with the same seed)
  crypto2 = Crypto(seed)
  # create another random token
  token2 = crypto2.token_urlsafe()
  print("token2 = %s" % token2)
 

# Generated at 2022-06-23 21:17:12.635791
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    instance = Cryptographic()
    assert len(instance.token_hex(4)) == 8, 'wrong output for token_hex'



# Generated at 2022-06-23 21:17:18.325256
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm
    c = Cryptographic()
    word = c.token_hex()
    assert len(word) >= 64
    assert isinstance(word, str)
    assert word[0] in '0123456789abcdef'
    word2 = c.hash(Algorithm.SHA256)
    assert len(word2) == 64
    assert isinstance(word2, str)
    assert word2[0] in '0123456789abcdef'

# Generated at 2022-06-23 21:17:20.815448
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    myCryptographic = Cryptographic()
    print(type(myCryptographic.hash(Algorithm.SHA_512)))

# Generated at 2022-06-23 21:17:23.348260
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    print(crypto.token_urlsafe())


# Generated at 2022-06-23 21:17:24.668146
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()

    assert(type(cr.mnemonic_phrase()) == str)

# Generated at 2022-06-23 21:17:27.506084
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Arrange
    crypto = Cryptographic()
    # Act
    token = crypto.token_hex()
    # Assert
    assert token is not None
    assert len(token) == 64


# Generated at 2022-06-23 21:17:29.461585
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    new_Cryptographic = Cryptographic()
    assert new_Cryptographic is not None


# Generated at 2022-06-23 21:17:40.240544
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method Cryptographic.uuid"""
    crypto = Cryptographic()
    uuid = crypto.uuid()
    assert(isinstance(uuid, str))
    assert(len(uuid) == 36)
    assert(uuid[9] == '-')
    assert(uuid[14] == '-')
    assert(uuid[19] == '-')
    assert(uuid[24] == '-')
    assert(uuid[4] in '0123456789')
    assert(uuid[13] in '0123456789')
    assert(uuid[18] in '0123456789')
    assert(uuid[23] in '0123456789')
    assert(uuid[0] in '0123456789abcdef')

# Generated at 2022-06-23 21:17:41.237784
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:17:42.792126
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    assert crypto.token_urlsafe() is not None

# Generated at 2022-06-23 21:17:45.862468
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    this_hash = crypto.hash()
    assert len(this_hash) == 64 and all(c in '0123456789abcdef' for c in this_hash)


# Generated at 2022-06-23 21:17:48.182196
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.providers.cryptographic import Cryptographic
    A = Cryptographic()
    B = A.token_bytes()
    assert isinstance(B, bytes)

# Generated at 2022-06-23 21:17:50.079481
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    x = Cryptographic()
    assert isinstance(x.uuid(), str)


# Generated at 2022-06-23 21:17:52.792829
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test uuid of class Cryptographic."""
    assert len(Cryptographic().uuid()) == 36
    assert len(Cryptographic().uuid(as_object=True)) == 4


# Generated at 2022-06-23 21:17:55.324214
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    token = provider.token_bytes()
    assert len(token) == 32

# Generated at 2022-06-23 21:17:58.868939
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64
    assert len(Cryptographic().token_hex(32)) == 64
    assert len(Cryptographic().token_hex(128)) == 256

# Generated at 2022-06-23 21:18:02.626491
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cp = Cryptographic()
    result = cp.token_hex(entropy=32)
    assert len(result) == 64 and isinstance(result, str)

# Generated at 2022-06-23 21:18:05.754764
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    for i in range(1000):
        c = Cryptographic()
        token = c.token_urlsafe(i)
        print(i, ":", token)

test_Cryptographic_token_urlsafe()

# Generated at 2022-06-23 21:18:07.467336
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    res = c.token_hex()
    print(res)
    assert True


# Generated at 2022-06-23 21:18:10.863116
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    actual = c.token_bytes(3)
    expected = b'\x9a\x9f\xa3'
    assert actual == expected

    return True


# Generated at 2022-06-23 21:18:13.716346
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    _expected = '9812e5a5f5e5f00d407c1eb69adfec71'
    _result = Cryptographic.token_hex(32)
    assert(_result == _expected)

# Generated at 2022-06-23 21:18:15.627680
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method ``token_urlsafe`` of the class ``Cryptographic``."""
    assert Cryptographic().token_urlsafe() != ''



# Generated at 2022-06-23 21:18:23.412614
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Seed: 103390817
    provider = Cryptographic(103390817)
    assert provider.token_urlsafe() == "D5VNQB5rJYrV7y5xzDpMnz1n"
    assert provider.token_urlsafe() == "IkaQF6jYShRUJ8xKj9dz-SE"
    assert provider.token_urlsafe() == "vWsYOYYSIyOHeb0-xz9h-iM"

# Generated at 2022-06-23 21:18:29.342003
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    #print(c.hash())
    #print(c.uuid())
    #print(c.mnemonic_phrase())

    uid = c.uuid(as_object=False)
    print(uid)

    print(c.uuid(as_object=True).hex)
    print(c.uuid(as_object=True).bytes)


if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:18:30.780546
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    entropy = 16
    assert len(provider.token_hex(entropy)) == entropy*2


# Generated at 2022-06-23 21:18:33.296977
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    '''Test method uuid of class Cryptographic'''
    Cryp = Cryptographic()
    assert Cryp.uuid() is not None
    assert Cryp.uuid(True) is not None


# Generated at 2022-06-23 21:18:35.987119
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.token_urlsafe()

# Generated at 2022-06-23 21:18:37.522884
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    print(c.token_bytes(32))
    print(c.token_bytes(64))

# Generated at 2022-06-23 21:18:38.451244
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    return Cryptographic().uuid()


# Generated at 2022-06-23 21:18:44.407129
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    token_hex = crypto.token_hex()
    if not isinstance(token_hex, str):
        raise AssertionError("token_hex is not str")
    if len(token_hex) != 32 * 2:
        raise AssertionError("token_hex is not 32 bytes long")
    try:
        int(token_hex, 16)
    except ValueError:
        raise AssertionError("token_hex is not an hexadecimal string")

# Generated at 2022-06-23 21:18:55.665327
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.seed import apply_seed
    from mimesis.typing import Seed

    cryptographic = Cryptographic()
    assert cryptographic.token_hex(32) == 'c5b5f8d2bd78ca73d9cf9e6463a6f3f6'

    cryptographic = Cryptographic()
    assert cryptographic.token_hex(32) == '9b9f26b1e6c1dceb68f2c0a0770b756f'

    apply_seed(Datetime(), 1601643837)



# Generated at 2022-06-23 21:19:00.830220
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    for i in range(0, 1000):
        assert len(Cryptographic.token_bytes()) == len(Cryptographic.token_bytes(entropy=16)) == 16       # noqa: E501
        assert len(Cryptographic.token_bytes()) == len(Cryptographic.token_bytes(entropy=32)) == 32       # noqa: E501
        assert len(Cryptographic.token_bytes()) == len(Cryptographic.token_bytes(entropy=64)) == 64       # noqa: E501