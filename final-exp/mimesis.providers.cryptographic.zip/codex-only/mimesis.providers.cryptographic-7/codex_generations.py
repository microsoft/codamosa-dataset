

# Generated at 2022-06-23 21:09:02.093181
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    a = Cryptographic()
    assert len(a.token_bytes()) == 32



# Generated at 2022-06-23 21:09:09.147459
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Verify to get the same content of string each time
    assert Cryptographic().token_urlsafe(entropy=64) == "w5V5l5swFJ9rpn2FiJzkuNOUD2L-AxbJqM3YgNbaZJGdHggCVx9a_JfwwgR7GaUa"
    assert Cryptographic().token_urlsafe(entropy=64) == "w5V5l5swFJ9rpn2FiJzkuNOUD2L-AxbJqM3YgNbaZJGdHggCVx9a_JfwwgR7GaUa"

# Generated at 2022-06-23 21:09:12.095896
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # "a38b087c2db64ff8d8c8f9cf193de836" == secrets.token_hex()
    cr = Cryptographic()
    data = cr.token_hex()
    assert(data == "a38b087c2db64ff8d8c8f9cf193de836")
    return True


# Generated at 2022-06-23 21:09:14.319489
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    instance = Cryptographic(seed=12345)
    assert instance == Cryptographic

# Generated at 2022-06-23 21:09:17.949743
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex(): # noqa: N802
    '''Tests function `token_hex` of class `Cryptographic`.'''
    token_hex_object = Cryptographic().token_hex()
    # Uncomment the next line to print the output
    # print(token_hex_object)


# Generated at 2022-06-23 21:09:19.748983
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    y=Cryptographic()
    for i in range(100):
        print(y.token_urlsafe())

# Generated at 2022-06-23 21:09:23.218899
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	from mimesis.enums import Algorithm
	a = Algorithm.MD5
	c = Cryptographic()
	assert c.hash(Algorithm.MD5) == c.hash(a)

if __name__ == '__main__':
	test_Cryptographic_hash()

# Generated at 2022-06-23 21:09:34.822767
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # The mnemonic phrase can be any string
    # of words from the provider's word-list
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    cr = Cryptographic()
    words = cr.mnemonic_phrase()
    # The length of the phrase may be specified in words and a space
    # will be used as default between them
    assert len(words.split(' ')) == 12
    # a custom separator may be specified
    words = cr.mnemonic_phrase(separator='-')
    assert len(words.split('-')) == 12
    # a custom length may be specified
    words = cr.mnemonic_phrase(length=24, separator='-')
    assert len(words.split('-')) == 24
    # the hash method should return a string


# Generated at 2022-06-23 21:09:37.900894
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.uuid() in crypto.__class__.__dict__['uuid'].__annotations__['return']


# Generated at 2022-06-23 21:09:38.942746
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    _hash = Cryptographic().hash(Algorithm.MD5)
    assert len(_hash) == 32


# Generated at 2022-06-23 21:09:40.076525
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    C_obj = Cryptographic()
    assert C_obj.hash()


# Generated at 2022-06-23 21:09:41.377301
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Unit test for method token_hex of class Cryptographic
    cg = Cryptographic()
    token = cg.token_hex()
    assert(len(token)==64)


# Generated at 2022-06-23 21:09:43.990075
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test method token_hex of class Cryptographic."""
    assert len(Cryptographic().token_hex(1)) == 2



# Generated at 2022-06-23 21:09:47.620967
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()

    assert provider.mnemonic_phrase() == 'uniform dust rotate bamboo call vulture success spin defence'
    assert provider.mnemonic_phrase(separator='.') == 'luxury.student.toy.basket.client.parcel.suit.absorption.matrix'
    assert provider.mnemonic_phrase(length=3, separator=',') == 'hail,ruin,maze'
    assert isinstance(provider.mnemonic_phrase(), str)

# Generated at 2022-06-23 21:09:51.816452
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Cleanup
    Cryptographic.reset_seed()
    # Run the test
    assert Cryptographic.token_hex() == "aa3ea5b50dd127b5e5c9e1e5fc11f8745e581a12acd5489b85e0d87a0b836158"

# Generated at 2022-06-23 21:09:55.044507
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    import uuid
    c = Cryptographic()
    assert c.uuid(as_object=False).__class__ is str
    assert isinstance(c.uuid(as_object=True), uuid.UUID)


# Generated at 2022-06-23 21:09:56.329868
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(16)

# Generated at 2022-06-23 21:09:57.389615
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token = crypto.token_bytes()
    assert type(token) == bytes


# Generated at 2022-06-23 21:09:58.608231
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  assert Cryptographic().hash(Algorithm.SHA1)


# Generated at 2022-06-23 21:10:01.172754
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    #def test_init(self):
    c = Cryptographic()
    assert c.__class__.__name__ == 'Cryptographic'


# Generated at 2022-06-23 21:10:04.253366
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic().token_hex() == 'aad9f9d9d9c40f89971dd76c07dae29b'


# Generated at 2022-06-23 21:10:12.034139
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # checking for a string length of 32
    test_token_urlsafe_1 = Cryptographic.token_urlsafe(32)
    assert len(test_token_urlsafe_1) == 43

    # checking for a string length of 16
    test_token_urlsafe_2 = Cryptographic.token_urlsafe(16)
    assert len(test_token_urlsafe_2) == 27

    # checking for a string length of 8
    test_token_urlsafe_3 = Cryptographic.token_urlsafe(8)
    assert len(test_token_urlsafe_3) == 19


# Generated at 2022-06-23 21:10:14.269692
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic.token_urlsafe()) == 43
    assert len(Cryptographic.token_urlsafe(2)) == 6

# Generated at 2022-06-23 21:10:25.981807
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for class Cryptographic."""
    from mimesis.enums import Algorithm

    crp = Cryptographic(seed=0)

    # Testing hashing method
    assert self.hash() == 'b8cac97c6f489a2a1b8d2b6c9a314da0'
    assert self.hash(algorithm=Algorithm.MD5) == 'b8cac97c6f489a2a1b8d2b6c9a314da0'
    assert self.hash(algorithm=Algorithm.SHA1) == '15b5832c45cda5633c7a1d6e56dcf3f8d0b35cb9'

# Generated at 2022-06-23 21:10:33.250168
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()

    # Test 1
    assert len(crypto.mnemonic_phrase().split(" ")) == 12

    # Test 2
    assert len(crypto.mnemonic_phrase(length=7).split(" ")) == 7

    # Test 3
    assert len(crypto.mnemonic_phrase(length=7, separator="-").split("-")) == 7

    # Test 4
    assert len(crypto.mnemonic_phrase(length=19, separator="#").split("#")) == 19


# Generated at 2022-06-23 21:10:37.479738
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic.uuid() != None
    assert Cryptographic.uuid(as_object=True) != None
    assert Cryptographic.hash() != None
    assert Cryptographic.token_bytes() != None
    assert Cryptographic.token_hex() != None
    assert Cryptographic.token_urlsafe() != None
    assert Cryptographic().mnemonic_phrase() != None

# Generated at 2022-06-23 21:10:44.588932
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.base import BaseProvider

    BaseProvider.seed(None)  # Clear the seed to show random value generation

    crypto = Cryptographic()

    print(crypto.token_hex())  # ed38e7e5aa84d82440f5cfc15b9e9f12
    print(crypto.token_hex())  # a6f20d34e05e1a0b6ff3c6bf9f6ff7ee

# Generated at 2022-06-23 21:10:47.916289
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic() # instantiate class Cryptographic
    hash = crypto.hash() # given a hash
    assert type(hash) == str # verify if it's a string


# Generated at 2022-06-23 21:10:53.043709
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe()
    assert type(token) is str
    assert (len(token) - token.count('=') * 1) % 4 == 0
    assert ' ' not in token
    assert '_' in token
    assert '-' in token

# Generated at 2022-06-23 21:10:56.036360
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    '''Verify that token_urlsafe from mimesis returns a url-safe string.'''
    import re
    assert re.search('[^a-zA-Z0-9-_=]',Cryptographic().token_urlsafe() ) is None

# Generated at 2022-06-23 21:10:58.710630
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token = crypto.token_bytes()
    assert isinstance(token, bytes)


# Generated at 2022-06-23 21:11:01.280334
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    assert type(phrase) == str


# Generated at 2022-06-23 21:11:07.737928
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Check that method works correctly with enum object
    data = Cryptographic().hash(Algorithm.SHA_1)
    assert data
    assert isinstance(data, str)

    # Check that method works correctly with string
    data = Cryptographic().hash('sha-1')
    assert data
    assert isinstance(data, str)

    # Check that method raises error if algorithm is unsupported
    try:
        data = Cryptographic().hash('sha-0')
    except NonEnumerableError:
        pass

# Generated at 2022-06-23 21:11:09.203322
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic.token_bytes(24)
    assert isinstance(token, bytes)


# Generated at 2022-06-23 21:11:10.490205
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    token = provider.token_hex()
    assert (len(token) == 64)

# Generated at 2022-06-23 21:11:11.995189
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe()
    assert len(token) == 43
    assert isinstance(token, str)

# Generated at 2022-06-23 21:11:14.958461
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    random_token = Cryptographic.token_bytes()
    assert type(random_token) == bytes
    assert len(random_token) == 32
    

# Generated at 2022-06-23 21:11:25.190267
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """ Unit test for method token_hex of class Cryptographic """
    from unittest import TestCase
    from mimesis.enums import Algorithm

    class UnitTest(TestCase):
        """Unit test for method token_hex of class Cryptographic."""

        def test_length(self):
            """Test default length of token.

            :return: None
            """
            c = Cryptographic()
            token = c.token_hex()
            self.assertEqual(len(token), 64)

        def test_with_provided_length(self):
            """Test length of token with provided length.

            :return: None
            """
            c = Cryptographic()
            token = c.token_hex(entropy=16)
            self.assertEqual(len(token), 32)


# Generated at 2022-06-23 21:11:28.944516
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test_c = Cryptographic()
    assert test_c.hash() == 'fc05ed74e8b35f413e9f02a81d9aa3a8aac1b2ca48f6c064a5e8f5b5c5365d0d'

# Generated at 2022-06-23 21:11:31.815812
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    assert isinstance(cr.uuid(True), UUID)
    assert isinstance(cr.uuid(), str)
    assert isinstance(cr.uuid(as_object=False), str)


# Generated at 2022-06-23 21:11:33.182954
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    test_Cryptographic = Cryptographic()
    assert test_Cryptographic is not None


# Generated at 2022-06-23 21:11:36.075438
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    key = hashlib.md5()
    key.update(Cryptographic().token_hex().encode())
    key = key.hexdigest()

    print(key)

# Generated at 2022-06-23 21:11:38.079900
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    bytes = provider.token_hex()
    assert len(bytes) in [32, 64]


# Generated at 2022-06-23 21:11:42.675598
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # crypto = Cryptographic()
    # crypto.token_urlsafe(16)
    assert len(Cryptographic().token_urlsafe(16)) == 22
    assert len(Cryptographic().token_urlsafe(32)) == 45

# Generated at 2022-06-23 21:11:45.400496
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for method token_hex of class Cryptographic."""
    assert isinstance(Cryptographic().token_hex(), str)


# Generated at 2022-06-23 21:11:48.518735
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    t = c.uuid(as_object = False)
    assert type(t) == str or type(t) == UUID


# Generated at 2022-06-23 21:11:49.349446
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic(seed=123456)

# Generated at 2022-06-23 21:11:52.787291
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test Enum name
    assert (Cryptographic().hash(Algorithm.SHA256) is not None)
    # Test Enum value
    assert (Cryptographic().hash(Algorithm.SHA256.name) is not None)
    # Test string
    assert (Cryptographic().hash('sha256') is not None)

# Generated at 2022-06-23 21:11:55.065423
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider=Cryptographic()
    token = provider.token_hex()
    print(token)
    mnemonic = provider.mnemonic_phrase()
    print(mnemonic)
    code = provider.hash()
    print(code)

# Generated at 2022-06-23 21:11:59.705787
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic.uuid() == '1a2b37f0-668f-4201-b4b8-a0e9c9e2f74a'
    assert Cryptographic.uuid(as_object=True) == UUID('1a2b37f0-668f-4201-b4b8-a0e9c9e2f74a')


# Generated at 2022-06-23 21:12:00.610120
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()

# Generated at 2022-06-23 21:12:02.479698
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(24) is not c.token_urlsafe(24)



# Generated at 2022-06-23 21:12:05.834513
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe of class Cryptographic."""
    assert isinstance(Cryptographic().token_urlsafe(), str)

# Generated at 2022-06-23 21:12:09.716573
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic"""
    token_urlsafe = Cryptographic(seed=1).token_urlsafe()
    assert token_urlsafe == 'pqE3qzcp_Za5UV5RjHc2Q'


# Generated at 2022-06-23 21:12:19.221359
# Unit test for method mnemonic_phrase of class Cryptographic

# Generated at 2022-06-23 21:12:20.779611
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase())

# Generated at 2022-06-23 21:12:24.878716
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    print(cr.uuid())
    print(cr.uuid(as_object=True))
    print(cr.hash(Algorithm.SHA512))
    print(cr.mnemonic_phrase())


# Generated at 2022-06-23 21:12:28.467382
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test method Cryptographic.token_bytes"""
    instance = Cryptographic()

    result = instance.token_bytes()
    assert type(result) == bytes


# Generated at 2022-06-23 21:12:29.770611
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    a = Cryptographic()
    print(a.mnemonic_phrase())

# Generated at 2022-06-23 21:12:32.987330
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    result = Cryptographic.token_hex()
    assert len(result) == 64
    

# Generated at 2022-06-23 21:12:39.697146
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic('1234')
    print(c.uuid())
    print(c.uuid(as_object=True))
    print(c.hash())
    print(c.hash(Algorithm.MD5))
    print(c.token_bytes(32))
    print(c.token_hex(32))
    print(c.token_urlsafe(32))
    print(c.mnemonic_phrase())
    print(c.mnemonic_phrase(separator=';'))
    print(c.mnemonic_phrase(length=8))
    print(c.mnemonic_phrase(length=8, separator=';'))

# Generated at 2022-06-23 21:12:43.279461
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    uuid = provider.uuid()
    assert isinstance(uuid, str) and len(uuid) == 36
    assert isinstance(provider.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:12:46.168271
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cr = Cryptographic()
    assert (len(cr.token_urlsafe(32)) == 43)
    assert (len(cr.token_urlsafe(16)) == 27)


# Generated at 2022-06-23 21:12:47.607616
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    print(crypto)


# Generated at 2022-06-23 21:12:52.424473
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()

    assert crypto.hash() is not None
    assert crypto.hash(Algorithm.MD5) is not None
    assert crypto.hash(Algorithm.SHA256) is not None
    assert crypto.hash(Algorithm.SHA512) is not None
    assert crypto.token_bytes() is not None
    assert crypto.token_hex() is not None
    assert crypto.token_urlsafe() is not None
    assert crypto.mnemonic_phrase() is not None


# Generated at 2022-06-23 21:12:54.395895
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    for _ in range(1, 15):
        mnemonic_phrase = cr.mnemonic_phrase()
        assert len(mnemonic_phrase), _

# Generated at 2022-06-23 21:12:59.790369
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    print(crypto.uuid())
    print(crypto.uuid(as_object=True))
    print(crypto.hash(Algorithm.MD5))
    print(crypto.hash(Algorithm.SHA256))
    print(crypto.hash(Algorithm.SHA512))
    print(crypto.token_bytes(64))
    print(crypto.token_hex(64))
    print(crypto.token_urlsafe(64))
    print(crypto.mnemonic_phrase())
    print(crypto.mnemonic_phrase(separator='-'))

if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:13:03.363262
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic.uuid(), str)
    assert isinstance(Cryptographic.uuid(True), UUID)
    assert len(Cryptographic.uuid()) == 36


# Generated at 2022-06-23 21:13:07.112714
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=42)
    assert c.mnemonic_phrase() == 'forceful pretend slightly shield guide learn main\
     generation'
    assert c.mnemonic_phrase(4) == 'built imagine passive\
     watch video'
    assert c.mnemonic_phrase(3, '-') == 'leaf-kiss-name'

# Generated at 2022-06-23 21:13:12.742761
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    g = Cryptographic(seed=1234567)
    assert g.uuid() == '3742d638-855c-4096-9e50-dfa9355930b6'
    assert g.uuid(as_object=True) == UUID('3742d638-855c-4096-9e50-dfa9355930b6')


# Generated at 2022-06-23 21:13:15.514489
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    _c = Cryptographic()
    _c.uuid()
    _c.hash()
    _c.token_bytes()
    _c.token_hex()
    _c.token_urlsafe()
    _c.mnemonic_phrase()

# Generated at 2022-06-23 21:13:25.081509
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase(length=1) == 'potent'
    assert crypto.mnemonic_phrase(length=2) == 'potent public'
    assert crypto.mnemonic_phrase(length=3) == 'potent public court'
    assert crypto.mnemonic_phrase(length=4) == 'potent public court rural'
    assert crypto.mnemonic_phrase(length=5) == 'potent public court rural secret'
    assert crypto.mnemonic_phrase(length=6) == 'potent public court rural secret system'
    assert crypto.mnemonic_phrase(length=7) == 'potent public court rural secret system section'
    assert crypto.mnemonic_phrase(length=8) == 'potent public court rural secret system section less'

# Generated at 2022-06-23 21:13:28.768705
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Initialize default Cryptographic object
    d = Cryptographic()

    # Return string by default
    assert isinstance(d.uuid(), str)

    # Return uuid.UUID object
    assert isinstance(d.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:13:32.075863
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    expected = Cryptographic(seed=123456789).uuid()
    a1 = Cryptographic(seed=123456789).uuid()
    assert a1 == expected



# Generated at 2022-06-23 21:13:41.246887
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic."""
    # Given a cryptographic provider
    cryptographic_provider = Cryptographic(seed=1)
    # When I call token_hex method
    token = cryptographic_provider.token_hex(64)
    # Then I get the expected token
    expected_token = '6f1ea6c394579b8d6d95bd6d9e9f9c6f01d0c6e28b23904a0d16c358faa1d6f16f1ea6c394579b8d6d95bd6d9e9f9c6f01d0c6e28b23904a0d16c358faa1d6f1'  # noqa: E501
    assert token == expected_token


# Generated at 2022-06-23 21:13:46.232111
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test method token_urlsafe of class Cryptographic"""
    # Arrange
    # Act
    result = Cryptographic.token_urlsafe(10)
    # Assert
    assert isinstance(result, str)
    assert len(result) == 22
    assert result == '-qN3ZpXN1rMHYjTd'


# Generated at 2022-06-23 21:13:47.171811
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cryptographic = Cryptographic()
    print(cryptographic.token_hex())


# Generated at 2022-06-23 21:13:49.923803
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    result = provider.token_urlsafe()
    assert result
    assert type(result) is str
    assert len(result) == 43

# Generated at 2022-06-23 21:13:58.099683
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 44

    m = Cryptographic(seed=42)
    assert len(m.token_urlsafe()) == 44

    # Check that if called repeatedly with the same algorithm,
    # that a repeatable sequence of values is returned.
    m = Cryptographic(seed=42)
    values = [m.token_urlsafe() for _ in range(3)]
    assert values == ['5VuE5A9X7VuU5ABX7VuU5ABX7VuU5ABX',
                      '0Bry5AdX7Rtb0QIA7VuU5ABX7VuU5ABX',
                      '5VuE5A9X7VuU5ABX7VuU5ABX7VuU5ABX']

    # Check

# Generated at 2022-06-23 21:14:08.408790
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    import random
    def set_seed(seed=None):
        r = random.Random()
        r.seed(seed)
        return r

    def get_mnemonic_phrase(length=12, separator=' '):
        c = Cryptographic()
        return c.mnemonic_phrase(length, separator)

    def test_mnemonic_phrase(length=12):
        print("len({}): {}".format(length, test_mnemonic_phrase_with_seed(length)))
        print("len({}): {}".format(length, test_mnemonic_phrase_with_seed(length)))
        print("len({}): {}".format(length, test_mnemonic_phrase_with_seed(length)))
        print("len({}): {}".format(length, test_mnemonic_phrase_with_seed(length)))
       

# Generated at 2022-06-23 21:14:09.618471
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    print(c.token_hex())


# Generated at 2022-06-23 21:14:11.337378
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    result = crypto.mnemonic_phrase()
    assert result.split()


# Generated at 2022-06-23 21:14:13.764022
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert (
        len(Cryptographic.uuid()) == 36
    ), 'Method uuid of class Cryptographic does not work correctly'

# Generated at 2022-06-23 21:14:17.405463
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    tokens = []
    for _ in range(0, 1000):
        tokens.append(Cryptographic.token_bytes(20))
    assert set(tokens) == set(tokens)


# Generated at 2022-06-23 21:14:23.893240
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cry = Cryptographic('en')
    assert cry.mnemonic_phrase().count(' ') == 11
    assert cry.mnemonic_phrase(separator=',').count(',') == 11
    assert cry.mnemonic_phrase(length=24).count(' ') == 23
    assert cry.mnemonic_phrase(separator='-', length=24).count('-') == 23

test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:14:31.001803
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    uuid = crypto.uuid() 
    hash = crypto.hash()
    token_bytes = crypto.token_bytes()
    token_hex = crypto.token_hex()
    token_urlsafe = crypto.token_urlsafe()
    mnemonic_phrase = crypto.mnemonic_phrase()

    print("Class: Cryptographic")
    print("\tuuid:", uuid)
    print("\thash:", hash)
    print("\ttoken_bytes:", token_bytes)
    print("\ttoken_hex:", token_hex)
    print("\ttoken_urlsafe:", token_urlsafe)
    print("\tmnemonic_phrase:", mnemonic_phrase)

# Generated at 2022-06-23 21:14:32.723035
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis import Cryptographic
    cr = Cryptographic()
    token_urlsafe = cr.token_urlsafe()
    assert type(token_urlsafe) == str
    assert len(token_urlsafe) >= 32

# Generated at 2022-06-23 21:14:39.382437
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.builtins import Cryptographic
    Crypto = Cryptographic()
    assert Crypto.hash() == Crypto.hash()
    assert Crypto.hash(algorithm=Algorithm.MD5) == Crypto.hash(algorithm=Algorithm.MD5)
    assert Crypto.hash(algorithm=Algorithm.MD5) != Crypto.hash(algorithm=Algorithm.SHA1)
    assert Crypto.hash(algorithm=Algorithm.SHA1) == Crypto.hash(algorithm=Algorithm.SHA1)
    assert Crypto.hash(algorithm=Algorithm.SHA256) == Crypto.hash(algorithm=Algorithm.SHA256)
    assert Crypto.hash(algorithm=Algorithm.SHA384) == Crypto.hash(algorithm=Algorithm.SHA384)

# Generated at 2022-06-23 21:14:43.021286
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crg = Cryptographic()
    assert len(crg.token_hex(5))==10
    assert len(crg.token_hex(32))==64
    assert len(crg.token_hex())==64


# Generated at 2022-06-23 21:14:46.001491
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for method token_hex() of class Cryptographic."""
    token = Cryptographic().token_hex(32)
    assert len(token) == 64

# Generated at 2022-06-23 21:14:52.668650
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    d = Cryptographic()
    print(d.hash())
    print(d.hash(Algorithm.SHA224))
    print(d.hash(Algorithm.SHA256))
    print(d.hash(Algorithm.SHA384))
    print(d.hash(Algorithm.SHA512))
    print(d.hash(Algorithm.MD5))
    print(d.mnemonic_phrase())
    print(d.token_bytes())
    print(d.token_hex())
    print(d.token_urlsafe())
    print(d.uuid())

# Generated at 2022-06-23 21:14:55.839564
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    assert crypto.token_urlsafe() == 'OtL-mpM1AaY1RUlNdC9tXzNtRmlkR1EzRjBvU3pGblZUM3l3'

# Generated at 2022-06-23 21:14:56.849525
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cryptographic = Cryptographic()
    assert cryptographic is not None

# Generated at 2022-06-23 21:14:58.216764
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert len(c.token_hex()) == 64


# Generated at 2022-06-23 21:14:59.739967
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid(True).__class__ is UUID


# Generated at 2022-06-23 21:15:02.161810
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Initialize object
    crypto = Cryptographic()

    # Assert if object is created
    assert crypto

# Generated at 2022-06-23 21:15:03.421870
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64


# Generated at 2022-06-23 21:15:05.161339
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    assert isinstance(cr.uuid(), str)


# Generated at 2022-06-23 21:15:06.167054
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.SHA_512)) == 128

# Generated at 2022-06-23 21:15:11.314110
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    parser = argparse.ArgumentParser(
        description='''
        This is a unit test for method token_hex of class Cryptographic. '''
    )
    parser.add_argument(
        '-e',
        '--entropy',
        type=int,
        help='Sets number of bytes of the token.',
        required=False,
        default=32
    )
    args = parser.parse_args()

    test_obj = Cryptographic()
    token = test_obj.token_hex(args.entropy)

    print(token)

# Generated at 2022-06-23 21:15:14.588581
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("test_Cryptographic_hash")
    crypto = Cryptographic()
    result = crypto.hash(Algorithm.MD5)
    assert len(result) == 32
    print("DONE")


# Generated at 2022-06-23 21:15:19.364269
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(32) == "f4445de1f51d6ef9f6bb66c6ef4d3e4f"

# Generated at 2022-06-23 21:15:21.194959
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initializing the class
    c = Cryptographic()
    # Getting a random hash
    c.hash()


# Generated at 2022-06-23 21:15:27.228367
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm
    from mimesis.builtins import Cryptographic
    from mimesis.providers.base import Provider
    cr=Cryptographic
    cr.locale = 'en'
    cr.datetime = Provider('datetime').datetime()

    assert type(cr) is not None
    assert cr.token_bytes() != None
    assert type(cr.token_bytes()) is bytes


# Generated at 2022-06-23 21:15:36.647138
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA3_224)
    assert crypto.hash(Algorithm.BLAKE2s)
    assert crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.RIPEMD160)
    assert crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA224)
    assert crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA384)
    assert crypto.hash(Algorithm.SHA3_224)
    assert crypto.hash(Algorithm.SHA3_256)
    assert crypto.hash(Algorithm.SHA3_384)
    assert crypto.hash(Algorithm.SHA3_512)
    assert crypto.hash(Algorithm.SHA512)

# Generated at 2022-06-23 21:15:38.252512
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() != Cryptographic().uuid()


# Generated at 2022-06-23 21:15:40.235538
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase(): # noqa: N802
    x = Cryptographic()
    assert x.mnemonic_phrase()

# Generated at 2022-06-23 21:15:44.806033
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	# Create object
	data = Cryptographic()
	uuid = data.uuid()
	hash = data.hash(Algorithm.SHA512)
	token_bytes = data.token_bytes()
	token_hex = data.token_hex()
	token_urlsafe = data.token_urlsafe()

# Test some methods of object Cryptographic

# Generated at 2022-06-23 21:15:47.583946
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    words = "abandon above absorb abuse access".split(' ')
    assert Cryptographic().mnemonic_phrase(length=5) in words

# Generated at 2022-06-23 21:15:50.364413
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():  # noqa: N802
    """Test for method token_bytes for class Cryptographic."""
    bytes_test = Cryptographic().token_bytes()
    assert isinstance(bytes_test, bytes)
    assert len(bytes_test) != 0


# Generated at 2022-06-23 21:15:52.519575
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash in Cryptographic class."""
    obj=Cryptographic()
    s=Cryptographic.Meta.name
    assert obj.hash() is not None, "test_Cryptographic_hash failed"
    assert s is not None, "test_Cryptographic_hash failed"

# Generated at 2022-06-23 21:15:55.800891
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    try:
        assert len(str(Cryptographic().token_bytes())) > 0
    except Exception as e:
        print(e)
        return False
    return True


# Generated at 2022-06-23 21:15:57.150155
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()[0:3] == 'a95'

# Generated at 2022-06-23 21:15:58.865211
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    actual = Cryptographic().token_bytes()
    expected = bytes
    assert isinstance(actual,expected)


# Generated at 2022-06-23 21:16:04.005071
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    alg = crypto.random.choice(list(Algorithm))  # noqa: A003

    print('\n### Testing method hash of class Cryptographic ###')
    print(f'Hashing algorithm: {alg.value}')
    print(f'Result: {crypto.hash(alg)}')


# Generated at 2022-06-23 21:16:12.023445
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    '''
    testing the hash method of the class
    '''
    # pylint: disable=C0116, C0121
    c = Cryptographic(seed=17)
    hashlib.sha256(c.uuid().encode()).hexdigest()
    c.hash()
    assert (hashlib.sha256(c.uuid().encode()).hexdigest() ==
            'e1f8ff649b0a4f0cd1b4a4a8a0cd4db224bae7c965f588dff8b53105c4f4f22c')


# Generated at 2022-06-23 21:16:17.141929
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Test if return value has the expected type
    provider = Cryptographic()
    assert isinstance(provider.token_urlsafe(), str)

    # Test if entropy is used as a limit
    assert len(provider.token_urlsafe(1)) == 1

    # Test if default entropy is used
    assert len(provider.token_urlsafe()) == 32

    # Test if a random token is generated
    assert provider.token_urlsafe() != provider.token_urlsafe()

# Generated at 2022-06-23 21:16:29.199862
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cp = Cryptographic()
    assert cp.uuid() == 'd8c88f7a-e1a0-4e20-9aef-1d05b78d06f7'
    assert cp.hash() in ['0xab6e7ba6', '0x0b95883e', '0x2e8d0f2b', '0xdf5a3a5f', '0x5a6a5289']

# Generated at 2022-06-23 21:16:35.360631
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.uuid() == Cryptographic.uuid()
    assert c.hash('sha256') == Cryptographic.hash('sha256')
    assert c.token_bytes(8) == Cryptographic.token_bytes(8)
    assert c.token_hex(8) == Cryptographic.token_hex(8)
    assert c.token_urlsafe(8) == Cryptographic.token_urlsafe(8)
    assert c.mnemonic_phrase(3) == Cryptographic.mnemonic_phrase(3)

# Generated at 2022-06-23 21:16:38.709671
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cryptographic = Cryptographic()
    url_safe_token = cryptographic.token_urlsafe(32)
    print(url_safe_token)
# End Unit test for method token_urlsafe of class Cryptographic



# Generated at 2022-06-23 21:16:41.563553
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'a8cdbb94a0f3e3ddde9ff9cad1f35c98dce42e45e44cfb12a94d95e15bc965f1'



# Generated at 2022-06-23 21:16:47.377432
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    import random
    import string
    random = random.SystemRandom()
    token = random.choice(string.ascii_uppercase + string.digits)
    test_result = Cryptographic.token_bytes(entropy=32)
    print(test_result)


# Generated at 2022-06-23 21:16:56.971342
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe."""
    from mimesis.enums import Algorithm

    crypto = Cryptographic()

    # random.seed(9999)
    # print(crypto.token_urlsafe(32))

    assert crypto.token_urlsafe(32) == '_6I_U6zJUQxCxL-EuZDY9bJjWO7rUAdw'
    assert crypto.token_urlsafe(32) == '619E7F9Cf8pChr6rv5wNk7VyC5b3N7V5'
    assert crypto.token_urlsafe(32) == 'J_zwFDCbQt1GN8CQUxoLIf0oCf_aAmXq'



# Generated at 2022-06-23 21:16:59.059684
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid().__class__ == str
    assert Cryptographic().uuid(as_object=True).__class__ == UUID


# Generated at 2022-06-23 21:17:00.781999
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex(32)
    assert isinstance(token, str)


# Generated at 2022-06-23 21:17:02.580521
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    assert isinstance(obj.hash(), str) and len(obj.hash()) == 32



# Generated at 2022-06-23 21:17:05.067484
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(entropy=10)) == 20
    assert len(Cryptographic().token_bytes(entropy=43)) == 86


# Generated at 2022-06-23 21:17:07.398213
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto
    assert crypto.__class__ == Cryptographic


# Generated at 2022-06-23 21:17:10.842374
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for Cryptographic.token_hex()."""
    assert isinstance(Cryptographic.token_hex(), str)
    assert len(Cryptographic.token_hex()) == 64


# Generated at 2022-06-23 21:17:13.185371
# Unit test for method mnemonic_phrase of class Cryptographic

# Generated at 2022-06-23 21:17:15.894499
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase()
    assert crypto.mnemonic_phrase(8)
    assert crypto.mnemonic_phrase(8, ".")

# Generated at 2022-06-23 21:17:18.256218
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic('en')
    mnemonic = c.mnemonic_phrase(separator = ',')
    assert type(mnemonic) == str
    assert len(mnemonic.split(',')) == 12

# Generated at 2022-06-23 21:17:20.720831
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert isinstance(Cryptographic.token_bytes(), bytes)
    assert isinstance(Cryptographic.token_bytes(100), bytes)


# Generated at 2022-06-23 21:17:24.354111
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == '80703c6d5f6d5b6c3d72e5e6cc2e56f7'


# Generated at 2022-06-23 21:17:27.875179
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Test with the default value
    token_bytes = Cryptographic.token_bytes()
    assert len(token_bytes) == 32

    # Test with a specified value
    token_bytes = Cryptographic.token_bytes(10)
    assert len(token_bytes) == 10


# Generated at 2022-06-23 21:17:31.125582
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(Cryptographic.token_hex())
    print(Cryptographic.token_hex(16))
    print(Cryptographic.token_hex(32))


# Generated at 2022-06-23 21:17:33.623807
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test constructor of class Cryptographic."""
    p=Cryptographic()
    p.uuid()
    p.mnemonic_phrase()

# Generated at 2022-06-23 21:17:44.189524
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c is not None
    assert c.uuid() == "4b9fd7a1-c2dd-4c56-a049-7a46a6b73d6c"
    assert c.hash() == '6a1e6aafc6f8afd79973ba5b5dc5aa5d5a9f534b23422e5a7e30a5b8e2cdc16f'

# Generated at 2022-06-23 21:17:45.521694
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert(Cryptographic().__init__)


# Generated at 2022-06-23 21:17:49.242808
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    current_provider = Cryptographic()
    assert len(str(current_provider.uuid())) == 36
    assert len(str(current_provider.uuid())) == 36
    assert str(current_provider.uuid()) != str(current_provider.uuid())
	

# Generated at 2022-06-23 21:17:51.442988
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.providers.cryptographic import Cryptographic
    provider = Cryptographic()
    #print(provider.mnemonic_phrase())

# Generated at 2022-06-23 21:17:55.913369
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    # Tests for method token_bytes
    crypto = Cryptographic()
    entropy = 32
    token1 = crypto.token_bytes(entropy)
    token2 = crypto.token_bytes(entropy)
    assert type(token1) is bytes
    assert type(token2) is bytes
    assert len(token1) == entropy
    assert len(token2) == entropy
    assert token1 != token2


# Generated at 2022-06-23 21:17:58.434898
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    for i in range(3):
        print(crypto.mnemonic_phrase())

# Generated at 2022-06-23 21:18:02.832768
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp = Cryptographic()
    mnemonic_phrase = cp.mnemonic_phrase()
    assert mnemonic_phrase is not None
    assert isinstance(mnemonic_phrase, str)

# Generated at 2022-06-23 21:18:04.261711
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase()



# Generated at 2022-06-23 21:18:07.434902
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test Cryptographic.token_urlsafe.

    Expected:
    >>> assert len(Cryptographic().token_urlsafe()) == 45

    """
    token = Cryptographic().token_urlsafe()
    assert isinstance(token, str) and len(token) == 45

# Generated at 2022-06-23 21:18:09.498018
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic(seed=123)

    assert c.token_bytes() != c.token_bytes()  # noqa: E712

# Generated at 2022-06-23 21:18:11.670530
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    '''
    Function to test method token_bytes of class Cryptographic
    '''
    assert Cryptographic.token_bytes()


# Generated at 2022-06-23 21:18:15.329186
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    import uuid

    # without params
    result = Cryptographic.uuid()
    assert len(result) == 36

    # As object
    result = Cryptographic.uuid(True)
    assert isinstance(result, uuid.UUID)
    assert str(result) != ''


# Generated at 2022-06-23 21:18:16.209751
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic() is not None

# Generated at 2022-06-23 21:18:22.084964
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    function_output = crypto.hash(Algorithm.SHA256)
    true_output = '38ceee2ec78a134585867f5abb6f57e6b79a9b59cb6b8a0050309d40f4c4e1f6'
    assert function_output == true_output

# Generated at 2022-06-23 21:18:23.121401
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c

# Generated at 2022-06-23 21:18:24.645774
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic().token_urlsafe())
    assert True


# Generated at 2022-06-23 21:18:28.954686
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Arrange
    from mimesis.typing import Seed

    seed = Seed(42)
    provider = Cryptographic(seed)

    expected = 'desde algunos solos dentro fuego'
    # Act
    result = provider.mnemonic_phrase()
    # Assert
    assert result == expected


# Generated at 2022-06-23 21:18:32.705412
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # This test is only checking types of values returned by uuid method,
    # as it is actually not testable.
    _uuid = Cryptographic().uuid()
    assert isinstance(_uuid, str), "Returned value is not str."


test_Cryptographic_uuid()

# Generated at 2022-06-23 21:18:35.823552
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    result = c.uuid()
    assert isinstance(result, str)
    assert len(result) == 36
    # __format__ (format_spec = 'P')
    result = c.uuid().__format__('P')
    assert isinstance(result, str)



# Generated at 2022-06-23 21:18:36.694017
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic is not None

# Generated at 2022-06-23 21:18:37.841187
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    print(c.uuid())


# Generated at 2022-06-23 21:18:44.183347
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis import Cryptographic

    crypto = Cryptographic()

    assert crypto.token_urlsafe() == 'o0yh_VTE0KM5bxV7-LJ1BdKjBHwZjws6z17U6pDHUe8'

    assert crypto.token_urlsafe(entropy=56) == 'ZHrjd1QQGWAzKq3X8i4sxmTjbKpIoWBI8ZHv-FcKdzss'

# Generated at 2022-06-23 21:18:55.502690
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test of method mnemonic_phrase()"""
    assert(len(Cryptographic().mnemonic_phrase()) == 12)
    assert(len(Cryptographic().mnemonic_phrase(5)) == 5)
    assert(len(Cryptographic().mnemonic_phrase(length=15)) == 15)
    assert(len(Cryptographic().mnemonic_phrase(length=15, separator='&')) == 15)
    assert(len(Cryptographic().mnemonic_phrase(length=15, separator='&').split('&')) == 15)
    assert(len(Cryptographic().mnemonic_phrase(length=15, separator='?')) == 15)
    assert(len(Cryptographic().mnemonic_phrase(length=15, separator='?').split('?')) == 15)

# Generated at 2022-06-23 21:18:56.342119
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  assert len(Cryptographic().token_urlsafe()) == 43

# Generated at 2022-06-23 21:18:59.794621
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test method token_bytes of class Cryptographic."""
    assert isinstance(Cryptographic.token_bytes(), bytes)
    assert len(Cryptographic.token_bytes()) == 32
    assert len(Cryptographic.token_bytes(100)) == 100


# Generated at 2022-06-23 21:19:02.710384
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    print(c.mnemonic_phrase())
    print(c.mnemonic_phrase())
    print(c.mnemonic_phrase())
    print(c.mnemonic_phrase())
