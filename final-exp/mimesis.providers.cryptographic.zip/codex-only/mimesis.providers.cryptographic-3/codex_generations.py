

# Generated at 2022-06-23 21:08:59.405052
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c



# Generated at 2022-06-23 21:09:01.482192
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    algorithm = Algorithm.SHA256

    c = Cryptographic()

    assert len(c.hash(algorithm)) == 64

# Generated at 2022-06-23 21:09:07.729296
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Field

    crypto = Cryptographic()

    assert len(crypto.uuid()) == 36
    assert isinstance(crypto.uuid(as_object=True), UUID)

    # Validate pattern
    pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    assert crypto.validate(Field.UUID, pattern)


# Generated at 2022-06-23 21:09:09.834384
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    assert(str(cr.uuid())!=None)


# Generated at 2022-06-23 21:09:13.144864
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()

    assert isinstance(crypto.uuid(), str)

    p = lambda x: isinstance(crypto.uuid(as_object=x), UUID)  # noqa: E731
    assert p(True)
    
    for _ in range(100):
        actual = crypto.uuid()
        assert len(actual) == 36
        assert isinstance(actual, str)
        

# Generated at 2022-06-23 21:09:16.581491
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes(entropy=0)) == 0
    # Test if method returns byte string
    assert isinstance(Cryptographic.token_bytes(entropy=10), bytes)


# Generated at 2022-06-23 21:09:18.955199
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic.uuid() == Cryptographic.uuid()

# Generated at 2022-06-23 21:09:21.104651
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic.token_urlsafe()) == 22
    assert len(Cryptographic.token_urlsafe(20)) == 32


# Generated at 2022-06-23 21:09:23.129411
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.mnemonic_phrase() is not None
    assert c.token_hex() is not None

# Generated at 2022-06-23 21:09:26.675353
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    # Run test
    result = Cryptographic.token_bytes()
    # Assert results
    assert len(result) == 32


# Generated at 2022-06-23 21:09:29.688595
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    mn = Cryptographic()
    token_urlsafe = mn.token_urlsafe()
    assert token_urlsafe
    print(token_urlsafe)


# Generated at 2022-06-23 21:09:31.478892
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    print(phrase)

# Generated at 2022-06-23 21:09:34.918845
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    expected_result = 'f30d6dd9b8e0b7ab57fa621c72677f3b'
    assert Cryptographic().token_hex(32) == expected_result


# Generated at 2022-06-23 21:09:36.970273
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Create an instance of Cryptographic"""
    crypt = Cryptographic()
    assert isinstance(crypt, Cryptographic)



# Generated at 2022-06-23 21:09:37.858261
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic is not None


# Generated at 2022-06-23 21:09:44.513858
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic"""
    x = Cryptographic()
    assert x.hash(Algorithm.SHA1) is not None
    assert x.hash(Algorithm.SHA224) is not None
    assert x.hash(Algorithm.SHA256) is not None
    assert x.hash(Algorithm.SHA384) is not None
    assert x.hash(Algorithm.SHA512) is not None
    assert x.hash(Algorithm.SHA3_224) is not None
    assert x.hash(Algorithm.SHA3_256) is not None
    assert x.hash(Algorithm.SHA3_384) is not None
    assert x.hash(Algorithm.SHA3_512) is not None


# Generated at 2022-06-23 21:09:46.844797
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    p = Cryptographic()
    assert type(p.uuid(True)) is UUID
    assert type(p.uuid()) is str


# Generated at 2022-06-23 21:09:50.545864
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    uuid = provider.uuid()
    assert isinstance(uuid, str)
    assert isinstance(UUID(uuid), UUID)
    assert isinstance(provider.uuid(True), UUID)


# Generated at 2022-06-23 21:09:52.876583
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonic_phrase = Cryptographic().mnemonic_phrase()
    assert len(mnemonic_phrase.split(' ')) == 12

# Generated at 2022-06-23 21:09:55.349336
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    data1 = Cryptographic.token_bytes(1)
    data2 = Cryptographic.token_bytes(1)
    assert data1 != data2


# Generated at 2022-06-23 21:09:56.286865
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c is not None

# Generated at 2022-06-23 21:09:58.896545
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic"""
    phrase = Cryptographic.mnemonic_phrase(3, '-')
    assert phrase == "muscle-oxygen-nervous"


# Generated at 2022-06-23 21:10:00.344383
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert str(Cryptographic)
    assert Cryptographic.uuid()

# Generated at 2022-06-23 21:10:02.652859
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    result = c.token_hex()
    length = len(result)
    assert length == 64



# Generated at 2022-06-23 21:10:07.112428
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase of class Cryptographic."""
    en = Cryptographic(seed=12345)
    output = en.mnemonic_phrase(length=12, separator=' ')
    assert en.mnemonic_phrase(length=12, separator=' ') == output

# Generated at 2022-06-23 21:10:08.988865
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    data = c.token_bytes()
    assert len(data) > 0

# Generated at 2022-06-23 21:10:13.054363
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.uuid())
    print(c.hash())
    print(c.token_bytes())
    print(c.token_hex())
    print(c.token_urlsafe())
    print(c.mnemonic_phrase())

if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:10:21.380581
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.enums import Algorithm
    crypt = Cryptographic()
    assert crypt.mnemonic_phrase()
    assert crypt.uuid()
    assert crypt.hash(Algorithm.MD5)
    assert crypt.hash(Algorithm.SHA1)
    assert crypt.hash(Algorithm.SHA224)
    assert crypt.hash(Algorithm.SHA256)
    assert crypt.hash(Algorithm.SHA384)
    assert crypt.hash(Algorithm.SHA512)
    assert crypt.token_bytes()
    assert crypt.token_hex()
    assert crypt.token_urlsafe()

# Generated at 2022-06-23 21:10:22.034892
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass

# Generated at 2022-06-23 21:10:25.368637
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method uuid of class Cryptographic."""
    c = Cryptographic()
    assert isinstance(c.uuid(), str)
    assert isinstance(c.uuid(True), UUID)


# Generated at 2022-06-23 21:10:31.472940
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.exceptions import NonEnumerableError
    instance = Cryptographic('en')
    output = instance.mnemonic_phrase()
    if not isinstance(output, str):
        assert False
    output = instance.mnemonic_phrase(1)
    if not isinstance(output, str):
        assert False
    output = instance.mnemonic_phrase(0)
    if not isinstance(output, str):
        assert False


# Generated at 2022-06-23 21:10:32.874914
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """This generates a random number between 0 and 1."""
    assert Cryptographic().hash()

# Generated at 2022-06-23 21:10:34.863618
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    # This returns a random value
    test = Cryptographic().hash(Algorithm.SHA1)
    print(test)


# Generated at 2022-06-23 21:10:37.677990
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64
    assert Cryptographic().token_hex(2) == '3b38d3e0'
    assert Cryptographic().token_hex(15) == 'b0d737a802b26937'

# Generated at 2022-06-23 21:10:38.833684
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    assert a.hash() is not None


# Generated at 2022-06-23 21:10:41.804295
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    result = c.token_hex()
    assert isinstance(result, str)
    assert len(result) == 64


# Generated at 2022-06-23 21:10:45.826606
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    assert isinstance(cr.token_bytes(), bytes)
    assert isinstance(cr.token_hex(), str)
    assert isinstance(cr.token_urlsafe(), str)
    assert isinstance(cr.uuid(), str)
    assert isinstance(cr.uuid(as_object=True), UUID)

# Generated at 2022-06-23 21:10:47.871520
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    data = c.uuid()
    assert data != ''

# Generated at 2022-06-23 21:10:49.591674
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert secrets.token_urlsafe(5) == b"Rn\x9d\xd8"


# Generated at 2022-06-23 21:10:52.272319
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr = Cryptographic()
    assert len(cr.token_hex(20)) == 40
    assert len(cr.token_hex(2)) == 4
    assert len(cr.token_hex()) == 64


# Generated at 2022-06-23 21:10:56.344331
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():

    cr = Cryptographic()

    # Assert by UUID pattern
    uuid_pattern = r'^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$'

    assert re.search(uuid_pattern, cr.uuid())


# Generated at 2022-06-23 21:10:58.069244
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    #assert type(Cryptographic().uuid()) is str
    pass

# Generated at 2022-06-23 21:11:01.484094
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase of class Cryptographic."""
    provider = Cryptographic(seed=123)
    wordlist = provider.mnemonic_phrase()
    assert wordlist



# Generated at 2022-06-23 21:11:04.121904
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes(20)) == 20
    assert Cryptographic.token_bytes(20).decode("utf-8").isalnum()


# Generated at 2022-06-23 21:11:06.466537
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic"""
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase(2))

# Generated at 2022-06-23 21:11:10.363876
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    crypto.seed(0)
    assert crypto.uuid() == '4f58d924-ad52-4a1f-a0c7-f8cf6fef6951'
    assert crypto.uuid() == 'a1ef56fc-b3d3-46e2-a167-f47a59a17ca9'



# Generated at 2022-06-23 21:11:11.876704
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert crypto.token_hex() is not None


# Generated at 2022-06-23 21:11:14.222637
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # assert Cryptographic().token_hex() == 'test_Cryptographic_token_hex'
    assert False

# Generated at 2022-06-23 21:11:20.135598
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    # c.random.set_seed(42)
    print("random.set_seed(42)")
    print("UUID:", c.uuid())
    print("hash:", c.hash())
    print("token_bytes:", c.token_bytes())
    print("token_hex:", c.token_hex())
    print("token_urlsafe:", c.token_urlsafe())
    print("mnemonic_phrase:", c.mnemonic_phrase())
    print("engine:", c.engine)



# Generated at 2022-06-23 21:11:22.059969
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Generate random token
    token = Cryptographic().token_urlsafe()
    # Generate random token
    token2 = Cryptographic(seed=1234).token_urlsafe()
    assert token != token2


# Generated at 2022-06-23 21:11:29.073602
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.exceptions import NonFieldError
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    # print(Cryptographic().mnemonic_phrase())

    # print(Cryptographic().mnemonic_phrase(separator='-'))

    # print(Cryptographic().mnemonic_phrase(length=100))

    print(RussiaSpecProvider().person(gender=Gender.MALE))

test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:11:31.653432
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == '5a5fbb79-9618-43b5-89e3-c0492aa95ddb'

# Generated at 2022-06-23 21:11:33.957623
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test for method mnemonic_phrase of class Cryptographic"""
    crypt = Cryptographic()
    result = crypt.mnemonic_phrase()

    assert result is not None


# Generated at 2022-06-23 21:11:35.680798
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    crypto.mnemonic_phrase()

# Generated at 2022-06-23 21:11:37.659193
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Assert if Cryptographic.uuid had been implemented."""
    assert 'uuid' in dir(Cryptographic)



# Generated at 2022-06-23 21:11:38.812213
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    result = Cryptographic.token_bytes()
    assert isinstance(result, bytes)


# Generated at 2022-06-23 21:11:45.561025
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic(seed=9001).uuid() == '1e2efb7a-f0a5-4062-90ce-5b5a5b68042c'
    assert Cryptographic(seed=9001).uuid() == '0f3b5426-b7a6-4a6a-bfb3-cf6a4ffb4d4a'


# Generated at 2022-06-23 21:11:50.948578
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Create a new Cryptographic instance
    c = Cryptographic()

    # Create a random hexadecimal token
    hex_token = c.token_hex()

    # Make sure that the token is valid
    assert isinstance(hex_token, str)
    assert len(hex_token) == 64
    assert all(c in '0123456789abcdef' for c in hex_token)


# Generated at 2022-06-23 21:11:51.998249
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    print(crypto.token_hex())


# Generated at 2022-06-23 21:11:54.342567
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    token = provider.token_urlsafe(512)
    assert len(token) == 512
    assert isinstance(token, str)


# Generated at 2022-06-23 21:12:02.360904
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # check for a number of return values to be equal to the number of times the method is called
    # call method 100 times
    repetitions = 100
    # init empty generator
    generator = []

    # call method 100 times and append return value to generator
    for _ in range(repetitions):
        generator.append(Cryptographic.token_bytes())
    
    # init empty list
    list = []

    # create a list of unique values from the generator
    # then, if the length of the list is equal to the number of repetitions,
    # then all values are unique
    list = list(set(generator))
    assert len(list) == repetitions


# Generated at 2022-06-23 21:12:06.478978
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  from mimesis.enums import Algorithm
  provider = Cryptographic('en')
  result = provider.hash(algorithm=Algorithm.FOREST)
  print(result)
  assert len(result)==40

# Generated at 2022-06-23 21:12:11.263224
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test function to test method token_hex of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.token_hex() != crypto.token_hex()
    assert crypto.token_hex(10) != crypto.token_hex(10)
    assert crypto.token_hex() != crypto.token_hex(10)


# Generated at 2022-06-23 21:12:12.721200
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Constructor of class Cryptographic."""
    crypto = Cryptographic()


# Generated at 2022-06-23 21:12:15.796928
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    CR = Cryptographic()
    res = CR.token_bytes()
    assert type(res) == bytes
    assert len(res) == 32
    res = CR.token_bytes(256)
    assert len(res) == 256

# Generated at 2022-06-23 21:12:19.275752
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto_provider = Cryptographic()
    assert isinstance(crypto_provider.token_bytes(), bytes)
    assert isinstance(crypto_provider.token_bytes(5), bytes)



# Generated at 2022-06-23 21:12:20.827027
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase() is not None

# Generated at 2022-06-23 21:12:25.655767
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid = Cryptographic().uuid()
    print("uuid:", uuid)
    assert isinstance(uuid, str)

    uuid = Cryptographic().uuid(as_object=True)
    print("uuid:", uuid)
    assert isinstance(uuid, UUID)


# Generated at 2022-06-23 21:12:30.824600
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    assert re.match("[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}", provider.uuid())


# Generated at 2022-06-23 21:12:35.165499
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    g = Cryptographic()
    print(g.token_bytes())
    print(g.token_bytes(g.random.randint(1, 100)))


# Generated at 2022-06-23 21:12:36.279687
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    

# Generated at 2022-06-23 21:12:41.198834
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    import unittest
    class Prueba(unittest.TestCase):

        def test1(self):
            self.assertEqual(len(Cryptographic().mnemonic_phrase()), 37)
            self.assertEqual(len(Cryptographic().mnemonic_phrase(length=18)), 55)
            self.assertEqual(len(Cryptographic().mnemonic_phrase(length=18,separator='-')) ,54)
    
    unittest.main()

# Generated at 2022-06-23 21:12:41.930163
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto is not None

# Generated at 2022-06-23 21:12:52.077151
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    print(crypto.hash())
    print(crypto.hash(Algorithm.BLAKE2B_512))
    print(crypto.hash(Algorithm.BLAKE2B_384))
    print(crypto.hash(Algorithm.BLAKE2B_256))
    print(crypto.hash(Algorithm.BLAKE2S_256))
    print(crypto.hash(Algorithm.MD5))
    print(crypto.hash(Algorithm.SHA1))
    print(crypto.hash(Algorithm.SHA224))
    print(crypto.hash(Algorithm.SHA256))
    print(crypto.hash(Algorithm.SHA384))
    print(crypto.hash(Algorithm.SHA512))

# Generated at 2022-06-23 21:12:53.751932
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token_1=Cryptographic().token_urlsafe(10)
    print(token_1)



# Generated at 2022-06-23 21:12:55.927770
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    crypto = Cryptographic()
    token = crypto.token_urlsafe()
    assert len(token) > 0 and '=' not in token

# Generated at 2022-06-23 21:12:57.020098
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert(isinstance(Cryptographic.token_bytes(), bytes))


# Generated at 2022-06-23 21:12:58.719940
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    check = Cryptographic().token_hex(4)
    assert len(check) == 8
    assert isinstance(check, str)


# Generated at 2022-06-23 21:13:01.363461
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    token = crypto.token_hex()
    assert len(token) == 64

# Generated at 2022-06-23 21:13:03.613940
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cr_test = Cryptographic()
    token = cr_test.token_urlsafe()
    assert len(token)>20
    print(token)

# Generated at 2022-06-23 21:13:08.012692
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	c = Cryptographic()
	# Check if class has attribute __words
	assert hasattr(c, '_Cryptographic__words')
	# Check if class has attribute __words, with keys
	# ['normal']
	assert 'normal' in c._Cryptographic__words.keys()
	# Check if class has attribute __words, with values
	# ['normal']
	assert c._Cryptographic__words['normal']

# Unit tests for methods in class Cryptographic

# Generated at 2022-06-23 21:13:08.943266
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic().token_urlsafe(entropy=16))

# Generated at 2022-06-23 21:13:12.824965
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token_hex_return = Cryptographic_instance.token_hex()
    print(token_hex_return)

Cryptographic_instance = Cryptographic()
# now use Cryptographic_instance for all further calls to this class


# Generated at 2022-06-23 21:13:14.676287
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    h = Cryptographic().token_hex(10)
    assert type(h) == str
    assert len(h) == 20


# Generated at 2022-06-23 21:13:18.314571
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    assert cr.__class__.__name__ == "Cryptographic"
    assert isinstance(cr, Cryptographic)
    assert isinstance(cr, BaseProvider)

# Generated at 2022-06-23 21:13:21.703425
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid_key = str(Cryptographic.uuid())
    assert len(uuid_key) == 36
    assert uuid_key.count('-') == 4
    assert len(uuid_key.replace('-', '')) == 32

# Generated at 2022-06-23 21:13:23.005363
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64


cryptographic = Cryptographic()

# Generated at 2022-06-23 21:13:23.828136
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    Cryptographic().token_hex()

# Generated at 2022-06-23 21:13:24.934445
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  c = Cryptographic()
  assert c.token_hex() == c.token_hex()

# Generated at 2022-06-23 21:13:26.877472
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print("Testing class Cryptographic")
    test = Cryptographic()
    print(test)


# Generated at 2022-06-23 21:13:29.791549
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """
    Test for method uuid of class Cryptographic
    """
    uuid = Cryptographic().uuid()
    assert type(uuid) is str


# Generated at 2022-06-23 21:13:36.341911
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.uuid())
    print(c.uuid(as_object=True))

    #h = Algorithm.md5
    print(c.hash(Algorithm.md5))
    print(c.token_bytes(32))
    print(c.token_hex(32))
    print(c.token_urlsafe(32))

    print(c.mnemonic_phrase(12))
    print(c.mnemonic_phrase(12, '-'))

# Generated at 2022-06-23 21:13:38.290218
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    mask = Cryptographic()
    res = mask.token_urlsafe(32)
    assert isinstance(res, str) == True


# Generated at 2022-06-23 21:13:40.141653
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert(Cryptographic().token_bytes(10) != Cryptographic().token_bytes(10))


# Generated at 2022-06-23 21:13:41.445470
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    print(c.token_urlsafe())

# Generated at 2022-06-23 21:13:43.400346
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic()
    assert len(token.token_hex()) == 64


# Generated at 2022-06-23 21:13:52.357493
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic(seed=123126348626)
    res1 = c.token_bytes(64)

# Generated at 2022-06-23 21:13:53.486167
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    x = Cryptographic()
    print(x.uuid())

# Generated at 2022-06-23 21:13:56.958842
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    uuid_1 = crypto.uuid()
    uuid_2 = crypto.uuid()
    assert isinstance(uuid_1, str)
    assert isinstance(uuid_2, str)
    assert uuid_1 != uuid_2


# Generated at 2022-06-23 21:13:58.448757
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    instance = Cryptographic()
    token = instance.token_hex()
    assert ''.join(token)

# Generated at 2022-06-23 21:13:59.576248
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32


# Generated at 2022-06-23 21:14:02.168953
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    hash_ = c.hash(Algorithm.SHA224)
    assert isinstance(hash_, str)
    assert len(hash_) == 56


# Generated at 2022-06-23 21:14:05.634374
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    result1 = c.mnemonic_phrase()
    # print(result1)
    result2 = c.mnemonic_phrase(separator='|')
    # print(result2)

# Generated at 2022-06-23 21:14:09.163053
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert c.token_bytes() == secrets.token_bytes()
    assert c.token_bytes(128) == secrets.token_bytes(128)


# Generated at 2022-06-23 21:14:17.358557
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic(seed=123)
    assert c.token_bytes() == b'4\xc4\x17\xdb\xfe\x0bS\xeb\x14\x13\x7f\xdc\xa9\x0e\x81\x8d\xe0\xeb\x1f\x81\xc6\x9f\x90\xd1\xa7\xb6\xa2\x1f\x85\x13\x91\xb9\x9e\xfd\xb2\x1b5'


# Generated at 2022-06-23 21:14:19.501270
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    # Length = 12
    assert len(provider.mnemonic_phrase()) == 12
    assert isinstance(provider.mnemonic_phrase(), str)

# Generated at 2022-06-23 21:14:24.270718
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Instantiate class Cryptographic
    instance = Cryptographic()

    # Method mnemonic_phrase of class Cryptographic
    result = instance.mnemonic_phrase()
    print(result)
    if len(result.split(' ')) != 12:
        return False

    return True


# Generated at 2022-06-23 21:14:29.493672
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Arrange
    tester = Cryptographic('en')
    # Act
    result = tester.token_bytes(10)

    # Assert
    token_bytes = result.hex()
    assert len(result) == 10
    assert type(token_bytes) == str
    print(result)
    print()


# Generated at 2022-06-23 21:14:32.059025
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert crypto.token_hex(entropy=10) == crypto.token_hex(entropy=10)

# Generated at 2022-06-23 21:14:33.434426
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    phrase = c.mnemonic_phrase()


# Generated at 2022-06-23 21:14:35.575626
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    assert Cryptographic().hash(Algorithm.MD5)
    assert Cryptographic().hash(Algorithm.SHA256)
    assert Cryptographic().hash(Algorithm.SHA512)

# Generated at 2022-06-23 21:14:45.901263
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test that the method token_urlsafe of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    crypto = Cryptographic('en')

    # Test token_urlsafe
    byte_str = crypto.token_urlsafe(32)
    assert isinstance(byte_str, str)
    assert 32 == len(byte_str)

    byte_str = crypto.token_bytes(32)
    assert isinstance(byte_str, bytes)
    assert 32 == len(byte_str)

    hex_str = crypto.token_hex(32)
    assert isinstance(hex_str, str)
    assert 32 == len(hex_str)

    # Test Algorithm
    sha512 = crypto.hash(Algorithm.SHA512)
    assert isinstance

# Generated at 2022-06-23 21:14:51.415762
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Seed is not applicable, so we use fixed value
    # TODO: fix this
    from mimesis.enums import Algorithm, AlgorithmData
    obj = Cryptographic('seed')
    algos = {name: val for name, val in Algorithm.__members__.items()
            if len(val.value) == 1}
    for algo, data in algos.items():
        assert type(obj.hash(algo)) is str
        assert len(obj.hash(algo)) == AlgorithmData[algo]['digest_size']
        assert obj.hash(algo) == obj.hash(algo)


# Generated at 2022-06-23 21:14:54.995967
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    crypto.seed(12345)
    assert crypto.hash(algorithm=Algorithm.MD5) == '0d1d9fbbf0b45e19c31d083bf0fc17d0'

# Generated at 2022-06-23 21:14:56.044786
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print(Cryptographic())



# Generated at 2022-06-23 21:15:00.741600
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    crypto = Cryptographic()
    hash_algorithm = crypto.hash()
    assert hash_algorithm is not None
    hash_algorithm = crypto.hash(Algorithm.SHA3_512)
    assert hash_algorithm is not None

# Generated at 2022-06-23 21:15:03.765143
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypt = Cryptographic()
    crypt.__init__()
    length = 24
    assert len(crypt.mnemonic_phrase(length)) == length



# Generated at 2022-06-23 21:15:05.071172
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
	print(Cryptographic.token_bytes())
	return 1


# Generated at 2022-06-23 21:15:07.474940
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from pprint import pprint
    from mimesis import Cryptographic
    crypto = Cryptographic()
    h = crypto.token_hex()
    print(h)
    pprint(list(h))


# Generated at 2022-06-23 21:15:08.363534
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
   assert Cryptographic().hash() == Cryptographic().hash()


# Generated at 2022-06-23 21:15:09.818119
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase(length=12, separator=' ')
    print(phrase)


# Generated at 2022-06-23 21:15:12.720018
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    generator = Cryptographic()
    print(generator.token_urlsafe())


# Generated at 2022-06-23 21:15:18.199848
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test function token_hex."""
    crypto = Cryptographic('en')
    assert crypto.token_hex(32) == 'a4732d2b8a0db220a14e0e3aa3a8c847'
    assert crypto.token_hex(64) == '8d8bd077c44eb1e06485bf06e6e151d70451399768f2b6c8ed6e4b6c673ac6ac'
    assert crypto.token_hex(16) == 'f9c027047e8108f0'


# Generated at 2022-06-23 21:15:20.157593
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(100) == c.token_hex(100)

# Generated at 2022-06-23 21:15:30.875380
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():

    from mimesis.enums import Algorithm
    from mimesis.enums import CryptographicMethod
    import hashlib
    import secrets
    import uuid

    crypto = Cryptographic()

    # Test method `__init__`
    assert crypto.seed == "mimesis"
    assert crypto.random is not None

    # Test method `_validate_enum`
    assert crypto._validate_enum(None, CryptographicMethod) == 'uuid'
    assert crypto._validate_enum(Algorithm.MD5, Algorithm) == 'md5'

    # Test method `uuid`
    uuid_str = crypto.uuid()
    assert isinstance(uuid_str, str)
    assert uuid.UUID(uuid_str)

# Generated at 2022-06-23 21:15:38.452698
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Unit test for constructor of class Cryptographic."""
    # with seed
    crypto = Cryptographic(seed=123)
    phrase = crypto.mnemonic_phrase()
    assert phrase == 'itself berserk possibly discern guillotine'
    phrase = crypto.mnemonic_phrase(length=14)
    assert phrase == 'itself berserk possibly discern guillotine unify barren superb animal'
    assert crypto.hash() == 'ce2c03ad6bfac544388bafbbce80f3d3b6e12b1a7b40c0d2e03ed32f0b2daa46'
    assert crypto.hash(algorithm=Algorithm.SHA1) == '5a6f5f1c877187f982954c7675d4b8c4aab2e125'

# Generated at 2022-06-23 21:15:41.353979
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic
    """
    assert Cryptographic.uuid(as_object=False)



# Generated at 2022-06-23 21:15:49.796555
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == '5e5c9597-3d3a-41ab-a73b-ec7b48e30f96'
    assert c.uuid() == 'ddcd364b-6e0c-4f92-90cd-ec6a4d6cb853'
    assert c.uuid(as_object=True) == UUID('7c4e5f5b-d8b5-46e9-9ccd-a3c90b2ebfef')
    assert c.uuid(as_object=True) == UUID('61238d0b-7d8c-4444-a6a1-f09bc7bc57d9')



# Generated at 2022-06-23 21:15:50.868544
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid()


# Generated at 2022-06-23 21:16:01.105527
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Test function token_hex of class Cryptographic
    provider = Cryptographic(seed=123)
    result = provider.hash(algorithm=Algorithm.SHA127)
    assert result == 'c269a2b83a6f1b8db1429de3c3f3b7ae3c8fdab8'
    result = provider.token_bytes()
    expected_type = type(provider.token_bytes())
    assert type(result) == expected_type
    result = provider.token_hex()
    assert len(result) == 64
    result = provider.token_urlsafe()
    assert len(result) == 43
    result = provider.mnemonic_phrase(length=10, separator='-')

# Generated at 2022-06-23 21:16:02.576860
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token_bytes = Cryptographic().token_bytes()
    assert token_bytes is not None


# Generated at 2022-06-23 21:16:04.334161
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() != c.uuid()


# Generated at 2022-06-23 21:16:11.196908
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Unit test for method hash of class Cryptographic
    print("\n")
    print("-----Unit test for method hash of class Cryptographic-----")
    algo = Algorithm.SHA3_224
    print("The algorithm selected is: ", algo)
    hashed_string = Cryptographic().hash(algorithm=algo)
    print("The hashed string is: ", hashed_string)
    assert(len(hashed_string) == 56)
    print("The length of the hash is 56 bits.")

# Generated at 2022-06-23 21:16:19.370228
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    c.seed(123456789)
    assert c.hash("MD5") == "b9a52ab9dff9e00842a3c3d3ae1d8a92", 'MD5 hash is wrong'
    assert c.hash("SHA1") == "b47a09b8a80f826edc9847b4a0c7aec4e4c05a16", 'SHA1 hash is wrong'
    assert c.hash("SHA224") == "3ccc25217bba9d2c392a0a62512ce7d5cef81c7a090183c0c585cf9", 'SHA224 hash is wrong'

# Generated at 2022-06-23 21:16:23.047439
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    c.token_bytes()
    c.hash()
    print(c.mnemonic_phrase())

if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-23 21:16:32.358726
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == '7afc818e9249a6c4078fa1d1c0e81458'
    assert Cryptographic().hash(Algorithm.SHA1) == '948c4ecce0d7ddc8e45a8a2a04a6111546eab8c9'
    assert Cryptographic().hash(Algorithm.SHA224) == '6e4d6e1e6a1aa637e9c4e4d49d7eaf91e23c620fc45e1bde2dcb6c66'

# Generated at 2022-06-23 21:16:34.021514
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    assert cr.mnemonic_phrase() != ''


# Generated at 2022-06-23 21:16:35.283977
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    c.uuid()


# Generated at 2022-06-23 21:16:37.333457
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    test_Cryptographic = Cryptographic()
    token_byte = test_Cryptographic.token_bytes()
    print(token_byte)


# Generated at 2022-06-23 21:16:40.102504
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()

    assert len(provider.mnemonic_phrase(separator=" ")) > 0
    assert len(provider.mnemonic_phrase(separator="")) > 0

# Generated at 2022-06-23 21:16:42.323913
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert Cryptographic().token_bytes(5) != Cryptographic().token_bytes(5)


# Generated at 2022-06-23 21:16:47.159583
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print("In test_Cryptographic_token_urlsafe()")
    test = Cryptographic()
    token = Cryptographic.token_urlsafe()
    print("token_urlsafe(): ", token)
    assert isinstance(token, str)

# Generated at 2022-06-23 21:16:48.589731
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
	assert len(Cryptographic().token_hex(entropy=10)) == 20

# Generated at 2022-06-23 21:16:50.630093
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Arrange
    # Act
    _Cryptographic = Cryptographic()

    # Assert
    assert _Cryptographic is not None

# Generated at 2022-06-23 21:16:57.128212
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test for method mnemonic_phrase of class Cryptographic.

    Case 1: Length = 12 and no seperator.
    Case 2: Length = 12 and '-'.
    """
    # Case 1
    mnemonic_phrase = Cryptographic().mnemonic_phrase()
    assert len(mnemonic_phrase.split()) == 12

    # Case 2
    mnemonic_phrase = Cryptographic().mnemonic_phrase(separator='-')
    assert len(mnemonic_phrase.split('-')) == 12

# Generated at 2022-06-23 21:16:59.269121
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert (Cryptographic().uuid()) == str(uuid4())

# Generated at 2022-06-23 21:17:00.664245
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert 32 == len(Cryptographic().token_bytes())



# Generated at 2022-06-23 21:17:03.356655
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for Cryptographic.hash()."""
    validate_data_type(
        data_type=str,
        provider_class=Cryptographic,
        method='hash',
        assert_expected_type=True
    )


# Generated at 2022-06-23 21:17:04.557121
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 36


# Generated at 2022-06-23 21:17:13.379986
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
	s = Cryptographic()
	print("testing the token_bytes method of class Cryptographic")
	print("checking the length of the token:")
	assert len(s.token_bytes()) == 32
	print("checking that the token is of type bytes:")
	assert isinstance(s.token_bytes(), bytes)
	print("checking that the token is in hex format:")
	assert any(c in '0123456789abcdefABCDEF' for c in s.token_bytes()) == True
	print("\n")


# Generated at 2022-06-23 21:17:20.994467
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # test_mnemonic_phrase
    crypto = Cryptographic()
    mnemonic_phrase = crypto.mnemonic_phrase(4)
    assert isinstance(mnemonic_phrase, str)
    assert len(mnemonic_phrase) > 0
    # test_mnemonic_phrase_with_no_parameter
    mnemonic_phrase_with_no_parameter = crypto.mnemonic_phrase(4)
    assert isinstance(mnemonic_phrase_with_no_parameter, str)
    assert len(mnemonic_phrase_with_no_parameter) > 0
    # test_mnemonic_phrase_with_no_parameter_with_seperator
    mnemonic_phrase_with_no_parameter_with_seperator = crypto.mnemonic_phrase(4, 'seperator')

# Generated at 2022-06-23 21:17:22.356083
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert isinstance(c.uuid(), str)
    assert isinstance(c.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:17:24.094762
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonicPhrase = Cryptographic()
    mnemonicPhrase.mnemonic_phrase()



# Generated at 2022-06-23 21:17:25.767027
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    result = Cryptographic().mnemonic_phrase()
    print(result)
    assert type(result) == str

# Generated at 2022-06-23 21:17:28.146984
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    a = Cryptographic()
    assert type(a.uuid()) == str
    assert type(a.uuid(as_object=True)) == UUID


# Generated at 2022-06-23 21:17:39.413434
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method Cryptographic_token_urlsafe of class Cryptographic."""
    import re
    import random
    import pytest
    from mimesis.enums import Algorithm
    from mimesis.typing import Seed
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.enum_factory import EnumFactory
     
   
    hash_algos = EnumFactory(Algorithm)
    crypto = Cryptographic(Seed.create_seed())
    crypto2 = Cryptographic(Seed.create_seed())
    selection = [hash_algos.SHA224, hash_algos.SHA256, hash_algos.SHA384, hash_algos.SHA512]
    entropy = 32
    output = crypto.token_urlsafe(entropy)
    output2 = crypto2.token_url

# Generated at 2022-06-23 21:17:41.629840
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    _uuid_1 = Cryptographic().uuid()
    _uuid_2 = Cryptographic().uuid()
    assert type(_uuid_1) == type(_uuid_2) == str
    assert len(Cryptographic().uuid()) == len(_uuid_1) == len(_uuid_2) == 36



# Generated at 2022-06-23 21:17:44.201478
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    p = Cryptographic()
    assert len(p.uuid()) == len(p.uuid(True)) == 36


# Generated at 2022-06-23 21:17:44.882867
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a=Cryptographic()

# Generated at 2022-06-23 21:17:49.764024
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initialize the object
    provider = Cryptographic()
    # Get the value
    result = provider.hash(Algorithm.SHA256)
    # Check the result
    assert isinstance(result, str)
    assert result == 'c76d698e7c9ddc9791447f0920f6a5d173402cdc8382b0c2f2a1735d1e9c8cfb'

# Generated at 2022-06-23 21:17:57.178047
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    # Unit test for seed
    crypto = Cryptographic(seed = 1)

    # Unit test for uuid
    u = crypto.uuid()
    print('uuid: ', u)
    assert type(u) == str
    u = crypto.uuid(as_object=True)
    print('uuid as object: ', u)
    assert type(u) == UUID

    # unit test for hash
    h = crypto.hash(algorithm = Algorithm.MD5)
    print('MD5: ', h)
    assert len(h) == 32
    h = crypto.hash(algorithm = Algorithm.SHA1)
    print('SHA1: ', h)
    assert len(h) == 40
    h = crypto.hash(algorithm = Algorithm.SHA3_224)

# Generated at 2022-06-23 21:18:00.594914
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print("rst:")
    print(Cryptographic.mnemonic_phrase())
    print("\n")
    print("---")
    print("\n")
    print("code:")
    print(crypto.mnemonic_phrase())


# Generated at 2022-06-23 21:18:03.305495
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic().token_hex(100) != Cryptographic().token_hex(100)


# Generated at 2022-06-23 21:18:06.802964
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    result = crypto.hash()
    #print(result)
    assert result == "fd10a6f77b6ba3e3c66a9e2a6e3d6279"



# Generated at 2022-06-23 21:18:11.432731
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    a = Cryptographic()
    b = a.uuid()
    assert (len(b) == 32)
    assert (b[8] == '-')
    assert (b[13] == '-')
    assert (b[18] == '-')
    assert (b[23] == '-')


# Generated at 2022-06-23 21:18:13.686752
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=12345)
    assert c.mnemonic_phrase(length=12, separator='-') == 'history-truck-program-niece-misunderstanding-staff-decide-third-tourism-section-kid-curve'

# Generated at 2022-06-23 21:18:15.166517
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase()

# Generated at 2022-06-23 21:18:23.222089
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic"""
    # NOTE: TO TEST IF METHOD WORKS, MUST: 1) RUN SCRIPT 2) PRINT RESULTS
    a = Cryptographic()
    b = Cryptographic()
    print(f"Cryptographic().uuid() --> {a.uuid()}")
    print(f"Cryptographic().uuid() --> {b.uuid()}")
    print(f"a.uuid() == b.uuid() --> {a.uuid() == b.uuid()}")


# Generated at 2022-06-23 21:18:32.224297
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    print('\nHash using MD5:', crypto.hash(Algorithm.MD5))
    print('Hash using SHA1:', crypto.hash(Algorithm.SHA1))
    print('Hash using SHA224:', crypto.hash(Algorithm.SHA224))
    print('Hash using SHA256:', crypto.hash(Algorithm.SHA256))
    print('Hash using SHA384:', crypto.hash(Algorithm.SHA384))
    print('Hash using SHA512:', crypto.hash(Algorithm.SHA512))
    print('Hash using BLAKE2b:', crypto.hash(Algorithm.BLAKE2b))
    print('Hash using BLAKE2s:', crypto.hash(Algorithm.BLAKE2s))
    print('\nToken byte:', crypto.token_bytes())
    print

# Generated at 2022-06-23 21:18:36.612233
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Test constructor with default seed
    crypto = Cryptographic()
    assert isinstance(crypto._seed, int)

    # Test constructor with custom seed
    seed = 98765
    crypto = Cryptographic(seed)
    assert crypto._seed == seed


# Generated at 2022-06-23 21:18:37.794223
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic.uuid(), str)


# Generated at 2022-06-23 21:18:46.988823
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Constructor test
    #print("Constructor test")
    s = Cryptographic()

    assert s is not None

    # Method uuid() test
    #print("\nMethod uuid() test")
    for _ in range(3):
        uuid = s.uuid()
        assert len(uuid) != 0

    # Method hash() test
    #print("\nMethod hash() test")
    hash = s.hash()
    assert len(hash) != 0

    # Method token_bytes() test
    #print("\nMethod token_bytes() test")
    a = s.token_bytes()
    assert len(a) != 0

    # Method token_hex() test
    #print("\nMethod token_hex() test")
    b = s.token_hex()
    assert len(b) != 0



# Generated at 2022-06-23 21:18:50.131463
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    print("obj.uuid() = ", obj.uuid())
    print("obj.uuid() = ", obj.uuid())


# Generated at 2022-06-23 21:18:52.997882
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    choice = Cryptographic.token_bytes(32)
    assert len(choice) == 32
    assert isinstance(choice, bytes)

# Generated at 2022-06-23 21:18:54.126537
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes(32)) == 32


# Generated at 2022-06-23 21:18:58.710815
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    result = Cryptographic('en').mnemonic_phrase()
    assert result != ''
    assert isinstance(result, str)
    assert len(result.split()) == 12
    assert len(result.split('-')) == 12
    assert len(result.split('#')) == 12
    assert len(result.split(',')) == 12
