

# Generated at 2022-06-23 21:09:09.840459
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Create an instance of class Cryptographic
    my_random_Cryptographic = Cryptographic(seed = 12345)
    # Check that the result of method mnemonic_phrase is a string
    assert isinstance(my_random_Cryptographic.mnemonic_phrase(), str)
    # Unit test for method mnemonic_phrase for 12 words and no separator
    assert my_random_Cryptographic.mnemonic_phrase() == \
        'grow chameleon trunk gather surround mist fat bagel'
    # Unit test for method mnemonic_phrase for 12 words and separator "-"
    assert my_random_Cryptographic.mnemonic_phrase(separator = '-') == \
        'pepper-help-whip-dark-chalk-stretch-make-finger-light-breeze-spore'
    # Unit test for method mnemonic

# Generated at 2022-06-23 21:09:11.682141
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert (len(crypto.token_hex()) == 32*2) and (len(crypto.token_hex(64)) == 64*2)


# Generated at 2022-06-23 21:09:14.794009
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto_obj = Cryptographic()
    assert crypto_obj.token_hex(10) == "1bfdd7b06a4c"


# Generated at 2022-06-23 21:09:16.486340
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    for _ in range(100):
        assert len(c.hash()) == 40

# Generated at 2022-06-23 21:09:18.857141
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert type(Cryptographic()) == Cryptographic


# Generated at 2022-06-23 21:09:24.899490
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Default values of method mnemonic_phrase of class Cryptographic
    assert len(Cryptographic().mnemonic_phrase().split()) == 12
    assert len(Cryptographic().mnemonic_phrase(length=10).split()) == 10
    assert len(Cryptographic().mnemonic_phrase(separator='|').split('|')) == 12
    assert len(Cryptographic().mnemonic_phrase(length=10, separator='|').split('|')) == 10


# Generated at 2022-06-23 21:09:27.152352
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic"""
    # Write your code here
    pass



# Generated at 2022-06-23 21:09:29.741838
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    x = Cryptographic.mnemonic_phrase(length=24)
    print(x) # prints random 24 word phrase


# Generated at 2022-06-23 21:09:31.912883
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Unit test for constructor of class Cryptographic
    cr = Cryptographic('seed')
    assert cr is not None


# Generated at 2022-06-23 21:09:33.073707
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # arrange
    random_token = Cryptographic.token_bytes()
    # assert
    assert len(random_token) == 32

# Generated at 2022-06-23 21:09:41.993292
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase of class Cryptographic."""
    cr = Cryptographic(seed=42)
    # 12 words, separated by space
    assert cr.mnemonic_phrase() == 'annoying furnace cork apple aid buzzard feast burden space capricious earthy'
    # 12 words, separated by ";"
    assert cr.mnemonic_phrase(separator=';') == ('annoying;furnace;cork;apple;aid;buzzard;feast;burden'
                                                 ';space;capricious;earthy;doubtful')
    # 20 words, separated by " "

# Generated at 2022-06-23 21:09:42.763664
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    generator = Cryptographic()

# Generated at 2022-06-23 21:09:48.948968
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic."""
    test_uuid = Cryptographic().uuid()
    assert isinstance(test_uuid, str)
    assert len(test_uuid) == 36

    test_uuid_obj = UUID(test_uuid, version=4)
    assert test_uuid_obj.hex == test_uuid.replace('-', '').lower()


# Generated at 2022-06-23 21:09:50.589112
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic("en").uuid() == Cryptographic("en").uuid()


# Generated at 2022-06-23 21:09:57.299875
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic(seed=123456)
    res = c.uuid(as_object=True)
    assert res == UUID('160ceb0a-b9a6-4d0e-ad6b-a05a34a6a0e4')
    assert isinstance(res, UUID)
    res = c.uuid()
    assert res == '160ceb0a-b9a6-4d0e-ad6b-a05a34a6a0e4'
    assert isinstance(res, str)

# Generated at 2022-06-23 21:10:02.169099
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    
    a = Cryptographic()
    b = a.uuid()
    c = str(a.uuid(as_object=True))
    d = a.uuid()
    e = a.uuid()
    
    assert b != c and b != d and b != e
    assert c != d and c != e
    assert d != e

# Generated at 2022-06-23 21:10:04.842963
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex()
    assert type(c.token_hex()) == str



# Generated at 2022-06-23 21:10:06.673205
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic(seed=1)
    print(crypto.hash())



# Generated at 2022-06-23 21:10:09.084733
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    g = Cryptographic()
    print(g.token_hex())
    print(g.token_hex(10))


# Generated at 2022-06-23 21:10:11.550985
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp = Cryptographic()
    phrase = cp.mnemonic_phrase()
    assert isinstance(phrase, str)
    assert len(phrase.split(' ')) == 12

# Generated at 2022-06-23 21:10:13.825163
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    toke_hex_test = Cryptographic.token_hex()
    assert toke_hex_test.random_token


# Generated at 2022-06-23 21:10:14.815176
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 43


# Generated at 2022-06-23 21:10:26.564369
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic('en')
    result = crypto.hash(Algorithm.SHA3_224)
    assert isinstance(result, str), "Result of the hashing is not string"

    result = crypto.uuid()
    assert isinstance(result, str), "Result of the UUID is not string"

    result = crypto.token_bytes(32)
    assert isinstance(result, bytes), "Result of the bytes is not bytes"

    result = crypto.token_hex(32)
    assert isinstance(result, str), "Result of the hexadecimal is not string"

    result = crypto.token_urlsafe(32)
    assert isinstance(result, str), "Result of the URL-safe string is not string"

    result = crypto.mnemonic_phrase(12)

# Generated at 2022-06-23 21:10:30.743313
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid = Cryptographic().uuid()
    assert isinstance(uuid, str)
    assert len(uuid) == 36
    uuid_object = Cryptographic().uuid(True)
    assert isinstance(uuid_object, UUID)


# Generated at 2022-06-23 21:10:34.986772
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print("##### Start unit test for constructor of class Cryptographic")
    provider = Cryptographic()
    uuid = provider.uuid()
    assert UUID(uuid, version = 4)
    assert len(uuid.replace("-", "")) == 32
    assert isinstance(uuid, str)
    print("--- OK")


# Generated at 2022-06-23 21:10:40.579633
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    print("Test constructor of Cryptographic class: ")
    print("Random uuid: ", obj.uuid())
    print("Random hash: ", obj.hash())
    print("Random token bytes: ", obj.token_bytes())
    print("Random token hex: ", obj.token_hex())
    print("Random token url-safe: ", obj.token_urlsafe())
    print("Random mnemonic phrase: ", obj.mnemonic_phrase())

if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-23 21:10:42.777406
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic.token_bytes()
    assert isinstance(token, bytes)


# Generated at 2022-06-23 21:10:45.141664
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    result = crypto.uuid()
    assert isinstance(result, str)
    assert len(result) == 36


# Generated at 2022-06-23 21:10:54.345623
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cryptography = Cryptographic()
    user_uuid = cryptography.uuid()
    user_hash = cryptography.hash()
    user_token_bytes = cryptography.token_bytes()
    user_token_hex = cryptography.token_hex()
    user_token_urlsafe = cryptography.token_urlsafe()
    user_mnemonic_phrase = cryptography.mnemonic_phrase()
    print('user_uuid: %s', user_uuid)
    print('user_hash: %s', user_hash)
    print('user_token_bytes: %s', user_token_bytes)
    print('user_token_hex: %s', user_token_hex)
    print('user_token_urlsafe: %s', user_token_urlsafe)

# Generated at 2022-06-23 21:10:55.320046
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    pass


# Generated at 2022-06-23 21:10:59.294319
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    words = provider.mnemonic_phrase().split()
    word1 = provider.random.choice(words)
    word2 = provider.random.choice(words)
    assert word1 != word2

# Generated at 2022-06-23 21:11:00.290468
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert len(Cryptographic().mnemonic_phrase()) == 12

# Generated at 2022-06-23 21:11:02.828162
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token_bytes = Cryptographic().token_bytes()
    assert token_bytes
    assert len(token_bytes) == 32


# Generated at 2022-06-23 21:11:07.420463
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic"""
    c = Cryptographic()
    uuid = c.uuid()
    assert len(uuid) == 36
    assert '-' in uuid
    assert type(c.uuid(False)) is str
    assert type(c.uuid(True)) is UUID


# Generated at 2022-06-23 21:11:16.946055
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm
    path = "datasets/datasets/data/bytes_gen"
    key_name = Algorithm.SHA256.value
    test = True
    with open(path) as f:
        for line in f:
            _ = None
            if "test_result" in line:
                _ = line.split(":")[1]
                _ = _.strip()
                if _ == "True":
                    test_result = True
                else:
                    test_result = False
            if "input_data" in line:
                _ = line.split(":")[1]
                input_data = _.strip()
        f.close()
    if test_result == Cryptographic().hash(algorithm=Algorithm.SHA256):
        test = False
    else:
        test

# Generated at 2022-06-23 21:11:21.309742
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # All code that is not inside a method, class or if __name__ == '__main__' is ignored for coverage purposes.
    assert UUID(Cryptographic().uuid(as_object=True), version=4)
    assert isinstance(Cryptographic().uuid(), str)


# Generated at 2022-06-23 21:11:22.957082
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
  """Test Cryptographic"""
  obj = Cryptographic()
  assert obj is not None


# Generated at 2022-06-23 21:11:26.158781
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    data1 = Cryptographic('en').mnemonic_phrase()
    data2 = Cryptographic('en', seed=1).mnemonic_phrase()
    assert data1 != data2  # pylint: disable=no-member

# Generated at 2022-06-23 21:11:27.157294
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64

# Generated at 2022-06-23 21:11:28.911910
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert crypto.uuid(as_object=False)


# Generated at 2022-06-23 21:11:33.496699
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()

    phrase = provider.mnemonic_phrase()
    print(phrase)

    phrase = provider.mnemonic_phrase(3)
    print(phrase)

    phrase = provider.mnemonic_phrase(3, "-")
    print(phrase)

    phrase = provider.mnemonic_phrase(length=3, separator="-")
    print(phrase)

# Generated at 2022-06-23 21:11:35.548253
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
  c = Cryptographic()
  assert c.Meta.name == 'cryptographic'


# Generated at 2022-06-23 21:11:37.166933
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert len(crypto.token_hex()) == 64


# Generated at 2022-06-23 21:11:40.885346
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert type(Cryptographic().mnemonic_phrase()) == str
    assert type(Cryptographic().hash()) == str
    assert type(Cryptographic().token_hex()) == str
    assert type(Cryptographic().token_urlsafe()) == str
    assert type(Cryptographic().token_bytes()) == bytes
    assert type(Cryptographic().uuid()) == str

# Generated at 2022-06-23 21:11:43.600658
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    result = provider.token_hex()
    assert len(result) == 64
    assert isinstance(result, str)

# Generated at 2022-06-23 21:11:47.085355
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    i = 1
    c = Cryptographic()
    while True:
        result = c.mnemonic_phrase()
        print(result)
        if i == 10:
            break
        i += 1


# Generated at 2022-06-23 21:11:48.602024
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c != None

# Generated at 2022-06-23 21:11:49.759784
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 43



# Generated at 2022-06-23 21:11:51.511855
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	"""Unit test for constructor of class Cryptographic
	"""
	assert Cryptographic()
	assert Cryptographic(seed=0)


# Generated at 2022-06-23 21:11:53.040880
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic('en')
    assert c.hash() == "b35e2034b670f1b6c3676325d07eafed"

# Generated at 2022-06-23 21:11:54.161572
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert(len(Cryptographic().token_urlsafe()) != 0)

# Generated at 2022-06-23 21:11:57.266327
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    print(c.mnemonic_phrase())


if __name__ == '__main__':
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:12:03.688729
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash()
    assert crypto.hash(algorithm=Algorithm.SHA1)
    assert crypto.hash(algorithm=Algorithm.SHA224)
    assert crypto.hash(algorithm=Algorithm.SHA256)
    assert crypto.hash(algorithm=Algorithm.SHA384)
    assert crypto.hash(algorithm=Algorithm.SHA512)
    assert crypto.hash(algorithm=Algorithm.MD5)
    assert crypto.hash(algorithm=Algorithm.BLAKE2B)
    assert crypto.hash(algorithm=Algorithm.BLAKE2S)

# Generated at 2022-06-23 21:12:07.709271
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    data = {
        'separator': None,
        'length': 12,
    }
    a = Cryptographic.mnemonic_phrase(**data)
    assert re.match(r'^[\w\s]+$', a)

# Generated at 2022-06-23 21:12:10.393302
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    test_Obj = Cryptographic()
    assert len(test_Obj.token_urlsafe()) == 45
    assert len(test_Obj.token_urlsafe(512)) == 512 * 2

# Generated at 2022-06-23 21:12:11.435232
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crytg = Cryptographic()
    assert crytg.hash() in [crytg.uuid()]


# Generated at 2022-06-23 21:12:16.122594
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # just one test.
    random_text = Cryptographic().token_urlsafe()
    assert type(random_text) == type('a')
    # more than one tests.
    random_text = Cryptographic().token_urlsafe()
    print(random_text)
    print(type(random_text))
    assert type(random_text) == type('a')

# Generated at 2022-06-23 21:12:24.878901
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid_fuzz = []
    for _ in range(20):
        uuid_fuzz.append(Cryptographic().uuid())

    hash_uuid_fuzz = [hash(uuid) for uuid in uuid_fuzz]

    assert len(hash_uuid_fuzz) == len(set(hash_uuid_fuzz))

    # check that the argument `as_object` works:
    uuid_object = Cryptographic().uuid(as_object=True)

    assert isinstance(uuid_object, uuid.UUID)


# Generated at 2022-06-23 21:12:29.293648
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  gen = Cryptographic()
  tok = gen.token_urlsafe(32)
  assert len(tok) == 43, len(tok)
  assert tok.isalnum(), tok
  assert tok[0] != '-', tok
  assert tok[-1] != '-', tok


# Generated at 2022-06-23 21:12:39.619558
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.mnemonic_phrase(length=16) == "jacket note fish eager guitar noise hero tremble clap sad pattern square plant"
    assert c.mnemonic_phrase(length=16, separator=".") == "jacket.note.fish.eager.guitar.noise.hero.tremble.clap.sad.pattern.square.plant"
    assert c.hash() == "4d381c57f7b10f846b7a720a1dc2c7a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5"

# Generated at 2022-06-23 21:12:40.722385
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print('unit_test_result:', Cryptographic.token_bytes())


# Generated at 2022-06-23 21:12:41.739597
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert len(crypto.token_hex())

# Generated at 2022-06-23 21:12:44.177521
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert isinstance(Cryptographic.token_hex(), str)
    assert isinstance(Cryptographic.token_hex(), str)

# Generated at 2022-06-23 21:12:46.214341
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    assert type(phrase) is str



# Generated at 2022-06-23 21:12:52.077060
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    Cryptographic().hash(algorithm=Algorithm.MD5)
    Cryptographic().hash(algorithm=Algorithm.SHA_1)
    Cryptographic().hash(algorithm=Algorithm.SHA_224)
    Cryptographic().hash(algorithm=Algorithm.SHA_256)
    Cryptographic().hash(algorithm=Algorithm.SHA_384)
    Cryptographic().hash(algorithm=Algorithm.SHA_512)

test_Cryptographic_hash()


# Generated at 2022-06-23 21:12:53.076630
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print('f')

# Generated at 2022-06-23 21:12:55.327863
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    x = cr.hash()
    assert x != None
    assert x != ''
    assert isinstance(x, str)
    assert len(x) == 64

# Generated at 2022-06-23 21:12:57.423049
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert len(c.token_hex()) == 64
    assert len(c.token_hex(entropy=50)) == 100
    

# Generated at 2022-06-23 21:13:01.734360
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase() != ""
    assert crypto.mnemonic_phrase(12) != ""
    assert crypto.mnemonic_phrase(12, "en") != ""
    assert crypto.mnemonic_phrase(12, "") != ""
    assert crypto.mnemonic_praze() == ""
    assert crypto.mnemonic_praze(12) == ""
    assert crypto.mnemonic_praze(12, "en") == ""
    assert crypto.mnemonic_praze(12, "") == ""

# Generated at 2022-06-23 21:13:05.158251
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    # This assert depends of the seed given
    assert c.token_bytes(16).hex() == "3dc7a2fc1cd97d7d60eb0fa59a7cfb88"


# Generated at 2022-06-23 21:13:13.261258
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    seed = "42"
    expected = "word-word-word-word-word-word-word-word-word-word-word-word"
    #Create a dictionary of words
    words_dict = {"normal": ["word"]*40}
    #Create a cryptographic object to use
    crypto_object = Cryptographic(seed=seed)
    #Call the method mnemonic_phrase with length 12
    crypto_object._data["words"] = words_dict
    actual = crypto_object.mnemonic_phrase(length=12)
    assert(actual == expected)

# Generated at 2022-06-23 21:13:20.749483
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cp = Cryptographic()
    assert cp.uuid() == '8d7dbf60-0931-4e5e-b8c7-d2ebb80c7f3b'
    assert cp.mnemonic_phrase() == 'urge agree light corn office desk street'
    assert cp.mnemonic_phrase(5) == 'urge agree light corn office'
    assert cp.mnemonic_phrase(length=6, separator='-') == 'urge-agree-light-corn-office-desk'
    assert cp.hash(algorithm=Algorithm.SHA256) == 'a6c0d6f9954e7828475e6494df698b7783bbd54a6dd9a20f2e6a86d0d1ef27ab'

# Generated at 2022-06-23 21:13:22.400201
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()

    # length of token
    entropy = 32
    token = c.token_urlsafe(entropy)
    assert(len(token) == entropy * 3 // 4)

# Generated at 2022-06-23 21:13:23.909259
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert isinstance(c.token_hex(), str)


# Generated at 2022-06-23 21:13:30.559923
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Test without seed
    c = Cryptographic()
    uuid = c.uuid()
    print("UUID: {}".format(uuid))

    # Test with seed
    c = Cryptographic(seed=42)
    uuid = c.uuid()
    print("UUID: {}".format(uuid))

    # Test hash()
    # Pass None as argument
    hash = c.hash()
    print("Hash: {}".format(hash))

    # Test token_bytes()
    # Pass None as argument
    token_bytes = c.token_bytes()
    print("Token bytes: {}".format(token_bytes))

    # Test token_hex()
    # Pass None as argument
    token_hex = c.token_hex()
    print("Token hex: {}".format(token_hex))

    # Test token

# Generated at 2022-06-23 21:13:32.318113
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr = Cryptographic()
    assert len(cr.token_hex()) == 64


# Generated at 2022-06-23 21:13:33.200745
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert isinstance(c, Cryptographic)
    

# Generated at 2022-06-23 21:13:37.194762
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c  = Cryptographic()
    c.seed(1)
    c.uuid(as_object=True)
    c.uuid()

# Generated at 2022-06-23 21:13:39.390144
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto_provider = Cryptographic(seed=42)
    assert crypto_provider.token_hex(6) == "06d5e6ea"

# Generated at 2022-06-23 21:13:41.705790
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    for _ in range(5):
        print(crypto.mnemonic_phrase())


# Generated at 2022-06-23 21:13:43.630338
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    ## For example,
    assert Cryptographic.token_urlsafe(4) == secrets.token_urlsafe(4)

# Generated at 2022-06-23 21:13:44.589529
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid().__class__ == str

# Generated at 2022-06-23 21:13:51.814568
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """
    Unit test for method mnemonic_phrase() of the class Cryptographic
    """
    # Default unit test
    provider = Cryptographic()
    result = provider.mnemonic_phrase()
    print(result)
    # Length of mnemonic phrase
    result = provider.mnemonic_phrase(length=6)
    print(result)
    # Separator of words
    result = provider.mnemonic_phrase(separator="-")
    print(result)
    # Length of mnemonic phrase and separator of words
    result = provider.mnemonic_phrase(length=5, separator="-")
    print(result)

# Generated at 2022-06-23 21:13:53.790659
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    print(cr.hash())


# Generated at 2022-06-23 21:13:54.860303
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert crypto.token_bytes()


# Generated at 2022-06-23 21:13:56.424834
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid1 = Cryptographic().uuid()
    assert isinstance(uuid1,str)
    assert isinstance(Cryptographic().uuid(True),UUID)

# Generated at 2022-06-23 21:14:03.819834
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from pprint import pprint
    from mimesis.enums import Algorithm
    from mimesis.builtins import Cryptographic

    cr = Cryptographic()

    pprint(cr.token_urlsafe(entropy=32))
    pprint(cr.token_urlsafe(entropy=64))
    pprint(cr.token_urlsafe(entropy=128))

    pprint(cr.hash(algorithm=Algorithm.SHA1))
    pprint(cr.hash(algorithm=Algorithm.SHA256))
    pprint(cr.hash(algorithm=Algorithm.SHA512))

    #   pprint(cr.token_bytes(entropy=32))
    pprint(cr.token_hex(entropy=32))
    pprint(cr.mnemonic_phrase())


# Generated at 2022-06-23 21:14:06.248284
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = Cryptographic('se', 12345)
    assert data.hash() == '3dde29f65287ee82c8b75a1b9907d9e9bf31f91c97f6ad7b67d4e2e4b6ecb8eb'


# Generated at 2022-06-23 21:14:08.603116
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method ``uuid``."""
    assert isinstance(Cryptographic().uuid(), str)



# Generated at 2022-06-23 21:14:09.834100
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    cr.uuid()


# Generated at 2022-06-23 21:14:10.828998
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(),str)

# Generated at 2022-06-23 21:14:14.385014
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex()
    assert isinstance(c.token_hex(), str)
    assert len(c.token_hex()) == 64


# Generated at 2022-06-23 21:14:15.415410
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert isinstance(Cryptographic(), Cryptographic)

# Generated at 2022-06-23 21:14:23.399572
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    from mimesis.providers.base import Provider

    ct = Cryptographic(seed=123)

    # Simplest implementation
    token2 = ct.token_urlsafe()
    assert type(token2) is str
    assert len(token2) is 43

    # With seed
    p = Provider(seed=123)
    token3 = ct.token_urlsafe(entropy=p.random.randint(0, 100))
    assert type(token3) is str
    assert len(token3) is 17

    # No seed
    token4 = ct.token_urlsafe(entropy=p.random.randint(0, 100))
    assert type(token4) is str
    assert len(token4) is 15

    assert token2 != token3
   

# Generated at 2022-06-23 21:14:25.383235
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    cr = Cryptographic(seed=1234567890987654321)
    # Test
    for _ in range(10):
        assert isinstance(cr.hash(), str)


# Generated at 2022-06-23 21:14:28.498894
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    for i in range(10):
        phrases = Cryptographic().mnemonic_phrase()
        print(phrases)
        print(phrases.split())


# Generated at 2022-06-23 21:14:32.236120
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
  from mimesis.enums import Algorithm
  hasher = Cryptographic()
  assert type(hasher.hash(algorithm=Algorithm.MD5)) == str
  assert type(hasher.token_bytes()) == bytes
  assert type(hasher.token_hex()) == str
  assert len(hasher.uuid()) == 36
  assert len(hasher.uuid(as_object=False)) == 36
  assert len(hasher.uuid(as_object=True)) == 36
  assert len(hasher.mnemonic_phrase()) == 12
  assert len(hasher.mnemonic_phrase(length=6)) == 6
  assert len(hasher.mnemonic_phrase(length=6, separator='.')) == 6

# Generated at 2022-06-23 21:14:34.042874
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    print(c.hash(Algorithm.SHA224))


# Generated at 2022-06-23 21:14:37.830223
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
        c = Cryptographic()
        assert c.token_bytes(32) != c.token_bytes(32)
        assert len(c.token_bytes(32)) == 32


# Generated at 2022-06-23 21:14:40.773529
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis import Cryptographic

    crypto = Cryptographic()
    mnemonic_phrase = crypto.mnemonic_phrase()

    assert(type(mnemonic_phrase) is str)

# Generated at 2022-06-23 21:14:43.885542
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    print(c.uuid())
    print(c.uuid(True))
    uuid = c.uuid()
    assert len(uuid) == 36


# Generated at 2022-06-23 21:14:46.553947
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
	c = Cryptographic()
	f=c.token_bytes(10)
	print(f)
	assert len(f) == 20
	

# Generated at 2022-06-23 21:14:49.665538
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash()
    assert crypto.hash(algorithm = Algorithm.SHA256)
    return


# Generated at 2022-06-23 21:14:51.168783
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Locale

    c = Cryptographic(Locale.EN)
    word = c.mnemonic_phrase()
    assert word is not None

# Generated at 2022-06-23 21:14:53.729266
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe()
    assert(type(token)) == type(bytes())
    assert(len(token)) == 64

# Generated at 2022-06-23 21:14:56.748977
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    for i in range(100):
        try:
            r = Cryptographic().token_hex(16)
            assert isinstance(r, str)
        except NotImplementedError:
            pass
        except Exception:
            raise AssertionError("Incorrect hash generated.")


# Generated at 2022-06-23 21:15:07.220774
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
  from mimesis.enums import Algorithm
  from mimesis.providers.datetime import Datetime
  from mimesis.providers.math import Math
  from mimesis.providers.misc import Misc
  from mimesis.providers.text import Text
  from mimesis.enums import Gender
  from mimesis.providers.person import Person
  from mimesis.providers.business import Business
  from mimesis.providers.internet import Internet
  from mimesis.providers.payment import Payment
  from mimesis.providers.food import Food
  from mimesis.providers.unit import Unit
  from mimesis.providers.code import Code
  from mimesis.providers.transport import Transport
  from mimesis.providers.address import Address

# Generated at 2022-06-23 21:15:09.369561
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    t0 = Cryptographic().hash()
    t1 = Cryptographic().hash()

    assert type(t0) == str
    assert type(t1) == str


# Generated at 2022-06-23 21:15:11.386407
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    c.token_bytes()

# Generated at 2022-06-23 21:15:14.669361
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	hasher = hashlib.sha256()
	t = str(Cryptographic.uuid())
	hasher.update(t.encode())
	print(hasher.hexdigest())

test_Cryptographic()

# Generated at 2022-06-23 21:15:20.693013
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic"""

    # Arrange
    text = Cryptographic()

    # Act
    result = text.mnemonic_phrase(length = 3)

    # Assert
    assert isinstance(result, str)
    assert len(result.split(' ')) == 3

# Generated at 2022-06-23 21:15:23.469892
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    assert isinstance(Cryptographic.token_bytes(), bytes)  # type: ignore



# Generated at 2022-06-23 21:15:26.934046
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    _Cryptographic = Cryptographic()
    _Cryptographic = Cryptographic(seed=48991423)
    _Cryptographic = Cryptographic(seed='seed')
    _Cryptographic = Cryptographic(seed=None)


# Generated at 2022-06-23 21:15:28.374010
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    
    result = provider.hash()
    assert result
    

# Generated at 2022-06-23 21:15:30.128586
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.mnemonic_phrase())
    print(c.hash())


# Generated at 2022-06-23 21:15:32.617050
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()

    assert c.token_urlsafe() == c.token_urlsafe()
    assert len(c.token_urlsafe()) == 43


# Generated at 2022-06-23 21:15:35.825985
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    new_Cryptographic = Cryptographic()
    value = new_Cryptographic.uuid()
    assert isinstance(value, str)
    assert len(value) == 36
    assert value.count("-") == 4


# Generated at 2022-06-23 21:15:42.600663
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test for method mnemonic_phrase of class Cryptographic."""
    crypto = Cryptographic()
    result1 = crypto.mnemonic_phrase()
    result2 = crypto.mnemonic_phrase(separator='_')
    result3 = crypto.mnemonic_phrase(length=10)

    assert len(result1.split()) == 12
    assert len(result2.split()) == 12
    assert len(result3.split()) == 10


# Generated at 2022-06-23 21:15:46.496240
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic(provides='cryptographic')
    assert crypto.token_bytes(100)
    assert crypto.token_bytes()
    assert crypto.token_bytes(24)
    assert crypto.token_bytes(entropy=24)
    assert crypto.token_bytes(entropy=32)


# Generated at 2022-06-23 21:15:49.757930
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    for _ in range(3):
        c.mnemonic_phrase(length=3)
        c.mnemonic_phrase(length=3, separator=" ")
        c.mnemonic_phrase(length=3, separator=" - ")

# Generated at 2022-06-23 21:15:51.508360
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert crypto.uuid() == crypto.uuid()


# Generated at 2022-06-23 21:15:54.344790
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    import mimesis
    c = mimesis.Cryptographic()
    assert isinstance(c, mimesis.Cryptographic)


# Generated at 2022-06-23 21:15:58.377505
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for the method ``token_hex`` of the class ``Cryptographic``."""
    tokenizer = Cryptographic()
    token = tokenizer.token_hex()
    assert len(token) == 64
    assert isinstance(token, str)


# Generated at 2022-06-23 21:16:01.510961
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    h = crypto.hash(algorithm=Algorithm.SHA256)
    assert isinstance(h, str)


# Generated at 2022-06-23 21:16:02.471941
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert Cryptographic.mnemonic_phrase() is not None

# Generated at 2022-06-23 21:16:12.796915
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    # static_var.seed(0)
    # Not sure if this is the correct way to call the method
    # since the parameter passed is an enum object
    # The following example works:
    assert Cryptographic().hash(Algorithm.MD5) == '730bf1ab4b21d0f42cde8a6cacf9d7dc'
    assert Cryptographic().hash(Algorithm.MD4) == '2d2d88b857a0a9f7f54d2b0dad7be0f0'
    assert Cryptographic().hash(Algorithm.SHA1) == '9a7fe0a357c837b8efa34e65ca7db3e3b390d152'

# Generated at 2022-06-23 21:16:14.058055
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    token = provider.token_urlsafe()
    assert isinstance(token, str)

# Generated at 2022-06-23 21:16:15.883171
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic('en')
    assert crypto.mnemonic_phrase() == "onion octopus squirrel resist rhythm"


# Generated at 2022-06-23 21:16:16.518937
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid()


# Generated at 2022-06-23 21:16:20.470393
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    p = Cryptographic()
    assert p.hash() == hashlib.sha256(p.uuid().encode()).hexdigest()


# Generated at 2022-06-23 21:16:22.373613
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert c.token_bytes(32) is not None


# Generated at 2022-06-23 21:16:25.216869
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print("\ntest_Cryptographic_mnemonic_phrase()")
    cr = Cryptographic()
    print(cr.mnemonic_phrase())


# Generated at 2022-06-23 21:16:29.483306
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr = Cryptographic()
    entropy = cr.token_hex()
    assert isinstance(entropy, str)
    assert len(entropy) == 64
    entropy = cr.token_hex(8)
    assert isinstance(entropy, str)
    assert len(entropy) == 16

# Generated at 2022-06-23 21:16:30.414683
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    pass


# Generated at 2022-06-23 21:16:32.017030
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    x = Cryptographic().token_bytes()
    assert len(x) == 32


# Generated at 2022-06-23 21:16:39.283375
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash."""

# Generated at 2022-06-23 21:16:51.090799
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from .Mimesis import Mimesis_nometadata
    print('Testing method mnemonic_phrase of class Cryptographic')

    # Test a default case
    phrase=Mimesis_nometadata.Cryptographic().mnemonic_phrase()

    print('     Testing default phrase:',phrase)
    assert len(phrase)!=0, "Default phrase has no length"
    assert phrase.count(' ')==11, "Default phrase has wrong number of words"

    # Test a single-word case
    phrase=Mimesis_nometadata.Cryptographic().mnemonic_phrase(length=1)

    print('     Testing single-word phrase:',phrase)
    assert len(phrase)!=0, "Single-word phrase has no length"
    assert phrase.count(' ')==0, "Single-word phrase has space"

    # Test a two

# Generated at 2022-06-23 21:16:54.668965
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(16)) == 16
    assert len(Cryptographic().token_bytes(64)) == 64


# Generated at 2022-06-23 21:17:01.669689
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Call function with default value
    token = Cryptographic().token_urlsafe()
    assert token is not None
    assert len(token) >= 32
    assert len(token) <= 128
    assert len(token.split('=')) == 1
    assert len(token.split('_')) == 3
    assert len(token.split('-')) == 3

    # Call function with 48 as input
    token = Cryptographic().token_urlsafe(48)
    assert token is not None
    assert len(token) >= 48
    assert len(token) <= 128
    assert len(token.split('=')) == 1
    assert len(token.split('_')) == 6
    assert len(token.split('-')) == 6


# Generated at 2022-06-23 21:17:02.420393
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
	Cryptographic().token_hex()

# Generated at 2022-06-23 21:17:05.150477
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cryp = Cryptographic()

    assert cryp.uuid() == str(uuid4())
    assert cryp.uuid(as_object=True) == uuid4()


# Generated at 2022-06-23 21:17:07.091054
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() != Cryptographic().uuid()


# Generated at 2022-06-23 21:17:09.430612
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    hex = Cryptographic().token_hex(512)
    assert(len(hex) == 1024)

# Generated at 2022-06-23 21:17:12.792640
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid()
    assert isinstance(Cryptographic().uuid(), str)
    assert isinstance(Cryptographic().uuid(True), UUID)


# Generated at 2022-06-23 21:17:14.566213
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cg = Cryptographic()
    cg.hash(algorithm=Algorithm.SHA_512)

# Generated at 2022-06-23 21:17:15.401231
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	x = Cryptographic()
	assert type(x) == Cryptographic

# Generated at 2022-06-23 21:17:16.099876
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic().token_hex(3) == 'b89a0b0c'

# Generated at 2022-06-23 21:17:17.276760
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    x = Cryptographic()
    x.token_bytes()


# Generated at 2022-06-23 21:17:18.468885
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    print(crypto.hash())


# Generated at 2022-06-23 21:17:22.134934
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cp = Cryptographic()
    x = cp.token_hex(32)
    outputstr = len(x)
    assert outputstr == 64


# Generated at 2022-06-23 21:17:26.069632
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # GIVEN
    crypto = Cryptographic()

    # WHEN
    c_uuid = crypto.uuid()

    # THEN
    assert isinstance(c_uuid, str)
    assert len(c_uuid) == 36
    assert c_uuid.count('-') == 4


# Generated at 2022-06-23 21:17:28.990555
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm
    mnem = Cryptographic().token_hex(20)
    assert mnem == '9b9a6b0f87929488c2dbfcd1183cf'


# Generated at 2022-06-23 21:17:30.671459
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    m = Cryptographic()
    assert m.hash() is not None


# Generated at 2022-06-23 21:17:32.214669
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert uuid4() == Cryptographic().uuid(True)
	

# Generated at 2022-06-23 21:17:33.920249
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # TODO: Implement unit test
    raise NotImplementedError

# Generated at 2022-06-23 21:17:39.756567
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    #with pytest.raises(TypeError):
    #    Cryptographic()
    #crypto = Cryptographic(seed="test")
    #assert isinstance(crypto, Cryptographic)
    #assert crypto._seed == "test"
    #assert crypto._random is not None
    
    crypto = Cryptographic()
    assert isinstance(crypto, Cryptographic)
    assert crypto._seed is not None
    assert crypto._random is not None


# Generated at 2022-06-23 21:17:41.893471
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase(12) == 'definitely swamp balance special unique loan just verify tuition best skate'
    assert c.mnemonic_phrase(12, '-') == 'train-midnight-number-may-rhythm-cheerful-thermal-transport-debt-turn-rabbit-smile'

# Generated at 2022-06-23 21:17:48.577960
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Testing method Cryptographic.mnemonic_phrase with default arguments
    assert len(Cryptographic().mnemonic_phrase().split()) == 12
    # Testing method Cryptographic.mnemonic_phrase with different arguments
    assert len(Cryptographic().mnemonic_phrase(24).split()) == 24
    assert len(Cryptographic().mnemonic_phrase(length=12).split()) == 12
    assert len(Cryptographic().mnemonic_phrase(separator=' ').split()) == 12
    assert len(Cryptographic().mnemonic_phrase(24, ' ').split()) == 24

# Generated at 2022-06-23 21:17:51.658211
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a = Cryptographic().token_hex(41)
    print(len(a))
    print(a)

if __name__ == "__main__":
    test_Cryptographic_token_hex()

# Generated at 2022-06-23 21:17:53.431392
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    assert len(Cryptographic.uuid()) == 36



# Generated at 2022-06-23 21:18:03.412270
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.builtins import Cryptographic
    from mimesis.enums import Algorithm
    from mimesis.exceptions import NonEnumerableError

    crypto = Cryptographic()
    print(crypto.mnemonic_phrase())
    # 'graphic scale fox radio bingo record'

    print(crypto.mnemonic_phrase(separator='_', length=10))
    # 'hold_talk_glove_margin_town_cloud_planet_junk_sugar_cycle'

    # Generate random hash
    print(crypto.hash())
    # 'c7e49acddd9140d41e299472c2a7d2de'

    # Generate hash with algorithm
    print(crypto.hash(algorithm=Algorithm.SHA1))
    # 'a3a7e37d55caa

# Generated at 2022-06-23 21:18:12.867849
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    obj = Cryptographic()
    assert obj.mnemonic_phrase()
    assert len(obj.mnemonic_phrase()) == 12
    assert obj.mnemonic_phrase(length=6)
    assert len(obj.mnemonic_phrase(length=6)) == 6
    assert obj.mnemonic_phrase(separator='-')
    assert '-' in obj.mnemonic_phrase(separator='-')
    assert obj.mnemonic_phrase(length=6, separator='-')
    assert len(obj.mnemonic_phrase(length=6, separator='-')) == 6
    assert '-' in obj.mnemonic_phrase(length=6, separator='-')


if __name__ == '__main__':
    print(Cryptographic.uuid())
    print(Cryptographic().hash())

# Generated at 2022-06-23 21:18:14.519864
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    with Cryptographic() as crypto:
        assert isinstance(crypto, Cryptographic)


# Generated at 2022-06-23 21:18:16.380479
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    c.token_hex(32)
    assert (c.token_hex(32), 32)


# Generated at 2022-06-23 21:18:23.511562
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'a120c07d06a70a0f2eee9d24f5e5ce04f8796c57db6a0bdd7c17e8c8da7e0cb9'
    assert crypto.hash(Algorithm.MD5) == 'a120c07d06a70a0f2eee9d24f5e5ce04'


# Generated at 2022-06-23 21:18:25.278760
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    for i in range(5):
        assert len(crypto.token_urlsafe()) == 43

# Generated at 2022-06-23 21:18:32.177331
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method uuid of class Cryptographic.
    Test data is generated by method uuid of class Cryptographic
    """
    assert re.match('^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', Cryptographic().uuid())



# Generated at 2022-06-23 21:18:34.550287
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cry = Cryptographic()
    cry.mnemonic_phrase(length=12, separator='*')


# Generated at 2022-06-23 21:18:35.366660
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic is not None

# Generated at 2022-06-23 21:18:39.476425
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """ Unit test for method hash of class Cryptographic """
    crypto = Cryptographic()
    assert isinstance(crypto.hash(Algorithm.MD5), str)
    assert isinstance(crypto.hash(Algorithm.SHA224), str)
    assert isinstance(crypto.hash(Algorithm.SHA256), str)
    assert isinstance(crypto.hash(Algorithm.SHA384), str)
    assert isinstance(crypto.hash(Algorithm.SHA512), str)


# Generated at 2022-06-23 21:18:41.588466
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    data = c.hash(Algorithm.SHA256)

    assert(data)


# Generated at 2022-06-23 21:18:44.230517
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    UUID4 = str(Cryptographic().uuid())
    assert UUID4.replace('-', ''), 'not a valid UUID4'


# Generated at 2022-06-23 21:18:48.479568
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic(seed=424242)
    assert c.token_urlsafe() == 'QwhgBsOtWTdZAm_hJ_NjY0sTv171SUyQrED3qTjMkpk'


# Generated at 2022-06-23 21:18:49.919878
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert Cryptographic.token_urlsafe() is not None

# Generated at 2022-06-23 21:18:51.732341
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cr = Cryptographic()
    print(cr.token_bytes())


# Generated at 2022-06-23 21:18:53.721361
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic.token_urlsafe()
    assert type(token) == str



# Generated at 2022-06-23 21:18:55.302828
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic().token_bytes()
    assert type(token) == bytes


# Generated at 2022-06-23 21:18:56.115372
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert(isinstance(Cryptographic(), Cryptographic))

# Generated at 2022-06-23 21:19:04.385444
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
	tests = [
		{
			'entropy': 32,
			'expected': b'\xa0\x8a\x9c\x9f\xa1\x97\x98\xea\x03\xdd\xb8\xf0\xf9\xce\xc4\xf4dg\xa4\xea\x1b\xbf;\xdd\xe9\xcb\xc9\x07\x8d\xab\xf5'
		},
		{
			'entropy': 10,
			'expected': b'\xec\xdc\xc1\xac\x05\n\x9c\xcd\xfe\xde'
		}
	]

	provider = Cryptographic()
	