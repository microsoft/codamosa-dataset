

# Generated at 2022-06-23 21:09:00.253202
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    c.token_urlsafe()

# Generated at 2022-06-23 21:09:01.789158
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-23 21:09:06.408029
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic.uuid(as_object=False) == '7ca967b9-a7b6-4b27-a5b5-40c0ce0d5b09'
    assert Cryptographic.uuid(as_object=True) == UUID('7ca967b9-a7b6-4b27-a5b5-40c0ce0d5b09')


# Generated at 2022-06-23 21:09:09.355756
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64
    assert len(Cryptographic.token_hex(16)) == 32
    assert len(Cryptographic.token_hex(32)) == 64
    assert len(Cryptographic.token_hex(64)) == 128


# Generated at 2022-06-23 21:09:10.589840
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    result = crypto.hash()
    assert result != ''


# Generated at 2022-06-23 21:09:13.881257
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic"""
    assert Cryptographic.token_hex() == secrets.token_hex()


# Generated at 2022-06-23 21:09:17.593823
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Testing method token_hex of class Cryptographic."""
    cr = Cryptographic()
    token = cr.token_hex(16)
    assert len(token) == 32

    token = cr.token_hex(32)
    assert len(token) == 64


# Generated at 2022-06-23 21:09:22.551492
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    cryptographer = Cryptographic()
    result1 = cryptographer.uuid(as_object=True)
    result2 = cryptographer.uuid(as_object=False)
    assert (result1.hex == result2), \
        "cryptographer.uuid() method did not work correctly"


# Generated at 2022-06-23 21:09:25.218243
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    obj = Cryptographic()
    result = obj.mnemonic_phrase()
    assert isinstance(result, str)
    assert len(result.split(' ')) == 12


# Generated at 2022-06-23 21:09:36.572565
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("\nTesting hash() of class Cryptographic")

    c=Cryptographic()

    hashes = {
        Algorithm.BLAKE2B: 64,
        Algorithm.BLAKE2S: 64,
        Algorithm.MD5: 32,
        Algorithm.SHA1: 40,
        Algorithm.SHA224: 56,
        Algorithm.SHA256: 64,
        Algorithm.SHA384: 96,
        Algorithm.SHA3_224: 56,
        Algorithm.SHA3_256: 64,
        Algorithm.SHA3_384: 96,
        Algorithm.SHA3_512: 128,
        Algorithm.SHA512: 128,
        Algorithm.SHAKE_128: 64,
        Algorithm.SHAKE_256: 64,
    }


# Generated at 2022-06-23 21:09:38.859520
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid_object = Cryptographic.uuid(as_object=True)
    assert isinstance(uuid_object, UUID)

    uuid_str = Cryptographic.uuid()
    assert isinstance(uuid_str, str)



# Generated at 2022-06-23 21:09:47.767484
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # This is a unit test for method token_urlsafe of class Cryptographic
    from mimesis.enums import Algorithm  # noqa: E501
    cr = Cryptographic()
    cr.token_urlsafe()
    cr.mnemonic_phrase()
    cr.mnemonic_phrase(length=123)
    cr.mnemonic_phrase(separator='.')
    cr.mnemonic_phrase(length=123, separator='.')
    cr.hash(Algorithm.SHA3_512)
    cr.uuid()
    cr.uuid(as_object=True)
    cr.token_bytes()
    cr.token_hex()

# Generated at 2022-06-23 21:09:51.963188
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(16) != c.token_hex(16)
    assert c.token_hex(16) != c.token_hex(15)
    assert c.token_hex(16) != c.token_hex(17)


# Generated at 2022-06-23 21:09:54.517526
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for Cryptographic.uuid() method."""
    cryptographic = Cryptographic()
    assert cryptographic.uuid()
    assert cryptographic.uuid(as_object=True)

# Generated at 2022-06-23 21:09:57.214122
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 32
    assert len(Cryptographic.token_bytes(24)) == 24
    assert Cryptographic.token_bytes(0) == b''


# Generated at 2022-06-23 21:09:59.728143
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(help(Cryptographic.token_hex))
    token =  Cryptographic.token_hex()
    assert isinstance(token,str)
    assert len(token) == 64
    print(token)

# Generated at 2022-06-23 21:10:01.220216
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    data = Cryptographic().token_bytes()
    assert data is not None


# Generated at 2022-06-23 21:10:03.451618
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypt = Cryptographic()
    result = crypt.token_hex()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:10:05.332749
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    d = Cryptographic()
    print(d.mnemonic_phrase(10))

# Generated at 2022-06-23 21:10:08.663320
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    #test object instantiation
    crypto = Cryptographic()
    #test object type
    assert type(crypto) is Cryptographic
    #test attribute of crypto
    assert crypto.random.seed == crypto.seed


# Generated at 2022-06-23 21:10:10.488832
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    a = Cryptographic()
    assert a.mnemonic_phrase() != a.mnemonic_phrase()

# Generated at 2022-06-23 21:10:11.577189
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) >= 33
    assert len(Cryptographic().token_urlsafe(10)) == 10

# Generated at 2022-06-23 21:10:15.761289
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm

    provider = Cryptographic()
    assert provider.uuid() == 'bd59b4f4-4fc4-4a79-ab50-1bb4dfa966b8'
    assert isinstance(provider.uuid(True), UUID)



# Generated at 2022-06-23 21:10:18.629401
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():

	cm = Cryptographic()

	result = cm.token_bytes(32)

	assert len(result) == 32


# Generated at 2022-06-23 21:10:19.687223
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()

# Generated at 2022-06-23 21:10:29.934990
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    try:
        import pytest
        from mimesis.enums import Algorithm
    except ImportError as e:
        print("Importing mimesis failed->pytest,mimesis.enums:", e)
        return

    with pytest.raises(Exception):
        crypto = Cryptographic(seed=None)
    with pytest.raises(Exception):
        crypto = Cryptographic(seed="string")
    crypto = Cryptographic()
    assert crypto != None
    assert crypto is not None
    assert crypto.mnemonic_phrase() != None


token_urlsafe = Cryptographic.token_urlsafe
token_hex = Cryptographic.token_hex
token_bytes = Cryptographic.token_bytes
hash = Cryptographic.hash
uuid = Cryptographic.uuid

# Generated at 2022-06-23 21:10:34.456013
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Create object of class Cryptographic
    # for generating cryptographic data
    cryptographic_provider = Cryptographic()
    # Generate random bytes using method token_bytes of class Cryptographic
    token_bytes = cryptographic_provider.token_bytes()
    # Check type of result using isinstance method
    assert isinstance(token_bytes, bytes)


# Generated at 2022-06-23 21:10:39.822766
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    cp = Cryptographic()

    # check that the method returns a string
    assert isinstance(cp.token_urlsafe(), str)
    # check that the string length is 45
    assert len(cp.token_urlsafe()) == 45
    # check that the string length is 32
    assert len(cp.token_urlsafe(32)) == 45
    # check that the string length is 150
    assert len(cp.token_urlsafe(150)) == 150



# Generated at 2022-06-23 21:10:42.419468
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    x = c.mnemonic_phrase()
    result = x.split(' ')
    assert len(result) == 12

# Generated at 2022-06-23 21:10:47.369217
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    assert isinstance(cr, Cryptographic)
    assert cr.uuid() is not None
    assert cr.mnemonic_phrase() is not None
    assert cr.token_urlsafe() is not None
    assert cr.token_hex() is not None
    assert cr.token_bytes() is not None
    assert cr.hash() is not None

# Generated at 2022-06-23 21:10:49.472218
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    obj = Cryptographic()

    # Check type of returned value
    assert isinstance(obj.hash(), str)


# Generated at 2022-06-23 21:10:58.614109
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Test for expected value
    expected = b'\xf1x\xad\x02\xee\x96\xc0\x9c\xac\n\xdd\x1f\xce\x82\x8c\x9a\xe7N\xfe\xdb*\xbc\x83\x1a\x10\x8d\x98\x9d\xb9\x06\xf8\x18\xec\x82\x0b\x8b'
    c = Cryptographic()
    assert c.token_bytes(32) == expected
    c._reset_seed()

    # Test for expected value

# Generated at 2022-06-23 21:11:01.224620
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonic_phrase = Cryptographic().mnemonic_phrase(15)
    assert type(mnemonic_phrase) == type('string')


# Generated at 2022-06-23 21:11:06.002933
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    s = Cryptographic()
    token_urlsafe2  = s.token_urlsafe(2)

    print("Token URL Safe 2: " + token_urlsafe2)
    assert token_urlsafe2 != None
    assert isinstance(token_urlsafe2, str)
    assert len(token_urlsafe2) == 2


# Generated at 2022-06-23 21:11:07.296537
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64


# Generated at 2022-06-23 21:11:13.783277
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Seed (default)
    crypto = Cryptographic(seed=400)
    phrase = crypto.mnemonic_phrase()
    assert isinstance(phrase, str)
    assert len(phrase.split()) == 12

    # Seed (4)
    crypto = Cryptographic(seed=4)
    phrase = crypto.mnemonic_phrase()
    assert isinstance(phrase, str)
    assert len(phrase.split()) == 12

    # Seed (10)
    crypto = Cryptographic(seed=10)
    phrase = crypto.mnemonic_phrase()
    assert isinstance(phrase, str)
    assert len(phrase.split()) == 12

    # Seed (20)
    crypto = Cryptographic(seed=20)
    phrase = crypto.mnemonic_phrase()
    assert isinstance(phrase, str)
    assert len(phrase.split()) == 12

# Generated at 2022-06-23 21:11:21.303854
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.builtins.cryptographic import Cryptographic
    c = Cryptographic()

# Generated at 2022-06-23 21:11:22.380084
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert type(Cryptographic().token_urlsafe()) == str

# Generated at 2022-06-23 21:11:29.029594
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    import unittest
    import uuid

    from mimesis.providers.cryptographic import Cryptographic

    class CryptographicTestCase(unittest.TestCase):
        def setUp(self):
            self.cryptographic = Cryptographic('en')

        def test_token_bytes(self):
            result = self.cryptographic.token_bytes()
            self.assertIsInstance(result, bytes)
            self.assertEqual(32, len(result))

    unittest.main()


# Generated at 2022-06-23 21:11:37.985099
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() != c.hash()
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA512) != c.hash(Algorithm.SHA512)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384) != c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA224) != c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA1) != c.hash(Algorithm.SHA1)


# Generated at 2022-06-23 21:11:46.468418
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    '''
    test token_bytes method of class Cryptographic
    '''
    token_bytes = Cryptographic.token_bytes()
    assert(len(token_bytes) == 32) # default length is 32
    assert(isinstance(token_bytes, bytes))

    token_bytes_5 = Cryptographic.token_bytes(5)
    assert(len(token_bytes_5) == 10) # length should be twice the input
    assert(isinstance(token_bytes_5, bytes))



# Generated at 2022-06-23 21:11:50.441141
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()

    if crypto.token_bytes() == crypto.token_bytes():
        raise AssertionError("The result of token_bytes method must be unique")
    if crypto.token_bytes() == crypto.token_bytes():
        raise AssertionError("The result of token_bytes method must be unique")

    assert True


# Generated at 2022-06-23 21:11:55.965769
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cp=Cryptographic()
    #local variables
    #[]
    #[]
    #[]
    #[]
    #[[]]
    #[]
    #[]
    #[]
    #[[[]]]
    #[[[]]]
    #[[[[[[]]]]]]
    #[[[[[]]]]]
    #[[[[[[]]]]]]
    #[[[[[[]]]]]]
    #[[[[]]]]
    #[[[[]]]]
    #[[[[]]]]
    #[[]]
    #[[]]
    #[[]]
    #[[]]
    #[[]]
    #[[]]
    #[[]]
    assert cp
    #unit test for method Cryptographic.uuid
    #local variables
    #[]
    #[]
    #[]
    #[]
    #[[]]
    #[]
    #

# Generated at 2022-06-23 21:12:00.313034
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # the test
    tokens_list = []
    n = 20
    for i in range(n):
        tokens_list.append(Cryptographic().token_bytes(0))
    assert len(tokens_list) == n
    assert len(set(tokens_list)) == 1
    assert tokens_list[0] == b''


# Generated at 2022-06-23 21:12:04.935563
# Unit test for method hash of class Cryptographic

# Generated at 2022-06-23 21:12:15.100989
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm


# Generated at 2022-06-23 21:12:16.284059
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex(32)) == 64



# Generated at 2022-06-23 21:12:19.002238
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe of class Cryptographic."""
    crypto = Cryptographic('en')
    hash_ = crypto.token_urlsafe()
    assert isinstance(hash_, str)



# Generated at 2022-06-23 21:12:25.608881
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    cr = Cryptographic()

    assert len(cr.hash()) == 64  # SHA-256
    assert len(cr.hash(Algorithm.SHA512)) == 128  # SHA-512

    try:
        assert cr.hash('')
    except Exception as e:
        print(e)

    cr.seed(None)
    assert len(cr.hash()) == 64  # SHA-256

# Generated at 2022-06-23 21:12:27.011556
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32



# Generated at 2022-06-23 21:12:29.429736
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test the method token_hex of class Cryptographic."""
    a = Cryptographic()
    b = Cryptographic()
    assert a.token_hex() != b.token_hex()

# Generated at 2022-06-23 21:12:31.010920
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    value = Cryptographic().hash()
    print(value)

# Generated at 2022-06-23 21:12:33.419627
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert (provider.mnemonic_phrase())

# Generated at 2022-06-23 21:12:38.581226
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    #Test for normal case
    a = Cryptographic(seed=0)
    assert a.mnemonic_phrase() == 'toad jump pencil city good'

    # Test for abnormal case
    # 1. Test for input length is negative
    a = Cryptographic(seed=0)
    assert a.mnemonic_phrase(-1) == ''
    # 2. Test for input is not int
    a = Cryptographic(seed=0)
    assert a.mnemonic_phrase(False) == ''

# Generated at 2022-06-23 21:12:40.128505
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    res = crypto.token_bytes()
    assert(isinstance(res, bytes))


# Generated at 2022-06-23 21:12:41.491848
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cryp = Cryptographic()
    assert getattr(cryp, 'uuid') is not None

# Generated at 2022-06-23 21:12:43.475310
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    x = Cryptographic()
    assert x.random



# Generated at 2022-06-23 21:12:46.667872
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    mnemonic_phrase = Cryptographic().mnemonic_phrase
    assert mnemonic_phrase() != None
    assert mnemonic_phrase(length = 1260) != None
    assert mnemonic_phrase(length = 160, separator = ' ') != None

# Generated at 2022-06-23 21:12:49.492363
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    token_hex = c.token_hex()
    assert len(token_hex) == 64
    print(token_hex)


# Generated at 2022-06-23 21:12:50.919677
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    data = Cryptographic()
    assert len(data.token_hex()) == 64
    print(data.token_hex())



# Generated at 2022-06-23 21:12:52.185526
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    actual = Cryptographic().token_urlsafe()
    assert isinstance(actual, str)
    assert len(actual) == 43

# Generated at 2022-06-23 21:12:59.033608
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    result1 = Cryptographic(seed=12345).token_bytes(entropy=32)
    assert result1 == b'\x1f\x84x\x1a\xad\xff\xfa\x9a\x99c\x1f\xed\xfd\xceG2\xae\x0c\xe9\x9e\x18k\x07\\\x1bF\x8a\x0b\x04\xbf\x9a\x8d"\xa6'
    result2 = Cryptographic(seed=12345).token_bytes(entropy=48)

# Generated at 2022-06-23 21:13:02.224868
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == str(UUID(c.uuid(as_object=True)))


# Generated at 2022-06-23 21:13:04.101309
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cryptographic = Cryptographic()
    token = cryptographic.token_urlsafe()
    print(token)


# Generated at 2022-06-23 21:13:06.652882
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto is not None


# Generated at 2022-06-23 21:13:09.388354
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for Cryptographic.hash()."""
    assert Cryptographic().hash() == '2f28f60d7c1b234d07a7c8f827d9a942'



# Generated at 2022-06-23 21:13:12.244651
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    token_bytes = c.token_bytes()
    assert isinstance(token_bytes, bytes)


# Generated at 2022-06-23 21:13:15.954846
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    crp = Cryptographic()
    assert crp.mnemonic_phrase()
    crp.seed(7)
    assert crp.mnemonic_phrase(length=7, separator=' - ') == 'steel - proud - police - annual - peace - seven - spread'

# Generated at 2022-06-23 21:13:18.649730
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    result = provider.token_urlsafe(32)
    print(result)

    assert result == "JZ25DwN_N2QWswChbyNIG84X-aLAPJetJb2QhfvO5xo"

# Generated at 2022-06-23 21:13:25.130650
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    crypt_hash_md5 = crypto.hash(algorithm=Algorithm.MD5)
    crypt_hash_sha1 = crypto.hash(algorithm=Algorithm.SHA1)
    crypt_hash_sha224 = crypto.hash(algorithm=Algorithm.SHA224)
    crypt_hash_sha256 = crypto.hash(algorithm=Algorithm.SHA256)
    crypt_hash_sha384 = crypto.hash(algorithm=Algorithm.SHA384)
    crypt_hash_sha512 = crypto.hash(algorithm=Algorithm.SHA512)
    print('MD5 hash:', crypt_hash_md5)
    print('SHA1 hash:', crypt_hash_sha1)
    print('SHA224 hash:', crypt_hash_sha224)

# Generated at 2022-06-23 21:13:26.729358
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    a = c.token_urlsafe()
    assert a == c.token_urlsafe()


# Generated at 2022-06-23 21:13:28.560248
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto_provider = Cryptographic()
    result = crypto_provider.uuid()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:13:31.508690
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test = Cryptographic()
    result = test.hash()
    for i in range(4):
        print(result)


# Generated at 2022-06-23 21:13:36.501700
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    seed = 'my_seed'
    return_type = 'str'
    provider = Cryptographic(seed=seed)
    assert isinstance(provider.uuid(as_object=True), UUID)
    assert isinstance(provider.uuid(as_object=False), str)
    assert provider.uuid(as_object=True) != provider.uuid(as_object=False)



# Generated at 2022-06-23 21:13:40.770506
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    #assert Cryptographic.token_hex == type(str)
    assert type(Cryptographic.token_hex(entropy=5)) == str
    assert len(Cryptographic.token_hex(entropy=5)) == 10
    assert len(Cryptographic.token_hex(entropy=10)) == 20
#test passed


# Generated at 2022-06-23 21:13:50.298935
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    assert provider.hash(Algorithm.MD5) == '9f9952cd479c0f0d8b2c2d48dea1c4d4'
    assert provider.hash(Algorithm.SHA1) == '4d4b4f4dbe96dc09f3a1d3fd40326e9f0904e6e2'
    assert provider.hash(Algorithm.SHA256) == '2e1bcef8b8a24bdeb55410b7aef69c3589f8f3f3ed3b7a91393a1fb8cbe5f6e5'

# Generated at 2022-06-23 21:13:52.991666
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    output = crypto.uuid()
    output_obj = crypto.uuid(as_object=True)
    assert isinstance(output, str)
    assert isinstance(output_obj, UUID)


# Generated at 2022-06-23 21:13:56.085205
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cr = Cryptographic()
    print(cr.token_urlsafe())
    print(cr.token_urlsafe(4))
    print(cr.token_urlsafe(2))

if __name__ == "__main__":
    test_Cryptographic_token_urlsafe()

# Generated at 2022-06-23 21:13:59.453424
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Start class Cryptographic
    token_bytes1 = Cryptographic().token_bytes()
    token_bytes2 = Cryptographic().token_bytes(32)
    # End class Cryptographic
    assert isinstance(token_bytes1, bytes)
    assert isinstance(token_bytes2, bytes)



# Generated at 2022-06-23 21:14:00.706809
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    token = crypto.token_urlsafe()
    assert len(token) == 44


# Generated at 2022-06-23 21:14:04.063131
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    result = c.token_hex()
    assert len(result) == 64
    assert isinstance(result, str)

# Generated at 2022-06-23 21:14:06.860982
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj_1 = Cryptographic()
    obj_2 = Cryptographic()

    res_1 = obj_1.hash()
    res_2 = obj_2.hash()

    assert len(res_1) == 64
    assert len(res_2) == 64
    assert res_1 != res_2
    print(res_1)
    print(res_2)


# Generated at 2022-06-23 21:14:16.007704
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    '''
    Test method mnemonic_phrase of class Cryptographic
    '''
    c = Cryptographic()
    # Test case 1
    tmp_result = c.mnemonic_phrase()
    assert(isinstance(tmp_result, str))
    # Test case 2
    tmp_result = c.mnemonic_phrase(length=16)
    assert(isinstance(tmp_result, str))
    # Test case 3
    tmp_result = c.mnemonic_phrase(length=16, separator='-')
    assert(isinstance(tmp_result, str))
    assert(tmp_result.count('-') == 15)

# Generated at 2022-06-23 21:14:16.831513
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert type(Cryptographic().token_urlsafe(10)) == str



# Generated at 2022-06-23 21:14:22.510309
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # This test checks that the method uuid() of class Cryptographic
    # generates a random UUID every time it is called

    cm = Cryptographic()
    cm_uuid = cm.uuid()

    assert type(cm_uuid) == str

    for _ in range(0, 100):
        assert cm_uuid != cm.uuid()


# Generated at 2022-06-23 21:14:23.564172
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()


# Generated at 2022-06-23 21:14:25.747847
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic."""
    u = Cryptographic().uuid()
    assert len(u) == 36
    assert type(u) == str


# Generated at 2022-06-23 21:14:27.600185
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token_bytes = Cryptographic().token_bytes
    assert type(token_bytes(entropy=2)) is bytes



# Generated at 2022-06-23 21:14:31.444949
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    print(crypto.token_urlsafe())
    print(crypto.token_urlsafe(16))
    print(crypto.token_urlsafe(32))


# Generated at 2022-06-23 21:14:33.140864
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    token = provider.token_urlsafe()
    assert token is not None

# Generated at 2022-06-23 21:14:34.736664
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert Cryptographic.token_urlsafe(entropy=32) == secrets.token_urlsafe(entropy=32)

# Generated at 2022-06-23 21:14:37.165611
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crp = Cryptographic()
    assert crp.provider == 'cryptographic'


# Generated at 2022-06-23 21:14:46.689288
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for Cryptographic.mnemonic_phrase method."""
    c = Cryptographic()
    # For that to work mnemonic phrase must contain word _and_

# Generated at 2022-06-23 21:14:49.456851
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    uuid = Cryptographic().uuid()
    assert len(uuid) > 0 and len(uuid) <= 36  # noqa: WPS432


# Generated at 2022-06-23 21:14:52.222237
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    s = crypto.token_bytes(entropy=32)
    assert len(s) >= 32  # テスト成功。


# Generated at 2022-06-23 21:14:54.134967
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    result = crypto.token_urlsafe()
    assert result

# Generated at 2022-06-23 21:14:55.973167
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    _token_bytes = Cryptographic().token_bytes()
    assert _token_bytes != None
    

# Generated at 2022-06-23 21:14:58.745280
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    for _ in range(4):
        assert Cryptographic().uuid() == str(UUID(Cryptographic().uuid()))


# Generated at 2022-06-23 21:15:01.880110
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic().token_urlsafe())
    # ZB-qvNp9CnAku6K8U6WwJg


# Generated at 2022-06-23 21:15:04.216164
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic('en')
    res = c.hash()
    assert res is not None
    assert len(res) > 0

# Generated at 2022-06-23 21:15:07.654567
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    assert a.mnemonic_phrase()
    assert a.hash()
    assert a.token_bytes()
    assert a.token_hex()
    assert a.token_urlsafe()
    assert a.uuid()
    assert a.uuid(as_object=True)

# Generated at 2022-06-23 21:15:10.157096
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(100)) == 100
    assert len(Cryptographic().token_bytes(10)) == 10
    assert len(Cryptographic().token_bytes(1)) == 1


# Generated at 2022-06-23 21:15:12.774369
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test Cryptographic.token_hex()."""
    assert Cryptographic().token_hex() == Cryptographic().token_hex()

# Generated at 2022-06-23 21:15:15.916896
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic"""
    crypto = Cryptographic(seed=0)
    assert crypto.hash() == 'd5d5e0a5dc5f29cc5f5fc5a1dec5b5e5'


# Generated at 2022-06-23 21:15:19.554493
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    t = c.token_urlsafe()
    assert type(t) == str

# Generated at 2022-06-23 21:15:24.107966
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    import re
    cr = Cryptographic()
    assert len(cr.token_urlsafe()) == 45 and re.match(r'\w{45}', cr.token_urlsafe())

# Generated at 2022-06-23 21:15:25.523937
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic("it")
    assert len(provider.token_urlsafe()) == 45
    assert provider.token_urlsafe() != provider.token_urlsafe()

# Generated at 2022-06-23 21:15:35.519107
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # arrange
    expected_result_bytes = b'\xd2\x92"`\xe1\x9d\xb0\xca\xc5\x83\xe7\x8d\x1c\xf40\x1d\x83\x13%\xc3\xaf\x94\x16\xe8\x99\x1c'
    expected_result_hex = 'd2922260e19db0cac583e78d1cf401d831325c3af9416e8991c'

    # act
    result_bytes = Cryptographic.token_bytes(32)
    result_hex = Cryptographic.token_hex(32)

    # assert
    assert result_bytes == expected_result_bytes
    assert result_hex == expected_result_hex

# Generated at 2022-06-23 21:15:38.842668
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic"""
    # there will be printed a random string in Base64 encoding
    token = Cryptographic().token_urlsafe()
    print(token)



# Generated at 2022-06-23 21:15:44.715752
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm
    cr = Cryptographic()
    entropy = 32
    algorithm = Algorithm.SHA3_512

    b = cr.token_bytes(entropy)
    assert isinstance(b, bytes)
    assert len(b) == entropy

    h = cr.hash(algorithm)
    assert len(h) == algorithm.value['length']



# Generated at 2022-06-23 21:15:46.409008
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    result = Cryptographic.token_bytes()
    assert result is not None and isinstance(result, bytes)


# Generated at 2022-06-23 21:15:53.159567
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis import Cryptographic
    from mimesis.enums import Algorithm

    c = Cryptographic()
    token = c.token_urlsafe()
    assert len(token.encode()) == 44
    assert token.encode().decode() == token
    assert c.hash(Algorithm.SHA512) == 'ccc0d820bac2d9447451b8ecad1fbd1873c05b7e0745b8a3b3ee9089c44d1e9c0f5b5491a9877dd42cc5e0ed834457c68b7faac1ae9bf9d8a1706991e1c16dcf'

# Generated at 2022-06-23 21:15:55.982426
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cry = Cryptographic()
    cry.token_hex()
    assert cry.token_hex() != cry.token_hex()


# Generated at 2022-06-23 21:15:58.357445
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test type of return a random URL-safe text string, in Base64 encoding..

    .. warning:: Seed is not applicable to this method,
        because of its cryptographic-safe nature.
    :return: URL-safe token.
    """
    token = Cryptographic.token_urlsafe()
    print("URL-safe token: ", token)



# Generated at 2022-06-23 21:16:09.447969
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryp = Cryptographic()
    # print(cryp.hash())
    # print(cryp.hash())
    # print(cryp.hash())
    # print(cryp.hash())
    # print(cryp.hash(Algorithm.SHA1))
    # print(cryp.hash(Algorithm.SHA1))
    # print(cryp.hash(Algorithm.SHA1))
    # print(cryp.hash(Algorithm.SHA1))
    # print(cryp.hash(Algorithm.SHA224))
    # print(cryp.hash(Algorithm.SHA224))
    # print(cryp.hash(Algorithm.SHA224))
    # print(cryp.hash(Algorithm.SHA224))
    # print(cryp.hash(Algorithm.SHA256))
    # print(cryp.

# Generated at 2022-06-23 21:16:11.772520
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    data = Cryptographic().uuid()
    assert len(data) == 36
    assert isinstance(data, str)


# Generated at 2022-06-23 21:16:13.451594
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # getting values and checking
    c = Cryptographic()
    assert c.mnemonic_phrase()

# Generated at 2022-06-23 21:16:14.637899
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() != None


# Generated at 2022-06-23 21:16:16.417290
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    x = Cryptographic()
    assert type(x.uuid()) == str
    assert len(x.uuid()) == 36


# Generated at 2022-06-23 21:16:19.196529
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print('\n\n==========> test_Cryptographic_mnemonic_phrase')
    from mimesis.providers.cryptographic import Cryptographic
    phrase = Cryptographic().mnemonic_phrase(length=6)
    print('phrase:', phrase)
    assert phrase


# Generated at 2022-06-23 21:16:21.001500
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic().token_hex(32) != Cryptographic().token_hex(32)

# Generated at 2022-06-23 21:16:22.473638
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) >= 36

# Generated at 2022-06-23 21:16:24.852609
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 36
    assert isinstance(Cryptographic().uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:16:25.486983
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass

# Generated at 2022-06-23 21:16:27.359182
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('generate hash:', Cryptographic().hash())


# Generated at 2022-06-23 21:16:36.293986
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.cryptographic import Cryptographic

    crypto = Cryptographic()

    # ValueError: token_urlsafe() takes 1 positional argument but 2 were given
    token = crypto.token_urlsafe(entropy=32)
    print("token: " + token)
    """
    token: Jg_Bp1dTJVEFjf2O-k1sIw
    """

    # NonEnumerableError: value not in enumeration Algorithm
    try:
        hash_ = crypto.hash(algorithm=Algorithm.WHIRLPOOL)
        print("hash: " + hash_)
    except NonEnumerableError as e:
        print(e)

# Generated at 2022-06-23 21:16:39.252583
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test token_hex method of class Cryptographic."""
    crypt = Cryptographic()
    assert len(crypt.token_hex(256)) == 256



# Generated at 2022-06-23 21:16:42.325448
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert len(crypto.token_bytes()) == 32
    assert len(crypto.token_bytes(10)) == 20


# Generated at 2022-06-23 21:16:45.841522
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Testing with SHA3_512 algorithm
    hash = Cryptographic().hash(Algorithm.SHA3_512)
    assert isinstance(hash, str)


# Generated at 2022-06-23 21:16:48.979386
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(entropy = 32) != c.token_urlsafe(entropy = 32)


# Generated at 2022-06-23 21:16:51.702701
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    try:
        assert repr(Cryptographic)
        assert str(Cryptographic)
    except Exception as e:
        raise AssertionError("Could not instantiate Cryptographic: {0}".format(e.args))



# Generated at 2022-06-23 21:16:55.621475
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    assert isinstance(a, Cryptographic)
    b = Cryptographic(seed=None)
    assert isinstance(b, Cryptographic)
    assert a.seed != b.seed

# Unit tests for method uuid

# Generated at 2022-06-23 21:16:57.129085
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert c.token_bytes()
    assert c.token_bytes(32).decode()

# Generated at 2022-06-23 21:17:02.369068
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA1) == 'cdea292e7e1fa999b9d9a49e83ad3a3c2f08b879'
    assert crypto.hash(Algorithm.SHA256) == '92368c47b3aa7b2c725f8af79d48c6fbd7155c47d01bf8d7f9e96f395f7c58cf'


# Generated at 2022-06-23 21:17:07.229903
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptogrphic."""
    string = 'e7e6918d-a036-4982-8949-f3b611b16e45'
    crypto = Cryptographic()
    # Test with a string as parameter
    assert crypto.hash('sha1') == '2a2d7fa8a5814c7ee4ddcbf1c7f828646217c946'
    # Test with an enum object as parameter
    assert crypto.hash(Algorithm.SHA1) == '2a2d7fa8a5814c7ee4ddcbf1c7f828646217c946'
    # Test with a NoneType as parameter

# Generated at 2022-06-23 21:17:18.222354
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()

    # type
    assert isinstance(cr.hash(), str)

    # content
    h = hashlib.md5()
    h.update(cr.uuid().encode())
    assert cr.hash(Algorithm.MD5) == h.hexdigest()

    # content
    h = hashlib.sha1()
    h.update(cr.uuid().encode())
    assert cr.hash(Algorithm.SHA1) == h.hexdigest()

    # content
    h = hashlib.sha224()
    h.update(cr.uuid().encode())
    assert cr.hash(Algorithm.SHA224) == h.hexdigest()

    # content
    h = hashlib.sha256()
    h.update(cr.uuid().encode())

# Generated at 2022-06-23 21:17:20.673334
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic(seed=12345)
    assert provider.token_bytes(1) != provider.token_bytes(1)


# Generated at 2022-06-23 21:17:23.203887
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    ob = Cryptographic()
    assert isinstance(ob.token_hex(), str)



# Generated at 2022-06-23 21:17:26.818463
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Instantiate Cryptographic
    c = Cryptographic()
    # Call method
    result = c.token_urlsafe()
    # Check type
    assert isinstance(result, str)
    # Check length
    assert len(result) == 43


# Generated at 2022-06-23 21:17:27.701182
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    k = Cryptographic()
    assert isinstance(k, BaseProvider)



# Generated at 2022-06-23 21:17:29.347194
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert type(c.token_bytes()) == bytes

# Generated at 2022-06-23 21:17:31.917018
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    for i in range(20):
        token = Cryptographic().token_hex()
        assert len(token) == 64


# Generated at 2022-06-23 21:17:33.572934
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    provider.token_bytes()
    return

# Generated at 2022-06-23 21:17:36.225600
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token_hex = Cryptographic().token_hex()
    assert (token_hex is not None)
    assert (len(str(token_hex)) == 64)


# Generated at 2022-06-23 21:17:37.328888
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print(Cryptographic.token_bytes())


# Generated at 2022-06-23 21:17:39.559400
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash = Cryptographic().hash()
    expected_types = {"hexdigest"}
    assert type(hash).__name__ in expected_types


# Generated at 2022-06-23 21:17:42.281311
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Testing method token_bytes of class Cryptographic
    # Since the method is static, we can use this way of calling
    cryptography = Cryptographic()
    cryptography.token_bytes()

# Generated at 2022-06-23 21:17:51.210891
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.builtins import Cryptographic
    from mimesis.enums import Algorithm
    from mimesis.providers.text import Text
    c = Cryptographic('en')
    t = Text('en')
    print(c.mnemonic_phrase())
    print(c.mnemonic_phrase(separator='-'))
    print(c.mnemonic_phrase(separator=t.separator()))
    print(c.mnemonic_phrase(length=24))
    print(c.mnemonic_phrase(length=8))
    print(c.hash(Algorithm.SHA256))
    print(c.hash(Algorithm.SHA384))
    print(c.hash(Algorithm.SHA512))
    print(c.hash(Algorithm.SHA1))

# Generated at 2022-06-23 21:17:54.638808
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    str = Cryptographic.token_urlsafe();
    print(str)
    print(str.__class__)
    print(len(str))
    print('')

# test for class Cryptographic

# Generated at 2022-06-23 21:18:04.539908
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Create a instance of Cryptographic
    crypt = Cryptographic()
    phrase = crypt.mnemonic_phrase(12, ' ')
    # Check that phrase is a string
    phrase_type = type(phrase) == str
    assert phrase_type == True
    print('phrase is a string: ', phrase_type)
    # Check that phrase consists of 12 words
    phrase_lenght = len(phrase.split())
    assert phrase_lenght == 12
    print('phrase consists of 12 words: ', phrase_lenght)
    # Check that phrase contains only words
    phrase_words = phrase.split()
    all_words = 1
    for i in range(len(phrase_words)):
        if phrase_words[i].isalpha():
            pass
        else:
            all_words = 0
            break
    assert all_

# Generated at 2022-06-23 21:18:08.493936
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Test 1.
    cp1 = Cryptographic()
    result1 = cp1.token_urlsafe()
    assert len(result1) == 43

    # Test 2.
    cp2 = Cryptographic()
    result2 = cp2.token_urlsafe(32)
    assert len(result2) == 44

# Generated at 2022-06-23 21:18:09.754817
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic(seed=1)
    assert cr is not None

# Generated at 2022-06-23 21:18:14.436502
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic(seed=666)
    c.token_hex()
    c.token_hex(50)
    c.token_hex(100)
    c.token_hex(150)
    c.token_hex(200)
    c.token_hex(250)
    c.token_hex(300)
    c.token_hex(350)

# Generated at 2022-06-23 21:18:15.926288
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    print(c.token_bytes(4))


# Generated at 2022-06-23 21:18:27.249901
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase(10, "-") != crypto.mnemonic_phrase(10, "-")
    assert crypto.mnemonic_phrase(12, "-") != crypto.mnemonic_phrase(12, "-")
    assert crypto.mnemonic_phrase(10, "-") != crypto.mnemonic_phrase(12, "-")
    assert crypto.mnemonic_phrase(30) != crypto.mnemonic_phrase(30)
    assert crypto.mnemonic_phrase(30) != crypto.mnemonic_phrase()
    assert crypto.uuid() != crypto.uuid()
    assert crypto.uuid(False) != crypto.uuid(False)
    assert crypto.uuid() != crypto.uuid(False)
    assert crypto.hash(Algorithm.SHA384) != crypto.hash(Algorithm.SHA384)


# Generated at 2022-06-23 21:18:31.026832
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    g = Cryptographic()
    assert len(g.mnemonic_phrase()) > 0
    assert len(g.mnemonic_phrase(length=10)) > 0

# Generated at 2022-06-23 21:18:32.473555
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    assert isinstance(provider.uuid(), str)

# Generated at 2022-06-23 21:18:35.174311
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Unit test for constructor of class Cryptographic"""
    cr = Cryptographic()
    print(cr.mnemonic_phrase())

# Generated at 2022-06-23 21:18:38.032573
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    assert len(cr.mnemonic_phrase().split()) == 12
    assert len(cr.mnemonic_phrase().split()) == 12
    assert len(cr.mnemonic_phrase().split()) == 12



# Generated at 2022-06-23 21:18:40.903435
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    data = [c.token_urlsafe() for i in range(0, 10)]
    assert data is not None
    assert len(data) == 10
    assert len(data[0]) >= 32

# Generated at 2022-06-23 21:18:44.190624
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Test whether the result is an empty string.
    def test_empty_string():
        crypto = Cryptographic()
        assert crypto.mnemonic_phrase() == '', "Failed: Generated phrase is an empty string"
    test_empty_string()

    # Test whether the result is a phrase.
    def test_phrase():
        crypto = Cryptographic()
        assert crypto.mnemonic_phrase(1, '') != '', "Failed: Generated phrase is a phrase"
    test_phrase()

# Generated at 2022-06-23 21:18:47.125077
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    hash = crypto.hash(Algorithm.SHA1)
    assert isinstance(hash, str)
    assert len(hash) == 40

# Generated at 2022-06-23 21:18:51.840261
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    assert phrase.__class__ == str
    assert len(phrase.split()) == 12
    phrase_with_separator = crypto.mnemonic_phrase(separator=' ')
    assert phrase == phrase_with_separator

# Generated at 2022-06-23 21:19:00.511821
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    #Create an instance of Cryptographic
    crypto = Cryptographic()
    # Generate a mnemonic phrase with a specified number of words and a specified separator
    actual = crypto.mnemonic_phrase(6, "|")
    # Check if the length of the phrase is equal to the specified number of words plus the number of specified separators
    assert len(actual) == 3 * (6-1) + 6 * (len("invitation")), "#1 Check if the length of the phrase is equal to the specified number of words plus the number of specified separators"
    # Check that the phrase contains only words from the dictionary of normal words
    assert all(word in crypto._data['words']['normal'] for word in actual.split("|")), "#2 Check that the phrase contains only words from the dictionary of normal words"