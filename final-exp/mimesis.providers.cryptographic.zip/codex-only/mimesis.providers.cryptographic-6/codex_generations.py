

# Generated at 2022-06-23 21:09:01.314009
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    tokens = Cryptographic().token_hex()
    assert len(tokens) == 64


# Generated at 2022-06-23 21:09:03.653594
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	print('\nRunning constructor tests...\n')
	# Initialize object
	c = Cryptographic()
	assert c.uuid() is not None


# Generated at 2022-06-23 21:09:05.508426
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert isinstance(crypto.uuid(as_object=True), UUID)



# Generated at 2022-06-23 21:09:07.916632
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()

    token_urlsafe = provider.token_urlsafe()

    assert isinstance(token_urlsafe, str), "Should be a string"

    token_urlsafe = provider.token_urlsafe(1024)

    assert isinstance(token_urlsafe, str), "Should be a string"

# Generated at 2022-06-23 21:09:18.544450
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    import pytest
    from mimesis.enums import Algorithm

    assert Cryptographic.mnemonic_phrase() is not None
    assert Cryptographic.mnemonic_phrase(length = 100) is not None
    assert Cryptographic.mnemonic_phrase(separator = ',') is not None

    #if pytest.__version__ >= '3.5.0' and pytest.__version__ <= '3.9.0':
    #    with pytest.raises(AssertionError):
    #        Cryptographic.mnemonic_phrase(length = 0)
    #else:
    #    with pytest.raises(ValueError):
    #        Cryptographic.mnemonic_phrase(length = 0)

    #if pytest.__version__ >= '3

# Generated at 2022-06-23 21:09:22.905065
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    a = Cryptographic()
    print(a.hash(Algorithm.SHA256))
    print(a.hash(Algorithm.SHA384))
    assert a.hash(Algorithm.SHA1) is not None


# Generated at 2022-06-23 21:09:23.786462
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    print(obj.hash())

# Generated at 2022-06-23 21:09:26.779835
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid()
    assert isinstance(c.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:09:29.789995
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Init
    c = Cryptographic()
    # Result
    res = c.token_bytes(0)
    # Assert
    assert isinstance(res, bytes)


# Generated at 2022-06-23 21:09:39.057231
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # test for default value
    token_urlsafe = Cryptographic.token_urlsafe()
    assert len(token_urlsafe) == 43
    assert isinstance(token_urlsafe, str)
    assert not token_urlsafe.startswith(b'0b')
    assert not token_urlsafe.endswith(b'0b')
    # test for arbitrary sizes
    for i in range(1, 1004):
        token_urlsafe = Cryptographic.token_urlsafe(i)
        assert len(token_urlsafe) == i
        assert isinstance(token_urlsafe, str)
        assert not token_urlsafe.startswith(b'0b')
        assert not token_urlsafe.endswith(b'0b')

# Generated at 2022-06-23 21:09:39.741705
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert len(Cryptographic().mnemonic_phrase()) == 12

# Generated at 2022-06-23 21:09:51.012034
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """
    Test method mnemonic_phrase of class Cryptographic
    """
    import unittest
    import re
    import random

    class Test_Cryptographic_mnemonic_phrase(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.__random = random.Random()
            cls.__uuid_regex = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'

# Generated at 2022-06-23 21:09:55.528130
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method uuid of class Cryptographic
    """
    c = Cryptographic()
    assert c.uuid()[0] == '{' and c.uuid()[-1] == '}'
    assert c.uuid(as_object=True).hex == c.uuid().replace('-', '')


# Generated at 2022-06-23 21:09:57.746560
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """
    GIVEN Cryptographic class
    WHEN instancing class with parameters as_object=True
    THEN assert return type
    """
    test_result = Cryptographic.uuid(as_object=True)
    assert type(test_result) == UUID


# Generated at 2022-06-23 21:09:59.258203
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    ct = Cryptographic()
    result = ct.mnemonic_phrase()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:10:00.561759
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(str(Cryptographic.uuid())) == 36


# Generated at 2022-06-23 21:10:03.747663
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cr = Cryptographic(seed=123456)
    token = cr.token_urlsafe()
    assert token == "qn4Ci9FuoYnZgl-iVzB2Qw"

# Generated at 2022-06-23 21:10:05.474270
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(10)


# Generated at 2022-06-23 21:10:07.537548
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    value = secrets.token_bytes(16)
    length = len(value)
    assert length == 32


# Generated at 2022-06-23 21:10:08.677641
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()

    assert provider is not None

# Generated at 2022-06-23 21:10:10.211159
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic(seed=None)
    res1 = c.uuid()
    res2 = c.uuid()
    print(res1, type(res1))
    print(res2, type(res2))


# Generated at 2022-06-23 21:10:19.894957
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    import random
    from mimesis.providers.enums import Algorithm
    from mimesis.providers.text import Text

    t = Text('en')
    # It is reasonable to set the same seed
    t.seed(1)

    print("Text seed:", t.seed_value)
    # set the same seed for Cryptographic provider
    c = Cryptographic(seed=1)
    print("Cryptographic seed:", c.seed_value)

    # generate the same random words from Text provider
    s = t.words()
    print("Random words from Text provider:", s)

    # generate the same pseudo-mnemonic phrase from Cryptographic provider
    phrase = c.mnemonic_phrase(5)
    print("Random pseudo-mnemonic phrase from Cryptographic provider:", phrase)
    assert phrase == s

    # generate the same

# Generated at 2022-06-23 21:10:30.791905
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    from mimesis.providers.base import BaseProvider
    from mimesis.registry import ProviderRegistry
    pr = ProviderRegistry()
    algos = pr.get('algorithm')
    crypto = pr.get('cryptographic')
    algo = crypto.hash(Algorithm.MD5)
    mnemo_phrase = crypto.mnemonic_phrase(length = 5,separator = '_')
    assert isinstance(algos, BaseProvider)
    assert isinstance(crypto, BaseProvider)
    assert isinstance(algo, str)
    assert isinstance(mnemo_phrase, str)
    assert isinstance(crypto.Meta, type)
    assert len(mnemo_phrase.split('_')) == 5
    assert len(algo) == 32


# Generated at 2022-06-23 21:10:34.287694
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.SHA_256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA_384)) == 96
    assert len(Cryptographic().hash(Algorithm.SHA_512)) == 128

# Generated at 2022-06-23 21:10:35.530559
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto


# Generated at 2022-06-23 21:10:38.039889
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic"""
    assert isinstance(Cryptographic.uuid(), str)
    assert isinstance(Cryptographic.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:10:46.682249
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    # Testing an empty constructor of Cryptographic
    cryptography = Cryptographic()
    assert callable(cryptography.uuid)
    assert callable(cryptography.hash)
    assert callable(cryptography.token_bytes)
    assert callable(cryptography.token_hex)
    assert callable(cryptography.token_urlsafe)
    cur_hash = cryptography.hash()
    assert isinstance(cur_hash, str)
    assert len(cur_hash) > 0
    cur_hash = cryptography.hash(Algorithm.MD5)
    assert isinstance(cur_hash, str)
    assert len(cur_hash) > 0
    cur_hash = cryptography.hash(Algorithm.SHA1)
    assert isinstance

# Generated at 2022-06-23 21:10:49.152187
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cryptographic = Cryptographic()
    print(cryptographic.token_hex())
    print(cryptographic.token_hex(16))

test_Cryptographic_token_hex()

# Generated at 2022-06-23 21:10:50.400954
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(), str)


# Generated at 2022-06-23 21:10:51.982860
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    u = Cryptographic()
    print(u.uuid())


# Generated at 2022-06-23 21:10:54.547447
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    try:
        crypto = Cryptographic()
        result = crypto.uuid()
        assert result[0] == "{"
        assert result[-1] == "}"
    except Exception:
        raise AssertionError("Method uuid of class Cryptographic failed")


# Generated at 2022-06-23 21:10:55.525639
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32

# Generated at 2022-06-23 21:10:59.293111
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    p = Cryptographic()
    print(p.mnemonic_phrase())
    print(p.mnemonic_phrase(3))
    print(p.mnemonic_phrase(3, '-'))


# Generated at 2022-06-23 21:11:01.483062
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(32) is not None


# Generated at 2022-06-23 21:11:03.273320
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test class Cryptographic."""
    obj = Cryptographic()
    assert obj is not None


# Generated at 2022-06-23 21:11:11.604260
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic(seed=1)
    l=c.token_urlsafe(5)

# Generated at 2022-06-23 21:11:13.560752
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(32) is not None

# Generated at 2022-06-23 21:11:19.154574
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    if Algorithm.MD5 != 0:
        assert c.hash(Algorithm.MD5) == 'd5ff5f1617c449e30f3e44b22a28ea60'
    if Algorithm.SHA1 != 0:
        assert c.hash(Algorithm.SHA1) == 'acf38877c9e0e92b65b8af8b0f38cdb25d27762d'
    if Algorithm.SHA256 != 0:
        assert c.hash(Algorithm.SHA256) == '4d2e7a4ab14c4f636e9ca9aeb7267a8c8143b7fe017d42080a1a15a36c8f0df7'

# Generated at 2022-06-23 21:11:22.698410
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Function to test method token_hex of class Cryptographic"""
    c = Cryptographic()
    assert c.token_hex(10) == '5324d7d55f1714'



# Generated at 2022-06-23 21:11:24.662511
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    a = Cryptographic()
    assert a.mnemonic_phrase().count(' ') == 11


# Generated at 2022-06-23 21:11:27.739798
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test method token_hex of class Cryptographic."""
    c = Cryptographic()
    for _ in range(10):
        m = c.token_hex()
        assert len(m) == 64


# Generated at 2022-06-23 21:11:29.768418
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str)
    assert isinstance(Cryptographic().uuid(True), UUID)


# Generated at 2022-06-23 21:11:37.250439
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test of cryptographic method hash()."""
    c = Cryptographic()
    output = c.hash(Algorithm.SHA1)
    assert isinstance(output, str)
    assert len(output) == 40
    assert isinstance(c.hash(Algorithm.SHA256), str)
    assert isinstance(c.hash(Algorithm.SHA384), str)
    assert isinstance(c.hash(Algorithm.SHA512), str)
    assert isinstance(c.hash(Algorithm.BLAKE2_S), str)
    assert isinstance(c.hash(Algorithm.BLAKE2_B), str)

# Generated at 2022-06-23 21:11:38.505177
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-23 21:11:40.841543
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    value = Cryptographic().token_urlsafe(8)
    assert(len(value)==11)

# Generated at 2022-06-23 21:11:50.888934
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    cr = Cryptographic()
    assert isinstance(cr.uuid(), UUID)
    assert isinstance(cr.uuid(False), str)
    assert isinstance(cr.hash(), str)
    assert isinstance(cr.hash(Algorithm.SHA_512), str)
    assert isinstance(cr.token_bytes(), bytes)
    assert isinstance(cr.token_hex(), str)
    assert isinstance(cr.token_urlsafe(), str)
    assert isinstance(cr.mnemonic_phrase(), str)
    assert isinstance(cr.mnemonic_phrase(separator=':'), str)

# Generated at 2022-06-23 21:11:55.494861
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe of class Cryptographic."""
    data_provider = Cryptographic()
    assert len(data_provider.token_urlsafe()) == 43
    assert len(data_provider.token_urlsafe(16)) == 24
    assert len(data_provider.token_urlsafe(32)) == 43
    assert len(data_provider.token_urlsafe(64)) == 86


# Generated at 2022-06-23 21:11:56.640704
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert Cryptographic.token_urlsafe(2) is not None

# Generated at 2022-06-23 21:11:58.699996
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    data = Cryptographic('en').token_urlsafe(11)
    assert len(data) == 18
    assert isinstance(data, str)

# Generated at 2022-06-23 21:12:00.269263
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    assert isinstance(provider.token_urlsafe(), str)



# Generated at 2022-06-23 21:12:02.480603
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token_list=[]
    for i in range(10):
        token_list.append(Cryptographic.token_bytes())
    print(token_list)

# Generated at 2022-06-23 21:12:04.707784
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:12:06.431677
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert crypto.token_bytes() is not crypto.token_bytes()



# Generated at 2022-06-23 21:12:10.333414
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    my_bytes = c.token_bytes()
    print(my_bytes)
    print(type(my_bytes))
    #assert len(my_bytes) == 32
    #assert isinstance(my_bytes, bytes)


# Generated at 2022-06-23 21:12:13.491596
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex(): # get_token_method
    # unit test for method token_hex of class Cryptographic
    assert len(Cryptographic.token_hex()) == 64
    assert len(Cryptographic.token_hex(8)) == 16

# Generated at 2022-06-23 21:12:16.164094
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    providers = {}
    providers['UUID'] = Cryptographic().uuid()
    providers['UUID obj'] = Cryptographic().uuid(as_object=True)
    print(providers)


# Generated at 2022-06-23 21:12:21.173734
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic"""
    hasher = Cryptographic(seed=12345)
    generated_hash = hasher.hash()
    expected_hash = "138d23f519072a2c06684dddfe54c8a1"
    assert generated_hash == expected_hash


# Generated at 2022-06-23 21:12:22.312343
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Write the code
    pass

# Generated at 2022-06-23 21:12:24.029629
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash. This method generates an random hash, no test"""
    assert True

# Generated at 2022-06-23 21:12:27.493660
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic."""
    cr = Cryptographic()

    result = cr.uuid()
    assert type(result) is str
    assert isinstance(UUID(result), UUID)


# Generated at 2022-06-23 21:12:32.036615
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():

    # Initializing instance of Cryptographic
    cr = Cryptographic(seed=12345)

    # Printing uuid of the seed
    print(cr.uuid())

    # Printing uuid with default seed
    print(cr.uuid())

    # Printing uuid with default seed
    print(cr.uuid())



# Generated at 2022-06-23 21:12:35.088159
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    uuid_obj = crypto.uuid(True)
    assert isinstance(uuid_obj, UUID)

    uuid_str = crypto.uuid()
    assert isinstance(uuid_str, str)


# Generated at 2022-06-23 21:12:35.927618
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto is not None

# Generated at 2022-06-23 21:12:40.617232
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from pprint import pprint
    from mimesis.enums import Algorithm

    c = Cryptographic()
    token = c.token_hex()
    pprint(token)

    assert isinstance(token, str)

    algorithm = c.hash(Algorithm.SHA512)
    assert type(algorithm) == str

    algorithm = c.hash(Algorithm.SHA3_384)
    assert type(algorithm) == str



# Generated at 2022-06-23 21:12:43.577290
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    hash_ = c.hash(Algorithm.SHA256)
    assert hash_ is not None
    assert len(hash_) == 64


# Generated at 2022-06-23 21:12:46.078943
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase())

if __name__ == "__main__":
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:12:48.910205
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    assert isinstance(cr.uuid(), str)
    assert cr.uuid_object() is UUID(cr.uuid())


# Generated at 2022-06-23 21:12:50.531748
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    a = Cryptographic().token_urlsafe()
    assert len(a) == 43
    assert type(a) is str

# Generated at 2022-06-23 21:12:52.645266
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    test = Cryptographic()
    assert test.token_hex(32) == "b400cbf0664e126e0c17ec6dbb80d6c8"


# Generated at 2022-06-23 21:12:54.270624
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    test_arg = 'TEST_ARG'
    crypto = Cryptographic(test_arg)
    assert crypto.seed == test_arg

# Generated at 2022-06-23 21:12:55.809468
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    obj=Cryptographic()
    assert type(obj.mnemonic_phrase()) == str


# Generated at 2022-06-23 21:13:01.520990
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    import datetime
    a = Cryptographic()
    assert type(a.uuid()) == str
    assert type(a.uuid(as_object=True)) == UUID
    assert type(a.mnemonic_phrase()) == str
    time = datetime.datetime.utcnow()
    assert a.mnemonic_phrase() != a.mnemonic_phrase()
    assert time < datetime.datetime.utcnow()
    assert type(a.hash()) == str
    assert a.hash() != a.hash()
    assert type(a.token_bytes()) == bytes
    assert a.token_bytes() != a.token_bytes()
    assert type(a.token_hex()) == str
    assert a.token_hex() != a.token_hex()
    assert type(a.token_urlsafe()) == str


# Generated at 2022-06-23 21:13:06.044025
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Example for method hash of class Cryptographic
    crypto = Cryptographic(seed=42)
    print(crypto.hash())  # 'b9e8e30062a3c750747960d3f8c8aa0b'
    print(crypto.hash(Algorithm.MD5))  # '79a87b07fe21f50c2a2a5b6f0d6e948a'
    print(crypto.hash(Algorithm.SHA1))  # '5e0c717b68e27d9c939b0c3d7e765e3d8e8c0ede'
    print(crypto.hash(Algorithm.SHA256))  # 'b7ffa4a034a4ba4b4369bccb7c002d0f9079c2c

# Generated at 2022-06-23 21:13:08.358612
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto_p = Cryptographic()
    answer = crypto_p.token_bytes()
    assert isinstance(answer, bytes)


# Generated at 2022-06-23 21:13:13.913654
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert provider.uuid() is not None
    assert provider.uuid(as_object=True) is not None
    assert provider.hash() is not None
    assert provider.token_bytes() is not None
    assert provider.token_hex() is not None
    assert provider.token_urlsafe() is not None
    assert provider.mnemonic_phrase() is not None


# Generated at 2022-06-23 21:13:24.259300
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    import functools
    import operator
    import sys
    from mimesis.builtins import hash_code

    _id = hash_code(sys.modules[__name__])
    _id = hash_code(_id, Cryptographic.__module__, Cryptographic.__name__)
    from mimesis.enums import Algorithm
    _id = hash_code(_id, Algorithm.__module__, Algorithm.__name__)
    _id = hash_code(_id, Algorithm.SHA256.__module__, Algorithm.SHA256.__name__)
    _id = hash_code(_id, Algorithm.SHA256.value)
    _id = hash_code(_id, Algorithm.SHA256.__dict__)
    _id = hash_code(_id, Algorithm.SHA256.__class__)
   

# Generated at 2022-06-23 21:13:26.803190
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():

    token = Cryptographic().token_hex()
    print(token)
    assert len(token) == 64


# Generated at 2022-06-23 21:13:30.902104
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    for _ in range(1, 10):
        token_bytes = Cryptographic.token_bytes(entropy=64)
        assert(len(token_bytes) == 64)
        assert(isinstance(token_bytes, bytes))


# Generated at 2022-06-23 21:13:33.469975
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    print(c.token_hex(entropy=32))
    print(c.token_hex(entropy=32))


# Generated at 2022-06-23 21:13:36.497943
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    print(type(crypto))


# Generated at 2022-06-23 21:13:42.246630
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Encoding
    cp = Cryptographic(seed=0)
    assert cp.token_hex(10) == b'58f0b8e0c9'
    assert cp.token_hex(10, encoding=Encoding.BASE64) == b'NVhmMGI4ZTBjOQ=='
    assert cp.token_hex() == b'09af985cee45b85c46d13a2c1f0bc85a'

# Generated at 2022-06-23 21:13:43.811083
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() is not None


# Generated at 2022-06-23 21:13:52.688605
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic().uuid() == 'c091b9e9-d74f-4a00-a04a-54dca47e94b5'
    assert Cryptographic().uuid() == 'f5e5b839-e830-42bb-b531-df1eb8f77a61'
    assert Cryptographic().uuid() == 'b2c5658d-f1c6-43f8-b491-a9b9a3d3e28b'
    assert Cryptographic().uuid(as_object=True) == UUID('5c9e2fcd-5e5f-40f0-a519-d30e92ee6cfa')

# Generated at 2022-06-23 21:13:53.995678
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() != Cryptographic().uuid()

# Generated at 2022-06-23 21:14:02.169522
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import json
    import os.path
    import sys
    import unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    class TestCryptographic(unittest.TestCase):

        def setUp(self):
            self.crypto = Cryptographic()
            with open('tests/providers/cryptographic/data.json') as data_file:
                self.data = json.load(data_file)

        def test_hash(self):
            value = self.crypto.hash(algorithm=Algorithm.MD5)

# Generated at 2022-06-23 21:14:02.971445
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    #Test Constructor
    assert(isinstance(Cryptographic(), Cryptographic))


# Generated at 2022-06-23 21:14:04.476621
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  cr = Cryptographic()
  cr.token_urlsafe()


# Generated at 2022-06-23 21:14:06.836768
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    result = provider.hash()
    assert len(result) == 64
    assert result == "c224ad981e128cfc22e2e9ddcafb360fd41b0e1a1db8e27c1b0846d4e4d99c60"

# Generated at 2022-06-23 21:14:09.534647
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test for Cryptographic method mnemonic_phrase."""
    crypto = Cryptographic()
    assert len(crypto.mnemonic_phrase().split()) == 12

# Generated at 2022-06-23 21:14:10.877015
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert "encrypt identity" == Cryptographic().mnemonic_phrase()

# Generated at 2022-06-23 21:14:13.334516
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    t = Cryptographic()
    a = t.token_bytes(entropy=1)
    print(a)
    return a


# Generated at 2022-06-23 21:14:15.076031
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.sha256)

# Generated at 2022-06-23 21:14:17.358763
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # init
    result = Cryptographic()
    # assert
    assert result is not None


# Generated at 2022-06-23 21:14:23.523287
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    tokens = {}
    for i in range(100):
        token = Cryptographic().token_hex()
        tokens[token] = tokens.get(token, 0) + 1
    for key, value in tokens.items():
        if value != 1:
            print('ERROR: token_hex fails to produce unique tokens!')
            print(key,value)


# Generated at 2022-06-23 21:14:26.719358
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    alg1 = Algorithm.MD5
    alg2 = Algorithm.SHA3_256
    assert len(Cryptographic().hash(alg1)) == 32
    assert len(Cryptographic().hash(alg2)) == 64


# Generated at 2022-06-23 21:14:29.448464
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    assert phrase is not None and len(phrase) > 0

# Generated at 2022-06-23 21:14:31.711506
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic.token_urlsafe()
    assert len(token) > 0



# Generated at 2022-06-23 21:14:38.874081
# Unit test for method token_bytes of class Cryptographic

# Generated at 2022-06-23 21:14:40.229053
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print(Cryptographic().token_bytes())


# Generated at 2022-06-23 21:14:42.759665
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    data = Cryptographic().uuid()
    assert type(data) == str
    assert len(data) == 36


# Generated at 2022-06-23 21:14:52.939302
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import random
    import string
    import re
    import base64
    from mimesis.providers.cryptographic import Cryptographic

    contains_characters = False
    random.seed(1)
    for i in range(0, 100):
        url_safe_token = Cryptographic.token_urlsafe()
        contains_characters = bool(re.search('[A-Za-z]', url_safe_token))
        if contains_characters == True:
            break

    # Test that the URL-safe token contains characters
    assert contains_characters == True

    contains_equal = False
    random.seed(1)
    contains_plus = False
    random.seed(1)
    contains_slash = False
    random.seed(1)
    for i in range(0, 100):
        url_safe_

# Generated at 2022-06-23 21:14:56.344565
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert crypto.token_hex(20) is not crypto.token_hex(20)
    assert crypto.token_hex(20) is not crypto.token_hex(30)
    assert crypto.token_hex() is not crypto.token_hex()


# Generated at 2022-06-23 21:15:03.211728
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Test case data
    entropy_list = [0, 5, 10, 15, 20]

    # loop through the list of entries
    # and check the results
    for entropy in entropy_list:
        token = Cryptographic().token_urlsafe(entropy)
        if entropy == 0 or entropy == 5 or entropy == 10 or entropy == 15 or entropy == 20:
            assert token == token
            print("Test passed for entropy:: ", entropy)



# Generated at 2022-06-23 21:15:04.935784
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    ret = Cryptographic.mnemonic_phrase()
    assert ' ' in ret
    assert len(ret) >= 12

# Generated at 2022-06-23 21:15:06.470914
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic.token_hex(entropy=32)
    assert token


# Generated at 2022-06-23 21:15:11.858435
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    print(provider.mnemonic_phrase())
    print(provider.uuid())
    print(provider.token_urlsafe())
    print(provider.token_hex())
    print(provider.hash(Algorithm.SHA1))
    print(provider.uuid(True))
    print(provider.uuid(True).get_version())
    print(provider.uuid(True).bytes)
    print(provider.uuid(True).hex)
    print(provider.uuid(True).int)
    print(provider.uuid(True).urn)
    print(provider.uuid(True).variant)
    print(provider.uuid(True).fields)
    print(provider.uuid(True).time_low)

# Generated at 2022-06-23 21:15:14.227324
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    print(provider.uuid())
    print(provider.uuid(True))

# Generated at 2022-06-23 21:15:19.616591
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    obj = Cryptographic()
    r1 = obj.mnemonic_phrase(length=5, separator='+')
    assert isinstance(r1, str) == True
    assert len(r1.split('+')) == 5
    r2 = obj.mnemonic_phrase()
    assert isinstance(r2, str) == True
    assert len(r2.split(' ')) == 12
    r3 = obj.mnemonic_phrase(separator='-')
    assert isinstance(r3, str) == True
    assert len(r3.split('-')) == 12
    r4 = obj.mnemonic_phrase(length=8)
    assert isinstance(r4, str) == True
    assert len(r4.split(' ')) == 8

# Generated at 2022-06-23 21:15:22.031414
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash = Cryptographic().hash(Algorithm.SHA224)
    assert hash
    assert isinstance(hash, str)


# Generated at 2022-06-23 21:15:25.557425
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    c = Cryptographic()
    assert type(c.uuid()) == type(c.uuid(as_object=True))
    assert len(c.uuid()) == 32


# Generated at 2022-06-23 21:15:28.221322
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    r = Cryptographic().token_hex(16)
    assert len(r) == 32, 'Invalid length'
    assert r.isalnum()


# Generated at 2022-06-23 21:15:30.611795
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(42) != c.token_urlsafe(42)


# Generated at 2022-06-23 21:15:38.318968
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import random
    # Check that method hash is working as expected
    # Initiate the Object
    cObj = Cryptographic(random)
    # Check that the object is created successfully
    assert(cObj != None)
    # Check that the method hash is working as expected
    method_hash = cObj.hash(Algorithm.MD5)
    assert(method_hash is not None)
    assert(method_hash != '')
    # Check that the length of the hash is not null
    assert(len(method_hash) != 0)
    # Check that the length of hash is 32
    assert(len(method_hash) == 32)
    assert(method_hash.isalnum())
    # Check that the method is_alphanumeric is working as expected
    assert(method_hash.isalnum() == True)
    # Check that the method is

# Generated at 2022-06-23 21:15:48.596525
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # For unit testing use
    # python -m unittest discover -s test
    # or
    # python -m unittest discover -s test -p '*_test.py'

    c = Cryptographic()

    # Cryptographic.uuid()
    # type(UUID)
    a = c.uuid()
    assert isinstance(a, str)

    # type(str)
    b = c.uuid(as_object=False)
    assert isinstance(b, str)

    # type(UUID)
    c = c.uuid(as_object=True)
    assert isinstance(c, UUID)

    # Cryptographic.hash()
    # type(str)
    a = c.hash()
    assert isinstance(a, str)

    # Cryptographic.token_bytes()
   

# Generated at 2022-06-23 21:15:50.751284
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    assert obj != None


# Generated at 2022-06-23 21:15:52.432894
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():


    output = Cryptographic.hash()
    assert len(output) > 0
    assert isinstance(output, str)



# Generated at 2022-06-23 21:15:54.103194
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    p = Cryptographic()
    assert p


# Generated at 2022-06-23 21:16:03.194387
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    # Check Cryptographic().token_hex() is a str
    assert isinstance(Cryptographic().token_hex(), str)
    # Check Cryptographic().token_hex(1) is a str
    assert isinstance(Cryptographic().token_hex(1), str)
    # Check len(Cryptographic().token_hex(1)) is 2
    assert len(Cryptographic().token_hex(1)) is 2
    # Check Cryptographic().token_hex(32) is a str
    assert isinstance(Cryptographic().token_hex(32), str)
    # Check len(Cryptographic().token_hex(32)) is 64
    assert len(Cryptographic().token_hex(32)) is 64
    # Check Cryptographic().token_hex(64

# Generated at 2022-06-23 21:16:04.559510
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    bytes = Cryptographic.token_bytes()
    print(bytes)


# Generated at 2022-06-23 21:16:06.484914
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test Cryptographic.token_hex."""
    hash = Cryptographic().token_hex()
    assert hash is not None

# Generated at 2022-06-23 21:16:07.582507
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) > 1

# Generated at 2022-06-23 21:16:09.060744
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    assert a.hash() != a.hash()

# Generated at 2022-06-23 21:16:17.931531
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    print('Algorithm: ', Algorithm.__name__) #Test for method name
    print('Algorithm: ', Algorithm.BLAKE2B) #Test for enum value
    print('Algorithm: ', Algorithm.BLAKE2B.value) #Test for enum value
    print('UUID: ', Cryptographic().uuid(as_object=True)) #Test for method uuid
    print('UUID: ', Cryptographic().uuid()) #Test for method uuid
    print('Hash: ', Cryptographic().hash(Algorithm.SHA3_384)) #Test for method hash
    print('Hash: ', Cryptographic().hash()) #Test for method hash
    print('Token Bytes: ', Cryptographic().token_bytes()) #Test for method token_bytes

# Generated at 2022-06-23 21:16:19.305625
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic.token_urlsafe()
    assert len(token) == 43



# Generated at 2022-06-23 21:16:22.372703
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import random
    random.seed(5)
    x = Cryptographic.token_urlsafe()
    assert x == 'FhRb2Q2MK0c'


# Generated at 2022-06-23 21:16:23.599139
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    pass



# Generated at 2022-06-23 21:16:25.655882
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    res = c.token_bytes(entropy=32)
    assert len(res) == 32


# Generated at 2022-06-23 21:16:30.799694
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Default
    actual = Cryptographic.uuid()
    expected = (
        '00000000-0000-0000-0000-000000000000'
    )
    assert actual == expected

    # With object
    actual = Cryptographic.uuid(True)
    expected = UUID('00000000-0000-0000-0000-000000000000')
    assert actual == expected


# Generated at 2022-06-23 21:16:38.597715
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic(seed=24)
    assert crypto.hash() == '0cee3ba8d88a68f7dcefb1a3831c3b9e'
    assert crypto.hash("md5") == '0cee3ba8d88a68f7dcefb1a3831c3b9e'
    crypto.seed(24)
    assert crypto.hash("sha1") == '723adb9a4d2ae4e62a26a7eed8124d77eaa7fd62'
    crypto.seed(24)
    assert crypto.hash("sha224") == '2a8b70fb02a7cbe6322f420a2ff24c9d6873cacbfdd1bd73b3c845e3'
    crypto.seed(24)

# Generated at 2022-06-23 21:16:42.544485
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()

    val = crypto.token_hex(16)
    assert val
    assert type(val) == str
    assert len(val) == 32

    # call again, will return new random hex string
    val = crypto.token_hex(16)
    assert val
    assert type(val) == str
    assert len(val) == 32


# Generated at 2022-06-23 21:16:48.930617
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
	'''This is a test for unit test'''
	inputs = [32]
	outputs = ['0x7bef6e1768c48b55107412c9fcfbc8bc']
	for i in range(len(inputs)):
		assert Cryptographic.token_hex(inputs[i]) == outputs[i]

# Generated at 2022-06-23 21:16:50.710837
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()

    assert c.mnemonic_phrase() == "rotten simile electric deafen"


# Generated at 2022-06-23 21:16:51.905301
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-23 21:16:57.088170
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm
    provider = Cryptographic()
    data = provider.uuid()
    assert isinstance(data, str)
    assert len(data) == 36
    data = provider.uuid(as_object=True)
    assert isinstance(data, UUID)
    assert len(str(data)) == 36


# Generated at 2022-06-23 21:17:00.365926
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for Cryptographic.uuid"""
    assert_equal(Cryptographic.uuid(),
                 'f5c34b05-d3b3-4b2e-9f30-9b38fbdf0054')


# Generated at 2022-06-23 21:17:03.962257
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """test the hash method of Cryptographic class."""
    from mimesis.enums import Algorithm

    assert isinstance(Cryptographic().hash(Algorithm.SHA1), str)
    assert isinstance(Cryptographic().hash(Algorithm.SHA256), str)
    assert isinstance(Cryptographic().hash(Algorithm.SHA512), str)


# Generated at 2022-06-23 21:17:05.472877
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    assert len(Cryptographic.token_urlsafe()) == 43
    assert len(Cryptographic.token_urlsafe(16)) == 24


# Generated at 2022-06-23 21:17:09.952667
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Test constructor of class Cryptographic
    cry = Cryptographic()
    assert cry != None
    assert cry.__hash__() != None
    assert cry.__str__() != None
    assert cry.__doc__ != None




# Generated at 2022-06-23 21:17:17.531204
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test Cryptographic.uuid method."""
    import uuid
    uuidObj = uuid.UUID('6fa459ea-ee8a-3ca4-894e-db77e160355e')
    assert isinstance(Cryptographic().uuid(as_object=True), uuid.UUID)
    assert Cryptographic().uuid(as_object=True) == uuidObj
    assert isinstance(Cryptographic().uuid(), str)
    assert Cryptographic().uuid() == str(uuidObj)


# Generated at 2022-06-23 21:17:27.953445
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()

# Generated at 2022-06-23 21:17:34.789625
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    provider = Cryptographic()
    assert re.match("^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$", provider.uuid())


# Generated at 2022-06-23 21:17:36.225276
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cry = Cryptographic()
    assert cry.token_hex() != None

# Generated at 2022-06-23 21:17:40.370849
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic."""
    uuid_object = Cryptographic().uuid(True)
    assert isinstance(uuid_object, UUID)
    assert isinstance(Cryptographic().uuid(), str)
    assert len(str(uuid_object)) == 36



# Generated at 2022-06-23 21:17:44.189655
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic"""
    crypto = Cryptographic()
    result = crypto.hash(Algorithm.SHA512)
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:17:45.134491
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 45

# Generated at 2022-06-23 21:17:50.080819
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # return a random URL-safe text string, in Base64 encoding.
    # The string has *entropy* random bytes.  If *entropy* is "None"
    # or not supplied, a reasonable default is used.
    token = Cryptographic().token_urlsafe(entropy=8)
    token2 = Cryptographic().token_urlsafe()
    assert len(token) == 12
    assert len(token2) >= 32

# Generated at 2022-06-23 21:17:54.536352
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    params = [
        (16,),
        (32,),
    ]
    expected_results = [
        '3d95f1f46ab4b4ffa4d71a41e596d8ee',
        '2c0d1298d09e7194e72a27fe561e0924',
    ]
    for index, (input_data, ) in enumerate(params):
        result = Cryptographic.token_hex(input_data)
        assert result == expected_results[index]


# Generated at 2022-06-23 21:17:57.763994
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cryptographic = Cryptographic()
    token_bytes = cryptographic.token_bytes()
    assert len(token_bytes) == 32


# Generated at 2022-06-23 21:18:01.764821
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.mnemonic_phrase())
    print(c.hash())
    print(c.uuid())
    print(c.token_bytes())
    print(c.token_hex())
    print(c.token_urlsafe())

if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-23 21:18:08.048314
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    test_list = []
    for _ in range(10):
        mnemonic_phrase = crypto.mnemonic_phrase()
        test_list.append(mnemonic_phrase)
        assert isinstance(mnemonic_phrase, str)

    len_list = []
    for item in test_list:
        len_list.append(len(item.split(' ')))
    assert (len(set(len_list)) == 1)

# Generated at 2022-06-23 21:18:09.713848
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    word = crypto.mnemonic_phrase(10)
    assert word != ''

# Generated at 2022-06-23 21:18:11.039377
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto is not None


# Generated at 2022-06-23 21:18:18.608900
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Test variant 1
    assert 'c5550e8e-d584-4d18-9c0e-d8ccc7e6a364' == Cryptographic.uuid()
    # Test variant 2
    assert 'a7c5d5be-e7a5-4a5c-b120-8a1bd7d907b9' == Cryptographic.uuid()
    # Test variant 3
    assert '7c1db2d3-7a9f-4e0f-84d8-f91b7f4ccb4c' == Cryptographic.uuid()
    # Test variant 4
    assert 'd88f5c5a-2e66-4285-ad19-a24327d7657f' == Cryptographic.uuid()
    # Test variant 5

# Generated at 2022-06-23 21:18:23.369446
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    expected = 'cxqB3i9Zv39bZiWV2jKq3QPVyvU8zEwL7xU_zpUYXvB'
    assert Cryptographic().token_urlsafe() == expected

# Generated at 2022-06-23 21:18:26.165425
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic"""
    numeric_type_value="Hello World"

    assert numeric_type_value.isnumeric() == False

# Generated at 2022-06-23 21:18:30.160935
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    data = Cryptographic()
    mnemonic_phrase = data.mnemonic_phrase()
    assert isinstance(mnemonic_phrase, str)


# Generated at 2022-06-23 21:18:33.718095
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Arrange
    # Act
    uuid = Cryptographic.uuid()
    # Assert
    assert isinstance(uuid, str)
    assert len(uuid) == 36
    assert uuid[14] == '4'
    assert uuid[19] in '89ab'


# Generated at 2022-06-23 21:18:35.303220
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    Cryptographic().hash(Algorithm('md5'))

# Generated at 2022-06-23 21:18:36.571578
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto



# Generated at 2022-06-23 21:18:38.960679
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == '1abacdfe-7b38-4f3b-8a3f-b9d2d9cfea7f'


# Generated at 2022-06-23 21:18:40.378120
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert isinstance(provider, Cryptographic)

# Generated at 2022-06-23 21:18:41.832679
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a = Cryptographic().token_hex()
    print('Token Hex: ', a)
    assert len(a) == 64


# Generated at 2022-06-23 21:18:43.833610
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.__class__.__name__ == 'Cryptographic'


# Generated at 2022-06-23 21:18:45.755253
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert secrets.token_bytes(16) == secrets.token_bytes(16)

# Generated at 2022-06-23 21:18:47.223554
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.mnemonic_phrase()

# Generated at 2022-06-23 21:18:49.557336
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cryp = Cryptographic('en')
    cryp.mnemonic_phrase()


# Generated at 2022-06-23 21:18:53.232715
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    test_str = Cryptographic().token_hex()

    assert isinstance(test_str, str)
    assert len(test_str) == 64
    assert test_str.isalnum()



# Generated at 2022-06-23 21:18:56.453106
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5)
    assert Cryptographic().hash(Algorithm.SHA1)
    assert Cryptographic().hash(Algorithm.SHA256)
    assert Cryptographic().hash(Algorithm.SHA384)
    assert Cryptographic().hash(Algorithm.SHA512)


# Generated at 2022-06-23 21:19:02.787945
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Should return a random URL-safe text string, in Base64 encoding
    # The string has *entropy* random bytes.  If *entropy* is ``None``
    # or not supplied, a reasonable default is used.
    assert len(Cryptographic().token_urlsafe(16)) == 16
    assert len(Cryptographic().token_urlsafe(32)) == 32
    assert len(Cryptographic().token_urlsafe(64)) == 64

    assert len(Cryptographic().token_urlsafe(32)) != 16
    assert len(Cryptographic().token_urlsafe(64)) != 32
    assert len(Cryptographic().token_urlsafe()) != 64
