

# Generated at 2022-06-23 21:09:00.919592
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    result = Crypto.token_urlsafe()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:09:04.060841
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():

    potential_results = [12, 14, 16]
    count = 0

    for _ in range(10000):
        if len(Cryptographic().mnemonic_phrase()) in potential_results:
            count += 1

    assert count == 10000

# Generated at 2022-06-23 21:09:11.008993
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    # change hash algorithm
    key = "md5"
    fn = getattr(hashlib, key)
    hash_val = fn(obj.uuid().encode()).hexdigest()

    if(hash_val == obj.hash(algorithm=Algorithm.MD5)):
        print(hash_val == obj.hash(algorithm=Algorithm.MD5))
        print(hash_val)
        print(obj.hash(algorithm=Algorithm.MD5))
    else:
        print(hash_val == obj.hash(algorithm=Algorithm.MD5))
        print(hash_val)
        print(obj.hash(algorithm=Algorithm.MD5))



# Generated at 2022-06-23 21:09:14.660289
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    test = Cryptographic()
    str1 = test.token_bytes()
    str2 = test.token_bytes()
    assert str1 != str2



# Generated at 2022-06-23 21:09:20.484502
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic"""
    from mimesis import Cryptographic
    from mimesis.enums import Seed

    s = Cryptographic(Seed.MIMESIS)
    assert s.mnemonic_phrase(4) != s.mnemonic_phrase(4)
    assert len(s.mnemonic_phrase(5).split()) == 5
    assert s.mnemonic_phrase(0) == ''
    assert s.mnemonic_phrase(0).split() == ['']
    assert s.mnemonic_phrase(-1) == ''


# Generated at 2022-06-23 21:09:24.213394
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Arrange
    provider = Cryptographic()

    # Act
    actual = provider.uuid()

    # Assert
    assert (type(actual) == str)
    assert (len(actual) == 36)
    assert (actual is not None)



# Generated at 2022-06-23 21:09:25.175279
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert type(Cryptographic().token_hex()) == str

# Generated at 2022-06-23 21:09:36.527261
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypt = Cryptographic()
    hash1 = crypt.uuid()
    hash2 = crypt.uuid(as_object=True)
    hash3 = crypt.hash(Algorithm.MD5)
    hash4 = crypt.hash(Algorithm.SHA512)
    hash5 = crypt.token_bytes()
    hash6 = crypt.token_hex()
    hash7 = crypt.token_urlsafe()
    hash8 = crypt.mnemonic_phrase(3)
    assert isinstance(hash1, str)
    assert isinstance(hash2, UUID)
    assert isinstance(hash3, str)
    assert isinstance(hash4, str)
    assert isinstance(hash5, bytes)
    assert isinstance(hash6, str)
    assert isinstance(hash7, str)
    assert isinstance(hash8, str)

# Generated at 2022-06-23 21:09:38.829846
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    x = Cryptographic()
    m = x.token_hex(32)
    n = x.token_hex(32)
    if m == n:
        print("token_hex is not correct")
    else:
        print("token_hex is correct")


# Generated at 2022-06-23 21:09:49.332584
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    cp = Cryptographic()
    t = cp.token_urlsafe()
    assert type(t) == str
    assert len(t) == 44
    with open("/tmp/test_Cryptographic.log", 'w') as f:
        f.write("In test_Cryptographic_token_urlsafe:\n\n")
        f.write("cp.token_urlsafe() returned:\n\n")
        f.write("====>{}\n".format(t))
        f.write("====>{}\n".format(type(t)))
        f.write("====>{}\n".format(len(t)))
        f.write("\n==========================================================\n")
    return

# Generated at 2022-06-23 21:09:50.588920
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    print(provider.uuid())


# Generated at 2022-06-23 21:09:52.156895
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic().__class__.__name__ == 'Cryptographic'

# Generated at 2022-06-23 21:09:53.513442
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert isinstance(Cryptographic.token_bytes(), bytes)


# Generated at 2022-06-23 21:09:54.857287
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    print (a.mnemonic_phrase())

# Generated at 2022-06-23 21:09:56.377937
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    result = Cryptographic.token_bytes()
    assert isinstance(result, bytes)
    assert len(result) == 32


# Generated at 2022-06-23 21:09:57.444543
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase() != ''
    assert crypto.hash() != ''

# Generated at 2022-06-23 21:10:08.712211
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    test_cases = [
        (12, None, None),
        (13, None, None),
        (10, '|', None),
        (20, '|', None),
        (15, None, b'123456')
    ]

    for words, separator, seed in test_cases:
        crypto = Cryptographic(seed=seed)
        assert len(crypto.mnemonic_phrase(words, separator).split(' ')) == words

    # Test Algorithm handles

# Generated at 2022-06-23 21:10:10.182564
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic(random=True).mnemonic_phrase() != None
    

# Generated at 2022-06-23 21:10:12.709585
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    seed = None
    provider = Cryptographic(seed)
    token = provider.token_hex()

    assert isinstance(token, str)
    assert len(token) > 0
    assert not token.isspace()

# Generated at 2022-06-23 21:10:14.445651
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic().token_hex() == '278ef1b826aab31efaee577e45c2744d'

# Generated at 2022-06-23 21:10:15.911071
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe()
    assert type(token) is str

# Generated at 2022-06-23 21:10:17.954233
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert provider.__init__(provider)

# Generated at 2022-06-23 21:10:20.301376
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    uuid_data = obj.uuid()


# Generated at 2022-06-23 21:10:22.872354
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Test method Cryptographic.token_bytes
    test = Cryptographic()
    assert isinstance(test.token_bytes(), bytes)


# Generated at 2022-06-23 21:10:26.179084
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test method token_urlsafe of class Cryptographic."""
    crypto = Cryptographic()
    token = crypto.token_urlsafe()
    assert isinstance(token, str)
    assert len(token) == 43


# Generated at 2022-06-23 21:10:27.534473
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64


# Generated at 2022-06-23 21:10:31.330309
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 64
    assert len(Cryptographic.token_bytes(16)) == 32
    assert Cryptographic.token_bytes(16).count(b'\x00') <= 1


# Generated at 2022-06-23 21:10:38.795681
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert(c.hash(Algorithm.BLAKE2B)=='58aa3d75f0b9a76a8a88ac44d0781e65a6327a7ab8c8b2a2b6622c82bd77b105c46b6a51e7c570fb33791c743c0e8ed7')
    assert(c.hash(Algorithm.BLAKE2S)=='488f28b6da85b6fc1b6f0cec2a9e8f8ca2bd2d41c459d7a1ccce0f8d78c70c6e')


# Generated at 2022-06-23 21:10:42.413900
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method Cryptographic.hash."""
    Cryptographic.hash(algorithm=None).should.be.a('str')
    Cryptographic.hash(algorithm=Algorithm.MD5).should.be.a('str')


# Generated at 2022-06-23 21:10:44.471311
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cr = Cryptographic()
    result = cr.token_bytes()
    print(result)
    assert len(result) == 32


# Generated at 2022-06-23 21:10:46.781325
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == len('xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx')
    assert len(Cryptographic().uuid(as_object=True)) == 16


# Generated at 2022-06-23 21:10:54.917755
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto_data = Cryptographic()

    # When algorithm is not set it will default to 'sha1'
    assert crypto_data.hash() == 'd51eb4f97a0c4bcab5d5b5adf8a8b2e2bcd1d7d5'
    assert crypto_data.hash(algorithm=Algorithm.SHA1) == '6710c80ddf9ceac2afd252247a8b2285c64b63d3'
    assert crypto_data.hash(algorithm=Algorithm.SHA256) == '0a36b340eeabf0bd7c770a085ba5a2ae547bdb9d20eae98f8e7e0c0d6c26750e'
    assert crypto_data.hash(algorithm=Algorithm.SHA512)

# Generated at 2022-06-23 21:10:58.817772
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    phrases = []
    for i in range(100):
        phrases.append(c.mnemonic_phrase())
    return phrases


# Generated at 2022-06-23 21:11:01.783700
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    result = crypto.token_bytes()
    assert len(result) == 32
    assert type(result) == bytes


# Generated at 2022-06-23 21:11:04.369096
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crp = Cryptographic()
    assert len(crp.uuid()) == 36
    assert len(crp.uuid(as_object=True)) == 36

# Generated at 2022-06-23 21:11:06.336969
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert crypto.uuid(as_object=True) is not None


# Generated at 2022-06-23 21:11:07.579747
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase()

# Generated at 2022-06-23 21:11:11.675025
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    s = c.token_hex()
    assert len(s) == 64
    assert isinstance(s, str)


# Generated at 2022-06-23 21:11:12.758617
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    Cryptographic().token_bytes()


# Generated at 2022-06-23 21:11:13.581940
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert crypto.token_bytes(32)


# Generated at 2022-06-23 21:11:16.678915
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None
    assert Cryptographic().hash(Algorithm.SHA512) is not None
    assert Cryptographic().hash(Algorithm.SHA256) is not None


# Generated at 2022-06-23 21:11:18.782366
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert isinstance(c.token_bytes(), bytes)


# Generated at 2022-06-23 21:11:21.403554
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    cryptographic = Cryptographic()
    assert cryptographic.hash() is not None


# Generated at 2022-06-23 21:11:22.414312
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  assert Cryptographic.hash() != Cryptographic.hash()


# Generated at 2022-06-23 21:11:32.050291
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    x = Cryptographic.token_hex(entropy = 32)
    #print(x)
    assert x is not None
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-23 21:11:36.252913
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    try:
        dict_ = Cryptographic().__dict__
        name = dict_['_name']  # type: ignore
        assert name == 'cryptographic', \
            'Fail: name must be "cryptographic", but is "{}"'.format(name)
    except Exception as e:
        raise e

# Generated at 2022-06-23 21:11:37.524387
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    assert obj != None

# Generated at 2022-06-23 21:11:39.921836
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto_provider = Cryptographic()
    crypto_provider.mnemonic_phrase()


# Generated at 2022-06-23 21:11:41.403387
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    #print(cr.mnemonic_phrase())

# Generated at 2022-06-23 21:11:44.109565
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Tests for the Cryptographic class."""
    c = Cryptographic()
    assert len(c.token_urlsafe()) == 22



# Generated at 2022-06-23 21:11:46.725763
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    token = crypto.token_urlsafe()
    assert token is not None
    assert token != ''


# Generated at 2022-06-23 21:11:47.951449
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # result = Cryptographic().token_urlsafe(32)
    # assert result
    pass

# Generated at 2022-06-23 21:11:49.687163
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Testing method token_bytes of class Cryptographic
    token = Cryptographic().token_bytes()
    assert isinstance(token, bytes)

# Generated at 2022-06-23 21:11:52.426024
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Arrange
    expected_lenght = 20
    cryp = Cryptographic()

    # Act
    result = cryp.token_hex(expected_lenght)

    # Assert
    assert len(result) == expected_lenght * 2


# Generated at 2022-06-23 21:11:59.405723
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.builtins import Cryptographic
    from mimesis.enums import Algorithm
    from mimesis.providers.text import Text
    import pytest
    from random import Random
    from seed.helper.safe_cast import safe_int
    random = Random(32845)
    data = Text('en')._data
    words = data.get('words', {})
    words = words['normal']
    words_count = len(words)
    length = 1
    separator = ' '
    crypto = Cryptographic(seed=32845)
    crypto._random = random
    crypto._data = data
    crypto.__words = {'normal': words}
    mnemonic_phrase = crypto.mnemonic_phrase(
        length=length, separator=separator,
    )

# Generated at 2022-06-23 21:12:02.153765
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() == 'b04c5730-2d1b-4c1f-a696-c90848e918b0'
    assert Cryptographic().uuid(as_object=True) == uuid.UUID('b04c5730-2d1b-4c1f-a696-c90848e918b0')


# Generated at 2022-06-23 21:12:05.657107
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    _c = Cryptographic()

    _t = _c.token_hex()

    assert isinstance(_t, str)
    assert len(_t) == 64

# Generated at 2022-06-23 21:12:15.714548
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase())
    print(crypto.mnemonic_phrase(1))
    print(crypto.mnemonic_phrase(2, '-'))
    print(crypto.mnemonic_phrase(3, '_'))
    print(crypto.mnemonic_phrase(4, '-'))
    print(crypto.mnemonic_phrase(5))
    print(crypto.mnemonic_phrase(6))
    print(crypto.mnemonic_phrase(7, '_'))
    print(crypto.mnemonic_phrase(8, ':'))
    print(crypto.mnemonic_phrase(9, '-'))
    print(crypto.mnemonic_phrase(10, ':'))
    print(crypto.mnemonic_phrase(11))

# Generated at 2022-06-23 21:12:20.173060
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic"""
    obj = Cryptographic(seed=123456789)
    result = obj.mnemonic_phrase()
    expected = "solution bottle body sketch stem"
    assert result == expected


# Generated at 2022-06-23 21:12:28.054496
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Test normal behaviour
    token1 = Cryptographic().token_urlsafe(entropy=10)
    assert isinstance(token1, str)
    assert len(token1) == 16

    # Test incorrect type of variable
    token2 = Cryptographic().token_urlsafe(entropy='10')
    assert isinstance(token2, str)
    assert len(token2) == 16

    # When entropy is 0
    token3 = Cryptographic().token_urlsafe(entropy=0)
    assert isinstance(token3, str)
    assert len(token3) == 4



# Generated at 2022-06-23 21:12:29.599507
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase())

if __name__ == '__main__':
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:12:37.049000
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import secrets
    import re
    # the token_urlsafe function inside secrets should generate a string
    # composed of [a-zA-Z0-9_-] and have a length of 32
    # to make sure it can be used in a web app
    assert re.match("^[a-zA-Z0-9_-]{32}$", secrets.token_urlsafe(32)) is not None

# Generated at 2022-06-23 21:12:38.299563
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    test = crypto.hash()
    print(test)


# Generated at 2022-06-23 21:12:39.383474
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) >= 32


# Generated at 2022-06-23 21:12:40.517833
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    assert Cryptographic().hash() is not None



# Generated at 2022-06-23 21:12:42.567471
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert isinstance(crypto, Cryptographic)


# Generated at 2022-06-23 21:12:43.977571
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cry = Cryptographic()
    cry.mnemonic_phrase()

# Generated at 2022-06-23 21:12:45.622508
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert crypto.token_bytes(32).decode().isalnum()


# Generated at 2022-06-23 21:12:46.978692
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert isinstance(c, Cryptographic)


# Generated at 2022-06-23 21:12:49.358666
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    obj = Cryptographic()
    assert isinstance(obj.hash(), str)


# Generated at 2022-06-23 21:12:50.948087
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    token = c.token_urlsafe()
    assert len(token) == 45

# Generated at 2022-06-23 21:12:57.942229
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # test the class
    assert len(Cryptographic().hash()) == 128

    assert len(Cryptographic().hash(Algorithm.SHA3_256)) == 64

    assert len(Cryptographic().mnemonic_phrase()) == 24
    assert len(Cryptographic().mnemonic_phrase(12, "-")) == 25

    assert len(Cryptographic().token_hex()) == 64

    assert len(Cryptographic().token_bytes()) == 32

    assert len(Cryptographic().token_urlsafe()) == 45

    assert Cryptographic().uuid() == '9e9f7250-a408-4a71-b074-012a4aa4f961'

    assert Cryptographic().uuid(True) == UUID('9e9f7250-a408-4a71-b074-012a4aa4f961')

# Generated at 2022-06-23 21:12:58.720469
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert len(Cryptographic().mnemonic_phrase()) == 12

# Generated at 2022-06-23 21:13:00.321621
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cryptographic()

# Generated at 2022-06-23 21:13:02.319257
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic.token_bytes()
    assert len(token) == 32


# Generated at 2022-06-23 21:13:04.198598
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid_str = Cryptographic.uuid()
    assert type(uuid_str) is str


# Generated at 2022-06-23 21:13:06.738297
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypt = Cryptographic()
    crypt.token_bytes()

# Generated at 2022-06-23 21:13:08.399957
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Should return a hash
    assert isinstance(Cryptographic().hash(), str)


# Generated at 2022-06-23 21:13:10.640166
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    print(c.token_hex())
    return True


# Generated at 2022-06-23 21:13:12.118089
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe()

# Generated at 2022-06-23 21:13:19.788686
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    cp = Cryptographic()
    print(cp.token_urlsafe())
    print(cp.token_urlsafe(16))
    print(cp.token_urlsafe(65))
    print(cp.hash(Algorithm.MD5))
    print(cp.hash(Algorithm.SHA1))
    print(cp.hash(Algorithm.SHA224))
    print(cp.hash(Algorithm.SHA256))
    print(cp.hash(Algorithm.SHA384))
    print(cp.hash(Algorithm.SHA512))
    print(cp.token_hex())
    print(cp.token_hex(16))
    print(cp.token_hex(65))
    print(cp.token_bytes())
    print(cp.token_bytes(16))

# Generated at 2022-06-23 21:13:21.068127
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 36

# Generated at 2022-06-23 21:13:26.803464
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # GIVEN a Cryptographic object
    cryptoclass = Cryptographic(seed=123)

    # WHEN obtaining a token urlsafe
    expected_result = 'U6XaU6x8dvTKjQwkwYq3rBHWjBd7rIIR_Rn9XpkJGpc'
    result = cryptoclass.token_urlsafe()
    # THEN the result should be as expected
    assert result == expected_result


# Generated at 2022-06-23 21:13:28.352681
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    res = crypto.token_hex()
    print(res)
    assert len(res) == 64  # Default length 32

# Generated at 2022-06-23 21:13:29.751227
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(Cryptographic().token_hex())

# Generated at 2022-06-23 21:13:31.507729
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) > 0


# Generated at 2022-06-23 21:13:34.418268
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    expected = "fame assume whom vague quick"
    cc = Cryptographic("test")
    result = cc.mnemonic_phrase()
    assert result == "fame assume whom vague quick"

# Generated at 2022-06-23 21:13:36.051599
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()
    assert Cryptographic().hash(Algorithm.SHA512)


# Generated at 2022-06-23 21:13:36.671549
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    pass

# Generated at 2022-06-23 21:13:46.416235
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import secrets
    import string
    import random
    import re
    import base64
    url_valid_chars = '-_' + string.ascii_letters + string.digits
    chars_in_base64 = string.ascii_letters + string.digits + '+/'
    
    entropy = random.randint(1,100)
    token = secrets.token_urlsafe(entropy)
    
    # Check every character in token
    for char in token:
        assert char in chars_in_base64 or char in url_valid_chars, f'{char} is not in base64 or url_valid_chars'
        assert char not in '/', f'{char} is invalid'
        assert char not in '+', f'{char} is invalid'
    
    # Token length must be

# Generated at 2022-06-23 21:13:48.703059
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() is not None
    assert Cryptographic().uuid(as_object=True) is not None


# Generated at 2022-06-23 21:13:51.341514
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    p = Cryptographic()
    assert type(p.mnemonic_phrase(length=10)) is str
    assert type(p.mnemonic_phrase(length=50)) is str
    assert type(p.mnemonic_phrase()) is str


# Generated at 2022-06-23 21:13:53.106240
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    uid = crypto.uuid()
    assert isinstance(uid, str)



# Generated at 2022-06-23 21:13:54.823310
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    #print (c.uuid())
    assert type(c.uuid()) == str


# Generated at 2022-06-23 21:13:56.164667
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    assert a.uuid() != None

# Generated at 2022-06-23 21:13:57.642560
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token_hex = Cryptographic().token_hex()
    assert(len(token_hex) == 64)

# Generated at 2022-06-23 21:14:00.075951
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initialize a Cryptographic instance
    __instance = Cryptographic("en")
    # Initialize a Algorithm instance
    __instance = __instance.hash(Algorithm.MD5)



# Generated at 2022-06-23 21:14:03.485949
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic.
    """
    cg = Cryptographic()
    assert len(cg.uuid()) == 36

# Generated at 2022-06-23 21:14:05.830818
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    mnemonic_phrase = cr.mnemonic_phrase(3)
    assert mnemonic_phrase != None
    

# Generated at 2022-06-23 21:14:11.020258
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.builtins import Seed
    from mimesis.providers.cryptographic import Cryptographic
    seed = Seed()
    seed.set_state('c25a1e7d91f2')
    crypto = Cryptographic(seed)
    result = crypto.token_hex()
    assert result == '5c0f26e3aed3e9bf'

# Generated at 2022-06-23 21:14:14.581969
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '3a213d3a14b64d8aec6363b3e5f5bbd999f7b8e611a7a2d4'

# Generated at 2022-06-23 21:14:18.599677
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print("This method generates a pseudo-random string with a given length, based on the seed if any")
    crypto = Cryptographic()
    token = crypto.uuid()
    assert token_hex(token) == crypto.token_hex(token)
    print("Test passed")


# Generated at 2022-06-23 21:14:22.256201
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(str(Cryptographic().uuid())) == 36
    assert isinstance(Cryptographic().uuid(True), UUID)


# Generated at 2022-06-23 21:14:24.270078
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # hash should be string
    x = Cryptographic()
    result = type(x.hash())
    assert result == str


# Generated at 2022-06-23 21:14:25.949283
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic.token_urlsafe())


# Generated at 2022-06-23 21:14:28.326987
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Generate a random text string, in hexadecimal.
    random_hex = Cryptographic.token_hex()
    print(random_hex)
    assert isinstance(random_hex, str)


# Generated at 2022-06-23 21:14:32.533332
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cryptographic = Cryptographic()
    assert cryptographic.uuid() == '4b4e4f4c-1783-4c10-bce2-6bd5e6b5f9e3'
    assert isinstance(cryptographic.uuid(True), UUID)


# Generated at 2022-06-23 21:14:36.304138
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    expected1 = "7"
    expected2 = "700000000000000000000000000000000"
    result1 = Cryptographic.token_hex(1)
    result2 = Cryptographic.token_hex(32)
    assert len(result1) == 1
    assert len(result2) == 64
    assert result1 == expected1
    assert result2 == expected2

# Generated at 2022-06-23 21:14:37.733555
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 32


# Generated at 2022-06-23 21:14:43.310439
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    cnt = 0
    for i in range (0, 10):
        s = cr.hash()
        print(s)
        assert type(s) is str
        if s == 'da39a3ee5e6b4b0d3255bfef95601890afd80709':
            cnt += 1
    assert cnt < 3

# Generated at 2022-06-23 21:14:47.054078
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test function for Cryptographic class method token_hex."""
    assert len(Cryptographic().token_hex()) == 64  # type: ignore
    assert len(Cryptographic().token_hex(128)) == 256  # type: ignore


# Generated at 2022-06-23 21:14:48.170760
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    c.uuid()


# Generated at 2022-06-23 21:14:50.527546
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    obj = Cryptographic()
    o = obj.token_urlsafe()
    assert len(o) == 43
    assert type(o) is str


# Generated at 2022-06-23 21:14:52.890574
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    mnemonic_phrase = cr.mnemonic_phrase()
    assert mnemonic_phrase is not None

# Generated at 2022-06-23 21:14:55.431423
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    my_Cryptographic = Cryptographic(seed=1234567890)
    token = my_Cryptographic.hash()
    assert isinstance(token, str)


# Generated at 2022-06-23 21:14:56.810718
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() != Cryptographic().uuid()

# Generated at 2022-06-23 21:15:01.371692
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test method token_bytes of class Cryptographic."""
    c = Cryptographic()
    assert len(c.token_bytes()) == 32
    assert len(c.token_bytes(64)) == 64
    assert len(c.token_bytes()) == 32


# Generated at 2022-06-23 21:15:05.113937
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    '''Unit test for method mnemonic_phrase of class Cryptographic'''
    c = Cryptographic()
    phrase = c.mnemonic_phrase(length=6, separator=' ')
    assert len(phrase.split(' ')) == 6
    assert phrase != ''

# Generated at 2022-06-23 21:15:06.319774
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-23 21:15:08.010306
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    bytes = c.token_bytes(10)
    assert len(bytes) == 10


# Generated at 2022-06-23 21:15:14.708398
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() != Cryptographic().uuid()
    assert len(Cryptographic().uuid()) == 36
    assert isinstance(Cryptographic().uuid(), str)
    assert len(Cryptographic().uuid(True)) == 36
    assert isinstance(Cryptographic().uuid(True), UUID)


# Generated at 2022-06-23 21:15:21.742166
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test for constructor of class Cryptographic."""
    crypto = Cryptographic()
    assert isinstance(crypto.uuid(), str)
    assert isinstance(crypto.hash(), str)
    assert isinstance(crypto.token_bytes(), bytes)
    assert isinstance(crypto.token_hex(), str)
    assert isinstance(crypto.token_urlsafe(), str)
    assert isinstance(crypto.mnemonic_phrase(), str)



# Generated at 2022-06-23 21:15:23.371219
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex()
    assert isinstance(token, str)

# Generated at 2022-06-23 21:15:27.228272
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test method token_bytes of class Cryptographic."""
    assert len(Cryptographic().token_bytes(16)) == 16
    assert len(Cryptographic().token_bytes(32)) == 32
    assert len(Cryptographic().token_bytes(64)) == 64

# Generated at 2022-06-23 21:15:30.497687
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase(2)[0:2] == crypto.mnemonic_phrase(2)[0:2]
    assert crypto.mnemonic_phrase(2, '-')[0:2] != crypto.mnemonic_phrase(2)[0:2]

# Generated at 2022-06-23 21:15:32.412446
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes(): # noqa
    c = Cryptographic(seed=12345)
    c.token_bytes()  # noqa
    assert c.token_bytes() is not None

# Generated at 2022-06-23 21:15:35.708976
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print("****** Test: Cryptographic::token_bytes() ******")
    print("****** Test: Cryptographic::token_bytes() ******")


# Generated at 2022-06-23 21:15:37.673216
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()

    # check that generated token of length 32
    assert len(c.token_hex()) == 64

# Generated at 2022-06-23 21:15:41.005509
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Generate a random mnemonic phrase
    c1 = Cryptographic()
    phrase1 = c1.mnemonic_phrase(length=16)
    print(f'Your randomly generated mnemonic phrase: {phrase1}')


for _ in range(15):
    test_Cryptographic_mnemonic_phrase()
    print()

# Generated at 2022-06-23 21:15:42.832204
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
  c = Cryptographic()
  result = c.mnemonic_phrase()
  assert len(result.split(" ")) == 12

# Generated at 2022-06-23 21:15:45.635627
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Crypto = Cryptographic()
    print(Crypto.mnemonic_phrase())
    print(Crypto.uuid())


if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-23 21:15:47.385656
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase of class Cryptographic."""
    obj = Cryptographic()
    phrase = obj.mnemonic_phrase()

    assert isinstance(phrase, str)
    assert len(phrase.split()) == 12

# Generated at 2022-06-23 21:15:49.165851
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()  
    token = crypto.token_urlsafe()
    print(token)


# Generated at 2022-06-23 21:15:51.730203
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method uuid"""
    Cryptographic.uuid(as_object=True)
    Cryptographic.uuid()


# Generated at 2022-06-23 21:15:55.428271
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Generate crypto-safe value.

    :return: None.
    """
    c = Cryptographic()
    assert c.token_urlsafe()


# Generated at 2022-06-23 21:15:58.635405
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.enums import Algorithm
    obj = Cryptographic()
    assert isinstance(obj.mnemonic_phrase(), str)
    assert obj.mnemonic_phrase() != ''

# Generated at 2022-06-23 21:16:01.722869
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    result = obj.hash(Algorithm.MD5)
    assert len(result) == 32


# Generated at 2022-06-23 21:16:04.602581
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Arrange
    n = 16
    c = Cryptographic()
    
    # Act
    token = c.token_hex(n)

    # Assert
    assert(len(token) == n*2)

# Generated at 2022-06-23 21:16:09.737937
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import os
    import time

    print("test start...")
    print("test1")
    print(Cryptographic.token_urlsafe(32))
    print("test2")
    print(Cryptographic.token_urlsafe(32))
    print("test3")
    print(Cryptographic.token_urlsafe(32))
    print("test4")
    print(Cryptographic.token_urlsafe(32))
    os._exit(-1)

# Generated at 2022-06-23 21:16:14.152829
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method Cryptographic.hash()"""
    print('Testing method Cryptographic.hash()')
    pc = Cryptographic()
    print('pc.hash() =', pc.hash())
    print('pc.hash(Algorithm.BLAKE2B) =', pc.hash(Algorithm.BLAKE2B))
    print()


# Generated at 2022-06-23 21:16:15.883392
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    obj = Cryptographic()
    assert len(obj.token_bytes()) == 32
    assert len(obj.token_bytes(48)) == 48


# Generated at 2022-06-23 21:16:17.009011
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert isinstance(provider, Cryptographic)



# Generated at 2022-06-23 21:16:21.211559
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert crypto.token_bytes(32) != crypto.token_bytes(32)


# Generated at 2022-06-23 21:16:23.352800
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    instance = Cryptographic()
    assert len(instance.token_hex()) == 64


# Generated at 2022-06-23 21:16:33.893283
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Unit test for constructor of Cryptographic class
    c = Cryptographic()
    print(c)
    assert c is not None
    # Unit test for uuid of Cryptographic class
    a = c.uuid()
    print(a)  # '9a9c8be3-3a49-45e3-a003-8e8b289efa11'
    assert a is not None
    # Unit test for uuid of Cryptographic class
    b = c.uuid(True)
    print(b)  # '9a9c8be3-3a49-45e3-a003-8e8b289efa11'
    assert b is not None
    # Unit test for hash of Cryptographic class
    d = c.hash(Algorithm.MD5)
    print(d)

# Generated at 2022-06-23 21:16:42.426613
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe of class Cryptographic."""
    """Test for method token_urlsafe of class Cryptographic."""
    from mimesis import Cryptographic

    crypto1 = Cryptographic()
    token1 = crypto1.token_urlsafe(32)
    assert (len(token1)) != 32
    assert (type(token1)) == str

    crypto2 = Cryptographic()
    token2 = crypto2.token_urlsafe()
    assert (len(token2)) == 44
    assert (type(token2)) == str

    crypto3 = Cryptographic()
    token3 = crypto3.token_urlsafe(100)
    assert (len(token3)) == 132
    assert (type(token3)) == str



# Generated at 2022-06-23 21:16:47.685271
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test mnemonic_phrase method."""
    assert len(Cryptographic().mnemonic_phrase().split()) == 12
    assert len(Cryptographic().mnemonic_phrase(4).split()) == 4
    assert '-' in Cryptographic().mnemonic_phrase(4, '-')

# Generated at 2022-06-23 21:16:54.834899
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    t = Cryptographic()
    # My current phrase from BIP39 is "reduce ozone wood tomato able equal fossil episode loan crystal"
    assert len(t.mnemonic_phrase().split(' ')) == 12, "Unexpected phrase generated by mnemonic_phrase method."
    assert len(t.mnemonic_phrase(20).split(' ')) == 20, "Unexpected phrase generated by mnemonic_phrase method."
    assert len(t.mnemonic_phrase(15, '^').split('^')) == 15, "Unexpected phrase generated by mnemonic_phrase method."

# Generated at 2022-06-23 21:16:58.504193
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    mnemonic_sentence = provider.mnemonic_phrase()
    assert mnemonic_sentence is not None
    assert len(mnemonic_sentence.split(' ')) == 12
    assert provider.mnemonic_phrase(length=10, separator='-') is not None

# Generated at 2022-06-23 21:16:59.026938
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass

# Generated at 2022-06-23 21:17:00.390067
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(),str)


# Generated at 2022-06-23 21:17:04.226765
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    # test default
    expected = crypto.hash()
    actual = crypto.hash(algorithm=Algorithm.SHA256)
    assert expected == actual
    # test with param
    expected = crypto.hash(algorithm=Algorithm.SHA1)
    actual = crypto.hash(algorithm=Algorithm.SHA1)
    assert expected == actual


# Generated at 2022-06-23 21:17:05.378422
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid(False)) == 36



# Generated at 2022-06-23 21:17:07.347227
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    result = Cryptographic().token_urlsafe()
    print(result)


# Generated at 2022-06-23 21:17:10.093174
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    p = Cryptographic(use_random_data={'token': '00'})
    assert p.token_hex() == '3030'

# Generated at 2022-06-23 21:17:12.206222
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 32


# Generated at 2022-06-23 21:17:16.876980
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    seed = 1337
    alg = Algorithm.SHA256
    cr = Cryptographic(seed=seed)
    hash1 = cr.hash(alg)
    cr_2 = Cryptographic(seed=seed)
    hash2 = cr_2.hash(alg)
    assert hash1 == hash2


# Generated at 2022-06-23 21:17:19.673647
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    u = crypto.uuid()
    assert isinstance(u, str)
    assert len(u) == 36
    assert u.count('-') == 4


# Generated at 2022-06-23 21:17:22.185827
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes() ) == 32


# Generated at 2022-06-23 21:17:29.130721
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print("\n-----------------------")
    print("Testing token_hex()")
    print("-----------------------\n")
    RNG = Cryptographic("en")
    a = 10
    b = 10
    cnt = 0
    while (cnt < 10):
        a = RNG.token_hex(65)
        b = RNG.token_hex(65)
        if (a != b):
            print("Test #", cnt+1, "passed\n")
        else:
            print("Test #", cnt+1, "failed\n")
        cnt += 1
    return 0


# Generated at 2022-06-23 21:17:32.698850
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    result = obj.hash(Algorithm.SHA1)
    assert any([isinstance(result, str), result is None])
    assert result is not None

# Generated at 2022-06-23 21:17:38.205890
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    assert len(cr.hash()) == 32
    assert len(cr.hash(cr.Algorithm.SHA256)) == 64
    assert len(cr.hash(cr.Algorithm.SHA512)) == 128
    assert len(cr.hash(cr.Algorithm.BLAKE2S)) == 64
    assert len(cr.hash(cr.Algorithm.BLAKE2B)) == 128

# Generated at 2022-06-23 21:17:42.129464
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    uuid = cr.uuid(as_object=True)
    assert isinstance(uuid, UUID)
    uuid = cr.uuid()
    assert isinstance(uuid, str)
    assert len(cr.uuid()) == 36


# Generated at 2022-06-23 21:17:44.239510
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    result = obj.hash()
    assert len(result) != 0


# Generated at 2022-06-23 21:17:45.562895
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto is not None


# Generated at 2022-06-23 21:17:51.452727
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    token = crypto.token_hex()
    assert type(token) == str
    # Test for uuid
    uuid1 = crypto.uuid()
    assert type(uuid1) == str
    # Test for token_bytes
    b_token = crypto.token_bytes()
    assert type(b_token) == bytes
    # Test for token_urlsafe
    u_token = crypto.token_urlsafe()
    assert type(u_token) == str

# Generated at 2022-06-23 21:17:57.598397
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic"""
    cryp = Cryptographic()
    res = cryp.uuid()
    assert isinstance(res, str)
    assert len(res) == 36
    # testing parameter as_object
    res = cryp.uuid(True)
    assert isinstance(res, UUID)


# Generated at 2022-06-23 21:18:00.556302
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for method token_bytes of class Cryptographic."""
    result = Cryptographic().token_bytes()
    assert len(result) > 0
    assert isinstance(result, bytes)


# Generated at 2022-06-23 21:18:11.320806
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    r = Cryptographic()
    # test method hash
    alg = Algorithm
    alg.MD5 = "md5"
    alg.SHA1 = "sha1"
    alg.SHA224 = "sha224"
    alg.SHA256 = "sha256"
    alg.SHA384 = "sha384"
    alg.SHA512 = "sha512"
    alg.SHA3_224 = "sha3_224"
    alg.SHA3_256 = "sha3_256"
    alg.SHA3_384 = "sha3_384"
    alg.SHA3_512 = "sha3_512"
    assert r.hash(alg.MD5) is not None
    assert r.hash(alg.SHA1) is not None

# Generated at 2022-06-23 21:18:18.767094
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert isinstance(crypto, Cryptographic)
    assert isinstance(crypto.seed, int)
    assert isinstance(crypto.random, random.Random)
    assert isinstance(Cryptographic(seed=123), Cryptographic)
    assert isinstance(Cryptographic(seed=123).seed, int)
    assert isinstance(Cryptographic(seed=123).random, random.Random)
    assert isinstance(Cryptographic(), Cryptographic)
    assert isinstance(Cryptographic().seed, int)
    assert isinstance(Cryptographic().random, random.Random)
    assert isinstance(Cryptographic(random=False), Cryptographic)
    assert isinstance(Cryptographic(random=False).random, random.Random)
    assert isinstance(Cryptographic(random=False, seed=123).random, random.Random)

# Generated at 2022-06-23 21:18:22.588297
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """ test method token_hex of class Cryptographic"""
    crypto = Cryptographic()
    res = crypto.token_hex(55)
    assert len(res) == 110
    assert type(res) == str
    return res

# Generated at 2022-06-23 21:18:24.454650
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase() is not None
test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:18:26.340489
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print(Cryptographic().uuid())
    print(Cryptographic().uuid(as_object=True))


# Generated at 2022-06-23 21:18:29.948265
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    prov = Cryptographic()
    token = prov.token_urlsafe()
    assert isinstance(token, str)
    assert len(token)==45

# Generated at 2022-06-23 21:18:32.051568
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # The string has 32 random bytes
    # If entropy is None or is not supplied, a reasonable default is used
    assert len(Cryptographic.token_urlsafe()) == 43


# Generated at 2022-06-23 21:18:41.121812
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	c = Cryptographic()
	assert isinstance(c.hash(), str)
	assert len(c.hash()) == 128
	assert isinstance(c.hash(Algorithm.MD5), str)
	assert len(c.hash(Algorithm.MD5)) == 32
	assert isinstance(c.hash(Algorithm.SHA1), str)
	assert len(c.hash(Algorithm.SHA1)) == 40
	assert isinstance(c.hash(Algorithm.SHA224), str)
	assert len(c.hash(Algorithm.SHA224)) == 56
	assert isinstance(c.hash(Algorithm.SHA256), str)
	assert len(c.hash(Algorithm.SHA256)) == 64
	assert isinstance(c.hash(Algorithm.SHA384), str)

# Generated at 2022-06-23 21:18:42.077270
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    u = cr.uuid()
    assert isinstance(u, str)


# Generated at 2022-06-23 21:18:43.630433
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print(Cryptographic.token_bytes())


# Generated at 2022-06-23 21:18:50.079265
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()

    assert len(provider.mnemonic_phrase().split()) == 12
    assert len(provider.mnemonic_phrase(length=15).split()) == 15
    assert len(provider.mnemonic_phrase(separator=':').split(':')) == 12
    assert len(provider.mnemonic_phrase(length=15, separator=':').split(':')) == 15

# Generated at 2022-06-23 21:18:59.776704
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    c = Cryptographic()
    assert c.hash(algorithm=Algorithm.MD5) == "a5fad8ef3e19b22fea3a7d5f6030ac14"
    assert c.hash(algorithm=Algorithm.SHA1) == "2faedc7f92d6e57b7f52146eee59b738b93f1d8c"
    assert c.hash(algorithm=Algorithm.SHA224) == "e6bbe6a20a63946d9dd83b9adc0af0d40d2f8dc33bccbc0f21f68e0d"