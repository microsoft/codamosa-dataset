

# Generated at 2022-06-23 21:09:03.608227
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic(seed = 'test')
    result = provider.mnemonic_phrase()
    assert result == 'highway shelter wrong project'


# Generated at 2022-06-23 21:09:04.606580
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    if c.mnemonic_phrase():
        print("success")
    else:
        print("fail")

# Generated at 2022-06-23 21:09:05.428498
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    provider.mnemonic_phrase()

# Generated at 2022-06-23 21:09:06.049372
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) > 0

# Generated at 2022-06-23 21:09:07.810055
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()

    mnemonic_phrase = crypto.mnemonic_phrase(length=10)
    print(mnemonic_phrase)
    assert len(mnemonic_phrase.split(' ')) == 10

# Generated at 2022-06-23 21:09:10.103882
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    assert type(cr.mnemonic_phrase()) == str
    assert len(cr.mnemonic_phrase().split(' ')) == 12

# Generated at 2022-06-23 21:09:10.882075
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic()
    print(a.hash())

# Generated at 2022-06-23 21:09:12.447404
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic.token_urlsafe()) == 43  # type: ignore

# Generated at 2022-06-23 21:09:17.042622
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic().token_bytes()
    assert len(token) == 32
    token = Cryptographic().token_bytes(64)
    assert len(token) == 64
    token = Cryptographic().token_bytes(128)
    assert len(token) == 128


# Generated at 2022-06-23 21:09:19.104079
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) > 0


# Generated at 2022-06-23 21:09:21.281701
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    obj_Cryptographic = Cryptographic()
    result = obj_Cryptographic.token_hex()
    print(result)



# Generated at 2022-06-23 21:09:22.240993
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert Cryptographic().token_bytes()

# Generated at 2022-06-23 21:09:28.428458
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA1)
    assert Cryptographic().hash(Algorithm.SHA256)
    assert Cryptographic().hash(Algorithm.SHA512)
    assert Cryptographic().hash(Algorithm.MD5)
    assert not Cryptographic().hash(Algorithm.SHA256).isalpha()
    assert not Cryptographic().hash(Algorithm.SHA256).isdigit()


# Generated at 2022-06-23 21:09:31.130421
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    words = crypto.mnemonic_phrase()
    print(words)
    print(words.split())
    print(len(words.split()))

# Generated at 2022-06-23 21:09:33.950609
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic(seed=__name__)
    token = provider.token_hex()
    print(token)

    words = provider.mnemonic_phrase()
    print(words)

# Generated at 2022-06-23 21:09:39.102811
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypt = Cryptographic(seed=42)
    result = crypt.hash()
    assert result == 'aee85ef645bdfbfc8d9a09a12a76a0bb20cdea8d63c2da3bc7e1a3a9b9c9c11d'
    result = crypt.uuid()
    assert result == '3b83fa3b-3bd5-44c5-ab0b-5a5e5d5f8a99'
    result = crypt.uuid(as_object=True)
    assert result == UUID('3b83fa3b-3bd5-44c5-ab0b-5a5e5d5f8a99')
    result = crypt.token_bytes()

# Generated at 2022-06-23 21:09:40.014180
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj = Cryptographic()
    assert len(obj.token_bytes()) == 32


# Generated at 2022-06-23 21:09:44.901249
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    result = Cryptographic.mnemonic_phrase()

    assert isinstance(result, str)
    assert len(result.split(' ')) == 12

    result = Cryptographic.mnemonic_phrase(separator='*')

    assert isinstance(result, str)
    assert len(result.split('*')) == 12

    result = Cryptographic.mnemonic_phrase(length=4)

    assert isinstance(result, str)
    assert len(result.split(' ')) == 4


# Generated at 2022-06-23 21:09:49.598358
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    c = Cryptographic()
    sep = c.random.choice(['-', '_', '+'])
    l = c.random.randint(6, 32)
    print("String: [{}]".format(c.mnemonic_phrase(l, sep)))


# Generated at 2022-06-23 21:09:52.387766
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    uu_id = Cryptographic().uuid()
    assert len(uu_id) == 36


# Generated at 2022-06-23 21:09:54.856720
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    assert cr.hash() == '0fb0f01fc1e6ed8f2f0abf5e5f9a5d5a'

# Generated at 2022-06-23 21:10:02.620787
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 32
    assert type(Cryptographic().uuid(as_object=True)) == UUID

# # Unit test for method hash of class Cryptographic
# def test_Cryptographic_hash():
#    assert len(Cryptographic().hash()) == 64
#    assert type(Cryptographic().hash()) == str
#    assert len(Cryptographic().hash(algorithm=Algorithm.SHA1)) == 40
#    assert len(Cryptographic().hash(algorithm=Algorithm.SHA224)) == 56
#    assert len(Cryptographic().hash(algorithm=Algorithm.SHA384)) == 96
#    assert len(Cryptographic().hash(algorithm=Algorithm.SHA512)) == 128
#    assert len(Cryptographic().hash(algorithm=Algorithm.SHA3_224)) == 56
#    assert len(

# Generated at 2022-06-23 21:10:04.889997
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert type(c.token_bytes()) == bytes


# Generated at 2022-06-23 21:10:14.214966
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Unit test for constructor of class Cryptographic."""
    provider = Cryptographic()
    assert provider
    assert isinstance(provider.uuid(), str)
    assert provider.uuid()
    assert isinstance(provider.uuid(as_object=True), UUID)
    assert provider.uuid(as_object=True)
    assert provider.hash()
    assert isinstance(provider.hash(), str)
    assert provider.hash(Algorithm.SHA1)
    assert provider.hash(Algorithm.SHA256)
    assert provider.hash(Algorithm.SHA512)
    assert provider.token_bytes()
    assert isinstance(provider.token_bytes(), bytes)
    assert provider.token_hex()
    assert isinstance(provider.token_hex(), str)
    assert provider.token_urlsafe()
   

# Generated at 2022-06-23 21:10:15.699013
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    result = Cryptographic().token_bytes()
    assert isinstance(result, bytes)
    assert len(result) == 32


# Generated at 2022-06-23 21:10:17.680545
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe(32)) == 43

# Generated at 2022-06-23 21:10:21.279987
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = set()
    for i in range(10000):
        c = Cryptographic(seed=i)
        data.add(c.hash())

    assert len(data) == 10000


# Generated at 2022-06-23 21:10:24.285891
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():  # noqa: N802
    crypto = Cryptographic(seed=42)
    phrase = crypto.mnemonic_phrase()

    assert phrase == 'gift eject wooden fight stool tape'

# Generated at 2022-06-23 21:10:28.332369
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Tests for token_hex of class Cryptographic"""
    # Arrange
    cryptographic_obj = Cryptographic()

    # Act
    token_hex = cryptographic_obj.token_hex(32)

    # Assert
    assert isinstance(token_hex, str), "token_hex must return string"


# Generated at 2022-06-23 21:10:30.302514
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypt_provider = Cryptographic()
    crypt_provider.token_bytes()

# Generated at 2022-06-23 21:10:35.696560
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Ensure the Cryptographic.hash() works."""
    cr = Cryptographic()
    patterns = [Algorithm.MD5, Algorithm.SHA1, Algorithm.SHA224,
                Algorithm.SHA256, Algorithm.SHA384, Algorithm.SHA512]

    for p in patterns:

        result = cr.hash(p)
        assert len(result) == (p.value[-1] / 8) * 2



# Generated at 2022-06-23 21:10:37.492353
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr = Cryptographic()
    result = cr.token_hex(20)
    print(result)


# Generated at 2022-06-23 21:10:43.951450
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    # Initialization of class
    cr = Cryptographic()
    # Unit test
    assert (len(cr.mnemonic_phrase()) == 23)
    assert (len(cr.mnemonic_phrase(length=1)) == 3)
    assert (len(cr.mnemonic_phrase(separator='-')) == 25)
    assert (len(cr.mnemonic_phrase(length=1, separator='-')) == 5)


# Generated at 2022-06-23 21:10:45.285567
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-23 21:10:52.344360
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    c.token_urlsafe()
    # '3sBV2szsxX9-7mZ6EWz12De7PYNLfzJh2jKUBNlD18k'
    c.token_urlsafe(64)
    # 'Yt4I4ImA380M8-kJMLo5PjDZS9WZWH8q_jA2Q1YyvWFbw0P8C0pRJH-kFv1XW7b8'

# Generated at 2022-06-23 21:10:55.448061
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex."""
    tokens = []
    for i in range(100000):
        tokens.append(Cryptographic().token_hex(5))

    assert len(set(tokens)) == len(tokens)

# Generated at 2022-06-23 21:10:57.020213
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass


# Generated at 2022-06-23 21:10:59.949051
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    Crypto = Cryptographic()
    token = Crypto.token_bytes()
    assert len(token) == 32
    assert isinstance(token, bytes)


# Generated at 2022-06-23 21:11:04.511830
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.typing import Seed

    c = Cryptographic()

    token = c.token_bytes()
    bytes_result = isinstance(token, bytes)

    assert bytes_result == True


# Generated at 2022-06-23 21:11:05.326913
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token = crypto.token_bytes()
    len(token) # 32


# Generated at 2022-06-23 21:11:06.628454
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto=Cryptographic()
    # print(crypto.token_bytes(16).decode())
    print("token_bytes:",crypto.token_bytes(16))


# Generated at 2022-06-23 21:11:09.075806
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print(Cryptographic().hash())


# Generated at 2022-06-23 21:11:14.291398
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Method token_urlsafe of class Cryptographic
    # should return a random URL-safe text string in Base64 encoding
    # Objective: Test the method token_urlsafe of class Cryptographic
    # Assertion: The string should be a random URL-safe text string in Base64 encoding
    c = Cryptographic()
    assert (c.token_urlsafe() == '0WQ9vBH_YiYjT1NnA1N94w')

# Generated at 2022-06-23 21:11:15.613073
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe()

# Generated at 2022-06-23 21:11:18.650069
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    result = Cryptographic.token_bytes()
    assert isinstance(result, bytes)
    assert len(result) == 32



# Generated at 2022-06-23 21:11:19.897678
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 44



# Generated at 2022-06-23 21:11:21.865361
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto


# Generated at 2022-06-23 21:11:25.021373
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """
        Class Cryptographic unit test
    """
    my_crypto = Cryptographic()
    print(my_crypto.mnemonic_phrase())
    print(my_crypto.token_hex())
    print(my_crypto.uuid())
    print(my_crypto.hash())

# Generated at 2022-06-23 21:11:26.105631
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64

# Generated at 2022-06-23 21:11:28.984213
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    cryptographic = Cryptographic()
    print("cryptographic.mnemonic_phrase()")
    print("-> " + cryptographic.mnemonic_phrase() + "\n")


# Generated at 2022-06-23 21:11:33.153600
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    def test_Cryptographic_uuid_seed(seed):
        crypto = Cryptographic(seed=seed)
        assert crypto.uuid() == '2fbcbd1a-9d00-48c9-a7a6-c0fb0e7d79f8'

    test_Cryptographic_uuid_seed(123)


# Generated at 2022-06-23 21:11:34.226913
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic(seed=0)

# Generated at 2022-06-23 21:11:35.586735
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    token = provider.token_bytes()
    assert isinstance(token, bytes)


# Generated at 2022-06-23 21:11:38.582241
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    assert len(str(cr.uuid())) == 36
    assert isinstance(cr.uuid(), str)
    assert isinstance(cr.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:11:40.943093
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes(entropy=32)) == 64


# Generated at 2022-06-23 21:11:43.164375
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    seed = '111111111'
    c = Cryptographic(seed)
    pass



# Generated at 2022-06-23 21:11:48.287392
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    result1 = crypto.token_hex(4)
    assert type(result1) == str and len(result1) > 0
    result2 = crypto.token_hex()
    assert type(result2) == str and len(result2) > 0


# Generated at 2022-06-23 21:11:50.633188
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic(seed=1234567890)
    print(c.uuid())
    print(c.uuid(as_object=True))


# Generated at 2022-06-23 21:11:53.524079
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    hash = cr.hash()
    # Assert that hash is a string
    assert isinstance(hash, str)
    # Assert the length of the string
    assert len(hash) == 64



# Generated at 2022-06-23 21:11:59.883180
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test method token_hex of class Cryptographic."""
    test_provider = Cryptographic()

    # Test token_hex()
    x = test_provider.token_hex()
    assert len(x) == 64
    assert str(x).isalnum()
    assert x.isalnum()

    # Test token_hex with param
    x = test_provider.token_hex(5)
    assert len(x) == 10
    assert str(x).isalnum()
    assert x.isalnum()

    # Test token_hex with wrong type of param
    try:
        test_provider.token_hex('str')
    except TypeError:
        assert True

    # Test token_hex with wrong negative param
    try:
        test_provider.token_hex(-5)
    except ValueError:
        assert True

# Generated at 2022-06-23 21:12:01.305524
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    ext = Cryptographic()
    result = ext.token_hex()
    assert isinstance(result, str)
    assert len(result) == 64


# Generated at 2022-06-23 21:12:03.101508
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():    
    crypto_test = Cryptographic(seed=42)
    lenght = 12
    phrase = crypto_test.mnemonic_phrase(length=lenght)
    assert len(phrase.split(' ')) == lenght

# Generated at 2022-06-23 21:12:06.627159
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    ct = Cryptographic()
    ct.seed(123)
    ret = ct.mnemonic_phrase(separator="-",length=12)
    assert ret is not None

# Generated at 2022-06-23 21:12:11.435178
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hasher = Cryptographic()

    assert len(hasher.hash(Algorithm.SHA512)) == 128
    assert len(hasher.hash(Algorithm.SHA256)) == 64
    assert len(hasher.hash(Algorithm.SHA1)) == 40
    assert len(hasher.hash(Algorithm.MD5)) == 32

# Generated at 2022-06-23 21:12:14.382651
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()     # object of Cryptographic class
    print('Cryptographic.token_bytes test: |bytes| = {}'.format(len(c.token_bytes())))


# Generated at 2022-06-23 21:12:15.962168
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    random_urlsafe = Cryptographic.token_urlsafe(80)
    print(random_urlsafe)

# Generated at 2022-06-23 21:12:17.343414
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic()
    assert (len(token.token_bytes()) == 32)


# Generated at 2022-06-23 21:12:29.159719
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print("Testing Cryptographic")
    print("UUID")
    for _ in range(0, 10):
        print(Cryptographic().uuid())
    print("HASH")
    for _ in range(0, 10):
        print(Cryptographic().hash(Algorithm.SHA256))
    print("TOKEN")
    for _ in range(0, 10):
        print(Cryptographic().token_bytes())
    print("TOKEN HEX")
    for _ in range(0, 10):
        print(Cryptographic().token_hex())
    print("TOKEN URLSAFE")
    for _ in range(0, 10):
        print(Cryptographic().token_urlsafe())
    print("PHRASE")
    for _ in range(0, 10):
        print(Cryptographic().mnemonic_phrase())

# Generated at 2022-06-23 21:12:31.504178
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(Cryptographic().token_hex())



# Generated at 2022-06-23 21:12:35.834187
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic(seed = '1')
    c.token_hex(entropy = 32)
    c.token_bytes(entropy = 32)
    c.token_urlsafe(entropy = 32)

# Generated at 2022-06-23 21:12:38.663693
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    random = Cryptographic('en')
    crypto_hash = random.hash()
    assert isinstance(crypto_hash, str)
    assert len(crypto_hash) > 1


# Generated at 2022-06-23 21:12:39.937446
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    value = obj.uuid()
    assert value


# Generated at 2022-06-23 21:12:41.889501
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert(len(Cryptographic().token_bytes()) == 32)
    assert(len(Cryptographic().token_bytes(entropy=16)) == 16)


# Generated at 2022-06-23 21:12:43.830607
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():

    print(Cryptographic.token_hex())


# Generated at 2022-06-23 21:12:46.667860
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic(seed=12345)
    assert c.uuid() == 'd8cda874-fcf9-4b36-a7c1-42fb39b2afe0'


# Generated at 2022-06-23 21:12:48.770051
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cryp = Cryptographic()
    assert len(cryp.token_bytes()) == 32


# Generated at 2022-06-23 21:12:52.938106
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    m = Cryptographic()
    assert m.mnemonic_phrase() == 'spring blue excuse bus picnic'
    assert m.mnemonic_phrase(24) == 'spring blue excuse bus picnic spring blue excuse bus picnic'
    assert m.mnemonic_phrase(24, '-') == 'spring-blue-excuse-bus-picnic-spring-blue-excuse-bus-picnic'

# Generated at 2022-06-23 21:12:54.680439
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    faker = Cryptographic()
    token_bytes, type_ = faker.token_bytes(), type(faker.token_bytes())
    assert token_bytes == faker.token_bytes()
    assert type_ is bytes


# Generated at 2022-06-23 21:12:56.843511
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
   token =  Cryptographic.token_bytes()
   #print("test_Cryptographic_token_bytes: ", type(token))
   assert type(token) is bytes


# Generated at 2022-06-23 21:12:58.824232
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Check:
    if method token_bytes generated bytes of length 32.
    """
    assert len(Cryptographic.token_bytes()) == 32


# Generated at 2022-06-23 21:13:01.466194
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    instance = Cryptographic()
    assert isinstance(instance.token_bytes(), bytes)


# Generated at 2022-06-23 21:13:02.514952
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    return Cryptographic().uuid()


# Generated at 2022-06-23 21:13:05.443596
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(32) == 'Nj8w0ZTICvD63Fm2xzdFW8Wj-cYG1f6p'

# Generated at 2022-06-23 21:13:10.679176
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    mycrypto = Cryptographic()
    test1 = mycrypto.token_urlsafe(20)
    test2 = mycrypto.token_urlsafe(20)
    test3 = mycrypto.token_urlsafe(20)
    assert test1 != test2
    assert test2 != test3


# Generated at 2022-06-23 21:13:14.386362
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    string_uuid = provider.uuid()
    int_uuid = provider.uuid(as_object=True)
    assert isinstance(string_uuid, str)
    assert isinstance(int_uuid, UUID)


# Generated at 2022-06-23 21:13:21.025340
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("\nTesting method hash of class Cryptographic")
    # generate hash of a word
    print(Cryptographic().hash(Algorithm.SHA224))
    # generate hash of a number
    print(Cryptographic().hash(Algorithm.SHA1))
    # generate hash of an email
    print(Cryptographic().hash(Algorithm.SHA384))
    # generate hash of a number
    print(Cryptographic().hash(Algorithm.MD5))


# Generated at 2022-06-23 21:13:23.950253
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto_gen = Cryptographic()
    assert crypto_gen.__provider__ == 'Cryptographic'
    assert crypto_gen.__seed__ is not None
    assert crypto_gen.__settings__ is not None


# Generated at 2022-06-23 21:13:24.746463
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 43

# Generated at 2022-06-23 21:13:34.866576
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    data_set = [('1ca3c78a-a1e7-47d0-b7f2-f23d4801d927', False),
                ('1ca3c78a-a1e7-47d0-b7f2-f23d4801d927', True),
                ('1ca3c78a-a1e7-47d0-b7f2-f23d4801d927', False),
                ('1ca3c78a-a1e7-47d0-b7f2-f23d4801d927', True)]
    provider = Cryptographic()
    for string, obj in data_set:
        assert provider.uuid(obj) == string



# Generated at 2022-06-23 21:13:36.138339
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic('en')
    c.uuid()

# Generated at 2022-06-23 21:13:37.061094
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 43

# Generated at 2022-06-23 21:13:41.706006
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    x = Cryptographic()
    assert isinstance(x, Cryptographic)
    assert str(x) == '<Cryptographic>'
    assert x.seed == '0.6601525076597745'
    assert x.field_names() == ['token_bytes', 'hash', 'token_urlsafe', 'token_hex', 'uuid', 'mnemonic_phrase']


# Generated at 2022-06-23 21:13:43.990115
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    pool = Cryptographic()
    uuid = pool.uuid()
    assert len(uuid) > 0


# Generated at 2022-06-23 21:13:45.769124
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():  # noqa: N802
    assert len(Cryptographic().token_bytes()) == 32


# Generated at 2022-06-23 21:13:49.217021
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test method token_urlsafe of class Cryptographic"""
    from collections import Counter
    from mimesis.enums import SpecialChar
    import re
    assert len(re.findall(r'\s', Cryptographic().token_urlsafe())) == 0
    pass


# Generated at 2022-06-23 21:13:50.952413
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    u = Cryptographic.token_bytes(16)
    assert type(u) == bytes
    assert len(u) == 16


# Generated at 2022-06-23 21:13:55.134888
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    
    # Test Cryptographic constructor with default parameters
    crypto = Cryptographic()
    crypto.__str__()
    crypto.__repr__()
    crypto.mnemonic_phrase()
    crypto.token_bytes()
    crypto.token_hex()
    crypto.token_urlsafe()
    crypto.hash()
    crypto.uuid()
    crypto.uuid(as_object=True)

# Generated at 2022-06-23 21:14:00.411832
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm

    algorithm = Algorithm.SHA256
    if hasattr(hashlib, algorithm.value):
        fn = getattr(hashlib, algorithm.value)
    print(fn)

    c = Cryptographic(seed=123)
    result = c.hash(algorithm)
    print(result)

# Generated at 2022-06-23 21:14:09.252917
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    data = ['7J_FJ8m1n0hVxIwbjm2Q',
            'Yi_DzjGpXrD7rjaU_NgR6A',
            'okjfTKhGCs3sJ-VuZOTX',
            '3dW3uxQOvO_e1Jw',
            'Gknjzgvgcdr9c-CP',
            'vi4o4WH0TVxJG',
            'z5jC-0d5_J-0',
            'CNKssmlWMw',
            'Cp4',
            'UD']

    for _ in range(1000):
        token = Cryptographic().token_urlsafe()
        assert token in data

# Generated at 2022-06-23 21:14:14.238262
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(Cryptographic().token_hex())

if __name__ == '__main__':
    print(Cryptographic().token_hex())
    print(Cryptographic().token_bytes())
    print(Cryptographic().token_bytes(16))
    print(Cryptographic().token_urlsafe())
    print(Cryptographic().token_urlsafe(16))

# Generated at 2022-06-23 21:14:22.648500
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test for the constructor of class Cryptographic."""
    crypto = Cryptographic()

# Generated at 2022-06-23 21:14:28.623795
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Locale
    from mimesis.providers.cryptographic import Cryptographic
    cryptographic = Cryptographic(Locale.EN)

    for _ in range(3):
        generated = cryptographic.mnemonic_phrase(length=9, separator='-')
        assert isinstance(generated, str)
        assert len(generated.split('-')) == 9

# Generated at 2022-06-23 21:14:33.243437
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase(): # noqa
    cp = Cryptographic()
    mnemonic_phrase = cp.mnemonic_phrase()
    print(mnemonic_phrase)
    assert isinstance(mnemonic_phrase, str)

    #Test if the length is correct
    assert len(mnemonic_phrase.split()) == 12


# Generated at 2022-06-23 21:14:34.244059
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert (Cryptographic().token_hex()) is not None

# Generated at 2022-06-23 21:14:45.334535
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    assert a.hash() == '4717d65f6f17a5726f2301bce9d7e91d66f1acf5cd6df54e128e747bb6b5ebdb'
    assert a.uuid() == '17894a4c-4f4f-4c19-893f-52d0f22b79e9'
    assert a.uuid(as_object=True) == UUID('17894a4c-4f4f-4c19-893f-52d0f22b79e9')

# Generated at 2022-06-23 21:14:46.867433
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(32) == secrets.token_hex(32)


# Generated at 2022-06-23 21:14:48.922794
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token = crypto.token_bytes()
    assert ( len(token) > 0 )


# Generated at 2022-06-23 21:14:53.339076
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    expected = '7b591745b34d7b911c4b4f7d28c1f4e4aeefc1baa0e0f9e50b1812fb8e76e72f'
    actual = Cryptographic.token_hex()
    assert expected == actual


# Generated at 2022-06-23 21:14:56.048628
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print("test_Cryptographic_token_bytes")
    x = Cryptographic()
    print(x.token_bytes())



# Generated at 2022-06-23 21:14:59.599078
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert isinstance(crypto.uuid(), str)
    assert isinstance(crypto.uuid(as_object=True), UUID)
    

# Generated at 2022-06-23 21:15:01.931338
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
	c = Cryptographic()
	for i in range(100):
		print(c.uuid())

# Generated at 2022-06-23 21:15:05.158194
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit testing for method uuid of class Cryptographic"""
    from mimesis.providers.cryptographic import Crypto
    data = Crypto().uuid(as_object=True)
    assert isinstance(data, UUID)


# Generated at 2022-06-23 21:15:06.660078
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    token = c.token_bytes()
    assert token is not None


# Generated at 2022-06-23 21:15:08.010545
# Unit test for constructor of class Cryptographic
def test_Cryptographic():

    # Init
    c = Cryptographic()

    # Test
    assert c



# Generated at 2022-06-23 21:15:12.561837
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """ Unit test for method token_hex of class Cryptographic """
    k = Cryptographic()
    assert len(k.token_hex(3)) == 6

# Generated at 2022-06-23 21:15:13.289012
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    for _ in range(10):
        print(Cryptographic().mnemonic_phrase())

# Generated at 2022-06-23 21:15:18.105992
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.data import CACHE_PATH
    from mimesis.enums import Algorithm
    import os

    path = os.path.join(CACHE_PATH, 'mimesis_en.json')
    instance = Cryptographic(seed=123, locale="en", data_file=path)

# Generated at 2022-06-23 21:15:19.434174
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    x = c.hash()
    assert len(x) > 0


# Generated at 2022-06-23 21:15:20.605969
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    pass


# Generated at 2022-06-23 21:15:22.406386
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    hex = c.token_hex()
    assert type(hex) == str

# Generated at 2022-06-23 21:15:25.069680
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    t = c.token_bytes(10)
    assert isinstance(t, bytes)
    assert len(t) == 10


# Generated at 2022-06-23 21:15:26.981255
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    handler = Cryptographic()
    token = handler.token_urlsafe(10)

    assert len(token) == 10*4

# Generated at 2022-06-23 21:15:28.421616
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() == Cryptographic().uuid()


# Generated at 2022-06-23 21:15:31.184176
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """
    Test that the generated token is url safe
    """
    token = Cryptographic.token_urlsafe()
    assert token == secrets.token_urlsafe()


# Generated at 2022-06-23 21:15:32.744110
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    result = Cryptographic.token_urlsafe()
    assert result is not None
    

# Generated at 2022-06-23 21:15:39.325493
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic('en')
    str1 = c.hash(Algorithm.SHA1)
    assert len(str1) == 40
    str2 = c.hash(Algorithm.SHA224)
    assert len(str2) == 56
    str3 = c.hash(Algorithm.SHA256)
    assert len(str3) == 64
    str4 = c.hash(Algorithm.SHA384)
    assert len(str4) == 96
    str5 = c.hash(Algorithm.SHA512)
    assert len(str5) == 128
    str6 = c.hash(Algorithm.SHA512_224)
    assert len(str6) == 56
    str7 = c.hash(Algorithm.SHA512_256)
    assert len(str7) == 64

# Generated at 2022-06-23 21:15:40.073729
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    Cryptographic().uuid()

# Generated at 2022-06-23 21:15:42.377808
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    res = cr.uuid()
    # print(res)
    assert res is not None


# Generated at 2022-06-23 21:15:49.361018
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initialize instance of Cryptographic
    cryptographic = Cryptographic(seed=12345)
    # Store a result
    result = cryptographic.hash(algorithm=Algorithm.SHA512)
    # Compare the result is expected
    assert result == "f0bd9ee64c17aa83df2e8c3e38e3d3b5c5b2e8d23078142416d5c09409c925bcc8f5f5bada6a4f4a4de333e501d750e91767a0c6b968a6a12ec6a2b6acf5b527"

# Generated at 2022-06-23 21:15:56.351886
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    print('test_Cryptographic_hash()')
    crp = Cryptographic()

    # test with no parameters
    print('1: ' + crp.hash())
    
    # test with parameters
    print('2: ' + crp.hash(Algorithm.SHA512))

test_Cryptographic_hash()


# Generated at 2022-06-23 21:15:56.949096
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert 0

# Generated at 2022-06-23 21:15:58.993855
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    g = Cryptographic()
    assert isinstance(g.mnemonic_phrase(), str)
    print(g.mnemonic_phrase())


# Generated at 2022-06-23 21:16:02.520781
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    for alg in Algorithm:
        crypto.hash(alg)

# Generated at 2022-06-23 21:16:05.955284
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert len(
        Cryptographic().hash(algorithm=Algorithm.SHA512)) == 128
    assert len(
        Cryptographic().hash(algorithm=Algorithm.SHA256)) == 64


# Generated at 2022-06-23 21:16:07.635106
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert isinstance(provider, Cryptographic)


# Generated at 2022-06-23 21:16:09.493296
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    result = provider.uuid()
    assert isinstance(result, str)



# Generated at 2022-06-23 21:16:11.445930
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
  crypto = Cryptographic()
  assert crypto.mnemonic_phrase(length=12, separator=" ")


# Generated at 2022-06-23 21:16:12.840178
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test = Cryptographic()
    print(test.hash())


# Generated at 2022-06-23 21:16:13.848966
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert isinstance(c.token_bytes(), bytes)


# Generated at 2022-06-23 21:16:15.236086
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 64
    assert type(Cryptographic.token_bytes()) == str


# Generated at 2022-06-23 21:16:16.180653
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic.uuid() == Cryptographic.uuid()


# Generated at 2022-06-23 21:16:18.282703
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase() == crypto.mnemonic_phrase()
    assert crypto.mnemonic_phrase(length=13) == crypto.mnemonic_phrase(length=13)



# Generated at 2022-06-23 21:16:20.964585
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Testing the method token_bytes of class Cryptographic."""
    t1=Cryptographic.token_bytes()
    assert type(t1) == bytes
    t2=Cryptographic.token_bytes(entropy=56)
    assert type(t2) == bytes
    assert len(t2) == 56


# Generated at 2022-06-23 21:16:25.410205
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert crypto.uuid().__class__.__name__ == 'str'
    assert crypto.uuid(as_object=True).__class__.__name__ == 'UUID'
    assert len(str(crypto.uuid())) == 36


# Generated at 2022-06-23 21:16:32.061180
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto_obj = Cryptographic()
    print("token_bytes(entropy=32) test, crypto_obj.token_bytes() = ", crypto_obj.token_bytes())
    print("token_bytes(entropy=16) test, crypto_obj.token_bytes(16) = ", crypto_obj.token_bytes(16))
    print("token_bytes(entropy=8) test, crypto_obj.token_bytes(8) = ", crypto_obj.token_bytes(8))


# Generated at 2022-06-23 21:16:34.113384
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic('en')
    token_bytes = crypto.token_bytes(256)
    assert len(token_bytes) == 256


# Generated at 2022-06-23 21:16:35.358803
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 45


# Generated at 2022-06-23 21:16:41.928700
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    method_name = 'token_bytes'
    entropy = 10
    cryp = Cryptographic()
    try:
        result = cryp.token_bytes(entropy)
    except:
        print(method_name + ": " + "not " + "passed")
    else:
        if type(result) == bytes and len(result) == 10:
            print(method_name + ": " + "passed")
        else:
            print(method_name + ": " + "not " + "passed")


# Generated at 2022-06-23 21:16:50.161773
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic(seed=1234567890)
    result = provider.token_urlsafe()
    assert result == 'T7T00T9XrT7T00T9XrT7T00T9XrT7T00T9-T7T00T9XrT7T00T9XrT7T00T9XrT7T00T9-T7T00T9XrT7T00T9XrT7T00T9XrT7T00T9'

# Generated at 2022-06-23 21:16:52.574511
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic(seed=123456)
    assert provider.mnemonic_phrase() == "concernant coup agréable ahurie anxieux aimé"

# Generated at 2022-06-23 21:16:55.814028
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid(): 
    """Unit test for method uuid of class Cryptographic."""

    a = Cryptographic()
    for i in range(10):
        assert isinstance(a.uuid(), str)


# Generated at 2022-06-23 21:16:57.289738
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import mimesis
    c = mimesis.Cryptographic()
    hash = c.hash()


# Generated at 2022-06-23 21:16:59.797680
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    if c.token_bytes(32) == c.token_bytes(32):
        raise AssertionError()

# Generated at 2022-06-23 21:17:01.583381
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    for _ in range(100):
        assert isinstance(Cryptographic.token_hex(), str)


# Generated at 2022-06-23 21:17:05.971409
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    str_uuid = provider.uuid()
    print(str_uuid)
    assert isinstance(str_uuid, str)
    assert str_uuid == provider.uuid(as_object=False)

    uuid_obj = provider.uuid(as_object=True)
    assert isinstance(uuid_obj, UUID)
    assert uuid_obj != provider.uuid(as_object=False)


# Generated at 2022-06-23 21:17:06.637506
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic.token_hex()


# Generated at 2022-06-23 21:17:11.754126
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method uuid of class Cryptographic."""
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.enums import Algorithm

    p = Cryptographic()

    # uuid(as_object: bool = False)
    assert isinstance(p.uuid(), str)
    assert isinstance(p.uuid(as_object=True), UUID)

    # hash(algorithm: Algorithm = None)
    assert not p.hash(Algorithm.MD4)  # noqa: A003
    assert len(p.hash()) == 40
    assert len(p.hash(Algorithm.SHA256)) == 64  # noqa: A003
    with p.override_seed('seed'):
        assert not p.hash(Algorithm.MD4)  # noqa: A003

# Generated at 2022-06-23 21:17:13.778775
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj_Cryptographic = Cryptographic()
    assert obj_Cryptographic.uuid()


# Generated at 2022-06-23 21:17:14.819305
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    print(crypto.token_urlsafe())


# Generated at 2022-06-23 21:17:16.596604
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    ret = crypto.hash()
    assert len(ret) == 32


# Generated at 2022-06-23 21:17:18.563459
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cpt = Cryptographic()
    cpt.token_bytes(32)


# Generated at 2022-06-23 21:17:22.678793
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    i = 0
    while i < 100:
        t = crypto.token_urlsafe()
        assert isinstance(t, str)
        i += 1


# Generated at 2022-06-23 21:17:26.209016
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase() is not None
    assert c.mnemonic_phrase(length=2) is not None
    assert c.mnemonic_phrase(length=2, separator=':') is not None


# Generated at 2022-06-23 21:17:27.334826
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    result = c.token_bytes()
    assert isinstance(result, bytes)
    assert len(result) == 32


# Generated at 2022-06-23 21:17:31.081811
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    with Cryptographic(seed=42) as cr:
        mnemonic_phrase = cr.mnemonic_phrase(length=3, separator='-')
        assert mnemonic_phrase == 'sos-exchange-tent'


# Generated at 2022-06-23 21:17:33.162771
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    value = crypto.token_urlsafe()
    assert len(value) == 44

# Generated at 2022-06-23 21:17:35.481894
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    result = crypto.token_hex(32)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:17:37.326472
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic(seed=None)
    assert isinstance(provider.token_bytes(), bytes)


# Generated at 2022-06-23 21:17:38.093060
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    phrase = Cryptographic().mnemonic_phrase()
    assert phrase != "" and phrase != None

# Generated at 2022-06-23 21:17:38.724643
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print(Cryptographic())

# Generated at 2022-06-23 21:17:44.823966
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    # Check that seed is used during initialization
    a = Cryptographic(seed=9)
    b = Cryptographic(seed=9)
    # Check for different elements
    assert(a.mnemonic_phrase() != c.mnemonic_phrase())
    # Check for equal elements
    assert(a.mnemonic_phrase() == b.mnemonic_phrase())
    assert(a.token_bytes() != c.token_bytes())

# Generated at 2022-06-23 21:17:47.341879
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test of method mnemonic_phrase of class Cryptographic"""
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    assert isinstance(phrase, str)



# Generated at 2022-06-23 21:17:49.994617
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() == 'ea5a5a15-c602-4925-9a2f-2f44f99b26d8'


# Generated at 2022-06-23 21:17:52.082764
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cryptographic = Cryptographic()
    uuid = cryptographic.uuid()
    assert isinstance(uuid, str) == True


# Generated at 2022-06-23 21:17:54.105787
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert (len(Cryptographic().token_hex()) == 64)

# Generated at 2022-06-23 21:17:57.257135
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    url_safe = Cryptographic.token_urlsafe()
    print(url_safe)
    print(type(url_safe))

# Generated at 2022-06-23 21:17:58.868844
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes(10)) == 20

# Generated at 2022-06-23 21:18:04.263621
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.exceptions import NonEnumerableError

    sut = Cryptographic()
    non_enum_value = 'not_existed'

    with pytest.raises(NonEnumerableError):
        sut.hash(algorithm=non_enum_value)

# Generated at 2022-06-23 21:18:07.297180
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase())
    print(crypto.hash(Algorithm.SHA256))

if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-23 21:18:13.855322
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    with Cryptographic() as cr:
        assert isinstance(cr, BaseProvider)
        p = cr.uuid()
        assert isinstance(p, str)
        p = cr.uuid(as_object=True)
        assert isinstance(p, UUID)
        assert isinstance(cr.hash(), str)
        assert isinstance(cr.token_bytes(), bytes)
        assert isinstance(cr.token_hex(), str)
        assert isinstance(cr.token_urlsafe(), str)
        assert isinstance(cr.mnemonic_phrase(), str)

if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:18:15.765807
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider_Cryptographic_hash = Cryptographic()
    provider_Cryptographic_hash.hash('sha256')
    

# Generated at 2022-06-23 21:18:18.723203
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test token_bytes."""
    c = Cryptographic()
    result = c.token_bytes()
    assert isinstance(result, bytes)


# Generated at 2022-06-23 21:18:22.182044
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=8)
    word = c.mnemonic_phrase(length=6)
    assert word == 'claim about buzz every speak toward'


# Generated at 2022-06-23 21:18:24.405832
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print("token_urlsafe:")
    x = Cryptographic.token_urlsafe()
    print(x)
    assert True


# Generated at 2022-06-23 21:18:25.961428
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash()


# Generated at 2022-06-23 21:18:27.329088
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    result = crypto.token_hex()


# Generated at 2022-06-23 21:18:30.291387
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    p = Cryptographic()
    print(p.hash(Algorithm.SHA256))

# Generated at 2022-06-23 21:18:31.686512
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cod = Cryptographic()
    assert cod is not None


# Generated at 2022-06-23 21:18:33.623739
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert len(str(Cryptographic().uuid())) == 36
    assert len(str(Cryptographic().hash())) == 64

# Generated at 2022-06-23 21:18:35.896603
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cryptographic = Cryptographic()
    assert cryptographic is not None
    # test_Cryptographic ends here


# Generated at 2022-06-23 21:18:42.085644
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test class Cryptographic."""
    crypto_1 = Cryptographic()
    crypto_2 = Cryptographic(seed=123)

    assert crypto_1.uuid() != crypto_2.uuid()
    assert crypto_1.hash() != crypto_2.hash()
    assert crypto_1.mnemonic_phrase() != crypto_2.mnemonic_phrase()
    assert crypto_1.token_hex() != crypto_2.token_hex()
    assert crypto_1.token_bytes() != crypto_2.token_bytes()
    assert crypto_1.token_urlsafe() != crypto_2.token_urlsafe()

# Unit tests for Mnemonic_phrase method

# Generated at 2022-06-23 21:18:46.010907
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cryp = Cryptographic()
    assert(cryp.token_urlsafe())
    assert(len(cryp.token_urlsafe()) == 43)
    length = secrets.randbelow(10)
    assert(len(cryp.token_urlsafe(length)) == length*3//4)


# Generated at 2022-06-23 21:18:56.050321
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    a = Cryptographic()
    assert len(a.hash()) == 64
    assert len(a.hash(Algorithm.MD5)) == 32
    assert len(a.hash(Algorithm.SHA1)) == 40
    assert len(a.hash(Algorithm.SHA224)) == 56
    assert len(a.hash(Algorithm.SHA256)) == 64
    assert len(a.hash(Algorithm.SHA384)) == 96
    assert len(a.hash(Algorithm.SHA512)) == 128
    assert len(a.hash(Algorithm.BLAKE2S)) == 64
    assert len(a.hash(Algorithm.BLAKE2B)) == 128

# Generated at 2022-06-23 21:19:04.359416
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    algorithim_list = [
        Algorithm.SHA1,
        Algorithm.SHA224,
        Algorithm.SHA256,
        Algorithm.SHA384,
        Algorithm.SHA512,
        Algorithm.SHA3_224,
        Algorithm.SHA3_256,
        Algorithm.SHA3_384,
        Algorithm.SHA3_512,
        Algorithm.BLAKE2S,
        Algorithm.BLAKE2B,
        Algorithm.MD4,
        Algorithm.MD5,
        Algorithm.WHIRLPOOL
    ]

    for algorithim in algorithim_list:
        assert len(Cryptographic().hash(algorithim)) == 64
