

# Generated at 2022-06-23 21:09:03.897427
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic.token_bytes()
    assert isinstance(token, bytes)
    assert len(token) == 32

    token = Cryptographic.token_bytes(64)
    assert isinstance(token, bytes)
    assert len(token) == 64

    token = Cryptographic.token_bytes(128)
    assert isinstance(token, bytes)
    assert len(token) == 128


# Generated at 2022-06-23 21:09:06.049312
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    result = Cryptographic.token_urlsafe()
    print(result)
    assert isinstance(result, str)
    assert len(result) == 44


# Generated at 2022-06-23 21:09:13.186516
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    hash_value = 'c51e8e1b6c0d6fcf7b2c8358f20a6ac1'
    assert c.hash(Algorithm.MD5) == hash_value
    assert c.hash(Algorithm.SHA1) == hash_value
    assert c.hash(Algorithm.SHA224) == hash_value
    assert c.hash(Algorithm.SHA256) == hash_value
    assert c.hash(Algorithm.SHA384) == hash_value
    assert c.hash(Algorithm.SHA512) == hash_value

# Generated at 2022-06-23 21:09:16.581788
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cp = Cryptographic()
    token = cp.token_bytes()
    assert len(token) == 32
    token = cp.token_bytes(32)
    assert len(token)  ==32


# Generated at 2022-06-23 21:09:24.432874
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method ``mnemonic_phrase`` of class Cryptographic."""
    length = 12

    c = Cryptographic()

    phrase = c.mnemonic_phrase(length)
    assert isinstance(phrase, str)
    assert phrase.count(' ') == length - 1
    assert len(phrase.split(' ')) == length

    phrase = c.mnemonic_phrase(length, '-')
    assert isinstance(phrase, str)
    assert phrase.count('-') == length - 1
    assert len(phrase.split('-')) == length



# Generated at 2022-06-23 21:09:26.625526
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic().token_bytes()
    assert isinstance(token, bytes)


# Generated at 2022-06-23 21:09:28.125889
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 40
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128

# Generated at 2022-06-23 21:09:31.180415
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 44
    assert len(Cryptographic().token_urlsafe(32)) == 44
    assert len(Cryptographic().token_urlsafe(64)) == 88


# Generated at 2022-06-23 21:09:33.177363
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    s = c.hash()
    assert type(s) == str


# Generated at 2022-06-23 21:09:34.919201
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c


# Generated at 2022-06-23 21:09:36.321172
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    l = c.uuid()
    assert isinstance(l, str)


# Generated at 2022-06-23 21:09:37.038416
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = Cryptographic().hash()
    assert data

# Generated at 2022-06-23 21:09:37.717234
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    return Cryptographic.hash()


# Generated at 2022-06-23 21:09:39.080177
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(1)) == 2


# Generated at 2022-06-23 21:09:42.359081
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    expected = 'xJCDGeqg3qnBdCzQwIDR_A'
    result = Cryptographic().token_urlsafe(entropy=18)
    assert result is not None and len(result) > 0
    assert len(result) == 22  # expect 22 characters for 18 bytes base64 encoding
    assert result == expected, 'Unexpected value for token_urlsafe: ' + result

# Generated at 2022-06-23 21:09:46.793665
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cp = Cryptographic()
    uuid = cp.uuid()
    # print(uuid)
    assert isinstance(uuid, str)
    assert len(uuid) == 36


if __name__ == "__main__":
    test_Cryptographic_uuid()

# Generated at 2022-06-23 21:09:49.465270
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():  # noqa: D103
    assert isinstance(Cryptographic().uuid(), str)
    assert isinstance(Cryptographic().uuid(True), UUID)


# Generated at 2022-06-23 21:09:51.082878
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    pass

# Generated at 2022-06-23 21:09:55.567867
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # uuid4
    # Type for uuid4 is string
    assert isinstance(Cryptographic().uuid(), str)

    # Length for uuid4 is 36
    assert len(Cryptographic().uuid()) == 36

    # uuid4 as object
    assert isinstance(Cryptographic().uuid(True), UUID)


# Generated at 2022-06-23 21:09:56.234582
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypt = Cryptographic()
    crypt.token_bytes()

# Generated at 2022-06-23 21:09:57.810692
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    result = c.token_bytes()
    assert len(result) == 32


# Generated at 2022-06-23 21:09:59.017421
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str)


# Generated at 2022-06-23 21:10:02.452632
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Test for default value
    cr = Cryptographic()
    token = cr.token_urlsafe()
    assert len(token) == 45

    # Test for specified value
    token = cr.token_urlsafe(15)
    assert len(token) == 23

# Generated at 2022-06-23 21:10:05.901677
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptography = Cryptographic()
    cryptography.hash(algorithm=Cryptographic.Meta.name)
    cryptography.hash(algorithm=None)
    cryptography.hash(algorithm=Cryptographic)

# Generated at 2022-06-23 21:10:10.404244
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    '''
    test function for Cryptographic_token_bytes:
    '''
    print('start testing...')
    print(len(Cryptographic.token_bytes()))
    print(Cryptographic.token_bytes())


if __name__ == '__main__':
    test_Cryptographic_token_bytes()

# Generated at 2022-06-23 21:10:13.473895
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    expected_result = 'VgB86n5dRhV5Zp8uB7rYvx-P4hoJjufz4c4yd_wNEno'
    result = Cryptographic().token_urlsafe()

    assert expected_result == result


# Generated at 2022-06-23 21:10:15.599767
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    test_obj = Cryptographic()
    test_data = test_obj.token_bytes()
    assert type(test_data) == bytes


# Generated at 2022-06-23 21:10:16.804150
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.MD5)

# Generated at 2022-06-23 21:10:20.250060
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Object of class Cryptographic
    crypto = Cryptographic()
    # Testing method mnemonic_phrase of class Cryptographic
    print(crypto.mnemonic_phrase())


# Generated at 2022-06-23 21:10:31.059740
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == "f3a0ea2b2d11a8c8a9de9c08deee3786"
    assert crypto.hash(Algorithm.SHA224) == "b494729271b9a9a24d7b0a71048f1f220e47b022446d38d08baccef8"
    assert crypto.hash(Algorithm.SHA256) == "6f5c6d1e3cd4ace4f62cd6ba9b9b6faf44c2f8f816e9c9770f16d1b29022b0f8"

# Generated at 2022-06-23 21:10:32.493180
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    assert obj is not None



# Generated at 2022-06-23 21:10:34.082260
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	cryptographic = Cryptographic('en')
	print(cryptographic.mnemonic_phrase(separator = '-'))

# Generated at 2022-06-23 21:10:38.217698
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypt = Cryptographic()
    crypt.token_urlsafe()
    crypt.token_urlsafe(5)
    crypt.token_urlsafe(8)
    crypt.token_urlsafe(10)
    crypt.token_urlsafe(15)
    crypt.token_urlsafe(20)
    crypt.token_urlsafe(25)
    crypt.token_urlsafe(30)

# Generated at 2022-06-23 21:10:41.104132
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    obj = Cryptographic()
    uuid = obj.uuid()
    assert type(uuid) == str
    assert len(uuid) == 36
    assert uuid[14] == '4'
    assert uuid[19] in '89ab'


# Generated at 2022-06-23 21:10:43.386396
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # print(Cryptographic().uuid(True))
    assert isinstance(Cryptographic().uuid(True), UUID)

'''Unit test for method mnemonic_phrase of class Cryptographic'''

# Generated at 2022-06-23 21:10:46.146409
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method `token_bytes` of class `Cryptographic`."""
    result = Cryptographic.token_bytes()
    assert isinstance(result, bytes)


# Generated at 2022-06-23 21:10:49.418000
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test Cryptographic.uuid
    """
    assert len(Cryptographic.uuid()) == 36
    assert isinstance(Cryptographic.uuid(True), UUID)
    assert Cryptographic.uuid(True).version == 4

# Generated at 2022-06-23 21:10:50.650983
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    c.token_urlsafe()

# Generated at 2022-06-23 21:10:55.594459
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic(seed=0)
    assert c.uuid() == '26c6e688-46f1-40a3-bf97-c735b9371a3e'
    assert c.uuid() == '3f3f3cff-dabf-41ce-b3ac-1da44d84d378'
    assert c.uuid() == '8c69a566-9f97-41cf-8b5a-e5d5c5f5a476'



# Generated at 2022-06-23 21:11:04.417514
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Test with default size
    c1 = Cryptographic().token_bytes()
    c2 = Cryptographic().token_bytes()
    assert c1 != c2
    assert c1 != b''
    assert c2 != b''
    assert len(c1) == 32
    assert len(c2) == 32

    # Test with parameter size = 16
    c1 = Cryptographic().token_bytes(16)
    c2 = Cryptographic().token_bytes(16)
    assert len(c1) == 16
    assert len(c2) == 16
    assert c1 != c2


# Generated at 2022-06-23 21:11:06.372141
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    actual = Cryptographic().hash(Algorithm.MD5)
    assert len(actual) == 32


# Generated at 2022-06-23 21:11:09.165253
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """
    Test for method "Cryptographic_token_hex"
    """
    Cryptographic_Test = Cryptographic()
    if isinstance(Cryptographic_Test.token_hex(), str):
        raise Exception('Cryptographic_token_hex error')

# Generated at 2022-06-23 21:11:09.901924
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32


# Generated at 2022-06-23 21:11:12.759061
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex(16)
    assert token[2]=='4'
    assert token[4]=='4'

# Generated at 2022-06-23 21:11:15.427722
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test gen_Cryptographic()."""
    c = Cryptographic()
    assert c  # Pass assertion, just avoiding warning.


# Generated at 2022-06-23 21:11:17.689379
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(1024)) == 1024


# Generated at 2022-06-23 21:11:19.168158
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase())

# Generated at 2022-06-23 21:11:21.584376
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert isinstance(c.token_hex(), str)


# Generated at 2022-06-23 21:11:22.924253
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    assert isinstance(obj.hash(), str)

# Generated at 2022-06-23 21:11:25.749126
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cp = Cryptographic()
    cp.token_bytes(12)
    cp.token_hex(12)
    cp.token_urlsafe(12)

# Generated at 2022-06-23 21:11:28.668863
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """The test_password_Cryptographic_uuid() method of the class."""
    cryp = Cryptographic()
    assert cryp.uuid() != cryp.uuid()


# Generated at 2022-06-23 21:11:30.288932
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a = Cryptographic()
    token = a.token_hex(32)
    assert isinstance(token, str)

# Generated at 2022-06-23 21:11:32.963451
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # given:
    # cryptographic = Cryptographic()

    # when:
    cryptographic = Cryptographic()
    token = cryptographic.token_urlsafe(4)
    print("token is {}".format(token))
    # then:
    # assert token == 4

# Generated at 2022-06-23 21:11:37.609205
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Test for default value
    token = Cryptographic().token_urlsafe()
    assert type(token) == bytes
    assert len(token) == 44
    # Test for entropy = 32 byte
    token = Cryptographic().token_urlsafe(entropy=32)
    assert type(token) == bytes
    assert len(token) == 44


# Generated at 2022-06-23 21:11:39.737000
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    uuid = c.uuid()
    assert isinstance(uuid, str)

    uuid = c.uuid(as_object=True)
    assert isinstance(uuid, UUID)


# Generated at 2022-06-23 21:11:51.039579
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  provider = Cryptographic()

# Generated at 2022-06-23 21:11:53.536586
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():   # noqa: D103
    from mimesis.enums import Algorithm

    cr = Cryptographic()
    algorithm = Algorithm.SHA256
    hash = cr.hash(algorithm)
    assert hash is not None
    assert len(hash) > 0

# Generated at 2022-06-23 21:11:56.028277
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    assert len(Cryptographic().uuid()) == 36


# Generated at 2022-06-23 21:11:58.368768
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    crypto = Cryptographic()
    uuid = crypto.uuid()
    assert uuid is not None


# Generated at 2022-06-23 21:12:02.598356
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic."""
    crypto1 = Cryptographic()
    crypto2 = Cryptographic()
    crypto3 = Cryptographic()
    crypto4 = Cryptographic()

    crypto1.token_hex()
    crypto2.token_hex()
    crypto3.token_hex()
    crypto4.token_hex()


# Generated at 2022-06-23 21:12:05.884650
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    a = Cryptographic('en')
    result = a.uuid()
    assert type(result) is str


# Generated at 2022-06-23 21:12:15.921777
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    for i in range(10):
        s = Cryptographic()
        x = s.uuid()
        assert type(x) == str, 'Type of x is not string'
        assert (len(x) == 36), 'Length of x is not equal 36'

        y = s.uuid(as_object = True)
        assert type(x) == str, 'Type of x is not string'
        assert (len(x) == 36), 'Length of x is not equal 36'

        z = s.hash()
        assert type(x) == str, 'Type of x is not string'
        assert (len(x) == 40), 'Length of x is not equal 40'

        a = s.token_bytes()
        assert type(a) == bytes, 'Type of a is not bytes'

        b = s.token_hex()

# Generated at 2022-06-23 21:12:18.390010
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert isinstance(crypto.uuid(), str)
    assert isinstance(crypto.uuid(True), UUID)


# Generated at 2022-06-23 21:12:21.621375
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert len(c.token_bytes()) == 32
    assert len(c.token_bytes(16)) == 16



# Generated at 2022-06-23 21:12:32.222529
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # create object of class Cryptographic
    cr = Cryptographic()
    assert(type(cr) == Cryptographic)

    # test method uuid()
    s = cr.uuid(False)
    assert(len(s) == 36)

    # test method hash()
    s = cr.hash()
    assert(len(s) == 32)

    # test method token_bytes()
    s = cr.token_bytes()
    assert(len(s) == 32)

    # test method token_hex()
    s = cr.token_hex()
    assert(len(s) == 64)

    # test method token_urlsafe()
    s = cr.token_urlsafe()
    assert(len(s) == 44)

    # test method mnemonic_phrase()
    s = cr.mnemonic_phrase()
   

# Generated at 2022-06-23 21:12:35.319248
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert len(Cryptographic(seed = 123456789).mnemonic_phrase()) > 1
    assert len(Cryptographic(seed = 123456789).mnemonic_phrase()) <= 12
    assert isinstance(Cryptographic(seed = 123456789).mnemonic_phrase(), str)

# Generated at 2022-06-23 21:12:36.824257
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64


# Generated at 2022-06-23 21:12:40.091089
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    algo = Algorithm.SHA3_512

    crypto = Cryptographic()
    hash = crypto.hash(algo)
    assert (hashlib.new(algo.value, crypto.uuid().encode()).hexdigest() == hash)

# Generated at 2022-06-23 21:12:48.420558
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(Algorithm.MD5)
    assert cryptographic.hash(Algorithm.SHA1)
    assert cryptographic.hash(Algorithm.SHA256)
    assert cryptographic.hash(Algorithm.SHA512)
    assert cryptographic.hash(Algorithm.BLAKE_256)
    assert cryptographic.hash(Algorithm.BLAKE_512)
    assert cryptographic.hash(Algorithm.SHA3_256)
    assert cryptographic.hash(Algorithm.SHA3_512)
    assert cryptographic.hash(Algorithm.SHAKE_128)
    assert cryptographic.hash(Algorithm.SHAKE_256)


# Generated at 2022-06-23 21:12:49.751514
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c
    assert c.mnemonic_phrase()

# Generated at 2022-06-23 21:12:57.769493
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    import pytest
    from mimesis.providers.utils import get_provider
    from mimesis.enums import Algorithm
    
    with pytest.raises(TypeError) as context:
        foo = Cryptographic.uuid(1)
    assert "unexpected keyword argument" in str(context.value)
    with pytest.raises(TypeError) as context:
        foo = Cryptographic.uuid("1")
    assert "unexpected keyword argument" in str(context.value)
    with pytest.raises(TypeError) as context:
        foo = Cryptographic.uuid(True)
    assert "unexpected keyword argument" in str(context.value)
    with pytest.raises(TypeError) as context:
        foo = Cryptographic.uuid([])

# Generated at 2022-06-23 21:12:58.442975
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic.token_urlsafe()) == 43

# Generated at 2022-06-23 21:12:59.299601
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print(Cryptographic().mnemonic_phrase())


# Generated at 2022-06-23 21:13:02.946908
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic()
    result = provider.token_hex(10)
    assert len(result) == 20
    assert isinstance(result, str)


# Generated at 2022-06-23 21:13:05.787568
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic('en').uuid() == '7b12f0d3-7d0b-4cdc-b08f-e21c7e1b0d9f'


# Generated at 2022-06-23 21:13:06.472684
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert type(Cryptographic().hash()) == str


# Generated at 2022-06-23 21:13:08.483608
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test Cryptographic class method token_bytes()."""
    assert len(Cryptographic().token_bytes().hex()) == 32


# Generated at 2022-06-23 21:13:10.756590
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    a = Cryptographic()
    print('a.uuid():', a.uuid())


# Generated at 2022-06-23 21:13:12.824848
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    assert cr != None

if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:13:15.057845
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto_obj = Cryptographic()
    ans = crypto_obj.token_urlsafe()
    print(ans)
    assert isinstance(ans, str)

# Generated at 2022-06-23 21:13:17.058519
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 32



# Generated at 2022-06-23 21:13:18.096094
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes(32)) == 32
#


# Generated at 2022-06-23 21:13:26.764022
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider_Cryptographic = Cryptographic()
    assert isinstance(provider_Cryptographic, Cryptographic)
    assert provider_Cryptographic.uuid() == '5099af6c-d859-4b7e-94ce-40571409e8f2'
    assert provider_Cryptographic.hash() == '96571f7bb78f125440c7a0da62789c96d6ad2f2c1ce37efd9f3b0a0a27a4954e'

# Generated at 2022-06-23 21:13:29.776198
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    s = Cryptographic(seed=1234567890)
    target = 'c62b96bf-74b3-47b1-b3c3-d3a9f9ddb73f'
    result = s.uuid()
    print('target = ', target)
    print('result = ', result)
    assert result == target


# Generated at 2022-06-23 21:13:32.316949
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp = Cryptographic()
    phrase = cp.mnemonic_phrase(length=12, separator=' ')
    assert phrase



# Generated at 2022-06-23 21:13:33.694432
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    b = Cryptographic().token_urlsafe()
    print(b)

# Generated at 2022-06-23 21:13:36.051214
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c=Cryptographic()
    assert c.token_urlsafe() != c.token_urlsafe()
    assert c.token_hex(5) == len(c.token_hex(5))

# Generated at 2022-06-23 21:13:37.731407
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    algorithm = Algorithm.SHA256
    crypto.hash(algorithm)


# Generated at 2022-06-23 21:13:44.661883
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cypto = Cryptographic()
    print(cypto.uuid())
    print(cypto.uuid())
    print(cypto.uuid(as_object=True))
    print(cypto.uuid(as_object=True))

    print(cypto.hash(Algorithm.MD4))
    print(cypto.hash())

    print(cypto.token_bytes(32))
    print(cypto.token_hex(32))
    print(cypto.token_urlsafe(32))

    print(cypto.mnemonic_phrase())
    print(cypto.mnemonic_phrase(12, '-'))
    print(cypto.mnemonic_phrase(4, '-'))


# Generated at 2022-06-23 21:13:53.316413
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Testing for class Cryptographic and method hash

    # To check if the syntax is correct.
    assert callable(Cryptographic.hash)
    assert not hasattr(Cryptographic.hash, '__call__')

    # To check if the method is working correctly.
    # Test for default algorithm.
    default = Cryptographic().hash()
    assert isinstance(default, str)
    assert len(default) == 64

    for _ in range(4):
        # Test for MD5 algorithm.
        arg = Algorithm.MD5
        md5 = Cryptographic().hash(algorithm=arg)
        assert isinstance(md5, str)
        assert len(md5) == 32

        # Test for SHA1 algorithm.
        arg = Algorithm.SHA1
        sha1 = Cryptographic().hash(algorithm=arg)
        assert isinstance

# Generated at 2022-06-23 21:13:54.476357
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() is not None


# Generated at 2022-06-23 21:14:02.645175
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  # переменная Crypto инициализируется классом Cryptographic
  # и присваивается имя Crypto (запоминается как Crypto)
  Crypto = Cryptographic()

  # Вызывается метод Crypto.hash()
  # и возвращается значение переменной hash
  hash = Crypto.hash()

  # Переменная hash выводится

# Generated at 2022-06-23 21:14:04.327321
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64


# Generated at 2022-06-23 21:14:05.187807
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert isinstance(Cryptographic().mnemonic_phrase(), str)

# Generated at 2022-06-23 21:14:08.038122
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print('token_bytes(): ' + str(Cryptographic().token_bytes()) + '\n')

# Generated at 2022-06-23 21:14:09.580675
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    phr = Cryptographic().mnemonic_phrase()
    assert phr is not None


# Generated at 2022-06-23 21:14:15.798993
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    correct_value = ('a47141b8f3f3e79bea35e2a0cbb8e969'
                     'f981dceb87aa837dcd7eaefc6e1a7e24')
    c = Cryptographic()
    value = c.hash()
    assert value == correct_value, 'Value: "{}", Expected: "{}"'.format(value, correct_value)


# Generated at 2022-06-23 21:14:17.306828
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str) == True
    assert isinstance(Cryptographic().uuid(as_object=True), UUID) == True


# Generated at 2022-06-23 21:14:18.839843
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == c.uuid()


# Generated at 2022-06-23 21:14:24.839332
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Test only for this method,
    # because of cryptographic-safe nature.
    from os import urandom
    from binascii import b2a_base64
    from mimesis.builtins import Math

    provider = Cryptographic()

    # Testing token_urlsafe by comparing it
    # to native python's urandom method.
    assert provider.token_urlsafe() == b2a_base64(urandom(32)).decode()

    for i in range(0, Math().random_int(1, 100)):
        entropy = provider.random.choice(range(0, 1024))
        token_urlsafe = provider.token_urlsafe(entropy)
        assert urandom(entropy).hex() == token_urlsafe


# Generated at 2022-06-23 21:14:27.366652
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    for _ in range(100):
        token = Cryptographic().token_hex()
        try:
            int(token, 16)
            assert True
        except:
            assert False


# Generated at 2022-06-23 21:14:29.152505
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()

    assert crypto.hash() == crypto.hash()

# Generated at 2022-06-23 21:14:31.801253
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert isinstance(Cryptographic().mnemonic_phrase(), str)
    assert Cryptographic().mnemonic_phrase(2) is not None


# Generated at 2022-06-23 21:14:38.919584
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.enums import Algorithm
    import pytest
    c = Cryptographic(seed=12345)
    # testing hash function
    assert c.hash(algorithm=Algorithm.MD5) == '0b7dbcd5b5b1c5b5d89e69140caf5e5c'
    # testing cryptographic.uuid function
    assert str(c.uuid()) == "a4b7ad4b-4b78-4e98-9b1f-ce078316c0da"
    # testing cryptographic.token_bytes function
    x = c.token_bytes(entropy=32)
    y = c.token_bytes(entropy=32)
    assert x != y
    # testing cryptographic.token_hex function
    x = c.token_hex(entropy=32)

# Generated at 2022-06-23 21:14:40.667625
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic(seed=2)
    assert a.mnemonic_phrase(length = 7) == 'worldway faultless heraldry fitting'
    assert a.mnemonic_phrase(length = 7, separator = ',') == 'worldway,faultless,heraldry,fitting'

# Generated at 2022-06-23 21:14:43.187763
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token: bytes = Cryptographic.token_bytes(32)
    length: int = len(token)
    assert length, 32


# Generated at 2022-06-23 21:14:46.400832
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Given
    entropy = 32

    # When
    result = Cryptographic().token_bytes(entropy)

    # Then
    assert len(result) == entropy



# Generated at 2022-06-23 21:14:49.662697
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic"""
    expected = 32
    token = Cryptographic().token_hex()
    answer = len(token)
    assert (expected == answer), 'Expected: %s, but the result is: %s' % (expected, answer)



# Generated at 2022-06-23 21:14:51.438301
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    a =  Cryptographic.token_bytes()
    assert type(a) == bytes


# Generated at 2022-06-23 21:14:56.239063
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    expected_result = 'rm0yUi3d0B4g4O-em0nYw21-pD1I0Kd7wd_9G5O5M5M'
    result = Cryptographic.token_urlsafe()
    assert result == expected_result


# Generated at 2022-06-23 21:15:02.743155
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():

    str(Cryptographic("en").mnemonic_phrase(length=6, separator=","))
    str(Cryptographic("en").mnemonic_phrase(length=6, separator=" "))

    assert(isinstance(Cryptographic("en").mnemonic_phrase(length=6, separator=" "), str))
    assert(isinstance(Cryptographic("en").mnemonic_phrase(length=6, separator=","), str))

# Generated at 2022-06-23 21:15:05.158712
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() == 'b2e6b9a6-d589-4b38-8c3f-b65e1cbfdaab'

# Generated at 2022-06-23 21:15:11.083761
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic"""

    obj = Cryptographic()

    # test with default value of entropy and validates type
    assert isinstance(obj.token_bytes(32), bytes)

    # validates lenght of the returned string 
    assert len(obj.token_bytes(32)) == 32

    # test with different value of entropy and validates type
    assert isinstance(obj.token_bytes(100), bytes)

    # validates lenght of the returned string 
    assert len(obj.token_bytes(100)) == 100

    # test with negative value of entropy and validates type
    assert isinstance(obj.token_bytes(100), bytes)

    # validates lenght of the returned string 
    assert len(obj.token_bytes(100)) == 100


# Generated at 2022-06-23 21:15:14.747044
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
  # Generate uuid
  data = Cryptographic().uuid()
  # Check length of data.
  assert len(data) == 36
  # Check that data is string.
  assert isinstance(data, str)


# Generated at 2022-06-23 21:15:18.589112
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    p = c.token_hex()
    print('Hash:', p)

# Generated at 2022-06-23 21:15:20.659980
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe()
    assert isinstance(token, str)
    assert len(token) == 43


# Generated at 2022-06-23 21:15:23.420334
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    res = c.token_urlsafe(entropy=12)
    print(res)
    assert len(res) > 100


# Generated at 2022-06-23 21:15:24.621071
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic().uuid() is not None

# Generated at 2022-06-23 21:15:26.880694
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    mimesis = Cryptographic()
    token = mimesis.token_bytes()
    assert isinstance(token, bytes)


# Generated at 2022-06-23 21:15:29.444078
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert isinstance(c, Cryptographic)

a = Cryptographic()
b = a.uuid()
print(b)


# Generated at 2022-06-23 21:15:32.046476
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for method token_bytes of class Cryptographic."""
    cr = Cryptographic()
    assert isinstance ( cr.token_bytes(), bytes)


# Generated at 2022-06-23 21:15:36.965362
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert isinstance(c.hash(), str)
    assert len(c.hash()) == 64
    assert isinstance(c.hash(Algorithm.MD5), str)
    assert len(c.hash(Algorithm.MD5)) == 32


# Generated at 2022-06-23 21:15:40.780474
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Instance of class Cryptographic
    cryptographic = Cryptographic()
    # Assertion that cryptographic is an instance of class Cryptographic
    assert isinstance(cryptographic, Cryptographic)


# Generated at 2022-06-23 21:15:43.500518
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    assert provider.uuid() is not None
    assert provider.uuid(as_object=True) is not None


# Generated at 2022-06-23 21:15:44.330852
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic"""
    assert len(Cryptographic().token_urlsafe()) > 0



# Generated at 2022-06-23 21:15:52.717535
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Boolean for import
    flag = False
    for i in range (100):
        # Booleans for test
        flag1 = False
        flag2 = False
        x = Cryptographic()
        # Generate string of lenght 32
        y = x.token_hex()
        # If lenght of string is 32
        if len(y) == 64:
            flag1 = True
        # If string consists of letters and numbers
        if y.isalnum():
            flag2 = True
        # If both booleans are True
        if flag1 and flag2:
            # Increment number of successfull tests
            flag += 1
    # If number of successfull tests is 100
    if flag == 100:
        print("\033[1;32;40m Test for method token_hex of class Cryptographic is passed!")

# Generated at 2022-06-23 21:15:58.236849
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    person = Person('en')
    person.seed(42)
    person.gender(Gender.MALE)

    assert person.mnemonic_phrase().startswith('salt')


# Generated at 2022-06-23 21:16:00.510214
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    data_provider = Cryptographic()
    result = data_provider.token_bytes()
    assert len(result) == 32, "generate token bytes error"


# Generated at 2022-06-23 21:16:03.043921
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    assert len(crypto.token_urlsafe()) == 43
    assert len(crypto.token_urlsafe(32)) == 44


# Generated at 2022-06-23 21:16:06.106295
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # initialise the Cryptographic instance
    crypto = Cryptographic()

    # call the method to be tested
    res = crypto.hash()

    # check if the result is not None
    assert res != None


# Generated at 2022-06-23 21:16:08.808250
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for Cryptographic class."""
    provider = Cryptographic()
    result = provider.token_bytes()
    assert isinstance(result, bytes)


# Generated at 2022-06-23 21:16:11.090856
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic.token_urlsafe()) == 45
    assert len(Cryptographic.token_urlsafe(12)) == 22

# Generated at 2022-06-23 21:16:12.840866
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    output = crypto.token_urlsafe()
    print(output)
    pass

# Generated at 2022-06-23 21:16:15.101907
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    result_1 = Cryptographic.uuid()
    result_2 = Cryptographic.uuid()
    assert type(result_1) == str
    assert type(result_2) == str
    assert len(result_1) == len(result_2)

# Generated at 2022-06-23 21:16:16.683288
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase(separator='.') != ' '
    assert c.mnemonic_phrase(separator='.', length=24) != ' '

# Generated at 2022-06-23 21:16:19.640075
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-23 21:16:21.465393
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32


# Generated at 2022-06-23 21:16:24.432608
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    mnemonic_phrase = crypto.mnemonic_phrase()
    print('mnemonic_phrase is: ' + str(mnemonic_phrase))


# Generated at 2022-06-23 21:16:28.860807
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()

    b = c.token_bytes()
    assert type(b) is bytes
    assert len(b) == 32

    b = c.token_bytes(42)
    assert type(b) is bytes
    assert len(b) == 42


# Generated at 2022-06-23 21:16:32.615548
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypt = Cryptographic()
    print(crypt.uuid())
    print(crypt.hash())
    print(crypt.token_bytes())
    print(crypt.token_hex())
    print(crypt.token_urlsafe())
    print(crypt.mnemonic_phrase())

test_Cryptographic()

# Generated at 2022-06-23 21:16:35.519133
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm

    crypto = Cryptographic()
    assert len(crypto.hash()) == 64
    assert crypto.hash(Algorithm.SHA256)

# Generated at 2022-06-23 21:16:38.531735
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    phrase = Cryptographic().mnemonic_phrase(length=4)
    assert phrase  is not None
    assert phrase  != False
    assert len(phrase)  == 4

# Generated at 2022-06-23 21:16:42.229848
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    #Ran the code using the object created
    obj.token_bytes()
    obj.token_hex()
    obj.token_urlsafe()
    obj.hash()
    obj.mnemonic_phrase()
    obj.uuid()

#test_Cryptographic()
# Identical output is shown on the screen

# Generated at 2022-06-23 21:16:47.581862
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    with open('./pwd.txt', 'a', encoding='utf-8') as f:
        for i in range(200):
            s = Cryptographic().token_hex()
            f.write(s)
            f.write('\n')
    print('Finished')

# Generated at 2022-06-23 21:16:48.010377
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass

# Generated at 2022-06-23 21:16:54.459916
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    from mimesis.providers import Cryptographic
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase())
    print(crypto.mnemonic_phrase(length=24))
    print(crypto.mnemonic_phrase(length=24, separator='-'))
    print(crypto.hash(algorithm=Algorithm.SHA512))

# Generated at 2022-06-23 21:16:55.282228
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    x = Cryptographic().mnemonic_phrase()
    assert len(x.split()) == 12

# Generated at 2022-06-23 21:17:02.858546
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()

    h = c.hash(Algorithm.SHA1)
    assert len(h) == 40, "Must be 40 digits"
    assert h[-1].islower()
    assert h[0].islower()

    h = c.hash(Algorithm.SHA224)
    assert len(h) == 56, "Must be 56 digits"
    assert h[-1].isupper()
    assert h[0].islower()

    h = c.hash(Algorithm.SHA256)
    assert len(h) == 64, "Must be 64 digits"
    assert h[-1].islower()
    assert h[0].isupper()

    h = c.hash(Algorithm.SHA384)
    assert len(h) == 96, "Must be 96 digits"
    assert h[-1].isupper

# Generated at 2022-06-23 21:17:05.543438
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    # print(obj.uuid())
    # print(obj.hash())
    # print(obj.token_bytes())
    # print(obj.memonic_phrase())
    # print(obj.token_hex())
    # print(obj.token_urlsafe())
    print(obj._seed)

# Generated at 2022-06-23 21:17:11.788385
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.mnemonic_phrase())
    print(c.uuid())
    print(c.hash(Algorithm.MD5))
    print(c.token_urlsafe())
    print(c.token_hex())
    print(c.token_bytes())

test_Cryptographic()



# Generated at 2022-06-23 21:17:14.564834
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    phrase = provider.mnemonic_phrase(6)
    assert phrase == 'sodium-chemistry-diving-diving-poison-elephant'

# Generated at 2022-06-23 21:17:16.470948
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic('ru')
    c.uuid()

    assert c.uuid() != None

# Generated at 2022-06-23 21:17:19.020853
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(8)) == 8


# Generated at 2022-06-23 21:17:23.455281
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm
    from mimesis.types import Seed
    obj = Cryptographic(Seed.TEST)
    data = obj.token_bytes()
    assert isinstance(data, bytes)


# Generated at 2022-06-23 21:17:28.630779
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    UUID_REGEXP = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    uid = Cryptographic().uuid()
    assert (UUID_REGEXP.match(uid) is not None)


# Generated at 2022-06-23 21:17:35.680265
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    '''
    Generate random URL-safe text string, in Base64 encoding.
    The string has *entropy* random bytes.  If *entropy* is ``None``
    or not supplied, a reasonable default is used.
    :param entropy: Number of bytes (default: 32).
    :return: URL-safe token.
    '''
    print("---- test_Cryptographic_token_hex() ----")
    print(Cryptographic.token_hex(entropy=32))


# Generated at 2022-06-23 21:17:36.821127
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    first = crypto.token_urlsafe()
    second= crypto.token_urlsafe()

    assert first != second

# Generated at 2022-06-23 21:17:39.029814
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert(c.__init__())
    #print(c.uuid())

test_Cryptographic()

# Generated at 2022-06-23 21:17:41.187249
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():

    c = Cryptographic()
    assert c.token_bytes(32).decode() != c.token_bytes(32).decode()



# Generated at 2022-06-23 21:17:42.396186
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c is not None

# Generated at 2022-06-23 21:17:44.493385
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp = Cryptographic()
    assert cp.mnemonic_phrase() != cp.mnemonic_phrase()

# Generated at 2022-06-23 21:17:45.372020
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
	cryptographic._token_hex()

# Generated at 2022-06-23 21:17:53.699762
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import os
    obj_Cryptographic = Cryptographic()
    obj_Cryptographic.token_urlsafe(64)
    obj_Cryptographic.token_urlsafe(32)
    obj_Cryptographic.token_urlsafe(128)
    assert os.path.exists('/Users/benjamin/PycharmProjects/pymimesis/pymimesis/providers/cryptographic.py')
    assert os.path.exists('/Users/benjamin/PycharmProjects/pymimesis/pymimesis/providers/cryptographic.py')
    assert os.path.exists('/Users/benjamin/PycharmProjects/pymimesis/pymimesis/providers/cryptographic.py')


# Generated at 2022-06-23 21:17:56.506760
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    output = c.token_hex()
    # A string of 64 characters
    assert len(output) == 64

# Generated at 2022-06-23 21:17:59.747146
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    obj = Cryptographic()
    result = obj.token_urlsafe(32)
    assert len(result) == 44

# Generated at 2022-06-23 21:18:04.713510
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    answer = Cryptographic.uuid()
    assert type(answer) == str
    assert len(answer) == 36
    answer = Cryptographic.uuid(as_object=True)
    assert type(answer) == UUID
    assert answer.version == 4


# Generated at 2022-06-23 21:18:07.297151
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    if crypto.hash(Algorithm.blake2b) == None:
        assert True
    else:
        assert False

# Generated at 2022-06-23 21:18:15.575740
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic(seed=SEED)
#   token = provider.token_hex()
#   print(token)
    assert provider.token_hex() == '6f4b6fd4fd6c4d6f4cc54cff7f822cb6'

# Generated at 2022-06-23 21:18:22.582022
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # GIVEN
    provider = Cryptographic(seed='yuri')

    # WHEN
    result1 = provider.mnemonic_phrase()
    result2 = provider.mnemonic_phrase()
    result3 = provider.mnemonic_phrase()

    # THEN
    assert result1 == 'actually away infant soap sorry'
    assert result2 == 'actually away infant soap sorry'
    assert result3 == 'actually away infant soap sorry'

# Generated at 2022-06-23 21:18:24.060721
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert isinstance(Cryptographic().token_bytes(), bytes)


# Generated at 2022-06-23 21:18:26.188520
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic"""
    assert Cryptographic().mnemonic_phrase()

# Generated at 2022-06-23 21:18:29.383932
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase(4) == 'earth mom dad dog'

# Generated at 2022-06-23 21:18:31.686735
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Generate a random token
    token = Cryptographic.token_hex()
    # Example of a token
    print('Token:', token)
    assert len(token) == 64


# Generated at 2022-06-23 21:18:38.889307
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.__class__.__name__ == 'Cryptographic'
    assert c.__class__.Meta.name == 'cryptographic'
    assert callable(c.uuid)
    assert callable(c.hash)
    assert callable(c.token_bytes)
    assert callable(c.token_hex)
    assert callable(c.token_urlsafe)
    assert callable(c.mnemonic_phrase)
    # assert callable(c.__init__)
    assert callable(c.__repr__)


# Generated at 2022-06-23 21:18:45.304250
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    @given(st.data())
    def test(data):
        seed = data.draw(st.integers(min_value=1))
        # Initialize the class
        c = Cryptographic(seed=seed)

        # Get a random string
        result = c.uuid()
        assert result
        assert isinstance(result, str)

        # Get a random object
        result = c.uuid(as_object=True)
        assert result
        assert isinstance(result, UUID)

    test()

# Generated at 2022-06-23 21:18:47.606905
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    result = crypto.token_hex(10)
    assert (type(result) == str)


# Generated at 2022-06-23 21:18:49.438262
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto is not None, 'Cannot instantiate class Crypto'

# Generated at 2022-06-23 21:18:51.348507
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64, "token_hex length is not as expected"

# Generated at 2022-06-23 21:18:56.205243
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    get_bytes=Cryptographic.token_hex(4)
    expected_list = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']
    list1=[i for i in get_bytes]
    for i in range(8):
        assert list1[i] in expected_list


# Generated at 2022-06-23 21:19:02.855192
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Testing method token_urlsafe of class Cryptographic."""
    # Test 1
    result = Cryptographic.token_urlsafe(12)
    expected = "KV5B_J1jjRzyFxcUIZwB"
    assert result == expected
    # Test 2
    result = Cryptographic.token_urlsafe()
    expected = "6ZOoVdUiF6UWJ6NfmKjX"
    assert result == expected
    # Test 3
    result = Cryptographic.token_urlsafe(24)
    expected = "Xj5VuCtbz24ax-eGZqiF"
    assert result == expected
