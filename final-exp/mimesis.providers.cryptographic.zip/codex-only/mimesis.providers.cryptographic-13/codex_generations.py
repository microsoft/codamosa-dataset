

# Generated at 2022-06-23 21:09:00.393565
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic("seed")
    print(c.token_urlsafe())

test_Cryptographic_token_urlsafe()

# Generated at 2022-06-23 21:09:02.264394
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonic_phrase = Cryptographic().mnemonic_phrase()

test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:09:10.304547
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # output:
    # TypeError
    # r1 = Cryptographic.token_urlsafe(entropy='15')
    # output:
    # TypeError
    # r2 = Cryptographic.token_urlsafe(entropy=[15])
    r3 = Cryptographic.token_urlsafe(entropy=15)
    # output:
    # TypeError
    # r4 = Cryptographic.token_urlsafe(entropy='15')
    # output:
    # TypeError
    # r5 = Cryptographic.token_urlsafe(entropy=[15])
    r6 = Cryptographic.token_urlsafe()
    print(r3)
    print(r6)
    assert isinstance(r3, str) == True
    assert isinstance(r6, str) == True


# Generated at 2022-06-23 21:09:11.564279
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:09:13.692359
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == len(Cryptographic.token_bytes())

# Generated at 2022-06-23 21:09:15.552239
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    g = Cryptographic()
    print(g.token_urlsafe(32))


# Generated at 2022-06-23 21:09:22.268544
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Should store the last generated values for the same seed.
    c1 = Cryptographic(seed=1337)
    c2 = Cryptographic(seed=1337)
    assert c1._random == c2._random
    # Should generate a random value
    t1 = c1.token_urlsafe()
    t2 = c1.token_urlsafe()
    t3 = c1.token_urlsafe()
    assert t1 != t2 != t3
    # Should generate the same value for the same seed
    t1 = c2.token_urlsafe()
    t2 = c2.token_urlsafe()
    t3 = c2.token_urlsafe()
    assert t1 == t2 == t3
    # Should generate the same value for the same seed
    t1 = c1.token_urlsafe()
    t

# Generated at 2022-06-23 21:09:24.565868
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 32
    assert type(Cryptographic.token_bytes()) == bytes


# Generated at 2022-06-23 21:09:31.958006
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    token_32_hex = crypto.token_hex()
    token_40_hex = crypto.token_hex(40)
    token_50_hex = crypto.token_hex(50)

    assert len(token_32_hex) == 32 * 2, 'wrong length of token'
    assert len(token_40_hex) == 40 * 2, 'wrong length of token'
    assert len(token_50_hex) == 50 * 2, 'wrong length of token'


# Generated at 2022-06-23 21:09:34.013815
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cryptographic = Cryptographic()

    for _ in range(1000):
        cryptographic.token_urlsafe(260)

# Generated at 2022-06-23 21:09:34.775403
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes(32)) == 32

# Generated at 2022-06-23 21:09:39.138017
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Generate token bytes of length 20
    c = Cryptographic()
    token = c.token_bytes(entropy=20)

    # Get number of bytes of the token
    # noinspection PyTypeChecker
    numOfBytes = len(token)

    # Check if the number of bytes of the token is 20
    assert numOfBytes == 20


# Generated at 2022-06-23 21:09:49.508870
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd2f581c95b7f2ce8bd63d1aef3a6220db7095a0a8a9d0febda81a04a5c5fb8b5'
    assert Cryptographic().hash('sha3_512') == '4e3f3d6f1f6c8b6bccff2d2f418db7ac6fd8ab933dfceb0a1d6e1e6f8b6ff7d2cecacaf0a44cab8a9dee0b1a5fa547e0168f5b5f5b5a5ed5f5b5a5fa5a5e5f5a'


# Generated at 2022-06-23 21:09:52.109228
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    result_uuid = c.uuid()
    assert isinstance(result_uuid, str)

test_Cryptographic_uuid()


# Generated at 2022-06-23 21:09:52.692881
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert True

# Generated at 2022-06-23 21:09:55.522595
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic."""
    assert len(Cryptographic().token_hex()) > 0
    assert type(Cryptographic().token_hex()) == str



# Generated at 2022-06-23 21:10:02.367693
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from random import seed

    # Seed used for test is 12345
    seed(12345)
    cr = Cryptographic()

    for _ in range(1000):
        mnemonic_phrase = cr.mnemonic_phrase()
        assert mnemonic_phrase in ['radiant welcome zebra firefly lion',
                                   'unaware step cold almost tunnel',
                                   'transfer smile female cannon charge',
                                   'brick flower badge upon travel',
                                   'borrow office van noise train',
                                   'great screen anchor ribbon just',
                                   'claim cat note charge camera',
                                   'jolly carbon maple brush goose',
                                   'good cereal across assume brutal',
                                   'zipper swap gospel reflect crouch']

# Generated at 2022-06-23 21:10:04.644322
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert isinstance(c.token_bytes(), bytes)


# Generated at 2022-06-23 21:10:09.959935
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """
    Unit test for method uuid of class Cryptographic.
    """

    crypto = Cryptographic()

    assert isinstance(crypto.uuid(), str) == True
    assert isinstance(crypto.uuid(as_object=True), UUID) == True
    assert isinstance(crypto.uuid(as_object=False), str) == True


# Generated at 2022-06-23 21:10:10.652908
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    s = provider.secret
    assert s is not None

# Generated at 2022-06-23 21:10:11.768066
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic().token_urlsafe())


if __name__ == '__main__':
    test_Cryptographic_token_urlsafe()

# Generated at 2022-06-23 21:10:20.004716
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Given
    sample_payload = {
        'random': 1,
        'data': {
            'cryptographic': {
                'words': {
                    'normal': [
                        ('lorem'), ('ipsum'), ('dolor')
                    ]
                }
            }
        }
    }

    # When
    cryptographic = Cryptographic(sample_payload)

    # Then
    assert cryptographic.seed == 1
    assert cryptographic.__words == {'normal': [('lorem'), ('ipsum'), ('dolor')]}



# Generated at 2022-06-23 21:10:22.976760
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    assert 8 <= len(Cryptographic().mnemonic_phrase(4)) <= 39


# Generated at 2022-06-23 21:10:26.742157
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import re

    pattern = r'^\w+$'
    length = 10
    result = Cryptographic().token_urlsafe(length)
    assert isinstance(result, str)
    assert re.match(pattern, result)
    assert len(result) == length

# Generated at 2022-06-23 21:10:29.180993
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    for _ in range(20):
        result=Cryptographic().mnemonic_phrase(12)
        print(result)


# Generated at 2022-06-23 21:10:31.937393
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Vars
    length = 32
    # Execution and Assertion
    assert len(Cryptographic().token_urlsafe(length)) == length
    

# Generated at 2022-06-23 21:10:33.293603
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    result = Cryptographic().mnemonic_phrase()
    assert result != None


# Generated at 2022-06-23 21:10:41.438771
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Test that only url safed tokens are generated
    token_list = []

# Generated at 2022-06-23 21:10:42.414087
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(Cryptographic.token_hex())

# Generated at 2022-06-23 21:10:46.051506
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic."""
    t1 = Cryptographic.token_hex(3)
    t2 = Cryptographic.token_hex(3)
    assert t1 != t2
    assert len(t1) == 6
    assert len(t2) == 6

# Generated at 2022-06-23 21:10:49.423104
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    import mimesis.builtins
    token_bytes = mimesis.builtins.Cryptographic.token_bytes()
    print(type(token_bytes))
    print(token_bytes)
    print(len(token_bytes))



# Generated at 2022-06-23 21:10:56.434070
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    print("（1）生成随机的助记词短语，默认单词数为12个，默认分隔符为空格：")
    mnemonic_phrase = crypto.mnemonic_phrase()
    print(mnemonic_phrase)
    print("（2）生成随机的助记词短语，单词数为5个，默认分隔符为空格：")
    mnemonic_phrase = crypto.mnemonic_phrase(length=5)

# Generated at 2022-06-23 21:11:00.953385
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert len(Cryptographic().mnemonic_phrase().split()) == 12
    assert Cryptographic().mnemonic_phrase(separator='_') == 'cat_over_other_sing_great_field_clock_reveal_cannot_always_robot_squeeze_short'

# Generated at 2022-06-23 21:11:02.790732
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    alg = Cryptographic.hash(Algorithm.SHA512)
    assert len(alg) == 128

# Generated at 2022-06-23 21:11:05.953700
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    result = Cryptographic.token_urlsafe()
    assert isinstance(result, str)
    assert len(result) == 43


# Generated at 2022-06-23 21:11:09.424562
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic"""
    # assert 1==0
    print(eval("Cryptographic().hash()"))
    print(eval("Cryptographic().hash(algorithm='md5')"))
    # assert Cryptographic().hash() ==
    # assert Cryptographic().hash('md5') ==


# Generated at 2022-06-23 21:11:13.764747
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic."""
    assert type(Cryptographic().uuid()) == str
    assert type(Cryptographic().uuid(True)) == UUID
    assert type(Cryptographic().uuid(True)) == UUID
    assert type(Cryptographic().uuid(as_object=False)) == str
    
assert test_Cryptographic_uuid() == None

# Generated at 2022-06-23 21:11:15.290269
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 64
    assert type(Cryptographic().token_bytes()) == bytes


# Generated at 2022-06-23 21:11:17.127916
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    # crypto.token_bytes()
    crypto.token_bytes(16)


# Generated at 2022-06-23 21:11:21.023892
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic.token_urlsafe()
    assert len(token) == 45
    print(token)
    assert type(token) == str
    assert len(Cryptographic.token_urlsafe(1)) == 12


# Generated at 2022-06-23 21:11:22.517495
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64



# Generated at 2022-06-23 21:11:23.952484
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex(5)) == 11


# Generated at 2022-06-23 21:11:30.363208
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for method token_hex of class Cryptographic."""
    # Test length of returned string
    assert len(Cryptographic().token_hex(32)) == 64

    # Test that the function returns a hexadecimal value
    assert Cryptographic().token_hex(32).startswith('4')
    assert Cryptographic().token_hex(32).endswith('0')

    # Test that the function returns a different value! :)
    assert Cryptographic().token_hex(32) != Cryptographic().token_hex(32)

# Generated at 2022-06-23 21:11:39.479292
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    import unittest
    from mimesis.exceptions import NonEnumerableError

    class TestCryptographic(unittest.TestCase):

        def setUp(self):
            self.c = Cryptographic()

        def test_uuid(self):
            result = self.c.uuid()
            self.assertIsInstance(result, str)

            result = self.c.uuid(as_object=True)
            self.assertIsInstance(result, UUID)

        def test_hash(self):
            result = self.c.hash(Algorithm.MD5)
            self.assertIsInstance(result, str)

            with self.assertRaises(NonEnumerableError):
                self.c.hash('test')

        def test_token_bytes(self):
            result = self.c.token_bytes()
           

# Generated at 2022-06-23 21:11:43.881908
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    _Cryptographic_ = Cryptographic()
    assert len(_Cryptographic_._Cryptographic__words.keys()) > 0
    assert len(_Cryptographic_.uuid()) == 36
    assert len(_Cryptographic_.uuid(as_object=True).hex) == 32


# Generated at 2022-06-23 21:11:46.520598
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    a = Algorithm.SHA512
    assert c.hash(algorithm=a) != None

# Generated at 2022-06-23 21:11:48.695694
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase(length=6, separator='-') == "canal-lunch-stretch-produce-root-faint"

# Generated at 2022-06-23 21:11:50.695046
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    assert obj.Meta.name == 'cryptographic'
    assert obj.Meta.providers == 'cryptographic'


# Generated at 2022-06-23 21:11:51.750125
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 32


# Generated at 2022-06-23 21:11:54.415225
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for method 'token_hex' of class Cryptographic."""
    cr = Cryptographic()
    token = cr.token_hex()
    assert token
    assert type(token) == str


# Generated at 2022-06-23 21:11:56.531241
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cryptographic = Cryptographic()
    print(cryptographic.token_hex(100))


# Generated at 2022-06-23 21:11:58.245172
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    assert provider.meta == 'cryptographic'
    assert isinstance(provider.hash(), str)

# Generated at 2022-06-23 21:12:01.150538
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic.token_bytes()

    assert token is not None, 'Cryptographic.token_bytes returned None'
    assert len(token) == 32, 'Cryptographic.token_bytes did not return the correct number of bytes'


# Generated at 2022-06-23 21:12:05.482229
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Token will be 32 bytes (256 bits) which is 64 URL safe base64 characters
    #, which is 44 bytes when decoded.
    #
    # The minimum entropy should be 128 bits (16 bytes) and can be 256 bits (32 bytes)
    #, so as an example we use 32 bytes for the entropy.
    token = Cryptographic.token_urlsafe(32)
    print(token)
    if len(token) != 44:
        raise Exception("Token length is not 44")

# Generated at 2022-06-23 21:12:07.659858
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    result = crypto.mnemonic_phrase()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:12:09.182127
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a = Cryptographic()
    assert len(a.token_hex()) == 64

# Generated at 2022-06-23 21:12:12.721544
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test of class Cryptographic"""
    a = Cryptographic()
    assert Cryptographic.token_hex(entropy = 5) == '8a8c9d69f65f'
    assert len(a.token_hex(entropy = 5)) == 5

# Generated at 2022-06-23 21:12:14.570684
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic("en")
    result = provider.hash(Algorithm.SHA256)
    assert "5c5b8eb5b5f04ddb944e9c21cb1f7d140911c99379e5d5af68b5d2f39f95142c" == result

# Generated at 2022-06-23 21:12:19.329472
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    print(cr.uuid())
    print(cr.mnemonic_phrase())
    print(cr.mnemonic_phrase(2))
    print(cr.token_urlsafe())
    print(cr.hash(Algorithm.MD5))

# Generated at 2022-06-23 21:12:22.309939
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypt = Cryptographic()
    assert len(crypt.token_bytes()) == 32
    assert len(crypt.token_bytes(entropy=48)) == 48


# Generated at 2022-06-23 21:12:24.932355
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    tok = c.token_hex()
    assert isinstance(tok, str)


# Generated at 2022-06-23 21:12:27.521533
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # arguments: algorithm
    g = Cryptographic()
    data = g.hash(Algorithm.BLAKE2B)
    assert isinstance(data, str)


# Generated at 2022-06-23 21:12:29.244472
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token_byte = Cryptographic().token_bytes()
    assert isinstance(token_byte, bytes)


# Generated at 2022-06-23 21:12:35.080143
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic."""
    cr = Cryptographic(seed=123456789)
    assert len(cr.token_hex()) == 64
    assert len(cr.token_hex(512)) == 1024

# Generated at 2022-06-23 21:12:36.241421
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert isinstance(Cryptographic.token_hex(), str)
    


# Generated at 2022-06-23 21:12:40.320157
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Test method token_bytes with default entropy value
    token1 = Cryptographic().token_bytes()
    assert isinstance(token1, bytes)
    # Test method token_bytes with custom entropy value
    token2 = Cryptographic().token_bytes(32)
    assert isinstance(token2, bytes)
    assert len(token2) == 32 * 2


# Generated at 2022-06-23 21:12:45.061246
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', crypto.uuid())


# Generated at 2022-06-23 21:12:46.390862
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-23 21:12:48.109094
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert len(c.token_hex()) == 64

# Generated at 2022-06-23 21:12:49.452354
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(str(Cryptographic.token_hex(64))) == 64

# Generated at 2022-06-23 21:12:51.028547
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.__class__.__name__ == 'Cryptographic'


# Generated at 2022-06-23 21:12:52.494404
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cp = Cryptographic('en')
    assert cp.token_bytes() is not None


# Generated at 2022-06-23 21:12:55.573727
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Get instance of Cryptographic
    crypt = Cryptographic()
    # Generate random UUID
    uuid = crypt.uuid()
    assert len(uuid) == 36, 'Error: Invalid UUID length'
    assert uuid.count('-') == 4, 'Error: Invalid UUID'

# Generated at 2022-06-23 21:12:58.256130
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a = Cryptographic().token_hex()
    b = Cryptographic().token_hex()
    assert isinstance(a, str)
    assert isinstance(b, str)
    assert len(a) == len(b)


# Generated at 2022-06-23 21:13:02.368868
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cry = Cryptographic()
    cry.uuid()
    cry.hash()
    cry.token_bytes()
    cry.token_hex()
    cry.token_urlsafe()
    cry.mnemonic_phrase()

# Generated at 2022-06-23 21:13:04.620196
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    p = Cryptographic()
    x = p.token_urlsafe()
    assert(len(x) < 33)


# Generated at 2022-06-23 21:13:08.399549
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    assert Cryptographic().uuid()
    assert isinstance(Cryptographic().uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:13:09.657104
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == Cryptographic().uuid()

# Generated at 2022-06-23 21:13:14.793919
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()
    assert c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA512)


# Generated at 2022-06-23 21:13:18.314341
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for method token_bytes of class Cryptographic."""
    crypto = Cryptographic()

    assert crypto.token_bytes() != ''
    assert crypto.token_bytes(64) != ''


# Generated at 2022-06-23 21:13:26.968446
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test constructor of class Cryptographic."""
    c1 = Cryptographic()
    c2 = Cryptographic(seed=1)
    c1._set_seed(1)
    assert c1.uuid() == c2.uuid()
    assert c1.uuid() == c1.uuid()
    assert c1.uuid() == c2.uuid()
    assert c1.hash() == c2.hash()
    assert c1.hash() == c2.hash()
    assert c1.token_hex() == c2.token_hex()
    assert c1.token_urlsafe() == c2.token_urlsafe()
    assert c1.mnemonic_phrase() == c2.mnemonic_phrase()
    assert c1.mnemonic_phrase(1) == c2.mnemonic_phrase(1)

# Generated at 2022-06-23 21:13:31.458835
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() != c.uuid()

    assert isinstance(c.uuid(as_object= True), UUID)
    assert isinstance(c.uuid(as_object= False), str)



# Generated at 2022-06-23 21:13:33.653775
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()

    result = provider.token_urlsafe()
    assert result is not None and len(result) > 0

# Generated at 2022-06-23 21:13:34.594743
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr= Cryptographic()
    cr.token_hex()

# Generated at 2022-06-23 21:13:38.488988
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # test attribute of class Cryptographic
    test = Cryptographic()
    assert type(test._seed) == int
    assert type(test._random) == random.Random
    assert test._random_provider_name == 'random'


# Generated at 2022-06-23 21:13:39.339751
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    b = Cryptographic()
    print(b.hash())

# Generated at 2022-06-23 21:13:42.111753
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """
    Test method mnemonic_phrase of class Cryptographic
    """
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase() is not None


# Generated at 2022-06-23 21:13:51.451859
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test = Cryptographic()
    print("*************Testing function Cryptographic.hash*************")
    print("Hash for sha256 : ", test.hash(Algorithm.SHA_256))
    print("Hash for sha224 : ", test.hash(Algorithm.SHA_224))
    print("Hash for sha512 : ", test.hash(Algorithm.SHA_512))
    print("Hash for sha384 : ", test.hash(Algorithm.SHA_384))
    print("Hash for sha1 : ", test.hash(Algorithm.SHA_1))
    print("Hash for md5 : ", test.hash(Algorithm.MD5))
    print("Hash for sha3_512 : ", test.hash(Algorithm.SHA_3_512))

# Generated at 2022-06-23 21:13:53.523727
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    assert isinstance(provider.uuid(), str)
    assert isinstance(provider.uuid(True), UUID)


# Generated at 2022-06-23 21:13:55.570562
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    token_bytes = c.token_bytes()

    # Length = 1000 because of the default value of entropy is 32
    assert len(token_bytes)*2 == 1000


# Generated at 2022-06-23 21:13:58.244569
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex(32)
    print(token)


# Generated at 2022-06-23 21:14:01.275870
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert str(c.uuid()).__len__() == 36
    assert str(c.uuid()).__class__.__name__ == 'str'


# Generated at 2022-06-23 21:14:02.061311
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert type(Cryptographic().token_urlsafe()) == str

# Generated at 2022-06-23 21:14:04.611175
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # TODO: Unit test for method token_bytes of class Cryptographic
    pass


# Generated at 2022-06-23 21:14:10.061875
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    a = Cryptographic()
    assert a.uuid() is not a.uuid()
    assert a.uuid() != a.uuid()
    assert a.uuid() is not None
    assert a.uuid() is not ''
    assert a.uuid() != ''
    assert a.uuid() != None
    assert a.uuid(as_object=True) is not None
    assert a.uuid(as_object=True) is not ''
    assert a.uuid(as_object=True) != ''
    assert a.uuid(as_object=True) != None


# Generated at 2022-06-23 21:14:16.773603
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    _seed = 1234567890
    _entropy = 4
    _result = Cryptographic(_seed).token_bytes(entropy=_entropy)
    assert len(_result) == _entropy
    assert isinstance(_result, bytes)
    _seed = 1234567890
    _entropy = 11
    _result = Cryptographic(_seed).token_bytes(entropy=_entropy)
    assert len(_result) == _entropy
    assert isinstance(_result, bytes)

# Generated at 2022-06-23 21:14:18.102413
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    tok = Cryptographic().token_bytes()
    assert type(tok) is bytes
    assert len(tok) == 32


# Generated at 2022-06-23 21:14:19.578323
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    data = Cryptographic().uuid()
    assert typ(data) == '<class \'str\'>'


# Generated at 2022-06-23 21:14:22.212336
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64
    assert Cryptographic.token_hex(1).isalnum()

# Generated at 2022-06-23 21:14:23.893274
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    result = Cryptographic('en').hash(Algorithm.SHA256)
    assert result is not None


# Generated at 2022-06-23 21:14:25.875936
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
	c = Cryptographic()
	len(c.token_hex()) == 64


# Generated at 2022-06-23 21:14:27.711012
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test the constructor of class Cryptographic."""
    cg = Cryptographic(seed=0)
    assert cg.seed == 0

# Generated at 2022-06-23 21:14:29.494682
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr = Cryptographic()
    print(cr.token_hex())


# Generated at 2022-06-23 21:14:31.348721
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex(10)) == 20

# Generated at 2022-06-23 21:14:35.672143
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Created by Andrey Shevchenko on 2019-01-04.
    # It is an example of unit test for method mnemonic_phrase of class Cryptographic.

    from mimesis.providers.cryptographic import Cryptographic

    crypto = Cryptographic()
    mnemonic = crypto.mnemonic_phrase()

    assert len(mnemonic.split(' ')) == 12


# Generated at 2022-06-23 21:14:37.878533
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) is not None


# Generated at 2022-06-23 21:14:40.469487
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic(seed=123)

    assert provider.mnemonic_phrase() == "spring garden man"


# Generated at 2022-06-23 21:14:42.238369
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    test = Cryptographic()
    assert test.token_urlsafe()


# Generated at 2022-06-23 21:14:47.418441
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptography import Cryptographic
    from mimesis.providers.uuid import UUIDProvider

    cr = Cryptographic()
    uuid = UUIDProvider()

    output = cr.token_bytes()
    assert len(output) == 32
    assert output != uuid.uuid()

    output = cr.token_bytes(entropy=16)
    assert len(output) == 16
    assert output != uuid.uuid()



# Generated at 2022-06-23 21:14:49.662372
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test for constructor."""
    p = Cryptographic()
    assert isinstance(p, Cryptographic)
    assert isinstance(p, BaseProvider)



# Generated at 2022-06-23 21:14:55.469840
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    h = c.hash()  # MD5
    assert isinstance(h, str)
    assert len(h) == 32

    h = c.hash(Algorithm.SHA_1)
    assert isinstance(h, str)
    assert len(h) == 40

    h = c.hash(Algorithm.SHA_256)
    assert isinstance(h, str)
    assert len(h) == 64

# Generated at 2022-06-23 21:14:59.312553
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test to generate token_hex
    
    
    """
    token_hex = Cryptographic().token_hex()
    assert len(token_hex) == 64
    assert isinstance(token_hex, str)


# Generated at 2022-06-23 21:15:03.211452
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.data import CRYPTO_WORDS
    assert len(Cryptographic().mnemonic_phrase().split()) == 12
    assert Cryptographic().mnemonic_phrase(20, ' ').split() == CRYPTO_WORDS[:20]

# Generated at 2022-06-23 21:15:06.584853
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import random
    _algo = Cryptographic.Meta.algorithms
    print(random.choice(_algo))
    print(random.choice(_algo))
    print(random.choice(_algo))
    print(random.choice(_algo))


# Generated at 2022-06-23 21:15:08.550669
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert c.token_bytes() != c.token_bytes()
    assert c.token_bytes(0) == b''
    

# Generated at 2022-06-23 21:15:10.153427
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    s = obj.hash()
    assert(s and isinstance(s, str) and len(s) == 40)


# Generated at 2022-06-23 21:15:14.548417
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print("\nTesting ...")
    c = Cryptographic()
    print("1. ",c.token_urlsafe(32))
    print("2. ",c.token_urlsafe())
    print("3. ",c.token_urlsafe(4))


# Generated at 2022-06-23 21:15:17.890945
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token_bytes = crypto.token_bytes()
    assert token_bytes


# Generated at 2022-06-23 21:15:19.800067
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic('en')
    assert crypto.token_urlsafe().isalnum()

# Generated at 2022-06-23 21:15:29.642005
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test for method mnemonic_phrase."""
    # Number of words for generation phrase
    LENGTH = 12

    # Obtain an instance of class Cryptographic
    # One argument is an Random class
    # It needed for getting seeds and random numbers
    # For more details, see documentation on the mimesis.Random
    c = Cryptographic(seed=0)
    phrase = c.mnemonic_phrase(LENGTH)

    # Expected phrase, with result of a previous call method
    # mnemonic_phrase of class Cryptographic
    EXPECTED = 'abort stiffen whopper wrangle chink hagfish goodly ' \
               'bluesy paint prune pose'

    # The expected phrase must be equal to phrase
    assert phrase == EXPECTED

# Generated at 2022-06-23 21:15:31.923620
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 32
    assert len(Cryptographic.token_bytes(0)) == 0


# Generated at 2022-06-23 21:15:33.722298
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    data = crypto.uuid()
    assert isinstance(data, str)
    assert data != ''


# Generated at 2022-06-23 21:15:36.732820
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cp = Cryptographic()

    assert cp.token_hex() == secrets.token_hex(32)
    assert len(cp.token_hex()) == (32 * 2)
    assert isinstance(cp.token_hex(), str)


# Generated at 2022-06-23 21:15:38.788472
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    for _ in range(20):
        assert len(Cryptographic.token_urlsafe(32)) == 44


# Generated at 2022-06-23 21:15:39.707743
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    pass

# Generated at 2022-06-23 21:15:41.795473
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c is not None
    assert type(c) == Cryptographic

# Generated at 2022-06-23 21:15:43.590360
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Assert token_hex() is not None (returns string)
    assert Cryptographic().token_hex() is not None

# Generated at 2022-06-23 21:15:45.635600
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    cr = Cryptographic()
    hash = cr.hash()
    assert bool(hash) is True

# Generated at 2022-06-23 21:15:46.580285
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic().token_hex(32) != None

# Generated at 2022-06-23 21:15:46.953054
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert True

# Generated at 2022-06-23 21:15:49.522142
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    # The algorithm is valid
    assert len(Cryptographic().hash()) > 0

    # The algorithm is invalid
    assert Cryptographic().hash('foo') == ''

# Generated at 2022-06-23 21:15:52.271745
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto_p = Cryptographic()
    res = crypto_p.token_bytes()
    assert len(res) == 32
    print(res)


# Generated at 2022-06-23 21:15:54.485275
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Cryptographic().hash()
    assert type(Cryptographic().hash()) == str


# Generated at 2022-06-23 21:16:00.191562
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """
    Unit test for method mnemonic_phrase of class Cryptographic
    """
    # Initialise class
    test = Cryptographic(seed=0)
    # Test method with default parameters
    assert test.mnemonic_phrase(12) == "secretly equal consume always"
    # Test method with different parameters
    assert test.mnemonic_phrase(5, "*") == "unit*strict*communicate*woodpecker*embarrass"

# Generated at 2022-06-23 21:16:05.128737
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
   # Arrange
   length = 12
   # Act
   token = Cryptographic().token_hex(length)
   # Assert
   assert type(token) == str
   assert len(token) == 64
   for c in token:
      assert (c >= '0' and c <= '9') or (c >= 'a' and c <= 'f')

# Generated at 2022-06-23 21:16:06.958604
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c is not None
    assert isinstance(c, Cryptographic)

# Generated at 2022-06-23 21:16:08.410379
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert Cryptographic().token_urlsafe() != Cryptographic().token_urlsafe()

# Generated at 2022-06-23 21:16:10.311788
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert len(c.token_hex()) > 0


# Generated at 2022-06-23 21:16:12.120767
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    token = c.token_bytes()
    assert len(token) == 32


# Generated at 2022-06-23 21:16:20.797565
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.providers.base import Seed
    from mimesis.providers.text import Text
    from mimesis.enums import TextType

    seed = Seed('seed')
    text = Text('en')

    text_type = TextType.NORMAL
    word_list = text._data.get('words', {})
    word_list = word_list.get(text_type.value, [])

    crypto = Cryptographic('en')
    mnemonic_phrase = crypto.mnemonic_phrase(222, ' ')

    mnemonic_list = mnemonic_phrase.split(' ')
    assert len(mnemonic_list) == 222

    for word in mnemonic_list:
        assert word in word_list

# Generated at 2022-06-23 21:16:22.898984
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert len(c.token_bytes(32)) == 32


# Generated at 2022-06-23 21:16:25.114519
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    Crypto = Cryptographic()
    token_hex = Crypto.token_hex()
    assert type(token_hex) == str


# Generated at 2022-06-23 21:16:28.686358
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test Cryptographic.uuid method."""
    assert len(Cryptographic().uuid()) == 36
    assert Cryptographic().uuid(as_object=True).version == 4


# Generated at 2022-06-23 21:16:30.327818
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cp = Cryptographic()
    assert cp.uuid(as_object=True).version == 4


# Generated at 2022-06-23 21:16:33.348528
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    a = Cryptographic()
    algorithm = Algorithm
    salt = a.similar(a.hash(), algorithm.SHA256.value)
    assert a.hash(algorithm.SHA256) == salt

# Generated at 2022-06-23 21:16:36.346789
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex() == 'd1dfcc24fbe9e0ddc8b6e2282fcfd7c1'


# Generated at 2022-06-23 21:16:38.587897
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    x = Cryptographic()
    z = x.token_urlsafe(32)
    assert z

# Generated at 2022-06-23 21:16:40.510272
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    assert provider.hash()
    assert provider.hash(Algorithm.MD5)


# Generated at 2022-06-23 21:16:46.425610
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method ``uuid`` of class ``Cryptographic``."""
    crypto = Cryptographic(seed=42)

    result = crypto.uuid()
    assert result == '147b0e93-a96a-47d9-9eb0-9523efb7c0d0'


# Generated at 2022-06-23 21:16:49.981527
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for the Cryptographic.token_hex()."""
    result = Cryptographic().token_hex(8)
    assert isinstance(result, str)
    assert len(result) == 8 * 2
    assert result.isalnum()

# Generated at 2022-06-23 21:16:53.854183
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print("\nGenerating a random string")
    # Testing method token_hex
    token = Cryptographic.token_hex()
    print("\nToken:", token)
    assert token is not None
    assert token != 'None'


# Generated at 2022-06-23 21:16:55.213876
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase() != crypto.mnemonic_phrase()

# Generated at 2022-06-23 21:16:56.774751
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():

    crypto = Cryptographic()

    phrases = [crypto.mnemonic_phrase() for _ in range(100)]
    assert phrases != (['abbey'] * 100)



# Generated at 2022-06-23 21:17:00.665850
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():  # noqa: D103
    to_test = ('mimesis', 'mimesis_json')
    for module in to_test:
        if module == 'mimesis':
            from mimesis import Cryptographic
        else:
            from mimesis_json import Cryptographic
        assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:17:03.682404
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print('test_Cryptographic_token_bytes: start')

    # Assert method token_bytes() of class Cryptographic return list with 1 element
    assert len(Cryptographic().token_bytes()) == 32

    print('test_Cryptographic_token_bytes: end')


# Generated at 2022-06-23 21:17:04.463025
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex(128)) == 256

# Generated at 2022-06-23 21:17:16.429031
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    from mimesis.builtins import Localization
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.cryptographic import Cryptographic

    L=Localization('ru')

    p=Person('ru')
    a=Address('ru')
    c=Cryptographic()
    h=c.hash(Algorithm.MD5)

    s=p.full_name(gender=Gender.MALE)
    print(s)
    s=a.full_address(level=1)
    print(s)
    s=str(c.uuid())
    print(s)
    s=c.hash(Algorithm.MD5)

# Generated at 2022-06-23 21:17:19.019072
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert(len(Cryptographic().mnemonic_phrase()) > 12)
    assert(len(Cryptographic().mnemonic_phrase()) > 12)

# Generated at 2022-06-23 21:17:22.680807
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    fake = Cryptographic(seed=1)
    phrase = fake.mnemonic_phrase(length=3, separator=',')
    assert phrase == "joint , elapse , rut"

# Generated at 2022-06-23 21:17:23.979513
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    algorithm = Algorithm.SHA256
    value = obj.hash(algorithm)
    assert isinstance(value, str) & (len(value) == 64)


# Generated at 2022-06-23 21:17:25.983918
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic."""
    crypto = Cryptographic()
    assert len(crypto.token_hex(32)) == 64

# Generated at 2022-06-23 21:17:28.031792
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj = Cryptographic()
    result = obj.token_bytes()
    assert result
    assert isinstance(result, bytes)


# Generated at 2022-06-23 21:17:31.001043
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes(): # noqa: E302
    instance = Cryptographic()
    assert isinstance(instance.token_bytes(), bytes)


# Generated at 2022-06-23 21:17:39.130324
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert Cryptographic.token_urlsafe()
    assert Cryptographic.token_urlsafe(32)
    assert Cryptographic.token_urlsafe(entropy=32)
    assert Cryptographic.token_urlsafe(32)
    assert Cryptographic.token_urlsafe(entropy=32)
    assert len(Cryptographic.token_urlsafe().replace(r"-", "")) == 48
    assert len(Cryptographic.token_urlsafe().replace(r"=", "")) == 32
    assert len(Cryptographic.token_urlsafe().replace(r"-", "").replace(r"=", "")) == 32


# Generated at 2022-06-23 21:17:39.975706
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert len(Cryptographic().mnemonic_phrase()) == 12*37

# Generated at 2022-06-23 21:17:40.929249
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    temp = Cryptographic().uuid()
    assert(isinstance(temp, str))

# Test for getting a hash

# Generated at 2022-06-23 21:17:44.393140
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    token = crypto.token_urlsafe()
    assert len(token) == 43
    assert crypto.token_urlsafe(4) == "4fqDpYwV"

# Generated at 2022-06-23 21:17:45.562416
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:17:48.227241
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Calling the method token_hex of class Cryptographic
    hash = Cryptographic.token_hex()
    # Checking if the method token_hex of class Cryptographic returned the expected value
    assert hash


# Generated at 2022-06-23 21:17:52.331778
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic('en')
    print(cr.mnemonic_phrase())
    print(cr.mnemonic_phrase(separator='-'))
    print(cr.mnemonic_phrase(length=15))
    print(cr.mnemonic_phrase(separator='-', length=15))


# Generated at 2022-06-23 21:17:57.870928
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic("en")
    s = c.uuid(as_object=False)
    print("\n" + s)
    assert len(s) == 36
    print("\n" + str(c.uuid(as_object=True)))


# Generated at 2022-06-23 21:17:59.791773
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print(Cryptographic().uuid())
    print(Cryptographic().uuid(as_object=True))


# Generated at 2022-06-23 21:18:01.447202
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    assert cr != None, 'Failed to instantiate Cryptographic'

# Generated at 2022-06-23 21:18:03.257092
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic()


# Generated at 2022-06-23 21:18:04.312242
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic()


# Generated at 2022-06-23 21:18:06.871989
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert isinstance(Cryptographic.token_bytes(), bytes)
    assert len(Cryptographic.token_bytes()) == 32
    assert len(Cryptographic.token_bytes(64)) == 64


# Generated at 2022-06-23 21:18:09.086096
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic.token_urlsafe()) == 43
    assert len(Cryptographic.token_urlsafe(16)) == 27

# Generated at 2022-06-23 21:18:15.102395
# Unit test for constructor of class Cryptographic
def test_Cryptographic():

    c = Cryptographic()

    assert c.uuid()
    assert c.uuid(as_object=True)
    assert c.hash()
    assert c.hash(algorithm=Algorithm.MD5)
    assert c.token_bytes()
    assert c.token_hex()
    assert c.token_urlsafe()
    assert c.mnemonic_phrase()
    assert c.mnemonic_phrase(separator='-')
    assert c.mnemonic_phrase(length=20, separator='-')

# Generated at 2022-06-23 21:18:17.537373
# Unit test for constructor of class Cryptographic
def test_Cryptographic(): # noqa
    obj = Cryptographic()
    assert isinstance(obj, Cryptographic) is True

# Unit tests for uuid

# Generated at 2022-06-23 21:18:19.879008
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe() == c.token_urlsafe()

# Generated at 2022-06-23 21:18:21.127436
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert 1 == 1


# Generated at 2022-06-23 21:18:25.628442
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    a = Cryptographic()
    assert a.mnemonic_phrase(length=5) in str(a.mnemonic_phrase(length=5))
    assert a.mnemonic_phrase(length=5,separator='-') in str(a.mnemonic_phrase(length=5,separator='-'))


# Generated at 2022-06-23 21:18:29.659504
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print('\nMethod uuid of class Cryptographic')
    print('-' * 80)
    timestamp = 1549085607
    # seed = 999
    cr = Cryptographic(timestamp)
    for i in range(3):
        print(cr.uuid())
        print(cr.uuid(as_object=True))



# Generated at 2022-06-23 21:18:35.400807
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    assert len(provider.mnemonic_phrase().split(' ')) == 12
    assert len(provider.mnemonic_phrase(length=3).split(' ')) == 3
    assert len(provider.mnemonic_phrase(separator="-").split('-')) == 12
    assert len(provider.mnemonic_phrase(length=3, separator="-").split('-')) == 3
    assert provider.mnemonic_phrase(length=1).split(' ')[0] in provider._data['words']['normal']

# Generated at 2022-06-23 21:18:36.772314
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.hash())
# luancher
if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-23 21:18:41.275227
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash(Algorithm.MD5)
    assert Cryptographic.hash(Algorithm.SHA1)
    assert Cryptographic.hash(Algorithm.SHA224)
    assert Cryptographic.hash(Algorithm.SHA256)
    assert Cryptographic.hash(Algorithm.SHA384)
    assert Cryptographic.hash(Algorithm.SHA512)

# Generated at 2022-06-23 21:18:42.914964
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c=Cryptographic()
    assert c.hash() != c.hash()

# Generated at 2022-06-23 21:18:45.654858
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print(dir(Cryptographic))
    cr = Cryptographic()
    print(cr.hash())

# Generated at 2022-06-23 21:18:47.499798
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    obj = Cryptographic()
    assert isinstance(obj.token_hex(), str)

# Generated at 2022-06-23 21:18:58.062830
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    print(crypto.hash())
    print(crypto.hash(Algorithm.SHA256))
    print(crypto.hash(Algorithm.SHA384))
    print(crypto.hash(Algorithm.SHA512))
    print(crypto.token_bytes())
    print(crypto.token_bytes(1024))
    print(crypto.token_hex())
    print(crypto.token_hex(1024))
    print(crypto.token_urlsafe())
    print(crypto.token_urlsafe(1024))
    print(crypto.uuid())
    print(crypto.uuid(as_object=True))
    print(crypto.mnemonic_phrase())
    print(crypto.mnemonic_phrase(length=15))
