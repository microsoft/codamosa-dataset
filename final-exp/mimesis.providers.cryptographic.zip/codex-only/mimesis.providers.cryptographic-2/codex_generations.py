

# Generated at 2022-06-23 21:09:02.179720
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # test
    token = Cryptographic.token_hex()

    # postcondition
    assert len(token) == 64
    assert isinstance(token, str)

# Generated at 2022-06-23 21:09:06.449935
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    x = Cryptographic()
    algorithm = Algorithm.SHA256
    assert isinstance(x.hash(algorithm), str)
    assert isinstance(x.hash(algorithm), str)
    assert isinstance(x.hash(algorithm), str)
    assert isinstance(x.hash(algorithm), str)
    assert isinstance(x.hash(algorithm), str)

# Generated at 2022-06-23 21:09:10.633183
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    _Cryptographic = Cryptographic("en")
    assert _Cryptographic.uuid()
    assert _Cryptographic.hash(Algorithm.MD5)
    assert _Cryptographic.token_bytes()
    assert _Cryptographic.token_hex()
    assert _Cryptographic.token_urlsafe()
    assert _Cryptographic.mnemonic_phrase()

# Generated at 2022-06-23 21:09:20.455230
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method uuid of class Cryptographic."""
    assert str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid()) == str(Cryptographic().uuid())
    assert str(Cryptographic().uuid()) != str(Cryptographic().uuid())
    assert str(Cryptographic().uuid()) != str(Cryptographic().uuid())
    assert str(Cryptographic().uuid()) != str(Cryptographic().uuid())

# Generated at 2022-06-23 21:09:26.999800
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # This is a unit test for method 'hash' of class 'Cryptographic'.
    my_Cryptographic = Cryptographic()
    res = my_Cryptographic.hash()
    print(res)

    #This is a unit test for method 'hash' of class 'Cryptographic'.
    my_Cryptographic = Cryptographic()
    res = my_Cryptographic.hash(Algorithm.SHA1)
    print(res)
    assert isinstance(res,str)



# Generated at 2022-06-23 21:09:35.204310
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    from mimesis.providers.base import BaseProvider

    class MockCryptographic(Cryptographic, BaseProvider):
        pass

    test_cryptographic = MockCryptographic()
    assert isinstance(test_cryptographic.token_urlsafe(entropy=128), str)
    assert len(test_cryptographic.token_urlsafe(entropy=128)) == 46
    assert len(test_cryptographic.token_urlsafe()) == 43
    assert test_cryptographic.hash(algorithm=Algorithm.SHA256)


# Generated at 2022-06-23 21:09:36.220208
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypt = Cryptographic()
    print("token_hex:",crypt.token_hex())


# Generated at 2022-06-23 21:09:40.691012
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Testing parameters
    algorithm = Algorithm.BLAKE2B
    hash = Cryptographic().hash(algorithm)
    hashlen = len(hash)
    assert hashlen == 128, 'Returned hash is not the correct size.'

    # Testing returns
    if isinstance(hash, str):
        assert True, 'hash() returned non-string'
    else:
        assert False, 'hash() did not return a string'

# Generated at 2022-06-23 21:09:46.490419
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    uuid_str = crypto.uuid()
    print(uuid_str)
    assert isinstance(uuid_str, str)
    uuid_uuid = crypto.uuid(True)
    print(uuid_uuid)
    assert isinstance(uuid_uuid, UUID)


# Generated at 2022-06-23 21:09:50.886091
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.uuid() is not None
    assert crypto.token_bytes() is not None
    assert crypto.token_hex() is not None
    assert crypto.token_urlsafe() is not None
    assert crypto.hash() is not None
    assert crypto.mnemonic_phrase() is not None

# Generated at 2022-06-23 21:10:00.159829
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for the function Cryptographic.hash()."""
    # Defining the seed for random generator
    seed = 15465
    # Defining the variable "data_crypto" of class Cryptographic
    data_crypto = Cryptographic(seed)
    # Defining the variable "data" with the result of method "hash"
    data = data_crypto.hash()
    # The length of variable "data" is 32 bytes
    print("Test #1: length_data = {}".format(len(data)))
    # The result of method "hash" with seed is "5c5d2964c1a9f7a28b2d61481da2c2ab"
    print("Test #2: hash = {}".format(data))
    # The result of method "hash" is a string

# Generated at 2022-06-23 21:10:11.049210
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic.

    This unit test is based on test that is written in the
    Python 3.6.7 documentation.

    https://docs.python.org/3.6/library/hashlib.html#hashlib.hash.digest_size
    """

    algorithms = [
        'md5',
        'sha1',
        'sha224',
        'sha256',
        'sha384',
        'sha512',
    ]

    for algorithm in algorithms:
        print("{:<7}: {:>3} bytes".format(algorithm, len(getattr(hashlib, algorithm)().digest())))

    for algorithm in algorithms:
        print("{:<7}: {:>3} bytes".format(algorithm, len(Cryptographic().hash(Algorithm(algorithm)))))

# Unit test

# Generated at 2022-06-23 21:10:11.627732
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic()


# Generated at 2022-06-23 21:10:14.579179
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    obj_1 = Cryptographic()
    obj_2 = Cryptographic()

    print (obj_1.token_urlsafe())
    print (obj_2.token_urlsafe())


# Generated at 2022-06-23 21:10:16.317864
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print(Cryptographic.token_bytes())


# Generated at 2022-06-23 21:10:22.261983
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test method token_urlsafe of class Cryptographic."""
    a = Cryptographic()
    assert isinstance(a.token_urlsafe(), str)
    assert isinstance(a.token_urlsafe(), str)
    assert isinstance(a.token_urlsafe(), str)
    assert isinstance(a.token_urlsafe(128), str)


# Generated at 2022-06-23 21:10:23.981661
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    assert len(crypto.token_urlsafe()) == 44

# Generated at 2022-06-23 21:10:24.817536
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    token = provider.token_urlsafe()
    assert isinstance(token, str)

# Generated at 2022-06-23 21:10:26.972659
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(entropy=1) == c.token_hex(entropy=1)


# Generated at 2022-06-23 21:10:30.203732
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Arrange
    expectedOutput = "inhabit vice remember anchor affect copper remind ocean"
    #Act
    actualOutput = Cryptographic.mnemonic_phrase()
    #Assert
    assert(expectedOutput == actualOutput)

# Generated at 2022-06-23 21:10:32.188404
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test that method returns UUID4."""
    assert len(Cryptographic().uuid()) == 36

# Generated at 2022-06-23 21:10:33.551151
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str)


# Generated at 2022-06-23 21:10:35.204735
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert len(crypto.token_bytes()) >= 32


# Generated at 2022-06-23 21:10:37.041166
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic('seed')
    res = c.token_hex(12)
    assert len(res) == 24


# Generated at 2022-06-23 21:10:43.861655
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Tests for method token_urlsafe of class Cryptographic"""
    cp = Cryptographic()
    token_urlsafe = cp.token_urlsafe(32)
    cp2 = Cryptographic()
    token_urlsafe2 = cp2.token_urlsafe(32)
    assert token_urlsafe != token_urlsafe2
    assert isinstance(token_urlsafe, str)
    assert isinstance(token_urlsafe2, str)
    assert token_urlsafe != ''
    assert token_urlsafe2 != ''
    assert len(token_urlsafe) == len(token_urlsafe2)
    assert len(token_urlsafe) == 44
    assert len(token_urlsafe2) == 44


# Generated at 2022-06-23 21:10:46.585032
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    result = c.mnemonic_phrase()
    assert isinstance(result, str)



# Generated at 2022-06-23 21:10:50.104784
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex() == '62809daa9b7e0fba66abbed7a78a0e00c0dcc3eac2f1f10f9c0b1ebb5ca96d5a'

# Generated at 2022-06-23 21:10:51.931905
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str)


# Generated at 2022-06-23 21:10:54.726543
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print("Test for method token_bytes of class Cryptographic\n")
    tk = Cryptographic()
    x = tk.token_bytes()
    print(x)
    print()


# Generated at 2022-06-23 21:10:56.598783
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    h = c.hash()
    assert type(h) is str
    assert len(h) == 32

# Generated at 2022-06-23 21:10:59.545989
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    algorithm = Algorithm.SHA224
    hash = cr.hash(algorithm)
    assert hash
    assert isinstance(hash, str)


# Generated at 2022-06-23 21:11:09.424589
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase(): # noqa
    """Perform unit-tests for method 'mnemonic_phrase' of class 'Cryptographic'"""

    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.text import Text

    c = Cryptographic()
    t = Text()

    # Mnemonic phrase with default length of words
    c_phrase = c.mnemonic_phrase()
    t_phrase = ' '.join([t.word() for _ in range(12)])
    assert c_phrase == t_phrase

    # Mnemonic phrase with default separator of words
    c_phrase = c.mnemonic_phrase(separator='')
    t_phrase = ''
    t_phrase = t_phrase.join([t.word() for _ in range(12)])
    assert c

# Generated at 2022-06-23 21:11:13.612943
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm
    crt = Cryptographic(seed=42)
    assert crt.uuid() == '4a66b0f4-246c-4e5e-8988-5cf5692a4d7b'
    assert crt.uuid() == '9d3c06a3-2a7c-4a70-a3b1-3d2e1994388f'
    assert crt.uuid() == 'f7c828e1-07c6-4511-b8c6-9f9e90e6ba12'
    assert crt.uuid() == '57e6e1b6-a8a9-4f71-ba6a-d6a583c6af2b'

# Generated at 2022-06-23 21:11:18.561228
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    cryptographer = Cryptographic(seed=12)
    seed_12_unsupported = cryptographer.hash(algorithm=Algorithm.MD6)
    assert seed_12_unsupported is None

    seed_12_md5 = cryptographer.hash(algorithm=Algorithm.MD5)
    assert hashlib.md5(seed_12_md5.encode()).hexdigest() == seed_12_md5


# Generated at 2022-06-23 21:11:21.689185
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    mnemonic_phrase = cr.mnemonic_phrase(length=4)
    assert mnemonic_phrase == 'kraftwerk iceland osaka disney'

# Generated at 2022-06-23 21:11:22.415634
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cp = Cryptographic()
    assert cp is not None

# Generated at 2022-06-23 21:11:23.996085
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj = Cryptographic()
    assert len(obj.token_bytes()) == 32  # 32 byte: 256 bits

# Generated at 2022-06-23 21:11:26.772408
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import mimesis
    c = mimesis.Cryptographic()
    assert c.hash('md5') is not None
    assert c.hash('sha1') is not None

# Generated at 2022-06-23 21:11:31.299222
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    x = Cryptographic()
    # phrase1 = x.mnemonic_phrase(12)
    # phrase2 = x.mnemonic_phrase(10, '.')
    # print(phrase1, phrase2)

    # mnemonic_phrase should return a string of length 12
    assert (len(str(x.mnemonic_phrase())) == 12)


# Generated at 2022-06-23 21:11:33.794973
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Arrange
    provider = Cryptographic()
    # Act
    result = provider.token_bytes()
    # Assert
    assert result is not None
    assert len(result) == 32
    assert type(result) is bytes


# Generated at 2022-06-23 21:11:42.386172
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # hash работает
    def foo(x):
        return x.hash, x.hash(Algorithm.MD5), x.hash(Algorithm.SHA1), x.hash(Algorithm.SHA224)


    assert foo(Cryptographic()) != foo(Cryptographic(seed=1))  # Проверка на зависимость от seed
    assert foo(Cryptographic()).__hash__() == foo(Cryptographic()).__hash__()  # Проверка на стабильность
    assert type(foo(Cryptographic())) == tuple  # Проверка на возвращаемы

# Generated at 2022-06-23 21:11:49.640847
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid_str = '6f9c9e3b-e0ac-447d-bf5d-e542cb1d6bab'
    uuid_obj = UUID('6f9c9e3b-e0ac-447d-bf5d-e542cb1d6bab')
    assert str(Cryptographic().uuid()) == uuid_str
    assert Cryptographic().uuid(True) == uuid_obj


# Generated at 2022-06-23 21:11:51.027254
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    c.mnemonic_phrase()


# Generated at 2022-06-23 21:11:52.395131
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    print(c.token_urlsafe())
    

# Generated at 2022-06-23 21:11:55.256901
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    print(c.hash())
    print(c.uuid())


if __name__ == '__main__':
    test_Cryptographic_hash()

# Generated at 2022-06-23 21:12:00.567876
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test for Cryptographic"""
    # Test for class Cryptographic 
    obj = Cryptographic()
    assert isinstance(obj, Cryptographic)
    assert hasattr(obj, 'uuid')
    assert hasattr(obj, 'hash')
    assert hasattr(obj, 'token_bytes')
    assert hasattr(obj, 'token_hex')
    assert hasattr(obj, 'token_urlsafe')
    assert hasattr(obj, 'mnemonic_phrase')


# Generated at 2022-06-23 21:12:02.744478
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj = Cryptographic()
    assert len(obj.token_bytes()) == 32
    assert len(obj.token_bytes(64)) == 64


# Generated at 2022-06-23 21:12:05.879325
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    bytes = Cryptographic.token_bytes(32)
    assert type(bytes) == bytes
    assert len(bytes) == 32


# Generated at 2022-06-23 21:12:07.317332
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex()
    assert(token is not None)

# Generated at 2022-06-23 21:12:09.228248
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test class Cryptographic."""
    cr = Cryptographic()
    assert cr._seed is not None


# Generated at 2022-06-23 21:12:10.171943
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto_data = Cryptographic()
    assert crypto_data.uuid()


# Generated at 2022-06-23 21:12:12.928456
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of the class Cryptographic."""
    uuid = Cryptographic().uuid()
    assert len(uuid) == 36


# Generated at 2022-06-23 21:12:15.008875
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  token = Cryptographic('en').token_urlsafe()
  assert len(token.split("-")) == 4


# Generated at 2022-06-23 21:12:16.830967
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    test_code = lambda : Cryptographic.token_urlsafe()
    assert isinstance(test_code, str)


# Generated at 2022-06-23 21:12:18.927168
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print("Testing method token_bytes...")
    token = Cryptographic.token_bytes(6)
    assert len(token) == 6


# Generated at 2022-06-23 21:12:22.411525
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic(seed=1)
    actual = provider.mnemonic_phrase()
    expected = 'scale segment fortune enjoy blossom urban'
    assert actual == expected, 'TEST FAILED'


# Generated at 2022-06-23 21:12:27.012082
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto_provider = Cryptographic()
    crypto_provider.seed('test')
    result = crypto_provider.uuid()
    assert result == 'ed5d845e-c988-4b76-b2f2-d749c2e2bd72'


# Generated at 2022-06-23 21:12:28.730553
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    data = Cryptographic.token_bytes(entropy=32)
    assert len(data) == 32

# Generated at 2022-06-23 21:12:36.919128
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    assert str(a.uuid()) != str(a.uuid())
    assert a.hash() != a.hash()
    assert a.token_bytes() != a.token_bytes()
    assert a.token_hex() != a.token_hex()
    assert a.token_urlsafe() != a.token_urlsafe()
    assert a.mnemonic_phrase() != a.mnemonic_phrase()

# Generated at 2022-06-23 21:12:38.477026
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic(seed=None, datetime=None)
    assert isinstance(c.uuid(), UUID)


# Generated at 2022-06-23 21:12:41.927800
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonic_phrase1 = Cryptographic().mnemonic_phrase(12, ' ')
    mnemonic_phrase2 = Cryptographic().mnemonic_phrase(12, ' ')
    assert str(mnemonic_phrase1) != str(mnemonic_phrase2)
    print("Cryptographic method 'mnemonic_phrase' works successfully")


# Generated at 2022-06-23 21:12:43.033612
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass

# Generated at 2022-06-23 21:12:45.091047
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test method token_urlsafe of class Cryptographic."""
    c = Cryptographic()
    c.token_urlsafe()


# Generated at 2022-06-23 21:12:46.078657
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic().token_urlsafe())

# Generated at 2022-06-23 21:12:47.508520
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    print(c.mnemonic_phrase())


# Generated at 2022-06-23 21:12:50.868791
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import secrets
    url = 'http://127.0.0.1/'
    # Here we check that our function is equal to secrets.token_urlsafe
    assert secrets.token_urlsafe() == Cryptographic().token_urlsafe()

# Generated at 2022-06-23 21:12:52.144289
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic.token_urlsafe()
    assert isinstance(token, str)
    assert len(token) == 8

# Generated at 2022-06-23 21:12:59.006546
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis import Cryptographic
    from mimesis.enums import Algorithm

    provider = Cryptographic('en')
    assert provider.uuid() == '7de93c9f-0f84-48f2-8854-c445b606eb6f'
    assert isinstance(provider.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:13:02.996703
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase of class Cryptographic"""
    tmp = Cryptographic.mnemonic_phrase()
    assert isinstance(tmp, str)
    assert len(tmp) > 0
    return tmp


# Generated at 2022-06-23 21:13:05.199746
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for uuid method."""
    cr = Cryptographic()
    assert isinstance(cr.uuid(), str)


# Generated at 2022-06-23 21:13:13.592549
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    t = Cryptographic(seed=123)

    assert t.hash() == '6e0d6fcf80a23de5cddf1d8a1e7faf66acb51d2e9a5a5d564b0b1e7e46f6d36a'
    assert t.hash(Algorithm.SHA256) == 'a80c83a002a7546c6e1d621ca510ec74929e18a9a9a5a5f5d564b0b1e7e46f6d'


# Generated at 2022-06-23 21:13:18.125511
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    # Arrange
    obj = Cryptographic(seed=123456)
    entropy = 32
    # Act
    result = obj.token_urlsafe(entropy)
    # Assert


# Generated at 2022-06-23 21:13:20.074359
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    mnemonic_phrase = provider.mnemonic_phrase(length=3)
    assert len(mnemonic_phrase.split(' ')) == 3

# Generated at 2022-06-23 21:13:24.465242
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """
    >>> from mimesis.builtins import Cryptographic
    >>> t1 = Cryptographic().token_hex()
    >>> len(t1) == 64
    True
    >>> t2 = Cryptographic().token_hex(8)
    >>> len(t2) == 16
    True
    >>> t3 = Cryptographic().token_hex(2)
    >>> len(t3) == 4
    True
    >>> t4 = Cryptographic().token_hex(20)
    >>> len(t4) == 40
    True
    """

# Generated at 2022-06-23 21:13:28.033417
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    uuid_str = cr.uuid()
    assert len(uuid_str) == 36
    assert isinstance(uuid_str, str)


# Generated at 2022-06-23 21:13:29.807326
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    dut = Cryptographic()
    assert dut is not None

# Generated at 2022-06-23 21:13:33.133677
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    try:
        Cryp = Cryptographic()
        a = Cryp.token_bytes(8)
        assert a.decode()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-23 21:13:34.470981
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cg = Cryptographic()
    cg.token_urlsafe()


# Generated at 2022-06-23 21:13:37.065131
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Method mnemonic_phrase of class Cryptographic should return a string made up of random words."""
    assert Cryptographic('en').mnemonic_phrase() != Cryptographic('en').mnemonic_phrase()

# Generated at 2022-06-23 21:13:40.990623
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    a = c.mnemonic_phrase(length=6)
    b = c.mnemonic_phrase(length=6, separator='|')
    assert a != b
    assert isinstance(a, str)
    assert isinstance(b, str)


# Generated at 2022-06-23 21:13:43.314232
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    assert cr.mnemonic_phrase() != ()
    assert type(cr.mnemonic_phrase()) == str


# Generated at 2022-06-23 21:13:45.062747
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypt = Cryptographic()
    print( crypt.mnemonic_phrase(8, "-"))


# Generated at 2022-06-23 21:13:46.414742
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    p = Cryptographic()
    print(p.uuid())
    pass

# Generated at 2022-06-23 21:13:54.163717
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print("Is Cryptographic's uuid function work properly?")
    print("Test start!")
    cryp = Cryptographic()
    print("Using default object:")
    for i in range(10):
        print(cryp.uuid())
    print("---------------------------------")
    print("Using new object:")
    for i in range(10):
        print(cryp.uuid(as_object = True))
    print("---------------------------------")
    print("Using new object and random seed:")
    cryp = Cryptographic(seed = i)
    for i in range(10):
        print(cryp.uuid(as_object = True))
    print("Test end!")
    print()
    print()


# Generated at 2022-06-23 21:13:58.051408
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    a = Cryptographic().token_urlsafe(20)
    b = Cryptographic().token_urlsafe(20)
    c = a[0:20]
    assert (len(a) == 24)
    assert (len(b) == 24)
    assert (a != b)
    assert (len(c) == 20)

# Generated at 2022-06-23 21:13:59.371083
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()

# Generated at 2022-06-23 21:14:01.005474
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert isinstance(c.token_bytes(), bytes)

# Generated at 2022-06-23 21:14:04.065177
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Example for testing method token_hex of class Cryptographic"""
    assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:14:06.593545
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Call method token_hex of class Cryptographic
    result = Cryptographic.token_hex(16)
    lenght = len(result)

    # Verify the result
    assert(lenght == 32)

# Generated at 2022-06-23 21:14:17.951395
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print()
    print(Cryptographic.mnemonic_phrase())
    print(Cryptographic.token_bytes())
    print(Cryptographic.token_hex())
    print(Cryptographic.token_urlsafe())
    print(Cryptographic.uuid())
    print(Cryptographic.uuid(as_object=True))
    print(Cryptographic.hash())
    print(Cryptographic.hash(algorithm=Algorithm.MD5))
    print(Cryptographic.hash(algorithm=Algorithm.SHA1))
    print(Cryptographic.hash(algorithm=Algorithm.SHA224))
    print(Cryptographic.hash(algorithm=Algorithm.SHA256))
    print(Cryptographic.hash(algorithm=Algorithm.SHA384))
    print(Cryptographic.hash(algorithm=Algorithm.SHA512))

# Generated at 2022-06-23 21:14:20.195677
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    actual = Cryptographic.token_hex()
    assert isinstance(actual, str)

# Generated at 2022-06-23 21:14:22.427062
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    return Cryptographic(seed = 123)

# Test function uuid()

# Generated at 2022-06-23 21:14:24.760136
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    a = Cryptographic()
    assert isinstance(a.uuid(), UUID)
    assert isinstance(a.uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:14:32.100007
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    if __name__ == '__main__':
        from mimesis.enums import Algorithm
        import pytest
        from pprint import pprint

        CRYPTO = Cryptographic()
        ALGORITHMS = [
            Algorithm.BLAKE2B,
            Algorithm.BLAKE2S,
            Algorithm.MD5,
            Algorithm.SHA1,
            Algorithm.SHA224,
            Algorithm.SHA256,
            Algorithm.SHA384,
            Algorithm.SHA512,
            Algorithm.SHA3_224,
            Algorithm.SHA3_256,
            Algorithm.SHA3_384,
            Algorithm.SHA3_512
        ]

        def test_hash_algorithms():
            for algorithm in ALGORITHMS:
                hash_result = CRYPTO.hash

# Generated at 2022-06-23 21:14:33.018733
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    Cryptographic.token_hex()


# Generated at 2022-06-23 21:14:34.360883
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic('en')
    assert a is not None


# Generated at 2022-06-23 21:14:39.091107
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test the method mnemonic_phrase of class Cryptographic."""
    p = Cryptographic()
    assert re.search(r'\w+\s\w+\s\w+', p.mnemonic_phrase())

# Generated at 2022-06-23 21:14:43.735316
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    obj = Cryptographic(seed=42)
    args = obj._validate_int(10)
    expected = "4f4d2f4c4d4e4f4d609c9d3b3cb1cb3f"
    actual = obj.token_hex(args)
    assert actual == expected


# Generated at 2022-06-23 21:14:46.783074
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # 1. Create object
    crypto = Cryptographic()

    # 2. Get result
    result = crypto.token_bytes()

    # 3. Check result
    assert result is not None # Assert check


# Generated at 2022-06-23 21:14:49.325786
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto_provider = Cryptographic()
    result = crypto_provider.mnemonic_phrase()
    assert result is not None
    assert isinstance(result, str)
    assert len(result) == 36

# Generated at 2022-06-23 21:14:50.721470
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert crypto.token_bytes()



# Generated at 2022-06-23 21:14:57.980760
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    import unittest
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    class TestCryptographic(unittest.TestCase):

        def setUp(self):
            self.crypto = Cryptographic('en')

        def test_hash(self):
            result = self.crypto.hash(Algorithm.MD5)
            self.assertEqual(len(result), 32)
            self.assertIsInstance(result, str)
            self.assertNotIsInstance(result, int)

    unittest.main()

# Generated at 2022-06-23 21:15:00.403480
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    tb = Cryptographic().token_bytes(10)
    assert len(tb) == 10
    assert isinstance(tb, bytes)

# Generated at 2022-06-23 21:15:05.687756
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cracker = Cryptographic(seed=42)
    # algorithm = Algorithm.SHA1
    # print(cracker.hash(algorithm=Algorithm.SHA1))
    assert cracker.hash(algorithm=Algorithm.SHA1) == "4f3020bc6c2b6b9422feb62d1adca1e4b6ad9d4b"



# Generated at 2022-06-23 21:15:12.534453
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print()
    print('*' * 80)
    print('* Testing method "mnemonic_phrase" of module "cryptographic" *')
    print('*' * 80)

    crypto_provider = Cryptographic(seed=123456)

    # Length is 12
    phrase = crypto_provider.mnemonic_phrase(12)
    print(phrase)
    assert phrase == 'desk engine choice glove avoid picture spring upset split'\
                    ' shoulder effort'

    # Length is 24
    phrase = crypto_provider.mnemonic_phrase(24)
    print(phrase)
    assert phrase == 'desk engine choice glove avoid picture spring upset split'\
                    ' shoulder effort\n'\
                    'sponge army surround scan diamond inquiry snow seed tray'\
                    ' morning'

    # Length is 12, but separator is set to be character

# Generated at 2022-06-23 21:15:16.553876
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    possible_values = (
        'md5',
        'sha256',
        'sha512',
    )

    crypto = Cryptographic()
    for possible_value in possible_values:
        result = crypto.hash(algorithm=Algorithm(possible_value))

        assert isinstance(result, str) is True

# Generated at 2022-06-23 21:15:20.233193
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonic_phrase = Cryptographic().mnemonic_phrase()
    assert len(mnemonic_phrase.split(" ")) == 12
    assert isinstance(mnemonic_phrase,str) is True

# Generated at 2022-06-23 21:15:22.137977
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    result = provider.token_urlsafe()
    assert(len(result) > 0)

# Generated at 2022-06-23 21:15:24.873577
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test token_bytes method"""
    data = Cryptographic().token_bytes()
    assert(data)
    assert(len(data) > 0)


# Generated at 2022-06-23 21:15:27.565018
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    x = Cryptographic().token_hex()
    print("x=", x)
    print("type(x)=", type(x))

    assert type(x) is str


# Generated at 2022-06-23 21:15:29.394840
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token_bytes = Cryptographic.token_bytes()
    assert isinstance(token_bytes, bytes)

# Generated at 2022-06-23 21:15:29.961697
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass

# Generated at 2022-06-23 21:15:31.961327
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    uuid = crypto.uuid()
    assert isinstance(uuid, str)



# Generated at 2022-06-23 21:15:33.453900
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    _cryp = Cryptographic()
    print(_cryp.token_bytes(30))



# Generated at 2022-06-23 21:15:35.755199
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    data_provider_cryptographic = Cryptographic()
    assert isinstance(data_provider_cryptographic.token_bytes(), bytes)


# Generated at 2022-06-23 21:15:37.214870
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    res = Cryptographic().token_hex()
    assert res is not None


# Generated at 2022-06-23 21:15:47.756346
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm
    from mimesis.enums import Algorithm
    from mimesis.enums import Algorithm
    from mimesis.enums import Algorithm
    assert isinstance(Algorithm.MD5, Algorithm)
    assert Algorithm.MD5.value != 'abc'
    assert Algorithm.MD5 != 'abc'
    assert Algorithm.MD5 != Algorithm.SHA1
    assert Algorithm(Algorithm.MD5.value) == Algorithm.MD5
    assert Algorithm.MD5.name == Algorithm.MD5.value
    assert isinstance(str(Algorithm.MD5), str)
    assert repr(Algorithm.MD5) == '<Algorithm.MD5: MD5>'
    assert str(Algorithm.MD5) == 'MD5'

# Generated at 2022-06-23 21:15:50.513753
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # TODO: write unit test for method token_bytes of class Cryptographic
    pass


# Generated at 2022-06-23 21:15:53.740152
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.uuid()
    assert crypto.uuid(as_object=True)
    assert crypto.mnemonic_phrase()
    assert crypto.mnemonic_phrase(length=4)
    assert crypto.token_bytes()
    assert crypto.token_hex()
    assert crypto.token_urlsafe()

# Generated at 2022-06-23 21:15:57.416264
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    h = crypto.hash(Algorithm.SHA256)
    assert (len(h) == 64)
    assert (isinstance(h, str))
    assert (h.isalnum())


# Generated at 2022-06-23 21:16:00.739998
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Arrange
    tokens = [
        Cryptographic().token_hex() for _ in range(3)
    ]
    # Act
    results = [
        len(token) == 32 for token in tokens
    ]
    # Assert
    assert all(results)

# Generated at 2022-06-23 21:16:02.566682
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    result = c.token_bytes()
    print(result)


# Generated at 2022-06-23 21:16:04.690298
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert 'string' == type(Cryptographic.token_hex(32))
    assert 64 == len(Cryptographic.token_hex(32))


# Generated at 2022-06-23 21:16:05.956366
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic('en')
    s = c.mnemonic_phrase()
    c.close()
    return s


# Generated at 2022-06-23 21:16:07.432334
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert isinstance(Cryptographic().token_urlsafe(), str)

# Generated at 2022-06-23 21:16:10.963423
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase
    assert crypto.hash
    assert crypto.token_bytes
    assert crypto.token_hex
    assert crypto.token_urlsafe
    assert crypto.uuid
    

# Generated at 2022-06-23 21:16:13.106744
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    print(c.mnemonic_phrase())
    print(c.mnemonic_phrase(12))


# Generated at 2022-06-23 21:16:14.091279
# Unit test for constructor of class Cryptographic
def test_Cryptographic(): 
    assert type(Cryptographic()) == Cryptographic


# Generated at 2022-06-23 21:16:24.762717
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm
    from mimesis.exceptions import SeedRequiredError
    from mimesis.enums import Data
    from mimesis.seed import Seed
    from mimesis import Cryptographic
    cls = Cryptographic(seed=Seed(Data.SEED_DATA))
    cls_no_seed = Cryptographic()
    # Case 1: Check if value is valid UUID object
    valid_uuid = cls.uuid(as_object=True)
    assert isinstance(valid_uuid, UUID)
    # Case 2: If the random seed is not passed,
    # then raise SeedRequiredError
    try:
        cls_no_seed.uuid()
    except SeedRequiredError:
        pass
    # Case 3: Check if value is a valid string
    valid_string

# Generated at 2022-06-23 21:16:29.747345
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    uuid = crypto.uuid()
    assert uuid is not None
    assert len(uuid) == 36
    assert type(uuid) == str

    uuid = crypto.uuid(True)
    assert uuid is not None
    assert type(uuid) == UUID


# Generated at 2022-06-23 21:16:31.700936
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test method token_bytes."""
    token_bytes = Cryptographic().token_bytes()
    assert len(token_bytes)


# Generated at 2022-06-23 21:16:34.775209
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Generate random "token_bytes"
    assert len(Cryptographic.token_bytes()) == 32
    assert len(Cryptographic.token_bytes(32)) == 32
    assert len(Cryptographic.token_bytes(64)) == 64



# Generated at 2022-06-23 21:16:35.789676
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic.token_urlsafe())

# Generated at 2022-06-23 21:16:38.750583
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    import mimesis
    # Setup the provider
    provider = mimesis.Cryptographic()
    # Generate some data
    data = provider.token_bytes()
    print (data)

# Generated at 2022-06-23 21:16:43.084015
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    cryptographic = Cryptographic('en')
    for algorithm in Algorithm:
        assert cryptographic.hash(algorithm=algorithm)
    assert cryptographic.hash(algorithm=Algorithm.NONE)
    assert cryptographic.uuid()
    assert cryptographic.token_bytes()
    assert cryptographic.token_hex()
    assert cryptographic.token_urlsafe()
    assert cryptographic.mnemonic_phrase()

# Generated at 2022-06-23 21:16:46.624220
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto_provider = Cryptographic()
    token_bytes = crypto_provider.token_bytes()
    assert len(token_bytes) == 32


# Generated at 2022-06-23 21:16:49.175427
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic()
    hex = token.token_hex(36)
    print(hex)


# Generated at 2022-06-23 21:16:50.911004
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Unit test for constructor of class Cryptographic"""
    test = Cryptographic()
    print(test.__dict__, '\n')


# Generated at 2022-06-23 21:16:54.120919
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert isinstance(Cryptographic().token_bytes(), (bytes))
    assert isinstance(Cryptographic().token_bytes(entropy=16), (bytes))


# Generated at 2022-06-23 21:16:58.936065
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Test case 1
    gen = Cryptographic('en')
    phrase = gen.mnemonic_phrase()
    assert phrase is not None
    # Test case 2
    gen = Cryptographic('en')
    phrase = gen.mnemonic_phrase(length=22)
    assert phrase is not None
    # Test case 3
    gen = Cryptographic('en')
    phrase = gen.mnemonic_phrase(length=22,separator='-')
    assert phrase is not None

# Generated at 2022-06-23 21:17:01.973022
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    a = Cryptographic()
    assert len(a.mnemonic_phrase()) == 12
    assert len(a.mnemonic_phrase(10)) == 10
    assert len(a.mnemonic_phrase(5, separator='')) == 5

# Generated at 2022-06-23 21:17:05.033151
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cryptographic = Cryptographic()
    result = cryptographic.token_bytes()
    assert len(result) == 32
    result = cryptographic.token_bytes(64)
    assert len(result) == 64
    result = cryptographic.token_bytes(512)
    assert len(result) == 512


# Generated at 2022-06-23 21:17:10.982041
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    hash_ = provider.hash(Algorithm.MD5)
    bytes = provider.token_bytes(5)
    hex_ = provider.token_hex(10)
    urlsafe = provider.token_urlsafe()
    mnemonic_phrase = provider.mnemonic_phrase()


if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-23 21:17:13.583936
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert(len(crypto.token_hex()) == 64)


# Generated at 2022-06-23 21:17:15.456273
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crg = Cryptographic()
    uuid_1 = crg.uuid()
    uuid_2 = crg.uuid()
    assert uuid_1 != uuid_2  # noqa: E711,E712



# Generated at 2022-06-23 21:17:17.071697
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    decoded = Crypto.token_urlsafe(entropy=20)
    decoded = decoded.encode()
    b64_encode = base64.urlsafe_b64encode(decoded)
    print(b64_encode)

# Generated at 2022-06-23 21:17:21.783821
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj_Cryptographic = Cryptographic()
    random_Cryptographic_token_bytes = obj_Cryptographic.token_bytes()
    assert isinstance(random_Cryptographic_token_bytes,bytes)
    assert len(random_Cryptographic_token_bytes) == 32


# Generated at 2022-06-23 21:17:24.270122
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    ret = crypto.token_bytes(32)
    assert len(ret) == 32
    assert isinstance(ret, bytes)


# Generated at 2022-06-23 21:17:27.794307
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    results = []
    for _ in range(1000):
        c = Cryptographic()
        results.append(c.mnemonic_phrase())
    assert results[0] == 'handling teacher standing awkward sphere'
    assert results[-1] == 'cobble basement canyon drop'


# Generated at 2022-06-23 21:17:30.394063
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    test = Cryptographic()
    # Validate that method is returning a UUID
    assert type(test.uuid()) is str



# Generated at 2022-06-23 21:17:32.066235
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic.token_urlsafe(3)
    assert token == 's'

# Generated at 2022-06-23 21:17:34.534597
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 36
    assert len(Cryptographic().uuid(as_object=True)) == 36


# Generated at 2022-06-23 21:17:38.781202
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """cryptographic.test_Cryptographic_token_bytes"""
    # Arrange
    cr = Cryptographic()
    result = cr.token_hex()
    # Act
    # Assert
    assert result is not None
    assert isinstance(result, str)
    assert len(result) == 64


# Generated at 2022-06-23 21:17:40.418937
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test unit for method Cryptographic::token_urlsafe
    """
    entropy = secrets.token_urlsafe()
    print(entropy)


# Generated at 2022-06-23 21:17:41.976678
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 32


# Generated at 2022-06-23 21:17:43.631051
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():

    assert len(Cryptographic().token_hex(10)) == 20


# Generated at 2022-06-23 21:17:45.045772
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    provider = Cryptographic.token_hex()
    print(provider)

# Generated at 2022-06-23 21:17:45.566231
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()

# Generated at 2022-06-23 21:17:49.851188
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # init the Cryptographic object
    cryp = Cryptographic()
    # get the mnemonic_phrase
    mnemonic_phrase = cryp.mnemonic_phrase()
    # display the result
    print('cryp.mnemonic_phrase() = {mnemonic_phrase}'.format(mnemonic_phrase=mnemonic_phrase))


# Generated at 2022-06-23 21:17:51.266908
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    _instance = Cryptographic()
    _instance.hash()


# Generated at 2022-06-23 21:17:53.092905
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    assert isinstance(Cryptographic.token_bytes(), bytes)


# Generated at 2022-06-23 21:17:54.365934
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    Cryptographic().token_urlsafe()


# Generated at 2022-06-23 21:18:00.991588
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic('en')
    print(crypto.hash(Algorithm.MD5))
    print(crypto.hash(Algorithm.SHA1))
    print(crypto.hash(Algorithm.SHA224))
    print(crypto.hash(Algorithm.SHA256))
    print(crypto.hash(Algorithm.SHA384))
    print(crypto.hash(Algorithm.SHA512))



# Generated at 2022-06-23 21:18:04.959251
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    Cryptographic_obj = Cryptographic(seed=5)
    output = Cryptographic_obj.token_urlsafe()
    assert output == 'uG7VrYYrZvAX8V-WtOOgnw'

# Generated at 2022-06-23 21:18:07.055438
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic('en')
    result = crypto.token_bytes(16)
    assert len(result) == 16


# Generated at 2022-06-23 21:18:08.692953
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Cryptographic.uuid()
    assert Cryptographic.uuid()


# Generated at 2022-06-23 21:18:17.233016
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    random = Cryptographic(seed=1234567890)
    assert random.hash() == 'c1819fd7f55a9c9e7dd74e6c72a8e0c6'
    assert random.hash(Algorithm.SHA3_256) == 'b2f4cc4e9460661a7225370d34d249a86c12a1b8df0eeb90dff99e11c0a89b14'
    assert random.hash(Algorithm.SHA256) == '6097c9b938d072e4f4a3e8ea4fdb4d4b1fdcad0e8fd9dee9a42a7a95c46f8ff8'

# Generated at 2022-06-23 21:18:21.127029
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex(entropy=40) == "27d1f3db817ad2efa2bfdfd9eefbaf8da7eecbc5"

# Generated at 2022-06-23 21:18:23.121221
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe() != c.token_urlsafe()


# Generated at 2022-06-23 21:18:25.110077
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    test = obj.hash()
    assert test != None


# Generated at 2022-06-23 21:18:26.512224
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic.token_urlsafe()
    assert len(token) > 0

# Generated at 2022-06-23 21:18:31.729202
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    phrases = []
    for i in range(1000):
        phrases.append(c.mnemonic_phrase())

    print(phrases)
    assert phrases


if __name__ == '__main__':
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:18:36.066060
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test method token_urlsafe of class Cryptographic."""
    cr = Cryptographic(seed=1234567)
    token_urlsafe = cr.token_urlsafe(entropy=1)
    assert token_urlsafe == 'fY8'


# Generated at 2022-06-23 21:18:43.191739
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    rnd = secrets.SystemRandom()
    algos = [alg for alg in dir(hashlib) if callable(getattr(hashlib, alg))]
    for _ in ['foo', rnd, rnd.random, rnd.choice, rnd.sample, rnd.randrange]:
        for _ in range(32):
            alg = rnd.choice(algos)
            if not alg.startswith('_'):
                break

    hash = Cryptographic().hash(alg)
    assert len(hash) == 32
    assert isinstance(hash, str)



# Generated at 2022-06-23 21:18:47.712993
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe of class Cryptographic."""
    assert len(Cryptographic.token_urlsafe()) == 44
    assert len(Cryptographic.token_urlsafe(10)) == 22
    assert len(Cryptographic.token_urlsafe(100)) == 132


# Generated at 2022-06-23 21:18:50.403879
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj = Cryptographic()
    for i in range(10):
        assert(type(obj.token_bytes()) == bytes)


# Generated at 2022-06-23 21:18:51.850400
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Create instance of class Cryptographic
    Cryptographic()

# Generated at 2022-06-23 21:18:56.265903
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    l = []
    for x in range(0,20):
        l.append(len(Cryptographic.token_bytes(64).hex()))
    print(l)
    assert l==[128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128]


# Generated at 2022-06-23 21:18:57.446576
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32


# Generated at 2022-06-23 21:19:01.576103
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic(seed=123)
    assert cr.hash() == 'c56ae9a68cff7ae56b3907f148aee354df27d8b8fb89b5635e9290553e13c8ab'
