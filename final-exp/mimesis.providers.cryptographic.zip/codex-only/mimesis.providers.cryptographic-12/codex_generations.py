

# Generated at 2022-06-23 21:09:01.967690
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cp = Cryptographic()
    assert len(cp.token_bytes(8)) == 8


# Generated at 2022-06-23 21:09:09.599060
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c1 = Cryptographic()
    c2 = Cryptographic()
    c3 = Cryptographic()
    c4 = Cryptographic()
    c5 = Cryptographic()
    c6 = Cryptographic()

    #print(c1.mnemonic_phrase())
    #print(c2.mnemonic_phrase())
    #print(c3.mnemonic_phrase())
    #print(c4.mnemonic_phrase())
    #print(c5.mnemonic_phrase())
    #print(c6.mnemonic_phrase())

    assert c1.mnemonic_phrase() != c2.mnemonic_phrase() != c3.mnemonic_phrase() != c4.mnemonic_phrase() != c5.mnemonic_phrase() != c6.mnemonic_phrase()

# Generated at 2022-06-23 21:09:14.936623
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto1=Cryptographic()
    crypto2=Cryptographic()
    crypto3=Cryptographic()

    crypto1.seed(1)
    crypto2.seed(1)
    crypto3.seed(2)

    print("This is test_Cryptographic_mnemonic_phrase()")
    print("The mnemonic phrase of crypto1.seed(1) is: ", crypto1.mnemonic_phrase())
    print("The mnemonic phrase of crypto2.seed(1) is: ", crypto2.mnemonic_phrase())
    print("The mnemonic phrase of crypto3.seed(2) is: ", crypto3.mnemonic_phrase())
    print("The mnemonic phrase of crypto2.seed(1) with length 10 is: ", crypto2.mnemonic_phrase(10))

# Generated at 2022-06-23 21:09:18.106591
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic(seed=123456789)
    assert crypto.uuid() == '3aafd7a3-8c8f-4f37-acb2-764b203032b7'


# Generated at 2022-06-23 21:09:26.521613
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Arrange
    crypto = Cryptographic()

    # Act
    url_token = crypto.token_urlsafe(32)
    # URL-safe tokens do not contain "+" and "/".
    # This token is a Base64-encoded URL-safe token.
    # https://docs.python.org/3/library/secrets.html
    url_token_valid = url_token.replace('+', '-').replace('/', '_')

    # Assert
    assert len(url_token) == 43
    assert len(url_token_valid) == 44
    assert len(set(url_token_valid)) == 64

# Generated at 2022-06-23 21:09:29.930451
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert (
        Cryptographic.uuid()
        == "66b90a49-9faa-4041-be17-f7eddc0df84c"
    )


# Generated at 2022-06-23 21:09:32.727494
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    seed = 'a random string'
    c = Cryptographic(seed=seed)
    output_1 = c.mnemonic_phrase()
    print(output_1)



# Generated at 2022-06-23 21:09:34.471770
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert isinstance(Cryptographic.token_bytes(), bytes)


# Generated at 2022-06-23 21:09:37.944034
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import mimesis as mimesis
    import mimesis.enums
    import mimesis.providers.cryptographic
    import os
    import secrets

    c = mimesis.providers.cryptographic.Cryptographic()
    c.token_urlsafe()


# Generated at 2022-06-23 21:09:39.396106
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test token_urlsafe method of class Cryptographic."""
    c = Cryptographic()
    result = c.token_urlsafe(32)
    assert len(result) == 43

# Generated at 2022-06-23 21:09:50.673999
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    import random as rnd
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    rnd.seed(9001)

    def word_list(x, word_len):
        words = []
        for i in range(x):
            words.append(str(i) * word_len)
        return words

    def test_len(phrase_len, word_len, delimiters, phrases=None):
        if phrases is None:
            phrases = {}
        for delimiter in delimiters:
            phrases[delimiter] = []
            provider = Cryptographic(word_list=word_list(1, word_len))
            result = provider.mnemonic_phrase(phrase_len, delimiter)
            result_words = result.split(delimiter)
           

# Generated at 2022-06-23 21:09:52.254390
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe()
    assert token
    print(token)

# Generated at 2022-06-23 21:09:54.377081
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cp = Cryptographic.token_bytes(16)
    assert isinstance(cp, bytes)
    assert len(cp) == 32


# Generated at 2022-06-23 21:09:56.025830
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cryptographic = Cryptographic('en')
    # print(cryptographic.token_bytes(8))


# Generated at 2022-06-23 21:09:57.309578
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    assert cr.hash() == cr.hash()

# Generated at 2022-06-23 21:10:00.810020
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """The test for the method Cryptographic.token_bytes."""
    tok = Cryptographic().token_bytes(entropy=32)
    assert b'\x10' in tok
    assert b'\x80' in tok


# Generated at 2022-06-23 21:10:11.591795
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    from mimesis.enums import SHA256
    from mimesis.enums import SHA512
    from mimesis.enums import SHA1
    from mimesis.enums import SHA384
    from mimesis.enums import SHA224
    from mimesis.enums import SHA3_256
    from mimesis.enums import SHA3_512
    from mimesis.enums import SHA3_224
    from mimesis.enums import SHA3_384
    from mimesis.enums import BLAKE2s
    from mimesis.enums import BLAKE2b
    from mimesis.enums import MD5
    from mimesis.enums import MD4
    from mimesis.enums import MD5_SHA1

    #

# Generated at 2022-06-23 21:10:14.163184
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    result = crypto.token_hex()
    assert type(result) == str
    assert len(result) == 64


# Generated at 2022-06-23 21:10:15.889724
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic('a')
    # case 0
    string = provider.token_urlsafe()
    assert type(string) == str
    assert len(string) == 43

# Generated at 2022-06-23 21:10:22.872059
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Create a Cryptographic
    c = Cryptographic()
    # c.token_hex() -> Convert a 16-byte string to a hexadecimal string.
    # c.token_hex(32) -> Convert a 32-byte string to a hexadecimal string.
    assert c.token_hex() == c.token_hex()
    assert c.token_hex() != c.token_hex(32)


# Generated at 2022-06-23 21:10:25.084403
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic(seed=1234)
    assert cr.mnemonic_phrase() == 'grasped fistfuls tabling'



# Generated at 2022-06-23 21:10:26.466466
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid()


# Generated at 2022-06-23 21:10:30.696650
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    Cy = Cryptographic()
    token_urlsafe = Cy.token_urlsafe(32)
    asserttoken_urlsafe!="", f"Value not expected: {token_urlsafe}. Please recheck the code"

#Unit test for method token_hex of class Cryptographic

# Generated at 2022-06-23 21:10:33.546492
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis import Cryptographic
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    assert isinstance(phrase, str)
    assert len(phrase) > 0



# Generated at 2022-06-23 21:10:39.971373
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Default parameters
    t_urls = []
    url_len = []
    # Generate 100 tokens
    for i in range(100):
        t_urls.append(Cryptographic().token_urlsafe())
    # Get string length of each token
    for i in range(100):
        url_len.append(len(t_urls[i]))
    # Check if the length is consistent
    length = url_len[0]
    for j in range(100):
        if url_len[j] != length:
            print("Fail", j, url_len[j], length)


# Generated at 2022-06-23 21:10:42.218047
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex() is not None


# Generated at 2022-06-23 21:10:49.442697
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    ## - Tests 
    crypto = Cryptographic()
    # Should not raise NonEnumerableError
    crypto.hash(Algorithm.SHA1)
    crypto.hash(Algorithm.SHA224)
    crypto.hash(Algorithm.SHA256)
    crypto.hash(Algorithm.SHA384)
    crypto.hash(Algorithm.SHA512)
    crypto.hash(Algorithm.MD5)
    crypto.hash(Algorithm.BLAKE2S)
    crypto.hash(Algorithm.BLAKE2B)
    crypto.hash(Algorithm.SHA3_224)
    crypto.hash(Algorithm.SHA3_256)
    crypto.hash(Algorithm.SHA3_384)
    crypto.hash(Algorithm.SHA3_512)
    crypto.hash(Algorithm.SHAKE_128)
    crypto.hash

# Generated at 2022-06-23 21:10:52.530550
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    token = Cryptographic().token_bytes()
    assert type(token) == bytes
    assert len(token) == 32


# Generated at 2022-06-23 21:10:55.279690
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic
    res = crypto.hash()
    assert len(res) == 32
    res = crypto.hash(Algorithm.SHA256)
    assert len(res) == 64


# Generated at 2022-06-23 21:10:58.015000
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for the method mnemonic_phrase of class Cryptographic."""
    print(Cryptographic.mnemonic_phrase())

# Generated at 2022-06-23 21:11:04.215791
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.builtins import Cryptographic
    # Generate UUID as string
    uuid1 = Cryptographic.uuid()
    assert uuid1
    assert isinstance(uuid1, str)
    # Generate UUID as UUID object
    uuid2 = Cryptographic.uuid(as_object=True)
    assert uuid2
    assert isinstance(uuid2, UUID)


# Generated at 2022-06-23 21:11:05.753299
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    a = Cryptographic.token_bytes()
    print(a)


# Generated at 2022-06-23 21:11:07.379209
# Unit test for constructor of class Cryptographic
def test_Cryptographic():  # noqa: D202
    """Unit test for constructor of class Cryptographic"""
    crpt = Cryptographic()

# Generated at 2022-06-23 21:11:11.027436
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    assert isinstance(obj.hash(Algorithm.MD5), str)


# Generated at 2022-06-23 21:11:20.301359
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Init
    cr = Cryptographic()
    
    # Test
    assert cr.hash(Algorithm.SHA256) == '8ed056f07a6d29c6e93f2a8c1d0b60efc6a6821b68085e6aeee6456c99d147e9'
    assert cr.hash(Algorithm.SHA512) == 'af3b8cef2e2ea25c6d9583020e8da5adf2ff04fb1ca78a7b8c50e4fa4fc4a4d9a9b0845c5532cf7d28c19ebf2b47815a1c0a7b47d13b3ff9c3c8a2b65d1b3ca0'


# Generated at 2022-06-23 21:11:30.446063
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from random import seed
    from mimesis.builtins import  datetime, random, math, network, system, text, web
    seed(1)
    c = Cryptographic('en')
    assert c.seed == 1
    assert c.random is instance(random)
    assert c.datetime is instance(datetime)
    assert c.math is instance(math)
    assert c.network is instance(network)
    assert c.system is instance(system)
    assert c.text is instance(text)
    assert c.web is instance(web)
    assert c.token_bytes() == b'\x8b\x9e\x84\xb5\xbe\xdeu\x10\x97\x06\x16\x1a\xbb\x86'

# Unit tests for instance method "uuid

# Generated at 2022-06-23 21:11:36.123634
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cd = Cryptographic()
    assert cd.token_hex() 
    assert len(cd.token_hex()) == 64
    assert cd.token_hex(32)
    assert len(cd.token_hex(32)) == 64
    assert cd.token_hex(50)
    assert len(cd.token_hex(50)) == 100
    assert cd.token_hex(100)
    assert len(cd.token_hex(100)) == 200


# Generated at 2022-06-23 21:11:47.086864
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Create object of class Cryptographic
    crypto = Cryptographic()

    # Create variable for object of class Cryptographic.Meta
    meta = crypto.Meta

    # Create variable for name of class Cryptographic
    name = crypto.__class__.__name__

    # Create variable for doc string of class Cryptographic
    doc_string = crypto.__doc__

    # Check name of class Cryptographic
    assert name == 'Cryptographic'

    # Check doc string of class Cryptographic
    assert doc_string == 'Class that provides cryptographic data.'

    # Check doc string of class Cryptographic.Meta
    assert meta.__doc__ == 'Class for metadata.'

    # Check name of class Cryptographic.Meta
    assert meta.name == 'cryptographic'

    # Check equality of random UUIDs
    assert crypto.uuid() != crypto.uuid()

    #

# Generated at 2022-06-23 21:11:51.213881
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis import Cryptographic
    cy = Cryptographic('zh')
    result = cy.mnemonic_phrase()
    assert(result)
    print("test_Cryptographic_mnemonic_phrase=", result)



# Generated at 2022-06-23 21:11:52.295754
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex(16)) == 32

# Generated at 2022-06-23 21:11:59.335479
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    x = Cryptographic(seed=1)
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
    print(x.mnemonic_phrase())
   

# Generated at 2022-06-23 21:12:00.504094
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  assert len(Cryptographic.token_urlsafe()) == 43
  assert len(Cryptographic.token_urlsafe(10)) == 16

# Generated at 2022-06-23 21:12:02.996763
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # format what the function should return
    # assert is the assertion
    assert 'a51480ae907e7a25f8e2f7bbbfb58a43' == Cryptographic.token_hex(32)

# Generated at 2022-06-23 21:12:09.423087
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    entropy = 32
    c = Cryptographic()
    token = c.token_urlsafe(entropy)

    token2 = c.token_urlsafe(entropy)
    #print(token, token2)
    print(token, len(token)) 
    print(token2, len(token2))
    assert token != token2

# Generated at 2022-06-23 21:12:15.201319
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe of class Cryptographic."""
    c = Cryptographic()
    assert isinstance(c.token_urlsafe(), str)
    assert not c.token_urlsafe().endswith('==')
    assert len(c.token_urlsafe(64)) == 64
    assert len(c.token_urlsafe(64)) == 64
    assert len(c.token_urlsafe()) == 43


# Generated at 2022-06-23 21:12:16.511023
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32


# Generated at 2022-06-23 21:12:23.049021
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    test = Cryptographic()
    # test function
    res = test.token_hex()
    # test type return
    assert isinstance(res, str), 'Return must str '
    # test length return
    assert len(res) == 64, 'len(res) must be 64'
    # test length return
    assert len(res) == 64, 'len(res) must be 64'


# Generated at 2022-06-23 21:12:25.226237
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.MD5)



# Generated at 2022-06-23 21:12:26.079367
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic()

# Generated at 2022-06-23 21:12:28.573274
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """ Test for method token_bytes."""
    result = Cryptographic().token_bytes()
    assert result
# Test for method token_bytes of class Cryptographic


# Generated at 2022-06-23 21:12:30.343847
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32

# Generated at 2022-06-23 21:12:35.755107
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic."""
    if Cryptographic().uuid() and Cryptographic().uuid(as_object=False) and \
            Cryptographic().uuid(as_object=True):
        return True
    else:
        return False


# Generated at 2022-06-23 21:12:38.582196
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypt = Cryptographic(seed=1)
    crypt_res = crypt.token_hex()
    assert crypt_res == 'a8f8a320d35effbfa28a22fa0e3c8d51'


# Generated at 2022-06-23 21:12:41.476554
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # test1
    actual = len(Cryptographic().token_bytes()) <= 32
    expected = True
    assert actual == expected

    # test2
    actual = len(Cryptographic().token_bytes()) <= 32
    expected = True
    assert actual == expected


# Generated at 2022-06-23 21:12:43.476554
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    obj = Cryptographic()
    print(obj.mnemonic_phrase())

# Generated at 2022-06-23 21:12:45.193813
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Method for testing method mnemonic_phrase"""
    print(Cryptographic().mnemonic_phrase())


# Generated at 2022-06-23 21:12:46.533381
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.mnemonic_phrase())

# Generated at 2022-06-23 21:12:49.001135
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(32)) == 32


# Generated at 2022-06-23 21:12:51.135716
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    C = Cryptographic()
    result = C.hash(algorithm=Algorithm.SHA256)
    assert isinstance(result, str)
    assert len(result) == 64


# Generated at 2022-06-23 21:12:52.144545
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c is not None
    return c


# Generated at 2022-06-23 21:12:53.657528
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto is not None


# Generated at 2022-06-23 21:12:56.726393
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(algorithm=None) == "8f0f850c38d083e112d93c2f1bcc11f732fafc020e97f0b213e4d4100a58e47a"


# Generated at 2022-06-23 21:13:00.440498
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()
    assert Cryptographic().hash(Algorithm.MD5)
    assert Cryptographic().hash(Algorithm.SHA1)
    assert Cryptographic().hash(Algorithm.SHA224)
    assert Cryptographic().hash(Algorithm.SHA256)
    assert Cryptographic().hash(Algorithm.SHA384)
    assert Cryptographic().hash(Algorithm.SHA512)


# Generated at 2022-06-23 21:13:01.928018
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic.uuid() is not None


# Generated at 2022-06-23 21:13:02.946655
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-23 21:13:04.807909
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crt = Cryptographic()
    assert len(crt.token_hex(15)) == 30

# Generated at 2022-06-23 21:13:07.894017
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    assert isinstance(Cryptographic.token_bytes(), bytes)


# Generated at 2022-06-23 21:13:17.048573
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm
    from mimesis.enums import Field

    c = Cryptographic()


# Generated at 2022-06-23 21:13:18.239573
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic.mnemonic_phrase(2)
    print(c)

# Generated at 2022-06-23 21:13:20.467593
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Seed

    c = Cryptographic(seed=Seed.MIMESIS)
    result = c.mnemonic_phrase(4)
    assert result is not None

# Generated at 2022-06-23 21:13:22.702439
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    result = c.uuid()
    assert isinstance(result, str) == True


# Generated at 2022-06-23 21:13:24.183295
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    algorithm = Algorithm.SHA256
    assert c.hash(algorithm).isalnum()

# Generated at 2022-06-23 21:13:25.261351
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(16) is not None

# Generated at 2022-06-23 21:13:26.588851
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    token_urlsafe = provider.token_urlsafe()
    assert token_urlsafe

# Generated at 2022-06-23 21:13:28.695605
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  bytes_token = Cryptographic().token_urlsafe()
  assert len(bytes_token) == 43
  assert bytes_token.isascii()
  assert bytes_token.startswith('_')


# Generated at 2022-06-23 21:13:31.978619
# Unit test for constructor of class Cryptographic
def test_Cryptographic(): 
    """Test for the constructor."""
    crypto = Cryptographic()
    assert crypto.uuid() is not None
    assert crypto.uuid() != crypto.uuid()

# Generated at 2022-06-23 21:13:34.151722
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Unit test for method token_bytes of class Cryptographic
    cp = Cryptographic()
    print(cp.token_bytes())


# Generated at 2022-06-23 21:13:36.138368
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    assert c.token_bytes() != None

# Generated at 2022-06-23 21:13:37.394309
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64
    return


# Generated at 2022-06-23 21:13:40.223861
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Arrange
    token_bytes_var = (
        Cryptographic.token_bytes(entropy=32)
    )
    assert token_bytes_var
    assert isinstance(token_bytes_var, bytes)


# Generated at 2022-06-23 21:13:42.289694
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert isinstance(crypto.hash(), str)
    assert len(crypto.hash()) != 0


# Generated at 2022-06-23 21:13:44.222539
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():

	cr = Cryptographic()

	x = cr.uuid()
	assert isinstance(x,str)


# Generated at 2022-06-23 21:13:52.996955
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # With default algorithm
    cg = Cryptographic()
    assert len(cg.hash()) == 40

    # With algorithm SHA-1
    cg = Cryptographic(algorithm=Algorithm.SHA1)
    assert len(cg.hash(Algorithm.SHA1)) == 40
    assert len(cg.hash()) == 40

    # With algorithm SHA-256
    cg = Cryptographic(algorithm=Algorithm.SHA256)
    assert len(cg.hash(Algorithm.SHA256)) == 64
    assert len(cg.hash()) == 64

    # With algorithm SHA-512
    cg = Cryptographic(algorithm=Algorithm.SHA512)
    assert len(cg.hash(Algorithm.SHA512)) == 128
    assert len(cg.hash()) == 128

    # With algorithm BLAKE2

# Generated at 2022-06-23 21:14:01.172738
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.enums import Algorithm 
    from hashlib import sha256
    from mimesis.providers.cryptographic import Cryptographic
    assert Cryptographic.token_bytes(10) == b'\x89\xab\xeb\x9f\x9a\x86\xb6\x8a\xea\xbb'
    assert Cryptographic.token_hex(20) == 'b82bbf43cdcf2b8f1c01e62d6a7c0258e70a8b3f'
    assert len(Cryptographic.token_hex(256)) == 512
    assert Cryptographic.token_urlsafe(20) == 'd9XeZmiKxy6Woo_8U5L6Uw'
    assert Cryptographic.hash(Algorithm.SHA256) == sha256

# Generated at 2022-06-23 21:14:05.628784
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex(32)
    assert len(token) == 64


if __name__ == '__main__':
    c = Cryptographic();
    print(c.mnemonic_phrase(4, '-'))

# Generated at 2022-06-23 21:14:07.376983
# Unit test for constructor of class Cryptographic
def test_Cryptographic():

    obj_C = Cryptographic()
    
    assert obj_C


# Generated at 2022-06-23 21:14:10.300914
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    try:
        token = Cryptographic.token_hex(20)
    except Exception as e:
        raise AssertionError('Wrong') from e
    assert len(token) == 40, 'Wrong'

# Generated at 2022-06-23 21:14:20.473264
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic.

    +-------------+----------+
    | token_urlsafe | output  |
    +=============+==========+
    | sample_1    | gkhyi    |
    +-------------+----------+
    | sample_2    | a3va     |
    +-------------+----------+
    | sample_3    | cb_B     |
    +-------------+----------+
    | sample_4    | aiKf     |
    +-------------+----------+
    | sample_5    | 3xQM     |
    +-------------+----------+
    """
    sample_1 = Cryptographic().token_urlsafe()
    sample_2 = Cryptographic().token_urlsafe()
    sample_3 = Cryptographic().token_urlsafe()
    sample_4 = Cryptographic

# Generated at 2022-06-23 21:14:22.551375
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex(12)) == 24


# Generated at 2022-06-23 21:14:24.250886
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    assert(type(phrase) is str)
    assert(len(phrase.split()) == 12)

# Generated at 2022-06-23 21:14:27.748528
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    data = ['\xad\xc4', '\x12\xbf\x98', '\xe8', '\x1e\xfe\xdf\xc9', '\xdd']
    if Cryptographic().token_bytes() not in data:
        raise Exception('Test failed')


# Generated at 2022-06-23 21:14:30.692575
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert type(Cryptographic().uuid()) == str
    assert type(Cryptographic().uuid(as_object=True)) == UUID


# Generated at 2022-06-23 21:14:38.376645
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) != None
    assert len(c.hash(Algorithm.MD5)) == 32
    assert c.hash(Algorithm.SHA1) != None
    assert len(c.hash(Algorithm.SHA1)) == 40
    assert c.hash(Algorithm.SHA224) != None
    assert len(c.hash(Algorithm.SHA224)) == 56
    assert c.hash(Algorithm.SHA256) != None
    assert len(c.hash(Algorithm.SHA256)) == 64
    assert c.hash(Algorithm.SHA384) != None
    assert len(c.hash(Algorithm.SHA384)) == 96
    assert c.hash(Algorithm.SHA512) != None
    assert len(c.hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-23 21:14:40.369359
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic('en')
    res = crypto.token_hex()
    assert len(res) == 64

# Generated at 2022-06-23 21:14:42.139473
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    print(c.token_bytes())


# Generated at 2022-06-23 21:14:44.363471
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    uuid = provider.uuid()
    assert isinstance(uuid, str)
    assert len(uuid) == 36


# Generated at 2022-06-23 21:14:46.125770
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == len(Cryptographic().hash())


# Generated at 2022-06-23 21:14:47.325761
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    result = Cryptographic().uuid()
    assert isinstance(result, str)
    assert result


# Generated at 2022-06-23 21:14:51.536835
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.enums import Algorithm
    assert len(Cryptographic.token_bytes()) == 64
    assert len(Cryptographic.token_bytes(10)) == 20
    Algorithm.validate(Algorithm.SHA1)
    Cryptographic.hash(algorithm=Algorithm.SHA1)
    Cryptographic.mnemonic_phrase()
    Cryptographic.mnemonic_phrase(10)
    
    

# Generated at 2022-06-23 21:14:56.817708
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    length = 12
    separator = ' '
    words_generator = []
    while True:
        words_generator.append(secrets.token_urlsafe(16))
        if len(words_generator) >= length:
            break
    mnemonic_phrase = '{}'.format(separator).join(words_generator)
    assert mnemonic_phrase == Cryptographic().mnemonic_phrase(length, separator)

# Generated at 2022-06-23 21:15:04.266412
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Seed
    provider = Cryptographic(seed=42)
    result = provider.hash(Algorithm.MD5)
    assert result == 'c9f7a1d8bf062a2eccbceda0bdb41c8e', "Should be equal"

    # Without seed
    provider = Cryptographic()
    result = provider.hash(Algorithm.SHA_256)
    assert isinstance(result, str) and len(result) == 64, "Should be equal"




# Generated at 2022-06-23 21:15:06.203163
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cp = Cryptographic()
    uuid_1 = cp.uuid()
    assert isinstance(uuid_1, str)


# Generated at 2022-06-23 21:15:09.081818
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    n = 0
    provider = Cryptographic()
    for i in range(1000):
        mnemonic_phrase = provider.mnemonic_phrase()
        if mnemonic_phrase != ' ':
            n += 1
    assert n == 1000

if __name__ == "__main__":
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:15:14.284563
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    c = Cryptographic()
    b = c.mnemonic_phrase()
    print(b)
    c = Cryptographic()
    b = c.mnemonic_phrase(length=6)
    print(b)
    c = Cryptographic()
    b = c.mnemonic_phrase(length=6,separator=' - ')
    print(b)
    c = Cryptographic()
    b = c.hash()
    print(b)
    c = Cryptographic()
    b = c.hash(algorithm=Algorithm.SHA256)
    print(b)
    c = Cryptographic()
    b = c.hash(algorithm=Algorithm.SHA3_224)
    print(b)

# Generated at 2022-06-23 21:15:15.988650
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    s = Cryptographic('en')
    t = s.token_bytes(32)
    assert isinstance(t, bytes)


# Generated at 2022-06-23 21:15:20.488257
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    m = Cryptographic()
    token_hex = m.token_hex()
    assert token_hex != None
    assert len(token_hex) == 64
    assert type(token_hex) == str

# Generated at 2022-06-23 21:15:23.617869
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Constructor without params
    c = Cryptographic()
    assert c is not None
    # Constructor with params
    c = Cryptographic(seed=7)
    assert c is not None


# Generated at 2022-06-23 21:15:25.414379
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert c.token_bytes() == c.token_bytes()


# Generated at 2022-06-23 21:15:26.538433
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print(Cryptographic().uuid())


# Generated at 2022-06-23 21:15:30.918803
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypt = Cryptographic()
    crypt.seed(9)
    key = crypt._validate_enum('sha1', Algorithm)
    hash_value = crypt.hash(key)
    print(hash_value)

if __name__ == "__main__":
    test_Cryptographic_hash()

# Generated at 2022-06-23 21:15:32.830248
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    seed = 0
    provider = Cryptographic(seed=seed)
    assert provider.mnemonic_phrase() == "further grant motion market"

# Generated at 2022-06-23 21:15:34.727430
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cp = Cryptographic()
    assert cp.token_hex() == cp.token_hex(),  "Expected the same value"



# Generated at 2022-06-23 21:15:37.569972
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    _provider = Cryptographic()
    _result = _provider.uuid()

    assert type(_result) is str


# Generated at 2022-06-23 21:15:42.109504
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # \=o^O^o=/
    crypto = Cryptographic()
    actual_output = crypto.token_urlsafe()
    # System random is used to generate token
    # Hervious output always different, so I test non empty string 
    assert len(actual_output) > 0

# Generated at 2022-06-23 21:15:43.501435
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    x = Cryptographic.token_urlsafe()
    print(x, type(x))

# Generated at 2022-06-23 21:15:48.714575
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    x= Cryptographic()
    #assert x.uuid() == str(uuid.uuid4())
    x=x.uuid()
    assert type(x)==str
    assert len(x)==36
    assert x.count('-')==4
    for i in x.split('-'):
        if i.isdigit():
            assert len(i)==4
        else:
            assert len(i)==8


# Generated at 2022-06-23 21:15:51.730926
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    result = crypto.token_urlsafe()
    assert isinstance(result, str)
    assert len(result) == 44
    print(result)

# Generated at 2022-06-23 21:16:02.036863
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    seed = b'\x00\x01'
    c = Cryptographic(seed)
    assert c.token_hex() == '6a3d6a90a600bd91565b9d9b7f86bc67'
    assert c.token_hex() == '06f59bef1e6fca70b9d766961f6c18a6'
    assert c.token_hex() == 'c27b6a1c9f1a6a45a6a92f05f34f57a1'
    assert c.token_hex() == 'c9ddfad2a2f6a13fd47584f878e04b71'
    assert c.token_hex(3) == '4f315e4125c1b4a4'

# Generated at 2022-06-23 21:16:03.785513
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    words = Cryptographic().mnemonic_phrase(16)
    print(words)


# Generated at 2022-06-23 21:16:06.053511
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """ Test for method token_urlsafe of class Cryptographic """
    assert len(Cryptographic().token_urlsafe()) == 43



# Generated at 2022-06-23 21:16:07.108248
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 32

# Generated at 2022-06-23 21:16:11.012221
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    token_1  = c.token_urlsafe()
    print(token_1)
    token_2  = c.token_urlsafe()
    print(token_2)
    assert token_1 != token_2


# Generated at 2022-06-23 21:16:13.147921
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    # print(cr.hash())
    # print(cr.hash(Algorithm.MD5))


# Generated at 2022-06-23 21:16:16.852984
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Crypto = Cryptographic()
    print(Crypto.mnemonic_phrase())
    print(Crypto.hash('<Algorithm.MD5>'))
    print(Crypto.uuid())
    print(Crypto.token_bytes())
    print(Crypto.token_hex())
    print(Crypto.token_urlsafe())

# Generated at 2022-06-23 21:16:21.411332
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash1 = Cryptographic().hash(Algorithm.MD5)
    assert type(hash1) == str
    assert len(hash1) == 32


# Generated at 2022-06-23 21:16:23.099556
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  c=Cryptographic()
  print(c.token_hex())


# Generated at 2022-06-23 21:16:26.839140
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Pre-condition
    c = Cryptographic()
    #print(c.mnemonic_phrase(length=16))
    # Test execution
    result = c.mnemonic_phrase(length=16)
    # Assertion
    token = result
    assert token


# Generated at 2022-06-23 21:16:27.881751
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 43

# Generated at 2022-06-23 21:16:32.387092
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cr = Cryptographic()
    for x in range(100):
        res = cr.token_urlsafe(64)
        assert len(res) == 88
        assert not any([c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in res])


# Generated at 2022-06-23 21:16:35.231240
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    x = c.token_hex()
    assert isinstance(x, str)
    assert len(x) == 64


# Generated at 2022-06-23 21:16:43.489389
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase() == 'minor abandon korean strong sense impact attack siren rotate'
    assert crypto.mnemonic_phrase(length=5) == 'art exhaust denial cool funny'
    assert crypto.mnemonic_phrase(separator=',') == 'energetic junk,alive argue,doubtful park,truly wrong,tidy korean,prompt damage,cabbage hill'
    assert crypto.mnemonic_phrase(length=3, separator=' ') == 'copy order carpet'
    assert crypto.mnemonic_phrase(23) == 'powerful focus true scatter genuine drill frequent uphold obvious weird chase argue narrow rescue spin trophy frame'
    assert crypto.mnemonic_phrase(13) == 'oppose guide fade cool race noble siren phone solid increase'


# Generated at 2022-06-23 21:16:46.624269
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""

    crypto = Cryptographic()
    assert crypto.token_urlsafe()


# Generated at 2022-06-23 21:16:47.886896
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print (Cryptographic().hash())


# Generated at 2022-06-23 21:16:50.745592
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    h = c.hash()
    assert isinstance(h, str)
    assert len(h) == 40

# Generated at 2022-06-23 21:16:53.990360
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """unit test for Cryptographic.token_hex() method"""
    token_hex = Cryptographic().token_hex()
    assert len(token_hex) %2 == 0

# Generated at 2022-06-23 21:16:57.450006
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert len(Cryptographic().mnemonic_phrase()) >= 12
    assert len(Cryptographic().mnemonic_phrase(6)) >= 6
    assert len(Cryptographic().mnemonic_phrase(6, '_')) >= 6
    assert len(Cryptographic().mnemonic_phrase(6, ' ')) >= 6

# Generated at 2022-06-23 21:16:58.943505
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    assert isinstance(cr.hash(Algorithm.MD5), str)


# Generated at 2022-06-23 21:17:00.939598
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test unit for method uuid of class Cryptographic"""
    assert(Cryptographic.uuid().__class__ == 'str')


# Generated at 2022-06-23 21:17:07.809886
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=1)
    print(c.mnemonic_phrase(length=12, separator=None))
    print("your 'mnemonic phrase' is ")
    print(c.mnemonic_phrase(length=12, separator='-'))
    print("your 'mnemonic phrase' is ")
    print(c.mnemonic_phrase(length=12, separator='.'))
    print("your 'mnemonic phrase' is ")
    print(c.mnemonic_phrase(length=12, separator='/'))
    print("your 'mnemonic phrase' is ")
    print(c.mnemonic_phrase(length=12, separator='_'))
    #your 'mnemonic phrase' is 
    #your 'mnemonic phrase' is 
    #your 'mnemonic phrase' is 
   

# Generated at 2022-06-23 21:17:12.422274
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test that method Cryptographic.uuid returns valid UUID."""
    cr = Cryptographic()
    assert isinstance(cr.uuid(), str)
    assert isinstance(cr.uuid(as_object=True), UUID)



# Generated at 2022-06-23 21:17:15.377801
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypt = Cryptographic()
    result = crypt.token_bytes()
    assert isinstance(result, bytes)
    assert len(result) == 32


# Generated at 2022-06-23 21:17:19.265466
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test Cryptographic with defined seed value."""
    seed = 1234
    crypto = Cryptographic(seed)
    uuid = "18b9e45b-f11c-4d3e-b0d8-36d3864d0ac6"
    hashv = "b5ec31c5d5a5c36127bfa8e8fc4dff4a197d5ce5e8e5b31e06cbe99d354e4b20"

    assert crypto.uuid(as_object=False) == uuid
    assert crypto.hash() == hashv

# Generated at 2022-06-23 21:17:22.631183
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  try:
    mimesis.Cryptographic.token_hex()
  except:
    assert False, "Could not generate token_hex"


# Generated at 2022-06-23 21:17:26.651956
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    algorithm = Algorithm.SHA256
    result = provider.hash(algorithm=algorithm)
    assert result[0] == '0' and result[1] == 'e' and result[2] == '9' \
        and result[3] == 'e'


# Generated at 2022-06-23 21:17:31.414336
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # GIVEN
    provider = Cryptographic(seed=42)
    
    # WHEN
    actual = provider.uuid(as_object=True)
    
    # THEN
    expected = UUID('4de1b8ff-d4c4-4a92-b1cb-f64bd6630aac')
    assert actual == expected
    
    

# Generated at 2022-06-23 21:17:34.386277
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr1 = Cryptographic()
    mnemonic_phrase = cr1.mnemonic_phrase()
    print(mnemonic_phrase)
    print("\n\n")


# Generated at 2022-06-23 21:17:37.034025
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    crypto1 = Cryptographic()
    crypto2 = Cryptographic()
    assert crypto1.uuid() == crypto2.uuid()

# Generated at 2022-06-23 21:17:39.658456
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test for the method mnemonic_phrase."""
    expected = 'grasshopper square separate stereo'
    phrase = Cryptographic().mnemonic_phrase()
    assert phrase == expected

# Generated at 2022-06-23 21:17:49.401544
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase."""
    result = Cryptographic().mnemonic_phrase()

    first_result = result
    assert first_result != None
    assert isinstance(first_result, str)
    assert len(first_result.split()) == 12

    second_result = Cryptographic().mnemonic_phrase(8)
    assert second_result != first_result
    assert second_result != None
    assert isinstance(second_result, str)
    assert len(second_result.split()) == 8

    third_result = Cryptographic().mnemonic_phrase(length=10, separator='-')
    assert third_result != first_result
    assert third_result != second_result
    assert third_result != None
    assert isinstance(third_result, str)

# Generated at 2022-06-23 21:17:51.873759
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() == 'bb7f1e47-cf77-4fbe-bb22-e265dddf5a5a'


# Generated at 2022-06-23 21:18:00.478779
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    _c = Cryptographic()
    _uuid_as_object = _c.uuid(as_object=True)
    _uuid_as_string = _c.uuid(as_object=False)
    assert isinstance(_uuid_as_object, UUID)
    assert isinstance(_uuid_as_string, str)
    assert len(_uuid_as_string) == 36
    assert len(_uuid_as_object.hex) == 32


# Generated at 2022-06-23 21:18:03.605696
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert isinstance(Cryptographic().token_bytes(), bytes)



# Generated at 2022-06-23 21:18:09.315981
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for Cryptographic class"""
    data = Cryptographic(seed=42)
    assert len(data.hash()) == 64
    assert len(data.hash(Algorithm.SHA3_224)) == 56
    assert len(data.hash(Algorithm.SHA3_256)) == 64
    assert len(data.hash(Algorithm.SHA3_384)) == 96
    assert len(data.hash(Algorithm.SHA3_512)) == 128

# Generated at 2022-06-23 21:18:11.363318
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.providers.cryptographic import Cryptographic
    assert len(Cryptographic().token_hex(5)) == 10


# Generated at 2022-06-23 21:18:15.427408
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Create instance of class Cryptographic and call method token_hex."""
    expected = '3d3f240c42cefcd104c26c502f6665b1a7075ef8bb3768a5faa06eee532b8c8f'
    assert Cryptographic().token_hex() == expected


# Generated at 2022-06-23 21:18:26.802687
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    '''
    Unit test for method mnemonic_phrase of class Cryptographic`
    '''
    provider = Cryptographic()

    # Test Case #1
    phrase1 = provider.mnemonic_phrase()
    assert (isinstance(phrase1, str))

    # Test Case #2
    phrase2 = provider.mnemonic_phrase(length=10)
    assert (isinstance(phrase2, str))

    # Test Case #3
    phrase3 = provider.mnemonic_phrase(length=10, separator = '|')
    assert (isinstance(phrase3, str))

    # Test Case #4
    phrase4 = provider.mnemonic_phrase(length=10, separator = ' ')
    assert (isinstance(phrase4, str))

    # Test Case #5

# Generated at 2022-06-23 21:18:31.978064
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic(seed=1)

    expected = provider.hash(Algorithm.MD5)
    result = 'f634aeb6c17e6bbf16c803a8e481f0a8'
    assert expected == result



# Generated at 2022-06-23 21:18:34.634930
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    instance = Cryptographic()
    result = instance.token_bytes()
    assert isinstance(result, bytes)


# Generated at 2022-06-23 21:18:39.490576
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm
    # When we create an object of Cryptographic 
    # If there is no seed, the system will be using a constant value as the seed value
    # So the results are always the same
    # In this case, the results will be '1cb41b8a9c5a5d82c811b759ee2de54c'
    crypto = Cryptographic()
    print(crypto.token_hex())

# Generated at 2022-06-23 21:18:41.394449
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    res = cr.mnemonic_phrase()
    assert len(res.split(' ')) == 12
    pass

test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:18:44.672539
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    token = c.token_urlsafe()
    assert type(token) is str
    assert len(token) > 0
    assert token.count('/') == 1
    assert token.count('_') == 1


# Generated at 2022-06-23 21:18:47.174976
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid = Cryptographic().uuid()
    assert isinstance(uuid, UUID) or isinstance(uuid, str)


# Generated at 2022-06-23 21:18:50.289100
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    token = crypto.token_urlsafe()
    assert token == '0RVxjmspUk1AcZO_fZM4QQ'

# Generated at 2022-06-23 21:18:53.845036
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    t=Cryptographic()
    test = t.token_bytes(32)
    s = str(test)
    s = s[2:-1]
    print(s)


# Generated at 2022-06-23 21:18:56.153351
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    for _ in range(10):
        r = provider.mnemonic_phrase()
        assert isinstance(r, str)
        assert len(r) > 0
        

# Generated at 2022-06-23 21:19:03.060745
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    # Generating a UUID
    print(c.uuid())
    # Generating a hash with default algorithm
    print(c.hash())
    # Generating a hash with MD5 algorithm
    print(c.hash(Algorithm.MD5))
    # Generating random bytes
    print(c.token_bytes())
    # Generating random text string in hexadecimal
    print(c.token_hex())
    # Generating random URL-safe token
    print(c.token_urlsafe())
    # Generating pseudo mnemonic phrase
    print(c.mnemonic_phrase())

if __name__ == '__main__':
    test_Cryptographic()