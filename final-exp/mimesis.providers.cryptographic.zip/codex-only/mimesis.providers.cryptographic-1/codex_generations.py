

# Generated at 2022-06-23 21:09:04.263501
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    uuid = c.uuid()
    assert uuid == '4b4f83c6-08e9-4c28-94ea-17eb7b2670d6'

# Generated at 2022-06-23 21:09:05.467829
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe(1) is not ""

# Generated at 2022-06-23 21:09:12.412777
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.useragent import UserAgent
    from mimesis.providers.website import Website

    crypto = Cryptographic()
    person = Person('en')
    address = Address('en')
    website = Website('en')
    ua = UserAgent()
    mnemonic_phrase = crypto.mnemonic_phrase().lower()
    assert mnemonic_phrase != None
    assert mnemonic_phrase != ''
    array_phrase = mnemonic_phrase.split(' ')
    array_phrase_12 = array_phrase
    # select 1
    array_phrase_12.append(person.password())
    # select 2
    array_phrase_12

# Generated at 2022-06-23 21:09:15.129833
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    words = crypto.mnemonic_phrase(12)
    print(words)

# Generated at 2022-06-23 21:09:17.310366
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid = ""
    for i in range(100):
        uuid = Cryptographic().uuid()
        assert isinstance(uuid,str)

# Generated at 2022-06-23 21:09:20.004977
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe(): # noqa: D102
    provider = Cryptographic()
    token = provider.token_urlsafe(8)
    assert len(token) == 8

# Generated at 2022-06-23 21:09:20.970393
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print(Cryptographic().uuid())

# Generated at 2022-06-23 21:09:25.079559
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    provider.seed(11)
    result = provider.token_urlsafe()
    assert result == "Rw0dCvWWjkOoN_p0q0Nb9X3qCAS7ygt5nxF5wcM5vqQ"


# Generated at 2022-06-23 21:09:28.887297
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert c.token_bytes() == c.token_bytes()
    assert c.token_bytes(4) == c.token_bytes(4)


# Generated at 2022-06-23 21:09:38.975776
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    print('---')
    print('--- test_Cryptographic_mnemonic_phrase ---')
    print('---')

    phrase = provider.mnemonic_phrase()
    print('phrase: ' + str(phrase))
    print('length: ' + str(len(phrase.split())))

    word = provider.random.choice(phrase.split())
    print('word (' + str(word) + ') in phrase (' + str(phrase) + '): ' + str(word in phrase))

    word = provider.random.choice(provider.__words['normal'])
    print('word (' + str(word) + ') in phrase (' + str(phrase) + '): ' + str(word in phrase))


if __name__=='__main__':
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:09:44.150088
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic(seed=0)

    assert c.uuid() == 'a1ef6c43-d1b1-4c99-a0a6-849ad3c3dd9d'
    assert c.uuid(True) == UUID('a1ef6c43-d1b1-4c99-a0a6-849ad3c3dd9d')

    c = Cryptographic(seed=1)

    assert c.uuid() == 'f06912d9-b0f1-42bd-91a5-5c090f5fe572'
    assert c.uuid(True) == UUID('f06912d9-b0f1-42bd-91a5-5c090f5fe572')



# Generated at 2022-06-23 21:09:44.581272
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    pass

# Generated at 2022-06-23 21:09:45.704061
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    if Cryptographic().token_urlsafe():
        return True
    else:
        return False


# Generated at 2022-06-23 21:09:47.571341
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    for i in range(10):
        print(Cryptographic().mnemonic_phrase())


# Generated at 2022-06-23 21:09:49.422768
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert c.token_bytes() == c.token_bytes()


# Generated at 2022-06-23 21:09:52.058263
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic('en')
    token = provider.token_bytes(32)
    assert type(token) == bytes


# Generated at 2022-06-23 21:09:54.899589
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 44
    assert len(Cryptographic().token_urlsafe(16)) == 24
    assert len(Cryptographic().token_urlsafe(32)) == 44

# Generated at 2022-06-23 21:10:02.653128
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    assert Cryptographic().hash(algorithm=Algorithm.SHA1) == '9bc7bc5b785823d837a832fefba7c47b6c3d8e1b'
    assert Cryptographic().hash(algorithm=Algorithm.SHA224) == '07f6462d0f2bde8b9fa1cd7e9d6c1bf8ff8d2ed38870a7b45c9b9f83'
    assert Cryptographic().hash(algorithm=Algorithm.SHA256) == '2bffa45678d8614b0a52be9a9894c7b573b27cd697f8ccd25a1413cd3b97c25d'

# Generated at 2022-06-23 21:10:04.938695
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp = Cryptographic.mnemonic_phrase(length=1,separator=None)
    print(cp)

# Generated at 2022-06-23 21:10:07.023702
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    t = Cryptographic()
    result = t.token_bytes()
    print(result)


# Generated at 2022-06-23 21:10:10.834276
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for method token_bytes of class Cryptographic"""
    try:
        crypto = Cryptographic()
        crypto.token_bytes(32)
        print("Success")
    except Exception as ex:
        print("Fail")
        print("Error:", ex)


# Generated at 2022-06-23 21:10:13.540832
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # create object
    cp = Cryptographic()
    # call function
    uuid = cp.uuid()
    # print
    print(uuid)
    # execute assert
    assert uuid is not None


# Generated at 2022-06-23 21:10:18.194934
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token1 = Cryptographic.token_urlsafe(30)
    assert len(token1) > 0 and len(token1) <= 45

    token2 = Cryptographic.token_urlsafe(30)
    assert len(token2) > 0 and len(token2) <= 45

    assert token1 != token2

# Generated at 2022-06-23 21:10:21.728826
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    obj = {}
    obj['mnemonic_phrase'] = Cryptographic().mnemonic_phrase()
    return obj


# Generated at 2022-06-23 21:10:23.068651
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic().seed == None

# Generated at 2022-06-23 21:10:29.037720
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c1 = Cryptographic()
    c2 = Cryptographic()
    c3 = Cryptographic()

    c1_token = c1.token_urlsafe(10)
    c2_token = c2.token_urlsafe(20)
    c3_token = c3.token_urlsafe(30)

    print(c1_token)
    print(c2_token)
    print(c3_token)


# Generated at 2022-06-23 21:10:32.178858
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    assert '9da70a06a35a962a8b95f3f2865d73cf' == Cryptographic('en').hash(Algorithm.MD5)

# Generated at 2022-06-23 21:10:38.518873
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    seed = 42
    expected = b'\xb1\x1f\xdd\xe2\xd9\xa9\xc1\x8e\xa11\x90\xed\xe9\x8c\xac\xd6\xc1\x88\x02\x01\xa5\xbd\x88\xaf\xe4\x1f\x9e\xf3\x11\xbd\x17\r'
    provider = Cryptographic(seed)
    result = provider.token_bytes(32)
    assert result == expected

# Generated at 2022-06-23 21:10:39.350862
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c

# Generated at 2022-06-23 21:10:42.288270
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    token = provider.token_bytes()
    assert token
    assert len(token) == 32
    assert isinstance(token, bytes)


# Generated at 2022-06-23 21:10:44.351903
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
  assert Cryptographic().token_hex() == 'f325094015f4328b1dac86f19ac58f9c'


# Generated at 2022-06-23 21:10:50.589158
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Unit test for method mnemonic_phrase of class Cryptographic."""
    provider = Cryptographic()

# Generated at 2022-06-23 21:10:53.610302
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    assert(Cryptographic().hash() == Cryptographic().hash(Algorithm.MD5))
    assert(Cryptographic().hash() != Cryptographic().hash(Algorithm.SHA1))

# Generated at 2022-06-23 21:10:58.059594
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Check default implementation
    cr = Cryptographic()
    result = cr.hash()
    print(result)
    assert re.match(r'^([a-z0-9])+$', result)
    # Check SHA-512
    result = cr.hash(Algorithm.SHA512)
    print(result)
    assert re.match(r'^([a-z0-9])+$', result)


# Generated at 2022-06-23 21:11:02.271163
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes(): # noqa: E301
    crypt = Cryptographic() # noqa: E301
    token = crypt.token_bytes() # noqa: E301
    assert isinstance(token, bytes) # noqa: E501
    assert len(token) == 32 # noqa: E501

# Generated at 2022-06-23 21:11:09.425892
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic("123456")
    print("\nUnique ID:", c.uuid(), "\n")
    print("Hash:", c.hash(Algorithm.SHA_1), "\n")
    print("Token Bytes:", c.token_bytes(), "\n")
    print("Hexadecimal:", c.token_hex(), "\n")
    print("URL Safe Token:", c.token_urlsafe(), "\n")
    print("Mnemonic Phrase:", c.mnemonic_phrase(), "\n")

if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:11:10.951223
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    first = Cryptographic.token_hex(32)
    second = Cryptographic.token_hex(32)
    assert first != second

# Generated at 2022-06-23 21:11:18.949659
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    provider = Cryptographic()
    assert isinstance(provider.hash(algorithm=Algorithm.MD5), str)
    assert provider.hash(algorithm=Algorithm.MD5) == 'a3b8c7491884f1b96d430ee00ab17b06'
    assert provider.hash(algorithm=Algorithm.ITERATOR) is None
    assert isinstance(provider.token_bytes(), bytes)
    assert provider.token_bytes(entropy=17) == b'\x17\xee\xcc`\x15\xfb\xa6\xfc\xa0\xd7\x01\xf5\x0e\xaf\x96\xbf\xec1'
    assert isinstance(provider.token_hex(), str)


# Generated at 2022-06-23 21:11:22.101063
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    try:
        c.token_urlsafe()
    except:
        c.token_urlsafe()
        print("Test pass")


# Generated at 2022-06-23 21:11:27.208541
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.uuid() is not None
    assert crypto.uuid(as_object=True) is not None
    assert crypto.hash() is not None
    assert crypto.token_bytes() is not None
    assert crypto.token_hex() is not None
    assert crypto.token_urlsafe() is not None
    assert crypto.mnemonic_phrase() is not None

# Generated at 2022-06-23 21:11:30.019911
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Arrange - Act
    result = Cryptographic().uuid(as_object=True)
    # Assert
    assert isinstance(result, UUID)
    assert result.int is not None


# Generated at 2022-06-23 21:11:30.571819
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()

# Generated at 2022-06-23 21:11:32.597647
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() == \
        '54eb0711-1ee3-45f6-8b6c-e6f18ae6f71b'


# Generated at 2022-06-23 21:11:37.563588
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    print(c.hash(Algorithm.SHA1))
    print(c.hash(Algorithm.SHA224))
    print(c.hash(Algorithm.SHA256))
    print(c.hash(Algorithm.SHA384))
    print(c.hash(Algorithm.SHA512))
    print(c.hash(Algorithm.MD5))

# Generated at 2022-06-23 21:11:39.104940
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    bytes = Cryptographic.token_bytes()
    assert len(bytes) == 32


# Generated at 2022-06-23 21:11:41.193491
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert isinstance(crypto.uuid(), str)


# Generated at 2022-06-23 21:11:49.234415
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA1) != c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA512) != c.hash(Algorithm.SHA512)


# Generated at 2022-06-23 21:11:50.329017
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    Cryptographic()

# Generated at 2022-06-23 21:11:57.860632
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from random import shuffle
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.enums import Gender

    crypto = Cryptographic(Gender.FEMALE)
    assert crypto.hash()
    assert crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA512)
    assert crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA224)
    assert crypto.hash(Algorithm.SHA384)
    assert crypto.hash(Algorithm.MD5)

    assert crypto.uuid()
    assert crypto.uuid(True)

    assert crypto.token_hex()
    assert len(crypto.token_hex()) == 64
    assert crypto.token_urlsafe()
    assert len

# Generated at 2022-06-23 21:11:59.113602
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    _ = Cryptographic()
    assert _.mnemonic_phrase()



# Generated at 2022-06-23 21:12:01.346883
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print("\nstart test_Cryptographic_token_urlsafe")
    c = Cryptographic()
    print(c.token_urlsafe(32))

# Generated at 2022-06-23 21:12:02.514494
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    result = Cryptographic.token_hex()
    assert len(result) == 64
    assert isinstance(result, str)

# Generated at 2022-06-23 21:12:09.514392
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test generation of URL-safe tokens in base64 encoding from class Cryptographic."""
    crypto = Cryptographic()
    token = crypto.token_urlsafe()
    assert(token is not None)
    assert(isinstance(token, str))
    assert(token.isalnum())
    assert(token.count('/') == 1)
    assert(token.count('_') == 1)
    assert(token.count('-') == 0)


# Generated at 2022-06-23 21:12:10.400209
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data = Cryptographic().hash(Algorithm.MD5)
    print(data)


# Generated at 2022-06-23 21:12:11.528941
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # test for isinstance
    result = Cryptographic.token_hex(1)
    assert isinstance(result, str)

# Generated at 2022-06-23 21:12:12.608351
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic is not None


# Generated at 2022-06-23 21:12:15.052185
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    for i in range(0,5):
        assert isinstance(c.mnemonic_phrase(), str)

# test pseudo_random method

# Generated at 2022-06-23 21:12:19.075256
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test for Cryptographic"""
    crypto = Cryptographic()
    assert isinstance(crypto, BaseProvider)
    assert crypto.hash() != ""
    assert crypto.token_bytes() != b''
    assert crypto.token_hex() != ""
    assert crypto.token_urlsafe() != ""
    assert crypto.mnemonic_phrase() != ""

# Generated at 2022-06-23 21:12:21.174520
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cp = Cryptographic()
    token = cp.token_urlsafe(20)
    print(token)


# Generated at 2022-06-23 21:12:23.250987
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():     
    a = Cryptographic.mnemonic_phrase()
    print(a)
    assert a is not None


# Generated at 2022-06-23 21:12:23.607557
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    pass

# Generated at 2022-06-23 21:12:33.308256
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from unittest import TestCase

    class CryptographicTestCase(TestCase):

        def setUp(self) -> None:
            self.crypto = Cryptographic()

        def test_hash(self):
            result = self.crypto.hash()
            self.assertIsInstance(result, str)

            result = self.crypto.hash(Algorithm.MD5)
            self.assertIsInstance(result, str)

            result = self.crypto.hash(Algorithm.SHA1)
            self.assertIsInstance(result, str)

            result = self.crypto.hash(Algorithm.SHA256)
            self.assertIsInstance(result, str)


# Generated at 2022-06-23 21:12:41.476932
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.enums import Algorithm

    c = Cryptographic()
    uuid4 = c.uuid()
    assert isinstance(uuid4, str)

    alg = Algorithm
    hash1 = c.hash(alg.SHA256)
    assert isinstance(hash1, str)

    hash2 = c.hash(alg.MURMUR3_128)
    assert isinstance(hash2, str)

    hash3 = c.hash(alg.MD5)
    assert isinstance(hash3, str)

    hash4 = c.hash(alg.WHIRLPOOL)
    assert isinstance(hash4, str)

    token1 = c.token_bytes()
    assert isinstance(token1, bytes)

    token2 = c.token_hex()

# Generated at 2022-06-23 21:12:44.277988
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token = crypto.token_bytes(entropy=32)
    print(type(token))
    
    

# Generated at 2022-06-23 21:12:47.141011
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == '1cdb06c2-53a2-471c-b2bf-33d6bc5bc8e5'



# Generated at 2022-06-23 21:12:51.830431
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    t0 = crypto.token_urlsafe()
    t1 = crypto.token_urlsafe()
    assert(len(t0)==44)
    assert(len(t1)==44)
    assert(t0 != t1)

if __name__ == '__main__':
    test_Cryptographic_token_urlsafe()

# Generated at 2022-06-23 21:12:57.789194
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    print(c.hash(Algorithm.SHA256))
    print(c.hash(Algorithm.SHA1))
    print(c.hash(Algorithm.MD5))
    print(c.hash(Algorithm.SHA512))
    print(c.hash(Algorithm.SHA3_256))
    print(c.hash(Algorithm.SHA3_512))
    # print(c.hash(Algorithm.BLAKE2S))
    # print(c.hash(Algorithm.BLAKE2B))
    print(c.hash(Algorithm.SHAKE_128))
    print(c.hash(Algorithm.SHAKE_256))

# Generated at 2022-06-23 21:13:00.806397
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """
    Test for method token_bytes of class Cryptographic
    """

    crypto = Cryptographic()
    assert isinstance(crypto.token_bytes(), bytes)


# Generated at 2022-06-23 21:13:04.300243
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():

    crypt_provider = Cryptographic()

    bytes_string_len = 32
    random_bytes = crypt_provider.token_bytes(entropy=bytes_string_len)

    assert len(random_bytes) == bytes_string_len


# Generated at 2022-06-23 21:13:12.580234
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Seed test
    c1 = Cryptographic(seed=23)
    c2 = Cryptographic(seed=23)
    assert c1.uuid(as_object=True) == c2.uuid(as_object=True)

    # Test as_object parameter of method uuid
    c = Cryptographic(seed=23)
    uuid_obj = c.uuid(as_object=True)
    assert isinstance(uuid_obj, UUID)
    assert str(uuid_obj) == c.uuid()



# Generated at 2022-06-23 21:13:15.952080
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():  # noqa: N802
    """Test for method token_hex of class Cryptographic."""
    token_hex = Cryptographic.token_hex() # noqa: N806
    print(token_hex)
    print(f'len: {len(token_hex)}')
    #assert len(token_hex) == 64

# Generated at 2022-06-23 21:13:17.689074
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("Cryptographic.hash\n", Cryptographic().hash())


# Generated at 2022-06-23 21:13:18.759269
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    cg = Cryptographic()
    cg.token_bytes()


# Generated at 2022-06-23 21:13:20.018642
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash() != Cryptographic.hash()


# Generated at 2022-06-23 21:13:24.185817
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    for i in range(10):
        assert len(Cryptographic().mnemonic_phrase().split(' ')) == 12
        assert len(Cryptographic().mnemonic_phrase(length=6).split(' ')) == 6
        assert len(Cryptographic().mnemonic_phrase(length=6, separator='-').split('-')) == 6
        assert len(Cryptographic().mnemonic_phrase(separator='-').split('-')) == 12
        assert len(Cryptographic().mnemonic_phrase(length=6, separator='')) == 30

# Generated at 2022-06-23 21:13:27.026261
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """test for method hash of class Cryptographic."""
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-23 21:13:36.944165
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.uuid() is not None
    assert crypto.uuid(True) is not None
    assert crypto.uuid(as_object=True) is not None
    assert crypto.hash() is not None
    assert crypto.hash(Algorithm.SHA256) is not None
    assert crypto.token_bytes() is not None
    assert crypto.token_hex() is not None
    assert crypto.token_urlsafe() is not None
    assert crypto.mnemonic_phrase() is not None
    assert crypto.mnemonic_phrase(length=12) is not None
    assert crypto.mnemonic_phrase(separator='_') is not None
    assert crypto.mnemonic_phrase(length=12, separator='_') is not None


# Generated at 2022-06-23 21:13:44.036727
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj = Cryptographic()
    assert len(obj.token_bytes()) == 32
    assert obj.token_bytes(64) == b'D\xcf\xd9\x84\xbc\xda\xbc\x11\xb6\xb4O\x12\x9e\x9c\x1d\x03\x8d\x0e\xc2\x81\x85\x0c\xb9\x95\xa5\x03\xf5\xdb\x98\xf3\xcc\x18@\xe6'


# Generated at 2022-06-23 21:13:46.552553
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	'''
	Test method hash of class Cryptographic
	'''

	assert hasattr(Cryptographic, "hash")
	assert isinstance(Cryptographic().hash(), str)


# Generated at 2022-06-23 21:13:49.596045
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test token_urlsafe method of class Cryptographic."""
    provider = Cryptographic(random_generator=None)
    result = provider.token_urlsafe()
    assert result
    assert isinstance(result, str)



# Generated at 2022-06-23 21:13:55.382803
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Crypto
    crypto = Cryptographic()
    print(crypto.uuid())
    print(crypto.uuid(as_object=True))
    print(crypto.hash())
    print(crypto.hash(algorithm=Algorithm.MD5))
    print(crypto.token_bytes())
    print(crypto.token_hex())
    print(crypto.token_urlsafe())
    print(crypto.mnemonic_phrase())
    print(crypto.mnemonic_phrase(length=15))
    print(crypto.mnemonic_phrase(length=15, separator="-"))


# Generated at 2022-06-23 21:13:57.107775
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid()) == 36



# Generated at 2022-06-23 21:13:59.493737
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic(seed=777)
    assert c.hash() == 'd5b081f8cb9cd9c76d088814ef0b0e8f'
    assert isinstance(c.hash(), str)


# Generated at 2022-06-23 21:14:01.160102
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    output = Cryptographic().token_bytes()
    assert output is not None

# Generated at 2022-06-23 21:14:03.837009
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert crypto.uuid() is not None


# Generated at 2022-06-23 21:14:10.630848
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """ Test function for method uuid of class Cryptographic."""
    # We create the object crypto, instance of the class Cryptographic
    crypto = Cryptographic()
    # Create the list to save the UUID objects
    listAux = []
    # Create the list 1000 times, each time we call the function uuid,and save the new UUIDs in the list
    for i in range(1000):
        listAux.append(crypto.uuid())
    # Save the first UUID object created
    aux = listAux[0]
    # We compare the first UUID with all the UUIDs created
    for i in listAux:
        # If the comparison between the first UUID and the current UUID is not equal, the test fails
        assert aux == i


# Generated at 2022-06-23 21:14:12.253544
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-23 21:14:15.169514
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'f9d9ea2c1e8e7994a4bbd83d1f3b3f8b'


# Generated at 2022-06-23 21:14:16.684421
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    print(a.mnemonic_phrase())

# Generated at 2022-06-23 21:14:19.910279
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    obj = Cryptographic()
    assert len(obj.token_hex()) == 64
    assert len(obj.token_hex(entropy=16)) == 32
    assert len(obj.token_hex(entropy=20)) == 40

# Generated at 2022-06-23 21:14:29.436160
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    c = Cryptographic()
    num = c.token_urlsafe(32)
    assert isinstance(num, str)
    assert len(num) == 43

    # Test for min entropy
    num = c.token_urlsafe(10)
    assert isinstance(num, str)
    assert len(num) == 22

    # Test for max entropy
    num = c.token_urlsafe(86)
    assert isinstance(num, str)
    assert len(num) == 119

    # Test for hash
    num = c.hash(Algorithm.SHA1)
    assert isinstance(num, str)
    assert len(num) == 40

    # Test for hash

# Generated at 2022-06-23 21:14:37.934141
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    test = Cryptographic()
    # Sample results:
    # e67d622d-26f8-49fc-a2e2-b3f6a3a6fb3e
    # ef89ef03-c816-4351-b7d9-98f64e936010
    # a7e7c404-bc1c-4790-8dc2-a264a4f4f9ee
    results = [
        test.uuid()
        for _ in range(3)
    ]
    assert all([
        isinstance(result, str)
        for result in results
    ])

    # Sample results:
    # UUID('4d4e4155-4a94-4c7d-a98a-84c846ecef1c')
    # UUID('399

# Generated at 2022-06-23 21:14:39.563522
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 32
    assert len(Cryptographic.token_bytes(33)) == 66


# Generated at 2022-06-23 21:14:45.335279
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cg = Cryptographic()
    print(cg.uuid(as_object=True))
    print(cg.hash(algorithm=Algorithm.SHA_256))
    print(cg.token_bytes(entropy=32))
    print(cg.token_hex(entropy=32))
    print(cg.token_urlsafe(entropy=32))
    print(cg.mnemonic_phrase(length=12, separator=None))

# Generated at 2022-06-23 21:14:48.435390
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic.token_urlsafe()) == 43
    for _ in range(10):
        assert len(Cryptographic.token_urlsafe(50)) == 86

if __name__ == "__main__":
    test_Cryptographic_token_urlsafe()

# Generated at 2022-06-23 21:14:56.202580
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test :class:`~mimesis.providers.cryptographic.Cryptographic`.

    :return: None
    """
    crypto = Cryptographic()
    hash_ = crypto.hash()
    assert len(hash_) == 64

    words = crypto.mnemonic_phrase()
    assert len(words) >= 12

    token = crypto.token_hex()
    assert len(token) >= 64

    token_urlsafe = crypto.token_urlsafe()
    assert len(token) >= 64

    assert crypto.uuid()  # noqa: WPS421
    assert crypto.uuid(as_object=True)  # noqa: WPS421

# Generated at 2022-06-23 21:15:04.171576
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    
    """Test for Cryptographic method mnemonic_phrase."""
    crypto = Cryptographic(seed=123)
    phrase = crypto.mnemonic_phrase()
    assert phrase == "bronze statue aside smooth"
    phrase = crypto.mnemonic_phrase(length=11, separator='')
    assert phrase == "bronzestatueasidesmooth"
    phrase = crypto.mnemonic_phrase(length=10, separator=',')
    assert phrase == "bronze,statue,aside,smooth"

# Generated at 2022-06-23 21:15:07.454138
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    my_obj = Cryptographic()
    entropy = 32
    token = my_obj.token_bytes(entropy)
    assert len(token) == entropy
    for x in token:
        assert x in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-23 21:15:10.128625
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic"""
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1) == "724b32cda2a7d63f74bfc3037c40e9435c89418a"


# Generated at 2022-06-23 21:15:15.425451
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    seed = "bbbea57985d89e788b76e8a9d4520cf5"
    provider_1 = Cryptographic(seed)
    provider_2 = Cryptographic(seed)

    assert provider_1.token_urlsafe() == provider_2.token_urlsafe()

# Generated at 2022-06-23 21:15:22.628483
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print()
    print("##### Start unit test for method token_urlsafe of class Cryptographic #####")
    print()

    crypto = Cryptographic()

    for _ in range(10):
        print(crypto.token_urlsafe())

    print()
    print("##### End unit test for method token_urlsafe of class Cryptographic #####")
    print()

test_Cryptographic_token_urlsafe()



# Generated at 2022-06-23 21:15:24.796638
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    test_obj = Cryptographic()
    x = test_obj.token_hex()
    if ( isinstance( x, bytes ) ):
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:15:32.866301
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis import Cryptographic
    print("Unit test for Cryptographic.uuid()")
    with open("test_Cryptographic_uuid_result.txt", "w") as f:
        f.write("Unit test for Cryptographic.uuid()\n")
    for i in range(0,10):
        print(str(Cryptographic().uuid()))
        with open("test_Cryptographic_uuid_result.txt", "a") as f:
            f.write(str(Cryptographic().uuid()))
            f.write("\n")
# End of test_Cryptographic_uuid()


# Generated at 2022-06-23 21:15:38.525850
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    tester = Cryptographic()
    token = tester.token_urlsafe()
    assert len(token) == 43
    assert token in "jZP8-LgY5ndMiM0Jwma0R5j5a1Ib9AeAe0HmhZ8QvYg"


# Generated at 2022-06-23 21:15:41.404005
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    hash = cr.hash()
    assert hash is not None
    assert len(hash) == 64


# Generated at 2022-06-23 21:15:45.034195
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test function for class Cryptographic"""
    from mimesis.enums import CryptographicAlgorithm as Algorithm
    c = Cryptographic('en')
    print(c.mnemonic_phrase(12," "))
    print(c.hash(Algorithm.MD5))

# Generated at 2022-06-23 21:15:53.219884
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	assert Cryptographic().hash(Algorithm.SHA224) == 'f5987c3e3f0ffbfe96a0bd1e6927c335790a46f9af4e6d4b1df2c6fbe'
	assert Cryptographic().hash(Algorithm.SHA256) == '9cbb0a1dabcdaefb70fbd8e49ca0779e0a50f0fa12a8fd8a9b2d9fa7c636b1de'

# Generated at 2022-06-23 21:15:56.444444
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert type(Cryptographic().uuid()) == str

    assert str(UUID(Cryptographic().uuid(as_object=True))) == Cryptographic().uuid()


# Generated at 2022-06-23 21:15:59.580368
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initialize the instance
    c = Cryptographic()

    # Execute the method
    s = c.hash()
    # Check result
    assert isinstance(s, str) is True
    assert len(s) == 40


# Generated at 2022-06-23 21:16:01.064275
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(), str)  # type: ignore



# Generated at 2022-06-23 21:16:11.446130
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # 1st test: init mimesis with specific seed
    seed = 1234567890
    crypto_1 = Cryptographic(seed)

    crypto_1.hash()
    crypto_1.mnemonic_phrase()
    crypto_1.token_bytes()
    crypto_1.token_hex()
    crypto_1.token_urlsafe()
    crypto_1.uuid()

    # 2nd test: init mimesis with default seed
    crypto_2 = Cryptographic()

    crypto_2.hash()
    crypto_2.mnemonic_phrase()
    crypto_2.token_bytes()
    crypto_2.token_hex()
    crypto_2.token_urlsafe()
    crypto_2.uuid()

    # 3rd test: init mimesis with random seed

# Generated at 2022-06-23 21:16:13.473506
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    assert c.token_bytes()
    assert len(c.token_bytes()) == 32
    assert len(c.token_bytes(16)) == 32


# Generated at 2022-06-23 21:16:14.697084
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    result = Cryptographic().token_urlsafe(32)
    assert isinstance(result, str)

# Generated at 2022-06-23 21:16:17.824965
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    entropy_count = 8
    result = crypto.token_urlsafe(entropy=entropy_count)
    expected_number_of_bytes = entropy_count * 3/4
    expected_number_of_characters_in_result = expected_number_of_bytes * 2
    assert len(result) == expected_number_of_characters_in_result

# Generated at 2022-06-23 21:16:21.248840
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Arrange
    c = Cryptographic()
    expected = '637bb7bfd4d4b4cf32b4f07a76ddb9bc1bbf86ab521352ea7821b2c6d818a29a'

    # Act
    actual = c.hash(Algorithm.SHA256)

    # Assert
    assert expected == actual


# Generated at 2022-06-23 21:16:24.163486
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    h1 = crypto.hash()
    h2 = crypto.hash()
    assert (len(h1) == len(h2))


# Generated at 2022-06-23 21:16:28.034488
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    result = crypto.mnemonic_phrase()
    assert len(result) > 0


if __name__ == '__main__':
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-23 21:16:31.900628
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Initialize seed value
    seed = 0
    # Initialize object under test
    cut = Cryptographic(seed=seed)
    # Retrieve result with given parameters by calling function
    result = cut.uuid()
    # Expected result
    expect = 'bfd03754-cc0f-4c30-bcc0-e6c8ae6ebef3'
    # Check if result equals expected value
    assert result == expect


# Generated at 2022-06-23 21:16:34.927906
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Test that the mnemonic phrase length is correct
    c = Cryptographic()
    length = 12
    phrase = c.mnemonic_phrase(length)
    assert(len(phrase.split(' ')) == length)


# Generated at 2022-06-23 21:16:39.032442
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.mnemonic_phrase())
    print(c.mnemonic_phrase(5))
    print(c.mnemonic_phrase(10,","))


if __name__ == "__main__":
    test_Cryptographic()

# Generated at 2022-06-23 21:16:40.720197
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cr = Cryptographic()
    assert isinstance(cr.token_urlsafe(), str)


# Generated at 2022-06-23 21:16:48.137037
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print()
    print("**************** test_Cryptographic_mnemonic_phrase() ****************")
    # Create an instanc of class Cryptographic
    crypto = Cryptographic()
    # Generate a pseudo mnemonic phrase
    print(crypto.mnemonic_phrase())
    # Generate a 5 word pseudo mnemonic phrase
    print(crypto.mnemonic_phrase(5))
    print()


# Generated at 2022-06-23 21:16:49.521712
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert Cryptographic().token_urlsafe() is not None



# Generated at 2022-06-23 21:16:53.673426
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    x = Cryptographic.uuid()
    assert isinstance(x,str)
    assert len(x) == len("55ca60c7-83a0-4d4d-8b32-1b4f5b5edc7a")


# Generated at 2022-06-23 21:16:57.257984
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cr = Cryptographic()
    print("UUID: ", Cr.uuid())
    print("Hash: ", Cr.hash())
    print("Token bytes: ", Cr.token_bytes())
    print("Token hex: ", Cr.token_hex())
    print("Token urlsafe: ", Cr.token_urlsafe())
    print("Mnemonic phrase: ", Cr.mnemonic_phrase())

test_Cryptographic()

# Generated at 2022-06-23 21:16:59.363623
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic('en')
    assert True == isinstance(cr.uuid(), str)
    assert True == isinstance(cr.uuid(True), UUID)


# Generated at 2022-06-23 21:17:04.687607
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
	MyTools.run_test(
		Cryptographic.token_bytes,
		b'0\x10\x0e\xcd\x87\n\xf7\xd0k\x9f\xed\x8a\xe0\x1d\x90\xe4\xa2\x97\x9e\xf4\x87\x14\x1f\x03\xe0\x8d\x07@',
		{'entropy': 32}
	)

# Generated at 2022-06-23 21:17:09.036629
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    entropy_options = [16, 24, 32, 48, 64]

    for entropy in entropy_options:
        token = crypto.token_urlsafe(entropy)
        assert len(token) == entropy * 3 / 4

# Generated at 2022-06-23 21:17:10.463355
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic.token_urlsafe()) == 43


# Generated at 2022-06-23 21:17:14.346640
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.uuid()
    assert c.token_bytes()
    assert c.token_hex()
    assert c.hash()
    assert c.mnemonic_phrase()

# Generated at 2022-06-23 21:17:15.189569
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    test = Cryptographic()
    assert isinstance(test, Cryptographic)



# Generated at 2022-06-23 21:17:16.604751
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert len(Cryptographic().uuid(as_object=False)) == 36
    assert isinstance(Cryptographic().uuid(as_object=True), UUID)


# Generated at 2022-06-23 21:17:18.562677
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    token = crypto.token_urlsafe()
    assert isinstance(token, str)

# Generated at 2022-06-23 21:17:23.819497
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Assert that Cryptographic.token_hex() is a crypto-safe method."""

    crypto = Cryptographic()
    token = crypto.token_hex(3)

    assert len(token) == 6
    assert isinstance(token, str)
    assert token == 'c1d36705c8'


# Generated at 2022-06-23 21:17:27.379247
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # data = Cryptographic('en')
    data = Cryptographic('en')
    print(data.mnemonic_phrase())
    print(data.uuid())
    print(data.token_hex())
    print(data.token_bytes())



# Generated at 2022-06-23 21:17:30.055129
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    address = "0xA5aC03D1e0c836A9a105Fb2f6432Df8B8D5417bA"
    expected = "0x" + secrets.token_hex(32).upper()
    assert address == expected


# Generated at 2022-06-23 21:17:34.026972
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    assert crypto.token_urlsafe(entropy=64) == 'eMZmOQ2Dm0Gc9Xbgbxupdp8JpPnfzH63DRlwjFz1J-k'

# Generated at 2022-06-23 21:17:39.080826
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5)
    assert Cryptographic().hash(Algorithm.SHA1)
    assert Cryptographic().hash(Algorithm.SHA224)
    assert Cryptographic().hash(Algorithm.SHA256)
    assert Cryptographic().hash(Algorithm.SHA384)
    assert Cryptographic().hash(Algorithm.SHA512)


# Generated at 2022-06-23 21:17:40.539574
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    token = crypto.token_hex()
    assert token is not None
    assert type(token) == str
    assert len(token) == 64


# Generated at 2022-06-23 21:17:42.895290
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cryt = Cryptographic()
    print(cryt.uuid(as_object=True))

#test_Cryptographic()

# Generated at 2022-06-23 21:17:48.104300
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm
    import uuid
    crypto = Cryptographic()
    # check that the string is a valid UUID
    assert str(uuid.UUID(crypto.uuid(), version=4)) == crypto.uuid()
    # check that the type is UUID
    assert type(crypto.uuid(as_object=True)) == uuid.UUID



# Generated at 2022-06-23 21:17:49.983160
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase of class Cryptographic."""
    assert str is type(Cryptographic.mnemonic_phrase())

# Generated at 2022-06-23 21:17:51.047039
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert len(Cryptographic(seed=0)) == 1

# Generated at 2022-06-23 21:17:52.375527
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    value = Cryptographic().token_bytes()
    assert len(value) == 32

# Generated at 2022-06-23 21:17:58.434533
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    c = Cryptographic(seed=12345)
    assert (c.uuid() ==
            '64e3a418-b8d2-4936-bf6c-e66e9ca8c1fd')


# Generated at 2022-06-23 21:18:03.257013
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert isinstance(Cryptographic(), Cryptographic)
    assert isinstance(Cryptographic(seed=0), Cryptographic)
    assert isinstance(Cryptographic(seed='test'), Cryptographic)

# Unit tests for uuid() method

# Generated at 2022-06-23 21:18:06.563375
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from random import choice
    from string import ascii_uppercase

    def _get_token():
        return Cryptographic._Cryptographic__token_urlsafe()

    for _ in range(250):
        entropy = choice(range(1, 64))
        token = _get_token(entropy)
        assert len(token) == (entropy * 2) + (entropy / 2)



# Generated at 2022-06-23 21:18:10.670875
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # t = Cryptographic()
    # assert t.token_urlsafe() == t.token_urlsafe()
    # assert len(t.token_urlsafe()) == 32
    # assert t.token_urlsafe(10) == t.token_urlsafe(10)
    assert True

# Generated at 2022-06-23 21:18:13.492470
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Test 1
    print(Cryptographic().token_bytes(100))
    # Test 2
    print(Cryptographic().token_bytes())
    # Test 3
    print(Cryptographic().token_bytes(10))


# Generated at 2022-06-23 21:18:15.062162
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert len(crypto.token_bytes()) == 32


# Generated at 2022-06-23 21:18:18.306132
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    c = Cryptographic()
    token = c.token_urlsafe()
    assert (isinstance(token, str))
    print(token)

# Generated at 2022-06-23 21:18:21.279419
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    assert provider.token_bytes(32) == secrets.token_bytes(32)


# Generated at 2022-06-23 21:18:27.528022
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic

    This method checks whether the function returns the correct value of
    a standard UUID4.
    """
    obj = Cryptographic()
    uuid = obj.uuid()

    assert isinstance(uuid, str)
    assert len(uuid) == 36, 'Length of the UUID must be 36'
    assert uuid.count('-') == 4, 'UUID must contain 4 dashes'


# Generated at 2022-06-23 21:18:32.558018
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    result = provider.token_bytes()
    assert type(result) == bytes
    assert len(result) == 32
    result = provider.token_bytes(8)
    assert type(result) == bytes
    assert len(result) == 16


# Generated at 2022-06-23 21:18:35.261245
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert (Cryptographic().mnemonic_phrase(length=32,separator='-'))


# Generated at 2022-06-23 21:18:37.793941
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # No parameters
    c = Cryptographic()
    assert c.token_urlsafe()

    # With entropy
    c = Cryptographic()
    assert c.token_urlsafe(64)


# Generated at 2022-06-23 21:18:42.062074
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Function for unit-testing method token_bytes of class Cryptographic."""
    # Arrange
    entropy = 32
    cls = Cryptographic()

    # Act
    expected = cls.token_bytes(entropy)
    actual = cls.token_bytes(entropy)

    # Assert
    assert expected != actual


# Generated at 2022-06-23 21:18:45.067986
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for the method token_bytes of class Cryptographic."""
    assert isinstance(Cryptographic.token_bytes(), bytes)
    assert len(Cryptographic.token_bytes(entropy = 16)) == 16


# Generated at 2022-06-23 21:18:49.810960
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    assert cr.mnemonic_phrase() == 'true snow coffee section system '
    assert cr.mnemonic_phrase(length=3, separator='-') == 'hospital-demolition-nudge'
    assert cr.mnemonic_phrase(length=1) == 'movie '


# Generated at 2022-06-23 21:18:52.426555
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe(20)
    assert isinstance(token, str) and len(token) == 26


# Generated at 2022-06-23 21:18:53.756572
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == len(Cryptographic().hash())



# Generated at 2022-06-23 21:18:58.104184
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cryp = Cryptographic()
    print(Cryp.uuid())
    print(Cryp.hash())
    print(Cryp.token_bytes())
    print(Cryp.token_hex())
    print(Cryp.token_urlsafe())
    print(Cryp.mnemonic_phrase())

if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-23 21:18:59.692026
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    data_provider = Cryptographic()
    assert len(data_provider.token_hex()) == 64

# Generated at 2022-06-23 21:19:01.847775
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    words = crypto.mnemonic_phrase(length=3)
    assert isinstance(words, str)
    assert len(words.split(' ')) == 3
