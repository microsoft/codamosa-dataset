

# Generated at 2022-06-25 20:29:22.145038
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    str_0 = Cryptographic(seed=123).hash()
    assert str_0 == 'a2f854b7e3f3dcdc1dba2a9a05e34d5a67e5a5f5e8cce7bc13d6fc87b7c88991'

# Generated at 2022-06-25 20:29:24.241121
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    with raises(NonEnumerableError):
        cryptographic_0.hash('md5')


# Generated at 2022-06-25 20:29:26.895558
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.SHA512)


# Generated at 2022-06-25 20:29:29.689180
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    hash_ = cryptographic.hash(algorithm=Algorithm.SHA256)
    assert isinstance(hash_, str)
    assert len(hash_) == 64


# Generated at 2022-06-25 20:29:33.174717
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """ Test method hash of class Cryptographic """
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert len(str_0) == 64


# Generated at 2022-06-25 20:29:35.618955
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash() == '3e3ea0d3e2b8eeed6171d3b3ba0baf2f'

# Generated at 2022-06-25 20:29:37.519383
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    token = Cryptographic().token_hex()
    assert type(token) == str
    assert len(token) == 64


# Generated at 2022-06-25 20:29:39.062047
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert 'A' <= Cryptographic().hash() and Cryptographic().hash() <= 'f'


# Generated at 2022-06-25 20:29:50.515415
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA256) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA384) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA512) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.MD5) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA1) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA3_224) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA3_256) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA3_384) is not None
    assert cryptographic_

# Generated at 2022-06-25 20:29:51.515211
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test cases
    test_case_0()


# Generated at 2022-06-25 20:32:23.888163
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic(seed=0)  # type: Cryptographic
    str_0 = cryptographic_0.hash(algorithm=Algorithm.SHA1)
    assert str_0 == 'b2f3f3a2cbe0cb66475f6c2393bf0912c1cfad7e'
    cryptographic_1 = Cryptographic(seed=1)  # type: Cryptographic
    str_1 = cryptographic_1.hash(algorithm=Algorithm.SHA1)
    assert str_1 == '9b28d68b3e3f4c8b38db4df55c59d18ba4a87972'
    cryptographic_2 = Cryptographic(seed=2)  # type: Cryptographic
    str_2 = cryptographic_2.hash(algorithm=Algorithm.SHA1)
    assert str

# Generated at 2022-06-25 20:32:26.635246
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    val = cryptographic_0.hash(Algorithm.MD5)
    assert isinstance(val, str)



# Generated at 2022-06-25 20:32:29.806174
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 128
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-25 20:32:32.374417
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) in range(4, 130)


# Generated at 2022-06-25 20:32:37.090757
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    Algorithm_0 = cryptographic_0._validate_enum(str, Algorithm)
    str_1 = cryptographic_0.hash(Algorithm_0)


# Generated at 2022-06-25 20:32:39.789280
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    _crypto_0 = Cryptographic().hash()
    _crypto_1 = Cryptographic().hash(Algorithm.SHA3_512)


# Generated at 2022-06-25 20:32:42.306538
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    hash_ = cryptographic.hash()
    assert len(hash_) > 16



# Generated at 2022-06-25 20:32:43.703817
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert cryptographic_0.hash() != None


# Generated at 2022-06-25 20:32:47.909332
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    generated_array = []
    for i in range(10):
        hash_0 = cryptographic.hash()
        assert hash_0 not in generated_array
        generated_array.append(hash_0)


# Generated at 2022-06-25 20:32:54.115925
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()  # MD5
    str_1 = cryptographic_0.hash(Algorithm.MD5)
    str_2 = cryptographic_0.hash(Algorithm.SHA224)
    str_3 = cryptographic_0.hash(Algorithm.SHA1)
    str_4 = cryptographic_0.hash(Algorithm.SHA256)
    str_5 = cryptographic_0.hash(Algorithm.SHA512)
    str_6 = cryptographic_0.hash(Algorithm.SHA384)
    str_7 = cryptographic_0.uuid()
    str_8 = cryptographic_0.uuid(True)
    result = True
    assert result
