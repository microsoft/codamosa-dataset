

# Generated at 2022-06-25 20:30:58.208682
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Declare variables
    cryptographic_0 = Cryptographic()

    # Setup
    algorithm_0 = Algorithm.SHA1.value

    # Exercise
    str_0 = cryptographic_0.hash(algorithm_0)

    # Verify
    assert len(str_0) == 40

    # Cleanup - none necessary


# Generated at 2022-06-25 20:30:59.720836
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    test_case_0()

# Generated at 2022-06-25 20:31:02.411373
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert all([
        0 == len(str_0),
    ])

# Generated at 2022-06-25 20:31:06.767452
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm_0 = None
    str_0 = cryptographic_0.hash(algorithm_0)
    assert str_0


# Generated at 2022-06-25 20:31:12.542656
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    algorithm = None
    assert type(cryptographic.hash(algorithm)) == str
    assert cryptographic.hash(algorithm).isalnum()


# Generated at 2022-06-25 20:31:15.940818
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test the method with 0 arguments.
    """

    cryptographic_0 = Cryptographic()
    algorithm_0 = None
    str_0 = cryptographic_0.hash(algorithm_0)

    print(str_0)

    assert isinstance(str_0, str)



# Generated at 2022-06-25 20:31:21.444384
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm_0 = None
    str_0 = cryptographic_0.hash(algorithm_0)
    assert_equal(len(str_0), 64)


# Generated at 2022-06-25 20:31:26.262443
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    algorithm = None
    assert cryptographic.hash(algorithm) == '7d865e959b2466918c9863afca942d0fb89d7c9ac0c99bafc3749504ded97730'


# Generated at 2022-06-25 20:31:30.552092
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0
    algorithm_0 = Algorithm.SHA1
    str_0 = cryptographic_0.hash(algorithm_0)


# Generated at 2022-06-25 20:31:33.871100
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm_0 = None
    str_0 = cryptographic_0.hash(algorithm_0)


# Generated at 2022-06-25 20:33:47.285674
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.MD5)
    str_1 = cryptographic_0.hash(Algorithm.SHA1)
    str_2 = cryptographic_0.hash(Algorithm.SHA224)
    str_3 = cryptographic_0.hash(Algorithm.SHA256)
    str_4 = cryptographic_0.hash(Algorithm.SHA384)
    str_5 = cryptographic_0.hash(Algorithm.SHA512)
    str_6 = cryptographic_0.hash(Algorithm.BLAKE2B)
    str_7 = cryptographic_0.hash(Algorithm.BLAKE2S)

# Generated at 2022-06-25 20:33:54.460075
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64
    assert Cryptographic().hash() == 'c33b18937d3db3fad16735bb08a6a6dee8db8545bb6f959ddb9e6f451d6c8a6e'


# Generated at 2022-06-25 20:33:55.504945
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    cryptographic.hash()

# Generated at 2022-06-25 20:34:06.536447
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic(seed=1234)
    str_0 = cryptographic_0.hash(Algorithm.SHA512)

# Generated at 2022-06-25 20:34:11.372088
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    # It should be assert equal str_0, str_1
    str_0 = crypto.hash()
    str_1 = crypto.hash()
    assert str_0 == str_1


# Generated at 2022-06-25 20:34:18.179145
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Unit test for method hash of class Cryptographic
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert type(str_0) is str and len(str_0) == 40

    # Unit test for method hash of class Cryptographic
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert type(str_0) is str and len(str_0) == 40

    # Unit test for method hash of class Cryptographic
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(algorithm=Algorithm.MD5)
    assert str(str_0) == 'ed4c1d1f55c22b9f945d0a22868e1e28'

# Generated at 2022-06-25 20:34:19.980654
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert len(cryptographic_0.hash()) >= 10



# Generated at 2022-06-25 20:34:29.008522
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic(seed=12345)
    assert cryptographic_0.hash() == 'd41d8cd98f00b204e9800998ecf8427e'
    assert cryptographic_0.hash() == 'd41d8cd98f00b204e9800998ecf8427e'
    cryptographic_1 = Cryptographic(seed=0)
    assert cryptographic_1.hash() == 'b026324c6904b2a9cb4b88d6d61c81d1'
    assert cryptographic_1.hash() == 'b026324c6904b2a9cb4b88d6d61c81d1'
    cryptographic_2 = Cryptographic(seed=89)

# Generated at 2022-06-25 20:34:36.531830
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("Start " + "test_Cryptographic_hash")

    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.SHA256)
    assert isinstance(str_0, str)
    str_1 = cryptographic_0.hash(Algorithm.SHA512)
    assert isinstance(str_1, str)
    str_2 = cryptographic_0.hash()
    assert isinstance(str_2, str)

    print("End " + "test_Cryptographic_hash")


# Generated at 2022-06-25 20:34:46.097929
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    item_0 = Cryptographic()
    item_25 = item_0.hash(Algorithm.BLAKE2B)
    item_1 = Cryptographic()
    item_26 = item_1.hash(Algorithm.BLAKE2S)
    item_2 = Cryptographic()
    item_27 = item_2.hash(Algorithm.MD5)
    item_3 = Cryptographic()
    item_28 = item_3.hash(Algorithm.SHA1)
    item_4 = Cryptographic()
    item_29 = item_4.hash(Algorithm.SHA224)
    item_5 = Cryptographic()
    item_30 = item_5.hash(Algorithm.SHA256)
    item_6 = Cryptographic()
    item_31 = item_6.hash(Algorithm.SHA384)
    item_7

# Generated at 2022-06-25 20:35:02.518707
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert str_0 == '5c5fd0fd5b8e1d0f86fb882bdac681e7'


# Generated at 2022-06-25 20:35:09.035145
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    str_0 = cryptographic.hash(Algorithm.SHA256)
    assert str_0 == '75f939ad0c47b0f7b00da497953d8e579c1b6ce87f6d9fb0e8beb23c33b30799'


# Generated at 2022-06-25 20:35:17.703444
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash_method = Cryptographic().hash

    algo_list = [
        Algorithm.BLAKE2S, Algorithm.BLAKE2B, Algorithm.MD4,
        Algorithm.MD5, Algorithm.SHA1, Algorithm.SHA224,
        Algorithm.SHA256, Algorithm.SHA384, Algorithm.SHA512,
        Algorithm.SHA3_224, Algorithm.SHA3_256, Algorithm.SHA3_384,
        Algorithm.SHA3_512, Algorithm.BLAKE2S, Algorithm.BLAKE2B,
        Algorithm.SHAKE128, Algorithm.SHAKE256
    ]

    for algo in algo_list:
        out = hash_method(algorithm=algo)
        assert len(out) == 64


# Generated at 2022-06-25 20:35:21.199593
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert len(str_0) == 64


# Generated at 2022-06-25 20:35:23.857141
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert str_0 == 'e15cdb7be13bfa8b9a05a34db1c70bff'


# Generated at 2022-06-25 20:35:29.500279
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    # Method call with default parameters
    str_0 = cryptographic_0.hash()
    assert str_0 != None
    # Method call with not default parameters
    str_0 = cryptographic_0.hash(Algorithm.SHA1)
    assert str_0 != None


# Generated at 2022-06-25 20:35:30.289535
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash("md5")



# Generated at 2022-06-25 20:35:38.580942
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() in [
        'd41d8cd98f00b204e9800998ecf8427e',
        'afb5b5bd5e5fa43da63e22e5ffaec04b',
        '037f1b9edf7f0f93d32bccbf8f21e0b7',
    ]



# Generated at 2022-06-25 20:35:45.232667
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash(Algorithm.MD5) == '22e7bab98b0663c8e9f934c6d020f6cd'
    assert Cryptographic.hash(Algorithm.SHA3_512) == 'c81f5b100c5d5e5df0f89e8caa0a52ee1eabac488ea20a03c9f933dcf37b2a1a6971c7c78045c60d0f0f8b2e2b4c41b958dc4e414728fd01fd4cf6a75d6f774d'

# Generated at 2022-06-25 20:35:47.673199
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic('seed')
    str_1 = cryptographic_1.hash()



# Generated at 2022-06-25 20:36:19.744647
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.MD5)
    str_1 = cryptographic_0.hash(Algorithm.SHA1)
    str_2 = cryptographic_0.hash(Algorithm.SHA224)
    str_3 = cryptographic_0.hash(Algorithm.SHA256)
    str_4 = cryptographic_0.hash(Algorithm.SHA384)
    str_5 = cryptographic_0.hash(Algorithm.SHA512)


# Generated at 2022-06-25 20:36:24.461136
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert isinstance(str_0, str)



# Generated at 2022-06-25 20:36:27.027116
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    result = cryptographic.hash()
    assert cryptographic != cryptographic.hash()


# Generated at 2022-06-25 20:36:30.348242
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:36:31.771319
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic(seed=0)
    a = cryptographic.hash()
    b = cryptographic.hash()
    assert a == b



# Generated at 2022-06-25 20:36:35.482339
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert (str_0 is not None)



# Generated at 2022-06-25 20:36:36.717198
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    pass


# Generated at 2022-06-25 20:36:39.534313
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    res = cryptographic.hash()
    assert isinstance(res, str)


# Generated at 2022-06-25 20:36:41.541653
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash()
    assert isinstance(str_1, str)


# Generated at 2022-06-25 20:36:51.860969
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    seed = 123
    cryptographic_0 = Cryptographic(seed = seed)
    # Test with default algorithm parameter
    str_0 = cryptographic_0.hash()
    assert str_0 == 'e2c2f97d62665f16be7271be8fad3b20', 'AssertionError'
    str_0 = cryptographic_0.hash()
    assert str_0 != 'e94ca0b9e9d2c4989a78b8c1d7e6a072', 'AssertionError'
    # Test with sha256 algorithm parameter
    str_0 = cryptographic_0.hash(algorithm = Algorithm.SHA256)

# Generated at 2022-06-25 20:38:49.851804
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() == 'a60e93da8c9b2a54b3e3b4a4a8a35e4d'
    assert cryptographic_0.hash() == '67c9f47d1a7a2f08e8af7ff77a63d9c9'
    assert cryptographic_0.hash() == 'd8a29eec17a0c2a2d2b1b8d2b00f1749'
    assert cryptographic_0.hash() == 'f09d4e4cc3bb3e9d64c96fe539a1711c'
    assert cryptographic_0.hash() == 'bfdc7aefa0d8c03e9f38e18c7a65e1c8'
    assert cryptographic

# Generated at 2022-06-25 20:38:50.930513
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:38:53.454072
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    str_1 = cryptographic_0.hash()
    str_2 = cryptographic_0.hash()
    assert str_0 != str_1
    assert str_1 != str_2
    assert str_2 != str_0


# Generated at 2022-06-25 20:38:56.328065
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash() # str
    assert str_0 is not None
    assert str_0 != ""
    assert str_0 != b"\x00"
    assert len(str_0) != 0


# Generated at 2022-06-25 20:38:59.053473
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import random
    cryptographic_0 = Cryptographic()
    import mimesis.enums
    random_hash = cryptographic_0.hash(mimesis.enums.Algorithm.MD5)
    assert isinstance(random_hash, str)

# Generated at 2022-06-25 20:39:01.346306
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    #Create a object of class Cryptographic
    cryptographic_0 = Cryptographic()
    #Call method hash for the class Cryptographic
    assert isinstance(cryptographic_0.hash(), str)


# Generated at 2022-06-25 20:39:02.619632
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash()  # TODO: Not true!

# Generated at 2022-06-25 20:39:03.699703
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    str_0 = Cryptographic.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:39:05.866139
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    # Setup
    cryptographic = Cryptographic()
    algorithm = None

    # Target
    result = cryptographic.hash(algorithm)

    # Assertion
    str_0 = result


# Generated at 2022-06-25 20:39:09.265701
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    # The following line should be uncommented
    #assert cryptographic_0.hash() == '620c2d2fb00b74682637e94d5c5a5a5c'
