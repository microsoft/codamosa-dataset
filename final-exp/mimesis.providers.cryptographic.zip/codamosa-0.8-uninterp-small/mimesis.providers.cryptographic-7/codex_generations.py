

# Generated at 2022-06-25 20:29:17.469628
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    cryptographic.hash()


# Generated at 2022-06-25 20:29:27.360537
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # hash for '1eb4d4d6-1b30-4c57-8d8b-f6a83c36e9e6' from
    # https://emn178.github.io/online-tools/sha512.html
    cryptographic_1 = Cryptographic()
    print(
        cryptographic_1.hash(Algorithm.SHA512) ==
        "ddf6c18b44a1f2e8f8e3e36a82b667f0b7ba70adac8b986c025f063aa9bb2e26"
        "33a38a58a6c806ca34d8c82a46e2cb1cbcf5b5ea566f8b89cffb1a6fdd7c8b8d"
    )


# Generated at 2022-06-25 20:29:30.061762
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    res = cryptographic.hash(algorithm=Algorithm.MD5)
    assert isinstance(res, str) is True
    assert len(res) == 32


# Generated at 2022-06-25 20:29:34.990566
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    m = hashlib.md5()
    m.update(b'Hello World')
    m_d = m.hexdigest()
    assert m_d == 'b10a8db164e0754105b7a99be72e3fe5', 'Test fail'


# Generated at 2022-06-25 20:29:37.602581
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic('123', 'test')

    assert cryptographic_1.hash().isalnum()
    assert cryptographic_1.hash(Algorithm.MD5) is not None


# Generated at 2022-06-25 20:29:39.494101
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    med_provider = Cryptographic()
    assert isinstance(med_provider.hash(), str)
    return None


# Generated at 2022-06-25 20:29:47.331366
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()
    assert c.hash(Algorithm.SHA512) == '674d27f4e7c313a8e1fd5751f03a6c86e41b8f1c4d965f4dabddc7ef849661b34056e03e6d89b0a3b3f9c7d0d67a099cec81257e66b7a17d69f0a7a8b2d15c9d'



# Generated at 2022-06-25 20:29:50.409829
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash(algorithm=Algorithm.MD5) != None


# Generated at 2022-06-25 20:29:53.109926
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print(Cryptographic().hash())


# Generated at 2022-06-25 20:30:03.597316
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(Algorithm.BLAKE2B) == 'f36a51e053a6b5fa6b38756b7bdc6e4d58aa996dfadf4292eab4d4b90401e8a6'
    assert cryptographic.hash(Algorithm.BLAKE2S) == '731e2ac2f8d24d9b9c0569b33310c7ead8d8f8a60fad1d0dfbce08f487b0e9b3'
    assert cryptographic.hash(Algorithm.SHA3_224) == 'b34063c1f2c3c9ea3a0cd33f47b07a8b4f08ba4e4d4a211eab25afd'

# Generated at 2022-06-25 20:30:15.874417
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm_0 = Algorithm.SHA3_256
    var_0 = cryptographic_0.hash(algorithm_0)
    assert isinstance(
        var_0, str,
        "Expected return value of Cryptographic.hash to be instance of `str`",
    )


# Generated at 2022-06-25 20:30:19.260183
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_of_cryptographic_0 = cryptographic_0.hash()
    assert isinstance(hash_of_cryptographic_0, str)


# Generated at 2022-06-25 20:30:21.780311
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # A dummy test to verify that the value is not None
    assert Cryptographic().hash() != None


# Generated at 2022-06-25 20:30:30.140551
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic(seed = 0)
    res = cryptographic.hash()
    assert res == 'd30a820738ff68b9a9a3cc3b3c8f2a1a', 'Wrong value'
    res = cryptographic.hash()
    assert res == '31dfadb08c53790ada20b0d95c4f7467', 'Wrong value'
    res = cryptographic.hash()
    assert res == 'a5afe5b820bc40e3a7a70a3656cc1f2d', 'Wrong value'
    res = cryptographic.hash()
    assert res == '81b4b4a4b4dc4b9d9378a0f5a5f5b5c6', 'Wrong value'
    res = cryptographic.hash()

# Generated at 2022-06-25 20:30:32.250402
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(Algorithm.SHA512), str)


# Generated at 2022-06-25 20:30:37.110945
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    result = cryptographic_0.hash(Algorithm.SHA256)
    assert result == "92d0d743c4f4e4bd44822a8a9eadb9f7530c12cb7e3d3ed23eda7a36beb1e705"

# Generated at 2022-06-25 20:30:42.692156
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test case 1
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash() == '9a505f1a07bbe58b77eb1d0e8cde55a7b38367966d6f9cc6f4c6b4cd6b2e5d36'
    # Test case 2
    cryptographic_2 = Cryptographic()
    assert cryptographic_2.hash(algorithm='sha256') == '8b5c1f7e47b9527f9a9acdda3e3cc3f1184e077fbe8c8312c7b5e0b54f7b1e94'
    # Test case 3
    cryptographic_3 = Cryptographic()

# Generated at 2022-06-25 20:30:47.561761
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic0 = Cryptographic()
    cryptographic1 = Cryptographic(seed=300)
    cryptographic0.seed(300)

    assert 'a5f5c5f5e5d5a5b5aa5b5a5a5d5c5b5b5f5b5a5a' == cryptographic0.hash()
    assert 'a5f5c5f5e5d5a5b5aa5b5a5a5d5c5b5b5f5b5a5a' == cryptographic1.hash()
    assert 'c5e5d5d5e5b5c5a5f5a5f5c5b5f5e5e5a5e5b5c' == cryptographic0.hash(algorithm=Algorithm.SHA256)


# Generated at 2022-06-25 20:30:53.257638
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    cryptographic_1 = cryptographic_1.hash()
    cryptographic_1 = cryptographic_1.hash(algorithm="Algorithm.MD5")
    cryptographic_1 = cryptographic_1.hash(algorithm="Algorithm.SHA1")
    cryptographic_1 = cryptographic_1.hash(algorithm="Algorithm.SHA224")
    cryptographic_1 = cryptographic_1.hash(algorithm="Algorithm.SHA256")
    cryptographic_1 = cryptographic_1.hash(algorithm="Algorithm.SHA384")
    cryptographic_1 = cryptographic_1.hash(algorithm="Algorithm.SHA512")


# Generated at 2022-06-25 20:30:57.915087
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    cg = Cryptographic()
    cg.hash(Algorithm.MD5)
    cg.hash(Algorithm.SHA1)
    cg.hash(Algorithm.SHA224)
    cg.hash(Algorithm.SHA256)
    cg.hash(Algorithm.SHA384)
    cg.hash(Algorithm.SHA512)



# Generated at 2022-06-25 20:31:40.954357
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    Crypto_0 = Cryptographic()
    assert Crypto_0.hash(Algorithm.MD5) == Crypto_0.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:31:43.062943
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()

# Generated at 2022-06-25 20:31:45.711871
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0.hash(algorithm=Algorithm.SHA224)


# Generated at 2022-06-25 20:31:53.605842
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_0 = cryptographic_0.hash()
    hash_1 = cryptographic_0.hash(algorithm = Algorithm.MD5)
    hash_2 = cryptographic_0.hash()
    hash_3 = cryptographic_0.hash(algorithm = Algorithm.SHA1)
    hash_4 = cryptographic_0.hash()
    hash_5 = cryptographic_0.hash(algorithm = Algorithm.SHA224)
    hash_6 = cryptographic_0.hash()
    hash_7 = cryptographic_0.hash(algorithm = Algorithm.SHA256)
    hash_8 = cryptographic_0.hash()
    hash_9 = cryptographic_0.hash(algorithm = Algorithm.SHA384)
    hash_10 = cryptographic_0.hash()

# Generated at 2022-06-25 20:31:57.184434
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash() is not None

# Generated at 2022-06-25 20:32:02.210922
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    for x in range(1, 20):
        print(cryptographic.hash())
    for x in range(1, 20):
        print(cryptographic.hash(algorithm=Algorithm.SHA512))


# Generated at 2022-06-25 20:32:04.992082
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    value = cryptographic_0.hash(Algorithm.BLAKE2B)
    assert len(value) == 128


# Generated at 2022-06-25 20:32:08.906390
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash(algorithm=Algorithm.SHA_1)
    assert cryptographic_1.hash(algorithm=Algorithm.SHA_224)
    assert cryptographic_1.hash(algorithm=Algorithm.SHA_256)
    assert cryptographic_1.hash(algorithm=Algorithm.SHA_384)
    assert cryptographic_1.hash(algorithm=Algorithm.SHA_512)
    assert cryptographic_1.hash(algorithm=Algorithm.MD5)


# Generated at 2022-06-25 20:32:12.357172
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Return random hash.
    cryptographic = Cryptographic()
    hash_ = cryptographic.hash()
    assert(isinstance(hash_, str))


# Generated at 2022-06-25 20:32:16.407731
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    result = cryptographic.hash()
    assert len(result) == len('2e44bd009d95a6c55ab6f0a01f8a0af4515b9c90')

if __name__ == '__main__':
    test_case_0()
    test_Cryptographic_hash()

# Generated at 2022-06-25 20:33:05.508114
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() == '3e828cc0ff7bebf4f4c4ced56d1ab4b33f4bde22f24aec103675c8e2d67c16ad'


# Generated at 2022-06-25 20:33:09.314923
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_of_uuid = cryptographic_0.uuid()
    result_of_method = cryptographic_0.hash(hash_of_uuid)
    assert isinstance(result_of_method, str)


# Generated at 2022-06-25 20:33:14.879710
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash(algorithm=Algorithm.MD5) == 'a9a895ca209f3b3d82ace04eb87562ec'


# Generated at 2022-06-25 20:33:15.969406
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0.hash(algorithm=Algorithm.SHA1)


# Generated at 2022-06-25 20:33:18.276963
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert type(cryptographic.hash()) == str


# Generated at 2022-06-25 20:33:19.839873
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert isinstance(cryptographic.hash(), str)
    assert cryptographic.hash() == cryptographic.hash()


# Generated at 2022-06-25 20:33:25.019147
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Unit test for hash without arguments
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() is not None
    assert cryptographic_0.hash() != ''
    assert type(cryptographic_0.hash()) is str
    assert type(cryptographic_0.hash(algorithm=Algorithm.SHA1)) is str
    assert cryptographic_0.hash(algorithm=Algorithm.SHA1) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA1) != ''
    assert cryptographic_0.hash(algorithm=Algorithm.SHA224) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA224) != ''
    assert cryptographic_0.hash(algorithm=Algorithm.SHA256) is not None

# Generated at 2022-06-25 20:33:31.427510
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_1 = cryptographic_0.hash()
    assert len(hash_1) == 64
    hash_2 = cryptographic_0.hash(Algorithm.SHA512)
    assert len(hash_2) == 128


# Generated at 2022-06-25 20:33:35.086152
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    result = getattr(Cryptographic(), 'hash')()
    assert(len(result)==40)
    assert(isinstance(result, str))


# Generated at 2022-06-25 20:33:37.464439
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Tests
    cryptographic_0 = Cryptographic()
    cryptographic_0.hash()
