

# Generated at 2022-06-25 20:29:21.386077
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    ss = Cryptographic()
    var_0 = Algorithm.MD5
    assert ss.hash(algorithm=var_0) in Algorithm.to_value(Algorithm.MD5)
    var_1 = Algorithm.SHA512
    assert ss.hash(algorithm=var_1) in Algorithm.to_value(Algorithm.SHA512)
    var_2 = Algorithm.SHA256
    assert ss.hash(algorithm=var_2) in Algorithm.to_value(Algorithm.SHA256)
    var_3 = Algorithm.SHA3_512
    assert ss.hash(algorithm=var_3) in Algorithm.to_value(Algorithm.SHA3_512)
    var_4 = Algorithm.SHA3_384
    assert ss.hash(algorithm=var_4) in Algorithm.to_

# Generated at 2022-06-25 20:29:22.226016
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA1)

# Generated at 2022-06-25 20:29:25.356858
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    key_0 = Algorithm.SHA_224  # type: ignore
    var_0 = cryptographic_0.hash(algorithm=key_0)  # type: ignore


# Generated at 2022-06-25 20:29:31.641872
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic('en')
    res = cryptographic.hash()
    assert len(res) == 64
    res = cryptographic.hash(Algorithm.MD5)
    assert len(res) == 32
    res = cryptographic.hash(Algorithm.SHA1)
    assert len(res) == 40
    res = cryptographic.hash(Algorithm.SHA256)
    assert len(res) == 64
    res = cryptographic.hash(Algorithm.SHA512)
    assert len(res) == 128

# Generated at 2022-06-25 20:29:33.028860
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    pass


# Generated at 2022-06-25 20:29:35.121882
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Init a Cryptographic object
    cryptographic = Cryptographic()
    assert cryptographic.hash(algorithm=Algorithm.SHA512)


# Generated at 2022-06-25 20:29:36.714131
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    h = c.hash()
    assert isinstance(h, str)



# Generated at 2022-06-25 20:29:38.918646
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()
    assert var_0 is None, "Method hash() is not working"



# Generated at 2022-06-25 20:29:41.259266
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    result = cryptographic_0.hash(algorithm=None)
    assert isinstance(result, str)


# Generated at 2022-06-25 20:29:46.212555
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    algo = Algorithm.MD5
    entro = 32
    cg = Cryptographic()
    hash_ = cg.hash(algo)
    assert len(hash_) == 32 * 2
    assert isinstance(hash_, str)



# Generated at 2022-06-25 20:30:06.264233
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    _algorithm = Algorithm()
    _algorithm_0 = _algorithm.SHA256
    _algorithm_1 = _algorithm.SHA1
    var_0 = cryptographic_0.hash(algorithm=_algorithm_0)
    var_1 = cryptographic_0.hash(algorithm=_algorithm_1)


# Generated at 2022-06-25 20:30:17.074048
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    # Call method hash
    var_1 = cryptographic_1.hash()
    # Call method hash
    var_2 = cryptographic_1.hash(Algorithm.SHA256)
    # Call method hash
    var_3 = cryptographic_1.hash(Algorithm.SHA384)
    # Call method hash
    var_4 = cryptographic_1.hash(Algorithm.SHA512)
    # Call method hash
    var_5 = cryptographic_1.hash(Algorithm.SHA1)
    # Call method hash
    var_6 = cryptographic_1.hash(Algorithm.BLAKE2B)
    # Call method hash
    var_7 = cryptographic_1.hash(Algorithm.BLAKE2S)
    # Call method hash

# Generated at 2022-06-25 20:30:24.561732
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash() == cryptographic.hash(Algorithm.MD5)
    assert cryptographic.hash() == cryptographic.hash(Algorithm.SHA1)
    assert cryptographic.hash() == cryptographic.hash(Algorithm.SHA224)
    assert cryptographic.hash() == cryptographic.hash(Algorithm.SHA256)
    assert cryptographic.hash() == cryptographic.hash(Algorithm.SHA384)
    assert cryptographic.hash() == cryptographic.hash(Algorithm.SHA512)


# Generated at 2022-06-25 20:30:30.415465
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash() == '1e734f0e-bb79-447c-91a7-01b8d6aec2f2'
    assert cryptographic.hash(algorithm=None) == '1e734f0e-bb79-447c-91a7-01b8d6aec2f2'
    assert cryptographic.hash(algorithm=Algorithm.MD5) == '4a28a9c2-532c-4c2a-a45a-ab1dd7b8c274'

# Generated at 2022-06-25 20:30:33.004402
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(Algorithm.MD5)
    assert (var_0 is not None)


# Generated at 2022-06-25 20:30:40.116921
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic(seed=123456789)
    var_1 = cryptographic_1.hash(Algorithm.SHA_512.name)
    assert var_1 == 'cd6a4a6e8f4b12f4d4a3bac3f2c8fca7d9c9f1b4e8e0f0ec71fa4c4fa3f3ac0d175c9d0db39f9ccb6d5af6cdc75e31d2d807e0bff5dd6c8ba6e7e6a9b63f7dc15'


# Generated at 2022-06-25 20:30:50.687777
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Given:
    cryptographic_0 = Cryptographic()
    # When:
    var_0 = cryptographic_0.hash()
    # Then:
    assert isinstance(var_0, str)
    assert len(var_0) == 64
    # Given:
    cryptographic_1 = Cryptographic()
    # When:
    var_1 = cryptographic_1.hash()
    # Then:
    assert isinstance(var_1, str)
    assert len(var_1) == 64
    # Given:
    cryptographic_2 = Cryptographic()
    # When:
    var_2 = cryptographic_2.hash()
    # Then:
    assert isinstance(var_2, str)
    assert len(var_2) == 64
    # TODO: Fix this test
    assert var_0 != var_1 != var_2

# Generated at 2022-06-25 20:30:58.699477
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(Algorithm.SHA1) == cryptographic.hash(Algorithm.SHA1)
    assert cryptographic.hash(Algorithm.SHA224) == cryptographic.hash(Algorithm.SHA224)
    assert cryptographic.hash(Algorithm.SHA256) == cryptographic.hash(Algorithm.SHA256)
    assert cryptographic.hash(Algorithm.SHA384) == cryptographic.hash(Algorithm.SHA384)
    assert cryptographic.hash(Algorithm.SHA512) == cryptographic.hash(Algorithm.SHA512)
    assert cryptographic.hash(Algorithm.MD5) == cryptographic.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:31:03.586933
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm = Algorithm.SHA256
    var_0 = cryptographic_0.hash(algorithm)
    assert var_0 != None and isinstance(var_0, str), "Returned value is wrong"


# Generated at 2022-06-25 20:31:11.349575
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()
    assert isinstance(var_0, str)
    var_0 = cryptographic_0.hash(algorithm=Algorithm.MD5)
    assert isinstance(var_0, str)
    assert len(var_0) == 32
    var_0 = cryptographic_0.hash(algorithm=Algorithm.SHA1)
    assert isinstance(var_0, str)
    assert len(var_0) == 40
    var_0 = cryptographic_0.hash(algorithm=Algorithm.SHA224)
    assert isinstance(var_0, str)
    assert len(var_0) == 56
    var_0 = cryptographic_0.hash(algorithm=Algorithm.SHA256)
    assert isinstance(var_0, str)
   

# Generated at 2022-06-25 20:31:45.537028
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0.seed(0)
    cryptographic_0.hash()


# Generated at 2022-06-25 20:31:47.671672
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print()
    print("Unit test for method hash of class Cryptographic")
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:31:49.413256
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    var_1 = cryptographic_1.hash(Algorithm.SHA256)
    # String with 64 hexadecimal digits.
    assert len(var_1) == 64 and var_1.isalnum()


# Generated at 2022-06-25 20:31:52.865370
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(algorithm=Algorithm.SHA512) is not None


# Generated at 2022-06-25 20:31:54.809495
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() == 'e6ae8d6b3941f3c2bdb217d139b763fd'


# Generated at 2022-06-25 20:31:57.318166
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    assert cryptographic_1().hash()


# Generated at 2022-06-25 20:32:01.240809
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(Algorithm.MD5)
    print(var_0)


# Generated at 2022-06-25 20:32:04.787755
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    var_0 = cryptographic.hash()
    algo = Algorithm.MD5
    var_1 = cryptographic.hash(algorithm=algo)



# Generated at 2022-06-25 20:32:15.797281
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    cryptographic.hash(algorithm=0)
    cryptographic.hash(algorithm=1)
    cryptographic.hash(algorithm=2)
    cryptographic.hash(algorithm=3)
    cryptographic.hash(algorithm=4)
    cryptographic.hash(algorithm=5)
    cryptographic.hash(algorithm=6)
    cryptographic.hash(algorithm=7)
    cryptographic.hash(algorithm=8)
    cryptographic.hash(algorithm=9)
    cryptographic.hash(algorithm=10)
    cryptographic.hash(algorithm=11)
    cryptographic.hash(algorithm=12)


# Generated at 2022-06-25 20:32:19.008788
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    var_0 = cryptographic.hash()


# Generated at 2022-06-25 20:33:29.447102
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm_0 = Algorithm.SHA512
    var_0 = cryptographic_0.hash(algorithm_0)
    # var_0: str = '5c5f5efd1e06e7c848b6eaf7ea9f9b9c7d5e5f5c5e5ef5d5e5f5efd1e06e7c848b6eaf7ea9f9b9c7d5e5f5c5e5ef5d5e5f5efd1e06e7c848b6eaf7ea9f9b9c7d5e5f5c5e5ef5d5e5f5efd1e06e7c848b6eaf7ea9f9b9c7d5

# Generated at 2022-06-25 20:33:38.863439
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c_0 = Cryptographic()
    result_0 = c_0.hash()
    # TODO: from here to the end of the method
    #  need to be manually modified
    target_str_0 = '20eaa7bf4d6d4f6f9e6cdcff7e9d9f48b8d3114f28a63a981d9525e34d75fd69'
    target_str_1 = '38d8b99f0a2879e13f83e1d8a2cd99f0e2832f3ed3a8d3ecb94cffb0f0db27f8'

# Generated at 2022-06-25 20:33:41.817884
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    var_1 = cryptographic_1.hash(algorithm=Algorithm.SHA1)


# Generated at 2022-06-25 20:33:43.767531
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    cryptographic.hash()
