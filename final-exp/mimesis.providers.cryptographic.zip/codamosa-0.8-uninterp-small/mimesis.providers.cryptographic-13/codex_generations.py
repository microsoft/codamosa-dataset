

# Generated at 2022-06-25 20:29:18.220999
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert len(str_0) == 40


# Generated at 2022-06-25 20:29:21.465528
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0.random.seed(0)
    result = cryptographic_0.hash()
    assert result == 'd7f50a1a89e81b5d1dde95906c93ae41'


# Generated at 2022-06-25 20:29:23.854642
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    strategy_2 = Algorithm.MD5
    str_1 = cryptographic_1.hash(strategy_2)



# Generated at 2022-06-25 20:29:25.065649
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert True == True



# Generated at 2022-06-25 20:29:29.039720
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    key = Algorithm.MD5.value
    if hasattr(hashlib, key):
        fn = getattr(hashlib, key)
        fn(cryptographic.uuid().encode()).hexdigest()  # type: ignore


# Generated at 2022-06-25 20:29:34.694355
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    value = "b08c5b3a-99fd-4df9-9cd5-f360acf1b2c2"
    assert crypto.hash() == crypto.hash()
    assert crypto.hash(value).lower() == "6885a93c6a7194058f8b0aaed0117c93e2e0d37c"



# Generated at 2022-06-25 20:29:39.653333
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test for non-enumeration.
    cryptographic_0 = Cryptographic()
    try:
        cryptographic_0.hash(algorithm='foo')
    except ValueError:
        pass
    else:
        assert False, 'Non-enumeration'
    # Test for known enumeration.
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash(algorithm=Algorithm.SHA1), 'Enumeration'


# Generated at 2022-06-25 20:29:41.433211
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()



# Generated at 2022-06-25 20:29:44.765309
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_0 = cryptographic_1.token_urlsafe()
    str_1 = cryptographic_1.hash()


# Generated at 2022-06-25 20:29:46.975511
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:30:05.223449
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    str_0 = cryptographic.hash(Algorithm.BLAKE2B)



# Generated at 2022-06-25 20:30:06.475325
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    result = Cryptographic().hash()
    assert type(result) == str


# Generated at 2022-06-25 20:30:13.248766
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorith_0 = Algorithm()
    algorith_1 = Algorithm()
    str_0 = cryptographic_0.hash(algorithm=algorith_0)
    str_1 = cryptographic_0.hash(algorithm=algorith_1)
    assert str_0 != str_1

# Test case for method mnemonic_phrase of class Cryptographic

# Generated at 2022-06-25 20:30:15.910459
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Basic unit test for method hash of class Cryptographic."""
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert str_0, 'Failed to execute method hash of class Cryptographic'

# Generated at 2022-06-25 20:30:17.892678
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:30:21.334173
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_hash_0 = Cryptographic()
    result_0 = cryptographic_hash_0.hash()
    result_1 = str(result_0)


# Generated at 2022-06-25 20:30:24.835333
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash_0 = Cryptographic().hash()
    hash_1 = Cryptographic().hash()
    hash_2 = Cryptographic().hash()
    assert hash_0 != hash_1
    assert hash_1 != hash_2


# Generated at 2022-06-25 20:30:26.404901
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj_1 = Cryptographic()
    assert isinstance(obj_1.hash(), str)


# Generated at 2022-06-25 20:30:27.746892
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    algorithm = Algorithm.SHA1
    cryptographic.hash(algorithm)

# Generated at 2022-06-25 20:30:35.885236
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.MD5)
    str_1 = cryptographic_0.hash(Algorithm.SHA1)
    str_2 = cryptographic_0.hash(Algorithm.SHA224)
    str_3 = cryptographic_0.hash(Algorithm.SHA256)
    str_4 = cryptographic_0.hash(Algorithm.SHA384)
    str_5 = cryptographic_0.hash(Algorithm.SHA512)


# Generated at 2022-06-25 20:31:41.616607
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm_0 = Algorithm('')
    str_0 = cryptographic_0.hash(algorithm_0)


# Generated at 2022-06-25 20:31:46.315794
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    
    with raises(ValueError):
        str_0 = cryptographic.hash()

    with raises(ValueError):
        str_0 = cryptographic.hash(algorithm='md5')



# Generated at 2022-06-25 20:31:55.117207
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # initialization
    cryptographic = Cryptographic()
    # Simple test
    hash = cryptographic.hash()
    assert len(hash) > 40
    # test support of enum
    hash = cryptographic.hash(algorithm=Algorithm.MD5)
    assert hash.startswith('d41d8')


# Generated at 2022-06-25 20:31:57.911794
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:32:01.311294
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.MD5)
    assert isinstance(str_0, str)

# Generated at 2022-06-25 20:32:04.274969
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    ret = c.hash()
    assert isinstance(ret, str)
    assert len(ret) == 40


# Generated at 2022-06-25 20:32:12.214522
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    value_str_1: str = Cryptographic().hash()
    str_1: str = Cryptographic().hash()
    str_2: str = Cryptographic().hash()
    str_3: str = Cryptographic().hash()
    str_4: str = Cryptographic().hash()
    str_5: str = Cryptographic().hash()


# Generated at 2022-06-25 20:32:14.918291
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    enum_0 = Algorithm.MD5
    str_0 = cryptographic_0.hash(algorithm=enum_0)

# Generated at 2022-06-25 20:32:20.402542
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(algorithm=Algorithm.SHA256)
    assert str_0.isalnum()



# Generated at 2022-06-25 20:32:24.446614
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash(cryptographic_1.ALGORITHM.SHA_512)

