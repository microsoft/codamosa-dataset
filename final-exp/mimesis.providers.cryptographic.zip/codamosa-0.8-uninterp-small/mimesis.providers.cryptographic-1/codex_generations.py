

# Generated at 2022-06-25 20:29:51.489613
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print(Cryptographic().hash())
    print(Cryptographic().hash(algorithm=Algorithm.SHA3_224))
    print(Cryptographic().hash(algorithm=Algorithm.SHA3_256))
    print(Cryptographic().hash(algorithm=Algorithm.SHA3_384))
    print(Cryptographic().hash(algorithm=Algorithm.SHA3_512))

# Generated at 2022-06-25 20:29:56.239358
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash()


# Generated at 2022-06-25 20:29:58.814832
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    dict_0 = {}
    cryptographic_0 = Cryptographic(**dict_0)
    assert type(cryptographic_0.hash()) == str


# Generated at 2022-06-25 20:30:02.210843
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    for _ in range(4):
        dict_0 = {}
        cryptographic_0 = Cryptographic(**dict_0)
        Algorithm_0 = Algorithm.SHA3_512
        str_0 = cryptographic_0.hash(algorithm=Algorithm_0)


# Generated at 2022-06-25 20:30:08.339695
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    dict_1 = {}
    cryptographic_1 = Cryptographic(**dict_1)
    str_1 = cryptographic_1.hash()
    assert str_1 == "9c5bd5e3c5d3d11f5c8aba5e5ae24e6701dc3eb762a00bb9cc0f26d0b41e7cd6"
    assert type(str_1) is str

    dict_2 = {}
    cryptographic_2 = Cryptographic(**dict_2)
    str_2 = cryptographic_2.hash(Algorithm.SHA224)
    assert str_2 == "bdbd072e7b421ac8f84ed7d6aa92a1af7b77f9b25c7e3f3b3f7ccb5c"

# Generated at 2022-06-25 20:30:10.627693
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    dict_0 = {}
    cryptographic_0 = Cryptographic(**dict_0)
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:30:16.156462
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    dict_1 = {}
    cryptographic_1 = Cryptographic(**dict_1)
    str_1 = cryptographic_1.token_hex()
    str_2 = cryptographic_1.hash()
    str_3 = cryptographic_1.hash(Algorithm.SHA1)
    str_4 = cryptographic_1.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:30:20.334648
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    dict_0 = {}
    cryptographic_0 = Cryptographic(**dict_0)
    print(cryptographic_0.hash())
    print(cryptographic_0.hash())
    print(cryptographic_0.hash())


# Generated at 2022-06-25 20:30:22.477900
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    result_0 = cryptographic_0.hash()



# Generated at 2022-06-25 20:30:24.134736
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    dict_0 = {}
    cryptographic_0 = Cryptographic(**dict_0)
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:31:39.909522
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    alg = Algorithm.SHA256
    str_0 = Cryptographic().hash(alg)
    assert str_0 is not None


# Generated at 2022-06-25 20:31:41.975659
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()

# Generated at 2022-06-25 20:31:47.203583
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0.seed(0)
    cryptographic_1 = Cryptographic()
    cryptographic_1.seed(0)

    str_0 = cryptographic_0.hash()
    str_1 = cryptographic_1.hash()

    assert (str_0 == str_1)


# Generated at 2022-06-25 20:31:55.021033
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import hashlib
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(algorithm=Algorithm.SHA512)
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash(algorithm=Algorithm.MD5)
    cryptographic_2 = Cryptographic()
    str_2 = cryptographic_2.hash(algorithm=Algorithm.SHA256)
    cryptographic_3 = Cryptographic()
    str_3 = cryptographic_3.hash(algorithm=Algorithm.SHA1)
    cryptographic_4 = Cryptographic()
    str_4 = cryptographic_4.hash(algorithm=Algorithm.BLAKE2B)
    cryptographic_5 = Cryptographic()
    str_5 = cryptographic_5.hash(algorithm=Algorithm.BLAKE2S)
    cryptographic_6 = Cryptographic()

# Generated at 2022-06-25 20:32:01.630894
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Arrange
    cryptographic_0 = Cryptographic()
    algorithm = Algorithm.MD5
    # Act
    actual_result_0 = cryptographic_0.hash(algorithm)
    # Assert
    assert isinstance(actual_result_0, str), 'Expected result is str'


# Generated at 2022-06-25 20:32:04.232353
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert isinstance(cryptographic_0.hash(), str)


# Generated at 2022-06-25 20:32:06.979114
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert isinstance(str_0, str)
    assert re.match('[0-9a-f]{32}', str_0)


# Generated at 2022-06-25 20:32:18.158372
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    cryptographic = Cryptographic()

    # Test with algorithm = None
    cryptographic_hash_1 = cryptographic.hash()
    
    assert isinstance(cryptographic_hash_1, str)

    # Test with algorithm = Algorithm.MD5
    cryptographic_hash_2 = cryptographic.hash(Algorithm.MD5)
    
    assert isinstance(cryptographic_hash_2, str)

    # Test with algorithm = Algorithm.SHA1
    cryptographic_hash_3 = cryptographic.hash(Algorithm.SHA1)
    
    assert isinstance(cryptographic_hash_3, str)

    # Test with algorithm = Algorithm.SHA224
    cryptographic_hash_4 = cryptographic.hash(Algorithm.SHA224)
    
    assert isinstance(cryptographic_hash_4, str)

    # Test with algorithm = Algorithm.SHA256
    cryptographic

# Generated at 2022-06-25 20:32:25.816490
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.SHA224)
    str_1 = cryptographic_0.hash(Algorithm.SHA256)
    str_2 = cryptographic_0.hash(Algorithm.SHA384)
    str_3 = cryptographic_0.hash(Algorithm.SHA512)
    str_4 = cryptographic_0.hash()


# Generated at 2022-06-25 20:32:28.625779
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() is not None


# Generated at 2022-06-25 20:35:09.517633
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hexdigest_0 = cryptographic_0.hash(None)
    hexdigest_1 = cryptographic_0.hash('SHA224')


# Generated at 2022-06-25 20:35:12.156296
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:35:13.870370
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	print("There is no unit test for method 'hash' of class 'Cryptographic'")


# Generated at 2022-06-25 20:35:25.062813
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_1 = Cryptographic(seed=0)
    cryptographic_2 = Cryptographic(seed=0)
    cryptographic_3 = Cryptographic(seed=1)
    cryptographic_4 = Cryptographic(seed=1)
    cryptographic_5 = Cryptographic(seed=2)
    cryptographic_6 = Cryptographic(seed=2)
    cryptographic_7 = Cryptographic(seed=3)
    cryptographic_8 = Cryptographic(seed=3)
    cryptographic_9 = Cryptographic(seed=4)
    cryptographic_10 = Cryptographic(seed=4)
    cryptographic_11 = Cryptographic(seed=5)
    cryptographic_12 = Cryptographic(seed=5)
    cryptographic_13 = Cryptographic(seed=6)
    cryptographic_14 = Cryptographic(seed=6)

# Generated at 2022-06-25 20:35:27.699402
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:35:29.601560
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert 'Cryptographic().hash()' == 'Cryptographic().hash()'


# Generated at 2022-06-25 20:35:30.893292
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    str_var_0 = cryptographic.hash()
    assert isinstance(str_var_0, str)

# Generated at 2022-06-25 20:35:32.588805
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  cryptographic = Cryptographic()
  assert type(cryptographic.hash()) == str

# Generated at 2022-06-25 20:35:43.374159
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(Algorithm.MD5) == 'fe01ce2a7fbac8fafaed7c982a04e229'
    assert cryptographic.hash(Algorithm.MD4) == 'f2e7ee8bdfc8225ba59e2395c7467cf8'
    assert cryptographic.hash(Algorithm.BLAKE2B) == '3d087d985270efc820fe8f642e4fbb4d4ea2e39b078e7c6570ce24e03dc9bf0b' \
                                          '2fbea7cf6c1000ee8b7a3a52de3ca7a6'

# Generated at 2022-06-25 20:35:46.888127
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash()
    str_2 = cryptographic_1.hash(Algorithm.SHA1)
