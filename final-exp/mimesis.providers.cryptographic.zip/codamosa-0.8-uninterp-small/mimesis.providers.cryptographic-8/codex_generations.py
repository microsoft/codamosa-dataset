

# Generated at 2022-06-25 20:29:26.579931
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    # TypeError:
    try:
        cryptographic_0.hash(algorithm=None)
    except TypeError as e:
        print(f'Test: {e} has been raised')
    # TypeError:
    try:
        cryptographic_0.hash(algorithm='foo')
    except TypeError as e:
        print(f'Test: {e} has been raised')
    # TypeError:
    try:
        cryptographic_0.hash(algorithm=2)
    except TypeError as e:
        print(f'Test: {e} has been raised')
    # TypeError:
    try:
        cryptographic_0.hash(algorithm=('foo', 'bar'))
    except TypeError as e:
        print(f'Test: {e} has been raised')
   

# Generated at 2022-06-25 20:29:31.004749
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    list_0 = []
    cryptographic_0 = Cryptographic(*list_0)
    var_1 = cryptographic_0.hash(algorithm = Algorithm.MD5)
    assert var_1 == '6505b6c5e5e5ef6be5c2f5aa6d8406db'




# Generated at 2022-06-25 20:29:40.458470
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0.hash(Algorithm.MD5)

    cryptographic_1 = Cryptographic()
    cryptographic_1.hash(Algorithm.SHA1)

    cryptographic_2 = Cryptographic()
    cryptographic_2.hash(Algorithm.SHA256)

    cryptographic_3 = Cryptographic()
    cryptographic_3.hash(Algorithm.SHA3_224)

    cryptographic_4 = Cryptographic()
    cryptographic_4.hash(Algorithm.SHA3_256)

    cryptographic_5 = Cryptographic()
    cryptographic_5.hash(Algorithm.SHA3_384)

    cryptographic_6 = Cryptographic()
    cryptographic_6.hash(Algorithm.SHA3_512)

    cryptographic_7 = Cryptographic()
    cryptographic_7.hash(Algorithm.SHA512)

    cryptographic_8 = Cryptographic

# Generated at 2022-06-25 20:29:42.925262
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_0 = cryptographic_0.hash()
    assert hash_0 != ""


# Generated at 2022-06-25 20:29:46.571990
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    list_1 = []
    cryptographic_1 = Cryptographic(*list_1)
    var_1 = cryptographic_1.hash(algorithm=('SHA-512',))
    assert var_1



# Generated at 2022-06-25 20:29:54.193983
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    sample_size = 100
    list_0 = [
        Algorithm.BLAKE2B,
        Algorithm.BLAKE2S,
        Algorithm.MD5,
        Algorithm.SHA1,
        Algorithm.SHA224,
        Algorithm.SHA256,
        Algorithm.SHA384,
        Algorithm.SHA512,
    ]
    cryptographic_0 = Cryptographic(*list_0)
    var_0 = cryptographic_0.hash()
    sample_estimate = len(set([var_0 for i in range(sample_size)]))
    assert sample_estimate == 1

# Generated at 2022-06-25 20:30:03.659951
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_hash_0 = Cryptographic.hash(algorithm=Algorithm.SHA512)
    assert isinstance(cryptographic_hash_0, str)
    assert cryptographic_hash_0 == '2b2f8c8e68e58d6a54cff7a0e8a81620e73c8a8f7d1215a825c7f9e42c34d7ff0f0fadb7a31b0c65ee7e25d9c361f7a0b00d0f4a4bdd3b4ce70b4e8b2d6f1aaa'
    cryptographic_hash_0 = Cryptographic.hash(algorithm=Algorithm.SHA256)
    assert isinstance(cryptographic_hash_0, str)

# Generated at 2022-06-25 20:30:15.423581
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hashval = Cryptographic().hash(Algorithm.SHA512)
    assert isinstance(hashval, str)
    assert len(hashval) == 128
    assert hashval.count('.') == 0
    assert hashval.count('e') == 0
    assert hashval.count('2') == 2
    assert hashval.count('f') == 2
    assert hashval.count('1') == 2
    assert hashval.count('a') == 2
    assert hashval.count('8') == 2
    assert hashval.count('9') == 2
    assert hashval.count('0') == 2
    assert hashval.count('4') == 2
    assert hashval.count('c') == 2
    assert hashval.count('3') == 2
    assert hashval.count('d') == 2
    assert hashval.count

# Generated at 2022-06-25 20:30:26.648238
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(Algorithm.MD5)
    var_1 = cryptographic_0.hash(Algorithm.SHA224)
    var_2 = cryptographic_0.hash(Algorithm.SHA384)
    var_3 = cryptographic_0.hash(Algorithm.WHIRLPOOL)
    var_4 = cryptographic_0.hash(Algorithm.SHA256)
    var_5 = cryptographic_0.hash(Algorithm.SHA512)
    var_6 = cryptographic_0.hash(Algorithm.SHA1)
    var_7 = cryptographic_0.hash(Algorithm.SHA3_224)
    var_8 = cryptographic_0.hash(Algorithm.SHA3_512)
    var_9 = cryptographic_0.hash(Algorithm.SHA3_384)
   

# Generated at 2022-06-25 20:30:28.372566
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash(Algorithm.SHA1)  # Must be hashable


# Generated at 2022-06-25 20:30:45.632177
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash("MD5") != None


# Generated at 2022-06-25 20:30:48.848997
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(
        Cryptographic().hash()
    ) == 64


# Generated at 2022-06-25 20:30:51.984868
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert len(str_0) == 40


# Generated at 2022-06-25 20:30:59.987059
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Check that cryptographic_0.hash() produces an instance of class str
    cryptographic_0 = Cryptographic()
    hash_0 = cryptographic_0.hash()
    assert isinstance(hash_0, str)
    # Check that cryptographic_1.hash() produces an instance of class str
    cryptographic_1 = Cryptographic()
    hash_1 = cryptographic_1.hash()
    assert isinstance(hash_1, str)
    # Check that cryptographic_2.hash() produces an instance of class str
    cryptographic_2 = Cryptographic(seed=1234)
    hash_2 = cryptographic_2.hash()
    assert isinstance(hash_2, str)
    # Check that cryptographic_3.hash() produces a different value than cryptographic_4.hash()
    cryptographic_3 = Cryptographic()
    hash_3 = cryptographic_3.hash()
   

# Generated at 2022-06-25 20:31:03.305445
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash()
    assert type(str_1) == str

# Generated at 2022-06-25 20:31:06.867195
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert isinstance(str_0, str)
    assert len(str_0) > 0


# Generated at 2022-06-25 20:31:12.903496
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c1 = Cryptographic()
    h1 = c1.hash()
    print(len(h1))

    c2 = Cryptographic()
    h2 = c2.hash()
    print(len(h2))

    assert h1 != h2

# Generated at 2022-06-25 20:31:16.122592
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Assert that the hash contains only hexadecimal digits
    assert (str(str_0).isalnum())
    assert len(str(str_0)) == 64


# Generated at 2022-06-25 20:31:28.004580
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_ = Cryptographic()
    cryptographic_._validate_enum = mock.MagicMock()
    cryptographic_._validate_enum.return_value = 'algorithm'
    cryptographic_.uuid = mock.MagicMock()
    cryptographic_.uuid.return_value = mock.sentinel.uuid
    hashlib.algorithm = mock.MagicMock()
    hashlib.algorithm.return_value = hashlib.algorithm
    hashlib.algorithm.hexdigest = mock.MagicMock()
    hashlib.algorithm.hexdigest.return_value = mock.sentinel.hexdigest
    assert cryptographic_.hash() == mock.sentinel.hexdigest
    hashlib.algorithm.assert_called_once()
    hashlib.algorithm.assert_called_once()
    hashlib.algorithm.return_

# Generated at 2022-06-25 20:31:32.179909
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    assert obj.hash() == '6e82b2d4b838e4b4e4fc6900ae2ebfa0'



# Generated at 2022-06-25 20:32:39.123672
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Get a reference to the module under test
    from mimesis.datetime import Datetime
    # Get a reference to the class under test
    import mimesis.enums
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.exceptions import NonEnumerableError
    # Construct object
    cryptographic_0 = Cryptographic()
    # Test method
    with raises(NonEnumerableError) as exception_context:
        cryptographic_0.hash(mimesis.enums.Algorithm.MD5)
    # Test method
    cryptographic_0.hash(mimesis.enums.Algorithm.SHA1)
    # Test method
    cryptographic_0.hash(mimesis.enums.Algorithm.SHA224)
    # Test method

# Generated at 2022-06-25 20:32:43.196225
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider_0 = Cryptographic()
    str_0 = provider_0.hash()
    str_1 = provider_0.hash()
    assert str_0 is not str_1


# Generated at 2022-06-25 20:32:47.878544
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test with default value of algorithm
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:32:49.616865
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    h = Cryptographic()
    theResult = h.hash(Algorithm.SHA224)
    print(theResult)
    assert theResult is not None

# Generated at 2022-06-25 20:32:55.922877
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert str_0 != ""
    # Test for exception of method hash of class Cryptographic
    try:
        cryptographic_0 = Cryptographic()
        cryptographic_0.hash(algorithm=None)
    except Exception as exception_0:
        print(f"Error: {exception_0}")


# Generated at 2022-06-25 20:33:05.390303
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash(Algorithm.MD5) == '8f18a7b09404d23e4c4cf4ce4ef32f62'
    assert cryptographic_0.hash(Algorithm.MD4) == 'cd2b08711f8da03b577d3c3cc3d9f6fb'
    assert cryptographic_0.hash(Algorithm.SHA1) == '5b17f6be021dc2d9e01b8ab2b1b17d75e6a61c6f'
    assert cryptographic_0.hash(Algorithm.SHA224) == '852c79f7af3d3e782c7a8a8a21e7e2d05f9c9a2bf818d1ddfceacd32'


# Generated at 2022-06-25 20:33:14.880051
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(algorithm = Algorithm.SHA256)
    assert re.search('^[a-zA-Z0-9]', str_0) is not None
    str_1 = cryptographic_0.hash(algorithm = Algorithm.SHA256)
    assert re.search('^[a-zA-Z0-9]', str_1) is not None
    algorithmalgorithm_0 = cryptographic_0.random.choice(Algorithm)
    str_2 = cryptographic_0.hash(algorithm = algorithmalgorithm_0)
    assert re.search('^[a-zA-Z0-9]', str_2) is not None
    algorithmalgorithm_1 = cryptographic_0.random.choice(Algorithm)
    str_3 = cryptographic_0

# Generated at 2022-06-25 20:33:21.143293
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash()) == 64
    assert Cryptographic().hash(Algorithm.MD5) == Cryptographic().hash(Algorithm.MD5)
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40
    assert len(Cryptographic().hash(Algorithm.SHA224)) == 56
    assert len(Cryptographic().hash(Algorithm.SHA384)) == 96
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128
    assert len(Cryptographic().hash(Algorithm.BLAKE2b512)) == 128
    assert len(Cryptographic().hash(Algorithm.BLAKE2s)) == 64

# Generated at 2022-06-25 20:33:26.782652
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Set up test data
    cryptographic_0 = Cryptographic()
    algorithm_0 = Algorithm.SHA224
    # Invoke method
    str_0 = cryptographic_0.hash(algorithm_0)
    # Check for expected result
    assert isinstance(str_0, str)
    # Invoke method
    str_1 = cryptographic_0.hash()
    # Check for expected result
    assert isinstance(str_1, str)


# Generated at 2022-06-25 20:33:34.757400
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    alg = 'md5'
    obj = Cryptographic()
    res = obj.hash(alg)
    assert len(res) > 0
    assert isinstance(res, str)
    assert hashlib.algorithms_guaranteed[alg](u'7e8ab59f-097c-4a5e-be44-6e2d6a2039c1'.encode()).hexdigest() == res

# Generated at 2022-06-25 20:34:35.046904
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test hash from class Cryptographic."""
    cryptographic_0 = Cryptographic(_seed=0)
    str_0 = cryptographic_0.hash()
    assert str_0 == '69420bd7b6c230f8204bf0d1c2a06e7a'


# Generated at 2022-06-25 20:34:37.083734
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    string_0_0 = Cryptographic().hash()


# Generated at 2022-06-25 20:34:37.937298
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  assert len(Cryptographic().hash()) == 40


# Generated at 2022-06-25 20:34:39.525821
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert len(str_0) > 5


# Generated at 2022-06-25 20:34:44.977950
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj_0 = Cryptographic()
    # Tests
    assert obj_0.hash(algorithm=Algorithm.MD5) is not None
    assert obj_0.hash(algorithm=Algorithm.SHA1) is not None
    assert obj_0.hash(algorithm=Algorithm.SHA224) is not None
    assert obj_0.hash(algorithm=Algorithm.SHA256) is not None
    assert obj_0.hash(algorithm=Algorithm.SHA384) is not None
    assert obj_0.hash(algorithm=Algorithm.SHA512) is not None


# Generated at 2022-06-25 20:34:49.736851
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    s = cryptographic.hash()
    assert isinstance(s, str)

# Generated at 2022-06-25 20:34:53.227672
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """The test for method hash of class Cryptographic"""
    cryptographic_0 = Cryptographic()

    str_0 = cryptographic_0.hash()
    assert str_0


# Generated at 2022-06-25 20:34:57.380465
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash()


if __name__ == '__main__':
    test_case_0()
    test_Cryptographic_hash()

# Generated at 2022-06-25 20:35:06.994606
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    #  Getting hash of the class Cryptographic
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    #  String must be equal to str_0
    assert str_0 is not None
    #  Getting hash of the class Cryptographic
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash()
    #  String must be equal to str_1
    assert str_1 is not None
    #  Getting hash of the class Cryptographic
    cryptographic_2 = Cryptographic()
    str_2 = cryptographic_2.hash()
    #  String must be equal to str_2
    assert str_2 is not None
    #  Getting hash of the class Cryptographic
    cryptographic_3 = Cryptographic()
    str_3 = cryptographic_3.hash()
    #  String must be equal to

# Generated at 2022-06-25 20:35:10.341357
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert type(str_0) == str
