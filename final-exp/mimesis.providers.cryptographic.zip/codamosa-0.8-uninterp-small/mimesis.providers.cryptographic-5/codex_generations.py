

# Generated at 2022-06-25 20:29:24.583034
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    if cryptographic_1.hash() == cryptographic_1.hash():
        print("Method hash of class Cryptographic works fine")
    else:
        raise AssertionError("Method hash of class Cryptographic doesn't work")


# Generated at 2022-06-25 20:29:28.483025
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    # Test case with the default enum
    var_0 = cryptographic_0.hash()
    var_1 = cryptographic_0.hash(algorithm=Algorithm.SHA3_256)


# Generated at 2022-06-25 20:29:30.020023
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:29:37.393752
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Useing the method hash of class Cryptographic with the params:
    # algorithm= <Enum.Algorithm.SHA1>

    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(algorithm=Enum.Algorithm.SHA1)
    # The value for the var_0 is: 40d15fee74675c5a15c03e34b46d515867e1ab77
    assert var_0 == '40d15fee74675c5a15c03e34b46d515867e1ab77'


# Generated at 2022-06-25 20:29:38.919847
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:29:50.478647
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash() == '8c8f1d892cffbac6bd37ce832e9e1225c3ad3e0840a8a0b213cb98f08c3a3e3b'
    assert cryptographic.hash(Algorithm.MD5) == '47a758c1287f87c6988fc15428b072e2'
    assert cryptographic.hash(Algorithm.SHA1) == '06e0b8749c324eef90a00a2c252ef9f0c6668c99'
    assert cryptographic.hash(Algorithm.SHA224) == '16b3f58adc9d14b2c7b1f24b822e198916ddd37c2b62328ac20e8f61d'
    assert cryptographic

# Generated at 2022-06-25 20:29:58.397971
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('Begin test for Cryptographic method hash')
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(algorithm=Algorithm.BLAKE2B_256)
    print('var_0: \'{}\''.format(var_0))
    cryptographic_1 = Cryptographic()
    var_1 = cryptographic_1.hash(algorithm=Algorithm.BLAKE2B_384)
    print('var_1: \'{}\''.format(var_1))
    cryptographic_2 = Cryptographic()
    var_2 = cryptographic_2.hash(algorithm=Algorithm.BLAKE2B_512)
    print('var_2: \'{}\''.format(var_2))
    cryptographic_3 = Cryptographic()

# Generated at 2022-06-25 20:30:03.047436
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash() == '5d1c7e5eb0a44f7c99f4b4d3ddf204f6'
    assert cryptographic_1.hash() == '1f825b736a814c959049e20d9b605a4b'
    assert cryptographic_1.hash() == '7853eb4f7594497b984d4d3ee48f024f'


# Generated at 2022-06-25 20:30:04.808805
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()
    assert True == isinstance(var_0, str)


# Generated at 2022-06-25 20:30:06.340188
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() is not None


# Generated at 2022-06-25 20:30:45.748928
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    pass

# Generated at 2022-06-25 20:30:49.584689
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash() is not None


# Generated at 2022-06-25 20:30:51.625467
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    cryptographic.hash()


# Generated at 2022-06-25 20:30:55.312401
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    # hash_0 = cryptographic_0.hash(Algorithm.MD5)
    var_0 = cryptographic_0.hash()

# Generated at 2022-06-25 20:30:58.847620
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic0 = Cryptographic()
    var_0 = cryptographic0.hash(Algorithm.SHA256)
    assert (var_0 is not None)

#

# Generated at 2022-06-25 20:31:00.230148
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    pass


# Generated at 2022-06-25 20:31:10.398374
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == hashlib.sha512(crypto.uuid().encode()).hexdigest()
    assert crypto.hash(Algorithm.SHA256) == hashlib.sha256(crypto.uuid().encode()).hexdigest()
    assert crypto.hash(Algorithm.SHA384) == hashlib.sha384(crypto.uuid().encode()).hexdigest()
    assert crypto.hash(Algorithm.SHA1) == hashlib.sha1(crypto.uuid().encode()).hexdigest()
    assert crypto.hash(Algorithm.MD5) == hashlib.md5(crypto.uuid().encode()).hexdigest()

# Generated at 2022-06-25 20:31:16.503082
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    print("hash : ")
    print(cryptographic_0.hash() )
    cryptographic_1 = Cryptographic()
    print("hash : ")
    print(cryptographic_1.hash() )
    cryptographic_2 = Cryptographic()
    print("hash : ")
    print(cryptographic_2.hash() )


# Generated at 2022-06-25 20:31:21.577678
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test if hash is getting called with parameters
    cryptographic_1 = Cryptographic()
    param_hash = Algorithm.SHA224()
    var_1 = cryptographic_1.hash(param_hash)


# Generated at 2022-06-25 20:31:26.929999
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic(seed=1234567890)
    hash_0 = cryptographic_0.hash(Algorithm.MD5)
    hash_1 = cryptographic_0.hash(Algorithm.MD5)
    assert hash_0 == hash_1

if __name__ == "__main__":
    test_Cryptographic_hash()
    test_case_0()

# Generated at 2022-06-25 20:37:40.923094
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    var_0 = cryptographic.hash(Algorithm.SHA1)
    var_1 = cryptographic.hash(Algorithm.SHA256)
    assert(var_0 == var_1)


# Generated at 2022-06-25 20:37:42.135913
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    var_1 = cryptographic_1.hash()


# Generated at 2022-06-25 20:37:43.928979
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:37:46.357629
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for hash method"""
    cryptographic_0 = Cryptographic()

    # Print the object
    result = cryptographic_0.hash()
    assert isinstance(result, str)



# Generated at 2022-06-25 20:37:48.156745
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    cryptographic = Cryptographic()
    assert cryptographic.hash() is not None


# Generated at 2022-06-25 20:37:51.696586
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash(Algorithm.MD5) == '1a86b77e05b879b9ce222bff2f044923'


# Generated at 2022-06-25 20:37:55.302726
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    cryptographic_0 = Cryptographic(seed=777)
    var_0 = cryptographic_0.hash()
    assert var_0 != cryptographic_0.hash(algorithm=Algorithm.SHA256) and var_0 != cryptographic_0.hash(algorithm=Algorithm.SHA512)


# Generated at 2022-06-25 20:37:57.807232
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()
    cryptographic_1 = Cryptographic()
    var_1 = cryptographic_1.hash(Algorithm.SHA512)


# Generated at 2022-06-25 20:38:00.076618
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    p = Cryptographic()
    # Make sure that parameter algorithm is the type Algorithm
    assert isinstance(Algorithm.SHA256, Algorithm)
    p.hash(algorithm=Algorithm.SHA256)


# Generated at 2022-06-25 20:38:04.031246
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    var_0 = cryptographic.hash()

