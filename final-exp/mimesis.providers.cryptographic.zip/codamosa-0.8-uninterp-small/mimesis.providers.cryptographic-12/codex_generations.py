

# Generated at 2022-06-25 20:29:17.002955
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.MD5)
    str_1 = cryptographic_0.hash(Algorithm.SHA256)
    str_2 = cryptographic_0.hash(Algorithm.SHA512)

# Generated at 2022-06-25 20:29:19.140598
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert len(str_0) == 64


# Generated at 2022-06-25 20:29:19.715094
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    return

# Generated at 2022-06-25 20:29:29.445610
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    class_1 = Cryptographic(seed=177556)
    str_0 = class_1.hash()
    assert str_0 == "4d4c4a4bdc29f3504f0f63e0a93cf82e"

    class_2 = Cryptographic(seed=177556)
    str_0 = class_2.hash(Algorithm.SHA256)
    assert str_0 == "c3f71770dd2c696b78892b311fbcb7d07c9d9a7f99425d3c7ea983c0eaf1b822"

    str_0 = class_2.hash(Algorithm.SHA384)

# Generated at 2022-06-25 20:29:31.211608
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash().isalnum() == True



# Generated at 2022-06-25 20:29:33.749123
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Tests for method hash of class Cryptographic

    cryptographic_0 = Cryptographic()

    assert cryptographic_0.hash()


# Generated at 2022-06-25 20:29:35.404178
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    
    cg = Cryptographic()
    
    assert isinstance(cg.hash(), str)


# Generated at 2022-06-25 20:29:36.972240
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Place your code here
    cryptographic_2 = Cryptographic()
    str_0 = cryptographic_2.hash()


# Generated at 2022-06-25 20:29:44.693224
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic(seed=1323)
    str_0 = cryptographic_0.hash()
    assert str_0 == '6481e2ce9da7fef6e15a6e18e6d4c4f4a12638ec28dd7b4e5f9d7b5a2c5b7f5d'
    str_1 = cryptographic_0.hash()
    assert str_1 == '29f5e259f7cc566295dac8e6ece1f3c349d2d2e9e7fef0aad171074c98d16f8c'
    str_2 = cryptographic_0.hash()

# Generated at 2022-06-25 20:29:46.897948
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    result = cryptographic_0.hash()
    assert type(result) is str


# Generated at 2022-06-25 20:30:00.740666
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:30:02.717014
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.BLAKE2b)


# Generated at 2022-06-25 20:30:04.295679
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:30:05.552431
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method Cryptographic.hash()"""
    pass



# Generated at 2022-06-25 20:30:07.827521
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:30:15.724515
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic(seed=0)
    cryptographic_1 = Cryptographic(seed=1)
    assert cryptographic_0.hash(algorithm=Algorithm.SHA1) == 'a1d88eec929ac971cab00c3a82e3b3a2c7e28b73'
    assert cryptographic_1.hash(algorithm=Algorithm.SHA1) == '45b6dfc57fec8b6d3e735d0f4eb9e07e857b4d7a'

# Generated at 2022-06-25 20:30:18.099626
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    algorithm = Algorithm.MD5  # type: Algorithm

    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(algorithm)

# Generated at 2022-06-25 20:30:25.622599
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_1 = Cryptographic()
    cryptographic_0.seed(0)
    cryptographic_1.seed(0)
    str_0 = cryptographic_0.hash()
    str_1 = cryptographic_1.hash()
    assert str_0 == str_1
    cryptographic_0.seed()
    cryptographic_1.seed()
    str_0 = cryptographic_0.hash()
    str_1 = cryptographic_1.hash()
    assert str_0 != str_1


# Generated at 2022-06-25 20:30:27.417696
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:30:33.479325
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()

    assert cryptographic.hash() == 'daa52f9fc78dd8a3afd56c66f2d1b13c36b2d2923e2a7b90e4679557640da8e1'
    assert cryptographic.hash().upper() == 'DAA52F9FC78DD8A3AFD56C66F2D1B13C36B2D2923E2A7B90E4679557640DA8E1'
    assert cryptographic.hash(algorithm=Algorithm.MD5) == 'e9425ed99acb575448d7e9c95984e2ee'

# Generated at 2022-06-25 20:31:04.519524
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()



# Generated at 2022-06-25 20:31:06.904864
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash(Algorithm.SHA512)


# Generated at 2022-06-25 20:31:09.811424
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(str(Cryptographic.hash())) == 40

# Generated at 2022-06-25 20:31:12.629281
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:31:15.990916
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic(seed=1234)
    assert cryptographic_1.hash() == '175238fcd2c65b1d5c3610a8f8ccd596'

# Generated at 2022-06-25 20:31:20.346020
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert str_0 != None


# Generated at 2022-06-25 20:31:23.211895
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    result = cryptographic_0.hash()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:31:29.727442
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Paths coverage
    #
    # All paths with Algorithm.* (enum)
    #
    # Paths coverage with Algorithm.ALGORITHM_MD5
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash(Algorithm.ALGORITHM_MD5)
    # Paths coverage with Algorithm.ALGORITHM_SHA1
    cryptographic_2 = Cryptographic()
    str_2 = cryptographic_2.hash(Algorithm.ALGORITHM_SHA1)
    # Paths coverage with Algorithm.ALGORITHM_SHA224
    cryptographic_3 = Cryptographic()
    str_3 = cryptographic_3.hash(Algorithm.ALGORITHM_SHA224)
    # Paths coverage with Algorithm.ALGORITHM_SHA256
    cryptographic_4

# Generated at 2022-06-25 20:31:35.159892
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash()
    str_2 = cryptographic_1.hash(algorithm = Algorithm.SHA256)
    assert isinstance(str_1, str)
    assert isinstance(str_2, str)


# Generated at 2022-06-25 20:31:36.108038
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = cryptographic.Cryptographic()
    assert cryptographic_0.hash() is not None
