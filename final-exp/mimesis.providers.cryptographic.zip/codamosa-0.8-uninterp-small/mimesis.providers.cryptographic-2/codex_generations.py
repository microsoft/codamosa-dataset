

# Generated at 2022-06-25 20:29:16.631253
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    print(str_0)


# Generated at 2022-06-25 20:29:20.340546
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    try:
        crypto.hash(algorithm='not_exists')
        assert False
    except Exception as e:
        assert True
    try:
        crypto.hash(algorithm=Algorithm.SHA256)
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-25 20:29:21.505535
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0.hash()


# Generated at 2022-06-25 20:29:24.584151
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash() is not None
    assert cryptographic.hash(algorithm=Algorithm.MD5) is not None
    assert cryptographic.hash(Algorithm.MD5) is not None


# Generated at 2022-06-25 20:29:27.743372
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    list_0 = []
    cryptographic_0 = Cryptographic(*list_0)
    str_0 = cryptographic_0.hash()
    assert str_0 is not None


# Generated at 2022-06-25 20:29:30.918363
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    Algorithm_enumerator = Algorithm
    hash_0 = cryptographic_0.hash(Algorithm_enumerator.SHA1)
    assert len(hash_0) == 40


# Generated at 2022-06-25 20:29:35.744743
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test case for method hash of class Cryptographic"""

    list_0 = []
    cryptographic_0 = Cryptographic(*list_0)
    str_0 = cryptographic_0.hash()
    assert str_0 == '49c94e6d7b8f8b4ba97d901d4e4d1b67'


# Generated at 2022-06-25 20:29:37.975046
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    str_1 = cryptographic_0.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:29:41.297050
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    list_0 = []
    cryptographic_0 = Cryptographic(*list_0)
    str_0 = cryptographic_0.hash()
    assert str_0
    assert len(str_0)


# Generated at 2022-06-25 20:29:47.597274
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    list_0 = []
    cryptographic_0 = Cryptographic(*list_0)
    cryptographic_0.seed = 'b'
    assert cryptographic_0.hash() == 'e5649746f00d15c113b74dca6caf2b20e9c9dc84718d3c3acaa3f00b6f020601', "Error while executing test_Cryptographic_hash."


# Generated at 2022-06-25 20:29:59.411461
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.SHA224)
    assert str_0



# Generated at 2022-06-25 20:30:03.656618
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() in [
        'MD5',
        'SHA1',
        'SHA224',
        'SHA256',
        'SHA384',
        'SHA512',
        'blake2b',
        'blake2s',
    ]

test_Cryptographic_hash()


# Generated at 2022-06-25 20:30:05.973833
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    # Create instance
    cryptographic_0 = Cryptographic()

    # Call test method
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:30:13.107905
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    password = '6872b376-6b59-4ee0-b3e2-2c957cbe1561'
    seed = 0
    provider = Cryptographic(seed)
    cryptographic_0 = Cryptographic(seed)
    str_0 = cryptographic_0.hash(Algorithm.SHA256)
    assert isinstance(provider.hash(Algorithm.SHA256), str)



# Generated at 2022-06-25 20:30:15.498283
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert str_0 is not None
    assert type(str_0) is str


# Generated at 2022-06-25 20:30:18.016781
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    seed = 1234
    cryptographic = Cryptographic(seed=seed)
    assert (cryptographic.hash() == cryptographic.hash())



# Generated at 2022-06-25 20:30:20.609991
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:30:23.338357
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    str_0 = Cryptographic().hash()

    assert str_0 is not None and str_0 != "" and isinstance(str_0, str)


# Generated at 2022-06-25 20:30:31.995141
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Testing method hash
    # Algorithm(s) to test the method
    algorithm = Algorithm.SHA512
    expected_result = 'b03a9efc722b44a091af7e0030b2d8e4b4a26f2a4f4ba3c3a71927c83d4dbf1877d0b8f70fd6a80a6e9a6d58e8a358a94c2e07f3b01ab3a845f89ebcfe1b0b33'
    actual_result = Cryptographic().hash(algorithm)
    assert expected_result == actual_result


# Generated at 2022-06-25 20:30:33.953275
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    result = cryptographic.hash()
    assert result.isalnum()


# Generated at 2022-06-25 20:31:00.668168
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    str_0 = cryptographic.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:31:10.531481
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.SHA512)
    assert str_0 == '1fbf8b0020d40122d44f670ea3025a53b0ec83e0040ebd0e9b2a0df1ee3b4d04f4' \
                    '96cd4a0370f5ccd9f9a214a299ba43eefa48d3cf0e45c734e60b98ddfc7e87e1'
    assert str_0 == algorithmic_data_provider_0.hash(Algorithm.SHA512)
    assert str_0 == cryptographic_0.hash(Algorithm.SHA512)
    assert str_0 == algorithmic_data_provider_0.hash(Algorithm.SHA512)
   

# Generated at 2022-06-25 20:31:12.700235
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:31:13.686928
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()

# Generated at 2022-06-25 20:31:14.837246
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert isinstance(cryptographic.hash(), str)

# Generated at 2022-06-25 20:31:18.111879
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Arrange
    cryptographic_0 = Cryptographic()
    # Act
    str_0 = cryptographic_0.hash()
    # Assert
    assert str_0 is not None


# Generated at 2022-06-25 20:31:19.954547
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(str_0) == 64


# Generated at 2022-06-25 20:31:21.793356
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()

    assert crypto.hash() != None


# Generated at 2022-06-25 20:31:24.127674
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:31:25.417047
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    hash = cryptographic.hash()
    assert len(hash) > 0
