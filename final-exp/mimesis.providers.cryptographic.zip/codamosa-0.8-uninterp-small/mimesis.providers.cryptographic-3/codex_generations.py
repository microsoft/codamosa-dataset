

# Generated at 2022-06-25 20:29:11.197019
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash() != None
    assert cryptographic.hash(algorithm=Algorithm.SHA384) != None


# Generated at 2022-06-25 20:29:12.476320
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0.hash(Algorithm.SHA224)


# Generated at 2022-06-25 20:29:18.122154
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("\tTesting method hash...")
    for algorithm in Algorithm:
        # Print some of the algorithm values (not all of them)
        if algorithm in [Algorithm.MD5, Algorithm.SHA1, Algorithm.SHA224, Algorithm.SHA256, Algorithm.SHA384,
                         Algorithm.SHA512]:
            print("\t\tTesting {}...".format(algorithm))
            cryptographic_0 = Cryptographic()
            hash = cryptographic_0.hash(algorithm)
            if not isinstance(hash, str):
                print("FAIL")
                print("\t\tThe cryptographic hash was not type string.")
                return False
            print("PASS")
    return True


# Generated at 2022-06-25 20:29:20.437054
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash() == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-25 20:29:23.421110
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_0 = cryptographic_0.hash(algorithm = Algorithm.SHA512)
    assert isinstance(hash_0, str)
    assert len(hash_0) == 128



# Generated at 2022-06-25 20:29:25.358155
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    cryptographic.hash(algorithm=Algorithm.SHA256)



# Generated at 2022-06-25 20:29:35.787434
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test cases for method hash of class Cryptographic"""

    cryptographic_0 = Cryptographic()
    algorithm_0 = Algorithm.MD5
    assert isinstance(cryptographic_0.hash(algorithm_0), str)

    cryptographic_1 = Cryptographic(use_cache=False)
    algorithm_1 = Algorithm.SHA512
    assert isinstance(cryptographic_1.hash(algorithm_1), str)

    cryptographic_2 = Cryptographic(use_cache=False, seed=117)
    algorithm_2 = Algorithm.SHA256
    assert isinstance(cryptographic_2.hash(algorithm_2), str)

    cryptographic_3 = Cryptographic()
    algorithm_3 = Algorithm.SHA1
    assert isinstance(cryptographic_3.hash(algorithm_3), str)


# Generated at 2022-06-25 20:29:43.810003
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic(seed=0)
    assert cryptographic.hash() == 'd10ee6756f47b6a19f8e08f3ffc6fd35'
    cryptographic = Cryptographic(seed=1)
    assert cryptographic.hash() == 'a098afc57b1d0e77f7f1a0fb9dee6d57'
    cryptographic = Cryptographic(seed=2)
    assert cryptographic.hash() == '76c5e079d3a3415f5e4c4141ba4e4fc7'
    cryptographic = Cryptographic(seed=3)
    assert cryptographic.hash() == 'bdb33852ce41ca72b680d5c5f0efcc28'
    cryptographic = Cryptographic(seed=4)

# Generated at 2022-06-25 20:29:45.805757
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash() != None


# Generated at 2022-06-25 20:29:53.353153
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test case for testing hash of class Cryptographic"""
    cryptographic_0 = Cryptographic()
    hashed_data = cryptographic_0.hash()
    assert len(hashed_data) == 64
    assert type(hashed_data) == str

    hashed_data = cryptographic_0.hash(Algorithm.MD5)
    assert len(hashed_data) == 32
    assert type(hashed_data) == str


# Generated at 2022-06-25 20:30:02.371300
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    # No error
    cryptographic_0.hash()
    cryptographic_0.hash()

# Generated at 2022-06-25 20:30:08.345303
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic(seed=12345)

# Generated at 2022-06-25 20:30:17.718993
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic(seed=42)

    hash_1 = cryptographic_0.hash(algorithm=Algorithm.SHA512)
    assert hash_1 == 'a98d06890b57c30f9a9d57548d648b8bbbffc6e0a6b26dd6b8a8c24f6d59db6a5c5e5cc8f19c5a2a67b23df388a5d8c5a5f5f5b5dacd0cf8c4a50adbefbe3f3f'
    hash_2 = cryptographic_0.hash(algorithm=Algorithm.SHA224)

# Generated at 2022-06-25 20:30:27.187714
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    algorith = ['blake2b', 'blake2s', 'md4', 'md5', 'md5-sha1', 'mdc2', 'ripemd160', 'sha1', 'sha224', 'sha256', 'sha384', 'sha512', 'sha3-224', 'sha3-256', 'sha3-384', 'sha3-512', 'shake-128', 'shake-256']
    import random
    i = random.randint(0, len(algorith)-1)
    print('Testing Cryptographic().hash with: \n')
    print('Algorithm:', algorith[i])
    print('Outcome:', Cryptographic().hash(Algorithm(algorith[i])))


# Generated at 2022-06-25 20:30:31.127345
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initialization of class Cryptographic
    cryptographic_0 = Cryptographic()
    # Call method hash of class Cryptographic
    result = cryptographic_0.hash()


# Generated at 2022-06-25 20:30:33.255630
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    result = cryptographic.hash(Algorithm.SHA3_224)
    assert isinstance(result, str)


# Generated at 2022-06-25 20:30:41.060233
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()

# Generated at 2022-06-25 20:30:45.950018
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    _hash = Cryptographic().hash()
    assert isinstance(_hash, str)
    assert (len(_hash) == hashlib.sha256(Cryptographic().uuid().encode()).hexdigest().__len__())


# Generated at 2022-06-25 20:30:56.338502
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    for _ in range(100):
        assert len(cryptographic.hash(Algorithm.MD5)) == 32
        assert len(cryptographic.hash(Algorithm.SHA1)) == 40
        assert len(cryptographic.hash(Algorithm.SHA256)) == 64
        assert len(cryptographic.hash(Algorithm.SHA512)) == 128
        assert len(cryptographic.hash(Algorithm.BLAKE2B)) == 128
        assert len(cryptographic.hash(Algorithm.BLAKE2S)) == 64


# Generated at 2022-06-25 20:31:05.762700
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() == '5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c5b5c'


# Generated at 2022-06-25 20:31:22.084845
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash(Algorithm.SHA3_224) is not None


# Generated at 2022-06-25 20:31:29.174007
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  cryptographic_hash_0 = Cryptographic().hash()
  assert len(cryptographic_hash_0) == 64
  assert cryptographic_hash_0 == "8a7fd24a3e21fd7d9a9e871e7f6c62efa7e18a4d64e4b4afe4b4f7b938e8c865"
  cryptographic_hash_1 = Cryptographic().hash()
  assert len(cryptographic_hash_1) == 64
  assert cryptographic_hash_1 == "41be30d6f8c6b707522dfebac6b0d3c44e8a8013006ecb1c69c50d3dd0c40e21"
  cryptographic_hash_2 = Cryptographic().hash()
  assert len(cryptographic_hash_2) == 64
 

# Generated at 2022-06-25 20:31:32.865745
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    ans = cryptographic_0.hash()
    assert len(ans) == 40
    assert isinstance(ans, str)


# Generated at 2022-06-25 20:31:40.827483
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # case 0
    cryptographic_0 = Cryptographic()
    result_0 = cryptographic_0.hash()
    assert (result_0 == "e24b8b2c158f1e69b2636fcb0017e9d9") == True
    # case 1
    cryptographic_1 = Cryptographic()
    result_1 = cryptographic_1.hash(algorithm=Algorithm.MD4)
    assert (result_1 == "7afd6764d2cd60c1f894c0d3f4cc4b20") == True
    # case 2
    cryptographic_2 = Cryptographic()
    result_2 = cryptographic_2.hash(algorithm=Algorithm.MD5)
    assert (result_2 == "5c6ef5b5d73c6bdb951e2c7243c48e43")

# Generated at 2022-06-25 20:31:50.065470
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()

    h1 = c.hash()
    assert(c.hash() != h1)

    h2 = c.hash()
    assert(h1 != h2)

    assert(c.hash(Algorithm.MD5) != c.hash(Algorithm.SHA1))
    assert(c.hash(Algorithm.SHA1) != c.hash(Algorithm.SHA224))
    assert(c.hash(Algorithm.SHA3_224) != c.hash(Algorithm.SHA3_256))
    assert(c.hash(Algorithm.SHA3_384) != c.hash(Algorithm.SHA3_512))


# Generated at 2022-06-25 20:31:57.057006
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash(Algorithm.MD5) == '518e9e1c4b26aef18dfc8ac3ac3f36d1'
    assert cryptographic_0.hash(Algorithm.SHA1) == '5f54b43e99d5e5f5d9101e9e7c54e6d9a0145cb2'
    assert cryptographic_0.hash(Algorithm.SHA224) == '64f0c8f66d1e7a397b78a1b7c8ae6f61839f5711e04914a08a8b3a3'

# Generated at 2022-06-25 20:31:59.524255
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0.hash(algorithm=None)


# Generated at 2022-06-25 20:32:08.518981
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    print(cr.hash())
    print(cr.hash(algorithm=Algorithm.MURMUR3_128))
    print(cr.hash(algorithm=Algorithm.MURMUR3_32))
    print(cr.hash(algorithm=Algorithm.MD5))
    print(cr.hash(algorithm=Algorithm.SHA1))
    print(cr.hash(algorithm=Algorithm.SHA224))
    print(cr.hash(algorithm=Algorithm.SHA256))
    print(cr.hash(algorithm=Algorithm.SHA384))
    print(cr.hash(algorithm=Algorithm.SHA3_224))
    print(cr.hash(algorithm=Algorithm.SHA3_256))

# Generated at 2022-06-25 20:32:10.347542
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert  Cryptographic().hash() is not None


# Generated at 2022-06-25 20:32:19.117779
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert isinstance(cryptographic_0.hash(), str) is True
    assert cryptographic_0.hash() == '85c971bb5e5a5f14a5f5c5e5a5f5c5e5a5f5c5e5a5f5c5e5a5f5c5e5a5f5c5e5a'
    assert cryptographic_0.hash() == '850c901b5e5a5f14a5f5c5e5a5f5c5e5a5f5c5e5a5f5c5e5a5f5c5e5a5f5c5e5a'

# Generated at 2022-06-25 20:33:00.225601
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash()


# Generated at 2022-06-25 20:33:01.913259
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash = cryptographic_0.hash()
    print(hash)

# Generated at 2022-06-25 20:33:03.418718
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm[0]) == crypto.hash(Algorithm[0])


# Generated at 2022-06-25 20:33:05.931609
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_0 = cryptographic_0.hash()
    assert type(hash_0) is str
    hash_1 = cryptographic_0.hash(Algorithm.SHA256)
    assert type(hash_1) is str


# Generated at 2022-06-25 20:33:08.424014
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash() is not None
    assert cryptographic.hash() != cryptographic.hash()


# Generated at 2022-06-25 20:33:14.879759
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    # Test with default parameters
    algorithm = Algorithm.MD5
    assert isinstance(cryptographic.hash(), str)
    # Test with parameter algorithm
    assert isinstance(cryptographic.hash(algorithm), str)


# Generated at 2022-06-25 20:33:21.117512
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() is not None
    assert cryptographic_0.hash(algorithm=Algorithm.MD5) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA1) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA224) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA256) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA384) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.SHA512) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.BLAKE2B) is not None
    assert cryptographic_0.hash(algorithm=Algorithm.BLAKE2S) is not None
    assert cryptographic_

# Generated at 2022-06-25 20:33:29.446368
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(Algorithm.SHA1) == 'e72c58b6474c7f91e4a67be7d661ad0ec4b7a80f'
    assert cryptographic.hash(Algorithm.SHA224) == '06ea8f4229d4b4d7b80a0f8e7e49c68bcda5c5e5cc5ba8dcb07a903'
    assert cryptographic.hash(Algorithm.SHA256) == '6e0a6a0b8f7a1035b945a7c0f34d6f73a0e0a62233c6dd3a6a0f6d9f6ccc81f2c'

# Generated at 2022-06-25 20:33:30.738740
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    cryptographic_0 = Cryptographic()
    cryptographic_0.hash()


# Generated at 2022-06-25 20:33:34.682924
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_0 = cryptographic_0.hash(algorithm=Algorithm.MD5)
    assert isinstance(hash_0,str)
