

# Generated at 2022-06-25 20:30:25.350920
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(algorithm=Algorithm.SHA224) is not None


# Generated at 2022-06-25 20:30:32.137805
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    mimesis_enums_1 = Algorithm()
    str_0 = cryptographic_0.hash(algorithm=mimesis_enums_1.SHA1())
    assert isinstance(str_0, str)
    # Testing the invariant
    assert len(str_0) == 40
    str_1 = cryptographic_0.hash(algorithm=mimesis_enums_1.SHA256())
    assert isinstance(str_1, str)
    # Testing the invariant
    assert len(str_1) == 64
    str_2 = cryptographic_0.hash(algorithm=mimesis_enums_1.SHA512())
    assert isinstance(str_2, str)
    # Testing the invariant
    assert len(str_2) == 128

# Generated at 2022-06-25 20:30:36.579358
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Algorithm
    cr = Cryptographic()
    alg = Algorithm.MD5
    try:
        cr.hash(alg)
        assert True
    except NonEnumerableError:
        assert False


# Generated at 2022-06-25 20:30:37.760937
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm = Algorithm.MD5
    var_0 = cryptographic_0.hash(algorithm)


# Generated at 2022-06-25 20:30:39.858026
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    seed = 12460
    cryptographic = Cryptographic(seed)
    print(cryptographic.hash())



# Generated at 2022-06-25 20:30:50.594187
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    assert cryptographic_1.hash(
        algorithm=Algorithm.SHA512) == '40a8a097dda01d5c2f4a68cad8d7f094e4a6a5b6c8b622ce54bc925bef5e5257abb0ab3b088d0c1f55a6a1612069c0758f51c6efb7e71b0f3abfe5b5f5f5f5f5f5'
    assert cryptographic_1.hash(
        algorithm=Algorithm.SHA256) == '4e4b2ce3020a17951b1ffb446d49adf7b0e1f8c176d92b066188e84cd41dd944'

# Generated at 2022-06-25 20:30:53.058947
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:30:55.596118
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    var_1 = cryptographic_1.hash()


# Generated at 2022-06-25 20:31:00.193592
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    with raises(NotImplementedError):
        cryptographic_0.hash('ferret')


if __name__ == '__main__':
    test_case_0()
    test_Cryptographic_hash()

# Generated at 2022-06-25 20:31:05.919451
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_0._seed = "test"
    assert cryptographic_0.hash().__class__.__name__ == 'str'
    assert cryptographic_0.hash().__class__.__name__ == 'str'
