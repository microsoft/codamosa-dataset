

# Generated at 2022-06-25 20:29:17.703766
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    mod_obj_0 = Cryptographic()

    # Test case 0
    mod_param_0 = Algorithm.BLAKE2B

    # Test case 1
    mod_param_1 = Algorithm.SHA256

    # Test case 2
    mod_param_2 = Algorithm.SHA512

    # Test case 3
    mod_param_3 = Algorithm.SHA3_224

    # Test case 4
    mod_param_4 = Algorithm.SHA3_256

    # Test case 5
    mod_param_5 = Algorithm.SHA3_512

    # Test case 6
    mod_param_6 = Algorithm.MD5

    # Test case 7
    mod_param_7 = Algorithm.SHA1



# Generated at 2022-06-25 20:29:21.583407
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print('Testing hash')
    print('Testing hasher with none algorithm')
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()
    print('Testing hasher with md5 algorithm')
    var_1 = cryptographic_0.hash(algorithm=Algorithm.MD5)


# Generated at 2022-06-25 20:29:27.562366
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Initialization
    cryptographic_0 = Cryptographic()
    var_1 = cryptographic_0.hash()
    assert var_1 != None, "Hash generation failed"
    assert type(var_1) == str, "Hash generated is not of correct type"
    assert var_1 == "f856bf37babf2d760eb00b6e4cd8f4e9c25d07d4", "Hash generated is incorrect"


# Generated at 2022-06-25 20:29:29.201473
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:29:32.599034
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()
    assert isinstance(var_0, str)
    assert len(var_0) == 40


# Generated at 2022-06-25 20:29:34.405917
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:29:37.353002
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():  # noqa: D103
    cryptographic_0 = Cryptographic()

    # undefined params
    assert cryptographic_0.hash() is not None
    # enum params
    assert cryptographic_0.hash(Algorithm.SHA512) is not None

# Generated at 2022-06-25 20:29:42.284818
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash_1 = Algorithm.BLAKE2B
    hash_2 = Algorithm.BLAKE2B
    cryptographic_0 = Cryptographic()
    result = cryptographic_0.hash(algorithm=hash_1)
    assert result == 'd0a1cd8434f053675b88c0dc58e7eab40b1a4b9c038d4e4c4adf42ac4eb0a231'


# Generated at 2022-06-25 20:29:49.409072
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()

    # test with specified value
    alg0 = Algorithm.SHA256
    assert cryptographic.hash(algorithm=alg0) == cryptographic.hash(algorithm=alg0)

    # test with unspecified value, expect random result
    alg1 = Algorithm.MD5
    alg2 = Algorithm.SHA512
    assert cryptographic.hash(algorithm=alg1) != cryptographic.hash(algorithm=alg2)


# Generated at 2022-06-25 20:29:54.315950
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(Algorithm.MD5)
    assert var_0 == cryptographic_0.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:30:07.132478
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    algorithm = [Algorithm.SHA1, Algorithm.SHA224, Algorithm.SHA256, Algorithm.SHA384, Algorithm.SHA512, Algorithm.MD5, Algorithm.BLAKE2B, Algorithm.BLAKE2S, Algorithm.SHA3_224, Algorithm.SHA3_256, Algorithm.SHA3_384, Algorithm.SHA3_512, Algorithm.SHA512_224, Algorithm.SHA512_256]
    for i in algorithm:
        print('Generating hash value with {} algorithm'.format(i))
        print('Hash:',cryptographic_1.hash(algorithm=i))


# Generated at 2022-06-25 20:30:09.828321
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()

#Unit test for method mnemonic_phrase of class Cryptographic

# Generated at 2022-06-25 20:30:14.035694
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_2 = Cryptographic()

    # Test 1
    var_1 = cryptographic_2.hash(Algorithm.SHA512)

    # Test 2
    var_2 = cryptographic_2.hash(Algorithm.SHA256)



# Generated at 2022-06-25 20:30:16.481487
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    algorithm = "md5"
    assert cryptographic.hash(algorithm) == "c37d66e3bb1d11585421d62cce1304c4"

# Generated at 2022-06-25 20:30:22.403112
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(
        algorithm=Algorithm.MD5,
    )
    # assert if expected value is equal to var_0
    assert var_0 == 'b4d4b4e2fdb6a834e05b0e9f7d20b35c'



# Generated at 2022-06-25 20:30:26.364175
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert(cryptographic.hash() == 'c49a9abf1e8c9f6f0c6b1d6de68b8fb0f1207b0bbcad9b0fcbf7d874276b3caf')


# Generated at 2022-06-25 20:30:27.789493
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto_0 = Cryptographic()
    print("Hash result: ", crypto_0.hash())



# Generated at 2022-06-25 20:30:29.876973
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm_0 = Algorithm.MD5
    hash_0 = cryptographic_0.hash(algorithm_0)
    print(hash_0)


# Generated at 2022-06-25 20:30:38.449957
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    algo = crypto._get_enum_type(Algorithm)
    hashes = [crypto.hash(algorithm=algo.SHA1), crypto.hash(algorithm=algo.SHA224),
              crypto.hash(algorithm=algo.SHA256), crypto.hash(algorithm=algo.SHA384),
              crypto.hash(algorithm=algo.SHA512)]
    for hash_ in hashes:
        assert len(hash_) == 40 or len(hash_) == 56 or len(hash_) == 64 \
               or len(hash_) == 96 or len(hash_) == 128


# Generated at 2022-06-25 20:30:40.482758
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    var_1 = cryptographic_1.hash()


# Generated at 2022-06-25 20:31:07.469806
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Setup
    cryptographic_0 = Cryptographic()
    cryptographic_0._random = MagicMock()

    # Testing method hash of class Cryptographic
    assert cryptographic_0.hash(Algorithm.CRC32() is None)
    assert cryptographic_0.hash(Algorithm.MD5() is None)
    assert cryptographic_0.hash(Algorithm.SHA1() is None)
    assert cryptographic_0.hash(Algorithm.SHA224() is None)
    assert cryptographic_0.hash(Algorithm.SHA256() is None)
    assert cryptographic_0.hash(Algorithm.SHA384() is None)
    assert cryptographic_0.hash(Algorithm.SHA512() is None)


# Generated at 2022-06-25 20:31:13.100348
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    alg = Algorithm.SHA256
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(alg)


# Generated at 2022-06-25 20:31:16.213848
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    var = cryptographic.hash(Algorithm.SHA512)
    assert cryptographic.hash(Algorithm.SHA512) == var



# Generated at 2022-06-25 20:31:18.836059
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    cryptographic.hash()

# Generated at 2022-06-25 20:31:27.035170
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Init class
    cryptographic_1 = Cryptographic() # noqa: E501

    # Test method hash
    var_1 = cryptographic_1.hash(Algorithm.MD5)

    # Test method hash
    var_2 = cryptographic_1.hash(Algorithm.SHA1)

    # Test method hash
    var_3 = cryptographic_1.hash(Algorithm.SHA224)

    # Test method hash
    var_4 = cryptographic_1.hash(Algorithm.SHA256)

    # Test method hash
    var_5 = cryptographic_1.hash(Algorithm.SHA384)

    # Test method hash
    var_6 = cryptographic_1.hash(Algorithm.SHA512)

    # Test method hash
    var_7 = cryptographic_1.hash()



# Generated at 2022-06-25 20:31:30.511686
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash(Algorithm.BLAKE2B) is not None


# Generated at 2022-06-25 20:31:33.066673
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:31:39.640672
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == '6518e8a3a0aa1e2c0e10a9a849092cfbe062cbdf'
    assert crypto.hash(Algorithm.SHA256) == '9079e0dec37bafc6b7d30e3214293250fef8dfea6719e9c9f9b1315b8c79a349'
    assert crypto.hash(Algorithm.MD5) == '7bdba2fb0a83fd9e28c3b0d12f2a0ecc'


# Generated at 2022-06-25 20:31:47.085859
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Check method hash."""
    for _ in range(10):
        assert len(Cryptographic().hash()) == 32
        assert len(Cryptographic().hash(Algorithm.SHA1)) == 40
        assert len(Cryptographic().hash(Algorithm.SHA224)) == 56
        assert len(Cryptographic().hash(Algorithm.SHA384)) == 96
        assert len(Cryptographic().hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-25 20:31:48.803396
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    hash_1 = cryptographic_1.hash()
    assert hash_1 is not None


# Generated at 2022-06-25 20:34:57.347211
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert len(cryptographic_0.hash()) == 40

# Generated at 2022-06-25 20:35:05.060898
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(Algorithm.SHA512) == 'a6a5c02f5cc6e5d6a5bf6f1707f87b8d53c2030b0e17d5a325e0c0a8f01d94ebacb5f2b788cbbb3d3fbb500b46c39db0adc8a01bfcebacaa5be2e7b926b9d3b3'


# Generated at 2022-06-25 20:35:07.683300
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    m = Cryptographic()
    var_1 = m.hash()

# Generated at 2022-06-25 20:35:17.354927
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic(seed=100)
    var_0 = c.hash(Algorithm.SHA1)
    assert var_0 == '78c7b215e57f04c7e485a4d87e7d2a063635d7b9'
    var_1 = c.hash(Algorithm.MD5)
    assert var_1 == '5c5cca09fb5f5c5e7a62a0f27e7f0e59'
    var_2 = c.hash(Algorithm.SHA256)
    assert var_2 == '28d1870848fbd5118acb743f79c0eba9a2de92c3fb7fd2a77c84a187f5212c0f'
    var_3 = c.hash(Algorithm.SHA384)
   

# Generated at 2022-06-25 20:35:20.418399
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:35:22.137182
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash()


# Generated at 2022-06-25 20:35:32.444335
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()

    # case 1
    var_1 = cryptographic_0.hash(Algorithm.MD5)
    assert var_1

    # case 2
    var_2 = cryptographic_0.hash()
    assert var_2

    # case 3
    var_3 = cryptographic_0.hash(Algorithm.SHA256)
    assert var_3

    # case 4
    var_4 = cryptographic_0.hash(Algorithm.SHA3_512)
    assert var_4

    # case 5
    var_5 = cryptographic_0.hash(Algorithm.BLAKE2B)
    assert var_5

    # case 6
    var_6 = cryptographic_0.hash(Algorithm.SHA512)
    assert var_6

    # case 7

# Generated at 2022-06-25 20:35:35.627332
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:35:39.638977
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_1 = cryptographic_0.hash(algorithm=Algorithm.SHA224)
    print(var_1)


# Generated at 2022-06-25 20:35:45.657205
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()

    # Test Algorithm.MD5
    assert cryptographic.hash(Algorithm.MD5)
    # Test Algorithm.SHA1
    assert cryptographic.hash(Algorithm.SHA1)
    # Test Algorithm.SHA256
    assert cryptographic.hash(Algorithm.SHA256)
    # Test Algorithm.SHA384
    assert cryptographic.hash(Algorithm.SHA384)
    # Test Algorithm.SHA512
    assert cryptographic.hash(Algorithm.SHA512)
    # Test Algorithm.SHA3_224
    assert cryptographic.hash(Algorithm.SHA3_224)
    # Test Algorithm.SHA3_256
    assert cryptographic.hash(Algorithm.SHA3_256)
    # Test Algorithm.SHA3_384
    assert cryptographic.hash(Algorithm.SHA3_384)
    # Test Al