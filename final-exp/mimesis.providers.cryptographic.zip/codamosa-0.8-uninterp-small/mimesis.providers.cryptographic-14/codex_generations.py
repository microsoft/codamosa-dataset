

# Generated at 2022-06-25 20:29:18.430320
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    data_0 = Cryptographic.hash(Algorithm.SHA1)
    print(data_0)
    data_1 = Cryptographic.hash()
    print(data_1)
    data_2 = Cryptographic.hash(Algorithm.MD5)
    print(data_2)
    data_3 = Cryptographic.hash(Algorithm.SHA256)
    print(data_3)
    data_4 = Cryptographic.hash(Algorithm.SHA512)
    print(data_4)


# Generated at 2022-06-25 20:29:23.509206
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    algorithm_0 = Algorithm.MD5

    str_0 = '# Gq&+stAd>!V'
    dict_0 = {str_0: str_0}
    cryptographic_0 = Cryptographic(**dict_0)

    # Testing hash method with one parameter
    assert cryptographic_0.hash(algorithm_0) == 'e05315f2d10db8eaff92f20589e3af73'


# Generated at 2022-06-25 20:29:26.001934
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    global obj_0
    global str_0
    obj_0 = Cryptographic()
    str_0 = obj_0.hash()


# Generated at 2022-06-25 20:29:27.053771
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash_0 = Cryptographic.hash(SHA512)

# Generated at 2022-06-25 20:29:37.013841
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic('# Gq&+stAd>!V')
    cryptographic_1 = Cryptographic('$R)R{8%ZJHffe')
    cryptographic_2 = Cryptographic('@OV:Q*LlXBHv')
    cryptographic_3 = Cryptographic('5^5nxv(j+f;8')
    cryptographic_4 = Cryptographic('a"b$VJzA2S/7')
    cryptographic_5 = Cryptographic('o:mIb+"m{l2{')
    cryptographic_6 = Cryptographic('C?>F)RJMY#<A')
    cryptographic_7 = Cryptographic('M+H9T98=tR_;')
    cryptographic_8 = Cryptographic('s)>4f_7c%`e#')
    cryptographic_9 = Cryptographic

# Generated at 2022-06-25 20:29:44.718858
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic(seed=23496)
    str_0 = cryptographic_0.hash()
    assert str_0 == 'b1f7a2a0f7b1a13b67302dfd05f593dfa1309bfca0a19a17'
    str_1 = cryptographic_0.hash(algorithm=Algorithm.MD5)
    assert str_1 == '23c36e1e28d8f7c1243a529e8760816f'
    str_2 = cryptographic_0.hash(algorithm=Algorithm.SHA1)
    assert str_2 == '0dd4a4d65c62b6a0af6d5a611e8a6c5f02bfb7c4'

# Generated at 2022-06-25 20:29:51.956462
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert(len(Cryptographic().hash()) == 64)
    assert(Cryptographic().hash(
        Algorithm.SHA256
    ) == Cryptographic().hash(
        Algorithm.SHA256
    ))
    assert(len(Cryptographic().hash(
        Algorithm.SHA256
    )) == 64)
    assert(Cryptographic().hash(
        Algorithm.SHA512
    ) == Cryptographic().hash(
        Algorithm.SHA512
    ))
    assert(len(Cryptographic().hash(
        Algorithm.SHA512
    )) == 128)


# Generated at 2022-06-25 20:29:55.845937
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == Cryptographic().hash()



# Generated at 2022-06-25 20:30:05.110252
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash('sha256') == 'd9dde848b79c45fddbf28b67e6c8e6ad68ceb2132953b732f9596b8e7a59f0a3' \
                                            and Cryptographic.hash('sha3_384') == '0a90a8e7eaa6f22c0e09d23a38f16a17677f7d15fd9132724093ba3c8bb0a4d4' \
                                                                                     '4a4e9d91447a9a79c45650e8ccb6747' and Cryptographic.hash('sha1') == '04af9f9eac881d2c6b8f6b2ddc80da590d7fef6e'

#

# Generated at 2022-06-25 20:30:09.953212
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    strategy_0 = None
    alg = Algorithm.SHA512
    strategy_1 = Cryptographic(benchmark=False)

    def func_0(arg_0):
        return arg_0
    assert strategy_1.hash(algorithm=alg) == func_0(strategy_0)


# Generated at 2022-06-25 20:30:17.766763
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()

    assert cryptographic_0.hash is not None


# Generated at 2022-06-25 20:30:28.144092
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic('seed')
    assert crypto.hash(Algorithm.MD5) == '6a1b6d9b06e6b1a6a45b6f897c8ea14c'
    assert crypto.hash(Algorithm.SHA1) == '4444bdb5c24bd5d0d8dc0b3f91e5be5e5cb5d0f3'
    assert crypto.hash(Algorithm.SHA224) == 'b9953a1854e955a86b9f933b2054a77c4a2d2bff8eb4bb4f4d4c269b'

# Generated at 2022-06-25 20:30:32.135809
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash() is not None
    assert type(cryptographic.hash()) == str


# Generated at 2022-06-25 20:30:35.618630
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()

    assert cryptographic_0._validate_enum(None, Algorithm) == 'md5'
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:30:38.740267
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    str_1 = cryptographic_0.hash()
    assert str_0 != str_1, "Test failed on line 67"


# Generated at 2022-06-25 20:30:41.372413
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert isinstance(str_0, str)
    assert len(str_0) == 64

# Generated at 2022-06-25 20:30:43.917374
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """ Verify the output.
    """
    cryptography = Cryptographic()
    cryptography.hash()

# Generated at 2022-06-25 20:30:46.620140
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    int_0 = str_0.count("a")


# Generated at 2022-06-25 20:30:51.161417
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    hash_0 = Cryptographic.hash()
    assert hash_0 == 'da39a3ee5e6b4b0d3255bfef95601890'

# Generated at 2022-06-25 20:30:53.591961
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()  # type: ignore


# Generated at 2022-06-25 20:31:07.158537
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()



# Generated at 2022-06-25 20:31:18.641595
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Unit test for Cryptographic.hash()
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    str_1 = cryptographic_0.hash(Algorithm.SHA224)
    str_2 = cryptographic_0.hash(Algorithm.SHA384)
    str_3 = cryptographic_0.hash(Algorithm.SHA3_224)
    str_4 = cryptographic_0.hash(Algorithm.SHA3_256)
    str_5 = cryptographic_0.hash(Algorithm.SHA3_384)
    str_6 = cryptographic_0.hash(Algorithm.SHA3_512)
    str_7 = cryptographic_0.hash(Algorithm.BLAKE2S)
    str_8 = cryptographic_0.hash(Algorithm.BLAKE2B)

# Generated at 2022-06-25 20:31:19.607801
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_0 = cryptographic_1.hash()


# Generated at 2022-06-25 20:31:27.970046
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_obj = Cryptographic()
    assert isinstance(cryptographic_obj.hash(), str)
    assert isinstance(cryptographic_obj.hash(algorithm=Algorithm.SHA256), str)
    assert isinstance(cryptographic_obj.hash(algorithm=Algorithm.SHA1), str)
    assert isinstance(cryptographic_obj.hash(algorithm=Algorithm.SHA512), str)
    assert isinstance(cryptographic_obj.hash(algorithm=Algorithm.MD5), str)
    assert isinstance(cryptographic_obj.hash(algorithm=Algorithm.BLAKE2B), str)
    assert isinstance(cryptographic_obj.hash(algorithm=Algorithm.BLAKE2S), str)
    assert isinstance(cryptographic_obj.hash(algorithm=Algorithm.SHA3_224), str)

# Generated at 2022-06-25 20:31:32.744852
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash()

    assert isinstance(str_1, str)
    assert len(str_1) == 64



# Generated at 2022-06-25 20:31:40.779087
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    string_0 = cryptographic_0.hash(algorithm=Algorithm.MD5)
    string_0 = cryptographic_0.hash(algorithm=Algorithm.MD4)
    string_0 = cryptographic_0.hash(algorithm=Algorithm.RIPEMD160)
    string_0 = cryptographic_0.hash(algorithm=Algorithm.SHA224)
    string_0 = cryptographic_0.hash(algorithm=Algorithm.SHA256)
    string_0 = cryptographic_0.hash(algorithm=Algorithm.SHA384)
    string_0 = cryptographic_0.hash(algorithm=Algorithm.SHA512)
    string_0 = cryptographic_0.hash(algorithm=Algorithm.SHA3_224)

# Generated at 2022-06-25 20:31:44.896112
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.SHA256)
    assert str_0 != None


# Generated at 2022-06-25 20:31:48.804037
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    cryptographic_1 = Cryptographic()
    str_1 = cryptographic_1.hash(Algorithm.SHA256)
    cryptographic_2 = Cryptographic()
    str_2 = cryptographic_2.hash(Algorithm.SHA512)


# Generated at 2022-06-25 20:31:52.865406
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    try:
        str_0 = cryptographic_0.hash()
    except NotImplementedError:
        assert False


# Generated at 2022-06-25 20:31:55.363863
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert(str_0 == '9a284fafba21aab71101677e2c0acb6f')


# Generated at 2022-06-25 20:34:39.667178
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    cryptographic_0 = Cryptographic()
    data = cryptographic_0.hash(algorithm=Algorithm.SHA224)


# Generated at 2022-06-25 20:34:47.255572
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert isinstance(str_0, str)
    assert str_0 == '3b89e8b9e31ce983c068a6040b3cd3e1fd24c56beb30f8e787056b2a7107b4a4'


# Generated at 2022-06-25 20:34:52.968665
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()

    # Test with optional param "algorithm"
    str_0 = cryptographic_0.hash(algorithm=None)

    # Test with no optional param
    str_1 = cryptographic_0.hash()

    assert cryptographic_0.hash(algorithm=None) == cryptographic_0.hash()


# Generated at 2022-06-25 20:35:00.769046
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    instances = [
        Cryptographic(seed=1),
        Cryptographic(seed=1),
        Cryptographic(seed=2),
    ]
    first_hash = instances[0].hash()
    second_hash = instances[1].hash()
    third_hash = instances[2].hash()
    assert first_hash == second_hash
    assert first_hash != third_hash



# Generated at 2022-06-25 20:35:08.120985
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.SHA1)
    assert str_0 != ""
    str_0 = cryptographic_0.hash(Algorithm.SHA2_224)
    assert str_0 != ""
    str_0 = cryptographic_0.hash(Algorithm.SHA2_256)
    assert str_0 != ""
    str_0 = cryptographic_0.hash(Algorithm.SHA2_512)
    assert str_0 != ""
    str_0 = cryptographic_0.hash(Algorithm.SHA2_384)
    assert str_0 != ""
    str_0 = cryptographic_0.hash(Algorithm.SHA2_512_224)
    assert str_0 != ""
    str_0 = cryptographic_0.hash(Algorithm.SHA2_512_256)


# Generated at 2022-06-25 20:35:11.426280
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert cryptographic_0.hash() == '4a63e395a78c64e5dcfa5117b18ec6e3'


# Generated at 2022-06-25 20:35:16.506534
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Variants
    cryptographic_0 = Cryptographic()
    cryptographic_1 = Cryptographic(seed=1)
    cryptographic_2 = Cryptographic(seed=2)

    # Tests
    assert cryptographic_0.hash(Algorithm.SHA3_512) == cryptographic_1.hash(Algorithm.SHA3_512)
    assert cryptographic_1.hash(Algorithm.SHA3_512) != cryptographic_2.hash(Algorithm.SHA3_512)


# Generated at 2022-06-25 20:35:20.707965
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
  cryptographic = Cryptographic()
  str = cryptographic.hash(Algorithm.SHA1)
  if str:
    assert True
  else:
    assert False


# Generated at 2022-06-25 20:35:22.754327
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash(Algorithm.SHA1)



# Generated at 2022-06-25 20:35:32.708127
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0: str = cryptographic_0.hash(Algorithm.SHA512)
    assert str_0 == '9386582d67c10e2a8cc6899b56d83bba82c1f746bb811a9b7a03bde2300b7edc69f5b6f4b637e2e0ff92f865c5e9ce5c5f3bb3b8355a98a2d40daf61e89deaa8'
    assert str_0 == cryptographic_0.hash(algorithm=Algorithm.SHA256)
    cryptographic_1 = Cryptographic()
    str_1: str = cryptographic_1.hash(Algorithm.SHA384)