

# Generated at 2022-06-25 20:29:18.905592
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() # type: ignore


# Generated at 2022-06-25 20:29:19.792585
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert True


# Generated at 2022-06-25 20:29:29.579428
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("Testing hash in Cryptographic...")
    cryptographic_3 = Cryptographic(seed=0)
    assert cryptographic_3.hash() == '0828b0a99b39e12b8c1d9deff7bda6a9'
    cryptographic_4 = Cryptographic()
    assert cryptographic_4.hash() == '09bdca5d5b5e5bcef4b4a4b4c4d4b4c4'
    cryptographic_5 = Cryptographic(seed=0)
    assert cryptographic_5.hash(Algorithm.SHA224) == 'fa3c3f3d7f9b9581e11bc8f3a3d3e3d3e3d3e3d3e3d3e3d3e3d3e3d'


# Generated at 2022-06-25 20:29:33.027727
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm = Algorithm.MD5
    var_0 = cryptographic_0.hash(algorithm=algorithm)
    assert var_0 is not None


# Generated at 2022-06-25 20:29:36.800012
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash(): 
    cryptographic = Cryptographic()
    try:
        assert cryptographic.hash(algorithm=Algorithm.SHA1) == '9f0cd7961d2e7a6d810a1a871ad0ba5b2e5bb5e5'
    except AssertionError: 
        raise


# Generated at 2022-06-25 20:29:39.376871
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic(seed=4978)
    assert cryptographic_0.hash() == '2d9981a95b0a8a2cff76b95207b007a7'


# Generated at 2022-06-25 20:29:42.790073
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    ##################
    # Test null data #
    ##################
    cryptographic_0 = Cryptographic()

    assert cryptographic_0.hash(algorithm = Algorithm.SHA512) is not None


# Generated at 2022-06-25 20:29:46.097027
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    hash_0 = cryptographic_0.hash(Algorithm.MD5)
    assert hash_0 is not None



# Generated at 2022-06-25 20:29:50.851360
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash() == 'e0bf8a6e-a1ef-405c-9b37-8d072d1344e0'



# Generated at 2022-06-25 20:29:53.584054
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(Algorithm.SHA256) is not None


# Generated at 2022-06-25 20:30:16.026975
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    var_1 = 'md5'
    assert cryptographic_1.hash(algorithm='md5') == cryptographic_1.hash(algorithm=var_1)


# Generated at 2022-06-25 20:30:18.219950
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    c = Cryptographic()
    assert c.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:30:26.404478
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    assert cryptographic.hash(Algorithm.MD5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert cryptographic.hash(Algorithm.SHA512) == 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e'

# Generated at 2022-06-25 20:30:27.825937
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()  # type: Cryptographic

    assert cryptographic.hash().isalnum()



# Generated at 2022-06-25 20:30:29.419322
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()

# Generated at 2022-06-25 20:30:38.708176
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    cryptographic_0 = Cryptographic()
    string_0 = cryptographic_0.hash()
    string_1 = cryptographic_0.hash(Algorithm.BLAKE2S)
    string_2 = cryptographic_0.hash(Algorithm.BLAKE2B)
    string_3 = cryptographic_0.hash(Algorithm.SHA1)
    cryptographic_0.seed(0)
    cryptographic_0.random.seed(0)
    cryptographic_0.random.jumpahead(0)
    print(string_0)
    print(string_1)
    print(string_2)
    print(string_3)


# Generated at 2022-06-25 20:30:39.941178
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash().isalnum()


# Generated at 2022-06-25 20:30:46.727288
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    var_0 = Cryptographic()
    var_1 = var_0.hash(Algorithm.BLAKE2B)
    assert var_1 == '2b9eacf7bdcc6e94d6cfd7026a8b6f98fbcb38c2ffc6e64d6d421b622daa1906'


# Generated at 2022-06-25 20:30:50.130374
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    var_1 = cryptographic_0.hash(algorithm=None)


# Generated at 2022-06-25 20:30:51.790605
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # test case 0
    algorithm = Algorithm.SHA3_512
    cryptographic_0 = Cryptographic()
    var_0 = cryptographic_0.hash(algorithm)


# Generated at 2022-06-25 20:31:44.153416
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    result = cryptographic.hash(Algorithm.BLAKE2B)
    assert isinstance(result, str)
    result = cryptographic.hash()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:31:49.658280
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    seed = 0
    cryptographic_0 = Cryptographic(seed=seed)
    algorithm = Algorithm.MD5
    result_0 = cryptographic_0.hash(algorithm=algorithm)
    expected_result = '64bc18e7c4657f572d4f4e4a8b4b7f34'
    # Assert that the expected result is very close to the result
    assert expected_result == result_0
