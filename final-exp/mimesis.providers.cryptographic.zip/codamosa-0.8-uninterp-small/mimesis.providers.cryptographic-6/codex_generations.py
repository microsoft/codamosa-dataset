

# Generated at 2022-06-25 20:29:41.094677
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    cryptographic_0 = Cryptographic()
    cryptographic_0.hash(Algorithm.MD5)


# Generated at 2022-06-25 20:29:43.413758
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert not cryptographic_0.hash()


# Generated at 2022-06-25 20:29:51.355537
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    n_key = 'sha3_512'
    n_expected = '1a7f5c54dc8bac7f7d20b48c9d47b8c8c723a5bc26d5df1a2a8a5c5f9e9470d5c5d5ef835c956097f67826e08adc2e857c95e5dd0b3f3a3f09a8c7ebb7928a0e'
    n_actual = Cryptographic().hash(Algorithm[n_key])


# Generated at 2022-06-25 20:29:58.773068
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algo = Algorithm.SHA256
    hash_0 = cryptographic_0.hash(algorithm=algo)
    assert(algo.value in hash_0)
    #assert(hashlib.sha256(str(uuid.uuid4).encode()).hexdigest() == hash_0)


# Generated at 2022-06-25 20:30:00.471523
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash().isalnum() == True


# Generated at 2022-06-25 20:30:05.250316
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():

    # Set up test data
    data = [
        ({"algorithm": "sha224"},),
        ({"algorithm": "sha256"},),
        ({"algorithm": "sha384"},),
        ({"algorithm": "sha512"},),
        ({"algorithm": "md5"},),
        ({"algorithm": "sha1"},),
    ]

    for (key,value) in data:
        assert Cryptographic().hash(key) == value



# Generated at 2022-06-25 20:30:09.655825
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    expected = '2a438e4c8d928ae4e36acf5ae43295fa3c1714cf'
    assert crypto.hash(Algorithm.MD5) == expected


# Generated at 2022-06-25 20:30:14.342606
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    assert cryptographic_0.hash(Algorithm.MD5) is not None
    assert cryptographic_0.hash(Algorithm.SHA_256) is not None
    assert cryptographic_0.hash(Algorithm.SHA_512) is not None


# Generated at 2022-06-25 20:30:22.917287
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    cryptographic_1 = Cryptographic()
    str_0 = cryptographic_0.mnemonic_phrase()
    str_1 = cryptographic_1.mnemonic_phrase()
    hash_0 = cryptographic_0.hash()
    hash_1 = cryptographic_1.hash()
    bool_0 = hash_0 == cryptographic_1.hash()
    bool_1 = cryptographic_0.hash() == hash_1
    bool_2 = cryptographic_0.hash() == cryptographic_1.hash()


# Generated at 2022-06-25 20:30:25.254318
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()
    assert str_0.isalnum()


# Generated at 2022-06-25 20:31:35.014165
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    try:
        assert (Cryptographic.hash() == Cryptographic.hash())
    except AssertionError:
        return 1
    return 0


# Generated at 2022-06-25 20:31:36.744318
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:31:40.025618
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    # Test for Algorithm.SHA256
    cryptographic_0.hash(Algorithm.SHA256)


# Generated at 2022-06-25 20:31:43.293089
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    algorithm = Algorithm.MD5
    str_0 = cryptographic_0.hash(algorithm)

# Generated at 2022-06-25 20:31:46.854974
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_1 = Cryptographic()
    Algorithm_0 = cryptographic_1.get_enum(Algorithm)
    str_1 = cryptographic_1.hash(Algorithm_0.MD5)


# Generated at 2022-06-25 20:31:47.620590
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert isinstance(Cryptographic().hash(), str)


# Generated at 2022-06-25 20:31:48.594856
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_ = Cryptographic()
    str_ = cryptographic_.hash()
    assert type(str_) == str



# Generated at 2022-06-25 20:31:49.669473
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    Algorithm_0 = Algorithm
    str_0 = cryptographic_0.hash(Algorithm.SHA256)


# Generated at 2022-06-25 20:31:52.865366
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    algorithm = Algorithm.SHA512
    crypto0 = Cryptographic()

    crypto0.hash(algorithm)

# Generated at 2022-06-25 20:31:54.302846
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.mnemonic_phrase()


# Generated at 2022-06-25 20:32:34.139035
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash()  # Should be '6b5cbda1e29edaf5c0ff73a0e24ece42'


# Generated at 2022-06-25 20:32:41.488627
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic('ru')
    assert c.hash(Algorithm.MD4) is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.SHA1) is not None
    assert c.hash(Algorithm.SHA224) is not None
    assert c.hash(Algorithm.SHA256) is not None
    assert c.hash(Algorithm.SHA384) is not None
    assert c.hash(Algorithm.SHA512) is not None
    assert c.hash(Algorithm.BLAKE2S) is not None
    assert c.hash(Algorithm.BLAKE2B) is not None
    assert c.hash(Algorithm.SHA3_224) is not None
    assert c.hash(Algorithm.SHA3_256) is not None

# Generated at 2022-06-25 20:32:44.074151
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    Algorithm.SHA256
    cryptographic_0 = Cryptographic()
    str_0 = cryptographic_0.hash(Algorithm.SHA256)


# Generated at 2022-06-25 20:32:47.878540
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(algorithm=Algorithm.SHA1) == '35b8f6d99d6aa88cb01b8035097b8d1f9b3d3e2f'


# Generated at 2022-06-25 20:32:48.942248
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA1)


# Generated at 2022-06-25 20:32:50.886742
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic = Cryptographic()
    enumObject = Algorithm()
    assert cryptographic.hash(enumeration = enumObject) == hashlib.sha1(cryptographic.uuid().encode()).hexdigest()


# Generated at 2022-06-25 20:33:01.301413
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    seed=12345
    c = Cryptographic(seed)
    hashResult = c.hash(Algorithm.SHA3_512)
    assert hashResult != None
    assert isinstance(hashResult, str)
    assert hashResult == '7e4c4f3021e5e846b9804ee5a5aae7f1d33ac2e7b7609216e3e719bb846bdd22ae9e0f87c26bbb4c4d4f3595ae27f12c21eae1417c5790764ee5f5e5a50feecaf'


# Generated at 2022-06-25 20:33:03.944197
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cryptographic_0 = Cryptographic()
    # algorithm=None
    str_0 = cryptographic_0.hash()


# Generated at 2022-06-25 20:33:06.766516
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    cr.hash(Algorithm.MD5)
    cr.hash(Algorithm.SHA1)
    cr.hash(Algorithm.SHA224)
    cr.hash(Algorithm.SHA256)
    cr.hash(Algorithm.SHA384)
    cr.hash(Algorithm.SHA512)


# Generated at 2022-06-25 20:33:14.879857
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    algorithm = Algorithm.BLAKE2B_512
    cryptographic_0 = Cryptographic(seed=1)
    cryptographic_1 = Cryptographic(seed=1)
    hash_0 = cryptographic_0.hash(algorithm=algorithm)
    hash_1 = cryptographic_1.hash(algorithm=algorithm)
    try:
        assert hash_0 == hash_1
    except:
        raise AssertionError('Hash of the two instances of Cryptographic are not equal.')
