

# Generated at 2022-06-17 22:29:31.416335
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert isinstance(c.hash(), str)
    assert isinstance(c.hash(Algorithm.SHA1), str)
    assert isinstance(c.hash(Algorithm.SHA224), str)
    assert isinstance(c.hash(Algorithm.SHA256), str)
    assert isinstance(c.hash(Algorithm.SHA384), str)
    assert isinstance(c.hash(Algorithm.SHA512), str)
    assert isinstance(c.hash(Algorithm.MD5), str)
    assert isinstance(c.hash(Algorithm.BLAKE2B), str)
    assert isinstance(c.hash(Algorithm.BLAKE2S), str)

# Generated at 2022-06-17 22:29:32.497643
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:29:33.791712
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:29:34.889717
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:46.610132
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'e7c0a8a8a7d6f0f6a0a6f8d8e7d6f0f6a0a6f8d8'
    assert c.hash(Algorithm.SHA1) == 'e7c0a8a8a7d6f0f6a0a6f8d8e7d6f0f6a0a6f8d8'
    assert c.hash(Algorithm.SHA224) == 'e7c0a8a8a7d6f0f6a0a6f8d8e7d6f0f6a0a6f8d8'

# Generated at 2022-06-17 22:29:47.265269
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()


# Generated at 2022-06-17 22:29:53.934539
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert Cryptographic().hash() == 'b6e8f8f9e6f0f3d9b6e8f8f9e6f0f3d9'
    assert Cryptographic().hash(Algorithm.SHA256) == 'b6e8f8f9e6f0f3d9b6e8f8f9e6f0f3d9b6e8f8f9e6f0f3d9b6e8f8f9e6f0f3d9'

# Generated at 2022-06-17 22:30:04.483776
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1) == 'c4b9f9f0c9d8a8b5f6b4d3b4e0b0e8d4b4e9a9b5'
    assert c.hash(Algorithm.SHA224) == 'e6a8e8b5f6b4d3b4e0b0e8d4b4e9a9b5c4b9f9f0c9d8a8b5f6b4d3b4'

# Generated at 2022-06-17 22:30:05.329975
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:30:08.078173
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd9b1a0a8f0c8e8a8d9b1a0a8f0c8e8a8'


# Generated at 2022-06-17 22:30:41.205985
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test with default algorithm
    assert len(Cryptographic().hash()) == 64
    # Test with SHA256
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    # Test with SHA512
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128
    # Test with MD5
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32
    # Test with unsupported algorithm
    try:
        Cryptographic().hash(Algorithm.UNSUPPORTED)
    except Exception as e:
        assert e.args[0] == 'Unsupported algorithm'


# Generated at 2022-06-17 22:30:44.160328
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b7c1d9f9e8e8b0d3c7a9c7c8d1f2f7f3'


# Generated at 2022-06-17 22:30:47.899182
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert len(c.hash()) == 64
    assert len(c.hash(Algorithm.SHA256)) == 64
    assert len(c.hash(Algorithm.SHA512)) == 128
    assert len(c.hash(Algorithm.MD5)) == 32


# Generated at 2022-06-17 22:30:56.425134
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) == '5f9b9c6b8f6b7c6b8f6b7c6b8f6b7c6b'
    assert c.hash(Algorithm.SHA1) == '5f9b9c6b8f6b7c6b8f6b7c6b8f6b7c6b8f6b7c6b'
    assert c.hash(Algorithm.SHA224) == '5f9b9c6b8f6b7c6b8f6b7c6b8f6b7c6b8f6b7c6b8f6b7c6b8f6b7c6b'

# Generated at 2022-06-17 22:31:00.632801
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd6e8b3c8f6d8a7f9e6b0b9c9d6f8b6d8'


# Generated at 2022-06-17 22:31:11.195511
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'c8a8b8f8b7d9b9f9b8f8b8a8b8f8b7d9b9f9b8f8b8a8b8f8b7d9b9f9b8f8b8a8'
    assert c.hash(Algorithm.SHA1) == 'c8a8b8f8b7d9b9f9b8f8b8a8b8f8b7d9b9f9b8f8'

# Generated at 2022-06-17 22:31:16.857596
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'c2c5b0c4b4d4e4c9e9b0f9c3b3c0d3c5'
    assert c.hash(Algorithm.SHA1) == 'b9e5b5c7b2e5d0c7e5b5c7b2e5d0c7e5b5c7b2e5'
    assert c.hash(Algorithm.SHA224) == 'b9e5b5c7b2e5d0c7e5b5c7b2e5d0c7e5b5c7b2e5d0c7e5b5c7b2e5d0c7e5b5c7'


# Generated at 2022-06-17 22:31:18.329965
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 40


# Generated at 2022-06-17 22:31:28.148320
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    # Test with default algorithm
    assert len(Cryptographic().hash()) == 64

    # Test with SHA256
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64

    # Test with SHA512
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128

    # Test with MD5
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32

    # Test with SHA1
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40

    # Test with SHA224
    assert len(Cryptographic().hash(Algorithm.SHA224)) == 56

    # Test with SHA384
    assert len(Cryptographic().hash(Algorithm.SHA384)) == 96

    # Test with SHA3_224

# Generated at 2022-06-17 22:31:29.021821
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()
