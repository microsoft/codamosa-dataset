

# Generated at 2022-06-17 22:30:09.784099
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:30:20.025826
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None
    assert c.hash(Algorithm.SHA1) is not None
    assert c.hash(Algorithm.SHA224) is not None
    assert c.hash(Algorithm.SHA256) is not None
    assert c.hash(Algorithm.SHA384) is not None
    assert c.hash(Algorithm.SHA512) is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.BLAKE2B) is not None
    assert c.hash(Algorithm.BLAKE2S) is not None
    assert c.hash(Algorithm.SHA3_224) is not None
    assert c.hash(Algorithm.SHA3_256) is not None

# Generated at 2022-06-17 22:30:21.904822
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == Cryptographic().hash()


# Generated at 2022-06-17 22:30:32.106846
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'd4f8a8a4a4a4a4a4a4a4a4a4a4a4a4a4'
    assert crypto.hash(Algorithm.SHA1) == 'd4f8a8a4a4a4a4a4a4a4a4a4a4a4a4a4'
    assert crypto.hash(Algorithm.SHA224) == 'd4f8a8a4a4a4a4a4a4a4a4a4a4a4a4a4'
    assert crypto.hash(Algorithm.SHA256) == 'd4f8a8a4a4a4a4a4a4a4a4a4a4a4a4a4'

# Generated at 2022-06-17 22:30:44.161153
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'b2a7b9f5f79bb7bc8a7a3d28bd07c9db'
    assert c.hash(Algorithm.SHA256) == 'b2a7b9f5f79bb7bc8a7a3d28bd07c9db'
    assert c.hash(Algorithm.SHA512) == 'b2a7b9f5f79bb7bc8a7a3d28bd07c9db'
    assert c.hash(Algorithm.SHA1) == 'b2a7b9f5f79bb7bc8a7a3d28bd07c9db'

# Generated at 2022-06-17 22:30:54.227929
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash(Algorithm.MD5) == c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA1) == c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA224) == c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256) == c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384) == c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA512) == c.hash(Algorithm.SHA512)

# Generated at 2022-06-17 22:31:04.715173
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() is not None
    assert crypto.hash(Algorithm.SHA1) is not None
    assert crypto.hash(Algorithm.SHA224) is not None
    assert crypto.hash(Algorithm.SHA256) is not None
    assert crypto.hash(Algorithm.SHA384) is not None
    assert crypto.hash(Algorithm.SHA512) is not None
    assert crypto.hash(Algorithm.MD5) is not None
    assert crypto.hash(Algorithm.BLAKE2B) is not None
    assert crypto.hash(Algorithm.BLAKE2S) is not None
    assert crypto.hash(Algorithm.SHA3_224) is not None
    assert crypto.hash(Algorithm.SHA3_256) is not None


# Generated at 2022-06-17 22:31:09.803939
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == crypto.hash()
    assert crypto.hash(Algorithm.MD5) == crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.SHA1) == crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA224) == crypto.hash(Algorithm.SHA224)
    assert crypto.hash(Algorithm.SHA256) == crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA384) == crypto.hash(Algorithm.SHA384)
    assert crypto.hash(Algorithm.SHA512) == crypto.hash(Algorithm.SHA512)

# Generated at 2022-06-17 22:31:16.038734
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test with default algorithm
    assert len(Cryptographic().hash()) == 32
    # Test with algorithm SHA256
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    # Test with algorithm SHA512
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128
    # Test with algorithm SHA1
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40
    # Test with algorithm MD5
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32
    # Test with algorithm BLAKE2b
    assert len(Cryptographic().hash(Algorithm.BLAKE2b)) == 128
    # Test with algorithm BLAKE2s
    assert len(Cryptographic().hash(Algorithm.BLAKE2s)) == 64
    # Test with algorithm SHA3_224

# Generated at 2022-06-17 22:31:26.565517
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'e9d8b7c8a8a8a8a8a8a8a8a8a8a8a8a8'
    assert c.hash(Algorithm.SHA1) == 'b9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9'
    assert c.hash(Algorithm.SHA224) == 'f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9'
   

# Generated at 2022-06-17 22:31:44.372729
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:31:47.680049
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e8b7b8d8a8f2b1b6a8f2b1b6a8f2b1b6'


# Generated at 2022-06-17 22:31:50.007882
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd4e9f4c9e9f0b5c7d5b5d5b5d5b5d5b5'


# Generated at 2022-06-17 22:31:52.746548
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd0e9e7a8c8a0d7f0d3a9c7a8d3e9c7a8'


# Generated at 2022-06-17 22:31:56.954842
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd8c9c9e8f8c7f8c7f8c7f8c7f8c7f8c7'


# Generated at 2022-06-17 22:31:59.000790
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:32:01.066053
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:32:06.507430
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd8e8fca2dc0f896fd7cb4cb0031ba249'
    assert c.hash(Algorithm.SHA512) == 'f7fbba6e0636f890e56fbbf3283e524c6fa3204ae298382d624741d0dc6638326e282c41be5e4254d8820772c5518a2c5a8c0c7f7eda19594a7eb539453e1e24'

# Generated at 2022-06-17 22:32:10.037902
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA512)


# Generated at 2022-06-17 22:32:20.573315
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e2d8c7b9f8f6f7d6d9c8c7b9f8f6f7d6d9c8c7b9f8f6f7d6d9c8c7b9f8f6f7d6'
    assert c.hash(Algorithm.SHA1) == 'e2d8c7b9f8f6f7d6d9c8c7b9f8f6f7d6d9c8c7b9'

# Generated at 2022-06-17 22:38:34.155853
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'c7d9f9a9a7a6a9a6a7a7a6a9a6a7a6a9a6a7a6a9a6a7a6a9a6a7a6a9a6a7a6a9a6'
    assert c.hash(Algorithm.SHA256) == 'c7d9f9a9a7a6a9a6a7a7a6a9a6a7a6a9a6a7a6a9a6a7a6a9a6a7a6a9a6a7a6a9a6'

# Generated at 2022-06-17 22:38:35.278451
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:38:40.585600
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA224)
    assert crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA384)
    assert crypto.hash(Algorithm.SHA512)
    assert crypto.hash(Algorithm.BLAKE2B)
    assert crypto.hash(Algorithm.BLAKE2S)
    assert crypto.hash(Algorithm.SHA3_224)
    assert crypto.hash(Algorithm.SHA3_256)
    assert crypto.hash(Algorithm.SHA3_384)

# Generated at 2022-06-17 22:38:50.654631
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e5d5d8b8c6a8a6a3c6a3a8a6b8d8e5e5'
    assert Cryptographic().hash(Algorithm.SHA1) == 'd5e5d8b8c6a8a6a3c6a3a8a6b8d8e5e5d5e5d8b8'
    assert Cryptographic().hash(Algorithm.SHA224) == 'd5e5d8b8c6a8a6a3c6a3a8a6b8d8e5e5d5e5d8b8c6a8a6a3c6a3a8a6b8d8e5e5'

# Generated at 2022-06-17 22:39:04.007942
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == '5e9a5f5a8b5c5b5d5e9a5f5a8b5c5b5d'
    assert c.hash(Algorithm.MD5) == '5e9a5f5a8b5c5b5d5e9a5f5a8b5c5b5d'
    assert c.hash(Algorithm.SHA1) == '5e9a5f5a8b5c5b5d5e9a5f5a8b5c5b5d'

# Generated at 2022-06-17 22:39:09.466149
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e0b9f8b8f9c9b9f9e0c8f8e8b9f9e0c8'
    assert c.hash(Algorithm.SHA1) == 'f8c8e8b9f9e0c8f8e8b9f9e0c8f8e8b9f9e0c8'
    assert c.hash(Algorithm.SHA224) == 'f8e8b9f9e0c8f8e8b9f9e0c8f8e8b9f9e0c8f8e8b9f9e0c8f8e8b9'