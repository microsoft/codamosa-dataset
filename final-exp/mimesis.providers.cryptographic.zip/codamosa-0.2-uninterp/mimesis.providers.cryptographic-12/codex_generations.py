

# Generated at 2022-06-17 22:29:53.180636
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'e5b5d5e5b5d5e5b5d5e5b5d5e5b5d5e5'
    assert c.hash(Algorithm.SHA1) == 'e5b5d5e5b5d5e5b5d5e5b5d5e5b5d5e5'
    assert c.hash(Algorithm.SHA224) == 'e5b5d5e5b5d5e5b5d5e5b5d5e5b5d5e5'

# Generated at 2022-06-17 22:30:06.461696
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e1b7a8e8c2e7b8c4e4b7a8c4e1b7a8e8c2e7b8c4'
    assert c.hash(Algorithm.SHA256) == 'e1b7a8e8c2e7b8c4e4b7a8c4e1b7a8e8c2e7b8c4'
    assert c.hash(Algorithm.SHA512) == 'e1b7a8e8c2e7b8c4e4b7a8c4e1b7a8e8c2e7b8c4'

# Generated at 2022-06-17 22:30:11.334757
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32


# Generated at 2022-06-17 22:30:21.015938
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'd6c9e8d8f6a9a6b5d6c9e8d8f6a9a6b5'
    assert crypto.hash(Algorithm.MD5) == 'd6c9e8d8f6a9a6b5d6c9e8d8f6a9a6b5'
    assert crypto.hash(Algorithm.SHA1) == 'd6c9e8d8f6a9a6b5d6c9e8d8f6a9a6b5'

# Generated at 2022-06-17 22:30:31.741385
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b9d9f8f8d0b8f0b8d0b8f0b8d0b8f0b8'
    assert c.hash(Algorithm.SHA256) == 'b9d9f8f8d0b8f0b8d0b8f0b8d0b8f0b8'
    assert c.hash(Algorithm.SHA512) == 'b9d9f8f8d0b8f0b8d0b8f0b8d0b8f0b8'
    assert c.hash(Algorithm.MD5) == 'b9d9f8f8d0b8f0b8d0b8f0b8d0b8f0b8'

# Generated at 2022-06-17 22:30:35.402050
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '5c8e5e5c5c8e5e5c5c8e5e5c5c8e5e5c'


# Generated at 2022-06-17 22:30:37.176527
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:30:44.638032
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    assert c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA512)


# Generated at 2022-06-17 22:30:54.499362
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert Cryptographic().hash(Algorithm.MD5) == '9e107d9d372bb6826bd81d3542a419d6'
    assert Cryptographic().hash(Algorithm.SHA1) == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    assert Cryptographic().hash(Algorithm.SHA224) == 'd14a028c2a3a2bc9476102bb288234c415a2b01f828ea62ac5b3e42f'

# Generated at 2022-06-17 22:31:00.985254
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA256) == 'f7b9d0b1a7e0a8c8e9a9a9d0c0f7b9d0b1a7e0a8c8e9a9a9d0c0f7b9d0b1a7e0a'


# Generated at 2022-06-17 22:31:21.874175
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '9c4f9b9f6a4d4e8f8a2e6a3e6e3d3f9f'


# Generated at 2022-06-17 22:31:30.397925
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'a8d8d8f7e9f9a9e9b8f8d8d8f7e9f9a9e9b8f8d8d8f7e9f9a9e9b8f8d8d8f7e9'
    assert c.hash(Algorithm.SHA1) == 'a8d8d8f7e9f9a9e9b8f8d8d8f7e9f9a9e9b8f8d8'

# Generated at 2022-06-17 22:31:40.468681
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == '2a6c9f8d8e6a4b6a4c6d9f8d8e6a4b6a4c6d9f8d8e6a4b6a4c6d9f8d8e6a4b6a4'
    assert crypto.hash(Algorithm.SHA1) == '2a6c9f8d8e6a4b6a4c6d9f8d8e6a4b6a4c6d9f8d'

# Generated at 2022-06-17 22:31:41.904244
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:31:50.845518
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == '9d7a9a9a9a9a9a9a9a9a9a9a9a9a9a9a'
    assert crypto.hash(Algorithm.SHA1) == '9d7a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a'

# Generated at 2022-06-17 22:31:58.792897
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'e5c9e9a9f9f2d5b5a5c8a5a9e5c9e9a9f9f2d5b5a5c8a5a9'
    assert crypto.hash(Algorithm.SHA1) == 'e5c9e9a9f9f2d5b5a5c8a5a9e5c9e9a9f9f2d5b5'

# Generated at 2022-06-17 22:32:06.459429
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == 'e8d8a8f6f8f6d8d8'
    assert crypto.hash(Algorithm.SHA1) == 'd8d8a8f6f8f6e8d8'
    assert crypto.hash(Algorithm.SHA224) == 'd8d8a8f6f8f6e8d8'
    assert crypto.hash(Algorithm.SHA256) == 'd8d8a8f6f8f6e8d8'
    assert crypto.hash(Algorithm.SHA384) == 'd8d8a8f6f8f6e8d8'
    assert crypto.hash(Algorithm.SHA512) == 'd8d8a8f6f8f6e8d8'


# Generated at 2022-06-17 22:32:07.899002
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:32:09.311894
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:32:19.885557
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == '1d0f8b7d6d0e6c9e0e9b6a7d6d0e6c9e'
    assert crypto.hash(Algorithm.SHA1) == '8d0f8b7d6d0e6c9e0e9b6a7d6d0e6c9e0e9b6a7d'
    assert crypto.hash(Algorithm.SHA224) == '8d0f8b7d6d0e6c9e0e9b6a7d6d0e6c9e0e9b6a7d6d0e6c9e0e9b6a7d'

# Generated at 2022-06-17 22:32:39.343366
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'c4ca4238a0b923820dcc509a6f75849b'


# Generated at 2022-06-17 22:32:43.291390
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32


# Generated at 2022-06-17 22:32:45.429265
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:32:46.538231
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:32:47.957823
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-17 22:32:55.003737
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash()
    assert crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA224)
    assert crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA384)
    assert crypto.hash(Algorithm.SHA512)
    assert crypto.hash(Algorithm.BLAKE2B)
    assert crypto.hash(Algorithm.BLAKE2S)
    assert crypto.hash(Algorithm.SHA3_224)
    assert crypto.hash(Algorithm.SHA3_256)
    assert crypto.hash(Algorithm.SHA3_384)
    assert crypto.hash(Algorithm.SHA3_512)
    assert crypto

# Generated at 2022-06-17 22:32:57.809165
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() is not None


# Generated at 2022-06-17 22:33:05.807759
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd5b9a9d9a9c9d9d9d9d9d9d9d9d9d9d9'
    assert c.hash(Algorithm.SHA256) == 'd5b9a9d9a9c9d9d9d9d9d9d9d9d9d9d9'
    assert c.hash(Algorithm.SHA512) == 'd5b9a9d9a9c9d9d9d9d9d9d9d9d9d9d9'
    assert c.hash(Algorithm.MD5) == 'd5b9a9d9a9c9d9d9d9d9d9d9d9d9d9d9'

# Generated at 2022-06-17 22:33:11.618065
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'd8e8fca2dc0f896fd7cb4cb0031ba249'
    assert crypto.hash(Algorithm.SHA256) == 'd8e8fca2dc0f896fd7cb4cb0031ba249'
    assert crypto.hash(Algorithm.SHA512) == 'd8e8fca2dc0f896fd7cb4cb0031ba249'


# Generated at 2022-06-17 22:33:18.061370
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'b9f9a8d6e8f6c7f6a8a6d9f9b8d6e8f6'
    assert crypto.hash(Algorithm.SHA1) == 'b9f9a8d6e8f6c7f6a8a6d9f9b8d6e8f6'
    assert crypto.hash(Algorithm.SHA224) == 'b9f9a8d6e8f6c7f6a8a6d9f9b8d6e8f6'

# Generated at 2022-06-17 22:34:02.777903
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test for method hash of class Cryptographic
    # Arrange
    crypto = Cryptographic()
    # Act
    result = crypto.hash()
    # Assert
    assert isinstance(result, str)
    assert len(result) == 64


# Generated at 2022-06-17 22:34:10.775831
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'f9c9e8d8f7b8d7c6b5a4c3b2a1'
    assert c.hash(Algorithm.MD5) == 'f9c9e8d8f7b8d7c6b5a4c3b2a1'
    assert c.hash(Algorithm.SHA1) == 'f9c9e8d8f7b8d7c6b5a4c3b2a1'
    assert c.hash(Algorithm.SHA224) == 'f9c9e8d8f7b8d7c6b5a4c3b2a1'

# Generated at 2022-06-17 22:34:16.389700
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()
    assert c.hash() == c.hash()


# Generated at 2022-06-17 22:34:25.723089
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'e9e7c9c8d8d5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5'
    assert c.hash(Algorithm.SHA256) == 'e9e7c9c8d8d5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5'

# Generated at 2022-06-17 22:34:33.633098
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == '7f8d8c6b7d6d8c6b7f8d8c6b7d6d8c6b'
    assert crypto.hash(Algorithm.SHA256) == '7f8d8c6b7d6d8c6b7f8d8c6b7d6d8c6b'
    assert crypto.hash(Algorithm.SHA512) == '7f8d8c6b7d6d8c6b7f8d8c6b7d6d8c6b'

# Generated at 2022-06-17 22:34:38.260192
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'c5e8e50f965cff8e4f8e8d72085992e6'
    assert crypto.hash(Algorithm.SHA1) == 'c5e8e50f965cff8e4f8e8d72085992e6'
    assert crypto.hash(Algorithm.SHA224) == 'c5e8e50f965cff8e4f8e8d72085992e6'
    assert crypto.hash(Algorithm.SHA256) == 'c5e8e50f965cff8e4f8e8d72085992e6'

# Generated at 2022-06-17 22:34:38.969345
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:34:44.546634
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1) == 'b7d9c0e9e7a9f6c9c6a8a8d8d1b2d1b9'
    assert c.hash(Algorithm.SHA224) == 'f6b4d8f3e3c9f9e9e9d8d8d8d8d8d8d8d8d8d8d8d8d8d8d8d8d8d8'

# Generated at 2022-06-17 22:34:52.706772
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == 'b7f6f5d6f8a2d8a9b5f6b5f6d8a9b5f6'
    assert crypto.hash(Algorithm.SHA1) == 'b7f6f5d6f8a2d8a9b5f6b5f6d8a9b5f6'
    assert crypto.hash(Algorithm.SHA224) == 'b7f6f5d6f8a2d8a9b5f6b5f6d8a9b5f6'
    assert crypto.hash(Algorithm.SHA256) == 'b7f6f5d6f8a2d8a9b5f6b5f6d8a9b5f6'


# Generated at 2022-06-17 22:34:58.094677
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA1) == crypto.hash(Algorithm.SHA1)


# Generated at 2022-06-17 22:38:54.454714
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA256)


# Generated at 2022-06-17 22:38:59.050677
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd7b6c8f7c8b3c3d7d7b6c8f7c8b3c3d7'


# Generated at 2022-06-17 22:39:01.012515
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:39:02.808204
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash()


# Generated at 2022-06-17 22:39:09.063589
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()