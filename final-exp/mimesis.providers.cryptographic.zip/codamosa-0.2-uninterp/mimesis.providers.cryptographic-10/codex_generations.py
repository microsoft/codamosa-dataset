

# Generated at 2022-06-17 22:29:28.766561
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e7d9c8b8d7b8d7b8d7b8d7b8d7b8d7b8'
    assert c.hash(Algorithm.MD5) == 'e7d9c8b8d7b8d7b8d7b8d7b8d7b8d7b8'
    assert c.hash(Algorithm.SHA1) == 'e7d9c8b8d7b8d7b8d7b8d7b8d7b8d7b8'
    assert c.hash(Algorithm.SHA224) == 'e7d9c8b8d7b8d7b8d7b8d7b8d7b8d7b8'

# Generated at 2022-06-17 22:29:32.238918
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e9b9f7b0d6b8d7a8c8d7b8d6b9f7e9b0'


# Generated at 2022-06-17 22:29:38.855768
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA256) == 'c9b9e9f8f8e9b9c9f8e9f8e9b9c9f8e9b9c9f8e9b9c9f8e9b9c9f8e9b9c9f8e9'

# Generated at 2022-06-17 22:29:40.287487
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:50.679243
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == '0a9f9d5f5e7c12d9d0ef0c05bdb6670c'
    assert Cryptographic().hash(Algorithm.SHA1) == 'b7d8b8f3d3e8c3e2e7f8d4e9c7d8c4e9d3e8d4e9'
    assert Cryptographic().hash(Algorithm.SHA224) == 'e7d8c4e9d3e8d4e9c7d8b8f3d3e8c3e2e7f8d4e9c7d8b8f3d3e8c3e2e7f8d4e9'

# Generated at 2022-06-17 22:29:56.136189
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert Cryptographic().hash() == 'a8d9a0a9b9c8d8a9b8c9a0d9a8b9c8d9'


# Generated at 2022-06-17 22:30:08.316973
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.text import Text
    from mimesis.providers.utils import get_provider

    crypto = Cryptographic()
    text = Text('en')
    text.add_provider(get_provider('cryptographic'))

    assert crypto.hash() == text.hash()
    assert crypto.hash(algorithm=Algorithm.SHA1) == text.hash(algorithm=Algorithm.SHA1)
    assert crypto.hash(algorithm=Algorithm.SHA224) == text.hash(algorithm=Algorithm.SHA224)

# Generated at 2022-06-17 22:30:09.529587
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:30:12.593951
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b9c9b8d9c8c9d9c8d8d9c8d8c8d9c8d9'


# Generated at 2022-06-17 22:30:21.602125
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'd6a8a6b7e0e9c2c8b9f9d9e0c4f4b3b8'
    assert crypto.hash(Algorithm.SHA512) == 'f9d9e0c4f4b3b8d6a8a6b7e0e9c2c8b9f9d9e0c4f4b3b8d6a8a6b7e0e9c2c8b9f9d9e0c4f4b3b8d6a8a6b7e0e9c2c8b9f9d9e0c4f4b3b8'

# Generated at 2022-06-17 22:30:42.473152
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e8a7f8d8f7e7e8a7f8d8f7e7e8a7f8d8'


# Generated at 2022-06-17 22:30:50.691636
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == 'f7e8d9f9b9d9c8d8'
    assert crypto.hash(Algorithm.SHA1) == 'e8d9f9b9d9c8d8f7'
    assert crypto.hash(Algorithm.SHA224) == 'e8d9f9b9d9c8d8f7'
    assert crypto.hash(Algorithm.SHA256) == 'e8d9f9b9d9c8d8f7'

# Generated at 2022-06-17 22:30:56.776810
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b8c8b8f0-d8c3-4b1f-8a9f-b5f7e5a5d8f5'


# Generated at 2022-06-17 22:31:05.467858
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == crypto.hash()
    assert crypto.hash(Algorithm.MD5) == crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.SHA1) == crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA224) == crypto.hash(Algorithm.SHA224)
    assert crypto.hash(Algorithm.SHA256) == crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA384) == crypto.hash(Algorithm.SHA384)
    assert crypto.hash(Algorithm.SHA512) == crypto.hash(Algorithm.SHA512)

# Generated at 2022-06-17 22:31:13.972677
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) == 'c5e8e5c9d9a9c8c8d9a9c5e8e5c9d9a9'
    assert c.hash(Algorithm.SHA1) == 'c5e8e5c9d9a9c8c8d9a9c5e8e5c9d9a9c5e8e5c9'

# Generated at 2022-06-17 22:31:18.001089
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd8f1c9b1a9b9a9d8b1c9f1d8a9b9f1c9'


# Generated at 2022-06-17 22:31:21.874180
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd7c8d1b8a8b9b9b7d7c8d1b8a8b9b9b7'

# Generated at 2022-06-17 22:31:23.279388
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '4e8e4b9d0a4c7d8f8f8c7d9d0b4e8e4b9d0a4c7d8f'


# Generated at 2022-06-17 22:31:27.292195
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic"""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA1) == 'b5c5e8b8f7e5f9a2b7c3d8e0f1e2d3c4'
    assert crypto.hash(Algorithm.SHA224) == 'd8e0f1e2d3c4b5c5e8b8f7e5f9a2b7c3d8e0f1e2d3c4b5c5e8b8f7e5'

# Generated at 2022-06-17 22:31:28.510181
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'a6f4b93b1a1d18e6c2c6afc35a0c6718'
