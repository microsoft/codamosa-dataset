

# Generated at 2022-06-17 22:29:28.344830
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()


# Generated at 2022-06-17 22:29:31.839622
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'


# Generated at 2022-06-17 22:29:38.600961
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd7d9b8b7c8b8b8b7d7d9b8b7c8b8b8b7'
    assert c.hash(Algorithm.SHA256) == 'd7d9b8b7c8b8b8b7d7d9b8b7c8b8b8b7'
    assert c.hash(Algorithm.SHA512) == 'd7d9b8b7c8b8b8b7d7d9b8b7c8b8b8b7'

# Generated at 2022-06-17 22:29:49.417712
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'c8d8f7b2c0f6d9e9e8d8f7b2c0f6d9e9'
    assert crypto.hash(Algorithm.SHA1) == 'c8d8f7b2c0f6d9e9e8d8f7b2c0f6d9e9'
    assert crypto.hash(Algorithm.SHA224) == 'c8d8f7b2c0f6d9e9e8d8f7b2c0f6d9e9'

# Generated at 2022-06-17 22:29:58.315258
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'e7d9f9c9d7c0f8d3c7d3c0f8d3c7d3c0f8d3c7d3c0f8d3c7d3c0f8d3c7d3c0f8'
    assert c.hash(algorithm=Algorithm.SHA256) == 'e7d9f9c9d7c0f8d3c7d3c0f8d3c7d3c0f8d3c7d3c0f8d3c7d3c0f8d3c7d3c0f8'

# Generated at 2022-06-17 22:30:00.620716
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:30:03.720706
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e1e8b6c9d9d9c1e8b6e1d9d9c1e8b6c9'


# Generated at 2022-06-17 22:30:06.866676
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd8a8e8b7f9a8f8a8e8b7f9a8f8a8e8b7'


# Generated at 2022-06-17 22:30:14.223005
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e0f5e5f0-a8c1-4f3f-b9b3-9b9f6b2c2c2a'
    assert c.hash(Algorithm.SHA256) == 'e0f5e5f0a8c14f3fb9b39b9f6b2c2c2a4b4d9c9b9a9b9e9b9a9b9a9b9e9b9a9b9'

# Generated at 2022-06-17 22:30:18.070171
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    assert Cryptographic().hash() == 'd7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592'


# Generated at 2022-06-17 22:31:15.773017
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == 'f8c8e8a7b7d0f1a8b8e8f8c8e8a7b7d0'
    assert Cryptographic().hash(Algorithm.SHA1) == 'b8e8f8c8e8a7b7d0f1a8b8e8f8c8e8a7b7d0f1a8'
    assert Cryptographic().hash(Algorithm.SHA224) == 'b8e8f8c8e8a7b7d0f1a8b8e8f8c8e8a7b7d0f1a8b8e8f8c8e8a7b7d0f1a8'

# Generated at 2022-06-17 22:31:26.376080
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None
    assert c.hash(Algorithm.SHA256) is not None
    assert c.hash(Algorithm.SHA512) is not None
    assert c.hash(Algorithm.SHA1) is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.BLAKE2B) is not None
    assert c.hash(Algorithm.BLAKE2S) is not None
    assert c.hash(Algorithm.SHA3_224) is not None
    assert c.hash(Algorithm.SHA3_256) is not None
    assert c.hash(Algorithm.SHA3_384) is not None
    assert c.hash(Algorithm.SHA3_512) is not None

# Generated at 2022-06-17 22:31:27.979635
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test Cryptographic.hash()."""
    assert Cryptographic().hash()


# Generated at 2022-06-17 22:31:28.669971
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:31:39.698531
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()

# Generated at 2022-06-17 22:31:49.219415
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'a9c9d8d5f5a5b5c5d5e5f5a5b5c5d5e5'
    assert c.hash(Algorithm.SHA1) == 'a9c9d8d5f5a5b5c5d5e5f5a5b5c5d5e5'
    assert c.hash(Algorithm.SHA224) == 'a9c9d8d5f5a5b5c5d5e5f5a5b5c5d5e5'

# Generated at 2022-06-17 22:31:57.919713
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'c8b9e9a9a9e8b8c8'
    assert c.hash(Algorithm.MD5) == 'c8b9e9a9a9e8b8c8'
    assert c.hash(Algorithm.SHA1) == 'b8c8e8a9e9a9c8b8'
    assert c.hash(Algorithm.SHA224) == 'c8b9e9a9a9e8b8c8'
    assert c.hash(Algorithm.SHA256) == 'c8b9e9a9a9e8b8c8'

# Generated at 2022-06-17 22:32:01.999366
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b8f2b9d9a9b9e3c3b3f3b4d4b4f4d4a4'


# Generated at 2022-06-17 22:32:03.616726
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e8d9e9c9f9e8e8d9e9c9f9e8e8d9e9c9'


# Generated at 2022-06-17 22:32:04.430163
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:32:55.336746
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA1) != c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA224) != c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384) != c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA512) != c.hash(Algorithm.SHA512)
    assert c.hash(Algorithm.BLAKE2B) != c.hash(Algorithm.BLAKE2B)

# Generated at 2022-06-17 22:33:00.168364
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '6a4f6a8c6d8b6b9e6a4f6a8c6d8b6b9e'


# Generated at 2022-06-17 22:33:06.397548
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None
    assert c.hash(Algorithm.SHA1) is not None
    assert c.hash(Algorithm.SHA224) is not None
    assert c.hash(Algorithm.SHA256) is not None
    assert c.hash(Algorithm.SHA384) is not None
    assert c.hash(Algorithm.SHA512) is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.BLAKE2B) is not None
    assert c.hash(Algorithm.BLAKE2S) is not None
    assert c.hash(Algorithm.SHA3_224) is not None
    assert c.hash(Algorithm.SHA3_256) is not None

# Generated at 2022-06-17 22:33:14.880264
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'b9e8f8f9c9b7c7f9d9c9b7c7f9d9c9b7c7f9d9c9b7c7f9d9c9b7c7f9d9c9b7c7'

# Generated at 2022-06-17 22:33:16.198987
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:33:18.433313
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'd7b5f5d8c8c4f5f4f4c4c4c4c4c4c4c4'


# Generated at 2022-06-17 22:33:28.146665
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'f8f8a2f43c8376cc3d655871fa68d2c9'
    assert c.hash(Algorithm.SHA256) == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-17 22:33:29.375501
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:33:30.905613
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:33:33.790940
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test for method hash of class Cryptographic
    # Arrange
    crypto = Cryptographic()
    # Act
    result = crypto.hash()
    # Assert
    assert isinstance(result, str)
    assert len(result) == 40
