

# Generated at 2022-06-17 22:30:02.813124
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e6f7f6d0b6a7e6f7f6d0b6a7e6f7f6d0b6a7e6f7f6d0b6a7'


# Generated at 2022-06-17 22:30:09.562463
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd9d9a8b3a3f9e0b0f8d8e8f9e0b0f8d8'
    assert c.hash(Algorithm.SHA256) == 'd9d9a8b3a3f9e0b0f8d8e8f9e0b0f8d8'
    assert c.hash(Algorithm.SHA512) == 'd9d9a8b3a3f9e0b0f8d8e8f9e0b0f8d8'
    assert c.hash(Algorithm.SHA1) == 'd9d9a8b3a3f9e0b0f8d8e8f9e0b0f8d8'

# Generated at 2022-06-17 22:30:17.420219
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == crypto.hash()
    assert crypto.hash(Algorithm.SHA256) == crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA512) == crypto.hash(Algorithm.SHA512)
    assert crypto.hash(Algorithm.SHA1) == crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.MD5) == crypto.hash(Algorithm.MD5)


# Generated at 2022-06-17 22:30:19.052764
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-17 22:30:22.395348
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b7d5f8b5d8b8f5c9b5c9d8b8f5d8b8f5'


# Generated at 2022-06-17 22:30:32.478952
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA512)
    assert c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.BLAKE2B)
    assert c.hash(Algorithm.BLAKE2S)
    assert c.hash(Algorithm.SHA3_224)
    assert c.hash(Algorithm.SHA3_256)
    assert c.hash(Algorithm.SHA3_384)
    assert c.hash(Algorithm.SHA3_512)

# Generated at 2022-06-17 22:30:44.370448
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'e0c5d0f5-5e5c-4d7c-a8f9-9c8b9d5e7c5d'
    assert crypto.hash(Algorithm.SHA1) == 'e0c5d0f55e5c4d7ca8f99c8b9d5e7c5d'
    assert crypto.hash(Algorithm.SHA224) == 'e0c5d0f55e5c4d7ca8f99c8b9d5e7c5d'

# Generated at 2022-06-17 22:30:47.992709
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'a3f5d6d1-c8e8-4d7b-a9b0-7b9b9c9c7f5a'


# Generated at 2022-06-17 22:30:56.565273
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert c.hash(Algorithm.SHA1) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert c.hash(Algorithm.SHA224) == 'd14a028c2a3a2bc9476102bb288234c415a2b01f828ea62ac5b3e42f'
    assert c.hash(Algorithm.SHA256) == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    assert c.hash(Algorithm.SHA384)

# Generated at 2022-06-17 22:31:06.135560
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""

# Generated at 2022-06-17 22:32:04.259223
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'd6c9a6a4c6f8e9f9a6a4c6f8e9f9a6a4c6f8e9f9a6a4c6f8e9f9a6a4c6f8e9f9a'


# Generated at 2022-06-17 22:32:06.147563
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd7a2e9c9f9e1c6d0d7f8b8f8b8d0c6e1f9c9e9a2d7'


# Generated at 2022-06-17 22:32:17.053346
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'd9a9b7d7c9e9e8a8f8b9d9d8c8e9f9e8'
    assert crypto.hash(Algorithm.SHA1) == 'a3a2b2b3c3d3d2a2b3c3c2d3a3b3c2d2'
    assert crypto.hash(Algorithm.SHA224) == 'd9a9b7d7c9e9e8a8f8b9d9d8c8e9f9e8'

# Generated at 2022-06-17 22:32:17.742895
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-17 22:32:20.107380
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae'


# Generated at 2022-06-17 22:32:20.950435
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:32:25.325106
# Unit test for method hash of class Cryptographic

# Generated at 2022-06-17 22:32:28.770947
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-17 22:32:31.517239
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '6a5c6e9c7a3d8a9b7c9b9c8d7a8a9a7b'


# Generated at 2022-06-17 22:32:32.647938
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash()


# Generated at 2022-06-17 22:35:13.467461
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:35:20.177928
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'd7f9e8e8c7a6d9b1f7c2f2a8c8e9d9d3'
    assert crypto.hash(Algorithm.SHA256) == 'd7f9e8e8c7a6d9b1f7c2f2a8c8e9d9d3'
    assert crypto.hash(Algorithm.SHA512) == 'd7f9e8e8c7a6d9b1f7c2f2a8c8e9d9d3'

# Generated at 2022-06-17 22:35:23.697464
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b6a7c6b8f6e7c6b8f6a7c6b8f6a7c6b8'


# Generated at 2022-06-17 22:35:26.855689
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b9a9b9f9b9a9b9f9b9a9b9f9b9a9b9f9'
