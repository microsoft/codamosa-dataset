

# Generated at 2022-06-17 22:29:15.135295
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:20.861841
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'a4a9e9f9d9a3a1a4a9e9f9d9a3a1a4a9e9f9d9a3a1'
    assert c.hash(Algorithm.MD5) == 'a4a9e9f9d9a3a1a4a9e9f9d9a3a1a4a9e9f9d9a3a1'
    assert c.hash(Algorithm.SHA1) == 'a4a9e9f9d9a3a1a4a9e9f9d9a3a1a4a9e9f9d9a3a1'

# Generated at 2022-06-17 22:29:23.263560
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '1e8f7b8e8d9a9b9c9d9e9f808182838485868788'


# Generated at 2022-06-17 22:29:25.593443
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd8a5d0d2f5a9a9f9f9c0f9a9a9a9a9a9'


# Generated at 2022-06-17 22:29:30.763241
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd0e8c8b8f8f9f9b7d0e8c8b8f8f9f9b7'


# Generated at 2022-06-17 22:29:31.910028
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:38.667486
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd8c8a9e9a7c0f3b3c8b2f8d0f7d5d5d5'
    assert c.hash(Algorithm.MD5) == 'd8c8a9e9a7c0f3b3c8b2f8d0f7d5d5d5'
    assert c.hash(Algorithm.SHA1) == 'd8c8a9e9a7c0f3b3c8b2f8d0f7d5d5d5'

# Generated at 2022-06-17 22:29:49.457099
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA1) == 'e5c9b8d9c9f7f9b0c9b7e8c9b8d9c9f7f9b0c9b7'
    assert Cryptographic().hash(Algorithm.SHA256) == 'e5c9b8d9c9f7f9b0c9b7e5c9b8d9c9f7f9b0c9b7e5c9b8d9c9f7f9b0c9b7e5c9b8d9c9f7f9b0c9b7e5c9b8d9c9f7f9b0c9b7'

# Generated at 2022-06-17 22:29:52.212244
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '9a7f9e9d9e7f9a9d9e7f9a9d9a7f9e9d9e7f9a9d'


# Generated at 2022-06-17 22:29:59.450768
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b8a8c0f1b7c9b8e8c8c0f1b7c9b8e8c8c0f1b7c9b8e8c8c0f1b7c9b8e8c8c0f1'


# Generated at 2022-06-17 22:30:11.041922
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b7e0f9a2e8c8f8c2b7c6e0a2e8c8f8c2'


# Generated at 2022-06-17 22:30:20.847099
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()

# Generated at 2022-06-17 22:30:31.671527
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'd8c6b8b6c9c9d9b6b8c6c9d8b6b8c9d8'
    assert crypto.hash(Algorithm.SHA1) == 'd8c6b8b6c9c9d9b6b8c6c9d8b6b8c9d8'
    assert crypto.hash(Algorithm.SHA224) == 'd8c6b8b6c9c9d9b6b8c6c9d8b6b8c9d8'

# Generated at 2022-06-17 22:30:43.438852
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'e8b8d9b7c3f6a3d3c3e8b8d9b7c3f6a3d3c3e8b8d9b7c3f6a3d3c3e8b8d9b7c3f'
    assert c.hash(Algorithm.MD5) == 'e8b8d9b7c3f6a3d3c3e8b8d9b7c3f6a3d'
    assert c.hash(Algorithm.SHA1) == 'e8b8d9b7c3f6a3d3c3e8b8d9b7c3f6a3d3c3e8b8'


# Generated at 2022-06-17 22:30:51.119208
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(algorithm=Algorithm.SHA1)
    assert crypto.hash(algorithm=Algorithm.SHA224)
    assert crypto.hash(algorithm=Algorithm.SHA256)
    assert crypto.hash(algorithm=Algorithm.SHA384)
    assert crypto.hash(algorithm=Algorithm.SHA512)
    assert crypto.hash(algorithm=Algorithm.MD5)
    assert crypto.hash(algorithm=Algorithm.BLAKE2B)
    assert crypto.hash(algorithm=Algorithm.BLAKE2S)
    assert crypto.hash(algorithm=Algorithm.SHA3_224)
   

# Generated at 2022-06-17 22:31:04.027305
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash(Algorithm.SHA256) == c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA512)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA3_256)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA3_512)

# Generated at 2022-06-17 22:31:13.566947
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == '2d711642b726b04401627ca9fbac32f5c8530fb1903cc4db02258717921a4881'
    assert c.hash(Algorithm.SHA256) == '2d711642b726b04401627ca9fbac32f5c8530fb1903cc4db02258717921a4881'

# Generated at 2022-06-17 22:31:24.866056
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA256) == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    assert crypto.hash(Algorithm.SHA512) == 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e'

# Generated at 2022-06-17 22:31:27.979631
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '0c5d5e9e5d1b8f8b8a9a0a2d2c8d8a8a'


# Generated at 2022-06-17 22:31:28.660333
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:31:55.371634
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '9b1e0f8e2c8b8b8e0f1e9b9b8e2c8f1e'


# Generated at 2022-06-17 22:32:05.476280
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(algorithm=Algorithm.SHA256) == 'd8b0f7d9a9b9f7b9d9f7b9d9a9b9f7b9d9f7b9d9a9b9f7b9d9f7b9d9a9b9f7b9'

# Generated at 2022-06-17 22:32:07.377462
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd8a9b9d1f9f8c8d1c8d1b9d1f9f8d8d1'


# Generated at 2022-06-17 22:32:18.094587
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""

# Generated at 2022-06-17 22:32:20.404637
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:32:21.133560
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:32:24.999625
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    hash_ = crypto.hash(Algorithm.SHA256)
    assert isinstance(hash_, str)
    assert len(hash_) == 64


# Generated at 2022-06-17 22:32:28.732317
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '2b7f5e5e5d7c8b8a4b4c4f5d2b7f5e5e5d7c8b8a4b4c4f5d'


# Generated at 2022-06-17 22:32:36.777392
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()
    assert c.hash(Algorithm.MD5) != c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA1) != c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA224) != c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384) != c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA512) != c.hash(Algorithm.SHA512)


# Generated at 2022-06-17 22:32:39.914193
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'f9d3b3e8d8c9c9b0f7f9f9d3b3e8d8c9c9b0f7f9'


# Generated at 2022-06-17 22:38:16.198457
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'c8d6a8f6d7c6d8b6a8f6d7c6d8b6a8f6d7c6d8b6'


# Generated at 2022-06-17 22:38:23.932266
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'c7b8d3c3f7d3a8a8c7b8d3c3f7d3a8a8'
    assert c.hash(Algorithm.SHA1) == 'a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0'
    assert c.hash(Algorithm.SHA224) == 'a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0a7e0'

# Generated at 2022-06-17 22:38:26.997888
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'


# Generated at 2022-06-17 22:38:29.241582
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:38:31.516426
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'e5d7d8e5d7d8e5d7d8e5d7d8e5d7d8e5'


# Generated at 2022-06-17 22:38:37.692657
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'a2b2d7b5d3c3a8f8a9b9e5e5d2d2a1a1'
    assert c.hash(Algorithm.SHA256) == 'c2d2e7e5f3f3a8a8b9b9e5e5d2d2a1a1'
    assert c.hash(Algorithm.SHA512) == 'a2b2d7b5d3c3a8f8a9b9e5e5d2d2a1a1'

# Generated at 2022-06-17 22:38:39.550230
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:38:41.316972
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:38:45.908185
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '9e9f9b9d7c3b3a2c7d3b3a2c7d3b3a2c7d3b3a2c7d3b3a2c7d3b3a2c7d3b3a2c'


# Generated at 2022-06-17 22:38:53.558629
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert Cryptographic().hash(Algorithm.SHA256) == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'