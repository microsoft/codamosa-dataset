

# Generated at 2022-06-17 22:29:46.673132
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'd41d8cd98f00b204e9800998ecf8427e'
    assert crypto.hash(Algorithm.MD5) == 'd41d8cd98f00b204e9800998ecf8427e'
    assert crypto.hash(Algorithm.SHA1) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert crypto.hash(Algorithm.SHA224) == 'd14a028c2a3a2bc9476102bb288234c415a2b01f828ea62ac5b3e42f'

# Generated at 2022-06-17 22:29:55.468281
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '0e8dc93e1f0ae5fe3d5b296e71b3c5dd'
    assert c.hash(Algorithm.SHA1) == '9e9f9c2f8d8a8a2a9a9f9e9e9f9c2f8d8a8a2a9a'
    assert c.hash(Algorithm.SHA224) == 'f8f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9f9'

# Generated at 2022-06-17 22:29:57.210026
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:30:08.849938
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'f1c7f8d8b8c8e5d5d5e7f1c7f8d8b8c8e5d5d5e7'
    assert crypto.hash(Algorithm.SHA256) == 'f1c7f8d8b8c8e5d5d5e7f1c7f8d8b8c8e5d5d5e7'
    assert crypto.hash(Algorithm.SHA512) == 'f1c7f8d8b8c8e5d5d5e7f1c7f8d8b8c8e5d5d5e7'

# Generated at 2022-06-17 22:30:19.192689
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()

# Generated at 2022-06-17 22:30:30.367256
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b8d4f8c9e9c7c2e9f9e3c3b8d4f8c9e9c7c2e9f9e3c3b8d4f8c9e9c7c2e9f9e3c3'
    assert c.hash(Algorithm.SHA256) == 'b8d4f8c9e9c7c2e9f9e3c3b8d4f8c9e9c7c2e9f9e3c3b8d4f8c9e9c7c2e9f9e3c3'

# Generated at 2022-06-17 22:30:41.591942
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == 'f4c4b4f8b9c9f9b9d7c8b8d8c7c8d7d8'
    assert Cryptographic().hash(Algorithm.SHA1) == '7e8c8d8c7d7c8b8d7c8b8d8c7c8d7d8c7c8d7d8'
    assert Cryptographic().hash(Algorithm.SHA224) == '7e8c8d8c7d7c8b8d7c8b8d8c7c8d7d8c7c8d7d8c7c8d7d8c7c8d7d8'

# Generated at 2022-06-17 22:30:42.922720
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:30:45.444542
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'c8e8e8f8b9f9f9f9f9f9f9f9f9f9f9f9'


# Generated at 2022-06-17 22:30:48.558143
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'f9d7f2a0e8f6f8c8b9b9c1c9d8d8e8e8'


# Generated at 2022-06-17 22:31:24.926101
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == '6f7b6c8d6b8f8d7b6c7b6c8d6b8f8d7b'
    assert crypto.hash(Algorithm.SHA1) == '6f7b6c8d6b8f8d7b6c7b6c8d6b8f8d7b6c7b6c8d'

# Generated at 2022-06-17 22:31:26.402903
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == '7d9c0b8b7c0c1f5e7d8d3f8c7f8d3c1f'


# Generated at 2022-06-17 22:31:27.979630
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'c4ca4238a0b923820dcc509a6f75849b'


# Generated at 2022-06-17 22:31:29.047883
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-17 22:31:31.205482
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'd6d5a9b9a0b9f4d2c4e4f8e1c4b4e4c4'


# Generated at 2022-06-17 22:31:40.498452
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == '5e543256c480ac577d30f76f9120eb74'
    assert c.hash(Algorithm.SHA1) == 'f9d2b8e8f0c5eaa1c5b9f9e8d6a5e5a5'
    assert c.hash(Algorithm.SHA224) == 'f5a5a5e8d6e9f9c5b1eaa0c5e8b8d2f9'
    assert c.hash(Algorithm.SHA256) == 'f5a5a5e8d6e9f9c5b1eaa0c5e8b8d2f9'

# Generated at 2022-06-17 22:31:43.533733
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd7b4a4c4c7e4f4c4c7e4f4c4c7e4f4c4'


# Generated at 2022-06-17 22:31:45.674057
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd0e0f2a7a9d8f8c0a8a8a0c7f2f8d0c0'


# Generated at 2022-06-17 22:31:47.877371
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:31:56.662157
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == '0b7e6b9e9d7c8e8c7d7f8e8f7b7e6b9e9d7c8e8c7d7f8e8f7b7e6b9e9d7c8e8c7d'
    assert crypto.hash(algorithm=Algorithm.SHA1) == '0b7e6b9e9d7c8e8c7d7f8e8f7b7e6b9e9d7c8e8c'