

# Generated at 2022-06-17 22:29:20.212197
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == '9e9c9f7b5d8a5e7d5c5a5d7d5c5a5d7d5c5a5d7d5c5a5d7d5c5a5d7d5c5a5d7d'
    assert c.hash(Algorithm.SHA1) == 'c4d4f4f4f4f4f4f4f4f4f4f4f4f4f4f4f4f4f4f4'

# Generated at 2022-06-17 22:29:23.495021
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b8d8f8c8d8f8c8d8f8c8d8f8c8d8f8c8'


# Generated at 2022-06-17 22:29:24.480402
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:29:34.890798
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == 'b9f9c9f1d2b8c8b0c9b9f9c9f1d2b8c8'
    assert Cryptographic().hash(Algorithm.SHA1) == 'c9f1d2b8c8b0c9b9f9c9f1d2b8c8b0c9f1d2b8c8'
    assert Cryptographic().hash(Algorithm.SHA224) == 'b8c8b0c9b9f9c9f1d2b8c8b0c9b9f9c9f1d2b8c8b0c9b9f9c9f1d2'

# Generated at 2022-06-17 22:29:46.673463
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash(Algorithm.SHA256) == c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA512)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA384)

# Generated at 2022-06-17 22:29:55.468317
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'e9f9c9e3f8d3c8b3e2f1d0c9b8a7f6e5'
    assert crypto.hash(Algorithm.SHA1) == '5a5f5e5d5c5b5a595857565554535251'
    assert crypto.hash(Algorithm.SHA224) == 'e9f9c9e3f8d3c8b3e2f1d0c9b8a7f6e5d4c3b2a1'

# Generated at 2022-06-17 22:30:00.232440
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'f5b3d3c8f2d1f9c9b9d1c8f2d3c8f5b3'


# Generated at 2022-06-17 22:30:05.211222
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test for method hash of class Cryptographic
    # Arrange
    from mimesis.enums import Algorithm
    crypto = Cryptographic()
    # Act
    result = crypto.hash(Algorithm.SHA256)
    # Assert
    assert len(result) == 64


# Generated at 2022-06-17 22:30:06.739825
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'a5c9b7f7a0c8a8e7c9c9b7a7a0c8a8e7'


# Generated at 2022-06-17 22:30:13.703677
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() is not None
    assert crypto.hash(Algorithm.SHA1) is not None
    assert crypto.hash(Algorithm.SHA224) is not None
    assert crypto.hash(Algorithm.SHA256) is not None
    assert crypto.hash(Algorithm.SHA384) is not None
    assert crypto.hash(Algorithm.SHA512) is not None
    assert crypto.hash(Algorithm.MD5) is not None
    assert crypto.hash(Algorithm.BLAKE2b) is not None
    assert crypto.hash(Algorithm.BLAKE2s) is not None


# Generated at 2022-06-17 22:30:38.165947
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:30:47.740247
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '1c8e6d9a6f9c6f8b6d8c6d9a6f9c6f8b6d8c6d9a6f9c6f8b6d8c6d9a6f9c6f8b'
    assert c.hash(Algorithm.SHA256) == '1c8e6d9a6f9c6f8b6d8c6d9a6f9c6f8b6d8c6d9a6f9c6f8b6d8c6d9a6f9c6f8b'

# Generated at 2022-06-17 22:30:56.352005
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'b8a6a9b7d1a0c8b7f8d9b9a9b9b8a8b8'
    assert crypto.hash(Algorithm.SHA1) == 'b8a6a9b7d1a0c8b7f8d9b9a9b9b8a8b8'
    assert crypto.hash(Algorithm.SHA224) == 'b8a6a9b7d1a0c8b7f8d9b9a9b9b8a8b8'

# Generated at 2022-06-17 22:31:05.336131
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '8a8b9c9d9e9f0a0b0c0d0e0f10111213'
    assert c.hash(Algorithm.SHA1) == 'b6d9c8a9b7c8d9e0f1a2b3c4d5e6f7a8b9c8d9e0'
    assert c.hash(Algorithm.SHA224) == 'a9b8c7d6e5f4g3h2i1j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6'

# Generated at 2022-06-17 22:31:08.309323
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'a8a8a8a8a8a8a8a8a8a8a8a8a8a8a8a8'


# Generated at 2022-06-17 22:31:09.847630
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-17 22:31:12.050705
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'd6d2c0a7a9f9a9b9b9e0c9a9a9a9a9a9'


# Generated at 2022-06-17 22:31:23.276594
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash(Algorithm.SHA1) == c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA224) == c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256) == c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384) == c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA512) == c.hash(Algorithm.SHA512)
    assert c.hash(Algorithm.MD5) == c.hash(Algorithm.MD5)

# Generated at 2022-06-17 22:31:24.734430
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'c4ca4238a0b923820dcc509a6f75849b'


# Generated at 2022-06-17 22:31:32.624288
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'b2d0c8f0b5c9b9b7d9d9f9e7f5c9b9b7d9d9f9e7f5c9b9b7d9d9f9e7f5c9b9b7'
    assert crypto.hash(Algorithm.SHA256) == 'b2d0c8f0b5c9b9b7d9d9f9e7f5c9b9b7d9d9f9e7f5c9b9b7d9d9f9e7f5c9b9b7'