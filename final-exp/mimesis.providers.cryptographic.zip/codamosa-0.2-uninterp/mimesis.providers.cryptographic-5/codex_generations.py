

# Generated at 2022-06-17 22:29:28.420573
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:30.636040
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:37.809468
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test Cryptographic.hash()."""
    crypto = Cryptographic()
    assert crypto.hash() == '9a7c8f8d8b7d9b8a8f7d8b8a8f7d9b8a'
    assert crypto.hash(Algorithm.SHA256) == '9a7c8f8d8b7d9b8a8f7d8b8a8f7d9b8a'
    assert crypto.hash(Algorithm.SHA512) == '9a7c8f8d8b7d9b8a8f7d8b8a8f7d9b8a'

# Generated at 2022-06-17 22:29:39.201648
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:42.553129
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == 'e4b8c4e4f0f6a5a6b8a6b8c4e4f0f6a5'


# Generated at 2022-06-17 22:29:45.838258
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'a8c8a5d5d7c0b9e9a8c8a5d5d7c0b9e9'


# Generated at 2022-06-17 22:29:53.468416
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA224)
    assert crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA384)
    assert crypto.hash(Algorithm.SHA512)
    assert crypto.hash(Algorithm.BLAKE2B)
    assert crypto.hash(Algorithm.BLAKE2S)
    assert crypto.hash(Algorithm.SHA3_224)
    assert crypto.hash(Algorithm.SHA3_256)
    assert crypto.hash(Algorithm.SHA3_384)
    assert crypto.hash(Algorithm.SHA3_512)
    assert crypto.hash(Algorithm.SHAKE_128)

# Generated at 2022-06-17 22:30:06.534996
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'e8b0d8e9a0c9f9d1b8f6f0b2f2b6c9c0'
    assert c.hash(Algorithm.SHA1) == 'd8b0d8e9a0c9f9d1b8f6f0b2f2b6c9c0'
    assert c.hash(Algorithm.SHA224) == 'd8b0d8e9a0c9f9d1b8f6f0b2f2b6c9c0'

# Generated at 2022-06-17 22:30:07.999474
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:30:18.403548
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == 'b3c1f2d7d2c0e8b8c2b8a9e9d9c9b8a8'
    assert Cryptographic().hash(Algorithm.SHA1) == 'c8a9b8c9d9e9a9b8c2d2c0f2c1b3'
    assert Cryptographic().hash(Algorithm.SHA224) == 'b8c2b8a9e9d9c9b8c0d2f2d7c1b3'
    assert Cryptographic().hash(Algorithm.SHA256) == 'b8c2b8a9e9d9c9b8c0d2f2d7c1b3e3d2c0e8b8a9'
    assert Crypt