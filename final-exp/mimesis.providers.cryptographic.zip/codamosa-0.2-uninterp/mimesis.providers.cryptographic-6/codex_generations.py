

# Generated at 2022-06-17 22:29:24.135233
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()

# Generated at 2022-06-17 22:29:25.501566
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:35.654449
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA1) == 'e9e9d9b8f8b9e9d9b8f8b9e9d9b8f8b9e9d9b8f8'
    assert Cryptographic().hash(Algorithm.SHA224) == 'e9e9d9b8f8b9e9d9b8f8b9e9d9b8f8b9e9d9b8f8b9e9d9b8f8b9e9d9b8f8b9e9'

# Generated at 2022-06-17 22:29:47.068321
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == '3e3b9a9f9c9f6d0d6c2e6c8a8f8a6d0d6c2e6c8a8f8a6d0d6c2e6c8a8f8a6d0d'
    assert c.hash(Algorithm.MD5) == '3e3b9a9f9c9f6d0d6c2e6c8a8f8a6d0d'
    assert c.hash(Algorithm.SHA1) == '3e3b9a9f9c9f6d0d6c2e6c8a8f8a6d0d6c2e6c8a'

# Generated at 2022-06-17 22:29:53.854482
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()

# Generated at 2022-06-17 22:30:01.140971
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA256) == 'd4d4b7e7c9f9b8f7e1e1a1a2a2b3b3c3c4c4d5d5d6d6e7e7e8e8f9f9fafa0a0b1b1'


# Generated at 2022-06-17 22:30:11.335920
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == 'a8b9c8d7e6f5a4b3c2d1e0f9e8d7c6b5'
    assert Cryptographic().hash(Algorithm.SHA1) == 'a8b9c8d7e6f5a4b3c2d1e0f9e8d7c6b5'
    assert Cryptographic().hash(Algorithm.SHA224) == 'a8b9c8d7e6f5a4b3c2d1e0f9e8d7c6b5'
    assert Cryptographic().hash(Algorithm.SHA256) == 'a8b9c8d7e6f5a4b3c2d1e0f9e8d7c6b5'
    assert Crypt

# Generated at 2022-06-17 22:30:15.348920
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'e0d7d9b8c8f7a0b0c1e7e6f3c3b7f1b0'


# Generated at 2022-06-17 22:30:16.691624
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-17 22:30:17.886007
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:30:34.970761
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == '7b9f9b7d7b9f9b7d7b9f9b7d7b9f9b7d'
    assert crypto.hash(Algorithm.SHA1) == '7b9f9b7d7b9f9b7d7b9f9b7d7b9f9b7d7b9f9b7d'

# Generated at 2022-06-17 22:30:38.303833
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e7f8b8a8d8b9e9e9f8f8f8f8f8f8f8f8'


# Generated at 2022-06-17 22:30:43.115267
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print(Cryptographic().hash())
    print(Cryptographic().hash(Algorithm.SHA1))
    print(Cryptographic().hash(Algorithm.SHA256))
    print(Cryptographic().hash(Algorithm.SHA512))
    print(Cryptographic().hash(Algorithm.MD5))


# Generated at 2022-06-17 22:30:51.002789
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b5d5f5a5a5b5d5d5f5a5a5b5d5d5f5a5'
    assert c.hash(Algorithm.SHA1) == 'a5d5f5a5a5b5d5d5f5a5a5b5d5d5f5a5'
    assert c.hash(Algorithm.SHA224) == 'd5f5a5a5b5d5d5f5a5a5b5d5d5f5a5a5'
    assert c.hash(Algorithm.SHA256) == 'f5a5a5b5d5d5f5a5a5b5d5d5f5a5a5d5'

# Generated at 2022-06-17 22:31:04.026499
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'd4f4a2b4e8f9a9b9d9c4b4e4a8f9f4a2'
    assert crypto.hash(Algorithm.SHA256) == 'd4f4a2b4e8f9a9b9d9c4b4e4a8f9f4a2'
    assert crypto.hash(Algorithm.SHA512) == 'd4f4a2b4e8f9a9b9d9c4b4e4a8f9f4a2'

# Generated at 2022-06-17 22:31:13.567028
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'c7d8f8b8a7f9e9d9c9e8d8f8a7f9e9d9'
    assert crypto.hash(Algorithm.SHA1) == 'c7d8f8b8a7f9e9d9c9e8d8f8a7f9e9d9'
    assert crypto.hash(Algorithm.SHA224) == 'c7d8f8b8a7f9e9d9c9e8d8f8a7f9e9d9'

# Generated at 2022-06-17 22:31:16.207505
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-17 22:31:19.747873
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd5d5f5d5c5d5f5d5d5d5f5d5c5d5f5d5'


# Generated at 2022-06-17 22:31:21.874453
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-17 22:31:22.488272
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:31:45.327991
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'a1f7e1a3d4d8b9f9f9a7a1e3d4d8b9f9f9a7a1e3d4d8b9f9f9a7a1e3d4d8b9f9f9'


# Generated at 2022-06-17 22:31:47.476826
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:31:55.652838
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'b7e2d8e9d9f9e9d8e2b7d8e9d9f9e9d8e2b7'
    assert crypto.hash(Algorithm.SHA1) == 'a7c3a3c3a3c3a3c3a7c3a3c3a3c3a3c3a7c3a3c3'
    assert crypto.hash(Algorithm.SHA224) == 'b7e2d8e9d9f9e9d8e2b7d8e9d9f9e9d8e2b7d8e9d9f9e9d8e2b7'

# Generated at 2022-06-17 22:32:05.571851
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == '8a1b8e8c7a0d4c2b8b1e8a1b8e8c7a0d4c2b8b1e'

# Generated at 2022-06-17 22:32:16.858509
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1) == 'f8d8c0e8b8c0f8d8b8c0e8d8c0f8d8e8'
    assert c.hash(Algorithm.SHA224) == 'f8d8c0e8b8c0f8d8b8c0e8d8c0f8d8e8'
    assert c.hash(Algorithm.SHA256) == 'f8d8c0e8b8c0f8d8b8c0e8d8c0f8d8e8'
    assert c.hash(Algorithm.SHA384) == 'f8d8c0e8b8c0f8d8b8c0e8d8c0f8d8e8'


# Generated at 2022-06-17 22:32:18.334214
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b'


# Generated at 2022-06-17 22:32:20.641906
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '8b9e7d9a9e8c7d8b9e7d9a9e8c7d8b9e'


# Generated at 2022-06-17 22:32:22.026123
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:32:22.720490
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != None


# Generated at 2022-06-17 22:32:32.184825
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.SHA1) is not None
    assert c.hash(Algorithm.SHA224) is not None
    assert c.hash(Algorithm.SHA256) is not None
    assert c.hash(Algorithm.SHA384) is not None
    assert c.hash(Algorithm.SHA512) is not None
    assert c.hash(Algorithm.BLAKE2B) is not None
    assert c.hash(Algorithm.BLAKE2S) is not None
    assert c.hash(Algorithm.SHA3_224) is not None
    assert c.hash(Algorithm.SHA3_256) is not None

# Generated at 2022-06-17 22:36:15.610502
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA1) == '9d9c2f7c0b4f4c7a8a3d4c7e9b0f9a7f9a9e9c7f'
    assert crypto.hash(Algorithm.SHA224) == 'b9a0a9d7a9f9c9a7a9e9c7f9d9c2f7c0b4f4c7a8a3d4c7e9b0f9a7f'

# Generated at 2022-06-17 22:36:22.119715
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'f9b2f9a9a7a6a4a3a2a1a0a9a8a7a6a5a4a3a2a1'
    assert crypto.hash(Algorithm.SHA1) == 'f9b2f9a9a7a6a4a3a2a1a0a9a8a7a6a5a4a3a2a1'
    assert crypto.hash(Algorithm.SHA224) == 'f9b2f9a9a7a6a4a3a2a1a0a9a8a7a6a5a4a3a2a1'

# Generated at 2022-06-17 22:36:29.680325
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.SHA1) is not None
    assert c.hash(Algorithm.SHA224) is not None
    assert c.hash(Algorithm.SHA256) is not None
    assert c.hash(Algorithm.SHA384) is not None
    assert c.hash(Algorithm.SHA512) is not None


# Generated at 2022-06-17 22:36:32.915668
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'f8f0d5c5b5b8a8f5f5b5b5b5b5b5b5b5'


# Generated at 2022-06-17 22:36:35.625771
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e9e9c7f2b0c6b8d0c1c8d7f2b0c6b8d0c1c8d7f2b0c6b8d0c1c8d7f2b0c6b8d0'


# Generated at 2022-06-17 22:36:37.444966
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:36:44.285582
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert isinstance(c.hash(), str)
    assert isinstance(c.hash(Algorithm.SHA1), str)
    assert isinstance(c.hash(Algorithm.SHA224), str)
    assert isinstance(c.hash(Algorithm.SHA256), str)
    assert isinstance(c.hash(Algorithm.SHA384), str)
    assert isinstance(c.hash(Algorithm.SHA512), str)
    assert isinstance(c.hash(Algorithm.MD5), str)


# Generated at 2022-06-17 22:36:48.824480
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b8c8f9c9c0a9d9a9c9d9b8c0a9d9a9c9d9b8c0a9d9a9c9d9b8c0a9d9a9c9d9b8'


# Generated at 2022-06-17 22:36:50.087468
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:36:54.286329
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == 'e6f0e2d7a8e8d9c5f5a5f6c5d6b8e6b7'
