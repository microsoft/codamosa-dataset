

# Generated at 2022-06-17 22:29:16.848043
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'e7d0c8f9b8d2c0b6d5a1c3c4b9d6a0f8'
    assert c.hash(Algorithm.MD5) == 'e7d0c8f9b8d2c0b6d5a1c3c4b9d6a0f8'
    assert c.hash(Algorithm.SHA1) == 'f8a0d6b9c4c3a1d5b6c0d2b8f9c8d0e7'

# Generated at 2022-06-17 22:29:18.487051
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'f6d7f6c8e6b9b9a9b9a9b9a9b9a9b9a9'


# Generated at 2022-06-17 22:29:27.905712
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'e8d7b8a3c8d9a2b1c8d9a2b1c8d9a2b1'
    assert crypto.hash(Algorithm.SHA1) == 'e8d7b8a3c8d9a2b1c8d9a2b1c8d9a2b1'
    assert crypto.hash(Algorithm.SHA224) == 'e8d7b8a3c8d9a2b1c8d9a2b1c8d9a2b1'

# Generated at 2022-06-17 22:29:36.658767
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None
    assert c.hash(Algorithm.SHA1) is not None
    assert c.hash(Algorithm.SHA224) is not None
    assert c.hash(Algorithm.SHA256) is not None
    assert c.hash(Algorithm.SHA384) is not None
    assert c.hash(Algorithm.SHA512) is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.BLAKE2B) is not None
    assert c.hash(Algorithm.BLAKE2S) is not None
    assert c.hash(Algorithm.SHA3_224) is not None
    assert c.hash(Algorithm.SHA3_256) is not None

# Generated at 2022-06-17 22:29:47.803497
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'e8b7b2a6b2f8b9c3b3f6d9c6c1b8b8c6'
    assert c.hash(Algorithm.SHA1) == 'a9b7b2a6b2f8b9c3b3f6d9c6c1b8b8c6'
    assert c.hash(Algorithm.SHA224) == 'e8b7b2a6b2f8b9c3b3f6d9c6c1b8b8c6'

# Generated at 2022-06-17 22:29:51.335503
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash(Algorithm.SHA256) == c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA512)


# Generated at 2022-06-17 22:29:53.535314
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-17 22:29:55.689297
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:57.764125
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:30:02.702667
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'


# Generated at 2022-06-17 22:30:18.644647
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    assert Cryptographic().hash(Algorithm.MD5) == 'f8b0d0f9a9e9b8e8d0f9f8b0d0f9a9e9'
    assert Cryptographic().hash(Algorithm.SHA1) == 'f8b0d0f9a9e9b8e8d0f9f8b0d0f9a9e9b8e8d0f9'
    assert Cryptographic().hash(Algorithm.SHA224) == 'f8b0d0f9a9e9b8e8d0f9f8b0d0f9a9e9b8e8d0f9f8b0d0f9a9e9b8e8d0f9'
    assert Crypt

# Generated at 2022-06-17 22:30:19.800588
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:30:23.331520
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '9a8d7f8e8d7f9a8d7f8e8d7f9a8d7f8e'


# Generated at 2022-06-17 22:30:28.905508
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '9d8c0d2f6c7d6c9c0e0b8f3c3d0d6c9c0e0b8f3c3d0d6c9c0e0b8f3c3d0d6c9c0'


# Generated at 2022-06-17 22:30:34.949117
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()
    assert c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA512)
    assert c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.BLAKE2B)
    assert c.hash(Algorithm.BLAKE2S)
    assert c.hash(Algorithm.SHA3_224)
    assert c.hash(Algorithm.SHA3_256)
    assert c.hash(Algorithm.SHA3_384)
    assert c.hash(Algorithm.SHA3_512)
    assert c.hash(Algorithm.SHAKE_128)
    assert c.hash(Algorithm.SHAKE_256)


# Generated at 2022-06-17 22:30:36.751789
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-17 22:30:40.124902
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b8b8b8b8b8b8b8b8b8b8b8b8b8b8b8b8'


# Generated at 2022-06-17 22:30:48.743141
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.text import Text
    from mimesis.providers.utils import get_provider
    from mimesis.typing import Seed

    seed = Seed(12345)
    crypto = Cryptographic(seed)
    text = Text(seed)
    assert crypto.hash() == 'e8d8b8f8c7a9b0f9c8b8d8b8f8c7a9b0f9c8b8d8b8f8c7a9b0f9c8b8d8b8f8c7'

# Generated at 2022-06-17 22:30:52.984962
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() != crypto.hash()
    assert crypto.hash(Algorithm.MD5) != crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA256) != crypto.hash(Algorithm.SHA512)


# Generated at 2022-06-17 22:31:04.167401
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert len(c.hash()) == 64
    assert len(c.hash(Algorithm.SHA1)) == 40
    assert len(c.hash(Algorithm.SHA224)) == 56
    assert len(c.hash(Algorithm.SHA256)) == 64
    assert len(c.hash(Algorithm.SHA384)) == 96
    assert len(c.hash(Algorithm.SHA512)) == 128
    assert len(c.hash(Algorithm.MD5)) == 32
    assert len(c.hash(Algorithm.BLAKE2B)) == 128
    assert len(c.hash(Algorithm.BLAKE2S)) == 64


# Generated at 2022-06-17 22:32:22.711914
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b4f9e7b2c9b0d7f8a8b8c7d8e7f9d7b2'


# Generated at 2022-06-17 22:32:25.910415
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'a8b7b7f0e3c8e0d8c8b7b7f0e3c8e0d8'


# Generated at 2022-06-17 22:32:27.443989
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:32:36.674446
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.SHA1) is not None
    assert c.hash(Algorithm.SHA224) is not None
    assert c.hash(Algorithm.SHA256) is not None
    assert c.hash(Algorithm.SHA384) is not None
    assert c.hash(Algorithm.SHA512) is not None
    assert c.hash(Algorithm.BLAKE2B) is not None
    assert c.hash(Algorithm.BLAKE2S) is not None
    assert c.hash(Algorithm.SHA3_224) is not None
    assert c.hash(Algorithm.SHA3_256) is not None

# Generated at 2022-06-17 22:32:46.100025
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'c4ca4238a0b923820dcc509a6f75849b'
    assert c.hash(Algorithm.SHA1) == 'c4ca4238a0b923820dcc509a6f75849b'
    assert c.hash(Algorithm.SHA224) == 'c4ca4238a0b923820dcc509a6f75849b'
    assert c.hash(Algorithm.SHA256) == 'c4ca4238a0b923820dcc509a6f75849b'
    assert c.hash(Algorithm.SHA384) == 'c4ca4238a0b923820dcc509a6f75849b'

# Generated at 2022-06-17 22:32:54.064306
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == crypto.hash()
    assert crypto.hash(Algorithm.SHA1) == crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA256) == crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA512) == crypto.hash(Algorithm.SHA512)
    assert crypto.hash(Algorithm.MD5) == crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.BLAKE2B) == crypto.hash(Algorithm.BLAKE2B)
    assert crypto.hash(Algorithm.BLAKE2S) == crypto.hash(Algorithm.BLAKE2S)

# Generated at 2022-06-17 22:32:57.485366
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:33:01.829813
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd7e0f8f8b7c8b8b7c8b8b7c8b8b7c8b8'


# Generated at 2022-06-17 22:33:11.950606
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1) == 'b7f8e0f0e8d8c8f8c8c8c8c8c8c8c8c8c8c8c8c8'
    assert c.hash(Algorithm.SHA224) == 'b7f8e0f0e8d8c8f8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8'

# Generated at 2022-06-17 22:33:13.074545
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() is not None


# Generated at 2022-06-17 22:34:57.490108
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'f4c7c4d2b3e5c8f0e0f5c5e5d5f5c0c5'


# Generated at 2022-06-17 22:34:59.809716
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:35:03.835680
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'd4c9f6c8e6e5b6c5f6c5e6e5b6c5f6c5e6e5b6c5f6c5e6e5b6c5f6c5e6e5b6c5'


# Generated at 2022-06-17 22:35:14.530161
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA1) == 'f4b4d4c4f8d4f4c4d4b4f4b4d4c4f8d4f4c4d4b4'
    assert Cryptographic().hash(Algorithm.SHA224) == 'f4b4d4c4f8d4f4c4d4b4f4b4d4c4f8d4f4c4d4b4f4b4d4c4f8d4f4c4d4b4'

# Generated at 2022-06-17 22:35:17.906725
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash(Algorithm.SHA256) == 'c8d6e9a1d7e7d9e9b8a8d6e9a1d7e7d9e9b8a8d6e9a1d7e7d9e9b8a8d6e9a1d7e'


# Generated at 2022-06-17 22:35:18.956804
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:35:27.099401
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    cr = Cryptographic()
    assert cr.hash() == cr.hash()
    assert cr.hash(Algorithm.SHA1) == cr.hash(Algorithm.SHA1)
    assert cr.hash(Algorithm.SHA256) == cr.hash(Algorithm.SHA256)
    assert cr.hash(Algorithm.SHA512) == cr.hash(Algorithm.SHA512)
    assert cr.hash(Algorithm.MD5) == cr.hash(Algorithm.MD5)


# Generated at 2022-06-17 22:35:29.181609
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '5b5d40b3e4b0f38b8eb3bfd2aa5510b3'


# Generated at 2022-06-17 22:35:40.535443
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd4f4d4b4f4d4b4f4d4b4f4d4b4f4d4b4'
    assert c.hash(Algorithm.SHA256) == 'd4f4d4b4f4d4b4f4d4b4f4d4b4f4d4b4'
    assert c.hash(Algorithm.SHA512) == 'd4f4d4b4f4d4b4f4d4b4f4d4b4f4d4b4'

# Generated at 2022-06-17 22:35:49.297428
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae'
    assert crypto.hash(Algorithm.SHA256) == '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae'