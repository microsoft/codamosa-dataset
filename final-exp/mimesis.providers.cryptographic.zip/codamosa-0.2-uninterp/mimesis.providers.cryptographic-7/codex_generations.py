

# Generated at 2022-06-17 22:29:17.338196
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:29:24.892979
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert Cryptographic().hash() == '0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b'
    assert Cryptographic().hash(Algorithm.MD5) == '900150983cd24fb0d6963f7d28e17f72'
    assert Cryptographic().hash(Algorithm.SHA1) == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert Cryptographic().hash(Algorithm.SHA224) == 'd14a028c2a3a2bc9476102bb288234c415a2b01f828ea62ac5b3e42f'

# Generated at 2022-06-17 22:29:35.326190
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    assert Cryptographic().hash(Algorithm.MD5) == 'c4ca4238a0b923820dcc509a6f75849b'
    assert Cryptographic().hash(Algorithm.SHA1) == '356a192b7913b04c54574d18c28d46e6395428ab'
    assert Cryptographic().hash(Algorithm.SHA224) == 'd14a028c2a3a2bc9476102bb288234c415a2b01f828ea62ac5b3e42f'

# Generated at 2022-06-17 22:29:38.771455
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '2e5c6d9b9f8d8f0f7b9c9e3c8c0d8d2e'


# Generated at 2022-06-17 22:29:49.532154
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'd8b2c5a7b0e9e9d9d8f9f9f9f9f9f9f9'
    assert crypto.hash(Algorithm.SHA256) == 'd8b2c5a7b0e9e9d9d8f9f9f9f9f9f9f9'
    assert crypto.hash(Algorithm.SHA512) == 'd8b2c5a7b0e9e9d9d8f9f9f9f9f9f9f9'

# Generated at 2022-06-17 22:29:53.205425
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    assert Cryptographic().hash() == 'c8a7f9a9c9d9e9f9a9b9c9d9e9f9a9b9c9d9e9f9a9b9c9d9e9f9a9b9c9d9e9f9a'


# Generated at 2022-06-17 22:29:58.123433
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b9e8a8e9e9f6c7d6d6c7c7d6d6c7c7d6d6c7c7d6d6c7c7d6d6c7c7d6d6c7c7d6'


# Generated at 2022-06-17 22:30:02.235055
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b'


# Generated at 2022-06-17 22:30:04.493912
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'c5a1b8a8b9e1d0e5c5a1b8a8b9e1d0e5'


# Generated at 2022-06-17 22:30:11.421347
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) == 'c0b8f8a9c9a0a9f2c9d8a8f8c9b8f8a9'
    assert c.hash(Algorithm.SHA1) == 'c0b8f8a9c9a0a9f2c9d8a8f8c9b8f8a9c9a0a9f2'
    assert c.hash(Algorithm.SHA224) == 'c0b8f8a9c9a0a9f2c9d8a8f8c9b8f8a9c9a0a9f2c9d8a8f8c9b8f8a9c9a0a9f2'

# Generated at 2022-06-17 22:30:21.652542
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:30:28.087881
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'b8c0d7d8c1f0d7d8c1f0d7d8c1f0d7d8'


# Generated at 2022-06-17 22:30:33.606830
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'c6f0a6a1e3d8d0f8f9a7e9b9b3c7b9a9'
    assert crypto.hash(Algorithm.SHA1) == 'c6f0a6a1e3d8d0f8f9a7e9b9b3c7b9a9'
    assert crypto.hash(Algorithm.SHA224) == 'c6f0a6a1e3d8d0f8f9a7e9b9b3c7b9a9'

# Generated at 2022-06-17 22:30:36.614244
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'c5e8e50f965cff8e75d570d8339895b1'


# Generated at 2022-06-17 22:30:46.603270
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'b7f3c6a0d8b8e8e9a9d9f3f3c6a0d8b8'
    assert crypto.hash(Algorithm.SHA1) == 'b7f3c6a0d8b8e8e9a9d9f3f3c6a0d8b8'
    assert crypto.hash(Algorithm.SHA224) == 'b7f3c6a0d8b8e8e9a9d9f3f3c6a0d8b8'

# Generated at 2022-06-17 22:30:55.662818
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd2d8f8b4f4c4d0b9d0b8c8e8b4f4c4d0b9d0b8c8e8b4f4c4d0b9d0b8c8e8b4f4c'
    assert c.hash(Algorithm.SHA1) == 'd2d8f8b4f4c4d0b9d0b8c8e8b4f4c4d0b9d0b8c8'

# Generated at 2022-06-17 22:30:59.758101
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'a1c8b7b8a5fbb76aad07dd8e6d0d1011'


# Generated at 2022-06-17 22:31:10.663713
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert c.hash(Algorithm.SHA256) == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-17 22:31:12.291076
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:31:23.613147
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'c5b5d5d6c5e5d5d6c5b5d5d6c5e5d5d6'
    assert crypto.hash(Algorithm.SHA1) == 'c5b5d5d6c5e5d5d6c5b5d5d6c5e5d5d6'
    assert crypto.hash(Algorithm.SHA224) == 'c5b5d5d6c5e5d5d6c5b5d5d6c5e5d5d6'

# Generated at 2022-06-17 22:31:48.705910
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd1c3f8c8e9d9e9d9b7f9f8f8b7f9f8f8'


# Generated at 2022-06-17 22:31:49.760439
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:31:50.500802
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()

# Generated at 2022-06-17 22:32:03.582333
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'd9a9d8d8e4c4a1b4c3c3d8d8a9d9e4e4'
    assert crypto.hash(Algorithm.SHA1) == 'a3b3c3d3e3f3a2b2c2d2e2f2a3b3c3d3e3f3a2b2'
    assert crypto.hash(Algorithm.SHA256) == 'a3b3c3d3e3f3a2b2c2d2e2f2a3b3c3d3e3f3a2b2c2d2e2f2a3b3c3d3e3f3a2b2'

# Generated at 2022-06-17 22:32:08.914972
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd8f8f8a2a3d3c3c3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3'
    assert c.hash(Algorithm.SHA256) == 'd8f8f8a2a3d3c3c3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3'

# Generated at 2022-06-17 22:32:12.612059
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e9b6f9b9-d8f3-4d0a-b2f2-7d3b3c8e7b9e'


# Generated at 2022-06-17 22:32:22.123761
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'f4d9f4c0d8a8a1b7e8d8e0a7d9f8d8e0'
    assert c.hash(Algorithm.SHA1) == 'f4d9f4c0d8a8a1b7e8d8e0a7d9f8d8e0'
    assert c.hash(Algorithm.SHA224) == 'f4d9f4c0d8a8a1b7e8d8e0a7d9f8d8e0'
    assert c.hash(Algorithm.SHA256) == 'f4d9f4c0d8a8a1b7e8d8e0a7d9f8d8e0'

# Generated at 2022-06-17 22:32:31.581716
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == 'f7c3bc1d808e04732adf679965ccc34ca7ae3441'
    assert crypto.hash(Algorithm.SHA1) == 'b6a9c8c230722b7c748331a8b450f055694b3ae3'
    assert crypto.hash(Algorithm.SHA224) == 'e9cad6c4682d1c1c7a7e3b5fa7e7f83c2a7e5d4a9c2a13e895df6a0'

# Generated at 2022-06-17 22:32:32.681630
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() is not None


# Generated at 2022-06-17 22:32:33.699547
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:35:03.768187
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e5e9fa1ba31ecd1ae84f75caaa474f3a663f05f4'
    assert c.hash(Algorithm.SHA256) == 'e5e9fa1ba31ecd1ae84f75caaa474f3a663f05f4'
    assert c.hash(Algorithm.SHA512) == 'e5e9fa1ba31ecd1ae84f75caaa474f3a663f05f4'


# Generated at 2022-06-17 22:35:14.330518
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == 'f6d8c9f9b6e9c8d8f6e9c9f9b6d8c8d8'
    assert Cryptographic().hash(Algorithm.SHA1) == 'd8c8d8f6e9c9f9b6d8c9f9b6e9c8d8f6e9c9f9b6'
    assert Cryptographic().hash(Algorithm.SHA224) == 'd8c8d8f6e9c9f9b6d8c9f9b6e9c8d8f6e9c9f9b6d8c9f9b6e9c8d8f6e9c9f9b6'

# Generated at 2022-06-17 22:35:23.127430
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd9e67a1c8f8b7c0c0b5f7d7e9c9d7f8b'
    assert c.hash(Algorithm.SHA1) == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    assert c.hash(Algorithm.SHA224) == 'd14a028c2a3a2bc9476102bb288234c415a2b01f828ea62ac5b3e42f'

# Generated at 2022-06-17 22:35:32.725511
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'f8a8e8c7e7b9f1a2d1b3c3a4a5a6b6c7'
    assert c.hash(Algorithm.SHA1) == '6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c'
    assert c.hash(Algorithm.SHA224) == '6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c6b5c'

# Generated at 2022-06-17 22:35:36.890295
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e7d6b5f6d7f8f3b3c7d6f3c7d7f8f3b3'


# Generated at 2022-06-17 22:35:43.780171
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == 'c9e9d9d9b2e2b2b2'
    assert crypto.hash(Algorithm.SHA1) == 'b2e2b2b2c9e9d9d9'
    assert crypto.hash(Algorithm.SHA224) == 'b2e2b2b2c9e9d9d9'
    assert crypto.hash(Algorithm.SHA256) == 'b2e2b2b2c9e9d9d9'
    assert crypto.hash(Algorithm.SHA384) == 'b2e2b2b2c9e9d9d9'

# Generated at 2022-06-17 22:35:50.194256
# Unit test for method hash of class Cryptographic

# Generated at 2022-06-17 22:35:52.031525
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:35:54.955925
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:36:00.276757
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    assert Cryptographic().hash() == '5d5e5b5f5c5d5e5b5f5c5d5e5b5f5c5d'
