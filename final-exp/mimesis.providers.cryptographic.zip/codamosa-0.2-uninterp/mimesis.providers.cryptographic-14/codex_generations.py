

# Generated at 2022-06-17 22:29:20.000468
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:22.307436
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:29:24.662234
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e2f9e9d9b9f8f8e8d8d7d7c7c6c6b6b5b5a5a4a4'


# Generated at 2022-06-17 22:29:35.106504
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.SHA1) == '7e7b0c1e7d0d8c2d7b9c9d9f7d7b8c8d7e7b0c1e'
    assert crypto.hash(Algorithm.SHA224) == '7e7b0c1e7d0d8c2d7b9c9d9f7d7b8c8d7e7b0c1e7d0d8c2d7b9c9d9f7d7b8c8d'

# Generated at 2022-06-17 22:29:37.590062
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() != crypto.hash()

# Generated at 2022-06-17 22:29:41.836676
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e8e8b9a9a9c9b9b9b9a9a9a9c9b9b9b9b9a9a9a9c9b9b9b9'


# Generated at 2022-06-17 22:29:51.422208
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'b8f9d9b7a0b9c9e7d8f9a8b7c9e7d8f9'
    assert c.hash(Algorithm.SHA1) == 'd8f9a8b7c9e7d8f9a8b7c9e7d8f9a8b7'
    assert c.hash(Algorithm.SHA224) == 'a8b7c9e7d8f9a8b7c9e7d8f9a8b7c9e7'

# Generated at 2022-06-17 22:30:05.504934
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd7b8b8c0b8a6a9f6e9d8e8c6b8a6b8a6b8a6b8a6b8a6b8a6b8a6b8a6b8a6b8a6'
    assert c.hash(Algorithm.MD5) == 'd7b8b8c0b8a6a9f6e9d8e8c6b8a6b8a6'
    assert c.hash(Algorithm.SHA1) == 'd7b8b8c0b8a6a9f6e9d8e8c6b8a6b8a6b8a6b8a6'


# Generated at 2022-06-17 22:30:09.786505
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '9d8e9a9d0c5b7f7b8f8d7d7c8f8d7d7c8f8d7d7c8f8d7d7c8f8d7d7c8f8d7d7c'


# Generated at 2022-06-17 22:30:11.139588
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash()


# Generated at 2022-06-17 22:30:31.741177
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.MD5) == 'e7c8a8f4d4b0a9b9c9b8b8d4d4a8f4e7'
    assert Cryptographic().hash(Algorithm.SHA1) == '9c8d8b8b9b9a0b4d4d4f4a8e7c8f4e7c'
    assert Cryptographic().hash(Algorithm.SHA224) == 'e7c8a8f4d4b0a9b9c9b8b8d4d4a8f4e7c8f4e7c8f4e7c8f4e7c8f4e7'

# Generated at 2022-06-17 22:30:36.239058
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert Cryptographic().hash() == '6f3a6f8b6d8e9a9b6f3a6f8b6d8e9a9b'


# Generated at 2022-06-17 22:30:46.310847
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd8b8a7d7a4f8b1c8b9e7f0b8f8b7c8b8'
    assert c.hash(Algorithm.SHA1) == 'd8b8a7d7a4f8b1c8b9e7f0b8f8b7c8b8'
    assert c.hash(Algorithm.SHA224) == 'd8b8a7d7a4f8b1c8b9e7f0b8f8b7c8b8'
    assert c.hash(Algorithm.SHA256) == 'd8b8a7d7a4f8b1c8b9e7f0b8f8b7c8b8'

# Generated at 2022-06-17 22:30:52.098383
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'd5c5b5f5b5d5e5f5d5f5d5c5e5d5e5f5d5c5b5f5b5d5e5f5d5f5d5c5e5d5e5f5'


# Generated at 2022-06-17 22:30:54.668779
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() is not None


# Generated at 2022-06-17 22:30:57.272018
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:31:05.584795
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a'
    assert Cryptographic().hash(Algorithm.SHA256) == '8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a8b9a'

# Generated at 2022-06-17 22:31:14.026342
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'e5b5d6a8c0b7a8c5a6d0d6c0b5a8c5d6'
    assert crypto.hash(Algorithm.SHA1) == 'd6b5a8c5d6b5a8c5d6a8c5d6b5a8c5d6'
    assert crypto.hash(Algorithm.SHA224) == 'd6b5a8c5d6b5a8c5d6a8c5d6b5a8c5d6'

# Generated at 2022-06-17 22:31:16.852700
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:31:18.666350
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:31:53.423449
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()

# Generated at 2022-06-17 22:32:04.697251
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()

# Generated at 2022-06-17 22:32:05.513776
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    obj = Cryptographic()
    assert obj.hash() is not None


# Generated at 2022-06-17 22:32:16.848484
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd6d7a8b0c8b1e6a3d6d7a8b0c8b1e6a3'
    assert c.hash(Algorithm.SHA1) == 'f6d7a8b0c8b1e6a3d6d7a8b0c8b1e6a3'
    assert c.hash(Algorithm.SHA224) == 'd6d7a8b0c8b1e6a3d6d7a8b0c8b1e6a3'

# Generated at 2022-06-17 22:32:21.229326
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None
    assert c.hash(Algorithm.SHA1) is not None
    assert c.hash(Algorithm.SHA224) is not None
    assert c.hash(Algorithm.SHA256) is not None
    assert c.hash(Algorithm.SHA384) is not None
    assert c.hash(Algorithm.SHA512) is not None
    assert c.hash(Algorithm.MD5) is not None
    assert c.hash(Algorithm.BLAKE2B) is not None
    assert c.hash(Algorithm.BLAKE2S) is not None
    assert c.hash(Algorithm.SHA3_224) is not None
    assert c.hash(Algorithm.SHA3_256) is not None

# Generated at 2022-06-17 22:32:31.433340
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    assert c.hash(algorithm=Algorithm.SHA1)
    assert c.hash(algorithm=Algorithm.SHA224)
    assert c.hash(algorithm=Algorithm.SHA256)
    assert c.hash(algorithm=Algorithm.SHA384)
    assert c.hash(algorithm=Algorithm.SHA512)
    assert c.hash(algorithm=Algorithm.MD5)
    assert c.hash(algorithm=Algorithm.BLAKE2B)
    assert c.hash(algorithm=Algorithm.BLAKE2S)
    assert c.hash(algorithm=Algorithm.SHA3_224)

# Generated at 2022-06-17 22:32:33.665072
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    assert cr.hash() == 'b2a7e9a8a9b0d6a0a1b1f8d8b0a8d3a3'


# Generated at 2022-06-17 22:32:42.828020
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '4b8c8b9a9b9a8c4b9a9b8c8b4b9a8c8b'
    assert c.hash(Algorithm.SHA256) == '9a8c8b4b9a9b8c8b4b8c8b9a9b9a8c4b'
    assert c.hash(Algorithm.SHA512) == '8c8b4b9a9b8c8b4b8c8b9a9b9a8c4b9a'
    assert c.hash(Algorithm.SHA3_256) == '8b4b9a9b8c8b4b8c8b9a9b9a8c4b9a9b'

# Generated at 2022-06-17 22:32:46.204568
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd8b4a8e0f8b4f3d4a2e9a1c9f9b6d8f0'


# Generated at 2022-06-17 22:32:47.836685
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()
