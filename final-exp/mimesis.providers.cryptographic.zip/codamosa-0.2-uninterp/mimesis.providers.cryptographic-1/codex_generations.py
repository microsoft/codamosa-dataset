

# Generated at 2022-06-17 22:29:14.819878
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() != crypto.hash()


# Generated at 2022-06-17 22:29:19.392881
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test for default value of parameter algorithm
    assert Cryptographic().hash() == '7b9b9e9e7f6e9c9c7b9b9e9e7f6e9c9c'
    # Test for value of parameter algorithm
    assert Cryptographic().hash(Algorithm.SHA256) == '7b9b9e9e7f6e9c9c7b9b9e9e7f6e9c9c'


# Generated at 2022-06-17 22:29:21.559912
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:29:31.641622
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == crypto.hash()
    assert crypto.hash(Algorithm.SHA1) == crypto.hash(Algorithm.SHA1)
    assert crypto.hash(Algorithm.SHA256) == crypto.hash(Algorithm.SHA256)
    assert crypto.hash(Algorithm.SHA512) == crypto.hash(Algorithm.SHA512)
    assert crypto.hash(Algorithm.MD5) == crypto.hash(Algorithm.MD5)
    assert crypto.hash(Algorithm.BLAKE2B) == crypto.hash(Algorithm.BLAKE2B)
    assert crypto.hash(Algorithm.BLAKE2S) == crypto.hash(Algorithm.BLAKE2S)

# Generated at 2022-06-17 22:29:35.282390
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA256) == 'e7c5e8e5d5a5c5e5e7d5e5e5d5a5c5e5e7d5e5e5d5a5c5e5e7d5e5e5d5a5c5e5'


# Generated at 2022-06-17 22:29:46.988890
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == 'b0e7b9f1b8e7b9f1b8e7b9f1b8e7b9f1'
    assert crypto.hash(Algorithm.SHA1) == 'e7b9f1b8e7b9f1b8e7b9f1b8e7b9f1b8e7b9f1b8'

# Generated at 2022-06-17 22:29:48.326629
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:29:51.995571
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128


# Generated at 2022-06-17 22:29:54.234272
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-17 22:30:04.512534
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert crypto.hash(Algorithm.SHA256) == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-17 22:30:18.661369
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash() == 'e0f6f8c6b9c6c0a6d9a6c8b9c0c6c0a6d9a6c8b9c0c6c0a6d9a6c8b9c0c6c0a6'


# Generated at 2022-06-17 22:30:19.840256
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:30:28.087899
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Test with default value
    assert len(Cryptographic().hash()) == 64
    # Test with enum value
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    # Test with string value
    assert len(Cryptographic().hash('sha256')) == 64
    # Test with unsupported algorithm
    assert Cryptographic().hash('unsupported') is None

# Generated at 2022-06-17 22:30:34.595451
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'f8d8b9d9e9e7f8f8e8e7f8f8e8e7f8f8e8e7f8f8e8e7f8f8e8e7f8f8e8e7f8f8'
    assert c.hash(Algorithm.SHA256) == 'f8d8b9d9e9e7f8f8e8e7f8f8e8e7f8f8e8e7f8f8e8e7f8f8e8e7f8f8e8e7f8f8'

# Generated at 2022-06-17 22:30:38.302935
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    assert Cryptographic().hash() == 'e8e6d9f6b9c6b8d6b8d6b8d6b8d6b8d6'


# Generated at 2022-06-17 22:30:43.485940
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32


# Generated at 2022-06-17 22:30:47.391277
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd2b0e9c4a0f7c9f8d2d8e8e4c4a0e9c4a0f7c9f8d2d8e8e4c4a0e9c4a0f7c9f8d2'


# Generated at 2022-06-17 22:30:52.400699
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash(Algorithm.SHA256) == c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA512)


# Generated at 2022-06-17 22:31:00.693780
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert len(Cryptographic().hash()) == 64
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32


# Generated at 2022-06-17 22:31:11.195794
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'd1a0b9a9f9f8f3f3f3f3f3f3f3f3f3f3'
    assert c.hash(Algorithm.SHA1) == 'a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9'
    assert c.hash(Algorithm.SHA256) == 'a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9'
    assert c

# Generated at 2022-06-17 22:32:32.292271
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'e5e9fa1ba31ecd1ae84f75caaa474f3a663f05f4'


# Generated at 2022-06-17 22:32:33.154006
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()


# Generated at 2022-06-17 22:32:34.400322
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == '9c9c9b8e7d8d8c8c8b8b8a8a89898989'


# Generated at 2022-06-17 22:32:43.416244
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd8e8fca2dc0f896fd7cb4cb0031ba249'
    assert c.hash(Algorithm.SHA1) == '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8'
    assert c.hash(Algorithm.SHA224) == 'c9a3f0f9c9e8e7f8f0d1b7b6b5c4c3c2c1a1a0a09f9e9d9c9b'
    assert c.hash(Algorithm.SHA256) == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'

# Generated at 2022-06-17 22:32:47.304977
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd6e8b8c5b5d5e7e5d6e8b8c5b5d5e7e5d6e8b8c5b5d5e7e5'


# Generated at 2022-06-17 22:32:48.483419
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:32:51.091695
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() is not None


# Generated at 2022-06-17 22:32:52.500855
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()

# Generated at 2022-06-17 22:33:04.663702
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA256) == '8c8a8f3c7b7a2a6a8a7f3c3c8a8f3c7b7a2a6a8a7f3c3c8a8f3c7b7a2a6a8a7f3c'

# Generated at 2022-06-17 22:33:14.284317
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA512)
    assert c.hash(Algorithm.BLAKE2B)
    assert c.hash(Algorithm.BLAKE2S)
    assert c.hash(Algorithm.SHA3_224)
    assert c.hash(Algorithm.SHA3_256)
    assert c.hash(Algorithm.SHA3_384)
    assert c.hash(Algorithm.SHA3_512)