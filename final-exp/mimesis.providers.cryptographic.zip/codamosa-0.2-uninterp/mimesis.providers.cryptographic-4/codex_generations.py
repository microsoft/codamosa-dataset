

# Generated at 2022-06-17 22:29:58.154348
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'd9d9b9e8c5b8a7b6d9d9b9e8c5b8a7b6'
    assert crypto.hash(Algorithm.SHA1) == 'c1c1a1b0d0d0e0f0c1c1a1b0d0d0e0f0'
    assert crypto.hash(Algorithm.SHA224) == 'a1a1b1c1d1e1f1a1a1b1c1d1e1f1a1a1'

# Generated at 2022-06-17 22:30:09.338819
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.text import Text
    from mimesis.providers.utils import ProviderType

    crypto = Cryptographic()
    assert isinstance(crypto, ProviderType)
    assert isinstance(crypto.hash(), str)
    assert isinstance(crypto.hash(Algorithm.SHA256), str)
    assert isinstance(crypto.hash(Algorithm.SHA512), str)
    assert isinstance(crypto.hash(Algorithm.SHA1), str)
    assert isinstance(crypto.hash(Algorithm.MD5), str)
    assert isinstance(crypto.hash(Algorithm.BLAKE2B), str)

# Generated at 2022-06-17 22:30:14.793874
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash(Algorithm.SHA256) == c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA512)


# Generated at 2022-06-17 22:30:19.006069
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash(Algorithm.SHA256) == c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA256) != c.hash(Algorithm.SHA512)


# Generated at 2022-06-17 22:30:30.333334
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'b3c1e7f8d9d9c7b3e7f8d9d9c7b3e7f8'
    assert crypto.hash(algorithm=Algorithm.SHA256) == 'b3c1e7f8d9d9c7b3e7f8d9d9c7b3e7f8d9d9c7b3e7f8d9d9c7b3e7f8d9d9c7b3'

# Generated at 2022-06-17 22:30:32.571793
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b6c7b6f9c6b9d9b9c6b9d9b9c6b9d9b9'


# Generated at 2022-06-17 22:30:34.869888
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != Cryptographic().hash()


# Generated at 2022-06-17 22:30:44.739669
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == c.hash()
    assert c.hash(Algorithm.MD5) == c.hash(Algorithm.MD5)
    assert c.hash(Algorithm.SHA1) == c.hash(Algorithm.SHA1)
    assert c.hash(Algorithm.SHA224) == c.hash(Algorithm.SHA224)
    assert c.hash(Algorithm.SHA256) == c.hash(Algorithm.SHA256)
    assert c.hash(Algorithm.SHA384) == c.hash(Algorithm.SHA384)
    assert c.hash(Algorithm.SHA512) == c.hash(Algorithm.SHA512)


# Generated at 2022-06-17 22:30:54.717870
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()

# Generated at 2022-06-17 22:30:56.796444
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() is not None


# Generated at 2022-06-17 22:32:08.772683
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != c.hash()


# Generated at 2022-06-17 22:32:13.865240
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '8b8a0a5a7c2b8f9e8c8d9e9f9c9e8d8a8b8a0a5a7c2b8f9e8c8d9e9f9c9e8d8a'


# Generated at 2022-06-17 22:32:22.984694
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'f4d7e8f9c0e1b8d9b3d7a8b9d0e1f4c0'
    assert c.hash(Algorithm.MD5) == 'f4d7e8f9c0e1b8d9b3d7a8b9d0e1f4c0'
    assert c.hash(Algorithm.SHA1) == 'f4d7e8f9c0e1b8d9b3d7a8b9d0e1f4c0'
    assert c.hash(Algorithm.SHA224) == 'f4d7e8f9c0e1b8d9b3d7a8b9d0e1f4c0'

# Generated at 2022-06-17 22:32:26.104810
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '9d9d8c8c7b7b6a6a595948484757564643535242415150404'


# Generated at 2022-06-17 22:32:35.487075
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash() == 'b8c8d9b7a9f9e8d8c7b6a5b4c3d2e1f0'
    assert c.hash(Algorithm.SHA1) == 'b8c8d9b7a9f9e8d8c7b6a5b4c3d2e1f0'
    assert c.hash(Algorithm.SHA224) == 'b8c8d9b7a9f9e8d8c7b6a5b4c3d2e1f0'

# Generated at 2022-06-17 22:32:36.839890
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert len(Cryptographic().hash()) == 64


# Generated at 2022-06-17 22:32:46.239552
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.hash() == 'b5a5a8d8f9a5a5a5a5a5a5a5a5a5a5a5'
    assert crypto.hash(Algorithm.SHA1) == 'b5a5a8d8f9a5a5a5a5a5a5a5a5a5a5a5'
    assert crypto.hash(Algorithm.SHA224) == 'b5a5a8d8f9a5a5a5a5a5a5a5a5a5a5a5'

# Generated at 2022-06-17 22:32:54.098406
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'f9e5c5f5-5c2b-4c2d-9e5c-5c2b4c2d9e5c'
    assert c.hash(Algorithm.SHA1) == 'f9e5c5f55c2b4c2d9e5c5c2b4c2d9e5c5c2b4c2d'
    assert c.hash(Algorithm.SHA224) == 'f9e5c5f55c2b4c2d9e5c5c2b4c2d9e5c5c2b4c2d9e5c5c2b4c2d9e5c'

# Generated at 2022-06-17 22:33:05.156635
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    c = Cryptographic()
    assert c.hash(Algorithm.MD5) == 'e1e7a8c8a7d5b5b5d0d5a8c8e7e1'
    assert c.hash(Algorithm.SHA1) == 'e1e7a8c8a7d5b5b5d0d5a8c8e7e1'
    assert c.hash(Algorithm.SHA224) == 'e1e7a8c8a7d5b5b5d0d5a8c8e7e1'
    assert c.hash(Algorithm.SHA256) == 'e1e7a8c8a7d5b5b5d0d5a8c8e7e1'

# Generated at 2022-06-17 22:33:06.895826
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash()


# Generated at 2022-06-17 22:35:14.448468
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'b6f5d6d8c8f5b6b9c8f5d6d8b6f5d6d8'


# Generated at 2022-06-17 22:35:23.605229
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    c = Cryptographic()

# Generated at 2022-06-17 22:35:33.049115
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == 'e8f4b4a5c7b0e5f5a8c5f5f5f5f5f5f5'
    assert crypto.hash(Algorithm.SHA1) == 'f8f4b4a5c7b0e5f5a8c5f5f5f5f5f5f5f5f5f5f5'
    assert crypto.hash(Algorithm.SHA224) == 'f8f4b4a5c7b0e5f5a8c5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5'

# Generated at 2022-06-17 22:35:37.621273
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test method hash of class Cryptographic."""
    assert Cryptographic().hash() == 'f8d0d5a7c9a0b3f8d0d5a7c9a0b3f8d0'


# Generated at 2022-06-17 22:35:48.336449
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == 'd8e8fca2dc0f896fd7cb4cb0031ba249'
    assert c.hash(Algorithm.SHA1) == 'd8e8fca2dc0f896fd7cb4cb0031ba249'
    assert c.hash(Algorithm.SHA224) == 'a6d7c8e0f9d9a8a0a0a7c2d2a6e7d1c8d8e8fca2dc0f896fd7cb4cb00'

# Generated at 2022-06-17 22:35:55.020616
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == 'f4a7b8a1c3e7d0c4a3a7f4b8d1c2e3d0'
    assert crypto.hash(Algorithm.SHA1) == 'c6a7e7b8a1c3e7d0c4a3a7f4b8d1c2e3d0c6a7e7'

# Generated at 2022-06-17 22:36:00.871152
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash(Algorithm.SHA1) == '7f9b9a9a7a9e9c9b7f9b9a9a7a9e9c9b7f9b9a9a'


# Generated at 2022-06-17 22:36:06.570285
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.text import Text
    from mimesis.providers.utils import gen_sha256
    from mimesis.typing import Seed

    seed = Seed(12345)
    c = Cryptographic(seed)
    assert c.hash(Algorithm.MD5) == 'b8d9b9a9e9c7e1f9c8c7b8d9b9a9e9c7'
    assert c.hash(Algorithm.SHA1) == 'b8d9b9a9e9c7e1f9c8c7b8d9b9a9e9c7'

# Generated at 2022-06-17 22:36:15.408617
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    crypto = Cryptographic()
    assert crypto.hash(algorithm=Algorithm.SHA256)
    assert crypto.hash(algorithm=Algorithm.SHA512)
    assert crypto.hash(algorithm=Algorithm.SHA1)
    assert crypto.hash(algorithm=Algorithm.MD5)
    assert crypto.hash(algorithm=Algorithm.BLAKE2B)
    assert crypto.hash(algorithm=Algorithm.BLAKE2S)
    assert crypto.hash(algorithm=Algorithm.SHA3_224)
    assert crypto.hash(algorithm=Algorithm.SHA3_256)

# Generated at 2022-06-17 22:36:22.087157
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() == 'e9e0c2b9f9b9c9d4f4b4e4d4c9d4f4b4e4d4c9d4f4b4e4d4c9d4f4b4e4d4c9d4'
    assert Cryptographic().hash(Algorithm.SHA1) == 'e9e0c2b9f9b9c9d4f4b4e4d4c9d4f4b4e4d4c9d4'