

# Generated at 2022-06-21 15:56:34.591352
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64

# Generated at 2022-06-21 15:56:35.927210
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cryp = Cryptographic()
    cryp.token_hex(32)

# Generated at 2022-06-21 15:56:38.522505
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
	my_Cryptographic = Cryptographic()
	content = my_Cryptographic.mnemonic_phrase(12)
	assert isinstance(content, str) == True
	assert len(content.split()) == 12


# Generated at 2022-06-21 15:56:40.447487
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
  c = Cryptographic()
  result = c.mnemonic_phrase()
  print(result)



# Generated at 2022-06-21 15:56:42.432376
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print(Cryptographic.token_bytes())
    print(Cryptographic.token_bytes(16))



# Generated at 2022-06-21 15:56:47.141477
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    x = Cryptographic()
    assert x.hash(algorithm=Algorithm.SHA3_512) != x.hash(algorithm=Algorithm.SHA3_512)

# Generated at 2022-06-21 15:56:59.093575
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test for two methods:

    Test 1: test without separator
    Test 2: test with separator
    """
    class TestMnemonicPhrase:
        """Unit test for method mnemonic_phrase."""

        def test_without_separator(self):
            """Test without separator."""
            inst = Cryptographic('en')
            result = inst.mnemonic_phrase(separator=None)
            #print("result=", result)
            assert isinstance(result, str)
            assert len(result.split()) == 12

        def test_with_separator(self):
            """Test with separator."""
            inst = Cryptographic('en')
            result = inst.mnemonic_phrase(separator='_')
            #print("result=", result)
            assert isinstance(result, str)
            assert len

# Generated at 2022-06-21 15:57:01.241344
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic"""
    test_length = 32
    assert len(Cryptographic().token_hex(test_length)) == 2 * test_length

# Generated at 2022-06-21 15:57:02.876562
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    tmp123: str = Cryptographic.token_hex()
    x: int = len(tmp123)
    assert x == 64

# Generated at 2022-06-21 15:57:04.318237
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()

    assert 1 == len(cr.hash())


# Generated at 2022-06-21 15:57:17.289280
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid1 = Cryptographic.uuid()
    assert uuid1 == Cryptographic.uuid()


# Generated at 2022-06-21 15:57:25.870527
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # создание объекта Cryptographic, который работает с определенным seed'ом
    # чтобы всегда получать одинаковые псевдослучайные значения
    cr = Cryptographic(seed=1234)
    # при попытке сгенерировать псевдослучайное значени

# Generated at 2022-06-21 15:57:29.081546
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex()
    assert isinstance(token, str)
    assert len(token) == 64
    print(token)


# Generated at 2022-06-21 15:57:31.383372
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert isinstance(Cryptographic.token_hex(), str)

if __name__ == "__main__":
    print(Cryptographic.token_hex())

# Generated at 2022-06-21 15:57:34.058770
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Simple case
    assert len(Cryptographic().mnemonic_phrase()) == 12

    # Edge case
    assert len(Cryptographic().mnemonic_phrase(length=1)) == 1

# Generated at 2022-06-21 15:57:37.050790
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    expected = 'f3445e6833969d8a205bdfd3f3b2a53a'
    result = Cryptographic().token_hex(32)
    assert result == expected


# Generated at 2022-06-21 15:57:43.226050
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Testing algorithm SHA1
    assert len(Cryptographic().hash(Algorithm.SHA1)) == 40

    # Testing algorithm SHA224
    assert len(Cryptographic().hash(Algorithm.SHA224)) == 56

    # Testing algorithm SHA256
    assert len(Cryptographic().hash(Algorithm.SHA256)) == 64

    # Testing algorithm SHA384
    assert len(Cryptographic().hash(Algorithm.SHA384)) == 96

    # Testing algorithm SHA512
    assert len(Cryptographic().hash(Algorithm.SHA512)) == 128

    # Testing algorithm MD5
    assert len(Cryptographic().hash(Algorithm.MD5)) == 32



# Generated at 2022-06-21 15:57:46.162969
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == "67d0e1c4-fdcf-4c9b-9f4c-d441e3f3c8ae"
    assert c.uuid(as_object = True) == UUID("67d0e1c4-fdcf-4c9b-9f4c-d441e3f3c8ae")


# Generated at 2022-06-21 15:57:46.800283
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    pass


# Generated at 2022-06-21 15:57:47.785225
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    x = Cryptographic()
    assert(len(x.hash())) == 32

# Generated at 2022-06-21 15:58:41.046420
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    seed = 'Test'

    crypto = Cryptographic(seed)
    result = crypto.uuid(as_object=True)
    assert isinstance(result, UUID)
    assert result == UUID('f080c49a-f0bb-4952-843c-25f91eaa6dc1')

    crypto = Cryptographic(seed)
    result = crypto.uuid()
    assert isinstance(result, str)
    assert result == 'f080c49a-f0bb-4952-843c-25f91eaa6dc1'


# Generated at 2022-06-21 15:58:43.786441
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test Cryptographic.token_bytes method."""
    c = Cryptographic()
    assert c.token_bytes()
    assert len(c.token_bytes()) >= 32


# Generated at 2022-06-21 15:58:44.588682
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass



# Generated at 2022-06-21 15:58:46.749493
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    token_hex = c.token_hex()
    assert (token_hex)
    assert (isinstance(token_hex, str))

# Generated at 2022-06-21 15:58:53.412094
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm
    from mimesis.providers.datetime import Datetime
    crypto = Cryptographic(seed=42424242)

    assert crypto.uuid() == '91b5e532-63f0-4d35-b5c1-2fbd9712de3e'
    assert crypto.hash() == 'daa5c1dccab1fbb0cbfb25a0cb974371e2d1ceb7c8e57a15f7aa02a9a347c9fa'
    assert crypto.hash() == 'b162805d5c5d5ef95f996c3e3d9f46994a102a16bfdd5d0b3d8d6f2ba6f52e0c'

# Generated at 2022-06-21 15:58:56.513427
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    fn = getattr(hashlib, 'md5')
    hashed = fn(Cryptographic().uuid().encode()).hexdigest()
    check = 'abcd'
    assert check in hashed


# Generated at 2022-06-21 15:58:59.711276
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    s = c.token_urlsafe()
    assert type(s) is str
    assert len(s) is 22


# Generated at 2022-06-21 15:59:09.969117
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print("\n=================================================")
    print("Constructor of Class '{}' ".format("Cryptographic"))
    print("=================================================")
    print("\n")
    crypto_data = Cryptographic(seed=111111)
    crypto_data.seed(111)
    select_algorithm = Algorithm.MD5
    print("Select hashing algorithm : ", select_algorithm)
    print("Generate Hash : ", crypto_data.hash(algorithm=select_algorithm))
    print("Generate UUID : ", crypto_data.uuid())
    print("Generate random byte string : ", crypto_data.token_bytes())
    print("Generate random hex string : ", crypto_data.token_hex())
    print("Generate random URL-safe text string : ", crypto_data.token_urlsafe())

# Generated at 2022-06-21 15:59:19.601338
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    test = Cryptographic(seed=30)
    print(test.token_bytes())
    # b'\xaf\x0c\x03\x1e\x93\xa2\x96\x13\xac\xbb\x98\x20\xeb\x08\x7f\xc5\x09\x1c\xb8\x96\xa1\xf1\xf9\xb8W\x88\x86\x0b\x13\x1c\x1c'
    print(test.token_bytes())
    # b'\xe5\xea\x8d\xc2\xbb\xb2\xe9\xd0\x8c\xe7\x95\xea\x1e\x1c\xef\x83\x9b\x8e

# Generated at 2022-06-21 15:59:23.126397
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert(len(set([Cryptographic.uuid() for i in range(0,10)])) == 10)


# Generated at 2022-06-21 16:04:26.991262
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    try:
        import secrets
        import hashlib
        from mimesis.enums import Algorithm
        from mimesis.providers.cryptographic import Cryptographic

        # Initialize with seed
        _seed = secrets.token_hex(32)
        crypto = Cryptographic(seed=_seed)
        # Check the first hash
        _hash = crypto.hash(algorithm=Algorithm.SHA1)
        assert len(_hash) == 40

        # Initialize with seed an algorithm
        _seed = secrets.token_hex(32)
        crypto = Cryptographic(seed=_seed)
        # Check the first hash
        _hash = crypto.hash(algorithm=Algorithm.SHA1)
        assert len(_hash) == 40

    except:
        print("Exception: {}".format(Exception))


# Generated at 2022-06-21 16:04:35.554299
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    print(cr.mnemonic_phrase())
    print(cr.mnemonic_phrase(6))
    print(cr.mnemonic_phrase(6, ','))
    print(cr.uuid())
    print(cr.hash())
    print(cr.hash(Algorithm.SHA1))
    print(cr.token_bytes(128))
    print(cr.token_hex(128))
    print(cr.token_urlsafe(128))

# test_Cryptographic()

# Generated at 2022-06-21 16:04:42.852041
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic(seed=42)

    test_val_1 = crypto.token_urlsafe()
    expected_value_1 = '-srsAufl7jK1Le2QYa3nXA'
    assert test_val_1 == expected_value_1

    test_val_2 = crypto.token_urlsafe()
    expected_value_2 = 'i6yCq0jF5QOz5wuk0hjKzw'
    assert test_val_2 == expected_value_2
    # method derived from: https://github.com/zalando-incubator/nakadi/blob/a3c6de16938b5e5b5ec5c5f73cef095d6773d6b9/nakadi/python_api/nakadi/

# Generated at 2022-06-21 16:04:43.577923
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert isinstance(Cryptographic().token_hex(), str)

# Generated at 2022-06-21 16:04:47.191738
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print("Cryptographic.token_hex()", Cryptographic.token_hex())
    assert Cryptographic.token_hex() is not None

if __name__ == '__main__':
    test_Cryptographic_token_hex()

# Generated at 2022-06-21 16:04:48.097365
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic()


# Generated at 2022-06-21 16:04:52.884538
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from random import Random
    from Crypto.Random import random
    from mimesis.providers.cryptographic import Cryptographic

    random_seed = random.getrandbits(128)
    Cryptographic(random_seed).token_hex()  # type: ignore
    Random(random_seed).random


# Generated at 2022-06-21 16:04:55.979935
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic('en').token_hex()) == 64

# Generated at 2022-06-21 16:04:57.577643
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cr = Cryptographic()
    assert len(cr.token_urlsafe()) == 43

# Generated at 2022-06-21 16:05:03.233327
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for method token_bytes of class Cryptographic."""

    # <WRAP group>
    # <WRAP round>
    # <WRAP centeralign>

    # Initialize Cryptographic object
    cr = Cryptographic()
    bytes = cr.token_bytes()

    # Assert that method returns bytes with length 32
    assert len(bytes) == 32

    # </WRAP>
    # </WRAP>
    # </WRAP>

