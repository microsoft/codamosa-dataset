

# Generated at 2022-06-21 15:56:48.347539
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    h1 = c.hash(Algorithm.MD5)
    h2 = c.hash(Algorithm.SHA1)
    h3 = c.hash(Algorithm.SHA3_512)
    assert h1 != h2 != h3
    assert len(h1) == 32
    assert len(h2) == 40
    assert len(h3) == 128


# Generated at 2022-06-21 15:56:50.692151
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    mimesis = Cryptographic()
    token = mimesis.token_urlsafe()
    print(token)

# Generated at 2022-06-21 15:57:01.586845
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Напишем юнит-тест для проверки работы метода mnemonic_phrase() класса Cryptographic
    # Create a test for checking the method mnemonic_phrase() of class Cryptographic
    # Создадим объект класса Cryptographic
    # Create an object of the class Cryptographic
    test_obj = Cryptographic()
    # Импортируем модуль unittest и создадим тестовый класс
    # Import the unittest module and

# Generated at 2022-06-21 15:57:02.874627
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
	cryptographic = Cryptographic()
	print(cryptographic.mnemonic_phrase())

# Generated at 2022-06-21 15:57:04.318085
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    instance = Cryptographic()
    assert instance.token_hex() == secrets.token_hex()

# Generated at 2022-06-21 15:57:05.504783
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print(Cryptographic.uuid())


# Generated at 2022-06-21 15:57:15.520779
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    t = Cryptographic()
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())
    print(t.token_urlsafe())

# Generated at 2022-06-21 15:57:16.715805
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic()
    assert len(token.token_urlsafe()) == 43

# Generated at 2022-06-21 15:57:20.478009
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # arrange
    uuid = Cryptographic()

    # act
    result = uuid.uuid()

    # assert
    assert isinstance(result, str)
    assert len(result) == 36
    assert result[8] == "-"
    assert result[13] == "-"
    assert result[18] == "-"
    assert result[23] == "-"


# Generated at 2022-06-21 15:57:22.078419
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    phrase = provider.mnemonic_phrase()
    assert provider.mnemonic_phrase() == phrase

# Generated at 2022-06-21 15:59:01.494218
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    assert crypto.token_bytes()


# Generated at 2022-06-21 15:59:05.116902
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic('en')

    assert len(c.token_urlsafe()) == 43

    assert len(c.token_urlsafe(length=32)) == 43

    assert len(c.token_urlsafe(length=100)) == 165



# Generated at 2022-06-21 15:59:09.173553
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    rv = Cryptographic().token_hex()
    assert rv == 'a64c0cb1b0a53b8f5086de9a1f19c1b0dcef73122bddab280b0bb087fb291aa8'


# Generated at 2022-06-21 15:59:14.827312
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	c = Cryptographic()
	result = c.hash()
	
	assert (len(result) == 32), "The length of the generated data is not correct"
	
	for i in result:
		assert (i in ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']), "The generated data is not hexadecimal"


# Generated at 2022-06-21 15:59:17.805348
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    token = c.token_bytes()
    verify = isinstance(token, bytes)
    assert verify == True
    print(token)



# Generated at 2022-06-21 15:59:22.099872
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Arrange
    c = Cryptographic()
    expected_value = str

    # Act
    actual_value = type(c.uuid())

    # Assert
    assert actual_value == expected_value


# Generated at 2022-06-21 15:59:28.109177
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == 'f11fe0a9-f722-4d49-b1c5-1dcfb7c5e527'
    assert c.uuid(as_object = True) == UUID('f11fe0a9-f722-4d49-b1c5-1dcfb7c5e527')


# Generated at 2022-06-21 15:59:30.135364
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Testing token_bytes(entropy: int = 32) -> bytes
    assert isinstance(Cryptographic.token_bytes(), bytes)


# Generated at 2022-06-21 15:59:32.064095
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # test isSuccessful
    # test isSuccessful
    assert Cryptographic().token_bytes() != Cryptographic().token_bytes()


# Generated at 2022-06-21 15:59:36.436514
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64
    assert len(Cryptographic.token_hex(17)) == 32
    import os
    for i in range(4):
        assert Cryptographic.token_hex(i) in (os.urandom(0).hex(), '')