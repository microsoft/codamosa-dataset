

# Generated at 2022-06-21 15:56:33.616850
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 32
    assert type(Cryptographic.token_bytes()) == bytes
    assert len(Cryptographic.token_bytes(32)) == 32
    assert len(Cryptographic.token_bytes(64)) == 128


# Generated at 2022-06-21 15:56:36.055014
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    text = Cryptographic().hash(Algorithm.SHA3_512)
    assert len(text) == 128
    assert text.isalpha()


# Generated at 2022-06-21 15:56:37.331500
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cg = Cryptographic()
    assert cg.hash()


# Generated at 2022-06-21 15:56:49.782139
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj = Cryptographic(seed=42)
    gen = obj.token_bytes()

# Generated at 2022-06-21 15:57:01.133605
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    _uuid = uuid4()

# Generated at 2022-06-21 15:57:03.076123
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c=Cryptographic()
    print()
    print("===hash===")
    print(c.hash(Algorithm.SHA256))


# Generated at 2022-06-21 15:57:05.554621
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonic_phrase = Cryptographic().mnemonic_phrase(5)
    assert len(mnemonic_phrase.split()) == 5

# Generated at 2022-06-21 15:57:09.055176
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic(seed=42)
    phrase = crypto.mnemonic_phrase(length=24)
    assert phrase == 'moved come winged winter general living plant satisfied excuse permit tomato'



# Generated at 2022-06-21 15:57:11.001818
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    assert isinstance(provider.token_bytes(), bytes)


# Generated at 2022-06-21 15:57:11.882087
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 43

# Generated at 2022-06-21 15:57:42.116511
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    assert obj, "could not instantiate Cryptographic"

# Generated at 2022-06-21 15:57:47.705237
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    test_Cryptographic = Cryptographic()

    assert len(test_Cryptographic.mnemonic_phrase()) == 12
    assert callable(test_Cryptographic.__init__)
    assert callable(test_Cryptographic.uuid)
    assert callable(test_Cryptographic.hash)
    assert callable(test_Cryptographic.token_bytes)
    assert callable(test_Cryptographic.token_hex)

# Generated at 2022-06-21 15:57:54.708061
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    _c = Cryptographic()
    _words = ['bald', 'bitter', 'foolish', 'goofy', 'helpful', 'mighty', 'precious', 'tidy', 'taut', 'tired', 'whole', 'uptight']
    _mnemonic_phrase = _c.mnemonic_phrase(separator='-')
    assert _mnemonic_phrase.split('-') == _words

# Generated at 2022-06-21 15:57:59.662456
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    x = c.token_hex()
    assert len(x) == 64
    assert x[0] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-21 15:58:01.554455
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    '''Returns a very long bit string'''
    k = Cryptographic()
    k.token_bytes()


# Generated at 2022-06-21 15:58:05.362568
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase()
    assert c.mnemonic_phrase(separator='-')
    assert c.mnemonic_phrase(length=18)
    assert c.mnemonic_phrase(length=18, separator='-')

# Generated at 2022-06-21 15:58:06.737319
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print(Cryptographic().hash(Algorithm.SHA224))


# Generated at 2022-06-21 15:58:10.122254
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    seed = 42
    provider = Cryptographic(seed)
    result = provider.uuid()
    assert result == '35e03d56-fe09-4b4c-b4a8-4a4cfec054e3'


# Generated at 2022-06-21 15:58:12.499765
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    provider = Cryptographic()
    apikey = provider.token_urlsafe()
    
    return True if len(apikey) == 43 else False

# Generated at 2022-06-21 15:58:19.639048
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    import os
    import json
    import pytest

    try:
        with open(os.path.dirname(__file__) + '/files/crypto.json', 'r') as data:
            test_mt = json.loads(data.read())
    except FileNotFoundError:
        pytest.skip("Could not read test data file")

    token = Cryptographic().token_hex(test_mt['length'])
    print(token)
    assert len(token) == test_mt['length']*2
    assert type(token) == str
