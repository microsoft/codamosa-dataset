

# Generated at 2022-06-21 15:59:04.617508
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str)
    assert isinstance(Cryptographic().uuid(True), UUID)


# Generated at 2022-06-21 15:59:14.780868
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    class Test:
        def __init__(self):
            self._data = {'words': {"normal": ["foo", "bar", "baz", "buzz"]}}

    _cryptographic = Cryptographic(seed=100)
    _cryptographic._data = Test()._data
    assert (_cryptographic.hash() ==
            'fcb30e21e82471adbf66c2eb0f10f5c2a0e0edfcf79770d1fd1fd14e9db9e525')
    assert (_cryptographic.hash() ==
            'a5ed5b7973f1dde5e5bd5e5fc5d691e5a3f3b9039e1b55d102e2847cdcbe9a9f')

# Generated at 2022-06-21 15:59:21.204587
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
	cry = Cryptographic()
	print(cry.uuid())
	print(cry.uuid(as_object=True))
	print(cry.hash())
	print(cry.hash(algorithm=Algorithm.SHA1))
	print(cry.token_bytes())
	print(cry.token_hex())
	print(cry.token_urlsafe())
	print(cry.mnemonic_phrase())
	print(cry.mnemonic_phrase(length=9))
	print(cry.mnemonic_phrase(separator="-"))

if __name__ == '__main__':
	test_Cryptographic()

# Generated at 2022-06-21 15:59:31.291462
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    import pytest
    from mimesis.enums import Algorithm
    
    c1 = Cryptographic()
    c2 = Cryptographic()
    c3 = Cryptographic()

    # test return type
    assert isinstance(c1.mnemonic_phrase(), str)
    assert isinstance(c2.mnemonic_phrase(separator=''), str)
    assert isinstance(c3.mnemonic_phrase(length=20), str)

    # test wrong input
    with pytest.raises(TypeError):
        c1.mnemonic_phrase(separator=123)
    with pytest.raises(TypeError):
        c2.mnemonic_phrase(length='1')

    # test if mnemonic_phrase is not empty
    assert c1.mnemonic_phrase() != ''
    assert c2.mnemonic_

# Generated at 2022-06-21 15:59:33.198972
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cr = Cryptographic()
    result = cr.token_urlsafe()
    print (result)
    pass


# Generated at 2022-06-21 15:59:37.331410
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # invoke constructor
    storage = Cryptographic()

    # assert
    assert storage.__class__.__name__ == 'Cryptographic'
    assert storage.__class__.__module__ == 'mimesis.providers.cryptographic'


# Generated at 2022-06-21 15:59:43.328891
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic(seed=5)
    assert c.uuid() == 'f2a2edb4-fbb4-4d56-a4e4-a7c99ece8bdb'
    assert c.hash() == '9a0f8a7d1b4ee4c7e0ba085efa744d5d'
    assert c.token_bytes() == b'@\x1c\xda\xf3\xdb\x85\xd1\xd9X\xb8\x87\xe6\xc0\x94\xc8\x14\xb1\x1a\xfb\xf8N8\xb7\xff'

# Generated at 2022-06-21 15:59:45.430146
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr = Cryptographic()
    result = cr.token_hex()
    assert result
    assert len(result) > 0


# Generated at 2022-06-21 15:59:50.769916
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    data = Cryptographic()
    hash_value = data.hash(algorithm=Algorithm.SHA256)

    assert isinstance(hash_value, str)
    assert len(hash_value) == 64


# Generated at 2022-06-21 15:59:57.080478
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    field = Cryptographic()
    for i in range(1, 10):
        assert len(field.uuid()) == 36

    assert field.hash(Algorithm.MD5)
    assert field.hash(Algorithm.SHA256)
    assert field.hash(Algorithm.SHA512)

    field.token_bytes()
    field.token_hex()
    field.token_urlsafe()

    mnemonic_phrase = field.mnemonic_phrase()
    assert mnemonic_phrase