

# Generated at 2022-06-21 15:56:32.628276
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    assert Cryptographic().hash(algorithm = Algorithm.MD5) == '3ae41f7f12b9e4b7e3d3d1b7fdb5b5d5'


# Generated at 2022-06-21 15:56:41.415749
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Language
    from mimesis.datetime import Datetime
    from mimesis.builtins import USASpecProvider
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.cryptographic import Cryptographic

    def return_true():
        return True

    def return_false():
        return False

    seed = '123'
    crypto = Cryptographic(seed=seed)
    crypto_custom = Cryptographic(seed=seed, custom_providers={
        'datetime': Datetime
    })
    crypto_loc_ru = Cryptographic(seed=seed, locale=Language.RU)
    crypto_loc_ru_spec_us = Cryptographic(seed=seed, locale=Language.RU,
                                          providers=[USASpecProvider])
    crypto_spec_us

# Generated at 2022-06-21 15:56:44.088648
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()

    assert phrase is not None

# Generated at 2022-06-21 15:56:47.813838
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    phrase = Cryptographic().mnemonic_phrase(length = 12)
    assert len(phrase.split()) == 12
    assert phrase.find(' ') == phrase.rfind(' ')

# Generated at 2022-06-21 15:56:52.073769
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic().hash()
    b = Cryptographic().hash(algorithm=Algorithm.MD5)
    assert a != b
    assert isinstance(a, str)
    assert isinstance(b, str)



# Generated at 2022-06-21 15:56:55.126966
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Given
    ch = Cryptographic()
    # When
    test_hash = ch.hash()
    # Then
    assert isinstance(test_hash, str)



# Generated at 2022-06-21 15:57:01.403087
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=13)
    print(c.mnemonic_phrase())
    # => 'bear practice cool kite book'

    c = Cryptographic(seed=15)
    print(c.mnemonic_phrase(length=4))
    # => 'tiger behind step action'

    c = Cryptographic(seed=15)
    print(c.mnemonic_phrase(length=4, separator='-'))
    # => 'tiger-behind-step-action'

# Generated at 2022-06-21 15:57:02.709684
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr = Cryptographic()
    result = cr.token_hex(32)
    assert result

# Generated at 2022-06-21 15:57:04.120017
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert isinstance(Cryptographic().token_urlsafe(), str)


# Generated at 2022-06-21 15:57:07.535226
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Test with default parameters 
    assert len(Cryptographic.token_urlsafe()) == 45
    # Test with entropy=3
    assert len(Cryptographic.token_urlsafe(entropy=3)) == 6

# Generated at 2022-06-21 15:57:19.259080
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # If: I create a Cryptographic object and call token_bytes
    crypto = Cryptographic()
    token = crypto.token_bytes()
    # Then: A base64 encoded string is returned
    assert isinstance(token, bytes)
    # And: The string is 32 bytes long
    assert len(token) == 32


# Generated at 2022-06-21 15:57:22.607418
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test method token_urlsafe of class Cryptographic."""
    t = Cryptographic()
    x = t.token_urlsafe()
    assert isinstance(x, str)
    assert len(x) == 43


# Generated at 2022-06-21 15:57:24.760652
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    crypto = Cryptographic()
    assert crypto.uuid()
    assert crypto.uuid(as_object=True)


# Generated at 2022-06-21 15:57:27.852428
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase1 = crypto.mnemonic_phrase()
    phrase2 = crypto.mnemonic_phrase()
    assert phrase1 != phrase2

# Generated at 2022-06-21 15:57:29.405962
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe(32)) == 44



# Generated at 2022-06-21 15:57:39.345324
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    import re
    import string
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    cry = Cryptographic()
    t = cry.token_urlsafe()
    assert isinstance(t, str)
    assert re.search(r'[0-9A-Za-z-_]{16}', t) is not None

    t = cry.token_hex(512)
    assert isinstance(t, str)
    assert len(t) == 512*2

    t = cry.uuid()
    assert isinstance(t, str)

# Generated at 2022-06-21 15:57:40.847190
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert type(Cryptographic().hash()) is str


# Generated at 2022-06-21 15:57:41.858439
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert isinstance(Cryptographic.token_bytes(), bytes)


# Generated at 2022-06-21 15:57:46.803683
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Creating local hashtable which is returned by method uuid
    # and matching it with the object which we get by
    # calling this method.
    obj = UUID(int=random.getrandbits(128), version=4)
    test = Cryptographic().uuid(as_object=True)
    assert test == obj


# Generated at 2022-06-21 15:57:47.785133
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(Cryptographic().token_hex())


# Generated at 2022-06-21 15:58:06.437313
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # TODO: Add test code
    a=Cryptographic()
    print(a.token_urlsafe())


# Generated at 2022-06-21 15:58:10.894048
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # To check if the Constructor works fine or not
    # by giving seed as 23
    x = Cryptographic(seed=23, disabled_locales=['en'])
    x.uuid()
    x.hash()
    x.token_hex()
    x.token_bytes()
    x.token_urlsafe()
    x.mnemonic_phrase()
    x.uuid()
    x.uuid(as_object=True)
    x.hash(algorithm=0)
    x.hash(algorithm='sha256')
    x.hash(algorithm=x.choice(types=Algorithm))
    try:
        x.hash(algorithm=5)
    except Exception:
        assert True
    x.token_hex(entropy=1)
    x.token_bytes(entropy=1)


# Generated at 2022-06-21 15:58:14.969421
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token_bytes_1 = crypto.token_bytes()
    assert isinstance(token_bytes_1, bytes)
    assert len(token_bytes_1) == 32

    token_bytes_2 = crypto.token_bytes(64)
    assert isinstance(token_bytes_2, bytes)
    assert len(token_bytes_2) == 64


# Generated at 2022-06-21 15:58:18.657897
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    result = provider.mnemonic_phrase()
    assert result is not None
    assert type(result) == str
    assert len(result) > 0
#

# Generated at 2022-06-21 15:58:21.459603
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid(as_object=True) == UUID('e5b08c87-b754-4df9-8a22-c11250c096a7')

# Generated at 2022-06-21 15:58:23.305497
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    print(c.token_bytes(64))


# Generated at 2022-06-21 15:58:26.774614
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Generate hash
    hash = Cryptographic().hash(Algorithm.MD5)

    # Check if it is a string
    assert isinstance(hash, str)

    # Check if it is a not empty
    assert bool(hash) is True

    # Check if length of hash is 32
    assert len(hash) == 32

# Generated at 2022-06-21 15:58:28.753902
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase(length=12).split()[0] in c.words().values()


# Generated at 2022-06-21 15:58:41.101678
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    ''' Test unit method mnemonic_phrase of class Cryptographic
    '''
    from mimesis.enums import Seed
    from mimesis.providers.cryptographic import Cryptographic

    # Init a cryptographic provider
    cryptographic = Cryptographic(Seed.BASIC)
    phrase = cryptographic.mnemonic_phrase()
    # print('mnemonic phrase = ',phrase)
    assert isinstance(phrase, str)


# Generated at 2022-06-21 15:58:43.823040
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Initialization
    seed = 42
    provider = Cryptographic(seed = seed)
    print(provider)
    assert provider is not None
