

# Generated at 2022-06-21 15:56:40.640675
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    result = crypto.hash(Algorithm.MD5)
    assert len(result) == 32

    crypto = Cryptographic()
    result = crypto.hash(Algorithm.MD5)
    assert len(result) == 32

    crypto = Cryptographic()
    result = crypto.hash(Algorithm.SHA1)
    assert len(result) == 40

    crypto = Cryptographic()
    result = crypto.hash(Algorithm.SHA224)
    assert len(result) == 56

    crypto = Cryptographic()
    result = crypto.hash(Algorithm.SHA256)
    assert len(result) == 64

    crypto = Cryptographic()
    result = crypto.hash(Algorithm.SHA512)
    assert len(result) == 128

    crypto = Cryptographic()
    result = crypto.hash()

# Generated at 2022-06-21 15:56:45.409762
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes(0)) == 0
    assert len(Cryptographic.token_bytes(1)) == 2
    assert len(Cryptographic.token_bytes(32)) == 64
    assert len(Cryptographic.token_bytes()) == 64

# Generated at 2022-06-21 15:56:49.230180
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # given
    entropy = 32
    expected = secrets.token_hex(entropy)

    # when
    result = Cryptographic.token_hex(entropy)

    # then
    assert result == expected

# Generated at 2022-06-21 15:56:53.432324
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    assert c.token_hex() == '526dc5ad593f841df22a2e36b7f3a3f3c7e3cfc5efb0a0769078b5350767b5fa'

# Generated at 2022-06-21 15:57:01.249682
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test hash method of class Cryptographic."""
    crypto = Cryptographic()
    test_data = [
        crypto.hash(Algorithm.SHA1),
        crypto.hash(Algorithm.SHA224),
        crypto.hash(Algorithm.SHA256),
        crypto.hash(Algorithm.SHA384),
        crypto.hash(Algorithm.SHA512),
        crypto.hash(Algorithm.BLAKE2B),
        crypto.hash(Algorithm.BLAKE2S),
    ]

    for test in test_data:
        assert len(test) == 64



# Generated at 2022-06-21 15:57:02.874806
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    assert isinstance(cr.hash(), str)


# Generated at 2022-06-21 15:57:03.896121
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """."""
    assert Cryptographic()

# Generated at 2022-06-21 15:57:05.941485
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    random_token = Cryptographic().token_hex(32)
    assert random_token is not None


# Generated at 2022-06-21 15:57:07.585559
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() == Cryptographic().uuid()


# Generated at 2022-06-21 15:57:10.458800
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    test_args = (32,)
    result = Cryptographic().token_urlsafe(*test_args)
    assert isinstance(result, str)


# Generated at 2022-06-21 15:57:28.210378
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    for i in range(10):
        token_urlsafe_value = crypto.token_urlsafe()
        assert isinstance(token_urlsafe_value, str) and len(token_urlsafe_value) > 0 #noqa
        print(token_urlsafe_value)


# Generated at 2022-06-21 15:57:31.468037
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for method token_hex of class Cryptographic."""
    a = Cryptographic().token_hex(16)
    b = Cryptographic().token_hex(16)
    assert a != b

# Generated at 2022-06-21 15:57:33.195612
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cryptographic = Cryptographic()
    value = cryptographic.uuid()
    assert isinstance(value, str)


# Generated at 2022-06-21 15:57:37.463925
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis import Cryptographic
    crypto = Cryptographic()
    test_alg = Algorithm.__members__[crypto.random.choice(list(Algorithm.__members__))]
    assert crypto.hash(test_alg)


# Generated at 2022-06-21 15:57:42.394475
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    c = Cryptographic()
    assert c.token_urlsafe()
    assert c.token_urlsafe(100)
    assert c.token_urlsafe(20)
    assert c.token_urlsafe(40)
    assert c.token_urlsafe(25)
    assert c.token_urlsafe(60)


# Generated at 2022-06-21 15:57:44.659688
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cry = Cryptographic()
    assert cry.mnemonic_phrase() == 'ecological easy small keep father event'

# Generated at 2022-06-21 15:57:46.422665
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr=Cryptographic(12345)
    answe = cr.hash()
    assert answe.isalnum() == True

# Generated at 2022-06-21 15:57:47.645889
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex()
    print("token = ", token)


# Generated at 2022-06-21 15:57:50.907122
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    b = Cryptographic().token_bytes(32)
    assert isinstance (b, bytes)
    assert len(b) == 32


# Generated at 2022-06-21 15:58:01.627394
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    _hashes = {}
    _hashes['md5'] = 'c5e433c0c68563e55add13fad7b9d9f6'
    _hashes['sha1'] = '1e2a6616af013d3e59ecb3d9de4b4b4b30d8ddc4'
    _hashes['sha256'] = '8c1b891f2d9e863ef3f83a3a23e36a16d52c7d29e2edf95b28d9b1f7c538e0cf'

# Generated at 2022-06-21 15:59:33.767338
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert Cryptographic().token_urlsafe() is not None

# Generated at 2022-06-21 15:59:35.235266
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    print(Cryptographic().token_bytes())


# Generated at 2022-06-21 15:59:38.668478
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    # It is not possible to implement this test because
    # the `token_urlsafe` method is not reproducible.
    pass

# Generated at 2022-06-21 15:59:40.574053
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print(Cryptographic().uuid())
    print(Cryptographic().uuid())
    print(Cryptographic().uuid())
    print(Cryptographic().uuid())


# Generated at 2022-06-21 15:59:44.229882
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """ Perform a unit test."""
    mytest = Cryptographic()
    assert mytest.token_hex() == mytest.token_hex()


# Generated at 2022-06-21 15:59:45.429949
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic.token_hex() != None


# Generated at 2022-06-21 15:59:49.301785
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    result = Cryptographic().mnemonic_phrase()
    assert len(result.split()) == 12
    assert all(word in Cryptographic().__words['normal'] for word in result.split())



# Generated at 2022-06-21 15:59:52.835446
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
	# Initialization of variable, which is a Cryptographic object
	assert type(Cryptographic().token_hex()) == str
	

# Generated at 2022-06-21 15:59:55.312590
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    assert c.token_urlsafe() != c.token_urlsafe()
    returns = c.token_urlsafe(8)
    assert len(returns) == 8 * 3 / 4

# Generated at 2022-06-21 15:59:56.472728
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert not Cryptographic()