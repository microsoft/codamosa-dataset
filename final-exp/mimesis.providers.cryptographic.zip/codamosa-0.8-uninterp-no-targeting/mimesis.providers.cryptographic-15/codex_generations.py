

# Generated at 2022-06-21 15:56:33.755088
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    from mimesis.providers.cryptographic import Cryptographic
    c = Cryptographic()
    assert c.token_bytes() is not None


# Generated at 2022-06-21 15:56:37.163861
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cp = Cryptographic()
    assert len(cp.token_hex()) == 64
    assert len(cp.token_hex(entropy=32)) == 64
    assert cp.token_hex() != cp.token_hex()



# Generated at 2022-06-21 15:56:38.804515
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    bytes = c.token_bytes()
    assert isinstance(bytes, bytes)

# Generated at 2022-06-21 15:56:42.487796
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    assert provider.uuid() != provider.uuid()
    assert provider.numerical_string(int(provider.uuid(), 16)) == provider.numerical_string()



# Generated at 2022-06-21 15:56:55.855483
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Construct Cryptographic."""
    seed = 1024
    cryptographic = Cryptographic(seed)
    assert cryptographic.uuid(True)
    assert cryptographic.hash(Algorithm.MD5)
    assert cryptographic.token_hex(32)
    assert cryptographic.token_urlsafe(32)
    assert cryptographic.mnemonic_phrase()
    assert cryptographic.uuid(False) == '57369079-f31c-46c1-bfd7-7ea8bab578cb'
    assert cryptographic.hash(Algorithm.MD5) == 'e7c79b5a4a7a8ec96d1b7d4b4a86f7fe'
    assert cryptographic.token_hex(32) == 'a7eb814f4d4f4999df58c52e7b9cc3f3'
    assert cryptographic

# Generated at 2022-06-21 15:56:58.691053
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    mimesis = Cryptographic(seed=4)
    expected = "4d902f6d4c6b21eac8a96a78a03f3b3fba6b71f6b933e9a2d0a65b8dd96b1359"
    actual = mimesis.hash()

    assert expected == actual

# Generated at 2022-06-21 15:57:01.133288
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    test_phrase = Cryptographic().mnemonic_phrase()
    assert type(test_phrase) == str
    assert len(test_phrase) == 24


# Generated at 2022-06-21 15:57:11.717038
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Positive tests
    assert len(Cryptographic().token_urlsafe(entropy=32)) == 44
    assert len(Cryptographic().token_urlsafe(entropy=10)) == 16
    assert len(Cryptographic().token_urlsafe(entropy=8)) == 13
    assert len(Cryptographic().token_urlsafe(entropy=6)) == 11
    assert len(Cryptographic().token_urlsafe(entropy=4)) == 8
    assert len(Cryptographic().token_urlsafe(entropy=2)) == 5
    assert len(Cryptographic().token_urlsafe(entropy=1)) == 3
    assert len(Cryptographic().token_urlsafe(entropy=0)) == 1
    assert len(Cryptographic().token_urlsafe(entropy=0)) == 1

# Generated at 2022-06-21 15:57:13.679890
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cryp = Cryptographic()
    assert cryp.token_hex() == secrets.token_hex()

# Generated at 2022-06-21 15:57:16.491430
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    fdir = "./tests/unit_tests/test_Cryptographic_token_urlsafe.txt"
    expected = open(fdir).readline().rstrip("\n")
    assert crypto.token_urlsafe(32) == expected

# Generated at 2022-06-21 15:57:41.380554
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Initialize instance of Cryptographic
    c = Cryptographic()
    #test the hash function
    assert isinstance(c.hash(), str)
    #test the mnemonic_phrase function
    assert isinstance(c.mnemonic_phrase(), str)
    #test the token_bytes function
    assert isinstance(c.token_bytes(), bytes)
    #test the token_hex function
    assert isinstance(c.token_hex(), str)
    #test the token_urlsafe function
    assert isinstance(c.token_urlsafe(), str)
    #test the uuid function
    assert isinstance(c.uuid(), str)

# Generated at 2022-06-21 15:57:43.406155
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() == str(UUID(c.uuid(True)))

# Generated at 2022-06-21 15:57:44.637535
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid = Cryptographic().uuid()
    assert type(uuid) == str and len(uuid) == 36


# Generated at 2022-06-21 15:57:46.384760
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    c = Cryptographic()
    assert c.uuid(as_object=False)
    assert c.uuid(as_object=True)


# Generated at 2022-06-21 15:57:48.270205
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic.token_bytes()) == 32
    assert isinstance(Cryptographic.token_bytes(), bytes)


# Generated at 2022-06-21 15:57:52.009971
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() == '6d7c6f1a79b7c474e935f937c2da8014e828fafc'

# Generated at 2022-06-21 15:58:00.114489
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    print('=== Start the Cryptographic.mnemonic_phrase unit test ===')

    from mimesis.enums import Algorithm
    from mimesis.enums import Seed

    crypto = Cryptographic(Seed.TEST)
    mnemonic = crypto.mnemonic_phrase(length=12, separator='/')
    for word in mnemonic.split('/'):
        print(word)
    assert len(mnemonic.split('/')) == 12

    print('=== Finished the Cryptographic.mnemonic_phrase unit test ===')
    print('')


# Generated at 2022-06-21 15:58:03.293637
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    assert provider.uuid(as_object=True)
    assert provider.uuid()


# Generated at 2022-06-21 15:58:12.771726
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Tests that Cryptographic.token_urlsafe() returns an URL safe token."""
    from mimesis.enums import Algorithm
    from mimesis.mimesis import Mimesis
    from mimesis.providers.utils import TRAVIS

    mimesis = Mimesis(seed=1)
    crypto = Cryptographic(seed=2)

    if TRAVIS:
        expected = '-Zn0H7k-q3JVPp7HSloyDw'  # noqa: E501
    else:
        expected = '9X-xe79U6QsU6RJmdrwfJA'  # noqa: E501

    actual = crypto.token_urlsafe()
    assert expected == actual

    # Test entropy parameter
    crypto = Cryptographic()

# Generated at 2022-06-21 15:58:20.834488
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Crypto=Cryptographic()
    print('Test for constructor of class Cryptographic::')
    print('UUID4:',Crypto.uuid())
    print(Crypto.uuid(as_object=True))
    print('SHA-512:',Crypto.hash(algorithm=Algorithm.SHA512))
    print('Password:',Crypto.mnemonic_phrase())
    print('Password:',Crypto.mnemonic_phrase(length=8,separator='-'))
    print('Token:',Crypto.token_urlsafe(), Crypto.token_hex(), Crypto.token_bytes())

if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-21 15:58:41.099390
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """ cryptograhic = Cryptographic()
    phrase = cryptograhic.mnemonic_phrase()
    print(phrase)
    """

# Generated at 2022-06-21 15:58:42.662525
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert Cryptographic().mnemonic_phrase()
# Unit test - end



# Generated at 2022-06-21 15:58:45.234916
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    test = Cryptographic()
    assert test.mnemonic_phrase() != ''
    assert test.mnemonic_phrase() != None
    assert isinstance(test.mnemonic_phrase(), str)


# Generated at 2022-06-21 15:58:51.299119
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # It is important to have an additional hash function.
    # These functions can be used in a few places, such as in a token.
    # The important thing is that the seed is working and that
    # the hash function works.
    Cryptographic_hash = Cryptographic(seed=0)
    for i in range(100):
        assert Cryptographic_hash.hash(algorithm=Algorithm.SHA256) == 'c9a1e47170916fbae2a08461c2816bbf83d8f6e6980a4e4e4c4d0ddaf6744d4b'


# Generated at 2022-06-21 15:58:58.925090
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    if "Cryptographic" not in dir(__import__("mimesis.data.cryptographic",
                                             fromlist=["Cryptographic"])):
        raise ImportError("object Cryptographic is not found")
    crypto = __import__("mimesis.data.cryptographic",
                        fromlist=["Cryptographic"]).Cryptographic()
    if not crypto.token_bytes() or type(crypto.token_bytes()) is not bytes:
        raise ValueError("value is not returned")
    if type(crypto.token_hex()) is not str:
        raise ValueError("value is not returned")

# Generated at 2022-06-21 15:59:02.403992
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test Cryptographic.token_hex"""
    c1 = Cryptographic.token_hex(32)
    c2 = Cryptographic.token_hex()
    assert len(c1) == 128
    assert len(c2) == 128

# Generated at 2022-06-21 15:59:03.602128
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex(32))==64

# Generated at 2022-06-21 15:59:07.003389
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    length = 32
    tokenbytes = crypto.token_bytes(length)
    assert len(tokenbytes) == length  # Assert we have the correct amount of bytes


# Generated at 2022-06-21 15:59:14.862684
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.__dict__)
    print(c.mnemonic_phrase())
    print(c.mnemonic_phrase(separator='_'))
    print(c.mnemonic_phrase(separator='_', length=5))
    print(c.token_bytes())
    print(c.token_bytes(20))
    print(c.token_hex())
    print(c.token_hex(20))
    print(c.token_urlsafe())
    print(c.token_urlsafe(20))
    print(c.uuid())
    print(c.uuid(as_object=True))

# Generated at 2022-06-21 15:59:22.425111
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic(seed=0).random.randint(1,1000000) == 506117
    assert Cryptographic(seed=0).random.randint(1,1000000) == 506117
    assert Cryptographic(seed=2).random.randint(1,1000000) == 639376
    assert Cryptographic(seed=0).random.randint(1,1000000) == 506117
    assert Cryptographic(seed=0).random.randint(1,1000000) == 506117
    assert Cryptographic().random.randint(1,1000000) != 506117

    assert Cryptographic(seed=0).random.randint(1,1000000) != 245998
    assert Cryptographic(seed=0).random.randint(1,1000000) != 245998
    assert Cryptographic(seed=0).random.randint

# Generated at 2022-06-21 15:59:43.096740
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    s = Cryptographic()
    print(s.token_bytes(1024))


# Generated at 2022-06-21 15:59:52.752312
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic(seed=123456789)
    assert c.uuid() == '3bc45a42-1c44-4f01-8e9c-5f5131f6c2fc'
    assert c.uuid() == '3bc45a42-1c44-4f01-8e9c-5f5131f6c2fc'
    assert c.uuid() == '3bc45a42-1c44-4f01-8e9c-5f5131f6c2fc'
    assert c.uuid() == '3bc45a42-1c44-4f01-8e9c-5f5131f6c2fc'


# Generated at 2022-06-21 15:59:57.616264
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Test length of token_hex
    test = Cryptographic()
    token = test.token_hex()
    assert len(token) == 64
    token = test.token_hex(64)
    assert len(token) == 128
    token = test.token_hex(128)
    assert len(token) == 256
    token = test.token_hex(256)
    assert len(token) == 512
    token = test.token_hex(512)
    assert len(token) == 1024



# Generated at 2022-06-21 16:00:05.494825
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    enums = {
        'sha1': 'sha1',
        'sha224': 'sha224',
        'sha256': 'sha256',
        'sha384': 'sha384',
        'sha512': 'sha512',
        'blake2s': 'blake2s',
        'blake2b': 'blake2b',
        'md5': 'md5'
    }

    cg = Cryptographic()
    for enum, key in enums.items():
        assert cg.hash(enum).startswith(key)


# Generated at 2022-06-21 16:00:15.585103
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Unit test for method hash of class Cryptographic."""
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic

    c = Cryptographic()

    def test_1():
        """Unit test for method hash of class Cryptographic."""
        h = c.hash(algorithm=Algorithm.MD5)
        assert isinstance(h, str) and len(h) == 32

    def test_2():
        """Unit test for method hash of class Cryptographic."""
        h = c.hash(algorithm=Algorithm.SHA1)
        assert isinstance(h, str) and len(h) == 40

    def test_3():
        """Unit test for method hash of class Cryptographic."""
        h = c.hash(algorithm=Algorithm.SHA256)

# Generated at 2022-06-21 16:00:18.766633
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm

    cry = Cryptographic()
    assert cry.hash(algorithm=Algorithm.SHA256) == '54d9e72fe1a7ec23b4a701b735ec4fc2e4e3ebc4e8d769d094a28b7e56b06d77'

# Generated at 2022-06-21 16:00:21.185587
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA1) is not None
    # Error situations
    try:
        Cryptographic().hash()
    except AttributeError:
        pass


# Generated at 2022-06-21 16:00:30.349556
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert Cryptographic().uuid() == "c49ada1a-be30-4ac4-8e85-284d4e4f4e4e"
    assert Cryptographic().uuid(as_object=True) == UUID('a5d5b5c5-1020-3040-5060-708090a0a0a0')
    assert str(Cryptographic().uuid(as_object=True)) == "a5d5b5c5-1020-3040-5060-708090a0a0a0"


# Generated at 2022-06-21 16:00:32.439059
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypt_provider = Cryptographic()
    crypt_provider.token_urlsafe()



# Generated at 2022-06-21 16:00:38.623635
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    print(c.uuid())
    print(c.uuid(as_object=True))
    print(c.hash())
    print(c.hash(Algorithm.MD5))
    print(c.token_bytes())
    print(c.token_hex())
    print(c.token_urlsafe())
    print(c.mnemonic_phrase(length=12))



# Generated at 2022-06-21 16:01:30.011939
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    result = provider.hash()
    assert len(result) == 64


# Generated at 2022-06-21 16:01:32.245949
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    token = Cryptographic().token_urlsafe()
    assert token
    assert len(token) == 43


# Generated at 2022-06-21 16:01:35.236188
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for Cryptographic.uuid()."""
    uuid_1 = Cryptographic().uuid()
    uuid_2 = Cryptographic().uuid()
    assert type(uuid_1) == type(uuid_2)
    assert uuid_1 != uuid_2


# Generated at 2022-06-21 16:01:36.834094
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic().token_urlsafe())



# Generated at 2022-06-21 16:01:39.149622
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    print("test_Cryptographic_hash()")
    hash = Cryptographic().hash(Algorithm.SHA256)
    print("hash = " + hash)
    assert hash is not None

# Generated at 2022-06-21 16:01:45.792558
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()

    crypto.mnemonic_phrase()
    crypto.token_hex()
    crypto.token_bytes()
    crypto.token_urlsafe()
    crypto.hash()
    crypto.hash(Algorithm.SHA1)
    crypto.hash(Algorithm.SHA256)
    crypto.hash(Algorithm.SHA512)
    crypto.hash(Algorithm.SHA3_256)
    crypto.hash(Algorithm.SHA3_512)


# Generated at 2022-06-21 16:01:48.937013
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test Cryptographic.uuid."""
    c = Cryptographic("1234")
    r = c.uuid()
    assert isinstance(r, str)
    assert len(r) == 36
    assert isinstance(c.uuid(as_object=True), UUID)


# Generated at 2022-06-21 16:01:52.449025
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # from mimesis.exceptions import SeedWarning
    c = Cryptographic()
    # with pytest.warns(SeedWarning):
    assert len(c.uuid()) == len('550e8400-e29b-41d4-a716-446655440000')
    assert isinstance(c.uuid(as_object=True), UUID)


# Generated at 2022-06-21 16:01:56.005919
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    x = Cryptographic()
    result = x.hash()
    assert isinstance(result, str)
    assert len(result) == 64
    result = x.hash(Algorithm.MD5)
    assert isinstance(result, str)
    assert len(result) == 32    


# Generated at 2022-06-21 16:01:59.027345
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for Cryptographic.uuid()."""
    cr = Cryptographic()
    result = cr.uuid(False)
    assert isinstance(result, str)
    result = cr.uuid(True)
    assert isinstance(result, UUID)
