

# Generated at 2022-06-21 15:56:23.201790
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    a = Cryptographic().token_urlsafe()
    print(a)


# Generated at 2022-06-21 15:56:25.563634
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Test for method token_bytes of class Cryptographic."""
    bytes_string = Cryptographic().token_bytes()
    assert isinstance(bytes_string, bytes)


# Generated at 2022-06-21 15:56:30.099090
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test for method token_hex of class Cryptographic."""
    char_set = set('0123456789abcdef')
    for _ in range(100):
        token = Cryptographic.token_hex()
        assert len(token) == 64
        assert all(c in char_set for c in token)

# Generated at 2022-06-21 15:56:37.574365
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    x = Cryptographic()
    assert isinstance(x.uuid(), str)
    assert isinstance(x.uuid(as_object=True), UUID)
    assert isinstance(x.hash(Algorithm.MD5), str)
    assert isinstance(x.token_bytes(), bytes)
    assert isinstance(x.token_hex(), str)
    assert isinstance(x.token_urlsafe(), str)
    assert isinstance(x.mnemonic_phrase(), str)

if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-21 15:56:39.314624
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    token = c.token_urlsafe()
    assert isinstance(token, str)

# Generated at 2022-06-21 15:56:39.904659
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    pass

# Generated at 2022-06-21 15:56:42.053460
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a = Cryptographic().token_hex()
    print(a)
    assert a is not None

# Generated at 2022-06-21 15:56:51.674406
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    print("\n#1: ", cr.uuid())
    print("#2: ", cr.hash(Algorithm.SHA512))

    print("\n#3: ", cr.token_bytes(32))
    print("#4: ", cr.token_hex(32))
    print("#5: ", cr.token_urlsafe(32))

    print("\n#6: ", cr.mnemonic_phrase(length=4, separator="-"))

# if __name__ == "__main__":
#     main()

# Generated at 2022-06-21 15:56:55.189228
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed="myseed")
    c.random = c._create_generator(seed=0)
    assert c.mnemonic_phrase(length=1) == "authorize"

# Generated at 2022-06-21 15:56:56.728563
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    a = crypto.uuid()
    print(a)

# Generated at 2022-06-21 15:57:15.913896
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    Cryptographic_tb = Cryptographic()
    res = Cryptographic_tb.token_bytes()
    assert res != None
    # assert isinstance(res, str)
    # assert res > 0

# Generated at 2022-06-21 15:57:16.715022
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic().token_hex()) == 64

# Generated at 2022-06-21 15:57:22.232798
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Test Cryptographic"""

    t0 = Cryptographic.token_hex()
    assert len(t0) == 64
    t1 = Cryptographic.token_hex(32)
    assert len(t1) == 64
    t2 = Cryptographic.token_hex(16)
    assert len(t2) == 32
    t3 = Cryptographic.token_hex(4)
    assert len(t3) == 8
    t4 = Cryptographic.token_hex(1)
    assert len(t4) == 2


# Generated at 2022-06-21 15:57:25.780737
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    # Test 1
    assert crypto.mnemonic_phrase(length=3,separator=' ') == 'get unite damage'

    # Test 2
    assert crypto.mnemonic_phrase(length=1,separator=' ') == 'difficult'

    # Test 3
    assert crypto.mnemonic_phrase(length=1,separator=';') == 'silk'

# Generated at 2022-06-21 15:57:29.448002
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    a = Cryptographic()
    b = Cryptographic()
    c = a.mnemonic_phrase()
    d = b.mnemonic_phrase()
    print(c)
    print(d)


# Generated at 2022-06-21 15:57:31.052648
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    gen = Cryptographic()
    gen.token_urlsafe()

# Generated at 2022-06-21 15:57:33.138338
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    phrase = provider.mnemonic_phrase(length=40)
    assert type(phrase) == str


# Generated at 2022-06-21 15:57:36.410614
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert (len(Cryptographic.token_bytes()) == 32)
    assert (len(Cryptographic.token_bytes(64)) == 64)
    assert (len(Cryptographic.token_bytes(128)) == 128)


# Generated at 2022-06-21 15:57:39.788181
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print("Inside test_Cryptographic_uuid()")

    # Create a class instance
    c = Cryptographic()

    # Generate random UUID4
    value = c.uuid()
    print(value)


# Generated at 2022-06-21 15:57:49.358882
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    print(Cryptographic().random.choice(list(range(100))))
    print(Cryptographic().random.random())
    print(Cryptographic().random.triangular(10, 20, 15))
    print(Cryptographic().random.uniform(1, 10))
    print(Cryptographic().random.weibullvariate(1, 1))
    print(Cryptographic().random.expovariate(1))
    print(Cryptographic().random.gammavariate(1, 1))
    print(Cryptographic().random.gauss(1, 1))
    print(Cryptographic().random.lognormvariate(1, 1))
    print(Cryptographic().random.normalvariate(1, 1))
    print(Cryptographic().random.vonmisesvariate(1, 1))

# Generated at 2022-06-21 15:58:52.667006
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Test constructor.
    crypto = Cryptographic()

    # Test uuid.
    assert isinstance(crypto.uuid(), str)
    assert isinstance(crypto.uuid(as_object=True), UUID)

    # Test hash.
    assert crypto.hash()
    assert crypto.hash('md5')

    # Test token_bytes.
    assert isinstance(crypto.token_bytes(), bytes)

    # Test token_hex.
    assert isinstance(crypto.token_hex(), str)

    # Test token_urlsafe.
    assert isinstance(crypto.token_urlsafe(), str)

    # Test  mnemonic_phrase.
    assert crypto.mnemonic_phrase()
    assert crypto.mnemonic_phrase(10, '-')

# Generated at 2022-06-21 15:59:03.300357
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic(seed=42).hash() =='e89f16dbb19bfab816531772646c1759d3cf83f8c2f608b68a238b3a3a3bc8d2'
    assert Cryptographic(seed=42).hash(algorithm=Algorithm.SHA384) =='1d7a849c8f29b7cbbb2a58d7f83586384a7edd0ae06c1fe0b8d8bbfe5bd7227fa2b0cb32d8e097711eb7b39a3b3a3a87'
    assert Cryptographic(seed=42).mnemonic_phrase() =='favourite erode blossom wonder super force'