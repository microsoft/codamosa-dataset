

# Generated at 2022-06-21 15:56:41.165601
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    c = Cryptographic()
    assert type(c.uuid()).__name__ == 'str'


# Generated at 2022-06-21 15:56:46.791616
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    import re
    from mimesis.enums import Algorithm

    c = Cryptographic()

    for algo in Algorithm:
        assert re.match(r'^[0-9a-f]{64}$', c.hash(algo))


# Generated at 2022-06-21 15:56:48.412955
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    global crypto
    crypto = Cryptographic(seed=0)


# Generated at 2022-06-21 15:56:50.758140
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic().hash(Algorithm.SHA224)
    assert Cryptographic().mnemonic_phrase()



# Generated at 2022-06-21 15:57:01.615689
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Test Cryptographic Class."""
    from mimesis.enums import Algorithm
    cr = Cryptographic()
    # Test UUID
    # assert re.match(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}', cr.uuid(as_object=False))
    # Test token_bytes
    # assert len(cr.token_bytes()) == 32
    # Test token_hex
    # assert len(cr.token_hex()) == 64
    # Test token_urlsafe
    # assert len(cr.token_urlsafe()) == 44
    # Test mnemonic_phrase
    # assert len(cr.mnemonic

# Generated at 2022-06-21 15:57:02.918019
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase()


# Generated at 2022-06-21 15:57:09.005937
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method mnemonic_phrase of class Cryptographic"""
    c = Cryptographic()
    word_count = 12
    mnemonic = c.mnemonic_phrase(length=word_count)

    if mnemonic is None or len(mnemonic.split(' ')) != word_count:
        raise AssertionError()

if __name__ == '__main__':
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-21 15:57:17.787970
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    _Cryptographic = Cryptographic()
    _Cryptographic.seed(12345)

    assert 'b9e2d9ba-c4f8-4d4e-a4d4-20b0e8b4e5b9' == _Cryptographic.uuid()
    assert '5fae2f99-33e6-46db-a56a-9d09e472659b' == _Cryptographic.uuid()
    assert 'bc56c70c-6f9f-4860-9a61-f5af5e5cc51d' == _Cryptographic.uuid()
    assert '70b65a6b-f3cc-4f09-a6e3-6ac6051cbf26' == _Cryptographic.uuid()

# Generated at 2022-06-21 15:57:19.471897
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic.hash(Algorithm.SHA256)
    assert len(cr) == 64
    assert True


# Generated at 2022-06-21 15:57:22.154415
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert crypto.token_hex() == '4eb4b28f0b4cbfcf78876fd95e98c7ed'

# Generated at 2022-06-21 15:58:12.126850
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    gen = Cryptographic()
    result = gen.mnemonic_phrase()

    assert len(result) > 0
    assert type(result) is str
    assert ' ' in result


# Generated at 2022-06-21 15:58:15.163165
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic()
    # 32 length
    assert len(c.token_hex()) == 64

    # 48 length
    assert len(c.token_hex(48)) == 96

    # 59 length
    assert len(c.token_hex(59)) == 118


# Generated at 2022-06-21 15:58:25.786327
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis.enums import Algorithm
    from mimesis.builtins import Cryptographic
    assert str(Cryptographic.uuid()) == 'dcd96c0c-bcf7-4b84-a263-9caf4a4abc53'
    assert str(Cryptographic.uuid()) == 'ccd051aa-a62a-4cf9-96e3-3e8e995ee3ff'
    assert Cryptographic.hash() == Cryptographic.hash()
    assert Cryptographic.hash(Algorithm.SHA1) == Cryptographic.hash(Algorithm.SHA1)
    assert Cryptographic.mnemonic_phrase() == 'lenticular claptrap abstruse avengers hemophilia'
    assert Cryptographic.mnemonic_phrase() == 'lenticular claptrap abstruse avengers hemophilia'

# Generated at 2022-06-21 15:58:26.598170
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash(Algorithm.SHA256)

# Generated at 2022-06-21 15:58:28.713785
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    result = provider.token_bytes()
    print(result)
    assert isinstance(result, bytes)
