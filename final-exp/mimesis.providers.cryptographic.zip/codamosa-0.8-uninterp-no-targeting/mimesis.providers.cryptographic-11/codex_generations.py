

# Generated at 2022-06-21 15:56:40.076468
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.seed == None
    assert crypto.random is not None
    assert crypto.provider is not None
    assert crypto.specification is not None
    assert crypto.localization is not None
    assert crypto.validator is not None
    assert crypto.mimetype is not None
    assert crypto.datetime is not None
    assert crypto.math is not None
    assert crypto.filesystem is not None
    assert crypto.faker is not None
    assert crypto.text is not None
    assert crypto.person is not None
    assert crypto.address is not None
    assert crypto.business is not None
    assert crypto.internet is not None
    assert crypto.code is not None
    assert crypto.date_time is not None
    assert crypto.enums is not None
    assert crypto.numbers is not None

# Generated at 2022-06-21 15:56:43.485505
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    obj = Cryptographic()
    assert len(obj.token_bytes()) == 32
    assert len(obj.token_bytes(entropy=5)) == 10


# Generated at 2022-06-21 15:56:49.115898
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    '''
    Test mimesis.providers.cryptographic.Cryptographic.token_bytes()
    '''
    cr = Cryptographic()
    # Not testable, because it returns a random string
    # assert cr.token_bytes(entropy=32) is not None
    pass


# Generated at 2022-06-21 15:56:51.450466
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    cr = Cryptographic()
    assert isinstance(cr.uuid(), str)


# Generated at 2022-06-21 15:56:56.779953
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe."""
    assert len(Cryptographic.token_urlsafe()) == 43
    assert len(Cryptographic.token_urlsafe(32)) == 43
    assert len(Cryptographic.token_urlsafe(10)) == 19
    assert len(Cryptographic.token_urlsafe(50)) == 86


# Generated at 2022-06-21 15:56:58.777989
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()

    assert crypto.token_bytes() == secrets.token_bytes()


# Generated at 2022-06-21 15:56:59.435789
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cryptographic()

# Generated at 2022-06-21 15:57:00.794428
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    C = Cryptographic()
    assert len(C.token_bytes(32)) == 32



# Generated at 2022-06-21 15:57:02.381136
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase()
    assert isinstance(phrase, str)

# Generated at 2022-06-21 15:57:05.506649
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    a = crypto.uuid()
    b = crypto.uuid(as_object=True)
    assert  isinstance(a, str)
    assert  type(b) == UUID

# Generated at 2022-06-21 15:57:49.959093
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert len(Cryptographic.token_hex()) == 64


# Generated at 2022-06-21 15:57:52.574423
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    res = Cryptographic().uuid()
    assert isinstance(res, str)
    assert len(str(res)) == 36


# Generated at 2022-06-21 15:57:54.060340
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe(): 
  assert len(Cryptographic().token_urlsafe()) == 43


# Generated at 2022-06-21 15:58:03.555430
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    crypto.uuid()  # '21c8b38a-bded-4dfd-a86c-1e0e50fb0079'
    crypto.uuid(as_object=True)  # UUID('21c8b38a-bded-4dfd-a86c-1e0e50fb0079')
    crypto.hash()  # 'c6b600a6cf6215b31ef20e4f4026fd7032512a0dcee2e1b4dc8a85be3e596f31'
    crypto.hash(Algorithm.SHA256)  # '7a96afa8884f4b4af3e66d341cdc051434a0a8f2d1c33a1d5598d27e869a70a

# Generated at 2022-06-21 15:58:05.493203
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    provider = Cryptographic()
    token = provider.token_bytes()
    assert isinstance(token, bytes)
    assert token is not None


# Generated at 2022-06-21 15:58:09.368604
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert type(Cryptographic.token_bytes()) == bytes
    assert len(Cryptographic.token_bytes()) == 32
    assert type(Cryptographic.token_bytes(4)) == bytes
    assert len(Cryptographic.token_bytes(4)) == 4


# Generated at 2022-06-21 15:58:11.117158
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    assert Cryptographic.token_hex() is not None
    assert Cryptographic.token_hex() != ''
    assert len(Cryptographic.token_hex()) == 64
    assert len(Cryptographic.token_hex(64)) == 128
    assert len(Cryptographic.token_hex(128)) == 256


# Generated at 2022-06-21 15:58:16.430031
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Create instance of class Cryptographic()
    crypto = Cryptographic()
    # Call test_Cryptographic_token_urlsafe and store it
    token = crypto.token_urlsafe()
    # Get a pseudorandom URL-safe text string, in Base64 encoding.
    # Should return the following:
    # b'4xqJ4H4vylesvQ8ZcWm3q3DKbPm5E5C5_OjMk1xfbRk'
    assert token == b'4xqJ4H4vylesvQ8ZcWm3q3DKbPm5E5C5_OjMk1xfbRk'


# Generated at 2022-06-21 15:58:26.380024
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    from mimesis import Cryptographic
    from mimesis.builtins import USASpecProvider
    from mimesis.enums import Algorithm
    import json

    data = USASpecProvider()
    cryp = Cryptographic()

    patterns_js = open("mimesis/json/patterns.json").read()
    patterns = json.loads(patterns_js)
    hash_algorithm = Algorithm(patterns['hash']['algorithm'])
    hash_value = cryp.hash(hash_algorithm)

    # Test tokens
    url_token = cryp.token_urlsafe()
    hex_token = cryp.token_hex()
    byte_token = cryp.token_bytes()

    assert len(url_token) >= 32
    assert len(hex_token) >= 64
    assert url_token

# Generated at 2022-06-21 15:58:28.629656
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash(): 
    print("Running test for method hash of class Cryptographic")
    for i in range(10):
        print(Cryptographic().hash())
