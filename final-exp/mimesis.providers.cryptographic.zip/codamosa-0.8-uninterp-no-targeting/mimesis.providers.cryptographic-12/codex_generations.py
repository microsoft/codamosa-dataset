

# Generated at 2022-06-21 15:56:45.953989
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    result = crypto.token_bytes()
    assert isinstance(result, bytes)


# Generated at 2022-06-21 15:56:51.393711
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cg = Cryptographic()
    assert cg.hash(Algorithm.SHA256)
    assert len(cg.hash(Algorithm.SHA256)) == 64
    assert cg.hash(Algorithm.SHA512)
    assert len(cg.hash(Algorithm.SHA512)) == 128

# Generated at 2022-06-21 15:56:53.484162
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    token = crypto.token_bytes()
    print(token)


# Generated at 2022-06-21 15:56:56.523477
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    result = crypto.token_hex()
    assert len(result) == 64
    assert '\n' not in result


# Generated at 2022-06-21 15:56:57.936164
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    k = Cryptographic()
    t = k.token_urlsafe(32)
    print(t)

test_Cryptographic_token_urlsafe()

# Generated at 2022-06-21 15:57:01.210602
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    results = set()
    for _ in range(100):
        results.add(Cryptographic.token_bytes())
    assert(len(results) > 1)
    assert(len(Cryptographic.token_bytes(8)) == 16)


# Generated at 2022-06-21 15:57:04.423509
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    result = Cryptographic().token_urlsafe(entropy=5)
    expected = 'vo1W8dPU7Y9vP4C4l7vv'
    assert result == expected, "Expected {}, got {}".format(result, expected)

# Generated at 2022-06-21 15:57:08.194620
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    for _ in range(100):
        phrase = Cryptographic().mnemonic_phrase()
        assert phrase is not None
        assert phrase != ''
        assert ' ' in phrase
        words = phrase.split(' ')
        assert len(words) == 12

# Generated at 2022-06-21 15:57:11.090229
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():

    cryptographic_obj = Cryptographic()
    token_bytes = cryptographic_obj.token_bytes(entropy=32)
    print(token_bytes)


# Generated at 2022-06-21 15:57:13.717667
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Arrange
    c = Cryptographic()
    # Act
    result = c.token_bytes()
    # Assert
    assert len(result) == 32



# Generated at 2022-06-21 15:58:17.200779
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    actual = [Cryptographic().uuid() for i in range(10)]

# Generated at 2022-06-21 15:58:21.407508
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():

    # Create cryptographic data provider
    # cryptographic_dp = Cryptographic()

    entropy = 32
    byte_str = Cryptographic.token_bytes(entropy)
    print(str(byte_str))
    assert entropy == len(byte_str)


# Generated at 2022-06-21 15:58:23.567087
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.builtins import Cryptographic
    a = Cryptographic()
    assert a.uuid() is not a.uuid()



# Generated at 2022-06-21 15:58:24.497009
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32

# Generated at 2022-06-21 15:58:26.003450
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    assert Cryptographic(seed=0).mnemonic_phrase(12) == 'fashionable kid afford mystery letter blade'

# Generated at 2022-06-21 15:58:27.874632
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print(Cryptographic.uuid())

test_Cryptographic_uuid()


# Generated at 2022-06-21 15:58:41.046636
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    l = c.hash()
    assert len(l) == 64 and l.isalnum()

# Generated at 2022-06-21 15:58:43.107222
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    h = c.hash()
    print(h)
    

# Generated at 2022-06-21 15:58:46.522591
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    assert provider.uuid() == str(UUID('7d2c239f-b4c4-4e7d-917e-8f20b529c4b1'))
    assert isinstance(provider.uuid(as_object=True), UUID)


# Generated at 2022-06-21 15:58:49.556673
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()

    token = crypto.token_bytes(10)
    assert type(token) == bytes
    assert len(token) == 10
    assert crypto.token_bytes() == crypto.token_bytes()



# Generated at 2022-06-21 16:02:24.362047
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    result = Cryptographic().token_bytes()
    assert isinstance(result, bytes)


# Generated at 2022-06-21 16:02:25.925086
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    token = Cryptographic().token_hex(32)
    assert len(token) == 64
    assert type(token) == str


# Generated at 2022-06-21 16:02:36.776453
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    """Unit test for class Cryptographic.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    # Initialize key variables
    seed = None
    number_tests = 100

    # Test UUID
    print('Testing UUID')
    for _ in range(number_tests):
        UUID(str(Cryptographic(seed=seed).uuid()))
    print('UUID Tested.')

    # Test hashes
    print('Testing hashes')
    for value in Algorithm:
        Cryptographic(seed=seed).hash(algorithm=value)
    print('Hashes tested')

    # Test token_bytes
    print('Testing token_bytes')
    for _ in range(number_tests):
        Cryptographic(seed=seed).token_bytes()

# Generated at 2022-06-21 16:02:43.768433
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    def check_uuid(uuid_str: str = None, as_object: bool = False):
        assert Cryptographic().uuid(as_object=as_object).__class__.__name__ == uuid_str

    check_uuid()
    check_uuid('UUID')
    check_uuid('str', as_object=True)


# Generated at 2022-06-21 16:02:45.338351
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    hash = crypto.hash()
    print(hash)


# Generated at 2022-06-21 16:02:47.512276
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    cry = Cryptographic()
    crytoken = cry.token_urlsafe()
    assert crytoken

# Generated at 2022-06-21 16:02:50.718175
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """test_Cryptographic_token_urlsafe"""
    assert len(Cryptographic().token_urlsafe()) == 44
    assert len(Cryptographic().token_urlsafe(512)) == 512


# Generated at 2022-06-21 16:02:54.119840
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.builtins import CRYPTOGRAPHIC
    expected = "e6b0fc6d2f6a0a7bcb2beb3682c4d4ed5c5f3f5c1b5d5bdbfcfbfbfdfdf9f9f9"
    assert CRYPTOGRAPHIC.token_hex() == expected

# Generated at 2022-06-21 16:02:55.107484
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
   c = Cryptographic()
   print(c.hash())


# Generated at 2022-06-21 16:02:57.667577
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic."""
    # Arrange
    crypt = Cryptographic()
    entropy = 32

    # Act
    token = crypt.token_hex(entropy)

    # Assert
    assert len(token) == (entropy * 2)
