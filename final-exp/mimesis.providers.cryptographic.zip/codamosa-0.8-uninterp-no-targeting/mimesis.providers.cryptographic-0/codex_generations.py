

# Generated at 2022-06-21 15:56:29.393346
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    # print(c.mnemonic_phrase())
    assert c.mnemonic_phrase() is not None


# Generated at 2022-06-21 15:56:37.453753
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # Arrange
    _uuid = Cryptographic().uuid()
    _uuid_2 = Cryptographic().uuid(as_object=False)
    _uuid_3 = Cryptographic().uuid(as_object=True)
    _uuid_4 = Cryptographic().uuid(as_object=True)

    # Act
    _expected = len(_uuid)

    # Assert
    assert _expected == len(_uuid_2)
    assert _expected == len(_uuid_3.hex)
    assert _expected == len(_uuid_4.hex)

# Generated at 2022-06-21 15:56:39.858544
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert isinstance(Cryptographic().uuid(), str)
    assert isinstance(Cryptographic().uuid(as_object=True), UUID)



# Generated at 2022-06-21 15:56:48.347814
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.enums import Algorithm
    provider = Cryptographic()
    assert isinstance(provider.uuid(), str)
    assert isinstance(provider.hash(Algorithm.SHA256), str)
    assert isinstance(provider.token_bytes(), bytes)
    assert isinstance(provider.token_hex(), str)
    assert isinstance(provider.token_urlsafe(), str)
    assert isinstance(provider.mnemonic_phrase(), str)

# Generated at 2022-06-21 15:57:00.157322
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    words = crypto._Cryptographic__words['normal']
    # Generate a random mnemonic phrase.
    mnemonic_phrase = crypto.mnemonic_phrase()
    assert mnemonic_phrase != None
    # Generate a random hash.
    token_hex = crypto.hash()
    assert token_hex != None
    # Generate a random URL-safe text string, in Base64 encoding.
    token_urlsafe = crypto.token_urlsafe()
    assert token_urlsafe != None
    # Generate a random text string, in hexadecimal.
    token_hex = crypto.token_hex()
    assert token_hex != None
    # Generate a random byte string.
    token_bytes = crypto.token_bytes()
    assert token_bytes != None
    # Generate a random UUID

# Generated at 2022-06-21 15:57:10.564987
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Tests that the method creates a random UUID."""
    crypto_provider = Cryptographic(seed=42)
    crypto_provider_two = Cryptographic(seed=42)
    crypto_provider_three = Cryptographic(seed=43)

    assert crypto_provider.uuid() == 'a542996e-2d8f-4cd7-b0de-533d7a1a1574'
    assert crypto_provider_two.uuid() == 'a542996e-2d8f-4cd7-b0de-533d7a1a1574'
    assert crypto_provider_three.uuid() == '6b8ac9e9-83fe-49b1-b6d8-c5a7cfb08f41'

    assert crypto_provider.uuid

# Generated at 2022-06-21 15:57:13.269986
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    for i in range(10):
        assert len(crypto.mnemonic_phrase(length=12)) == 12 * 6 - 5


# Generated at 2022-06-21 15:57:13.992416
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    CT = Cryptographic()
    token = CT.token_urlsafe()
    print(token)

# Generated at 2022-06-21 15:57:15.988567
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert len(Cryptographic().token_bytes()) == 32
    assert len(Cryptographic().token_bytes(64)) == 128


# Generated at 2022-06-21 15:57:19.675786
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic(seed=1234)
    assert c.mnemonic_phrase(length=2) == 'halt truer'
    assert c.mnemonic_phrase(length=4, separator='-') == 'bowed-bat-fame-crimp'
    assert c.mnemonic_phrase() != 'bowed-bat-fame-crimp'


# Generated at 2022-06-21 15:57:42.150568
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    a = Cryptographic()
    print(a)
    print(a.mnemonic_phrase())

if __name__ == "__main__":
    test_Cryptographic()

    # error
    # print(a.hash())

# Generated at 2022-06-21 15:57:45.965623
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic('en')
    assert (len(c.token_urlsafe()) == 24)
    assert (len(c.token_urlsafe(32)) == 44)
    assert (len(c.token_urlsafe(64)) == 88)

# Generated at 2022-06-21 15:57:56.942772
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    seed = 1
    assert Cryptographic(seed=seed).token_urlsafe() == "gvIz2X78_o_PzWOrEExvIw"
    assert Cryptographic(seed=seed).token_urlsafe() == "QjTzHy-YNVWImaEaT29FLg"
    assert Cryptographic(seed=seed).token_urlsafe() == "6UJc-WQ_8qoq3NDx17ehww"
    assert Cryptographic(seed=seed).token_urlsafe() == "1Oy73Dg5e5V7x5_FMw_Yg"
    assert Cryptographic(seed=seed).token_urlsafe() == "hcC1H2QxwLPwP1GJTahgaw"
    assert Cryptographic(seed=seed).token_urlsafe

# Generated at 2022-06-21 15:57:58.181242
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp = Cryptographic()
    assert cp.mnemonic_phrase() != ""

# Generated at 2022-06-21 15:57:58.890158
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cryptographic()

# Generated at 2022-06-21 15:57:59.900904
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    assert (isinstance(Cryptographic().uuid(), str))


# Generated at 2022-06-21 15:58:03.821794
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c1 = Cryptographic()
    c2 = Cryptographic()
    c1.seed('foo')
    hash = c1.uuid()
    assert hash == c2.uuid()
    assert isinstance(hash, str)
    assert isinstance(c1.uuid(as_object=True), UUID)
    assert isinstance(c2.uuid(as_object=True), UUID)


# Generated at 2022-06-21 15:58:08.694178
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis import Cryptographic
    c = Cryptographic('en')
    mnemonic_phrase = c.mnemonic_phrase(length=12,separator=" ")
    print(mnemonic_phrase)
    assert(len(mnemonic_phrase.split(" ")) == 12)

if __name__ == '__main__':
    test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-21 15:58:12.498810
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    algorithm = Algorithm.MD5
    h = c.hash(algorithm=algorithm)
    assert len(h) == 32
    assert h == '90d0bdf5c5b542f9640d4c3271f0bf0f'


# Generated at 2022-06-21 15:58:13.856709
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    value = Cryptographic.token_bytes(32)
    assert isinstance(value, bytes) == True
