

# Generated at 2022-06-21 15:56:36.682514
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    provider = Cryptographic()
    hash = provider.hash()
    assert isinstance(hash, str)

    mnemonic_phrase = provider.mnemonic_phrase()
    assert isinstance(mnemonic_phrase, str)

    token_bytes = provider.token_bytes()
    assert isinstance(token_bytes, bytes)

    token_hex = provider.token_hex()
    assert isinstance(token_hex, str)

    token_urlsafe = provider.token_urlsafe()
    assert isinstance(token_urlsafe, str)

    uuid = provider.uuid()
    assert isinstance(uuid, str)

# Generated at 2022-06-21 15:56:38.856062
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic.token_urlsafe()) == 44
    assert len(Cryptographic.token_urlsafe(20)) == 28


# Generated at 2022-06-21 15:56:40.807635
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    phrase = crypto.mnemonic_phrase(length = 12)
    assert phrase

# Generated at 2022-06-21 15:56:45.593932
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method crypt.token_hex."""
    token = Cryptographic().token_hex()
    assert len(token) > 0
    assert isinstance(token, str)
    assert len(token) == 64

# Generated at 2022-06-21 15:56:57.962744
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    """Test for Cryptographic method hash."""
    from mimesis.enums import Algorithm

    p = Cryptographic()

    # Test for MD5
    result = p.hash(algorithm=Algorithm.MD5)
    assert isinstance(result, str)
    assert len(result) == 32

    # Test for SHA1
    result = p.hash(algorithm=Algorithm.SHA1)
    assert isinstance(result, str)
    assert len(result) == 40

    # Test for SHA256
    result = p.hash(algorithm=Algorithm.SHA256)
    assert isinstance(result, str)
    assert len(result) == 64

    # Test for SHA512
    result = p.hash(algorithm=Algorithm.SHA512)
    assert isinstance(result, str)
    assert len(result)

# Generated at 2022-06-21 15:57:00.241514
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex(): # noqa: F811
    """ """
    token_hex = Cryptographic.token_hex(10)
    assert len(token_hex) == 20

# Generated at 2022-06-21 15:57:02.834938
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    Cryptographic = Cryptographic()
    result = Cryptographic.token_bytes(entropy=32)
    assert len(result) == 32
    assert isinstance(result, bytes)


# Generated at 2022-06-21 15:57:05.240344
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    size = 32
    token = crypto.token_urlsafe(size)
    assert len(token) == size * 3 / 4

# Generated at 2022-06-21 15:57:07.688932
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    result = crypto.token_hex()
    print(result)
    assert(type(result) == str)


# Generated at 2022-06-21 15:57:12.233275
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic(seed=1234)
    res = crypto.token_urlsafe()
    assert (res == '8pZLt27q3wYpj_AzWm-L1vuaBC1eQ2X9jRxnNe8rvxID')



# Generated at 2022-06-21 15:57:27.762233
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    cr = Cryptographic()
    for i in range(10):
        print(cr.hash())

# Generated at 2022-06-21 15:57:32.036982
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    """Test method CryptoGraphical.mnemonic_phrase."""
    crypto = Cryptographic()
    mnemo = crypto.mnemonic_phrase()
    assert mnemo.count(' ') == 11
    assert len(mnemo.split(' ')) == 12

test_Cryptographic_mnemonic_phrase()

# Generated at 2022-06-21 15:57:34.058924
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method Cryptographic.uuid"""
    # TODO
    pass


# Generated at 2022-06-21 15:57:38.249632
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.enums import Algorithm
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.cryptographic import Cryptographic

    assert isinstance(Cryptographic.uuid(), str)
    assert isinstance(Cryptographic.uuid(True), UUID)

    # Let's try some different hashes
    cryptographic = Cryptographic()
    algorithms = (Algorithm.SHA256, Algorithm.MD5, Algorithm.SHA512)
    h = list()
    for algorithm in algorithms:
        try:
            h.append(cryptographic.hash(algorithm))
        except NonEnumerableError:
            pass

    assert len(h) > 0

    # Check the token methods
    assert isinstance(Cryptographic.token_bytes(), bytes)
    assert isinstance(Cryptographic.token_hex(), str)


# Generated at 2022-06-21 15:57:39.203422
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
	pass


# Generated at 2022-06-21 15:57:41.066618
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    a1 = Cryptographic().token_hex(12)
    assert a1!=None


# Generated at 2022-06-21 15:57:41.985401
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic.hash() is not None

# Generated at 2022-06-21 15:57:45.397932
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    for i in range(100):
        s = Cryptographic()
        assert len(s.token_hex(32)) == 64
        assert isinstance(s.token_hex(32), str)


# Generated at 2022-06-21 15:57:46.408206
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    t = c.token_urlsafe()
    assert(len(t) == 44)

# Generated at 2022-06-21 15:57:50.048024
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    mnemonic_generator = Cryptographic()
    if mnemonic_generator.mnemonic_phrase(length=3, separator=',') == "":
        return False
    else:
        return True


# Generated at 2022-06-21 16:00:27.564502
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    Crypto_obj = Cryptographic()
    length = Crypto_obj.uuid()
    assert length == 'acaa7f49-2a9d-42c9-b858-6e86cd6e3b6f'


# Generated at 2022-06-21 16:00:29.218216
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid(): 
    cryptographic = Cryptographic()
    x=cryptographic.uuid()
    print(x)


# Generated at 2022-06-21 16:00:34.169527
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp = Cryptographic()
    print(cp.mnemonic_phrase(length=5, separator="-"))
    print(cp.mnemonic_phrase(length=6, separator=" "))
    print(cp.mnemonic_phrase(length=7, separator="-"))
    print(cp.mnemonic_phrase(length=8, separator=" "))


# Generated at 2022-06-21 16:00:38.153764
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    hash = Cryptographic().token_hex(20)
    assert len(hash) == 40
    assert hash[0].isalpha()
    assert hash[1].isalpha()
    assert hash[2].isalpha()


# Generated at 2022-06-21 16:00:40.222371
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    # Create a class for testing
    crypto = Cryptographic()
    # Verify that a uuid is generated
    assert crypto.uuid() is not None

# Generated at 2022-06-21 16:00:40.887418
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    pass

# Generated at 2022-06-21 16:00:43.113427
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    c = Cryptographic()
    assert c.hash() != None
    assert c.hash() != c.hash()


# Generated at 2022-06-21 16:00:44.095265
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    print(Cryptographic.uuid())

# Generated at 2022-06-21 16:00:51.256911
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    cr = Cryptographic("en")
    print("Algorithm.MD5 => " , cr.hash(algorithm=Algorithm.MD5))
    print("Algorithm.SHA224 => " , cr.hash(algorithm=Algorithm.SHA224))
    print("Algorithm.SHA256 => " , cr.hash(algorithm=Algorithm.SHA256))
    print("Algorithm.SHA384 => " , cr.hash(algorithm=Algorithm.SHA384))
    print("Algorithm.SHA512 => " , cr.hash(algorithm=Algorithm.SHA512))


# Generated at 2022-06-21 16:00:58.606454
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test that the output is a valid UUID."""
    import re
    import uuid

    pattern = re.compile(r'[0-9a-f]{8}-?[0-9a-f]{4}-?4[0-9a-f]{3}-?[89ab][0-9a-f]{3}-?[0-9a-f]{12}',
                         re.I)
    result = Cryptographic().uuid()
    assert pattern.match(result), "Not a valid UUID"
