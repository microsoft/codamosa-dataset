

# Generated at 2022-06-21 15:56:33.132993
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    uuid = Cryptographic.uuid()
    assert isinstance(uuid, str)
    assert len(uuid)  == 36


# Generated at 2022-06-21 15:56:35.966990
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Call function
    result = Cryptographic.token_urlsafe(32)

    # Tests
    assert len(result) == 43
    assert isinstance(result, str)


# Generated at 2022-06-21 15:56:42.951272
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    from mimesis.enums import Algorithm
    crypto = Cryptographic()
    assert crypto.__class__.__name__ == 'Cryptographic'
    assert crypto.random.__class__.__name__ == 'Generator'
    assert crypto.seed.__class__.__name__ == 'int'
    assert crypto._seed.__class__.__name__ == 'Generator'
    assert crypto._random.__class__.__name__ == 'Generator'
    assert crypto.per_provider.__class__.__name__ == 'dict'
    assert crypto.uuid() == crypto.uuid()
    assert crypto.uuid() != crypto.uuid()
    assert crypto.hash() == crypto.hash()
    assert crypto.hash() != crypto.hash()
    assert crypto.token_bytes() == crypto.token_bytes()

# Generated at 2022-06-21 15:56:49.613278
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from enum import Enum
    from mimesis.enums import Algorithm

    my_crypto = Cryptographic()
    for method_name in dir(my_crypto.hash(Algorithm.SHA1)) :
        try:
            if method_name[0] != "_":
                print(method_name)
        except :
            pass


# Generated at 2022-06-21 15:56:52.411307
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    obj = Cryptographic()
    assert len(obj.mnemonic_phrase(length=10).split(" ")) == 10



# Generated at 2022-06-21 15:56:53.548700
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    obj = Cryptographic()
    assert obj is not None

# Generated at 2022-06-21 15:57:03.081656
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic(seed=0)
    first_result = crypto.mnemonic_phrase(separator=" ", length=12)
    second_result = crypto.mnemonic_phrase(separator=" ", length=12)
    assert first_result == 'wound instant vehicle garment casino best'
    assert first_result != second_result

# -*- coding: utf-8 -*-
"""
Provides a way to generate data.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from mimesis.builtins import (
    BaseSpecProvider,
    EN_LOCALE,
    PT_BR_LOCALE,
    RUS_LOCALE,
    BaseSpec,
    PropertyTrait,
)
from mimesis.enums import Gender, Language, Property

# Generated at 2022-06-21 15:57:06.443063
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Setup
    entropy = 16
    # Exercise
    expected = secrets.token_hex(entropy)
    result = Cryptographic().token_hex(entropy)
    # Verify
    assert result == expected

# Generated at 2022-06-21 15:57:09.398558
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()  # create an instance of Cryptographic
    tokens = crypto.token_bytes()  # generate a token
    print(tokens)


# Generated at 2022-06-21 15:57:10.914843
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert callable(Cryptographic(seed=None).hash)


# Generated at 2022-06-21 15:57:36.799676
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c1 = Cryptographic()
    c1.uuid()

# Generated at 2022-06-21 15:57:44.147768
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cryptographic = Cryptographic()

    # 设置一个随机的种子数
    cryptographic.seed(1)

    # 调用uuid方法,生成一个随机的uuid的字符串
    print(cryptographic.uuid())

    # 调用hash方法,生成一个随机的hash字符串
    # 此处的algorithm是一个枚举类Algorithm的枚举标签
    print(cryptographic.hash(Algorithm.MD5))

    # 调用token_bytes方法,生成一个随机的bytes数据
   

# Generated at 2022-06-21 15:57:46.294528
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    assert crypto.mnemonic_phrase(1) != None and crypto.mnemonic_phrase(1) != ""

# Generated at 2022-06-21 15:57:47.261914
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    test = Cryptographic()
    assert test.hash()

# Generated at 2022-06-21 15:57:50.736168
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    b = c.token_bytes()
    if not isinstance(b, bytes):
        raise AssertionError('Return value is not bytes')


# Generated at 2022-06-21 15:57:51.917628
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print(Cryptographic.token_urlsafe())

# Generated at 2022-06-21 15:58:02.269998
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm
    
    # print(Algorithm(3))
    # print(Algorithm(4))
    # print(Algorithm(5))
    # print(Algorithm(6))
    # print(Algorithm(7))
    
    
    # To use in your code
    # from mimesis import Cryptographic
    # crypto = Cryptographic()
    # uuid_ = crypto.uuid(as_object=True)
    # print(uuid_)
    # print(crypto.hash(algorithm=Algorithm.SHA512))
    # print(crypto.hash(algorithm=Algorithm.SHA384))
    # print(crypto.hash(algorithm=Algorithm.SHA256))
    # print(crypto.hash(algorithm=Algorithm.SHA224))
    #

# Generated at 2022-06-21 15:58:12.044036
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    from mimesis.data import STRENGTH_TOKENS

    mime = Cryptographic()

    uid = mime.uuid(True)
    assert isinstance(uid, UUID), '{} is not UUID instance'.format(uid)

    uid_string = mime.uuid()
    assert isinstance(uid_string, str), '{} is not a string'.format(uid_string)

    # This hash is cryptographically weak, but still can be used
    # as a verification of randomness
    uid_string_hash = mime.hash(Algorithm.SHA256)

    assert len(uid_string_hash) == 64, '{} is not a valid SHA256 hash with length of 64' .format(uid_string_hash)

# Generated at 2022-06-21 15:58:13.778607
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.__class__.__name__ == 'Cryptographic'
    assert crypto._seed is not None


# Generated at 2022-06-21 15:58:16.657253
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    c = Cryptographic("seed")
    assert c.token_hex() == "ef8b6a0b6e5b6e5dfa1dfee5d9b9c06d"

# Generated at 2022-06-21 16:00:09.152384
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    assert len(Cryptographic.token_hex()) == 64
    algorithm = Algorithm.SHA256
    assert getattr(hashlib, algorithm.name)(Cryptographic.token_hex().encode()).hexdigest()
    assert getattr(hashlib, algorithm.name)(Cryptographic.token_hex(12).encode()).hexdigest()


# Generated at 2022-06-21 16:00:14.332594
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()


# Generated at 2022-06-21 16:00:17.319445
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cr = Cryptographic()
    print(cr.mnemonic_phrase())
    print(cr.mnemonic_phrase(length=15))

# Generated at 2022-06-21 16:00:18.932644
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Unit test for method token_urlsafe of class Cryptographic."""
    token = Cryptographic.token_urlsafe()
    assert token



# Generated at 2022-06-21 16:00:22.890978
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    uuid = Cryptographic().uuid()
    assert type(uuid) == str
    assert len(uuid) == 36
    uuid_object = Cryptographic().uuid(as_object=True)
    assert type(uuid_object) == UUID
    assert uuid_object.hex == '{0!s}'.format(uuid_object)


# Generated at 2022-06-21 16:00:27.522267
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
  crypto = Cryptographic()
  x = crypto.token_urlsafe()
  assert x == "Mszm_KCXWPdHmR1BhR5RJw"


# Generated at 2022-06-21 16:00:29.186307
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()
    r = provider.uuid()
    assert r


# Generated at 2022-06-21 16:00:30.876071
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    result = crypto.token_urlsafe()
    assert result is not None

# Generated at 2022-06-21 16:00:35.826958
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    from mimesis.enums import Algorithm
    from mimesis.providers.cryptographic import Cryptographic
    assert isinstance(Cryptographic().hash(), str)
    assert isinstance(Cryptographic().hash(algorithm=Algorithm.MD5), str)
    assert isinstance(Cryptographic().hash(algorithm=Algorithm.SHA256), str)


# Generated at 2022-06-21 16:00:38.471828
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # We test that the tokens are 42 characters long
    assert len(Cryptographic().token_urlsafe()) == 42