

# Generated at 2022-06-21 15:56:27.285403
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid()
    assert c.uuid(as_object=True)


# Generated at 2022-06-21 15:56:29.325885
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid() != c.uuid()


# Generated at 2022-06-21 15:56:31.829039
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == Cryptographic().token_urlsafe(32)

# Generated at 2022-06-21 15:56:32.871896
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert Cryptographic().token_bytes()



# Generated at 2022-06-21 15:56:34.096378
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    pass


# Generated at 2022-06-21 15:56:36.585633
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    result = set()
    c = Cryptographic()
    for _ in range(100):
        result.add(c.mnemonic_phrase())
    assert len(result) == 100

# Generated at 2022-06-21 15:56:40.326892
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    c = Cryptographic()
    token = c.token_bytes()
    return(len((token)))


if __name__ == "__main__":
    for i in range(10):
        tokensize = test_Cryptographic_token_bytes()
        print(f'{i} tokensize: {tokensize}')


# Generated at 2022-06-21 15:56:44.263538
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex(): # noqa: N802
    crypto = Cryptographic()
    assert crypto.token_hex() == 'd24b2d0e79bbb3dbef50e45985ae3bed'


# Generated at 2022-06-21 15:56:48.882181
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Create random object
    obj = Cryptographic()
    assert len(obj.hash()) == 64
    assert len(obj.hash(Algorithm.SHA512)) == 128
    assert len(obj.hash(algorithm=Algorithm.SHA256)) == 64

# Generated at 2022-06-21 15:57:00.531291
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    # Create an instance of the class Cryptographic 
    x = Cryptographic()
    # Generate a pseudo mnemonic phrase.
    phrase = x.mnemonic_phrase()
    print(phrase)
    # "lose rare all social winner unit increase over fruit slight"
    # --------------------------------------------------------------
    # The number of words in the mnemonic phrase is 12 by default.
    phrase2 = x.mnemonic_phrase(length=12)
    print(phrase2)
    # "summer page visit often rough loose upset process"
    # ----------------------------------------------------
    # The user can specify the separator of the words in the mnemonic phrase.
    phrase3 = x.mnemonic_phrase(length=12,separator="/")
    print(phrase3)
    # "comment/seek/air/glass/world/keen/privacy/agree/st

# Generated at 2022-06-21 15:57:11.255371
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    tester = Cryptographic()
    assert tester.mnemonic_phrase()
    assert tester.uuid()
    assert tester.hash(Algorithm.BLAKE2S)
    assert tester.token_bytes()
    assert tester.token_hex()
    assert tester.token_urlsafe()

# Generated at 2022-06-21 15:57:13.559745
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for token_hex method."""
    f = Cryptographic()
    assert len(f.token_hex()) == 64



# Generated at 2022-06-21 15:57:16.390459
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    cr.mnemonic_phrase()
    cr.hash()
    cr.hash(Algorithm.SHA512)
    cr.token_bytes()
    cr.token_hex()
    cr.token_urlsafe()
    cr.uuid()

# Generated at 2022-06-21 15:57:17.740306
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    for i in range(0,10):
        print(Cryptographic().token_hex())


# Generated at 2022-06-21 15:57:21.960929
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    assert crypto.uuid() == crypto.uuid()
    assert crypto.uuid(as_object=True) == crypto.uuid(as_object=True)
    assert crypto.uuid(as_object=True).__class__ == UUID


# Generated at 2022-06-21 15:57:27.165322
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    print(crypto.uuid())
    print(crypto.hash())
    print(crypto.hash(Algorithm.SHA256))
    print(crypto.token_bytes(2))
    print(crypto.token_hex(32))
    print(crypto.token_urlsafe(32))
    print(crypto.mnemonic_phrase(12))
    print(crypto.mnemonic_phrase(12, '-'))
    print(crypto.mnemonic_phrase(4, '-'))

test_Cryptographic()

# Generated at 2022-06-21 15:57:29.125566
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    entrez = 32
    assert len(Cryptographic.token_bytes(entrez)) == entrez


# Generated at 2022-06-21 15:57:35.085310
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    print("\nMethod token_urlsafe of class Cryptographic:")
    print("Default token_urlsafe")
    print(mimesis.Cryptographic().token_urlsafe())

    print("\nEntropy 32:")
    print(mimesis.Cryptographic().token_urlsafe(32))

    print("\nEntropy 50:")
    print(mimesis.Cryptographic().token_urlsafe(50))


# Generated at 2022-06-21 15:57:36.858322
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    with pytest.raises(NonEnumerableError):
        Cryptographic().hash('SHA1')


# Generated at 2022-06-21 15:57:39.387104
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    provider = Cryptographic()
    hash_ = provider.hash(Algorithm.SHA224)
    assert isinstance(hash_, str)
    assert len(hash_) == 56


# Generated at 2022-06-21 15:58:05.193570
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # validate
    assert(len(Cryptographic().hash(Algorithm.HASHLIB_MD5)) == 32)
    # assert(isinstance(Cryptographic().hash(Algorithm.HASHLIB_SHA1), bytes) == 32)
    assert(len(Cryptographic().hash(Algorithm.HASHLIB_SHA256)) == 64)
    assert(len(Cryptographic().hash(Algorithm.HASHLIB_SHA512)) == 128)


# Generated at 2022-06-21 15:58:11.961414
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypt = Cryptographic(seed=0)
    assert crypt.token_hex() == '2c2f18d8365646a3b4e75bdb0622d1f8'
    assert crypt.token_hex(4) == '8361b4d4'
    assert crypt.token_hex() == '2c2f18d8365646a3b4e75bdb0622d1f8'
    assert crypt.token_hex(16) == '1c716b33ecc8f7b3'

# Generated at 2022-06-21 15:58:13.973042
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    a = Cryptographic()
    bytes = a.token_bytes()
    assert type(bytes) is bytes
    assert len(bytes) == 32


# Generated at 2022-06-21 15:58:14.455372
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert Cryptographic()

# Generated at 2022-06-21 15:58:24.995870
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    for i in range(10):
        print(crypto.mnemonic_phrase(4))

    for i in range(10):
        print(crypto.token_hex())

    for i in range(10):
        print(crypto.token_bytes())

    for i in range(10):
        print(crypto.token_urlsafe())

    for i in range(10):
        print(crypto.hash())

    for i in range(10):
        print(crypto.hash(algorithm=Algorithm.SHA256))

    for i in range(10):
        print(crypto.uuid())

    for i in range(10):
        print(crypto.uuid(as_object=True))

if __name__ == '__main__':
    test_Cryptographic()

# Generated at 2022-06-21 15:58:27.696297
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.uuid()
    assert c.hash()
    assert c.token_bytes()
    assert c.token_hex()
    assert c.token_urlsafe()
    assert c.mnemonic_phrase()


# Generated at 2022-06-21 15:58:29.234995
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    c = Cryptographic()
    assert c.token_urlsafe()
    assert c._seed



# Generated at 2022-06-21 15:58:41.046902
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    crypto = Cryptographic()
    assert len(crypto.token_hex()) == 64
    assert len(crypto.token_hex(32)) == 64
    assert len(crypto.token_hex(8)) == 16
    assert len(crypto.token_hex(16)) == 32
    assert len(crypto.token_hex(4)) == 8


# Generated at 2022-06-21 15:58:43.784266
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test method uuid of class Cryptographic."""
    assert isinstance(Cryptographic().uuid(), str)
    assert isinstance(Cryptographic().uuid(), str)



# Generated at 2022-06-21 15:58:46.861317
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    _uuid = Cryptographic().uuid()

    assert len(_uuid) == 36
    assert isinstance(_uuid, str)

    _uuid = Cryptographic().uuid(as_object=True)

    assert isinstance(_uuid, UUID)


# Generated at 2022-06-21 15:59:29.284959
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    obj = Cryptographic(seed=123456)

    result = obj.token_bytes(entropy=300)
    assert len(result) == 300 and isinstance(result, bytes)


# Generated at 2022-06-21 15:59:30.821348
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    c = Cryptographic()
    assert c.mnemonic_phrase() != c.mnemonic_phrase()


# Generated at 2022-06-21 15:59:33.633541
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Arrange
    crypto_provider = Cryptographic()

    # Act
    hex_token = crypto_provider.token_hex()

    # Assert
    assert isinstance(hex_token, str)

# Generated at 2022-06-21 15:59:35.490281
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    result = Cryptographic.token_hex()
    assert len(result) == 64


# Generated at 2022-06-21 15:59:38.217008
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    cp=Cryptographic()
    res=cp.mnemonic_phrase()
    assert isinstance(res,str)


# Generated at 2022-06-21 15:59:39.357705
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    crypto = Cryptographic()
    print(crypto.mnemonic_phrase(length=5, separator=' '))


# Generated at 2022-06-21 15:59:40.962259
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    # Python version for unit test
    assert isinstance(Cryptographic().token_bytes(), bytes)


# Generated at 2022-06-21 15:59:44.667312
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    provider = Cryptographic()

    # Check that Cryptographic.uuid() returns a string
    assert isinstance(provider.uuid(), str)


# Generated at 2022-06-21 15:59:48.033551
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():  # noqa: N802
    """
    @UnitTest for method Cryptographic.uuid
    """
    print(Cryptographic().uuid())


# Generated at 2022-06-21 15:59:50.770054
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    """Unit test for method token_hex of class Cryptographic."""
    # Uncomment this line
    # print(get_random_hash())
    assert True