

# Generated at 2022-06-21 15:56:26.647292
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    assert len(Cryptographic().token_urlsafe()) == 43
    assert len(Cryptographic().token_urlsafe(128)) == 171

# Generated at 2022-06-21 15:56:29.381047
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    a=Cryptographic()
    print(a.uuid())
    print(a.uuid(True))


# Generated at 2022-06-21 15:56:33.023402
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Test for method uuid of class Cryptographic."""
    uuid_str = Cryptographic().uuid()
    assert isinstance(uuid_str, str) and len(uuid_str) == 36


# Generated at 2022-06-21 15:56:39.813869
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Verify that token_urlsafe method of class Cryptographic 
        returns a valid token that contains only ascii chars between a-z,
        A-Z, 0-9, "-", "_" and ".".
    """
    entropy = 30
    s = Cryptographic().token_urlsafe(entropy)
    
    assert len(s) == 44
    assert all([c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_." for c in s])



# Generated at 2022-06-21 15:56:44.836243
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    try:
        token = Cryptographic.token_urlsafe()
        # print(token)
        if len(token) != 43:
            raise Exception('Invalid length of token')
        return True
    except Exception as exception:
        print(exception)
        return False


# Generated at 2022-06-21 15:56:49.459232
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    result = provider.mnemonic_phrase()
    print(result)
    expected = "spend, new, race, tonight, hard, medicine, smoke, special, simple, expect, across, no"
    assert result == expected

# Generated at 2022-06-21 15:57:00.894655
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # GIVEN
    from mimesis.enums import Algorithm
    from mimesis.typing import Seed

    seed: Seed   = '0123456789'
    cr: Cryptographic = Cryptographic(seed)
    
    # WHEN
    uu: str = cr.uuid(as_object=False)
    uu2: str = cr.uuid(as_object=False)
    uu3: str = cr.hash(algorithm=Algorithm.MD5)
    uu4: str = cr.hash(algorithm=Algorithm.SHA1)
    uu5: str = cr.hash(algorithm=Algorithm.SHA3_224)
    uu6: str = cr.hash(algorithm=Algorithm.SHA3_256)

# Generated at 2022-06-21 15:57:03.983009
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    crypto = Cryptographic()
    res = crypto.uuid()
    assert re.match(r'\w{8}-\w{4}-\w{4}-\w{4}-\w{12}', res)


# Generated at 2022-06-21 15:57:07.432691
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():

    obj = Cryptographic('en')
    value = obj.uuid()
    assert isinstance(value, str)
    assert len(value) > 0

# Unit tests for method hash of class Cryptographic

# Generated at 2022-06-21 15:57:08.048292
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
	pass

# Generated at 2022-06-21 15:57:15.913672
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    assert isinstance(Cryptographic.token_bytes(), bytes)
    assert isinstance(Cryptographic.token_bytes(16), bytes)


# Generated at 2022-06-21 15:57:18.574876
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    """Unit test for method uuid of class Cryptographic."""
    c = Cryptographic(seed=42)
    uuid = c.uuid()
    assert isinstance(uuid, str)
    assert len(uuid) == 36



# Generated at 2022-06-21 15:57:23.684911
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # This method returns string by default,
    # but you can make it return uuid.UUID object using
    # parameter **as_object**
    as_object = False
    # This function is not testable, because
    # it always return crypto-safe random UUID
    uuid = Cryptographic().uuid(as_object)
    assert isinstance(uuid, str) or isinstance(uuid, UUID)


# Generated at 2022-06-21 15:57:25.492494
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    base = Cryptographic()
    base.token_urlsafe()
    return None


# Generated at 2022-06-21 15:57:36.674817
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    # Instance of Cryptographic with default class.
    default_crypto = Cryptographic()
    # Hash with the default class.
    hash_result = default_crypto.hash()

    # Hash with SHA224 algorithm.
    crypto_sha224 = Cryptographic()
    crypto_sha224.hash(Algorithm.SHA224)

    # Hash with SHA256 algorithm.
    crypto_sha256 = Cryptographic()
    crypto_sha256.hash(Algorithm.SHA256)

    # Hash with SHA384 algorithm.
    crypto_sha384 = Cryptographic()
    crypto_sha384.hash(Algorithm.SHA384)

    # Hash with SHA512 algorithm.
    crypto_sha512 = Cryptographic()
    crypto_sha512.hash(Algorithm.SHA512)

    # Asserts
    assert isinstance(hash_result, str)
   

# Generated at 2022-06-21 15:57:38.178856
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto
    print(crypto.uuid())


# Generated at 2022-06-21 15:57:41.076058
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    # assert isinstance(Cryptographic().uuid(), UUID)
    assert isinstance(Cryptographic().uuid(), str)
    assert isinstance(Cryptographic().uuid(True), UUID)



# Generated at 2022-06-21 15:57:43.951788
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    crypto = Cryptographic()
    assert crypto.seed == crypto._seed
    assert crypto.random == crypto._random
    assert crypto._data == crypto.data



# Generated at 2022-06-21 15:57:45.747553
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    print(Cryptographic().token_hex())
    print(Cryptographic().token_hex(10))


# Generated at 2022-06-21 15:57:48.044389
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    myToken = Cryptographic().token_urlsafe(32)
    print(myToken)


if __name__ == "__main__":
    test_Cryptographic_token_urlsafe()

# Generated at 2022-06-21 15:58:01.106061
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    c = Cryptographic()
    assert c.uuid()


# Generated at 2022-06-21 15:58:04.382509
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic()
    # print(data)
    bytes = crypto.token_bytes(256)
    assert isinstance(bytes, bytes)
    assert len(bytes) == 512


# Generated at 2022-06-21 15:58:05.962142
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    generator = Cryptographic()
    result = generator.uuid()
    assert type(result) is str


# Generated at 2022-06-21 15:58:08.787744
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    crypto = Cryptographic()
    result = crypto.token_urlsafe(1)
    print(result)
    assert len(result) == 22


# Generated at 2022-06-21 15:58:11.545674
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    # Arrange
    crypto = Cryptographic()

    # Act
    actual = crypto.token_urlsafe(32)

    # Assert
    assert len(actual) == 43


# Generated at 2022-06-21 15:58:13.357880
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    a = Cryptographic(seed=1234)
    result = a.hash()
    assert result == 'b6f452d766d8a63f7a44f3795057c2a2e8d8cd587cd621548a1f51d3946d7e2b'


# Generated at 2022-06-21 15:58:23.507551
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    assert len(provider.mnemonic_phrase()) == 12
    assert len(provider.mnemonic_phrase(length=6)) == 6
    assert len(provider.mnemonic_phrase(length=0)) == 0
    assert len(provider.mnemonic_phrase(length=1000)) == 0
    assert len(provider.mnemonic_phrase(separator='|')) == 12
    assert len(provider.mnemonic_phrase(separator='|', length=6)) == 6
    assert len(provider.mnemonic_phrase(separator='|', length=0)) == 0
    assert len(provider.mnemonic_phrase(separator='|', length=1000)) == 0
    assert len(provider.mnemonic_phrase(separator='')) == 12

# Generated at 2022-06-21 15:58:26.083100
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    cr = Cryptographic()
    assert isinstance(cr.uuid(), str)

    cr = Cryptographic(seed=123)
    assert isinstance(cr.uuid(), str)



# Generated at 2022-06-21 15:58:41.046788
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    cr = Cryptographic()
    token = cr.token_hex(24)
    assert type(token) == str
    assert len(token) == 48
    token = cr.token_hex()
    assert type(token) == str
    assert len(token) == 64


# Generated at 2022-06-21 15:58:44.095530
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    crypto = Cryptographic()
    assert crypto.hash(Algorithm.MD5) == "d1b05cde86b948c36f3b517a0a828f77"



# Generated at 2022-06-21 15:59:34.230136
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto = Cryptographic(seed=123)
    assert crypto.token_bytes(0) == b''
    assert crypto.token_bytes(1) == b'\xe2'
    assert crypto.token_bytes(2) == b'\xe2\x8e'
    assert crypto.token_bytes(3) == b'\xe2\x8e\x9f'
    assert crypto.token_bytes(4) == b'\xe2\x8e\x9f\x54'
    assert crypto.token_bytes(5) == b'\xe2\x8e\x9f\x54\x87'
    assert crypto.token_bytes(6) == b'\xe2\x8e\x9f\x54\x87\x9a'

# Generated at 2022-06-21 15:59:36.344647
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    assert type(Cryptographic(seed=12345) is Cryptographic)


# Generated at 2022-06-21 15:59:38.335465
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    obj = Cryptographic()
    mn = obj.mnemonic_phrase()

    assert isinstance(mn, str)
    assert len(mn) > 0

# Generated at 2022-06-21 15:59:40.311473
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test Cryptographic's method token_urlsafe"""
    tester = Cryptographic()
    # this should not raise
    token = tester.token_urlsafe()
    assert isinstance(token, str)


# Generated at 2022-06-21 15:59:42.557806
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    a = Cryptographic()
    assert type(a.token_urlsafe()) == str

# Generated at 2022-06-21 15:59:50.770227
# Unit test for method token_hex of class Cryptographic
def test_Cryptographic_token_hex():
    # Test 1
    hash = Cryptographic().token_hex()
    assert len(hash) == 64
    assert isinstance(hash, str)

    # Test 2
    hash = Cryptographic().token_hex(entropy=64)
    assert len(hash) == 128
    assert isinstance(hash, str)

    # Test 3
    hash = Cryptographic().token_hex(entropy=64)
    assert len(hash) == 128
    assert isinstance(hash, str)

# Generated at 2022-06-21 15:59:52.931695
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():  # noqa: N802
    c1 = Cryptographic()
    c2 = Cryptographic()
    c1_token = c1.token_bytes()
    c2_token = c2.token_bytes()

    # token_bytes generates random bytes and so not
    #  reproducible for other instances
    assert c1_token != c2_token

# Generated at 2022-06-21 15:59:54.883820
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    crypto_object = Cryptographic(seed=9087)
    bytes_string = crypto_object.token_bytes()
    assert type(bytes_string) == bytes and len(bytes_string) == 32


# Generated at 2022-06-21 15:59:57.848442
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    from mimesis import Cryptographic
    crypto = Cryptographic()
    result = crypto.mnemonic_phrase()
    assert  len(result) == 12


# Generated at 2022-06-21 15:59:59.516904
# Unit test for method mnemonic_phrase of class Cryptographic
def test_Cryptographic_mnemonic_phrase():
    provider = Cryptographic()
    print(provider.mnemonic_phrase())


# Generated at 2022-06-21 16:01:10.506782
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    pass


# Generated at 2022-06-21 16:01:14.113340
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    s = Cryptographic()
    assert s.uuid()
    assert s.hash()
    assert s.token_bytes()
    assert s.token_hex()
    assert s.token_urlsafe()
    assert s.mnemonic_phrase()

# Generated at 2022-06-21 16:01:15.647197
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    c = Cryptographic()
    tok = c.token_urlsafe()
    assert type(tok) == str

# Generated at 2022-06-21 16:01:20.281576
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():
    seed = 1
    cr = Cryptographic(seed)
    # Testing with a default parameter
    expected = "8a08f6e0-6a47-4d80-8e44-36f5ab5df5af"
    output = cr.uuid()
    # function uuid is cryptographic-safe, the output is always different
    assert output != expected


# Generated at 2022-06-21 16:01:24.629012
# Unit test for method token_urlsafe of class Cryptographic
def test_Cryptographic_token_urlsafe():
    """Test for method token_urlsafe of class Cryptographic."""
    c = Cryptographic('en')
    token = c.token_urlsafe()
    assert token[:16] == 'Tc9pTfTqE3qM-g'
    assert len(token) == 44

# Generated at 2022-06-21 16:01:26.891106
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    t0 = Cryptographic.token_bytes()
    t1 = Cryptographic.token_bytes()
    assert t0 != t1


# Generated at 2022-06-21 16:01:27.533835
# Unit test for method hash of class Cryptographic
def test_Cryptographic_hash():
    assert Cryptographic().hash() != ''

# Generated at 2022-06-21 16:01:27.933141
# Unit test for constructor of class Cryptographic
def test_Cryptographic():
    Cryptographic()

# Generated at 2022-06-21 16:01:32.120491
# Unit test for method uuid of class Cryptographic
def test_Cryptographic_uuid():

    crp=Cryptographic()

    assert True==True

    assert isinstance(crp.uuid(), str)
    assert isinstance(crp.uuid(), str)
    assert isinstance(crp.uuid(), str)
    assert isinstance(crp.uuid(), str)
    assert isinstance(crp.uuid(), str)
    assert isinstance(crp.uuid(), str)

    assert isinstance(crp.uuid(as_object=True), UUID)
    assert isinstance(crp.uuid(as_object=True), UUID)
    assert isinstance(crp.uuid(as_object=True), UUID)
    assert isinstance(crp.uuid(as_object=True), UUID)

# Generated at 2022-06-21 16:01:34.048837
# Unit test for method token_bytes of class Cryptographic
def test_Cryptographic_token_bytes():
    """Unit test for method token_bytes of class Cryptographic."""
    assert len(Cryptographic().token_bytes(entropy=10)) == 10
