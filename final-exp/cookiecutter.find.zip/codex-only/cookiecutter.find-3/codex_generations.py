

# Generated at 2022-06-23 16:12:22.029219
# Unit test for function find_template
def test_find_template():
    # repo_dir must have a child directory containing the string
    # cookiecutter and both of the strings {{ and }}
    repo_dir = os.path.join('tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    
    # assert project_template is a child directory of repo_dir
    assert os.path.basename(project_template) == 'fake-repo-tmpl'
    assert os.path.dirname(project_template) == repo_dir

# Generated at 2022-06-23 16:12:30.951685
# Unit test for function find_template
def test_find_template():
    # Create a test directory
    # Put a directory with 'cookiecutter' and '{{' and '}}' in it
    # Call the function
    # Ensure the right path to the directory is returned
    import tempfile
    import shutil
    import textwrap
    path = tempfile.mkdtemp()

# Generated at 2022-06-23 16:12:35.607588
# Unit test for function find_template
def test_find_template():
    # Given
    repo_dir = 'tests/fake-repo/'

    # When
    project_template = find_template(repo_dir)

    # Then
    expected_project_template = 'tests/fake-repo/fake-project-{{cookiecutter.repo_name}}'
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:12:41.944454
# Unit test for function find_template
def test_find_template():
    """ Test is the project template is found or not. """
    repo_dir = os.path.join(os.path.dirname(__file__), "fake-repo")
    project_template = 'fake-repo-{{cookiecutter.repo_name}}'
    assert find_template(repo_dir).endswith(project_template)
    fake_repo_dir = os.path.join(os.path.dirname(__file__), "fake-repo-repo-name")
    assert find_template(fake_repo_dir).endswith('fake-repo-repo-name')


# Generated at 2022-06-23 16:12:48.168505
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import os

    template_dir_with_cookiecutter_keyword = tempfile.mkdtemp()

    with open(os.path.join(template_dir_with_cookiecutter_keyword, 'cookiecutter.json'), 'w') as f:
        f.write('{"key": "value"}')

    assert find_template(template_dir_with_cookiecutter_keyword) == template_dir_with_cookiecutter_keyword

    shutil.rmtree(template_dir_with_cookiecutter_keyword)



# Generated at 2022-06-23 16:12:51.839108
# Unit test for function find_template
def test_find_template():
    template = find_template('cookiecutter/tests/test-output/repo-pypackage')
    assert template == 'cookiecutter/tests/test-output/repo-pypackage/{{cookiecutter.project_slug}}'

# Generated at 2022-06-23 16:13:02.568355
# Unit test for function find_template
def test_find_template():
    """Integration test for function find_template.

    Makes sure that the function can locate templates in various scenarios.
    """
    # Test case 1: repo cloned from repo with no nested repo
    os.chdir(os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'fake-repo-pre-gen'
    ))
    result = find_template(os.getcwd())
    assert os.path.basename(result) == 'fake-project'

    # Test case 2: repo cloned from repo with nested repo
    os.chdir(os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'fake-repo-pre-gen-2'
    ))

# Generated at 2022-06-23 16:13:13.859111
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected.

    This test only covers the case of an input dir that contains a cookiecutter
    template.
    """
    # FIXME: This is a 'manual' test until we implement proper unit tests
    #        --audreyr, 2015-07-09
    import subprocess
    import tempfile

    # Make temp dirs that mimic a project
    temp_repo_dir = tempfile.mkdtemp()
    temp_with_cookiecutter_dir = tempfile.mkdtemp(dir=temp_repo_dir)
    temp_normal_dir = tempfile.mkdtemp(dir=temp_repo_dir)
    temp_with_cookiecutter_dir_name = os.path.basename(temp_with_cookiecutter_dir)
    temp_normal_dir_

# Generated at 2022-06-23 16:13:19.846839
# Unit test for function find_template
def test_find_template():
    test_template_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-find-template',
        'cookiecutter-demo'
    ))
    project_template = find_template(test_template_dir)

    assert 'custom-extension.txt-tpl' in project_template

# Generated at 2022-06-23 16:13:22.632884
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.expanduser('~'))
    assert find_template('.') == '.cookiecutter'

# Generated at 2022-06-23 16:13:28.378740
# Unit test for function find_template
def test_find_template():
    """Test find_template in functions.py"""
    repo_dir = '/home/bob/gitrepos/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/home/bob/gitrepos/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:38.276512
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    logger.debug('Searching %s for the project template.', repo_dir)

    # repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template

# Generated at 2022-06-23 16:13:44.084832
# Unit test for function find_template
def test_find_template():
    """Tests find_template function."""
    test_dir = '/Users/audreyr/Documents/dev/cookiecutter/tests/input/repo_with_extra_dirs'
    assert find_template(test_dir) == '/Users/audreyr/Documents/dev/cookiecutter/tests/input/repo_with_extra_dirs/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:13:45.840068
# Unit test for function find_template
def test_find_template():
    # TODO: Implement unit tests for this function once it becomes
    # testable.
    pass

# Generated at 2022-06-23 16:13:50.315098
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    from cookiecutter import utils
    from tests import fixture

    repo_dir = fixture.template_repo_dir
    repo_dir_contents = os.listdir(repo_dir)
    main.find_template(os.path.normpath(repo_dir))
    assert utils.project_dir_contains(repo_dir, repo_dir_contents)

# Generated at 2022-06-23 16:13:56.802654
# Unit test for function find_template
def test_find_template():
    """Verify function find_template() returns expected project_template.
    
    """
    # GIVEN a local directory containing template contents and a nested 
    # project_template.
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fixtures',
        'fake-repo-tmpl'
    )
    # WHEN searching the repo_dir for it's project template.
    project_template = find_template(repo_dir)
    # THEN expect the project_template to be as expected.

# Generated at 2022-06-23 16:13:59.680284
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repos/fake-repo'

    project_template = find_template(repo_dir)
    print(project_template)



# Generated at 2022-06-23 16:14:09.177568
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns correct path to template."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'tests',
                     'test-tmpl')
    )
    project_template = find_template(repo_dir)
    expected_template = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'tests',
                     'test-tmpl', '{{cookiecutter.repo_name}}')
    )
    assert project_template == expected_template

# Generated at 2022-06-23 16:14:09.700126
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:13.242885
# Unit test for function find_template
def test_find_template():
    """Validate `find_template` function."""
    path = 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    repo_dir = os.path.dirname(path)
    project_dir = find_template(repo_dir)

    assert project_dir == path

# Generated at 2022-06-23 16:14:15.856664
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    template = find_template(repo_dir)
    assert 'cookiecutter-pypackage' in template
    assert 'cookiecutter.json' in template
    assert os.path.exists(template)
    assert os.path.isdir(template)

# Generated at 2022-06-23 16:14:20.043279
# Unit test for function find_template
def test_find_template():
    import pytest

    for test_path in ['.', os.path.join(os.getcwd(), '.')]:
        with pytest.raises(NonTemplatedInputDirException):
            find_template(test_path)

# Generated at 2022-06-23 16:14:24.549593
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo-pre/'
    template_path = find_template(repo_dir)
    assert os.path.normpath(template_path) == os.path.normpath('tests/test-repo-pre/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:14:27.120795
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-23 16:14:30.813169
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_utils import make_igitt_project
    repo_path = make_igitt_project('simple-cookiecutter-python')
    template_path = find_template(repo_path)
    assert template_path == os.path.join(repo_path, 'cookiecutter-pypackage')

# Generated at 2022-06-23 16:14:36.799488
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    base_path = os.path.dirname(__file__)
    repo_dir = os.path.join(base_path, 'tests/test-repo-tmpl/')
    project_tmpl_path = os.path.join(base_path, 'tests/test-repo-tmpl/{{cookiecutter.repo_name}}/')
    assert find_template(repo_dir) == project_tmpl_path


# Generated at 2022-06-23 16:14:42.033228
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.project_slug}}')

# Generated at 2022-06-23 16:14:48.932093
# Unit test for function find_template
def test_find_template():
    path = '/home/username/clone/cookies/'
    my_dir_contents = ['cookiecutter-pypackage', 'cookiecutter-djangopackage', 'cookiecutter-django-bootstrap']
    path_to_cookiecutter = '/home/username/clone/cookies/cookiecutter-pypackage'
    os.listdir = lambda x: my_dir_contents
    assert find_template(path) == path_to_cookiecutter


# Generated at 2022-06-23 16:14:53.499547
# Unit test for function find_template
def test_find_template():
    """Test for correct template discovery."""
    test_dir = os.path.join('tests', 'test-find-template')
    result = find_template(test_dir)
    assert 'cookiecutter-{{cookiecutter.repo_name}}' in result

# Generated at 2022-06-23 16:14:58.841976
# Unit test for function find_template
def test_find_template():
    input_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')

    project_template = find_template(input_dir)

    assert os.path.normpath(
        project_template
    ) == os.path.normpath(os.path.join(input_dir, '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-23 16:15:03.453787
# Unit test for function find_template
def test_find_template():
    """Tests the find_template function."""

    repo = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_repo'
    )

    expected = os.path.join(repo, '{{cookiecutter.repo_name}}')
    result = find_template(repo)

    assert result == expected

# Generated at 2022-06-23 16:15:06.752032
# Unit test for function find_template
def test_find_template():
    try:
        find_template('/usr')
    except NonTemplatedInputDirException:
        print('Passed test for non templated directory')
    else:
        raise Exception('Did not raise NonTemplatedInputDirException')

# Generated at 2022-06-23 16:15:14.247403
# Unit test for function find_template

# Generated at 2022-06-23 16:15:24.390441
# Unit test for function find_template
def test_find_template():
    # to run tests, "pip install nose" and then "nosetests"
    from nose.tools import assert_equals
    import os
    import tempfile

    repo_dir = tempfile.mkdtemp()
    logger.debug('Created a temporary directory at %s', repo_dir)

    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write('Hello')

    with open(os.path.join(repo_dir, 'cookiecutter-{{ project_name }}'), 'w') as f:
        f.write('Hello')

    with open(os.path.join(repo_dir, 'cookiecutter-{{ project_slug }}'), 'w') as f:
        f.write('Hello')


# Generated at 2022-06-23 16:15:29.669049
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(template_dir, 'test-templates', 'test-template')
    assert os.path.exists(template_dir)
    template = find_template(template_dir)
    assert os.path.exists(template)

# Generated at 2022-06-23 16:15:33.755095
# Unit test for function find_template
def test_find_template():
    assert find_template(os.getcwd() + '/tests/test-generate-files') == os.getcwd() + '/tests/test-generate-files/{{cookiecutter.repo_name}}'
# End testing

# Generated at 2022-06-23 16:15:37.795386
# Unit test for function find_template
def test_find_template():
    assert find_template('E:\Python\Python Projects\cookiecutter-pypackage\tests\fake-repo-pre\simple_with_bakery') == \
           'E:\Python\Python Projects\cookiecutter-pypackage\tests\fake-repo-pre\simple_with_bakery\simple'

# Generated at 2022-06-23 16:15:40.273961
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-django') == 'cookiecutter-django/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:47.440847
# Unit test for function find_template
def test_find_template():
    """Class for testing find_template method"""

    # Test case 1: NonTemplatedInputDirException is thrown when 'repo_dir' is not templated.
    # e.g. The name of the directory is not of the form '{{cookiecutter.project_name}}'

    # Test case 2: 'repo_dir' is templated and is just a directory

    # Test case 3: 'repo_dir' is templated and is a directory with subdirectories

    # Test case 4: 'repo_dir' is templated and has a file in it e.g. README.md

# Generated at 2022-06-23 16:15:52.505614
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.join('tests', 'fake-repo')
    test_template = find_template(test_repo_dir)
    expected_template = os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')
    assert test_template == expected_template

# Generated at 2022-06-23 16:15:56.789083
# Unit test for function find_template
def test_find_template():
    project_template = find_template('cookiecutter-pypackage')
    assert project_template == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:15:57.206606
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:02.920565
# Unit test for function find_template
def test_find_template():
    """Find the project template within a non-templated input directory."""
    test_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(test_dir, 'fixtures', 'non-templated-input-dir')
    assert find_template(repo_dir) == os.path.join(repo_dir, 'my-repo')

# Generated at 2022-06-23 16:16:05.580880
# Unit test for function find_template
def test_find_template():
    """
    Test normal behavior of find_template()
    """
    assert find_template('/home/johndoe') == '/home/johndoe'

# Generated at 2022-06-23 16:16:09.969667
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.getcwd(), 'tests/test-repo-pre/')
    project_template = find_template(repo_dir)
    assert 'tests/test-repo-pre/{{cookiecutter.repo_name}}' == project_template

# Generated at 2022-06-23 16:16:17.150070
# Unit test for function find_template
def test_find_template():
    '''
    Test the find_template function
    '''

    # Missing {{ and }}
    test_dir = "tests/test-find-template/no-vars-in-dir"
    project_template = find_template(test_dir)
    assert project_template == os.path.join(test_dir, 'cookiecutter-no-vars-in-dir')

    # Missing {{
    test_dir = "tests/test-find-template/missing-open-curly"
    project_template = find_template(test_dir)
    assert project_template == os.path.join(test_dir, 'cookiecutter-missing-open-curly')

    # Missing }}
    test_dir = "tests/test-find-template/missing-close-curly"

# Generated at 2022-06-23 16:16:26.736085
# Unit test for function find_template
def test_find_template():
    """Test that we can find a cookiecutter.json file in a directory"""
    import os
    import netrc
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

    repo_contents = os.path.join(os.path.dirname(__file__)[:-4], 'tests', 'test-repo-tmpl')
    shutil.copytree(repo_contents, temp_dir)
    try:
        template = find_template(temp_dir)
        assert os.path.exists(template)
    finally:
        shutil.rmtree(temp_dir)


# Generated at 2022-06-23 16:16:29.552682
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests import test_find_template_repo
    test_find_template_repo()
    from cookiecutter.tests import test_find_template_no_template
    test_find_template_no_template()


# Generated at 2022-06-23 16:16:30.255337
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-23 16:16:35.653100
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/code/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/home/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:37.940208
# Unit test for function find_template
def test_find_template():
    """Test function for `find_template`."""
    pass
    # assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:16:38.887707
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:39.462876
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:47.140144
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the right result."""
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(cur_dir, 'tests/fake-repo-tmpl')
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == expected
    repo_dir = os.path.join(cur_dir, 'tests/fake-repo-pre')
    expected = os.path.join(repo_dir, 'fake-pre-repo')
    assert find_template(repo_dir) == expected

# Generated at 2022-06-23 16:16:52.123271
# Unit test for function find_template
def test_find_template():
    template_path = os.path.join(
        'tests/files/fake-repo',
        '{{cookiecutter.repo_name}}',
    )
    assert find_template('tests/files/fake-repo') == template_path


# Generated at 2022-06-23 16:16:52.956539
# Unit test for function find_template
def test_find_template():
    find_template('.')


# Generated at 2022-06-23 16:16:59.225414
# Unit test for function find_template
def test_find_template():
    """Test if the directory is templated (if it contains double curly
    braces. If so, the directory is the project template, return it.
    """

    # create a temporary directory with a templated directory inside
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    templated_dir = os.path.join(tmp_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    os.mkdir(templated_dir)

    # check if the templated directory is returned
    template_dir = find_template(tmp_dir)
    assert template_dir == templated_dir



# Generated at 2022-06-23 16:17:03.364382
# Unit test for function find_template
def test_find_template():
    '''
    Test function find_template(repo_dir)
    '''
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../tests')
    templ_dir = find_template(repo_dir)
    assert templ_dir == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.project_name}}')

# Generated at 2022-06-23 16:17:09.783116
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    import tempfile

    # Create a templated dir with one file
    temp_dir = tempfile.mkdtemp()
    temp_subdir = os.path.join(temp_dir, 'mytemplatedir')
    os.mkdir(temp_subdir)
    temp_subsubdir = os.path.join(temp_subdir, 'foo')
    os.mkdir(temp_subsubdir)
    temp_file = os.path.join(temp_subsubdir, 'bar')
    with open(temp_file, 'w') as f:
        f.write('bar')

    template_dir = find_template(temp_subdir)

    assert os.path.relpath(template_dir, temp_subdir) == 'foo'

    # Clean up
    shut

# Generated at 2022-06-23 16:17:16.756263
# Unit test for function find_template
def test_find_template():
    """Test for find_template(repo_dir)"""

    working_dir = os.path.dirname(os.path.abspath(__file__))

    full_dir = os.path.join(working_dir, 'tests/test-input/test-repo')

    project_template = find_template(full_dir)

    full_expected_output = os.path.join(full_dir, 'test-repo{{cookiecutter.directory_name}}')

    assert project_template == full_expected_output

test_find_template()

# Generated at 2022-06-23 16:17:19.000242
# Unit test for function find_template
def test_find_template():
    assert find_template('fixtures/fake-repo-pre/') == 'fixtures/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:27.602153
# Unit test for function find_template
def test_find_template():
    os.environ['COOKIECUTTER_TEST_FOLDER'] = 'True'
    path = os.path.join(
        os.environ['COOKIECUTTER_TEST_TEMPLATES'],
        'cookiecutter-pypackage',
        'cookiecutter.json'
    )
    repo_dir = os.path.dirname(path)
    project_template = find_template(repo_dir)
    assert 'cookiecutter-pypackage-{{cookiecutter.repo_name}}' in project_template
    assert os.path.exists(project_template)
    assert os.path.isdir(project_template)



# Generated at 2022-06-23 16:17:34.942833
# Unit test for function find_template
def test_find_template():
    """
    Determines if find_template() locates the project template
    """
    import pytest
    a_local_repo = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'fake-repo-pre-gen'
    )
    logger.debug('a_local_repo is %s', a_local_repo)
    template = find_template(a_local_repo)
    assert template == os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'fake-repo-pre-gen/{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:17:38.089333
# Unit test for function find_template
def test_find_template():
    pass

if __name__ == '__main__':
    logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.DEBUG)
    unittest.main()

# Generated at 2022-06-23 16:17:48.280822
# Unit test for function find_template
def test_find_template():
    # Create temp dir
    import tempfile
    repo_dir = tempfile.mkdtemp()

    # Create project template in that dir
    project_template = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    os.makedirs(project_template)

    # Create other files & dirs in that dir
    os.makedirs(os.path.join(repo_dir, 'other_dir'))
    open(os.path.join(repo_dir, 'other_file.txt'), 'a').close()

    # Assert that find_template finds project template
    assert find_template(repo_dir) == project_template



# Generated at 2022-06-23 16:17:54.560418
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    from cookiecutter import generators

    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), '..', 'fake-repo', 'input-repo-tmpl'
        )
    )
    generators.find_template(repo_dir)

# Generated at 2022-06-23 16:17:58.380813
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the expected project_template."""
    expected = '/test/test_cookiecutter/test-cookiecutter'
    find_template('/test/test_cookiecutter/') == expected

# Generated at 2022-06-23 16:18:05.281900
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                            '..', 'tests', 'fake-repo-tmpl'))
    project_template = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                    '..', 'tests',
                                                    'fake-repo-tmpl',
                                                    '{{cookiecutter.repo_name}}'))
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:18:08.607877
# Unit test for function find_template
def test_find_template():
    """Test if the expected project template was located."""
    assert find_template('office_hours/') == 'office_hours/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:13.166435
# Unit test for function find_template
def test_find_template():
    template_path = find_template(os.path.join(os.getcwd(),"tests/fake-repo-pre/"))
    assert template_path == os.path.join(os.getcwd(),"tests/fake-repo-pre/{{cookiecutter.project_name}}")

# Generated at 2022-06-23 16:18:15.837291
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/cookiecutter-pypackage') == \
        '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:19.754685
# Unit test for function find_template
def test_find_template():
    """
    Test the function find_template.
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_find_template'
    )
    correct_project_template = os.path.join(
        repo_dir,
        'project_template'
    )

    assert correct_project_template == find_template(repo_dir)

# Generated at 2022-06-23 16:18:31.470830
# Unit test for function find_template
def test_find_template():
    from .compat import unittest
    from .compat import mock

    class TestEachRepo(unittest.TestCase):
        def test_jquery_repo(self):
            repo_dir = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                '..',
                'tests',
                'fake-repo-pre',
                'cookiecutter-jquery'
            )
            expected_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
            with mock.patch('cookiecutter.repository.main.os.listdir', return_value=os.listdir(repo_dir)):
                assert find_template(repo_dir) == expected_template

# Generated at 2022-06-23 16:18:33.392571
# Unit test for function find_template
def test_find_template():
    cwd = os.getcwd()
    find_template(cwd)



# Generated at 2022-06-23 16:18:34.049208
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:18:37.887675
# Unit test for function find_template
def test_find_template():
    """
    Test for finding the template in a valid git repo.
    """
    path = '/home/jon/my_repo'

    assert find_template(path) == '/home/jon/my_repo/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:18:40.649709
# Unit test for function find_template
def test_find_template():
    """Test function find_template in search.py file
    :returns: True
    """
    assert find_template(repo_dir="/Users/gaurav/Desktop/cookiecutter")
    return True

# Generated at 2022-06-23 16:18:43.026123
# Unit test for function find_template
def test_find_template():
    """ Unit test for the find_template function"""

    find_template('t/test-repo-tmpl')

# Generated at 2022-06-23 16:18:51.789472
# Unit test for function find_template
def test_find_template():
    """
    After:
    - Instantiating Cookiecutter using test-cookiecutter-repo,
    - Finding that repository,
    - Determining the project_template,
    - And rendering that project_template.

    Then:
    - The project template should render to the correct destination.
    """
    template_name = 'test-cookiecutter-repo'
    output_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'test-output'
    ))
    project_template = find_template(template_name)
    assert os.path.isdir(project_template)

# Generated at 2022-06-23 16:18:59.486166
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""

# Generated at 2022-06-23 16:19:05.045258
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'templates'))

    project_template = find_template(repo_dir)
    assert os.path.join(repo_dir, '{{cookiecutter.repo_name}}') == project_template

# Generated at 2022-06-23 16:19:11.525647
# Unit test for function find_template
def test_find_template():
    """Check that find_template() returns correct directory."""
    from cookiecutter.find import find_template

    # Check that find_template() correctly finds templated input_dir

    input_dir = os.path.abspath(os.path.join(
        os.getcwd(), 'tests/test-cookiecutter-master/{{cookiecutter.repo_name}}'))
    assert find_templa

# Generated at 2022-06-23 16:19:17.731354
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    project_template = find_template(repo_dir)
    is_expected_path = project_template == os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert is_expected_path is True
    print('test_find_template passed.')


# Generated at 2022-06-23 16:19:18.723606
# Unit test for function find_template
def test_find_template():
    """."""
    pass

# Generated at 2022-06-23 16:19:25.907595
# Unit test for function find_template
def test_find_template():
    """
    Fake a `repo_dir` and `project_template` for testing purposes.
    """
    repo_dir = '/home/audreyr/projects/cookiecutter/tests/fake-repo-pre/'
    project_template = '/home/audreyr/projects/cookiecutter/tests/fake-repo-pre/{{cookiecutter.project_slug}}/'

    # Make sure this is set to False before committing
    is_test_run = True

    if is_test_run:
        logger.debug('Searching %s for the project template.', repo_dir)

        repo_dir_contents = os.listdir(repo_dir)

        test_project_template = None

# Generated at 2022-06-23 16:19:34.000146
# Unit test for function find_template
def test_find_template():
    """Test the find_template function.

    Test that the function works when the template is found,
    and when the template is not found.
    """
    # Find a temp directory that doesn't exist.
    repo_dir = '/tmp/cookiecutter-tests/find-template/'

    # Should not raise error when template is found
    os.makedirs(repo_dir)
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    find_template(repo_dir)

    # Should raise error when template is not found
    project_template = find_template(repo_dir)
    assert project_template is None

# Generated at 2022-06-23 16:19:40.669082
# Unit test for function find_template
def test_find_template():
    from ..repository import determine_repo_dir
    from ..repository import clone

    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir = clone(repo_url)
    repo_dir = determine_repo_dir(repo_dir)
    project_template = find_template(repo_dir)
    assert '{{ cookiecutter.name}}' in project_template

# Generated at 2022-06-23 16:19:41.211890
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-23 16:19:44.626203
# Unit test for function find_template
def test_find_template():
    """Check that find_template() works as expected."""
    path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test_find_template',
    )

    assert find_template(path) == os.path.join(path, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:19:55.158043
# Unit test for function find_template
def test_find_template():
    """Test non-templated input directory and a normal input directory."""

    from cookiecutter import main
    from cookiecutter.compat import unicode
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = main.cookiecutter(unicode('tests/test-repo/'), no_input=True)

    # Test non-templated input dir
    os.rmdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    try:
        main.find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('Non templates input dir not detected')

    # Test normal input dir
    template_dir = main.find_template(repo_dir)

   

# Generated at 2022-06-23 16:20:03.122621
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import pytest
    import tempfile
    from cookiecutter.main import cookiecutter
    from cookiecutter.exceptions import NonTemplatedInputDirException

    with tempfile.TemporaryDirectory() as tmp_dir_name:
        results = cookiecutter(
            'tests/test-cookiecutters/invalid-project-templates',
            no_input=True,
            output_dir=tmp_dir_name
        )
        assert results['project_name'] == 'invalid-project-templates'

        tmp_repo_dir = os.path.join(tmp_dir_name, results['project_name'])

        # Test a valid repo directory

# Generated at 2022-06-23 16:20:06.098232
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fixtures/gitclone/{{cookiecutter.repo_name}}'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:20:08.990548
# Unit test for function find_template
def test_find_template():
    template_dir = 'tests/test-data/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-data/fake-repo-tmpl') == template_dir

# Generated at 2022-06-23 16:20:11.087380
# Unit test for function find_template
def test_find_template():
    assert find_template('/tmp/foo-cookiecutter-gh-7') == '/tmp/foo-cookiecutter-gh-7/cookiecutter-foo'

# Generated at 2022-06-23 16:20:15.612052
# Unit test for function find_template
def test_find_template():
    """Test to find the template when the input_dir is a repository."""
    logging.basicConfig(level=logging.DEBUG)
    input_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'fake-repo'))
    assert find_template(input_dir) == os.path.join(input_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:20:19.413701
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.join(os.path.dirname(__file__), 'tests/test-find-template'))
    project_template = find_template('.')
    assert project_template == os.path.join(os.getcwd(), 'cookiecutter-{{repo_name}}')



# Generated at 2022-06-23 16:20:23.362843
# Unit test for function find_template
def test_find_template():
    """Test function for find_template."""
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:30.986568
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns correct path."""
    from cookiecutter.main import cookiecutter

    project_dir = cookiecutter('tests/fake-repo-tmpl', no_input=True)

    project_template = find_template(project_dir)

    # Check that the path returned by find_template ends with the
    # correct template name.
    assert project_template.endswith('fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:20:38.994562
# Unit test for function find_template
def test_find_template():
    """Verify that we can find the project template.
    """
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()

    # Test we can find the project template
    os.makedirs(os.path.join(repo_dir, 'foobar'))
    shutil.copy(
        os.path.join('tests', 'test-templates', 'foobar', 'README.md'),
        os.path.join(repo_dir, 'foobar')
    )
    project_template = find_template(repo_dir)
    assert project_template.endswith('foobar')

    # Test we can't find the project template
    shutil.rmtree(repo_dir)
    repo

# Generated at 2022-06-23 16:20:41.714845
# Unit test for function find_template
def test_find_template():
    repo_dir = r'C:\Users\chris\workspace\cookiecutter-test'
    assert 'test_project' == find_template(repo_dir)

# Generated at 2022-06-23 16:20:48.855236
# Unit test for function find_template
def test_find_template():
    """
    Tests the find_template function.
    """

    try:
        find_template('tests')
        raise Exception
    except NonTemplatedInputDirException:
        assert True

    real_path = os.path.realpath(__file__)
    repo_dir = os.path.dirname(real_path)
    project_template = os.path.join(repo_dir, 'tests', 'fake-repo-pre/')

    assert find_template('tests/fake-repo-pre') == project_template

# Generated at 2022-06-23 16:20:54.504854
# Unit test for function find_template
def test_find_template():
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    test_path = os.path.join(fixture_path, 'template_search')
    project_template = find_template(test_path)
    expected_template = os.path.join(test_path, '{{cookiecutter.repo_name}}')
    assert project_template == expected_template

# Generated at 2022-06-23 16:20:55.490675
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-23 16:21:07.317372
# Unit test for function find_template
def test_find_template():
    import os
    from cookiecutter.utils import rmtree
    from cookiecutter import main
    from cookiecutter.main import cookiecutter

    # This should work
    try:
        user_config = main.get_user_config()
    except Exception as e:
        user_config = {}
    delete_on_failure = False
    if not os.path.isdir('tests/fake-repo-pre/'):
        output = cookiecutter(
            'https://github.com/audreyr/fake-repo-pre',
            no_input=True,
            config_file=user_config,
            overwrite_if_exists=True
        )
        assert os.path.isdir('tests/fake-repo-pre/')
        delete_on_failure = True
    template_path

# Generated at 2022-06-23 16:21:12.062182
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    assert find_template(test_repo_dir) == os.path.join(
        test_repo_dir, '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:21:14.631923
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:25.081604
# Unit test for function find_template
def test_find_template():
    """Simple test for function find_template"""
    # TODO: use a fake filesystem
    path_to_test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_find_template_dir'
    )
    path_to_test_dir = os.path.normpath(path_to_test_dir)

    assert find_template(path_to_test_dir) == os.path.join(path_to_test_dir, '{{cookiecutter.repo_name}}')

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-23 16:21:30.791849
# Unit test for function find_template
def test_find_template():
    """Find the template dir and return the expected directory."""
    abs_path_to_output_dir = os.path.abspath('./tests/files/fake-repo-pre/')

    # Update the output dir with the expected directory
    expected_dir = os.path.abspath(
        './tests/files/fake-repo-pre/fake-repo'
    )

    assert find_template(abs_path_to_output_dir) == expected_dir

# Generated at 2022-06-23 16:21:37.317370
# Unit test for function find_template
def test_find_template():
    git_repo = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir = '/tmp/test_find_template/'

    os.makedirs(repo_dir)
    os.listdir(repo_dir)

    folder = "cookiecutter-{{cookiecutter.repo_name}}"
    os.makedirs(os.path.join(repo_dir, folder))
    assert find_template(repo_dir) == os.path.join(repo_dir, folder)

    os.removedirs(repo_dir)

# Generated at 2022-06-23 16:21:40.736938
# Unit test for function find_template
def test_find_template():
    """
    Test that the expected template is correctly found
    """
    assert find_template("tests/fake-repo-pre/") == "tests/fake-repo-pre/{{cookiecutter.repo_name}}"



# Generated at 2022-06-23 16:21:46.569224
# Unit test for function find_template
def test_find_template():
    actual = find_template(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    expected = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl', '{{cookiecutter.repo_name}}')
    assert actual == expected

# Generated at 2022-06-23 16:21:55.466171
# Unit test for function find_template
def test_find_template():
    """Verify correct detection of project template directory."""
    from cookiecutter import tests
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test when there's a single project template dir
    find_template(tests.ROOT_DIR)

    # Test when there's no project template dir
    with pytest.raises(NonTemplatedInputDirException):
        find_template(tests.ROOT_DIR)

    # Test when there's more than one project template dir
    with pytest.raises(NonTemplatedInputDirException):
        find_template(tests.ROOT_DIR)

# Generated at 2022-06-23 16:21:57.592839
# Unit test for function find_template
def test_find_template():
    """Test find_template"""
    assert find_template('tests/test-data') == 'tests/test-data/cookiecutter-pypackage'

# Generated at 2022-06-23 16:22:06.970652
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""

    import os

    import pytest

    from cookiecutter.exceptions import NonTemplatedInputDirException

    root_dir = os.path.abspath(os.path.dirname(__file__))
    test_data_dir = os.path.join(root_dir, 'test_data')
    repo_dir = os.path.join(test_data_dir, 'fake-repo')

    project_template = find_template(repo_dir)
    wanted = 'fake-repo/{{cookiecutter.repo_name}}'
    assert project_template == wanted

    with pytest.raises(NonTemplatedInputDirException):
        find_template(test_data_dir)

# Generated at 2022-06-23 16:22:14.200714
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template(os.path.abspath(os.path.join(os.path.dirname(__file__), 'tests/test-template'))) == os.path.abspath(os.path.join(os.path.dirname(__file__), 'tests/test-template/{{cookiecutter.repo_name}}'))
    assert find_template(os.path.abspath(os.path.join(os.path.dirname(__file__), 'tests/fake-repo'))) == None