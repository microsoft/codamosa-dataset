

# Generated at 2022-06-23 16:12:18.673985
# Unit test for function find_template
def test_find_template():
    # TODO: figure out how to handle this
    assert True

# Generated at 2022-06-23 16:12:20.839962
# Unit test for function find_template
def test_find_template():
    find_template('./tests')

test_find_template()

# Generated at 2022-06-23 16:12:25.147250
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), 'test_repo',
    ))
    assert os.path.join(repo_dir, '{{cookiecutter.repo_name}}') == find_template(repo_dir)

# Generated at 2022-06-23 16:12:28.383380
# Unit test for function find_template
def test_find_template():
    assert find_template("/Users/david/Code/cookiecutter-pypackage") == '/Users/david/Code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:12:37.224890
# Unit test for function find_template
def test_find_template():
    """
    test_find_template should return the correct template name from the directory
    """
    #todo: make this match the structure of the test directory
    os.mkdir('test_repo')
    os.mkdir('test_repo/hello')
    os.mkdir('test_repo/hi')

    assert find_template('test_repo') == os.path.join(os.getcwd(), 'test_repo/hello')

    os.rmdir('test_repo/hello')
    os.rmdir('test_repo/hi')
    os.rmdir('test_repo')

    assert find_template('test_repo') == os.path.join(os.getcwd(), 'test_repo/hello')

# Generated at 2022-06-23 16:12:45.147483
# Unit test for function find_template
def test_find_template():
    """Function to test if find_template finds the correct path if repo_dir contains cookiecutter string in its name"""
    os.makedirs(os.getcwd()+'\\testpath\\')
    os.chdir(os.getcwd()+'\\testpath\\')
    repo_dir = os.getcwd()
    with open('cookiecutter.json', 'w') as template_found_correctly:
        template_found_correctly.write('some information')
    assert find_template(repo_dir) == repo_dir+'\\cookiecutter.json'

# Generated at 2022-06-23 16:12:51.644982
# Unit test for function find_template
def test_find_template():
    """Test finding templates in a cloned repo."""
    repo_dir = 'my/extra/long/path/to/cookiecutter-pypackage'
    template = find_template(repo_dir)
    assert template == 'my/extra/long/path/to/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:12:57.222616
# Unit test for function find_template
def test_find_template():
    """Verify proper error messages when the repo does not contain a template."""
    repo_dir = os.path.dirname(__file__)
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'An error should be raised when the repo does not contain a template.'

    find_template(os.path.join(repo_dir, '..'))

# Generated at 2022-06-23 16:13:05.309374
# Unit test for function find_template
def test_find_template():

    # Test template found
    template_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-pre')
    template = find_template(template_dir)
    assert template == os.path.join(template_dir, '{{cookiecutter.repo_name}}')

    # Test template not found
    template_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-no-template')
    try:
        template = find_template(template_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError('NonTemplatedInputDirException not raised')

# Generated at 2022-06-23 16:13:12.329719
# Unit test for function find_template
def test_find_template():
    """Verify template dir is returned when a template is found."""
    from cookiecutter.tests.test_repositories import TEST_USER, TEST_REPO
    from cookiecutter.tests.test_repositories import clone_repo
    repo = clone_repo(TEST_USER, TEST_REPO)
    template = find_template(repo)
    assert template == os.path.join(repo, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:19.669992
# Unit test for function find_template
def test_find_template():
    """Test find_template() with the fixture `test-find-template`."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    expected_result = os.path.join(
        repo_dir,
        'cookiecutter-pypackage-{{cookiecutter.project_slug}}'
    )
    assert find_template(repo_dir) == expected_result

# Generated at 2022-06-23 16:13:22.922511
# Unit test for function find_template
def test_find_template():
    expected = "unit/templates/{{cookiecutter.repo_name}}"
    repo_dir = "unit/template"
    result = find_template(repo_dir)
    assert result == expected


# Generated at 2022-06-23 16:13:34.400961
# Unit test for function find_template
def test_find_template():
    """Test that find template is working."""
    from cookiecutter import utils
    from cookiecutter.config import DEFAULT_CONFIG

    repo_dir = utils.make_empty_dir()
    config_file = utils.make_config_file(DEFAULT_CONFIG, repo_dir)

    # add a non-template directory
    dir_name = utils.make_empty_dir(repo_dir)

    # add a template directory
    template_dir = utils.make_empty_dir(repo_dir)
    os.mkdir(os.path.join(template_dir, '{{cookiecutter.pytest}}'))

    # test that the template dir is the one that is found
    assert os.path.abspath(find_template(repo_dir)) == os.path.abspath

# Generated at 2022-06-23 16:13:35.764186
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:13:41.088705
# Unit test for function find_template
def test_find_template():
    """Find the template in the current repo."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..'
    ))
    template_path = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '{{cookiecutter.repo_name}}'
    ))
    assert find_template(repo_dir) == template_path



# Generated at 2022-06-23 16:13:44.737294
# Unit test for function find_template
def test_find_template():
    repo_dir = "/home/sgy/Desktop/wechat-mina"
    project_template = "/home/sgy/Desktop/wechat-mina/{{cookiecutter.project_slug}}"
    assert project_template == find_template(repo_dir)



# Generated at 2022-06-23 16:13:46.566086
# Unit test for function find_template
def test_find_template():
    assert find_template('foo') == 'foo/bar'
    
test_find_template()

# Generated at 2022-06-23 16:13:54.510016
# Unit test for function find_template
def test_find_template():
    """Test that the function finds a template."""
    # Create a dummy input repo
    import tempfile
    repo_dir = tempfile.mkdtemp()

    cookiecutter_dirs = [
        'cookiecutter-pypackage',
        'cookiecutter-{{ cookiecutter.repo_name }}',
        'cookiecutter-awesome',
        'foo',
    ]
    for cookiecutter_dir in cookiecutter_dirs:
        os.mkdir(os.path.join(repo_dir, cookiecutter_dir))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{ cookiecutter.repo_name }}')

# Generated at 2022-06-23 16:13:59.681408
# Unit test for function find_template
def test_find_template():

    test_template_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-template'
    )

    result_template = find_template(test_template_dir)
    assert result_template.endswith('test-template/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:14:03.608857
# Unit test for function find_template
def test_find_template():
    """Where is the unit test?"""
    assert find_template('~/repos/cookiecutter-pypackage') == \
        '~/repos/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:14:11.872472
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils

    test_path_1 = '/Users/audreyr/Code/cookiecutter-pypackage'
    result_1 = utils.find_template(test_path_1)
    assert 'cookiecutter-pypackage{{cookiecutter.project_name}}' in result_1

    test_path_2 = '/Users/audreyr/Code/cookiecutter-django'
    result_2 = utils.find_template(test_path_2)
    assert 'cookiecutter-django/{{cookiecutter.repo_name}}' in result_2

# Generated at 2022-06-23 16:14:20.669385
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    temp_repo_dir_contents = ['{{cookiecutter.repo_name}}', 'README.rst', '.gitignore']
    for item in temp_repo_dir_contents:
        open(os.path.join(repo_dir, item), 'a').close()

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:14:27.842556
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/johndoe/dev/some_repo_name'
    project_template = find_template(repo_dir)
    project_template = os.path.normpath(
        project_template.replace('/home/johndoe/dev/some_repo_name', ''))
    assert project_template == '/cookiecutter-project-name'

# Generated at 2022-06-23 16:14:30.514283
# Unit test for function find_template

# Generated at 2022-06-23 16:14:34.355877
# Unit test for function find_template
def test_find_template():
    repo_dir = os.getcwd()
    project_template = find_template(repo_dir)
    assert project_template.endswith('cookiecutter-pypackage')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:14:41.628472
# Unit test for function find_template
def test_find_template():
    """
    Test `find_template` function.
    """
    from os.path import abspath, dirname, join
    from cookiecutter import configuration

    # Get root of this packaged project
    templates_dir = join(dirname(abspath(__file__)), 'tests', 'test-tmpl')

    repo_dir = join(templates_dir, 'fake-repo')

    project_template = find_template(repo_dir)

    configuration.TEMPLATE_DIR = project_template

# Generated at 2022-06-23 16:14:43.926396
# Unit test for function find_template
def test_find_template():
    """Test for find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, 'black-hole')

# Generated at 2022-06-23 16:14:52.718837
# Unit test for function find_template
def test_find_template():
    import tempfile
    dir = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(dir, 'foo'))
        os.makedirs(os.path.join(dir, 'foo', 'cookiecutter-{{generator_path}}'))

        assert 'cookiecutter-{{generator_path}}' == os.path.split(find_template(dir))[1]
    finally:
        import shutil
        shutil.rmtree(dir)

    try:
        os.makedirs(os.path.join(dir, 'foo'))
        os.makedirs(os.path.join(dir, 'foo', 'cookiecutter-bar'))

        assert find_template(dir) is NonTemplatedInputDirException
    finally:
        import shutil

# Generated at 2022-06-23 16:14:55.913223
# Unit test for function find_template
def test_find_template():
    # repo_dir = tempfile.mkdtemp()
    # print "TESTING"
    # find_template(repo_dir)
    assert 1==1

# Generated at 2022-06-23 16:15:06.609021
# Unit test for function find_template
def test_find_template():
    """Test the find_template function"""
    # It should be able to find the template dir in a git repo
    repo_dir = os.path.normpath('tests/test-find-template/git_repo')
    template_dir = find_template(repo_dir)
    template_dir_expected = os.path.normpath(
        'tests/test-find-template/git_repo/the-project'
    )
    assert template_dir == template_dir_expected

    # It should return None if no template dir could be found
    repo_dir = os.path.normpath('tests/test-find-template/no-template')
    template_dir = find_template(repo_dir)
    assert template_dir == None

# Generated at 2022-06-23 16:15:09.647096
# Unit test for function find_template
def test_find_template():
    repo_dir = 'cookiecutter-pypackage/'
    expected_output = 'cookiecutter-pypackage/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}/'
    output = find_template(repo_dir)
    print(output)
    assert output == expected_output

test_find_template()

# Generated at 2022-06-23 16:15:11.286429
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter/tests/test-findtemplate') == 'cookiecutter/tests/test-findtemplate/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:13.755026
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/user/Cookies/template/') == 'template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:19.435163
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    test_dir = os.path.abspath('tests/test-dir')
    res = find_template(test_dir)
    assert 'tests/test-dir/{{cookiecutter.project_name}}' == res

# Generated at 2022-06-23 16:15:23.627569
# Unit test for function find_template
def test_find_template():
    repo_dir = 'cookiecutter-pypackage'
    project_template = 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    project_template_found = find_template(repo_dir)

    assert project_template == project_template_found

# Generated at 2022-06-23 16:15:26.922366
# Unit test for function find_template
def test_find_template():
    repo_dir = "/home/khi/git/cookiecutter/tests/fake-repo-tmpl"

# Generated at 2022-06-23 16:15:29.709934
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/trpl/code/cookiecutter-example-template') == '/home/trpl/code/cookiecutter-example-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:36.788497
# Unit test for function find_template
def test_find_template():
    logger.debug('Testing the function "find_template"')
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter

    output = cookiecutter('tests/fake-repo-pre/', no_input=True)
    test_dir = tempfile.mkdtemp()
    shutil.copytree(output, test_dir)
    assert find_template(test_dir) == os.path.join(test_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:15:39.420043
# Unit test for function find_template
def test_find_template():
    """Verify find_template works."""
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:44.422659
# Unit test for function find_template
def test_find_template():
    """Unit tests for the find_template() function."""
    test_dir = os.path.join(os.path.dirname(__file__), '..', 'tests')
    assert find_template(test_dir) == os.path.join(
        test_dir, 'test-template', '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:15:55.787223
# Unit test for function find_template
def test_find_template():
    from cookiecutter import generate
    from test_utils.compare import compare_dirs

    TEST_DIR = os.path.dirname(os.path.abspath(__file__))
    input_path = TEST_DIR + '/fake-repo-pre/'
    # output_path = tempfile.mkdtemp()
    output_path = TEST_DIR + '/fake-repo-pre-output/'

    project_dir = generate.generate_files(
        repo_dir=input_path,
        context=None,
        output_dir=output_path,
        overwrite_if_exists=True)

    assert project_dir == os.path.join(output_path, 'fake-project')
    assert compare_dirs(project_dir, input_path + 'fake-project-pre/')

# Generated at 2022-06-23 16:15:58.820801
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/cookiecutter-pypackage/') == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:07.517828
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    try:
        # Test with a directory that has no template directory
        repo_dir = './tests/files/false_template'
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('find_template does not raise the proper exception')
    finally:
        # Test with a directory that has a template directory
        repo_dir = './tests/files/true_template'
        project_template = find_template(repo_dir)
        assert project_template == (
            './tests/files/true_template/{{cookiecutter.repo_name}}'
        )



# Generated at 2022-06-23 16:16:15.473151
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'fake-repo',
    )

    tmp_dir = tempfile.mkdtemp()
    shutil.copytree(repo_dir, os.path.join(tmp_dir, 'fake-repo'))
    tmp_repo_dir = os.path.join(tmp_dir, 'fake-repo')

    project_template = find_template(tmp_repo_dir)
    assert project_template == 'fake-repo/{{cookiecutter.repo_name}}', project_template

# Generated at 2022-06-23 16:16:21.128202
# Unit test for function find_template
def test_find_template():
    # Check file system
    assert find_template('/home/tester/tests/mock-repo') == '/home/tester/tests/mock-repo/{{cookiecutter.repo_name}}'
    assert find_template('/home/tester/tests/mock-repo-nontemplate') == NonTemplatedInputDirException

# Generated at 2022-06-23 16:16:27.018308
# Unit test for function find_template
def test_find_template():
    """Test that find_template is able to extract the name of a template."""
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    template_name = find_template(repo_dir)
    assert template_name == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:27.465282
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:32.106109
# Unit test for function find_template
def test_find_template():
    """Function to test find_template"""
    temp_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_data',
        'repo_with_templated_dir'
    )
    templated_dir = find_template(temp_dir)
    assert templated_dir == os.path.join(temp_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:16:35.302258
# Unit test for function find_template
def test_find_template():
    import tempfile
    cur_dir = os.getcwd()
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    os.makedirs('tests/fake-repo-tmpl')
    open('tests/fake-repo-tmpl/README.md', 'w').close()
    find_template('tests/fake-repo-tmpl')
    os.chdir(cur_dir)

# Generated at 2022-06-23 16:16:45.164251
# Unit test for function find_template
def test_find_template():
    """
    Sanity check for find_template.
    """
    import tempfile

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:16:53.794894
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct directory."""
    test_repo_dir = 'test_repo_dir'
    test_dir_contents = ['dir1', 'dir2', 'dir3', 'dir4', 'dir5', 'dir6']
    cookiecutter_dirs = {'dir1':False,
                         'dir2':True,
                         'dir3':False,
                         'dir4':False,
                         'dir5':True,
                         'dir6':False}
    test_project_template = find_template(test_repo_dir)
    assert test_project_template == 'test_repo_dir/dir2'

# Generated at 2022-06-23 16:16:54.336407
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-23 16:17:02.303369
# Unit test for function find_template
def test_find_template():
    """Verify the functionality of find_template()."""
    import shutil
    from cookiecutter.utils import rmtree

    # Setup
    path = '/tmp/cookiecutter-find-template-test'
    shutil.copytree(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 'fake-repo/',
        ),
        path
    )

    # Test no {{cookiecutter}}
    # Should raise exception
    try:
        shutil.rmtree(os.path.join(path, '{{cookiecutter.project_name}}'))
        find_template(path)
        raise Exception('This should not happen')
    except NonTemplatedInputDirException:
        pass

    # Test no cookiecutter.project_name
   

# Generated at 2022-06-23 16:17:03.328612
# Unit test for function find_template
def test_find_template():
    #TODO: unit test for function find_template
    return


# Generated at 2022-06-23 16:17:07.346513
# Unit test for function find_template
def test_find_template():
    """Verify find_template works correctly."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tests',
        'fake-repo-tmpl',
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-23 16:17:13.202641
# Unit test for function find_template
def test_find_template():
    assert find_template("cookiecutter-pypackage") == find_template("cookiecutter-pypackage")
    assert find_template(".") == find_template(".")
    assert find_template("cookiecutter-pypackage") != find_template("")
    assert find_template("") != find_template("cookiecutter-pypackage")

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:17:19.789271
# Unit test for function find_template
def test_find_template():
    input_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'tests/fake-repo-pre/')
    )
    expected = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'tests/fake-repo-pre/cookiecutter-pypackage/')
    )
    output = find_template(input_dir)
    assert output == expected

# Generated at 2022-06-23 16:17:24.612175
# Unit test for function find_template
def test_find_template():
    test_dir = 'tests/fake-repo'
    assert (
        find_template(test_dir) ==
        os.path.join(test_dir, 'fake-project')
    )

# Generated at 2022-06-23 16:17:33.835474
# Unit test for function find_template
def test_find_template():
    from cookiecutter.compat import TemporaryDirectory
    with TemporaryDirectory() as tmp_dir:
        cookiecutter_dir = os.path.join(tmp_dir, 'cookiecutter-django')
        os.makedirs(cookiecutter_dir)
        with open(os.path.join(cookiecutter_dir, 'file1.txt'), 'w') as f:
            f.write("Test")
        with open(os.path.join(cookiecutter_dir, 'file2.txt'), 'w') as f:
            f.write("Test")
        os.makedirs(os.path.join(cookiecutter_dir, '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-23 16:17:39.376020
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns correct project template dir."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'fake-repo',
        )
    )

    project_template_dir = find_template(repo_dir)

    assert project_template_dir == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-23 16:17:40.013674
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:17:46.872786
# Unit test for function find_template
def test_find_template():

    # Construct a repo_dir_contents list (simulating `os.listdir`)
    repo_dir_contents = [
        'dummy-repo',
        'cookiecutter-dummy',
        'dbuilder',
    ]

    # Ensure that it finds 'cookiecutter-dummy'
    project_template = find_template(repo_dir_contents)
    assert project_template == 'cookiecutter-dummy'

# Generated at 2022-06-23 16:17:48.785930
# Unit test for function find_template
def test_find_template():
    os.chdir("/Users/pydanny/github/cookiecutter-django")
    find_template(".")

# Generated at 2022-06-23 16:17:57.477708
# Unit test for function find_template
def test_find_template():
    """Verify that we correctly find the template in repository."""
    from cookiecutter import utils
    from cookiecutter.prompt import read_user_yes_no
    from cookiecutter.tests.test_rebuild import make_repo

    repo_dir, cleanup = make_repo()
    project_template = utils.find_template(repo_dir)
    assert u'{{cookiecutter.repo_name}}' in project_template

    # cleanup
    read_user_yes_no.cache_clear()
    cleanup()



# Generated at 2022-06-23 16:17:58.476588
# Unit test for function find_template
def test_find_template():
    # Mock the directories
    pass

# Generated at 2022-06-23 16:18:06.874689
# Unit test for function find_template
def test_find_template():
    import pytest

    dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'clone_repo_tests'
    )

    # Template is '{{cookiecutter.repo_name}}'
    assert 'foo-bar' == find_template(os.path.join(dir, 'expected_repo'))

    # Template is '{{cookiecutter.repo_name}}-master'
    assert 'foo-bar-master' == find_template(
        os.path.join(dir, 'expected_repo2')
    )

    # Raises exception if no templated directory found
    with pytest.raises(NonTemplatedInputDirException):
        find_template(os.path.join(dir, 'expected_repo3'))

# Generated at 2022-06-23 16:18:17.397297
# Unit test for function find_template
def test_find_template():
    """Test for the function find_template."""
    import tempfile

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    assert find_template(repo_dir) == os.path.join(
        repo_dir, 'cookiecutter-pypackage'
    )
    os.rmdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    assert find_template(repo_dir) == os.path.join(
        repo_dir, 'cookiecutter-pypackage'
    )

# Generated at 2022-06-23 16:18:27.861703
# Unit test for function find_template
def test_find_template():
    """
    Test that function find_template() finds the template dir.
    """
    import tempfile
    import shutil

    # Create a test directory with a single template directory.
    project_dir = os.path.join('tests', 'fake-repo-tmpl')
    temp_dir = tempfile.mkdtemp()
    temp_project_dir = shutil.copytree(project_dir, temp_dir)

    # Get relative path to template.
    template = find_template(temp_project_dir)
    _, filename = os.path.split(template)
    assert filename == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:32.071269
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the right template."""
    repo_dir = '/foo/bar/cookiecutter-pypackage'
    result = find_template(repo_dir)
    assert result == '/foo/bar/cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:18:34.102241
# Unit test for function find_template
def test_find_template():
    """Verify expected output of find_template()."""
    find_template('test/test-repo')

# Generated at 2022-06-23 16:18:36.452555
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""

# vim: fileencoding=utf-8 et ts=4 sts=4 sw=4 tw=0

# Generated at 2022-06-23 16:18:42.632242
# Unit test for function find_template
def test_find_template():
    test_input_path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        'tests',
        'test-cookiecutters',
        'fake-repo'
    )
    test_input_path = os.path.normpath(test_input_path)

    template_found = find_template(test_input_path)

    assert os.path.join(test_input_path, '{{cookiecutter.repo_name}}') == template_found

# Generated at 2022-06-23 16:18:47.125282
# Unit test for function find_template
def test_find_template():
    abs_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    repo_dir = os.path.join(abs_dir, 'tests', 'fake-repo-pre-rendered')
    template_dir = find_template(repo_dir)
    assert 'bakery' in template_dir

# Generated at 2022-06-23 16:18:52.353074
# Unit test for function find_template
def test_find_template():
    """Find the project template within a cloned repository."""
    test_folder = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-input')
    expected = os.path.join(test_folder, 'project_name')
    assert find_template(test_folder) == expected

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:19:00.453098
# Unit test for function find_template
def test_find_template():
    """
    Verify that `find_template` returns the directory path of the project
    template from the given repo directory.
    """
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)),
                            'fake-repo')
    expected_project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    actual_project_template = find_template(repo_dir)
    assert actual_project_template == expected_project_template

# Generated at 2022-06-23 16:19:06.706376
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    test_root = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "tests/fake-repo-pre-gen/"
    )
    template_root = os.path.join(
        test_root, "{{cookiecutter.repo_name}}"
    )
    assert find_template(test_root) == template_root

# Generated at 2022-06-23 16:19:10.008266
# Unit test for function find_template
def test_find_template():
    """Verify the template directory is correctly discovered."""
    repo_dir = 'tests/test-templates/fake-repo'
    template_dir = find_template(repo_dir)
    assert template_dir == 'tests/test-templates/fake-repo/fake-project'

# Generated at 2022-06-23 16:19:13.262060
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, 'cookiecutter-foobar')
    os.mkdir(project_template)

    try:
        assert find_template(repo_dir=repo_dir) == project_template
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:19:17.445380
# Unit test for function find_template
def test_find_template():
    repo_dir = ('tests/test-projects/cookiecutter-demo')
    project_template = ('tests/test-projects/cookiecutter-demo' + 
    '/cookiecutter-{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:19:20.662931
# Unit test for function find_template
def test_find_template():
    """Return path to the project template dir."""
    template_dir = 'tests/test-find-template/{{cookiecutter.repo_name}}'
    assert find_template(template_dir) == 'tests/test-find-template/my-fake-project'

# Generated at 2022-06-23 16:19:24.488715
# Unit test for function find_template
def test_find_template():
    """
    If a repository contains an 'undefined' dir with a '{{cookiecutter.repo_name}}' in the name,
    find_template should return that dir.
    """
    path = os.path.join('tests', 'test-find-repo', '{{cookiecutter.repo_name}}')
    template_dir = find_template(path)
    assert template_dir == path


# Generated at 2022-06-23 16:19:31.666083
# Unit test for function find_template
def test_find_template():
    """Test find_template function to make sure is working"""
    repo_dir = '/home/vivek/projects/cookiecutter-packagr/tests/test-files/test-repo'
    template = find_template(repo_dir)
    assert template == '/home/vivek/projects/cookiecutter-packagr/tests/test-files/test-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:34.097917
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected"""
    find_template(os.path.abspath(os.path.dirname(__file__)))

# Generated at 2022-06-23 16:19:39.092631
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre') == 'tests/fake-repo-pre/fake-repo'



# Generated at 2022-06-23 16:19:49.591572
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.main import cookiecutter

    TEMP_REPO_DIR = 'tests/files/fake-repo-tmpl'

    # Create a fake repo to test against
    shutil.copytree('tests/fake-repo-pre-gen', TEMP_REPO_DIR)
    cookiecutter(TEMP_REPO_DIR)

    # Run find_template on the fake repo to find the project template
    assert find_template(os.path.join(TEMP_REPO_DIR, 'fake-repo')) == os.path.join(TEMP_REPO_DIR, 'fake-repo', 'cookiecutter-pypackage')

    shutil.rmtree(TEMP_REPO_DIR)

# Generated at 2022-06-23 16:19:55.661544
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    # pylint: disable=no-member
    from cookiecutter.utils.paths import TEST_TEMPLATE_DIR
    from cookiecutter.utils.tests import generate_files
    from nose.tools import eq_

    with generate_files(TEST_TEMPLATE_DIR):
        project_template = find_template(TEST_TEMPLATE_DIR)
        eq_(project_template, os.path.join(TEST_TEMPLATE_DIR, 'project_template'))

# Generated at 2022-06-23 16:20:03.183902
# Unit test for function find_template

# Generated at 2022-06-23 16:20:08.797715
# Unit test for function find_template
def test_find_template():
    """
    Test that find_template finds a cookiecutter-configured directory in a
    test repo, and returns None if it doesn't exist
    """
    assert find_template('tests/test-repo-pre/') is None
    assert find_template('tests/test-repo-pre/fake-repo') is None

    assert os.path.exists(find_template('tests/fake-repo-tmpl'))

# Generated at 2022-06-23 16:20:16.089746
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    # Create a directory
    import tempfile
    temp_dir = tempfile.mkdtemp()
    # Create a fake template directory with one file in it
    template_dir = os.path.join(temp_dir,'fake_template')
    template_file = os.path.join(template_dir,'dummy-file')
    os.mkdir(template_dir)
    open(template_file, 'a').close()
    # Now test that the template directory was found
    assert find_template(temp_dir) == template_dir
    # Now remove the temporary directory
    import shutil
    shutil.rmtree(temp_dir)

# Generated at 2022-06-23 16:20:21.403014
# Unit test for function find_template
def test_find_template():
    """Test that ``find_template()`` can locate the project template."""
    curdir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(curdir, '..', 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    template_dir = find_template(test_dir)

    assert 'tests/fake-repo-pre/{{cookiecutter.repo_name}}' in template_dir

# Generated at 2022-06-23 16:20:27.329919
# Unit test for function find_template
def test_find_template():
    """Ensure function returns correct path to project template.
    """
    import tempfile
    import filecmp
    import shutil

    # Copy in test cookiecutter template inside temp directory
    temp_dir = tempfile.mkdtemp()
    template_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    fixture_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tests',
        'fixtures',
        'fake-repo'
    )
    shutil.copytree(fixture_dir, template_dir)

    # Ensure template is found

# Generated at 2022-06-23 16:20:30.753841
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-input/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-input/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:35.870001
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the template in a repo."""
    from cookiecutter.main import cookiecutter

    cookiecutter('tests/fake-repo-tmpl/')

    project_template = find_template('fake-repo-tmpl')
    assert project_template == 'fake-repo-tmpl/fake-project-tmpl'
    assert False

# Generated at 2022-06-23 16:20:46.290211
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function."""
    from cookiecutter import generate
    from cookiecutter import repo

    # Create a fake testing project
    generate.generate_files(
        repo_dir="",
        context={'project_name': 'test_project', 'repo_name': 'test_project'},
        overwrite_if_exists=True,
    )

    # Assert for proper behavior
    assert find_template(repo_dir=os.path.join(os.getcwd(), 'test_project')) == os.path.join(os.getcwd(), 'test_project', '{{cookiecutter.repo_name}}')

    # Remove fake project
    repo.remove_repo(repo_dir=os.getcwd())

# Generated at 2022-06-23 16:20:47.039327
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:20:53.000132
# Unit test for function find_template
def test_find_template():
    '''
    Check that the project template is found and returned as relative path
    '''
    input_directory_abspath = os.path.abspath(os.path.join(os.getcwd(), 'cookiecutter-pypackage/'))
    assert(find_template(input_directory_abspath) == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}')



# Generated at 2022-06-23 16:20:56.672462
# Unit test for function find_template
def test_find_template():
    assert find_template('/github.com/audreyr/cookiecutter-pypackage') == '/github.com/audreyr/cookiecutter-pypackage/cookiecutter-pypackage'



# Generated at 2022-06-23 16:21:08.182709
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'fake-repo'))
    project_template = find_template(repo_dir)
    assert project_template == os.path.abspath(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    try:
        repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tests'))
        find_template(repo_dir)
        assert False
    except NonTemplatedInputDirException:
        assert True

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:21:12.400091
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    repo_dir = 'tests/fake-repo-pre/'
    template = 'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'

    assert find_template(repo_dir) == template

# Generated at 2022-06-23 16:21:17.009070
# Unit test for function find_template
def test_find_template():
    """Test `find_template` function."""
    import os.path

    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre-gen',
        'fake-repo'
    )

    result = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert result == expected

# Generated at 2022-06-23 16:21:27.795101
# Unit test for function find_template
def test_find_template():
    import tempfile

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary repo made up of two subdirectories
    sub1 = tempfile.mkdtemp(prefix="sub1", dir=tmp_dir)
    sub2 = tempfile.mkdtemp(prefix="sub2", dir=tmp_dir)
    cookiecutter_sub1 = tempfile.mkdtemp(prefix="cookiecutter_{{", dir=sub1)
    cookiecutter_sub2 = tempfile.mkdtemp(prefix="cookiecutter_{{", dir=sub2)

    project_template = find_template(tmp_dir)

    assert project_template == os.path.join(tmp_dir, "sub1/cookiecutter_{{")

# Generated at 2022-06-23 16:21:29.373032
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    # TODO: figure out how to test this.
    assert True is True

# Generated at 2022-06-23 16:21:34.557765
# Unit test for function find_template
def test_find_template():
    """Assert that find_template returns the project template directory."""
    from cookiecutter import main

    # Create a test repo from the fixtures
    repo_dir = main.cookiecutter('tests/test-repo-pre/', no_input=True)

    # Find the project template directory
    assert find_template(repo_dir) == os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:21:38.944410
# Unit test for function find_template
def test_find_template():
    this_dir = os.path.dirname(__file__)
    repo_dir = os.path.join(this_dir, 'fake-repo')

    p_t = find_template(repo_dir)
    assert os.path.join(repo_dir, '{{cookiecutter.repo_name}}') == p_t

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:21:45.109167
# Unit test for function find_template
def test_find_template():
    """ Find the template that was cloned """
    test_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test-template')

    template = find_template(test_dir)

    assert template == os.path.join(test_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:21:50.687284
# Unit test for function find_template
def test_find_template():
    expected_template_dir = os.path.join(
        os.path.abspath(os.path.curdir), 'fake-repo-pre/masters/{{cookiecutter.repo_name}}'
    )
    actual_template_dir = find_template(
        os.path.abspath(os.path.join(os.path.curdir, 'fake-repo-pre'))
    )
    assert expected_template_dir == actual_template_dir

# Generated at 2022-06-23 16:21:56.065296
# Unit test for function find_template
def test_find_template():
    """Test if find_template returns the correct template directory"""
    repo_dir = os.path.join(os.getcwd(), 'tests', 'test-repo-pre')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-23 16:22:01.018196
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import repo
    from cookiecutter import utils

    # Make a temporary git clone of the project to work off of
    clone_dir = utils.make_empty_dir()
    repo.git_clone(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        'master',
        clone_dir,
        checkout='master',
        no_input=True
    )

    template_dir = '{{cookiecutter.repo_name}}'
    output_dir = os.path.join(clone_dir, template_dir)

    # Use a context that returns the project template name as the project_slug.
    # This is required because the template itself contains a {{cookiecutter.*}}
    # include: {{cookie

# Generated at 2022-06-23 16:22:01.897552
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/nonick/repo'
    assert find_template(repo_dir) == 'cookiecutter-python'

# Generated at 2022-06-23 16:22:13.017284
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    from cookiecutter.utils import cleanup_tmp_dir
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temp dir and cd into it
    old_dir = os.getcwd()
    tmpdir = tempfile.mkdtemp()

    # Create a template with jinja2 templates as directories
    cookiecutter_example_repo = os.path.abspath('tests/test-data/fake-repo')
    shutil.copytree(cookiecutter_example_repo, tmpdir)

    # Go into the tmp dir and run the function
    os.chdir(tmpdir)
    project_template = find_template(tmpdir)

    # Check that find_template returns the correct path

# Generated at 2022-06-23 16:22:24.150043
# Unit test for function find_template
def test_find_template():
    # test for the case in which the repo_dir is the template
    template_name = '{{cookiecutter.test_template.test_test}}'
    file_list = []
    file_list.append(template_name)
    found_template = find_template(file_list)
    assert found_template == template_name

    # test for the case in which the repo_dir is a parent of the template
    not_template_name = 'not_a_template'
    file_list.append(not_template_name)
    found_template = find_template(file_list)
    assert found_template == template_name

    # test for the case in which there is no template
    file_list = []
    file_list.append(not_template_name)