

# Generated at 2022-06-23 16:12:19.968619
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:12:21.912192
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template."""
    pass

# Generated at 2022-06-23 16:12:25.620615
# Unit test for function find_template
def test_find_template():
    path_to_test = os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    template = find_template('tests/fake-repo-pre')
    assert template == path_to_test, template

# Generated at 2022-06-23 16:12:29.941698
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/user/my-repo'
    repo_dir_contents = ['cookiecutter-pypackage']
    os.listdir(repo_dir)
    assert find_template(repo_dir) == os.path.join(repo_dir, repo_dir_contents[0])


# Generated at 2022-06-23 16:12:34.485835
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the relative path to the project template."""
    repo_dir = 'tests/test-repo'
    result = find_template(repo_dir)
    answer = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert result == answer


# Generated at 2022-06-23 16:12:36.713019
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/code/cookiecutter-pypackage') == '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:12:42.658981
# Unit test for function find_template
def test_find_template():
    """Return the path to the template in a locally cloned repo."""
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    expected = '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    actual = find_template(repo_dir)
    assert expected == actual

# Generated at 2022-06-23 16:12:54.176476
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    import tempfile
    import shutil
    import logging

    logger.debug('Running unit tests')
    logger.setLevel(logging.DEBUG)

    test_dir = tempfile.mkdtemp()
    fake_dir_without_cookiecutter_dir = os.path.join(test_dir, 'fake_dir')
    os.mkdir(fake_dir_without_cookiecutter_dir)
    os.mkdir(os.path.join(fake_dir_without_cookiecutter_dir, 'not_a_cookiecutter_dir'))

    fake_dir_with_cookiecutter_dir = os.path.join(test_dir, 'fake_dir_with_cookiecutter_dir')

# Generated at 2022-06-23 16:13:03.073957
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    tmp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(tmp_dir, 'repo_dir')
    os.makedirs(repo_dir, exist_ok=True)
    cookiecutter_json = os.path.join(repo_dir, 'cookiecutter.json')
    with open(cookiecutter_json, 'w') as fh:
        fh.write('{"Hello": "World"}')
    assert find_template(repo_dir) == cookiecutter_json


    repo_dir_without_template_dir = os.path.join(tmp_dir, 'repo_dir_without_template_dir')

# Generated at 2022-06-23 16:13:07.662233
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works properly."""
    this_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(this_dir, 'tests', 'test-hooks-repo')
    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(
        repo_dir, 'hooks-{{ hooks }}'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:13:11.108296
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}/'


# Generated at 2022-06-23 16:13:13.382115
# Unit test for function find_template
def test_find_template():
    """Check that find_template() returns the project template."""
    pass

# Generated at 2022-06-23 16:13:23.551961
# Unit test for function find_template
def test_find_template():
    """Verify `find_template` function."""
    from cookiecutter import utils

    tests_dir = os.path.abspath(os.path.dirname(__file__))
    fixture_dir = os.path.join(tests_dir, '..', 'tests/fixtures/fake-repo')

    project_template = utils.find_template(fixture_dir)
    assert project_template == os.path.join(fixture_dir, '{{cookiecutter.repo_name}}'), project_template

# Unit tests
if __name__ == '__main__':
    import sys
    import unittest

    # If no arguments are supplied, run all of the functions
    NO_ARGS = len(sys.argv) == 1


# Generated at 2022-06-23 16:13:34.874789
# Unit test for function find_template
def test_find_template():
    """
    Test find_template()
    """
    # Test 1
    test1_repo_dir = 'tests/test-repo-tmpl/fake-repo-pre/'
    test1_answer = 'tests/test-repo-tmpl/fake-repo-pre/{{cookiecutter.project_name}}'
    assert find_template(test1_repo_dir) == test1_answer

    # Test 2
    test2_repo_dir = 'tests/test-repo-tmpl/fake-repo-post/'
    test2_answer = 'tests/test-repo-tmpl/fake-repo-post/{{cookiecutter.project_name}}'
    assert find_template(test2_repo_dir) == test2_answer

    # Test 3

# Generated at 2022-06-23 16:13:45.660489
# Unit test for function find_template
def test_find_template():
    """Ensure find_template works properly."""
    from .bake import main
    from .repository import checkout
    from .utils import rmtree
    from mock import MagicMock
    import os

    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    context = {'cookiecutter': {'project_name': 'foobar'}}

    # Clear the tmp dir
    rmtree(os.path.join(repo_dir, 'tmp'))

    # Create a fake git repo to test
    checkout(repo_dir, context=context)

    # Mock out the prompt function so the user isn't prompted
    # for new values
    main.prompt_for_config = MagicMock()

    # Make sure the template is found
    main.find

# Generated at 2022-06-23 16:13:47.218073
# Unit test for function find_template
def test_find_template():
    """Ensure `find_template` returns the project template."""
    pass

# Generated at 2022-06-23 16:13:52.684987
# Unit test for function find_template
def test_find_template():

    import shutil
    from tempfile import mkdtemp

    from .compat import patch

    tmp_dir = mkdtemp()

    try:
        with patch('os.listdir', return_value=['{{cookiecutter.repo_name}}']):
            find_template(tmp_dir)
    except NonTemplatedInputDirException as e:
        raise(e)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

# Generated at 2022-06-23 16:13:53.913587
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:13:56.865530
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/test/test-repo') == '/home/vagrant/test/test-repo/{{test-template}}'

# Generated at 2022-06-23 16:14:02.546496
# Unit test for function find_template
def test_find_template():
    """
    Test that find_template() can find the correct child of the root project
    directory.
    """
    # TODO: This should be converted to a unittest
    from cookiecutter import utils
    repo_dir = utils.find_repo_dir('tests/fake-repo-pre/')

    assert find_template(repo_dir) == 'tests/fake-repo-pre/cookiecutter-pypackage/'



# Generated at 2022-06-23 16:14:09.178851
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find the template in a repo."""
    project_dir = os.path.abspath(os.path.join('tests', 'fake-repo-pre-gen'))
    project_template = find_template(project_dir)

    expected = os.path.join(project_dir, 'fake_project')
    assert project_template == expected
    assert os.path.isdir(project_template)

# Generated at 2022-06-23 16:14:20.297027
# Unit test for function find_template
def test_find_template():
    """Verifies that find_template works"""
    import pytest

    # Create a temporary directory
    import tempfile
    repo_dir = tempfile.mkdtemp()

    # Create three directories inside it
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'something-else'))
    os.mkdir(os.path.join(repo_dir, 'something-{{cookiecutter.repo_name}}'))

    # Check that only the directory with double curlys is identified
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Clean up the temporary directory
    import shutil

# Generated at 2022-06-23 16:14:29.113532
# Unit test for function find_template
def test_find_template():
    """Exercise find_template"""
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:14:35.717548
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    test_dir = tempfile.mkdtemp()

    open(os.path.join(test_dir, 'hello'), 'a').close()
    os.mkdir(os.path.join(test_dir, 'hello_1'))

    project_template = find_template(test_dir)
    assert project_template == os.path.join(test_dir, 'hello_1')

    shutil.rmtree(test_dir)

# Generated at 2022-06-23 16:14:43.250664
# Unit test for function find_template
def test_find_template():
    """
    Test find_template.
    """
    # Test a repo without a cookiecutter.json
    input_dir = 'tests/test-input/fake-repo'
    output = find_template(input_dir)
    expected_output = os.path.join(input_dir, 'fake-repo')
    assert output == expected_output

    # Test a correct repo
    input_dir = 'tests/test-input/fake-repo-tmpl/'
    output = find_template(input_dir)
    expected_output = os.path.join(input_dir, 'fake-repo-tmpl')
    assert output == expected_output

    # Test a folder with a cookiecutter.json that is not a template
    input_dir = 'tests/fake-repo-no-templ/'
   

# Generated at 2022-06-23 16:14:44.999560
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    assert find_template("hello") == None

# Generated at 2022-06-23 16:14:53.304907
# Unit test for function find_template
def test_find_template():
    import cookiecutter.config
    from cookiecutter import utils
    from cookiecutter import exceptions

    repo_dir = cloned_repo('https://github.com/audreyr/cookiecutter-pypackage.git')

    # By default, it should work in the repo_dir
    project_template = find_template(repo_dir)
    assert 'cookiecutter-pypackage' in project_template

    # But it might be buried in a subdir
    repo_dir = os.path.join(repo_dir, 'fake_dir')
    project_template = find_template(repo_dir)
    assert 'cookiecutter-pypackage' in project_template

    # If it's not a Cookiecutter template, it should throw an exception

# Generated at 2022-06-23 16:15:03.209055
# Unit test for function find_template
def test_find_template():
    
    find_template("git@github.com:appdynamics-community/cookiecutter-appdynamics-machine-agent#3.2.2")
    find_template("git@github.com:appdynamics-community/cookiecutter-appdynamics-machine-agent-extension#3.2.2")
    find_template("git@github.com:appdynamics-community/cookiecutter-appdynamics-python-extension#3.2")
    find_template("git@github.com:appdynamics-community/cookiecutter-appdynamics-db-agent-extension#3.2")
    find_template("git@github.com:appdynamics-community/cookiecutter-appdynamics-extension-boilerplate")

# Generated at 2022-06-23 16:15:10.836257
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    import tempfile
    tmpdir = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmpdir, 'cookiecutter-project'))
    os.makedirs(os.path.join(tmpdir, 'cookiecutter-foo'))
    os.makedirs(os.path.join(tmpdir, 'cookiecutter-{{cookiecutter.project}}'))
    os.makedirs(os.path.join(tmpdir, 'cookiecutter-bar'))
    assert find_template(tmpdir).endswith('cookiecutter-{{cookiecutter.project}}')

# Generated at 2022-06-23 16:15:18.084832
# Unit test for function find_template
def test_find_template():
    """Verify that find_template function works properly.
    """
    from cookiecutter import utils
    result = utils.find_template('https://github.com/audreyr/cookiecutter-pypackage.git')
    assert result.endswith('cookiecutter-pypackage/{{cookiecutter.repo_name}}')

# Test for template in a subdirectory

# Generated at 2022-06-23 16:15:22.789755
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""

    # Create a mock repo dir
    repo_dir = os.path.abspath('tests/files/test-repo-pre-gen')

    project_template = find_template(repo_dir)

    assert 'tests/files/test-repo-pre-gen/{{cookiecutter.repo_name}}' in project_template

test_find_template()

# Generated at 2022-06-23 16:15:31.537109
# Unit test for function find_template
def test_find_template():
    """Verify function find_template()."""
    os.mkdir('tests/fake-repo-tmpl')
    os.mkdir('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')

    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    os.rmdir('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')
    os.rmdir('tests/fake-repo-tmpl')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:15:36.361823
# Unit test for function find_template
def test_find_template():
    home = os.path.expanduser('~')
    repo_dir = os.path.join(home, 'cookiecutter-simple')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:15:40.575176
# Unit test for function find_template
def test_find_template():
    """
    Test basic function
    """
    path='/Users/raymondmeng/Downloads/cookiecutter-pypackage-minimal'
    project_template = os.path.join(path,'cookiecutter-pypackage-minimal')
    assert (find_template(path) == project_template)


# Generated at 2022-06-23 16:15:43.058370
# Unit test for function find_template
def test_find_template():
    template = find_template('tests/test-input')
    assert template == 'tests/test-input/{{cookiecutter.project_name}}'

# Generated at 2022-06-23 16:15:50.608048
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests import fixture_build_dir
    template_dir = os.path.join(
        fixture_build_dir,
        'templates',
        'cookiecutter-pypackage'
    )
    assert os.path.exists(find_template(template_dir))
    try:
        find_template(fixture_build_dir)
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-23 16:15:54.346646
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), "..")
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:15:57.176030
# Unit test for function find_template
def test_find_template():
    """Verify CookiecutterDjango was able to find the project template."""
    project_template = find_template('cookiecutter-django')
    assert project_template == 'cookiecutter-django/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:01.042687
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(__file__), 'tests', 'test-find-repo', 'pyproject-cookiecutter-master'
    )
    result = find_template(test_dir)
    assert result == os.path.join(test_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:16:01.605246
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:02.046337
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:05.312614
# Unit test for function find_template
def test_find_template():
    """Test the find_template function for finding the project template."""
    test_dir = './tests/test-find-repo/cookiecutter-pypackage'
    result = find_template(test_dir)
    assert result == './tests/test-find-repo/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:16:08.780851
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.abspath('tests/fake-repo'))
    assert find_template(os.path.abspath('.')) == os.path.abspath(
        'fake-project'
    )

# Generated at 2022-06-23 16:16:14.242789
# Unit test for function find_template
def test_find_template():
    """A unit test for the `find_template` function."""
    this_dir = os.path.dirname(os.path.realpath(__file__))
    repo_dir = os.path.join(this_dir, 'test-repo')
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:16:18.127627
# Unit test for function find_template
def test_find_template():
    
    repo_dir = "tests/fixtures/fake-repo"
    project_template = find_template(repo_dir)
    assert project_template == "tests/fixtures/fake-repo/{{cookiecutter.project_name}}"

# Generated at 2022-06-23 16:16:23.291594
# Unit test for function find_template
def test_find_template():
    # expect
    sample_project_template = os.path.join(
        'sample_template',
        '{{cookiecutter.repo_name}}'
    )

    # when
    result = find_template('sample_template')

    # then
    assert sample_project_template in result

# Generated at 2022-06-23 16:16:33.578704
# Unit test for function find_template
def test_find_template():
    """Test for the find_template function."""
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(repo_dir)

    f1 = open(os.path.join(repo_dir, 'foobar'), 'w')
    f1.close()

    f2 = open(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.project_slug}}'), 'w')
    f2.close()

    f3 = open(os.path.join(repo_dir, 'README.rst'), 'w')
    f3.close()


# Generated at 2022-06-23 16:16:43.675738
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import config
    from cookiecutter.compat import TemporaryDirectory

    repo_dir = os.path.join(
        config.get_user_config_path(),
        'cookiecutters',
        'cookiecutter-pypackage',
    )

    with TemporaryDirectory() as output_dir:
        logger.debug('Output directory is: %s', output_dir)
        cookiecutter(repo_dir, output_dir=output_dir)

        output_dir_contents = os.listdir(output_dir)
        project_template = None

        for item in output_dir_contents:
            if 'cookiecutter' in item and '{{' in item and '}}' in item:
                project_template = item


# Generated at 2022-06-23 16:16:54.286762
# Unit test for function find_template
def test_find_template():
    """Verify function can find template dir if present."""
    import shutil
    import tempfile
    template_dir = tempfile.mkdtemp()
    try:
        with open(os.path.join(template_dir, 'cookiecutter.json'), 'w') as f:
            f.write('')
        d = tempfile.mkdtemp()
        repo_dir = os.path.join(d, 'repo')
        os.makedirs(repo_dir)
        shutil.copytree(template_dir, os.path.join(repo_dir, 'cookiecutter-template'))
        assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-template')
    finally:
        shutil.rmtree(template_dir)
       

# Generated at 2022-06-23 16:17:02.272854
# Unit test for function find_template
def test_find_template():
    """
    This function is used to test find_template()
    """
    import random
    import string
    import shutil
    import tempfile

    from cookiecutter.generate import generate_context

    # Set up a fake cookiecutter template
    FAKE_REPO_DIR = tempfile.mkdtemp()

    FAKE_REPO = os.path.join(FAKE_REPO_DIR, 'fake-repo')
    os.mkdir(FAKE_REPO)

    project_dir = os.path.join(
        FAKE_REPO,
        '{{cookiecutter.repo_name}}'
    )
    os.mkdir(project_dir)

    other_dir = os.path.join(FAKE_REPO, 'other-dir')
    os.mkdir(other_dir)

# Generated at 2022-06-23 16:17:07.315376
# Unit test for function find_template
def test_find_template():
    # test_utils.py must be two directories above because it's in a 'tests'
    # subdirectory.
    root_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), os.pardir, os.pardir))
    repo_dir = os.path.join(root_dir, 'tests', 'fake-repo-pre', 'fake-repo')
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:17:09.072023
# Unit test for function find_template
def test_find_template():
    assert find_template('./') == './{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:20.317259
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() finds the correct project template."""
    from cookiecutter import utils
    from cookiecutter.tests import mock
    from cookiecutter.tests import test_utils
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_DIR
    from cookiecutter.tests.test_utils import TEST_USER_DIR

    mock_context = {
        'cookiecutter': {
            'repo_dir': TEST_USER_DIR,
        }
    }
    project_template = test_utils.find_project_template(TEST_USER_DIR)

    utils.find_template(TEST_USER_DIR)
    utils.make_sure_path_exists(project_template, TEST_USER_DIR)

# Generated at 2022-06-23 16:17:22.192990
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:25.752320
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-find-template/{{cookiecutter.project_name}}'
    project_template = find_template(repo_dir)
    assert project_template == repo_dir

# Generated at 2022-06-23 16:17:30.264714
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'fake-repo')
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == project_template


# Generated at 2022-06-23 16:17:31.560331
# Unit test for function find_template
def test_find_template():
    """Verify that `find_template` returns the correct directory name."""
    pass

# Generated at 2022-06-23 16:17:40.992332
# Unit test for function find_template
def test_find_template():
    import shutil
    from .compat import ConfigParser
    from cookiecutter.utils import work_in
    from tests.test_utils import TEST_TEMPLATE

    tmpdir = TEST_TEMPLATE
    os.makedirs(os.path.join(tmpdir, '{{cookiecutter.repo_name}}'))

    # Create repo_dir and repo_dir_contents
    repo_dir = os.path.join(tmpdir, '{{cookiecutter.repo_name}}')
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    repo_dir_contents = os.listdir(repo_dir)

    assert len(repo_dir_contents) == 1

    # Test that {{cookiecutter.re

# Generated at 2022-06-23 16:17:47.328182
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct template"""

    # Set up
    test_directory = os.path.join('tests', 'test-find-template')

    # Execute the function
    template_path = find_template(test_directory)

    # Verify the results
    expected_path = os.path.join(test_directory, 'cookiecutter-test-template')
    assert template_path == expected_path

# Generated at 2022-06-23 16:17:52.121872
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template()."""
    this_dir = os.path.abspath(os.path.dirname(__file__))
    project_template = find_template(this_dir)
    assert os.path.join(this_dir, 'my-fake-project') == project_template

# Generated at 2022-06-23 16:17:57.951232
# Unit test for function find_template
def test_find_template():
    """Test that find_template() can find the proper directory in a nested mess."""
    from cookiecutter.main import cookiecutter
    template = cookiecutter(
        'tests/test-find-template',
        no_input=True,
        overwrite_if_exists=True,
    )
    assert template == 'fake-project'

# Generated at 2022-06-23 16:18:03.102181
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.abspath('tests/test-data/fake-repo/')
    test_cookiecutter_json = os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(test_repo_dir) == test_cookiecutter_json

# Generated at 2022-06-23 16:18:12.199052
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/user/repo_folder'
    repo_dir_contents = ['unrelated_file', 'cookiecutter-{{cookiecutter.repo_name}}']
    expected_project_template = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    print(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    actual_project_template = find_template(repo_dir)

    assert expected_project_template == actual_project_template

# Generated at 2022-06-23 16:18:14.748467
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:18:21.339451
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template


# Generated at 2022-06-23 16:18:25.895835
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    assert repo_dir == find_template(os.path.join(repo_dir, 'cookiecutters', '_tests'))

# Generated at 2022-06-23 16:18:29.079554
# Unit test for function find_template
def test_find_template():
    assert find_template('../cookiecutter-pypackage') == '../cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:38.586605
# Unit test for function find_template
def test_find_template():
    """Verify function find_template.
    """
    # Create temporary directory
    import tempfile
    dir = tempfile.mkdtemp()

    # Create a temp file in the temp folder
    orig_dir = os.getcwd()
    file = open(os.path.join(dir, 'cookiecutter-foobar'), 'a')
    file.close()

    # Go to the temp folder
    os.chdir(dir)
    assert find_template(dir) == 'repositories/tests/test-repo/cookiecutter-foobar'

    # Go back to the original directory
    os.chdir(orig_dir)

# Generated at 2022-06-23 16:18:44.023862
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template`."""
    assert find_template('../tests/fake-repo-tmpl') == '../tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:52.645378
# Unit test for function find_template
def test_find_template():
    """Test that find_template method correctly finds the template from a non-templated directory.

    This test is unnecessary, since the method being tested is immediately 
    tested in test_parse_template(). This method is here for future use and 
    to show how to write a unit test.
    """
    os.chdir('tests')
    output = find_template('tests/fake-repo-pre')
    assert(output == 'tests/fake-repo-pre/fake-repo-{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:18:55.083755
# Unit test for function find_template
def test_find_template():
    find_template("/home/cookiecutter/cookiecutter-jquery")

# Generated at 2022-06-23 16:18:56.126268
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:19:00.020206
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:09.584446
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    from unittest import TestCase
    import shutil
    from cookiecutter import main

    class TestFindTemplate(TestCase):
        def setUp(self):
            self.repo_dir = main.cookiecutter(
                'tests/fake-repo-tmpl/',
                no_input=True
            )

        def tearDown(self):
            shutil.rmtree(self.repo_dir)

        def test_find_template(self):
            repo_dir = self.repo_dir
            template = find_template(repo_dir)
            self.assertTrue('fake-project-tmpl' in template)

# Generated at 2022-06-23 16:19:20.197270
# Unit test for function find_template
def test_find_template():
    """
    Test function for find_template.
    """
    import shutil
    import tempfile
    from cookiecutter.generate import generate_context

    def cleanup():
        # clear the test directory
        shutil.rmtree(test_dir)
    # create and populate a sample directory
    test_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(test_dir, 'test_project_dir'))
    os.mkdir(os.path.join(test_dir, 'test_project_dir2'))
    os.mkdir(os.path.join(test_dir, 'test_project_dir{{cookiecutter.dir_name}}'))

    test_dir2 = tempfile.mkdtemp()


# Generated at 2022-06-23 16:19:20.699624
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:19:22.397409
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.abspath('.'), 'tests/fake-repo-pre-gen/')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}/')

# Generated at 2022-06-23 16:19:32.022093
# Unit test for function find_template
def test_find_template():
    """Test find template function."""
    logger.debug('Running unit test for find_template.')

    repo_dir = os.path.join(
        os.getcwd(),
        'tests/test-find-template/fake-repo')

    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}')

    assert project_template == expected_project_template, 'Expected {} to be the template.'.format(expected_project_template)

# Generated at 2022-06-23 16:19:37.862724
# Unit test for function find_template
def test_find_template():
    import os
    os.chdir('tests/fake-repo-pre/')
    repo_dir = os.path.abspath(os.curdir)
    project_template = find_template(repo_dir)

    expected = os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert project_template == expected

# Generated at 2022-06-23 16:19:43.702095
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from .compat import NamedTemporaryFile
    from .main import cookiecutter

    with NamedTemporaryFile(suffix='.zip') as zipfile:
        cookiecutter('tests/fake-repo-tmpl/', no_input=True, output_dir='.')
        project_template = find_template('fake-repo-tmpl')
        assert project_template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-23 16:19:47.423200
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.

    Code in cookiecutter/tests/test-find-template.py
    """
    pass

# Generated at 2022-06-23 16:19:57.968883
# Unit test for function find_template
def test_find_template():
    is_dir = os.path.isdir
    is_file = os.path.isfile

    faketree = os.path.join(os.path.dirname(__file__), 'fake-template')

    assert find_template(faketree)

    faketree = os.path.join(os.path.dirname(__file__), 'fake-template1')
    assert find_template(faketree)

    faketree = os.path.join(os.path.dirname(__file__), 'nontemplated-dir')
    assert is_dir(faketree)
    try:
        find_template(faketree)
        assert False
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False


# Generated at 2022-06-23 16:20:06.172099
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/norman/Documents/PACKT/Learning Python Design Patterns/Chapter 11/cookiecutter-pypackage-minimal-git') == '/Users/norman/Documents/PACKT/Learning Python Design Patterns/Chapter 11/cookiecutter-pypackage-minimal-git/{{cookiecutter.project_slug}}'

    assert find_template('/Users/norman/Documents/PACKT/Learning Python Design Patterns/Chapter 11/cookiecutter-pypackage-minimal') == '/Users/norman/Documents/PACKT/Learning Python Design Patterns/Chapter 11/cookiecutter-pypackage-minimal/{{cookiecutter.project_name}}'


# Generated at 2022-06-23 16:20:14.241002
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""

    from cookiecutter.utils import rmtree
    from .context_dict import TEST_COOKIE_DIR

    # Setup
    new_repo_dir = 'tests/new-repo'
    repo_dir = 'tests/fake-repo-tmpl'

    if os.path.exists(new_repo_dir):
        rmtree(new_repo_dir)

    os.system('cp -r {0} {1}'.format(repo_dir, new_repo_dir))

    os.chdir(new_repo_dir)

    # Test
    result = find_template('.')
    assert result == 'tests/new-repo/fake_project_tmpl'

    # Teardown

# Generated at 2022-06-23 16:20:22.562474
# Unit test for function find_template
def test_find_template():
    # Test that a templated dir is found.
    #import pdb; pdb.set_trace()
    test_repo_contents = [
        'cookiecutter-pypackage/',
        'cookiecutter.json',
        'README.rst',
    ]
    assert find_template(test_repo_contents) == 'cookiecutter-pypackage/'

    # Test that a non-templated dir raises an exception.
    test_repo_contents = [
        'my_project/',
        'cookiecutter.json',
        'README.rst',
    ]
    #import pdb; pdb.set_trace()

# Generated at 2022-06-23 16:20:33.507697
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter's find_template function."""
    import shutil
    import tempfile

    # Create a fake template repo
    tmp_dir = tempfile.mkdtemp()
    template_dir = os.path.join(tmp_dir, 'fake-repo')
    os.makedirs(template_dir)
    project_template = os.path.join(template_dir, '{{cookiecutter.project_name}}')
    os.makedirs(project_template)

    try:
        found_template = find_template(template_dir)
    except NonTemplatedInputDirException:
        found_template = None

    assert found_template == project_template
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-23 16:20:40.355827
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'fake-repo')
    project_template = find_template(repo_dir)
    expected_result = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    assert project_template == expected_result
    return project_template

# Generated at 2022-06-23 16:20:40.963056
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-23 16:20:49.145117
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import jsonschema
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.utils import rmtree
    from cookiecutter.utils import work_in

    repo_path = os.path.expanduser('~/code/cookiecutter-pypackage')
    repo_dir = os.path.basename(repo_path)

    with work_in(os.path.expanduser('~')):
        # Clone our fixture repo
        os.system('git clone git@github.com:audreyr/cookiecutter-pypackage.git')


# Generated at 2022-06-23 16:20:53.546956
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct result."""
    project_template = find_template('/Users/user/cookiecutter-demo/')
    expected = '/Users/user/cookiecutter-demo/{{cookiecutter.repo_name}}'
    assert project_template == expected


# Generated at 2022-06-23 16:20:59.647467
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    dirname = tempfile.mkdtemp()
    init_dir = os.path.join(dirname, 'foo')
    repo_dir = os.path.join(init_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(init_dir)
    os.mkdir(repo_dir)
    result = find_template(init_dir)
    shutil.rmtree(init_dir)
    assert os.path.exists(init_dir) == False

# Generated at 2022-06-23 16:21:02.483162
# Unit test for function find_template
def test_find_template():
    template_dir = 'tests/files/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    tmpl_dir = find_template(template_dir)
    assert tmpl_dir == 'tests/files/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert os.path.isdir(tmpl_dir)

# Generated at 2022-06-23 16:21:03.400163
# Unit test for function find_template
def test_find_template():
    assert find_template('/tmp') == None

# Generated at 2022-06-23 16:21:08.258158
# Unit test for function find_template
def test_find_template():
    """Test find_template() in utils."""
    template_path = find_template(os.path.abspath('tests/fake-repo-tmpl'))
    assert template_path == os.path.abspath('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:13.686313
# Unit test for function find_template
def test_find_template():
    assert (find_template(os.path.join(os.path.dirname(__file__), 'tests', 'fake-repo-tmpl'))) == (
        os.path.join(os.path.dirname(__file__), 'tests', 'fake-repo-tmpl',
                     '{{cookiecutter.repo_name}}')
    )


# Generated at 2022-06-23 16:21:25.330537
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template() function.
    """
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests', 'fake-repo')
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    # find_template() works even if a default_context file is present
    template = find_template(os.path.join(repo_dir, 'fake-repo-with-context'))
    assert template == os.path.join(repo_dir, 'fake-repo-with-context', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:31.563354
# Unit test for function find_template
def test_find_template():
    """Find the project template in tests/test-repo-pre/."""
    test_dir = os.path.dirname(__file__)
    repo_dir = os.path.abspath(os.path.join(test_dir, '..', 'test-repo-pre'))
    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert project_template == expected_project_template

# Generated at 2022-06-23 16:21:36.205759
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'repositories',
        'tests',
        'test-repo-pre',
    )
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == expected



# Generated at 2022-06-23 16:21:46.805978
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    # Create a temporary directory and a new cookiecutter project within it
    this_dir = os.path.abspath(os.path.dirname(__file__))
    base_dir = os.path.join(this_dir, os.pardir, os.pardir)
    test_dir = tempfile.mkdtemp()
    new_repo_dir = os.path.join(test_dir, 'example_cookiecutter_repo')
    base_repo_dir = os.path.join(base_dir, 'tests', 'test-generate-repo')

    shutil.copytree(base_repo_dir, new_repo_dir)

    project_template = find_template(new_repo_dir)

# Generated at 2022-06-23 16:21:50.761911
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'fake-repo'))
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-23 16:22:02.070481
# Unit test for function find_template
def test_find_template():
    import json
    import tempfile
    from cookiecutter.main import cookiecutter

    with tempfile.TemporaryDirectory() as temp_dir:
        context = {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@gmail.com',
            'github_username': 'audreyr'
        }
        # Use the automatic context to get the name of the directory
        cookiecutter('.', no_input=True, output_dir=temp_dir, extra_context=context)
        project_template = find_template(temp_dir)

        # Assert that there is a project template and that it was round-tripped
        assert project_template
        with open(os.path.join(project_template, 'cookiecutter.json')) as f:
            assert json.load(f) == context

# Generated at 2022-06-23 16:22:06.529965
# Unit test for function find_template
def test_find_template():
    project_template = find_template('tests/fake-repo-pre/')
    assert os.path.exists(project_template)
    assert os.path.exists(os.path.join(project_template, 'README.rst'))

# Generated at 2022-06-23 16:22:09.832217
# Unit test for function find_template
def test_find_template():
    """ Test that find_template() searches for non-templated input directories """
    assert find_template(repo_dir) == repo_dir_contents


# Generated at 2022-06-23 16:22:19.333658
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""

    #TODO: Add test for non-templated input_dir
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), '..', 'tests', 'fake-repo'
        )
    )

    project_template = find_template(repo_dir)

    assert os.path.exists(project_template)
    assert 'fake-repo' in project_template

# Generated at 2022-06-23 16:22:23.550158
# Unit test for function find_template
def test_find_template():
    input_dir = os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    expected = os.path.join('tests', 'fake-repo-pre', '')
    actual = find_template(input_dir)
    assert actual == expected
