

# Generated at 2022-06-23 16:12:23.657160
# Unit test for function find_template
def test_find_template():
    """Verify find_template works as expected."""
    test_dir = os.path.join('tests', 'test-find-template')
    test_dir = os.path.abspath(test_dir)

    project_template = find_template(test_dir)
    assert project_template == os.path.join(test_dir, 'cookiecutter-pypackage'), \
        'find_template did not return the right project_template.'

# Generated at 2022-06-23 16:12:27.123426
# Unit test for function find_template
def test_find_template():
    find_template('.')
    find_template('~/boop')
    find_template('../boop')
    find_template('~/boop')

# Generated at 2022-06-23 16:12:28.786396
# Unit test for function find_template
def test_find_template():
    find_template('/home/hp/Projects/Cookiecutter/build/cookiecutter-buildout')



# Generated at 2022-06-23 16:12:37.851213
# Unit test for function find_template
def test_find_template():
    import shutil

    # Create a temporary testing directory
    repo_dir = os.path.abspath(os.path.join('tests', 'files', 'test-repo'))

    # Make sure the template is where it should be
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Move the template so we can make sure find_template can't find it
    shutil.move('tests/files/test-repo/{{cookiecutter.repo_name}}', 'tests/files/test-repo/foo')

    # Make sure find_template can't find the template
    import pytest
    with pytest.raises(NonTemplatedInputDirException):
        find_template(repo_dir)

    # Move

# Generated at 2022-06-23 16:12:47.110284
# Unit test for function find_template
def test_find_template():
    """Test for finding the template in the repo

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.

    """

    #logger.debug('Searching %s for the project template.', repo_dir)

    #repo_dir_contents = os.listdir(repo_dir)

    repo_dir = r"C:\Users\Lenovo\Desktop\my_cookie"

    project_template = None
    project_template = os.listdir(repo_dir)

    print(project_template)

    """
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break
    """


# Generated at 2022-06-23 16:12:49.660043
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    utils.path_exists = lambda *a, **k: True
    find_template('foo')

# Generated at 2022-06-23 16:12:58.176021
# Unit test for function find_template
def test_find_template():
    """Verify the correct project template is identified."""
    import tempfile
    import shutil

    template_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(template_dir, 'some_template'))
    os.mkdir(os.path.join(template_dir, 'some_other_template'))
    os.mkdir(os.path.join(template_dir, 'some_other_template_with_templating'))

    assert find_template(template_dir) == os.path.join(
        template_dir,
        'some_other_template_with_templating'
    )

    shutil.rmtree(template_dir)

# Generated at 2022-06-23 16:13:03.208185
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the proper template path."""
    def get_input_dir_contents(path):
        if path:
            return os.listdir(path)
        else:
            return []
    project_template = 'cookiecutter-pypackage'
    assert find_template() == os.path.join('.', project_template)
    assert find_template('.') == os.path.join('.', project_template)

# Generated at 2022-06-23 16:13:08.485225
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fake-repo')
    test_project_template = find_template(test_repo_dir)
    print(test_project_template)
test_find_template()

# Generated at 2022-06-23 16:13:13.516241
# Unit test for function find_template
def test_find_template():
    """Check that function finds a template in a repo."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == template_dir

# Generated at 2022-06-23 16:13:19.666951
# Unit test for function find_template
def test_find_template():
    """Function to test find_template.
    """
    try:
        os.mkdir('template')
        find_template('template')
    except Exception as e:
        exc_name = e.__class__.__name__
        assert exc_name == "NonTemplatedInputDirException"
    else:
        assert False
    finally:
        os.rmdir('template')
        print('test_find_template finished')


# Generated at 2022-06-23 16:13:30.916576
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the project template."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'fake-repo-tmpl'
        )
    )
    verified_project_template = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'fake-repo-tmpl',
            'cookiecutter-pypackage'
        )
    )
    project_template = find_template(repo_dir)
    assert project_template == verified_project_template

# Generated at 2022-06-23 16:13:34.836087
# Unit test for function find_template
def test_find_template():
    template_dir = find_template('/home/vagrant/cookiecutter-pypackage/')
    assert template_dir == '/home/vagrant/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:41.745083
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo-pre-gen-project/'
    )
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:13:45.465287
# Unit test for function find_template
def test_find_template():
    repo_dir = "/home/joe/cookiecutter/django-package"
    project_template = find_template(repo_dir)
    assert project_template == "/home/joe/cookiecutter/django-package/{{cookiecutter.repo_name}}"

# Generated at 2022-06-23 16:13:49.759273
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/code/cookiecutter-pypackage'
    template_path = find_template(repo_dir)
    assert template_path == '/home/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:13:56.097085
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils

    here = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(here, 'fake-repo-pre/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

    repo_dir = os.path.join(here, 'fake-repo-post/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:13:59.434622
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    test_directory = tempfile.mkdtemp()
    test_subdirectory = os.path.join(test_directory, 'cookiecutter-{{ cookiecutter.project_name }}')
    os.makedirs(test_subdirectory)
    template_path = find_template(test_directory)
    assert template_path == test_subdirectory

# Generated at 2022-06-23 16:14:05.571441
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-repo-{{cookiecutter.repo_name}}', 'fake-repo')

# Generated at 2022-06-23 16:14:10.558266
# Unit test for function find_template
def test_find_template():
    """Test if find_template() can find a directory for a project to create.

    Test for both a directory that does exist and one that does not exist.
    """
    # Test for a directory that does exist
    template_dir = find_template(repo_dir = '.')
    assert template_dir == './tests/fake-repo-pre/{{cookiecutter.repo_name}}', \
        "Should be a directory called "

# Generated at 2022-06-23 16:14:14.494303
# Unit test for function find_template
def test_find_template():
    # Sample output of os.listdir(repo_dir)
    repo_dir_contents = ['bak.py', 'cookiecutter', 'test']
    repo_dir = 'some/path'

    assert repo_dir == find_template(repo_dir, repo_dir_contents)

# Generated at 2022-06-23 16:14:14.975578
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:22.319790
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function returns the correct template path."""
    test_repo_dir = os.path.join(os.path.dirname(__file__), 'test-assets', 'unittest-cookiecutter-repo')
    project_template = find_template(test_repo_dir)
    assert project_template == os.path.abspath('test-assets/unittest-cookiecutter-repo/unittest-cookiecutter-repo/')

# Generated at 2022-06-23 16:14:24.875196
# Unit test for function find_template
def test_find_template():
    """Test find_template() from cookiecutter.find."""
    pass

# Generated at 2022-06-23 16:14:32.490569
# Unit test for function find_template
def test_find_template():
    """Verifies find_template() returns the correct child directory."""
    import shutil
    from cookiecutter import utils
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        # Make a fake repo
        fake_repo = os.path.join(temp_dir, 'fake-repo')
        os.makedirs(fake_repo)
        utils.workaround_directory_path_limits(fake_repo)
    
        # Make a fake template
        fake_template = os.path.join(fake_repo, 'doesnt-matter-{{cookiecutter.test}}')
        os.makedirs(fake_template)
        utils.workaround_directory_path_limits(fake_template)

        assert find_template(fake_repo) == fake_

# Generated at 2022-06-23 16:14:36.465292
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    assert find_template(os.path.join(
        os.getcwd(), 'tests/fake-repo-pre/')
    ) == os.path.join(os.getcwd(), 'tests/fake-repo-pre/{{cookiecutter.repo_name}}/')

# Generated at 2022-06-23 16:14:46.898190
# Unit test for function find_template
def test_find_template():
    """
    Basic unit test for the find_template function.
    """
    from pprint import pprint, pformat
    from nose.tools import assert_raises

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    pprint('Searching %s for the project template.' % repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test an intentionally broken repo
    from cookiecutter.exceptions import NonTemplatedInputDirException

# Generated at 2022-06-23 16:14:54.138942
# Unit test for function find_template
def test_find_template():
    """Verify the expected behavior of the find_template() function."""
    from cookiecutter.main import cookiecutter
    from nose.tools import assert_equal

    cookiecutter('tests/fake-repo-pre/',
                 no_input=True,
                 checkout='master',
                 directory='fake-repo-pre',
                 overwrite_if_exists=True)
    # This should raise an exception
    try:
        cookiecutter('tests/fake-repo-pre/',
                     no_input=True,
                     checkout='bugfix',
                     directory='fake-repo-pre',
                     overwrite_if_exists=True)
    except NonTemplatedInputDirException:
        pass
    else:
        raise ValueError('Expected exception')

    # This should not raise an exception

# Generated at 2022-06-23 16:14:55.242557
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:15:04.557766
# Unit test for function find_template
def test_find_template():
    import os
    import shutil

    from cookiecutter.exceptions import NonTemplatedInputDirException

    from .contexts import temp_repo

    with temp_repo('tests/test-find-template') as repo_dir:
        assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
        assert os.path.isdir(find_template(repo_dir))

    with temp_repo('tests/test-find-template') as repo_dir:
        expected_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:15:09.550131
# Unit test for function find_template
def test_find_template():
    """ Test file used to check if find_template works properly. """
    template_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    templated_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    assert find_template(template_dir) == os.path.join(template_dir, '{{ cookiecutter.repo_name }}')
    assert find_template(templated_dir) == os.path.join(templated_dir, 'fake-repo')

# Generated at 2022-06-23 16:15:10.010422
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-23 16:15:15.283484
# Unit test for function find_template
def test_find_template():
    from cookiecutter import config
    from cookiecutter import utils
    from cookiecutter.tests.test_utils import DIR_FIXTURES

    fixtures_dir = DIR_FIXTURES
    templates_dir = os.path.join(fixtures_dir, 'templates')
    template_path = os.path.join(templates_dir, 'example-repo')

    cloned_template_path = utils.make_sure_path_exists(
        config.DEFAULT_REPO_DIR + '/example-repo'
    )
    utils.rmtree(cloned_template_path)
    utils.copytree(template_path, cloned_template_path)

    template = find_template(cloned_template_path)
    assert 'example-repo' in template

# Generated at 2022-06-23 16:15:25.633108
# Unit test for function find_template
def test_find_template():
    #
    # Setup
    #
    import tempfile
    import shutil
    import os.path
    import random

    cur_dir = os.path.dirname(__file__)
    repo_dir = os.path.join(cur_dir, '..', 'tests', 'fake-repo-tmpl')
    tmp_dir = tempfile.mkdtemp()
    shutil.copytree(repo_dir, tmp_dir, symlinks=False)

    # Randomly insert some dummy files and directories
    for base in range(10):
        open(os.path.join(tmp_dir, 'foo-%s' % random.random()), 'a').close()
        os.makedirs(os.path.join(tmp_dir, 'bar-%s' % random.random()))

    #
    #

# Generated at 2022-06-23 16:15:33.585822
# Unit test for function find_template
def test_find_template():
    """Make sure it can find the template."""
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                            '..', 'tests', 'fake-repo'))
    template_dir = os.path.join(base_dir, '{{cookiecutter.repo_name}}')
    template_dir = find_template(base_dir)
    assert template_dir == template_dir

# Generated at 2022-06-23 16:15:35.817465
# Unit test for function find_template
def test_find_template():
    find_template('/Users/tonypratt/GitHub/cookiecutter-pypackage/tests')


# Generated at 2022-06-23 16:15:41.028363
# Unit test for function find_template
def test_find_template():
    """Verify proper template is found when present."""
    from cookiecutter import utils
    import os

    temp_dir = utils.workaround_make_readonly(os.path.abspath('tests/fake-repo-pre'))

    project_template = find_template(temp_dir)
    expected = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected

# Generated at 2022-06-23 16:15:42.922257
# Unit test for function find_template
def test_find_template():
    find_template('/path/to/input/dir')
    raise NonTemplatedInputDirException

# Generated at 2022-06-23 16:15:46.558796
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:48.382145
# Unit test for function find_template
def test_find_template():
    find_template('../tests/fake-repo-tmpl')

# Generated at 2022-06-23 16:15:55.669309
# Unit test for function find_template
def test_find_template():
    import pytest

    @pytest.fixture 
    def repo_dir(tmpdir):
        repo_dir = tmpdir.mkdir("cookiecutter-foo")
        repo_dir.join("cookiecutter-foo.txt")
        repo_dir.join("cookiecutter-bar.py")
        repo_dir.join("cookiecutter-baz.txt")
        repo_dir.join("{{cookiecutter.project_name}}.py")
        repo_dir.join("someproject-{{cookiecutter.repo_name}}.py")

# Generated at 2022-06-23 16:16:00.424931
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'tests')
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected

# Generated at 2022-06-23 16:16:06.064076
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct relative path to a
    project template.
    """
    input_dir = os.path.join('tests', 'fake-repo-pre-gen')
    correct_template = os.path.join('tests', 'fake-repo-pre-gen',
                                    '{{cookiecutter.repo_name}}')
    assert find_template(input_dir) == correct_template



# Generated at 2022-06-23 16:16:06.655553
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:15.987071
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.tests.test_replay import make_replay_dir

    os.chdir(make_replay_dir())

    try:
        # No project template
        project_template = utils.find_template(os.getcwd())
        assert False
    except NonTemplatedInputDirException:
        assert True

    # Now create the project template
    os.mkdir(os.path.join(os.getcwd(), 'cookiecutter-pypackage-template'))

    project_template = utils.find_template(os.getcwd())
    print(project_template)

# Generated at 2022-06-23 16:16:24.710901
# Unit test for function find_template
def test_find_template():
    """
    Create a test directory for testing.
    """
    repo_dir = '/home/user/projects/cookiecutter_example'

    # Create files for testing.
    for item in ['cookiecutter-example', 'cookiecutter.example', '.hidden']:
        item = os.path.join(repo_dir, item)
        open(item, 'a').close()

    # Test
    assert find_template(repo_dir) == '/home/user/projects/cookiecutter_example/cookiecutter-example'



# Generated at 2022-06-23 16:16:26.976331
# Unit test for function find_template
def test_find_template():
    """Test whether find_template function works."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo')
    project_template = find_template(repo_dir)
    assert 'fake-repo' in project_template

# Generated at 2022-06-23 16:16:33.209553
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    with temporary_directory() as tmpdir:
        repo_dir = tmpdir.name
        repo_dir_contents = os.listdir(repo_dir)
        assert not repo_dir_contents
        assert find_template(repo_dir) == None

        # Create a templated directory
        templated_dirname = '{{cookiecutter.hello}}'
        templated_path = os.path.join(repo_dir, templated_dirname)
        os.mkdir(templated_path)
        assert find_template(repo_dir) == templated_path

        # Create a non-templated directory
        nontemplated_dirname = 'nontemplated'

# Generated at 2022-06-23 16:16:35.340899
# Unit test for function find_template
def test_find_template():
    print(find_template('/home/akshay/Desktop/cookiecutter/cookiecutter'))
test_find_template()

# Generated at 2022-06-23 16:16:39.099558
# Unit test for function find_template
def test_find_template():
    """Unit test for the find_template method.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    find_template(repo_dir)

# Generated at 2022-06-23 16:16:47.978594
# Unit test for function find_template
def test_find_template():
    import mock
    import tempfile

    repo_dir = tempfile.mkdtemp(prefix='cookiecutter-')
    os.mkdir(os.path.join(repo_dir, 'monkey'))
    os.mkdir(os.path.join(repo_dir, 'banana'))
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'apple'))

    with mock.patch('cookiecutter.find.logging') as mock_logging:
        template_dir = find_template(repo_dir)

    mock_logging.info.assert_called_once_with('Searching %s for the project template.',
                                              repo_dir)


# Generated at 2022-06-23 16:16:55.420950
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    import shutil
    import tempfile

    # Create a temporary directory and add a templated subdirectory
    temp_dir = tempfile.mkdtemp()
    template_dir = os.path.join(temp_dir, 'my-{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)

    try:
        template = find_template(temp_dir)
        assert template == template_dir
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-23 16:16:58.089101
# Unit test for function find_template
def test_find_template():
    """ Test Case: Find the correct template"""
    repo_dir = 'repo_dir/'
    assert find_template('repo_dir') == 'repo_dir/{{ cookiecutter.repo_name }}'


# Generated at 2022-06-23 16:17:01.151773
# Unit test for function find_template
def test_find_template():
    assert find_template('./tests/fake-repo-tmpl') == './tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:03.212342
# Unit test for function find_template
def test_find_template():
    assert find_template('test/test_repo/') == 'test/test_repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:09.324711
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    # Simple test
    assert 'simple' in find_template(
        os.path.join(os.path.dirname(__file__), 'test_repo')
    )

    # Complex test
    assert 'complex' in find_template(
        os.path.join(os.path.dirname(__file__), 'test_repo_complex')
    )

    # Test for exception
    try:
        find_template(
            os.path.join(
                os.path.dirname(__file__),
                'fake_repo_with_no_cookiecutter_templates'
            )
        )
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-23 16:17:10.902492
# Unit test for function find_template
def test_find_template():
    find_template('tests/input/non-templated-input-dir-git')

# Generated at 2022-06-23 16:17:21.048901
# Unit test for function find_template
def test_find_template():
    """Test to check if find_template works as expected.
    """
    from cookiecutter import utils
    from tests.test_utils.compat import patch
    from tests.test_utils.temp_dir import TemporaryDirectory

    with patch('cookiecutter.utils.find_template') as mock_find_template:
        mock_find_template.return_value = 'test'
        with TemporaryDirectory() as repo_dir:
            repo_dir.write('cookiecutter.json', b'{"test": "test"}')
            template = utils.find_template(repo_dir.path)
            assert template == os.path.join(repo_dir.path, 'cookiecutter.json')

# Generated at 2022-06-23 16:17:29.597498
# Unit test for function find_template
def test_find_template():
    """Verify the behavior of find_template()."""

    # Write out a simple directory structure to disk
    tmp_dir = tempfile.mkdtemp(prefix='tmp-cookiecutter-')

# Generated at 2022-06-23 16:17:36.775416
# Unit test for function find_template
def test_find_template():
    """
    Test function.
    """
    from cookiecutter.main import cookiecutter
    from mock import patch

    with patch('cookiecutter.repository.clone') as mock_clone:
        repo_dir_1 = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    assert find_template(repo_dir_1) == os.path.join(
        repo_dir_1, '{{cookiecutter.repo_name}}'
    )

    with patch('cookiecutter.repository.clone') as mock_clone:
        repo_dir_2 = cookiecutter('tests/fake-repo-pre/', no_input=True)

# Generated at 2022-06-23 16:17:41.284211
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/'

# Generated at 2022-06-23 16:17:42.642210
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-23 16:17:43.724694
# Unit test for function find_template
def test_find_template():
    find_template('hello')

# Generated at 2022-06-23 16:17:48.424709
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    expected_result = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    result = find_template(repo_dir)

    assert result == expected_result


# Generated at 2022-06-23 16:17:55.821807
# Unit test for function find_template
def test_find_template():
    """
    Using the 'pytest' framework.

    1) Setup a test repo directory, with a subdirectory named with
       a template expression, that also contains a 'cookiecutter.json' file.
    2) Run find_template function.
    3) Assert that the function returns the correct path.

    This test is not expected to pass unless the function is
    explicitly run with the --debug flag.

    Example:
        $ cookiecutter gh:audreyr/cookiecutter-pypackage --debug --no-input
    """

    from cookiecutter.main import cookiecutter

    # Make a fresh directory
    project_slug = 'project'
    os.makedirs(project_slug)

    # Make a project template
    pkg_template_name = '{{ cookiecutter.pkg_name }}'
    p

# Generated at 2022-06-23 16:17:59.250019
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-input/fake-repo-tmpl/') == 'tests/test-input/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:04.728896
# Unit test for function find_template
def test_find_template():
    import tempfile

    tmpdir = tempfile.mkdtemp()
    project_template = 'my-sweet-project-template'
    os.mkdir(os.path.join(tmpdir, project_template))

    assert find_template(tmpdir) == os.path.join(tmpdir, project_template)

    os.rmdir(os.path.join(tmpdir, project_template))
    os.rmdir(tmpdir)

# Generated at 2022-06-23 16:18:09.705213
# Unit test for function find_template
def test_find_template():
    #TODO: Refactor this to not use a relative path
    assert find_template(os.path.join('tests', 'test-output', 'fake-repo')) == os.path.join('tests', 'test-output', 'fake-repo', 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:18:18.658601
# Unit test for function find_template
def test_find_template():
    """Test find_template by mocking files and directories."""
    import mock

    class mymock(object):
        '''
        necessary until mock.patch.multiple is available in python 2.7
        see https://github.com/testing-cabal/mock/issues/36 and
        https://github.com/testing-cabal/mock/pull/44
        '''
        def __init__(self, path):
            self.path = path

        def __call__(self, obj):
            class mypatch(mock.MagicMock):
                pass
            setattr(mypatch, 'start', mock.MagicMock(return_value = self.path))
            return mypatch(obj)


# Generated at 2022-06-23 16:18:27.959767
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import os
    import shutil
    from tempfile import mkdtemp
    from cookiecutter.utils import rmtree

    tmpdir = mkdtemp()

    try:
        os.makedirs(os.path.join(tmpdir, 'cookiecutter-foobar'))
        expected_dir = os.path.join(tmpdir, 'cookiecutter-foobar')

        template_dir = find_template(tmpdir)
        assert template_dir == expected_dir
    finally:
        rmtree(tmpdir)

# Generated at 2022-06-23 16:18:31.844792
# Unit test for function find_template
def test_find_template(): # pragma: no cover
    repo_dir = '/Users/audreyr/code/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:33.136525
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-23 16:18:40.772532
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find the project template in a repo clone."""
    from cookiecutter import utils

    test_input_path = 'tests/test-repo-pre/'

    try:
        template_dir = utils.find_template(test_input_path)
    except NonTemplatedInputDirException:
        assert False, 'Cookiecutter could not find the project template.'
    template_dir = os.path.relpath(template_dir)
    assert template_dir == 'tests/test-repo-pre/{{cookiecutter.repo_name}}', template_dir


# Generated at 2022-06-23 16:18:41.625573
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:18:51.830464
# Unit test for function find_template
def test_find_template():
    """Run unit tests for function find_template"""
    import shutil
    from tempfile import mkdtemp
    from cookiecutter import repository, utils

    # Create a temporary directory that we can use to test the find_template
    # function.
    # tmp_dir = mkdtemp()
    tmp_dir = "/home/kostmo/.cookiecutters/django-crud"

    # Make a fake project template directory within this temporary directory
    template_dir = os.path.join(tmp_dir, 'fake-template-dir')
    os.mkdir(template_dir)

    # Create a dummy README.rst so that we can test that we are finding inner
    # directories
    dummy_readme = os.path.join(template_dir, 'README.rst')

# Generated at 2022-06-23 16:18:58.928097
# Unit test for function find_template
def test_find_template():
    '''
    Discover the directory in the cloned template repo that contains the
    template files.
    '''
    repo_dir = os.path.abspath(os.path.join(__file__, '../..', '..', 'tests', 'fake-repo'))
    project_template = find_template(repo_dir)

    expected_project_template = os.path.abspath(os.path.join(__file__, '../..', '..', 'tests', 'fake-repo', 'cookiecutter-pypackage'))
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:19:02.509531
# Unit test for function find_template
def test_find_template():
    os.makedirs('tests/fake-repo/.cookiecutter/fake-project-template')

# Generated at 2022-06-23 16:19:12.295350
# Unit test for function find_template
def test_find_template():
    repo_dir_list = (
        ('tests/test-repo-pre/', 'tests/test-repo-pre/{{cookiecutter.repo_name}}'),
        ('tests/test-repo-post/', 'tests/test-repo-post/{{cookiecutter.repo_name}}'),
    )
    for repo_dir, expected_template in repo_dir_list:
        found_template = find_template(repo_dir)
        if found_template != expected_template:
            raise AssertionError('find_template:  Repo "%s" does not match expected template "%s"' % (repo_dir, expected_template))

test_find_template()

# Generated at 2022-06-23 16:19:21.454278
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter

    _, dest_dir = tempfile.mkstemp()
    # Make fake repo with expected template file
    template_dir = os.path.join(dest_dir, 'fake-repo', '{{cookiecutter.repo_name}}')
    real_repo_dir = os.path.join(template_dir, 'tests/fake-repo-tmpl')
    repo_dir = cookiecutter(real_repo_dir, no_input=True)
    found_template = find_template(repo_dir)
    shutil.rmtree(repo_dir)
    os.remove(dest_dir)
    assert found_template == repo_dir

# Generated at 2022-06-23 16:19:31.181294
# Unit test for function find_template
def test_find_template():
    """Test for finding template in repo dir."""
    import tempfile
    from cookiecutter import repo

    temp_dir = tempfile.mkdtemp()
    repo_dir = repo.clone(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        no_input=True,
        checkout='0.3.0'
    )
    os.rename(repo_dir, temp_dir)
    project_template = find_template(temp_dir)
    assert 'cookiecutter-pypackage' in project_template

# Generated at 2022-06-23 16:19:41.086612
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    from cookiecutter.main import cookiecutter

    temp_dir = 'tests/files/fake-repo-pre/'
    repo_dir = 'fake-repo-pre'

    # Make a fake git repo, and cd into it.
    os.chdir(temp_dir)
    temp_dir = os.getcwd()
    temp_repo_dir = os.path.join(temp_dir, repo_dir)

    # Run the tests
    template = find_template(temp_repo_dir)
    shutil.rmtree(os.path.join(temp_dir, repo_dir))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:19:46.221791
# Unit test for function find_template
def test_find_template():
    """Test for when find_template returns a directory with 'cookiecutter' and
    a mustache in its name.
    """
    path = os.path.dirname(os.path.abspath(__file__)) + "/tests/fake-repo-pre"
    project_template = find_template(path)
    assert "cookiecutter-pypackage" in project_template, \
        "The project template should be cookiecutter-pypackage"
    assert "{{" in project_template and "}}" in project_template, \
        "The project template should contain {{...}}"


# Generated at 2022-06-23 16:19:56.976160
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    from cookiecutter import utils

    repo_dir = 'tests/test-find-template/cookiecutter-pypackage'
    repo_dir_explicit = 'tests/test-find-template/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    shutil.rmtree(repo_dir, ignore_errors=True)

    utils.make_sure_path_exists(repo_dir_explicit)
    os.makedirs(os.path.join(repo_dir_explicit, 'another_dir'))

    assert find_template(repo_dir) == repo_dir_explicit
    assert find_template(repo_dir_explicit) == repo_dir_explicit

    #

# Generated at 2022-06-23 16:19:59.997395
# Unit test for function find_template
def test_find_template():
    """Test if find_template() finds the template folder in a git clone."""
    from cookiecutter.main import cookiecutter

    project_path = cookiecutter('tests/fake-repo-tmpl/')
    assert project_path == project_path

# Generated at 2022-06-23 16:20:02.263196
# Unit test for function find_template
def test_find_template():
    # TODO
    pass

# Generated at 2022-06-23 16:20:06.174372
# Unit test for function find_template
def test_find_template():
    """Find the path to the project template."""
    find_template(os.path.join(
        os.path.dirname(__file__),
        os.pardir,
        'tests',
        'fake-repo-tmpl'
    ))



# Generated at 2022-06-23 16:20:07.440561
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == './cookiecutter-pypackage'

# Generated at 2022-06-23 16:20:07.977508
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:20:14.576563
# Unit test for function find_template
def test_find_template():
    # Create test inputs
    # TODO: make a fake directory, instead of using a real one...
    repo_dir = '/Users/audreyr/Code/jhermann/cookiecutter-pypackage/tests/fake-repo-tmpl'
    expected_templated_path = '/Users/audreyr/Code/jhermann/cookiecutter-pypackage/tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    # Run the test
    templated_path = find_template(repo_dir)
    # print(templated_path)
    assert templated_path == expected_templated_path

# Generated at 2022-06-23 16:20:18.499922
# Unit test for function find_template
def test_find_template():
    """Function testing find_template with a hardcoded directory"""
    repo_dir = "tests/test-repo/fake-repo"
    project_template = find_template(repo_dir)
    assert  project_template == "tests/test-repo/fake-repo/cookiecutter-pypackage"


# Generated at 2022-06-23 16:20:22.456448
# Unit test for function find_template
def test_find_template():
    _dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    repo_dir = os.path.join(_dir, 'tests' , 'fakerepo')
    result = find_template(repo_dir)
    if 'pytest' in result:
        assert True
    else:
        assert False

# Generated at 2022-06-23 16:20:28.816941
# Unit test for function find_template
def test_find_template():
    _dirname = os.path.join(os.path.dirname(__file__), 'test-data', '{{cookiecutter.repo_name}}')
    _template = find_template(_dirname)
    assert os.path.basename(_template) == "{{cookiecutter.repo_name}}"

# Generated at 2022-06-23 16:20:35.106872
# Unit test for function find_template
def test_find_template():
    """Verify find_template."""

    # Check with a valid template dir
    assert find_template('./tests/test-drives/cookiecutter-jquery') == './tests/test-drives/cookiecutter-jquery/{{cookiecutter.repo_name}}'

    # Check with a no template dir
    try:
        result = find_template('./tests/fake-repo-tmpl')
    except NonTemplatedInputDirException as e:
        result = e
    assert repr(result) == "NonTemplatedInputDirException('No template found in fake-repo-tmpl',)"

# Generated at 2022-06-23 16:20:39.962132
# Unit test for function find_template
def test_find_template():
    repo_dir = '~/cookiecutters/my-repo'
    compare_dir = '~/cookiecutters/my-repo/{{ cookiecutter.project_name }}'
    assert find_template(repo_dir) == compare_dir

# Generated at 2022-06-23 16:20:48.579846
# Unit test for function find_template
def test_find_template():

    def test_find_template_success(repo_dir, template_dir):
        """
        :param repo_dir: Local directory of newly cloned repo.
        :param template_dir: Relative path to project template.
        """
        result = find_template(repo_dir)
        assert result == repo_dir + '/' + template_dir

    def test_find_template_failure(repo_dir):
        """
        :param repo_dir: Local directory of newly cloned repo.
        :raises NonTemplatedInputDirException:
        """
        find_template(repo_dir)

    repo_dir = 'tests/fake-repo-pre/'
    template_dir = 'fake-repo-pre'

    test_find_template_success(repo_dir, template_dir)

    #

# Generated at 2022-06-23 16:20:54.202558
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = 'tests/fake-repo-pre/'
    with pytest.raises(NonTemplatedInputDirException):
        result = find_template(repo_dir)
        assert result == 'tests/fake-repo-pre/{{cookiecutter.project_slug}}/'

# Generated at 2022-06-23 16:21:00.341406
# Unit test for function find_template
def test_find_template():
    """ Test the find_template function. """
    # Correct template found
    path = '/Users/xizhang/Documents/Projects/gattaca_cookiecutter/gattaca_cookiecutter'
    assert find_template(path) == os.path.join(path, '{{project_name}}')

    # Bad path
    path = '/Users/xizhang/Documents/Projects/gattaca'
    
    try:
        assert find_template(path)
    except Exception as e:
        assert type(e) == NonTemplatedInputDirException

# Generated at 2022-06-23 16:21:08.874635
# Unit test for function find_template
def test_find_template():
    """
    Test that find_template works as expected.
    """
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre'
    )
    expected_project_template = os.path.join(
        repo_dir,
        "{{cookiecutter.repo_name}}"
    )
    actual_project_template = find_template(repo_dir)
    assert actual_project_template == expected_project_template

# Generated at 2022-06-23 16:21:17.271797
# Unit test for function find_template
def test_find_template():
    import logging
    import shutil
    import tempfile
    import unittest

    logger = logging.getLogger()

    # Set logging level to DEBUG
    logger.setLevel(logging.DEBUG)

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 16:21:21.812267
# Unit test for function find_template
def test_find_template():
    # Set up
    logger = logging.getLogger(__name__)
    logger.debug('Starting unit test for function find_template()...')
    repo_dir = os.path.join(os.path.dirname(__file__), 'test_repo/')

    # Run function
    expected_result = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    actual_result = find_template(repo_dir)

    # Check for success
    assert expected_result == actual_result, \
        'find_template({}) returned {} instead of {}'.format(
            repo_dir,
            actual_result,
            expected_result
        )

# Generated at 2022-06-23 16:21:23.966644
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/username/cookiecutters') == '/home/username/cookiecutters/test/test{{test}}test'

# Generated at 2022-06-23 16:21:29.614226
# Unit test for function find_template
def test_find_template():
    """Unit tests for find_template."""
    assert find_template('tests/test-input/fake-repo-pre/') == 'tests/test-input/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-input/fake-repo-post/') == 'tests/test-input/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:34.453408
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'input', 'pyproject')
    logger.debug('Testing search for project template in %s', repo_dir)
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:40.130467
# Unit test for function find_template
def test_find_template():
    """Test for function find_template(repo_dir)"""

    testdir = os.path.dirname(os.path.abspath(__file__))
    testdirs = [
        os.path.join(testdir, "fake-repo"),
        os.path.join(testdir, "fake-repo-02"),
        os.path.join(testdir, "fake-repo-03"),
    ]

    for testdir in testdirs:
        assert os.path.basename(find_template(testdir)) == \
            os.path.basename(os.path.join(testdir, "fake-project"))


# Generated at 2022-06-23 16:21:44.474730
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.expanduser('~/cookiecutters/cookiecutter-pypackage')) == \
        os.path.expanduser('~/cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:48.318195
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    template = find_template(os.path.join('tests', 'test-find-template'))
    assert template == 'tests/test-find-template/{{cookiecutter.repo_name}}/'


# Generated at 2022-06-23 16:22:00.246505
# Unit test for function find_template
def test_find_template():
    """Make sure find_template returns the correct template directory."""

    # Create tests/input_dir with subdirs named cookiecutter*
    # and some dummy files
    import tempfile
    input_dir = tempfile.mkdtemp()
    input_dirs = [
        os.path.join(input_dir, 'cookiecutter-django'),
        os.path.join(input_dir, 'cookiecutter-pypackage')
    ]
    for input_dir in input_dirs:
        os.mkdir(input_dir)
        with open(os.path.join(input_dir, 'README.rst'), 'w') as f:
            f.write('')

    # Test a templated input dir

# Generated at 2022-06-23 16:22:04.411150
# Unit test for function find_template
def test_find_template():
    repo_dir = "d:\workspace\cookiecutterDemo\cookiecutter-pypackage"
    project_template_path = find_template(repo_dir)

# Generated at 2022-06-23 16:22:09.833884
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    result = cookiecutter('tests/fake-repo-tmpl/')
    utils.rmtree(result['cookiecutter']['project_slug'], ignore_errors=True)
    utils.rmtree('fake-repo-tmpl/', ignore_errors=True)

# Generated at 2022-06-23 16:22:15.420394
# Unit test for function find_template
def test_find_template():
    test_repo_dir = "tests/fake-repo/"
    assert find_template(test_repo_dir) == "tests/fake-repo/{{cookiecutter.repo_name}}"
    assert find_template(test_repo_dir) != "tests/fake-repo/{{cookiecutter.repo_name"
    assert find_template(test_repo_dir) != "tests/fake-repo/{{cookiecutter.repo_name}}}}"
    assert find_template(test_repo_dir) != "tests/fake-repo/"

# Generated at 2022-06-23 16:22:16.958258
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/shanglun/cookiecutter-django')