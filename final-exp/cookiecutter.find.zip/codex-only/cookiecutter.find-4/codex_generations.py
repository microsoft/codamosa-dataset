

# Generated at 2022-06-23 16:12:22.779971
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template


# Generated at 2022-06-23 16:12:31.276266
# Unit test for function find_template
def test_find_template():
    """Tries to find template in a known repo directory with hidden files."""

    import shutil
    import tempfile
    import git

    temp_dir = tempfile.mkdtemp()
    cookiecutter_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo', '{{cookiecutter.repo_name}}'
    )
    shutil.copytree(cookiecutter_dir, os.path.join(temp_dir, 'fake-repo'))

    git_repo = git.Repo(os.path.join(temp_dir, 'fake-repo'))
    git_repo.index.add([os.path.join(git_repo.working_dir, '.hidden')])

# Generated at 2022-06-23 16:12:39.875207
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected."""
    assert find_template(
        'tests/test-data/fake-repo-tmpl-cloned'
    ) == 'tests/test-data/fake-repo-tmpl-cloned/fake-project-{{cookiecutter.repo_name}}'
    try:
        find_template('tests/test-data/fake-repo-no-tmpl-cloned')
    except NonTemplatedInputDirException as e:
        assert str(e) == (
            "The repository you cloned at 'tests/test-data/fake-repo-no-tmpl-cloned' does not"
            " appear to contain a Cookiecutter template."
        )
        return True
    return False

# Generated at 2022-06-23 16:12:49.290682
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    import tempfile
    import shutil
    import os

    template_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(template_dir, 'fake-repo')
    os.makedirs(repo_dir)

    template_without_context = os.path.join(repo_dir, 'basic')
    os.makedirs(template_without_context)

    template_with_context = os.path.join(repo_dir, '{{cookiecutter.project_slug}}')
    os.makedirs(template_with_context)

    assert find_template(repo_dir) == template_with_context

    shutil.rmtree(template_dir)

# Generated at 2022-06-23 16:12:58.802433
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre-without-surrounding-spaces/') == 'tests/fake-repo-pre-without-surrounding-spaces/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre-with-spaces/') == 'tests/fake-repo-pre-with-spaces/{{ cookiecutter.repo_name }}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'

# End unit test for

# Generated at 2022-06-23 16:13:06.866722
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    import tempfile
    import shutil
    from cookiecutter.tests.test_find_template import (
        test_find_template_input_dirs
    )

    repo_dir = tempfile.mkdtemp()

    for test in test_find_template_input_dirs:
        for file_name in test['files']:
            with open(os.path.join(repo_dir, file_name), 'w') as fh:
                fh.write('foo')

        if 'exception' in test:
            success = False
            try:
                find_template(repo_dir)
            except test['exception']:
                success = True
            assert success
        else:
            assert find_template(repo_dir) == test['expected']

        shutil

# Generated at 2022-06-23 16:13:16.502164
# Unit test for function find_template
def test_find_template():

    # Create fake directory structure
    import tempfile
    os.makedirs(os.path.join(tempfile.gettempdir(), 'fake_repo'))

    os.makedirs(os.path.join(tempfile.gettempdir(), 'fake_repo', 'cookiecutter-project'))
    os.makedirs(os.path.join(tempfile.gettempdir(), 'fake_repo', 'test_cookiecutter'))
    os.makedirs(os.path.join(tempfile.gettempdir(), 'fake_repo', 'cookiecutter-project', 'static'))
    os.makedirs(os.path.join(tempfile.gettempdir(), 'fake_repo', 'cookiecutter-project', 'templates'))

    # Create files to fill the fake dir

# Generated at 2022-06-23 16:13:20.454924
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/code/cookiecutter-pypackage/'
    project_template = '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:13:28.584004
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import tempfile
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()

    # Create a git clone of the repo https://github.com/audreyr/cookiecutter-pypackage.git
    utils.git_clone(
        repo_url='https://github.com/audreyr/cookiecutter-pypackage.git',
        repo_dir=repo_dir
    )

    project_template = find_template(repo_dir=repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Create a git clone of the repo https://github.com/

# Generated at 2022-06-23 16:13:35.989659
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the expected project template."""
    import tempfile

    template_dir = tempfile.mkdtemp()
    project_template = os.path.join(
        template_dir,
        'cookiecutter-{{cookiecutter.repo_name}}'
    )
    os.makedirs(project_template)

    try:
        assert find_template(template_dir) == project_template
    finally:
        os.rmdir(project_template)
        os.rmdir(template_dir)

# Generated at 2022-06-23 16:13:38.872458
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    repo_dir = 'foo/bar'
    assert find_template(repo_dir) == 'foo/bar/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:42.368242
# Unit test for function find_template
def test_find_template():
    os.chdir('tests/files/fake-repo')
    # Name of template directory
    template_dir = find_template('.')
    assert template_dir == 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:13:47.085460
# Unit test for function find_template
def test_find_template():
    input_directory = os.path.abspath(os.path.join(os.path.dirname(__file__), 'test_find_template'))

    expected_output = os.path.join(input_directory, 'cookiecutter-pypackage')

    assert find_template(input_directory) == expected_output

# Generated at 2022-06-23 16:13:51.413807
# Unit test for function find_template
def test_find_template():
    """Verify that a template is properly discovered."""
    template_file_path = find_template(
        'tests/test-data/test-template/test-template'
    )
    assert template_file_path == 'tests/test-data/test-template/test-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:57.120370
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.getcwd(), 'tests/test-data-repo/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:14:01.568794
# Unit test for function find_template
def test_find_template():
    test_path = 'C:\\Users\\Janae\\PycharmProjects\\cookiecutter-pypackage'
    assert find_template(test_path) == 'C:\\Users\\Janae\\PycharmProjects\\cookiecutter-pypackage\\cookiecutter-pypackage'



# Generated at 2022-06-23 16:14:10.177270
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    # setup
    test_repo_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test-repo-pre-rendered'
    )

    test_project_template = os.path.join(
        test_repo_path,
        'cookiecutter-{{cookiecutter.folder_name}}'
    )

    # run function under test
    result = find_template(test_repo_path)

    # test
    assert result == test_project_template

# Generated at 2022-06-23 16:14:16.306786
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()

    os.mkdir(os.path.join(tmpdir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(tmpdir, 'something_else'))

    project_template = find_template(tmpdir)
    assert project_template.endswith('{{cookiecutter.repo_name}}')

    shutil.rmtree(tmpdir)

# Generated at 2022-06-23 16:14:23.890501
# Unit test for function find_template
def test_find_template():
    """Test for find_template"""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        '..',
        'tests',
        'test-repo',
        '{{cookiecutter.repo_name}}',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:14:24.751767
# Unit test for function find_template
def test_find_template():
    # TODO: This test should use mock objects
    pass

# Generated at 2022-06-23 16:14:27.379408
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:14:28.982406
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""

    find_template('.')
    find_template('tests/cookiecutters/fake-repo-tmpl')

# Generated at 2022-06-23 16:14:38.459944
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    from .compat import PY3
    from .compat import TemporaryDirectory
    from .compat import mkdtemp
    from .main import cookiecutter

    if PY3:
        assert cookiecutter('tests/fake-repo-tmpl') == 'tests/fake-repo-pre/'
    else:
        with TemporaryDirectory() as tmpdir:
            logger.debug('Temporary directory %s', tmpdir)

            result = cookiecutter('tests/fake-repo-tmpl',
                                  no_input=True,
                                  output_dir=tmpdir)

            assert result == os.path.join(tmpdir, 'fake-repo-pre')
            logger.debug('Result is %s', result)


# Generated at 2022-06-23 16:14:45.237908
# Unit test for function find_template
def test_find_template():
    """Verify that the correct project_template is found."""
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )

    expected_project_template = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.project_name}}',
    ))
    assert find_template(repo_dir) == expected_project_template

# Generated at 2022-06-23 16:14:48.345813
# Unit test for function find_template
def test_find_template():
    in_repo_dir_contents=['My-Cool-Project-{{cookiecutter.repo_name}}', 'other_file']
    # import pdb; pdb.set_trace()

# Generated at 2022-06-23 16:14:58.934031
# Unit test for function find_template
def test_find_template():
    """Test find_template() output."""
    from cookiecutter.compat import unicode
    from cookiecutter.main import cookiecutter

    logging.disable(logging.ERROR)

    project_dir = cookiecutter(
        'tests/fake-repo-tmpl',
        no_input=True,
        output_dir='tests',
        overwrite_if_exists=True
    )

    assert os.path.isdir(os.path.join(project_dir, 'tests', 'fake-repo-tmpl'))

    found_template = find_template(project_dir)

    assert isinstance(found_template, unicode)
    assert 'fake-repo-tmpl' in found_template

# Generated at 2022-06-23 16:15:02.028769
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/cookiecutter-pypackage') == '/home/vagrant/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:09.000581
# Unit test for function find_template
def test_find_template():
    # Create test repo_dir with non-templated child dir
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException
    repo_dir = tempfile.mkdtemp()
    non_templated_child_dir = os.path.join(repo_dir, 'my-proj')
    os.makedirs(non_templated_child_dir)

    assert find_template(repo_dir) == non_templated_child_dir

    shutil.rmtree(repo_dir)



# Generated at 2022-06-23 16:15:16.105301
# Unit test for function find_template
def test_find_template():
    """Test finding a template using a variety of test directories.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """

    from cookiecutter import utils

    base_dir = os.path.dirname(utils.__file__)
    repo_dir = os.path.join(base_dir, 'tests', 'test-repo-pre/')
    test_template = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    
    assert find_template(repo_dir) == test_template
    
    repo_dir2 = os.path.join(base_dir, 'tests', 'test-repo-post-jinja2/')
    test_template2 = os.path

# Generated at 2022-06-23 16:15:25.659419
# Unit test for function find_template
def test_find_template():
    import tempfile

    repo_dir = tempfile.mkdtemp()

    # Create temp directory with templated file name.
    temp_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(temp_dir)

    # File that has no templating.
    not_a_template = os.path.join(repo_dir, 'nope')
    open(not_a_template, 'a').close()

    # File that *has* templating, but isn't a directory.
    also_not_a_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    open(also_not_a_template, 'a').close()

    # File that has templating, and is

# Generated at 2022-06-23 16:15:35.331246
# Unit test for function find_template
def test_find_template():
    """Test that find_template finds the project template"""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-tmpl/',
    )
    project_template = find_template(repo_dir)
    expected_template = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-tmpl',
        '{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_template

# Generated at 2022-06-23 16:15:45.304437
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function."""
    from .config import USER_CONFIG

    import_error = False
    try:
        from .repository import determine_repo_dir
    except ImportError:
        import_error = True

    if import_error:
        logger.warning(
            'Function find_template not tested because cannot import '
            'determine_repo_dir'
        )
    else:
        repo_dir = determine_repo_dir(USER_CONFIG.get('default_repo'))[0]
        try:
            project_template = find_template(repo_dir)
        except NonTemplatedInputDirException:
            logger.warning(
                'Function find_template not tested because cannot find project'
                ' template directory in %s', repo_dir
            )

# Generated at 2022-06-23 16:15:56.097603
# Unit test for function find_template
def test_find_template():
    from cookiecutter import repo
    from cookiecutter import utils

    test_values = [
        'tests/test-repos/cookiecutter-jquery',
        'tests/test-repos/cookiecutter-simple',
        'tests/test-repos/good-namespaced-repo-tmpl',
        'tests/fake-repo-pre/',
        'tests/fake-repo-post/',
    ]

    for test_value in test_values:
        repo_dir = repo.clone(test_value)
        assert os.path.isdir(repo_dir)
        project_template = find_template(repo_dir)
        assert os.path.isdir(project_template)
        utils.rmtree(repo_dir)

# Generated at 2022-06-23 16:15:59.683062
# Unit test for function find_template
def test_find_template():
    repo_dir = '~/myrepo/myrepo'
    project_template = '~/myrepo/myrepo/project_template'
    assert find_template(repo_dir) == project_template


# Generated at 2022-06-23 16:16:02.540290
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('/tests/test-input/') == '/tests/test-input/cookiecutter-{{ cookiecutter.repo_name }}'

# Generated at 2022-06-23 16:16:03.426900
# Unit test for function find_template
def test_find_template():
    """Find a template in a repository directory"""
    pass

# Generated at 2022-06-23 16:16:04.339055
# Unit test for function find_template
def test_find_template():
    find_template('/home')

# Generated at 2022-06-23 16:16:07.119252
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:16:10.687882
# Unit test for function find_template
def test_find_template():
    repo_dir = 'cookiecutter-pypackage/'
    assert find_template(repo_dir) == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}/'


# Generated at 2022-06-23 16:16:12.792412
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    expected = '{{cookiecutter.repo_name}}'
    assert find_template('.') == expected

# Generated at 2022-06-23 16:16:18.532044
# Unit test for function find_template
def test_find_template():
    # Test to see that we can find non-templated input dir.
    os.chdir('tests/test-data')
    repo_dir = os.path.abspath(os.curdir)
    repo_dir_contents = os.listdir(repo_dir)
    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break
    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template
    else:
        raise NonTemplatedInputDirException

# Generated at 2022-06-23 16:16:30.337581
# Unit test for function find_template
def test_find_template():
    """Return the project template directory."""
    this_dir = os.path.dirname(__file__)
    test_template_dir = os.path.abspath(
        os.path.join(
            this_dir,
            '..',
            'tests',
            'fake-repo-pre',
            '{{cookiecutter.repo_name}}'
        )
    )

    repo_dir = os.path.abspath(
        os.path.join(
            this_dir,
            '..',
            'tests',
            'fake-repo-pre',
        )
    )
    test_find_template_result = find_template(repo_dir)

    assert test_find_template_result == test_template_dir


# Generated at 2022-06-23 16:16:36.138541
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/test-find-template/input/{{cookiecutter.repo_name}}/'
    project_template = './tests/test-find-template/input/{{cookiecutter.repo_name}}/{{cookiecutter.project_name}}'
    assert project_template == find_template(repo_dir)

# Generated at 2022-06-23 16:16:44.221088
# Unit test for function find_template
def test_find_template():
    repo_dir_list = {
        'repo_dir_test1': 'test1',
        'repo_dir_test2': 'test2',
        'repo_dir_test3': 'test3',
    }
    assert find_template(repo_dir_list['repo_dir_test1']) == 'repo_dir_test1'
    assert find_template(repo_dir_list['repo_dir_test2']) == 'repo_dir_test2'
    assert find_template(repo_dir_list['repo_dir_test3']) == 'repo_dir_test3'

# Generated at 2022-06-23 16:16:48.513429
# Unit test for function find_template
def test_find_template():
    assert find_template("cookiecutter/tests/test-repo") == "cookiecutter/tests/test-repo/{{cookiecutter.repo_name}}"

# Generated at 2022-06-23 16:16:52.133200
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/src/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/src/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:52.907537
# Unit test for function find_template
def test_find_template():
    """Unit tests for find_template function."""
    pass

# Generated at 2022-06-23 16:16:54.108334
# Unit test for function find_template
def test_find_template():
    """
    Test that the find_template function works.
    """
    pass

# Generated at 2022-06-23 16:17:02.145749
# Unit test for function find_template
def test_find_template():
    # Test against a simple project template with "cookiecutter" in the name
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests',
                            'fake-repo-pre/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test against a project template with {{, }} and "cookiecutter" somewhere
    # else in the name
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests',
                            'fake-repo-pre-2/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join

# Generated at 2022-06-23 16:17:07.233412
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils

    tmp_dir = os.path.realpath(tempfile.mkdtemp())
    repo_dir = os.path.join(tmp_dir, 'repo')
    os.mkdir(repo_dir)

    # Create a fake project template directory
    templ_dir_name = '{{cookiecutter.repo_name}}'
    templ_dir = os.path.join(repo_dir, templ_dir_name)
    os.mkdir(templ_dir)
    assert find_template(repo_dir)


# Generated at 2022-06-23 16:17:15.383837
# Unit test for function find_template
def test_find_template():
    """Unit test for :func:`find_template`."""
    import tempfile
    from shutil import rmtree
    tmp_dir = tempfile.mkdtemp()

    fpath = os.path.join(tmp_dir, 'foo')
    os.mkdir(fpath)

    result = find_template(tmp_dir)
    assert result is None

    fpath = os.path.join(tmp_dir, 'cookiecutter-foo')
    os.mkdir(fpath)

    result = find_template(tmp_dir)
    assert result == fpath

    rmtree(tmp_dir)

# Generated at 2022-06-23 16:17:23.680679
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns correct result."""
    import tempfile
    import shutil
    import os

    template_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'fake-repo')
    )

    # Create a temp dir and clone into it
    temp_dir = tempfile.mkdtemp()
    shutil.copytree(template_dir, temp_dir)

    project_template = find_template(temp_dir)
    expected_template = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')

    assert project_template == expected_template

# Generated at 2022-06-23 16:17:33.212603
# Unit test for function find_template
def test_find_template():

    # Create a directory for testing
    import tempfile
    import shutil
    import random

    temp_dir = tempfile.mkdtemp()
    temp_sub_dir = os.path.join(temp_dir, 'sub-dir-{}'.format(random.random()))
    os.mkdir(temp_sub_dir)

    # Create a sub directory with the intention of being a template
    temp_sub_sub_dir = os.path.join(temp_sub_dir, 'sub-sub-dir-{}'.format(random.random()))
    os.mkdir(temp_sub_sub_dir)

    # Create a directory without intention of being a template

# Generated at 2022-06-23 16:17:36.608188
# Unit test for function find_template
def test_find_template():
    test_template_dir = 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre') == test_template_dir

# Generated at 2022-06-23 16:17:41.495313
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'fake-repo')
    )
    project_template = find_template(repo_dir)
    assert 'fake-repo' in project_template

# Generated at 2022-06-23 16:17:42.856953
# Unit test for function find_template
def test_find_template():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-23 16:17:52.481730
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the correct value"""
    from .compat import patch

    with patch('cookiecutter.vcs.git.os.listdir') as mock_listdir:
        mock_listdir.return_value = ['a', 'cookiecutter{{', 'cookiecutter{{cookiecutter.my_var}}', 'cookiecutter{}']
        repo_dir = '/home/vagrant/code/cookiecutter-pypackage'
        project_template = find_template(repo_dir)
        assert project_template == '/home/vagrant/code/cookiecutter-pypackage/cookiecutter{{cookiecutter.my_var}}'


# Generated at 2022-06-23 16:18:03.882246
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.utils import rmtree

    # Create directories
    cc_dir = 'tests/files/find-template'
    rmtree(cc_dir)
    os.makedirs(cc_dir)

    # Create files
    file_template = '{{cookiecutter.test}}'
    file_content = 'test'

    with open(os.path.join(cc_dir, file_template), 'w') as f:
        f.write(file_content)

    # Reload the module to update the sys.path
    # (We need to do this because the path to the package changes after being imported)
    import imp
    imp.reload(find)

    template = find.find_template(cc_dir)

# Generated at 2022-06-23 16:18:05.019774
# Unit test for function find_template
def test_find_template():
    """
    Function for finding template

    """
    pass

# Generated at 2022-06-23 16:18:11.247872
# Unit test for function find_template
def test_find_template():
    """Verify that find_template is able to find a template directory."""
    test_dir = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(test_dir, 'fake-repo', 'cookiecutter-{{cookiecutter.repo_name}}')
    assert find_template(os.path.dirname(template_dir)) == template_dir

# Generated at 2022-06-23 16:18:15.717472
# Unit test for function find_template
def test_find_template():
    """Ensure that the find_template function works correctly."""
    template_path = os.path.join(os.getcwd(), 'tests/test-find-template')
    assert find_template(template_path) == os.path.join(
        template_path, 'foo-{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:18:21.646616
# Unit test for function find_template
def test_find_template():
    """
    It should determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    repo_dir = "./test/test-repo"
    expected = ("./test/test-repo/cookiecutter-pypackage")
    result = find_template(repo_dir)
    assert result == expected, "Expected %s, but got %s" % (expected, result)
#
# import os
# import shutil
# import unittest
#
# from cookiecutter import find, utils
# from tests.test_utils import BinaryStdErr, CHDIR, TEST_DIR
#
#
# class FindTestCase(unittest.TestCase

# Generated at 2022-06-23 16:18:23.877636
# Unit test for function find_template
def test_find_template():
    """Print output of find_template() if this module is run directly"""
    if __name__ == '__main__':
        local_repo_dir = os.path.join(
            os.path.dirname(os.path.realpath(__file__)), 'tests/test-input'
        )

# Generated at 2022-06-23 16:18:34.005753
# Unit test for function find_template
def test_find_template():
    # TODO: Unit test for this function

    # Create a temporary dir
    from cookiecutter.utils import rmtree
    from cookiecutter import utils
    from cookiecutter import main

    temp_dir = utils.workin(
        utils.make_empty_dir('_test-cookiecutterproject'),
    )

    # Make sure there is an empty dircetory. There should be no cookiecutter
    # template in this directory.
    assert os.listdir(temp_dir) == []

    with pytest.raises(NonTemplatedInputDirException):
        find_template(temp_dir)

    # Generate a template
    main.cookiecutter('tests/test-cookiecutter-project/', no_input=True)

    # generate a template

# Generated at 2022-06-23 16:18:40.482281
# Unit test for function find_template
def test_find_template():
    from pytest import raises
    
    repo_dir = './tests/input/fake-repo'

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{ cookiecutter.repo_name }}')

    with raises(NonTemplatedInputDirException):
        repo_dir = './tests/input/fake-non-templated-repo'
        project_template = find_template(repo_dir)

# Generated at 2022-06-23 16:18:44.330886
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/cookiecutter-pypackage') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:49.845622
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/code/good'
    result = find_template(repo_dir)
    expected_result = '/Users/audreyr/code/good/{{cookiecutter.repo_name}}'
    assert result == expected_result

# Generated at 2022-06-23 16:18:59.086231
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    repo_dir_contents = [
        'foo-{{cookiecutter.repo_name}}',
        'foo-old_bakery_in_1991',
        'bar-{{cookiecutter.repo_name}}',
        'bar-{{cookiecutter.r_e_p_o_name}}',
        'baz-{{cookiecutter.repo_name}}'
    ]
    for item in repo_dir_contents:
        os.makedirs(os.path.join(repo_dir, item))


# Generated at 2022-06-23 16:19:07.930573
# Unit test for function find_template
def test_find_template():
    """Test the find_template function in the find module."""
    repo_dir = os.path.realpath(os.path.join(
        os.path.dirname(__file__),
        '..', 'tests', 'test-repo'
    ))
    assert find_template(repo_dir) == os.path.join(
        os.path.realpath(os.path.join(
            os.path.dirname(__file__),
            '..', 'tests', 'test-repo', 'my-fake-project'))
    )



# Generated at 2022-06-23 16:19:12.638933
# Unit test for function find_template
def test_find_template():
    """Test template found."""
    fin = open('tests/test-repo/cookiecutter.json', 'r')
    project_template = find_template('tests/test-repo/')

    assert fin.read() in open(project_template, 'r').read()


# Generated at 2022-06-23 16:19:22.312541
# Unit test for function find_template
def test_find_template():

    TEMPLATE_DIR_1 = (
        'tests/test-find-template/fake-repo-tmpl/fake-repo-{{cookiecutter.repo_name}}'
    )
    TEMPLATE_DIR_2 = (
        'tests/test-find-template/fake-repo-tmpl/'
        'fake-repo-{{cookiecutter.repo_name_with_underscores}}'
    )
    TEMPLATE_DIR_3 = (
        'tests/test-find-template/fake-repo-tmpl/foo/'
        'fake-repo-{{cookiecutter.repo_name_with_a_dash}}'
    )

# Generated at 2022-06-23 16:19:30.708208
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    os.chdir(os.path.dirname(os.path.dirname(__file__)))
    template_name = find_template(os.path.abspath('tests/fake-repo-pre/'))

    assert 'real-repo' in template_name.replace('\\', '/')
    assert 'fake-repo-pre/tests/' in template_name.replace('\\', '/')

# Generated at 2022-06-23 16:19:39.188951
# Unit test for function find_template
def test_find_template():
    """Verify that the function finds the project template."""
    base_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), os.pardir)
    )

    for subdir in ['tests/fake-repo-tmpl', 'tests/fake-repo-pre']:
        template_dir = os.path.join(base_dir, subdir)
        template = find_template(template_dir)

        test_template = os.path.join(template_dir, '{{cookiecutter.repo_name}}')
        assert template == test_template

# Generated at 2022-06-23 16:19:48.626235
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rm_empty_dir
    from shutil import rmtree
    from tempfile import mkdtemp
    from nose.tools import (
        assert_raises,
        assert_true,
    )
    from tests.test_utils import make_example_dir

    project_dir = mkdtemp()
    example_dir = make_example_dir(project_dir)

    found_template = find_template(project_dir)

    assert_true(os.path.exists(found_template))

    # Clean up
    rmtree(example_dir)
    rm_empty_dir(project_dir)

# Generated at 2022-06-23 16:19:54.964025
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the project_template directory."""
    from cookiecutter.repository import determine_repo_dir
    repo_dir = determine_repo_dir('tests/fake-repo-tmpl/')
    project_template = find_template(repo_dir)

    assert 'fake-repo-tmpl' in project_template
    assert '/tests/fake-repo-tmpl/fake-repo-{{cookiecutter.repo_name}}/' in project_template

# Generated at 2022-06-23 16:20:02.819790
# Unit test for function find_template
def test_find_template():
    """Test the find_template function"""
    work_path = os.path.abspath(os.path.join(os.getcwd(), 'tests', 'fake-repo-pre'))
    os.chdir(work_path)
    assert find_template('fake-repo-pre') == os.path.join(work_path, '{{cookiecutter.repo_name}}')
    work_path = os.path.abspath(os.path.join(os.getcwd(), 'tests', 'fake-repo-post'))
    os.chdir(work_path)
    assert find_template('fake-repo-post') == os.path.join(work_path, 'fake-repo-post')

# Generated at 2022-06-23 16:20:08.579622
# Unit test for function find_template
def test_find_template():
    import tempfile
    dirname = tempfile.mkdtemp()
    os.mkdir(os.path.join(dirname, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(dirname, 'some_repo_name'))

    output = find_template(dirname)
    assert output == os.path.join(dirname, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:20:11.437388
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-find-template')
    find_template(repo_dir)

# Generated at 2022-06-23 16:20:14.745217
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/code/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/home/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:15.928100
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-23 16:20:19.999044
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:20:20.678099
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:20:31.431919
# Unit test for function find_template
def test_find_template():
    """Assert that find_template works as expected."""
    import tempfile

    template_name = 'my_template'

    tmp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(tmp_dir, 'my_repo')
    os.mkdir(repo_dir)

    project_template = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    os.mkdir(project_template)

    assert find_template(repo_dir) == project_template

    os.rmdir(project_template)
    os.rmdir(repo_dir)

# Generated at 2022-06-23 16:20:36.176205
# Unit test for function find_template
def test_find_template():
    """Corner case test for function find_template
    :param repo_dir: Test directory to find project template in
    :returns: the project template
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests')
    assert find_template(repo_dir) == 'cookiecutter/tests/tests/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:41.065030
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/files/fake-repo'
    template = find_template(repo_dir)
    expected_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert template == expected_template

# Generated at 2022-06-23 16:20:45.771501
# Unit test for function find_template
def test_find_template():
    import pytest
    with pytest.raises(NonTemplatedInputDirException):
        this_dir = os.path.dirname(os.path.abspath(__file__))
        repo_dir = os.path.join(this_dir, '..', 'fake-repo-pre')
        find_template(repo_dir)

# Generated at 2022-06-23 16:20:51.736950
# Unit test for function find_template
def test_find_template():
    """Verify the behaviour of the find_template function."""
    
    # Setup
    repo_dir = os.path.join("tests", "files")
    assert os.path.exists(repo_dir)

    # Call function
    project_template = find_template(repo_dir)

    # Test results
    assert project_template == repo_dir
    
    logger.debug('test_find_template passed.')

# Generated at 2022-06-23 16:20:56.294087
# Unit test for function find_template
def test_find_template():
    """
    This function tests the find_template() method and returns an
    exception if a template is not found.
    """
    try:
        assert find_template('cookiecutter')
    except NonTemplatedInputDirException:
        raise
    else:
        return 'find_template() function passed all tests'

# Generated at 2022-06-23 16:21:00.593159
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    expected = 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    actual = find_template(repo_dir)
    assert expected == actual

# Generated at 2022-06-23 16:21:06.962962
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the correct path.
    """
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    project_template_expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    project_template = find_template(repo_dir)
    assert project_template_expected == project_template

# Generated at 2022-06-23 16:21:13.565671
# Unit test for function find_template
def test_find_template():
    from .repository import determine_repo_dir

    project_dir = determine_repo_dir(
        repo_dir='tests/test-repo/',
        checkout=None,
        no_input=True
    )
    template = find_template(project_dir)
    assert template == os.path.join(
        project_dir, '{{cookiecutter.repo_name}}'
    )


# Generated at 2022-06-23 16:21:25.568153
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template()`."""
    import shutil
    import uuid
    import tempfile

    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'fake-repo-{0}'.format(uuid.uuid4()))
    os.makedirs(repo_dir)

    # Create a fake repo with some cookiecutter template directories
    project_template_one = os.path.join(repo_dir, '{{cookiecutter.project_slug}}')
    os.makedirs(project_template_one)
    project_template_two = os.path.join(repo_dir, '{{cookiecutter.project_slug}}-two')
    os.makedirs(project_template_two)

   

# Generated at 2022-06-23 16:21:30.748579
# Unit test for function find_template
def test_find_template():

    repo_dir = "tests/test-repo"
    res = find_template(repo_dir)
    assert res == "tests/test-repo/{{cookiecutter.repo_name}}"

    repo_dir = "tests/fake-repo-no-templated-dir"
    try:
        res = find_template(repo_dir)
        assert False
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-23 16:21:35.508297
# Unit test for function find_template
def test_find_template():
    non_template_dir = os.getcwd()
    template_dir = 'tests/fake-repo-tmpl'
    assert find_template(template_dir) == os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    try:
        find_template(non_template_dir)
    except NonTemplatedInputDirException:
        return True
    assert False

# Generated at 2022-06-23 16:21:43.552336
# Unit test for function find_template
def test_find_template():
    """Find the project template in the repo root dir.
    """
    # Standard test
    test_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'fake-repo-pre-gen',
            '{{cookiecutter.repo_name}}'
        )

    assert find_template(test_dir) == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
        '{{cookiecutter.repo_name}}'
    )


# Generated at 2022-06-23 16:21:46.112667
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/projects/cookiecutter/tests/git_test_dir'
    find_template(repo_dir)

# Generated at 2022-06-23 16:21:49.270534
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo-pre/'
    project_template = 'tests/test-repo-pre/{{cookiecutter.directory_name}}'
    assert find_template(repo_dir) == project_template



# Generated at 2022-06-23 16:21:50.348960
# Unit test for function find_template
def test_find_template():
    # todo
    pass

# Generated at 2022-06-23 16:21:56.855106
# Unit test for function find_template
def test_find_template():
    """Verify that function find_template finds a project template."""
    from cookiecutter.tests.test_repo import make_repo
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    make_repo(repo_dir)

    project_template = find_template(os.path.abspath('tests/fake-repo-pre/'))
    assert os.path.exists(project_template)

# Generated at 2022-06-23 16:22:01.306734
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""

    import tempfile

    test_template_dir = tempfile.mkdtemp()

    try:
        # Create a template 'abcd'
        os.mkdir(os.path.join(test_template_dir, 'abcd'))
        # Create a project template '{{cookiecutter.project_name}}'
        os.mkdir(os.path.join(test_template_dir, '{{cookiecutter.project_name}}'))

        project_template = find_template(test_template_dir)

        assert project_template == os.path.join(test_template_dir, '{{cookiecutter.project_name}}')
    finally:
        import shutil
        shutil.rmtree(test_template_dir)

# Generated at 2022-06-23 16:22:09.553258
# Unit test for function find_template
def test_find_template():
    """Verify the proper directory is found."""
    import shutil
    import tempfile

    class Args(object):
        pass

    args = Args()
    args.clone_to = tempfile.mkdtemp()

    # Remove default directory
    shutil.rmtree(args.clone_to)

    # Create parent and subdir
    os.makedirs(os.path.join(args.clone_to, 'foo'))
    assert os.path.isdir(args.clone_to)
    assert os.path.isdir(os.path.join(args.clone_to, 'foo'))

    # Test 1: subdir named with jinja2 template tags
    # Should pass with 'foo' as output
    find_template(args.clone_to)

    # Test 2: no subdir named with

# Generated at 2022-06-23 16:22:11.217797
# Unit test for function find_template
def test_find_template():
    """Unit tests for function find_template"""
    pass

# Generated at 2022-06-23 16:22:21.315533
# Unit test for function find_template
def test_find_template():
    def _mock_listdir(path):
        return ['foo', 'test-test', 'bar', 'bar-{{cookiecutter.repo_name}}', 'baz']

    path = os.path.abspath(os.getcwd())

    assert 'bar-{{cookiecutter.repo_name}}' == find_template(path, _mock_listdir)

    try:
        find_template(path, lambda x: ['foo', 'bar'])
    except Exception as e:
        assert 'Unable to find project template in' == str(e)[:37]
        assert path in str(e)
    else:
        assert False