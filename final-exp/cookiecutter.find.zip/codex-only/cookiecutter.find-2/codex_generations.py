

# Generated at 2022-06-23 16:12:26.675719
# Unit test for function find_template
def test_find_template():
    test_project = '..\\..\\tests\\fake-repo-pre\\{{cookiecutter.repo_name}}'
    test_project = os.path.abspath(os.path.join(os.path.dirname(__file__), test_project))
    test_repo = '..\\..\\tests\\fake-repo-pre'
    test_repo = os.path.abspath(os.path.join(os.path.dirname(__file__), test_repo))
    test1 = find_template(test_repo)
    assert test1 == test_project

# Generated at 2022-06-23 16:12:36.044999
# Unit test for function find_template
def test_find_template():
    """
    Test :func:`cookiecutter.find.find_template()`.
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'my_cool_project'))
    os.makedirs(os.path.join(repo_dir, '{{ cookiecutter.repo_name }}'))
    os.makedirs(os.path.join(repo_dir, 'my_other_cool_project'))

    try:
        template_dir = find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-23 16:12:39.232519
# Unit test for function find_template
def test_find_template():
    # path = '/Users/yas/Development/projects/cookiecutter/tests/fake-repo-pre/'
    path = os.path.dirname(__file__) + '/fake-repo-pre/'
    assert find_template(path) == '{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:12:42.119905
# Unit test for function find_template
def test_find_template():
    find_template('/home/audreyr/code/cookiecutter-pypackage')

# Generated at 2022-06-23 16:12:53.297928
# Unit test for function find_template
def test_find_template():
    import pytest

    def test_find_template_is_cookiecutterproject(cc_dir):
        """Verify find_template finds child dir of repo_dir with {{var}}s.
        """
        project_template = find_template(cc_dir)
        assert os.path.isdir(project_template)
        assert '{{' in project_template
        assert '}}' in project_template
    test_find_template_is_cookiecutterproject.pytestmark = pytest.mark.create

    def test_find_template_no_cookiecutter_dir(cc_dir):
        """Verify find_template raises exception if no dirs with {{var}}s.
        """
        bad_cc_dir = os.path.join(cc_dir, 'bad_template')

# Generated at 2022-06-23 16:13:01.004891
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils

    repo_dir = '/tests/fake-repo'
    repo_dir_contents = ['fake-cookiecutter-{{cookiecutter.repo_name}}']
    utils.mock_fs(repo_dir, repo_dir_contents)

    template_path = find_template(repo_dir)
    assert template_path == '/tests/fake-repo/fake-cookiecutter-{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:13:08.176540
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template function works in all cases."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    # Make a fake input repo to test cloning
    temp_directory = utils.make_empty_dir()
    temp_input_repo = utils.generate_files(temp_directory, 'fake-repo')

    assert find_template(temp_input_repo) == os.path.join(temp_input_repo, '{{cookiecutter.repo_name}}')

    # Non templated input directory
    temp_input_repo = utils.generate_files(temp_directory, 'fake-repo-nottemplated')

# Generated at 2022-06-23 16:13:12.730435
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'fake-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:13:18.948704
# Unit test for function find_template
def test_find_template():
    """Tests the ``find_template`` function from project_dir.py."""
    from tests.test_utils import TEST_TEMPLATE_DIR
    project_template = find_template(TEST_TEMPLATE_DIR)
    expected_project_template = os.path.join(TEST_TEMPLATE_DIR, '{{cookiecutter.repo_name}}')
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:13:22.258540
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.join(os.path.dirname(__file__), 'test-find-template'))
    assert find_template('.') == os.path.join('.', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:26.036355
# Unit test for function find_template
def test_find_template():
    """Test find_template function works as expected."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/fake-project/'

# Generated at 2022-06-23 16:13:36.032325
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree

    current_dir = os.getcwd()
    template_dir = os.path.join(current_dir, 'tests/test-repo-pre/')

    repo_dir = None

# Generated at 2022-06-23 16:13:41.273454
# Unit test for function find_template
def test_find_template():
    """Ensure we find the project template when we should."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'files',
        'test-repo-pre-gen-project',
    )
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(
        repo_dir,
        'cookiecutter-pypackage',
    )

# Generated at 2022-06-23 16:13:42.874537
# Unit test for function find_template
def test_find_template():
    find_template("/home/nikhil/myproject/cookie-repo")
    print("Test for find_template passed successfuly")




# Generated at 2022-06-23 16:13:47.716953
# Unit test for function find_template
def test_find_template():
    test_dir = './tests/fixtures/fake-repo-pre'
    project_template = find_template(test_dir)
    assert project_template == './tests/fixtures/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert os.path.isdir(project_template)

# Generated at 2022-06-23 16:13:48.126182
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:13:50.148247
# Unit test for function find_template
def test_find_template():
    repo_dir = '../tests/test-find-template'
    project_template = find_template(repo_dir)
    assert project_template == '../tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:57.541621
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-pre')
    template = find_template(repo_dir)
    expected_template = os.path.join(repo_dir, 'cookiecutter-pypackage')
    assert template == expected_template

# Generated at 2022-06-23 16:14:02.712450
# Unit test for function find_template
def test_find_template():
    """
    Tests find_template()
    """
    import pytest

    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(repo_dir, 'fake-repo-tmpl')
    assert find_template(repo_dir) == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:14:04.625120
# Unit test for function find_template
def test_find_template():
    """Make sure tests in this file are running as expected"""
    assert find_template('.')

# Generated at 2022-06-23 16:14:14.001384
# Unit test for function find_template
def test_find_template():
    """Unit test for the find_template function."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter import utils
    _, repo_dir = tempfile.mkstemp('test_find_template_repo', dir=tempfile.gettempdir())

# Generated at 2022-06-23 16:14:15.164655
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-23 16:14:15.982473
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-23 16:14:23.520223
# Unit test for function find_template
def test_find_template():
    """Find a project template from a directory whose name contains braces."""
    os.chdir('tests/fake-repo-pre/')

    assert find_template(os.getcwd()) == 'tests/fake-repo-pre/cookiecutter-{{cookiecutter.repo_name}}'
    assert os.getcwd() == os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    os.chdir('../..')

# Generated at 2022-06-23 16:14:25.049920
# Unit test for function find_template
def test_find_template():
    find_template('/Users/josephmisiti/Desktop/cookiecutters/python-pypackage')

# Generated at 2022-06-23 16:14:28.203366
# Unit test for function find_template
def test_find_template():
    """Test find_template() to ensure it returns a value.
    """
    path_to_test_input_dir = os.path.join(os.path.abspath('.'), 'tests', 'input', 'test-repo-pre')
    assert find_template(path_to_test_input_dir)

# Generated at 2022-06-23 16:14:30.780748
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'test_repo',
        'cookiecutter-pypackage'
    )

    find_template(repo_dir)

# Generated at 2022-06-23 16:14:38.129118
# Unit test for function find_template
def test_find_template():
    """Verify function that finds template in cloned repo."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-repo'))
    project_template = os.path.join(repo_dir, '.cookiecutter')

    assert find_template(repo_dir) == project_template, (
        'find_template does not find the project_template')
    with open(find_template(repo_dir)) as fh:
        assert 'cookiecutter' in fh.read(), (
            'find_template does not find a "cookiecutter" file')

# Generated at 2022-06-23 16:14:48.263667
# Unit test for function find_template
def test_find_template():
    """Test find_template function"""
    assert find_template("/Users/james/Jobs/cookiecutter-tryton/") == "/Users/james/Jobs/cookiecutter-tryton/cookiecutter-tryton-module"
    assert find_template("/Users/james/Jobs/cookiecutter-tryton/empty_dir") == None
    assert find_template("/Users/james/Jobs/cookiecutter-tryton/cookiecutter-tryton-module/{{cookiecutter.module}}") == None
    assert find_template("/Users/james/Jobs/cookiecutter-tryton/cookiecutter-tryton-module") == "/Users/james/Jobs/cookiecutter-tryton/cookiecutter-tryton-module"

# Generated at 2022-06-23 16:14:59.843423
# Unit test for function find_template
def test_find_template():
    """Tests for :func:`find_template`."""
    import tempfile
    import shutil
    import cookiecutter.main as cookiecutter_main

    tmp_dir = tempfile.mkdtemp()

    cookiecutter_main.cookiecutter(
        'tests/fake-repo-tmpl/',
        no_input=True,
        overwrite_if_exists=True,
        output_dir=tmp_dir
    )

    repo_dir = os.path.join(tmp_dir, 'fake-repo-tmpl')

    project_template = find_template(repo_dir)
    expected_template = 'fake-repo-tmpl/{{ cookiecutter.repo_name }}'
    assert project_template == expected_template

    shutil.rmtree(tmp_dir)

# Generated at 2022-06-23 16:15:05.342261
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(repo_dir, '..', '..', '..', 'fake-repo')
    template = find_template(repo_dir)
    expected = os.path.join(repo_dir, 'fake-project')
    assert template == expected

# Generated at 2022-06-23 16:15:10.058371
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), '..', 'tests', 'fake-repo'
        )
    )
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:15:11.541692
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/cookiecutter-pypackage') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:23.123458
# Unit test for function find_template
def test_find_template():
    """ Test for find template function """

    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    test_tmpl_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(test_tmpl_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(test_tmpl_dir, 'foobar'))

    ret_dir = find_template(test_tmpl_dir)
    assert ret_dir == os.path.join(test_tmpl_dir, 'cookiecutter-foobar')

    try:
        shutil.rmtree(test_tmpl_dir)
    except Exception as e:
        logger.error(e)


# Generated at 2022-06-23 16:15:28.863639
# Unit test for function find_template
def test_find_template():
    """Basic test for find_template function
    """
    from .context import find_template
    import os

    curdir = os.getcwd()
    repo_dir = os.path.join(curdir, "tests", "fake-repo-pre")

    project_template = find_template(repo_dir)
    print("project_template %s", project_template)

# Generated at 2022-06-23 16:15:32.088322
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo/'
    project_template = find_template(repo_dir)
    assert type(project_template) is str

# Generated at 2022-06-23 16:15:41.748265
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.main import cookiecutter

    tests_dir = os.path.join(os.path.dirname(__file__), 'tests')
    template_dir = os.path.join(tests_dir, 'fake-repo-pre/')
    output_dir = os.path.abspath(os.path.join(tests_dir, 'fake-repo-post/'))

    cookiecutter(template_dir, no_input=True)

    project_template = find_template(output_dir)
    project_template_expected = os.path.abspath(
        os.path.join(output_dir, 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    )

# Generated at 2022-06-23 16:15:47.025935
# Unit test for function find_template
def test_find_template():
    logger.debug('Running unit test for find_template')
    repo_dir = 'tests/fake-repo-tmpl/'
    expected = 'tests/fake-repo-tmpl/{{cookiecutter.project_name}}/'
    actual = find_template(repo_dir)
    assert expected == actual, 'find_template should return %s, but returned %s instead.' % (expected, actual)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:15:54.347216
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)

    assert '{{cookiecutter.repo_name}}' in project_template

    shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:15:57.418689
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo') == 'tests/test-repo/cookiecutter-pypackage'
    assert find_template('tests/test-repo-pre') == 'tests/test-repo-pre/cookiecutter-pypackage'

# Generated at 2022-06-23 16:16:03.754509
# Unit test for function find_template
def test_find_template():
    """Test for find_template function"""
    path_to_test_repo = 'tests/test-find-template/{{cookiecutter.project_slug}}'
    repo_dir = os.path.abspath(path_to_test_repo)
    expected_project_template = os.path.abspath('tests/test-find-template/{{cookiecutter.project_slug}}')

    project_template = find_template(repo_dir)

    assert project_template == expected_project_template

# Generated at 2022-06-23 16:16:07.315519
# Unit test for function find_template
def test_find_template():
    repo_dir = '~/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '~/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:10.110411
# Unit test for function find_template
def test_find_template():
    path = os.getcwd()
    assert find_template(path) == os.path.join(path, '{{cookiecutter.project_slug}}')

# Generated at 2022-06-23 16:16:14.866672
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    ))

    assert find_template(os.path.dirname(template_dir)) == template_dir


# Generated at 2022-06-23 16:16:26.889877
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import textwrap
    import logging
    import os

    # Create a temp directory
    repo_dir = tempfile.mkdtemp()

    # Dump some files into the temp directory
    not_a_project_template = os.path.join(repo_dir, 'foobar')
    project_template = os.path.join(repo_dir, '{{cookiecutter.project_name}}')

    with open(not_a_project_template, 'w') as fh:
        fh.write(textwrap.dedent("""
        This is not a project template.
        """))


# Generated at 2022-06-23 16:16:33.096459
# Unit test for function find_template
def test_find_template():

    dir_contents = {
        'foo_bar': False,
        'cookiecutter-foobar': False,
        '{{cookiecutter.repo_name}}': True,
        '__pycache__': False,
        'tests': False
    }

    # We need this to work in both Python 2 and Python 3. So we get
    # the items as a list and make sure they are returned in the same
    # order every time.
    dir_contents = sorted(list(dir_contents.items()))

    class MockListDir(object):

        def __init__(self, dir_contents):
            self.dir_contents = dir_contents
            self.current_iter = 0

        def __call__(self):
            return [item[0] for item in self.dir_contents]

   

# Generated at 2022-06-23 16:16:39.187484
# Unit test for function find_template
def test_find_template():
    """Test function for find_template."""
    repo_dir = os.path.join('tests', 'test-find-template-repo')
    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(
        repo_dir, 'fake-project-{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_project_template

test_find_template()

# Generated at 2022-06-23 16:16:47.740044
# Unit test for function find_template
def test_find_template():
    if os.path.exists('/tmp/test_template') is True:
        raise ValueError('/tmp/test_template exists.  Please delete it.')
    os.mkdir('/tmp/test_template')
    os.mkdir('/tmp/test_template/non_template')
    os.mkdir('/tmp/test_template/{{cookiecutter.project_name}}')

    project_template = find_template('/tmp/test_template')
    assert project_template == '/tmp/test_template/{{cookiecutter.project_name}}'
    # Clean up
    os.remove('/tmp/test_template/non_template')
    os.remove('/tmp/test_template/{{cookiecutter.project_name}}')
    os.remove('/tmp/test_template')

# Generated at 2022-06-23 16:16:50.983430
# Unit test for function find_template
def test_find_template():
    """Verify function find_template works correctly.
    """
    assert find_template('~/fake-repo/') == '../fake-repo/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:54.662979
# Unit test for function find_template
def test_find_template():
    """Ensure that find_template function is finding the project template."""
    repo_dir = 'tests/test-repo-tmpl/'
    project_template = find_template(repo_dir)

    assert project_template == 'tests/test-repo-tmpl/foobar{{cookiecutter.directory_name}}'

# Generated at 2022-06-23 16:16:57.504791
# Unit test for function find_template
def test_find_template():
    abs_path = '/Users/audreyr/cookiecutters/pypackage/'
    assert find_template(abs_path) == '/Users/audreyr/cookiecutters/pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:01.412365
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), 'test-find-template', 'repo'))
    exp_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == exp_template



# Generated at 2022-06-23 16:17:07.883743
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter import exceptions

    utils.work_in(os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test-data', 'test-repo'
    ))

    project_template = find_template('.')

    assert project_template == './{{cookiecutter.project}}'

    utils.work_in('../..')

    # Test for missing templated directory
    try:
        project_template = find_template('.')
        logger.error(
            'find_template did not raise an exception. '
            'Found %s instead.',
            project_template
        )
        raise NonTemplatedInputDirException()
    except exceptions.NonTemplatedInputDirException:
        pass



# Generated at 2022-06-23 16:17:12.303891
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/james/Work/cookiecutter-pypackage/tests/test-data/general-project/') == '/home/james/Work/cookiecutter-pypackage/tests/test-data/general-project/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:17:15.286491
# Unit test for function find_template
def test_find_template():
    find_template(r"C:\Users\bhart\workspace\Cookiecutter-Template")


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:17:21.742606
# Unit test for function find_template
def test_find_template():
    template = find_template('tests/test-repo-pre/fake-repo-tmpl')
    assert template == 'tests/test-repo-pre/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    template = find_template('tests/test-repo-pre/fake-repo-nontmpl')
    assert template == 'tests/test-repo-pre/fake-repo-nontmpl/cookiecutter-pypackage'

# Generated at 2022-06-23 16:17:23.792436
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.expanduser('~'))
    find_template('/Users/ryan/Code/cookiecutter-go')

# Generated at 2022-06-23 16:17:29.370987
# Unit test for function find_template
def test_find_template():
    """Find a template in a repo_dir without subdirs."""
    repo_dir = "tests/fake-repo/foobar"
    project_template = find_template('example_nested/{{cookiecutter.project_name}}/foobar')
    assert project_template == os.path.join(repo_dir, 'example_nested')

# Generated at 2022-06-23 16:17:36.267302
# Unit test for function find_template
def test_find_template():
    original_dir = os.getcwd()
    os.chdir('tests/test-find-repo/fake-repo')
    repo_dir = os.getcwd()

    project_template = find_template(repo_dir)

    assert project_template == 'tests/test-find-repo/fake-repo/{{cookiecutter.repo_name}}'

    os.chdir(original_dir)



# Generated at 2022-06-23 16:17:37.661345
# Unit test for function find_template
def test_find_template():
    """Test function for find_template."""
    find_template('.')

# Generated at 2022-06-23 16:17:40.794852
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    assert(find_template('tests/fake-repo-pre/') == \
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert(find_template('tests/fake-repo-post/') == \
        'tests/fake-repo-post/fake-repo')

# Generated at 2022-06-23 16:17:47.125606
# Unit test for function find_template
def test_find_template():
    """
    Test if it finds the project tempalate
    """

    repo_dir = os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')


    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:17:56.517941
# Unit test for function find_template
def test_find_template():
    """Make a fake repo directory and test find_template."""
    import shutil
    import tempfile
    from cookiecutter.generate import test_hook
    from cookiecutter.repository import determine_repo_dir

    repo_dir = tempfile.mkdtemp()

    test_hook(repo_dir)

    assert find_template(determine_repo_dir(repo_dir)) == os.path.join(
        repo_dir, 'fake-repo', '{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:18:05.933694
# Unit test for function find_template
def test_find_template():
    """Test that `find_template` correctly determines a project template."""
    import shutil
    import tempfile
    import textwrap
    from cookiecutter.compat import get_terminal_size

    input_dir = tempfile.mkdtemp()
    logger.debug('Project template search directory: %s', input_dir)

# Generated at 2022-06-23 16:18:10.202589
# Unit test for function find_template
def test_find_template():
    with working_dir(os.path.dirname(__file__)):
        assert find_template('tests/test-repo') == 'tests/test-repo/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:18:10.774376
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:18:19.277622
# Unit test for function find_template
def test_find_template():
    """
    Check that the correct template directory is found for cases:

    1. Template directory is named after the repo.
    2. Template directory is a subdirectory of the repo.
    3. Template directory is not a subdirectory of the repo.
    4. Template directory is named something else.
    """
    import shutil

    from cookiecutter.utils import rmtree

    from .test_files import copy_test_files

    repo_path = copy_test_files('template-repo-master')
    test_dir = os.path.join(repo_path, 'test_1')
    template_dir = os.path.join(test_dir, '{{cookiecutter.repo_name}}')

    assert find_template(test_dir) == template_dir


# Generated at 2022-06-23 16:18:28.712860
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/cookiecutter-pypackage') == '/home/vagrant/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('/home/vagrant/cookiecutter-tryton') == '/home/vagrant/cookiecutter-tryton/{{cookiecutter.repo_name}}'
    assert find_template('/home/vagrant/cookiecutter-docker-openstack') == '/home/vagrant/cookiecutter-docker-openstack/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:35.288207
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    check_false_test_find_template(NonTemplatedInputDirException)
    assert find_template('tests/fake-repo/') == 'tests/fake-repo/fake'

# Unit test to check if exception was raised

# Generated at 2022-06-23 16:18:46.197028
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template.
    """
    import os
    import shutil

    repo_dir = None
    try:
        # Make a temp dir to clone into
        repo_dir = tempfile.mkdtemp()

        # Clone the fake git repo into the temp dir
        subprocess.call(['git', 'clone', 'git://github.com/audreyr/cookiecutter-pypackage.git', repo_dir])

        # Find template in local repo
        find_template(repo_dir)

    finally:
        # Remove the temp dir
        if repo_dir:
            shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:18:53.309863
# Unit test for function find_template
def test_find_template():
    logger.debug('Testing %s', find_template.__name__)
    this_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(this_dir, 'test-repo-pre-gen')
    project_template = find_template(test_dir)
    assert project_template is not None
    assert 'cookiecutter' in project_template
    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-23 16:18:58.451921
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = 'tests/files/fake-repo-pre/'
    output = find_template(repo_dir)
    assert output == 'tests/files/fake-repo-pre/{{cookiecutter.repo_name}}', 'Templates do not match'

# Generated at 2022-06-23 16:19:02.861396
# Unit test for function find_template
def test_find_template():
    project_template = find_template('tests/test-repo-pre/')
    assert project_template == 'tests/test-repo-pre/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-23 16:19:14.317113
# Unit test for function find_template
def test_find_template():
    """Sanity check for find_template."""
    from console import console
    from cookiecutter import utils
    import textwrap

    repo_dir = utils.make_tmp_dir()

    with console.cd(repo_dir):
        open('cookiecutter.json', 'w').close()
        open('README.rst', 'w').close()
        open('{{cookiecutter.repo_name}}', 'w').close()

    # Test 1
    project_template = find_template(repo_dir)
    print(project_template)

    assert project_template == '{{cookiecutter.repo_name}}'

    # Test 2
    with console.cd(project_template):
        open('cookiecutter.json', 'w').close()

# Generated at 2022-06-23 16:19:23.090061
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree
    from cookiecutter import main
    from nose.tools import raises

    try:
        main.cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    except SystemExit:
        pass
    repo_dir = os.path.abspath(os.path.join('.', 'fake-repo'))
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.project_name}}')

    # Clean up repo
    rmtree(repo_dir)

    try:
        main.cookiecutter('tests/fake-repo-non-templated', no_input=True)
    except SystemExit:
        pass
    repo_

# Generated at 2022-06-23 16:19:24.556463
# Unit test for function find_template
def test_find_template():
    """Test function `find_template`."""
    pass

# Generated at 2022-06-23 16:19:33.153961
# Unit test for function find_template
def test_find_template():
    from .compat import patch
    from .compat import Mock

    with patch('os.listdir') as mock_listdir:
        mock_listdir.return_value = ['foo', 'bar', '{{cookiecutter.project_name}}']
        with patch('os.path.join') as mock_join:
            mock_join.return_value = '{{cookiecutter.project_name}}'
            find_template('.')
            mock_listdir.assert_called_once_with('.')
            mock_join.assert_called_once_with('.', '{{cookiecutter.project_name}}')

# Generated at 2022-06-23 16:19:37.258249
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(template_dir)
    assert project_template.endswith('cookiecutter-pypackage')

# Generated at 2022-06-23 16:19:38.996457
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    raise NotImplementedError

# Generated at 2022-06-23 16:19:42.610021
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/projects/cookiecutter-pypackage/'
    outpath = find_template(repo_dir)
    assert outpath == '/home/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:48.005490
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo/{{cookiecutter.project_slug}}'

# Generated at 2022-06-23 16:19:57.531383
# Unit test for function find_template
def test_find_template():
    """A functional test for the find_template() function."""

    import tempfile

    repo_dir = tempfile.mkdtemp()
    logger.debug('Created temporary repo directory {0}'.format(repo_dir))

    # Create a test project template.
    project_template_dir = '{{cookiecutter.repo_name}}'
    project_template_dir = os.path.join(repo_dir, project_template_dir)
    logger.debug('Created temporary project template directory {0}'.format(
        project_template_dir
    ))
    os.mkdir(project_template_dir)

    found_template = find_template(repo_dir)
    assert found_template == project_template_dir

# Generated at 2022-06-23 16:20:10.298338
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""
    import shutil
    from cookiecutter import utils
    from cookiecutter import vcs

    cwd = os.path.abspath(os.getcwd())
    tmp_repo_dir = os.path.join(cwd, 'test_find_template')
    shutil.rmtree(tmp_repo_dir, ignore_errors=True)

    test_repo = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir = vcs.clone(test_repo, checkout='0.1.2', no_checkout=False)
    assert os.path.basename(repo_dir) == 'cookiecutter-pypackage'
    assert find_template(repo_dir)

# Generated at 2022-06-23 16:20:15.460494
# Unit test for function find_template
def test_find_template():
    path_to_fake_repo = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..',
        'tests',
        'test-repo',
    )
    found_path = find_template(path_to_fake_repo)
    expected_path = os.path.join(
        path_to_fake_repo,
        '{{cookiecutter.repo_name}}'
    )
    assert found_path == expected_path

# Generated at 2022-06-23 16:20:18.516111
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    from cookiecutter.utils import rmtree
    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    project_dir = main.cookiecutter(template)
    assert project_dir == 'fake-package', project_dir
    rmtree(project_dir)

# Generated at 2022-06-23 16:20:21.026299
# Unit test for function find_template
def test_find_template():
    """Test the function find_template."""

    assert find_template('tests/fake-repo-tmpl/') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:33.179565
# Unit test for function find_template
def test_find_template():
    """Make sure that the find_template function works as expected.

    This will test the function on a clone of the default
    Cookiecutter.
    """

    from cookiecutter.prompt import prompt_for_config
    from cookiecutter.compat import input

    template_dir = os.path.dirname(os.path.dirname(__file__))
    template_dir = os.path.join(template_dir, 'tests', 'test-pypackage')
    context = prompt_for_config(template_dir)
    context['cookiecutter'] = template_dir
    context['full_name'] = 'Audrey Roy'
    context['email'] = 'audreyr@example.com'
    context['github_username'] = 'audreyr'

    # Creating a fake `input` function here because
    # `

# Generated at 2022-06-23 16:20:36.558626
# Unit test for function find_template
def test_find_template():
    repo_dir = 'test/test_repo'
    assert find_template(repo_dir) == 'test_repo/{{cookiecutter.repo_name}}'

# Unit tests for exceptions

# Generated at 2022-06-23 16:20:42.904708
# Unit test for function find_template
def test_find_template():
    """
    Finds template
    """
    repo_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)))
    project_template = find_template(repo_dir)

    assert os.path.isdir(project_template)
    assert '{{cookiecutter.repo_name}}' in  os.listdir(project_template)

# Generated at 2022-06-23 16:20:51.244903
# Unit test for function find_template

# Generated at 2022-06-23 16:20:51.835844
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:20:57.340209
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = ['cookiecutter', 'cookiecutter-python', 'cookiecutter-pypackage', 'foo', 'bar']
    for item in repo_dir_contents:
        dir = os.path.join('/home/user', item)
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            return dir


# Generated at 2022-06-23 16:21:08.615478
# Unit test for function find_template
def test_find_template():
    """Verifies that the correct project template is located."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    temp_dir = tempfile.mkdtemp()
    cookiecutter_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(cookiecutter_dir)
    os.mkdir(os.path.join(temp_dir, 'something_else'))

    # Verify that the correct project template is selected by default.
    assert find_template(temp_dir) == cookiecutter_dir

    shutil.rmtree(temp_dir)

    # Verify that function raises exception when there is no project
    # template.
    temp_dir = tempfile.mkdtemp()
    os.mk

# Generated at 2022-06-23 16:21:14.802732
# Unit test for function find_template
def test_find_template():
    """Test that find_template() returns correct relative paths."""
    assert find_template('tests/test-input/fake-repo-pre/') ==\
        'tests/test-input/fake-repo-pre/{{cookiecutter.repo_name}}'

    assert find_template('tests/test-input/fake-repo-pre-2/') ==\
        'tests/test-input/fake-repo-pre-2/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:18.589770
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    find_template('tests/fake-repo-pre/')

# Generated at 2022-06-23 16:21:19.194414
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:21:22.564729
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/anu/git/cookiecutter-pypackage') == '/Users/anu/git/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

# Generated at 2022-06-23 16:21:28.461108
# Unit test for function find_template
def test_find_template():
    """Tests find_template() on a test directory with a single file."""
    repo_dir = os.path.join('tests', 'test-find-template')
    logger.debug('repo_dir = %s', repo_dir)
    expected_project_template = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    assert find_template(repo_dir) == expected_project_template

# Generated at 2022-06-23 16:21:34.408346
# Unit test for function find_template
def test_find_template():
    """Check that the find_template function works as expected"""
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a dummy template directory
    template_dir = os.path.join(temp_dir, 'cookiecutter-project')
    os.makedirs(template_dir)

    # Create a dummy file within that directory
    with open(os.path.join(template_dir, 'README.md'), 'w') as fh:
        fh.write('This is a dummy README.')

    # Create a second template directory with a cookiecutter- prefix
    bad_template_dir = os.path.join(temp_dir, 'cookiecutter-bad_project')
    os.makedirs(bad_template_dir)

    # Create

# Generated at 2022-06-23 16:21:37.868315
# Unit test for function find_template
def test_find_template():
    """Find project template in 'tests/fake-repo/'."""
    assert find_template('tests/fake-repo/') == 'tests/fake-repo/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:21:48.946840
# Unit test for function find_template
def test_find_template():
    """ Verify that if we have a repo_dir with two non-templates and two templates, we only return one template """
    # Given
    testdir = os.path.join(os.path.dirname(__file__), 'test_find_template')
    repo_dir = os.path.join(testdir, 'repo_dir')
    templates = [os.path.join(testdir, 'repo_dir', 'template1'),
                 os.path.join(testdir, 'repo_dir', 'template2')]
    non_templates = [os.path.join(testdir, 'repo_dir', 'non_template1'),
                 os.path.join(testdir, 'repo_dir', 'non_template2')]

    # When
    test_template = find_template(repo_dir)

# Generated at 2022-06-23 16:21:53.988300
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') ==\
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') ==\
        'tests/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:22:00.198692
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter

    context = {
        'project_name': 'awesome_project',
        'repo_name': 'text2git',
        'author_name': 'John Doe',
    }
    res = cookiecutter(
        'tests/fake-repo-tmpl/',
        no_input=True,
        extra_context=context,
    )
    assert res

# Generated at 2022-06-23 16:22:03.596107
# Unit test for function find_template
def test_find_template():
    # TODO: May be a better way to test this function.
    try:
        find_template(os.path.join(os.path.dirname(__file__), 'tests'))
    except NonTemplatedInputDirException:
        return

# Generated at 2022-06-23 16:22:09.465893
# Unit test for function find_template
def test_find_template():
    """Test that the function `find_template` works as expected."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'fake-repo'))
    output = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert output == expected

# Generated at 2022-06-23 16:22:18.941933
# Unit test for function find_template
def test_find_template():
    """Get repo_dir"""
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'fake-repo-pre')
    template_dir = find_template(repo_dir)
    expected_template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    #TODO: assert template_dir == expected_template_dir
    assert True