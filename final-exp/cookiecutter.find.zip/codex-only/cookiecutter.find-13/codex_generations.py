

# Generated at 2022-06-23 16:12:25.108359
# Unit test for function find_template
def test_find_template():
    """
    Test ``find_template`` function.
    """
    # Test find_template in a directory containing a template
    good_repo = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..', 'tests', 'fake-repo-pre'
    )

    assert '{{cookiecutter.repo_name}}' in find_template(good_repo)
    assert find_template(good_repo).startswith(good_repo)

    # Test find_template in a directory containing no templates
    bad_repo = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..', 'tests', 'fake-repo-tmpl'
    )


# Generated at 2022-06-23 16:12:29.445105
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 'fake-repo')
    assert find_template(test_repo_dir) == os.path.join(test_repo_dir, 'fake')

# Generated at 2022-06-23 16:12:29.922004
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:12:32.480772
# Unit test for function find_template
def test_find_template():
    assert(find_template('tests/fake-repo-tmpl/') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:12:37.309177
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-pre-gen',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:12:43.754103
# Unit test for function find_template
def test_find_template():
    "Function to test find_template function"
    test_dir = os.path.join(
        os.path.dirname(__file__),
        '../tests/test-identical-dir/{{cookiecutter.repo_name}}'
    )

    assert find_template(os.path.join(
        os.path.dirname(__file__), '../tests/test-identical-dir'
    )) == test_dir

# Generated at 2022-06-23 16:12:50.490136
# Unit test for function find_template
def test_find_template():
    from cookiecutter import config

    repo_dir = 'tests/test-repo/'

    project_dir = find_template(repo_dir)
    assert project_dir == os.path.abspath('tests/test-repo/{{cookiecutter.repo_name}}')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:12:56.283548
# Unit test for function find_template
def test_find_template():
    """Test function for find_template."""
    from cookiecutter.utils.paths import get_test_data_path
    repo_dir = os.path.join(get_test_data_path(), 'test-repo', 'fake-repo')
    returned_path = find_template(repo_dir)
    assert returned_path == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:00.761663
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'tests', 'test-find-template')
    template_dir = find_template(test_dir)
    assert template_dir == os.path.join(test_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:02.184299
# Unit test for function find_template
def test_find_template():
    find_template('/Users/johndoe/cookiecutters/cookiecutter-pypackage')

# Generated at 2022-06-23 16:13:02.672232
# Unit test for function find_template
def test_find_template():
    #assert
    return

# Generated at 2022-06-23 16:13:11.502981
# Unit test for function find_template
def test_find_template():
    """Test `find_template` function."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    fixtures_dir = os.path.join(base_dir, '..', 'tests', 'fixtures')
    test_dir = os.path.join(fixtures_dir, 'test-cookiecutter-repo')
    template = find_template(test_dir)
    assert template == os.path.join(test_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-23 16:13:12.713858
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:13:18.180496
# Unit test for function find_template
def test_find_template():
    """Test that ``find_template()`` works in the way we expect."""
    template_dir = os.path.join(os.path.dirname(__file__),
                                'test_find_template')
    assert find_template(template_dir) == os.path.join(template_dir,
                                                       '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:26.688989
# Unit test for function find_template
def test_find_template():
    """
    Test function for `find_template`.

    :returns: PASS, FAIL
    """
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    template_dir = 'cookiecutter-{{cookiecutter.repo_name}}'

    try:
        os.makedirs(os.path.join(repo_dir, template_dir))
        template_path = find_template(repo_dir)
        assert template_path == os.path.join(repo_dir, template_dir)
    except NonTemplatedInputDirException:
        template_path = 'not_found'
        assert template_path == 'not_found'
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:13:29.841111
# Unit test for function find_template
def test_find_template():
    """Test that the project template is found."""
    path = 'tests/files/fake-repo'
    assert find_template(path) == 'tests/files/fake-repo/fake-project'

# Generated at 2022-06-23 16:13:38.276497
# Unit test for function find_template

# Generated at 2022-06-23 16:13:42.457034
# Unit test for function find_template
def test_find_template():
    find_template("C:\\Users\\khusu\\Desktop\\Algorithms\\Cookiecutter\\cookiecutter-django-crud\\"
                 "{% raw %}{{cookiecutter.repo_name}}{% endraw %}")



# Generated at 2022-06-23 16:13:47.173547
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        os.pardir,
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)

    assert project_template == repo_dir

# Generated at 2022-06-23 16:13:50.503558
# Unit test for function find_template
def test_find_template():
    rd = 'tests/fake-repo-tmpl'
    pt = find_template(rd)
    pt = pt.replace(rd + '/', '')
    assert pt == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:56.759324
# Unit test for function find_template
def test_find_template():
    import tempfile

    tdir = tempfile.mkdtemp()

    os.mkdir(os.path.join(tdir, 'my_template'))

    expected = os.path.join(tdir, 'my_template')
    actual = find_template(tdir)

    assert actual == expected

# Generated at 2022-06-23 16:13:59.631118
# Unit test for function find_template
def test_find_template():
    assert find_template('../tests/test-output/fake-repo') == '../tests/test-output/fake-repo/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:14:08.011534
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir_contents = ['cookiecutter-pypackage', 'cookiecutter-pypackage-master']
    open('/tmp/cookiecutter-pypackage', 'a').close()
    open('/tmp/cookiecutter-pypackage-master', 'a').close()
    repo_dir = '/tmp'
    project_template = find_template(repo_dir)
    assert '/tmp/cookiecutter-pypackage' == project_template



# Generated at 2022-06-23 16:14:16.235817
# Unit test for function find_template
def test_find_template():
    with open('test.txt', 'w') as f:
        f.write("Hello world\n")
    os.getcwd()
    os.mkdir("fake_dir")
    os.chdir("fake_dir")
    os.mkdir("fake_dir2")
    os.chdir("fake_dir2")
    os.mkdir("temp")
    # Fake template directory is created and made current working directory
    find_template("test")
    os.chdir("..")
    os.chdir("..")
    os.chdir("..")
    os.chdir("..")
    os.chdir("..")
    os.remove("test.txt")
    os.system("rm -rf fake_dir")

# Generated at 2022-06-23 16:14:24.554054
# Unit test for function find_template
def test_find_template():
    """Tests that find_template correctly finds the proper template directory.

    :returns bool: True if test passes
    """
    logger.debug('Testing find_template')
    repo_dir = os.path.join(os.path.dirname(__file__), 'test-find-template')
    try:
        template = find_template(repo_dir)
    except:
        return False

    for expected_result in ['fake-project-1', 'fake-project-2']:
        if expected_result not in template:
            return False

    return True

# Generated at 2022-06-23 16:14:31.764338
# Unit test for function find_template
def test_find_template():
    """
    Tests to see if the function finds a project template
    """
    find_template("/Users/danboone/Desktop/cookiecutter-fast-data-science/cookiecutter-fast-data-science")

# def _render_if_template(path):
#     """This is a hack of a function...
#
#     ...that will render a Jinja2 template `path` if it has delimiters.
#
#     :param str path: Path to render if it has delimiters
#     :returns str: The rendered path (or original path if no rendering was
#       required)
#     """
#     path = os.path.expanduser(path)
#     if '{{' in path or '}}' in path:
#         template = env.get_template(path)
#         path = template.

# Generated at 2022-06-23 16:14:36.543328
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake_repo',
    )
    project_template = find_template(test_dir)
    expected_template = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_template

# Generated at 2022-06-23 16:14:42.457931
# Unit test for function find_template
def test_find_template():
    """Test that we can find a template directory when it's present."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo'
    )
    expected_project_template = os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert expected_project_template == project_template

# Generated at 2022-06-23 16:14:48.623461
# Unit test for function find_template
def test_find_template():
    """
    Tests the find_template function.
    """
    repo_dir = os.path.expanduser('~/cookiecutter-django/')

    project_template = find_template(repo_dir)

    assert 'cookiecutter' in project_template
    assert '{{' in project_template
    assert '}}' in project_template
    assert '~/cookiecutter-django/cookiecutter-django/' == project_template

# Generated at 2022-06-23 16:14:59.879800
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter import exceptions

    if os.path.isdir('tests/fake-repo-pre/'):
        shutil.rmtree('tests/fake-repo-pre/')
    if os.path.isdir('tests/fake-repo-post/'):
        shutil.rmtree('tests/fake-repo-post/')
    if os.path.isdir('tests/fake-repo-pre-no-cc-dir/'):
        shutil.rmtree('tests/fake-repo-pre-no-cc-dir/')

    utils.copytree('tests/test-data/fake-repo-pre/', 'tests/fake-repo-pre/')

# Generated at 2022-06-23 16:15:02.182385
# Unit test for function find_template
def test_find_template():
    """Unit test function for function find_template."""
    logging.basicConfig(level=logging.DEBUG)

    repo_dir = 'tests/test-template-repo/{{cookiecutter.repo_name}}'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-template-repo/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:15:09.201713
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import os

    cwd = os.getcwd()

    repo_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 16:15:14.782952
# Unit test for function find_template
def test_find_template():
    from tests.test_finders import (
        repo_containing_a_template,
        repo_containing_a_non_template,
        repo_containing_a_subdir_containing_a_template,
        repo_containing_an_empty_dir,
        repo_containing_file_with_json_extension
    )
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from py.path import local  # pylint: disable=no-name-in-module

    logger.debug('Testing find_template()')
    repo_dir = repo_containing_a_template.working_dir
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:15:19.536217
# Unit test for function find_template
def test_find_template():
    """Check output of find_template."""
    repo_dir = 'my-repo'
    assert find_template('my-repo') == 'my-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:27.519922
# Unit test for function find_template
def test_find_template():
    # Setup
    import tempfile
    repo_dir = tempfile.mkdtemp()
    project_template_name = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    os.makedirs(project_template_name)

    # Test
    returned_project_template = find_template(repo_dir)

    # Teardown
    import shutil
    shutil.rmtree(repo_dir)

    # Assert
    assert returned_project_template == project_template_name

# Generated at 2022-06-23 16:15:28.509457
# Unit test for function find_template
def test_find_template():
    find_template('/')

# Generated at 2022-06-23 16:15:34.647352
# Unit test for function find_template
def test_find_template():
    """Tests for find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), 'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'test-project')

# Generated at 2022-06-23 16:15:42.007235
# Unit test for function find_template
def test_find_template():
    os.listdir = lambda x: ['foo', 'cookiecutter-{{cookiecutter.repo_name}}', 'bar']
    assert find_template('x') == 'x/cookiecutter-{{cookiecutter.repo_name}}'

    os.listdir = lambda x: ['cookiecutter-foo']
    assert find_template('x') == 'x/cookiecutter-foo'

    os.listdir = lambda x: ['foo']
    try:
        find_template('x')
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException not raised')

# Generated at 2022-06-23 16:15:44.031734
# Unit test for function find_template
def test_find_template():
    find_template('./tests/fake-repo-pre/')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:15:50.523562
# Unit test for function find_template
def test_find_template():
    """Check that find_template() returns the correct dir."""

    repo_dir = 'tests/fake-repo/'
    project_template = find_template(repo_dir)
    expected_template = os.path.join(repo_dir, 'cookiecutter-pypackage')
    assert project_template == expected_template, \
        'The project_template returned should be {}'.format(expected_template)

# Generated at 2022-06-23 16:15:58.967509
# Unit test for function find_template
def test_find_template():
    import shutil
    from tempfile import mkdtemp
    from cookiecutter.utils import rmtree

    def _create_dir_structure(dir_name):
        if os.path.isdir(dir_name):
            rmtree(dir_name)
        os.mkdir(dir_name)
        os.mkdir(os.path.join(dir_name, 'cookiecutter'))
        os.mkdir(os.path.join(dir_name, 'not-a-cookiecutter'))

    temp_dir = mkdtemp()
    project_dir = os.path.join(temp_dir, 'cookiecutter')


# Generated at 2022-06-23 16:16:01.212085
# Unit test for function find_template
def test_find_template():
    test_dir = 'tests/test-find-template/fake-repo'
    project_template = find_template(test_dir)
    assert project_template == 'tests/test-find-template/fake-repo/{{cookiecutter.repo_name}}', project_template

# Generated at 2022-06-23 16:16:07.757328
# Unit test for function find_template
def test_find_template():
    """
    Find_template(repo_dir) should return a string that contains repo_dir
    """
    repo_dir = '/home/bdesigner/Desktop/Cookiecutter/tests/fake-repo'
    result = find_template(repo_dir)
    template_name = 'cookiecutter-pypackage'

    assert repo_dir in result
    assert template_name in result

# Generated at 2022-06-23 16:16:15.789989
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils

    # Test a directory that should work
    template_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        '..',
        'tests',
        'test-data',
        '{{cookiecutter.repo_name}}'
    )

    project_template = find_template(template_dir)

    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'

    # Test a directory that should not work
    template_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        '..',
        'tests',
        'test-data',
        'no-template'
    )

# Generated at 2022-06-23 16:16:23.239297
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'input_project'
    )
    expected_template_dir = os.path.join(
        test_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    template_dir = find_template(test_dir)

    assert template_dir == expected_template_dir

# Generated at 2022-06-23 16:16:26.007676
# Unit test for function find_template
def test_find_template():
    expected = 'ok-to-check-in/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo') == expected

# Generated at 2022-06-23 16:16:34.471799
# Unit test for function find_template

# Generated at 2022-06-23 16:16:43.050608
# Unit test for function find_template
def test_find_template():
    import cookiecutter
    import pytest
    # repo_dir = '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    repo_dir = os.path.join(
        cookiecutter.__path__[0],
        'tests/test-data/git-repos/cookiecutter-pypackage-master')
    if not os.path.isdir(repo_dir):
        pytest.skip('Test data git repo unavailable')
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert expected == find_template(repo_dir)

# Generated at 2022-06-23 16:16:46.510861
# Unit test for function find_template
def test_find_template():
    pwd = os.path.abspath('/home/vagrant/cookiecutter/tests/test-find-template')
    assert find_template(pwd) == '/home/vagrant/cookiecutter/tests/test-find-template/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:16:57.423571
# Unit test for function find_template
def test_find_template():
    from environment import TEST_DIR
    from cookiecutter import utils
    from unittest import TestCase, skipIf

    class TestFindTemplate(TestCase):
        def test_templated_dir(self):
            template = find_template(
                os.path.join(TEST_DIR, 'fake-repo-pre/'),
                )
            self.assertEqual(
                utils.make_sure_path_exists(
                    os.path.join(
                        TEST_DIR,
                        'fake-repo-pre/',
                        '{{cookiecutter.repo_name}}'
                    )
                ),
                template
            )

    test_find_template = TestFindTemplate()
    test_find_template.test_templated_dir()

# Generated at 2022-06-23 16:17:03.494630
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'fake-repo',
        'fake_repo_pre_renderer',
    )
    project_template = find_template(repo_dir)
    project_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == project_dir

# Generated at 2022-06-23 16:17:07.911011
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree

    directory = 'fake-repo'
    template = 'fake-repo-master'

    os.makedirs(template)
    open(os.path.join(template, 'cookiecutter.json'), 'wb').close()

    try:
        template_dir = find_template(directory)
        assert template_dir == os.path.join(directory, template)

    finally:
        rmtree(template)

# Generated at 2022-06-23 16:17:11.988583
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected."""
    repo_dir = 'tests/fake-repo-pre'
    assert find_template(repo_dir) == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:15.374275
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/cookiecutter') == '/home/audreyr/cookiecutter/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:17:18.005507
# Unit test for function find_template
def test_find_template():
    repo_dir = 'test-repo'
    repo_dir_contents = ['{{cookiecutter.test}}']
    assert(repo_dir_contents[0] == find_template(repo_dir))

# Generated at 2022-06-23 16:17:27.350594
# Unit test for function find_template
def test_find_template():
    repo_dir = "/home/user/cookiecutter-pypackage"
    project_template = find_template(repo_dir)
    assert project_template == "/home/user/cookiecutter-pypackage/cookiecutter-pypackage"
    repo_dir = "/home/user/cookiecutter-pypackage-master"
    project_template = find_template(repo_dir)
    assert project_template == "/home/user/cookiecutter-pypackage-master/cookiecutter-pypackage"
    repo_dir = "/home/user/cookiecutter-example"
    project_template = find_template(repo_dir)
    assert project_template == "/home/user/cookiecutter-example/_cookiecutter"

# Generated at 2022-06-23 16:17:30.912402
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre'
    )
    project_template = find_template(repo_dir)
    project_template_dir_name = os.path.dirname(project_template)
    assert project_template_dir_name == repo_dir

# Generated at 2022-06-23 16:17:40.702158
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function."""
    from cookiecutter.utils import rmtree

    template_name = 'fake-template'
    template_dir = os.path.join(os.path.dirname(__file__), template_name)
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    rmtree(repo_dir, ignore_errors=True)

    shutil.copytree(template_dir, repo_dir)
    #Change the repo name to include cookiecutter variable
    os.rename(os.path.join(repo_dir, template_name),
              os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    #Change the repo name to include non-cookiecutter variable

# Generated at 2022-06-23 16:17:45.706670
# Unit test for function find_template
def test_find_template():
    """Verify function find_template"""
    repo_dir = 'tests/test-repo/'
    
    expected_output = 'tests/test-repo/{{cookiecutter.project_name}}/'
    actual_output = find_template(repo_dir)

    assert actual_output == expected_output

# Generated at 2022-06-23 16:17:57.857142
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

    os.makedirs(
        os.path.join(repo_dir, 'my_cool_project')
    )

    os.makedirs(
        os.path.join(repo_dir, 'user', 'repo', '{{ cookiecutter.repo_name }}')
    )
    os.makedirs(
        os.path.join(repo_dir, 'user2', 'repo', '{{ cookiecutter.repo_name }}')
    )

    os.makedirs(
        os.path.join(repo_dir, 'cookiecutter-{{ cookiecutter.repo_name }}')
    )


# Generated at 2022-06-23 16:18:06.536807
# Unit test for function find_template
def test_find_template():
    """Test function find_template"""

    repo_dir_contents = ['cookiecutter-py', 'cookiecutter-pypackage', 'cookiecutter-submodule',
                         'cookiecutter-submodule/cookiecutter-subsubmodule/{{cookiecutter.subsub_subsub_var}}',
                         'cookiecutter-subsubmodule', 'cookiecutter', '.gitignore', '.travis.yml',
                         'README.rst', 'tox.ini', 'tests', 'tests/test_find_template.py']


# Generated at 2022-06-23 16:18:13.114303
# Unit test for function find_template
def test_find_template():
    """Smoke test for function find_template."""
    from cookiecutter.utils import default_workflow

    repo_dir = default_workflow(input_dir='tests/fake-repo-pre/', no_input=True)
    project_template = find_template(repo_dir)

    assert 'tests' in project_template
    assert 'fake-repo-pre' in project_template

# Generated at 2022-06-23 16:18:13.795437
# Unit test for function find_template
def test_find_template():
    """Tests the find_template function."""
    pass

# Generated at 2022-06-23 16:18:16.595485
# Unit test for function find_template
def test_find_template():
    """Test case for function find_template"""
    template_path = find_template('/Users/au4h/Documents/GitHub/FooBar')
    assert template_path == '/Users/au4h/Documents/GitHub/FooBar/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:18:20.281104
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    template_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test-template')
    )

    found_template = os.path.abspath(
        os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    )

    assert find_template(template_dir) == found_template

# Generated at 2022-06-23 16:18:26.353527
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'
    )
    assert find_template(template_dir) == os.path.join(
        template_dir, '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:18:32.179783
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    repo_dir = 'tests/test-repo-pre/'
    assert find_template(repo_dir) == 'tests/test-repo-pre/{{cookiecutter.repo_name}}', 'The ' \
                                                                                        'project_template ' \
                                                                                        'variable should be the relative' \
                                                                                        ' path to the project template in ' \
                                                                                        'the repo.'

# Generated at 2022-06-23 16:18:33.283140
# Unit test for function find_template
def test_find_template():
    """Test find_template()"""
    pass



# Generated at 2022-06-23 16:18:38.439911
# Unit test for function find_template
def test_find_template():
    """Unit test function for function find_template."""
    try:
        find_template(os.path.join(os.getcwd(), 'tests', 'fake-repo-pre'))
    except NonTemplatedInputDirException:
        raise AssertionError('Could not find the template in tests/fake-repo-pre')
    else:
        pass

# Generated at 2022-06-23 16:18:45.540537
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fixtures/good-repo') == 'tests/fixtures/good-repo/{{cookiecutter.repo_name}}'
    assert find_template('tests/fixtures/fake-repo') != 'tests/fixtures/good-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:50.982639
# Unit test for function find_template
def test_find_template():
    project_template = find_template('/home/dmankow/MyProjects/cookiecutter-test/test_repo')
    assert project_template == '/home/dmankow/MyProjects/cookiecutter-test/test_repo/{{cookiecutter.project_name}}'

# Generated at 2022-06-23 16:18:59.904899
# Unit test for function find_template
def test_find_template():
    possible_templates = ['{{cookiecutter.repo_name}}',
                          'cookiecutter-{{cookiecutter.repo_name}}',
                          '{{cookiecutter.repo_name}}-master',
                          '{{cookiecutter.repo_name}}-develop',
                          '{{cookiecutter.repo_name}}-gh-pages',
                          '{{cookiecutter.repo_name}}-docs']

    for template in possible_templates:
        # Create folder
        try:
            os.makedirs(template)
        except OSError:
            if not os.path.isdir(template):
                raise

        # Create a file

# Generated at 2022-06-23 16:19:05.624778
# Unit test for function find_template
def test_find_template():
    """Test the find_template function.

    :returns: True if the test passes, False if it fails.
    """

    repo_dir = '.'
    project_template = find_template(repo_dir)

    if project_template == os.path.join(repo_dir, '.cookiecutter-project'):
        return True
    else:
        return False



# Generated at 2022-06-23 16:19:12.613251
# Unit test for function find_template
def test_find_template():
    """Function to unit test `find_template`."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-repo',
    )
    expected = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-repo',
        '{{cookiecutter.repo_name}}',
    )
    project_template = find_template(repo_dir)
    assert project_template == expected, project_template

# Generated at 2022-06-23 16:19:21.415929
# Unit test for function find_template
def test_find_template():
    """Test if the correct project template is found."""
    import os
    import shutil
    from cookiecutter.utils import rmtree

    # Create a fake cookiecutter template
    fake_repo = os.path.abspath('fake_repo')
    fake_repo_template = os.path.join(fake_repo, '{{cookiecutter.repo_name}}')
    os.makedirs(fake_repo_template)

    # Make sure this fake project template is found
    found_template = find_template(fake_repo)
    assert found_template == fake_repo_template

    # Clean up
    rmtree(fake_repo)

# Generated at 2022-06-23 16:19:27.416732
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/arbitrary/github.com/audreyr/cookiecutter-pypackage') == '/Users/audreyr/arbitrary/github.com/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:19:32.845014
# Unit test for function find_template
def test_find_template():
    """Test for function find_template

    Entry point:
        find_template('repo-dir')

    Exit point:
        Relative path to project template

    Sample pseudo-test function:
        find_template('/Users/me/repo-dir')

    Expected result (in /Users/me/repo-dir):
        /Users/me/repo-dir/project_template
    """
    pass

# Generated at 2022-06-23 16:19:34.046639
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir=None)

# Generated at 2022-06-23 16:19:41.698374
# Unit test for function find_template
def test_find_template():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import exists
    from os import makedirs

    repo_dir = mkdtemp()
    cookiecutter_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    makedirs(cookiecutter_dir)

    assert(exists(cookiecutter_dir))

    result = find_template(repo_dir)
    assert(result == cookiecutter_dir)

    rmtree(repo_dir)

# Generated at 2022-06-23 16:19:46.536693
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.regression import path_test_data
    repo_dir = os.path.join(
        path_test_data('find_template', 'template_root'), 'tests_find_template'
    )
    repo_dir_contents = os.listdir(repo_dir)
    assert repo_dir_contents == ['fake_project', 'ignorethis', '{{cookiecutter.project_name}}']
    template_name = find_template(repo_dir)
    assert template_name == os.path.join(repo_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-23 16:19:52.563631
# Unit test for function find_template
def test_find_template():
    base_path = os.path.join(os.path.dirname(__file__), '..', 'tests', 'files')
    os.chdir(base_path)
    path = os.getcwd()

    repo_dir = os.path.join(path, 'fake-repo-tmpl')

    expected = os.path.join(repo_dir, 'cookiecutter-pypackage')

    assert find_template(repo_dir) == expected

# Generated at 2022-06-23 16:19:58.077634
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.getcwd(), 'testdir')
    os.mkdir(test_dir)
    os.mkdir(os.path.join(test_dir, 'cookiecutter'))
    assert find_template(test_dir) == os.path.join(os.getcwd(), test_dir, 'cookiecutter')

# Generated at 2022-06-23 16:20:06.284789
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo'))
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    # Test that it raises the right exception if it fails to find the template.
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-no-templated-dir'))
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        return True

# Generated at 2022-06-23 16:20:11.724904
# Unit test for function find_template
def test_find_template():
    """Handling of non-parameterized directory names in input."""
    # An expected Cookiecutter "project template" subdirectory is
    # non-parameterized.
    non_parameterized = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), 'non-parameterized'
    )
    project_template = find_template(non_parameterized)
    assert os.path.basename(project_template) == 'cookiecutter'

# Generated at 2022-06-23 16:20:18.075779
# Unit test for function find_template
def test_find_template():
    """
    Test function find_template.
    """
    base_path = os.path.dirname(os.path.abspath(__file__))
    find_template(os.path.normpath(base_path + '/fixtures/test-repo-pre/'))


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:20:20.871980
# Unit test for function find_template
def test_find_template():
    assert find_template('~/pontch/cookiecutter-pypackage') == '~/pontch/cookiecutter-pypackage/%cookiecutter.repo_name%'

# Generated at 2022-06-23 16:20:31.083527
# Unit test for function find_template
def test_find_template():
    # test_repo_dir = 'tests/test-data'
    # project_template = find_template(test_repo_dir)
    # assert project_template == os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')

    test_repo_dir = '/Users/nicholas/Documents/nicholas/projects/algorithms/merge_sort'
    project_template = find_template(test_repo_dir)
    assert project_template == os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:20:35.433878
# Unit test for function find_template
def test_find_template():
    """Find the parent directory, test that find_template successfully identifies the template."""
    repo_dir = 'test/test-repo'
    expected_template = 'test/test-repo/cookiecutter-pypackage'
    assert find_template(repo_dir) == expected_template

# Generated at 2022-06-23 16:20:46.071007
# Unit test for function find_template
def test_find_template():
    """Validate the find_template function."""
    import io
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

    try:
        repo_dir = os.path.join(temp_dir, 'repo')
        os.makedirs(repo_dir)

        project_template_dir = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
        os.makedirs(project_template_dir)

        try:
            project_template = find_template(repo_dir)
        except NonTemplatedInputDirException:
            assert False

        assert '{{cookiecutter.project_name}}' in project_template
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-23 16:20:56.754619
# Unit test for function find_template
def test_find_template():
    """Test the find_template function
    """
    import shutil
    import tempfile

    template_directory = tempfile.mkdtemp()

# Generated at 2022-06-23 16:21:08.262154
# Unit test for function find_template
def test_find_template():
    """Make sure the function can find the template in a Cookiecutter repo."""
    import tempfile
    import shutil
    import os
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    dir_path = os.path.dirname(os.path.realpath(__file__))
    template_dir = os.path.join(dir_path, '..', 'tests', 'fake-repo-pre')

    repo_dir = tempfile.mkdtemp()
    logger.debug('Copying template directory to temporary directory...')
    shutil.copytree(template_dir, repo_dir)

    project_template = find_template(repo_dir)
    assert project_template, 'Project template was not found.'

# Generated at 2022-06-23 16:21:15.549990
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() finds Cookiecutter templates."""
    # import time
    # time.sleep(10)
    cc_dir = os.path.dirname(os.path.abspath(__file__))
    fixtures_dir = os.path.join(cc_dir, 'tests', 'fixtures')

    repo_dir = os.path.join(fixtures_dir, 'fake-repo')
    project_template = find_template(repo_dir)

    expected = os.path.join(repo_dir, 'fake-repo')

    assert project_template == expected

# Generated at 2022-06-23 16:21:27.439189
# Unit test for function find_template
def test_find_template():
    from cookiecutter import generate
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.utils import rmtree
    from tests.test_generate import TEST_DIR

    repo_dir = 'fake-repo'

    # Create the test repo
    generate.generate_files(
        repo_dir=repo_dir,
        context={'cookiecutter': {'repo_dir': repo_dir}}
    )

    # Test that a normal repo gets found
    project_template = find_template(repo_dir)
    assert project_template
    assert 'cookiecutter' in project_template

    # Test that a non-templated repo doesn't get found
    rmtree(repo_dir)

# Generated at 2022-06-23 16:21:37.059919
# Unit test for function find_template
def test_find_template():
    """Check that the project template is found under the current directory."""
    import os
    import tempfile

    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create a project template directory
    repo_dir = 'fake-repo'
    os.mkdir(repo_dir)
    os.chdir(repo_dir)
    os.mkdir('{{cookiecutter.repo_name}}')

    os.chdir(temp_dir)

    try:
        found_template = find_template(repo_dir)
    except NonTemplatedInputDirException:
        # Test should not find anything
        pass
    else:
        raise AssertionError(found_template)

    # Create a project template directory
    repo_dir = 'fake-repo'


# Generated at 2022-06-23 16:21:37.533487
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:21:48.402959
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os
    from cookiecutter import exceptions

    test_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(test_dir, 'repo'))

    open(os.path.join(test_dir, 'repo', 'file.txt'), 'a').close()
    open(os.path.join(test_dir, 'repo', 'cookiecutter.json'), 'a').close()
    open(os.path.join(test_dir, 'repo', '{{cookiecutter.repo_name}}'), 'a').close()
    template_dir = os.path.join(test_dir, 'repo', '{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:21:53.157750
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        'tests/test-input/{{cookiecutter.repo_name}}',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:56.672277
# Unit test for function find_template
def test_find_template():
    repo_dir = 'fake_repo_dir'
    repo_dir_contents = os.listdir(repo_dir)
    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    logger.debug('The project template appears to be %s', project_template)

# Generated at 2022-06-23 16:22:06.905825
# Unit test for function find_template
def test_find_template():
    from unittest import TestCase

    class TestFindTemplate(TestCase):
        def setUp(self):
            import tempfile
            import shutil
            self.test_dir = tempfile.mkdtemp()
            self.expected_result = os.path.join(
                self.test_dir,
                '{{cookiecutter.repo_name}}'
            )
            os.makedirs(self.expected_result)
            self.expected_result = os.path.abspath(self.expected_result)
            self.cc_pkg_dir = os.path.join(
                self.test_dir,
                'test_cookiecutter'
            )
            os.makedirs(self.cc_pkg_dir)


# Generated at 2022-06-23 16:22:15.766969
# Unit test for function find_template
def test_find_template():
    # Create mock directory contents
    os.mkdir('temp')
    with open('temp/foo', 'w') as f:
        f.write('foo')
    with open('temp/bar', 'w') as f:
        f.write('bar')
    with open('temp/cookiecutter', 'w') as f:
        f.write('cookie')
    with open('temp/cookiecutterdog', 'w') as f:
        f.write('dog')
    with open('temp/cookiecutter{{cookie}}', 'w') as f:
        f.write('dog')

    repo_dir = 'temp'
    
    assert find_template(repo_dir) == 'temp/cookiecutter{{cookie}}'

    # Tidy up mock directory contents
    os.remove('temp/foo')