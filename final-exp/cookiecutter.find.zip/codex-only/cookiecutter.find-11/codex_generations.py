

# Generated at 2022-06-23 16:12:25.106473
# Unit test for function find_template
def test_find_template():
    """Find the template directory in a local repo."""
    import vcr
    from cookiecutter.main import cookiecutter

    with vcr.use_cassette('tests/fixtures/vcr_cassettes/test_find_template.yaml'):
        cookiecutter('https://github.com/audreyr/cookiecutter-pypackage', no_input=True)


#     imports = [
#         'Bio',
#         'Bio.PDB',
#         'Bio.KDTree',
#         'Bio.pairwise2',
#         'Bio.pairwise2.align',
#         'Bio.Data.IUPACData'
#     ]

#     for imp in imports:
#         try:
#             __import__(imp)
#         except ImportError:
#             raise

# Generated at 2022-06-23 16:12:35.144896
# Unit test for function find_template
def test_find_template():
    """Test find_template()"""
    template_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'fake-repo-tmpl')
    # Expand user home
    template_dir = os.path.expanduser(template_dir)
    logger.info('template_dir = %s', template_dir)
    repo_dir = os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    logger.info('repo_dir = %s', repo_dir)
    project_template = find_template(repo_dir)
    logger.info('project_template = %s', project_template)
    # Should be /full/path/to/cookiecutter-fake-repo/{{cookiecutter.repo_

# Generated at 2022-06-23 16:12:44.853853
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works."""
    from .compat import TemporaryDirectory
    from .main import cookiecutter

    with TemporaryDirectory(prefix='cookiecutter-') as template_dir:
        context = cookiecutter(
            repo_dir=template_dir,
            extra_context={'full_name': 'Johannes "Hans" Bach'}
        )
        full_name = context['full_name']
        assert full_name == 'Johannes "Hans" Bach'
        template_dir_contents = os.listdir(template_dir)
        assert 'cookiecutter-{{cookiecutter.repo_name}}' in template_dir_contents

# Generated at 2022-06-23 16:12:54.927056
# Unit test for function find_template
def test_find_template():
    """Test find_template function from `utils`.
    """
    from cookiecutter.utils import find_template
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = 'tests/test-find-template'
    project_template = 'tests/test-find-template/{{cookiecutter.project_name}}'

    assert find_template(repo_dir) == project_template

    repo_dir = 'tests/fake-repo'
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

# Generated at 2022-06-23 16:13:04.012078
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    current_path = os.path.dirname(os.path.abspath(__file__))
    test_path = os.path.abspath(os.path.join(current_path, '..', '..', 'tests'))
    test_repo = os.path.join(test_path, 'test-repo')
    clone_path = utils.make_sure_path_exists('/tmp/cookiecutter-repo-test')
    utils.rmtree(clone_path)
    utils.copy_into(test_repo, clone_path)

    template_path = find_template(clone_path)


# Generated at 2022-06-23 16:13:12.328741
# Unit test for function find_template
def test_find_template():
    fake_repo_dir = '/home/audreyr/projects/fake'

    os.listdir = lambda x: []
    # no cookiecutter in repo_dir_contents nor any other items containing
    # '{{' and '}}', should raise exception
    os.path.exists = lambda x: True
    os.path.isfile = lambda x: False
    os.path.isdir = lambda x: True

# Generated at 2022-06-23 16:13:13.255634
# Unit test for function find_template
def test_find_template():
    print("test")

test_find_template()

# Generated at 2022-06-23 16:13:18.318818
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '../tests/test-repo-pre/',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:21.072160
# Unit test for function find_template
def test_find_template():
    path = '/home/user/project_template'
    template = find_template(path)
    assert template == path

# Generated at 2022-06-23 16:13:24.215500
# Unit test for function find_template
def test_find_template():
    template_path = find_template('tests/fake-repo-pre/')
    expected_template_path = 'tests/fake-repo-pre/{{cookiecutter.project_slug}}'
    assert template_path == expected_template_path



# Generated at 2022-06-23 16:13:29.740394
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-find-template'
    )
    assert find_template(test_dir) == os.path.join(
        test_dir, '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:13:37.795438
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_find import rmdir
    from tempfile import mkdtemp
    from shutil import rmtree
    import os

    input_dir = mkdtemp()
    os.makedirs(os.path.join(input_dir, '{{cookiecutter.repo_name}}'))
    assert find_template(input_dir) == os.path.join(
        input_dir, '{{cookiecutter.repo_name}}')

#     rmtree(input_dir)

#     input_dir = mkdtemp()
#     with pytest.raises(NonTemplatedInputDirException):
#         find_template(input_dir)

#     rmtree(input_dir)

# Generated at 2022-06-23 16:13:41.231930
# Unit test for function find_template
def test_find_template():
    """Test to check if it can find the project template"""
    from cookiecutter import utils
    from cookiecutter.main import cookiecutter

    context = cookiecutter('tests/fake-repo')

    assert context['project_name'] == 'Cookiecutter Django'
    assert context['repo_name'] == 'cookiecutter-django'


# Generated at 2022-06-23 16:13:45.748717
# Unit test for function find_template
def test_find_template():
    """Test the find_template method."""
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:46.250468
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:13:51.293943
# Unit test for function find_template
def test_find_template():
    """Validate function against known values."""
    input_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-fixtures',
        'test-repo'
    )

    result = find_template(input_dir)

    assert result == os.path.join(input_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:52.455771
# Unit test for function find_template
def test_find_template():
    assert(find_template("TestDir"))

# Generated at 2022-06-23 16:14:00.488490
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    # 1. Find the template when it is in a subdir
    assert ('fixtures/fake-repo-pre/{{cookiecutter.repo_name}}'
            == find_template('fixtures/fake-repo-pre'))

    # 2. Raise exception when no template dir found
    try:
        find_template('fixtures/fake-repo-no-template')
    except NonTemplatedInputDirException:
        assert 'Exception raised' == 'Exception raised'

# Generated at 2022-06-23 16:14:02.091817
# Unit test for function find_template
def test_find_template():
    # TODO: Add file fixtures to repo module
    pass

# Generated at 2022-06-23 16:14:05.949552
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    assert 'onion' in find_template(repo_dir)


# Generated at 2022-06-23 16:14:07.852697
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/features/my-repo') == 'tests/features/my-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:14:16.644058
# Unit test for function find_template
def test_find_template():
    """Verify the project template is found correctly."""
    import tempfile
    import shutil

    template_folder_name = 'fake-repo-templated'

    template_folder_path = os.path.join( tempfile.gettempdir(),
                                         template_folder_name )
    pre_existing_file = os.path.join( template_folder_path, 'pre-existing-file.txt' )
    expected_template_filename = '{{cookiecutter.repo_name}}'
    path_to_expected_template = os.path.join( template_folder_path,
                                              expected_template_filename )

    os.mkdir( template_folder_path )
    os.mkdir( path_to_expected_template )
    open( pre_existing_file, 'a' ).close()

    actual

# Generated at 2022-06-23 16:14:17.243627
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:27.416149
# Unit test for function find_template
def test_find_template():
    """Test for verifying that the `find_template` function is working.

    Create a fake directory, then use the `find_template` function on it to
    verify that it returns the correct value.
    """
    import tempfile
    from shutil import rmtree

    # Creating the temporary directory and its contents
    # The child directory is named 'cookiecutter-{{cookiecutter.username}}'
    tmp_dir = tempfile.mkdtemp()
    tmp_child_dir1 = os.path.join(tmp_dir, 'cookiecutter-temp-child-dir1')
    tmp_child_dir2 = os.path.join(
        tmp_dir, 'cookiecutter-temp-child-dir2-{{cookiecutter.username}}')

# Generated at 2022-06-23 16:14:35.163271
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = os.listdir('tests/fake-repo-tmpl')
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break
    repo_dir = 'tests/fake-repo-tmpl'
    assert find_template('tests/fake-repo-tmpl') == os.path.join(repo_dir, project_template)

# Generated at 2022-06-23 16:14:44.852601
# Unit test for function find_template
def test_find_template():
    """
    Tests that the function `find_template` is able to find the project template in the
    specified directory.
    """
    # Repo directories
    tests_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.normpath(os.path.join(tests_dir, '..', 'fake-repo'))

    # Cookiecutter template dir name
    cookiecutter_template = os.path.join(repo_dir, 'project_template')

    # Test finding the cookiecutter template
    cookiecutter_template_found = find_template(repo_dir)

    # Check that function worked
    assert cookiecutter_template_found == cookiecutter_template

# Generated at 2022-06-23 16:14:51.222254
# Unit test for function find_template
def test_find_template():
    """Ensures find_template() returns the correct path to the project template."""
    import test_utils
    import shutil

    # Create a temporary clone of the directory of this very project
    repo_dir = test_utils.temp_dir()
    shutil.copytree('.', repo_dir)

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Clean up temporary dir
    shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:15:01.768599
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works properly."""
    from cookiecutter.utils import rmtree

    import py
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    parent_dir = os.path.join(tmpdir, 'fake-repo')
    os.makedirs(parent_dir)

    # Create the following directory structure:
    # parent_dir/
    # ├── cc_file
    # ├── cc_folder
    # │   └── cc_file
    # ├── some_file
    # ├── some_folder
    # │   └── template_file
    # └── some_folder_2
    #     └── {{cookiecutter.repo_name}}
    #         ├── cc_file
    #         └── cc_folder
    #

# Generated at 2022-06-23 16:15:04.038729
# Unit test for function find_template
def test_find_template():
    find_template('/Users/macbookair/swisstxt/cookiecutter-basics/tests/test_repo')

# Generated at 2022-06-23 16:15:09.628547
# Unit test for function find_template
def test_find_template():
    """Tests find_template function."""
    find_template('~/cookiecutters/cookiecutter-pypackage')


# def find_dir(dir):
#     """
#     TODO: Add tests.
#     """
#     return os.path.isdir(dir)


# def find_file(file):
#     """
#     TODO: Add tests.
#     """
#     return os.path.isfile(file)

# Generated at 2022-06-23 16:15:20.748678
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from . import tempdir
    from . import _JINJA_ENV

    tmpl_dir, tmpl_name = 'dummy', 'cookiecutter-dummy'
    with tempdir.in_tempdir():
        tmpl_dir = os.path.join(os.path.abspath('.'), tmpl_dir)
        tmpl_name = os.path.join(os.path.abspath('.'), tmpl_name)
        os.makedirs('dummy')
        os.makedirs('cookiecutter-dummy')

        tmpl_dir = find_template(tmpl_dir)
        assert tmpl_dir == tmpl_name

        # Test NonTemplatedInputDirException

# Generated at 2022-06-23 16:15:21.627197
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:15:27.166116
# Unit test for function find_template
def test_find_template():
    """Test expected behavior of find_template function."""
    # Setup
    repo_dir = 'tests/files/fake-repo'
    expected_template = os.path.join(repo_dir, 'fake-{{cookiecutter.repo_name}}-template')

    # Run function under test and verify result
    assert expected_template == find_template(repo_dir)

# Generated at 2022-06-23 16:15:31.884159
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test-find-template')
    )
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:15:37.026801
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_dir')
    project_template = find_template(test_dir)
    correct_template = os.path.join(test_dir, 'cookiecutter-{{ cookiecutter.repo_name }}')
    assert project_template == correct_template

# Generated at 2022-06-23 16:15:44.896307
# Unit test for function find_template
def test_find_template():
    """Test to verify the correct template directory is returned."""

    test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'repos', 'tests')
    repo_dir_contents = os.listdir(test_dir)
    logging.disable(logging.WARNING)
    project_template = find_template(test_dir)
    logging.disable(logging.NOTSET)
    assert 't.{{cookiecutter.repo_name}}' in project_template

# Generated at 2022-06-23 16:15:51.859405
# Unit test for function find_template
def test_find_template():
    this_dir = os.path.abspath(os.path.dirname(__file__))
    test_dir = os.path.join(this_dir, 'test-find-template')
    template_dir = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)
    expected = template_dir
    found = find_template(test_dir)
    assert expected == found

# Generated at 2022-06-23 16:16:01.741482
# Unit test for function find_template
def test_find_template():
    """Test function `find_template`."""
    from tempfile import mkdtemp
    from shutil import rmtree
    from cookiecutter import main

    # create a temp directory to be used as fake repo root
    repo_dir = mkdtemp()

    # create a cookiecutter.json file in the fake repo
    main.cookiecutter(
        'tests/fake-repo-pre/',
        no_input=True,
        output_dir=repo_dir
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-pre')

    rmtree(repo_dir)

# Generated at 2022-06-23 16:16:06.489306
# Unit test for function find_template
def test_find_template():
    """Verify function returns expected results."""
    import os
    import shutil
    import tempfile

    expected_project_template = 'foo'
    repo_dir = tempfile.mkdtemp()
    project_template_dir = os.path.join(repo_dir, 'bar', expected_project_template)
    os.makedirs(project_template_dir)

    found_project_template = find_template(repo_dir)

    assert found_project_template == project_template_dir
    shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:16:13.807868
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo'
    )
    expected_project_template = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    project_template = find_template(repo_dir)

    if project_template != expected_project_template:
        raise ValueError('Project template returned from function was not expected value.')

# Generated at 2022-06-23 16:16:16.778937
# Unit test for function find_template
def test_find_template():
    find_template('../tests/fake-repo-tmpl')
    #TODO: Make this test more robust. Need to ensure the only directory
    # that has {{ and }} in it is the one found.

# Generated at 2022-06-23 16:16:20.114089
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir='tests/fake-repo-pre/')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:16:25.290715
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/foo/code/cookiecutter-foobar'
    repo_dir_contents = ['README.md', 'cookiecutter-foobar', 'hooks', '.git']

    assert find_template(repo_dir) == repo_dir + '/cookiecutter-foobar'

# Generated at 2022-06-23 16:16:31.464788
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.getcwd(),
        'tests',
        'fake-repo-pre-commit-hook',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:16:31.892693
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:37.800584
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works as expected."""
    from cookiecutter.tests.test_utils import make_empty_template_repo
    template_repo_dir = make_empty_template_repo()
    assert find_template(template_repo_dir) == os.path.join(
        template_repo_dir, 'my_cool_project'
    )

# Generated at 2022-06-23 16:16:44.838590
# Unit test for function find_template
def test_find_template():
    """
    Test for function find_template
    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """

    from unittest.mock import MagicMock

    mock = MagicMock()
    mock.listdir = MagicMock(return_value=['cookiecutter'])
    test_find_template = find_template('cookiecutter')
    mock.assert_called_once_with('cookiecutter')
    assert test_find_template == 'cookiecutter/cookiecutter'

# Generated at 2022-06-23 16:16:55.114899
# Unit test for function find_template
def test_find_template():
    """Verify normal behavior of find_template."""
    # Create a test directory that mimics what a cookiecutter repo clone
    # would look like
    tmp_dir = tempfile.mkdtemp()
    cookiecutter_json = os.path.join(tmp_dir, 'cookiecutter.json')
    with open(cookiecutter_json, 'w') as fh:
        fh.write('{"cookiecutter_dir": "{{cookiecutter.repo_name}}"}')
    # Need to create the cookiecutter directory for the test to work.
    os.makedirs(os.path.join(tmp_dir, '{{cookiecutter.repo_name}}'))


# Generated at 2022-06-23 16:16:57.746921
# Unit test for function find_template
def test_find_template():
    repo_dir= '.'
    result=find_template(repo_dir)
    assert result=='/Users/michaely/Desktop/cookiecutter-bigdata/{{cookiecutter.project_slug}}'




# Generated at 2022-06-23 16:17:05.164972
# Unit test for function find_template
def test_find_template():
    """Verify that function find_template handles bad input and finds template."""
    from cookiecutter import utils
    fixtures = os.path.join(os.path.dirname(__file__), 'fixtures')
    template = os.path.join(fixtures, 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    empty_repo = os.path.join(fixtures, 'empty_repo')

    # Test for non-existent directory
    try:
        utils.find_template('/path/does/not/exist')
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError("Expected NonTemplatedInputDirException")

    # Test for empty directory

# Generated at 2022-06-23 16:17:07.547007
# Unit test for function find_template
def test_find_template():
    """Find template function"""
    find_template(repo_dir)

# Generated at 2022-06-23 16:17:13.077673
# Unit test for function find_template
def test_find_template():
    here = os.path.abspath(os.path.dirname(__file__))
    fake_repo = os.path.join(here, 'fake-repo')

    template_dir = find_template(fake_repo)
    template_name = os.path.basename(template_dir)
    assert template_name == 'fake-project-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:13.638924
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:17:21.133642
# Unit test for function find_template
def test_find_template():
    """Example test to show how to write unit tests."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    )
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert find_template(repo_dir) == expected, (
        'find_template should return absolute path to the project template.'
    )

# Generated at 2022-06-23 16:17:29.656806
# Unit test for function find_template
def test_find_template():
    # create a simple cookiecutter directory structure to test find_template
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    cookiecutter_dir = os.path.join(temp_dir, 'cookiecutter-test-repo')
    os.mkdir(cookiecutter_dir)

    template_name = '{{cookiecutter.repo_name}}'
    cookiecutter_template = os.path.join(cookiecutter_dir, template_name)
    os.mkdir(cookiecutter_template)

    non_template_name = 'non-template'
    non_cookiecutter_template = os.path.join(cookiecutter_dir, non_template_name)
    os.mkdir(non_cookiecutter_template)

    # test function with known cookiecut

# Generated at 2022-06-23 16:17:30.156713
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:17:33.067207
# Unit test for function find_template
def test_find_template():
    assert find_template('test_cookiecutters/test_template/') == \
        os.path.join('test_cookiecutters/test_template/', '{{cookiecutter.project_name}}')
    assert find_template('test_cookiecutters/test_template_nested') == \
        os.path.join('test_cookiecutters/', '{{cookiecutter.project_name}}')

# Generated at 2022-06-23 16:17:41.179141
# Unit test for function find_template
def test_find_template():
    def mock_isfile(self):
        pass

    def mock_listdir(self):
        pass

    from unittest import TestCase
    import mock

    class TestFindTemplateFunction(TestCase):

        cookiecutter_dir = 'fake-dir'

        def test_find_template_when_template_is_in_input_dir(self):
            os.listdir = mock.Mock(return_value=["cookiecutter-extra-foobar"])
            os.path.isfile = mock.Mock(return_value=False)
            template = find_template('fake-dir')
            self.assertEqual(
                template,
                os.path.join(self.cookiecutter_dir, 'cookiecutter-extra-foobar')
            )


# Generated at 2022-06-23 16:17:52.939955
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    utils.work_in(
        ['tests', 'test-find-template'],
        remove_repo_dir_on_exit=False,
        print_debug=False
    )
    assert find_template(os.getcwd()) == 'tests/test-find-template/{{cookiecutter.repo_name}}'
    shutil.rmtree('tests/test-find-template')

    # The following test should raise an exception, if one isn't raised then
    # the test will fail.

# Generated at 2022-06-23 16:18:04.194779
# Unit test for function find_template
def test_find_template():
    import tempfile

    # make empty directory
    temp_dir = tempfile.mkdtemp()

    # create empty file
    temp_file = tempfile.NamedTemporaryFile(suffix='.txt', dir=temp_dir, delete=False)
    temp_file.close()

    # create file with cookiecutter in name, but no {{ or }}
    temp_file = tempfile.NamedTemporaryFile(suffix='cookiecutter.txt', dir=temp_dir, delete=False)
    temp_file.close()

    # create file with cookiecutter in name, but only one {{ or }}
    temp_file = tempfile.NamedTemporaryFile(suffix='cookiecutter{}.txt', dir=temp_dir, delete=False)
    temp_file.close()

    # create file with cookiecutter in name

# Generated at 2022-06-23 16:18:13.930244
# Unit test for function find_template
def test_find_template():
    """
    Test that find_template correctly finds a template directory.
    """
    from cookiecutter import utils
    from cookiecutter import exceptions

    repo_dir = utils.project.get_abs_path(
        os.path.join('tests', 'test-repo', 'bake-a-cake')
    )
    assert find_template(repo_dir) == repo_dir

    try:
        find_template(repo_dir=os.path.join('tests', 'test-repo'))
    except exceptions.NonTemplatedInputDirException:
        pass
    else:
        raise Exception('find_template should have thrown an exception.')

# Generated at 2022-06-23 16:18:16.714120
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/fake-repo-pre'
    project_temp = find_template(repo_dir)
    assert project_temp == './tests/fake-repo-pre/fake-project', project_temp


# Generated at 2022-06-23 16:18:21.869454
# Unit test for function find_template
def test_find_template():
    input_dir = '/Users/audreyr/cookiecutter-pypackage'  # noqa
    project_template = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'  # noqa

    assert find_template(input_dir) == project_template

# Generated at 2022-06-23 16:18:31.031166
# Unit test for function find_template
def test_find_template(): 
    """Unit test for function find_template."""
    # Here, repo_dir is a directory located within the system.
    repo_dir = "/Users/user/cookiecutter/cookiecutter"
    # Here, project_template is a file in repo_dir.
    project_template = "cookiecutter.json"
    # Below is the expected output of function find_template.
    expected_result = "/Users/user/cookiecutter/cookiecutter/cookiecutter.json"
    # The assert statement asserts that the value of find_template is equal to the expected output.
    assert find_template(repo_dir) == expected_result

# Generated at 2022-06-23 16:18:33.238903
# Unit test for function find_template
def test_find_template():
    """Test the success and failure of find_template."""
    pass

# Generated at 2022-06-23 16:18:36.407328
# Unit test for function find_template
def test_find_template():
    repo_dir = '{{cookiecutter.repo_name}}'
    repo_dir = find_template(repo_dir)
    assert repo_dir == '{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:18:39.362258
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/cookiecutter-pypackage') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:18:46.367773
# Unit test for function find_template
def test_find_template():
    temp_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'files')
    )
    template_found = find_template(temp_dir)
    template_expected = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    assert template_found == template_expected

# Generated at 2022-06-23 16:18:53.073054
# Unit test for function find_template
def test_find_template():
	"""
	Test that the find_template function returns the correct relative path to the project template.
	"""
	test_repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-input', 'cookiecutter-pypackage')
	expected_template = os.path.join('repo_dir', '{{cookiecutter.repo_name}}')
	assert(find_template == expected_template)

# Generated at 2022-06-23 16:18:57.586584
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    repo_dir = './tests/test-input/{{cookiecutter.template_name}}'
    project_template = find_template(repo_dir)


# Generated at 2022-06-23 16:18:59.661090
# Unit test for function find_template
def test_find_template():
    find_template('/Users/mglantz1/Desktop/Cookiecutter/cookiecutter-python/cookiecutter-pypackage/')

# Generated at 2022-06-23 16:19:01.074499
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:19:05.822662
# Unit test for function find_template
def test_find_template():
    test_dir = '/Users/johndoe/cookiecutter/test/test-repo-tmpl/'
    template = find_template(test_dir)
    assert template == '/Users/johndoe/cookiecutter/test/test-repo-tmpl/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:19:11.889021
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    current_dir = os.path.abspath(os.path.dirname(__file__))
    example_repo = os.path.join(current_dir, 'tests/big-repo-example')

    template = find_template(example_repo)
    assert template == os.path.join(example_repo, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:19:21.179254
# Unit test for function find_template
def test_find_template():
    import tempfile
    # tempdir = tempfile.mkdtemp()
    tempdir = 'D:\\test_dir'
    os.mkdir(tempdir)
    tempdir = os.path.dirname(tempdir)
    cookiecutter_dir = os.path.join(tempdir, 'cookiecutter-pypackage')
    os.mkdir(cookiecutter_dir)
    os.mkdir(os.path.join(cookiecutter_dir, '{{cookiecutter.repo_name}}'))
    project_template = find_template(cookiecutter_dir)
    assert (project_template == os.path.join(cookiecutter_dir,
                                             '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-23 16:19:32.984360
# Unit test for function find_template
def test_find_template():
    import cookiecutter.prompt as prompt

    # Test the case where we have a templated input_dir
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    )
    prompt.read_user_variable = lambda var, default: default
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test the case where we have a non-templated input_dir
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    )
    assert find

# Generated at 2022-06-23 16:19:39.663831
# Unit test for function find_template
def test_find_template():
    templates_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-templates',
        'test-templates'
    ))
    assert find_template(templates_dir) == os.path.join(
        templates_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:19:40.879806
# Unit test for function find_template
def test_find_template():
    find_template('tests/fake-repo-tmpl/')

# Generated at 2022-06-23 16:19:41.737025
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-23 16:19:48.006592
# Unit test for function find_template
def test_find_template():
    """Test the return value of find_template."""
    from .utils import TEST_COOKIE_DIR
    template = find_template(TEST_COOKIE_DIR)
    assert template == os.path.join(TEST_COOKIE_DIR, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:19:54.435323
# Unit test for function find_template
def test_find_template():
    """Find cookiecutter.json in the root."""
    actual = find_template('tests/fake-repo-pre/',)
    expected = os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert actual == expected

    actual = find_template('tests/fake-repo-pre/')
    expected = os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert actual == expected

# Generated at 2022-06-23 16:20:02.898244
# Unit test for function find_template
def test_find_template():
    """Verify the find_template() function."""
    import shutil
    import tempfile
    import unittest

    from cookiecutter import exceptions

    class TestFindTemplate(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.template_dir = os.path.join(self.test_dir, 'hello-world2')
            os.makedirs(self.template_dir)

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_find_template(self):
            """Verify find_template() can find templates."""
            output = find_template(self.test_dir)
            self.assertEqual(output, self.template_dir)


# Generated at 2022-06-23 16:20:09.590689
# Unit test for function find_template
def test_find_template():
    """Returns the template dir name for a directory if there are several
    directories
    """

    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test-find-template'
    )

    assert find_template(repo_dir=repo_dir) == os.path.join(
        repo_dir,
        'repo-name/{{cookiecutter.repo_name}}'
    )

#TODO: Unit test for function find_template

# Generated at 2022-06-23 16:20:17.657537
# Unit test for function find_template
def test_find_template():
    """
    A helper function for testing `find_template` function
    """
    # TODO: use a datadir similar to that used in tests/test_cli.py
    # TODO: this test is sensitive to the directory *name*, e.g.
    # 'cookiecutter-foo', which is not ideal, but I'm not sure how to do
    # better without relying on `mkdtemp`.
    tmpls_dir = os.path.join(os.path.dirname(__file__), "test-tmpls")
    repo = os.path.join(tmpls_dir, "test-repo", "{{cookiecutter.repo}}")
    tmpl = os.path.join(tmpls_dir, "test-repo", "cookiecutter-{{cookiecutter.repo}}")

# Generated at 2022-06-23 16:20:25.872616
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir_contents = os.listdir(temp_dir)
        PATTERN = 'cookiecutter-test'
        if 'foo' + PATTERN + 'bar' not in temp_dir_contents:
            os.mkdir(os.path.join(temp_dir, 'foo' + PATTERN + 'bar'))
        if 'foo' + PATTERN + 'baz' not in temp_dir_contents:
            os.mkdir(os.path.join(temp_dir, 'foo' + PATTERN + 'baz'))

        logger.debug('temp_dir: %s', temp_dir)
        logger.debug('temp_dir_contents: %s', temp_dir_contents)

        project

# Generated at 2022-06-23 16:20:35.023823
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test with explicit template
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'
    ))
    utils.find_template(repo_dir)

    # Test with implicit template
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo'
    ))
    utils.find_template(repo_dir)

    # Test with no template

# Generated at 2022-06-23 16:20:39.509179
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/code/cookiecutter-pypackage') == '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:45.158509
# Unit test for function find_template
def test_find_template():
    """Verify that the correct template is identified."""

    import tempfile

    d = tempfile.mkdtemp()
    os.mkdir(os.path.join(d, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(d, 'cookiecutter-{{foo}}'))

    assert 'cookiecutter-{{foo}}' == os.path.basename(find_template(d))

# Generated at 2022-06-23 16:20:48.247623
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-tmpl/') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:55.375123
# Unit test for function find_template
def test_find_template():
    import os
    import tempfile
    import shutil

    tmp_dir_name = tempfile.mkdtemp()
    template_dir = os.path.join(tmp_dir_name, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    found_template_dir = find_template(tmp_dir_name)

    assert found_template_dir == template_dir

    # Clean up
    shutil.rmtree(tmp_dir_name)

# Generated at 2022-06-23 16:21:02.279969
# Unit test for function find_template
def test_find_template():
    """If the directory layout is correct it will return the right folder."""
    import tempfile
    test_dir = tempfile.TemporaryDirectory()
    test_dir_path = test_dir.name
    os.makedirs(os.path.join(test_dir_path, 'foo/{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(test_dir_path, 'foo/{{cookiecutter.repo_name}}/bar'))
    os.makedirs(os.path.join(test_dir_path, 'foo/{{cookiecutter.repo_name}}/baz'))
    os.makedirs(os.path.join(test_dir_path, 'foo/{{cookiecutter.repo_name}}/qux/quux'))


# Generated at 2022-06-23 16:21:07.131733
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    branch_tmpl = find_template(os.getcwd())
    assert branch_tmpl == os.path.abspath('fake-repo/{{cookiecutter.repo_name}}/')

# Generated at 2022-06-23 16:21:12.726408
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    repo_dir = os.path.join(repo_dir, 'tests', 'fake-repo')

    project_template = find_template(repo_dir)
    assert project_template.endswith('cookiecutter-pypackage')

# Generated at 2022-06-23 16:21:15.357597
# Unit test for function find_template
def test_find_template():
    """Function for testing find_template"""
    assert find_template('/home/audreyr/cookiecutter-pypackage') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:21:25.449387
# Unit test for function find_template
def test_find_template():
    import pytest

    # test happy path
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    assert find_template(repo_dir) == os.path.join(
        os.path.dirname(__file__), 'fake-repo', '{{cookiecutter.repo_name}}'
    )
    # test exception case
    with pytest.raises(NonTemplatedInputDirException):
        repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-no-context')
        find_template(repo_dir)

# Generated at 2022-06-23 16:21:34.558751
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter import main

    user_config = main.get_user_config()
    original_dir = os.getcwd()

# Generated at 2022-06-23 16:21:39.523046
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test_find_template'
    )

    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:42.982028
# Unit test for function find_template
def test_find_template():
    repo_dir = '/scratch/cookiecutter_repos/django-cookiecutter-1.5.0/'
    project_template = find_template(repo_dir)

test_find_template()

# Generated at 2022-06-23 16:21:47.745755
# Unit test for function find_template
def test_find_template():
    import pytest
    with pytest.raises(NonTemplatedInputDirException):
        find_template('tests/fake-repo-pre/')
    assert find_template('tests/fake-repo-pre-master/') == \
            'tests/fake-repo-pre-master/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:54.341718
# Unit test for function find_template
def test_find_template():
    """Test find template."""
    from cookiecutter.main import cookiecutter

    template = cookiecutter(
        'tests/test-repo-pre/', 'fixtures/fake-repo-tmpl', no_input=True,
        overwrite_if_exists=True
    )

    assert template == 'fixtures/fake-repo-tmpl'
    assert os.path.exists(template) is True

# Generated at 2022-06-23 16:22:04.822970
# Unit test for function find_template
def test_find_template():
    """
    Verify that find_template() returns the correct value.
    """
    assert find_template('tests/test-repo-pre/') == \
        os.path.abspath('tests/test-repo-pre/cookiecutter-pypackage/')
    assert find_template('tests/test-repo-pre/tests/test-repo-pre') == \
        os.path.abspath('tests/test-repo-pre/tests/test-repo-pre/cookiecutter-pypackage/')
    assert find_template('tests/test-repo-pre/tests/fake') == \
        os.path.abspath('tests/test-repo-pre/tests/fake/cookiecutter-pypackage-master/')

# Generated at 2022-06-23 16:22:07.915324
# Unit test for function find_template
def test_find_template():
    project_template = find_template('/Users/Plateau/Desktop/wiking-master/')
    assert project_template == "/Users/Plateau/Desktop/wiking-master/{{cookiecutter.project_slug}}"

# Generated at 2022-06-23 16:22:12.202039
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-templates',
        'test_template_repo'
    )

    assert 'test_template' in find_template(test_dir)

# Generated at 2022-06-23 16:22:22.062889
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns relative path to project template."""
    repo = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo')
    assert find_template(repo) == os.path.join(repo, '{{cookiecutter.repo_name}}')

    # Test that it raises exception if template is missing
    repo = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-missing-template')
    try:
        find_template(repo)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False