

# Generated at 2022-06-23 16:12:20.944378
# Unit test for function find_template
def test_find_template():
    result = find_template('tests/test-find-template')
    expected = ('tests/test-find-template/{{cookiecutter.repo_name}}')
    assert result == expected



# Generated at 2022-06-23 16:12:23.802247
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-find-template/cookiecutter-django'
    assert find_template(repo_dir) == 'tests/test-find-template/cookiecutter-django/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:12:32.630006
# Unit test for function find_template
def test_find_template():
    """Test ``find_template`` function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = make_repo()
    try:
        assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

        with TemporaryDirectory() as td:
            assert find_template(td) == os.path.join(td, '.')
    except NonTemplatedInputDirException:
        raise NonTemplatedInputDirException

# Generated at 2022-06-23 16:12:41.017045
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    from . import utils
    from .exceptions import NonTemplatedInputDirException
    from .exceptions import NonTemplatedInputDirException

    tests_dir = utils.root_dir()
    fixtures_dir = os.path.abspath(os.path.join(tests_dir, 'fixtures'))

    # Test the happy path.
    repo_dir = os.path.join(fixtures_dir, 'unicode-repo')
    assert find_template(repo_dir).endswith('fake-repo-tmpl'), find_template(repo_dir)

    # Test that an exception is thrown when there is no project template.
    repo_dir = os.path.join(fixtures_dir, 'fake-repo-no-project-tmpl')


# Generated at 2022-06-23 16:12:43.168345
# Unit test for function find_template
def test_find_template():
    """Test the find template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(repo_dir, 'fake_template')
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:12:48.166288
# Unit test for function find_template
def test_find_template():
    repo_dir = "/Users/saebyul/projects/Cookiecutter/cookiecutter/"
    assert find_template(repo_dir) == "/Users/saebyul/projects/Cookiecutter/cookiecutter/{{cookiecutter.repo_name}}"

# Generated at 2022-06-23 16:12:53.591677
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works correctly."""
    repo_dir = os.path.abspath(os.path.join('tests', 'fake-repo'))
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-23 16:12:59.781480
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'fake-repo-pre-gen', '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    logger.debug('test_find_template passed')


# Generated at 2022-06-23 16:13:02.372696
# Unit test for function find_template
def test_find_template():
    assert 'cookiecutter-pypackage' == os.path.basename(find_template('tests/test-data/fake-repo-tmpl'))

# Generated at 2022-06-23 16:13:04.566043
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('examples/tests/fake-repo/')
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)

# Generated at 2022-06-23 16:13:11.357335
# Unit test for function find_template
def test_find_template():
    test_path = os.path.join(os.path.dirname(__file__), "..", "tests")
    test_path = os.path.abspath(test_path)
    expected_template = os.path.join(test_path, "fake-repo-pre/{{cookiecutter.repo_name}}")
    assert find_template(test_path) == expected_template

# Generated at 2022-06-23 16:13:15.672104
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fake-repo')
    assert find_template(repo_dir)


# Generated at 2022-06-23 16:13:16.501169
# Unit test for function find_template
def test_find_template():
    """Test that the repo directory is found.
    """

# Generated at 2022-06-23 16:13:19.764006
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.path.dirname(__file__), 'test-find-template')
    assert find_template(test_dir) == os.path.join(test_dir, 'cookiecutter-project')

# Generated at 2022-06-23 16:13:20.667155
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-23 16:13:23.735117
# Unit test for function find_template
def test_find_template():
    from tests.test_finders import REPO_DIR
    project_template = find_template(REPO_DIR)
    for item in ['cookiecutter', '{{', '}}', 'fake']:
        assert item in project_template

# Generated at 2022-06-23 16:13:28.178250
# Unit test for function find_template
def test_find_template():
    """Function test_find_template is the unit test for find_template"""
    assert(find_template('/tmp/cookiecutter-test-repo/') == '/tmp/cookiecutter-test-repo/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:31.714517
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template`.
    """

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_repo'
    )
    expected_project_template = os.path.join(
        repo_dir,
        'cookiecutter-pypackage'
    )
    project_template = find_template(repo_dir)

    assert project_template == expected_project_template

# Generated at 2022-06-23 16:13:40.811315
# Unit test for function find_template
def test_find_template():
    """Test function find_template from cookiecutter/find.py"""
    import tempfile
    repo_dir = tempfile.mkdtemp()

    # Test for non-templated directory
    os.rmdir(repo_dir)
    try:
        find_template(os.path.basename(repo_dir))
        assert False, 'find_template() did not raise exception'
    except NonTemplatedInputDirException:
        assert True

    # Test for templated directory
    os.mkdir(repo_dir)
    project_template = '{{ cookiecutter.project_name }}'
    os.mkdir(os.path.join(repo_dir, project_template))
    assert project_template == os.path.basename(find_template(repo_dir))

    # Clean up


# Generated at 2022-06-23 16:13:47.652568
# Unit test for function find_template
def test_find_template():
    """Verify that `find_template` returns the templated path."""
    from cookiecutter.tests.test_utils import make_empty_project_dir

    repo_dir = make_empty_project_dir('{{cookiecutter.repo_name}}')
    os.makedirs(os.path.join(repo_dir, 'tests'))

    created = find_template(repo_dir)

    assert created == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:51.414461
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join('tests', 'fake-repo-tmpl')
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:54.418648
# Unit test for function find_template
def test_find_template():
    """Test find_template() function."""
    find_template('/tmp/cookiecutter-pypackage')

# Generated at 2022-06-23 16:13:57.329933
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:14:05.546910
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    
    repo_dir = 'tests/fixtures/fake-repo'
    project_template = 'tests/fixtures/fake-repo/{{cookiecutter.repo_name}}'
    
    # Test that a repo_dir with the expected cookiecutter-related files in it
    # returns the expected project_template
    returned_project_template = find_template(repo_dir)
    assert(returned_project_template == project_template)

    # Test that a repo_dir without the expected cookiecutter-related files
    # raises the expected exception
    repo_dir = 'tests/fixtures/input/fake-repo-no-templated-files'
    NonTemplatedInputDirExceptionException = NonTemplatedInputDirException

# Generated at 2022-06-23 16:14:08.972635
# Unit test for function find_template
def test_find_template():
    from cookiecutter.operations import find_template
    import tempfile
    import os

    template_dir = os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')

    with tempfile.TemporaryDirectory() as tmpdir:
        assert find_template(tmpdir) == os.path.join(tmpdir, template_dir)

# Generated at 2022-06-23 16:14:14.114678
# Unit test for function find_template
def test_find_template():
    logging.basicConfig(level=logging.DEBUG)

    repo_dir = 'tests/fake-repo-pre/'
    assert find_template(repo_dir) == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    repo_dir = 'tests/fake-repo-post/'
    assert find_template(repo_dir) == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:14:16.099564
# Unit test for function find_template
def test_find_template():
    """Verify find_template() function."""
    find_template(repo_dir='tests/fake-repo-tmpl')

# Generated at 2022-06-23 16:14:22.082911
# Unit test for function find_template
def test_find_template():
    os.chdir('/Users/gz/Documents/Source/Python/Cookiecutter/cookiecutter/tests/test-generate')
    repo_dir = os.getcwd()

    import pdb
    pdb.set_trace()
    project_template = find_template(repo_dir)

# Generated at 2022-06-23 16:14:29.638168
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import pytest
    from .utils import make_repo
    from cookiecutter.exceptions import NonTemplatedInputDirException

    with make_repo('tests/test-find-template') as repo_dir:
        template = find_template(repo_dir)

        assert 'tests/test-find-template/fake' in template

        # Non-templated project should raise an exception
        with pytest.raises(NonTemplatedInputDirException):
            find_template('tests')

# Generated at 2022-06-23 16:14:38.549366
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    import shutil
    import tempfile
    import textwrap

    fh, repo_dir = tempfile.mkstemp()
    os.close(fh)

    repo_dir = os.path.abspath(repo_dir)


# Generated at 2022-06-23 16:14:41.014040
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:14:42.078983
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:51.372102
# Unit test for function find_template
def test_find_template():
    """Verify function for finding project templates."""
    from .compat import TemporaryDirectory
    from .repository import determine_repo_dir

    TEMPLATE_TEXT = (
        '# {{cookiecutter.repo_name}}\n'
        '\n'
        '{{cookiecutter.description}}\n'
    )

    with TemporaryDirectory() as tmpdir:
        repo_dir = tmpdir
        template_dir = os.path.join(repo_dir, 'cookiecutter-project-name')
        readme = os.path.join(template_dir, 'README.md')

        # Create the template dir
        os.mkdir(template_dir)

        # Create the template text

# Generated at 2022-06-23 16:14:56.119809
# Unit test for function find_template
def test_find_template():
    """Run tests for function find_template."""
    expected = '/Users/audreyr/cookiecutters/cookiecutter-pypackage'
    actual = find_template(
        '/Users/audreyr/cookiecutters'
    )

    assert actual == expected


# Generated at 2022-06-23 16:15:07.534978
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    test_dir = tempfile.mkdtemp()

    bad_path = os.path.join(test_dir, 'bad_path')
    os.makedirs(bad_path)

    assert not find_template(bad_path)

    good_path = os.path.join(test_dir, 'good_path')
    os.makedirs(good_path)

    # We're not defining this one in order to test the assert at the end
    # bad_template = os.path.join(good_path, 'bad_template')
    # os.makedirs(bad_template)

    good_template = os.path.join(good_path, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:15:13.715018
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    from cookiecutter import prompt
    from cookiecutter import generate

    context = prompt.prompt_for_config('tests/test-cookiecutter-repo/', {}, None)
    assert context['project_name'] == 'Cookiecutter Example'
    project_dir = generate.generate_files(
        repo_dir='tests/test-cookiecutter-repo/',
        context=context
    )
    assert project_dir == 'tests/test-cookiecutter-repo/{{cookiecutter.repo_name}}'

    project_dir_contents = os.listdir(project_dir)
    assert 'README.rst' in project_dir_contents
    assert 'setup.py' in project_dir_contents

# Generated at 2022-06-23 16:15:19.776346
# Unit test for function find_template
def test_find_template():
    abs_repo_dir = os.path.abspath('tests/test-repo')
    abs_project_template = os.path.join(abs_repo_dir, '{{cookiecutter.repo_name}}')

    assert abs_project_template == find_template(abs_repo_dir)

# Generated at 2022-06-23 16:15:27.314862
# Unit test for function find_template
def test_find_template():
    """Verify that `find_template` returns the expected value for the tests.

    Assumes the tests are run from the `tests` directory and that the tests
    use the standard Cookiecutter directory structure.
    """
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'test-template'
    )

    assert find_template(repo_dir) == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:15:32.723733
# Unit test for function find_template
def test_find_template():
    repo_dir = 'fake-repo'
    repo_dir_contents = ['something', 'cookiecutter-foobar', '{{cookiecutter.foobar}}']

    os.listdir = lambda x: repo_dir_contents

    expected_result = os.path.join(repo_dir, repo_dir_contents[2])

    assert(find_template(repo_dir) == expected_result)

# Generated at 2022-06-23 16:15:42.220484
# Unit test for function find_template
def test_find_template():
    """Test that the find_template() function works as expected."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.tests.test_replay import remove_tempdir

    tempdir = utils.workdir()
    repo_dir = os.path.join(tempdir, 'tests')
    os.mkdir(repo_dir)
    os.chdir(repo_dir)
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)


# Generated at 2022-06-23 16:15:45.189697
# Unit test for function find_template
def test_find_template():
    print("testing find_template")
    # Set up a temporary repo
    pass

# Generated at 2022-06-23 16:15:46.212297
# Unit test for function find_template
def test_find_template():
    find_template('test/test_repo')

# Generated at 2022-06-23 16:15:53.957071
# Unit test for function find_template
def test_find_template():
    """Test function to find the project_template in the repo_dir."""
    test_repo_dir = '/path/to/repo'
    repo_dir_contents = ['cookiecutter-pypackage',
                         'cookiecutter-{{cookiecutter.repo_name}}',
                         'cookiecutter-django']
    project_template = find_template(test_repo_dir)
    assert 'cookiecutter-{{cookiecutter.repo_name}}' in project_template

# Generated at 2022-06-23 16:15:57.719540
# Unit test for function find_template
def test_find_template():
    """Test for the find_template function."""
    from .generate import get_template_dirs
    from .main import cookiecutter

    cookiecutters = []
    for template_dir in get_template_dirs():
        # Use a random template from the list of template directories
        cookiecutters.append(cookiecutter(template_dir))

    for cookiecutter in cookiecutters:
        assert isinstance(cookiecutter, dict)
        assert '_template' in cookiecutter

# Generated at 2022-06-23 16:16:01.653939
# Unit test for function find_template
def test_find_template():
    repo_dir = '../tests/test-repo'
    project_template = find_template(repo_dir)

    expected_project_template = '../tests/test-repo/{{cookiecutter.repo_name}}'

    assert project_template == expected_project_template

# Generated at 2022-06-23 16:16:08.221474
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(repo_dir, 'tests/test-repo-pre/')

    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(repo_dir, 'tests/test-repo-post/')

    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException as e:
        assert 'Cookiecutter template not found in repo' in str(e)



# Generated at 2022-06-23 16:16:09.337381
# Unit test for function find_template
def test_find_template():
    """Test that find_template works."""
    pass

# Generated at 2022-06-23 16:16:16.778522
# Unit test for function find_template
def test_find_template():
    """Test function find_template()."""
    from cookiecutter import utils

    repo_dir = ''

    # Update repo_dir to point to tests/fake-repo-pre/
    tests_dir, _ = os.path.split(__file__)
    repo_dir = os.path.join(tests_dir, 'fake-repo-pre')

    # Test to ensure repo_dir is set properly
    if not repo_dir:
        raise Exception

    # Test to ensure path returned is correct
    actual_template_dir = utils.find_template(repo_dir)
    expected_template_dir = os.path.join(repo_dir, 'fake_template')
    if os.path.normpath(actual_template_dir) != os.path.normpath(expected_template_dir):
        raise Exception

# Generated at 2022-06-23 16:16:17.876095
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:22.299242
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works properly."""
    assert find_template(
        '/home/ben/code/cookiecutter-pypackage'
    ) == '/home/ben/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:27.065807
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/github/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/github/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:33.283712
# Unit test for function find_template
def test_find_template():
    """A sanity check to determine that the function find_template works as expected.
    """
    # add current directory to system path
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

    # create a test directory that mimics a git repository with a cookiecutter template inside
    test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_dir')
    template = os.path.join(test_dir, '{{cookiecutter.project_name}}')
    os.makedirs(template)

    # assert that inside test_dir, the project template is '{{cookiecutter.project_name}}'
    assert find_template(test_dir) == template

    # delete the test_dir
    shutil.r

# Generated at 2022-06-23 16:16:36.244170
# Unit test for function find_template
def test_find_template():
    """Test that the correct directory is found."""
    import tempfile
    example_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    temp_dir = tempfile.mkdtemp()
    project_template = find_template(example_dir)
    assert project_template == os.path.join(example_dir, 'fake_project_tmpl')

# Generated at 2022-06-23 16:16:38.887416
# Unit test for function find_template
def test_find_template():
    try:
        find_template('/cookiecutter-python')
    except Exception:
        return True
    return False



# Generated at 2022-06-23 16:16:47.671582
# Unit test for function find_template
def test_find_template():
    """
    Tests for find_template
    :return:
    """
    import json
    import shutil
    import sys
    import tempfile
    import unittest

    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest

    from cookiecutter import find

    class TestFindTemplate(unittest.TestCase):
        """ Tests for find_template """

        def setUp(self):
            """ Create a template repository with a few subdirectories. """
            self.repo_dir = tempfile.mkdtemp()
            self.repo_dir_contents = [
                'foobar',
                '{{cookiecutter.repo_name}}',
                '{{cookiecutter.repo_name}}-master',
                '.git',
            ]
           

# Generated at 2022-06-23 16:16:58.061170
# Unit test for function find_template
def test_find_template():
    import os
    import shutil

    from cookiecutter import repo

    # Create a fake repo to test with
    fake_repo_path = os.path.join(os.path.dirname(__file__), 'fake-repo')
    fake_repo_dest_path = os.path.join(
        os.path.dirname(__file__),
        'fake-repo-with-cookiecutter-dir'
    )
    shutil.copytree(fake_repo_path, fake_repo_dest_path)

    # Clone it
    repo.clone(fake_repo_dest_path)

    # Test
    actual_project_template = find_template(fake_repo_dest_path)

# Generated at 2022-06-23 16:17:07.169548
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can determine the project_dir."""
    dir_contents = ['my_project_name', 'another_project', '{{cookiecutter.repo_name}}']
    input_dir = os.path.join(os.getcwd(), 'test_find_template')
    os.mkdir(input_dir)
    [os.mkdir(os.path.join(input_dir, drc)) for drc in dir_contents]

    assert find_template(input_dir) == os.path.join(input_dir, dir_contents[2])
    [os.rmdir(os.path.join(input_dir, drc)) for drc in dir_contents]
    os.rmdir(input_dir)

test_find_template()

# Generated at 2022-06-23 16:17:18.434581
# Unit test for function find_template
def test_find_template():
    """Check if the repo_dir_contents has a cookiecutter template"""
    repo_dir_contents = [
        'cookiecutter-pypackage/{{cookiecutter.project_name}}',
        'cookiecutter-pypackage/build',
        'cookiecutter-pypackage/docs',
        'cookiecutter-pypackage/.gitignore',
        'cookiecutter-pypackage/README.rst',
        'cookiecutter-pypackage/setup.py',
        'cookiecutter-pypackage/tests',
        'cookiecutter-pypackage/tox.ini',
        '.git',
        'README.rst',
    ]


# Generated at 2022-06-23 16:17:19.556366
# Unit test for function find_template
def test_find_template():
    assert find_template('hello')

# Generated at 2022-06-23 16:17:23.834677
# Unit test for function find_template
def test_find_template():
    """Test find_template() function."""
    assert 'fake-repo' == find_template("tests/fake-repo-pre/fake-repo")
    assert 'fake-repo' == find_template("tests/fake-repo-post/fake-repo")
    # TODO: Add the zip tests

# Generated at 2022-06-23 16:17:29.637358
# Unit test for function find_template
def test_find_template():
    from tests.test_find import _create_files

    with _create_files(('ok1', 'ok2', 'nope', 'nope2')) as tmp_dir:
        template_dir = next(x for x in os.listdir(tmp_dir) if 'ok' in x)
        template_dir = os.path.join(tmp_dir, template_dir)
        assert find_template(tmp_dir) == template_dir

# Generated at 2022-06-23 16:17:31.050444
# Unit test for function find_template
def test_find_template():
    template = find_template('ar/hello-world/')
    assert ('ar/hello-world/{{cookiecutter.project_slug}}' == template)

# Generated at 2022-06-23 16:17:37.551718
# Unit test for function find_template
def test_find_template():
    target_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-find-template')
    os.chdir(target_dir)
    project_template = find_template(target_dir)
    assert project_template == 'cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:40.516647
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/vanessa/code/cookiecutter-data-science/'
    project_template_path = find_template(repo_dir)
    assert project_template_path == '/home/vanessa/code/cookiecutter-data-science/{{cookiecutter.repo_name}}'
test_find_template()

# Generated at 2022-06-23 16:17:52.262498
# Unit test for function find_template
def test_find_template():
    """Test for the find_template function.
    """
    repo_dir = os.path.join(os.path.dirname(__file__), 'fixtures/fake-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(os.path.join(repo_dir, '{{cookiecutter.repo_name}}')) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template('/etc') == NonTemplatedInputDirException
    assert find_template('') == NonTemplatedInputDirException
    assert find_template('{{cookiecutter.repo_name}}') == NonTemplatedInputDirException

# Generated at 2022-06-23 16:18:03.058496
# Unit test for function find_template
def test_find_template():

    """
    Test the find_template function.
    """
    source_dir = os.path.abspath(os.path.dirname(__file__))
    fixtures_dir = os.path.join(source_dir, '..', 'tests', 'fixtures')
    os.chdir(fixtures_dir)

    # Test when repo_dir has a templated directory
    repo_dir = os.path.join(
        fixtures_dir, 'non-templated-input-dir', 'repo-with-templated-dir')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:18:08.124006
# Unit test for function find_template
def test_find_template():
    import pytest
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    expected = '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == expected


# Generated at 2022-06-23 16:18:11.971714
# Unit test for function find_template
def test_find_template():
    template = find_template('/Users/audreyr/Desktop/cookiecutter-pypackage')
    assert template == '/Users/audreyr/Desktop/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:19.839241
# Unit test for function find_template
def test_find_template():
    import re
    import sys

    # Check that it returns the desired local directory.
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 
        'fake-repo'
    )

    project_template = find_template(repo_dir)
    regex = re.compile('^fake-repo\/.+')

    assert re.match(regex, project_template)

    # Check that it raises an exception if the directory is not a 
    # project template directory.
    bad_dir = os.path.abspath(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    )


# Generated at 2022-06-23 16:18:21.506704
# Unit test for function find_template
def test_find_template():
    assert find_template() is not None

# Generated at 2022-06-23 16:18:29.837045
# Unit test for function find_template
def test_find_template():
    """
    Test that the called function works as expected.
    """
    import pytest
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, 'cookiecutter-template')
    os.makedirs(template_dir)

    try:
        template = find_template(repo_dir)
        assert template == template_dir
    finally:
        shutil.rmtree(repo_dir)


# Generated at 2022-06-23 16:18:33.238566
# Unit test for function find_template
def test_find_template():
    return os.path.join(os.getcwd(), 'tests', 'fake-repo-pre')

test_find_template()
find_template(test_find_template())

# Generated at 2022-06-23 16:18:42.704241
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import os
    import shutil
    import tempfile
    import logging

    temp_dir = tempfile.mkdtemp()
    logging.disable(logging.CRITICAL)

    try:
        repo_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
        project_template = os.path.join(temp_dir, 'cookiecutter-pypackage', '{{cookiecutter.repo_name}}')

        os.makedirs(repo_dir)
        os.makedirs(project_template)

        template = find_template(repo_dir)
        assert template == project_template
    finally:
        shutil.rmtree(temp_dir)
        logging.disable(logging.NOTSET)

# Generated at 2022-06-23 16:18:45.850228
# Unit test for function find_template
def test_find_template():
    path_to_repo = '{{ cookiecutter.repo_dir }}'
    project_template = find_template(path_to_repo)
    assert project_template == path_to_repo

# Generated at 2022-06-23 16:18:48.670760
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.abspath(os.path.dirname(__file__)))

# Generated at 2022-06-23 16:18:53.770617
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    repo_dir_contents = os.listdir(repo_dir)
    expected_result = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == expected_result

# Generated at 2022-06-23 16:18:57.298864
# Unit test for function find_template
def test_find_template():
    """Test that function find_template is working properly"""
    import os
    find_template(r'C:\Users\Jared\Desktop\Cookiecutter-Test\my-repo-templated')

# Generated at 2022-06-23 16:19:00.736665
# Unit test for function find_template
def test_find_template():
    assert(find_template('/home/someuser/workspace/cookiecutter-pypackage/')) == (
        '/home/someuser/workspace/cookiecutter-pypackage/{{cookiecutter.repo_name}}/'
    )

# Generated at 2022-06-23 16:19:02.070095
# Unit test for function find_template
def test_find_template():
    find_template('C:\python\cookiecutter\tests\test-repo-pre')

# Generated at 2022-06-23 16:19:03.474822
# Unit test for function find_template
def test_find_template():
    """Ensure find_template() works as expected."""
    pass

# Generated at 2022-06-23 16:19:14.171419
# Unit test for function find_template
def test_find_template():
    """Find_template test
    """
    html_repo = "tests/test-repo-pre/{{cookiecutter.project_name}}"
    git_repo = "https://github.com/audreyr/cookiecutter-pypackage.git"
    test_template = find_template(html_repo)
    assert test_template == os.path.join(html_repo, 'tests/test-repo-pre/{{cookiecutter.project_name}}')

# Find the template in a git repo
    test_template = find_template(git_repo)
    assert os.path.isdir(test_template)
    assert test_template.endswith('/tests/test-repo-pre/python-package')

# Generated at 2022-06-23 16:19:18.675728
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests', 'test-find-template'
    )

    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:19:25.630405
# Unit test for function find_template
def test_find_template():
    """Test find_template()"""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Check for invalid input
    for bad_dir in ['./', 'foo/', 'bar']:
        try:
            utils.find_template(bad_dir)
            assert False
        except NonTemplatedInputDirException:
            pass

    # Check for valid input
    template = utils.find_template('tests/test-data/fake-repo-pre/')
    assert template == 'tests/test-data/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert os.path.isdir(template)
    assert os.path.isfile(os.path.join(template, 'fake-repo.py'))

# Generated at 2022-06-23 16:19:27.710275
# Unit test for function find_template
def test_find_template():
    template_directory = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test-template'
    )
    assert find_template(template_directory) == os.path.join(
        template_directory, '{{cookiecutter.repo_name}}'
    )


# Generated at 2022-06-23 16:19:28.739431
# Unit test for function find_template
def test_find_template():
    # TODO: Mock
    pass



# Generated at 2022-06-23 16:19:39.320543
# Unit test for function find_template
def test_find_template():
    from cookiecutter import repo
    from cookiecutter import utils
    from mock import patch

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(repo.__file__),
        'tests/test-repo-pre/',
    ))

    # empty list
    with patch.object(os, 'listdir', return_value=[]):
        assert not find_template(repo_dir)

    # list dir returns non-templated dir
    with patch.object(os, 'listdir', return_value=['cookiecutter-pypackage', 'cookiecutter-fake']):
        assert not find_template(repo_dir)

    # list dir returns templated dir

# Generated at 2022-06-23 16:19:49.750541
# Unit test for function find_template
def test_find_template():
    """
    Test function find_template
    """
    from tests.test_utils import TEST_PATH
    from .utils import change_directory, get_current_path

    # Test path for find_template
    # test path is 'simple_project/cookiecutter-simple-project'
    test_path = os.path.join(TEST_PATH, 'simple_project')

    # change directory to the test path
    original_path = get_current_path()
    change_directory(test_path)

    # try to find the project template
    template_dir = find_template(test_path)
    assert template_dir == "cookiecutter-simple-project"

    # change back to original directory
    change_directory(original_path)

# Generated at 2022-06-23 16:19:54.061710
# Unit test for function find_template
def test_find_template():
    """Verify the find_template() function."""
    from cookiecutter.tests.test_repositories import TEST_REPO_DIR

    project_template = find_template(TEST_REPO_DIR)
    assert project_template == TEST_REPO_DIR + '/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:59.260992
# Unit test for function find_template
def test_find_template():
    fake_repo_dir = 'temp-fake-repo-dir'
    os.makedirs(os.path.join(fake_repo_dir, 'cookiecutter-test'))
    assert find_template(fake_repo_dir) == os.path.join(fake_repo_dir, 'cookiecutter-test')
    os.removedirs(fake_repo_dir)


# Generated at 2022-06-23 16:20:04.972787
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    repo_dir = './tests/test-repo/'
    project_template = './tests/test-repo/cookiecutter-pypackage-master/'
    assert project_template == find_template(repo_dir)

# Generated at 2022-06-23 16:20:10.428212
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the right directory."""
    input_directory = '/home/vagrant/sync/cookiecutter-pypackage'
    result = '/home/vagrant/sync/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(input_directory) == result


# Generated at 2022-06-23 16:20:14.946595
# Unit test for function find_template
def test_find_template():
    # create a dummy project template directory
    temp = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp, 'cookiecutter-project-template'))
    # check that we find the dummy template
    template = find_template(temp)
    assert os.path.basename(template) == 'cookiecutter-project-template'

    # clean up
    shutil.rmtree(temp)

# Generated at 2022-06-23 16:20:18.055829
# Unit test for function find_template
def test_find_template():
    """Verify find_template's functionality."""
    repo_dir = 'tests/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:23.989819
# Unit test for function find_template
def test_find_template():
    """Integration test for function 'find_template'."""
    # Test for no project template found
    test_dir_no_template = os.path.join(
        'tests',
        'test-input',
        'fail',
        'no-template',
        'cookiecutter-pypackage'
    )
    try:
        find_template(test_dir_no_template)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('No project template was found.')

    # Test for project template found
    test_dir_with_template = os.path.join(
        'tests',
        'test-input',
        'success',
        'with-template',
        'cookiecutter-pypackage'
    )

# Generated at 2022-06-23 16:20:28.376581
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo'
    assert find_template(repo_dir) == 'tests/test-repo/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:20:31.980935
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audrey/code/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/home/audrey/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:33.301533
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-23 16:20:33.826562
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:20:36.505953
# Unit test for function find_template
def test_find_template():
    """
    Function that tests if find_template is working properly
    """
    find_template(repo_dir)    



# Generated at 2022-06-23 16:20:44.477569
# Unit test for function find_template
def test_find_template():
    repo_dir = "/path/to/repo"

    repo_dir_contents = ['cookiecutter-{{cookiecutter.repo_name}}',
                         'README.rst']
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    project_template = os.path.join(repo_dir, project_template)
    assert project_template == find_template(repo_dir)


# Generated at 2022-06-23 16:20:50.564893
# Unit test for function find_template
def test_find_template():

    path_to_template = 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre') == path_to_template

    path_to_template = 'tests/fake-repo-post/fake-repo'
    assert find_template('tests/fake-repo-post') == path_to_template

# Generated at 2022-06-23 16:20:59.811790
# Unit test for function find_template
def test_find_template():
    """Verify that find_template actually finds the template."""
    from shutil import copyfile
    from tempfile import mkdtemp
    from string import ascii_letters

    # Make a temporary directory
    temp_dir = mkdtemp()

    # Copy the test template to the temporary directory
    test_template_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                     'test-template')

    temp_test_template_dir = os.path.join(temp_dir, 'test-template')
    copyfile(test_template_dir, temp_test_template_dir)

    # Test that find_template finds the template
    found_template = find_template(temp_dir)
    assert found_template == temp_test_template_dir

# Generated at 2022-06-23 16:21:03.532485
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo/'
    project_template = 'fake-repo/{{cookiecutter.repo_name}}/'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:21:11.604150
# Unit test for function find_template
def test_find_template():
    """Test that find_template function works as expected on a non-templated directory."""
    import tempfile

    base_dir = tempfile.mkdtemp()

    repo_dir = os.path.join(base_dir, 'my-repo')
    os.mkdir(repo_dir)

    non_template_dir = os.path.join(repo_dir, 'not-a-template')
    os.mkdir(non_template_dir)

    project_template = find_template(repo_dir)
    expected_path = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    assert project_template == expected_path

# Generated at 2022-06-23 16:21:14.721034
# Unit test for function find_template
def test_find_template():
    """Test that the template was properly found."""
    repo_dir = 'test_find_template/test_repo/'
    expected = 'test_find_template/test_repo/project_{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == expected


# Generated at 2022-06-23 16:21:23.273276
# Unit test for function find_template
def test_find_template():
    """Test for finding project template after repo is cloned."""

    # TODO: This test is in desperate need of refactoring.
    os.chdir('tests/test-repo-pre/')
    project_template = find_template('test-repo-pre/')
    os.chdir('../')

    if project_template:
        assert project_template == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    else:
        raise Exception

# Generated at 2022-06-23 16:21:34.065543
# Unit test for function find_template
def test_find_template():
    import tempfile

    from cookiecutter.generate import generate_context
    from cookiecutter.utils import rmtree

    repo_dir = tempfile.mkdtemp()

    # Create our fake repo:
    fake_repo = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(fake_repo)

    # Our expected context:
    extra_context = {
        'repo_name': 'fake-repo-name',
    }

    # Our expected output:
    expected_output = 'fake-repo-name'

    # Get the context:
    context = generate_context(repo_dir, extra_context)

    # Test the find_template function:
    output = find_template(repo_dir)

# Generated at 2022-06-23 16:21:41.013538
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct result."""
    # Given: a local git repo containing a subdir with Cookiecutter template syntax
    repo_dir = os.path.abspath('cookiecutter_dummy_repo_dir')

    # When: I call find_template() with the repo dir
    project_template = find_template(repo_dir)

    # Then: I get the expected result
    expected = os.path.abspath(os.path.join('cookiecutter_dummy_repo_dir', 'cookiecutter-template'))
    assert project_template == expected

# Generated at 2022-06-23 16:21:45.159028
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/me/Documents/cookiecutter-tryton-module'
    assert find_template(repo_dir) == '/home/me/Documents/cookiecutter-tryton-module/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:46.947157
# Unit test for function find_template
def test_find_template():
    assert find_template('testdir') == os.path.join('testdir', 'test-name')

# Generated at 2022-06-23 16:21:47.508960
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:21:49.288492
# Unit test for function find_template
def test_find_template():
    """Test `find_template` function."""
    pass

# Generated at 2022-06-23 16:21:53.556023
# Unit test for function find_template
def test_find_template():
    assert find_template(
        '/Users/audreyr/Documents/GitHub/cookiecutter-pypackage'
    ) == '/Users/audreyr/Documents/GitHub/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:56.564694
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/test'
    assert find_template(repo_dir) == '/Users/audreyr/test/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:22:00.379629
# Unit test for function find_template
def test_find_template():
    """Test handling of invalid repo_dir."""
    from cookiecutter.main import cookiecutter

    # Create a fake repo
    path = os.path.abspath('fake/fake/path')
    os.makedirs(path)
    # Create a pretend template inside the fake repo
    os.makedirs(os.path.abspath('fake/fake/path/fake-cookiecutter-template'))
    try:
        cookiecutter(path, no_input=True)
    except NonTemplatedInputDirException:
        pass



# Generated at 2022-06-23 16:22:06.340734
# Unit test for function find_template
def test_find_template():
    logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.DEBUG)
    cwd = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(cwd, 'root_files')
    project_template = find_template(repo_dir)
    assert project_template == '/home/user/django-app/cookiecutter-django/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:22:11.154095
# Unit test for function find_template
def test_find_template():
    try:
        find_template('tests/fake-repo-pre')
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

    result = find_template('tests/fake-repo')
    assert result == 'tests/fake-repo/cookiecutter-pypackage'

# Generated at 2022-06-23 16:22:19.030631
# Unit test for function find_template
def test_find_template():
    """Example: find_template('tests/fake-repo-tmpl') -> 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'"""
    assert '{{cookiecutter.repo_name}}' in find_template('tests/fake-repo-tmpl')
    assert 'tests/fake-repo-tmpl' in find_template('tests/fake-repo-tmpl')