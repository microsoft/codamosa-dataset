

# Generated at 2022-06-23 16:12:20.116768
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('./tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    project_template = find_template(repo_dir)
    assert project_template == os.path.abspath('./tests/fake-repo-pre/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}')



# Generated at 2022-06-23 16:12:30.688691
# Unit test for function find_template
def test_find_template():

    os.chdir('tests')

    # Case where there is a cookiecutter.json file in the root of the project
    repo_dir_contents = ['cookiecutter.json']
    assert find_template('.') == 'cookiecutter.json'

    # Case where there is a cookiecutter.json file in a subdirectory
    repo_dir_contents = ['tests', 'cookiecutter.json']
    assert find_template('.') == 'tests/cookiecutter.json'

    # Case where there is no cookiecutter.json file
    repo_dir_contents = []
    try:
        find_template('.')
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException not raised!')

    # Case where there is a cookiecutter.

# Generated at 2022-06-23 16:12:31.234137
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:12:35.850149
# Unit test for function find_template
def test_find_template():
    """Find the project template directory in a newly cloned repo."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_repo'
    )
    project_template = find_template(repo_dir)
    assert project_template

# Generated at 2022-06-23 16:12:38.559236
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.DEBUG)
    repo_dir = os.path.join(os.path.dirname(__file__), 'tests/fake-repo-pre')
    project_dir = find_template(repo_dir)
    project_dir_expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_dir == project_dir_expected

# Generated at 2022-06-23 16:12:44.999757
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter import utils

    with tempfile.TemporaryDirectory() as tmp_dir:
        # Create a fake repo with a subdirectory containing a file with a jinja2 bracket in it.
        tmp_dir_contents = ['example_repo_template{{}}', 'example_repo_template_2']
        repo_path = os.path.join(tmp_dir, tmp_dir_contents[0])
        os.mkdir(repo_path)

        # check that the correct template is identified.
        assert find_template(tmp_dir) == repo_path

        # check that an error is raised if there is no templated directory.
        os.rmdir(repo_path)

# Generated at 2022-06-23 16:12:51.180918
# Unit test for function find_template
def test_find_template():
    test_dir = '/path/to/templated_dir'
    test_contents = os.listdir(test_dir)
    project_template = '/path/to/templated_dir/cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template(test_contents) == project_template

# Generated at 2022-06-23 16:12:57.186606
# Unit test for function find_template
def test_find_template():
    """ Test for find_template function """
    test_fix_repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '../tests/test-find-template'
    )
    assert find_template(test_fix_repo_dir) == os.path.join(
        test_fix_repo_dir,
        'fake-repo-{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:13:03.816997
# Unit test for function find_template
def test_find_template():
    from cookiecutter import finder
    from cookiecutter import utils

    repo_dir = utils.make_empty_dir()
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    utils.make_empty_dir(template_dir)

    template_dir2 = os.path.join(repo_dir, 'something_else')
    utils.make_empty_dir(template_dir2)

    found_template = finder.find_template(repo_dir)

    assert found_template == template_dir

# Generated at 2022-06-23 16:13:06.962151
# Unit test for function find_template
def test_find_template():
    assert find_template('/tmp/testrepo') == '/tmp/testrepo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:11.693987
# Unit test for function find_template
def test_find_template():
    """Test that a cookiecutter.json file is found.
    """
    template = find_template('cookiecutter-pypackage')
    assert template == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:13:20.240818
# Unit test for function find_template
def test_find_template():
    """Unit testing for find_template."""
    assert find_template('tests/fake-repo-tmpl/') == \
        'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre/') == \
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-no-tmpl/') == \
        'tests/fake-repo-no-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:24.325749
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter's behavior when it finds a template."""
    repo_dir = 'tests/fake-repo-tmpl/'
    project_template = os.path.join(repo_dir, '{{cookiecutter.project_slug}}')
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:13:32.280201
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns expected template path."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'fake-repo', 'input'
    ))
    project_template = find_template(repo_dir)

    expected_path = os.path.abspath(os.path.join(
        repo_dir, '{{cookiecutter.project_slug}}'
    ))

    assert project_template == expected_path

# Generated at 2022-06-23 16:13:38.823354
# Unit test for function find_template
def test_find_template():
    """Verify find_template()."""
    from cookiecutter.tests.test_utils import make_empty_file
    from cookiecutter.tests.fake_repo import fake_repo

    empty_repo = fake_repo.copy()
    project_template = os.path.join(empty_repo, '{{cookiecutter.repo_name}}')
    make_empty_file(project_template)
    found_project_template = find_template(empty_repo)
    assert found_project_template == project_template



# Generated at 2022-06-23 16:13:49.547242
# Unit test for function find_template
def test_find_template():
    """Test find_template for two correctly and one incorrectly templated dir.
    """
    test_template = '''
a/
    {{cookiecutter.repo_name}}/
        {{cookiecutter.repo_name}}/
            another_dir/
                file.txt
        {{cookiecutter.other_variable}}/
            another_dir/
                file2.txt
    not_a_template/
        another_dir/
            file3.txt
b/
c/
'''.strip()
    test_template_dir = 'test/example_template'
    import shutil
    shutil.rmtree(test_template_dir, ignore_errors=True)
    os.makedirs(test_template_dir)

# Generated at 2022-06-23 16:13:56.375079
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    import unittest

    from cookiecutter.exceptions import NonTemplatedInputDirException

    class TestFindTemplate(unittest.TestCase):
        def setUp(self):
            self.repo_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.repo_dir, ignore_errors=True)

        def test_find_template_fails_on_empty_directory(self):
            """find_template() raises NonTemplatedInputDirException on an empty directory."""
            with self.assertRaises(NonTemplatedInputDirException):
                find_template(self.repo_dir)


# Generated at 2022-06-23 16:14:02.235368
# Unit test for function find_template
def test_find_template():
    """Tests for find_template()"""
    import tempfile
    from cookiecutter import utils

    tmp_dir = tempfile.mkdtemp()

    repo_dir = os.path.join(tmp_dir, 'foobarbaz')
    os.makedirs(repo_dir)
    utils.workaround_git_scandal()

    template_path = find_template(repo_dir)
    os.removedirs(repo_dir)

# Generated at 2022-06-23 16:14:07.812340
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""

    assert find_template('/home/veekaybee/etc/cookiecutters/cookiecutter-pypackage') == '/home/veekaybee/etc/cookiecutters/cookiecutter-pypackage/{{cookiecutter.project_slug}}', 'did not find the project template'

# Generated at 2022-06-23 16:14:10.097301
# Unit test for function find_template
def test_find_template():
    assert find_template('./cookiecutter-django') == './cookiecutter-django/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:14:13.028071
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir)
    assert find_template(repo_dir) == '/Users/danielmoody/Documents/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:14:20.821676
# Unit test for function find_template
def test_find_template():
    """Verify function finds the correct directory when given a simple input."""
    # Based on the current working directory, find the full path to
    # tests/test-repo-pre/cookiecutter-{{cookiecutter.repo_name}}
    expected_result = 'tests/test-repo-pre/cookiecutter-{{cookiecutter.repo_name}}'
    result = find_template('tests/test-repo-pre')

    assert os.path.normpath(result) == os.path.normpath(expected_result)



# Generated at 2022-06-23 16:14:25.364352
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage/'

    find_template(repo_dir)

# Generated at 2022-06-23 16:14:25.895983
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:29.993854
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), os.pardir, 'tests')
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, 'fake-repo-pre/{{cookiecutter.repo_name}}')
    assert project_template == expected

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:14:33.356840
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    import shutil
    import tempfile

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    template_dir = os.path.join(cur_dir, 'test-tmpl')

    assert 'cookiecutter' in find_template(template_dir), \
        'test_find_template: find_template could not find test-tmpl'

# Generated at 2022-06-23 16:14:36.543066
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo'
    project_template = find_template(repo_dir)
    project_template = os.path.basename(project_template)
    assert project_template == 'cookiecutter-{{repo_name}}'

# Generated at 2022-06-23 16:14:45.955820
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.path.dirname(__file__), '..', 'tests')
    non_templated_dir = os.path.join(test_dir, 'fake-repo')
    templated_dir = os.path.join(test_dir, 'fake-repo-templated')

    assert find_template(templated_dir) == non_templated_dir + os.path.sep + '{{cookiecutter.repo_name}}'

    try:
        find_template(non_templated_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'Did not raise exception when trying to find a non-templated directory.'

# Generated at 2022-06-23 16:14:49.695256
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    input_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        os.pardir, os.pardir, os.pardir, 'tests', 'fake-repo'))
    output_dir = os.path.join(
        os.path.dirname(__file__),
        os.pardir, os.pardir, os.pardir, 'tests', 'fake-repo-out')

    if not os.path.isdir(output_dir):
        os.makedirs(output_dir)


# Generated at 2022-06-23 16:14:54.202606
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    assert find_template('/home/username/cookiecutter-pypackage-master') == '/home/username/cookiecutter-pypackage-master/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:04.230057
# Unit test for function find_template
def test_find_template():
    """Check that the find_template function works as expected."""
    # pylint: disable=missing-docstring
    import tempfile

    repo_dir = tempfile.mkdtemp()

    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-django'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter'))

    for project_template in (
        'cookiecutter-pypackage',
        'cookiecutter-django',
        'cookiecutter'
    ):
        template_dir = os.path.join(repo_dir, project_template)

# Generated at 2022-06-23 16:15:08.268682
# Unit test for function find_template
def test_find_template():
    """Verify the function `find_template`."""
    from cookiecutter.tests.test_find import DIRNAME
    from cookiecutter.tests.test_find import REPO_DIR_NAME
    from cookiecutter.tests.test_find import REPO_DIR
    from cookiecutter.tests.test_find import REPO_PATH

    expected = os.path.join(REPO_DIR, REPO_DIR_NAME)
    result = find_template(REPO_PATH)
    assert result == expected

# Generated at 2022-06-23 16:15:12.227491
# Unit test for function find_template
def test_find_template():
    repo_dir = '.\\repo-root'
    project_name = 'cookiecutter-pypackage'
    os.makedirs(os.path.join(repo_dir, project_name))
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, project_name)


# Generated at 2022-06-23 16:15:20.574872
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'tests', 'fake-repo-tmpl')
    # expected_template = os.path.join(repo_dir, 'fake-project-tmpl')
    test_template = find_template(repo_dir)
    assert test_template == os.path.join(repo_dir, 'fake-project-tmpl')

# Generated at 2022-06-23 16:15:24.015759
# Unit test for function find_template
def test_find_template():
    '''Tests if the template directory is found in a new
    directory with a generic name'''
    repo_dir = '/home/username/temp/'
    template_dir = find_template(repo_dir)
    assert template_dir

# Generated at 2022-06-23 16:15:31.028146
# Unit test for function find_template
def test_find_template():
    """Verify use of find_template()."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'))
    template = utils.find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:15:33.931090
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-data/test-repo') == 'tests/test-data/test-repo/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:15:39.580271
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import get_user_config, get_template_dir
    from .test_utils import TEST_COOKIE_DIR
    from .test_data_dirs import (
        DIRS_WITH_TEMPLATES, DIRS_WITHOUT_TEMPLATES,
        DIRS_WITH_NON_TEMPLATED_DIRS
    )

    user_config = get_user_config(config_file='cookiecutterrc')
    template_dir = get_template_dir(user_config, config_file='cookiecutterrc')

    # Loop through directories with templates and find the template

# Generated at 2022-06-23 16:15:48.564453
# Unit test for function find_template
def test_find_template():
    """Test for find_template."""
    from cookiecutter.tests.test_utils import make_temporary_directory
    from cookiecutter.utils import rmtree
    from git import Repo

    repo_dir = make_temporary_directory()
    repo = Repo.init(repo_dir)
    # Create a file
    fh = open(os.path.join(repo_dir, 'cookiecutter.json'), 'w')
    fh.write('')
    fh.close()
    # Create a directory
    os.mkdir(os.path.join(repo_dir, 'cookiecutter'))
    # Create a file in the directory
    fh = open(os.path.join(repo_dir, 'cookiecutter', '__init__.py'), 'w')
    f

# Generated at 2022-06-23 16:15:49.963550
# Unit test for function find_template
def test_find_template():
    print(find_template(repo_dir='/Users/paul/dev/git/cookiecutter-pypackage'))

# Generated at 2022-06-23 16:15:52.421596
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tools/test_dir'
    assert find_template(repo_dir) == 'tools/test_dir/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:03.592231
# Unit test for function find_template
def test_find_template():
    """Assert that the function find_template finds the template"""
    from cookiecutter import tempdir
    from cookiecutter.vcs import clone
    from cookiecutter.main import cookiecutter

    project_dir = tempdir.tempdir()

    # Create a fresh new repo
    context = {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com'}
    repo_dir = os.path.join(project_dir, 'fake-repo')
    repo = 'https://github.com/audreyr/fake-repo.git'  # or git@
    repo_dir = clone(repo, checkout='master', no_input=True)
    cookiecutter(repo_dir, no_input=True, extra_context=context)

    # Test if find_template returns template
   

# Generated at 2022-06-23 16:16:09.494559
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.expanduser('~/cookiecutter-test')
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-test'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-test-2'))
    assert 'cookiecutter-test' in find_template(repo_dir)
    os.rmdir(os.path.join(repo_dir, 'cookiecutter-test'))
    os.rmdir(os.path.join(repo_dir, 'cookiecutter-test-2'))
    os.rmdir(repo_dir)

# Generated at 2022-06-23 16:16:17.603241
# Unit test for function find_template
def test_find_template():
    """Verify the function `find_template()`."""
    from cookiecutter import utils
    from cookiecutter.compat import site_packages_path
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.repository import determine_repo_dir

    config_file = utils.make_config_file(
        config_dict=DEFAULT_CONFIG,
        output_dir=site_packages_path()
    )
    repo_dir = determine_repo_dir('tests/fake-repo-tmpl', config_file=config_file)
    project_template = find_template(repo_dir)

# Generated at 2022-06-23 16:16:20.846080
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test_input/fake-repo-tmpl') == 'tests/test_input/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:32.349557
# Unit test for function find_template
def test_find_template():
    """Test find_template."""

    tests = (
        # Template is in the input_dir
        {
            'input_dir': '{{cookiecutter.repo_name}}',
            'project_template': '{{cookiecutter.repo_name}}',
        },
        # No template is in the input_dir
        {
            'input_dir': 'nothing_to_see_here',
            'project_template': None,
        },
    )

    for t in tests:
        result = find_template(t['input_dir'])
        if t['project_template']:
            assert result == os.path.join(t['input_dir'], t['project_template'])
        else:
            assert result == t['project_template']

# Generated at 2022-06-23 16:16:36.127348
# Unit test for function find_template
def test_find_template():
    repo_dir='tests/fake-repo-pre'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:16:41.078608
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.abspath(os.path.dirname(__file__))
    fixture_path = os.path.join(test_dir, 'test-find-template')

    assert find_template(fixture_path) == os.path.join(
        fixture_path, 'cookiecutter-pypackage_templated')

# Generated at 2022-06-23 16:16:43.110717
# Unit test for function find_template
def test_find_template():
    """Test for function find_template.

    This test is not normally run, however to run it use `$ python -m pytest tests/test_checkout.py`
    """
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.project_name}}'

# Generated at 2022-06-23 16:16:49.703771
# Unit test for function find_template
def test_find_template():
    from cookiecutter.vcs import git
    from cookiecutter import main
    from tempdir import TempDir

    expected_dir = 'cookiecutter-pypackage'
    with TempDir() as tmp_dir:
        cloned_repo = main.clone(
            git_url='https://github.com/audreyr/cookiecutter-pypackage.git',
            checkout=None,
            clone_to_dir=tmp_dir.name,
            no_input=True
        )

    result_dir = find_template(cloned_repo)
    expected_path = os.path.join(tmp_dir.name, 'cookiecutter-pypackage')
    assert result_dir == expected_path

test_find_template()

# Generated at 2022-06-23 16:16:57.137090
# Unit test for function find_template
def test_find_template():

    # Create a repo_dir
    import tempfile
    temp_repo_dir = tempfile.mkdtemp()

    # Create a bogus project template, and add it to the repo_dir
    temp_project_template = tempfile.NamedTemporaryFile(
        dir=temp_repo_dir,
        prefix='cookiecutter',
        suffix='{{cookiecutter.bogus}}',
        delete=False
    ).name

    # Check to see if the project template is found
    assert find_template(temp_repo_dir) == temp_project_template

    # Clean up
    os.remove(temp_project_template)
    os.rmdir(temp_repo_dir)

test_find_template()

# Generated at 2022-06-23 16:17:02.526856
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/me/code/cookiecutter-pypackage') == '/Users/me/code/cookiecutter-pypackage/cookiecutter-pypackage'
    assert find_template('/Users/me/code/cookiecutter-pypackage-master') == '/Users/me/code/cookiecutter-pypackage-master/cookiecutter-pypackage'

# Generated at 2022-06-23 16:17:05.322921
# Unit test for function find_template
def test_find_template():
    """Test for determining which child directory of `repo_dir` is the project template."""
    repo_dir = '~/projects/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template

# Generated at 2022-06-23 16:17:16.560004
# Unit test for function find_template
def test_find_template():
    from shutil import rmtree
    from cookiecutter import repo

    # Python 3's tarfile module is b0rken for tarballs with non-ASCII filenames
    # https://bugs.python.org/issue27806
    if os.name != 'nt':
        return

    current_dir = os.path.abspath(os.path.dirname(__file__))
    test_files_dir = os.path.join(current_dir, 'test-files')
    test_repo_dir = os.path.join(test_files_dir, 'test-repo')
    repo.clone(
        repo_url='file:///{0}'.format(test_repo_dir),
        checkout=None
    )

# Generated at 2022-06-23 16:17:18.248535
# Unit test for function find_template
def test_find_template():
    find_template('/home/ryan/.cache/cookiecutters/cookiecutter-pypackage')

# Generated at 2022-06-23 16:17:21.171665
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/test-repo'
    project_template = find_template(repo_dir)
    assert project_template == './tests/test-repo/{{cookiecutter.project_slug}}'

# Generated at 2022-06-23 16:17:22.968469
# Unit test for function find_template
def test_find_template():
    repo_dir = '{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == repo_dir

# Generated at 2022-06-23 16:17:24.884919
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo/'
    assert find_template(repo_dir) == 'tests/test-repo/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:17:33.210496
# Unit test for function find_template
def test_find_template():
    """Test if find_template works as expected"""
    actual_template = find_template(os.path.join(os.path.dirname(__file__), 'fixtures'))
    assert actual_template.endswith('fixtures/cookiecutter-pypackage')

    non_templated_input_dir_exception_raised = False
    try:
        find_template(os.path.join(os.path.dirname(__file__), 'fixtures', 'non_templated_input_dir'))
    except NonTemplatedInputDirException:
        non_templated_input_dir_exception_raised = True
    assert non_templated_input_dir_exception_raised

# Generated at 2022-06-23 16:17:38.300002
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find a project template in the test repo."""
    from cookiecutter.tests.test_repository import test_repo_dir
    test_template = find_template(test_repo_dir)

    assert 'fake-repo-pre/' in test_template
    assert 'fake-repo-post/' not in test_template

# Generated at 2022-06-23 16:17:42.745050
# Unit test for function find_template
def test_find_template():
    """Test the find template function."""
    assert 'my-project' == find_template('/home/audreyr/cookiecutters/my-project')
    assert 'my-project' == find_template('/home/audreyr/cookiecutters/my-project/')

# Generated at 2022-06-23 16:17:47.076073
# Unit test for function find_template
def test_find_template():
    test_repo_dir = 'tests/fixtures/fake-repo-tmpl'
    assert find_template(test_repo_dir) == 'tests/fixtures/fake-repo-tmpl/cookiecutter-pypackage'

# Generated at 2022-06-23 16:17:56.533357
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    assert os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        'fake_file.txt'
    ), find_template(repo_dir)

# Generated at 2022-06-23 16:17:58.145847
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected."""
    pass

# Generated at 2022-06-23 16:18:02.930087
# Unit test for function find_template
def test_find_template():
    """
    Check that find_template returns the subdirectory named
    my_project_template, when the repo is cloned.
    """
    repo_dir = 'tests/test-repo/identify-project-template'
    project_template = find_template(repo_dir)
    assert project_template.endswith('my_project_template')

# Generated at 2022-06-23 16:18:10.153702
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
        'cookiecutter-django',
    )
    expected_output = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}',
    )
    assert find_template(repo_dir) == expected_output

# Generated at 2022-06-23 16:18:11.605933
# Unit test for function find_template
def test_find_template():
    """Verify function ``find_template``."""

    pass

# Generated at 2022-06-23 16:18:17.688570
# Unit test for function find_template
def test_find_template():
    os.environ['TESTING'] = 'True'
    logger.info('Starting find_template unit test')
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '../tests/fake-repo-pre-gen/'
    ))
    assert '{{cookiecutter.repo_name}}' in find_template(repo_dir)
    logger.info('find_template unit test passed')

# Generated at 2022-06-23 16:18:18.154873
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:18:18.785919
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:18:28.106087
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find the template."""
    from cookiecutter.tests.test_utils.paths import (
        PRE_GENERATED_PROJECT_TEMPLATE
    )
    template = find_template(
        PRE_GENERATED_PROJECT_TEMPLATE
    )

    # Check that the template is just the template, without the root
    # project_dir.
    assert template == './{{cookiecutter.repo_name}}', (
        'Expected find_template to return a relative path to the '
        'project template'
    )

# Generated at 2022-06-23 16:18:36.594139
# Unit test for function find_template
def test_find_template():
    """Verify ``find_template`` works like it should.
    """
    from unittest.mock import patch, mock_open
    from cookiecutter.utils import work_in, rmtree

    m = mock_open()
    with patch('cookiecutter.utils.open', m, create=True):
        with patch('os.path.isfile') as mock_isfile:
            mock_isfile.return_value = True
            with patch('os.path.isdir') as mock_isdir:
                mock_isdir.return_value = True
                with patch('os.listdir'):
                    with work_in('tests/fake-repo-tmpl'):
                        assert find_template('.')



# Generated at 2022-06-23 16:18:44.606744
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.utils.paths import ensure_directory

    with TemporaryDirectory() as template_dir:
        ensure_directory(template_dir)
        for item in ['some_file', 'cookiecutter{{cookiecutter.repo_name}}',
                     'cookiecutter_doesnt_work', 'cookiecutterfoo{{']:
            shutil.copy(
                os.path.join(
                    os.path.dirname(__file__),
                    '..', 'tests', 'test-repo', '{{cookiecutter.repo_name}}',
                    'README.rst'
                ), os.path.join(template_dir, item)
            )

# Generated at 2022-06-23 16:18:55.458871
# Unit test for function find_template
def test_find_template():
    """Unit test for function."""
    from cookiecutter import repo

    cloned_repo = repo.clone(
        'https://github.com/audreyr/cookiecutter-pypackage.git')
    cloned_repo = os.path.join(cloned_repo, 'cookiecutter-pypackage')
    cloned_repo_contents = os.listdir(cloned_repo)
    expected_template = None
    for item in cloned_repo_contents:
        # Project template
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            expected_template = item
            break
    expected_template = os.path.join(cloned_repo, expected_template)


# Generated at 2022-06-23 16:18:59.673039
# Unit test for function find_template
def test_find_template():
    result = find_template("C:\\Users\\<username>\\cookiecutter-pypackage")
    assert result == "C:\\Users\\<username>\\cookiecutter-pypackage\\cookiecutter-pypackage"
    print("test_find_template() - success")

# Generated at 2022-06-23 16:19:04.163842
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    path = 'tests/fake-repo-tmpl'
    project_template = find_template(path)
    assert project_template == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:08.232839
# Unit test for function find_template
def test_find_template():
    """Test finding the project template."""
    from . import utils
    from . import exceptions

    repo_dir = utils.code_dir(__file__)
    project_template = find_template(repo_dir)
    assert project_template.endswith('cookiecutter-pypackage')

    broken_dir = os.path.join(repo_dir, 'tests', 'files', 'broken-template')
    with pytest.raises(exceptions.NonTemplatedInputDirException):
        find_template(broken_dir)


# Generated at 2022-06-23 16:19:08.883862
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:19:09.996227
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    pass

# Generated at 2022-06-23 16:19:15.403460
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/files/input_proj_repo'
    project_template = find_template(repo_dir)
    logger.debug("the project template is %s", project_template)
    assert project_template == 'tests/files/input_proj_repo/bin'

test_find_template()

# Generated at 2022-06-23 16:19:16.768881
# Unit test for function find_template
def test_find_template():
    """Test find_template function"""
    raise NotImplementedError

# Generated at 2022-06-23 16:19:24.519496
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template() function.
    """
    from cookiecutter.utils import rmtree

    # Create a temporary working directory
    tmp_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..',
                           '..', 'test-find-template')
    os.makedirs(tmp_dir)
    # Create a simple Cookiecutter template inside tmp_dir
    cookiecutter_dir = os.path.join(tmp_dir, 'cookiecutter-find-template')
    os.makedirs(cookiecutter_dir)
    # Call the function to test
    project_template = find_template(tmp_dir)
    # Remove temporary dir
    rmtree(tmp_dir)

    # Assert that the correct path to the project

# Generated at 2022-06-23 16:19:34.637610
# Unit test for function find_template
def test_find_template():
    """Verify whether find_template() works."""
    import tempfile
    from cookiecutter.generate import generate_context

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:19:43.972784
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct directory name."""
    # Build a directory for a cookiecutter template
    repo_dir = os.path.abspath(os.path.join(
        os.getcwd(), 'tests/test-find-template/{{cookiecutter.repo_name}}'))
    if not os.path.exists(repo_dir):
        os.makedirs(repo_dir)
    # Create a file that is not the project template
    not_the_project_template = os.path.join(
        repo_dir,
        'not-{{cookiecutter.repo_name}}-the-project-template')
    with open(not_the_project_template, 'w') as f:
        f.write('nope')
    # Create a file that is the project template

# Generated at 2022-06-23 16:19:55.103523
# Unit test for function find_template
def test_find_template():
    """Verify that find_template can find the project template."""
    import os
    import shutil
    import tempfile

    from cookiecutter.exceptions import NonTemplatedInputDirException

    def _create_dir(dir_name, dir_contents):
        os.mkdir(dir_name)
        open(os.path.join(dir_name, 'test_file1'), 'w').close()
        os.mkdir(os.path.join(dir_name, dir_contents))
        open(os.path.join(dir_name, dir_contents, 'test_file2'), 'w').close()

        return dir_name

    temp_dir = tempfile.mkdtemp()
    logger.debug('Temp dir is at %s', temp_dir)


# Generated at 2022-06-23 16:19:58.362569
# Unit test for function find_template
def test_find_template():
    """Verify find_template() function works."""
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/fake-project'

# Generated at 2022-06-23 16:20:03.915621
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests/test-data/fake-repo/"
    template = find_template(repo_dir)
    assert template == "tests/test-data/fake-repo/tests/test-data/fake-repo"



# Generated at 2022-06-23 16:20:10.148587
# Unit test for function find_template
def test_find_template():
    """Test the finding of a project template directory."""
    assert(
        find_template('tests/test-generate/fake-repo-tmpl')
        == 'tests/test-generate/fake-repo-tmpl/{{project_name}}'
    )

    assert(
        find_template('tests/test-generate/fake-repo-nontmpl')
        == 'tests/test-generate/fake-repo-nontmpl/{{cookiecutter.project_name}}'
    )

# Generated at 2022-06-23 16:20:10.664793
# Unit test for function find_template
def test_find_template():
    """."""

# Generated at 2022-06-23 16:20:14.052893
# Unit test for function find_template
def test_find_template():
    print("Testing find_template")
    repo_dir = "C:\\Users\\xmlyu\\Desktop\\Cookiecutter\\test_dir"
    project_templae = find_template(repo_dir)
    print("The project template is %s" % project_templae)

# Generated at 2022-06-23 16:20:22.345394
# Unit test for function find_template
def test_find_template():
    """Verify function find_template works as expected."""

    import tempfile
    import shutil
    import os

    # Create two directories
    temp_dir = tempfile.mkdtemp()
    template_dir = os.path.join(temp_dir, 'cookiecutter-foobar')
    os.mkdir(template_dir)

    # Create two non-template files and directories
    non_template_file = os.path.join(temp_dir, 'README.md')
    non_template_dir = os.path.join(temp_dir, 'random_dir')
    os.mknod(non_template_file)
    os.mkdir(non_template_dir)

    # Create a template file, with and without brackets

# Generated at 2022-06-23 16:20:27.900379
# Unit test for function find_template
def test_find_template():
    repo_dir = '{{ cookiecutter.repo_name }}'
    assert(find_template(repo_dir) == os.path.join(repo_dir, '{{ cookiecutter.repo_name }}'))

# Generated at 2022-06-23 16:20:34.849060
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    import pytest
    import shutil
    import tempfile

    # Create a temporary repository to clone
    temp_repo_dir = os.path.join(tempfile.mkdtemp(), 'repo')
    cookiecutter('tests/fake-repo-pre/', no_input=True, output_dir=temp_repo_dir)

    with pytest.raises(NonTemplatedInputDirException):
        project_template = find_template(temp_repo_dir)

    # Remove temp repo dir
    shutil.rmtree(temp_repo_dir)

# Generated at 2022-06-23 16:20:46.254918
# Unit test for function find_template
def test_find_template():
    """Test function `find_template`."""
    import tempfile
    import shutil
    import textwrap

    local_repo_path = tempfile.mkdtemp()
    empty_repo_path = tempfile.mkdtemp()


# Generated at 2022-06-23 16:20:49.567360
# Unit test for function find_template
def test_find_template():
    """Find the project template inside the repo_dir."""
    try:
        find_template('test')
    except NonTemplatedInputDirException:
        # That's a good thing in this case
        pass

# Generated at 2022-06-23 16:20:56.113210
# Unit test for function find_template
def test_find_template():
    """
    Test the function find_template
    """
    from cookiecutter.find import find_template

    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-pre')

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')


# Generated at 2022-06-23 16:21:07.617252
# Unit test for function find_template
def test_find_template():
    import tempfile
    from shutil import rmtree
    from cookiecutter import repo
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = repo.clone("https://github.com/wdjungst/cookiecutter-pypackage-minimal.git")
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = tempfile.mkdtemp()
    logger.debug('Created temporary directory %s', repo_dir)


# Generated at 2022-06-23 16:21:11.539489
# Unit test for function find_template
def test_find_template():
    """ Test for function find_template """
    from cookiecutter import find
    repo_dir = find.find_template()
    repo_dir_contents = os.listdir(repo_dir)
    assert repo_dir == repo_dir_contents

# Generated at 2022-06-23 16:21:17.832474
# Unit test for function find_template
def test_find_template():
    """Verify function with a test file structure."""
    import tempfile
    import shutil
    import textwrap

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a test file structure
    os.mkdir(os.path.join(tmp_dir, 'my-project'))
    with open(os.path.join(tmp_dir, 'README'), 'w') as f:
        f.write('README file')
    os.mkdir(os.path.join(tmp_dir, 'my-project', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-23 16:21:22.425748
# Unit test for function find_template
def test_find_template():
    print ('****************************')
    print ('Testing find_template')
    print ('****************************')
    assert os.path.isdir(find_template('/home/jason/coding/cookiecutter-pypackage')) == True
    print ('Test find_template successful')



# Generated at 2022-06-23 16:21:32.976438
# Unit test for function find_template
def test_find_template():
    import os
    from cookiecutter.main import cookiecutter
    from cookiecutter.exceptions import NonTemplatedInputDirException

    def _test_find_template(test_dir, filenames, project_template_expected=None):
        if project_template_expected is None:
            with pytest.raises(NonTemplatedInputDirException):
                os.listdir(test_dir)
                for file in filenames:
                    open(os.path.join(test_dir, file), 'w').close()
                find_template(test_dir)
        else:
            os.listdir(test_dir)
            for file in filenames:
                open(os.path.join(test_dir, file), 'w').close()
            project_template_actual = find_template(test_dir)


# Generated at 2022-06-23 16:21:36.808250
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.abspath('tests/fake-repo-pre/'))
    assert find_template(os.path.abspath('tests/fake-repo-pre/')) == os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_name}}' )

# Generated at 2022-06-23 16:21:40.151632
# Unit test for function find_template
def test_find_template():
    cc_dir = 'tests/test-cookiecutters/pymodule-jinja2'
    pymodule_template = find_template(cc_dir)
    assert pymodule_template == 'tests/test-cookiecutters/pymodule-jinja2/pymodule-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:47.792593
# Unit test for function find_template
def test_find_template():
    """Ensure that the right child directory is found as the project template"""
    project_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')

    repo_dir = find_template(project_dir)
    repo_dir_name = '{{cookiecutter.repo_name}}'
    expected_dir = os.path.join(project_dir, repo_dir_name)
    expected_dir = expected_dir.replace(os.sep, '/')  # for Windows
    assert repo_dir == expected_dir

# Generated at 2022-06-23 16:21:55.615700
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == '/Users/audreyr/projects/cookiecutter-pypackage/cookiecutter-pypackage'
    assert find_template('/Users/audreyr/projects/cookiecutter-pypackage') == '/Users/audreyr/projects/cookiecutter-pypackage'



# Generated at 2022-06-23 16:21:56.564382
# Unit test for function find_template

# Generated at 2022-06-23 16:22:06.784473
# Unit test for function find_template
def test_find_template():
    import os
    from shutil import rmtree
    from .compat import TemporaryDirectory
    from .main import cookiecutter

    # Clone test repo
    with TemporaryDirectory(prefix='cookiecutter-') as tmpdir:
        cookiecutter('tests/test-repo/', no_input=True, output_dir=tmpdir)
        assert os.path.isdir(os.path.join(tmpdir, '{{cookiecutter.repo_name}}'))

        # Find the template inside the `cookiecutter-{{cookiecutter.repo_name}}` repo
        repo_dir = os.path.join(tmpdir, '{{cookiecutter.repo_name}}')
        project_template = find_template(repo_dir)

# Generated at 2022-06-23 16:22:15.682161
# Unit test for function find_template
def test_find_template():
    # Create a temporary directory for testing purposes
    # Needs to be deleted
    import sys, os, shutil, tempfile
    from cookiecutter.main import cookiecutter
    from cookiecutter.exceptions import RepositoryNotFound, InvalidModeException

    # Set a temporary directory and clone the repo
    tmp_dir = tempfile.mkdtemp()

    # Need to create a dummy repo, otherwise it won't work
    cc_dir = cookiecutter(
        'https://github.com/noirbizarre/cookiecutter-pypackage-minimal.git',
        checkout='master',
        no_input=True,
        quiet=True,
        replay=False,
        output_dir=tmp_dir,
        overwrite_if_exists=True
    )

    # Test whether the cookiecutter template exists