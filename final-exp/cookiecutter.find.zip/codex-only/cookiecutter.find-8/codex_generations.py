

# Generated at 2022-06-23 16:12:29.292996
# Unit test for function find_template
def test_find_template():
    from cookiecutter.repository import determine_repo_dir
    from cookiecutter import config
    from cookiecutter import utils

    # Create a fake cookiecutter.json file

    # Create a fake git repo
    repo_dir = '/home/vanessa/code/cookiecutter-djangopackage'

    # Template dir within fake git repo
    template_dir = '/home/vanessa/code/cookiecutter-djangopackage/{{cookiecutter.project_name}}'

    repo_dir = determine_repo_dir(repo_dir, {}, config.get_user_config())

# Generated at 2022-06-23 16:12:33.286347
# Unit test for function find_template
def test_find_template():
    """Check if find_template returns the template directory."""
    input_dir = os.path.abspath('tests/fake-repo-pre/fake-repo')
    output_dir = find_template(input_dir)
    assert os.path.basename(output_dir) == '{{cookiecutter.project_slug}}'



# Generated at 2022-06-23 16:12:36.777570
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""
    repo_dir = os.path.join('tests', 'test-find-template')

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:12:39.943507
# Unit test for function find_template
def test_find_template():
    assert find_template('Users/audreyr/cookiecutter-pypackage') == 'Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:12:49.285920
# Unit test for function find_template
def test_find_template():
    """Test the find_template function"""
    # Setup
    os.system("mkdir tests/test-find-template")
    os.system("touch tests/test-find-template/testfile")
    os.system("cp -rf tests/fake-repo/tests tests/test-find-template/")
    os.system("cp -rf tests/fake-repo/tests2 tests/test-find-template/")
    os.system("cp -rf tests/fake-repo/tests3 tests/test-find-template/")

    # Test
    output = find_template('tests/test-find-template/')
    output = os.path.basename(output)
    assert 'tests' == output

    os.system("rm -r tests/test-find-template/")


# Generated at 2022-06-23 16:12:54.439482
# Unit test for function find_template
def test_find_template():
    """
    Return the path to the only directory in the repo directory which contains
    the string `cookiecutter` and at least one other Jinja2 tag.
    """

    os.chdir('tests/test-repo/')
    project_template = find_template('.')
    assert project_template == './cookiecutter-pypackage'

    os.chdir('../..')

# Generated at 2022-06-23 16:12:58.690585
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/code/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    # TODO: Add a test for non-templated input directory

# Generated at 2022-06-23 16:13:04.973157
# Unit test for function find_template
def test_find_template():
    """Check that the find_template function finds the expected path."""
    # templates/{{cookiecutter.repo_name}}
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-templates',
        'test-repo'
    )

    expected_template = os.path.join(
        repo_dir,
        'templates',
        '{{cookiecutter.repo_name}}'
    )

    found_template = find_template(repo_dir)
    assert found_template == expected_template

# Generated at 2022-06-23 16:13:11.641062
# Unit test for function find_template
def test_find_template():
    """
    test find_template function
    """
    template_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(template_dir)
    assert project_template == os.path.join(template_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-23 16:13:19.476230
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from tests.test_main import get_basic_template
    from testfixtures import LogCapture, compare

    basic_template = get_basic_template()

    utils.find_template(basic_template)

    compare(
        LOG_MESSAGE,
        "DEBUG:cookiecutter.utils:Searching {} for the project template.\n"
        "DEBUG:cookiecutter.utils:The project template appears to be {}\n".format(basic_template,
                                                                                  basic_template)
    )

# Generated at 2022-06-23 16:13:28.130478
# Unit test for function find_template
def test_find_template():
    """Unit test to ensure that the function find_template returns the directory that
    is the cookiecutter project template."""
    # Test functionality for finding the project template
    template_dir = find_template("/Users/John/Desktop/cookiecutter-pypackage")
    assert template_dir == "/Users/John/Desktop/cookiecutter-pypackage/cookiecutter-{{ cookiecutter.project_name }}"

# Test for finding the project template in the case that no project template exists

# Generated at 2022-06-23 16:13:29.589551
# Unit test for function find_template
def test_find_template():
    find_template('D:/projects/cookiecutter-django')

# Generated at 2022-06-23 16:13:35.040796
# Unit test for function find_template
def test_find_template():
    parent_dir = os.path.abspath(os.path.dirname(__file__))

# Generated at 2022-06-23 16:13:43.793218
# Unit test for function find_template
def test_find_template():
    """
    Test if the non-templated project is identified.
    """
    if os.path.isdir('./tests/test_repo/cookiecutter-pypackage'):
        os.system('rm -rf ./tests/test_repo/cookiecutter-pypackage')
    os.system('cp -R ./tests/test-cookiecutters/cookiecutter-pypackage ./tests/test_repo')
    repo_dir = os.path.abspath('./tests/test_repo/cookiecutter-pypackage')

    find_template(repo_dir)

# Generated at 2022-06-23 16:13:50.673675
# Unit test for function find_template
def test_find_template():
    """Check that find_template() is able to find the template dir."""
    from cookiecutter import main
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(main.__file__),
            'tests/test-repo-pre-commit-hook/fake-repo'
        )
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:59.048231
# Unit test for function find_template
def test_find_template():
    """ Sanity check for find_template
    """
    testpath = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'input',
        'tests',
        'django_cookiecutter_cookiecutter',
        '{{cookiecutter.repo_name}}',
    )
    template = find_template(testpath)
    assert 'cookiecutter.json' in os.listdir(template)

# Generated at 2022-06-23 16:14:10.136644
# Unit test for function find_template
def test_find_template():
    # Create a temporary directory for storing our test repository
    import tempfile
    temp_dir = tempfile.mkdtemp()

    project_name = 'example_project'
    project_dir = os.path.join(temp_dir, project_name)
    os.mkdir(project_dir)
    os.mkdir(os.path.join(project_dir, 'cookiecutter'))

    # Fails if the project template doesn't notice the missing {{ }}
    try:
        find_template(project_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception("find_template() did not fail when it should have.")

    # Should succeed when the "cookiecutter" template directory exists

# Generated at 2022-06-23 16:14:18.240252
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    cookiecutter(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        no_input=True,
        output_dir='/tmp',
    )
    assert os.path.exists('/tmp/cookiecutter-pypackage')
    template_repo_path = os.path.join(
        utils.get_user_dir(),
        'repos',
        'https%3A%2F%2Fgithub.com%2Faudreyr%2Fcookiecutter-pypackage.git'
    )
    assert os.path.exists(template_repo_path)
    assert find_template(template_repo_path)

# Generated at 2022-06-23 16:14:22.031173
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-data/fake-repo/') == 'tests/test-data/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:14:30.132795
# Unit test for function find_template
def test_find_template():
    temp_dir = tempfile.mkdtemp()
    test_templates_dir = os.path.join(temp_dir, 'templates')
    test_template_name = 'my-cookiecutter-template'
    test_template_path = os.path.join(test_templates_dir, test_template_name)
    os.makedirs(test_template_path)

    assert find_template(test_templates_dir) == test_template_path
    assert find_template(test_template_path) == test_template_path
    assert find_template(temp_dir) == None

# Generated at 2022-06-23 16:14:35.638703
# Unit test for function find_template
def test_find_template():
    """Test function find_template with a simple example."""
    repo_dir = 'tests/fixtures/non-templated-input-dir/repo-with-templated-dir'
    project_template = find_template(repo_dir)

    assert project_template == 'tests/fixtures/non-templated-input-dir/repo-with-templated-dir/repo-{{project_name}}-dir'

# Generated at 2022-06-23 16:14:41.270854
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from ..compat import StringIO

    repo_dir = utils.workdir()
    with StringIO('{{ cookiecutter.project }}') as f:
        f.name = os.path.join(repo_dir, 'project{{ cookiecutter.project }}')
        assert os.path.exists(f.name)
        assert find_template(repo_dir) == f.name
        os.remove(f.name)
        assert not os.path.exists(f.name)

# Generated at 2022-06-23 16:14:46.797900
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template."""
    template_found = find_template('tests/test-repos')
    assert template_found == 'tests/test-repos/{% if cookiecutter.framework == "django" %}django_app/{% endif %}', \
        "Unexpected path for found project template."

# Generated at 2022-06-23 16:14:51.521310
# Unit test for function find_template
def test_find_template():
    """Find template in a repo."""
    print("\n")
    test_repo_dir = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    print("Testing find_template(%s):" % test_repo_dir)
    project_dir = find_template(test_repo_dir)
    print("Project directory is: %s" % project_dir)
    print("\n")


# Generated at 2022-06-23 16:14:56.623464
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    expected_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    found_template = find_template(repo_dir)

    assert found_template == expected_template

# Generated at 2022-06-23 16:14:57.512216
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:15:04.511340
# Unit test for function find_template
def test_find_template():
    """Test find_template
    """
    tests_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests')
    )
    input_filename = os.path.join(
        tests_dir, 'fake-repo', '{{cookiecutter.repo_name}}'
    )

    assert find_template(os.path.join(tests_dir, 'fake-repo')) == input_filename

# Generated at 2022-06-23 16:15:06.860081
# Unit test for function find_template
def test_find_template():
    """Test for finding project template."""
    path_to_template = find_template('cookiecutter/tests/fake-repo-pre/')

# Generated at 2022-06-23 16:15:12.851605
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    test_repo_dir = 'temp/test_find_template'
    os.makedirs(test_repo_dir)
    test_project = '{{cookiecutter.project_template}}'

    with open(os.path.join(test_repo_dir, test_project), 'a'):
        os.utime(os.path.join(test_repo_dir, test_project), None)

    assert find_template(test_repo_dir) == os.path.join(test_repo_dir, test_project)
    os.remove(os.path.join(test_repo_dir, test_project))
    os.removedirs(test_repo_dir)

# Generated at 2022-06-23 16:15:13.703363
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-23 16:15:14.475321
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:15:21.962967
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function"""

    test_repo_dir = os.path.join(os.path.dirname(__file__), 'test-data', 'repo-templates', 'test-1')
    project_template = find_template(test_repo_dir)

    expected_dir = os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_dir

# Generated at 2022-06-23 16:15:25.545860
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    assert find_template('/Users/audreyr/cookiecutter-pypackage') == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:37.537778
# Unit test for function find_template
def test_find_template():
    """Test find_template function with a simple template repo."""
    from .repository import clone
    from .utils import rmtree
    from .compat import environment_marker_supported

    if environment_marker_supported():
        expected = 'test_template_pypi/{{cookiecutter.package_name}}'
    else:
        expected = 'test_template_pypi/django_cookiecutter_{{cookiecutter.repo_name}}'

    template_path = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_path = 'test_template_pypi'
    clone(template_path, repo_path)
    template_dir = find_template(repo_path)
    assert template_dir == expected


# Generated at 2022-06-23 16:15:47.513275
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import os

    def create_folder_with_contents(contents, path=tempfile.mkdtemp()):
        """Create a directory with the given contents at temp path."""
        basepath = os.path.join(path, '')
        for item in contents:
            os.makedirs(basepath + item)
        return path

    def destroy_folder_with_contents(path):
        """Delete the directory with contents at the given path."""
        shutil.rmtree(path)

    # Create a directory with subdirectories
    substop = ['a cookiecutter {{ project }}', 'b cookiecutter', 'c']
    test_dir = create_folder_with_contents(substop)

# Generated at 2022-06-23 16:15:51.810866
# Unit test for function find_template
def test_find_template():
    """Verify that the template is found."""

# Generated at 2022-06-23 16:15:52.941840
# Unit test for function find_template
def test_find_template():
    find_template('/Users/j/cookiecutter-django/cookiecutter-django')

# Generated at 2022-06-23 16:16:01.795695
# Unit test for function find_template
def test_find_template():
    """Verify that find template returns the directory path of a template."""
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    new_dir = os.path.join(temp_dir, 'new_dir')
    os.mkdir(new_dir)
    template_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)

    try:
        assert find_template == template_dir
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-23 16:16:02.241691
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:03.752472
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests'
    assert find_template(repo_dir) == 'tests/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:16:07.700532
# Unit test for function find_template
def test_find_template():

    repo_dir = '/home/audreyr/cookiecutter-pypackage'

    project_template = find_template(repo_dir)

    assert project_template == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:16.606624
# Unit test for function find_template
def test_find_template():
    import tempfile, shutil
    from cookiecutter import utils

    tmpdir = tempfile.mkdtemp()
    cookiecutter_dir = os.path.join(tmpdir, 'cookiecutter-test-repo')
    utils.make_sure_path_exists(cookiecutter_dir)

    with open(os.path.join(cookiecutter_dir, 'foo'), 'w') as f:
        f.write('foo')
    with open(os.path.join(cookiecutter_dir, 'cookiecutter.json'), 'w') as f:
        f.write('{"foo": "bar"}')

    project_template = find_template(cookiecutter_dir)
    assert project_template == os.path.join(cookiecutter_dir, 'cookiecutter.json')


# Generated at 2022-06-23 16:16:22.013151
# Unit test for function find_template
def test_find_template():
    # Simple case
    fake_repo_dir = '/home/audreyr/fake-repo-dir'
    assert find_template(fake_repo_dir) == \
        os.path.join(fake_repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:16:27.832354
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(test_dir, 'fake-repo')

    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:16:29.008525
# Unit test for function find_template
def test_find_template():
    """
    Unit testing for find_template function.
    """
    find_template("github_repository")

# Generated at 2022-06-23 16:16:30.899896
# Unit test for function find_template
def test_find_template():
    assert find_template("tests/test_repo/repo-tmpl") == "tests/test_repo/repo-tmpl/{{cookiecutter.repo_name}}"

# Generated at 2022-06-23 16:16:33.761240
# Unit test for function find_template
def test_find_template():
    find_template("~/Desktops/Cookiecutter/cookiecutter")

# Generated at 2022-06-23 16:16:35.795072
# Unit test for function find_template
def test_find_template():
    result = find_template('/Users/bradley/Documents/code/repo-name/')
    assert result == '/Users/bradley/Documents/code/repo-name/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:39.914465
# Unit test for function find_template
def test_find_template():
    """Test a simple case of find_template."""
    workdir = '/fake/path/{{cookiecutter.repo_name}}'
    repo_dir = '/fake/path'
    template = find_template(repo_dir)
    assert template is workdir

# Generated at 2022-06-23 16:16:42.767973
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-data/fake-repo-tmpl') == (
        'tests/test-data/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:16:49.700837
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    from cookiecutter import generate
    from cookiecutter.utils import rmtree
    from cookiecutter.exceptions import NonTemplatedInputDirException

    main.cookiecutter('https://github.com/audreyr/cookiecutter-pypackage.git')

    project_template = find_template('cookiecutter-pypackage')

    assert project_template == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    rmtree('cookiecutter-pypackage')

    # Test error message
    try:
        find_template('/tmp')
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

    rmtree('cookiecutter-pypackage')

# Generated at 2022-06-23 16:16:53.152708
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage/'
    project_template = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}/'
    assert(find_template(repo_dir)) == project_template

# Generated at 2022-06-23 16:16:54.321593
# Unit test for function find_template
def test_find_template():
    """Test for find_template()."""
    pass



# Generated at 2022-06-23 16:16:59.764754
# Unit test for function find_template
def test_find_template():
    print('Testing function find_template.')

    # Setup
    test_input_repo = os.path.join(os.path.dirname(__file__), 'fake-repo')
    os.chdir(test_input_repo)

    # Expected result
    expected_result = os.path.join(test_input_repo, '{{cookiecutter.repo_name}}')

    # Test
    assert(find_template(test_input_repo) == expected_result)


# Generated at 2022-06-23 16:17:06.671634
# Unit test for function find_template
def test_find_template():
    """Verify function can locate project template inside a folder."""
    from .compat import unittest
    from .mock import mock

    # Mock out repo_dir, which is normally a local directory.
    repo_dir = mock.MagicMock()

    # Mock out repo_dir.listdir, which is normally a directory listing.
    # We always want to return a list containing the project template.
    repo_dir.listdir.return_value = [
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}/some_file.txt',
    ]

    # Call find_template
    template = find_template(repo_dir)

    # Confirm that repo_dir.listdir was only called once

# Generated at 2022-06-23 16:17:12.651176
# Unit test for function find_template
def test_find_template():
    """Test `find_template`."""
    from cookiecutter.tests.test_utils import test_dir

    repo_dir = os.path.join(test_dir, 'fake-repo-tmpl')

    project_template_path = find_template(repo_dir)

    assert project_template_path == os.path.join(
        test_dir, 'fake-repo-tmpl', '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:17:22.741560
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.main import cookiecutter
    import os
    import shutil
    import tempfile
    import textwrap


# Generated at 2022-06-23 16:17:23.907556
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:17:26.556080
# Unit test for function find_template
def test_find_template():
    # TODO: better test for this - we should have an output
    #       directory with both templated and non-templated
    #       items.
    test_find_template()

# Generated at 2022-06-23 16:17:28.853891
# Unit test for function find_template
def test_find_template():
    """Validate that find_template returns the correct values."""
    assert find_template('tests/fake-repo-tmpl/') == \
        'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:32.864450
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-find-template'))
    project_template = find_template(test_repo_dir)
    assert 'the-real-project-template' in project_template

# Generated at 2022-06-23 16:17:38.268488
# Unit test for function find_template
def test_find_template():
    """
    Verify if the function find_template is able to find a valid template
    directory.
    """
    from cookiecutter.tests.test_find import fixture_repo
    template = find_template(fixture_repo('foobar-cookiecutter'))
    assert template == fixture_repo('foobar-cookiecutter/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:17:46.459404
# Unit test for function find_template
def test_find_template():
    """ Verifies that find_template can find a template from a valid directory """
    import tempfile
    from os.path import join
    from shutil import rmtree

    repo_dir = tempfile.mkdtemp()
    test_project_template = join(repo_dir, "test{{cookiecutter.test_var}}")

    open(test_project_template, 'a').close()

    assert(find_template(repo_dir) == test_project_template)

    # Clean up
    rmtree(repo_dir)



# Generated at 2022-06-23 16:17:58.430364
# Unit test for function find_template
def test_find_template():
    """Test the find_template function for a few cases."""
    test_dir = os.path.dirname(__file__)

    with open(os.path.join(test_dir, 'cc-rego.json')) as fh:
        tmpl = find_template(fh.read())
    assert tmpl == '{{cookiecutter.repo_name}}'

    with open(os.path.join(test_dir, 'cc-jinja2.json')) as fh:
        tmpl = find_template(fh.read())
    assert tmpl == '{{cookiecutter.repo_name}}'

    with open(os.path.join(test_dir, 'cc-ansible.json')) as fh:
        tmpl = find_template(fh.read())

# Generated at 2022-06-23 16:18:01.202010
# Unit test for function find_template
def test_find_template():
    assert find_template('/path/to/cookiecutter-pypackage') == '/path/to/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:05.174281
# Unit test for function find_template
def test_find_template():
    """
    Test that project template is found and returned properly.
    """
    repo_dir = './tests/fake-repo-tmpl'
    project_dir = find_template(repo_dir)
    assert project_dir == os.path.join(repo_dir, 'fake-project-tmpl')
    return

# Generated at 2022-06-23 16:18:14.372509
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    # Test with no cookiecutter files in the repo
    no_cookiecutter_dir = '/usr/bin'
    assert find_template(no_cookiecutter_dir) is None

    # Test with a basic project template
    project_template_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        os.pardir,
        'tests',
        'fake-repo-pre',
        '{{cookiecutter.repo_name}}',
    )
    assert find_template(project_template_dir) == project_template_dir

# Generated at 2022-06-23 16:18:18.459458
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    cwd = os.getcwd()
    os.chdir('tests/test-data/')
    project_template = find_template('cookiecutter-pypackage')
    assert 'cookiecutter-pypackage/{{cookiecutter.project_slug}}' == project_template

    os.chdir('../..')
    os.chdir(cwd)

# Generated at 2022-06-23 16:18:26.463837
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.main import cookiecutter

    template_dir = tempfile.mkdtemp()
    cookiecutter(
        template_dir,
        no_input=True
    )
    expected_project_template = os.path.join(
        template_dir,
        'cookiecutter-{{cookiecutter.repo_name}}'
    )
    project_template = find_template(template_dir)
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:18:36.718631
# Unit test for function find_template
def test_find_template():
    """Unit tests for find_template"""
    # Setup
    import shutil
    from tempfile import mkdtemp
    from unittest import TestCase
    from cookiecutter import exceptions
    from cookiecutter import utils
    from tests.test_find_template_data import find_template_data
    import os

    class TestFindTemplate(TestCase):
        @classmethod
        def setUpClass(cls):
            cls.test_path = mkdtemp()

        @classmethod
        def tearDownClass(cls):
            shutil.rmtree(cls.test_path)

        def setUp(self):
            self.repo_dir = os.path.join(self.test_path, 'fake-repo')
            os.mkdir(self.repo_dir)


# Generated at 2022-06-23 16:18:41.567579
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'tests', 'fake-repo', '{{cookiecutter.repo_name}}')
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, 'fake-repo-master')

# Generated at 2022-06-23 16:18:43.255726
# Unit test for function find_template
def test_find_template():
    """
    Initialize the test.

    :returns: None
    """
    pass

# Generated at 2022-06-23 16:18:44.775610
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/home') == '/home/home/cookiecutter'

# Generated at 2022-06-23 16:18:49.947203
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/okken/src/cookiecutter/tests/test-repo/') == '/home/okken/src/cookiecutter/tests/test-repo/cookiecutter-pypackage'

# Generated at 2022-06-23 16:18:56.821557
# Unit test for function find_template
def test_find_template():
    """Test `find_template` function."""
    try:
        find_template('tests/fake-repo-tmpl')
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('test_find_template: Expected test to pass '
                        'NonTemplatedInputDirException but it did not.')

    assert find_template('tests/fake-repo-pre/') == \
        os.path.abspath('tests/fake-repo-pre/fake-project-tmpl')

# Generated at 2022-06-23 16:19:01.878939
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-input'
    )
    template = find_template(repo_dir=repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:19:04.993098
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/cookiecutter-pypackage') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:16.319187
# Unit test for function find_template
def test_find_template():
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.prompt import read_user_yes_no

    with TemporaryDirectory(prefix='cookiecutter-') as repo_dir:
        template_dir_name = '{{cookiecutter.repo_name}}'
        project_template = os.path.join(repo_dir, template_dir_name)

        os.makedirs(project_template)

        assert find_template(repo_dir) == project_template

        # Otherwise we wouldn't be able to delete the template folder
        os.chmod(project_template, 0o777)

        shutil.rmtree(project_template)

        os.makedirs(os.path.join(repo_dir, 'cookiecutter_does_not_equal_repo_name'))

        assert find

# Generated at 2022-06-23 16:19:23.678789
# Unit test for function find_template
def test_find_template():
    return find_template('/Users/myusername/myproject/')

# Generated at 2022-06-23 16:19:30.753252
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests/fake-repo/')
    )
    project_template = find_template(repo_dir)
    expected = os.path.abspath(os.path.join(repo_dir, 'cookiecutter-django'))
    assert project_template == expected

# Generated at 2022-06-23 16:19:35.495843
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre') == 'tests/fake-repo-pre/my-fake-cookiecutter-project'

# Generated at 2022-06-23 16:19:40.791873
# Unit test for function find_template
def test_find_template():
    """Test find_template """
    import tempfile
    from shutil import rmtree

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    assert 'cookiecutter-pypackage' in find_template(repo_dir)
    rmtree(repo_dir)

# Generated at 2022-06-23 16:19:44.565756
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns a directory under {{cookiecutter.repo_name}}.
    """
    curr_dir = os.getcwd()
    repo_dir = os.path.join(curr_dir, "tests/test-repo")
    template_dir = find_template(repo_dir)
    assert os.path.exists(template_dir)

# Generated at 2022-06-23 16:19:55.145941
# Unit test for function find_template
def test_find_template():
    """Delete testdir if it exists, create it, and run find_template."""
    # Delete testdir if it exists
    if os.path.isdir('testdir'):
        logger.info('testdir already exists. Deleting it.')
        shutil.rmtree('testdir')

    # Make testdir
    os.mkdir('testdir')

    # Make testdir/cookiecutter-nested-dir1
    os.mkdir('testdir/cookiecutter-nested-dir1')

    # Make cookiecutter.json in testdir/cookiecutter-nested-dir1
    with open('testdir/cookiecutter-nested-dir1/cookiecutter.json', 'w') as f:
        f.write('{}')

    # Make testdir/cookiecutter-nested-dir2

# Generated at 2022-06-23 16:19:58.629503
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests'
    project_template = '{{ cookiecutter.project_name }}'
    assert find_template(repo_dir) == project_template

# Function that creates a list of hook files

# Generated at 2022-06-23 16:20:07.713438
# Unit test for function find_template
def test_find_template():
    from cookiecutter.prompt import read_user_yes_no
    from cookiecutter.main import cookiecutter
    from cookiecutter.exceptions import DeleteClonedRepoException, NonTemplatedInputDirException

    print("just a test")
    logger.debug('Testing the find_template function.')
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-pre'))

    find_template(repo_dir)

# Generated at 2022-06-23 16:20:14.168842
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.join(os.getcwd(), 'tests'))
    project_template = find_template('testrepo_nocompiled')
    assert project_template == os.path.join(os.getcwd(), 'testrepo_nocompiled', '{{cookiecutter.project_name}}')
    project_template = find_template('testrepo_compiled')
    assert project_template == os.path.join(os.getcwd(), 'testrepo_compiled', '{{cookiecutter.project_name}}')

# Generated at 2022-06-23 16:20:22.457056
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.main import cookiecutter
    import shutil
    class Object(object):  # pylint: disable=too-few-public-methods
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # create a real repo with a real git repository
    test_template = 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-23 16:20:23.846673
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:20:28.665140
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function"""
    assert find_template(repo_dir='tests/fake-repo-templated-dir') == 'tests/fake-repo-templated-dir/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:29.237335
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:20:35.107566
# Unit test for function find_template
def test_find_template():
    """Test that find_template correctly finds the correct project template."""
    from .repository import make_empty_project_repo
    import tempfile

    repo_dir = make_empty_project_repo(
        tempfile.mkdtemp(),
        template='{{cookiecutter.repo_name}}',
        extra_context={'repo_name': 'awesome_package'}
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'awesome_package')

# Generated at 2022-06-23 16:20:36.089394
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:20:46.823439
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    char = os.linesep
    # Test empty directory
    empty_dir = os.path.join('tests', 'test-find-template-dirs', 'empty-dir')
    assert find_template(empty_dir) == None

    # Test directory with only non-templates
    no_cc_dir = os.path.join(
        'tests', 'test-find-template-dirs', 'no-cookicutter-dir'
    )
    assert find_template(no_cc_dir) == None

    # Test directory with template with no delimiters
    no_delim_dir = os.path.join(
        'tests', 'test-find-template-dirs', 'no-delim-dir'
    )

# Generated at 2022-06-23 16:20:49.618192
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/user/myrepo') == '/home/user/myrepo/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:20:55.653874
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.main import cookiecutter
    from os import listdir

    temp_dir = tempfile.mkdtemp()
    with TemporaryDirectory() as tmp_dir:
        template_dir = os.path.join(tmp_dir, '{{ cookiecutter.repo_name }}')

        cookiecutter(temp_dir, no_input=True, output_dir=tmp_dir)

        assert 'cookiecutter' in listdir(tmp_dir)[0]
        assert '{{ cookiecutter.repo_name }}' in listdir(tmp_dir)[0]

        result = find_template(tmp_dir)
        expected = os.path.join(tmp_dir, 'cookiecutter-{{ cookiecutter.repo_name }}')


# Generated at 2022-06-23 16:21:00.997441
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    URL = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    REPO_DIR = 'cookiecutter-pypackage'
    PROJECT_TEMPLATE = '{{cookiecutter.repo_name}}'
    # PROJECT_TEMPLATE = os.path.join(REPO_DIR, '{{cookiecutter.repo_name}}')
    
    assert os.path.basename(find_template(REPO_DIR)) == PROJECT_TEMPLATE

# Generated at 2022-06-23 16:21:03.753709
# Unit test for function find_template
def test_find_template():
    assert find_template("../tests/fake-repo-tmpl/") == "../tests/fake-repo-tmpl/{{cookiecutter.repo_name}}/"

# Generated at 2022-06-23 16:21:13.079971
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template`."""
    import shutil
    import tempfile
    from cookiecutter import utils
    
    temp_dir = tempfile.mkdtemp()
    shutil.copytree(utils.find_template('tests/fake-repo-pre/'),
                    os.path.join(temp_dir, 'tests/fake-repo-pre/'))
    
    fake_repo = os.path.join(temp_dir, 'tests/fake-repo-pre/')
    project_template = find_template(fake_repo)
    assert 'fake-project' in project_template

# Generated at 2022-06-23 16:21:21.096624
# Unit test for function find_template
def test_find_template():
    """Tests the functioning of the find_template function."""
    test_dir = os.path.join(os.curdir, 'tests', 'files', 'test-find-template')
    project_template = find_template(test_dir)
    assert project_template == os.path.join(
        test_dir,
        'example-{{cookiecutter.repo_name}}, {{ cookiecutter.project_name }}'
    )

# Generated at 2022-06-23 16:21:28.856182
# Unit test for function find_template
def test_find_template():
    # Create a template that should be found
    os.mkdir('temp')
    os.mkdir(os.path.join('temp', 'cookiecutter-{{ project_name }}'))

    # The template should be found
    assert find_template(os.path.join('temp', '')) == os.path.join('temp', 'cookiecutter-{{ project_name }}')

    # Clean up
    os.rmdir(os.path.join('temp', 'cookiecutter-{{ project_name }}'))
    os.rmdir(os.path.join('temp', ''))

# Generated at 2022-06-23 16:21:30.399191
# Unit test for function find_template
def test_find_template():
    f = find_template('.')
    assert f == './cookiecutter-pypackage'

# Generated at 2022-06-23 16:21:34.881152
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert 'fake-repo-tmpl/{{cookiecutter.repo_name}}' in project_template

# Generated at 2022-06-23 16:21:39.151808
# Unit test for function find_template
def test_find_template():
    fake_repo_dir = os.path.abspath(os.path.dirname(__file__))
    project_template = find_template(fake_repo_dir)
    assert project_template.endswith('tests/fake-repo-pre/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:40.056754
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:21:46.949006
# Unit test for function find_template
def test_find_template():
    dir = '/Users/tasdik/code/cookiecutter-tech-talk'
    # dir = '.'
    return find_template(dir)

# >>> from cookiecutter.main import find_template
# >>> find_template('/Users/tasdik/code/cookiecutter-tech-talk')
# '/Users/tasdik/code/cookiecutter-tech-talk/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:51.255945
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    import pytest
    from cookiecutter import utils

    with pytest.raises(NonTemplatedInputDirException):
        utils.find_template('tests/subdir')

# Generated at 2022-06-23 16:21:54.995186
# Unit test for function find_template
def test_find_template():
    os.chdir('tests/test-repo-pre/')
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}-master'

# Generated at 2022-06-23 16:22:01.165082
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert (project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-23 16:22:09.458713
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter import exceptions

    test_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)),
        'fake-repo-tmpl')

    template_dir = find_template(test_dir)
    expected_dir = os.path.join(test_dir, 'fake-project-{{cookiecutter.repo_name}}-dir')
    assert os.path.normcase(template_dir) == os.path.normcase(expected_dir)

    try:
        find_template(os.path.join(os.path.abspath(os.path.dirname(__file__))))
    except exceptions.NonTemplatedInputDirException:
        pass

# Generated at 2022-06-23 16:22:15.182265
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/test-repo-pre/{{cookiecutter.repo_name}}')
    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/test-repo-pre/{{cookiecutter.repo_name}}')

    assert expected_project_template == project_template

# Generated at 2022-06-23 16:22:18.663256
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/cookiecutter-pypackage') == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:22:21.194933
# Unit test for function find_template
def test_find_template():
    from test_files.basic_repo import REPO_DIR

    project_template = find_template(REPO_DIR)
    assert project_template == '{{cookiecutter.repo_name}}'