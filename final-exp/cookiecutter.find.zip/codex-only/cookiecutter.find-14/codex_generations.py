

# Generated at 2022-06-23 16:12:22.159332
# Unit test for function find_template
def test_find_template():
    assert find_template('lorem/ipsum/{{cookiecutter.project_name}}') == 'lorem/ipsum/{{cookiecutter.project_name}}'

# Generated at 2022-06-23 16:12:25.464379
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/testproject/cookiecutter-pytest-plugin'
    project_template = find_template(repo_dir)
    assert '{{cookiecutter.project_slug}}' in project_template



# Generated at 2022-06-23 16:12:34.145950
# Unit test for function find_template
def test_find_template():
    repo_dir = '/tmp/cookiecutter-test'

    # Assert correct result for normal input
    directory1 = os.path.join(repo_dir, 'cookiecutter-test')
    directory2 = os.path.join(repo_dir, 'cookiecutter-project')
    os.makedirs(directory1)
    os.makedirs(directory2)
    expected_result = directory1
    result = find_template(repo_dir)
    os.rmdir(directory1)
    os.rmdir(directory2)
    assert expected_result == result

    # Assert exception raised if no templated cookiecutter* directory
    os.makedirs(directory1)
    os.makedirs(directory2)
    assert find_template(repo_dir)
    os.r

# Generated at 2022-06-23 16:12:41.056478
# Unit test for function find_template
def test_find_template():
    test_dir = 'tests/test-find-template/test_dir'
    assert find_template(test_dir) == test_dir + '/{{cookiecutter.repo_name}}'
    assert find_template(test_dir + '/nested') == test_dir + '/nested/{{cookiecutter.repo_name}}'
    assert find_template(test_dir + '/nested/more') == test_dir + '/nested/more/{{cookiecutter.repo_name}}'
    assert find_template(test_dir + '/nested/more/nested') == test_dir + '/nested/more/nested/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:12:47.342879
# Unit test for function find_template
def test_find_template():
    """Unit test for the function find_template."""
    # Create a temporary directory and get its path
    from tempfile import mkdtemp
    tmpdir_path = mkdtemp()

    # Create a subdirectory of the temporary directory
    dir_name = 'cookiecutter-{{cookiecutter.repo_name}}'
    os.makedirs(os.path.join(tmpdir_path, dir_name))

    # Do the test
    project_template = find_template(tmpdir_path)
    output_dir_base = os.path.basename(project_template)
    assert output_dir_base == dir_name

# Generated at 2022-06-23 16:12:48.781347
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-templated') == 'tests/fake-repo-templated/{{cookiecutter.project_slug}}'

# Generated at 2022-06-23 16:12:52.806975
# Unit test for function find_template
def test_find_template():
    template_dir = find_template('/Users/yourhis/Documents/github/cookiecutter-pypackage')
    print(template_dir)

if __name__ == "__main__":
    # execute only if run as a script
    test_find_template()

# Generated at 2022-06-23 16:12:58.574915
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the correct value."""
    repo_dir = 'tests/fake-repo-pre-render/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre-render/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:05.051105
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the project template. """
    import tempfile

    from cookiecutter.tests.test_find import (
        create_test_repo,
        create_fake_project_template
    )
    test_repo_dir = tempfile.mkdtemp()
    create_test_repo(test_repo_dir)

    project_template = find_template(test_repo_dir)

    assert project_template == os.path.join(
        test_repo_dir,
        create_fake_project_template(test_repo_dir)
    )

# Generated at 2022-06-23 16:13:15.644221
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import textwrap

    dir_with_templates = tempfile.mkdtemp()
    repo_dir = os.path.join(dir_with_templates, '{{cookiecutter.repo_name}}')
    os.makedirs(repo_dir)

# Generated at 2022-06-23 16:13:16.735182
# Unit test for function find_template
def test_find_template():
    assert find_template('test_repo/templated') == 'test_repo/templated/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:23.277669
# Unit test for function find_template
def test_find_template():
    test_repo_path = os.path.abspath(
        'tests/test-repos/hooks-no-abbreviation/'
    )
    # Set this so tests work even when the working directory is elsewhere
    os.chdir(test_repo_path)

    return_value = find_template(test_repo_path)
    assert return_value == os.path.join(
        test_repo_path,
        '{{cookiecutter.repo_name}}'
    )



# Generated at 2022-06-23 16:13:30.541399
# Unit test for function find_template
def test_find_template():
    non_templated_input_dir_example = os.path.join(
        os.getcwd(),
        os.path.join(
            'tests',
            'non_templated_input_dir_example'
        )
    )
    assert find_template(non_templated_input_dir_example) == os.path.join(
        non_templated_input_dir_example,
        'cookiecutter-pypackage'
    )

# Generated at 2022-06-23 16:13:34.941020
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/test-dir-find-template/{{cookiecutter.repo_name}}'
    project_template = find_template(repo_dir)
    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:45.704208
# Unit test for function find_template
def test_find_template():
    """Verify that find_template correctly identifies the template directory."""
    import tempfile
    import shutil
    import os

    # Create a fake repo
    fake_repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(fake_repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(fake_repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(fake_repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    # Verify find_template gets the right directory
    project_template = find_template(fake_repo_dir)

# Generated at 2022-06-23 16:13:51.135446
# Unit test for function find_template
def test_find_template():
    """Verify find_template() finds the correct template dir in repo_dir."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'tests', 'fake-repo-pre-gen', '{{cookiecutter.repo_name}}'
    )
    found_template_dir = find_template(repo_dir)
    expected_template_dir = os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}'
    )
    assert found_template_dir == expected_template_dir

# Generated at 2022-06-23 16:13:51.795047
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:13:56.655196
# Unit test for function find_template
def test_find_template():
    """Test `find_template` function."""
    template = find_template('/home/jkoester/git/python-boilerplate')

    assert template == '/home/jkoester/git/python-boilerplate/python_boilerplate'

# Generated at 2022-06-23 16:13:59.923762
# Unit test for function find_template
def test_find_template():
    expected = 'input/cookiecutter-pypackage'
    actual = find_template('tests/test-input/cookiecutter-pypackage')
    assert expected == actual


# Generated at 2022-06-23 16:14:03.103589
# Unit test for function find_template
def test_find_template():
    find_template('tests/test-find-templates/fake_input_dir')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:14:08.150868
# Unit test for function find_template
def test_find_template():
    logger.debug('test_find_template')
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(repo_dir, 'tests/fake-repo-tmpl')
    return find_template(repo_dir)

# Generated at 2022-06-23 16:14:08.673026
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-23 16:14:14.672279
# Unit test for function find_template
def test_find_template():
    '''
    Test for finding the project template
    '''
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests',
                            'fake-repo-pre')
    template = find_template(repo_dir)
    assert template.endswith('cookiecutter-{{repo_name}}')

# Generated at 2022-06-23 16:14:25.387893
# Unit test for function find_template
def test_find_template():
    """Tests the find_template function."""
    # Given
    # that this is the directory structure of the cloned project
    #
    # foo_project/
    #     cookiecutter.json
    #     hook_dir/
    #         hook1.py
    #         hook2.py
    #     bar_cookiecutter/
    #         hook_dir/
    #             hook1.py
    #             hook2.py
    #         cookiecutter.json
    #
    #  when we call find_template, then it should return
    #  'bar_cookiecutter'
    #
    #  This can be generalized for any cookiecutter template,
    #  it just has to be a directory in the cloned repo
    #  and have 'cookiecutter' in its name.


    foo_project

# Generated at 2022-06-23 16:14:31.144916
# Unit test for function find_template
def test_find_template():
    # Create a repo with a project template
    import shutil
    import tempfile
    test_root_dir = tempfile.mkdtemp()
    test_repo_dir = os.path.join(test_root_dir, 'fake-repo')
    test_project_template = os.path.join(
        test_repo_dir, '{{cookiecutter.project}}'
    )
    os.makedirs(test_project_template)

    # Test that function finds project_template
    result = find_template(test_repo_dir)
    assert result == test_project_template

    # Clean up
    shutil.rmtree(test_root_dir)

# Generated at 2022-06-23 16:14:32.006528
# Unit test for function find_template
def test_find_template():
    assert True


# Generated at 2022-06-23 16:14:34.767402
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('fake-repo')
    assert find_template(repo_dir) == os.path.abspath('fake-repo/cookiecutter-pypackage')

# Generated at 2022-06-23 16:14:39.599218
# Unit test for function find_template
def test_find_template():
    """Test for function ``find_template``."""
    repo_dir = 'tests/test-repo-tmpl/'

    tmpl_dir = find_template(repo_dir)
    assert tmpl_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:14:40.916016
# Unit test for function find_template
def test_find_template():
    """Test find_template function with a test repo."""
    pass

# Generated at 2022-06-23 16:14:45.456517
# Unit test for function find_template
def test_find_template():
    from .context_file import TEST_COOKIECUTTER_REPO
    repo_dir = TEST_COOKIECUTTER_REPO
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'foobar')

# Generated at 2022-06-23 16:14:48.219048
# Unit test for function find_template

# Generated at 2022-06-23 16:14:49.845684
# Unit test for function find_template
def test_find_template():
    """Unit tests for function find_template."""
    pass

# Generated at 2022-06-23 16:14:58.075527
# Unit test for function find_template
def test_find_template():
    """
    Unit test for find_template function
    """
    import os
    import shutil
    test_cookiedir = 'test_cookiecutter_find_template'
    os.mkdir(test_cookiedir)
    os.mkdir(test_cookiedir + '/{{cookiecutter.repo_name}}')
    template = find_template(test_cookiedir)
    assert template == test_cookiedir + '/{{cookiecutter.repo_name}}'
    
    shutil.rmtree(test_cookiedir)

# Generated at 2022-06-23 16:15:03.668065
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'tests')
    project_template = find_template(repo_dir)
    assert 'cookiecutter-pypackage' in project_template
    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:15:10.072226
# Unit test for function find_template
def test_find_template():
    """Testing function find_template"""

    import shutil

    # 1. Create a temporary directory clone a new repo
    # inside it
    import tempfile
    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')

    import git
    repo = git.Repo.clone_from('https://github.com/audreyr/cookiecutter-pypackage.git', repo_dir)

    # 2. Change to repo_dir
    os.chdir(repo_dir)

    # 3. Find project_template
    project_template = find_template(repo_dir)

# Generated at 2022-06-23 16:15:12.050437
# Unit test for function find_template
def test_find_template():
    """Find template in local directory."""
    find_template(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'fake-repo'))


# Generated at 2022-06-23 16:15:23.520521
# Unit test for function find_template
def test_find_template():
    """
    Tests that the function for finding the project template works.
    """
    from unittest import TestCase
    import tempfile
    import shutil

    class FindTemplateTests(TestCase):
        """
        Tests the function find_template.
        """

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_experimentals(self):
            """
            Test the experimental templates.
            """
            for name in ('dir', 'dir-with-hyphen', 'dir with spaces'):
                os.mkdir(os.path.join(self.test_dir, name))

                # Test with no templating at all.

# Generated at 2022-06-23 16:15:24.181842
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:15:29.248534
# Unit test for function find_template
def test_find_template():

    repo_dir = os.path.join('tests/fake-repo-pre/', '{{cookiecutter.repo_name}}')

    template_dir = find_template(repo_dir)

    assert template_dir == os.path.join(repo_dir, 'cookiecutter-pypackage')



# Generated at 2022-06-23 16:15:33.363695
# Unit test for function find_template
def test_find_template():
    from tests.test_finders import repo_dir
    from tests.test_finders import project_template

    # project_template = find_template(repo_dir)

    assert project_template in os.listdir(repo_dir)



# Generated at 2022-06-23 16:15:36.088208
# Unit test for function find_template
def test_find_template():
    func = find_template
    assert func('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.project_slug}}'

# Generated at 2022-06-23 16:15:38.807614
# Unit test for function find_template
def test_find_template():
    """Tests if find_template returns the relative path to the project template."""
    repo_dir = '~/.cookiecutters/foo'
    # We don't check the value of returned path. It's just a test to see if
    # the function returns a path.
    find_template(repo_dir)

# Function to check if the (templated) directory is empty

# Generated at 2022-06-23 16:15:44.852768
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_util.test_paths import cookiecutters_dir

    repo_dir = os.path.join(cookiecutters_dir, 'cookiecutter-pypackage')
    found_template = find_template(repo_dir)

    expected_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert found_template == expected_template

# Generated at 2022-06-23 16:15:49.542681
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from tests.test_utils import template_dir

    project_template = find_template(template_dir)
    assert project_template == os.path.join(template_dir,
            '{{cookiecutter.project_name}}')

# Generated at 2022-06-23 16:15:58.399339
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import shutil
    import tempfile
    from cookiecutter import main

    # Create a fake repo with a cookiecutter.json in the root.
    repo_dir = tempfile.mkdtemp()

    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write('{"name": "example-repo"}')

    # Create a fake project template.
    project_template = os.path.join(repo_dir, 'fake-project-template')
    os.mkdir(project_template)

    # Find the project template
    project_template_found = main.find_template(repo_dir)

    # Clean up
    shutil.rmtree(repo_dir)

    # Make assertions


# Generated at 2022-06-23 16:16:02.920696
# Unit test for function find_template
def test_find_template():
    """
    Tests for function find_template
    """
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'tests')
    template_path = find_template(repo_dir)
    assert os.path.exists(template_path)

# Generated at 2022-06-23 16:16:04.160419
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir='tests/fake-repo-template/')

# Generated at 2022-06-23 16:16:14.331475
# Unit test for function find_template
def test_find_template():
    """ Test that function find_template successfully finds template directory."""
    repo_dir = "test_find_template"
    os.makedirs(os.path.join(repo_dir,"cookiecutter-pypackage"))
    os.makedirs(os.path.join(repo_dir,"cookiecutter-mypackage"))
    os.makedirs(os.path.join(repo_dir,"cookiecutter-otherpackage"))
    try: 
        assert find_template(repo_dir) == repo_dir
    finally:
        os.rmdir(os.path.join(repo_dir,"cookiecutter-pypackage"))
        os.rmdir(os.path.join(repo_dir,"cookiecutter-mypackage"))

# Generated at 2022-06-23 16:16:18.406814
# Unit test for function find_template
def test_find_template():
    assert find_template('/cookiecutter/tests/_test-repo/new-repo') == '/cookiecutter/tests/_test-repo/new-repo/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:16:21.865151
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = ['abc', 'abcdef', 'abc{{def}}', '{{abcdef}}']
    assert find_template(repo_dir_contents) == '{{abcdef}}'

# Generated at 2022-06-23 16:16:24.214842
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo') == 'tests/test-repo/fake-project'

# Generated at 2022-06-23 16:16:27.832639
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/test-repo-pre/')
    project_template = find_template(repo_dir)
    project_template_expected = os.path.abspath(
        'tests/test-repo-pre/cookiecutter-pypackage')
    assert project_template == project_template_expected

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_find_template()

# Generated at 2022-06-23 16:16:32.137439
# Unit test for function find_template
def test_find_template():
    """Verify expected behavior of find_template()"""

    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as tmpdir:
        os.mkdir(os.path.join(tmpdir, 'cookiecutter-foo'))
        os.mkdir(os.path.join(tmpdir, 'bar'))

        project_dir = find_template(tmpdir)
        assert 'cookiecutter-foo' in project_dir



# Generated at 2022-06-23 16:16:35.328574
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests import mock_project

    with mock_project('tests/test-find-template'):
        repo_dir = os.path.join(os.path.dirname(__file__), 'test-find-template')
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.project_name}}')



# Generated at 2022-06-23 16:16:39.821688
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-input/fake-repo'
    project_template = 'tests/test-input/fake-repo/{{cookiecutter.repo_name}}'
    # Test if project_template is detected correctly
    assert project_template == find_template(repo_dir)

# Generated at 2022-06-23 16:16:43.346471
# Unit test for function find_template
def test_find_template():
    repo_dir = 'cc/tests/test-repo/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'cc/tests/test-repo/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:47.415278
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'foobar'))

    try:
        template_dir = find_template(repo_dir)
        assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        shutil.rmtree(repo_dir)



# Generated at 2022-06-23 16:16:52.165631
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo2'
    project_template_path = 'tests/fake-repo2/cookiecutter-pypackage-mini'
    assert find_template(repo_dir) == project_template_path

test_find_template()

# Generated at 2022-06-23 16:16:52.654253
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:53.461771
# Unit test for function find_template
def test_find_template():
    find_template('../sample-repos')

# Generated at 2022-06-23 16:16:58.088610
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the templated directory name."""

    dir_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../test-cookiecutter')

    expected = os.path.abspath(os.path.join(dir_path, '{{ cookiecutter.repo_name }}'))
    actual = os.path.abspath(find_template(dir_path))
    assert expected == actual

# Generated at 2022-06-23 16:16:58.584578
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:17:00.525788
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = ['{{ cookiecutter.project_name }}']
    assert find_template(repo_dir_contents) == '{{ cookiecutter.project_name }}'

# Generated at 2022-06-23 16:17:06.786234
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() correctly determines which directory is the
    project template for a given repository.
    """
    import tempfile
    import shutil

    input_dir = tempfile.mkdtemp()

    # Create non-templated repo
    shutil.copytree('tests/test-data/test-repo-no-templated', input_dir)

    # Create templated repo
    shutil.copytree('tests/test-data/test-repo-templated', input_dir)

    # Run find_template
    output = find_template(input_dir)

    assert output == '{0}/test-repo-templated/{{cookiecutter.repo_name}}'.format(input_dir)

# Generated at 2022-06-23 16:17:12.431803
# Unit test for function find_template
def test_find_template():
    assert(find_template('./tests/fake-repo-pre/') == './tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    try:
        assert(find_template('./tests/fake-repo-post/') == './tests/fake-repo-post/{{cookiecutter.repo_name}}')
    except NonTemplatedInputDirException:
        assert(True)

# Generated at 2022-06-23 16:17:18.566690
# Unit test for function find_template
def test_find_template():
    """
    The assert statement is the test.
    TODO: Add a Python 3 version of assertIsNotNone.
    """
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    logger.debug('repo_dir is ' + repo_dir)
    project_template = find_template(repo_dir)
    assert project_template is not None  # pragma: no cover

# Generated at 2022-06-23 16:17:24.229580
# Unit test for function find_template
def test_find_template():
    # local path to the test repo.
    # TODO Find a way to get the path to test file more elegantly
    repo_dir = 'C:/Users/user/Projects/cookiecutter/tests/test-repos/fake-repo-tmpl'
    project_template = find_template(repo_dir)

    assert os.path.exists(project_template)
    assert project_template == 'C:/Users/user/Projects/cookiecutter/tests/test-repos/fake-repo-tmpl/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:17:27.010571
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/input'
    expected = 'tests/input/{{ cookiecutter.repo_name }}'
    actual = find_template(repo_dir)
    assert expected == actual

# Generated at 2022-06-23 16:17:30.531450
# Unit test for function find_template
def test_find_template():
    """Test that the correct path is returned when given the correct path."""
    template_path = find_template('mocks/my_fake_repo')
    assert template_path == 'mocks/my_fake_repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:38.774808
# Unit test for function find_template
def test_find_template():
    import mock
    import pytest

    from cookiecutter import find
    from cookiecutter import exceptions

    mocked_listdir = mock.Mock(return_value=['some-dir', '{{cookiecutter.repo_name}}'])
    with mock.patch('os.listdir', mocked_listdir):
        template_dir = find.find_template

    with pytest.raises(exceptions.NonTemplatedInputDirException):
        mocked_listdir.return_value = ['some-dir']
        template_dir = find.find_template('/some/fake/path')

# Generated at 2022-06-23 16:17:44.030156
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    expected_project_template = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    project_template = find_template(repo_dir)
    assert project_template == expected_project_template



# Generated at 2022-06-23 16:17:48.279499
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template.endswith('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:17:56.808741
# Unit test for function find_template
def test_find_template():
    repo_dir = "/home/username/cookiecutters_repo/example_repo"
    assert find_template(repo_dir) == "/home/username/cookiecutters_repo/example_repo/{{cookiecutter.project_name}}"
    #test function with non existing repo_dir
    repo_dir = "home/username/cookiecutters_repo/not_existing_repo"
    assert find_template(repo_dir) == None

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-23 16:18:00.067488
# Unit test for function find_template
def test_find_template():
    with open('test.txt', 'w') as f:
        f.write("test")

    logger.debug("test")
    find_template("test.txt")
    os.remove("test.txt")

# Generated at 2022-06-23 16:18:04.119405
# Unit test for function find_template
def test_find_template():
    """Unit test that returns the path to the template dir."""
    repo_dir = "/home/user/my-repo"
    project_template = find_template(repo_dir)

    assert project_template == "/home/user/my-repo/{{cookiecutter.project_name}}"

# Generated at 2022-06-23 16:18:10.392825
# Unit test for function find_template
def test_find_template():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        with open(os.path.join(temp_dir, 'cookiecutter_testing_file.txt'), 'w') as f:
            f.write('test')
        assert find_template(temp_dir) == 'cookiecutter_testing_file.txt'
    logger.debug('Successfully passed unit test')
    return True

# Generated at 2022-06-23 16:18:18.059005
# Unit test for function find_template
def test_find_template():
    """
    Tests the function find_template.
    """
    repo_dir = os.path.realpath(os.path.join('/', 'work', 'cookiecutter-pypackage'))
    repo_dir_contents = ['{{cookiecutter.repo_name}}', 'README.rst']
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        assert project_template == find_template(repo_dir)

# Generated at 2022-06-23 16:18:23.103415
# Unit test for function find_template
def test_find_template():
    """Sanity check: test find_template function."""
    
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:18:33.550860
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo'
    )

    # Test found template
    expected_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    project_template = find_template(repo_dir)
    assert project_template == expected_template

    # Test not found template
    bad_repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'bad-test-repo'
    )

# Generated at 2022-06-23 16:18:37.839472
# Unit test for function find_template
def test_find_template():
    """Test searching on a well-formed template."""
    repo_dir = 'tests/fake-repo-pre/'
    actual = find_template(repo_dir)
    expected = 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert actual == expected


# Generated at 2022-06-23 16:18:43.625743
# Unit test for function find_template
def test_find_template():
    test_input = "/home/jn/test"
    assert_result = find_template(test_input)
    assert assert_result == os.path.join(test_input, "cookiecutter")

# Generated at 2022-06-23 16:18:53.504588
# Unit test for function find_template
def test_find_template():
    """Gives a correct result for find_template.

    :returns: Status code for subprocess.call
    """
    import subprocess
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '../tests/test-repo/')
    )
    expected_project_template = os.path.join(
        repo_dir, '{{cookiecutter-project-name}}'
    )
    project_template = find_template(repo_dir)
    assert expected_project_template == project_template
    assert os.path.exists(project_template)

# Generated at 2022-06-23 16:19:03.207364
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    class TestData(object):
        def __init__(self, name, repo_dir, raises_exception=False):
            self.name = name
            self.repo_dir = repo_dir
            self.raises_exception = raises_exception

    test_data = (
        TestData(
            name='Regular',
            repo_dir='tests/test-repo-pre/',
            raises_exception=False,
        ),
        TestData(
            name='NoTemplates',
            repo_dir='tests/test-repo-old-style/',
            raises_exception=True,
        ),
    )


# Generated at 2022-06-23 16:19:07.548173
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/Documents/GitHub/cookiecutter-pycon-tutorial/'
    assert find_template(repo_dir) == '/Users/audreyr/Documents/GitHub/cookiecutter-pycon-tutorial/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:18.772264
# Unit test for function find_template
def test_find_template():
    """
    Unit test for find_template()
    """
    import pytest
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    try:
        shutil.copytree(
            os.path.join(
                os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo'),
            repo_dir
        )

        found_template_dir = find_template(repo_dir)
        expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}',)
        assert found_template_dir == expected
    finally:
        shutil.rmtree(repo_dir)

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:19:23.779873
# Unit test for function find_template
def test_find_template():
    """Test that find_template works."""
    from .file import generate_files
    from .compat import patch

    repo_dir = 'tests/files'
    generate_files(repo_dir)

    with patch('cookiecutter.prompt.read_user_yes_no', return_value=False):
        project_template = find_template(repo_dir)
        assert project_template == 'tests/files/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:31.177058
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function properly finds a template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..', 'tests', 'fake-repo', 'unrendered',
    )

    project_template = find_template(repo_dir)
    assert 'fake-repo' == os.path.basename(project_template)

# Generated at 2022-06-23 16:19:36.380711
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-tmpl')
    template_dir = find_template(repo_dir)
    assert template_dir.endswith('fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:19:41.939050
# Unit test for function find_template
def test_find_template():
    """Test that find_template works as expected."""
    search_dir1 = os.path.join(os.path.dirname(__file__), '..', '..', '.tests', 'test-find-template')
    result1 = find_template(search_dir1)
    expected_result1 = os.path.join(search_dir1, '{{cookiecutter.repo_name}}')
    assert result1 == expected_result1

# Generated at 2022-06-23 16:19:51.088122
# Unit test for function find_template
def test_find_template():
    """Test the function find_template(repo_dir)"""

    from tempfile import mkdtemp
    from shutil import rmtree

    repo_dir = mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-myproject'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-otherproject'))

    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-myproject')
    rmtree(repo_dir)

# Generated at 2022-06-23 16:19:52.351861
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == get_user_config_path()

# Generated at 2022-06-23 16:20:01.077642
# Unit test for function find_template
def test_find_template():
    # First test: pass in a directory that doesn't exist
    try:
        find_template('/tmp')
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'NonTemplatedInputDirException was not raised.'

    # Second test: Pass in a directory with no cookiecutter template
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'NonTemplatedInputDirException was not raised.'

    # Third test: pass in a directory with a cookiecutter template

# Generated at 2022-06-23 16:20:04.972246
# Unit test for function find_template
def test_find_template():
    assert find_template('/a/b/c')

# Test for find_template - no cookiecutter
#def test_find_template():
#    assert find_template('/a/b/c')

# Generated at 2022-06-23 16:20:10.807201
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    result = find_template(repo_dir)
    assert result == os.path.join(repo_dir, 'fake-project-tmpl')

    # test error exception
    repo_dir = 'tests/fake-repo'
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException as e:
        assert True
    else:
        assert False



# Generated at 2022-06-23 16:20:19.223571
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                            'repos', 'foo-bar'))
    actual_result = find_template(repo_dir)
    expected_result = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                   'repos', 'foo-bar',
                                                   'cookiecutter-{{cookiecutter.repo_name}}'))
    assert actual_result == expected_result

# Generated at 2022-06-23 16:20:26.368196
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    import shutil
    import tempfile
    import os
    template_dir = os.path.join(os.path.dirname(__file__), "..", "..", "tests", "test-cookiecutter-repo")
    temp_dir = tempfile.mkdtemp()
    cookiecutter(template_dir, no_input=True, output_dir=temp_dir)

    # find_template should return the templated directory
    templated_dir = os.path.join(temp_dir, 'test-cookiecutter-repo')
    assert find_template(temp_dir) == templated_dir

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-23 16:20:28.861748
# Unit test for function find_template
def test_find_template():
    template = find_template('tests/test-data')
    assert template == 'tests/test-data/{{cookiecutter.project_name}}'

# Generated at 2022-06-23 16:20:35.317278
# Unit test for function find_template
def test_find_template():
    """Test a valid project template without nested templates
    """
    parent_dir = "tests/fixtures/non-templated-project/"
    repo_dir_contents = os.listdir(parent_dir)

# Generated at 2022-06-23 16:20:40.861377
# Unit test for function find_template
def test_find_template():
    # FIXME: This is not a good unit test, because it actually has to clone a
    # repo.
    repo_dir = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert 'cookiecutter' in find_template(repo_dir)

# Generated at 2022-06-23 16:20:49.092420
# Unit test for function find_template
def test_find_template():
    """Test find_template() method."""
    # Mock a directory.
    mock_repo_dir = ['somefile.txt',
                     'someotherfile.py',
                     'topleveldir',
                     'cookiecutter{{cookiecutter.repo_name}}']

    # Mock the os.listdir function to return the mock directory.
    def mock_listdir(path):
        logger.debug('Mocking os.listdir()')
        return mock_repo_dir

    # Test for normal operation.
    os.listdir = mock_listdir
    assert find_template(mock_repo_dir) == \
        'cookiecutter{{cookiecutter.repo_name}}'

    # Test for non-templated directory exception.

# Generated at 2022-06-23 16:20:52.911210
# Unit test for function find_template
def test_find_template():
    print(find_template('/tmp/test/cookiecutter-pypackage'))
    assert(find_template('/tmp/test/cookiecutter-pypackage') == '/tmp/test/cookiecutter-pypackage/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:00.306798
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'test_repo')
    # Cd into temp dir to make sure we're using the test_repo/cookiecutter.json
    # in this repo, not a global one.
    cwd = os.getcwd()

    os.chdir(repo_dir)
    try:
        project_template = find_template(repo_dir)
        assert project_template.endswith(os.path.join(
            repo_dir,
            '{{cookiecutter.repo_name}}'
        ))
    finally:
        os.chdir(cwd)


# Generated at 2022-06-23 16:21:06.678649
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """

# Generated at 2022-06-23 16:21:12.137191
# Unit test for function find_template
def test_find_template():
    result = find_template(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests', 'fake-repo-tmpl'))
    expected = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests', 'fake-repo-tmpl', '{{cookiecutter.repo_name}}')
    assert result == expected, (
        u"Error: {0} is not {1}".format(result, expected)
    )


# Generated at 2022-06-23 16:21:12.664343
# Unit test for function find_template
def test_find_template():
    repo_di

# Generated at 2022-06-23 16:21:16.429105
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(
        os.path.dirname(__file__),
        '../tests/fake-repo-tmpl'
    )
    template_dir = os.path.normpath(template_dir)
    expected_result = os.path.join(template_dir, '{{cookiecutter.repo_name}}')

    result = find_template(template_dir)
    assert result == expected_result

# Generated at 2022-06-23 16:21:17.732540
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-23 16:21:23.483054
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)

    expected = 'fake-repo/fake_project/{{cookiecutter.repo_name}}'
    assert os.path.normpath(project_template) == os.path.normpath(expected)

# Generated at 2022-06-23 16:21:34.237246
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    import os
    import pytest
    from cookiecutter.main import find_template
    from cookiecutter.exceptions import NonTemplatedInputDirException

    no_template = os.path.join(os.path.dirname(__file__), 'fake-repo-pre/')
    with pytest.raises(NonTemplatedInputDirException):
        find_template(no_template)

    template = os.path.join(os.path.dirname(__file__), 'fake-repo-pre/cookiecutter-pypackage/')  # noqa
    assert find_template(template) == template + 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:21:41.298904
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-pre')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-post')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:46.017460
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)),
                            'fake-repo-pre/')
    tmpl_dir = find_template(repo_dir)
    assert os.path.exists(tmpl_dir)

# Generated at 2022-06-23 16:21:46.954948
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    pass

# Generated at 2022-06-23 16:21:54.745489
# Unit test for function find_template
def test_find_template():
    """
    Perform unit testing of function find_template.
    """
    from .utils import test_dir
    import shutil
    import tempfile

    # create a temp directory
    temp_dir = tempfile.mkdtemp()

    # create a directory with a repo containing a template named
    # cookiecutter-pypackage
    test_dir_path = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(test_dir_path)
    test_file_path = os.path.join(test_dir_path, 'testfile.txt')
    with open(test_file_path, 'w+') as test_file:
        test_file.write('Test file')

    # call find_template() with the repo containing a template named
    # cookiecutter-

# Generated at 2022-06-23 16:21:58.492616
# Unit test for function find_template
def test_find_template():
    project_template = find_template('/home/johndoe/cookiecutter-pypackage')
    assert project_template == '/home/johndoe/cookiecutter-pypackage/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:22:04.649580
# Unit test for function find_template
def test_find_template():
    """Basic unit test for find_template"""
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    template_dir = os.path.join(tmpdir, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    assert find_template(tmpdir) == template_dir

    shutil.rmtree(tmpdir)

# Generated at 2022-06-23 16:22:14.200590
# Unit test for function find_template
def test_find_template():
    """Test find_template() returns the correct project template."""
    from .compat import mock
    from .compat import unittest

    from .exceptions import NonTemplatedInputDirException

    class TestFindTemplate(unittest.TestCase):
        @mock.patch('cookiecutter.utils.find_template.os.listdir')
        def test_find_template(self, mock_listdir):
            mock_listdir.return_value = ['cookiecutter-pypackage', 'other', 'stuff']
            assert find_template('/foo/bar') == '/foo/bar/cookiecutter-pypackage'

        @mock.patch('cookiecutter.utils.find_template.os.listdir')
        def test_no_template_found(self, mock_listdir):
            mock_list

# Generated at 2022-06-23 16:22:24.857943
# Unit test for function find_template
def test_find_template():
    from tempdir import tempdir
    from binaryornot.check import is_binary
    from cookiecutter.utils import rmtree
    import os
    import shutil
    import zipfile

    # Make a clean working directory
    zipped_project = os.path.join(tempdir, 'some-repo.zip')
    shutil.copy(os.path.join('tests', 'files', 'some-repo.zip'), zipped_project)
    repo_dir = os.path.join(tempdir, 'some-repo')
    zip_file = zipfile.ZipFile(zipped_project)
    zip_file.extractall(path=repo_dir)

    repo_dir = repo_dir
    project_template = os.path.join(repo_dir, 'cookiecutter-pypackage')