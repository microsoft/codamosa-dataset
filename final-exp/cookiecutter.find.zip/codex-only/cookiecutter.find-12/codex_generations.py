

# Generated at 2022-06-23 16:12:19.174890
# Unit test for function find_template
def test_find_template():
    """Find template folder when there's a template folder."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )

    expected_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == expected_template



# Generated at 2022-06-23 16:12:24.319545
# Unit test for function find_template
def test_find_template():
    """ Find the template and output the path to the terminal.
    """
    import os
    os.chdir('../..')
    template = find_template('tests/test-data/fake-repo-pre/')
    print(template)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:12:34.582186
# Unit test for function find_template
def test_find_template():
    """Verify that the function `find_template` works correctly."""
    import tempfile
    import shutil
    import json
    import os

    # Create a new directory to store the repo we're going to clone
    repo_dir = tempfile.mkdtemp()
    # Create a new directory inside the repo dir.
    # This will be the project template
    proj_template = tempfile.mkdtemp(dir=repo_dir)
    # Find the path to the project template
    template_path = os.path.join(repo_dir, os.path.basename(proj_template))
    # Create a fake cookiecutter.json
    cookiecutter_json_path = os.path.join(proj_template, 'cookiecutter.json')
    # Store some fake data in the fake cookiecutter.json


# Generated at 2022-06-23 16:12:45.901066
# Unit test for function find_template
def test_find_template():
    """Verify that template directory is correctly identified."""
    from .compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, '{{cookiecutter.repo_name}}'))
        assert find_template(tmpdir) == os.path.join(tmpdir, '{{cookiecutter.repo_name}}')

        os.makedirs(os.path.join(tmpdir, 'foo'))
        assert find_template(tmpdir) == os.path.join(tmpdir, '{{cookiecutter.repo_name}}')

        os.makedirs(os.path.join(tmpdir, '{{cookiecutter.repo_name}}2'))

# Generated at 2022-06-23 16:12:52.659319
# Unit test for function find_template
def test_find_template():
    """Verify function find_template()."""
    import pytest
    from cookiecutter.prompt import read_user_variable

    def _test_find_template(template):
        repo_dir = os.path.join('tests', 'test-find-template', template)
        expected_template_dir = os.path.join(repo_dir, template)
        real_template_dir = find_t

# Generated at 2022-06-23 16:12:53.298470
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:13:03.783628
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    logger.debug('Testing function find_template().')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests',
        'test-find-template'
    ))

    # Test 1: Basic working case
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.project_slug}}'
    )

    # Test 2: No match
    non_templated_repo_dir = os.path.abspath(os.path.join(
        repo_dir, '..', 'test-no-template'
    ))


# Generated at 2022-06-23 16:13:06.338179
# Unit test for function find_template
def test_find_template():
    """Test function find_template"""
    find_template('https://github.com/audreyr/cookiecutter-pypackage.git')
    #Get the same result
    find_template('https://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:13:16.180677
# Unit test for function find_template

# Generated at 2022-06-23 16:13:19.688313
# Unit test for function find_template
def test_find_template():
    """Verify that find_template identifies a template."""
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    template_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    result = find_template(temp_dir)

    shutil.rmtree(temp_dir)

    assert result == template_dir

# Generated at 2022-06-23 16:13:26.876339
# Unit test for function find_template
def test_find_template():
    """Verify find_template() properly finds the project template dir."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '.cookiecutter')

# Generated at 2022-06-23 16:13:30.725019
# Unit test for function find_template
def test_find_template():
    from tests.fixtures import test_repo
    with test_repo('tests/test-repo') as repo_location:
        assert find_template(repo_location) == os.path.join(repo_location, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:13:38.100218
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    repo_dir_temp = tempfile.mkdtemp()

    # Create child dirs
    child_dirs = ('d1', 'd2', 'd3')
    for dir in child_dirs:
        try:
            os.makedirs(os.path.join(repo_dir_temp, dir))
        except OSError as e:
            print(e)

    # Test
    project_dir = find_template(repo_dir_temp)
    assert os.path.isdir(project_dir)
    print("Test passed")

    # Tear down
    shutil.rmtree(repo_dir_temp)

# Generated at 2022-06-23 16:13:38.927159
# Unit test for function find_template
def test_find_template():
    find_template('template')

# Generated at 2022-06-23 16:13:42.414057
# Unit test for function find_template
def test_find_template():
    """Test that find_template() returns a valid path."""
    assert find_template('not_a_real_dir') == '/not_a_real_dir/cookiecutter-{{cookiecutter.project_slug}}'

# Generated at 2022-06-23 16:13:45.796779
# Unit test for function find_template
def test_find_template():
    """Check if the right template is retrieved from the given directory."""
    template = find_template(os.path.join(os.path.dirname(__file__), '..'))
    assert 'cookiecutter-pypackage' in template

# Generated at 2022-06-23 16:13:48.229271
# Unit test for function find_template
def test_find_template():
    """Make sure the find_template function works properly."""
    assert find_template("tests/test-repo/") == "tests/test-repo/{{cookiecutter.repo_name}}"

# Generated at 2022-06-23 16:13:51.541793
# Unit test for function find_template
def test_find_template():
    """Verify proper template is found."""
    from cookiecutter import utils

    template_name = 'cookiecutter-pytest'
    repo_dir = utils. WorkDir(template_name, '', '')

    template_dir = find_template(repo_dir)

    # Verify the template_dir name is correct
    assert template_name in template_dir

# Generated at 2022-06-23 16:13:59.875459
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    try:
        temp_dir = tempfile.mkdtemp()
        os.mkdir(os.path.join(temp_dir, 'temp_dir'))
        shutil.copy('tests/test-data/fake-repo/README.md', temp_dir)

        template_dir = find_template(temp_dir)
        assert '{{cookiecutter.project_name}}' in template_dir
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-23 16:14:06.275685
# Unit test for function find_template
def test_find_template():
    """Verify template detection"""
    from cookiecutter import main
    from cookiecutter.config import DEFAULT_CONFIG

    with main.work_in(DEFAULT_CONFIG['cookiecutters_dir']):
        template = find_template('cookiecutter-pypackage')
        assert os.path.exists(template) is True

# Generated at 2022-06-23 16:14:13.486209
# Unit test for function find_template
def test_find_template():
    """Test find_templated()
    """
    import shutil
    import tempfile

    base_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(base_dir, 'cookiecutter-pypackage')
    os.mkdir(repo_dir)
    os.chdir(repo_dir)

    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(project_template)

    actual = find_template('.')
    expected = project_template

    shutil.rmtree(base_dir)

    assert actual == expected

# Generated at 2022-06-23 16:14:17.396328
# Unit test for function find_template
def test_find_template():
    """Test whether find_template() returns the name of the project template.
    """
    import shutil
    import tempfile
    result = None
    template_name = 'cookiecutter-pypackage'
    expected = os.path.join(tempfile.gettempdir(), template_name)

    try:
        shutil.copytree(
            'tests/test-input/cookiecutter-pypackage',
            expected
        )
        result = find_template(tempfile.gettempdir())
    finally:
        shutil.rmtree(expected)

    assert result == expected

# Generated at 2022-06-23 16:14:22.748338
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage-example')

# Generated at 2022-06-23 16:14:30.479180
# Unit test for function find_template
def test_find_template():
    """Test whether function find_template can find the project template"""
    from ..utils import work_in
    from .make_repo import make_repo
    from .generate_files import generate_files
    from .remove_repo import remove_repo

    repo_path = make_repo()
    with work_in(repo_path):
        generate_files()
    project_template = find_template(repo_path)
    assert os.path.exists(project_template)
    assert project_template.endswith('{{cookiecutter.repo_name}}')
    remove_repo(repo_path)

# Generated at 2022-06-23 16:14:36.837024
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join('tests', 'fake-repo-tmpl')

    # test for failure
    with utils.work_in(repo_dir):
        try:
            find_template(repo_dir)
        except NonTemplatedInputDirException:
            pass
        else:
            raise Exception('find_template found a template that does not exist.')

# Generated at 2022-06-23 16:14:40.478337
# Unit test for function find_template
def test_find_template():

    repo_dir = os.path.join('tests', 'files', 'new_project')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-23 16:14:50.347739
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter finds project templates."""
    import os
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    here = os.path.dirname(__file__)

    def _test_find_template(dirname):
        project_template = find_template(
            os.path.join(here, 'test-find-template', dirname)
        )
        assert project_template.endswith(os.path.join('tests', 'test-find-template', dirname, '{{cookiecutter.repo_name}}'))

    _test_find_template('single-root-file')
    _test_find_template('single-file-inside-root-dir')
    _test_find_template('multiple-files')

# Generated at 2022-06-23 16:14:54.743217
# Unit test for function find_template
def test_find_template():
    temp_dir = 'tests/fake-repo-tmpl'
    project_template = 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template(temp_dir) == project_template

# Generated at 2022-06-23 16:15:06.708166
# Unit test for function find_template
def test_find_template():
    """Verify that find_template gets the right directory path."""
    import tempfile
    import shutil
    import os
    temp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir, 'tests', 'fake', '.cookiecutter'))
    with open(os.path.join(temp_dir, 'tests', 'fake', '.cookiecutter',
              'hooks', 'pre_gen_project.py'), 'w') as fh:
        fh.write("def fake_hook(): pass")
    repo_dir = os.path.join(temp_dir, 'tests', 'fake')

    assert find_template(repo_dir) == os.path.join(repo_dir, '.cookiecutter')
    shutil.rmtree(temp_dir)

# Generated at 2022-06-23 16:15:08.958511
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('test-repo') == 'test-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:13.078614
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter import settings
    repo_dir = utils.expand_abbreviations(settings.REPO_DIR, {})
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, settings.DEFAULT_CONFIG['project_template'])



# Generated at 2022-06-23 16:15:21.773412
# Unit test for function find_template
def test_find_template():
    assert find_template('~/local/cookiecutter-djangopackage') == '~/local/cookiecutter-djangopackage/{{cookiecutter.repo_name}}'
    assert find_template('~/local/cookiecutter-pypackage') == '~/local/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
"""
find_template('~/local/cookiecutter-djangopackage')
find_template('~/local/cookiecutter-pypackage')
"""

# Generated at 2022-06-23 16:15:26.969858
# Unit test for function find_template
def test_find_template():
    """Test function find_template() returns expected results."""
    test_repo_dir = 'tests/test-repo-pre/'
    exp_result = 'tests/test-repo-pre/{{cookiecutter.project_name}}'
    test_result = find_template(test_repo_dir)
    assert test_result == exp_result

# Generated at 2022-06-23 16:15:35.357119
# Unit test for function find_template
def test_find_template():
    """Verifies templated and non-templated dirs can be found correctly."""
    from .compat import TemporaryDirectory
    from .exceptions import NonTemplatedInputDirException

    # Non-templated dir
    with TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, 'not_a_template'))
        tmpl_dir = os.path.join(tmpdir, 'not_a_template')
        os.makedirs(os.path.join(tmpl_dir, 'pizza'))
        os.makedirs(os.path.join(tmpl_dir, 'pasta'))

        non_tmpl_dir = os.path.join(tmpl_dir, 'pizza')

# Generated at 2022-06-23 16:15:42.170780
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works as expected."""
    from cookiecutter.main import cookiecutter
    context = cookiecutter('tests/fake-repo-tmpl')
    template_dir = find_template('tests/fake-repo-tmpl')
    assert template_dir == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    context = cookiecutter(template_dir)
    assert context['full_name'] == 'Audrey Roy'

# Generated at 2022-06-23 16:15:46.705778
# Unit test for function find_template
def test_find_template():
    item = find_template(r"D:\GitHub\cookiecutter-pypackage-minimal")
    print(item)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:15:54.385633
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    repo_dir = cookiecutter('.')
    assert os.path.exists(repo_dir)
    assert os.path.isdir(repo_dir)

    project_template = find_template(repo_dir)

    assert os.path.exists(project_template)
    assert os.path.isdir(project_template)
    assert os.path.join(repo_dir, '{{cookiecutter.repo_name}}') == project_template

# Generated at 2022-06-23 16:15:57.854933
# Unit test for function find_template
def test_find_template():
    """Test the return value of find_template."""
    test_dirname = os.path.expanduser('~/cookiecutters')
    repo_dir = os.path.join(test_dirname, 'cookiecutter-pypackage')
    template_dir = find_template(repo_dir)
    assert os.path.basename(template_dir) == '{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:15:58.869449
# Unit test for function find_template
def test_find_template():
    assert find_template('.')


# Generated at 2022-06-23 16:16:01.550124
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works."""
    assert find_template('/Users/audreyr/Documents/GitHub/cookiecutter-pypackage') == \
           '/Users/audreyr/Documents/GitHub/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:05.355849
# Unit test for function find_template
def test_find_template():
    """Asserts that a Cookiecutter template is found within a directory"""
    
    input_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-data', 'project_template'
    )
    project_template = find_template(input_dir)
    assert project_template == os.path.join(input_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:16:08.425213
# Unit test for function find_template
def test_find_template():
    """
    """
    print('Testing find_template')
    print('for ')

    print('has a templated directory in the repo root ')
    print('has no templated directory in the repo root ')

# Generated at 2022-06-23 16:16:13.640516
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the correct path to the template."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:16:18.661268
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    repo_dir = '../tests/fake-repo/'
    project_template = find_template(repo_dir)
    assert project_template == '../tests/fake-repo/testapp-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:24.710043
# Unit test for function find_template
def test_find_template():
    local_repo_dir = os.path.abspath('./tests/fake-repo-tmpl')
    template_dir = find_template(local_repo_dir)
    template_dir_expected = os.path.join(local_repo_dir, '{{cookiecutter.repo_name}}')
    assert template_dir == template_dir_expected

# Generated at 2022-06-23 16:16:26.157205
# Unit test for function find_template
def test_find_template():
    """Pass"""
    assert find_template(repo_dir="") == None

# Generated at 2022-06-23 16:16:28.171573
# Unit test for function find_template
def test_find_template():
    assert find_template('./repo/')=='./repo/{{cookiecutter.name}}'


# Generated at 2022-06-23 16:16:35.541495
# Unit test for function find_template
def test_find_template():
    '''
    Tests function find_template in module finder.py
    '''
    import pytest
    from cookiecutter import exceptions

    def test_find_template_exception(monkeypatch):
        def mock_listdir(*args, **kwargs):
            return ['dir1', 'dir2']

        monkeypatch.setattr(os, 'listdir', mock_listdir)

        with pytest.raises(exceptions.NonTemplatedInputDirException):
            find_template('foo')

    test_find_template_exception()

    def test_find_template_happy_path(monkeypatch):
        def mock_listdir(*args, **kwargs):
            return ['foo', 'bar', 'cookiecutter-{{cookiecutter.repo_name}}']


# Generated at 2022-06-23 16:16:45.313566
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    username = 'audreyr'
    repo_name = 'cookiecutter-pypackage'
    repo_dir = 'tests/test-find-template/{0}/{1}'.format(username, repo_name)
    clone_to_dir = os.path.join('tests', 'test-find-template')

# Generated at 2022-06-23 16:16:49.190832
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo/'
    assert find_template(repo_dir) == 'tests/fake-repo/{{cookiecutter.directory_name}}'

# Generated at 2022-06-23 16:16:54.594527
# Unit test for function find_template
def test_find_template():
    """Test for case where project template is in a child directory of the
    repository root.

    """
    template = find_template(
        os.path.abspath(
            os.path.join(
                os.path.dirname(__file__),
                '..', 'tests', 'fake-repo-pre'
            )
        )
    )
    assert os.path.basename(template) == 'cookiecutter-pypackage-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:01.729620
# Unit test for function find_template
def test_find_template():
    from cookiecutter import _copy_files_to_basedir

    test_template_path = 'tests/files/project_template'
    basedir = './tests/files/test_temp_dir'

    # Copy the test template to a temp directory and modify it
    _copy_files_to_basedir(test_template_path, basedir)

    dir_contents = os.listdir(basedir)

    assert 'input' in dir_contents
    assert 'cookiecutter.json' in dir_contents

    project_template = find_template(test_template_path)
    assert project_template == test_template_path
    logger.debug('test_find_template passed!')

# Generated at 2022-06-23 16:17:03.587736
# Unit test for function find_template
def test_find_template():
    # TODO: Mock a repo on the filesystem
    # TODO: Check the resulting path to make sure it is correct
    assert True

# Generated at 2022-06-23 16:17:05.910200
# Unit test for function find_template
def test_find_template():
    """Test the find_template function"""
    try:
        assert find_template("cookiecutter")
    except NonTemplatedInputDirException:
        print("No Templated Project Found")
    else:
        raise "Templated Project Found"

# Generated at 2022-06-23 16:17:10.636063
# Unit test for function find_template
def test_find_template():
    assert(find_template('hello'))

# Generated at 2022-06-23 16:17:16.696318
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected


# Generated at 2022-06-23 16:17:18.999675
# Unit test for function find_template
def test_find_template():
    assert find_template('../tests/test-repo-pre/') == '../tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:24.910529
# Unit test for function find_template
def test_find_template():
    """Test function find_template()."""
    from cookiecutter import utils
    import tempfile

    with tempfile.TemporaryDirectory() as temp_dir:
        # Create a fake template
        template_dir = os.path.join(temp_dir, 'fake-template')
        os.mkdir(template_dir)
        # Create a fake file
        fake_file = os.path.join(template_dir, 'fake.txt')
        fake_file_contents = 'A text file!'
        utils.write_file(fake_file, fake_file_contents)

        found_template = find_template(temp_dir)

    assert found_template == template_dir

# Generated at 2022-06-23 16:17:29.143757
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    from cookiecutter.tests.test_repo import repo_dir
    result = find_template(repo_dir)
    assert result.endswith('tests/test-repo-tmpl-abc/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:17:34.557127
# Unit test for function find_template
def test_find_template():
    if os.path.isdir('tests/fake-repo-pre/fake_repo'):
        assert find_template('tests/fake-repo-pre/fake_repo') == os.path.abspath('tests/fake-repo-pre/fake_repo/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:17:39.340710
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = '/Users/audreyr/projects/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:45.217447
# Unit test for function find_template
def test_find_template():
    os.mkdir('/tmp/test')
    open('/tmp/test/mydir', 'w').close()
    os.chdir('/tmp/test')
    assert find_template('/tmp/test') == '/tmp/test/mydir'
    os.remove('/tmp/test/mydir')
    os.rmdir('/tmp/test')



# Generated at 2022-06-23 16:17:50.404198
# Unit test for function find_template
def test_find_template():
    # Mock out some test data
    repo_dir = os.path.abspath("tests/fake-repo-pre/")
    project_template = os.path.abspath("tests/fake-repo-pre/my-{{cookiecutter.repo_name}}/")
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:17:58.447258
# Unit test for function find_template
def test_find_template():
    """Verify function returns the project template"""
    import tempfile
    from cookiecutter.utils import rmtree

    # Create a temporary directory
    d = tempfile.mkdtemp()

    # Create a file with the string 'cookiecutter' in it
    cookiecutter_file_location = os.path.join(d, 'cookiecutter')
    f = open(cookiecutter_file_location, "w")
    f.write("test")
    f.close()

    # Create a file with the string 'cookiecutter' and a Jinja 2 '{{' in it
    cookiecutter_jinja2_file_location = os.path.join(d, 'cookiecutter_jinja2')
    f = open(cookiecutter_jinja2_file_location, "w")
    f.write("test")

# Generated at 2022-06-23 16:18:03.563770
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test-find-template'
    )

# Generated at 2022-06-23 16:18:10.058451
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    # now = datetime.date.today()
    # repo_dir = 'tests/test-repos/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    # template = find_template(repo_dir)
    # assert 'cookiecutter-pypackage/{{cookiecutter.repo_name}}/' == template

# Generated at 2022-06-23 16:18:13.790248
# Unit test for function find_template
def test_find_template():
    template = 'project'
    template_dir = os.path.abspath(os.path.join('tests', 'fake-repo', template))
    assert find_template('tests' + os.sep + 'fake-repo') == template_dir

# Generated at 2022-06-23 16:18:18.586741
# Unit test for function find_template
def test_find_template():
    templates = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..', '..', '..', 'tests', 'fake-repo-tmpl'
    ))
    logger.debug('Searching in %s', templates)
    project_template = find_template(templates)
    assert project_template == os.path.abspath(os.path.join(
        templates,
        'cookiecutter-pypackage-{{cookiecutter.repo_name}}'
    ))

# Generated at 2022-06-23 16:18:30.768436
# Unit test for function find_template
def test_find_template():
    """Verify find_template can find templates in different states of completeness."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    def cleanup_and_exit(dirpath):
        shutil.rmtree(dirpath)
        raise Exception('Failed to find expected dir')

    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:18:34.187594
# Unit test for function find_template
def test_find_template():
    assert find_template('template/cookiecutter-pypackage/.cookiecutter') == 'template/cookiecutter-pypackage/.cookiecutter/__project_name__'

# Generated at 2022-06-23 16:18:39.582387
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '../tests/fake-repo')
    )
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:18:42.747927
# Unit test for function find_template
def test_find_template():
    # TODO: Do a full mock-up of a git repository to test this thing.
    # pass
    assert False

# Generated at 2022-06-23 16:18:43.970798
# Unit test for function find_template
def test_find_template():
    find_template()

# Generated at 2022-06-23 16:18:50.744495
# Unit test for function find_template
def test_find_template():
    import cookiecutter.tests.test_utils
    repo_dir = cookiecutter.tests.test_utils.create_random_project()
    template_dir = find_template(repo_dir)
    assert os.path.isdir(template_dir)
    assert 'cookiecutter' in template_dir
    assert '{{' in template_dir
    assert '}}' in template_dir

# Generated at 2022-06-23 16:18:59.736057
# Unit test for function find_template
def test_find_template():
    """
    Ensure that the find_template function returns the right value.
    """
    import mock

    mock_repo_dir = mock.Mock()
    mock_repo_dir.__str__ = mock.Mock(return_value='foo_mock_directory')
    mock_repo_dir.join = mock.Mock()
    mock_repo_dir.join.__str__ = mock.Mock(return_value = 'foo_mock_directory/')
    mock_repo_dir.join.listdir = mock.Mock(return_value = ['foo_bar', 'bar'])
    mock_repo_dir.listdir = mock.Mock(return_value = ['foo_bar', 'bar'])
    # Checks it is a string.

# Generated at 2022-06-23 16:19:08.936447
# Unit test for function find_template
def test_find_template():
    """Test the find_template function"""
    from cookiecutter.tests.test_utils import make_empty_dir
    from cookiecutter.tests.test_utils import make_test_gitignore
    from cookiecutter.tests.test_utils import remove_repo

    empty_dir = make_empty_dir()
    make_test_gitignore(empty_dir, 'cookiecutter')
    project_template = find_template(empty_dir)
    assert project_template.endswith(os.path.join('tests', 'files', 'templates', 'cookiecutter'))
    remove_repo(empty_dir)



# Generated at 2022-06-23 16:19:10.140348
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the correct directory."""
    assert find_template('/tmp/fake_dir') == '/tmp/fake_dir/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:20.644537
# Unit test for function find_template
def test_find_template():
    """Test find_template method"""

    def get_repo_dir(tmpdir, name):
        repo_dir = tmpdir.mkdir(name)
        repo_dir.mkdir('{{cookiecutter.repo_name}}')
        repo_dir.mkdir('my_repo')
        # The "to_be" in the name ensures this is the *last* match
        repo_dir.mkdir('{{cookiecutter.repo_name}}to_be')
        return repo_dir

    def test_case_good(tmpdir):
        """Test find_template in a directory with a valid template"""
        repo_dir = get_repo_dir(tmpdir, 'find_template')
        repo_dir_path = repo_dir.strpath
        project_template = find_template(repo_dir_path)

# Generated at 2022-06-23 16:19:24.921658
# Unit test for function find_template
def test_find_template():
    """Verify that a local repo has a project template."""
    import os

    test_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(test_dir, 'test-repo-tmpl')

    project_template = find_template(repo_dir)
    assert 'cookiecutter' in project_template
    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-23 16:19:26.600978
# Unit test for function find_template
def test_find_template():
    """
    """
    raise NotImplementedError

# Generated at 2022-06-23 16:19:32.020717
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..', 'tests', 'test-input-dir'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-23 16:19:37.070483
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_finders import mytestrepo
    repo_dir = mytestrepo.checkout()

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:19:43.703744
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo'
    ))
    expected = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    ))
    template = find_template(repo_dir)
    assert template == expected

# Generated at 2022-06-23 16:19:48.931798
# Unit test for function find_template
def test_find_template():
    template = find_template(os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        'tests',
        'fake-repo-pre'
    ))

    assert template

# Generated at 2022-06-23 16:19:57.203094
# Unit test for function find_template
def test_find_template():
    """Unit tests for find_template function."""
    # Create a directory
    try:
        os.makedirs('tests/test-find-template/project_template')
    except:
        pass
    try:
        os.makedirs('tests/test-find-template/not_the_templat')
    except:
        pass

    # Test if find_template works
    assert find_template('tests/test-find-template') == 'tests/test-find-template/project_template'

    # Remove the created directory
    os.rmdir('tests/test-find-template/project_template')
    os.rmdir('tests/test-find-template/not_the_templat')

# Generated at 2022-06-23 16:20:05.462288
# Unit test for function find_template
def test_find_template():
    # test 1
    repo_dir = "/Users/audreyr/github/cookiecutter/tests/test-repo-pre/existing-repo-with-templated-dir"
    project_template = '/Users/audreyr/github/cookiecutter/tests/test-repo-pre/existing-repo-with-templated-dir/{{cookiecutter.repo_name}}'
    result = find_template(repo_dir)
    assert result == project_template
    # test 2
    repo_dir = "/Users/audreyr/github/cookiecutter/tests/test-repo-pre/existing-repo-without-templated-dir"
    project_template = None
    result = find_template(repo_dir)
    assert result == project_template

# Generated at 2022-06-23 16:20:08.256780
# Unit test for function find_template
def test_find_template():
    template = find_template('~/repo_dir')
    assert template == '~/repo_dir/cookiecutter-{{ cookiecutter.project_name }}'
    # TODO: finish tests

# Generated at 2022-06-23 16:20:10.701843
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    assert find_template(repo_dir) == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:18.086069
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    repo_dir = os.path.join(os.getcwd(), "test/test-template")
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)


# Generated at 2022-06-23 16:20:22.374880
# Unit test for function find_template
def test_find_template():
    # Not a very good test, but it's the best we can do until we refactor
    # find_template() so it's testable.
    assert (
        find_template('tests/fixtures/fake-repo-pre/').endswith(
            'tests/fixtures/fake-repo-pre/{{cookiecutter.repo_name}}'
        )
    )

# Generated at 2022-06-23 16:20:29.558878
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests import mock_files
    from cookiecutter.utils import rmtree

    repo_dir = mock_files.mock_repo()

    template = find_template(repo_dir)
    assert template.endswith(os.path.join('{{cookiecutter.repo_name}}'))

    rmtree(repo_dir)

# Generated at 2022-06-23 16:20:34.631613
# Unit test for function find_template
def test_find_template():
    """Validate that find_template returns the expected project template"""
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test-input-git'
    )

    actual = find_template(repo_dir)

    expected = os.path.normpath(os.path.join(
        repo_dir,
        'cookiecutter-pypackage',
    ))
    assert actual == expected

# Generated at 2022-06-23 16:20:46.181382
# Unit test for function find_template
def test_find_template():
    """Integration test for function find_template."""
    from cookiecutter import repo

    test_repo_folder = repo.clone(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        no_input=True
    )
    assert find_template(test_repo_folder) == os.path.join(test_repo_folder, '{{cookiecutter.repo_name}}')

    os.system('rm -rf ' + test_repo_folder)

    test_repo_folder = repo.clone(
        'https://github.com/hackebrot/cookiecutter-pytest-plugin.git',
        no_input=True
    )

# Generated at 2022-06-23 16:20:56.874215
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template
    """
    import os
    import shutil
    from cookiecutter.tests.test_find import TEMPLATE_DIR
    from cookiecutter.tests.test_find import TEST_DIR
    from cookiecutter.tests.test_find import TEST_REPO_DIR

    # Create an empty dir to use as a repo
    os.makedirs(TEST_REPO_DIR)

    # Create a templated dir, a non-templated dir, and a non-dir
    os.makedirs(TEMPLATE_DIR)
    os.makedirs(os.path.join(TEST_REPO_DIR, 'not_a_template'))
    open(os.path.join(TEST_REPO_DIR, 'not_a_directory'), 'w')

# Generated at 2022-06-23 16:21:01.238623
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/Projects/cookiecutter-pypackage') == 'Users/audreyr/Projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:07.873261
# Unit test for function find_template
def test_find_template():
    """Unit test for `find_template`."""
    calling_dir = os.getcwd()
    try:
        os.chdir(os.path.join(os.path.dirname(__file__), '..', 'tests'))
        find_template('fake-repo-pre')
        assert True
    except:
        assert False
    finally:
        os.chdir(calling_dir)

# Generated at 2022-06-23 16:21:08.489318
# Unit test for function find_template
def test_find_template():
    assert find_template()

# Generated at 2022-06-23 16:21:10.325055
# Unit test for function find_template
def test_find_template():
    pass


# TODO: move to prompt.py?

# Generated at 2022-06-23 16:21:17.713990
# Unit test for function find_template
def test_find_template():
    """Verify function find_template."""
    import os
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:21:29.127095
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    # pylint: disable=W0612
    from shutil import rmtree, copytree
    from tempfile import mkdtemp, NamedTemporaryFile
    import time
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    import cookiecutter.utils.prompt

    def test_do_prompt(self, text, default=None, no_input=False):
        """Mock input prompt when runnning tests."""
        if no_input:
            raise KeyboardInterrupt
        else:
            return default

    cookiecutter.utils.prompt.do_prompt = test_do_prompt


# Generated at 2022-06-23 16:21:34.665516
# Unit test for function find_template
def test_find_template():
    """Verify that function is returning a proper directory."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == template_dir

# Generated at 2022-06-23 16:21:39.385494
# Unit test for function find_template
def test_find_template():
    TEST_REPO_DIR = '/home/brian/code/jaya-cookiecutter-pypackage'
    template_dir = find_template(TEST_REPO_DIR)

    assert template_dir == os.path.join(
        TEST_REPO_DIR,
        'cookiecutter-pypackage'
    )

# Generated at 2022-06-23 16:21:50.009450
# Unit test for function find_template
def test_find_template():
    """Validate the find_template function."""

    import os
    import tempfile

    # Create a temporary directory
    temp_repo_dir = tempfile.mkdtemp()

    # Enter the new directory
    previous_dir = os.getcwd()
    os.chdir(temp_repo_dir)

    # Create a valid template
    valid_template = 'cookiecutter-{{cookiecutter.repo_name}}'
    os.mkdir(valid_template)
    os.chdir(valid_template)

    # Test the function
    template_found = find_template(temp_repo_dir)

    assert template_found == os.path.join(temp_repo_dir, valid_template)

    os.chdir(previous_dir)

# Generated at 2022-06-23 16:21:54.685516
# Unit test for function find_template
def test_find_template():
    """Sanity check: ensure we can find template directory in conventional repo."""
    import tempfile

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:58.821158
# Unit test for function find_template
def test_find_template():
    assert find_template('myrepo') == 'myrepo/cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:22:03.790841
# Unit test for function find_template
def test_find_template():
    """Sanity-check `find_template` function."""
    os.chdir('./tests/test-generate-files')
    path = find_template('.')
    assert path.endswith('/tests/test-generate-files/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:22:04.513745
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:22:12.845250
# Unit test for function find_template
def test_find_template():
    import tempfile
    from shutil import rmtree
    from cookiecutter.compat import zip

    zipfile_name = 'tests/test-find-template/find-template.zip'
    with tempfile.TemporaryDirectory() as tmpdirname:
        import zipfile
        zip_ref = zipfile.ZipFile(zipfile_name, 'r')
        zip_ref.extractall(tmpdirname)
        zip_ref.close()

        assert find_template(tmpdirname) == os.path.join(tmpdirname, '{{cookiecutter.repo_name}}')
        rmtree(tmpdirname)

# Generated at 2022-06-23 16:22:20.109828
# Unit test for function find_template
def test_find_template():
    expected = "tests/test-data/fake-repo-tmpl"
    result = find_template('tests/test-data/fake-repo')
    assert expected == result
    try:
        expected = "tests/test-data/fake-repo-tmpl"
        result = find_template('tests/test-data/fake-repo-no-tmpl')
    except NonTemplatedInputDirException as e:
        assert True
    except Exception as e:
        assert False