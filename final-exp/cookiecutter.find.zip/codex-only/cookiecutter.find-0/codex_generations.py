

# Generated at 2022-06-23 16:12:24.497966
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'fake-repo-pre', 'tests', 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:12:30.955078
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_tmp_dir_output = make_repo()
    tmp_dir_output = find_template(repo_tmp_dir_output)

    assert tmp_dir_output == os.path.join(repo_tmp_dir_output, '{{cookiecutter.repo_name}}')

    remove_repo(repo_tmp_dir_output)

# Generated at 2022-06-23 16:12:34.926416
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutters/cookiecutter-pypackage/'
    project_template = find_template(repo_dir)
    assert project_template == repo_dir + '/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:12:39.152916
# Unit test for function find_template

# Generated at 2022-06-23 16:12:43.032592
# Unit test for function find_template
def test_find_template():

    # Test for failure
    repo_dir = 'tests/fake-repo'
    project_template = find_template(repo_dir)
    if project_template:
        assert os.path.exists(project_template)
        assert 'cookiecutter' in project_template
        assert '{{' in project_template
        assert '}}' in project_template
    else:
        assert repo_dir == None

# Generated at 2022-06-23 16:12:44.134304
# Unit test for function find_template
def test_find_template():
    # Can't be tested easily because it's an OS operation.
    pass



# Generated at 2022-06-23 16:12:51.332394
# Unit test for function find_template
def test_find_template():
    """Test the ``find_template`` function"""
    test_repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'my-repo-tmpl')

    assert find_template(test_repo_dir) == os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:12:59.740018
# Unit test for function find_template
def test_find_template():
    """Test find_template method."""
    import cookiecutter.main
    import pytest
    import shutil

    # Set up a fake repo
    shutil.copytree(
        'tests/fake-repo-tmpl',
        'tests/fake-repo-pre-find'
    )

    repo_dir = 'tests/fake-repo-pre-find'

    project_template = cookiecutter.main.find_template(repo_dir)

    assert project_template == ('tests/fake-repo-pre-find/'
                                '{{cookiecutter.repo_name}}')

    # Tear down the fake repo
    shutil.rmtree('tests/fake-repo-pre-find')


# Generated at 2022-06-23 16:13:01.771029
# Unit test for function find_template
def test_find_template():
    """Ensure that a directory is found which contains 'cookiecutter' and '{{' and '}}'."""
    assert False

# Generated at 2022-06-23 16:13:06.764791
# Unit test for function find_template
def test_find_template():
    project_template = find_template(os.path.join(
        os.path.dirname(__file__),
        '..',
      '..',
      'tests',
      'fake-repo-pre-render'
    ))
    assert project_template == os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo-pre-render',
        '{{cookiecutter.repo_name}}',
    )

# Generated at 2022-06-23 16:13:12.204318
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    result = find_template(repo_dir)
    expected = '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert result == expected, result

# Generated at 2022-06-23 16:13:18.804226
# Unit test for function find_template
def test_find_template():
    """
    Test function that finds the template directory in a cookiecutter repo.
    """

    # this should be a repo, albeit a nonsense one
    repo_dir = os.path.join(os.getcwd(), 'tests')
    template_path = find_template(repo_dir)
    assert template_path == os.path.abspath(os.path.join(repo_dir, 'tests', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-23 16:13:27.374275
# Unit test for function find_template
def test_find_template():
    def test_find_template_repo_exactly_one_template_dir():
        tmpl_dir = os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            '..', 'tests', 'test-tmpl',
        )
        expected = os.path.join(tmpl_dir, '{{cookiecutter.repo_name}}')
        assert find_template(tmpl_dir) == expected

    def test_find_template_repo_no_template_dirs():
        tmpl_dir = os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            '..', 'tests', 'test-tmpl2',
        )

# Generated at 2022-06-23 16:13:30.086871
# Unit test for function find_template
def test_find_template():
    """Test that find_template correctly determines which directory is
    the project template.
    """
    input_dir = '/foo/bar'
    output = None


# Generated at 2022-06-23 16:13:38.322286
# Unit test for function find_template
def test_find_template():
    """Verifies find_template() returns the correct
    template path when the template path is the first
    item in the repo dir and when it's the last item in
    the repo dir
    """
    assert find_template('tests/test-repo-pre') == \
        'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-repo-post') == \
        'tests/test-repo-post/{{cookiecutter.repo_name}}'

    # Verify exception is raised when no template is found
    try:
        find_template('tests/no-jekyll/_no_jekyll')
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'Exception not raised when no template was found'

# Generated at 2022-06-23 16:13:42.185362
# Unit test for function find_template
def test_find_template():
    repo_dir = "/home/audreyr/cookiecutter-pypackage"
    assert find_template(repo_dir) == "/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}"

# Generated at 2022-06-23 16:13:49.327827
# Unit test for function find_template
def test_find_template():
    # Using the test repo directory.
    project_template = find_template('tests/fake-repo-pre/')
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    # Using the template directory.
    project_template = find_template('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:51.251377
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests import fake_context

    assert find_template(fake_context['_template']) == fake_context['_template']

# Generated at 2022-06-23 16:13:52.455575
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir)

# Generated at 2022-06-23 16:13:59.392266
# Unit test for function find_template
def test_find_template():
    """Verify function find_template returns expected path."""
    repo_dir = os.path.abspath(
        os.path.join('tests', 'test-find-project-template')
    )
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    found = find_template(repo_dir)

    assert expected == found

# Generated at 2022-06-23 16:14:07.772768
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    import os
    import tempfile

    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(project_template)

    repo_dir_contents = os.listdir(repo_dir)

    assert repo_dir_contents == ['{{cookiecutter.repo_name}}']
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:14:09.741175
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir=os.path.join('tests', 'fake-repo-pre-gen'))


# Generated at 2022-06-23 16:14:20.362680
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    # Create tarfile in temporary dir
    import tarfile
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:14:27.464629
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'fake-repo-pre')
    template = find_template(repo_dir)
    if template != os.path.join(repo_dir, '{{cookiecutter.repo_name}}'):
        assert True == False
    else:
        assert True == True

# Generated at 2022-06-23 16:14:34.184519
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/brian/projects/cookiecutter'
    ret_val = find_template(repo_dir)
    assert ret_val == '/home/brian/projects/cookiecutter/cookiecutter-pypackage/'
    return ret_val


# Generated at 2022-06-23 16:14:40.388244
# Unit test for function find_template
def test_find_template():
    """Test find_template function.

    Test the function for finding a project template.
    """
    repo_dir = "/Users/audreyr/cookiecutter-pypackage"
    project_template = find_template(repo_dir)

    expected_project_template = "/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}"

    assert project_template == expected_project_template

# Generated at 2022-06-23 16:14:49.766031
# Unit test for function find_template
def test_find_template():
    """Find template test"""
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'tests', 'fake-repo-pre/')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'tests', 'fake-repo-post/')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:14:56.457096
# Unit test for function find_template
def test_find_template():
    """Case where project_template is the only item in repo_dir.
    """
    repo_dir = os.path.join(os.getcwd(), 'tests', 'test-find-template')
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(repo_dir, 'project_template')
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:15:00.241165
# Unit test for function find_template
def test_find_template():
    repo_dir = os.getcwd()
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)

# Generated at 2022-06-23 16:15:05.247085
# Unit test for function find_template
def test_find_template():
    """Unit tests the main find_template function."""
    # TODO: test when the repo has multiple cookiecutter templates in it
    find_template('tests/test-find-repo')
    # Test that the repo has no cookiecutter templates
    try:
        find_template('tests/fake-repo')
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-23 16:15:06.854895
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter') == 'cookiecutter/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:15:13.068634
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from tempfile import mkdtemp

    repo_dir = mkdtemp()

    # Create a simple repo layout
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'docs'))
    os.makedirs(os.path.join(repo_dir, 'tests'))

    project_dir = find_template(repo_dir)

    expected_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_dir == expected_dir

    utils.rmtree(repo_dir)

    # Test NonTemplatedInputDirException
    os.makedirs

# Generated at 2022-06-23 16:15:23.909697
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns expected result.

    Create a temporary directory and write a README.md file to ensure
    the repo is not empty. Add a child directory that should be the
    project_template. Verify that find_template returns the correct
    path to this child directory.

    :return: `True` if function returns correct path, `False` otherwise.
    :rtype: boolean
    """
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    logger.debug('Created temporary directory %s', temp_dir)

    # Write a README.md file to the temporary directory to ensure
    # the repo is not empty.
    readme = os.path.join(temp_dir, 'README.md')

# Generated at 2022-06-23 16:15:30.453706
# Unit test for function find_template
def test_find_template():

    test_data = {
        'repo_dir': '/Users/audreyr/src/cookiecutter/tests/fake-repo',
        'project_template': os.path.join('/Users/audreyr/src/cookiecutter/tests/fake-repo', '{{cookiecutter.repo_name}}')
    }

    assert find_template(test_data['repo_dir']) == test_data['project_template']

# Generated at 2022-06-23 16:15:40.532982
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/code/cookiecutter-pypackage') == '/home/vagrant/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('/home/vagrant/code/cookiecutter-flask') == '/home/vagrant/code/cookiecutter-flask/{{cookiecutter.repo_name}}'
    assert find_template('/home/vagrant/code/cookiecutter-django') == '/home/vagrant/code/cookiecutter-django/{{cookiecutter.repo_name}}'
    assert find_template('/home/vagrant/code/cookiecutter-custom') == '/home/vagrant/code/cookiecutter-custom/{{cookiecutter.app_name}}'

# Generated at 2022-06-23 16:15:48.969746
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()

    cookiecutter_template_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    non_cookiecutter_template_dir = os.path.join(temp_dir, 'does_not_have_cookiecutter')
    cookiecutter_variable_missing_dir = os.path.join(temp_dir, '{{variable_is_missing}}')
    hidden_dir = os.path.join(temp_dir, '.hidden')

    os.mkdir(cookiecutter_template_dir)
    os.mkdir(non_cookiecutter_template_dir)
    os.mkdir(cookiecutter_variable_missing_dir)
    os

# Generated at 2022-06-23 16:15:54.460369
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected."""
    project_dir = os.path.join(
        os.path.dirname(__file__),
        os.pardir,
        'tests',
        'fake-repo-tmpl',
        '{{cookiecutter.repo_name}}'
    )
    template = find_template(project_dir)
    assert template == project_dir

# Generated at 2022-06-23 16:15:59.732894
# Unit test for function find_template
def test_find_template():
    """Verify correct project template is found"""
    current_path = os.path.join(os.path.expanduser('~'),
                                'cookiecutter-{{ project_name }}')

    new_path = find_template(current_path)

    assert new_path == os.path.join(current_path, 'cookiecutter-{{ project_name }}')

# Generated at 2022-06-23 16:16:01.556305
# Unit test for function find_template
def test_find_template():
    find_template('/Users/bibhas/Projects/cookiecutter-django-crud')


# Generated at 2022-06-23 16:16:03.426240
# Unit test for function find_template
def test_find_template():
    find_template('~/Documents/.cookiecutters/cookiecutter-pypackage/')
    find_template('~/Documents/')

# Generated at 2022-06-23 16:16:04.338339
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    pass

# Generated at 2022-06-23 16:16:08.021570
# Unit test for function find_template
def test_find_template():
    test_dir = "test/test-repo"
    project_template = find_template(test_dir)
    assert project_template == os.path.join(test_dir, "{{cookiecutter.repo_name}}")

# Generated at 2022-06-23 16:16:12.883459
# Unit test for function find_template
def test_find_template():
    """
    The function should return the path to the project template.
    """
    test_dir = '/home/user/cookiecutter-repos/cookiecutter-django'
    tmpl = find_template(test_dir)
    assert tmpl == '/home/user/cookiecutter-repos/cookiecutter-django/{{cookiecutter.repo_name}}'

test_find_template()

# Generated at 2022-06-23 16:16:16.374290
# Unit test for function find_template
def test_find_template():
    """Verify that the correct template directory is found.
    """
    from cookiecutter import find

    logger.debug('Testing function find_template')

    with find.work_in('tests/fake-repo-tmpl'):
        project_template = find.find_template('.')
    assert project_template == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:21.067457
# Unit test for function find_template
def test_find_template():
    file = 'cookiecutter-{{cookiecutter.repo_name}}'
    os.mkdir(file)
    assert find_template('./') == './cookiecutter-{{cookiecutter.repo_name}}'
    os.remove(file)

# Generated at 2022-06-23 16:16:32.697525
# Unit test for function find_template
def test_find_template():

    # Should find project template if it is named cookiecutter-{% noqa %}foo
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'fake-repo-pre',
            '{{cookiecutter.repo_name}}'
        )
    )
    assert find_template(repo_dir) == os.path.join(
        repo_dir,
        'cookiecutter-{{cookiecutter.repo_name}}'
    )

    # Should find project template if it is named cookiecutter-foo-{% noqa %}bar

# Generated at 2022-06-23 16:16:37.447098
# Unit test for function find_template
def test_find_template():
    # Tests for finding template for non templated input dir
    non_temp_input_dir = '/home/dummy/workspace/dummy_project'
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException
    with pytest.raises(NonTemplatedInputDirException):
        find_template(non_temp_input_dir)

    # Tests for finding template for templated input dir
    temp_input_dir = '/home/dummy/workspace/.cookiecutters/cookiecutter-pypackage'
    project_template = find_template(temp_input_dir)
    assert project_template == '/home/dummy/workspace/.cookiecutters/cookiecutter-pypackage/cookiecutter-pypackage'

# Generated at 2022-06-23 16:16:42.452563
# Unit test for function find_template
def test_find_template():
    """Verify ``find_template`` works as expected."""
    # TODO: test ``NonTemplatedInputDirException``
    repo_dir = 'cookiecutter-pypackage'
    project_template = 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    output = find_template(repo_dir)
    assert output == project_template

# Generated at 2022-06-23 16:16:47.887825
# Unit test for function find_template
def test_find_template():
    testdir = os.path.dirname(os.path.abspath(__file__))
    testdir = os.path.join(testdir, '..', 'tests', 'test-find-template')
    repo_dir = os.path.join(testdir, 'django-cookiecutter')
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_project_template


# Generated at 2022-06-23 16:16:58.148252
# Unit test for function find_template

# Generated at 2022-06-23 16:17:07.228463
# Unit test for function find_template
def test_find_template():
    """Test if find_template functions properly."""
    import shutil
    import tempfile
    repo_dir = tempfile.mkdtemp()
    sub_dir1 = os.path.join(repo_dir, 'cookiecutter-foo')
    os.mkdir(sub_dir1)
    sub_dir2 = os.path.join(repo_dir, 'cookiecutter-bar')
    os.mkdir(sub_dir2)
    sub_dir3 = os.path.join(repo_dir, 'cookiecutter-baz')
    os.mkdir(sub_dir3)
    dummy_file = os.path.join(repo_dir, 'nodir')
    with open(dummy_file, 'w') as f:
        f.write('dummy test file')
    filename1

# Generated at 2022-06-23 16:17:16.744837
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/johndoe/repo_tmp'
    expected_template = '/home/johndoe/repo_tmp/{{cookiecutter.repo_name}}'
    os.listdir = lambda x: ['{{cookiecutter.repo_name}}', 'cookiecutter', 'other stuff']
    assert find_template(repo_dir) == expected_template

    os.listdir = lambda x: ['{{cookiecutter.repo_name}}', 'cookiecutter', '{{cookiecutter.other_variable}}']
    expected_template = '/home/johndoe/repo_tmp/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == expected_template

# Generated at 2022-06-23 16:17:25.710484
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter
    cc_repo_dir = 'https://github.com/pytest-dev/cookiecutter-pytest-plugin'

    with tempfile.TemporaryDirectory() as repo_dir:
        cookiecutter(
            cc_repo_dir,
            no_input=True,
            overwrite_if_exists=True,
            output_dir=repo_dir
        )

        # The repo dir must not be empty
        assert os.listdir(repo_dir)
        project_template = find_template(repo_dir)
        assert isinstance(project_template, str)

        # Clean up the cloned repo
        shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:17:28.046088
# Unit test for function find_template
def test_find_template():
    """Verify that the function returns non-None."""
    repo_dir = '.'
    assert find_template(repo_dir)

# Generated at 2022-06-23 16:17:31.471577
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo')
    project_template = 'tests/fake-repo/{{cookiecutter.project_name}}'
    assert find_template(repo_dir) == os.path.abspath(project_template)

# Generated at 2022-06-23 16:17:36.125096
# Unit test for function find_template
def test_find_template():

    os.chdir('tests')

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    find_template('fixtures/fake-repo-tmpl')

# Generated at 2022-06-23 16:17:44.825285
# Unit test for function find_template
def test_find_template():
    """Verify that we can find the project template."""
    from cookiecutter import utils

    # Find the repository root
    tests_dir = os.path.dirname(utils.__file__)
    repo_dir = os.path.abspath(os.path.join(tests_dir, '..'))

    # Run the function
    project_template = find_template(repo_dir)

    # Verify that the result matches our expectation
    assert project_template == os.path.join(repo_dir, 'tests', 'files', 'test-project')

# Generated at 2022-06-23 16:17:56.860082
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.utils import rmtree
    from cookiecutter.main import cookiecutter
    from git.repo.base import Repo
    import tempfile
    # Create a temporary git repo for this unit test
    tmp_git_repo = tempfile.mkdtemp()
    tmp_git_repo_clone = tempfile.mkdtemp()

    # Initialize a new git repo and commit some files
    Repo.init(tmp_git_repo)
    Repo(tmp_git_repo).index.commit("Initial commit")
    Repo(tmp_git_repo).create_remote("origin", tmp_git_repo)

    # Make directories and files to put in git repo

# Generated at 2022-06-23 16:18:03.962261
# Unit test for function find_template
def test_find_template():
    test_input_path = "/home/terry/my/random/path/"
    result = find_template(test_input_path)
    assert result == "/home/terry/my/random/path/cookiecutter-pypackage"

# Code calling the function
"""
Cookiecutter finds the project template within the repo by searching
for a directory that contains 'cookiecutter' and '{{' and '}}' in it.
"""
cookiecutter_dir = find_directory(cookiecutter_repo_dir)
"""
"""

# Generated at 2022-06-23 16:18:06.570339
# Unit test for function find_template
def test_find_template():
    this_dir = os.path.dirname(__file__)

# Generated at 2022-06-23 16:18:11.971679
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    project_templ = find_template(repo_dir)
    assert project_templ == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    
    

# Generated at 2022-06-23 16:18:14.201588
# Unit test for function find_template
def test_find_template():
    """Function to test function `find_template`."""
    find_template(os.path.abspath('tests/fake-repo'))

# Generated at 2022-06-23 16:18:19.078800
# Unit test for function find_template
def test_find_template():
    """
    This function is used to test the find_template function.
    """
    repo_dir = os.path.join(os.path.abspath(
        os.path.dirname(__file__)), '..', 'tests', 'fake-repo')
    assert 'tests/fake-repo/fake_template' == find_template(repo_dir)
    assert find_template(repo_dir)
    assert find_template(repo_dir).endswith('fake_template')



# Generated at 2022-06-23 16:18:27.104065
# Unit test for function find_template
def test_find_template():
    """Verify find_template correctly locates the project template."""
    repo_dir = '/path/to/cookiecutter-pypackage'
    project_template = '/path/to/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    os.listdir = lambda x: ['apple', 'banana', '{{cookiecutter.repo_name}}']

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:18:36.405084
# Unit test for function find_template
def test_find_template():
    """
    Sanity test for find_template
    """
    import shutil
    import tempfile

    from cookiecutter import find

    tmp_dir = tempfile.mkdtemp()

    repo_dir = os.path.join(tmp_dir, 'my_repo')
    os.mkdir(repo_dir)
    with open(os.path.join(repo_dir, 'file1.txt'), 'w') as f:
        f.write('Hello world!')

    # Setup the repo_dir to have a directory that should be the project
    # template, along with a couple of other directories.
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(project_template)

# Generated at 2022-06-23 16:18:43.638790
# Unit test for function find_template
def test_find_template():

    # Test with a usable repo
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    template = find_template(repo_dir)
    assert template.endswith('fake-repo-pre/project_template')

    # Test with a repo that doesn't have a template
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-no-template')
    try:
        template = find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-23 16:18:52.906299
# Unit test for function find_template
def test_find_template():
    """Test finding template directory."""
    template_dir = find_template(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), '../tests/fake-repo-tmpl'
    ))
    # The template dir is found with a leading slash, because the root
    # of the project is determined based on the cwd, which is different
    # during testing.
    assert template_dir.endswith('/tests/fake-repo-tmpl/_cookiecutter')
    assert os.path.exists(template_dir)

# Generated at 2022-06-23 16:18:57.150032
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/cookiecutter-pypackage') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:03.444399
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_utils import make_blank_dir
    temp_dir = make_blank_dir()

    # No templated directories
    os.mkdir(os.path.join(temp_dir, 'dir_name'))
    assert find_template(temp_dir) is None

    # One templated directory
    os.mkdir(os.path.join(temp_dir, '{{cookiecutter.project}}'))
    assert find_template(temp_dir) == os.path.join(
        temp_dir,
        '{{cookiecutter.project}}'
    )


# Generated at 2022-06-23 16:19:09.328417
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(
                            os.path.dirname(__file__),
                            '..', 'tests', 'test-repo')) == \
           os.path.join(
               os.path.dirname(__file__), 
               '..', 'tests', 'test-repo',
               'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:19:10.891294
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_main import TEST_REPO_DIR

# Generated at 2022-06-23 16:19:20.562348
# Unit test for function find_template
def test_find_template():
    """Test that the expected template is found."""
    test_template = '{{cookiecutter.repo_name}}'
    repo_dir = os.getcwd()
    repo_dir_contents = os.listdir(repo_dir)
    tt_present = False
    for item in repo_dir_contents:
        if test_template == item:
            tt_present = True
            break

    # If template is present, remove it before running test
    if tt_present:
        os.system('rm -rf %s' % test_template)

    os.system('mkdir %s' % test_template)
    assert find_template(repo_dir) == os.path.join(repo_dir, test_template)

# Generated at 2022-06-23 16:19:23.710928
# Unit test for function find_template
def test_find_template():
    """Verify find_template works."""
    compare_dir = 'tests/test-find-dir/fake-repo'
    project_template = find_template(compare_dir)
    assert project_template == 'tests/test-find-dir/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:31.135928
# Unit test for function find_template
def test_find_template():
    test_dir = None

    # Create a temporary directory
    try:
        temp_dir = tempfile.mkdtemp()
        test_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
        os.mkdir(test_dir)
        assert find_template(temp_dir) == test_dir

    finally:
        if test_dir:
            os.rmdir(test_dir)



# Generated at 2022-06-23 16:19:37.862594
# Unit test for function find_template
def test_find_template():
    """Nose unit test"""
    import os
    # Check the root of this project
    this_dir = os.path.dirname(__file__)
    repo_dir = os.path.abspath(os.path.join(this_dir, '..'))
    print(repo_dir)
    project_template = find_template(repo_dir)
    print(project_template)


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:19:41.265883
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    template = find_template('tests/files/foobarbaz')
    assert template == 'tests/files/foobarbaz/cookiecutter-foobarbaz'

# Generated at 2022-06-23 16:19:46.841720
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), os.pardir, 'fake-repo'
    ))

    test_find_template(test_repo_dir)

# Generated at 2022-06-23 16:19:50.006403
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:19:52.205306
# Unit test for function find_template
def test_find_template():
    assert find_template('temp/fake-repo-tmpl') == 'temp/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:00.909163
# Unit test for function find_template
def test_find_template():
    """
    Test that find_template finds the project template.
    """
    import tempfile
    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, 'tests/files/fake-repo')
    os.system("cp -r {0}/. {1}".format(template_dir, repo_dir))
    assert find_template(repo_dir) == os.path.join(repo_dir, 'fake_template')

    # Test that NonTemplatedInputDirException is raised if no templated directory is found
    os.system("rm -rf {0}".format(repo_dir))
    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:20:11.566183
# Unit test for function find_template
def test_find_template():
    """Verify that the correct template directory is found."""
    from .compat import TemporaryDirectory
    from .exceptions import NonTemplatedInputDirException

    template_path = os.path.join('{{cookiecutter.repo_name}}',
                                 '{{cookiecutter.project_name}}')
    with TemporaryDirectory() as temp_dirname:
        os.makedirs(os.path.join(temp_dirname, template_path))
        os.makedirs(os.path.join(temp_dirname, 'some_dir'))
        os.makedirs(os.path.join(temp_dirname, 'another_dir'))
        found_template = find_template(temp_dirname)
        assert found_template == os.path.join(temp_dirname, template_path)


# Generated at 2022-06-23 16:20:20.872070
# Unit test for function find_template
def test_find_template():
    import shutil
    from tempfile import mkdtemp
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    project_template = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl',
    )
    cloned_repo_dir = mkdtemp()
    shutil.copytree(project_template, cloned_repo_dir)

    project_template = find_template(cloned_repo_dir)

    rmtree(cloned_repo_dir)

# Generated at 2022-06-23 16:20:33.080530
# Unit test for function find_template
def test_find_template():
    """Verify function for finding templates."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar', '{{'))
    logger.debug('repo_dir is %s', repo_dir)

    # project_template = find_template(repo_dir)
    # assert 'cookiecutter-foobar' in project_template
    # assert '{{' in project_template
    # assert '}}' in project_template
    #
    # shutil.rmtree(repo_dir)
    # logger.debug("Deleted %s", repo_dir)


# Generated at 2022-06-23 16:20:36.497098
# Unit test for function find_template
def test_find_template():
    """
    Making sure the cookiecutter template directory is found.
    """
    template_dir = 'tests/test-find-template'
    good_template = '{{cookiecutter.project_name}}/{{cookiecutter.project_slug}}'
    assert find_template(template_dir) == os.path.join(template_dir, good_template)

# Generated at 2022-06-23 16:20:47.050736
# Unit test for function find_template
def test_find_template():
    # Create a simple template for testing
    import os
    import shutil
    from cookiecutter.vcs import clone
    from cookiecutter.utils import make_sure_path_exists

    from .exceptions import FailedHookException

    repo_dir = 'fake-repo'
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    branch = 'master'
    clone(repo_url, repo_dir, checkout=branch)
    project_dir = 'fake-project'

    if os.path.isdir(project_dir):
        shutil.rmtree(project_dir)
    make_sure_path_exists(project_dir)


# Generated at 2022-06-23 16:20:49.928719
# Unit test for function find_template
def test_find_template():
    """Test finding a template."""
    from cookiecutter.tests.test_find import fixture_path
    repo_path = fixture_path('fake-repo-tmpl')
    actual = find_template(repo_path)
    expected = os.path.join(repo_path, 'foobar-{{cookiecutter.foobar}}')
    assert actual == expected

# Generated at 2022-06-23 16:20:52.951422
# Unit test for function find_template
def test_find_template():
    try:
        find_template(os.path.join(os.path.dirname(__file__), 'repo-tmpl'))
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-23 16:20:55.924891
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/fake-repo-{{cookiecutter.repo_name}}/'

# Generated at 2022-06-23 16:21:01.150104
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        os.pardir,
        os.pardir,
        os.pardir,
        'tests',
        'test-repo',
        '{{cookiecutter.repo_name}}',
    )
    expected_path = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}',
    )
    found_path = find_template(repo_dir)
    assert expected_path == found_path

# Generated at 2022-06-23 16:21:02.181289
# Unit test for function find_template
def test_find_template():
    """Basic unit test for find_template"""
    pass

# Generated at 2022-06-23 16:21:07.043988
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = 'tests/fake-repo-pre/'

    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/cookiecutter-pypackage-min/'

# Generated at 2022-06-23 16:21:14.513788
# Unit test for function find_template
def test_find_template():
    """Test if find_template is working as expected."""
    import tempfile

    repo_dir = tempfile.mkdtemp()
    logger.debug('The repo dir is %s', repo_dir)

    # Create a project template dir
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter{{cookiecutter.repo_name}}'))

    os.mkdir(os.path.join(repo_dir, 'my_repo_name'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter_my_repo_name'))

    project_template = find_template(repo_dir)
    assert project_

# Generated at 2022-06-23 16:21:22.023080
# Unit test for function find_template
def test_find_template():
    this_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(this_dir, 'tests', 'fake-repo')
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:21:30.706100
# Unit test for function find_template
def test_find_template():
    os.path.join = os.path
    repo_dir = {
        'result': os.path.join('some', 'where', 'over', 'the', 'rainbow')
    }
    repo_dir_contents = [
        'so',
        'Toto',
        '{{cookiecutter.is_raining}}',
        'please-do-not-find-this',
        'weep-for-the-lost-patches'
    ]

    project_template = find_template(repo_dir, repo_dir_contents)

    assert project_template == os.path.join(
        'some', 'where', 'over', 'the', 'rainbow', '{{cookiecutter.is_raining}}'
    )

# Generated at 2022-06-23 16:21:36.952416
# Unit test for function find_template
def test_find_template():
    """Test the function find_template."""
    import shutil

    mock_repo_dir = 'test_find_templates'

    if not os.path.exists(mock_repo_dir):
        shutil.copytree(
            'tests/test-data/cookiecutter-django',
            mock_repo_dir
        )

    assert find_template(mock_repo_dir) == mock_repo_dir + '/{{cookiecutter.repo_name}}'
    shutil.rmtree(mock_repo_dir)

# Generated at 2022-06-23 16:21:39.218319
# Unit test for function find_template
def test_find_template():
    # TODO: does not work with real Git repo directories
    template = find_template('.')
    assert template == './{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:21:43.328422
# Unit test for function find_template
def test_find_template():
    assert find_template("/Users/audreyr/projects/cookiecutter-pypackage") == \
        "/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}"

# Generated at 2022-06-23 16:21:48.906102
# Unit test for function find_template
def test_find_template():
    test_repo_dir = '/Users/audreyr/projects/cookiecutter/tests/test-templates/good-repo'
    repo_dir = find_template(test_repo_dir)
    assert repo_dir == '/Users/audreyr/projects/cookiecutter/tests/test-templates/good-repo/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:21:53.590192
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    repo_dir = r"C:\Users\hongc\Documents\GitHub\cookiecutter-pypackage"
    find_template(repo_dir)
    return True

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:21:58.528170
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage-example/.cookiecutters/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/Users/audreyr/cookiecutter-pypackage-example/.cookiecutters/cookiecutter-pypackage/cookiecutter-pypackage'

# Generated at 2022-06-23 16:22:02.816927
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/files/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/files/fake-repo/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:22:07.199142
# Unit test for function find_template
def test_find_template():
    """ Assert function returns correct path """
    repo_dir = '/home/lara/projects/cookiecutter-django'
    expected = '/home/lara/projects/cookiecutter-django/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == expected

# Generated at 2022-06-23 16:22:13.223909
# Unit test for function find_template
def test_find_template():
    """
    Test function `find_template`
    """
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    template_path = find_template(repo_dir)

    assert os.path.isdir(template_path)
    assert os.path.basename(template_path) == 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:22:22.099323
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/Hudson/my_dir'
    logger.debug("repo_dir: " + repo_dir)
    os.path.basename('/Users/Hudson/my_dir')
    print("os.path.basename('/Users/Hudson/my_dir')")
    project_template = '/Users/Hudson/my_dir/cookiecutter-{{cookiecutter.project_slug}}'
    #project_template = 'cookiecutter-{{cookiecutter.project_slug}}'
    #assert project_template == repo_dir / 'cookiecutter-{{cookiecutter.project_slug}}'

