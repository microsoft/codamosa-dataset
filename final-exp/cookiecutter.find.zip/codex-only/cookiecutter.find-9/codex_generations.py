

# Generated at 2022-06-23 16:12:28.953110
# Unit test for function find_template
def test_find_template():
    """
    Expected Behavior:

    - Pulls repo down to a subdir of the cwd.
    - Finds the cookiecutter.json in that dir.
    - Uses the dir that contains that file as the project template.
    """
    import shutil
    import sys
    import tempfile
    import textwrap
    from mock import patch
    from cookiecutter.generate import generate_context, generate_files
    from git import Repo

    temp_dir = tempfile.mkdtemp()
    input_dir = os.path.join(temp_dir, 'input_dir')
    os.makedirs(input_dir)
    os.chdir(temp_dir)


# Generated at 2022-06-23 16:12:35.657006
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), '..', '..',
        'tests', 'test-input-repo-templated-only-vv'
    )
    repo_template_dir = find_template(repo_dir)
    # The path depends on the OS, so we can't use os.path.join here
    assert repo_template_dir.endswith('tests/test-input-repo-templated-only-vv/{{cookiecutter.repo_name}}'), repo_template_dir

# Generated at 2022-06-23 16:12:37.952727
# Unit test for function find_template
def test_find_template():
    """
    Test function find_template.
    """
    # TODO: Test for finding the template directory inside of the repo directory
    # TODO: Test for when there is no template directory inside of the repo directory
    # TODO: Test for when the repo directory is empty (except for .git)

# Generated at 2022-06-23 16:12:43.638549
# Unit test for function find_template
def test_find_template():
    """Ensure that find_template can find the correct repo_dir."""
    assert find_template('tests/fake-repo-pre/') == \
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre/') != \
        'tests/fake-repo-pre/'

# Generated at 2022-06-23 16:12:48.586143
# Unit test for function find_template
def test_find_template():
    res = find_template('/Users/audreyr/cookiecutter-example-100/')
    assert(res == '/Users/audreyr/cookiecutter-example-100/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:12:53.005334
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/test-dirs'
    logger.debug('Testing find_template')
    project_template = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:12:59.912449
# Unit test for function find_template
def test_find_template():
    """Verify the path to the project template is found."""
    test_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'fake-repo')
    )
    project_template = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    assert project_template == find_template(test_dir)

# Generated at 2022-06-23 16:13:07.146757
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from tests.test_utils import make_files

    tempdir = tempfile.mkdtemp()

    # check NonTemplatedInputDirException is raised if not found
    make_files(tempdir)
    try:
        find_template(tempdir)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'NonTemplatedInputDirException not raised'

    # check correct directory returned
    path = os.path.join(tempdir, '{{cookiecutter.repo_name}}')
    os.mkdir(path)
    result = find_template(tempdir)
    assert path == result, 'incorrect directory returned'

# Generated at 2022-06-23 16:13:15.728235
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template()"""
    from cookiecutter import utils
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_DIR
    from cookiecutter.tests.test_utils import TEST_REPO_DIR
    repo_dir = utils.make_sure_path_exists(TEST_REPO_DIR, utils.convert_to_os_path(TEST_TEMPLATE_DIR))
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    # Clean up.
    utils.rmtree(repo_dir)

# Generated at 2022-06-23 16:13:18.821701
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns correct template directory relative path."""
    repo_dir = 'tests/test-find-template'
    project_template = 'fake-project'
    project_template_dir = os.path.join(repo_dir, project_template)
    found_template = find_template(repo_dir)
    assert found_template == project_template_dir

# Generated at 2022-06-23 16:13:29.335419
# Unit test for function find_template
def test_find_template():
    """Tests `find_template`."""
    repo_dir = '/path/to/fake-repo'
    repo_dir_contents = [
        'doc',
        'example',
        'python-package-{{author_name}}',
    ]
    with patch('os.listdir') as mock_os_listdir:
        mock_os_listdir.return_value = repo_dir_contents
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(
            '/path/to/fake-repo',
            'python-package-{{author_name}}'
        )

# Generated at 2022-06-23 16:13:34.136091
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(template_dir)
    project_template = os.path.basename(project_template)
    assert project_template == 'fake-project-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:41.604336
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    # Setup
    repo_dir = os.path.join('tests', 'test-find-repo', 'cookiecutter-pypackage')
    project_template_rel = 'cookiecutter-pypackage'

    # Run
    project_template = find_template(repo_dir)

    # Test
    assert os.path.join(repo_dir, project_template_rel) == project_template

# Generated at 2022-06-23 16:13:46.309272
# Unit test for function find_template
def test_find_template():
    """Verify function returns expected result."""
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'

    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:13:52.510821
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/foo/my-repo'
    repo_dir_contents = ['.', '..', 'docs', 'tests', 'cookiecutter-{{project_name}}']

    def listdir_mock(path):
        return repo_dir_contents

    orig_listdir = os.listdir
    os.listdir = listdir_mock

    project_template = find_template(repo_dir)

# Generated at 2022-06-23 16:14:01.116813
# Unit test for function find_template
def test_find_template():
    """Verify function for finding project template."""
    from cookiecutter.tests.test_find import make_repo
    from tempfile import mkdtemp
    import shutil

    root_dir = mkdtemp()
    project_template = '{{cookiecutter.project_slug}}'
    make_repo(project_template, root_dir)

    project_template_found = find_template(root_dir)
    assert project_template_found == os.path.join(root_dir, project_template)

    shutil.rmtree(root_dir)

# Generated at 2022-06-23 16:14:07.374917
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""

    template_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'test-template')
    result = find_template(template_dir)
    assert result == os.path.join(template_dir, 'cookiecutter-base')

# Generated at 2022-06-23 16:14:07.892965
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:09.537721
# Unit test for function find_template
def test_find_template():
    abs_path = os.path.abspath(".")
    find_template(abs_path)

# Generated at 2022-06-23 16:14:17.801721
# Unit test for function find_template
def test_find_template():
    """Test the function find_template"""
    from cookiecutter import prompt
    from .repository import determine_repo_dir
    from . import clone

    logger = logging.getLogger(__name__)

    temp_repo_path = '/tmp/cookiecutter-tmp'
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dest = '{{cookiecutter.repo_name}}'

    # Delete temp repo if it exists.
    if os.path.isdir(temp_repo_path):
        prompt.rmtree(temp_repo_path)

    clone.clone(repo_url, temp_repo_path, no_input=True)


# Generated at 2022-06-23 16:14:18.730756
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:26.131822
# Unit test for function find_template
def test_find_template():
    """Verify that a template that is the only file in a repo is found."""
    from cookiecutter import repo
    from cookiecutter.utils import rmtree

    # Create a git repo in a temp folder
    temp_repo_path = repo.generate_files()

    try:
        project_template = find_template(temp_repo_path)
        assert project_template == os.path.join(temp_repo_path, '{{cookiecutter.repo_name}}')
    finally:
        rmtree(temp_repo_path)

# Generated at 2022-06-23 16:14:29.173559
# Unit test for function find_template
def test_find_template():
    import tempfile
    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    os.makedirs(project_template)
    assert find_template(repo_dir) == project_template



# Generated at 2022-06-23 16:14:30.452923
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:32.005674
# Unit test for function find_template
def test_find_template():
    find_template('/Users/myusuf3/projects/cookiecutter-django')

# Generated at 2022-06-23 16:14:37.226447
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter import utils

    with pytest.raises(NonTemplatedInputDirException):
        utils.find_template('tests/fake-repo-pre/')

    template_path = utils.find_template('tests/fake-repo-pre/tests/fake-repo-late/')
    assert template_path == 'tests/fake-repo-pre/tests/fake-repo-late/cookiecutter-pypackage'

# Generated at 2022-06-23 16:14:45.240288
# Unit test for function find_template
def test_find_template():
    from cookiecutter.vcs import clone
    from cookiecutter import utils
    from cookiecutter import exceptions

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    clone(template)
    folder_name = utils.workdir.split('/')[-1]

    assert(find_template(os.path.join(utils.workdir, folder_name)) == os.path.join(utils.workdir, folder_name, '{{ cookiecutter.repo_name }}'))
    utils.rmtree(utils.workdir)

# Generated at 2022-06-23 16:14:48.662852
# Unit test for function find_template
def test_find_template():
    template_path = find_template(
        "/Users/audreyr/git/cookiecutter-pytest-plugin"
    )
    assert template_path == "/Users/audreyr/git/cookiecutter-pytest-plugin"

# Generated at 2022-06-23 16:14:54.202152
# Unit test for function find_template
def test_find_template():
    """Test function for find_template function."""

    cookiecutter_path = 'my-fake-path'

    project_template = find_template(cookiecutter_path)
    expected_project_template = 'my-fake-path/cookiecutter-{{cookiecutter.repo_name}}'

    assert project_template == expected_project_template

# Generated at 2022-06-23 16:14:55.709634
# Unit test for function find_template
def test_find_template():
    return find_template('examples/generate-project')

# Generated at 2022-06-23 16:15:02.226154
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.expanduser('~'),
        'projects/gautheron-cookiecutter-pypackage'
    )
    template = find_template(repo_dir)

    assert os.path.exists(template)
    assert template.endswith('cookiecutter-pypackage')

# Generated at 2022-06-23 16:15:07.449350
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template.
    """
    from os.path import join

    this_function_name = inspect.stack()[0][3]
    print('in %s' % this_function_name)

    TEST_REPO_DIR = join(TEST_DIR, 'test_example')
    RESULT = find_template(TEST_REPO_DIR)
    assert RESULT

# Generated at 2022-06-23 16:15:10.072012
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    project_template = 'fake-repo-pre/{{cookiecutter.repo_name}}/'
    assert find_template(repo_dir) == project_template


# Generated at 2022-06-23 16:15:17.608351
# Unit test for function find_template
def test_find_template():
    """test find_template"""
    repo_dir = (
        '/home/audreyr/code/cookiecutter-pypackage/tests/test-input-dir'
    )
    project_template = find_template(repo_dir)
    assert project_template == (
        '/home/audreyr/code/cookiecutter-pypackage/tests/'
        'test-input-dir/{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:15:22.755272
# Unit test for function find_template
def test_find_template():
    """Verify that the function find_template finds the cookiecutter templates."""
    repo_dir = "/Users/audreyr/code/cookiecutter/tests/test-repos/foobar-test"
    project_template = find_template(repo_dir)
    assert project_template == "/Users/audreyr/code/cookiecutter/tests/test-repos/foobar-test/{{cookiecutter.foobar}}"


# Generated at 2022-06-23 16:15:30.454162
# Unit test for function find_template
def test_find_template():
    """Verify that `find_template` returns the relative path to the template."""
    here = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(here, 'fake-repo-pre-gen')

    project_template = find_template(repo_dir)
    logger.debug('The project template appears to be %s', project_template)
    expected_path = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_path

# Generated at 2022-06-23 16:15:36.976536
# Unit test for function find_template
def test_find_template():
    import os

    from .utils import make_repo
    from .utils import TEST_TEMPLATES_DIR

    repo_dir = os.path.join(TEST_TEMPLATES_DIR, 'fake-repo')
    make_repo(repo_dir)

    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, 'fake-project-template')
    assert project_template == expected



# Generated at 2022-06-23 16:15:44.656200
# Unit test for function find_template
def test_find_template():
    """
    Tests the 'find_template' function in the utils modules.
    """

    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    logger.debug('temp_dir %s', temp_dir)

    # Create a subdirectory inside temp_dir
    git_repo_dir = os.path.join(
        temp_dir,
        'cookiecutter-pypackage'
    )
    logger.debug('git_repo_dir %s', git_repo_dir)

    os.makedirs(git_repo_dir)

    # Create a child directory
    child_dir = os.path.join(
        git_repo_dir,
        'cookiecutter-pypackage'
    )
    logger.debug

# Generated at 2022-06-23 16:15:50.477467
# Unit test for function find_template
def test_find_template():
    """Test that the function find_template works as expected."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests',
                            'test-find-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir,
                                                   'cookiecutter-pypackage')

# Generated at 2022-06-23 16:15:53.123911
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests/fake-repo/"
    find_template(repo_dir)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:16:00.323748
# Unit test for function find_template
def test_find_template():
    """Find template in test repo"""
    os.chdir(os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test_find_template'
    ))
    project_template = find_template(
        os.path.join(os.getcwd(), 'fake-repo')
    )
    assert project_template == 'fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:04.492110
# Unit test for function find_template
def test_find_template():
    if os.path.isdir(os.path.dirname(__file__)+'/dummy_repo'):
        repo_dir = os.path.dirname(__file__)+'/dummy_repo'
        assert find_template(repo_dir) == repo_dir+'/{{ cookiecutter.repo_name }}'

# Generated at 2022-06-23 16:16:07.700330
# Unit test for function find_template
def test_find_template():
    """
    Unit test for find_template function
    """

    repo_dir = os.getcwd()

    project_template = find_template(repo_dir)
    assert project_template != None

# Generated at 2022-06-23 16:16:08.778681
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-23 16:16:11.818468
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    try:
        find_template('tests/fake-repo-tmpl/')
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-23 16:16:12.392783
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:16:19.420156
# Unit test for function find_template
def test_find_template():
    """Assert that find_template returns path of project template folder"""

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 
        '..', '..', 'tests', 'test-repo'
    )
    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(
        repo_dir, 'test-template'
    )

    assert project_template == expected_project_template

# Generated at 2022-06-23 16:16:22.403843
# Unit test for function find_template
def test_find_template():
    """Test function to find the template"""
    # assert find_template(repo_dir) == project_template

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:16:30.933285
# Unit test for function find_template
def test_find_template():
    assert(find_template('fixtures/fake-repo/tests/test-cookiecutter-ppp-substring') ==
           'fixtures/fake-repo/tests/test-cookiecutter-ppp-substring/{{cookiecutter.repo_name}}')
    assert(find_template('fixtures/fake-repo/tests/test-cookiecutter-missing-substring') ==
           'fixtures/fake-repo/tests/test-cookiecutter-missing-substring')

# Generated at 2022-06-23 16:16:38.887707
# Unit test for function find_template
def test_find_template():
    """Bill Gates the unit test for function find_template"""
    template_dir = os.path.join(os.path.dirname(__file__), '..', 'fake-repo-tmpl')
    template_dir = os.path.abspath(template_dir)
    logger.debug('abs template_dir: %s', template_dir)
    project_template = find_template(template_dir)
    logger.debug('project_template: %s', project_template)

# Generated at 2022-06-23 16:16:39.821644
# Unit test for function find_template
def test_find_template():

    find_template("hi") == None

# Generated at 2022-06-23 16:16:41.598141
# Unit test for function find_template
def test_find_template():
    find_template(os.path.join(os.getcwd(), 'tests/test-find-template'))

# Generated at 2022-06-23 16:16:44.221021
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo'
    expected = 'tests/fake-repo/{{cookiecutter.project_dir}}'
    actual = find_template(repo_dir)
    assert actual == expected

# Generated at 2022-06-23 16:16:45.892129
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == './cookiecutter-pypackage'

# Generated at 2022-06-23 16:16:48.253197
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    template = find_template('../tests/fake-repo-templated/')
    assert template == '../tests/fake-repo-templated/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:51.356897
# Unit test for function find_template
def test_find_template():  # noqa
    """Verify expected template is found."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:16:54.697737
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            '..',
            'tests',
            'test-repo'
        )
    )
    assert find_template(repo_dir)

# Generated at 2022-06-23 16:16:59.837051
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    test_input_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre/',
    )
    project_template = find_template(test_input_dir)
    assert project_template == test_input_dir + os.path.sep + '{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:17:01.963588
# Unit test for function find_template
def test_find_template():
    """ Test find_tmeplate returns the template directory if present """
    pass

# Generated at 2022-06-23 16:17:07.472625
# Unit test for function find_template
def test_find_template():
    """Test whether the function find_template finds the template within a
       non-templated repo"""

    # Setup
    repo_dir_1 = "tests/fixtures/fake-repo-tmpl"
    repo_dir_2 = "tests/fixtures/fake-repo-no-tmpl"

    # Test
    assert find_template(repo_dir_1) == \
           "tests/fixtures/fake-repo-tmpl/{{cookiecutter.repo_name}}"
    assert find_template(repo_dir_2) == \
           "tests/fixtures/fake-repo-no-tmpl/fake-repo"

# Generated at 2022-06-23 16:17:13.331092
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(__file__),
        'tests/test-data/fake-repo'
    )
    test_dir = os.path.abspath(test_dir)

    project_template = find_template(test_dir)
    project_template = os.path.basename(project_template)

    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-23 16:17:22.643371
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns a path to a cookiecutter template"""
    import os
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

    os.mkdir(os.path.join(repo_dir, 'not_a_template'))
    os.mkdir(os.path.join(repo_dir, 'not_a_template_either'))
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.project_name}}'))

    result = find_template(repo_dir)

    assert result == os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    shutil.rmtree(repo_dir)

# Generated at 2022-06-23 16:17:32.946517
# Unit test for function find_template
def test_find_template():
    """Verify find_template finds the Project Template."""
    import tempfile

    # Create a temporary directory
    repo_dir = tempfile.mkdtemp()

    # Create the file the function should find
    temp_file_path = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    temp_file = open(temp_file_path, 'w')
    temp_file.close()

    # Create a file that should be ignored
    temp_file_path = os.path.join(repo_dir, 'README.md')
    temp_file = open(temp_file_path, 'w')
    temp_file.close()

    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-23 16:17:34.183061
# Unit test for function find_template
def test_find_template():
    """ Test for find_template

    """
    pass

# Generated at 2022-06-23 16:17:35.343931
# Unit test for function find_template
def test_find_template():
    """Function that tests find_template."""
    # Possible TODO
    pass

# Generated at 2022-06-23 16:17:39.906366
# Unit test for function find_template
def test_find_template():
    """Tests the ``find_template`` function."""
    repo_dir = '/home/audreyr/cookiecutters/pypackage'
    template = '/home/audreyr/cookiecutters/pypackage/cookiecutter-pypackage'
    assert find_template(repo_dir) == template

# Generated at 2022-06-23 16:17:43.130585
# Unit test for function find_template
def test_find_template():
        repo_dir = 'd:/cookiecutter-pypackage'
        project_template = find_template(repo_dir)
        os.system('pause')

# Generated at 2022-06-23 16:17:49.098979
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'repos', 'cookiecutter-pypackage'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:17:52.163371
# Unit test for function find_template
def test_find_template():
    find_template('/Users/pydanny/projects/cookiecutter/cookiecutter-django/')
    # 'new-project-dir'
    assert False

# Generated at 2022-06-23 16:17:59.544988
# Unit test for function find_template
def test_find_template():
    # Absolute path to source code
    source_path = os.path.abspath(os.path.dirname(__file__))
    
    # Directory of cloned repo in CI configuration
    repo_dir = os.path.abspath(os.path.join(source_path, os.pardir, 'tests', '.cookiecutters', 'config'))
    assert find_template(repo_dir) == os.path.join(repo_dir, '.ci')

# Generated at 2022-06-23 16:18:04.372467
# Unit test for function find_template
def test_find_template():
    """Find a cookiecutter template which contains a variable in its name."""
    import tempfile

    template = '{{cookiecutter.project_name}}'
    root_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(root_dir, template))

    assert template == find_template(root_dir)


# Generated at 2022-06-23 16:18:09.369681
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/gavin/example/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/home/gavin/example/cookiecutter-pypackage/{{cookiecutter.repo_name}}', "{}".format(find_template(repo_dir))

# Generated at 2022-06-23 16:18:16.148763
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import tempfile

    current_dir = os.path.abspath(os.path.dirname(__file__))
    fixtures_dir = os.path.join(current_dir, 'fixtures')
    test_dir = os.path.join(fixtures_dir, 'abcd')

    with tempfile.TemporaryDirectory() as tmpdir:
        new_dir = os.path.join(tmpdir, "abcd")
        find_template(test_dir)

# Generated at 2022-06-23 16:18:18.585736
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:25.375564
# Unit test for function find_template
def test_find_template():
    # Set up
    orig_dir = os.getcwd()
    os.chdir('tests/test-find-template')
    result = find_template('.')
    expected = os.path.abspath('tests/test-find-template/{{cookiecutter.repo_name}}-master')
    # Tear down
    os.chdir(orig_dir)
    # Check
    assert result == expected

# Generated at 2022-06-23 16:18:31.505334
# Unit test for function find_template
def test_find_template():
    """
    Unit test to prove `find_template` function is working as expected.
    """
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == repo_dir + '\\cookiecutter-pypackage'

# Generated at 2022-06-23 16:18:41.712989
# Unit test for function find_template
def test_find_template():
    from shutil import rmtree
    from cookiecutter.operations import clone
    from cookiecutter import main

    # Create a simple directory for passing in to find_template
    repo_dir = '/tmp/find_template_test/'
    cookiecutter_dir = 'cookiecutter-pypackage'
    clone(
        'https://github.com/audreyr/' + cookiecutter_dir + '.git',
        repo_dir,
        checkout='',
    )

    # Run find_template against the new directory
    result_dir = find_template(repo_dir)

    # If the result dir contains the word 'cookiecutter', we've won
    assert 'cookiecutter' in result_dir, "Directory should contain 'cookiecutter'"

    # TODO: Add assertion that the result_dir contains '{{

# Generated at 2022-06-23 16:18:45.447284
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    assert find_template('tests/test-output/fake-repo-tmpl/') == 'tests/test-output/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:18:56.821983
# Unit test for function find_template
def test_find_template():
    """Test the function that finds a repo's project template.
    """
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    template_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-find-template/{{cookiecutter.repo_name}}'
    )
    expected_template = os.path.join(
        template_dir,
        'cookiecutter-pypackage'
    )
    logger.debug('Looking for a template in %s', template_dir)

    result_template = find_template(template_dir)
    assert result_template == expected_template


# Generated at 2022-06-23 16:19:04.474335
# Unit test for function find_template
def test_find_template():
    """ Test the find_template function.
    """
    import tempfile
    import shutil

    # Test for default project template
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:19:09.841490
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    project_template = 'cookiecutter-pypackage'

    assert find_template(repo_dir) == os.path.join(repo_dir, project_template)

# TODO: Move the next two functions to a separate util module.

# Generated at 2022-06-23 16:19:10.869428
# Unit test for function find_template
def test_find_template():
    """Test for the find_template function."""
    pass

# Generated at 2022-06-23 16:19:17.010223
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    output = find_template(repo_dir)
    assert output == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:19:19.371063
# Unit test for function find_template
def test_find_template():
    print(find_template('/home/matt/workspace/cookiecutter/tests/fake-repo'))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:19:23.906527
# Unit test for function find_template
def test_find_template():
    """Make sure find_template finds the template dir in cookiecutter/tests/test-input."""
    template_dir = os.path.join(
        os.getcwd(), 'tests', 'test-input', 'cookiecutter-pypackage')
    result = find_template(template_dir)
    expected = os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    assert result == expected

# Generated at 2022-06-23 16:19:28.048483
# Unit test for function find_template
def test_find_template():
    path = os.path.join(os.path.dirname(__file__), 'fake-repo')
    assert find_template(path) == os.path.join(path, '{{repo_name}}')

# Generated at 2022-06-23 16:19:36.153118
# Unit test for function find_template
def test_find_template():
    """Verify that the function `find_template` works correctly."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    project_template = tempfile.mkdtemp(dir=repo_dir)
    shutil.rmtree(project_template)
    project_template = os.path.basename(project_template)
    project_template = '{{%s}}' % project_template

    os.makedirs(os.path.join(repo_dir, project_template))

    assert find_template(repo_dir) == os.path.join(repo_dir, project_template)

# Generated at 2022-06-23 16:19:39.752417
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-find-template'
    template_dir = 'tests/test-find-template/my-template-{{cookiecutter.project_name}}'

    assert find_template(repo_dir) == template_dir

# Generated at 2022-06-23 16:19:44.992253
# Unit test for function find_template
def test_find_template():
    """Verify ``find_template`` works."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', 'tests', 'test-output',
        'cookiecutter-pypackage')

    assert os.path.isdir(repo_dir)

    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert os.path.isdir(expected)

    assert expected == find_template(repo_dir)

# Generated at 2022-06-23 16:19:49.140028
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/ros/Documents/cookiecutter-django.git'
    project_template = find_template(repo_dir)
    assert project_template == '/home/ros/Documents/cookiecutter-django.git/cookiecutter-django'

# Generated at 2022-06-23 16:19:52.935143
# Unit test for function find_template
def test_find_template():
    assert (
        find_template('tests/test-data/fake-repo-tmpl') ==
        os.path.abspath(
            'tests/test-data/fake-repo-tmpl/{{cookiecutter.repo_name}}'
        )
    )

# Generated at 2022-06-23 16:19:57.203077
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-repo')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:20:03.662712
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    import shutil

    TEST_DIR = '/tmp/cookiecutter_unittests/find_template'
    BASE_REPO = 'https://github.com/audreyr/cookiecutter-pypackage.git'

    try:
        shutil.rmtree(TEST_DIR)
    except OSError:
        pass

    from cookiecutter.vcs import git
    repo_dir = git.clone(BASE_REPO, TEST_DIR)


# Generated at 2022-06-23 16:20:04.244225
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:20:05.797302
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works as expected."""
    pass

# Generated at 2022-06-23 16:20:12.174457
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    print("Testing find_template function.")
    test_template_dir = os.path.join("tests", "test-input", "simple", "cookiecutter-simple")
    assert find_template(test_template_dir).endswith("cookiecutter-simple")

    test_template_dir = os.path.join("tests", "test-input", "simple", "cookiecutter-simple-master")
    assert find_template(test_template_dir).endswith("cookiecutter-simple-master")

# Generated at 2022-06-23 16:20:18.874881
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        '..',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
    )
    project_template = find_template(repo_dir)
    assert project_template == 'csn-unified-framework'

# Generated at 2022-06-23 16:20:19.784614
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir)


# Generated at 2022-06-23 16:20:26.839906
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter import exceptions

    with TemporaryDirectory() as repo_dir:
        utils.make_sure_path_exists(os.path.join(repo_dir, 'cookiecutter'))
        utils.make_sure_path_exists(os.path.join(repo_dir, 'cookiecutter-foobar'))
        utils.make_sure_path_exists(os.path.join(repo_dir, 'something-else'))

        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, 'cookiecutter')


# Generated at 2022-06-23 16:20:33.750055
# Unit test for function find_template
def test_find_template():
    """Ensure that `find_template` works as expected."""
    import tempfile
    from cookiecutter import utils

    # Create a repo dir
    repo_dir = tempfile.mkdtemp()

    # Add a project template to the repo dir
    project_template = os.path.join(repo_dir, "{{ cookiecutter.repo_name }}")
    utils.make_certain_path_exists(project_template)

    # Call function
    output = find_template(repo_dir)

    # Check result
    assert output == project_template

# Generated at 2022-06-23 16:20:37.543669
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir='tests/test-find-template') == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:20:38.796096
# Unit test for function find_template
def test_find_template():
    find_template("cookiecutter")

# Generated at 2022-06-23 16:20:41.814511
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo/' 
    template = find_template(repo_dir)
    correct_template = 'tests/test-repo/good-{{cookiecutter.repo_name}}'
    assert template == correct_template
    repo_dir = 'tests/test-repo/bad-repo-no-templated-dir'
    find_template(repo_dir)
    # non templated input directory should raise error

# Generated at 2022-06-23 16:20:45.072881
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory name."""
    assert find_template('tests/test-layouts/fake-repo/') == 'tests/test-layouts/fake-repo/{{cookiecutter.project_name}}'

# Generated at 2022-06-23 16:20:56.337696
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    from cookiecutter.tests.test_replay import reset_env_vars
    from cookiecutter.tests.test_replay import BUILTIN_ABSPATH
    from cookiecutter import utils
    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:21:01.440337
# Unit test for function find_template
def test_find_template():
    """Test that the find_template function is working."""

# Generated at 2022-06-23 16:21:13.045580
# Unit test for function find_template
def test_find_template():
    """Unit tests for function find_template."""
    import shutil
    import tempfile
    import textwrap

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:21:19.892042
# Unit test for function find_template
def test_find_template():
    repo_dir = "/local/path/to/cookiecutter-my-awesome-project/"
    expected_project_template = "/local/path/to/cookiecutter-my-awesome-project/{{cookiecutter.repo_name}}"
    actual_project_template = find_template(repo_dir)

    assert expected_project_template == actual_project_template

# Generated at 2022-06-23 16:21:20.944782
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:21:31.313683
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    import shutil
    from cookiecutter.generate import generate_context

    TMP_CHECKOUT_DIR = 'fake-repo-tmpl'
    REPO_DIR = 'fake-repo'
    REPO_URL = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    REPO_DIR_CONTENTS = os.listdir(
        os.path.join(os.path.dirname(__file__), REPO_DIR)
    )

    os.mkdir(TMP_CHECKOUT_DIR)

# Generated at 2022-06-23 16:21:38.027010
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns expected results."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/my-fake-cookiecutter-project'
    assert find_template('tests/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('.') == 'fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:41.617637
# Unit test for function find_template
def test_find_template():
    from cookiecutter import repo

    repo_dir = repo.clone("https://github.com/audreyr/cookiecutter-pypackage.git")

    # Todo: Mock this, I don't want a real repo_dir to test this
    assert find_template(repo_dir) == os.path.join(repo_dir, "{{cookiecutter.repo_name}}")

# Generated at 2022-06-23 16:21:44.311827
# Unit test for function find_template
def test_find_template():
    """Verify find_template function"""
    import doctest
    doctest.run_docstring_examples(find_template, globals(), verbose=False)


# Generated at 2022-06-23 16:21:48.188943
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/nvie/Code/cookiecutter-djangopackage'
    result = find_template(repo_dir)
    assert 'cookiecutter-djangopackage/{{cookiecutter.repo_name}}' == result


# Generated at 2022-06-23 16:21:54.644778
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    test_dir = os.path.join(os.path.dirname(__file__), 'test_template')
    result = find_template(test_dir)
    assert result == os.path.join(test_dir, '{{cookiecutter.repo_name}}'), \
        'test_find_template failed'

# Generated at 2022-06-23 16:21:58.530766
# Unit test for function find_template
def test_find_template():
    """
    Test find_template()
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'repo_dirs',
        'non_templated_dirs',
        'non-templated-repo'
    )

    actual = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert actual == expected

# Generated at 2022-06-23 16:22:03.245901
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(__file__) + '/../tests/fake-repo-tmpl/'
    assert find_template(repo_dir).endswith('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')



# Generated at 2022-06-23 16:22:07.994252
# Unit test for function find_template
def test_find_template():
    repo_dir = 'fake-repo'
    res = find_template(repo_dir)
    assert res == os.path.join(repo_dir, 'cookiecutter-pypackage'), 'find_template did not return the expected value'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:22:12.297073
# Unit test for function find_template
def test_find_template():
    """Find template in fixtures directory"""
    assert find_template(
        'tests/fixtures/input/fake-repo-tmpl') == 'tests/fixtures/input/fake-repo-tmpl/{{cookiecutter.repo_name}}'



# Generated at 2022-06-23 16:22:13.450184
# Unit test for function find_template
def test_find_template():

    pass

# Generated at 2022-06-23 16:22:17.150194
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo'
    project_template = 'tests/fake-repo/cookiecutter-pypackage'

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:22:21.234878
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'test-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'my-new-awesome-project')