

# Generated at 2022-06-23 16:12:26.435027
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
    ))
    expected_project_templ = os.path.join(
        repo_dir,
        'cookiecutter-pypackage',
    )
    project_templ = find_template(repo_dir)
    assert project_templ == expected_project_templ

# Generated at 2022-06-23 16:12:27.624234
# Unit test for function find_template
def test_find_template():
    """Verify function is working as expected."""
    pass


# Generated at 2022-06-23 16:12:31.915631
# Unit test for function find_template
def test_find_template():
    # This function works with paths
    assert find_template('tests/test-find-template') == 'tests/test-find-template/{{cookiecutter.repo_name}}'
    # This function works with folders
    assert find_template('tests') == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:12:40.470852
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree
    from cookiecutter import vcs
    from .compat import patch

    vcs_patcher = patch('cookiecutter.find.vcs')
    mock_vcs = vcs_patcher.start()
    mock_vcs.identify.return_value = 'git'
    mock_vcs.clone.return_value = 'tests/fake-repo-tmpl'

    vcs.identify('https://github.com/audreyr/cookiecutter-pypackage.git')
    vcs.clone('https://github.com/audreyr/cookiecutter-pypackage.git')


# Generated at 2022-06-23 16:12:46.867507
# Unit test for function find_template
def test_find_template():
    """Test that function find_template is able to detect the template."""

    from unittest import TestCase
    from tempdir import TemporaryDirectory

    class TestFindTemplate(TestCase):

        def test_find_template(self):
            with TemporaryDirectory() as tmpdir:
                template_dir = os.path.join(tmpdir, 'cookiecutter-helloworld')
                os.mkdir(template_dir)
                template_name = find_template(tmpdir)
                self.assertTrue(template_name, template_dir)

    test_find_template()

# Generated at 2022-06-23 16:12:52.035378
# Unit test for function find_template
def test_find_template():
    repo_dir = "../tests/fake-repo"
    answer = "../tests/fake-repo/fake-template"
    result = find_template(repo_dir)

    assert result == answer, \
        "Result {0} is not equal to the answer {1}".format(result, answer)

test_find_template()

# Generated at 2022-06-23 16:12:57.819726
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo')
    )
    project_template = find_template(repo_dir)

    assert (
        project_template ==
        os.path.join(repo_dir, '{{cookiecutter.project_name}}', '{{cookiecutter.repo_name}}')
    )

# Generated at 2022-06-23 16:13:03.435069
# Unit test for function find_template
def test_find_template():
    import os
    import tempfile

    logging.disable(logging.CRITICAL)
    tempdir = tempfile.mkdtemp()
    os.makedirs(os.path.join(tempdir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(tempdir, 'cookiecutter-otherpackage'))
    assert find_template(tempdir) == os.path.join(
        tempdir,
        'cookiecutter-pypackage',
    )

# Generated at 2022-06-23 16:13:06.837527
# Unit test for function find_template
def test_find_template():
    assert find_template("tests/test-input-repo/") == \
        "tests/test-input-repo/{{cookiecutter.repo_name}}"

# Generated at 2022-06-23 16:13:12.608999
# Unit test for function find_template
def test_find_template():
    this_dir = os.path.dirname(__file__)
    repo_dir_path = os.path.join(this_dir, 'repo-tmpl')

    project_template = find_template(repo_dir_path)
    project_template = os.path.basename(project_template)
    assert project_template == 'cookiecutter-project'

# Generated at 2022-06-23 16:13:16.536070
# Unit test for function find_template
def test_find_template():
    template_dir = find_template('examples/tests/fake-repo-pre/')
    assert template_dir == 'examples/tests/fake-repo-pre/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:13:22.045626
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    cookiecutters_dir = "cookiecutters/"
    main.cookiecutters_dir = cookiecutters_dir
    repo_dir = os.path.abspath(
        os.path.join(cookiecutters_dir, '0/cookiecutter-pypackage')
    )
    # print repo_dir
    template_dir = find_template(repo_dir)
    if template_dir != os.path.abspath(
        os.path.join(cookiecutters_dir, '0/cookiecutter-pypackage/{{cookiecutter.repo_name}}')
    ):
        raise Exception('find_template() is not working')
    print('find_template() is working')

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-23 16:13:24.362427
# Unit test for function find_template
def test_find_template():
    find_template('/Users/vahid/Developer/cookiecutter/tests/fake-repo-tmpl')

# Generated at 2022-06-23 16:13:28.680824
# Unit test for function find_template
def test_find_template():
    """Test function to see if it could find the correct template"""
    assert find_template("/tests/fixtures/fake-repo") == "/tests/fixtures/fake-repo/{{cookiecutter.repo_name}}/"

# Generated at 2022-06-23 16:13:33.480335
# Unit test for function find_template
def test_find_template():
    """Ensure that find_template can find the project template."""
    assert 'bar' == find_template('tests/input/find_template')
    assert 'qux' == find_template('tests/input/find_template_multiple')
    assert 'master' == find_template('tests/input/find_template_multilevel')

# Generated at 2022-06-23 16:13:34.443882
# Unit test for function find_template
def test_find_template():
    """Unit test to find_template function."""
    pass

# Generated at 2022-06-23 16:13:35.761657
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:13:39.828825
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    project_template = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:13:45.217482
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == expected

# Generated at 2022-06-23 16:13:48.877089
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-input/test-repo'

    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-input/test-repo/cookiecutter-pypackage'

# Generated at 2022-06-23 16:13:49.995046
# Unit test for function find_template

# Generated at 2022-06-23 16:13:50.545590
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:02.342356
# Unit test for function find_template
def test_find_template():
    import pathlib
    from cookiecutter.utils.paths import ensure_dir
    from cookiecutter.utils.paths import get_repo_root

    # Move to tests folder for cloning
    repo_root = get_repo_root()
    os.chdir(repo_root)

    fixture_path = 'tests/fixtures/fake-repo-pre'
    project_path = os.path.join(fixture_path, '{{cookiecutter.repo_name}}')

    # Copy fixtures directory to temporary path
    tmp_path = os.path.join(repo_root, 'tests/fixtures/fake-repo-pre')
    ensure_dir(tmp_path)

    # Clone fixture

# Generated at 2022-06-23 16:14:08.510670
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct file."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:14:15.508522
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test-data',
        'fake-repo',
    )
    project_template = os.path.join(
        repo_dir,
        'cookiecutter-{{cookiecutter.repo_name}}',
    )
    assert find_template(repo_dir) == project_template

# Unit test that function raises error when no template found

# Generated at 2022-06-23 16:14:16.022744
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:14:22.081317
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    found_template_dir = find_template(template_dir)
    assert found_template_dir == os.path.join(template_dir, '{{cookiecutter.repo_name}}')

test_find_template()

# Generated at 2022-06-23 16:14:27.065040
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/projects/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:14:31.022764
# Unit test for function find_template
def test_find_template():
    """ Find the Cookiecutter template in a directory """
    template_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'files', 'test-template')
    template = find_template(template_dir)
    assert template == os.path.join(template_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:14:34.479186
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo'
    project_template = find_template(repo_dir)
    assert project_template.endswith('tests/test-repo/{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:14:35.325847
# Unit test for function find_template
def test_find_template():
    find_template('cookiecutter')

# Generated at 2022-06-23 16:14:38.783125
# Unit test for function find_template
def test_find_template():
    template_under_test = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            'test-template-with-dashes',
            '{{cookiecutter.repo_name}}',
        )
    )
    assert template_under_test == find_template(os.path.dirname(template_under_test))

# Generated at 2022-06-23 16:14:49.082953
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() finds the template in a repo."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import main
    from unittest import TestCase
    import os
    import shutil

    class TestFindTemplate(TestCase):

        def test_find_template_in_repo(self):
            """Verify that find_template() finds the template in a repo."""
            repo_dir = 'tests/test-find-template'
            logger.debug('Creating fake repo...')
            shutil.copytree('tests/fake-repo-tmpl', repo_dir)
            logger.debug('Fake repo created at %s.', repo_dir)
            path = '{{cookiecutter.repo_dir}}'

            main.find_template(repo_dir)

# Generated at 2022-06-23 16:14:55.293395
# Unit test for function find_template
def test_find_template():
    """Check whether the correct template is found."""
    test_dir = os.path.join(os.path.dirname(__file__), 'test_repo')
    test_project_template = os.path.join(
        test_dir, '{{cookiecutter.repo_name}}'
    )
    assert find_template(test_dir) == test_project_template

# Generated at 2022-06-23 16:15:01.380946
# Unit test for function find_template
def test_find_template():
    test_path = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(
        test_path,
        'fake-project-template-with-a-cookiecutter-directory-inside'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        'cookiecutter-{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-23 16:15:06.764000
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('./tests/test-repo-tmpl')
    project_template = find_template(repo_dir)
    expected = 'tests/test-repo-tmpl/{{cookiecutter.repo_name}}'
    # test repo name is defined as 'repo_name' in cookiecutter.json
    assert(project_template == expected)

# Generated at 2022-06-23 16:15:09.547350
# Unit test for function find_template
def test_find_template():
    repo = os.path.join(os.path.dirname(__file__), os.pardir, 'tests',
                        'fake-repo-pre')
    project_template = find_template(repo)
    print(project_template)
    assert project_template == os.path.join(repo, 'fake_project_tmpl')



# Generated at 2022-06-23 16:15:12.441661
# Unit test for function find_template
def test_find_template():
    find_template('/home/daniel/Desktop/cookiecutter-tools/tests/stubs/repo') == '/home/daniel/Desktop/cookiecutter-tools/tests/stubs/repo/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:15:19.121254
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.join(os.path.dirname(__file__), '..', 'repos', 'cookiecutter-pypackage'))
    assert find_template(os.getcwd()) == os.path.join(os.getcwd(), '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:15:26.733143
# Unit test for function find_template
def test_find_template():
    import pytest
    import shutil
    import subprocess
    import tempfile

    @pytest.yield_fixture
    def repo_dir(request):
        repo_dir = tempfile.mkdtemp()
        os.chdir(repo_dir)
        subprocess.check_call(['git', 'init'])
        subprocess.check_call(
            ['git', 'remote', 'add', 'origin',
             'https://github.com/audreyr/cookiecutter-pypackage.git']
        )
        subprocess.check_call(['git', 'pull', 'origin', 'master'])
        yield repo_dir
        shutil.rmtree(repo_dir)

    def test_find_template(repo_dir):
        template = find_template(repo_dir)

# Generated at 2022-06-23 16:15:27.366157
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:15:35.554713
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import config
    from cookiecutter import utils

    repo_dir = "tests/test-templates/fake-repo-tmpl"
    project_template = "tests/test-templates/fake-repo-tmpl/fake-project-tmpl"

    repo_dir_bakeout = os.path.join(config.USER_BAKEOUT_DIRECTORY, 'fake-repo-tmpl')
    project_template_bakeout = os.path.join(repo_dir_bakeout, 'fake-project-tmpl')

    if os.path.isdir(repo_dir_bakeout):
        utils.rmtree(repo_dir_bakeout)

    cookiecutter(repo_dir)

   

# Generated at 2022-06-23 16:15:38.660423
# Unit test for function find_template
def test_find_template():
    find_template('/home/gbaron/Cookiecutter')
    assert find_template('/home/gbaron/Cookiecutter') == '/home/gbaron/Cookiecutter/cookiecutter-pypackage'

# Generated at 2022-06-23 16:15:43.638441
# Unit test for function find_template
def test_find_template():
    repo_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'templates'))
    template_path = os.path.join(repo_path, '{{cookiecutter.repo_name}}')

    assert find_template(repo_path) == template_path

# Generated at 2022-06-23 16:15:44.773862
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-23 16:15:50.915174
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template function works as expected."""
    repo_dir = os.path.abspath(os.path.join('tests', 'fake-repo-tmpl'))
    assert find_template(repo_dir) == os.path.join(repo_dir, 'fake-project-tmpl')

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-23 16:15:56.774282
# Unit test for function find_template
def test_find_template():
    temp_repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        'tests',
        'non_templated_repo'
    )
    template = find_template(temp_repo_dir)

    assert template == os.path.join(temp_repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:15:58.177463
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template()."""
    pass


# Generated at 2022-06-23 16:15:59.681770
# Unit test for function find_template
def test_find_template():
    find_template('/home/user/')


# Generated at 2022-06-23 16:16:06.344529
# Unit test for function find_template
def test_find_template():
    # test when the directory is empty
    test_dir = os.path.join(
        os.getcwd(),
        os.path.dirname(__file__),
        'empty-repo')
    repo_dir_contents = os.listdir(test_dir)
    project_template = find_template(test_dir)
    # expect NonTemplatedInputDirException
    assert project_template == None
    # test when there is only one project template
    test_dir = os.path.join(
        os.getcwd(),
        os.path.dirname(__file__),
        'input-repo')
    repo_dir_contents = os.listdir(test_dir)
    project_template = find_template(test_dir)

# Generated at 2022-06-23 16:16:11.131206
# Unit test for function find_template
def test_find_template():
    """Correctly find template file in a directory containing other files.
    """
    repo_dir = os.path.join('tests', 'fake-repo', 'input')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-23 16:16:16.639840
# Unit test for function find_template
def test_find_template():
    """Test find_template"""
    import shutil

    import pytest
    pytest.importorskip('git')
    # TODO: Find better example URL
    example_repo = 'https://github.com/audreyr/cookiecutter-pypackage'

    example_repo_dir = find_template(example_repo)

    # Clean up repo
    shutil.rmtree(example_repo_dir)

# Generated at 2022-06-23 16:16:24.602721
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template-repo'
    )
    project_template = '{{cookiecutter.project_name}}'
    project_template = os.path.join(repo_dir, project_template)
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-23 16:16:34.287574
# Unit test for function find_template
def test_find_template():

    # Arrange
    import tempfile
    from cookiecutter.utils import rmtree
    from cookiecutter import repo

    template_name = 'example-repo'

    temp_dir = tempfile.mkdtemp()
    clone_dir = os.path.join(temp_dir, template_name)
    repo.repo_dir = clone_dir

    # Grab input repository
    url = 'https://github.com/audreyr/{}.git'.format(template_name)
    repo.clone(url, checkout=None)

    # Get the "templated" directory
    templated = find_template(clone_dir)

    # Assert it's the right one
    assert os.path.exists(templated)

    # Teardown
    rmtree(temp_dir)

# Generated at 2022-06-23 16:16:38.110969
# Unit test for function find_template
def test_find_template():
    """ Unit test for find_template function """
    directory = '/home/foo/bar'
    os.path.isabs(directory)
    # Test: Returns a valid path
    # Test: Fails if no project template is found
    raise NotImplementedError


# Generated at 2022-06-23 16:16:39.774591
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected."""
    pass

# Generated at 2022-06-23 16:16:47.070025
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    repo_dir_contents = ['incorrect', 'incorrect2', '{{cookiecutter.repo_name}}']

    for item in repo_dir_contents:
        open('/'.join([repo_dir, item]), 'a').close()

    try:
        assert(find_template(repo_dir) ==
               os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    finally:
        shutil.rmtree(repo_dir)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:16:57.801836
# Unit test for function find_template
def test_find_template():
    """Verify ability to find project template in a repo."""
    from cookiecutter import repo

    # Create a temp dir
    import tempfile
    output_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(output_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create an empty fake cookiecutter.json file in the temp dir
    open(os.path.join(repo_dir, 'cookiecutter.json'), 'a').close()

    # Create a fake project template inside the temp dir
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    # Unit test find_template

# Generated at 2022-06-23 16:17:05.821439
# Unit test for function find_template
def test_find_template():
    # Create git repo
    os.mkdir('tests/fake-repo')

    # Create cookiecutter.json
    os.mkdir('tests/fake-repo/{{cookiecutter.repo_name}}')
    f = open('tests/fake-repo/{{cookiecutter.repo_name}}/cookiecutter.json', 'w')
    f.write('{"repo_name": "test_project"}')
    f.close()

    # Run function
    project_template = find_template('tests/fake-repo/')
    assert project_template == 'tests/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:17:11.004324
# Unit test for function find_template
def test_find_template():
    repo_dir = 'test/test-repo-pre/'
    project_temp = find_template(repo_dir)
    logger.debug('The project template is %s', project_temp)
    assert project_temp == 'test/test-repo-pre/{{cookiecutter.repo_name}}', project_temp

# Generated at 2022-06-23 16:17:13.154715
# Unit test for function find_template
def test_find_template():
    assert find_template('https://github.com/audreyr/cookiecutter-pypackage')

# Generated at 2022-06-23 16:17:19.747091
# Unit test for function find_template
def test_find_template():
    def mock_listdir(path):
        return ['my_template{{cookiecutter.folder}}', 'my_readme.txt']

    original_listdir = os.listdir
    os.listdir = mock_listdir

    try:
        assert find_template('tests/fake-repo-pre') == 'tests/fake-repo-pre/my_template{{cookiecutter.folder}}'
    finally:
        os.listdir = original_listdir



# Generated at 2022-06-23 16:17:31.472176
# Unit test for function find_template
def test_find_template():
    """Assert that the correct directory is found as the template."""
    from shutil import rmtree
    from .test.test_files import TEST_REPO_DIR, TEST_TEMPLATE_DIR
    from .repository import checkout
    from .exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        TEST_REPO_DIR,
        'multiple-templates',
        '{% now "utc" %}'
    )
    checkout(repo_dir, 'master')
    try:
        template_dir = find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception(
            'A NonTemplatedInputDirException should have been raised.'
        )

    template_dir = find_template

# Generated at 2022-06-23 16:17:38.952454
# Unit test for function find_template
def test_find_template():
    """Verify the template finder."""
    import pytest

    def check_template(dir_path, expected_template_name):
        template_name = find_template(dir_path)
        assert template_name == os.path.join(dir_path, expected_template_name)

    import_path = os.path.dirname(os.path.abspath(__file__))

    check_template(os.path.join(import_path, 'test-template-repo'), 'test-template')

# Generated at 2022-06-23 16:17:45.267567
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(os.path.dirname(__file__))),
        'tests', 'fake-repo-pre-rendered'
    )
    project_template = find_template(repo_dir)

    assert 'cookiecutter-pypackage' in project_template
    assert 'master' in project_template

# Generated at 2022-06-23 16:17:57.477614
# Unit test for function find_template
def test_find_template():
    cwd = os.path.realpath(os.path.curdir)
    test_dir = os.path.join(cwd, 'tests', 'test-templates')
    repo_dir = os.path.join(test_dir, 'ba')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(test_dir, 'bb')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(test_dir, 'bc')

# Generated at 2022-06-23 16:18:03.682093
# Unit test for function find_template
def test_find_template():
    """Verify that find_template can detect a project template."""
    import tempfile
    import shutil

    tmp = tempfile.mkdtemp()

    # Create a simple template
    template_dir = os.path.join(tmp, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    pth = find_template(tmp)
    assert pth == template_dir

    # Clean up
    shutil.rmtree(tmp)

# Generated at 2022-06-23 16:18:06.844925
# Unit test for function find_template
def test_find_template():
    repo_dir = './repo-dir'
    project_template = find_template(repo_dir)
    assert project_template == './repo-dir/repo-dir'



# Generated at 2022-06-23 16:18:11.866154
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    template_name = find_template('tests/fake-repo-templated')
    assert template_name == 'tests/fake-repo-templated/{{cookiecutter.repo_name}}'


# Generated at 2022-06-23 16:18:17.216605
# Unit test for function find_template
def test_find_template():
    """ Test find_template """
    import shutil
    import tempfile

    template_name = 'fake-template'

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, template_name))

    template_dir = find_template(repo_dir)
    shutil.rmtree(repo_dir)

    assert template_dir == os.path.join(repo_dir, template_name)

# Generated at 2022-06-23 16:18:20.501515
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template() function returns the expected results."""
    os.chdir(os.path.join(os.path.dirname(__file__), '..'))
    expected_result = os.path.abspath(os.path.join('tests', 'fake-repo-pre'))
    result = find_template('tests/fake-repo-pre')
    assert result == expected_result

# Generated at 2022-06-23 16:18:27.363264
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(
        os.path.dirname(__file__),
        '..', 'tests', 'fake-repo-pre',
    )) == os.path.join(
        os.path.dirname(__file__),
        '..', 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}'
    )



# Generated at 2022-06-23 16:18:36.594043
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.prompt import read_user_yes_no
    from cookiecutter.vcs import clone
    from cookiecutter.main import cookiecutter

    # Create a fake cookiecutter formatted repository for testing purposes
    os.makedirs('fake-repo/fake-project-template')
    os.makedirs('fake-repo/non-templated-input-dir')
    shutil.copy(
        os.path.join(
            os.path.dirname(__file__),
            '..', 'tests', 'test-repo', 'cookiecutter.json'
        ),
        'fake-repo/non-templated-input-dir/cookiecutter.json'
    )

# Generated at 2022-06-23 16:18:44.398043
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""

    # Create nonexistent template directory, to test error handling
    nonexistent_template_dir = 'test/{{cookiecutter.project_name}}'

    # Create template directory
    template_dir = 'test/template'
    if not os.path.exists(template_dir):
        os.makedirs(template_dir)

    # Test for nonexistent template
    find_template(nonexistent_template_dir)
    
    # Test for template
    template_path = find_template(template_dir)
    assert template_path == 'test/template/template'
    
    # Clean up
    os.rmdir(template_dir)
    

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:18:53.581802
# Unit test for function find_template
def test_find_template():
    """
    Make sure that find_template behaves as expected.
    """
    from pprint import pformat

    test_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'files')

    for filename in os.listdir(test_dir):
        fpath = os.path.join(test_dir, filename)

# Generated at 2022-06-23 16:19:02.983771
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected."""
    try:
        from cookiecutter import utils
    except ImportError:
        import utils
    tests_dir = 'tests/files'
    repo_dir = os.path.join(tests_dir, 'test-repo')

    expected = 'tests/files/test-repo/{{cookiecutter.repo_name}}'
    template_dir = utils.find_template(repo_dir)
    assert template_dir == expected

    repo_dir = os.path.join(tests_dir, 'test-repo-non-templated')
    try:
        utils.find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert True



# Generated at 2022-06-23 16:19:06.508896
# Unit test for function find_template
def test_find_template():
    if not os.path.isdir("tests/fake-repo-pre/{{cookiecutter.repo_name}}"):
        raise ValueError("Template not found")
    return find_template("tests/fake-repo-pre")

# Generated at 2022-06-23 16:19:07.497490
# Unit test for function find_template
def test_find_template():
    # TODO: add tests for find_template
    pass

# Generated at 2022-06-23 16:19:14.069440
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'test-template')
    project_template = find_template(repo_dir)
    expected_template = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    assert project_template == expected_template

# Generated at 2022-06-23 16:19:17.965754
# Unit test for function find_template
def test_find_template():
    sample_repo = 'tests/test-repo'
    sample_template = 'tests/test-repo/{{cookiecutter.repo_name}}'

    found_template = find_template(sample_repo)
    assert found_template == sample_template

# Generated at 2022-06-23 16:19:23.003770
# Unit test for function find_template
def test_find_template():
    """Simple unit test for function find_template."""
    template_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'cookiecutters',
        'cookiecutter-pypackage')

    project_template = find_template(template_dir)

    assert project_template == os.path.join(template_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:19:33.321261
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function from search.py
    """
    from os import sep
    from tempfile import mkdtemp
    from shutil import rmtree
    
    from pytest import raises
    
    try:
        # Create a temporary directory
        tmp_dir = mkdtemp()

        # Create a temporary directory
        now_dir = os.path.join(tmp_dir, '{{ cookiecutter.project_name }}')
        os.mkdir(now_dir)

        # Call function to be tested
        result = find_template(tmp_dir)

        # Check expected result
        assert result == now_dir
    finally:
        # Remove the directory after the test
        rmtree(tmp_dir)

# Generated at 2022-06-23 16:19:42.018725
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(
        os.path.dirname(__file__), '../tests/fake-repo-tmpl/'
    )) == os.path.join(os.path.dirname(__file__), '../tests/fake-repo-tmpl/{{cookiecutter.repo_name}}/')

    try:
        find_template(os.path.join(
            os.path.dirname(__file__), '../tests/fake-repo-pre/'
        ))
    except NonTemplatedInputDirException as e:
        assert type(e) == NonTemplatedInputDirException

# Generated at 2022-06-23 16:19:52.712682
# Unit test for function find_template
def test_find_template():
    """Check that find_template returns the non-templated project template."""
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import join

    template_dir = '{{cookiecutter.repo_name}}'
    result_template_dir = 'project_name'

    repo_dir = mkdtemp()
    template_dir_path = join(repo_dir, template_dir)
    os.mkdir(template_dir_path)
    project_template = find_template(repo_dir)
    assert project_template == join(repo_dir, result_template_dir)

    rmtree(repo_dir)

# Generated at 2022-06-23 16:19:54.846571
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo/'
    result = find_template(repo_dir)
    assert isinstance(result, str)

# Generated at 2022-06-23 16:19:59.193400
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(
        repo_dir,
        'fake-repo/{{cookiecutter.project_name}}'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-23 16:20:05.360134
# Unit test for function find_template
def test_find_template():
    """Verify proper template path is returned when given valid input."""
    repo_dir = 'tests/fake-repo'
    project_template_full_path = 'tests/fake-repo/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template_full_path

# Generated at 2022-06-23 16:20:08.484345
# Unit test for function find_template
def test_find_template():
    """
    Test that function find template returns the directory name
    if the directory name is templated
    else raises NonTemplatedInputDirException
    """
    repo_dir = "test"
    assert find_template(repo_dir)

# Generated at 2022-06-23 16:20:14.165938
# Unit test for function find_template
def test_find_template():
    """
    Unit test of find_template function.
    """
    logger.debug('Testing find_template function.')
    subdir = os.path.join(
        os.path.realpath(os.path.dirname(__file__)),
        'tests/test-repo-pre.no-input-git/'
    )
    project_template = find_template(subdir)
    result = False
    if project_template == os.path.join(subdir, 'cookiecutter-foobar{{cookiecutter.slug}}/'):
        result = True
    assert result

# Generated at 2022-06-23 16:20:19.688175
# Unit test for function find_template
def test_find_template():
    """Test whether find_template can detect the project template."""
    import cookiecutter.main
    cookiecutter.main.cookiecutter('tests/fake-repo-tmpl/')

    expected_output = 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-tmpl/') == expected_output

    import shutil
    shutil.rmtree('tests/fake-repo-tmpl/')

# Generated at 2022-06-23 16:20:23.696815
# Unit test for function find_template
def test_find_template():
    repo_dir = '~/.cookiecutters/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == os.path.expanduser('~/.cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-23 16:20:34.263878
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import glob
    import os.path

    logger = logging.getLogger(
        'cookiecutter.utilities.tests.test_find_template'
    )
    logger.debug('Creating temp directory')
    # Creating a temp directory
    tmp_dir = tempfile.mkdtemp()

    # Creating the necessary file structure
    logger.debug('Creating required file structure')
    repo_dir = os.path.join(tmp_dir, 'repo_dir')
    os.makedirs(repo_dir)
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'random_dir'))


# Generated at 2022-06-23 16:20:44.095359
# Unit test for function find_template
def test_find_template():
    """Verify function for finding Cookiecutter template."""
    from cookiecutter import utils

    # Setup
    repo_dir = utils.find_repo(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        no_input=True
    )
    expected_project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

    # Run function under test
    project_template = find_template(repo_dir)

    # Verify the result
    assert project_template == expected_project_template



# Generated at 2022-06-23 16:20:47.084995
# Unit test for function find_template
def test_find_template():
    assert find_template('non_templated_input_dir') == 'non_templated_input_dir\cookiecutter-non-templated-input-dir'

# Generated at 2022-06-23 16:20:53.474681
# Unit test for function find_template
def test_find_template():
    def _mock_directory_contents():
        for item in repo_dir_contents:
            yield item

    repo_dir_contents = [
        'foo',
        'foobar',
        'foobarbaz',
        '{{cookiecutter.repo_dir_name}}',
        'foobarbazqux',
    ]

    old_listdir = os.listdir

    try:
        os.listdir = _mock_directory_contents
        assert find_template('/home/vagrant/repo') == (
            '/home/vagrant/repo/{{cookiecutter.repo_dir_name}}'
        )
    finally:
        os.listdir = old_listdir

# Generated at 2022-06-23 16:21:00.878173
# Unit test for function find_template
def test_find_template():
    from cookiecutter import repo
    from cookiecutter import utils
    from cookiecutter.utils import rmtree
    from cookiecutter import config

    empty_dir = utils.make_empty_dir()
    repo_dir = repo.clone(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        empty_dir,
        no_input=True,
        checkout='0.4.2',
        quiet=True
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    rmtree(empty_dir)

# Generated at 2022-06-23 16:21:03.532505
# Unit test for function find_template
def test_find_template():
    template_under_test = find_template('sample')
    assert(template_under_test == 'sample/{{cookiecutter.repo_name}}')


# Generated at 2022-06-23 16:21:11.324614
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the name of the templated directory.
    """
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

    try:
        os.makedirs(os.path.join(temp_dir, '{{cookiecutter.repo_name}}'))
        os.makedirs(os.path.join(temp_dir, 'not_the_repo'))

        ret = find_template(temp_dir)
        assert ret == os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-23 16:21:14.261279
# Unit test for function find_template
def test_find_template():
    # Test when the template is the only thing in the cookiecutter_template dir
    find_template('/foo/bar/baz')
    # Test when the template is one of many things in the cookiecutter_template dir
    find_template('/foo/bar/baz')

# Generated at 2022-06-23 16:21:22.743551
# Unit test for function find_template
def test_find_template():
    """ Test find template function """
    # Pass a templated directory
    repo_dir = "tests/test-repo-pre"
    result = find_template(repo_dir)
    assert (result == repo_dir)

    # Pass a non-templated directory
    repo_dir = "tests/test-repo-pre-non-templated"
    result = find_template(repo_dir)
    assert (result == None)



# Generated at 2022-06-23 16:21:29.003091
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function."""
    repo_dir = '/home/audreyr/cookiecutters/cookiecutter-pypackage-minimal'
    project_template = find_template(repo_dir)
    assert (
        project_template ==
        '/home/audreyr/cookiecutters/cookiecutter-pypackage-minimal/{{cookiecutter.repo_name}}'
    )



# Generated at 2022-06-23 16:21:34.538693
# Unit test for function find_template
def test_find_template():
    repo_dir = '/usr/local/lib/python2.7/dist-packages/cookiecutter/tests/test-find-template'
    project_template = find_template(repo_dir)
    assert project_template == '/usr/local/lib/python2.7/dist-packages/cookiecutter/tests/test-find-template/{% cookiecutter.project_name %}'

# Generated at 2022-06-23 16:21:35.988155
# Unit test for function find_template
def test_find_template():
    """Verify that `find_template` finds a template in a repo."""
    find_template()

# Generated at 2022-06-23 16:21:38.537640
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter/tests/test-repo') == \
        'cookiecutter/tests/test-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:21:41.357836
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.getcwd(), 'tests/files/fake-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-23 16:21:46.384394
# Unit test for function find_template
def test_find_template():
    dir_curr = '/Users/richard/repo-cookie/cookiecutter/test_find_template'
    dir_test = find_template(dir_curr)
    dir_true = os.path.join(dir_curr, '{{cookiecutter.repo_name}}')
    assert dir_test == dir_true



# Generated at 2022-06-23 16:21:54.395489
# Unit test for function find_template
def test_find_template():
    """Test find_template function from cookiecutter.utils.find."""
    from .exceptions import NonTemplatedInputDirException
    from .compat import TemporaryDirectory
    from .main import cookiecutter

    with TemporaryDirectory() as template:
        cookiecutter(
            # The repo to clone
            'https://github.com/audreyr/cookiecutter-pypackage.git',
            # The directory name to clone it into
            no_input=True,
            overwrite_if_exists=True,
            output_dir=template,
        )
        template_path = os.path.join(template, 'cookiecutter-pypackage')
        # Test with good template, should return 'cookiecutter-pypackage'
        assert find_template(template_path)


# Generated at 2022-06-23 16:21:57.346063
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/brian/projects/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    print(project_template)

test_find_template()

# Generated at 2022-06-23 16:22:01.165096
# Unit test for function find_template
def test_find_template():
    repo_dir = 'test_repo'
    expected = 'test_repo/{{cookiecutter.repo_name}}'
    actual = find_template(repo_dir)
    assert expected == actual

# Generated at 2022-06-23 16:22:06.341047
# Unit test for function find_template
def test_find_template():
    test_path = os.path.abspath('tests/test-data/{{cookiecutter.repo_name}}')
    test_repo_dir = os.path.split(test_path)[0]
    expected_result = os.path.join(test_repo_dir,
                                   '{{cookiecutter.repo_name}}')
    assert find_template(test_repo_dir) == expected_result

# Generated at 2022-06-23 16:22:15.342129
# Unit test for function find_template
def test_find_template():
    """Test that the function find_template is working."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(utils.root_dir(), 'tests', 'fake-repo-pre')
    template = find_template(repo_dir)

    assert template == os.path.join(repo_dir, 'cookiecutter-pypackage')

    repo_dir = os.path.join(utils.root_dir(), 'tests', 'fake-repo-pre-1')
    template = find_template(repo_dir)

    assert template == os.path.join(repo_dir, 'test-cookiecutter')


# Generated at 2022-06-23 16:22:22.025952
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template()."""
    import tempfile

    # Make a temporary directory
    tmp_dir = tempfile.mkdtemp()

    template_names = set(['cookiecutter-pypackage', 'cookiecutter.json'])
    for name in template_names:
        dir_path = os.path.join(tmp_dir, name)
        os.mkdir(dir_path)

    assert find_template(tmp_dir) == os.path.join(tmp_dir, 'cookiecutter-pypackage')