

# Generated at 2022-06-17 17:11:29.156111
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:34.331232
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:11:40.087244
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:43.486817
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake project
    project_dir = cookiecutter('tests/fake-repo-tmpl')

    # Test find_template
    assert find_template(project_dir) == os.path.join(project_dir, 'fake-project')

# Generated at 2022-06-17 17:11:51.684758
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    logger.debug('Testing find_template function.')

    temp_dir = tempfile.mkdtemp()
    try:
        repo_dir = os.path.join(temp_dir, 'fake-repo')
        os.mkdir(repo_dir)

        project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
        os.mkdir(project_template)

        assert find_template(repo_dir) == project_template
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:12:03.352773
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(sub_dir)

    # Create a file inside the subdirectory
    file_path = os.path.join(sub_dir, 'README.rst')
    open(file_path, 'a').close()

    # Create a subdirectory inside the subdirectory
    subsub_dir = os.path.join(sub_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(subsub_dir)

    # Create a file inside the subdirectory


# Generated at 2022-06-17 17:12:13.445494
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:12:17.796611
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:27.257265
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake repo in the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a fake project template in the fake repo
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    # Test the find_template function
    assert utils.find_template(repo_dir) == project_template

    # Remove the temporary directory

# Generated at 2022-06-17 17:12:35.316793
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:44.710990
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:51.570625
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:57.656815
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:03.537192
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:08.429863
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:13.361025
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:21.623926
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:13:31.172668
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Create a fake project
    cookiecutter('tests/fake-repo-tmpl', no_input=True)

    # Find the template in the fake project
    repo_dir = 'fake-repo-tmpl'
    project_template = find_template(repo_dir)

    # Make sure it's the right one
    assert project_template == os.path.abspath('fake-repo-tmpl/{{cookiecutter.repo_name}}')

    # Clean up the fake project
    utils.rmtree(repo_dir)

# Generated at 2022-06-17 17:13:34.380679
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct path to the project template."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:41.840392
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:53.539126
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()

    try:
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}'))

        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}')
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:13:58.423971
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-cookiecutters',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:05.713027
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:14:10.708872
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:14.305942
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:24.267548
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:14:31.392352
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:42.491500
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    with open(os.path.join(sub_dir, 'file.txt'), 'w') as f:
        f.write('Hello world!')

    # Verify find_template returns the correct directory
    assert find_template(temp_dir) == sub_dir

    # Remove the temporary directory after the test
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:14:49.962388
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:14:56.629722
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:04.484796
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:13.342921
# Unit test for function find_template
def test_find_template():
    """
    Test find_template() function.
    """
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    # Create a temporary git repo
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'fake-repo-tmpl')
    repo_dir = main.cookiecutter(
        repo_dir, no_input=True, output_dir='.', overwrite_if_exists=True
    )

    # Test that the template is found
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, 'fake-project-tmpl')

    # Clean up
    rmtree(repo_dir)

# Generated at 2022-06-17 17:15:16.595673
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:23.328968
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'fake-repo-pre-rendered',
    )
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:15:28.025565
# Unit test for function find_template
def test_find_template():
    """Verify that the function find_template works as expected."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:15:35.583942
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))


# Generated at 2022-06-17 17:15:39.745856
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert '{{cookiecutter.repo_name}}' in project_template
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:15:49.546982
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Create a temporary project
    project_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Find the project template
    project_template = find_template(project_dir)

    # Check that the project template is correct
    assert project_template == os.path.join(project_dir, 'fake-project')

    # Clean up
    utils.rmtree(project_dir)

# Generated at 2022-06-17 17:15:56.439064
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests/test-find-template/fake-repo'
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        'fake-repo-{{cookiecutter.repo_name}}'
    )

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests/test-find-template/fake-repo-no-templated-dir'
    )


# Generated at 2022-06-17 17:16:03.727499
# Unit test for function find_template
def test_find_template():
    """Verify that the function `find_template` works as expected."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a directory with no templates
    no_templates_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'files',
            'no-templates'
        )
    )
    try:
        utils.find_template(no_templates_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('find_template should have raised a '
                        'NonTemplatedInputDirException')

    # Test a directory with a single template

# Generated at 2022-06-17 17:16:08.189671
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path to the template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:11.516189
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:22.514620
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a sub-directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file in the sub-directory
    fh = open(os.path.join(sub_dir, 'file.txt'), 'w')
    fh.write('some data')
    fh.close()

    # Create another sub-directory
    sub_dir2 = os.path.join(temp_dir, 'cookiecutter-foobar')
    os.mkdir(sub_dir2)

    # Create a file in

# Generated at 2022-06-17 17:16:32.429711
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a directory with no templates
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-pre/',
    )
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('find_template did not raise exception')

    # Test a directory with a template

# Generated at 2022-06-17 17:16:41.179058
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    # Create a project from a fixture and run find_template on it
    cookiecutter('tests/test-find-template/', no_input=True)
    project_template = find_template('boilerplate-repo')

    # Clean up the generated project
    rmtree('boilerplate-repo')

    # Assert that the project template was found
    assert project_template == 'boilerplate-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:16:49.584850
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:56.559915
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(temp_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    # Test the function
    utils.find_template(temp_dir)

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:17:06.971067
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:17:13.713483
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:23.399334
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'fake-repo',
    )
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-17 17:17:31.130213
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:37.253752
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:41.246793
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo'
    ))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:49.600379
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:54.998709
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    temp_sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(temp_sub_dir)

    # Create a file inside the subdirectory
    temp_sub_dir_file = os.path.join(temp_sub_dir, 'file.txt')
    with open(temp_sub_dir_file, 'w') as f:
        f.write('Hello, world!')

    # Create a subdirectory inside the subdirectory

# Generated at 2022-06-17 17:18:05.143597
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:11.579533
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:18.279415
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:24.250509
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:18:32.562141
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmp_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(tmp_dir, 'cookiecutter-baz'))
    os.makedirs(os.path.join(tmp_dir, 'cookiecutter-qux'))
    os.makedirs(os.path.join(tmp_dir, 'cookiecutter-quux'))
    os.makedirs(os.path.join(tmp_dir, 'cookiecutter-corge'))


# Generated at 2022-06-17 17:18:46.652427
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)

    assert find_template(repo_dir) == template_dir

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:18:54.243162
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import shutil
    import tempfile

    from cookiecutter import utils

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake repo
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a fake project template
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    # Test the find_template function
    assert find_template(repo_dir) == project_template

    # Remove the temporary directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:19:04.205522
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'not_the_template'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:19:09.925937
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:16.502602
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the expected directory."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a fake repo
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    utils.make_sure_path_exists(repo_dir)

    # Create a fake project template
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    utils.make_sure_path_exists(project_template)

    # Test find_template()
    assert find_template(repo_dir) == project_template

    # Test find_template() when no project template is found

# Generated at 2022-06-17 17:19:22.270512
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:30.873024
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected."""
    import tempfile
    import shutil
    import os
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temp directory to work in
    temp_dir = tempfile.mkdtemp()

    # Create a test directory structure
    os.makedirs(os.path.join(temp_dir, 'test_dir'))
    os.makedirs(os.path.join(temp_dir, 'test_dir', 'test_subdir'))
    os.makedirs(os.path.join(temp_dir, 'test_dir', 'test_subdir', 'test_subsubdir'))

    # Create a test file

# Generated at 2022-06-17 17:19:32.437113
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-17 17:19:39.215581
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo'))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:47.029961
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:01.579879
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import project_dir
    project_template = find_template(project_dir)
    assert project_template == os.path.join(project_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:07.437051
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    # Test a valid template
    template = utils.find_template(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'fake-repo-pre',
            '{{cookiecutter.repo_name}}'
        )
    )
    assert template == os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre',
        '{{cookiecutter.repo_name}}'
    )

    # Test an invalid template

# Generated at 2022-06-17 17:20:11.418008
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:17.500852
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:23.213968
# Unit test for function find_template
def test_find_template():
    """Test that the function finds the template directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:29.041962
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    repo_dir = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    repo_dir_2 = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    repo_dir_3 = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    repo_dir_4 = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    repo_dir_5 = tempfile.mkdtemp()

    # Create a temporary directory to clone into
    repo_dir_6 = tempfile

# Generated at 2022-06-17 17:20:37.683930
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:20:48.089015
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:57.972599
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a directory with no templates
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests/test-find-template/no-templates'
    )
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError('NonTemplatedInputDirException not raised')

    # Test a directory with a single template
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests/test-find-template/single-template'
    )


# Generated at 2022-06-17 17:21:04.638972
# Unit test for function find_template
def test_find_template():
    """Test that find_template finds the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')