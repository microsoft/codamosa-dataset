

# Generated at 2022-06-17 17:11:35.542541
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template directory."""
    from cookiecutter import utils
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        utils.make_sure_path_exists(os.path.join(tmpdir, 'cookiecutter-foobar'))
        utils.make_sure_path_exists(os.path.join(tmpdir, 'cookiecutter-baz'))
        utils.make_sure_path_exists(os.path.join(tmpdir, 'cookiecutter-qux'))
        utils.make_sure_path_exists(os.path.join(tmpdir, 'cookiecutter-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:11:41.405845
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:11:51.952631
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test with a non-templated directory
    repo_dir = utils.find_repo_dir(
        os.path.abspath(os.path.dirname(__file__))
    )
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('Should have raised NonTemplatedInputDirException')

    # Test with a templated directory

# Generated at 2022-06-17 17:11:59.313957
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:05.806642
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:12:10.244064
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:18.393073
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct template directory."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    template_dir = utils.find_template(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'tests/test-find-template'
        )
    )
    assert template_dir == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/test-find-template/{{cookiecutter.repo_name}}'
    )


# Generated at 2022-06-17 17:12:27.614702
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake repo dir
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a fake project template
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    # Test the find_template function
    assert utils.find_template(repo_dir) == project_template

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:12:32.787245
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works as expected."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.utils import rmtree

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        rmtree(repo_dir)

# Generated at 2022-06-17 17:12:36.641093
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:50.823971
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct directory."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project_template = find_

# Generated at 2022-06-17 17:12:59.941940
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-master'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}-master'))

# Generated at 2022-06-17 17:13:08.053824
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = cookiecutter('tests/fake-repo-tmpl/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

    # Test for exception
    repo_dir = cookiecutter('tests/fake-repo-no-tmpl/')
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'NonTemplatedInputDirException not raised'

    # Clean up
    utils.rmt

# Generated at 2022-06-17 17:13:13.913967
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:13:20.736582
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:31.498976
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:13:34.630896
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo('tests/test-find-template')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:42.444498
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:51.495486
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter import utils
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake project template
    project_template = os.path.join(temp_dir, 'fake-project-template')
    os.mkdir(project_template)

    # Create a fake file in the project template
    fake_file = os.path.join(project_template, 'fake-file.txt')
    with open(fake_file, 'w') as f:
        f.write('Hello world!')

    # Create a fake non-project template
    non_project_template = os.path.join(temp_dir, 'fake-non-project-template')

# Generated at 2022-06-17 17:13:57.101120
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:09.776549
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'))

# Generated at 2022-06-17 17:14:15.733695
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}-{{cookiecutter.project_name}}'))

# Generated at 2022-06-17 17:14:25.095329
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import (
        TEST_TEMPLATE_DIR,
        TEST_TEMPLATE_DIR_NON_TEMPLATED,
    )

    # Test finding a template
    assert find_template(TEST_TEMPLATE_DIR) == os.path.join(
        TEST_TEMPLATE_DIR,
        '{{cookiecutter.repo_name}}'
    )

    # Test not finding a template
    try:
        find_template(TEST_TEMPLATE_DIR_NON_TEMPLATED)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError('Should have raised a NonTemplatedInputDirException')

# Generated at 2022-06-17 17:14:32.553363
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-repo')

# Generated at 2022-06-17 17:14:37.833154
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:47.162266
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:54.815713
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:00.556954
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:06.283386
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:12.136801
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:15:17.512958
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:24.593358
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:32.388183
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_empty_dir
    from cookiecutter.tests.test_find import make_empty_file
    from cookiecutter.tests.test_find import remove_dir

    repo_dir = make_empty_dir('repo_dir')
    make_empty_file(os.path.join(repo_dir, 'cookiecutter.json'))
    make_empty_file(os.path.join(repo_dir, 'cookiecutter.yaml'))
    make_empty_file(os.path.join(repo_dir, 'cookiecutter.yml'))
    make_empty_file(os.path.join(repo_dir, 'cookiecutter.txt'))

# Generated at 2022-06-17 17:15:38.059290
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:48.825917
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:15:52.979372
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:16:00.062810
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:10.921081
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    import shutil
    import tempfile
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    fh = open(os.path.join(sub_dir, 'README.rst'), 'w')
    fh.write('README')
    fh.close()

    # Create a file inside the temporary directory
    fh = open(os.path.join(temp_dir, 'README.rst'), 'w')
    fh.write('README')
    fh

# Generated at 2022-06-17 17:16:12.089757
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    # TODO: write unit test
    pass

# Generated at 2022-06-17 17:16:21.727248
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:16:30.120002
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the correct template."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:35.941302
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))
    os.makedirs(os.path.join(repo_dir, 'foobar', '{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:16:44.974367
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test when template is found
    template = utils.find_template('tests/fake-repo-pre/')
    assert template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    # Test when template is not found
    try:
        utils.find_template('tests/fake-repo-no-templated-dir/')
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError('NonTemplatedInputDirException not raised')

# Generated at 2022-06-17 17:16:51.037418
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:56.728813
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()

    # Create a fake project template
    os.makedirs(os.path.join(repo_dir, 'fake_project_template'))

    # Create a fake non-template
    os.makedirs(os.path.join(repo_dir, 'fake_non_template'))

    # Create a fake template
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmt

# Generated at 2022-06-17 17:17:03.959674
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct template."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:14.263235
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-find-template'
    )

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

    # Test that NonTemplatedInputDirException is raised when there is no
    # templated directory.

# Generated at 2022-06-17 17:17:21.151902
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the expected directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:32.091546
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import os
    import shutil
    import tempfile

    from cookiecutter.exceptions import NonTemplatedInputDirException

    def _create_test_dir(tmpdir):
        """Create a test directory with a template."""
        test_dir = os.path.join(tmpdir, 'test_dir')
        os.mkdir(test_dir)

        template_dir = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
        os.mkdir(template_dir)

        return test_dir

    tmpdir = tempfile.mkdtemp()
    test_dir = _create_test_dir(tmpdir)


# Generated at 2022-06-17 17:17:37.329601
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:52.715289
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    from cookiecutter import utils
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a dummy project template
    project_template = os.path.join(temp_dir, '{{cookiecutter.project_name}}')
    os.makedirs(project_template)

    # Create a dummy file
    dummy_file = os.path.join(temp_dir, 'dummy_file')
    with open(dummy_file, 'w') as f:
        f.write('This is a dummy file.')

    # Create a dummy directory
    dummy_dir = os.path.join(temp_dir, 'dummy_dir')

# Generated at 2022-06-17 17:17:58.220480
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:18:04.825581
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-tmpl'
    ))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre'
    ))
    project_template = ut

# Generated at 2022-06-17 17:18:15.635668
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a directory with a template
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre',
        '{{cookiecutter.repo_name}}'
    ))
    project_template = utils.find_template(repo_dir)

# Generated at 2022-06-17 17:18:20.614599
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:30.566512
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil
    import os

    template_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(template_dir, 'my_template'))
    os.mkdir(os.path.join(template_dir, 'my_template', '{{cookiecutter.project_name}}'))
    os.mkdir(os.path.join(template_dir, 'my_template', '{{cookiecutter.project_name}}', '{{cookiecutter.project_slug}}'))

# Generated at 2022-06-17 17:18:35.180829
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:41.816175
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'not_the_template'))

    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:18:49.729025
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    from cookiecutter import utils
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:54.602792
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    assert find_template(repo_dir) == os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.project_name}}'
    )

# Generated at 2022-06-17 17:19:13.383617
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test with a non-templated input directory
    non_templated_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    )
    try:
        utils.find_template(non_templated_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException not raised')

    # Test with a templated input directory

# Generated at 2022-06-17 17:19:20.569556
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:23.574453
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:19:27.796245
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:30.470156
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:19:40.825267
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'my_repo'))
    os.makedirs(os.path.join(repo_dir, 'my_repo2'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:19:53.342871
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    import shutil
    import tempfile

    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:20:00.460903
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(sub_dir)

    # Create a file inside the subdirectory
    file_path = os.path.join(sub_dir, 'README.rst')
    with open(file_path, 'w') as f:
        f.write('This is a test file.')

    # Call the function we're testing
    result = find_template(temp_dir)

    # Verify that the result is correct
    assert result == sub_dir

    # Clean up


# Generated at 2022-06-17 17:20:10.441035
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from cookiecutter import __version__

    repo_dir = 'tests/test-find-template/'
    output_dir = 'tests/test-find-template-output/'
    rmtree(output_dir)

    cookiecutter(
        repo_dir,
        no_input=True,
        output_dir=output_dir,
        extra_context={'full_name': 'Test McTesty'},
        overwrite_if_exists=True,
        config_file='tests/test-find-template/cookiecutter.yaml',
        default_config=True
    )

    assert os.path.exists(output_dir)
    assert os.path.ex

# Generated at 2022-06-17 17:20:17.696355
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:33.750417
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:20:38.792982
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the expected value."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}',
    )
    assert project_template == expected_project_template

# Generated at 2022-06-17 17:20:50.770820
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter

    # Create a temporary directory to work in
    temp_dir = tempfile.mkdtemp()

    # Create a temporary cookiecutter template
    temp_template = os.path.join(temp_dir, 'my-fake-template')
    cookiecutter(
        'tests/fake-repo-pre/',
        no_input=True,
        output_dir=temp_dir,
        extra_context={
            'project_name': 'My Fake Project',
            'repo_name': 'my-fake-template',
        },
    )

    # Check that the template is found

# Generated at 2022-06-17 17:20:57.501230
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    ))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:02.860258
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:11.751614
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    try:
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
        os.mkdir(os.path.join(repo_dir, 'foobar'))

        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:21:18.902239
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre',
    ))

    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-post',
    ))

    project_

# Generated at 2022-06-17 17:21:25.960850
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-find-template'
    )

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')