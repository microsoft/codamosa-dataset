

# Generated at 2022-06-17 17:11:28.652963
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-17 17:11:39.033669
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:11:51.109042
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project

# Generated at 2022-06-17 17:12:02.406085
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:12.662173
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo',
    )

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test exception
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-no-templated-dir',
    )


# Generated at 2022-06-17 17:12:20.186442
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:24.871060
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:12:31.565026
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:32.962501
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    # TODO: Write unit test for function find_template
    pass

# Generated at 2022-06-17 17:12:37.444502
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:47.350367
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:54.333565
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-post',
    )
    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:13:03.604215
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    import os
    import shutil
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:13:08.435621
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:14.153330
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    import os
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a fake repo
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-tmpl')
    utils.make_sure_path_exists(repo_dir)

    # Test a repo with a templated directory
    project_dir = find_template(repo_dir)
    assert project_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test a repo without a templated directory

# Generated at 2022-06-17 17:13:19.454287
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works properly."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    file_path = os.path.join(sub_dir, 'README.rst')
    with open(file_path, 'w') as f:
        f.write('TEST')

    # Test the function
    assert find_template(temp_dir) == sub_dir

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:13:25.374755
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:13:34.402533
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage-master'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.version}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.version}}-master'))

# Generated at 2022-06-17 17:13:42.149854
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:51.066596
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:13:58.204890
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the expected value."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:03.199184
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a fake repo
    repo_dir = utils.make_empty_dir()
    utils.make_empty_dir(os.path.join(repo_dir, 'my_fake_repo'))
    utils.make_empty_dir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    # Test that find_template returns the correct directory
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test that find_template raises NonTemplatedInputDirException if no template is found
   

# Generated at 2022-06-17 17:14:09.044451
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )

    project_template = find_template(repo_dir)

    assert 'fake-repo' in project_template
    assert '{{cookiecutter.repo_name}}' in project_template

# Generated at 2022-06-17 17:14:15.695808
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.dirname(utils.__file__))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.dirname(__file__))
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError('NonTemplatedInputDirException not raised')

# Generated at 2022-06-17 17:14:25.398337
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:14:33.038134
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:38.512920
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:45.921362
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a fake project
    cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Test that the template is found
    repo_dir = 'fake-project'
    project_template = find_template(repo_dir)
    assert project_template == 'fake-project/{{cookiecutter.repo_name}}'

    # Test that the function raises an exception when the template is not found
    utils.rmtree(repo_dir)
    cookiecutter('tests/fake-repo-no-tmpl/', no_input=True)

# Generated at 2022-06-17 17:14:50.614718
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:01.385295
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-pre',
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-post',
    )

    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:15:10.044182
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:15:15.222476
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:19.639497
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:28.539002
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'fake-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'fake-repo-post',
    )
    project_template = find_template(repo_dir)
    assert project

# Generated at 2022-06-17 17:15:32.566098
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    assert find_template('tests/test-find-template') == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:15:38.398486
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:47.483819
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:51.535537
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:15:55.286301
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:00.594184
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
        os.makedirs(os.path.join(repo_dir, 'foo'))
        os.makedirs(os.path.join(repo_dir, 'bar'))
        os.makedirs(os.path.join(repo_dir, 'baz'))

        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        shutil.rmt

# Generated at 2022-06-17 17:16:12.207499
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:18.612427
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:23.847445
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:26.076548
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:31.582107
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:41.109682
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test with a non-templated directory
    try:
        utils.find_template('tests/fake-repo-pre/')
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('find_template should have raised a NonTemplatedInputDirException')

    # Test with a templated directory
    assert utils.find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:16:50.180580
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:53.981973
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:00.949230
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:17:06.921709
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:26.767600
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:32.547622
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:37.706931
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:17:47.717392
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:17:57.720098
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:00.446473
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:08.539488
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo
    from cookiecutter.tests.test_utils import TEST_COOKIE_PROJECT_DIR

    repo_dir = make_repo(TEST_COOKIE_PROJECT_DIR)
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:18:15.258308
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:18.235748
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:18:24.565714
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a directory with no templates
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-find-template/no-templates'
    )
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException not raised')

    # Test a directory with a single template

# Generated at 2022-06-17 17:18:54.479086
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:03.411569
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:06.474208
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:15.097280
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct template."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-pre/',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-post/',
    )

# Generated at 2022-06-17 17:19:24.295137
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    # Test a repo with a templated directory
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..', 'tests', 'test-repo-pre', '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test a repo without a templated directory

# Generated at 2022-06-17 17:19:31.721172
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-17 17:19:42.935837
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    from cookiecutter import utils

    repo_dir = tempfile.mkdtemp()
    utils.make_sure_path_exists(repo_dir)

    # Create a fake project template
    project_template = os.path.join(repo_dir, 'fake_project_template')
    utils.make_sure_path_exists(project_template)

    # Create a fake file
    fake_file = os.path.join(repo_dir, 'fake_file')
    utils.make_sure_path_exists(fake_file)

    # Create a fake directory
    fake_dir = os.path.join(repo_dir, 'fake_dir')

# Generated at 2022-06-17 17:19:54.006361
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-post',
    )
    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:20:01.165646
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:07.843231
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:18.551535
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:21:25.915327
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')