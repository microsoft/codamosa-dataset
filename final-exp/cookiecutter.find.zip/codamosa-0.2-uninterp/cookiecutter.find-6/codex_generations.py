

# Generated at 2022-06-17 17:11:33.136140
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    from cookiecutter.tests.test_find import (
        TEST_TEMPLATE_DIR,
        TEST_TEMPLATE_DIR_NON_TEMPLATED
    )

    assert find_template(TEST_TEMPLATE_DIR) == os.path.join(
        TEST_TEMPLATE_DIR,
        '{{cookiecutter.repo_name}}'
    )
    assert find_template(TEST_TEMPLATE_DIR_NON_TEMPLATED) == os.path.join(
        TEST_TEMPLATE_DIR_NON_TEMPLATED,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:11:42.691524
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    import os
    import shutil
    import tempfile

    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake repo directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a fake project template
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    # Test that the function returns the correct path
    assert find_template(repo_dir) == project_template

    # Test that the function raises an exception if no template is found

# Generated at 2022-06-17 17:11:53.010061
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:12:04.738137
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a sub-directory
    sub_dir = os.path.join(temp_dir, 'foobar')
    os.mkdir(sub_dir)
    # Create a file
    open(os.path.join(temp_dir, 'test.txt'), 'w').close()
    # Create a file in the sub-directory
    open(os.path.join(sub_dir, 'test.txt'), 'w').close()

    # Verify that find_template returns the correct directory
    assert find_template(temp_dir) == sub_dir

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:12:10.362485
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:12:16.116214
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-template')

# Generated at 2022-06-17 17:12:21.913389
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:26.702992
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:32.352737
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:12:37.622853
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Create a temporary repo
    repo_dir = cookiecutter('tests/test-repo-pre/', no_input=True)

    # Find the template in the repo
    project_template = find_template(repo_dir)

    # Check that the template is the one we expect
    expected_template = os.path.join(repo_dir, 'cookiecutter-pypackage')
    assert project_template == expected_template

    # Clean up the temporary repo
    utils.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:47.577520
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(sub_dir)

    # Create a file inside the subdirectory
    fh = open(os.path.join(sub_dir, 'README.rst'), 'w')
    fh.close()

    # Create a file inside the temporary directory
    fh = open(os.path.join(temp_dir, 'README.rst'), 'w')
    fh.close()

    # Create a file inside the temporary directory

# Generated at 2022-06-17 17:12:52.391020
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:00.692333
# Unit test for function find_template
def test_find_template():
    """Test function for find_template"""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:13:07.246171
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:13:15.017201
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:13:23.124966
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a sub-directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file in the sub-directory
    fh = open(os.path.join(sub_dir, 'file.txt'), 'w')
    fh.write('This is a test file')
    fh.close()

    # Create a file in the top-level directory
    fh = open(os.path.join(temp_dir, 'file2.txt'), 'w')

# Generated at 2022-06-17 17:13:33.685802
# Unit test for function find_template
def test_find_template():
    """Test function for find_template"""
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    fh = open(os.path.join(sub_dir, 'test.txt'), 'w')
    fh.write('test')
    fh.close()

    # Change the current working directory to the temporary directory
    # This is required because the function find_template uses the current
    # working directory to find the template
    cwd = os.getcwd()
    os.chdir

# Generated at 2022-06-17 17:13:44.710165
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:13:51.931799
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-repo')

# Generated at 2022-06-17 17:13:56.705061
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    from cookiecutter.tests.test_find import make_repo
    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:01.168833
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:14:08.579127
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:14:13.001855
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:22.211341
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(sub_dir)

    # Create a file inside the subdirectory
    open(os.path.join(sub_dir, 'file.txt'), 'w').close()

    # Verify that find_template() returns the correct directory
    assert find_template(temp_dir) == sub_dir

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:14:32.516993
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

    # Create a fake repo_dir
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-foobar')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:14:42.595919
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a valid template
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test an invalid template
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
   

# Generated at 2022-06-17 17:14:43.599204
# Unit test for function find_template
def test_find_template():
    """Test that the function find_template works as expected."""
    pass

# Generated at 2022-06-17 17:14:54.447727
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(os.path.dirname(utils.__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(os.path.dirname(utils.__file__), '..', 'tests', 'fake-repo-pre')
    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:15:00.020610
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:10.219733
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:15:16.543780
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:23.609670
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:15:28.538540
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:36.084468
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-no-templated-dir',
    )
    try:
        find_template(repo_dir)
    except exceptions.NonTemplatedInputDirException:
        pass

# Generated at 2022-06-17 17:15:41.611405
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:47.621248
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:51.702843
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_DIR
    template_dir = find_template(TEST_TEMPLATE_DIR)
    assert template_dir == os.path.join(TEST_TEMPLATE_DIR, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:56.269856
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:02.207865
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-pre-gen',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:16:09.275427
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:15.244645
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:16:21.518015
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:30.635106
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    file_name = os.path.join(sub_dir, 'README.rst')
    open(file_name, 'w').close()

    # Test the function
    assert find_template(temp_dir) == sub_dir

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:16:34.832707
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:40.718122
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    repo_dir = cookiecutter('tests/fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

# Generated at 2022-06-17 17:16:53.001774
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct directory."""
    from cookiecutter import utils
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, 'cookiecutter-pypackage'))
        os.makedirs(os.path.join(tmpdir, 'cookiecutter-foobar'))
        os.makedirs(os.path.join(tmpdir, 'cookiecutter-foobarbaz'))
        os.makedirs(os.path.join(tmpdir, 'foobar'))
        os.makedirs(os.path.join(tmpdir, 'foobarbaz'))
        os.makedirs(os.path.join(tmpdir, 'pypackage'))

       

# Generated at 2022-06-17 17:17:04.394992
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:14.764035
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a sub-directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file in the sub-directory
    file_path = os.path.join(sub_dir, 'README.rst')
    with open(file_path, 'w') as f:
        f.write('README')

    # Test the function
    assert find_template(temp_dir) == sub_dir

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:17:24.125202
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-no-tmpl'))

# Generated at 2022-06-17 17:17:29.072252
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:42.185426
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory inside the temporary directory
    temp_dir_2 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory inside the temporary directory
    temp_dir_3 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory inside the temporary directory
    temp_dir_4 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory inside the temporary directory
    temp_dir_5 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory inside the temporary directory
    temp_

# Generated at 2022-06-17 17:17:50.301894
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    # TODO: This test is not very good.
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:57.563595
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:18:01.986679
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    temp_subdir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(temp_subdir)

    # Create a file inside the subdirectory
    temp_file = os.path.join(temp_subdir, 'README.rst')
    with open(temp_file, 'w') as f:
        f.write('README')

    # Test the find_template function
    assert find_template(temp_dir) == temp_subdir

    # Remove the temporary directory after the test
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:18:12.616990
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:18:21.707930
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:18:31.249061
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a fake project to test with
    repo_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Test normal run
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

    # Test exception
    utils.rmtree(repo_dir)
    repo_dir = cookiecutter('tests/fake-repo-no-tmpl/', no_input=True)

# Generated at 2022-06-17 17:18:38.947239
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template

# Generated at 2022-06-17 17:18:44.887510
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:18:51.300919
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'fake-repo',
    )
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-17 17:19:14.826941
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage', '{{cookiecutter.repo_name}}', '{{cookiecutter.project_name}}'))

# Generated at 2022-06-17 17:19:24.294856
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a directory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a non-templated directory inside the temporary directory
    non_templated_dir = os.path.join(temp_dir, 'not-a-template')
    os.makedirs(non_templated_dir)

    # Create a templated directory inside the temporary directory
    templated_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    os.maked

# Generated at 2022-06-17 17:19:29.002973
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:33.534778
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    # Create a temporary repo with a template
    template_repo = cookiecutter('tests/test-template-repo')
    template_repo_dir = os.path.join(template_repo, 'test-template-repo')
    template_dir = find_template(template_repo_dir)
    assert template_dir == os.path.join(template_repo_dir, '{{cookiecutter.repo_name}}')

    # Clean up
    rmtree(template_repo)

# Generated at 2022-06-17 17:19:39.134932
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:48.032382
# Unit test for function find_template
def test_find_template():
    """Test that the correct template is found."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo-pre/',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:58.378010
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    # Test a directory with a templated directory
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-pre/',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test a directory without a templated directory

# Generated at 2022-06-17 17:20:03.730938
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:09.611584
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:20:15.494089
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    repo_dir = cookiecutter('tests/fake-repo-tmpl/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

# Generated at 2022-06-17 17:20:50.237792
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_find_template'
    )

    assert find_template(test_dir) == os.path.join(test_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:55.252939
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:00.087417
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = 'tests/fake-repo-tmpl'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:21:10.161493
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = utils.abs_expanduser(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            '..',
            'tests',
            'fake-repo-pre',
            '{{cookiecutter.repo_name}}'
        )
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-17 17:21:17.473602
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template."""
    template_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-template'
    )
    template = find_template(template_dir)
    assert template == os.path.join(template_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:28.915339
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'
    ))

    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-no-tmpl'
    ))
