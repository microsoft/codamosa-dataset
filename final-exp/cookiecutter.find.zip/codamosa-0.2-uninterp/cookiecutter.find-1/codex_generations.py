

# Generated at 2022-06-17 17:11:33.265496
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:42.788577
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a directory with a templated name
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(utils.__file__),
        'tests/test-repo-pre/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}'
    )

    # Test a directory without a templated name
    repo_dir = os

# Generated at 2022-06-17 17:11:50.261317
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:59.750945
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find the project template."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = utils.find_template('tests/fake-repo-tmpl')
    assert repo_dir == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    try:
        utils.find_template('tests/fake-repo-no-tmpl')
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('Did not raise NonTemplatedInputDirException')

# Generated at 2022-06-17 17:12:07.698770
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake cookiecutter template
    cookiecutter('tests/fake-repo-tmpl')

    # Test that find_template finds the template
    repo_dir = 'fake-repo-tmpl'
    project_template = find_template(repo_dir)
    assert project_template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'

    # Remove the fake cookiecutter template
    import shutil
    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:13.486832
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:24.562066
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    ))
    project_template = find_template(repo_dir)
    assert project_template == os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    ))

# Generated at 2022-06-17 17:12:33.822359
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the expected project template."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:40.359304
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-pre',
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-post',
    )

    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:12:45.954839
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:12:52.190482
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:00.383057
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = utils.find_repo_dir('tests/fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    repo_dir = utils.find_repo_dir('tests/fake-repo-pre/')
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'


# Generated at 2022-06-17 17:13:07.325981
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:15.073702
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    # Create a fake git repo
    repo_dir = make_repo()

    # Test normal behavior
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test exception
    os.remove(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException not raised')

   

# Generated at 2022-06-17 17:13:20.705464
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake project
    cookiecutter('tests/fake-repo-tmpl', no_input=True)

    # Find the project template
    project_template = find_template('fake-repo-tmpl')

    # Assert that the project template is what we expect
    assert project_template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:13:30.474486
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    try:
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
        os.mkdir(os.path.join(repo_dir, 'foobar'))

        assert find_template(repo_dir) == os.path.join(
            repo_dir, 'cookiecutter-pypackage'
        )
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:13:34.900972
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:43.037548
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:13:50.906089
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:59.791517
# Unit test for function find_template
def test_find_template():
    """Verify that the function `find_template` works as expected."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a sub-directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file in the sub-directory
    file_path = os.path.join(sub_dir, 'README.rst')
    with open(file_path, 'w') as f:
        f.write('This is a test file.')

    # Create a file in the top-level directory
    file_path = os.path.join(temp_dir, 'README.rst')

# Generated at 2022-06-17 17:14:11.551772
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_DIR

    test_template_dir = os.path.join(TEST_TEMPLATE_DIR, 'tests', 'test-template')
    assert utils.find_template(test_template_dir) == os.path.join(
        test_template_dir, '{{cookiecutter.repo_name}}'
    )

    test_template_dir = os.path.join(TEST_TEMPLATE_DIR, 'tests', 'test-template-no-templating')

# Generated at 2022-06-17 17:14:18.389329
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from tests import fixture

    # Test a directory with a template
    template_dir = fixture('fake-repo-pre/')
    template_dir = os.path.abspath(template_dir)
    template_dir = utils.convert_to_windows_path(template_dir)
    template = find_template(template_dir)
    assert template == template_dir + '\\{{cookiecutter.repo_name}}'

    # Test a directory without a template
    template_dir = fixture('fake-repo-no-template/')
    template_dir = os.path.abspath(template_dir)
    template_dir = utils.convert_to

# Generated at 2022-06-17 17:14:28.997316
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function."""
    from cookiecutter import utils
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'foobar')
    os.mkdir(sub_dir)

    # Create a file inside the temporary directory
    file_path = os.path.join(temp_dir, 'foo')
    with open(file_path, 'w') as f:
        f.write('foo')

    # Create a file inside the subdirectory
    sub_file_path = os.path.join(sub_dir, 'bar')
    with open(sub_file_path, 'w') as f:
        f.write('bar')

    # Create

# Generated at 2022-06-17 17:14:36.273485
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-tmpl'
    ))

    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre'
    ))

   

# Generated at 2022-06-17 17:14:43.736479
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:50.017997
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter import utils

    repo_dir = make_repo()
    template_dir = utils.find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:52.566009
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:14:55.276360
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-data',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:15:02.274080
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct path to the project template."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:12.377192
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct template."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:15:23.968083
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'test-repo')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    file_path = os.path.join(sub_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    open(file_path, 'w').close()

    # Test that the function returns the correct path
    assert find_template(temp_dir) == file_path

    # Test that the function raises an exception if no template

# Generated at 2022-06-17 17:15:29.379361
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:36.729306
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake project
    cookiecutter('tests/fake-repo-tmpl')

    # Test that the project template is found
    project_template = find_template('fake-repo-tmpl')
    assert 'fake-repo-tmpl/{{cookiecutter.repo_name}}' == project_template

    # Clean up
    os.removedirs('fake-repo-tmpl')

# Generated at 2022-06-17 17:15:44.376685
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-find-template'
    )

    assert find_template(repo_dir) == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/fake-repo'
    )


# Generated at 2022-06-17 17:15:50.750423
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:58.130779
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-pre'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:02.181752
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre/'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:09.234647
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:13.908994
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo'
    ))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:20.341863
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-repo-post/') == 'tests/test-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:16:26.838549
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:34.440855
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-pre',
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-post',
    )

    project_template = find_template(repo_dir)
    assert project

# Generated at 2022-06-17 17:16:43.887703
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:16:51.147792
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:54.757377
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct value."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:17:01.694429
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:06.828392
# Unit test for function find_template
def test_find_template():
    """Test function for find_template"""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:16.935100
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(temp_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(temp_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    assert find_template(temp_dir) == os.path.join(temp_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:17:25.467945
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from cookiecutter import __version__

    # Create a temporary repo to clone
    template_name = 'foobar'
    repo_dir = 'tests/test-find-template/{0}'.format(template_name)
    repo_url = 'https://github.com/audreyr/{0}.git'.format(template_name)

# Generated at 2022-06-17 17:17:33.847981
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'
    ))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake_template')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-post'
    ))
    project_template = utils.find_template(repo_dir)
    assert project_

# Generated at 2022-06-17 17:17:50.568500
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:17:55.648527
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = utils.find_repo_dir('tests/fake-repo-pre/')
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    repo_dir = utils.find_repo_dir('tests/fake-repo-post/')
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'


# Generated at 2022-06-17 17:18:05.185117
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:15.983959
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the expected path."""
    from cookiecutter.tests.test_find import make_empty_dir
    from cookiecutter.tests.test_find import make_empty_file

    repo_dir = make_empty_dir('repo_dir')
    make_empty_file(os.path.join(repo_dir, 'cookiecutter.json'))
    make_empty_file(os.path.join(repo_dir, 'README.md'))
    make_empty_file(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    make_empty_file(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', 'README.md'))

    project_template = find_template

# Generated at 2022-06-17 17:18:20.911789
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:28.048007
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:18:28.812869
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-17 17:18:35.468142
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:41.003996
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:50.602559
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-post',
    )
    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:19:05.311625
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a fake project
    cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Test that find_template returns the correct path
    repo_dir = 'fake-repo-tmpl'
    project_template = find_template(repo_dir)
    assert project_template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'

    # Test that find_template raises an exception when no template is found
    repo_dir = 'tests/fake-repo-pre/'
    utils.rmtree(repo_dir)


# Generated at 2022-06-17 17:19:12.280782
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:19:19.740740
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:27.425108
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:30.670056
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:33.695607
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:40.416238
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:49.088266
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:53.697299
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:00.813429
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:11.906972
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    assert find_template(repo_dir) == project_template

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:20:13.630909
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-17 17:20:24.650356
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:20:28.254256
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the correct path."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:20:32.680646
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:39.589127
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_empty_dir
    from cookiecutter.tests.test_find import make_empty_file

    repo_dir = make_empty_dir('repo_dir')
    make_empty_file(os.path.join(repo_dir, 'cookiecutter.json'))
    make_empty_file(os.path.join(repo_dir, 'README.md'))
    make_empty_file(os.path.join(repo_dir, 'LICENSE'))
    make_empty_file(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join

# Generated at 2022-06-17 17:20:50.926613
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template

# Generated at 2022-06-17 17:20:57.357139
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..', 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:21:07.549996
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.mkdir(repo_dir)

    # Create a fake project template inside the temporary directory
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(project_template)

    # Test the find_template function
    assert find_template(repo_dir) == project_template

    # Remove the temporary directory after the test
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:21:17.148035
# Unit test for function find_template
def test_find_template():
    """Verify the correct template is found."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = utils.abs_expanduser(
        os.path.join('tests', 'test-repo-pre', '{{cookiecutter.repo_name}}')
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = utils.abs_expanduser(
        os.path.join('tests', 'test-repo-pre', '{{cookiecutter.repo_name}}-master')
    )
    project_template = find_template(repo_dir)
    assert project