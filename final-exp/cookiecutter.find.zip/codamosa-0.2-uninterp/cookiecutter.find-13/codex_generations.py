

# Generated at 2022-06-17 17:11:30.905502
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:11:40.049112
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:11:44.286308
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:11:50.564349
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    assert find_template(repo_dir) == project_template

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:11:57.597923
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:12:08.231146
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.project_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.project_name}}', '{{cookiecutter.project_slug}}'))

# Generated at 2022-06-17 17:12:14.004452
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:21.468166
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:29.580088
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.project_name}}'))
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.project_name}}', '{{cookiecutter.project_slug}}'))

# Generated at 2022-06-17 17:12:36.460686
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:12:50.688463
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:12:59.836981
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    test_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(test_dir)

    # Create a dummy project template
    os.makedirs(os.path.join(test_dir, '{{cookiecutter.repo_name}}'))

    # Create a dummy file
    open(os.path.join(test_dir, 'foo.txt'), 'a').close()

    # Test that the function returns the correct path
    assert find_template(test_dir) == os.path.join(
        test_dir, '{{cookiecutter.repo_name}}'
    )

    # Clean up
    shutil

# Generated at 2022-06-17 17:13:07.360205
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:13.848139
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:13:20.122252
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:27.241332
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:32.916198
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:39.606114
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:48.641040
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    fh = open(os.path.join(sub_dir, 'README.rst'), 'w')
    fh.write('README')
    fh.close()

    # Create a file inside the temporary directory
    fh = open(os.path.join(temp_dir, 'README.rst'), 'w')
    fh.write('README')
    fh.close

# Generated at 2022-06-17 17:13:55.017811
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:02.430821
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'not_a_template'))
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}_not_a_template'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:14:08.539207
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:15.492322
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    # Test a directory with a template
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test a directory without a template
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'fake-repo',
    )

# Generated at 2022-06-17 17:14:21.405037
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:31.748280
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:14:42.527770
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'))

# Generated at 2022-06-17 17:14:46.221293
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:14:51.857608
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    from cookiecutter.tests.test_find import make_repo
    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:56.072778
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:02.070317
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:04.484782
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-17 17:15:13.039548
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:15:20.720753
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo
    from cookiecutter.tests.test_utils import TEST_COOKIE_DIR

    repo_dir = make_repo(TEST_COOKIE_DIR)
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:15:21.681278
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-17 17:15:26.696770
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:33.856570
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    # Test a directory with no templates
    repo_dir = utils.workaround_mac_python_mvn_bug(
        os.path.abspath(os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'files',
            'fake-repo-tmpl'
        ))
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, 'fake-project')

    # Test a directory with a template

# Generated at 2022-06-17 17:15:42.772202
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-17 17:15:51.893509
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template directory."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()

    # Create a fake template directory
    template_dir = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    # Create a fake non-template directory
    non_template_dir = os.path.join(repo_dir, 'cookiecutter-not-a-template')
    os.makedirs(non_template_dir)

    # Create a fake file
    fake_file = os.path.join(repo_dir, 'fake_file')
    with open(fake_file, 'w') as f:
        f.write

# Generated at 2022-06-17 17:16:01.778320
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = utils.find_repo_dir('tests/fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    repo_dir = utils.find_repo_dir('tests/fake-repo-no-tmpl')
    try:
        project_template = find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'NonTemplatedInputDirException not raised'

# Generated at 2022-06-17 17:16:08.742743
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    assert find_template(repo_dir) == template_dir

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:16:16.701399
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:27.813294
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:16:33.069663
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo'
    ))
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_project_template

# Generated at 2022-06-17 17:16:44.132609
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:16:47.527429
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:55.055048
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:00.825150
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:06.782004
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:13.004511
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:20.192983
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:30.092025
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo('tests/test-find-template')
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:36.853520
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:17:39.516280
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:47.579558
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:57.199175
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct path to the template."""
    import tempfile
    import shutil

    template_dir = tempfile.mkdtemp()
    template_name = '{{cookiecutter.project_name}}'
    template_path = os.path.join(template_dir, template_name)
    os.mkdir(template_path)

    assert find_template(template_dir) == template_path

    shutil.rmtree(template_dir)

# Generated at 2022-06-17 17:18:05.592834
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:18:13.376244
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct template."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre-gen',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:18:19.186210
# Unit test for function find_template
def test_find_template():
    """Verify that the function find_template works as expected."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:25.886051
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo

    repo_dir = make_repo()
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:30.738774
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:18:46.446216
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:18:51.830674
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:55.144418
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:01.410436
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path to the project template."""
    from cookiecutter.tests.test_utils import make_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:12.765513
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:19:20.519987
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:25.045778
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:29.856455
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:40.639833
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    fh = open(os.path.join(sub_dir, 'somefile.txt'), 'w')
    fh.write('some text')
    fh.close()

    # Create a second subdirectory inside the temporary directory
    sub_dir2 = os.path.join(temp_dir, 'cookiecutter-foobar')
    os.mkdir(sub_dir2)



# Generated at 2022-06-17 17:19:53.248748
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected."""
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:20:06.542740
# Unit test for function find_template
def test_find_template():
    """Test that find_template works as expected."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:20:09.927984
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:20:16.319459
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:25.455547
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__), 'tests', 'test-repo', 'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__), 'tests', 'test-repo', 'fake-repo-no-templ'
    )

# Generated at 2022-06-17 17:20:32.275969
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:36.151235
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = 'tests/test-find-template/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-find-template/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:20:43.222914
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    template_path = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre-gen',
        '{{cookiecutter.repo_name}}'
    )
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre-gen'
    )
    assert find_template(repo_dir) == template_path

# Generated at 2022-06-17 17:20:52.480565
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter.tests.test_utils import make_empty_dir
    from cookiecutter.tests.test_utils import remove_dir

    repo_dir = make_empty_dir()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:21:01.560595
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the project template."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:21:11.522835
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-pre',
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-post',
    )

    project_template = find_template(repo_dir)