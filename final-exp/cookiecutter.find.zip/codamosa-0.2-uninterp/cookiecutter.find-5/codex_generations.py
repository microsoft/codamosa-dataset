

# Generated at 2022-06-17 17:11:30.858029
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))
    os.makedirs(os.path.join(repo_dir, 'foobarbaz'))
    os.makedirs(os.path.join(repo_dir, 'foobarbazqux'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree

# Generated at 2022-06-17 17:11:37.065291
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import clone_test_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = clone_test_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:11:46.174409
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:47.623680
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    # TODO: write this test
    pass

# Generated at 2022-06-17 17:11:59.314699
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(
        repo_dir,
        'cookiecutter-{{cookiecutter.repo_name}}'
    )


# Generated at 2022-06-17 17:12:09.335704
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(temp_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(temp_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    template_dir = find_template(temp_dir)
    assert template_dir == os.path.join(temp_dir, 'cookiecutter-{{cookiecutter.repo_name}}')


# Generated at 2022-06-17 17:12:12.784936
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:12:19.362957
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:12:24.910707
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:30.166567
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:37.306932
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    assert find_template(repo_dir) == project_template

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:45.599765
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:50.755594
# Unit test for function find_template
def test_find_template():
    """Test function for find_template"""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:56.593917
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..', 'tests', 'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:03.684303
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path to the template."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:04.815344
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    # TODO: write this test
    pass

# Generated at 2022-06-17 17:13:09.302538
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:14.733079
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter import config
    from cookiecutter import exceptions

    # Create a fake project to use as a test case
    test_project_dir = os.path.join(config.USER_CACHE_DIRECTORY, 'tests/fake-project-tmpl')
    utils.rmtree(test_project_dir)
    cookiecutter(
        'tests/fake-repo-tmpl/',
        no_input=True,
        output_dir=config.USER_CACHE_DIRECTORY,
        overwrite_if_exists=True
    )

    # Test for expected project template
    project_template = find_template(test_project_dir)
    assert project_template

# Generated at 2022-06-17 17:13:17.694847
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:13:23.715027
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    assert find_template(repo_dir) == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:13:31.929127
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:39.571505
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:42.670035
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    # TODO: Write unit test for find_template
    pass

# Generated at 2022-06-17 17:13:49.901389
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:55.485494
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:00.692417
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(
        repo_dir,
        'cookiecutter-{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-17 17:14:07.638536
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    assert find_template(repo_dir) == template_dir

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:14:13.750714
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-pre/',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-post/',
    )
    project_template = find_template(repo_dir)


# Generated at 2022-06-17 17:14:23.777723
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns expected value."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    expected_project_template = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.project_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == expected_project_template

# Generated at 2022-06-17 17:14:30.683700
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:42.864305
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

    # Create a directory that looks like a project template
    project_template = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    os.mkdir(project_template)

    # Create a directory that does not look like a project template
    os.mkdir(os.path.join(repo_dir, 'not_a_project_template'))

    # Create a file that does not look like a project template
    open(os.path.join(repo_dir, 'not_a_project_template.txt'), 'a').close()

    # Verify that find_template() returns the correct directory

# Generated at 2022-06-17 17:14:53.826007
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    from cookiecutter import utils
    from cookiecutter import config
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a fake repo
    repo_dir = os.path.join(config.USER_CACHE_DIRECTORY, 'tests/fake-repo-tmpl')
    utils.make_sure_path_exists(repo_dir)

    # Test a repo with a templated directory
    project_dir = find_template(repo_dir)
    assert project_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test a repo without a templated directory

# Generated at 2022-06-17 17:14:59.181147
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake Cookiecutter project
    cookiecutter('tests/fake-repo-tmpl')

    # Test that the template is found
    template = find_template('fake-repo-tmpl')
    assert template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:15:05.997102
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a temporary repo with a project template
    repo_dir = cookiecutter('tests/fake-repo-tmpl/')

    # Find the project template
    project_template = find_template(repo_dir)

    # Test that the project template is found
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

# Generated at 2022-06-17 17:15:14.881254
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-pre',
    )
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-post',
    )
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-17 17:15:21.854295
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct directory."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:15:26.853296
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:29.271353
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the expected value."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:15:39.235170
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    assert find_template(repo_dir) == os.path

# Generated at 2022-06-17 17:15:45.952843
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:15:56.047813
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:59.160169
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:04.082179
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:16:09.675486
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:13.117609
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo('tests/test-find-template/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:21.518363
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo('tests/test-find-template')
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:27.590333
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:32.635767
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:43.781497
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import (
        TEST_TEMPLATE_DIR,
        TEST_TEMPLATE_DIR_NON_TEMPLATED
    )
    from cookiecutter.exceptions import NonTemplatedInputDirException

    template_dir = find_template(TEST_TEMPLATE_DIR)
    assert template_dir == os.path.join(TEST_TEMPLATE_DIR, '{{cookiecutter.repo_name}}')

    try:
        find_template(TEST_TEMPLATE_DIR_NON_TEMPLATED)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('find_template should have raised a NonTemplatedInputDirException')

# Generated at 2022-06-17 17:16:51.440765
# Unit test for function find_template
def test_find_template():
    """Test find_template() function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:08.308938
# Unit test for function find_template
def test_find_template():
    """Test find_template function"""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    fh = open(os.path.join(sub_dir, 'test.txt'), 'w')
    fh.write('test')
    fh.close()

    # Create a file inside the temporary directory
    fh = open(os.path.join(temp_dir, 'test2.txt'), 'w')
    fh.write('test')
    fh.close()

    # Test find_

# Generated at 2022-06-17 17:17:19.179873
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'test_dir')
    os.mkdir(sub_dir)

    # Create a file inside the subdirectory
    test_file = os.path.join(sub_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a templated directory inside the subdirectory
    templated_dir = os.path.join(sub_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(templated_dir)

   

# Generated at 2022-06-17 17:17:23.897226
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:32.444271
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    try:
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
        os.mkdir(os.path.join(repo_dir, 'foobar'))

        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:37.367599
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:44.780066
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:52.163233
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:58.967588
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:18:03.445286
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:18:14.295105
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template

# Generated at 2022-06-17 17:18:48.750336
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:52.792442
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake cookiecutter template
    cookiecutter('tests/fake-repo-tmpl')

    # Test that the template is found
    template = find_template('fake-repo-tmpl')
    assert template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:19:05.056198
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', 'foobar'))

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:19:14.215462
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a repo with a templated directory
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-pre/',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test a repo without a templated directory

# Generated at 2022-06-17 17:19:21.625644
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:27.281951
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    from cookiecutter import utils

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))
    os.makedirs(os.path.join(repo_dir, 'foobarbaz'))

    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:33.277361
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    repo_dir = utils.workaround_mac_python_bug(
        os.path.abspath(os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'fake-repo-tmpl'
        ))
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-17 17:19:42.681972
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:19:51.027111
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:00.411622
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()


# Generated at 2022-06-17 17:21:06.565865
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct path."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:11.337221
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:16.570734
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:21:24.937010
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')