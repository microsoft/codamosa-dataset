

# Generated at 2022-06-17 17:11:28.440621
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct directory."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:11:33.919352
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:11:41.581669
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = utils.find_template('tests/fake-repo-tmpl')
    assert repo_dir == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    try:
        utils.find_template('tests/fake-repo-no-tmpl')
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'NonTemplatedInputDirException not raised'

# Generated at 2022-06-17 17:11:45.222657
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:51.368686
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:58.849421
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:08.969545
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:12:17.625206
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project_template = find_template

# Generated at 2022-06-17 17:12:26.833129
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:30.611063
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:38.533677
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo', 'input'
    ))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:50.923180
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected."""
    from cookiecutter import utils
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'test_dir')
    os.mkdir(sub_dir)

    # Create a file inside the temporary directory
    file_path = os.path.join(sub_dir, 'test_file')
    with open(file_path, 'w') as f:
        f.write('test')

    # Create a file inside the temporary directory
    file_path = os.path.join(sub_dir, 'test_file2')
    with open(file_path, 'w') as f:
        f.write('test')

# Generated at 2022-06-17 17:13:00.013134
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}-master'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-master'))

    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:13:04.386776
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:09.190652
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:19.296434
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    tests_dir = os.path.abspath(os.path.dirname(__file__))
    fixtures_dir = os.path.join(tests_dir, 'fixtures')

    # Test a directory with no templates
    no_template_dir = os.path.join(fixtures_dir, 'no-template')
    try:
        utils.find_template(no_template_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException not raised')

    # Test a directory with a template
    template_dir = os.path.join(fixtures_dir, 'template')
    template_

# Generated at 2022-06-17 17:13:25.293544
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""

# Generated at 2022-06-17 17:13:34.353044
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:13:42.444281
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:51.495690
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-tmpl'
    ))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre'
    ))
   

# Generated at 2022-06-17 17:13:57.998404
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:01.615186
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:07.333302
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:14:12.541865
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:19.194590
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-data',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:23.122392
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake cookiecutter template
    template = cookiecutter('tests/fake-repo-tmpl')

    # Make sure the template is found
    assert find_template(template) == os.path.join(template, 'fake-repo')

# Generated at 2022-06-17 17:14:33.829862
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    from cookiecutter import utils
    from cookiecutter.tests.test_utils import make_empty_dir

    repo_dir = make_empty_dir()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = utils.find_template(repo_dir)
    assert project_template == os

# Generated at 2022-06-17 17:14:39.505721
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:47.443222
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:58.096925
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    import tempfile
    import shutil

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary directory inside the temporary directory
    tmp_dir_2 = tempfile.mkdtemp(dir=tmp_dir)

    # Create a temporary directory inside the temporary directory
    tmp_dir_3 = tempfile.mkdtemp(dir=tmp_dir)

    # Create a temporary directory inside the temporary directory
    tmp_dir_4 = tempfile.mkdtemp(dir=tmp_dir)

    # Create a temporary directory inside the temporary directory
    tmp_dir_5 = tempfile.mkdtemp(dir=tmp_dir)

    # Create a temporary directory inside the temporary directory

# Generated at 2022-06-17 17:15:08.201364
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct directory."""
    from cookiecutter import utils
    from cookiecutter.main import cookiecutter

    # Create a fake Cookiecutter project
    cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Find the project template
    project_template = utils.find_template('fake-repo-tmpl')

    # Verify the project template is the expected directory
    assert project_template == 'fake-repo-tmpl/fake-project-tmpl'

# Generated at 2022-06-17 17:15:15.938600
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-foobar')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:15:23.325671
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct path."""
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(repo_dir, 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected

# Generated at 2022-06-17 17:15:28.250757
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:36.339074
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:15:41.423265
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:51.004421
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    template_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(template_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(template_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(template_dir, 'cookiecutter-foobarbaz'))

    assert find_template(template_dir) == os.path.join(
        template_dir,
        'cookiecutter-pypackage'
    )

    shutil.rmtree(template_dir)

# Generated at 2022-06-17 17:15:58.992509
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:03.989883
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct path."""
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    # Create a temporary git repo
    repo_dir = main.cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Find the template in the repo
    project_template = find_template(repo_dir)

    # Verify the template path is correct
    expected = os.path.join(repo_dir, 'fake-project-tmpl')
    assert project_template == expected

    # Clean up
    rmtree(repo_dir)

# Generated at 2022-06-17 17:16:10.922264
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:23.027082
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:32.567397
# Unit test for function find_template
def test_find_template():
    """Test for find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    assert find_template(repo_dir) == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:16:43.713585
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from cookiecutter import __version__

    repo_dir = 'tests/test-repo-pre/'
    output_dir = 'tests/test-output-pre/'
    rmtree(output_dir)

    cookiecutter(
        repo_dir,
        no_input=True,
        output_dir=output_dir,
        extra_context={'full_name': 'Test User', 'email': 'test@example.com'},
        overwrite_if_exists=True,
        config_file='tests/test-config.yaml',
        default_config=True,
        version=__version__
    )


# Generated at 2022-06-17 17:16:53.626681
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct path."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-foobar')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:01.221788
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:11.067958
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:19.840439
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:26.771528
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()


# Generated at 2022-06-17 17:17:35.378214
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    # Test a repo with a templated directory
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test a repo with no templated directories

# Generated at 2022-06-17 17:17:39.942389
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:52.677244
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    # Test for a non-templated input directory
    repo_dir = utils.workaround_mac_python_bug(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre',
    ))
    try:
        find_template(repo_dir)
    except exceptions.NonTemplatedInputDirException:
        pass
    else:
        raise Exception('Should have raised NonTemplatedInputDirException')

    # Test for a templated input directory

# Generated at 2022-06-17 17:17:57.781922
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    # Create a fake repo_dir
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')

    # Test that find_template returns the correct path
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:00.818310
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:11.947888
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a test repo in the temporary directory
    test_repo = os.path.join(temp_dir, 'test_repo')
    os.makedirs(test_repo)

    # Create a test template in the test repo
    test_template = os.path.join(test_repo, 'test_template')
    os.makedirs(test_template)

    # Create a test file in the test template
    test_file = os.path.join(test_template, 'test_file')

# Generated at 2022-06-17 17:18:17.832249
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:24.035434
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:18:29.714355
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:36.541462
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:40.829235
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(repo_dir, 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:52.052255
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works properly."""
    import tempfile
    import shutil
    from cookiecutter import utils

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'my_template'))
    os.makedirs(os.path.join(repo_dir, 'my_template', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'my_template', '{{cookiecutter.repo_name}}', '{{cookiecutter.project_name}}'))

# Generated at 2022-06-17 17:19:15.785934
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:19:24.028926
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:19:28.843274
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:32.380738
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the expected value."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:42.985610
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    tests_dir = os.path.abspath(os.path.dirname(__file__))
    fixtures_dir = os.path.join(tests_dir, 'fixtures')
    repo_dir = os.path.join(fixtures_dir, 'fake-repo-tmpl')

    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(fixtures_dir, 'fake-repo-no-tmpl')

# Generated at 2022-06-17 17:19:47.478013
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter import utils
    import tempfile

    temp_dir = tempfile.mkdtemp()
    temp_dir_contents = ['cookiecutter-pypackage', 'cookiecutter-djangopackage', 'cookiecutter-foopackage']
    for item in temp_dir_contents:
        os.mkdir(os.path.join(temp_dir, item))

    assert utils.find_template(temp_dir) == os.path.join(temp_dir, 'cookiecutter-djangopackage')

# Generated at 2022-06-17 17:19:57.886729
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'
    ))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-no-tmpl'
    ))

# Generated at 2022-06-17 17:20:04.921820
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    from cookiecutter import utils

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake project template
    utils.make_sure_path_exists(os.path.join(temp_dir, 'fake-project-template'))

    # Create a fake non-project template
    utils.make_sure_path_exists(os.path.join(temp_dir, 'fake-non-template'))

    # Test that find_template returns the correct path
    assert find_template(temp_dir) == os.path.join(temp_dir, 'fake-project-template')

# Generated at 2022-06-17 17:20:10.670418
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:17.696922
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:38.436086
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:47.808063
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:57.710733
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre',
    ))

    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-post',
    ))

    project

# Generated at 2022-06-17 17:21:07.267166
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:21:13.628478
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:21.941853
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake cookiecutter template inside it
    os.makedirs(os.path.join(temp_dir, 'fake-cookiecutter-{{project_name}}'))

    # Test the find_template function
    assert find_template(temp_dir) == os.path.join(
        temp_dir, 'fake-cookiecutter-{{project_name}}'
    )

    # Remove the temporary directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:21:27.397527
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')