

# Generated at 2022-06-17 17:11:37.685403
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage-master'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage-master-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:11:50.780033
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:11:56.955830
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:07.698258
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    from cookiecutter.tests.test_utils import make_empty_dir
    from cookiecutter.tests.test_utils import remove_dir

    repo_dir = make_empty_dir()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:12:13.808421
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:12:17.825353
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(project_template)

    assert find_template(repo_dir) == project_template

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:23.946166
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    assert find_template(repo_dir) == project_template

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:30.246165
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)

    assert find_template(repo_dir) == template_dir

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:35.214171
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-pre-gen-project',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:44.863148
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:51.478287
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:00.508637
# Unit test for function find_template
def test_find_template():
    """Verify that the function find_template works as expected."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.mkdir(repo_dir)

    # Create a non-templated directory inside the repo_dir
    non_templated_dir = os.path.join(repo_dir, 'not-a-template')
    os.mkdir(non_templated_dir)

    # Create a templated directory inside the repo_dir
    templated_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-17 17:13:04.884882
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:12.623674
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:13:22.244256
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

    # Create a directory that contains a template
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    # Create a directory that does not contain a template
    os.makedirs(os.path.join(repo_dir, 'not_a_template'))

    # Create a file that contains a template
    open(os.path.join(repo_dir, '{{cookiecutter.repo_name}}.txt'), 'a').close()

    # Create a file that does not contain a template

# Generated at 2022-06-17 17:13:33.023224
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-find-template'
    )

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test that an exception is raised if no project template is found
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/fake-repo'
    )

# Generated at 2022-06-17 17:13:41.917280
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    # TODO: This test is not very good.
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-data',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:49.037386
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:13:55.681021
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:00.315558
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-pre'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:09.276453
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:13.494591
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:14:20.003815
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:24.476122
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:31.623599
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:41.908189
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage-master'))

    assert find_template(repo_dir) == os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:14:45.373075
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:55.487273
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-17 17:15:01.476965
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:08.081042
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter import utils

    repo_dir = make_repo()
    project_template = utils.find_template(repo_dir)
    assert os.path.exists(project_template)
    assert '{{cookiecutter.repo_name}}' in project_template
    assert '{{cookiecutter.repo_name}}' in os.listdir(project_template)

# Generated at 2022-06-17 17:15:15.285485
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:15:22.172755
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_empty_dir
    from cookiecutter.tests.test_find import make_empty_file

    repo_dir = make_empty_dir('repo_dir')
    make_empty_file(os.path.join(repo_dir, 'cookiecutter.json'))
    make_empty_file(os.path.join(repo_dir, 'README.md'))
    make_empty_file(os.path.join(repo_dir, 'LICENSE'))
    make_empty_file(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))


# Generated at 2022-06-17 17:15:29.065596
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file in the subdirectory
    fh = open(os.path.join(sub_dir, 'file.txt'), 'w')
    fh.write('test')
    fh.close()

    # Create a file in the top-level directory
    fh = open(os.path.join(temp_dir, 'file.txt'), 'w')
    fh.write('test')
    fh.close()

    # Verify that find

# Generated at 2022-06-17 17:15:39.210300
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a sub-directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file in the sub-directory
    fh = open(os.path.join(sub_dir, 'file.txt'), 'w')
    fh.write('some data')
    fh.close()

    # Create a file in the top-level directory
    fh = open(os.path.join(temp_dir, 'file.txt'), 'w')
    fh.write('some data')

# Generated at 2022-06-17 17:15:43.545065
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:50.307840
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a temporary repo to test with
    repo_dir = cookiecutter('tests/test-repo-pre/', no_input=True)

    # Test the find_template function
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:56.355980
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Create a temporary project
    project_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Find the project template
    project_template = find_template(project_dir)

    # Check that the project template is the expected one
    expected_project_template = os.path.join(
        project_dir,
        'fake-project-{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_project_template

    # Clean up
    utils.rmtree(project_dir)

# Generated at 2022-06-17 17:16:01.745114
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(repo_dir, 'tests', 'fake-repo-pre-gen')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:09.392060
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:14.128316
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:27.494638
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:34.567380
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobarbaz'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:16:41.675431
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:51.112163
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'fake-repo',
            '{{cookiecutter.repo_name}}'
        )
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:54.855253
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'fake-repo')
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:01.346840
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:07.285052
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:18.144869
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-pre/',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-post/',
    )
    project_template = find_template(repo_dir)
   

# Generated at 2022-06-17 17:17:22.843527
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo', 'input'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:28.745348
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:44.035182
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import project_dir
    project_template = find_template(project_dir)
    assert project_template == os.path.join(project_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:53.221302
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a test directory with a cookiecutter template
    test_dir = os.path.join(temp_dir, 'test_dir')
    os.mkdir(test_dir)
    test_template = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(test_template)

    # Test that the function finds the template
    assert find_template(test_dir) == test_template

    # Clean up the temporary directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:18:00.101632
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-post'))
    project_template = utils.find_template(repo_dir)
    assert project_

# Generated at 2022-06-17 17:18:07.034912
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct path to the project template."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    remove_repo(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:14.008101
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo', 'input'
    ))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:22.492049
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected."""
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:18:28.228773
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:34.857190
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:39.041316
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:18:50.538384
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:19:11.846844
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake project
    repo_dir = cookiecutter('tests/fake-repo-tmpl')

    # Test the find_template function
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

# Generated at 2022-06-17 17:19:20.131235
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:19:26.955753
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:32.181397
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:19:39.448026
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:40.862717
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-17 17:19:49.612068
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:59.044333
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    try:
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:20:05.659205
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    assert find_template(repo_dir) == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:20:12.930473
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    from cookiecutter import utils

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'my-fake-project'))
    os.makedirs(os.path.join(repo_dir, 'my-fake-project-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'my-fake-project-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project_template = utils.find_template(repo_dir)

# Generated at 2022-06-17 17:20:50.859013
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:55.638850
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:01.488087
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:07.880753
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:15.287322
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from tests.test_utils import TEST_TEMPLATE_DIR

    # Test with a template that has a templated directory
    template_dir = os.path.join(TEST_TEMPLATE_DIR, 'test-template')
    project_template = utils.find_template(template_dir)
    assert project_template == os.path.join(template_dir, '{{cookiecutter.repo_name}}')

    # Test with a template that does not have a templated directory
    template_dir = os.path.join(TEST_TEMPLATE_DIR, 'test-template-no-templated-dir')

# Generated at 2022-06-17 17:21:17.079457
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import test_find_template
    test_find_template()

# Generated at 2022-06-17 17:21:28.890849
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a directory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a non-templated directory inside the temporary directory
    non_templated_dir = os.path.join(temp_dir, 'non-templated-dir')
    os.makedirs(non_templated_dir)

    # Create a templated directory inside the temporary directory
    templated_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')