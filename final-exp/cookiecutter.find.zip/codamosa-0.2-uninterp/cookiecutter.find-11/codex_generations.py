

# Generated at 2022-06-17 17:11:29.610686
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import repo_dir
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:35.498233
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:41.646035
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:11:46.528682
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:11:53.826681
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:02.392332
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.r

# Generated at 2022-06-17 17:12:08.724371
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:17.450817
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))
    os.makedirs(os.path.join(repo_dir, 'baz'))
    os.makedirs(os.path.join(repo_dir, 'qux'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:23.778863
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake project
    cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Find the project template
    project_template = find_template('fake-repo-tmpl')
    assert project_template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:12:31.014033
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    from cookiecutter.tests.test_find import make_empty_dir
    from cookiecutter.tests.test_find import make_empty_file
    from cookiecutter.tests.test_find import remove_dir

    repo_dir = make_empty_dir('repo_dir')
    make_empty_file(os.path.join(repo_dir, 'cookiecutter.json'))
    make_empty_file(os.path.join(repo_dir, 'README.md'))
    make_empty_file(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:12:38.636079
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    from cookiecutter import utils
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, 'cookiecutter-foobar'))
        os.makedirs(os.path.join(tmpdir, 'cookiecutter-{{cookiecutter.repo_name}}'))
        os.makedirs(os.path.join(tmpdir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

        template_dir = utils.find_template(tmpdir)
        assert template_dir == os.path.join(tmpdir, 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:50.956291
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a non-template directory inside the temporary directory
    non_template_dir = os.path.join(repo_dir, 'my-fake-project')
    os.makedirs(non_template_dir)

    # Create a template directory inside the temporary directory
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:57.357702
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:03.497312
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:04.636388
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    # TODO: Add tests
    pass

# Generated at 2022-06-17 17:13:09.415032
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:12.825774
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:20.009345
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake cookiecutter template
    cookiecutter('tests/fake-repo-tmpl', no_input=True)
    template_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-tmpl',
        'fake-project-tmpl'
    )
    assert find_template(template_dir) == template_dir

# Generated at 2022-06-17 17:13:27.084755
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:34.851781
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from cookiecutter import __version__

    repo_dir = 'tests/test-repo-pre/'
    output_dir = 'tests/fake-repo-tmpl/'
    context = {
        'full_name': 'Test Author',
        'email': 'test@example.com',
        'github_username': 'test',
        'project_name': 'Test Project',
        'project_slug': 'test-project',
        'release_date': '2014-12-25',
        'version': '0.1.0',
        'cookiecutter': __version__,
    }


# Generated at 2022-06-17 17:13:43.357124
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:13:50.994629
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:59.847674
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:14:06.382419
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:14:11.870809
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:14:18.662167
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    import os
    import shutil
    import tempfile

    from cookiecutter import find

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake repo
    fake_repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(fake_repo_dir)

    # Create a fake project template
    fake_project_template = os.path.join(
        fake_repo_dir, '{{cookiecutter.repo_name}}'
    )
    os.makedirs(fake_project_template)

    # Test
    assert find.find_template(fake_repo_dir) == fake_project_template

    # Clean up
    shutil.r

# Generated at 2022-06-17 17:14:29.504701
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct project template."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert utils.find_template(repo_dir) == project_template

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-no-tmpl'))


# Generated at 2022-06-17 17:14:34.415920
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:14:39.804149
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo'
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:47.161844
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:55.858009
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo'))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:06.878146
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-post'
    )

# Generated at 2022-06-17 17:15:10.503137
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:15.415126
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:15:20.283395
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:28.978161
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.mkdir(repo_dir)

    # Create a subdirectory inside the repo_dir
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(project_template)

    # Call find_template
    result = find_template(repo_dir)

    # Verify that find_template returned the correct path
    assert result == project_template

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:15:39.211695
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a sub-directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.mkdir(sub_dir)

    # Create a file in the sub-directory
    open(os.path.join(sub_dir, 'setup.py'), 'a').close()

    # Create a file in the top-level directory
    open(os.path.join(temp_dir, 'README.rst'), 'a').close()

    # Test the function
    assert find_template(temp_dir) == sub_dir

    # Remove the directory after the test
   

# Generated at 2022-06-17 17:15:45.953371
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Create a temporary cookiecutter template
    template = 'tests/test-find-template'
    utils.make_sure_path_exists(template)

    # Create a temporary cookiecutter template
    template_name = 'test-find-template'
    template_path = os.path.join(template, template_name)
    utils.make_sure_path_exists(template_path)

    # Create a temporary cookiecutter template
    template_name2 = 'test-find-template2'
    template_path2 = os.path.join(template, template_name2)
    utils.make_sure_path_exists(template_path2)

    # Create a temporary cookie

# Generated at 2022-06-17 17:15:51.047712
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:58.016752
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:14.811086
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:16:21.474432
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-17 17:16:27.543897
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:32.323192
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:39.065862
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:49.742914
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:51.182842
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    # TODO: This is a stub.
    assert True

# Generated at 2022-06-17 17:16:57.704218
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:17:04.213153
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    repo_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    project_template = find_template(repo_dir)
    assert os.path.isdir(project_template)

    utils.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:14.539768
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    # Create a fake cookiecutter template
    cookiecutters_dir = os.path.abspath(os.path.dirname(__file__))
    fake_repo_dir = os.path.join(cookiecutters_dir, 'fake-repo')
    fake_repo_dir_tmpl = os.path.join(fake_repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(fake_repo_dir_tmpl)

    # Run cookiecutter against the fake repo

# Generated at 2022-06-17 17:17:25.248179
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:33.205754
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct value."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:17:37.925534
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:49.495969
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Create a temporary repo
    repo_dir = cookiecutter('tests/test-repo-pre/', no_input=True)

    # Find the template inside the repo
    project_template = find_template(repo_dir)

    # Check the template is the one we expect
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

    # Clean up the repo
    utils.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:52.949934
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:58.823003
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

# Generated at 2022-06-17 17:18:04.979200
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    from cookiecutter.tests.test_find import make_repo

    repo_dir = make_repo('tests/test-find-template/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:15.788106
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-tmpl'
    ))

    project_template = utils.find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre'
    ))

   

# Generated at 2022-06-17 17:18:21.011133
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    import tempfile

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    assert utils.find_template(repo_dir) == template_dir

# Generated at 2022-06-17 17:18:25.595620
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import repo_dir
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:48.537918
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template directory."""
    from cookiecutter import utils
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-pre'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:51.473551
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = 'tests/test-find-template'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:18:53.952425
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct template directory."""
    from cookiecutter.tests.test_find import make_repo
    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:05.280176
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:19:12.889580
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:19:20.930050
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:25.505721
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', 'tests'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}', 'docs'))

# Generated at 2022-06-17 17:19:29.920438
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:19:40.253472
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake repo
    fake_repo = os.path.join(temp_dir, 'fake_repo')
    os.makedirs(fake_repo)

    # Create a fake project template
    fake_project_template = os.path.join(fake_repo, '{{cookiecutter.repo_name}}')
    os.makedirs(fake_project_template)

    # Test find_template
    assert find_template(fake_repo) == fake_project_template

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:19:50.259273
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:20:26.732732
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:20:37.359050
# Unit test for function find_template
def test_find_template():
    """Test find_template() function."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake cookiecutter template in the temporary directory
    os.makedirs(os.path.join(temp_dir, 'fake-cookiecutter-template'))

    # Create a fake non-cookiecutter template in the temporary directory
    os.makedirs(os.path.join(temp_dir, 'fake-non-cookiecutter-template'))

    # Test the find_template() function
    template_dir = find_template(temp_dir)
    assert template_dir == os.path.join(temp_dir, 'fake-cookiecutter-template')

    # Remove the temporary directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:20:50.562638
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:20:59.561279
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:21:02.590680
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the template in a repo."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:21:09.097103
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    remove_repo(repo_dir)

# Generated at 2022-06-17 17:21:17.963863
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake project
    cookiecutter('tests/fake-repo-tmpl', no_input=True)

    # Find the project template
    project_template = find_template('fake-repo-tmpl')

    # Check that the project template is correct
    assert project_template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:21:28.914751
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'))
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake_project_tmpl')

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-post'))
    project_template = utils.find_template(repo_dir)