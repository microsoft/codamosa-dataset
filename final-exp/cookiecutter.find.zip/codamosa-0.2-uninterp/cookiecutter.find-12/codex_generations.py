

# Generated at 2022-06-17 17:11:34.203308
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a temporary repo with a project template in it
    cookiecutter('tests/test-repo-tmpl/', no_input=True)

    # Find the project template
    project_template = find_template('tests/test-repo-tmpl/')

    # Check that the project template is what we expect
    assert project_template == 'tests/test-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:11:40.950563
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template."""
    from cookiecutter import utils
    from cookiecutter import config

    repo_dir = os.path.join(config.USER_CACHE_DIRECTORY, 'tests/fake-repo-pre/')
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:44.265849
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:50.145645
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:56.266478
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:06.040623
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre-master/') == 'tests/fake-repo-pre-master/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post-master/') == 'tests/fake-repo-post-master/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:12:15.506169
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:23.362777
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:29.621545
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:36.952544
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:12:49.910403
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = utils.find_template('tests/fake-repo-tmpl')
    assert repo_dir == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    try:
        repo_dir = utils.find_template('tests/fake-repo-pre')
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException not raised')

# Generated at 2022-06-17 17:12:59.143473
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

        assert find_template(repo_dir) == os.path.join(
            repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
        )
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:13:07.219855
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:14.986949
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a subdirectory inside the temporary directory
    project_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_dir)

    # Call function
    project_template = find_template(repo_dir)

    # Verify that the correct path was returned
    assert project_template == project_dir

    # Clean up
    shutil.rmt

# Generated at 2022-06-17 17:13:23.096917
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Create a fake cookiecutter template
    template_name = 'fake-repo'
    template = cookiecutter(
        'tests/fake-repo-pre/',
        no_input=True,
        extra_context={'repo_name': template_name}
    )

    # Test that the template is found
    template_dir = os.path.join(template, template_name)
    assert template_dir == find_template(template_dir)

    # Test that a NonTemplatedInputDirException is raised if the template is
    # not found
    utils.rmtree(template)

# Generated at 2022-06-17 17:13:33.650726
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

    # Create a directory that looks like a template
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)

    # Create a directory that doesn't look like a template
    os.mkdir(os.path.join(repo_dir, 'not_a_template'))

    # Create a file that doesn't look like a template
    open(os.path.join(repo_dir, 'not_a_template_either'), 'a').close()

    # Test that the template is found
    assert find_template(repo_dir) == template_dir

    # Clean up
    shutil

# Generated at 2022-06-17 17:13:44.684261
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:13:54.173959
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:14:03.335028
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:14:12.509816
# Unit test for function find_template
def test_find_template():
    """Test that the function find_template works as expected."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:14:21.937985
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    ))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:32.552982
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:14:39.055678
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:50.797674
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))

    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-no-tmpl'))


# Generated at 2022-06-17 17:14:56.024915
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    assert find_template(repo_dir) == repo_dir

# Generated at 2022-06-17 17:15:02.030206
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter import utils

    repo_dir = make_repo()
    template_dir = utils.find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:08.302014
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:16.386354
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(utils.ROOT_PROJECT_DIR, 'tests/fake-repo-pre/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(utils.ROOT_PROJECT_DIR, 'tests/fake-repo-post/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os

# Generated at 2022-06-17 17:15:26.855210
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

    # Test exception
    repo_dir = cookiecutter('tests/fake-repo-no-templ/', no_input=True)
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False


# Generated at 2022-06-17 17:15:31.848700
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    from cookiecutter import utils

    repo_dir = tempfile.mkdtemp()
    project_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_dir)

    try:
        assert find_template(repo_dir) == project_dir
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:15:45.869014
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:51.336856
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:01.961696
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:16:08.957494
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:12.025825
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:17.582037
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter

    repo_dir = cookiecutter('tests/fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project-tmpl')

# Generated at 2022-06-17 17:16:24.026256
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:33.005618
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:16:44.133300
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-17 17:16:49.984626
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:06.874334
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:11.585714
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:22.144417
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:17:28.420560
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:36.258154
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a directory with no templates
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests/test-find-template/no-templates'
    )
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('find_template should have raised a '
                        'NonTemplatedInputDirException')

    # Test a directory with one template

# Generated at 2022-06-17 17:17:43.011704
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    cookiecutter_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(cookiecutter_dir)

    # Create a file inside the temporary directory
    readme_file = os.path.join(temp_dir, 'README.md')
    with open(readme_file, 'w') as f:
        f.write('README')

    # Create a file inside the subdirectory
    cookiecutter_file = os.path.join(cookiecutter_dir, 'cookiecutter.json')

# Generated at 2022-06-17 17:17:43.605344
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-17 17:17:52.193274
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Create a temporary project
    project_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Find the project template
    project_template = find_template(project_dir)

    # Remove the temporary project
    utils.rmtree(project_dir)

    assert project_template == os.path.join(project_dir, 'fake-project')

# Generated at 2022-06-17 17:17:59.778856
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from unittest import TestCase

    class TestFindTemplate(TestCase):

        def setUp(self):
            self.repo_dir = os.path.abspath(os.path.dirname(__file__))

        def test_find_template(self):
            project_template = utils.find_template(self.repo_dir)
            self.assertEqual(
                project_template,
                os.path.join(self.repo_dir, 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
            )

        def test_find_template_no_templated_dir(self):
            repo

# Generated at 2022-06-17 17:18:11.046708
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = utils.find_repo_dir('tests/fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    repo_dir = utils.find_repo_dir('tests/fake-repo-pre/')
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'


# Generated at 2022-06-17 17:18:31.558059
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..', 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..', 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:18:34.278517
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:18:36.517186
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct value."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:18:41.756737
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:48.679469
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    from cookiecutter.tests.test_utils import make_repo
    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:51.922109
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    repo_dir = 'tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:18:56.575938
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a fake project template inside the temporary directory
    project_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_dir)

    # Test the find_template function
    assert utils.find_template(repo_dir) == project_dir

    # Remove the temporary directory after the test
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:18:58.026743
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    # TODO: write this test
    pass

# Generated at 2022-06-17 17:19:04.238851
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:19:06.572165
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:28.050871
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:19:31.365380
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:42.821208
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage', '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage', '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:19:51.181771
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..', 'tests', 'fake-repo', '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:55.551300
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:20:05.385285
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:20:09.904477
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-repo-post/') == 'tests/test-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:20:20.069854
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct template directory."""
    from cookiecutter import utils
    from cookiecutter import config

    # Create a fake repo
    repo_dir = os.path.join(config.USER_CACHE_DIRECTORY, 'tests/fake-repo-tmpl')
    utils.make_sure_path_exists(repo_dir)

    # Create a fake template
    fake_template = os.path.join(repo_dir, 'fake-project-{{cookiecutter.repo_name}}')
    utils.make_sure_path_exists(fake_template)

    # Create a fake file
    fake_file = os.path.join(repo_dir, 'README.rst')

# Generated at 2022-06-17 17:20:24.708988
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:28.109008
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo'
    ))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:46.761033
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:51.409176
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:56.656008
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter import utils

    repo_dir = make_repo()
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:07.772705
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_DIR

    template_dir = utils.find_template(TEST_TEMPLATE_DIR)
    assert template_dir == os.path.join(TEST_TEMPLATE_DIR, '{{cookiecutter.repo_name}}')

    # Test that an exception is raised if the template dir is not found
    os.chdir(os.path.join(TEST_TEMPLATE_DIR, '..'))

# Generated at 2022-06-17 17:21:12.798610
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree

    # Create a fake Cookiecutter project
    cookiecutter('tests/fake-repo-tmpl')

    # Find the project template
    project_template = find_template('fake-repo-tmpl')

    # Clean up
    rmtree('fake-repo-tmpl')

    assert project_template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:21:22.510892
# Unit test for function find_template
def test_find_template():
    """Verify that the function find_template works as expected."""
    import tempfile
    import shutil

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a fake cookiecutter.json file
    fake_json = os.path.join(tmp_dir, 'cookiecutter.json')
    with open(fake_json, 'w') as f:
        f.write('{"foo": "bar"}')

    # Create a fake template directory
    fake_template = os.path.join(tmp_dir, 'fake_template')
    os.mkdir(fake_template)

    # Create a fake template file
    fake_file = os.path.join(fake_template, 'fake_file')

# Generated at 2022-06-17 17:21:27.924425
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')