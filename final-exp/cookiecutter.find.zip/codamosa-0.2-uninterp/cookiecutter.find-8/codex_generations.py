

# Generated at 2022-06-17 17:11:31.682856
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:37.212654
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:11:46.319810
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function.
    """
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(project_template)

    assert find_template(repo_dir) == project_template

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:11:54.034404
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:12:00.734974
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:07.183922
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works as expected."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:12:12.661257
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(repo_dir, 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:19.303211
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(sub_dir)

    # Create a file inside the subdirectory
    fh = open(os.path.join(sub_dir, 'test.txt'), 'w')
    fh.write('test')
    fh.close()

    # Create a subdirectory inside the subdirectory
    subsub_dir = os.path.join(sub_dir, 'cookiecutter-pypackage')
    os.makedirs(subsub_dir)

    # Create

# Generated at 2022-06-17 17:12:27.979413
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

    project_template = find_template(repo_dir)
    assert project_template

# Generated at 2022-06-17 17:12:32.345256
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:12:38.356928
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre-gen-project',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:12:50.582988
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:12:55.814436
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:05.449032
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-tmpl'
    ))

    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre'
    ))

    project_template = utils.find_template

# Generated at 2022-06-17 17:13:13.533893
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-pre/',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-repo-post/',
    )
    project_template = find_template(repo_dir)
   

# Generated at 2022-06-17 17:13:18.378850
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(os.path.dirname(__file__), 'fake-repo')) == os.path.join(os.path.dirname(__file__), 'fake-repo', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:24.232545
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct template."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_DIR

    template = utils.find_template(TEST_TEMPLATE_DIR)
    assert template == os.path.join(TEST_TEMPLATE_DIR, '{{cookiecutter.repo_name}}')

    try:
        utils.find_template('/tmp/not-a-real-dir')
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException not raised')

# Generated at 2022-06-17 17:13:31.538728
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:34.571895
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo

    repo_dir = make_repo()

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:13:44.516164
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile
    from cookiecutter.utils import rmtree

    # Create a temp directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake repo
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a fake project template
    project_template = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    os.makedirs(project_template)

    # Test find_template
    assert find_template(repo_dir) == project_template

    # Clean up
    rmtree(temp_dir)

# Generated at 2022-06-17 17:13:54.199846
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a file inside the subdirectory
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    # Test the find_template function
    assert find_template(temp_dir) == project_template

    # Remove the directory after the test
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:13:58.946208
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:14:06.512518
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:14.207510
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:14:24.182494
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a fake repo
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'fake-repo'))
    assert os.path.isdir(repo_dir)

    # Test a repo with a templated directory
    project_dir = utils.find_template(repo_dir)
    assert project_dir == os.path.join(repo_dir, 'fake-project')

    # Test a repo without a templated directory

# Generated at 2022-06-17 17:14:29.093201
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    from cookiecutter.tests.test_find import repo_dir
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:34.241935
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:43.146113
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:14:49.239816
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:14:55.982494
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    from cookiecutter import utils
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    )
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:04.772882
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:13.270093
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:15:19.785955
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:15:27.055174
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test a valid template
    template = utils.find_template('tests/test-repo-pre/')
    assert template == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'

    # Test an invalid template
    try:
        template = utils.find_template('tests/fake-repo-tmpl/')
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'NonTemplatedInputDirException not raised'

# Generated at 2022-06-17 17:15:31.091999
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:15:39.909124
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-17 17:15:49.379351
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}',
    )
    assert project_template == expected_project_template

# Generated at 2022-06-17 17:16:00.333774
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct directory."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

    assert find_template(repo_dir) == os.path.join(
        repo_dir,
        'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:16:10.920926
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a sub-directory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a non-templated directory inside the temporary directory
    non_templated_dir = os.path.join(repo_dir, 'myproject')
    os.makedirs(non_templated_dir)

    # Create a templated directory inside the temporary directory
    templated_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:16.388822
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path to the template."""
    from cookiecutter.tests.test_utils import make_repo
    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:24.962287
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:16:31.850196
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:16:42.987176
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test with a non-templated input directory
    repo_dir = utils.workaround_mac_python_bug(
        os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'))
    )
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException not raised')

    # Test with a templated input directory

# Generated at 2022-06-17 17:16:53.308274
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:17:03.406953
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
        os.makedirs(os.path.join(repo_dir, 'foobar'))

        assert find_template(repo_dir) == os.path.join(
            repo_dir, 'cookiecutter-pypackage'
        )
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:17:10.038878
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:17:20.684311
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.main import cookiecutter

    # Create a fake project
    fake_project = cookiecutter('tests/fake-repo-tmpl/', no_input=True)

    # Test that find_template returns the correct path
    assert find_template(fake_project) == os.path.join(
        fake_project, 'fake-project-{{cookiecutter.repo_name}}'
    )

    # Test that find_template raises an exception if no template is found
    utils.rmtree(fake_project)
    fake_project = cookiecutter('tests/fake-repo-no-tmpl/', no_input=True)

# Generated at 2022-06-17 17:17:27.113334
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre/',
    ))
    project_template = os.path.join(repo_dir, 'fake-project-{{cookiecutter.repo_name}}')

    assert utils.find_template(repo_dir) == project_template


# Generated at 2022-06-17 17:17:32.303921
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:40.729909
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 17:17:50.484135
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:17:56.753203
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:10.066142
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary git repo
    repo_dir = os.path.join(utils.workdir, 'fake-repo')
    utils.make_sure_path_exists(repo_dir)
    utils.workdir = repo_dir
    utils.run_command('git init')
    utils.run_command('touch README.md')
    utils.run_command('git add .')
    utils.run_command('git commit -m "Initial commit"')

    # Create a temporary directory to clone the repo into

# Generated at 2022-06-17 17:18:20.061016
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a directory inside the temporary directory
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)

    # Create a directory inside the repo_dir
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)

    # Test the find_template function
    assert find_template(repo_dir) == project_template

    # Remove the temporary directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 17:18:26.785791
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:18:30.906622
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    assert find_template(repo_dir) == template_dir

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:18:36.647220
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        remove_repo(repo_dir)

# Generated at 2022-06-17 17:18:41.148213
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import tempfile
    import shutil
    import os

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)

    assert find_template(repo_dir) == template_dir

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:18:50.601781
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    )
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-no-tmpl')
    )

# Generated at 2022-06-17 17:18:53.851937
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct project template."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:09.263540
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.main import cookiecutter

    # Create a fake cookiecutter template in tmp
    cookiecutter('tests/fake-repo-pre/', no_input=True)

    # Test the find_template function
    template_dir = find_template('tests/fake-repo-pre/')
    assert template_dir == 'tests/fake-repo-pre/fake-project'

# Generated at 2022-06-17 17:19:13.567398
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the correct path."""
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_DIR
    template_dir = find_template(TEST_TEMPLATE_DIR)
    assert template_dir == os.path.join(TEST_TEMPLATE_DIR, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:21.054174
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:19:27.121459
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'foobar'))
    os.makedirs(os.path.join(repo_dir, 'baz'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-17 17:19:33.195794
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary directory inside the temporary directory
    temp_dir_2 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory inside the temporary directory
    temp_dir_3 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory inside the temporary directory
    temp_dir_4 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory inside the temporary directory
    temp_dir_5 = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary directory inside the temporary directory
    temp

# Generated at 2022-06-17 17:19:40.014337
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:42.527516
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter import utils

    repo_dir = make_repo()
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:19:53.372913
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:20:00.398179
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-17 17:20:07.138910
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:20.570374
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:25.635066
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:20:33.992848
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-17 17:20:40.241077
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-pre',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__),
        'tests',
        'test-repo-post',
    )
    project_template = find_template(repo_dir)

# Generated at 2022-06-17 17:20:48.992464
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.tests.test_find import make_repo
    from cookiecutter.tests.test_find import remove_repo

    repo_dir = make_repo()
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    remove_repo(repo_dir)

# Generated at 2022-06-17 17:20:55.220687
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:02.379015
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct path."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-data',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(
        repo_dir,
        'cookiecutter-pypackage'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-17 17:21:11.694543
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-17 17:21:16.049987
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-17 17:21:20.344516
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre/') != 'tests/fake-repo-pre/'