

# Generated at 2022-06-25 15:22:04.756345
# Unit test for function find_template

# Generated at 2022-06-25 15:22:05.796292
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:08.073850
# Unit test for function find_template
def test_find_template():
    assert True

# Generated at 2022-06-25 15:22:16.773789
# Unit test for function find_template
def test_find_template():
    dict_0 = {}
    dict_1 = {"": "", "": "", "": "", "": "", "": "", "": "", "": "", "": ""}
    dict_2 = {"": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": ""}
    dict_3 = {"": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": "", "": ""}

# Generated at 2022-06-25 15:22:17.578647
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:22:18.625924
# Unit test for function find_template
def test_find_template():
    num = 5
    for i in range(num):
        test_case_0()

# Generated at 2022-06-25 15:22:24.936345
# Unit test for function find_template
def test_find_template():
    assert(find_template("C:\\Users\\dell\\Desktop\\cookiecutter-django-crud") == "C:\\Users\\dell\\Desktop\\cookiecutter-django-crud\\cookiecutter-django-crud")
    assert(find_template("/home/user/cookiecutter-django-crud") == "/home/user/cookiecutter-django-crud/cookiecutter-django-crud")

# Generated at 2022-06-25 15:22:27.567933
# Unit test for function find_template
def test_find_template():
    test_case_0()



# Generated at 2022-06-25 15:22:32.950751
# Unit test for function find_template
def test_find_template():
    dict_0 = {}
    var_0 = find_template(dict_0)
    assert var_0 is not None

# Generated at 2022-06-25 15:22:34.896870
# Unit test for function find_template
def test_find_template():
    dict_0 = {}

    # Call function with argument dict_0
    find_template(dict_0)



# Generated at 2022-06-25 15:22:38.423336
# Unit test for function find_template
def test_find_template():
    assert find_template('test') == 'test/cookiecutter-test'


# Generated at 2022-06-25 15:22:40.378149
# Unit test for function find_template
def test_find_template():
    # If the function does not return a value, test that it raises an exception.
    with raises(Exception):
        find_template()

# Generated at 2022-06-25 15:22:41.222791
# Unit test for function find_template
def test_find_template():
    assert True == True

# Unit testing 

# Generated at 2022-06-25 15:22:47.963422
# Unit test for function find_template
def test_find_template():
    # Unit test for function find_template
    import copy
    import sys
    import os
    import random
    import unittest
    from contextlib import contextmanager
    from io import StringIO
    import traceback
    from test import support
    from cookiecutter.exceptions import NonTemplatedInputDirException


    class TestException(Exception): pass


    class TestCase(unittest.TestCase):

        def setUp(self):
            self.buffer = StringIO()
            self.stream = copy.copy(sys.stderr)
            sys.stderr = self.buffer

        def tearDown(self):
            self.buffer.close()
            self.stream.close()
            sys.stderr = self.stream

        @contextmanager
        def assertStderr(self, expected):
            old_st

# Generated at 2022-06-25 15:22:57.847107
# Unit test for function find_template
def test_find_template():
    #print("in function test_find_template()")
    test_cases = [
        {
            'name': 'test_case_0',
            'repo_dir': '.',
            'output': '.',
            'return-code': 0,  # return-code of 0 means success
            'msg': 'Cookiecutter template found in %s'
        },
    ]

    # write unit tests
    for test_case in test_cases:
        if (test_case['return-code'] != 0):
            print("Error in Unit Test: %s" % test_case)
        else:
            print("Unit Test: %s" % test_case)

    # execute unit tests
    for test_case in test_cases:
        int_0 = test_case['repo_dir']
        var_0

# Generated at 2022-06-25 15:23:06.032896
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 15:23:07.049711
# Unit test for function find_template
def test_find_template():
    assert find_template("/test-repo") == "/test-repo/{{cookiecutter.project_slug}}"


# Generated at 2022-06-25 15:23:09.553841
# Unit test for function find_template
def test_find_template():
    print('Testing function find_template with input:')
    print('Expected output: cookiecutter/{{cookiecutter.repo_name}}')
    print('Actual output: ' + find_template('cookiecutter'))

# Generated at 2022-06-25 15:23:16.858583
# Unit test for function find_template
def test_find_template():
    test_cases = [
        # Normalize
        {
            "test_case_name":"test_case_0",
            "function_inputs":{"repo_dir":None},
            "function_outputs":{},
            "function_side_effects":{}
        },

    ]
    for test_case in test_cases:
        locals()[test_case["test_case_name"]]()

# Generated at 2022-06-25 15:23:21.795359
# Unit test for function find_template
def test_find_template():
    int_0 = "env_0"
    var_0 = find_template(int_0)
    assert var_0 == "env_0/cookiecutter-{{cookiecutter.project_slug}}"

# Generated at 2022-06-25 15:23:28.298938
# Unit test for function find_template
def test_find_template():
    import os
    this_dir = os.path.dirname(__file__)
    repo_dir = os.path.join(this_dir, 'test_repo')
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-25 15:23:36.436659
# Unit test for function find_template
def test_find_template():
    import unittest
    import builtins
    import mock

    class TestCase(unittest.TestCase):

        def test_find_template(self):

            real_open = open

            class OpenMock(object):

                # This function takes a file name and returns a file-like object
                def __call__(self, *args, **kwargs):
                    # Get the file name from the arguments
                    file_name = args[0]
                    if file_name == 'cookiecutter/tests/test-case-1/README.md':
                        # If the file name is the README file, return a file-like object
                        # containing the expected file contents
                        file_like_object = real_open(
                            file_name,
                            mode='r'
                        )
                        return file_like_object

# Generated at 2022-06-25 15:23:41.085832
# Unit test for function find_template
def test_find_template():
    # Error cases
    test_case_0()

    # Normal case
    # int_1 = 'tests/test_repos/long-description'
    # var_1 = find_template(int_1)
    # assert var_1 == os.path.join('tests/test_repos/long-description', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:23:43.234421
# Unit test for function find_template
def test_find_template():
    # Test case 0
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass



# Generated at 2022-06-25 15:23:44.079664
# Unit test for function find_template
def test_find_template():
    assert find_template("github") == None


# Generated at 2022-06-25 15:23:47.215052
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(os.path.expanduser('~'), 'cookiecutter-django')) == os.path.join(os.path.expanduser('~'), 'cookiecutter-django', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:23:49.734746
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        print("NonTemplatedInputDirException in function find_template")

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:50.502572
# Unit test for function find_template
def test_find_template():
    assert True == True


# Generated at 2022-06-25 15:23:54.450956
# Unit test for function find_template
def test_find_template():
    input_0 = '~/repos/cookiecutter/cookiecutter-pypackage/'
    expected_output = os.path.join(input_0, '{{cookiecutter.project_slug}}')
    actual_output = find_template(input_0)
    assert actual_output == expected_output


# Generated at 2022-06-25 15:23:59.805605
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:24:05.354253
# Unit test for function find_template
def test_find_template():
    assert 'git' in find_template('git@github.com:user/repo.git')

# Generated at 2022-06-25 15:24:07.083269
# Unit test for function find_template
def test_find_template():
    import pytest
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()

# Generated at 2022-06-25 15:24:16.489867
# Unit test for function find_template
def test_find_template():
    import shlex
    import subprocess
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_dir:
        subprocess.call(shlex.split('mkdir ' + tmp_dir + '/project_template'))
        subprocess.call(shlex.split('touch ' + tmp_dir + '/project_template/{{cookiecutter.name}}'))
        expected_output = tmp_dir + '/project_template'
        assert(find_template(tmp_dir) == expected_output)


# Generated at 2022-06-25 15:24:27.104699
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    TEST_CASES = [
        # (input_dir, output_dir),
        (os.path.join('tests', 'files', 'fake-repo-pre'),
            os.path.join('tests', 'files', 'fake-repo-pre', '{{cookiecutter.repo_name}}')),
        (os.path.join('tests', 'files', 'fake-repo-post'),
            os.path.join('tests', 'files', 'fake-repo-post', 'fake-repo-post')),
    ]

    for (input_dir, output_dir) in TEST_CASES:
        result = find_template(input_dir)
        assert result == output_dir

# Generated at 2022-06-25 15:24:33.662463
# Unit test for function find_template

# Generated at 2022-06-25 15:24:41.121626
# Unit test for function find_template
def test_find_template():
    test_cases = [
        {
            'desc': 'TestCase 0',
            'inputs': [
                None
            ],
            'expected': NonTemplatedInputDirException()
        }
    ]


# Generated at 2022-06-25 15:24:43.852493
# Unit test for function find_template
def test_find_template():
    assert find_template("/Users/kevin/cookiecutters/cookiecutter-pypackage") == "/Users/kevin/cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}"



# Generated at 2022-06-25 15:24:44.651293
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir) == "path"

# Generated at 2022-06-25 15:24:48.128299
# Unit test for function find_template
def test_find_template():
    # Not a repo dir.
    try:
        find_template
    except NameError as e:
        assert True
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)
    # Empty repo dir.
    assert find_template('.')
    # None.
    try:
        test_case_0()
    except NonTemplatedInputDirException as e:
        assert True
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)

# Generated at 2022-06-25 15:24:51.734447
# Unit test for function find_template
def test_find_template():
    home = os.path.expanduser('~')
    repo_dir = os.path.join(
        home,
        'repos',
        'cookiecutter-shogbot',
    )
    print(repo_dir)
    print(find_template(repo_dir))


# Generated at 2022-06-25 15:24:58.978107
# Unit test for function find_template
def test_find_template():
    if not os.path.exists('cookiecutter-pypackage'):
        os.system('git clone https://github.com/audreyr/cookiecutter-pypackage.git')
    assert 'cookiecutter-pypackage/{{cookiecutter.repo_name}}' == find_template('cookiecutter-pypackage')
    os.system('rm -rf cookiecutter-pypackage')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:25:03.340962
# Unit test for function find_template
def test_find_template():
    array_0 = os.listdir('{{ cookiecutter.repo_name }}')
    for item in array_0:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            assert item == 'cookiecutter.json'
            break
        else:
            assert False

# Generated at 2022-06-25 15:25:03.951671
# Unit test for function find_template
def test_find_template():
    unittest.main()

# Generated at 2022-06-25 15:25:06.947836
# Unit test for function find_template
def test_find_template():
    os.chdir("/data/git/cookiecutter-data-science")
    a = find_template('./')
    print(a)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 15:25:17.342238
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None
    assert find_template('/Users/rogue/repos/cookiecutter-pypackage') == '/Users/rogue/repos/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    try:
        assert find_template('/Users/rogue/repos/cookiecutter-pypackage/') == '/Users/rogue/repos/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    except NonTemplatedInputDirException as e:
        print(e)

# test_case_0()
# test_find_template()

# Generated at 2022-06-25 15:25:20.373619
# Unit test for function find_template
def test_find_template():
    int_0 = "./tests/test-repo"
    var_0 = find_template(int_0)
    assert('tests/test-repo/{{cookiecutter.repo_name}}' == var_0)
    pass

# Generated at 2022-06-25 15:25:27.711840
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None


if __name__ == '__main__':
    logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.DEBUG)
    create_dir_if_needed(input_dir)
    repo_dir = clone(input_dir, checkout=checkout)

    if not no_input:
        # Find the project template
        project_template = find_template(repo_dir)
        dict_var = dict_var or os.path.join(project_template, 'cookiecutter.json')

        if not os.path.isfile(dict_var):
            raise InvalidModeException(
                "Couldn't find 'cookiecutter.json' in {0}".format(project_template)
            )

        # Load in the dictionary for the cookie

# Generated at 2022-06-25 15:25:32.068380
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


# Program entry
if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:25:33.320959
# Unit test for function find_template
def test_find_template():
    assert find_template() == None

# Test Test_Case_0

# Generated at 2022-06-25 15:25:41.909181
# Unit test for function find_template
def test_find_template():
    class_0 = find_template('/home/ben/Desktop/test/test/test_template')
    assert class_0 == '/home/ben/Desktop/test/test/test_template/test_template'
    class_1 = find_template('/home/ben/Desktop/test/test/test_template_with_name')
    assert class_1 == '/home/ben/Desktop/test/test/test_template_with_name/test_template_with_name'
    class_2 = find_template('/home/ben/Desktop/test/test/test_template_with_slash')
    assert class_2 == '/home/ben/Desktop/test/test/test_template_with_slash/test_template_with_slash'

# Generated at 2022-06-25 15:25:55.372982
# Unit test for function find_template
def test_find_template():
    assert find_template (test_case_0()) == 'None', "the result is not as expected"
    return


# Unit Test
print("--------------- Find template: Output result ------------------")
print(test_find_template())
print("---------------------------------------------------------------")

# Generated at 2022-06-25 15:26:00.411233
# Unit test for function find_template
def test_find_template():
    """Test the functionality and output of ``find_template``."""
    repo_dir = ''
    result = find_template(repo_dir)
    assert result == None

# Generated at 2022-06-25 15:26:01.317445
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:26:11.827717
# Unit test for function find_template
def test_find_template():
    assert find_template("/root/dev/github/customer/customer-repo/cookiecutter-rep") == "/root/dev/github/customer/customer-repo/cookiecutter-rep/cookiecutter-rep"
    assert find_template("/root/dev/github/customer/customer-repo/customer-rep") == False

# argparse
# https://docs.python.org/3/library/argparse.html
import argparse

parser = argparse.ArgumentParser(description='Process some integers.')
parser.add_argument('repo_dir', metavar='REPO_DIR', type=find_template, nargs='+',
                    help='an integer for the accumulator')



# Generated at 2022-06-25 15:26:22.500983
# Unit test for function find_template
def test_find_template():

    # Normal case, one directory
    test_dict = {
        'repo_dir': 'tests/test-data/repo-tmpl',
        'expected': 'tests/test-data/repo-tmpl/{{cookiecutter.repo_name}}'
    }
    check_find_template(test_dict)

    # Normal case, multiple directories
    test_dict = {
        'repo_dir': 'tests/test-data/repo-tmpl-complex',
        'expected': 'tests/test-data/repo-tmpl-complex/{{cookiecutter.repo_name}}'
    }
    check_find_template(test_dict)

    # Normal case, no directories, one file

# Generated at 2022-06-25 15:26:23.795487
# Unit test for function find_template
def test_find_template():
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()

# Generated at 2022-06-25 15:26:33.849756
# Unit test for function find_template
def test_find_template():
    if not os.path.exists("/home/travis/build/stephenmcd/cookiecutter-pypackage/tests/fake-repo-pre/{{cookiecutter.repo_name}}"):
        raise Exception("No such file or directory")
    int_1 = '/home/travis/build/stephenmcd/cookiecutter-pypackage/tests/fake-repo-pre'
    var_1 = find_template(int_1)
    if var_1 != '/home/travis/build/stephenmcd/cookiecutter-pypackage/tests/fake-repo-pre/{{cookiecutter.repo_name}}':
        raise Exception("test_find_template (cookiecutter.finders)")

test_find_template()

# Generated at 2022-06-25 15:26:35.319267
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/flisakowski/Documents/github/com.pydanny') == None

# Generated at 2022-06-25 15:26:37.373105
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        if "None" not in str(e):
            raise e

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:45.030070
# Unit test for function find_template
def test_find_template():
    repo_dir = "/home/sam/Documents/Projects/cookiecutter/cookiecutter/tests/test-repo-pre/{{cookiecutter.repo_name}}/new"
    project_template = find_template(repo_dir)
    assert project_template == "/home/sam/Documents/Projects/cookiecutter/cookiecutter/tests/test-repo-pre/{{cookiecutter.repo_name}}/new/cookiecutter-pypackage"

# Generated at 2022-06-25 15:27:08.179823
# Unit test for function find_template
def test_find_template():
    try:
        import pytest
        from mock import patch

        with patch("os.listdir") as os_listdir:
            os_listdir.return_value = ["cookiecutter-pypackage"]
            assert find_template("/new_repo") == "/new_repo/cookiecutter-pypackage"
    except ImportError:
        print("Could not import pytest or mock, skipping tests.")


# Generated at 2022-06-25 15:27:11.825788
# Unit test for function find_template
def test_find_template():
    assert find_template('test/test_atomic_cookiecutter/test_repo') == \
           'test/test_atomic_cookiecutter/test_repo/{{cookiecutter.project_name}}'


# Generated at 2022-06-25 15:27:16.741760
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/nimit/Desktop/Cookiecutter-Udacity/cookiecutter-udacity-master/') == '/home/nimit/Desktop/Cookiecutter-Udacity/cookiecutter-udacity-master/cookiecutter-project'

# Generated at 2022-06-25 15:27:18.507147
# Unit test for function find_template
def test_find_template():
    int_0 = 'dir/dir/dir'
    var_0 = find_template(int_0)


# Generated at 2022-06-25 15:27:22.459085
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/mohit/cookiecutter-django/tests') == '/home/mohit/cookiecutter-django/tests/{{cookiecutter.project_name}}'
    with pytest.raises(NonTemplatedInputDirException):
        find_template("/home/mohit/cookiecutter-django/")

# Generated at 2022-06-25 15:27:23.692150
# Unit test for function find_template
def test_find_template():
    assert find_template("repo_dir") == "project_template"

# Generated at 2022-06-25 15:27:25.859385
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:27:29.309624
# Unit test for function find_template
def test_find_template():
    int_0 = './test/test_repos/fake-repo'
    var_0 = find_template(int_0)
    assert var_0 == './test/test_repos/fake-repo/cookiecutter-fake'


# Generated at 2022-06-25 15:27:35.155332
# Unit test for function find_template
def test_find_template():
    # Setup the parameters and expected results for the test case
    int_0 = "templates/python"
    str_0 = find_template(int_0)
    str_1 = "templates/python/cookiecutter-pypackage"
    print(str_0)
    print(str_1)
    # Try to do the test

# Generated at 2022-06-25 15:27:39.157179
# Unit test for function find_template
def test_find_template():
    repo_dir = None
    var_0 = find_template(repo_dir)
    assert var_0 is None

# Generated at 2022-06-25 15:28:01.968526
# Unit test for function find_template
def test_find_template():
    """Test that ``find_template`` works for a very simple template."""

    logger.debug(find_template(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-find-template')))

    assert find_template(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-find-template')) == \
        os.path.join(
            os.path.dirname(__file__), '..', 'tests',
            'test-find-template',
            'awesome-project-template'
        )

# Generated at 2022-06-25 15:28:08.767204
# Unit test for function find_template
def test_find_template():
    int_0 = 'C:\\Users\\XFINITY\\Documents\\Projects\\GitHub\\Cookiecutter\\cookiecutter\\tests\\test_dir'
    var_0 = find_template(int_0)

    assert var_0 == 'C:\\Users\\XFINITY\\Documents\\Projects\\GitHub\\Cookiecutter\\cookiecutter\\tests\\test_dir\\{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:28:12.913400
# Unit test for function find_template
def test_find_template():
    assert find_template(os.getcwd()) is True
    assert find_template(None) is False
    assert find_template(int) is False
    assert find_template(str) is False
    assert find_template(list) is False
    assert find_template(dict) is False

# Generated at 2022-06-25 15:28:18.802635
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        print("Failed test case 0. Expected NonTemplatedInputDirException")

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:28:31.751085
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.utils import make_sure_path_exists

    temp_dir = tempfile.mkdtemp()
    template_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    make_sure_path_exists(template_dir)

    # Templates can contain {{}} in their names.
    assert find_template(temp_dir) == template_dir

    non_templated_dir = os.path.join(temp_dir, 'this-repo-name-is-not-templated')
    make_sure_path_exists(non_templated_dir)

    import pytest
    with pytest.raises(NonTemplatedInputDirException):
        find_template(temp_dir)

    import shutil
   

# Generated at 2022-06-25 15:28:33.100349
# Unit test for function find_template
def test_find_template():
    assert find_template('/path/to/file') is not None


# Generated at 2022-06-25 15:28:36.943923
# Unit test for function find_template
def test_find_template():
    int_0 = 'C:\\Users\\Daniel_Lee\\Desktop\\cookiecutter-pypackage-docs\\tests\\fixtures\\git-repos\\empty-repo'
    var_0 = find_template(int_0)


# Generated at 2022-06-25 15:28:37.601319
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir)
    return None

# Generated at 2022-06-25 15:28:42.699675
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    import json
    import os
    import shutil
    import sys
    import tempfile
    import time
    import unittest
    from unittest.mock import patch

    import pdb
    from pprint import pformat

    #
    # Mock related code
    #

    class MockRepo(object):
        def __init__(self):
            self.repo_dir = None
            self.is_zipfile = False
            self.commit_id = None

        def clone_to(self, repo_dir):
            self.repo_dir = repo_dir

# Generated at 2022-06-25 15:28:45.994527
# Unit test for function find_template
def test_find_template():
    int_0 = 'test_repo' # directory name
    var_0 = find_template(int_0)

    assert var_0 == 'test_repo/cookiecutter-{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:29:23.652910
# Unit test for function find_template
def test_find_template():
    int_0 = './tests/data'
    var_0 = find_template(int_0)
    var_0_expect = os.path.join(os.path.abspath('./tests/data'), '{{cookiecutter.repo_name}}')
    assert var_0 == var_0_expect

    # MOCK: raise NonTemplatedInputDirException
    # int_0 = './tests/data_error'
    # with assert_raises(NonTemplatedInputDirException):
    #     var_0 = find_template(int_0)
    

test_case_0()
test_find_template()

# Generated at 2022-06-25 15:29:30.637286
# Unit test for function find_template
def test_find_template():
    if __name__ == '__main__':
        import sys
        import pytest
        pytest.main(sys.argv)
    else:
        try:
            IntCaseObject = test_case_0()
        except:
            print('Not Passed!')
        else:
            print('Passed!')
test_find_template()

# Generated at 2022-06-25 15:29:39.584794
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    int_0 = ""
    with pytest.raises(NonTemplatedInputDirException) as e_info:
        var_0 = find_template(int_0)
    int_1 = "tests/test-repo-pre/fake-repo-tmpl"
    var_1 = find_template(int_1)
    assert var_1 == "tests/test-repo-pre/fake-repo-tmpl/cookiecutter-pypackage/"

    int_2 = "tests/test-repo-pre/fake-repo-tmpl-wo-hooks"
    var_2 = find_template(int_2)

# Generated at 2022-06-25 15:29:44.541513
# Unit test for function find_template
def test_find_template():
    if os.path.isdir('tests'):
        os.chdir('tests')

    # Create a dummy repository directory
    test_dir = 'r6'
    if os.path.isdir(test_dir):
        import shutil
        shutil.rmtree(test_dir)
    os.mkdir(test_dir)

    # Create a dummy project template inside repository directory
    project_template = '{{cookiecutter.project_name}}'
    open(os.path.join(test_dir, project_template), 'a').close()

    # Create a dummy non-project template inside repository directory
    non_project_template = '{{cookiecutter.project_slug}}'
    open(os.path.join(test_dir, non_project_template), 'a').close()

    # Test for a project template

# Generated at 2022-06-25 15:29:46.788895
# Unit test for function find_template
def test_find_template():
    with pytest.raises(Exception):
        test_case_0()

# Generated at 2022-06-25 15:29:51.104187
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/cskow/cookiecutter-test/cookiecutter-template'
    project_template = find_template(repo_dir)
    project_template_correct = '/home/cskow/cookiecutter-test/cookiecutter-template/{{cookiecutter.repo_name}}'
    assert project_template == project_template_correct


# Generated at 2022-06-25 15:29:54.552567
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-find-template') == 'tests/test-find-template/{{cookiecutter.project_slug}}'

# Coverage test for function find_template

# Generated at 2022-06-25 15:30:02.215384
# Unit test for function find_template
def test_find_template():
    int_0 = "/Users/erik/Documents/GitHub/cookiecutter-python-package"
    var_0 = find_template(int_0)
    var_1 = "/Users/erik/Documents/GitHub/cookiecutter-python-package/{{cookiecutter.repo_name}}"

    assert var_0 == var_1


test_find_template()

# Generated at 2022-06-25 15:30:07.165432
# Unit test for function find_template
def test_find_template():
    int_0 = 1
    var_0 = find_template(int_0)

    if var_0:
        print ("Test case 0 passed!")
    else:
        print ("Test case 0 failed!")



# Generated at 2022-06-25 15:30:16.232835
# Unit test for function find_template
def test_find_template():
    import mock
    import os
    import pytest

    logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.DEBUG)

    # Create a list of the test input file names
    test_input_file = []
    test_input_file.append('test_input_0')
    test_input_file.append('test_input_1')
    test_input_file.append('test_input_2')

    # Create a list of the test input files
    test_input_dir = []
    for file in test_input_file:
        test_input_dir.append(file)

    # Create an empty list for the test output files
    test_output_dir = []

    # Create input file path

# Generated at 2022-06-25 15:31:30.941615
# Unit test for function find_template
def test_find_template():

    import CookieCutter
    import os, tempfile
    import shutil

    try:
        temp_directory = tempfile.mkdtemp()
        CookieCutter.main.cookiecutter(
            'https://github.com/audreyr/cookiecutter-pypackage.git',
            no_input=True,
            output_dir=temp_directory)
        CookieCutter.find_template(temp_directory)
    finally:
        shutil.rmtree(temp_directory)

    try:
        CookieCutter.find_template(temp_directory)
    except CookieCutter.NonTemplatedInputDirException:
        pass
    else:
        assert 0, "Did not raise NonTemplatedInputDirException"

# Generated at 2022-06-25 15:31:32.351374
# Unit test for function find_template
def test_find_template():

    assert find_template('test') == None

if __name__ == '__main__':
    test_find_template()




# Generated at 2022-06-25 15:31:37.411755
# Unit test for function find_template
def test_find_template():
    
    assert find_template("/home/example/project_dir")
    assert find_template("/home/example/project_dir/")

    try:
        find_template(None)
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-25 15:31:40.687736
# Unit test for function find_template
def test_find_template():
    import unittest

    class TestFind_Template(unittest.TestCase):
        def test_find_template(self):
            pass


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 15:31:41.962831
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False



# Generated at 2022-06-25 15:31:45.587011
# Unit test for function find_template
def test_find_template():
    int_0 = os.path.abspath('/Users/omar/temp/cookiecutter-test-repo')
    var_0 = find_template(int_0)
    assert var_0 == os.path.join(int_0, '{{cookiecutter.repo_name}}')


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 15:31:55.962328
# Unit test for function find_template

# Generated at 2022-06-25 15:31:58.262075
# Unit test for function find_template
def test_find_template():
    assert_equals(find_template('variable_0'), None)

# Useful for testing against a local clone of the repo.

# Generated at 2022-06-25 15:32:03.019840
# Unit test for function find_template
def test_find_template():
    int_0 = None
    # Function call:
    try:
        find_template(int_0)
    except NonTemplatedInputDirException as exc:
        assert exc.args[0] == "Input directory {0} does not appear to be a Cookiecutter template".format(None)
        assert exc.args[1] == "Input directory {0} does not appear to be a Cookiecutter template".format(None)
    # Test failed!
    # Check the exception message, and how did it come?

