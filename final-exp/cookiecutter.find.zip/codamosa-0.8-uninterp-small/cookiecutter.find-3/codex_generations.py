

# Generated at 2022-06-25 15:22:05.714211
# Unit test for function find_template
def test_find_template():
    str_0 = '/home/alex/Documents/Autobotz/prj/autobotz/cookiecutter-autobotz/cookiecutter-autobotz'
    var_0 = find_template(str_0)

# Generated at 2022-06-25 15:22:14.621070
# Unit test for function find_template
def test_find_template():
    str_0 = '/tmp/cookiecutter-test'
    var_0 = find_template(str_0)
    str_1 = '/tmp/cookiecutter-test/cookiecutter-pypackage'
    str_2 = 'cookiecutter-pypackage'
    assert var_0 == str_1, 'test_find_template: %s' % var_0
    assert os.path.basename(var_0) == str_2, 'test_find_template: %s' % os.path.basename(var_0)
    os.rmdir(str_0)
    return True


# Generated at 2022-06-25 15:22:18.827454
# Unit test for function find_template
def test_find_template():
    str_0 = 'C:\\Users\\nitin\\Documents\\projects\\cookiecutter-pypackage-minimal'
    var_0 = find_template(str_0)
    var_1 = 'C:\\Users\\nitin\\Documents\\projects\\cookiecutter-pypackage-minimal\\cookiecutter-pypackage-minimal'
    assert var_0 == var_1


# Generated at 2022-06-25 15:22:22.702112
# Unit test for function find_template

# Generated at 2022-06-25 15:22:29.834796
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """

    assert not find_template(None)

    assert find_template(Path('tests/test-repo/cookiecutter-postgrespy'))


if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:22:32.727907
# Unit test for function find_template
def test_find_template():
    try:
        find_template(None)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError('Should not have passed')

# Generated at 2022-06-25 15:22:38.006988
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException as e:
        logger.error(e)
    logger.info("Success! find_template works!\n")

if __name__ == '__main__':
    logger.info("Testing.")
    test_find_template()

# Generated at 2022-06-25 15:22:40.297221
# Unit test for function find_template
def test_find_template():
    str_1 = 'cookiecutter/tests/test-output/hook-no-repo/j/k'
    var_1 = find_template(str_1)


# Generated at 2022-06-25 15:22:42.984984
# Unit test for function find_template
def test_find_template():
    assert (find_template(None) == NonTemplatedInputDirException)
    assert (find_template('') == NonTemplatedInputDirException)
    assert (find_template('/dev/null') == NonTemplatedInputDirException)

# Generated at 2022-06-25 15:22:45.196491
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError("Could not trigger NonTemplatedInputDirException")

# Generated at 2022-06-25 15:22:57.075795
# Unit test for function find_template
def test_find_template():
    str_0 = None
    str_1 = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         'fake_repo_pre_0_dot_7_2')
    str_2 = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         'fake_repo_pre_0_dot_7_2_missing_hooks')

    try:
        find_template(str_0)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False

    assert find_template(str_1) == os.path.join(str_1, 'fake_project')


# Generated at 2022-06-25 15:23:06.648253
# Unit test for function find_template
def test_find_template():
    dirname = os.path.dirname(__file__)
    repo_dir = os.path.join(dirname, '..', 'cookiecutters', 'i18n', 'tests', 'test-repo-tmpl')
    project_template = 'cookiecutter-tests-{{cookiecutter.repo_name}}'
    project_template_path = os.path.join(repo_dir, project_template)
    assert find_template(repo_dir) == project_template_path

# Generated at 2022-06-25 15:23:08.626230
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        assert True


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:11.317470
# Unit test for function find_template
def test_find_template():
    str_0 = "/www/python/git_cookiecutter"
    var_0 = find_template(str_0)

# Generated at 2022-06-25 15:23:21.660928
# Unit test for function find_template
def test_find_template():
    str_0 = "abcd"
    var_0 = find_template(str_0)
    assert var_0 == "abcd"

# Case1: NonTemplatedInputDirException
# Case2: NonTemplatedInputDirException
# Case3: NonTemplatedInputDirException
# Case4: str_0 is empty
# Case5: str_0 is a number
# Case6: str_0 is a string
# Case7: str_0 is a bool
# Case8: str_0 is a list
# Case9: str_0 is a dict
# Case10: str_0 is none
# Case11: str_0 is a tuple


if __name__ == '__main__':
    str_0 = 'root'
    result = find_template(str_0)
    print(result)
    print

# Generated at 2022-06-25 15:23:31.376785
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/guglielmo/cookiecutter-pypackage') is None
    assert find_template('/home/guglielmo/cookiecutter-pypackage') is not None
    assert find_template('/home/guglielmo/cookiecutter-pypackage') != '/home/guglielmo/cookiecutter-pypackage'
    assert find_template('/home/guglielmo/cookiecutter-pypackage') == '/home/guglielmo/cookiecutter-pypackage'
    assert find_template('/home/guglielmo/cookiecutter-pypackage') != 'cookiecutter-pypackage'

# Generated at 2022-06-25 15:23:39.569872
# Unit test for function find_template
def test_find_template():
    #assert find_template('/') == False
    #assert find_template('/') == False
    #assert find_template('/') == False
    #assert find_template('/') == False
    #assert find_template('/') == False
    #assert find_template('/') == False
    #assert find_template('/') == False
    #assert find_template('/') == False
    #assert find_template('/') == False
    pass

# Generated at 2022-06-25 15:23:43.134165
# Unit test for function find_template
def test_find_template():
    var_0 = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_folders', 'test_0')
    var_1 = find_template(var_0)
    assert type(var_1) == str

# Generated at 2022-06-25 15:23:43.999605
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:23:45.463990
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-25 15:23:48.111689
# Unit test for function find_template
def test_find_template():
    assert find_template('ABCDEF') == None

# Generated at 2022-06-25 15:23:51.820594
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/jneal/projects/cookiecutter-pypackage'
    project_template = '/home/jneal/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert(project_template == find_template(repo_dir))

test_case_0()
test_find_template()

# Generated at 2022-06-25 15:23:52.538691
# Unit test for function find_template
def test_find_template():
    assert find_template() == 0

# Generated at 2022-06-25 15:23:53.405623
# Unit test for function find_template
def test_find_template():
    test_case_0()



# Generated at 2022-06-25 15:23:59.152007
# Unit test for function find_template
def test_find_template():
    import ctypes
    c_path = ctypes.create_string_buffer(b"\x00" * 512)
    libc = ctypes.CDLL("libc.so.6")
    libc.getcwd(c_path, ctypes.sizeof(c_path))
    str_0 = c_path.value.decode()
    var_0 = find_template(str_0)
    assert(var_0 == str_0)

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:24:00.585099
# Unit test for function find_template
def test_find_template():
    str_0 = None
    var_0 = find_template(str_0)



# Generated at 2022-06-25 15:24:01.617195
# Unit test for function find_template
def test_find_template():
    assert find_template('str_0') == None

# Generated at 2022-06-25 15:24:05.309369
# Unit test for function find_template
def test_find_template():
    str_0 = None
    var_0 = find_template(str_0)

if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:24:17.646882
# Unit test for function find_template
def test_find_template():
    tmp_dict = {
        'cookiecutter' : [
            'abc',
            'abc{{xyz}}',
            'abcxyz',
        ],
        'abc' : [],
        'abcxyz' : [],
    }
    test_cases = [('cookiecutter', 'cookiecutter/abc{{xyz}}'),
                  ('cookiecutter/abc/../', 'cookiecutter/abc{{xyz}}'),
                  ('cookiecutter/abcxyz', None), ]
    for case in test_cases:
        mocker.patch('os.listdir').return_value = tmp_dict[case[0]]
        if case[1] is not None:
            assert find_template(case[0]) == case[1]
        else:
            assert find_template(case[0]) is None

test

# Generated at 2022-06-25 15:24:19.164041
# Unit test for function find_template

# Generated at 2022-06-25 15:24:25.559054
# Unit test for function find_template
def test_find_template():
    str_0 = "n_Fo_GONpq\q^"
    var_0 = find_template(str_0)
    if (var_0 == str_0):
        print("Test 0: PASS")
    else:
        print("Test 0: FAIL")

# Executed from command line
test_find_template()

# Generated at 2022-06-25 15:24:29.587236
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/zhiwen/.cache/cookiecutters/cookiecutter-pylibrary/f87b9c9') == '/home/zhiwen/.cache/cookiecutters/cookiecutter-pylibrary/f87b9c9/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:24:36.439844
# Unit test for function find_template
def test_find_template():
    str_0 = "tests/files/fake-repo-pre/{{cookiecutter.repo_name}}"
    str_1 = "fake-repo-pre/{{cookiecutter.repo_name}}"
    var_0 = find_template(str_0)
    assert var_0 == str_1
    str_2 = "tests/files/fake-repo-pre"
    str_3 = "fake-repo-pre/{{cookiecutter.repo_name}}"
    var_1 = find_template(str_2)
    assert var_1 == str_3

# Generated at 2022-06-25 15:24:41.579607
# Unit test for function find_template
def test_find_template():
    # This can only test that the exception is raised.
    str_0 = None
    try:
        find_template(str_0)
    except NonTemplatedInputDirException:
        pass
    except:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-25 15:24:47.878060
# Unit test for function find_template
def test_find_template():
    '''
    Unit test for function find_template
    '''
    try:
        test_case_0()
    except NonTemplatedInputDirException as error:
        print("Exception Error!")

# Call the main() function to begin the program.
if __name__ == '__main__':
    print("Test case function find_template: ")
    test_find_template()

# Generated at 2022-06-25 15:24:51.193171
# Unit test for function find_template
def test_find_template():
    from cookiecutter.unit.find import find_template

    project_template = find_template('tests/files/fake-repo-pre/')
    assert project_template == 'tests/files/fake-repo-pre/{{cookiecutter.repo_name}}'



# Generated at 2022-06-25 15:24:55.685969
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template(None) == None
    except NonTemplatedInputDirException:
        pass

    try:
        assert find_template('') == None
    except NonTemplatedInputDirException:
        pass

    try:
        assert find_template('/tmp') == None
    except NonTemplatedInputDirException:
        pass


if __name__ == '__main__':
    logging.basicConfig(format='TEST %(message)s', level=logging.INFO)

    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:25:04.941406
# Unit test for function find_template
def test_find_template():
    str_0 = None
    var_0 = find_template(str_0)
    assert(var_0 == None)


# def test_case_1():
#     str_0 = None
#     var_0 = find_template(str_0)


# def test_case_2():
#     str_0 = None
#     var_0 = find_template(str_0)


# def test_case_3():
#     str_0 = None
#     var_0 = find_template(str_0)


# def test_case_4():
#     str_0 = None
#     var_0 = find_template(str_0)



# Generated at 2022-06-25 15:25:06.736940
# Unit test for function find_template
def test_find_template():
    template = find_template('C:\\Users\\Lei\\Desktop\\pre-work')
    print(template)

# Generated at 2022-06-25 15:25:12.307595
# Unit test for function find_template
def test_find_template():

    str_0 = None
    try:
        find_template(str_0)
    except NonTemplatedInputDirException as non_templated_input_dir_exception_0:
        print(non_templated_input_dir_exception_0.message)

# Generated at 2022-06-25 15:25:19.350501
# Unit test for function find_template
def test_find_template():
    # assert find_template('str_0') == 'app_0'
    assert find_template('str_0') == 'app_0'


# Generated at 2022-06-25 15:25:20.590916
# Unit test for function find_template
def test_find_template():
    # Test with a None string
    test_case_0()

# Generated at 2022-06-25 15:25:23.372875
# Unit test for function find_template
def test_find_template():
    str_0 = '/home/lhoussaine/cookiecutter-django-bare'
    var_0 = find_template(str_0)

# Generated at 2022-06-25 15:25:24.073651
# Unit test for function find_template
def test_find_template():
    assert find_template('test_case_0') == None

# Generated at 2022-06-25 15:25:29.269228
# Unit test for function find_template
def test_find_template():
    str_0 = "C:\\Users\\Derek\\PycharmProjects\\cookiecutter"
    var_0 = find_template(str_0)
    print(var_0)


if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:25:39.199092
# Unit test for function find_template
def test_find_template():
    """Tests find_template function."""
    str_0 = None
    exc = None
    try:
        find_template(str_0)
    except Exception as err:
        exc = err
    assert exc
    assert isinstance(exc, NonTemplatedInputDirException)
    assert exc.args[0] == 'Failed to find a project template in the input dir.'

    str_0 = '.git/refs/heads/master'
    exc = None
    try:
        find_template(str_0)
    except Exception as err:
        exc = err
    assert exc
    assert isinstance(exc, NonTemplatedInputDirException)
    assert exc.args[0] == 'Failed to find a project template in the input dir.'


# Generated at 2022-06-25 15:25:45.686924
# Unit test for function find_template
def test_find_template():
    str_0 = "fgr"
    # str_0 = "G:/data/cookie/bobby/github/cookiecutter-django/tests/test-repo"

    try:
        var_0 = find_template(str_0)
    except Exception:
        import traceback
        # raise
        traceback.print_exc()
    # assert var_0 == 'test_project'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:25:51.035778
# Unit test for function find_template

# Generated at 2022-06-25 15:25:54.045426
# Unit test for function find_template
def test_find_template():

    str_0 = '2018-09-06'
    var_0 = find_template(str_0)
    str_1 = 'C:\\Users\\user\\AppData\\Local\\Temp\\cookiecutter-2018-09-06'
    var_1 = find_template(str_1)

# Generated at 2022-06-25 15:26:00.114596
# Unit test for function find_template
def test_find_template():
    print("START")
    test_case_0()
    print("END")
if __name__ == '__main__':
    test_find_template()

# pytest --cov=cookiecutter/utils/finders tests/utils/test_finders.py

# Generated at 2022-06-25 15:26:08.689815
# Unit test for function find_template
def test_find_template():
    assert find_template(None)
    #raise NotImplementedError()



# Generated at 2022-06-25 15:26:13.696952
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\\Users\\dell\\Desktop\\cookiecutter-master\\tests\\test_project\\input\\git_repo') == 'C:\\Users\\dell\\Desktop\\cookiecutter-master\\tests\\test_project\\input\\git_repo\\cookiecutter-pypackage{{cookiecutter.project_name}}'


# Unit test with pytest for function find_template

# Generated at 2022-06-25 15:26:16.002338
# Unit test for function find_template
def test_find_template():
    str_1 = 'repo_dir'
    try:
        var_1 = find_template(str_1)
        assert False
    except NonTemplatedInputDirException:
        assert True



# Generated at 2022-06-25 15:26:22.414772
# Unit test for function find_template
def test_find_template():
    with mock.patch('os.listdir', return_value = ['abcdefg', 'hijklm']) as mock_listdir:
        with pytest.raises(NonTemplatedInputDirException):
            find_template('some_dir')

# Generated at 2022-06-25 15:26:23.839087
# Unit test for function find_template
def test_find_template():
    cases = [
        {'input': None, 'expected': None, 'error': TypeError}
    ]

    for case in cases:
        with pytest.raises(case['error']):
            assert find_template(case['input']) == case['expected']

# Generated at 2022-06-25 15:26:29.248992
# Unit test for function find_template
def test_find_template():
    try:
        with open(r'./tests/fixtures/repo/{{cookiecutter.repo_name}}.tmpl.ace', 'r') as test_file:
            assert (find_template("./tests/fixtures/repo") == test_file.name)
    except NonTemplatedInputDirException:
        assert False
    else:
        assert True

# Generated at 2022-06-25 15:26:36.743705
# Unit test for function find_template
def test_find_template():
    str_0 = '/Users/aaron/Dropbox/Programming/python/cookiecutter/tests/'
    str_0 = str_0 + 'test-repo-pre/{{cookiecutter.repo_name}}'
    var_0 = find_template(str_0)
    assert var_0 == '/Users/aaron/Dropbox/Programming/python/cookiecutter'
    assert var_0 == '/Users/aaron/Dropbox/Programming/python/cookiecutter'
    assert var_0 == '/Users/aaron/Dropbox/Programming/python/cookiecutter'
    assert var_0 == '/Users/aaron/Dropbox/Programming/python/cookiecutter'


# Generated at 2022-06-25 15:26:39.274429
# Unit test for function find_template
def test_find_template():
    assert find_template(None)== NonTemplatedInputDirException

# Generated at 2022-06-25 15:26:40.739839
# Unit test for function find_template
def test_find_template():
    str_1 = "C:\Python34\\Lib\\cookiecutter\\_cookiecutter.py"
    var_0 = find_template(str_1)



# Generated at 2022-06-25 15:26:43.101035
# Unit test for function find_template
def test_find_template():
    with pytest.raises(RuntimeError):
        test_case_0()

# Compiled version of test_find_template

# Generated at 2022-06-25 15:26:57.511055
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:27:04.758298
# Unit test for function find_template
def test_find_template():
    str_0 = None
    var_0 = find_template(str_0)
    assert var_0 == "b", "Return value was: " + var_0 + "Expected: " + "b"


test_find_template()

# Generated at 2022-06-25 15:27:10.387375
# Unit test for function find_template
def test_find_template():
    assert find_template('/private/var/folders/2x/k3l_918d3fj5y5tlpzc1rf7h0000gq/T/tmp_m6xhxx/{{project_name}}') == '/private/var/folders/2x/k3l_918d3fj5y5tlpzc1rf7h0000gq/T/tmp_m6xhxx/{{project_name}}'

test_case_0()

# Generated at 2022-06-25 15:27:21.142070
# Unit test for function find_template
def test_find_template():
    assert find_template('/usr/local/lib/python2.7/dist-packages/cookiecutter-1.6.0-py2.7.egg/tests/fake-repo-tmpl/') == '/usr/local/lib/python2.7/dist-packages/cookiecutter-1.6.0-py2.7.egg/tests/fake-repo-tmpl/obscure-package-name'

# Generated at 2022-06-25 15:27:25.391306
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/xuyu/github/cookiecutter/tests/test-data/test-case-0') == '/Users/xuyu/github/cookiecutter/tests/test-data/test-case-0/{{cookiecutter.project_name}}-cookiecutter'



# Generated at 2022-06-25 15:27:30.873535
# Unit test for function find_template
def test_find_template():
    str_0 = str("/var/folders/lc/9qf3qdjl6rg8kjb75pjgrx300000gn/T/tmprKlZk0")
    var_0 = find_template(str_0)
    assert os.path.exists(os.path.join(str_0, var_0))
    assert var_0 == "untemplated-cookiecutter-project"
    print("test_find_template passed")


# Generated at 2022-06-25 15:27:31.532205
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None

# Generated at 2022-06-25 15:27:33.248652
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as exc:
        assert isinstance(exc, NonTemplatedInputDirException)

# Generated at 2022-06-25 15:27:42.711162
# Unit test for function find_template
def test_find_template():
    var_0 = b'C:\\Users\\Ben\\PycharmProjects\\cookiecutter\\tests\\fake-repo-tmpl'
    var_1 = find_template(var_0)
    assert var_1 == b'C:\\Users\\Ben\\PycharmProjects\\cookiecutter\\tests\\fake-repo-tmpl\\{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:27:50.620587
# Unit test for function find_template
def test_find_template():
    str_0 = None
    str_1 = "C:\\Users\\rupasov_i\\Documents\\GitHub\\dvcs-cookiecutter.git\\"
    str_1 = "C:\\Users\\rupasov_i\\Documents\\GitHub\\dvcs-cookiecutter.git\\"
    str_1 = "C:\\Users\\rupasov_i\\Documents\\GitHub\\dvcs-cookiecutter.git\\"
    str_2 = "C:\\Users\\rupasov_i\\Documents\\GitHub\\dvcs-cookiecutter.git\\"
    str_2 = "C:\\Users\\rupasov_i\\Documents\\GitHub\\dvcs-cookiecutter.git\\"

# Generated at 2022-06-25 15:28:21.031788
# Unit test for function find_template
def test_find_template():
    str = "https://github.com/cookiecutter-django/cookiecutter-django.git"
    var = find_template(str)
    assert var is not None

# Generated at 2022-06-25 15:28:26.920953
# Unit test for function find_template
def test_find_template():
    os.chdir('C:\\Users\\Jonathan Londoño\\Desktop\\GitHub\\cookiecutter-libreria\\tests')
    with open('inputdata.txt') as f:
        lines = f.readlines()
    string = lines[0]
    assert string[0:3] == 'C:\\'
    assert find_template(string) == os.path.join(string, 'cookiecutter-project', 'cookiecutter.json')
    assert string[0:3] != 'C:\\'

# Generated at 2022-06-25 15:28:28.227136
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)
    var_0 = find_template(str)

# Generated at 2022-06-25 15:28:39.865989
# Unit test for function find_template
def test_find_template():

    # Test cases
    # Base case.
    if find_template('tests/test-dirs/test-dir-0') == 'tests/test-dirs/test-dir-0/{{cookiecutter.repo_name}}':
        print('p1')

    # Second base case.
    if find_template('tests/test-dirs/test-dir-1') == 'tests/test-dirs/test-dir-1/{{cookiecutter.repo_name}}':
        print('p1')

    # Second base case.
    if find_template('tests/test-dirs/test-dir-1') == 'tests/test-dirs/test-dir-1/{{cookiecutter.repo_name}}':
        print('p1')


# Generated at 2022-06-25 15:28:41.170452
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:28:44.259546
# Unit test for function find_template
def test_find_template():
    str_0 = 'repo_dir'
    var_0 = find_template(str_0)
    assert var_0 == 'repo_dir'


# Generated at 2022-06-25 15:28:45.546549
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:28:47.494364
# Unit test for function find_template

# Generated at 2022-06-25 15:28:52.056248
# Unit test for function find_template
def test_find_template():
    file_path_0 = 'cookiecutter/tests/test-input/'
    var_0 = find_template(file_path_0)
    assert (var_0 == 'cookiecutter/tests/test-input/{{cookiecutter.repo_name}}')


# Generated at 2022-06-25 15:28:53.323348
# Unit test for function find_template
def test_find_template():
    str_0 = None
    var_0 = find_template(str_0)

# Generated at 2022-06-25 15:29:56.242408
# Unit test for function find_template
def test_find_template():
    str_0 = 'C:\\git\\Python-Cookiecutter-DataScience\\cookiecutter-data-science'
    var_0 = find_template(str_0)
    assert var_0 == 'C:\\git\\Python-Cookiecutter-DataScience\\cookiecutter-data-science\\{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:29:59.375744
# Unit test for function find_template
def test_find_template():
    '''
    This function unit test function find_template()
    '''
    str_0 = 'C:\\the_path'
    var_0 = find_template(str_0)

    assert isinstance(var_0, str), 'Returned value must be a str.'

# Generated at 2022-06-25 15:30:01.617967
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template() == None
    except:
        assert True

# Generated at 2022-06-25 15:30:10.093441
# Unit test for function find_template
def test_find_template():
    """Check that find_template succeeds on a known template."""
    pwd = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(pwd, 'tests/test-repo-pre/')

    project_template = find_template(repo_dir)
    project_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert project_template == project_dir

# Generated at 2022-06-25 15:30:10.989476
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:30:13.717176
# Unit test for function find_template
def test_find_template():
    if test_case_0():
        test_case_0()

# Generated at 2022-06-25 15:30:16.265446
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir=None) == None
    assert find_template(repo_dir=False) == False
    assert find_template(repo_dir='') == ''
    assert find_template(repo_dir=0) == None

# Generated at 2022-06-25 15:30:27.702478
# Unit test for function find_template
def test_find_template():
    assert find_template('dir') == "dir"
    assert find_template('dir1/dir2') == "dir1/dir2"
    assert find_template('dir/') == "dir/"
    assert find_template('/dir/') == "/dir/"
    assert find_template('') == ""
    assert find_template(None) == None
    assert find_template(True) == True
    assert find_template(False) == False
    assert find_template(list()) == list()
    assert find_template({}) == {}
    assert find_template(set()) == set()
    assert find_template((1, 2, 3)) == (1, 2, 3)
    assert find_template(1) == 1
    assert find_template(1.0) == 1.0

# Generated at 2022-06-25 15:30:30.045033
# Unit test for function find_template
def test_find_template():
    str_0 = None
    var_0 = find_template(str_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 15:30:34.105012
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception:
        assert False
    else:
        assert True