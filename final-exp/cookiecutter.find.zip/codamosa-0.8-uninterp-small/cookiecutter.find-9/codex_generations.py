

# Generated at 2022-06-25 15:22:09.645284
# Unit test for function find_template
def test_find_template():
    assert find_template("../cookiecutter-django-master/{{cookiecutter.repo_name}}") == "../cookiecutter-django-master/{{cookiecutter.repo_name}}"
    assert find_template("../cookiecutter-pypackage-master/{{cookiecutter.repo_name}}") == "../cookiecutter-pypackage-master/{{cookiecutter.repo_name}}"
    assert find_template("../cookiecutter-pypackage-master/{{cookiecutter.repo_name}}/") == "../cookiecutter-pypackage-master/{{cookiecutter.repo_name}}/"

# Generated at 2022-06-25 15:22:11.641251
# Unit test for function find_template
def test_find_template():
    logger.info('Testing "find_template"')
    test_case_0()
    logger.info('"find_template" passed testing')

# Generated at 2022-06-25 15:22:12.446884
# Unit test for function find_template
def test_find_template():
    assert test_case_0() is None

# Generated at 2022-06-25 15:22:13.401087
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:16.894153
# Unit test for function find_template
def test_find_template():
    # Setup
    str_0 = "3wY`HNRS])7SI(\r\x0c'l@B"

    # Invoke
    var_0 = find_template(str_0)

    # Check
    # pass


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:22:17.809282
# Unit test for function find_template
def test_find_template():
    test_case_0()
    print('Success: test_find_template')



# Generated at 2022-06-25 15:22:21.995621
# Unit test for function find_template
def test_find_template():
    var_0 = find_template('ABT')
    assert var_0 == None

# Generated at 2022-06-25 15:22:24.852781
# Unit test for function find_template
def test_find_template():
    assert find_template(str_0) == var_0

# Generated at 2022-06-25 15:22:29.220092
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Standard boilerplate to call the main() function.
if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:22:31.779593
# Unit test for function find_template
def test_find_template():
    str_0 = "3wYHNRS7SIl@B"
    var_0 = find_template(str_0)

# Generated at 2022-06-25 15:22:39.156758
# Unit test for function find_template
def test_find_template():
    str_0 = "3wY`HNRS])7SI(\r\x0c'l@B"
    var_0 = find_template(str_0)

    str_1 = "E2W{J828(r\r\x0c\x1a'l@B"
    var_1 = find_template(str_1)


# Generated at 2022-06-25 15:22:40.262259
# Unit test for function find_template
def test_find_template():
    # test non_templated input_dir
    test_case_0()

# Generated at 2022-06-25 15:22:41.417963
# Unit test for function find_template
def test_find_template():
    case_0 = 0
    test_case_0()


# Generated at 2022-06-25 15:22:44.861718
# Unit test for function find_template
def test_find_template():
    str_0 = "3wY`HNRS])7SI(\r\x0c'l@B"
    expected_result = "3wY`HNRS])7SI(\r\x0c'l@B\\cookiecutter-pypackage"
    assert(expected_result == find_template(str_0))

test_find_template()

# Generated at 2022-06-25 15:22:47.344946
# Unit test for function find_template
def test_find_template():
    a1 = "a"
    ret_val = find_template(a1)
    assert ret_val == 'a'

# Generated at 2022-06-25 15:22:51.966510
# Unit test for function find_template
def test_find_template():
    print("\n===Unit test for function find_template===")
    test_case_0()
    print("\n===Unit test completed successfully!===")


# Run unit test
if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:22:52.902303
# Unit test for function find_template
def test_find_template():
    assert find_template(None) != None

# Generated at 2022-06-25 15:23:00.742027
# Unit test for function find_template
def test_find_template():
    ret_0 = find_template(os.path.abspath(os.path.join(os.path.dirname(__file__), "../tests/fake-repo-pre/{{cookiecutter.repo_name}}/")))
    assert ret_0 == os.path.abspath(os.path.join(os.path.dirname(__file__), "../tests/fake-repo-pre/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}/"))
    try:
        find_template(os.path.abspath(os.path.join(os.path.dirname(__file__), "../tests/fake-repo-pre/")))
    except Exception as e:
        assert type(e) == NonTemplatedInputDirException


# Generated at 2022-06-25 15:23:02.760005
# Unit test for function find_template
def test_find_template():
    str_0 = "3wY`HNRS])7SI(\r\x0c'l@B"
    var_0 = find_template(str_0)
    assert var_0 is None

# Generated at 2022-06-25 15:23:08.306417
# Unit test for function find_template
def test_find_template():
    assert find_template('3wY`HNRS])7SI(\r\x0c\'l@B') == "3wY`HNRS])7SI(\r\x0c'l@B/cookiecutter-{{cookiecutter.repo_name}}"


if __name__ == "__main__":
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:23:15.563361
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-pypackage')
    assert find_template('cookiecutter-pypackage/{{cookiecutter.repo_name}}/')


# Generated at 2022-06-25 15:23:16.437167
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:23:22.961138
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = ['my_json', 'mysecond_json', 'cookiecutter1', 'cookiecutter2']
    repo_dir = None
    project_template = None
    item = None

    i = 0
    while i < len(repo_dir_contents):
        if 'cookiecutter' in repo_dir_contents[i]:
            project_template = repo_dir_contents[i]
            break
        i += 1

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        print ('The project template appears to be %s', os.path.join(project_template))
        return project_template
    else:
        raise NonTemplatedInputDirException

# Generated at 2022-06-25 15:23:30.245706
# Unit test for function find_template
def test_find_template():
    import shutil

    repo_dir = '/tmp/cookiecutter-test-repo'
    project_template = '{{cookiecutter.project_name}}'

    # Cloning the test repo
    os.system('mkdir %s; git clone https://github.com/audreyr/cookiecutter-pypackage.git %s' % (repo_dir, repo_dir))

    result = find_template(repo_dir)
    assert result == os.path.join(repo_dir, project_template)

    # Cleaning up
    shutil.rmtree(repo_dir)

# Generated at 2022-06-25 15:23:33.828452
# Unit test for function find_template
def test_find_template():
    from tests.test_utils import TEST_COOKIE_PROJECT_DIR
    try:
        template_dir = find_template(TEST_COOKIE_PROJECT_DIR)
        assert template_dir
    except NonTemplatedInputDirException:
        raise Exception("Project directory is not templated correctly")

# Generated at 2022-06-25 15:23:38.605266
# Unit test for function find_template
def test_find_template():
    repo_dir='/var/src/github.com/cookiecutter-django/cookiecutter-django-rest'
    template_path = find_template(repo_dir)
    expected_template_path = template_path

    assert template_path == expected_template_path

# Generated at 2022-06-25 15:23:42.445879
# Unit test for function find_template
def test_find_template():
    template_directory = "/Users/saravana/Downloads/cookiecutter-django-1.7-master/cookiecutter-django-1.7/{{cookiecutter.repo_name}}"
    assert find_template(template_directory) == template_directory

# Generated at 2022-06-25 15:23:50.716235
# Unit test for function find_template
def test_find_template():
    ## Positive test
    # Case 0: file not found
    repo_dir = 'C:\\Users\\shacksan\\Desktop\\test'
    error = ''
    try:
        find_template(repo_dir)
        test_case_0()
    except NonTemplatedInputDirException:
        error = 'Positive test with NonTemplatedInputDirException failed'
    except Exception as e:
        error = 'Positive test failed: ' + str(e)

    assert error == '', error

    ## Negative test
    # Case 0: invalid path
    repo_dir = ''
    error = ''
    try:
        find_template(repo_dir)
    except Exception as e:
        error = 'Negative test with empty string failed: ' + str(e)

    assert error == '', error

    ## Negative

# Generated at 2022-06-25 15:23:53.030114
# Unit test for function find_template

# Generated at 2022-06-25 15:23:55.126403
# Unit test for function find_template
def test_find_template():
    repo_dir = ''
    result = find_template(repo_dir)
    print(result)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:03.897516
# Unit test for function find_template
def test_find_template():
    # call the function with different inputs.
    # This is white-box testing because we know the internal logic of the function.
    logger.debug('Starting unit test for function test_find_template')

    # case 0: the input is not a directory.
    try:
        find_template('/tmp/no_such_dir')
    except OSError as e:
        if 'is not a directory' in e.strerror:
            logger.debug('Finished unit test for function test_find_template')
            return True
    except:
        pass
    return False


# Generated at 2022-06-25 15:24:06.830627
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == '{{cookiecutter.project_name}}'

# {%- if cookiecutter.open_source_license == 'Not open source' -%}

# Generated at 2022-06-25 15:24:11.354918
# Unit test for function find_template

# Generated at 2022-06-25 15:24:19.152348
# Unit test for function find_template
def test_find_template():
    # Set up the input directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(current_dir, '../input_dir')

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-25 15:24:22.051305
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException
    test_case_1(test_case_0)


# Generated at 2022-06-25 15:24:22.898757
# Unit test for function find_template
def test_find_template():
    assert os.path.isfile('tests/login/tests_find_template.txt')

# Generated at 2022-06-25 15:24:25.099729
# Unit test for function find_template
def test_find_template():
    try:
        find_template('./tests/repos')
    except NonTemplatedInputDirException:
        assert(True)

# Generated at 2022-06-25 15:24:28.737932
# Unit test for function find_template
def test_find_template():
    path_0 = "test_case_0"
    path_1 = find_template(path_0)
    assert path_1 == "test_case_0"

if __name__ == "__main__":
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:24:30.115106
# Unit test for function find_template
def test_find_template():
    int_1 = 1
    assert(int_1) == 1

# Generated at 2022-06-25 15:24:33.652322
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/yuz/Projects/pycharm/cookiecutter-express/tests/test_project') == '/home/yuz/Projects/pycharm/cookiecutter-express/tests/test_project/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:24:38.636829
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:24:47.539911
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests/fake-repo-pre/{{cookiecutter.repo_name}}"
    project_template_contents = os.listdir(repo_dir)
    project_template = find_template(repo_dir)
    print(project_template_contents)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:51.235489
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-25 15:24:54.449646
# Unit test for function find_template
def test_find_template():
    assert len('dog') == 3
    int_1 = 1
    int_2 = 2
    int_2_1 = 3
    int_not_0 = int_2 + int_2_1
    assert int_not_0 != 0
    assert int_1 == 1
    assert isinstance(int_not_0, int)


# Generated at 2022-06-25 15:25:01.662540
# Unit test for function find_template
def test_find_template():
    repo_dir = "../tests/test-repo/"
    project_template = find_template(repo_dir)

    # The function does not throw an error.
    assert project_template

    # The project_template variable is not empty.
    assert project_template != ""

    # The project_template variable contains the substring "cookiecutter"
    assert "cookiecutter" in project_template

# Generated at 2022-06-25 15:25:06.732959
# Unit test for function find_template
def test_find_template():
    # This test case is to check if the function find_template is able to find
    # the path of template without error.
    # Also, if the template is not found, assert will stop the process.
    assert_with_msg(""+find_template("/Users/shangzhong/Downloads/cookiecutter-custom-templates/cookiecutter-custom-templates")+"", "/Users/shangzhong/Downloads/cookiecutter-custom-templates/cookiecutter-custom-templates/{{cookiecutter.repo_name}}")

# Generated at 2022-06-25 15:25:11.931104
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(__file__) + "/test_find_template"
    template = find_template(repo_dir)
    assert template == os.path.abspath(repo_dir + "/{{cookiecutter.repo_name}}")

# Generated at 2022-06-25 15:25:19.410078
# Unit test for function find_template
def test_find_template():
    # When dir_path is None
    result = find_template(None)
    assert result == None

    # When dir_path is empty
    result = find_template("")
    assert result == None

    # When dir_path is valid and contains a cookicutter template
    result = find_template("/Users/test/repo")
    assert result == "/Users/test/repo"

    # When dir_path is valid but does not contain a cookiecutter template
    result = find_template("/Users/test/repo_empty_dir")
    assert result == None

# Generated at 2022-06-25 15:25:25.358254
# Unit test for function find_template
def test_find_template():
    # test case 0
    repo_dir = "/Users/kevin/workspace/personal/cookiecutter-pypackage-minimal"
    try:
        project_template = find_template(repo_dir)
    except NonTemplatedInputDirException:
        project_template = None
    assert project_template is not None, "find_template failed for test case 0"

# Generated at 2022-06-25 15:25:31.302736
# Unit test for function find_template
def test_find_template():
    # Call function find_template with a fake directory path
    label_returned = find_template('./test_0/fake_path')

    # Compare the label returned by the function to a known value
    test_case_0()
    assert label_returned is None


# Generated at 2022-06-25 15:25:40.840998
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/tianyu/Desktop/cookiecutter/tests/test_template') == '/home/tianyu/Desktop/cookiecutter/tests/test_template/{{cookiecutter.repo_name}}'


# Generated at 2022-06-25 15:25:49.973264
# Unit test for function find_template
def test_find_template():
    # Test normal case
    repo_dir = os.path.abspath(os.path.join('./test_files/test_libraries/test_library_template_01'))
    print(find_template(repo_dir))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:25:53.128206
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join("tests", "fixtures", "fake-repo-pre")
    project_template = find_template(repo_dir)

    assert os.path.basename(project_template) == "fake-repo-pre"


# Generated at 2022-06-25 15:26:02.627887
# Unit test for function find_template
def test_find_template():

    # Test case 1
    # Happy case
    repo_dir = 'E:/workplace/Projects/cookiecutter-pypackage'
    project_template_expected = 'E:/workplace/Projects/cookiecutter-pypackage/{{cookiecutter.project_name}}'
    project_template = find_template(repo_dir)
    int_1 = 1
    assert(project_template == project_template_expected)

    # Test case 2
    # The directory doesn't contain cookiecutter but "{{cookiecutter.project_name}}"
    repo_dir = 'E:/workplace/Projects/cookiecutter-pypackage'
    project_template_expected = 'E:/workplace/Projects/cookiecutter-pypackage/cookiecutter'

# Generated at 2022-06-25 15:26:04.792368
# Unit test for function find_template
def test_find_template():
    #should pass
    try:
        template = find_template("tests/test-repo")
    except:
        test_case_0()

    #should fail
    try:
        template = find_template("tests/test-repo-fail")
    except:
        return

    test_case_0()

# Generated at 2022-06-25 15:26:08.656128
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/travis/build/alandekok/cookiecutter-readme/tests/fake-repo-pre/'

    project_template = find_template(repo_dir)
    assert project_template == '/home/travis/build/alandekok/cookiecutter-readme/tests/fake-repo-pre/{{cookiecutter.project_slug}}'


# Generated at 2022-06-25 15:26:10.611033
# Unit test for function find_template
def test_find_template():
    assert find_template("../tests") == "../tests/{{cookiecutter.repo_name}}"


# Generated at 2022-06-25 15:26:15.431038
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "unit_tests", "test_case_0")
    project_template = find_template(test_dir)
    # test_case_0 should return the test case directory itself as the project template
    assert project_template == os.path.join(test_dir, "test_case_0")


# Generated at 2022-06-25 15:26:19.733921
# Unit test for function find_template
def test_find_template():
    project_path = 'C:\\Users\\David\\GitHub\\Network-Automation-Scripts\\scripts'
    print(find_template(project_path))
    return;

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:23.801625
# Unit test for function find_template
def test_find_template():
    path = "/Users/rpaliwal/Documents/Cookiecutter-Teaching/tests"
    print(os.listdir(path))
    print (find_template(path))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:34.288291
# Unit test for function find_template
def test_find_template():
    int_0 = 0
    rep_dir = '../tests/fake-repo-0'
    expected_template = '../tests/fake-repo-0/{{cookiecutter.repo_name}}'
    try:
        template = find_template(rep_dir)
        if template == expected_template:
            int_0 = int_0 + 1 
    except NonTemplatedInputDirException:
        print("Expected template not found in directory")
        return False
    if int_0 == 0:
        return False
    return True


# Generated at 2022-06-25 15:26:45.030598
# Unit test for function find_template
def test_find_template():
    # Test case #0
    try:
        find_template("test_dir")
        assert False
    except NonTemplatedInputDirException:
        assert True

    # Test case #1
    assert find_template("test_dir") == "test_dir/cookiecutter-{{cookiecutter.repo_name}}"
    # Test case #2
    assert find_template("test_dir") == "test_dir/{{cookiecutter.repo_name}}-cookiecutter"
    # Test case #3
    assert find_template("test_dir") == "test_dir/{{cookiecutter.repo_name}}-{{cookiecutter.description}}"

# Generated at 2022-06-25 15:26:46.194787
# Unit test for function find_template
def test_find_template():
    find_template('C:\\Users\\Tyranitar\\Downloads\\projects')

# Generated at 2022-06-25 15:26:50.845598
# Unit test for function find_template
def test_find_template():
    repo_dir = "https://github.com/audreywatters/cookiecutter-education"

# Generated at 2022-06-25 15:26:52.485624
# Unit test for function find_template
def test_find_template():
    # Test case 0: No file or directory found in current directory
    path = os.getcwd()
    assert find_template(path) == None


# Generated at 2022-06-25 15:27:01.751911
# Unit test for function find_template
def test_find_template():
    global int_0
    repo_dir = r'C:\Users\Administrator\Desktop\cookiecutter-pypackage\{{cookiecutter.project_slug}}'
    project_template = r'C:\Users\Administrator\Desktop\cookiecutter-pypackage\{{cookiecutter.project_slug}}'
    int_0 = 1
    return True if (project_template == find_template(repo_dir)) else False


# Generated at 2022-06-25 15:27:02.248531
# Unit test for function find_template
def test_find_template():
    assert 1 == 1

# Generated at 2022-06-25 15:27:05.482459
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/nl35t740/PycharmProjects/GitHub/Cookiecutter'
    assert find_template(repo_dir) == '/Users/nl35t740/PycharmProjects/GitHub/Cookiecutter'

# Generated at 2022-06-25 15:27:09.935622
# Unit test for function find_template
def test_find_template():
    repo_dir = 'C:\\Users\\SNathani\\Documents\\GitHub\\cookiecutter-django'
    expected_output = 'C:\\Users\\SNathani\\Documents\\GitHub\\cookiecutter-django\\cookiecutter-{{cookiecutter.repo_name}}'
    actual_output = find_template(repo_dir)
    assert actual_output == expected_output

# Generated at 2022-06-25 15:27:16.549901
# Unit test for function find_template

# Generated at 2022-06-25 15:27:28.984121
# Unit test for function find_template
def test_find_template():
    list_0 = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'tests')
    var_0 = find_template(list_0)
    assert var_0 == os.path.join(os.path.dirname(__file__), '..', '..', '..', 'tests', 'tests-master')

# Generated at 2022-06-25 15:27:35.218309
# Unit test for function find_template
def test_find_template():
    import inspect
    # Copy all of the parameters in the function signature.
    args, varargs, varkw, defaults = inspect.getargspec(find_template)
    for val in args:
        locals()[val] = None
    # Set the parameter repo_dir to a default value.
    locals()['repo_dir'] = None
    try:
        find_template(repo_dir)
        assert False
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-25 15:27:37.305359
# Unit test for function find_template
def test_find_template():
    list_0 = 'test_input_dir'
    test_case_0()



# Generated at 2022-06-25 15:27:39.154728
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/hello_world/') == '/home/hello_world/cookiecutter-hello_world'

# unit test for function test_case_0

# Generated at 2022-06-25 15:27:41.183675
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException as e:
        print("Error: " + str(e))

# Generated at 2022-06-25 15:27:44.569151
# Unit test for function find_template
def test_find_template():
    list_0 = {"cookiecutter": "{{cookiecutter.project_name}}",
              "cookiecutter.project_name": "test_find_template"}
    assert find_template(list_0) == "test_find_template"

# Generated at 2022-06-25 15:27:45.997606
# Unit test for function find_template
def test_find_template():
    list_0 = os.listdir(os.getcwd())
    var_0 = find_template(list_0)

# Generated at 2022-06-25 15:27:51.962108
# Unit test for function find_template

# Generated at 2022-06-25 15:28:00.721207
# Unit test for function find_template
def test_find_template():
    print("Testing function find_template")

    # If a repository has no files
    assert find_template('A') == "non-templated directory, no files in repo"

    # If a repository has a single file
    assert find_template('AB') == "non-templated directory, no files in repo"

    # If a repository has two files, and one is a template.
    assert find_template('ABC') == 'C'

    # If a repository has multiple files, and one is a template.
    assert find_template('ABD') == 'D'

    # If a repository has multiple files, and two are templates.
    assert find_template('ABDE') == 'DE'

    print("Passed")

test_find_template()

# Generated at 2022-06-25 15:28:01.874254
# Unit test for function find_template
def test_find_template():
    assert(find_template('test_find_template'))



# Generated at 2022-06-25 15:28:17.808164
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)



# Generated at 2022-06-25 15:28:19.605828
# Unit test for function find_template
def test_find_template():

    assert(find_template(list_0) == None)

# Generated at 2022-06-25 15:28:26.629011
# Unit test for function find_template
def test_find_template():
    """Test cases for function find_template"""
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

# Function list_components

# Generated at 2022-06-25 15:28:33.376804
# Unit test for function find_template
def test_find_template():
    import sys

    for name, value in [('find_template', find_template), ('sys', sys), ('__name__', __name__), ('logging', logging), ('logger', logger), ('NonTemplatedInputDirException', NonTemplatedInputDirException)]:
        if name in globals():
            del globals()[name]
    import os
    import logging

    logger = logging.getLogger(__name__)

    logger.debug('Searching %s for the project template.', 'repo_dir')
    setattr(os, 'path', 'path')
    setattr(os, 'listdir', 'listdir')
    setattr(os, 'path', 'path')
    setattr(logging, 'info', 'info')

# Generated at 2022-06-25 15:28:37.556293
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        import sys
        print("In test case 0: ", sys.exc_info()[1])

# Program entry point
if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:28:39.479480
# Unit test for function find_template
def test_find_template():
    os.chdir('/Users/emily/Desktop/cookiecutter-pypackage')
    test_case_0()

# Generated at 2022-06-25 15:28:41.129140
# Unit test for function find_template
def test_find_template():
    find_template("themes")


# Generated at 2022-06-25 15:28:44.260102
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print("Exception raised for test case 0")

# Main function for testing

# Generated at 2022-06-25 15:28:46.379685
# Unit test for function find_template
def test_find_template():
    list_0 = []
    assert find_template(list_0) == None



# Generated at 2022-06-25 15:28:52.023382
# Unit test for function find_template
def test_find_template():
    template_dir = "/Users/kyleaom/Documents/Learn/cookiecutter/cookiecutter-pypackage/.heroku"
    result = find_template(template_dir)
    expected = "/Users/kyleaom/Documents/Learn/cookiecutter/cookiecutter-pypackage/.heroku/cookiecutter-pypackage"
    assert result == expected

# Generated at 2022-06-25 15:29:23.734139
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except(TypeError):
        testcase_0_error = True
    assert testcase_0_error


# Generated at 2022-06-25 15:29:25.658110
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        pass

# Generated at 2022-06-25 15:29:35.669936
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    import sys
    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Create a temporary directory
    TEST_DIR = 'test_dir_cookiecutter'
    try:
        os.mkdir(TEST_DIR)
        # Copy the project template into the temporary directory
        os.makedirs(os.path.join(TEST_DIR, 'cookiecutter-pypackage'))
        # Run find_template() against the temporary directory
        result = find_template(TEST_DIR)
        # TODO: Should also check that it raises an Exception if no template exists.
    finally:
        # Remove the temporary directory
        shutil.rmtree(TEST_DIR)

    # Test that the

# Generated at 2022-06-25 15:29:38.237470
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception:
        pass


# print(find_template('C:\git\devops\devops\cookiecutters\lazp-4-machine'))

# Generated at 2022-06-25 15:29:45.070262
# Unit test for function find_template
def test_find_template():
    assert find_template("C2C/cookiecutter") == "C2C/cookiecutter/{{cookiecutter.project_slug}}"
    assert find_template("C2C/cookiecutter-pypackage") == "C2C/cookiecutter-pypackage/{{cookiecutter.project_slug}}"
    assert find_template("C2C/cookiecutter-django") == "C2C/cookiecutter-django/{{cookiecutter.project_slug}}"
    assert find_template("C2C/cookiecutter-golang") == "C2C/cookiecutter-golang/{{cookiecutter.project_slug}}"

# Generated at 2022-06-25 15:29:47.461253
# Unit test for function find_template
def test_find_template():
    print(test_case_0())

test_find_template()

# Generated at 2022-06-25 15:29:52.817740
# Unit test for function find_template
def test_find_template():
    with pytest.raises(NonTemplatedInputDirException) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert the_exception.__str__() == 'No cookiecutter templating in repo. Use a repo like https://github.com/audreyr/cookiecutter-pypackage', 'The raised exception is not expected'

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 15:29:54.782801
# Unit test for function find_template
def test_find_template():
    # Test False
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()



# Generated at 2022-06-25 15:29:59.192367
# Unit test for function find_template
def test_find_template():
    assert find_template("repo_dir") == "repo_dir/cookiecutter-{{cookiecutter.repo_name}}"

# Generated at 2022-06-25 15:30:05.764156
# Unit test for function find_template
def test_find_template():
    import inspect
    import os
    import sys
    # add parent directory to sys path to import cookiecutter
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(test_case_0)))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0,parentdir)
    try:
        from cookiecutter.find import find_template
    except:
        from find import find_template
    
    
    this_path = os.path.dirname(os.path.abspath(inspect.getfile(test_case_0)))
    this_path = os.path.join(this_path, 'tests', 'input', 'regression_tests', 'cookiecutter-pypackage')

# Generated at 2022-06-25 15:31:10.411287
# Unit test for function find_template
def test_find_template():
    testcase_find_template_0()


# Generated at 2022-06-25 15:31:17.446248
# Unit test for function find_template
def test_find_template():
    path_0 = './tests/test-output/fake-repo'
    assert find_template(path_0) == path_0 + '/{{cookiecutter.project_slug}}'


if __name__ == '__main__':
    print('Collecting tests ...')
    test_find_template()

# Generated at 2022-06-25 15:31:18.339441
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Collect all test cases in this file

# Generated at 2022-06-25 15:31:19.826214
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:31:31.279489
# Unit test for function find_template

# Generated at 2022-06-25 15:31:34.604817
# Unit test for function find_template

# Generated at 2022-06-25 15:31:39.620641
# Unit test for function find_template
def test_find_template():
    try:
        list_0 = '/home/travis/build/audreyr/cookiecutter/tests/fake-repo-pre/'
        project_template = find_template(list_0)
        print(project_template)
    except NonTemplatedInputDirException as e:
        print(e)
# test_find_template()

# Generated at 2022-06-25 15:31:41.047107
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:31:43.029220
# Unit test for function find_template
def test_find_template():
    # Clean up after tests have finished
    test_tear_down()
    try:
        # Testing with a non templated directory
        test_case_0()
    except ValueError or NonTemplatedInputDirException:
        print("Unit test for function find_template passed")

# Clean up after tests have finished

# Generated at 2022-06-25 15:31:43.849294
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == var_0

