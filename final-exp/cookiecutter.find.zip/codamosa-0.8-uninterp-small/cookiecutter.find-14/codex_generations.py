

# Generated at 2022-06-25 15:22:10.172025
# Unit test for function find_template
def test_find_template():
    # Template is not a string
    var_0 = find_template(None)
    # Template is a string
    var_1 = find_template("{{cookiecutter.project_name}}")
    # Template is a template string
    var_2 = find_template("{{cookiecutter.project_name}}/{{cookiecutter.project_name}}")
    # Template is a non-templatized string
    var_3 = find_template("/{{cookiecutter.project_name}}/{{cookiecutter.project_name}}")
    # Template is a non-existing string
    var_4 = find_template("/{{cookiecutter.project_name}}/{{cookiecutter.project_name}}")

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 15:22:18.591207
# Unit test for function find_template
def test_find_template():
    assert find_template('/usr/local/lib/python2.7/dist-packages/cookiecutter') == '/usr/local/lib/python2.7/dist-packages/cookiecutter/cookiecutter'
    assert find_template('/usr/local/lib/python2.7/dist-packages/cookiecutter-django') == '/usr/local/lib/python2.7/dist-packages/cookiecutter-django/cookiecutter-django'
    assert find_template('/usr/local/lib/python2.7/dist-packages/cookiecutter-django-paas') == '/usr/local/lib/python2.7/dist-packages/cookiecutter-django-paas/cookiecutter-django-paas'

# Generated at 2022-06-25 15:22:24.252706
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    # function template
    template = find_template("./fake-repo-tmpl")

    assert template == "./fake-repo-tmpl/fake-project-{{cookiecutter.repo_name}}"



# Generated at 2022-06-25 15:22:32.187742
# Unit test for function find_template
def test_find_template():
    template_path = find_template('./tests/fake-repo-pre')
    assert template_path == './tests/fake-repo-pre/{{cookiecutter.repo_name}}', 'should be equal'
    template_path = find_template('./tests/fake-repo-post')
    assert template_path == './tests/fake-repo-post/cookiecutter-pypackage', 'should be equal'

# Generated at 2022-06-25 15:22:39.984534
# Unit test for function find_template
def test_find_template():
    try:
        result = find_template('/home/ben/cookiecutter-pypackage-minimal/cookiecutter-pypackage-minimal/')
        print(result)

    except NonTemplatedInputDirException:
        pass

# Program entry point
if __name__ == "__main__":
   logger.setLevel(logging.DEBUG)
   logger.debug("Started Program.")
   test_find_template()
   logger.debug("Exiting Program.")

# End of file

# Generated at 2022-06-25 15:22:41.765905
# Unit test for function find_template
def test_find_template():
    # Test cases
    assert test_case_0() == NonTemplatedInputDirException
    # Test case 0: non-templated input directory
    # Test case 1: empty input directory

# Generated at 2022-06-25 15:22:44.298845
# Unit test for function find_template
def test_find_template():
    var_0 = find_template(repo_dir='tests/fake-repo-pre/')
    assert var_0 == 'tests/fake-repo-pre/fake-project-{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:22:55.319388
# Unit test for function find_template
def test_find_template():
    bool_0 = False
    var_0 = find_template(bool_0)
    #assert var_0 == 'C:\\Users\\JP\\Documents\\GitHub\\cookiecutter-django\\tests\\fake-repo-pre\\{{cookiecutter.repo_name}}'
    assert var_0 == '/home/travis/build/achyn/cookiecutter-berlin/tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    bool_1 = True
    var_1 = find_template(bool_1)
    #assert var_1 == 'C:\\Users\\JP\\Documents\\GitHub\\cookiecutter-django\\tests\\fake-repo-pre\\{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:23:00.218907
# Unit test for function find_template
def test_find_template():
    test_0 = {
        "bool_0": False,
        "var_0": find_template(False)
    }

    test_cases = {
        0: test_case_0,
    }

    tests = [x for x in test_cases if test_cases[x]() is False]

    if len(tests) > 0:
        for test in tests:
            print('test_find_template - {0}'.format(test))
        assert False

# Generated at 2022-06-25 15:23:01.525556
# Unit test for function find_template
def test_find_template():
    assert find_template == test_case_0

# Generated at 2022-06-25 15:23:06.555698
# Unit test for function find_template
def test_find_template():
    # Test for command line option '-t'
    float_0 = None
    var_0 = find_template(float_0)
    assert var_0 != None


# Generated at 2022-06-25 15:23:08.522262
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        import sys
        print("In test case 0")
        print("Exception: ", sys.exc_info()[0])

# Generated at 2022-06-25 15:23:10.131819
# Unit test for function find_template
def test_find_template():
    try:
        find_template(float_0)
    except NonTemplatedInputDirException as err:
        assert True
        print(err)

# Generated at 2022-06-25 15:23:16.040839
# Unit test for function find_template
def test_find_template():
    from nose.tools import assert_equals, assert_not_equals, assert_raises
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        assert True

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:19.147916
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template(None) == None
        assert find_template('') == None
    except:
        assert False
    else:
        assert True

if __name__ == '__main__':
    # test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:23:25.718213
# Unit test for function find_template
def test_find_template():
    # Try to find the template in the current directory
    current_directory = os.path.dirname(os.path.realpath(__file__))
    test_template_dir = os.path.join(current_directory, 'test_templates', 'test_template_1')
    template = find_template(test_template_dir)
    logging.debug('The template is at %s', template)
    assert template == test_template_dir


# Generated at 2022-06-25 15:23:28.525491
# Unit test for function find_template
def test_find_template():

    # Setup
    float_0 = None

    # Invocation
    var_0 = find_template(float_0)

    # Check if the returned value is correct
    assert var_0 == None



# Generated at 2022-06-25 15:23:32.678765
# Unit test for function find_template
def test_find_template():
    var_0 = ['/home/paul/.pyenv/versions/2.7.12/bin/cookiecutter', '--no-input', '-o', '/tmp/cookiecutter_1520696634', 'https://github.com/datadesk/cookiecutter-la-template.git']
    with open('/tmp/cookiecutter_1520696634/cookiecutter.json') as fh:
        var_1 = json.load(fh)
    var_2 = find_template(var_0[3])
    with open(var_2) as fh_0:
        var_3 = fh_0.read()
    var_4 = {}
    var_5 = var_3.format(**var_1)

# Generated at 2022-06-25 15:23:39.125547
# Unit test for function find_template
def test_find_template():
    this_dir = os.getcwd()
    repo_dir = os.path.join(this_dir, 'tests', 'test-find-template')
    assert find_template(repo_dir) == os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.project_slug}}'
    )

# Generated at 2022-06-25 15:23:40.828313
# Unit test for function find_template
def test_find_template():
    
    try:
        test_case_0()
        return True
    except:
        return False

# Generated at 2022-06-25 15:23:43.256427
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:23:50.826241
# Unit test for function find_template
def test_find_template():
    import sys
    import time

    input_0 = "./tests/test-data/fake-repo/"
    output_0 = find_template(input_0)

    # Todo: Finish this, not sure how to detect which files are created.
    # if output_0 == ?:
    #     print( "Pass" )
    # else:
    #     print( "Fail" )
    # assert output_0 == ?


# Unit test execution
if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:52.181234
# Unit test for function find_template
def test_find_template():

    float_0 = None
    var_0 = find_template(float_0)

# Generated at 2022-06-25 15:23:56.209170
# Unit test for function find_template
def test_find_template():
    float_0 = 'tests/test_repo'
    float_1 = 'tests/test_repo/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:23:57.355718
# Unit test for function find_template
def test_find_template():
    assert find_template((test_case_0())) == None

if __name__ == '__main__':
    print(test_case_0())
    print(test_find_template())

# Generated at 2022-06-25 15:23:57.912958
# Unit test for function find_template
def test_find_template():
    assert find_template(test_case_0()) == test_case_0()

# Generated at 2022-06-25 15:23:59.709434
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        logger.error(e, exc_info=True)

# Generated at 2022-06-25 15:24:04.712691
# Unit test for function find_template
def test_find_template():
    """Test function find_template()"""

    # Initialize the project_dir variable with a valid value
    project_dir = os.path.abspath('.')

    # Check if find_template() safe to call, if yes call it
    if True:
        find_template(project_dir)


# Generated at 2022-06-25 15:24:07.888775
# Unit test for function find_template
def test_find_template():
    print('Testing function find_template.')

    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print('test case: 0 passed')
    except TypeError:
        print('test case: 0 failed')

    print('Testing function find_template done.')

# Generated at 2022-06-25 15:24:11.515760
# Unit test for function find_template
def test_find_template():

    # Setup test cases
    test_case_0()


# run tests
test_find_template()

# Generated at 2022-06-25 15:24:19.410558
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 15:24:20.625331
# Unit test for function find_template
def test_find_template():
    assert find_template is not None

# Generated at 2022-06-25 15:24:22.051484
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir = 'None') == None


# Generated at 2022-06-25 15:24:23.386597
# Unit test for function find_template
def test_find_template():
    assert find_template(float_0) == None
    return "unit test for find_template"

if __name__ == '__main__':
    print(test_find_template())

# Generated at 2022-06-25 15:24:26.061073
# Unit test for function find_template
def test_find_template():
    assert(test_case_0() == None)



# Generated at 2022-06-25 15:24:27.107569
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == NonTemplatedInputDirException

# Generated at 2022-06-25 15:24:28.346954
# Unit test for function find_template
def test_find_template():
    assert True == True

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:32.356386
# Unit test for function find_template
def test_find_template():
    os.chdir('tests/test-input/find-template-tests')
    assert find_template == 'tests/test-input/find-template-tests/' in os.listdir()
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:33.313440
# Unit test for function find_template
def test_find_template():
    assert ('/') in find_template('/')


# Generated at 2022-06-25 15:24:41.332439
# Unit test for function find_template
def test_find_template():
    test_case_0()

#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#


# Generated at 2022-06-25 15:24:45.026722
# Unit test for function find_template
def test_find_template():
    assert find_template(float_0) == var_0

# Generated at 2022-06-25 15:24:47.103128
# Unit test for function find_template
def test_find_template():
    find_template(0)
    pass

# Generated at 2022-06-25 15:24:48.800519
# Unit test for function find_template
def test_find_template():
    var_0 = None
    var_1 = find_template(var_0)


# Generated at 2022-06-25 15:24:50.937168
# Unit test for function find_template
def test_find_template():
    template = find_template('/home/cookiecutter/tests/test-templates/')
    assert template == '/home/cookiecutter/tests/test-templates/{{cookiecutter.repo_name}}'


# Generated at 2022-06-25 15:24:54.679551
# Unit test for function find_template
def test_find_template():

    # Check if the value returned from find_template was correct
    try:
        assert find_template('/Users/pedro/Projects/cookiecutter') == '/Users/pedro/Projects/cookiecutter/{{ cookiecutter.repo_name }}'
        return 'function find_template worked correctly'
    except AssertionError:
        return 'function find_template did not work correctly'


# Generated at 2022-06-25 15:24:58.416795
# Unit test for function find_template
def test_find_template():
    float_0 = find_template("")
    assert float_0 == None

# AssertionError: NonTemplatedInputDirException not raised

# Generated at 2022-06-25 15:25:00.570074
# Unit test for function find_template
def test_find_template():
    from cookiecutter.find import find_template
    assert find_template('var_0') == None

# Generated at 2022-06-25 15:25:06.756620
# Unit test for function find_template
def test_find_template():
    from cookiecutter import repo

    test_0_cc_repo = os.path.abspath(
        os.path.join(
            os.path.dirname(repo.__file__),
            'tests/test-0-cc-repo'
        )
    )
    logger.debug('test_0_cc_repo is %s', test_0_cc_repo)

    project_template = find_template(test_0_cc_repo)

    assert os.path.split(project_template)[-1] == '{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:25:07.656838
# Unit test for function find_template
def test_find_template():
    assert find_template() == None

# Generated at 2022-06-25 15:25:18.041059
# Unit test for function find_template
def test_find_template():
    # Python 2.6
    import sys
    if sys.version_info[0] == 3:
        from unittest.mock import MagicMock
    # Python 2.7
    else:
        from mock import MagicMock
    
    #try:
    #    float_0 = MagicMock(return_value=0.1)
    #    float_0() # <-- returns 0.1
        
    #except:
    #    logger.info("This is not it")
    #    raise ValueError('Function find_template not implemented')
    
    return

if __name__ == "__main__":
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:25:28.011599
# Unit test for function find_template
def test_find_template():
    arg_0 = None
    if arg_0 is None:
        arg_0 = "{{cookiecutter.repo_name}}"
    assert find_template(arg_0) == "{{cookiecutter.repo_name}}"

# Generated at 2022-06-25 15:25:36.834818
# Unit test for function find_template
def test_find_template():
    ##Expected instance of class NonTemplatedInputDirException
    non_templated_instance = NonTemplatedInputDirException()
    func_call_instance = find_template("non templated input dir")
    assert func_call_instance is not None, "The function call find_template(\"non templated input dir\") did not return expected output. Expected output is not None"
    assert isinstance(func_call_instance, type(non_templated_instance)), "The function call find_template(\"non templated input dir\") did not return expected output.\nExpected output instance is of type NonTemplatedInputDirException"

# Generated at 2022-06-25 15:25:45.007518
# Unit test for function find_template
def test_find_template():
    # Input parameters
    float_0 = None

    # Additional wanted results
    str_0 = 'Cookiecutter'
    str_1 = '.'
    str_2 = '.'
    # No exception should be raised
    result = find_template(float_0)
    assert '.' in result
    assert 'Cookiecutter' in result
    assert '.' in result

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:25:46.278525
# Unit test for function find_template
def test_find_template():
    assert find_template() == 0

# Generated at 2022-06-25 15:25:51.445072
# Unit test for function find_template
def test_find_template():
    input0 = """no_cookiecutter_dir_in_here"""
    with pytest.raises(NonTemplatedInputDirException):
        # The following line is used instead of test case 0 for input 0
        test_case_0()
        test_case_0(float_0=float_0)



# Generated at 2022-06-25 15:25:57.425963
# Unit test for function find_template
def test_find_template():
    print('Creating test case 0')
    try:
        test_case_0()
    except NonTemplatedInputDirException as e:
        logger.debug('NonTemplatedInputDirException Occurred')
    print('Test case 0 finished')



# Generated at 2022-06-25 15:26:05.943756
# Unit test for function find_template
def test_find_template():
    # Mock os.listdir to cause an exception
    repo_dir = '.'
    os.listdir = Mock(return_value = {'.': '.'})

    # Call the function under test
    try:
        find_template(repo_dir)
    except Exception:
        # If we get an exception, the function did what we thought it would
        pass
    else:
        # If we don't get an exception, then the function did NOT do what we
        # thought it would
        raise Exception('Expected an exception, but we did not get one!')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:26:07.340758
# Unit test for function find_template
def test_find_template():

    try:
        test_case_0()
    except:
        print ("Error during test case 0.")


# Generated at 2022-06-25 15:26:09.108514
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template(None) == None
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-25 15:26:11.783888
# Unit test for function find_template
def test_find_template():
    float_0 = None
    var_0 = find_template(float_0)

# if __name__ == '__main__':
#     test_find_template()

# Generated at 2022-06-25 15:26:28.337582
# Unit test for function find_template
def test_find_template():
    assert callable(find_template), "Function does not exist" 

# Input parameters for unit test
float_0 = "test"

# Perform unit test
test_case_0()

# Print output from unit test
print("Input value for find_template: " + float_0 + " output value: " + var_0)

# Generated at 2022-06-25 15:26:30.061565
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-25 15:26:37.783077
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import os
    import shutil
    from cookiecutter import utils

    # Test Case 0
    try:
        shutil.rmtree('repo_0')
    except:
        pass
    utils.make_sure_path_exists('repo_0')
    with open(os.path.join('repo_0', '{{cookiecutter.project_name}}'), 'w') as f:
        f.write('')
    test_case_0()


if __name__ == '__main__':
    from cookiecutter import utils
    logging.basicConfig(level=logging.DEBUG)
    utils.set_excepthook()
    test_find_template()

# Generated at 2022-06-25 15:26:40.687734
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:43.401353
# Unit test for function find_template
def test_find_template():
    assert find_template('.') != None
    assert find_template('.') == None
    assert find_template('.') == None
    assert find_template('.') != None

# Generated at 2022-06-25 15:26:46.227627
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
        test_case_1()
    except Exception as e:
        print("Exception caught in function find_template")
        raise e

# Generated at 2022-06-25 15:26:48.374672
# Unit test for function find_template
def test_find_template():
    assert callable(find_template.func_code)


# Entry points for extensible cli

# Generated at 2022-06-25 15:26:51.271629
# Unit test for function find_template
def test_find_template():
    # Local variables
    float_0 = None

    # Setup test case
    setup_test_case_0()

    # Test function
    var_0 = find_template(float_0)

    # Verify results
    verify_results_0(var_0)



# Generated at 2022-06-25 15:26:54.521552
# Unit test for function find_template
def test_find_template():
    player_0 = None
    var_0 = find_template(player_0)

# Generated at 2022-06-25 15:26:57.250673
# Unit test for function find_template
def test_find_template():
    float_0 = '/home/cookiecutter_template'
    var_0 = find_template(float_0)


# Generated at 2022-06-25 15:27:22.375154
# Unit test for function find_template
def test_find_template():
    assert find_template() == 'project_template'

# Generated at 2022-06-25 15:27:23.602580
# Unit test for function find_template
def test_find_template():
    assert find_template(get_var_0()) == get_var_0()


# Generated at 2022-06-25 15:27:32.589934
# Unit test for function find_template
def test_find_template():
    float_0 = None
    var_0 = find_template(float_0)
    with pytest.raises(NonTemplatedInputDirException):
        var_1 = find_template(var_0)
    float_0 = "pMtp,JmZq.TKc"
    float_1 = "V8W@Kj&vb7}s"
    float_2 = -27
    float_3 = -27
    var_2 = find_template(float_0)
    var_3 = find_template(float_0)
    var_4 = find_template(float_0)
    var_5 = find_template(float_0)
    var_6 = find_template(float_0)
    var_7 = find_template(float_0)

# Generated at 2022-06-25 15:27:41.879036
# Unit test for function find_template
def test_find_template():
    try:
        assert test_case_0() == "False"

    except AssertionError as e:
        raise(e)

    return True

print("thank you for your patience")
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #
# #

# Generated at 2022-06-25 15:27:45.574473
# Unit test for function find_template
def test_find_template():
    import unittest

    test_case_0()
    test_case_1()
    test_case_2()

    class TestFindTemplateTest(unittest.TestCase):
        def test_find_template_0(self):
            self.assertAlmostEqual(1, 1)

    unittest.main()

# Generated at 2022-06-25 15:27:48.868687
# Unit test for function find_template
def test_find_template():
    if os.path.isfile('./test_template/cookiecutter.json'):
        assert find_template('./test_template') == './test_template/cookiecutter.json'
    else:
        assert find_template('./test_template') == './test_template/cookiecutter.json'

# Generated at 2022-06-25 15:27:51.292366
# Unit test for function find_template
def test_find_template():
    import pathlib
    test_dir = pathlib.Path(__file__).parent.absolute()
    assert find_template(test_dir) == test_dir / 'fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:28:00.945590
# Unit test for function find_template
def test_find_template():
    var_0 = None
    var_1 = None
    var_2 = None

    logger.debug('Testing find_template')
    try:
        find_template(var_0)
        raise ValueError('ValueError expected')
    except NonTemplatedInputDirException:
        pass
    except ValueError:
        raise
    except Exception as e:
        raise ValueError('Unexpected exception thrown: {}'.format(e))

    # Call the function with incorrect types of arguments
    try:
        find_template(var_1, var_2)
        raise ValueError('TypeError expected')
    except TypeError:
        pass
    except ValueError:
        raise
    except Exception as e:
        raise ValueError('Unexpected exception thrown: {}'.format(e))

# Generated at 2022-06-25 15:28:01.834108
# Unit test for function find_template
def test_find_template():
    test_case_0()



# Generated at 2022-06-25 15:28:03.038061
# Unit test for function find_template
def test_find_template():

    if not test_case_0() == NonTemplatedInputDirException:
        raise Exception

# Generated at 2022-06-25 15:28:54.019393
# Unit test for function find_template
def test_find_template():
    from pydevd  import settrace; settrace()
    repo_dir = None
    exception_raised = False

    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        exception_raised = True

    assert(exception_raised) == True

# Generated at 2022-06-25 15:28:56.940186
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    project_template = find_template(repo_dir)

    assert project_template.endswith('cookiecutter-{{ cookiecutter.project_name }}')

# Generated at 2022-06-25 15:28:58.132065
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:28:59.095729
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:29:04.092852
# Unit test for function find_template
def test_find_template():
    with open("test_find_template.txt", "w") as output:
        old_stdout = sys.stdout
        sys.stdout = output
        
        test_case_0()

        sys.stdout = old_stdout

    with open("test_find_template.txt", "r") as report:
        lines = report.readlines()
        assert(lines[-1] == "The project template appears to be None\n")

# Generated at 2022-06-25 15:29:09.933210
# Unit test for function find_template
def test_find_template():
    var_0 = os.path.abspath("tests/test-repo-pre/")

    assert find_template(var_0) == os.path.abspath("tests/test-repo-pre/cookiecutter-pypackage")

# Generated at 2022-06-25 15:29:12.537914
# Unit test for function find_template

# Generated at 2022-06-25 15:29:13.564876
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-25 15:29:14.392203
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:29:17.409597
# Unit test for function find_template
def test_find_template():
    float_1 = None
    var_1 = find_template(float_1)
    if var_1 != None:
        raise Exception(
            "Expected None, but got %s" % (
                var_1
            )
        )


# Generated at 2022-06-25 15:31:01.377847
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
        assert False
    except:
        pass



# Generated at 2022-06-25 15:31:02.098605
# Unit test for function find_template
def test_find_template():
    assert find_template == test_case_0

# Generated at 2022-06-25 15:31:05.376219
# Unit test for function find_template
def test_find_template():

    # Test with a un-templated directory as input
    float_0 = '.'
    var_0 = find_template(float_0)
    assert var_0 == './{{cookiecutter.repo_name}}'

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:31:06.305966
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)


# Generated at 2022-06-25 15:31:07.984307
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 15:31:13.058032
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(template_dir, '../tests/fake-repo-tmpl')
    assert find_template(template_dir) == os.path.join(template_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-25 15:31:13.902703
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None


# Generated at 2022-06-25 15:31:19.043084
# Unit test for function find_template
def test_find_template():
    try:
        find_template(None)
    except NonTemplatedInputDirException as e:
        assert str(e) == 'Input directory ({}) ' \
            'must contain a template'.format(None)
    except Exception as e:
        print(e)
    else:
        raise Exception("Unhandled exception was raised")
# end of unit test for function find_template


# # Unit test for function test_case_0
# def test_test_case_0():
#     try:
#         test_case_0()
#     except:
#         raise Exception("Unhandled exception was raised")
# # end of unit test for function test_case_0

# class TestClass:
#     # Unit test for function test_case_0
#     def test_test_case_0(self):
#         try:


# Generated at 2022-06-25 15:31:25.965767
# Unit test for function find_template
def test_find_template():
    # assert find_template(repo_dir) == expected
    assert find_template('C:\\Users\\dev\\.cookiecutters\\cookiecutter-pypackage') == 'C:\\Users\\dev\\.cookiecutters\\cookiecutter-pypackage\\{{cookiecutter.repo_name}}'
    assert find_template('') == ''



# Generated at 2022-06-25 15:31:28.793217
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_find import (
        test_case_0,
    )
    test_case_0()