

# Generated at 2022-06-25 15:22:04.155331
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:06.689215
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    assert str(type(var_0)).find('str') != -1, "Expected an instance of str"

# Generated at 2022-06-25 15:22:11.155435
# Unit test for function find_template
def test_find_template():
    var_0 = find_template('/tmp/cookiecutter-stamp/cookiecutter-pypackage')
    assert var_0 == '/tmp/cookiecutter-stamp/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:22:12.032931
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:14.660876
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print("Exception raised for test case 0")

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:22:16.480971
# Unit test for function find_template
def test_find_template():
    with pytest.raises(Exception):
        test_case_0()

test_find_template.__doc__ = find_template.__doc__

# Generated at 2022-06-25 15:22:18.512868
# Unit test for function find_template
def test_find_template():
    # Using arguments 0 (defaults)...
    with pytest.raises(NonTemplatedInputDirException) as e_1:
        find_template(None)


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 15:22:23.496169
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir='D:/dev/python/cookiecutter-pypackage/') == 'D:/dev/python/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:22:35.685984
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template(None) == None
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False
    try:
        assert find_template('dir_') == None
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False
    try:
        assert find_template('dir_1') == None
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False
    try:
        assert find_template(3) == None
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False
    try:
        assert find_template(4.5) == None
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

# Generated at 2022-06-25 15:22:36.338345
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-25 15:22:41.454583
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print("TEST CASE 0 FAILED:")
        print("NonTemplatedInputDirException was raised")
        assert False
    else:
        print("TEST CASE 0 PASSED")


# Generated at 2022-06-25 15:22:43.196187
# Unit test for function find_template
def test_find_template():
    with pytest.raises(AssertionError):
        find_template('abc')
    with pytest.raises(TypeError):
        find_template(test_case_0)

# Generated at 2022-06-25 15:22:49.048084
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/james/cookiecutter-django-rest-framework'
    project_template = find_template(repo_dir)
    print(project_template)
    assert project_template == '/home/james/cookiecutter-django-rest-framework/cookiecutter-django-rest-framework'


# Generated at 2022-06-25 15:22:54.437179
# Unit test for function find_template
def test_find_template():
    # No parameters passed
    # Setup mock object
    class MockClass1:
        pass
    bool_0 = MockClass1()
    # Now run the test and assert
    assert find_template(bool_0) == None
    # One parameter passed
    # Setup mock object
    bool_0 = None
    var_0 = find_template(bool_0)
    # Now run the test and assert
    assert var_0 == None

# Generated at 2022-06-25 15:23:02.024412
# Unit test for function find_template
def test_find_template():
    var_0 = None
    var_1 = "cookiecutter.json"
    var_2 = "cookiecutter"
    var_3 = "{{cookiecutter.project_slug}}"
    var_4 = "{{cookiecutter.project_name}}"
    var_5 = "{{cookiecutter.project_name}}"
    var_names = ["repo_dir", "repo_dir_contents", "item", "project_template"]
    var_values = [var_0, var_1, var_2, var_3, var_4, var_5]
    var_parent_names = [None, None, None, var_2, var_2, var_2]
    var_parents = [None for i in range(len(var_names))]

# Generated at 2022-06-25 15:23:12.217904
# Unit test for function find_template
def test_find_template():
    assert ('{{cookiecutter.' in find_template('/home/mmczarn/Desktop/projekt/studia/cookiecutter/tests/test-repo-pre/my-repo-template'))
    assert ('{{cookiecutter.' in find_template('/home/mmczarn/Desktop/projekt/studia/cookiecutter/tests/test-repo-pre/my-repo-template/'))

if __name__ == '__main__':
    if __package__ is None:
        import sys
        from os import path
        sys.path.append( path.dirname( path.dirname( path.abspath(__file__) ) ) )
        from components import find_template
    else:
        from ..components import find_template
    test_find_template()

# Generated at 2022-06-25 15:23:15.395243
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    assert var_0 is None

test_case_0()



# Generated at 2022-06-25 15:23:17.370653
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    assert var_0 == None


# Generated at 2022-06-25 15:23:28.826284
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)


# class CloneRepoTestSuite(TestSuite):
#     """Test suite for `clone_repo` function."""

#     def __init__(self):
#         """Construct items of test suite."""
#         logger.debug('Creating CloneRepoTestSuite')
#         self._items = [
#             TestCase(test_case_0, NonTemplatedInputDirException),
#         ]

#     @staticmethod
#     def name():
#         """Return the name of this test suite."""
#         return 'CloneRepoTestSuite'


# def run_clone_repo_test_suite():
#     """Run the CloneRepoTestSuite."""
#     print('Running Test Suite: CloneRepoTestSuite')
#     t =

# Generated at 2022-06-25 15:23:30.148868
# Unit test for function find_template
def test_find_template():
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:23:45.011564
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print("Test Case 0 Passed")
    try:
        assert find_template('C:\Python33\Lib\site-packages\cookiecutter\tests\test-find-template') == 'C:\Python33\Lib\site-packages\cookiecutter\tests\test-find-template\tpl'
    except NonTemplatedInputDirException as e:
        print(e)
    try:
        assert find_template('C:\Python33\Lib\site-packages\cookiecutter\tests\test-find-template\tpl') == 'C:\Python33\Lib\site-packages\cookiecutter\tests\test-find-template\tpl'
    except NonTemplatedInputDirException as e:
        print(e)

# Generated at 2022-06-25 15:23:46.838053
# Unit test for function find_template
def test_find_template():

    try:
        test_case_0()
        assert False
    except TypeError:
        assert True
    except NonTemplatedInputDirException:
        assert False

# Generated at 2022-06-25 15:23:52.180564
# Unit test for function find_template
def test_find_template():
    input_0 = "/W8yTtHpj9Y" # fixture for repo_dir
    expected_output_0 = "expect output" # expected return value

    #Invoke the tested function
    actual_output_0 = find_template(input_0)

    #Check if the return value and the expected return value are equal
    print('Expected output: {}'.format(expected_output_0))
    print('Actual output: {}'.format(actual_output_0))
    assert actual_output_0 == expected_output_0



# Generated at 2022-06-25 15:23:57.966674
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        logger.exception('An error occurred during the test.')

tests = [
    test_find_template,
]

if __name__ == '__main__':
    for test in tests:
        test()

# Generated at 2022-06-25 15:24:00.055088
# Unit test for function find_template
def test_find_template():
    assert find_template('/') # == '/'
    assert find_template('~') # == '~'
    assert find_template('/home') # == '/home'


# Generated at 2022-06-25 15:24:01.466297
# Unit test for function find_template
def test_find_template():
    try:
        find_template('test')
        assert True
    except:
        assert False


# Generated at 2022-06-25 15:24:03.607159
# Unit test for function find_template
def test_find_template():
    bool_0 = os.getcwd()
    var_0 = find_template(bool_0)



# Generated at 2022-06-25 15:24:05.668050
# Unit test for function find_template
def test_find_template():
    template = find_template(os.getcwd())
    assert isinstance(template, str)

# Generated at 2022-06-25 15:24:17.384246
# Unit test for function find_template
def test_find_template():
    # Test 3: Path to repo with project template
    repo_path = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'fake-repo-pre-gen',
            'tests',
            'test-case-0',
        )
    )
    expect_path = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'fake-repo-pre-gen',
            'tests',
            'test-case-0',
            '{{cookiecutter.repo_name}}'
        )
    )

    assert find_template(repo_path) == expect_path

# Generated at 2022-06-25 15:24:19.785059
# Unit test for function find_template
def test_find_template():
    assert find_template(bool_0) == None



# Generated at 2022-06-25 15:24:27.878504
# Unit test for function find_template
def test_find_template():
    with pytest.raises(NonTemplatedInputDirException) as exec_info:
        test_case_0()
# }}}

# Generated at 2022-06-25 15:24:31.195405
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)
    try:
        find_template(bool)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'ExpectedNonTemplatedInputDirException'

# Generated at 2022-06-25 15:24:33.201083
# Unit test for function find_template
def test_find_template():
    repo_dir = 'repo_dir'
    assert find_template(repo_dir) == 'repo_dir'
    return



# Generated at 2022-06-25 15:24:36.490635
# Unit test for function find_template
def test_find_template():
    assert 'my_test_folder/{{' in find_template('my_test_folder')


# Generated at 2022-06-25 15:24:45.557488
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('cookiecutter-pypackage/') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('cookiecutter-pypackage/test') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('cookiecutter-pypackage/test/') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('cookiecutter-pypackage/tests') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
   

# Generated at 2022-06-25 15:24:50.689827
# Unit test for function find_template
def test_find_template():
    var_0 = os.path.abspath('/Users/Ben/.cookiecutters/cookiecutter-test')
    var_1 = os.path.abspath('/Users/Ben/.cookiecutters/cookiecutter-test/{{cookiecutter.repo_name}}')
    assert find_template(var_0) == var_1
 

# Generated at 2022-06-25 15:24:53.034765
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/me/some-repo/{{cookiecutter.repo_name}}') == '/home/me/some-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:24:54.844852
# Unit test for function find_template
def test_find_template():
    assert find_template('../tests/files') == '../tests/files/{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:24:57.528756
# Unit test for function find_template
def test_find_template():
    assert find_template() == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:24:58.767784
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:25:12.543844
# Unit test for function find_template
def test_find_template():
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()


# Generated at 2022-06-25 15:25:15.701531
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)


'''
if __name__ == '__main__':
    # test_case_0()
    test_find_template()
'''

# Generated at 2022-06-25 15:25:21.529082
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(template_dir, 'fake-repo-pre/fake-repo')

    result = find_template(template_dir)
    assert result == os.path.join(template_dir, '{{cookiecutter.repo_name}}')

if __name__ == '__main__':
    test_find_template()
    test_case_0()

# Generated at 2022-06-25 15:25:24.401540
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException as e:
        assert str(e) == 'Missing repo_dir'
    else:
        raise Exception('NonTemplatedInputDirException was not raised.')

# Generated at 2022-06-25 15:25:32.240409
# Unit test for function find_template
def test_find_template():
    template_directory = os.path.abspath(__file__)
    template_directory = os.path.dirname(template_directory)
    template_directory = template_directory.split(os.sep)
    template_directory.pop()
    template_directory.append('templates')
    template_directory.append('example_template')
    template_directory = os.sep.join(template_directory)
    assert find_template(template_directory) == template_directory

# Generated at 2022-06-25 15:25:33.797709
# Unit test for function find_template
def test_find_template():
    test_case_0()


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:25:36.412031
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception:
        logger.exception('An unexpected exception occurred!')
    else:
        logger.info('Successfully executed test case!')

# Generated at 2022-06-25 15:25:41.638340
# Unit test for function find_template
def test_find_template():
    assert find_template('nonexistent/directory') == NonTemplatedInputDirException
    assert find_template('tests/fixtures/fake-repo-tmpl/{{cookiecutter.repo_name}}') == find_template('non_existent/directory')
    assert find_template('tests/fixtures/fake-repo-pre/{{cookiecutter.repo_name}}') == find_template('tests/fixtures/fake-repo-pre/{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:25:46.450805
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    assert var_0 == None

# Generated at 2022-06-25 15:25:57.840248
# Unit test for function find_template
def test_find_template():
    var_1 = os.path.join('path', 'to', 'repo')
    var_1 = unittest.mock.MagicMock(return_value=var_1)
    os.listdir.return_value = var_1
    var_2 = os.path.join('path', 'to', 'repo', 'cookiecutter-{{cookiecutter.repo_name}}')
    var_2 = unittest.mock.MagicMock(return_value=var_2)
    os.path.join.return_value = var_2

    with unittest.mock.patch('sys.stdout', new=io.StringIO()) as fake_out:
        test_case()

# Generated at 2022-06-25 15:26:27.313729
# Unit test for function find_template
def test_find_template():
    # Setup
    func = find_template
    non_templated_dir = os.path.join('non_templated_dir', '', 'not a real path')
    templated_dir = os.path.join('templated_dir', '', 'not a real path')

    # Default case
    try:
        assert func(non_templated_dir) == 'not a real path'
    except Exception as ex:
        assert type(ex) == NonTemplatedInputDirException

    # Non-default case
    assert func(templated_dir) == templated_dir

# Generated at 2022-06-25 15:26:31.986281
# Unit test for function find_template
def test_find_template():
    bool_0 = ''
    var_0 = find_template(bool_0)
    assert var_0 is None
    bool_0 = ''
    var_0 = find_template(bool_0)
    assert var_0 is None
    bool_0 = ''
    var_0 = find_template(bool_0)
    assert var_0 is None



# Generated at 2022-06-25 15:26:43.960297
# Unit test for function find_template
def test_find_template():
    assert find_template("{{cookiecutter.repo_name}}{{cookiecutter.repo_name}}{{cookiecutter.repo_name}}{{cookiecutter.repo_name}}") == "cookiecutter-pypackage{{cookiecutter.repo_name}}{{cookiecutter.repo_name}}{{cookiecutter.repo_name}}"
    assert find_template("{{cookiecutter.repo_name}}") == "cookiecutter-pypackage"

# Generated at 2022-06-25 15:26:46.451839
# Unit test for function find_template
def test_find_template():
    assert find_template(r'C:\GitHub\cookiecutter-pypackage') == r'C:\GitHub\cookiecutter-pypackage\{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:26:47.958105
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        print("Exception in testing.")

# Driver for function find_template

# Generated at 2022-06-25 15:26:48.714436
# Unit test for function find_template
def test_find_template():
    assert find_template(None)



# Generated at 2022-06-25 15:26:51.778910
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/Dev/Github/CodeLabs/lab-python-cookiecutter') == '/home/vagrant/Dev/Github/CodeLabs/lab-python-cookiecutter/hello-world'


# Generated at 2022-06-25 15:27:01.402038
# Unit test for function find_template
def test_find_template():
    print('Testing function find_template')

    try:
        test_case_0()
    except NameError:
        print('AssertionError: Please provide search directory.')
    else:
        print('AssertionError: Please provide search directory.')
    try:
        test_case_0()
    except:
        pass
    else:
        print('AssertionError: Invalid search directory.')


if __name__ == '__main__':
    print('Running unit test for function find_template')
    print('Unit test complete.')
    test_find_template()

# Generated at 2022-06-25 15:27:04.827117
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        logger.info(e)
        return False
    else:
        return True



# Generated at 2022-06-25 15:27:09.269713
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        assert False, "Unit test failure. Function 'find_template' raises exception: {}".format(e)
    # Place additional test cases here


# Run unit test in case this module is called directly
if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:28:01.592298
# Unit test for function find_template
def test_find_template():
    logger.debug('testing find_template()')
    # check that the function is callable (i.e. has an __call__ method)
    assert callable(find_template)


# Generated at 2022-06-25 15:28:02.460124
# Unit test for function find_template
def test_find_template():
    assert True



# Generated at 2022-06-25 15:28:03.600394
# Unit test for function find_template
def test_find_template():
    assert find_template('test_repo') == 'test_repo'

# Generated at 2022-06-25 15:28:06.027431
# Unit test for function find_template
def test_find_template():
    # print find_template("./tests/fake-repo-pre/")
    # This function does not use the contents of 'repo_dir' as an argument.
    pass

# Generated at 2022-06-25 15:28:09.170965
# Unit test for function find_template
def test_find_template():
    assert find_template(None) is None



# Generated at 2022-06-25 15:28:15.791564
# Unit test for function find_template
def test_find_template():
    """Test that the correct template is returned."""
    def _template_found(repo_dir, expected_output):
        """
        :raises AssertionError: If a directory that is not a template is found.
        """
        output = find_template(repo_dir)
        output = os.path.relpath(output, repo_dir)
        assert output == expected_output

    input_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-hook-repo'
    )

    _template_found(input_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-25 15:28:21.947726
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        logger.debug(e)
        logger.debug('Something went wrong :(')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:28:29.159804
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import exceptions
    import os
    import os.path

    # Create a new repo of this project for testing
    repo_dir = cookiecutter('.')

    project_template = find_template(repo_dir)
    assert isinstance(project_template, str)
    assert os.path.exists(project_template)
    assert os.path.isabs(project_template)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Now try to find the template in a directory that does not contain any
    # templated directories.
    repo_dir = cookiecutter('tests/test-case-1')

# Generated at 2022-06-25 15:28:31.875389
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == NonTemplatedInputDirException

# Generated at 2022-06-25 15:28:33.190228
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 15:30:22.329607
# Unit test for function find_template
def test_find_template():
    assert find_template({}) == NonTemplatedInputDirException

# Generated at 2022-06-25 15:30:26.258918
# Unit test for function find_template
def test_find_template():
    try:
        find_template(None)
    except Exception as e:
        if(e.__class__.__name__ == 'NonTemplatedInputDirException'):
            return 1
        else:
            return 0

#definitions of test cases

# Generated at 2022-06-25 15:30:27.825994
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:30:34.502635
# Unit test for function find_template
def test_find_template():
    # Unit:test_find_template_0
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass
    # Unit:test_find_template_1
    # Unit:test_find_template_2
    # Unit:test_find_template_3
    # Unit:test_find_template_4

# Generated at 2022-06-25 15:30:44.571764
# Unit test for function find_template
def test_find_template():

    # Tests for exceptions
    try:
        test_case_0()
    except Exception as e:
        if isinstance(e, NonTemplatedInputDirException):
            assert True
        else:
            assert False
    try:
        find_template('Jeff')
    except Exception as e:
        if isinstance(e, NonTemplatedInputDirException):
            assert True
        else:
            assert False

    # Tests valid input
    if os.name == 'nt':
        path_for_tests = 'C:\\Users\\Jeff\\Django\\cookiecutter-django\\cookiecutter_test'
    else:
        path_for_tests = '/Users/Jeff/Django/cookiecutter-django/cookiecutter_test'
    assert find_template(path_for_tests) == path_for

# Generated at 2022-06-25 15:30:45.713679
# Unit test for function find_template
def test_find_template():
    assert type(find_template(bool_0)) == str


# Generated at 2022-06-25 15:30:46.199170
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-25 15:30:46.958170
# Unit test for function find_template
def test_find_template():
    test_case_0()
    assert True

# Generated at 2022-06-25 15:30:50.542217
# Unit test for function find_template
def test_find_template():
    assert find_template(bool_0) == None
    repos_dir = os.path.abspath('repos')
    os.path.join(repos_dir, 'cookiecutter-pypackage')
    assert find_template(os.path.join(repos_dir, 'cookiecutter-pypackage')).endswith('tests/test-repo1/{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:30:51.934811
# Unit test for function find_template
def test_find_template():
    assert find_template() == "Template Found"