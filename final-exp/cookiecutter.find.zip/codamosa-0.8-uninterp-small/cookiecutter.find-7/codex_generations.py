

# Generated at 2022-06-25 15:22:05.937286
# Unit test for function find_template
def test_find_template():

    # This test is not yet implemented

    pass

# Generated at 2022-06-25 15:22:09.196995
# Unit test for function find_template
def test_find_template():
    assert 'cookiecutter/{{cookiecutter.repo_name}}/' == find_template('./cookiecutter')

# Generated at 2022-06-25 15:22:11.837422
# Unit test for function find_template
def test_find_template():
    template = find_template('./testproject')
    assert template is not None
    assert os.path.exists(template) is True
    assert os.path.basename(template) == 'test'

# Generated at 2022-06-25 15:22:13.401095
# Unit test for function find_template
def test_find_template():
    print('Testing find_template')
    #assert test_case_0() == False

# Generated at 2022-06-25 15:22:16.094381
# Unit test for function find_template
def test_find_template():
    test_case_0()
    template_dir = 'tests/fake-repo/'
    project_template = find_template(template_dir)
    assert project_template == os.path.join(
        template_dir,
        'fake-project-{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:22:18.962768
# Unit test for function find_template
def test_find_template():
    logger.debug('Testing the find_template function')
    assert test_case_0() == '("\xcc\r\xe4\x90\xbf\x10\x05\x87\x9cnK\xa0\xacO<\xa1'

# Generated at 2022-06-25 15:22:23.255432
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/fake-project/'
    except NonTemplatedInputDirException:
        pass



# Generated at 2022-06-25 15:22:34.685875
# Unit test for function find_template
def test_find_template():
    import os
    import shutil

    try:
      os.mkdir('repo_dir')
      files = ['cookiecutter-{{cookiecutter.project_name}}',
               os.path.join('cookiecutter', 'a.txt'), 
               os.path.join('cookiecutter', 'b.txt')] 
      for f in files:
        with open(os.path.join('repo_dir', f), 'w') as fh:
          fh.write('\n')
      assert find_template('repo_dir') == 'repo_dir/cookiecutter-{{cookiecutter.project_name}}'
    finally:
      shutil.rmtree('repo_dir')

# Generated at 2022-06-25 15:22:35.531472
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:22:37.169838
# Unit test for function find_template
def test_find_template():
    assert find_template('foo') is None


# Generated at 2022-06-25 15:22:39.622071
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:40.457863
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:22:41.704317
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:22:49.539457
# Unit test for function find_template
def test_find_template():
    import inspect
    import sys
    import traceback
    import unittest

    class FindTemplateTestCase(unittest.TestCase):
        def test_execute_case_0(self):
            try:
                test_case_0()
            except non_templated_input_dir_exception:
                pass

# Generated at 2022-06-25 15:22:58.400632
# Unit test for function find_template
def test_find_template():
    import tempfile

    def _test_find_template(expected_template_dirname, repo_subdirs):
        """Test that `find_template` finds the expected template"""
        # Create a temporary directory
        temp_repo_dir = tempfile.mkdtemp()
        # Create the subdirectories which contain the template
        for repo_subdir in repo_subdirs:
            os.makedirs(os.path.join(temp_repo_dir, repo_subdir))
        # Run find_template and assert that it finds the right template
        found_template_dir = find_template(temp_repo_dir)
        expected_template_dir = os.path.join(temp_repo_dir,
                                             expected_template_dirname)
        assert found_template_dir == expected_template_dir

   

# Generated at 2022-06-25 15:23:11.004585
# Unit test for function find_template
def test_find_template():
    from cookiecutter.generate import find_template
    from shutil import rmtree
    import os

    cache_dir_content = os.listdir(os.path.expanduser(os.path.join(
        '~', '.cookiecutters')))

    if 'example' in cache_dir_content:
        repo_dir = os.path.expanduser(os.path.join(
            '~', '.cookiecutters', 'example'))
        rmtree(repo_dir)
        repo_dir_content = os.listdir(os.path.expanduser(os.path.join(
            '~', '.cookiecutters')))
        assert 'example' not in repo_dir_content

    from cookiecutter import generate

# Generated at 2022-06-25 15:23:14.010190
# Unit test for function find_template
def test_find_template():
    assert(test_case_0() == None)

# Generated at 2022-06-25 15:23:15.745843
# Unit test for function find_template
def test_find_template():
    if not test_case_0():
        print("Test for function find_template Failed")
    else:
        print("Test for function find_template Passed")

# Generated at 2022-06-25 15:23:18.892083
# Unit test for function find_template
def test_find_template():
    os.chdir(os.getcwd())
    assert find_template('/home/abhishek/cookiecutter/tests/fixtures/test-repo-pre/') == '/home/abhishek/cookiecutter/tests/fixtures/test-repo-pre'

# Generated at 2022-06-25 15:23:22.825154
# Unit test for function find_template
def test_find_template():
    template_dir = find_template('/home/taoyc/mysite')
    assert template_dir == '/home/taoyc/mysite/{{cookiecutter.project_slug}}'


# Generated at 2022-06-25 15:23:33.500187
# Unit test for function find_template
def test_find_template():
    from cookiecutter.find import find_template

    # Case 0 - Path with no template
    template_path = "/tmp/foo/bar"
    assert find_template(template_path) is None

    # Case 1 - Path with a templated directory
    template_path = "/tmp/{{cookiecutter.repo_name}}/bar"
    assert find_template(template_path) == "/tmp/{{cookiecutter.repo_name}}"

    # Case 2 - Path with a templated directory in subdirectory
    template_path = "/tmp/foo/{{cookiecutter.repo_name}}/bar"
    assert find_template(template_path) == "/tmp/foo/{{cookiecutter.repo_name}}"

    # Case 3 - Path with a templated file

# Generated at 2022-06-25 15:23:40.169910
# Unit test for function find_template
def test_find_template():
    template_dir = find_template('/Users/mkissel/Projects/personal/git-repo/ncu-cecs-420-cookiecutter')
    assert template_dir == '/Users/mkissel/Projects/personal/git-repo/ncu-cecs-420-cookiecutter/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:23:49.071186
# Unit test for function find_template
def test_find_template():
    from os.path import abspath, dirname
    import pytest

    # Test case 0
    # Call the function with no arguments
    test_case_0()
    # Test case 1
    # Call the function as intended
    repo_dir = abspath(dirname(__file__)) + '/test-repo/'
    test_find_template = find_template(repo_dir)
    assert test_find_template == repo_dir + 'test-project/'
    # Test case 2
    # Call the function with no project template
    # This will throw a NonTemplatedInputDirException, which pytest will catch
    repo_dir = abspath(dirname(__file__)) + '/test-repo-notemplate/'
    with pytest.raises(NonTemplatedInputDirException):
        find_template

# Generated at 2022-06-25 15:23:52.053599
# Unit test for function find_template
def test_find_template():
    # set up
    repo_dir = 'tests/input/cookiecutter-pypackage/'

    # test
    var_0 = find_template(repo_dir)

    # check
    assert var_0 == 'tests/input/cookiecutter-pypackage/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-25 15:23:55.605511
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except (NameError, TypeError, SystemExit, IOError, ValueError,
            AttributeError, RuntimeError, NonTemplatedInputDirException) as e:
        pass
    else:
        raise AssertionError('Expected to raise '
                             'NonTemplatedInputDirException not raised')
    set_1 = ''
    var_1 = find_template(set_1)



# Generated at 2022-06-25 15:24:00.054967
# Unit test for function find_template
def test_find_template():
    # Path of directory to be used as a test repo
    test_repo_dir = os.path.join(os.path.dirname(__file__),
                                 '../tests/test-repo-for-cookiecutter-tests/')

    assert find_template(test_repo_dir) == os.path.join(test_repo_dir,
        '{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:24:03.141417
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    tests = (
        'input',
        os.path.join('{{cookiecutter.repo_name}}', 'cookiecutter.json'),
        'foo'
    )
    for test in tests:
        assert find_template(test) == test

# Generated at 2022-06-25 15:24:04.013144
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:24:14.099092
# Unit test for function find_template
def test_find_template():
    import os
    import shutil

    def setup():
        repo_dir = os.path.join(os.getcwd(), 'tests/test-find-template')
        if not os.path.exists(repo_dir):
            os.mkdir(repo_dir)
        subdirs = [
            'non-cookiecutter-dir',
            'cookiecutter-{{cookiecutter.repo_name}}-should-be-ignored',
            'cookiecutter-{{cookiecutter.repo_name}}',
        ]
        for subdir in subdirs:
            subdir_path = os.path.join(repo_dir, subdir)
            if not os.path.exists(subdir_path):
                os.mkdir(subdir_path)
        return repo_dir

   

# Generated at 2022-06-25 15:24:15.001729
# Unit test for function find_template
def test_find_template():
    assert find_template('..') == None

# Generated at 2022-06-25 15:24:27.745154
# Unit test for function find_template
def test_find_template():
    # Currently assumes test_find_template is called from test dir
    # todo: could probably find better way to do this
    pwd = os.getcwd()

# Generated at 2022-06-25 15:24:31.062955
# Unit test for function find_template
def test_find_template():
    test_input = 'tests/test-input/test-cookiecutter-master/'
    assert find_template(test_input) == 'tests/test-input/test-cookiecutter-master/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:24:31.994074
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:24:37.999120
# Unit test for function find_template
def test_find_template():
    import sys
    print('Testing function find_template')

    # Set test case 0
    print('  Set test case 0')
    set_0 = None
    find_template_exception_pass_0 = None
    try:
        var_0 = find_template(set_0)
    except:
        print('    Exception pass')

if __name__ == '__main__':
    sys.exit(test_case_0())

# Generated at 2022-06-25 15:24:52.060454
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
        assert 1, "test_case_0 failed."
    except:
        pass
    try:
        set_1 = None
        var_1 = find_template(set_1)
        assert 1, "test_case_1 failed."
    except:
        pass
    try:
        set_2 = None
        var_2 = find_template(set_2)
        assert 1, "test_case_2 failed."
    except:
        pass
    try:
        set_3 = None
        var_3 = find_template(set_3)
        assert 1, "test_case_3 failed."
    except:
        pass

# Generated at 2022-06-25 15:24:54.488398
# Unit test for function find_template
def test_find_template():
    from . import fake

    assert find_template(fake.repo_dir_path) == fake.expected_project_dir

# Generated at 2022-06-25 15:24:56.575566
# Unit test for function find_template
def test_find_template():
    assert find_template('/test/test_cookiecutter.py') is None

# Generated at 2022-06-25 15:25:06.241099
# Unit test for function find_template
def test_find_template():
    """
    Comfirms that the find_template function can correctly identify the 
    cookiecutter template directory within an example repo, and that it
    throws an exception if there is no cookiecutter template directory.
    """
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.utils import rmtree
    from test_utils import TEST_REPO_DIR

    template_dir = find_template(TEST_REPO_DIR)
    print(template_dir)
    assert os.path.exists(template_dir)
    assert template_dir.endswith('{{cookiecutter.project_slug}}')
    rmtree(TEST_REPO_DIR)


# Generated at 2022-06-25 15:25:07.833375
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:25:14.722368
# Unit test for function find_template
def test_find_template():
    assert find_template('test_dir') == os.path.join('test_dir', 'cookiecutter-test')
    assert find_template('test_dir2') == None
    assert find_template('test_dir3') == os.path.join('test_dir3', 'cookiecutter-test')

# Test non-existent directory should give error

# Generated at 2022-06-25 15:25:20.875041
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_find import test_case_0
    import sys
    import nose
    test_case_0
    args = [sys.argv[0], '-v']
    nose.main(argv=args)

test_find_template()

# Generated at 2022-06-25 15:25:23.845649
# Unit test for function find_template
def test_find_template():
    repo_dir = "~/repo"
    logger.debug('Searching %s for the project template.', repo_dir)
    try:
        find_template(repo_dir)
        assert False
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-25 15:25:25.445759
# Unit test for function find_template
def test_find_template():
    set_0 = None
    var_0 = find_template(set_0)
    assert var_0 == None


# Generated at 2022-06-25 15:25:30.035223
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        if not isinstance(e, NonTemplatedInputDirException):
            raise e

# Generated at 2022-06-25 15:25:36.792172
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils.paths import TEST_COOKIE_PROJECT, TEST_REPO_DIR
    from cookiecutter.exceptions import NonTemplatedInputDirException
    import os

    expected_dir = os.path.join(TEST_REPO_DIR, '{{cookiecutter.repo_name}}')
    repo_dir = TEST_REPO_DIR

    assert find_template(repo_dir) == expected_dir
    assert find_template(repo_dir) != TEST_COOKIE_PROJECT

# Generated at 2022-06-25 15:25:39.669565
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:25:40.664029
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:25:54.657691
# Unit test for function find_template
def test_find_template():
    set_0 = 'an'
    var_0 = find_template(set_0)
    var_0 = find_template(set_0)
    var_0 = find_template(set_0)
    var_0 = find_template(set_0)
    var_0 = find_template(set_0)

    set_1 = 'an'
    var_1 = find_template(set_1)
    var_1 = find_template(set_1)
    var_1 = find_template(set_1)
    var_1 = find_template(set_1)
    var_1 = find_template(set_1)

    set_2 = 'an'
    var_2 = find_template(set_2)
    var_2 = find_template(set_2)
    var_2

# Generated at 2022-06-25 15:26:00.710454
# Unit test for function find_template
def test_find_template():
    # The function takes one argument, a string
    assert callable(find_template)
    # The function raises NonTemplatedInputDirException if there is no template
    # in the directory
    assert_raises(NonTemplatedInputDirException, find_template, None)

# Generated at 2022-06-25 15:26:04.303538
# Unit test for function find_template
def test_find_template():
    directory = "/home/paul/Documents/cookiecutter-pypackage/{{cookiecutter.project_slug}}"
    assert find_template("/home/paul/Documents/cookiecutter-pypackage") == directory

# Generated at 2022-06-25 15:26:09.067716
# Unit test for function find_template
def test_find_template():
    find_template('I:/tmp/Tmp_Cookie/tmpo4j8byuk')

# Generated at 2022-06-25 15:26:17.324672
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    from tempfile import mkdtemp

    test_loc = "test_location"
    tempdir = mkdtemp()
    test_dir = os.path.join(tempdir, test_loc)

    # Test the simple case of a non templated dir
    os.makedirs(test_dir)
    try:
        find_template(test_dir)
        assert False, "Did not raise NonTemplatedInputDirException"
    except NonTemplatedInputDirException:
        assert True

    # Test the simple case of finding a templated dir
    os.makedirs(os.path.join(test_dir,'{{cookiecutter.test_dir}}'))
    result = find_template(test_dir)

# Generated at 2022-06-25 15:26:19.461503
# Unit test for function find_template
def test_find_template():
    find_template('examples')


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:21.485561
# Unit test for function find_template
def test_find_template():
    set_0 = "/home/vagrant/cookiecutter-django"
    var_0 = find_template(set_0)
    test_case_0()



# Generated at 2022-06-25 15:26:26.194415
# Unit test for function find_template

# Generated at 2022-06-25 15:26:30.442054
# Unit test for function find_template
def test_find_template():
    # Setup
    set_0 = None
    # Exercise
    var_0 = find_template(set_0)

    # Verify
    print("find_template:", var_0)
    assert 0


if __name__ == "__main__":
    values = test_find_template()
    print(values)

# Generated at 2022-06-25 15:26:34.914140
# Unit test for function find_template
def test_find_template():
    # Test case 1:
    set_1 = './tests/test-repos/abspath'
    var_1 = find_template(set_1)
    assert var_1 == './tests/test-repos/abspath/{{cookiecutter.repo_name}}'
    # Test case 2:
    set_2 = './tests/test-repos/git+https'
    var_2 = find_template(set_2)
    assert var_2 ==\
        './tests/test-repos/git+https/{{cookiecutter.repo_name}}'
    # Test case 3:
    set_3 = './tests/test-repos/git+ssh'
    var_3 = find_template(set_3)

# Generated at 2022-06-25 15:26:41.742342
# Unit test for function find_template
def test_find_template():
    set_1 = 'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    var_1 = find_template(set_1)
    assert var_1 == 'tests/test-repo-pre/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:26:44.881933
# Unit test for function find_template
def test_find_template():
    find_template_cases = [
        # (input, output)
        (''),
    ]
    for case in find_template_cases:
        yield unit_test_find_template, case[0], case[1]



# Generated at 2022-06-25 15:26:48.081940
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo/fake-repo-tmpl') == 'tests/test-repo/fake-repo-tmpl/fake-project-{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:27:01.727498
# Unit test for function find_template
def test_find_template():
    assert(find_template('/Users/hafeez/Documents/src/bootstrap-cookiecutter') ==
           '/Users/hafeez/Documents/src/bootstrap-cookiecutter/{{cookiecutter.project_name}}')


if __name__ == '__main__':
    import nose
    nose.main()

# Generated at 2022-06-25 15:27:06.082276
# Unit test for function find_template
def test_find_template():
    config = {'cookiecutters_dir': 'C:\\Users\\johndoe\\.cookiecutters'}
    set_0 = config['cookiecutters_dir']
    var_0 = find_template(set_0)
    assert var_0 is None


# Generated at 2022-06-25 15:27:08.680879
# Unit test for function find_template
def test_find_template():

    assert find_template(os.path.join('tests', 'fake-repo-pre')) == os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:27:11.709372
# Unit test for function find_template
def test_find_template():
    set_0 =  {'/home/joe/template': 'Joe'}
    var_0 = find_template(set_0)




# Generated at 2022-06-25 15:27:17.884272
# Unit test for function find_template
def test_find_template():
    assert find_template('C:/Users/guita/Desktop/sutd_programming/cookiecutter-pypackage-minimal')
    
    
    

# print(find_template('C:/Users/guita/Desktop/sutd_programming/cookiecutter-pypackage-minimal'))
# test_find_template()

# Generated at 2022-06-25 15:27:18.801578
# Unit test for function find_template
def test_find_template():
    assert find_template == test_case_0

# Generated at 2022-06-25 15:27:23.434220
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        assert False


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:27:29.905700
# Unit test for function find_template
def test_find_template():
    # test_case_0

    # test_case_1
    set_1 = b'/Users/lgonzalez/Documents/github/cookiecutter/tests/test-input/abutcher-master/bacon-ipsum'
    var_1 = find_template(set_1)
    assert var_1 == '/Users/lgonzalez/Documents/github/cookiecutter/tests/test-input/abutcher-master/bacon-ipsum/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:27:33.336279
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as err:
        print(err)

# Conform to PEP8
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 15:27:41.230735
# Unit test for function find_template
def test_find_template():
    os.environ['REPO_DIR'] = 'tests/files/fake-repo'
    logging.disable(logging.CRITICAL)
    assert find_template(os.environ['REPO_DIR']) == 'tests/files/fake-repo/cookiecutter-pypackage'

# Generated at 2022-06-25 15:27:56.927628
# Unit test for function find_template
def test_find_template():
    if os.path.exists('/tmp/test-repo'):
        os.system('rm -rf /tmp/test-repo')
    os.system('git clone https://github.com/alembic/cookiecutter-alembic-pylons.git /tmp/test-repo')
    repo_dir = '/tmp/test-repo/cookiecutter-alembic-pylons'
    assert find_template(repo_dir) == '/tmp/test-repo/cookiecutter-alembic-pylons/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:28:06.428348
# Unit test for function find_template
def test_find_template():
    import mock

    mocked_repo_dir = mock.Mock()
    mocked_repo_dir.listdir = mock.Mock(return_value=['foo', 'bar', 'baz', 'cookiecutter-foo'])
    mocked_repo_contents = mock.Mock()
    mocked_repo_contents.__iter__ = mock.Mock(return_value=['foo', 'bar', 'baz', 'cookiecutter-foo'].__iter__())
    mocked_repo_dir.__iter__ = mock.Mock(return_value=mocked_repo_contents.__iter__())
    mocked_repo_dir.join = mock.Mock(return_value='cookiecutter-foo')
    res = find_template(mocked_repo_dir)

# Generated at 2022-06-25 15:28:10.460862
# Unit test for function find_template
def test_find_template():
    assert find_template("test_dir") == "test_dir/test_project"

test_find_template()

# Generated at 2022-06-25 15:28:11.896288
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NameError as e:
        pass
    else:
        raise Exception(
            'ExpectedNameError not raised in template finder test case 0'
        )



# Generated at 2022-06-25 15:28:12.703794
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:28:24.459945
# Unit test for function find_template
def test_find_template():

    # Check whether function can handle expected input (1)
    repo_dir = "/Users/Mick/Local/Code/cookiecutter-pytest-kos/test/_test_create_dir"
    project_dir = os.path.join(repo_dir, "test")
    set_0 = repo_dir
    var_0 = find_template(set_0)
    assert var_0 == project_dir

    # Check whether function can handle expected input (2)
    repo_dir = "/Users/Mick/Local/Code/cookiecutter-pytest-kos/test/_test_create_dir"
    project_dir = os.path.join(repo_dir, "test1")
    set_1 = repo_dir + "/" + "test1"
    assert find_template(set_1) == project_dir

   

# Generated at 2022-06-25 15:28:29.653476
# Unit test for function find_template
def test_find_template():
    test_cases = [
        {'input': '/home/audreyr/cookiecutter-pypackage',
         'expected': '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'},
        {'input': '/home/audreyr/test',
         'expected': None},
        {'input': '/home/audreyr/cookiecutter-pypackage/',
         'expected': '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'},
    ]
    for case in test_cases:
        actual = find_template(case['input'])

# Generated at 2022-06-25 15:28:35.594905
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(test_dir, 'fake-repo-pre-gen')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:28:37.022390
# Unit test for function find_template
def test_find_template():
    # Test case 0
    set_0 = 'input_dir'
    var_0 = find_template(set_0)

# Generated at 2022-06-25 15:28:41.544973
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print('set_0 test case passed for NonTemplatedInputDirException')
    except:
        print('set_0 test case failed for NonTemplatedInputDirException')

    try:
        test_case_1()
    except NonTemplatedInputDirException:
        print('set_1 test case passed for NonTemplatedInputDirException')
    except:
        print('set_1 test case failed for NonTemplatedInputDirException')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:29:07.081131
# Unit test for function find_template
def test_find_template():
    """ """

# Generated at 2022-06-25 15:29:09.777559
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-output/repo_dir') == 'tests/test-output/repo_dir/cookiecutter-pypackage'

# Generated at 2022-06-25 15:29:12.025801
# Unit test for function find_template
def test_find_template():
    test_set_0 = None
    var_1 = find_template(test_set_0)


# Generated at 2022-06-25 15:29:14.276070
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/toddrobinson/src/Cookicutter/cookiecutter'
    project_template = find_template(repo_dir)
    assert 'cookiecutter-skeleton' in project_template

# Generated at 2022-06-25 15:29:18.620388
# Unit test for function find_template
def test_find_template():
    set_1 = '/home/username/cookiecutters/my-new-cookiecutter-project'
    var_1 = find_template(set_1)
    assert var_1 == '/home/username/cookiecutters/my-new-cookiecutter-project/{{cookiecutter.repo_name}}'


# Generated at 2022-06-25 15:29:22.259081
# Unit test for function find_template
def test_find_template():
    import itertools
    import nose.tools as nt
    import os

    set_0 = 'abc'
    var_0 = find_template(set_0)


# Generated at 2022-06-25 15:29:30.790123
# Unit test for function find_template
def test_find_template():
    repo_dir = 'https://github.com/contortus/cookiecutter-python-cli'
    
    #Test 1
    project_template = find_template(repo_dir)
    assert  project_template == 'https://github.com/contortus/cookiecutter-python-cli/cookiecutter-python-cli/docs/conf.py'
    
    #Test 2
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        project_template = None

    assert project_template == None
    

     

# Generated at 2022-06-25 15:29:31.650923
# Unit test for function find_template
def test_find_template():
    assert find_template=="test_case_0()"

# Generated at 2022-06-25 15:29:40.584828
# Unit test for function find_template
def test_find_template():
    set_1 = {'os': {'sep': '/'}, 'os.path': {'abspath': 'jklmnopqr'},
        'cookiecutter': {}}
    var_1 = find_template(set_1)
    assert var_1 == 'jklmnopqr/{{cookiecutter.repo_name}}', \
        "Expected value does not match actual value."

    set_2 = {'os': {'sep': '/'}, 'os.path': {'abspath': 'abcdefghi'},
        'cookiecutter': {}}
    var_2 = find_template(set_2)
    assert var_2 == 'abcdefghi/{{cookiecutter.repo_name}}', \
        "Expected value does not match actual value."

    set_

# Generated at 2022-06-25 15:29:49.014290
# Unit test for function find_template
def test_find_template():
    """Test test_find_template function."""
    from cookiecutter import find
    set_0 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    var_0 = find.find_template(set_0)
    test_1 = assert_equals('cookiecutter-pypackage/{{cookiecutter.repo_name}}', var_0)
    test_1
    if test_1:
        print('SUCCESS: find.find_template')
    else:
        print('FAIL: find.find_template')


# Generated at 2022-06-25 15:30:42.279322
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:30:48.515005
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_case_0(os.path.join(test_dir, 'test_files', 'repo_without_cookiecutter_json'))
    test_case_1(os.path.join(test_dir, 'test_files', 'find_template'))
    test_case_2(os.path.join(test_dir, 'test_files', 'Cookiecutter-Puppet-Module'))
    test_case_3(os.path.join(test_dir, 'test_files', 'cookiecutter-pypackage'))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:30:52.545408
# Unit test for function find_template
def test_find_template():
    set_0 = 'repo_dir'
    var_1 = find_template(set_0)
    assert var_1 == 'repo_dir/cookiecutter-{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:31:00.210994
# Unit test for function find_template
def test_find_template():
    import os
    import mock
    import unittest
    with mock.patch('os.listdir') as mock_listdir:
        mock_listdir.return_value = ['test_template']
        test_case_0()

# Run unit tests
if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 15:31:02.447910
# Unit test for function find_template
def test_find_template():
    test_case_0()
    #print(var_0)
    assert var_0 is None, 'Expected None, got {0}'.format(var_0)

# Generated at 2022-06-25 15:31:06.256380
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print('pass')
        return
    assert False

if __name__ == '__main__':
    #test_find_template()
    #find_template('')
    print(find_template(os.getcwd()))

# Generated at 2022-06-25 15:31:13.689960
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as ex:
        if ex.__class__.__name__ == 'NonTemplatedInputDirException':
            print(ex.__class__.__name__)
            e = ex.__class__.__name__
            if e == 'NonTemplatedInputDirException':
                print('TEST OK')
            else:
                print('TEST ERROR')
        else:
            print('TEST ERROR')
    else:
        print('TEST OK')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:31:20.776229
# Unit test for function find_template
def test_find_template():
    """
    Function find_template() should find the child directory of a given directory
    (set_0) which contains 'cookiecutter' and '{{' and '}}'.  Then it should return
    the relative path to that directory.
    """
    set_0 = 'C:/Users/Matt/Documents/GitHub/cookiecutter-pypackage'
    var_0 = find_template(set_0)
    var_1 = 'C:/Users/Matt/Documents/GitHub/cookiecutter-pypackage/cookiecutter-pypackage'
    assert var_0 == var_1
    set_1 = 'C:/Users/Matt/Documents/GitHub/cookiecutter-pypackage/cookiecutter-pypackage'
    var_0 = find_template(set_1)
   

# Generated at 2022-06-25 15:31:25.180264
# Unit test for function find_template
def test_find_template():
    # example to show how to log an error
    try:
        test_case_0()
    except NonTemplatedInputDirException as e:
        logger.exception('test_case_0: Input dir not templated')


# Generated at 2022-06-25 15:31:26.186659
# Unit test for function find_template
def test_find_template():
    set_0 = None
    result_0 = None
    assert test_case_0() == result_0

