

# Generated at 2022-06-25 15:22:09.355231
# Unit test for function find_template
def test_find_template():
    find_template_args_0 = {"repo_dir": bool}
    find_template_ans_0 = {'project_template': None}
    test_0 = (find_template_args_0, find_template_ans_0)

    find_template_args_1 = ["repo_dir", None]
    find_template_ans_1 = {'project_template': False}
    test_1 = (find_template_args_1, find_template_ans_1)

    find_template_args_2 = ["repo_dir", None]
    find_template_ans_2 = {'project_template': False}
    test_2 = (find_template_args_2, find_template_ans_2)

    tests = [test_0, test_1, test_2]

# Generated at 2022-06-25 15:22:15.387326
# Unit test for function find_template
def test_find_template():
    repo_dir = "/home/user/"
    project_template = "/home/user/cookiecutter_project_template"
    test_listdir = ["cookiecutter_project_template"]
    test_isfile = False
    test_isdir = True
    os.listdir = lambda x: test_listdir
    os.path.isfile = lambda x: test_isfile
    os.path.isdir = lambda x: test_isdir
    assert(find_template(repo_dir) == project_template)


# Generated at 2022-06-25 15:22:16.243374
# Unit test for function find_template
def test_find_template():
    assert isinstance(find_template, object)

# Generated at 2022-06-25 15:22:17.085260
# Unit test for function find_template
def test_find_template():

    assert test_case_0() == None

# Generated at 2022-06-25 15:22:19.249298
# Unit test for function find_template
def test_find_template():
    
    try:
        assert find_template("boolean") == None # True # None # 
    except NonTemplatedInputDirException:
        assert True



# Test this test.
test_case_0()

# Generated at 2022-06-25 15:22:21.829094
# Unit test for function find_template
def test_find_template():
    assert find_template(None)



# Generated at 2022-06-25 15:22:24.910026
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:22:28.547376
# Unit test for function find_template
def test_find_template():
    PATH_0 = 'test_case_0'
    find_template(PATH_0)


# Generated at 2022-06-25 15:22:29.505517
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)


# Generated at 2022-06-25 15:22:30.613712
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:22:33.261801
# Unit test for function find_template
def test_find_template():
    assert find_template("foo")



# Generated at 2022-06-25 15:22:36.336696
# Unit test for function find_template
def test_find_template():
    var_1 = find_template('./tests/files/fake-repo-pre/')
    assert var_1 == './tests/files/fake-repo-pre/{{cookiecutter.repo_name}}'


# Generated at 2022-06-25 15:22:39.708990
# Unit test for function find_template
def test_find_template():
    from cookiecutter import find, generate

    repo_dir = generate.clone(
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    )
    project_template = find.find_template(repo_dir)
    assert project_template == repo_dir



# Generated at 2022-06-25 15:22:40.865212
# Unit test for function find_template
def test_find_template():
    assert True == True

# Linter entry-point

# Generated at 2022-06-25 15:22:46.417826
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        return False
    else:
        return True

# Generated at 2022-06-25 15:22:48.828941
# Unit test for function find_template
def test_find_template():
    var_0 = find_template('')
    assert var_0 == ''


# Generated at 2022-06-25 15:22:56.957855
# Unit test for function find_template
def test_find_template():
    try:
        assert callable(find_template)
    except NameError:
        return "function find_template not defined"
    if not find_template('http://github.com/audreyr/cookiecutter-pypackage'):
        return "Incorrect values returned"
    if not find_template('https://github.com/audreyr/cookiecutter-pypackage.git'):
        return "Incorrect values returned"
    if not find_template('git+https://github.com/audreyr/cookiecutter-pypackage.git'):
        return "Incorrect values returned"

    return "function find_template ran to completion"

print(test_find_template())

# Generated at 2022-06-25 15:23:01.318911
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 15:23:02.802308
# Unit test for function find_template
def test_find_template():
    # Test cases
    assert find_template(repo_dir='a') == 'a'

# Generated at 2022-06-25 15:23:07.144167
# Unit test for function find_template
def test_find_template():
    bool_0 = True
    var_0 = find_template(bool_0)
    var_1 = find_template(bool_0)
    assert var_0 == var_1
    print("find_template: ", var_0)


if __name__ == "__main__":
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:23:11.105833
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception:
        print("Failed to test function: find_template")

# Generated at 2022-06-25 15:23:16.437187
# Unit test for function find_template
def test_find_template():
    logging.basicConfig(level=logging.DEBUG)
    assert find_template('repo_dir') == find_template('repo_dir')
# print(find_template('repo_dir'))
# test_find_template()

# Generated at 2022-06-25 15:23:20.330293
# Unit test for function find_template
def test_find_template():
    with open('cookiecutter.log', 'r') as log:
        assert 'CRITICAL:cookiecutter.finders:Searching None for the project template.\n' in log.readlines()
    os.remove('cookiecutter.log')

if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:23:21.902617
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)


# Generated at 2022-06-25 15:23:26.430740
# Unit test for function find_template
def test_find_template():
    template_name1 = "cookiecutter-pypackage/"
    #check if the right template is found
    assert find_template("cookiecutter-pypackage/") == template_name1
    #check if any exception is thrown
    assert test_case_0() == None

# Unit test function for function get_template

# Generated at 2022-06-25 15:23:27.394808
# Unit test for function find_template
def test_find_template():
    assert find_template == find_template

# Generated at 2022-06-25 15:23:30.198476
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:34.760261
# Unit test for function find_template
def test_find_template():
    repo_dir = '{{ cookiecutter-repo }}'
    expected_output = '{{ cookiecutter-repo }}/{{ cookiecutter.project_template }}'
    # assert find_template(repo_dir) == expected_output
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        return '{{ cookiecutter.project_template }} not found'

# Generated at 2022-06-25 15:23:38.982887
# Unit test for function find_template
def test_find_template():

    # Example of a "Cookiecutter" project template

    # Create a temporary working directory for the purposes of testing.
    test_dir = tempfile.mkdtemp()
    test_case_0(test_dir)

    # Clean up.
    shutil.rmtree(test_dir)

# Generated at 2022-06-25 15:23:47.865596
# Unit test for function find_template
def test_find_template():
    # check for path with cookiecutter in it but not brackets
    if os.path.exists('/tmp/test_find_template/cookiecutter'):
        os.system('rm -rf /tmp/test_find_template')
    os.system('mkdir /tmp/test_find_template')
    os.system('touch /tmp/test_find_template/cookiecutter')
    var_0 = find_template('/tmp/test_find_template')
    assert var_0 == None
    # check for path with cookiecutter but only one bracket
    os.system('rm -rf /tmp/test_find_template')
    os.system('mkdir /tmp/test_find_template')
    os.system('touch /tmp/test_find_template/cookiecutter{{')
    var_0 = find_template

# Generated at 2022-06-25 15:23:54.939314
# Unit test for function find_template
def test_find_template():
    os.chdir('tests')

    var_0 = find_template('cloned-repo-simple')
    assert var_0 == 'cloned-repo-simple/{{cookiecutter.repo_name}}'

    var_1 = find_template('cloned-repo-complex')
    assert var_1 == 'cloned-repo-complex/{{cookiecutter.repo_name}}'

    os.chdir('..')


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-25 15:24:00.061144
# Unit test for function find_template
def test_find_template():
    # Setup
    variable_0 = find_template(None)
    variable_1 = find_template(True)
    variable_2 = find_template(123)
    variable_3 = find_template(123.456)
    variable_4 = find_template(["a", "b", "c"])
    variable_5 = find_template(("a", "b", "c"))
    variable_6 = find_template({1, 2, 3})
    variable_7 = find_template({1: 1, 2: 2, 3: 3})
    variable_8 = find_template("def")
    variable_9 = find_template("abcdef")

    # assert
    assert variable_0 == "abcdef", "assert #1 failed"
    assert variable_1 == "abcdef", "assert #2 failed"
    assert variable_2

# Generated at 2022-06-25 15:24:00.850138
# Unit test for function find_template
def test_find_template():
    try:
        assert True # TODO: implement your test here
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 15:24:05.354307
# Unit test for function find_template

# Generated at 2022-06-25 15:24:12.538991
# Unit test for function find_template
def test_find_template():
    # This is an example of what a test case might look like.  Think of them
    # as a piece of documentation of how a function is supposed to work.  Try
    # to write a test case for each scenario that you can envision for a
    # function.  Think about edge cases, too.
    assert find_template(None) == None


# Generated at 2022-06-25 15:24:19.442022
# Unit test for function find_template
def test_find_template():
    assert find_template("test_input") == "test_input/cookiecutter-{{cookiecutter.project_name.replace(' ', '_')}}"


# Generated at 2022-06-25 15:24:23.996969
# Unit test for function find_template
def test_find_template():
    try:
        capture_stdout(test_case_0)
    except Exception as e:
        assert type(e) == NonTemplatedInputDirException
        assert str(e) == 'Could not find a Jinja2-flavored project template in /home/theo/Scratch/cookiecutter'


# Generated at 2022-06-25 15:24:31.240781
# Unit test for function find_template
def test_find_template():
    var_1 = os.path.join('tests/test-input/{{cookiecutter.repo_name}}/')
    var_0 = find_template(var_1)
    if isinstance(var_0, str) and var_0.count('/') == 2:
        print('Value of str  <{}>  tested to be True'.format(var_0))
    else:
        print('Value of str  <{}>  tested to be False'.format(var_0))
    assert(isinstance(var_0, str))

test_find_template()

# Generated at 2022-06-25 15:24:32.178150
# Unit test for function find_template
def test_find_template():
    assert 1 == 1


# Generated at 2022-06-25 15:24:34.782208
# Unit test for function find_template
def test_find_template():
    template_dir = 'tests/files/fake-repo'
    result = find_template(template_dir)
    assert result == os.path.join(template_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-25 15:24:39.698681
# Unit test for function find_template
def test_find_template():
    from pytest import raises
    from cookiecutter.exceptions import NonTemplatedInputDirException

    with raises(NonTemplatedInputDirException):
        test_case_0()

# Generated at 2022-06-25 15:24:41.395843
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    var_1 = find_template(os.getcwd())



# Generated at 2022-06-25 15:24:42.812382
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    assert find_template(bool_0) == find_template(bool_0)



# Generated at 2022-06-25 15:24:44.694351
# Unit test for function find_template
def test_find_template():
    test_case_0()


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:49.365072
# Unit test for function find_template
def test_find_template():
    t = find_template('/Users/aurora/Desktop/Git/cookiecutter-pypackage/')
    assert t == '/Users/aurora/Desktop/Git/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-25 15:24:52.525387
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.exceptions import UndefinedVariableInTemplate
    from jinja2 import UndefinedError

    with pytest.raises(UndefinedError):
        find_template(None)

# Generated at 2022-06-25 15:24:54.042530
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    assert var_0 == False
    return locals()

# Generated at 2022-06-25 15:24:54.846670
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-25 15:25:05.738363
# Unit test for function find_template
def test_find_template():
    bool_0 = bool(find_template("cookiecutter"))
    bool_1 = bool(find_template("cookiecutter"))
    bool_2 = bool(find_template("cookiecutter"))
    bool_3 = bool(find_template("cookiecutter"))
    bool_4 = bool(find_template("cookiecutter"))
    bool_5 = bool(find_template("cookiecutter"))
    bool_6 = bool(find_template("cookiecutter"))
    bool_7 = bool(find_template("cookiecutter"))
    bool_8 = bool(find_template("cookiecutter"))
    bool_9 = bool(find_template("cookiecutter"))
    assert bool_0 is bool_1 is bool_2
    assert bool_1 is bool_2 is bool_3
    assert bool_2 is bool_3 is bool

# Generated at 2022-06-25 15:25:07.700494
# Unit test for function find_template
def test_find_template():
    assert find_template(bool_0) == None, 'Expected None, but returned: ' + find_template(bool_0)

# Generated at 2022-06-25 15:25:15.931224
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()

    # unit test success
    except:
        return 0

    # unit test failure
    else:
        return 1

# Generated at 2022-06-25 15:25:17.606474
# Unit test for function find_template

# Generated at 2022-06-25 15:25:21.282557
# Unit test for function find_template
def test_find_template():

    try:
        test_case_0()
    except NonTemplatedInputDirException as error:
        return str(error) == 'Could not find a templated project.'
    except Exception as error:
        return str(error) == 'Could not find a templated project.'
    else:
        return False

# Generated at 2022-06-25 15:25:27.755680
# Unit test for function find_template
def test_find_template():
    assert (call(find_template, ("test/fake-repo-tmpl",)) == "test/fake-repo-tmpl/fake-project-tmpl")
    assert (call(find_template, ("test/fake-repo-pre/",)) == "test/fake-repo-pre/fpp")
    assert (call(find_template, ("test/fake-repo-post/",)) == "test/fake-repo-post/fpo")
    assert (call(find_template, ("test/fake-repo-rm/",)) == "test/fake-repo-rm/fr")
    assert (call(find_template, ("test/fake-repo-big-cookiecutter-json/",)) == "test/fake-repo-big-cookiecutter-json/foo")

# Generated at 2022-06-25 15:25:34.165442
# Unit test for function find_template
def test_find_template():
    sample_dir = os.path.dirname(__file__)
    repo_dir = os.path.join(sample_dir, '..', 'fake-repo')

    project_template = find_template(repo_dir)

    assert 'cookiecutter-pypackage/{{cookiecutter.repo_name}}' in project_template


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:25:42.505212
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    import os
    import shutil
    import tempfile
    from cookiecutter.utils import rmtree

    # Since we are testing dir creation, we don't want to actually
    # delete the directories we create.
    rmtree = lambda d: None

    tmp_dir = tempfile.mkdtemp()
    template = os.path.join(tmp_dir, 'foo')
    clone_dir = os.path.join(tmp_dir, 'foo_clone')
    try:
        # Create a simple template
        os.makedirs(template)
        main.cookiecutter(
            template, no_input=True, output_dir=clone_dir,
            overwrite_if_exists=True, replay=False
        )
    finally:
        rmtree(template)
        rmt

# Generated at 2022-06-25 15:25:49.775633
# Unit test for function find_template
def test_find_template():
    from random import randint
    from string import letters
    from os.path import join
    from tempfile import mkdtemp
    from shutil import rmtree
    from mock import patch, mock_open
    from cookiecutter.find import find_template

    # Setup
    repo_dir = mkdtemp()
    logger.debug('Created temp repo_dir %s', repo_dir)

    # Create the project template
    project_template = mkdtemp(dir=repo_dir)
    logger.debug('Created temp project_template %s', project_template)

    # Create a number of child directories in the repo that should be
    # ignored as the project template
    for i in range(10):
        ignore = mkdtemp(dir=repo_dir)
        logger.debug('Created temp ignore %s', ignore)

    # Patch

# Generated at 2022-06-25 15:25:50.185052
# Unit test for function find_template
def test_find_template():
    assert True == True

# Generated at 2022-06-25 15:25:52.378808
# Unit test for function find_template
def test_find_template():
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException as e:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:25:56.471718
# Unit test for function find_template
def test_find_template():

    # Ensure that the function properly handles a NoneType input
    assert test_case_0() is None


# Generated at 2022-06-25 15:26:11.434561
# Unit test for function find_template
def test_find_template():
    var_0 = os.path.join('tests', 'files', 'fake-repo-pre')
    var_1 = os.path.join(var_0, '{{cookiecutter.repo_name}}')
    var_2 = find_template(var_0)
    assert var_1 == var_2

# Generated at 2022-06-25 15:26:16.818325
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-find-template') == 'tests/test-find-template/{{cookiecutter.project_slug}}'

if __name__ == "__main__":
    import sys
    import traceback

    try:
        test_find_template()
    except Exception:
        details = traceback.format_exc()
        print(test_find_template.__name__, ": ", details)
        sys.exit(1)
    else:
        print(test_find_template.__name__, ": ok")

# Generated at 2022-06-25 15:26:18.350696
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception:
        pass
    try:
        find_template()
    except Exception:
        pass

# Generated at 2022-06-25 15:26:21.324342
# Unit test for function find_template
def test_find_template():
    template_path = find_template('tests/fake-repo-tmpl')
    expected_path = os.path.normpath('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')
    try:
        assert template_path == expected_path
        print("Test 1 Pass")
    except:
        print("Test 1 Fail")

#test_find_template()
#test_case_0()

# Generated at 2022-06-25 15:26:26.804369
# Unit test for function find_template
def test_find_template():
    bool_0 = ''
    var_0 = find_template(bool_0)
    print(var_0)
    var_0 = find_template(bool_0)
    print(var_0)

# Main entry point for script
if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:27.476833
# Unit test for function find_template
def test_find_template():
    assert find_template() == 'value'


# End of file tests

# Generated at 2022-06-25 15:26:33.850197
# Unit test for function find_template
def test_find_template():
    # The function should raise an exception if a non template repo is used
    with pytest.raises(NonTemplatedInputDirException):
        find_template('tests/fake-repo-pre/')

    assert find_template('tests/fake-repo-pre/tests/fake-repo-pre/') == None

    # The function should not return 'None' if a template repo is used
    assert find_template('tests/fake-repo-pre/tests/fake-repo-render/') != None

    # TODO: Further testing for special cases

# Generated at 2022-06-25 15:26:45.938431
# Unit test for function find_template
def test_find_template():
    logging.debug("Testing find_template")
    assert find_template("/home/preston/git/cookiecutter-pypackage")=="/home/preston/git/cookiecutter-pypackage/{{cookiecutter.github_project_name}}"
    assert find_template("/home/preston/git/cookiecutter-django")=="/home/preston/git/cookiecutter-django/{{cookiecutter.repo_name}}"
    assert find_template("/home/preston/git/cookiecutter-pypackage")!="/home/preston/git/cookiecutter-pypackage/{{cookiecutter.repo_name}}"

# Generated at 2022-06-25 15:26:48.184561
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    assert var_0 == None

# Generated at 2022-06-25 15:26:49.990162
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        print ('Got expected exception:', e)
    else:
        raise Exception('Did not get expected exception')

# Generated at 2022-06-25 15:27:13.248402
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        return True
    else:
        return False

# Run the unit tests
test_find_template()

# Generated at 2022-06-25 15:27:18.546095
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass
    except Exception:
        logger.error('Unit test failed for %s', os.path.basename(__file__))
        raise

# Generated at 2022-06-25 15:27:22.488045
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        assert True == True
        print('Success: test_case_0')
    else:
        assert False == True
        print('Failure: test_case_0')

# program entry point
if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:27:24.477955
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        assert True



# Generated at 2022-06-25 15:27:30.095371
# Unit test for function find_template
def test_find_template():

    # Assign model_path to the path to the template
    model_path = os.path.dirname(
        os.path.dirname(
            os.path.realpath(__file__)
        )
    )
    # Pass through model_path and compare it to the location of the template.
    # This will return the same path.
    path_to_template = find_template(model_path)
    assert path_to_template == model_path

# Generated at 2022-06-25 15:27:34.423973
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    
    # Equality assertion  - This should always be true
    assert var_0 is not None
    
    # Type assertion - We expect a string
    assert type(var_0) == str
    

# Generated at 2022-06-25 15:27:40.342243
# Unit test for function find_template
def test_find_template():
    assert find_template('qtpy')
    assert find_template('assets')
    assert find_template('adres')
    assert find_template('templates')
    assert find_template('ladies')


# functest_find_template

# Generated at 2022-06-25 15:27:41.323480
# Unit test for function find_template
def test_find_template():
    assert find_template == "test"

# Generated at 2022-06-25 15:27:42.560244
# Unit test for function find_template
def test_find_template():
    assert True == True


# Program entry point

# Generated at 2022-06-25 15:27:45.538072
# Unit test for function find_template
def test_find_template():
    print('Testing find_template')
    new_list = [0, 1, 2, 4]
    list_temp = new_list
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 15:28:38.473810
# Unit test for function find_template
def test_find_template():
    import cookiecutter.utils
    import os
    import shutil
    import tempfile
    repo_dir = tempfile.mkdtemp()
    try:
        this_dir = os.path.dirname(os.path.abspath(__file__))
        cookiecutter.utils.copy(os.path.join(this_dir, 'fake-repo-tmpl'), repo_dir)
        proj_tmpl = find_template(repo_dir)
        assert proj_tmpl == os.path.join(repo_dir, 'fake-project-tmpl')
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-25 15:28:39.497994
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:28:42.987483
# Unit test for function find_template
def test_find_template():
    template_dir = find_template("./tests/input/othercase")
    assert template_dir == "./tests/input/othercase/my-course"

# Generated at 2022-06-25 15:28:48.808935
# Unit test for function find_template
def test_find_template():
    # Setup test
    repo_dir = os.path.join(
        'tests',
        'files',
        'test-find-template',
    )
    expected = os.path.join(
        'tests',
        'files',
        'test-find-template',
        '{{cookiecutter.project_name}}',
    )

    # Perform test
    result = find_template(repo_dir)

    # Verify results
    assert result == expected



# Generated at 2022-06-25 15:28:58.073706
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)
    assert os.path.abspath(find_template('/home/ctf/ctf/test_cases/test_0/cookiecutter-test-framework-test-0')).strip() == '/home/ctf/ctf/test_cases/test_0/cookiecutter-test-framework-test-0/{{cookiecutter.test_description_0}}'
    try:
        assert find_template('/home/ctf/ctf/test_cases/test_0/cookiecutter-test-framework-test-0') == '/home/ctf/ctf/test_cases/test_0/cookiecutter-test-framework-test-0/test_description_0'
    except NonTemplatedInputDirException as e:
        print(e.message)
    assert os

# Generated at 2022-06-25 15:28:59.056354
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:29:03.255710
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
        print("Test case 0 successful")
    except NonTemplatedInputDirException:
        print("Test case 0 failed: NonTemplatedInputDirException Exception not raised")
    except:
        print("Test case 0 failed: Exception raised")

a = test_find_template()
print(a)

# Generated at 2022-06-25 15:29:06.930600
# Unit test for function find_template
def test_find_template():
    assert True == True

# Generated at 2022-06-25 15:29:10.431912
# Unit test for function find_template
def test_find_template():
    import unittest
    class TestFindTemplate(unittest.TestCase):
        def test_find_template_0(self):
            bool_0 = None
            var_0 = find_template(bool_0)
    unittest.main()


# Generated at 2022-06-25 15:29:12.025729
# Unit test for function find_template
def test_find_template():
    assert find_template() == None


# Generated at 2022-06-25 15:30:45.963966
# Unit test for function find_template
def test_find_template():
    bool_1 = None
    try:
        find_template(bool_1)
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-25 15:30:48.296538
# Unit test for function find_template
def test_find_template():
    assert find_template("./tests/test-repo")
    assert not find_template("./tests/test-repo/")
    assert not find_template("./tests/test-repo/REAADME.md")

# Generated at 2022-06-25 15:30:51.847468
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print("Exception was thrown")


# Generated at 2022-06-25 15:31:01.998752
# Unit test for function find_template
def test_find_template():
    try:
        assert callable(find_template)
    except AssertionError as e:
        print(e, file=sys.stderr)
        sys.exit(1)

    try:
        assert isinstance(find_template('/'), basestring)
    except AssertionError as e:
        print(e, file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    import sys
    test_find_template()

# Generated at 2022-06-25 15:31:02.709664
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)



# Generated at 2022-06-25 15:31:03.696210
# Unit test for function find_template
def test_find_template():
    pass
    # TODO: construct object with mock



# Generated at 2022-06-25 15:31:06.130978
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException as e:
        logger.error('NonTemplatedInputDirException: %s', e)

# Generated at 2022-06-25 15:31:07.815827
# Unit test for function find_template
def test_find_template():
    assert find_template("test_dir") == "test_dir/test_template"

# Generated at 2022-06-25 15:31:08.688755
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)


# Generated at 2022-06-25 15:31:09.500846
# Unit test for function find_template
def test_find_template():
    with pytest.raises(Exception):
        test_case_0()