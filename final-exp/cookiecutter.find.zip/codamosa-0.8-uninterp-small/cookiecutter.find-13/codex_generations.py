

# Generated at 2022-06-25 15:22:09.302970
# Unit test for function find_template
def test_find_template():

    str_0 = '.kTR52U&eH/t'
    var_0 = find_template(str_0)
    assert var_0 == '.kTR52U&eH/t/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

    str_1 = ').K?+DWT/'
    var_1 = find_template(str_1)
    assert var_1 == ').K?+DWT/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

    str_2 = '%c*J1'
    var_2 = find_template(str_2)
    assert var_2 == '%c*J1/cookiecutter-pypackage/{{cookiecutter.project_slug}}'


# Generated at 2022-06-25 15:22:12.598427
# Unit test for function find_template
def test_find_template():
    log_level = logging.ERROR
    logging.basicConfig(format='%(levelname)s:%(message)s', level=log_level)
    test_case_0()


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:22:14.500766
# Unit test for function find_template
def test_find_template():
    assert callable(find_template), "Function does not exist"


# Python code to demonstrate naive method
# to compute factorial

# Generated at 2022-06-25 15:22:21.806553
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test template without any variables
    template_dir = os.path.join(utils.resource_path('tests/fake-repo-pre/'), 'fake-repo-pre')
    with utils.work_in(template_dir):
        try:
            find_template(template_dir)
            raise ValueError('Should have raised ValueError')
        except NonTemplatedInputDirException:
            pass

    # Test template with variables
    template_dir = os.path.join(utils.resource_path('tests/fake-repo-pre/'), 'fake-repo-pre-with-vars')

# Generated at 2022-06-25 15:22:25.596339
# Unit test for function find_template
def test_find_template():
    for x in range(10):
        test_case_0()

# Generated at 2022-06-25 15:22:30.750507
# Unit test for function find_template
def test_find_template():
    str_0 = '.kTR52U&eH/t'
    var_0 = find_template(str_0)
    assert var_0 == '.kTR52U&eH/t/cookiecutter-pypackage-kTR52U&eH'

# Generated at 2022-06-25 15:22:36.783580
# Unit test for function find_template
def test_find_template():
    str_0 = 'yBtNzYcOjb'
    var_0 = find_template(str_0)

    assert var_0 is None


# Generated at 2022-06-25 15:22:42.109676
# Unit test for function find_template
def test_find_template():
    input_arg = '<blank>'
    try:
        find_template(input_arg)
    except Exception as inst:
        # If exception is due to function argument being a string, re-raise
        # exception
        if isinstance(inst.args[0], basestring):
            raise
        # Else, treat it as an actual exception

# Generated at 2022-06-25 15:22:42.820062
# Unit test for function find_template
def test_find_template():
    assert find_template == test_case_0

# Generated at 2022-06-25 15:22:44.332967
# Unit test for function find_template
def test_find_template():
    str_0 = '/home/yourname/cookiecutters'
    var_0 = find_template(str_0)

# Generated at 2022-06-25 15:22:48.830783
# Unit test for function find_template
def test_find_template():
    set_1 = "test_dir"
    var_1 = find_template(set_1)
    assert var_1 == 2



# Generated at 2022-06-25 15:22:53.613851
# Unit test for function find_template
def test_find_template():
    path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
#    if find_template(path) == path:
#        print("The project template is " + path)
#    else:
#        print("failure error")

#if __name__ == '__main__':
#    test_find_template()

# Generated at 2022-06-25 15:23:01.452452
# Unit test for function find_template
def test_find_template():
    '''
    Test function find_template
    INPUT :
        cookiecutter_template[0] = None
    EXPECTED OUTPUT :
        cookiecutter_template[0] = NonTemplatedInputDirException
    '''
    print('Testing function find_template')
    cookiecutter_template = [None]

    try :
        cookiecutter_template[0] = find_template(cookiecutter_template[0])
    except NonTemplatedInputDirException:
        cookiecutter_template[0] = 'NonTemplatedInputDirException'

    print('cookiecutter_template[0] = ' + cookiecutter_template[0])
    assert cookiecutter_template[0] == 'NonTemplatedInputDirException'
    print('Finished testing find_template')

test_case_0()

# Generated at 2022-06-25 15:23:03.453030
# Unit test for function find_template
def test_find_template():
    set_0 = None
    var_0 = find_template(set_0)


# Generated at 2022-06-25 15:23:07.107270
# Unit test for function find_template
def test_find_template():
    assert find_template(
        "/home/user/cookiecutter/set_0/") == \
        "/home/user/cookiecutter/set_0/cookiecutter-set_0/"

# Generated at 2022-06-25 15:23:08.024396
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:23:09.438016
# Unit test for function find_template
def test_find_template():
    test_dir = 'tests/files/test-repo-tmpl'
    assert find_template(test_dir) == os.path.join(test_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:23:13.389911
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\\Users\\Abhishek\\PycharmProjects\\cookiecutter-test\\cookiecutter\\test1')

# Generated at 2022-06-25 15:23:18.630705
# Unit test for function find_template
def test_find_template():
    # Set up arguments for find_template
    set_1 = os.path.join('tests', 'files', 'input_repo_3')
    var_1 = find_template(set_1)
    assert os.path.join(set_1, '{{cookiecutter.project_slug}}') == var_1
# END find_template

# Generated at 2022-06-25 15:23:24.501639
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter

    set_0 = "https://github.com/pierre-rouanet/testrepo"

    repo_0 = cookiecutter(set_0)

    var_0 = find_template(repo_0)

    assert_equals(var_0, repo_0 + '/{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:23:27.303959
# Unit test for function find_template
def test_find_template():
    SET_0 = None
    VAR_0 = find_template(SET_0)

# Generated at 2022-06-25 15:23:28.615517
# Unit test for function find_template
def test_find_template():
    # TODO: Implement this unit test
    raise NotImplementedError

# Generated at 2022-06-25 15:23:29.551271
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:23:32.256351
# Unit test for function find_template
def test_find_template():
    import pytest
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        test_case_0()
    assert pytest_wrapped_e.type == SystemExit

# Generated at 2022-06-25 15:23:38.430402
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as err:
        print('Test case 0 failed: ' + str(err))


# Program entry point
if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:47.011680
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import temp_chdir

    # Setup
    os.makedirs("/tmp/repo")
    os.makedirs("/tmp/repo/cookiecutter-project")

    # Test chdir
    with temp_chdir("/tmp/repo", "cookiecutter-project"):
        project_template = find_template('/tmp/repo')
        assert os.path.join(os.getcwd(), 'cookiecutter-project') == project_template

    # Test no chdir
    project_template = find_template('/tmp/repo/cookiecutter-project')
    assert os.path.join(os.getcwd(), 'cookiecutter-project') == project_template


# Generated at 2022-06-25 15:23:50.991780
# Unit test for function find_template
def test_find_template():
    set_0 = 'cookiecutter-qgis-plugin'
    var_0 = find_template(set_0)
    assert var_0 == 'cookiecutter-qgis-plugin/{{cookiecutter.plugin_name}}', \
           "Unexpected value for find_template(\"cookiecutter-qgis-plugin\")"


# Generated at 2022-06-25 15:23:54.618042
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    try:
        set_0 = None
        test_case_0()
        assert 0, 'Expected to raise a NonTemplatedInputDirException.'
    except NonTemplatedInputDirException as e:
        pass


# Generated at 2022-06-25 15:24:00.739481
# Unit test for function find_template
def test_find_template():
    test_case_0()
    

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:08.621942
# Unit test for function find_template
def test_find_template():
    import mock
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            pass

        def test_0(self):
            with mock.patch('os.listdir') as mk:
                mk.return_value = [
                    b'cookiecutter-pypackage',
                    b'cookiecutter-pypackage.egg-info',
                    b'mkdir.py'
                ]

                self.assertEqual(
                    find_template('cookiecutter-pypackage/'),
                    b'cookiecutter-pypackage/cookiecutter-pypackage'
                )

    unittest.main()

# Generated at 2022-06-25 15:24:19.444525
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    from cookiecutter.generate import utils
    from cookiecutter import utils as cutils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    set_0 = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test_find_template_set_0')
    )
    var_0 = os.path.abspath(
        os.path.join(set_0, 'cookiecutter-pypackage')
    )
    var_1 = os.path.abspath(
        os.path.join(set_0, 'cookiecutter-pypackage', '{{cookiecutter.repo_name}}')
    )

# Generated at 2022-06-25 15:24:23.250154
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/env/lib/python2.7/site-packages/cookiecutter') == '/home/vagrant/env/lib/python2.7/site-packages/cookiecutter/cookiecutter'

# Generated at 2022-06-25 15:24:28.919480
# Unit test for function find_template
def test_find_template():
    # Setup (create sample set)
    repo_dir = "/home/staceyp/cookiecutter-pypackage/tests/test-repo/"
    # Exercise (run function)
    result = find_template(repo_dir)
    # Verify
    assert result == '/home/staceyp/cookiecutter-pypackage/tests/test-repo/cookiecutter-pypackage'


# Generated at 2022-06-25 15:24:37.772425
# Unit test for function find_template
def test_find_template():
    # <input directory> is None
    set_0 = None
    try:
        var_0 = find_template(set_0)
    except NonTemplatedInputDirException:
        var_0 = None
    assert var_0 == None

    # <input directory> doesn't have any content
    set_1 = os.path.abspath('test/test_dir/dir_no_content')
    try:
        var_1 = find_template(set_1)
    except NonTemplatedInputDirException:
        var_1 = None
    assert var_1 == None

    # <input directory> doesn't have a template
    set_2 = os.path.abspath('test/test_dir/dir_no_template')

# Generated at 2022-06-25 15:24:43.338338
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir/cookiecutter-{{repo_name}}'

# Generated at 2022-06-25 15:24:53.306623
# Unit test for function find_template
def test_find_template():

    # test for finding template in repo_dir
    repo_dir = os.getcwd()
    repo_dir_contents = os.listdir(repo_dir)

    pre_test_project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            pre_test_project_template = item
            break

    # test that you can find template in repo_dir
    if pre_test_project_template:
        pre_test_project_template = os.path.join(repo_dir, pre_test_project_template)

        assert find_template(repo_dir) == pre_test_project_template

    # test that find_template throws the correct error if template is not found

# Generated at 2022-06-25 15:25:00.987267
# Unit test for function find_template
def test_find_template():

    import os
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

    template_dir = os.path.join(repo_dir, 'project_dir')
    os.mkdir(template_dir)

    expected_dir = os.path.abspath(template_dir)
    assert find_template(repo_dir) == expected_dir

    shutil.rmtree(repo_dir)

# Generated at 2022-06-25 15:25:03.341764
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-dir/test-repo') == 'tests/test-dir/test-repo/{{cookiecutter.directory_name}}'

# Generated at 2022-06-25 15:25:14.294993
# Unit test for function find_template
def test_find_template():
    from cookiecutter import exceptions
    import os
    import shutil
    import tempfile
    repo_dir = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(repo_dir, 'test'))
        with open(os.path.join(repo_dir, 'test', 'cookiecutter.json'), 'w') as f:
            f.write('')
        with open(os.path.join(repo_dir, 'test', '{{cookiecutter.key}}.txt'), 'w') as f:
            f.write('')
        result = find_template(repo_dir)
        assert result == os.path.join(repo_dir, 'test')
    finally:
        shutil.rmtree(repo_dir)
    # Check

# Generated at 2022-06-25 15:25:24.311018
# Unit test for function find_template
def test_find_template():
    params = []
    param = None
    params.append(param)
    param = ""
    params.append(param)
    param = "TestPara"
    params.append(param)
    param = "/some/path/to/template"
    params.append(param)
    param = "//"
    params.append(param)
    for param in params:
        try:
            find_template(param)
        except:
            pass

# Generated at 2022-06-25 15:25:30.390631
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir / cookiecutter {{ cookiecutter }}'

test_find_template()
test_case_0()

# Generated at 2022-06-25 15:25:33.704621
# Unit test for function find_template
def test_find_template():
    import os
    from tempfile import mkdtemp
    from cookiecutter import find

    project_dir = os.path.dirname(os.path.realpath(__file__))

    d = mkdtemp()
    find.find_template(d)

# Generated at 2022-06-25 15:25:42.191656
# Unit test for function find_template
def test_find_template():
    def test_case_0():
        set_0 = None
        var_0 = find_template(set_0)
        assert var_0 == '{{cookiecutter.project_name}}'

    def test_case_1():
        set_0 = "{{cookiecutter.project_name}}"
        var_0 = find_template(set_0)
        assert var_0 == '{{cookiecutter.project_name}}'

    def test_case_2():
        set_0 = "/Users/audreyr/cookiecutters/cookiecutter-pypackage"
        var_0 = find_template(set_0)
        assert var_0 == "{{cookiecutter.project_name}}"


# Generated at 2022-06-25 15:25:45.722329
# Unit test for function find_template
def test_find_template():
    test_cases = [test_case_0()]
    for num, test in enumerate(test_cases):
        try:
            assert test == test_cases[num]
        except AssertionError as e:
            print(test_case_0())
            raise e

# Generated at 2022-06-25 15:25:48.796952
# Unit test for function find_template
def test_find_template():
    test_case_0()


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:25:54.086861
# Unit test for function find_template
def test_find_template():
    import nose

    args = ['/home/rajat/cookicutter-demo']
    nose.tools.assert_raises(NonTemplatedInputDirException, find_template, *args)

    args = ['/home/rajat/cookiecutter-demo']
    nose.tools.assert_equal(find_template(*args),
                            '/home/rajat/cookiecutter-demo/{{ cookiecutter.repo_name }}')

# Generated at 2022-06-25 15:25:58.337384
# Unit test for function find_template
def test_find_template():
    # No exception thrown
    test_case_0()
    # NonTemplatedInputDirException thrown
    #assertRaises(find_template(None))

# Generated at 2022-06-25 15:26:00.367831
# Unit test for function find_template
def test_find_template():
    # Unit testing the test
    if test_case_0() == False:
        return False
    else:
        return True

# Generated at 2022-06-25 15:26:09.111139
# Unit test for function find_template
def test_find_template():

    # Try path to sample-cookiecutter-repo
    assert find_template('sample-cookiecutter-repo') == \
        'sample-cookiecutter-repo/{{cookiecutter.project_name}}'

    # Try path to sample-py-cookiecutter-repo
    assert find_template('sample-py-cookiecutter-repo') == \
        'sample-py-cookiecutter-repo/{{cookiecutter.repo_name}}'

    try:
        # Try empty path
        find_template('')
    except NonTemplatedInputDirException as e:
        # Should raise NonTemplatedInputDirException
        assert e

# Generated at 2022-06-25 15:26:17.354102
# Unit test for function find_template
def test_find_template():
    import inspect
    import sys
    #import os
    #import codecs
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)

    #from cookiecutter import hook
    #from cookiecutter.prompt import read_user_variable
    #from cookiecutter import exceptions
    #from cookiecutter.environment import StrictUndefined

    import pytest

    @pytest.mark.parametrize("data_name, expected", [
        pytest.param("set_0", None, id="basic"),
    ])
    def test_data(data_name, expected):
        if '\\\\' in sys.platform:
            py

# Generated at 2022-06-25 15:26:23.885134
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/cookiecutter/cookiecutter'
    var_0 = find_template(repo_dir)
    if var_0 == None:
        raise AssertionError("Variable should be set.")

# Generated at 2022-06-25 15:26:25.364423
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:26:27.215547
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:33.600636
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath("repo-template")
    project_template = find_template(repo_dir)
    assert project_template == 'repo-template/{{cookiecutter.repo_name}}'

    repo_dir = os.path.abspath("repo-template-with-quotes")
    project_template = find_template(repo_dir)
    assert project_template == 'repo-template-with-quotes/{{ "{{cookiecutter.repo_name}}" }}'

# Generated at 2022-06-25 15:26:38.913140
# Unit test for function find_template
def test_find_template():
    template = find_template("/home/preeti/PycharmProjects/cookiecutter/tests")
    assert template == "/home/preeti/PycharmProjects/cookiecutter/tests/fake-repo-tmpl"

# Generated at 2022-06-25 15:26:45.971352
# Unit test for function find_template
def test_find_template():
    repo_dir=r'C:\Users\User\Desktop\HCTK\cookiecutter-pypackage-minimal\cookiecutter-pypackage-minimal'
    var_0 = find_template(repo_dir)
    var_0 = find_template(repo_dir)
    assert var_0 == r'C:\Users\User\Desktop\HCTK\cookiecutter-pypackage-minimal\cookiecutter-pypackage-minimal\{{cookiecutter.repo_name}}'



# Generated at 2022-06-25 15:26:49.731739
# Unit test for function find_template
def test_find_template():
    test_set = ['test1', 'test2', 'test3']
    for item in test_set:
        try:
            find_template(item)
            raise RuntimeError("No Exception Raised")
        except:
            pass
	
if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:52.458896
# Unit test for function find_template
def test_find_template():
    # Check for no template
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:27:00.264007
# Unit test for function find_template
def test_find_template():
    from os import path
    from tempfile import mkdtemp
    from shutil import rmtree

    tmpdir = mkdtemp()
    try:
        project_template = path.join(tmpdir, '{{cookiecutter.repo_name}}')
        os.mkdir(project_template)
        find_template(tmpdir)
    finally:
        rmtree(tmpdir)



# Generated at 2022-06-25 15:27:01.156449
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:27:12.888346
# Unit test for function find_template
def test_find_template():
    import sys
    from os.path import abspath, join, dirname

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    sys.path.append(abspath(join(dirname(__file__), '..')))
    addr = 'tests\\test-find-template'

    with patch('os.listdir') as mock_listdir:
        mock_listdir.return_value = [
            '.git',
            'cookiecutter.json',
            'Dockerfile',
            'cookiecutter-{{cookiecutter.repo_name}}',
            'cookiecutter-{{cookiecutter.repo_name_1}}',
            'requirements.txt'
        ]

        ret = find_template(addr)

# Generated at 2022-06-25 15:27:17.817108
# Unit test for function find_template
def test_find_template():
    # Test set 0
    try:
        test_case_0()
        assert False
    except Exception:
        assert True


# Test the file
if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:27:20.868941
# Unit test for function find_template
def test_find_template():
    set_0 = 'folder_of_newly_cloned_repo'
    var_0 = find_template(set_0)
    assert var_0 == 'relative_path_to_project_template'


# Generated at 2022-06-25 15:27:29.724240
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.getcwd(), 'repo_with_template')
    project_template = find_template(repo_dir)
    project_template_path = 'repo_with_template/repo_with_template{{cookiecutter.flag}}'

    assert project_template == project_template_path

    repo_dir_missing_template = os.path.join(os.getcwd(), 'repo_with_no_template')

    try:
        project_template = find_template(repo_dir_missing_template)
    except NonTemplatedInputDirException as exception:
        project_template = None

    assert project_template == None

# Generated at 2022-06-25 15:27:33.445585
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_find_template()

# Generated at 2022-06-25 15:27:39.792240
# Unit test for function find_template
def test_find_template():
    set_0 = 'test'
    var_0 = find_template(set_0)
    assert var_0 is None


test_case_0()
test_find_template()

# Generated at 2022-06-25 15:27:40.652400
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:27:45.309561
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-pypackage')
    assert find_template('')
    assert find_template('cookiecutter-pypackage/')
    assert find_template('cookiecutter-pypackage/cookiecutter.json')
    assert find_template('cookiecutter-pypackage/{{cookiecutter.project_name}}')

# Generated at 2022-06-25 15:27:49.805174
# Unit test for function find_template
def test_find_template():
    # Check if unit test is setup or not.
    # Expecting NonTemplatedInputDirException
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        assert True


# Expected = 'templates/project_name'
# Actual = find_template('templates/project_name')
# assert Expected == Actual

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:27:55.391361
# Unit test for function find_template
def test_find_template():
    import pytest

    # Number of arguments: 1
    # Argument 0: Repo directory
    repo_dir_0 = 'http://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-25 15:28:24.768974
# Unit test for function find_template
def test_find_template():
    # check that an exception is raised if repo_dir is not a string
    try:
        var_0 = find_template(None)
    except TypeError as raised_exc:
        assert 'repo_dir must be a string' in str(raised_exc)

    # check that an exception is raised if repo_dir is not a valid directory
    try:
        var_1 = find_template('a')
    except ValueError as raised_exc:
        assert 'repo_dir: a is not a valid directory' in str(raised_exc)

    # check that an exception is raised if repo_dir is an empty directory

# Generated at 2022-06-25 15:28:29.502102
# Unit test for function find_template
def test_find_template():
    import unittest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    class MyTest(unittest.TestCase):
        def test_find_template(self):
            set_0 = None
            self.assertRaises(NonTemplatedInputDirException, find_template, set_0)

    unittest.main()


# Generated at 2022-06-25 15:28:35.963976
# Unit test for function find_template
def test_find_template():
    set_0 = '/Users/aalarcn/Desktop/cookiecutter/py_cookiecutter/tests/set_0'
    var_0 = find_template(set_0)
    assert var_0 == '/Users/aalarcn/Desktop/cookiecutter/py_cookiecutter/tests/set_0/{{cookiecutter.project_slug}}'


# Generated at 2022-06-25 15:28:41.665939
# Unit test for function find_template
def test_find_template():
    set_0 = None
    var_0 = find_template(set_0)

    try:
        assert var_0 == None
    except AssertionError as e:
        raise(e)
    
    set_1 = 'test/test_input_dir'
    var_1 = find_template(set_1)

    try:
        assert var_1 == 'test/test_input_dir/cookiecutter-pypackage'
    except AssertionError as e:
        raise(e)


# Generated at 2022-06-25 15:28:44.810788
# Unit test for function find_template
def test_find_template():
    try:
        find_template(repo_dir="None")
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

# Generated at 2022-06-25 15:28:54.850770
# Unit test for function find_template
def test_find_template():
    # Test when input directory is not a string.
    # If the input directory is not a string, a TypeError will be thrown.
    try:
        find_template(123)
    except TypeError:
        pass
    else:
        raise AssertionError

    # Test when input directory does not exists.
    # If the input directory does not exist, a OSError will be thrown.
    try:
        find_template('not_a_valid_directory')
    except OSError:
        pass
    else:
        raise AssertionError

    # Test when there isn't any directory in the input directory.
    try:
        find_template('tests/fixtures/empty_directory')
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError

    # Test when there are

# Generated at 2022-06-25 15:29:05.134424
# Unit test for function find_template
def test_find_template():
    # run test_case_0
    set_0 = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-cookiecutters',
                         'empty-repo')
    var_0 = find_template(set_0)

# Generated at 2022-06-25 15:29:16.271507
# Unit test for function find_template
def test_find_template():
    repo_dir = None
    set_0 = None
    var_0 = 'cookiecutter'
    expected_0 = None
    var_1 = ['cookiecutter']
    var_2 = None
    var_3 = None
    var_4 = None
    expected_4 = None
    var_5 = None
    var_6 = ['cookiecutter']
    expected_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    expected_12 = None
    var_13 = None
    var_14 = None
    var_15 = ['cookiecutter']
    var_16 = None
    var_17 = None
    var_18 = None
    expected_18 = None
   

# Generated at 2022-06-25 15:29:18.728631
# Unit test for function find_template
def test_find_template():

    # Test case 0
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()
    
    
    
    

# Generated at 2022-06-25 15:29:22.069436
# Unit test for function find_template
def test_find_template():
    logging.basicConfig(level=logging.DEBUG)
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 15:30:15.108645
# Unit test for function find_template
def test_find_template():
    test_repo_dir = "/home/ubuntu/cookiecutter-pypackage/{{cookiecutter.project_name}}"
    test_project_template = "cookiecutter-pypackage"

    # Verify that the test repository exists
    assert os.path.exists(test_repo_dir)

    # Verify that the test repository is a directory
    assert os.path.isdir(test_repo_dir)

    # Call find_template with the test repository
    actual_project_template = find_template(test_repo_dir)

    # Verify that the actual project template is the same as the expected value
    assert actual_project_template == test_project_template

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_case_0()

# Generated at 2022-06-25 15:30:17.620633
# Unit test for function find_template
def test_find_template():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 15:30:18.519443
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:30:20.102400
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:30:24.312955
# Unit test for function find_template
def test_find_template():
    set_0 = None
    with pytest.raises(NonTemplatedInputDirException) as execinfo:
        var_0 = find_template(set_0)



# Generated at 2022-06-25 15:30:26.879348
# Unit test for function find_template
def test_find_template():
    repo_dir = 'repo_dir'
    assert find_template(repo_dir) == os.path.join('repo_dir', 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:30:35.297716
# Unit test for function find_template
def test_find_template():
    import os
    try:
        os.makedirs('tests/temp/cookiecutter-pypackage')
        os.makedirs('tests/temp/cookiecutter-pypackage/{{cookiecutter.repo_name}}')
        open('tests/temp/cookiecutter-pypackage/README.md', 'w').close()
        open('tests/temp/cookiecutter-pypackage/{{cookiecutter.repo_name}}', 'w').close()
        assert find_template('tests/temp/cookiecutter-pypackage') == 'tests/temp/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    finally:
        os.remove('tests/temp/cookiecutter-pypackage/README.md')
        os.remove

# Generated at 2022-06-25 15:30:39.060641
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:30:44.561321
# Unit test for function find_template
def test_find_template():
    test_cases = [
        {
            "input": test_case_0,
            "output": None
        }
    ]

# Generated at 2022-06-25 15:30:45.440830
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None