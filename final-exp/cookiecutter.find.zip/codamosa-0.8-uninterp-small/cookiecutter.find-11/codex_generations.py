

# Generated at 2022-06-25 15:22:02.443363
# Unit test for function find_template
def test_find_template():
    repo_dir = ''
    project_template = find_template(repo_dir)
    assert project_template is None

# Generated at 2022-06-25 15:22:11.949808
# Unit test for function find_template

# Generated at 2022-06-25 15:22:15.278470
# Unit test for function find_template
def test_find_template():
    var_0 = "\n    Exception for unknown repo types.\n\n    Raised if a repo's type cannot be determined.\n    "
    # Call function and test return values and exceptions raised.
    var_1 = find_template(var_0)
    assert var_1 is None

# Generated at 2022-06-25 15:22:18.521083
# Unit test for function find_template
def test_find_template():
    str_0 = "\n    Exception for unknown repo types.\n\n    Raised if a repo's type cannot be determined.\n    "
    var_0 = find_template(str_0)
    # assert var_0 == var_0

# Test case for function find_template

# Generated at 2022-06-25 15:22:22.946664
# Unit test for function find_template
def test_find_template():
    str_0 = "from cookiecutter.exceptions import NonTemplatedInputDirException"
    var_0 = find_template(str_0)


# Generated at 2022-06-25 15:22:35.610387
# Unit test for function find_template
def test_find_template():
    str_0 = "\n    Exception for unknown repo types.\n\n    Raised if a repo's type cannot be determined.\n    "
    var_0 = find_template(str_0)
    assert(var_0 == None)

    str_1 = "\n    NonTemplatedInputDirException\n\n    Raised when a project template directory is not found\n    in the input directory.\n    "
    with raises(NonTemplatedInputDirException):
        var_0 = find_template(str_1)
        assert (var_0 == None)

    str_2 = "\n    NonTemplatedInputDirException\n\n    Raised when a project template directory is not found\n    in the input directory.\n    "
    var_1 = find_template(str_2)

# Generated at 2022-06-25 15:22:37.758865
# Unit test for function find_template
def test_find_template():
    print("Start test")
    test_case_0()
    print("End test")

test_find_template()

# Generated at 2022-06-25 15:22:45.665827
# Unit test for function find_template

# Generated at 2022-06-25 15:22:46.880571
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:51.166718
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as ex:
        var_0 = None
        logger.info("Unhandled exception in test 'test_find_template' raised:\n{}".format(ex))



# Generated at 2022-06-25 15:22:56.385090
# Unit test for function find_template
def test_find_template():
    # Set up test
    repo_dir = './tests/test-find-template'
    result = find_template(repo_dir)

    # Check if test passed
    assert result == repo_dir + '/cookiecutter-find-template'
    return True


# Generated at 2022-06-25 15:23:03.071090
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template(var_0) == 'output_project/'
    except NameError:
        assert find_template() == 'output_project/'

test_find_template()

# Generated at 2022-06-25 15:23:06.478976
# Unit test for function find_template
def test_find_template():
    dir_0 = 'test/files/fake-repo-tmpl'
    var_0 = find_template(dir_0)
    
    assert var_0 == 'test/files/fake-repo-tmpl/fake-project'

# Generated at 2022-06-25 15:23:08.198724
# Unit test for function find_template
def test_find_template():
    template_dir = 'tests/fake-repo-tmpl'
    project_template = find_template(template_dir)
    assert project_template == 'tests/fake-repo-tmpl/{{cookiecutter.project_name}}'


# Generated at 2022-06-25 15:23:10.712951
# Unit test for function find_template
def test_find_template():
    var_0 = None
    var_0 = find_template()
    print("test_find_template done")


# Generated at 2022-06-25 15:23:14.792202
# Unit test for function find_template
def test_find_template():
    var_0 = None
    var_0 = find_template(var_0)


# Generated at 2022-06-25 15:23:16.053735
# Unit test for function find_template
def test_find_template():
    var_1 = None


# Generated at 2022-06-25 15:23:17.328844
# Unit test for function find_template
def test_find_template():
    assert os.path.isdir(find_template('.')) == True


# Generated at 2022-06-25 15:23:28.437580
# Unit test for function find_template
def test_find_template():
    source = 'test/test-cookiecutter'
    logger.debug('Searching %s for the project template.', source)

    repo_dir_contents = os.listdir(source)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(source, project_template)
        logger.info('The project template appears to be %s', project_template)
    else:
        raise NonTemplatedInputDirException


if __name__ == '__main__':
    test_find_template()
    # test_case_0()

# Generated at 2022-06-25 15:23:33.286315
# Unit test for function find_template
def test_find_template():
    # Check whithout assert
    try:
        if find_template(os.path.join(os.path.dirname(__file__), '..', 'tests')) is not None:
            print("Test PASSED")
    except Exception:
        print("Test FAILED")

# Execute only if called directly
if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:39.018587
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir='/opt/openstack-neat/openstack/neat/tests/test_project/repo') == '/opt/openstack-neat/openstack/neat/tests/test_project/repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:23:40.175525
# Unit test for function find_template
def test_find_template():
    assert os.path.isdir(find_template('../../'))


# Generated at 2022-06-25 15:23:42.808905
# Unit test for function find_template
def test_find_template():
    var_0 = find_template('repo_dir')
    assert var_0 == 'project_template'
    assert var_0 != 'project_template'
 

# Generated at 2022-06-25 15:23:44.944699
# Unit test for function find_template

# Generated at 2022-06-25 15:23:47.030957
# Unit test for function find_template
def test_find_template():
    assert find_template(os.chdir('/home/cs17d07/PycharmProjects/cookiecutter')) == os.chdir('/home/cs17d07/PycharmProjects/cookiecutter')

# Generated at 2022-06-25 15:23:48.314002
# Unit test for function find_template
def test_find_template():
    assert true, "this is a test to make pytest test"

# Generated at 2022-06-25 15:23:56.016104
# Unit test for function find_template
def test_find_template():
    test_cases = (
        {'repo_dir': '/Users/taylor/src/cookiecutter/tests/fake-repo-tmpl',
         'project_template': os.path.join(
             '/Users/taylor/src/cookiecutter/tests/fake-repo-tmpl',
             'fake-project-{{cookiecutter.repo_name}}'
         )},
    )

    for test_case in test_cases:
        assert find_template(
            test_case['repo_dir']
        ) == test_case['project_template']

# Generated at 2022-06-25 15:23:57.136471
# Unit test for function find_template
def test_find_template():
    assert_equal(find_template, var_0)


# Generated at 2022-06-25 15:23:59.434640
# Unit test for function find_template
def test_find_template():
    assert find_template() == None

if __name__ == '__main__':
    test_case_0()
    test_find_template()
    print('All tests passed!')

# Generated at 2022-06-25 15:24:08.362239
# Unit test for function find_template
def test_find_template():

    # Setup
    repo_dir = "tests/fixtures/fake-repo-pre/"
    # Exercise
    var_0 = find_template(repo_dir)
    var_1 = find_template(repo_dir)
    var_2 = find_template(repo_dir)

    # Verify
    assert(var_0 == 'tests/fixtures/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert(var_1 == 'tests/fixtures/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert(var_2 == 'tests/fixtures/fake-repo-pre/{{cookiecutter.repo_name}}')


# Generated at 2022-06-25 15:24:17.282566
# Unit test for function find_template
def test_find_template():
    # Test template search in fixture.
    test_input_dir = os.path.join(
        os.path.dirname(__file__), 'input', 'test-template'
    )
    template = find_template(test_input_dir)
    assert os.path.basename(template) == '{{cookiecutter.repo_name}}'

    # Test exception raise in case of invalid template.
    assert test_case_0() == NonTemplatedInputDirException

# Generated at 2022-06-25 15:24:21.545364
# Unit test for function find_template
def test_find_template():
    template_path = find_template("/home/bob/project_cookiecutter")
    assert template_path == '/home/bob/project_cookiecutter/{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:24:24.956936
# Unit test for function find_template
def test_find_template():
    dict_0 = "/home/dev/source/cookiecutter"
    var_0 = find_template(dict_0)
    assert var_0 == "/home/dev/source/cookiecutter/{{cookiecutter.repo_name}}"

# Generated at 2022-06-25 15:24:25.960665
# Unit test for function find_template
def test_find_template():
    assert find_template(None)

# Generated at 2022-06-25 15:24:27.381700
# Unit test for function find_template
def test_find_template():
    assert find_template() == '__main__'


# Generated at 2022-06-25 15:24:28.646945
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fixtures/fake-repo-pre') is None

# Generated at 2022-06-25 15:24:32.676072
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/Excalibur/Desktop/job/cookiecutter/tests/fixtures/fake-repo-tmpl/') == '/Users/Excalibur/Desktop/job/cookiecutter/tests/fixtures/fake-repo-tmpl/features/'


# Generated at 2022-06-25 15:24:35.886102
# Unit test for function find_template
def test_find_template():
    template_dir = '/Users/minrk/.cookiecutters/foobar'
    returned_dir = find_template(template_dir)
    assert returned_dir == '/Users/minrk/.cookiecutters/foobar/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:24:42.756336
# Unit test for function find_template
def test_find_template():
    assert find_template("C:\\fakepath\\textfile.txt") == "C:\\fakepath\\textfile.txt"
    assert find_template("C:\\fakepath\\textfile.txt") == "C:\\fakepath\\textfile.txt"
    assert find_template("C:\\fakepath\\textfile.txt") == "C:\\fakepath\\textfile.txt"
    assert find_template("C:\\fakepath\\textfile.txt") == "C:\\fakepath\\textfile.txt"
    assert find_template("C:\\fakepath\\textfile.txt") == "C:\\fakepath\\textfile.txt"
    dict_0 = None
    assert find_template(dict_0) == dict_0

# Generated at 2022-06-25 15:24:44.305206
# Unit test for function find_template
def test_find_template():
    assert find_template(dict_0) == None


# Generated at 2022-06-25 15:24:49.752672
# Unit test for function find_template
def test_find_template():
    dict_0 = None
    var_0 = find_template(dict_0)
    assert var_0 == "Cookiecutter-PEP8", "Failure: Expected 'Cookiecutter-PEP8' but got '%s'" % var_0

# Main program

# Generated at 2022-06-25 15:24:52.275862
# Unit test for function find_template
def test_find_template():
    dict_0 = 'tests/mytestdir'
    var_0 = find_template(dict_0)

    assert(var_0 == 'tests/mytestdir/{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:24:59.110331
# Unit test for function find_template
def test_find_template():
    dict = "C:\\Users\\Sushmitha\\MyProjectDir\\cookiecutter-project-template\\Cookiecutter-project-template"
    assert  'C:\\Users\\Sushmitha\\MyProjectDir\\cookiecutter-project-template\\Cookiecutter-project-template\\Cookiecutter-project-template' == find_template(dict)


# Generated at 2022-06-25 15:25:01.278001
# Unit test for function find_template
def test_find_template():
    my_dict = None
    assert (find_template(my_dict) == None), "wrong"

# Generated at 2022-06-25 15:25:02.199239
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == 0



# Generated at 2022-06-25 15:25:05.519951
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        # expected exception
        pass

    try:
        test_case_0()
    except Exception as e:
        # unexpected exception
        assert False, "Something went wrong with find_template: %s" % e

# Generated at 2022-06-25 15:25:17.297456
# Unit test for function find_template
def test_find_template():
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None, "Failed on input: ''"
    assert find_template("") == None

# Generated at 2022-06-25 15:25:18.928675
# Unit test for function find_template
def test_find_template():
    assert find_template() == '{{cookiecutter.project_directory}}'


# Generated at 2022-06-25 15:25:20.195160
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Master test for function find_template

# Generated at 2022-06-25 15:25:22.371453
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        print("Error: test_case_0")

# Run unit tests
test_find_template()

# Generated at 2022-06-25 15:25:30.527587
# Unit test for function find_template
def test_find_template():
    param_0 = '/'
    try:
        find_template(param_0)
    except NonTemplatedInputDirException:
        return True
    else:
        return False


# Generated at 2022-06-25 15:25:32.475196
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:25:33.705625
# Unit test for function find_template
def test_find_template():
    assert find_template("abc") == None


# Generated at 2022-06-25 15:25:42.190608
# Unit test for function find_template
def test_find_template():
    dict_0 = None
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_8 = dict_7
    dict_9 = dict_8
    dict_10 = dict_9
    dict_11 = dict_10
    dict_12 = dict_11
    dict_13 = dict_12
    dict_14 = dict_13
    dict_15 = dict_14
    dict_16 = dict_15
    dict_17 = dict_16
    dict_18 = dict_17
    dict_19 = dict_18
    dict_20 = dict_19
    dict_21 = dict_20
    dict_

# Generated at 2022-06-25 15:25:49.548488
# Unit test for function find_template
def test_find_template():
    *_, module, _ = find_template.__module__.split('.')
    module = str(module)

    # Test 1: ValueError for None
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass  # Expected.
    except Exception as e:
        raise AssertionError(
            'Unexpected exception raised. {}'.format(e)
        ) from e
    else:
        raise AssertionError('Test 1 failed.')

    # Test 2: ValueError for non-existent directory
    try:
        find_template('not_a_directory')
    except NonTemplatedInputDirException:
        pass  # Expected.

# Generated at 2022-06-25 15:25:51.119099
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-25 15:25:54.397004
# Unit test for function find_template
def test_find_template():
    print("Test 1 of 2, Simple case:")
    # Test 1 of 2, Simple case:
    assert test_case_0() == None
    print("Test 2 of 2, Simple case:")
    # Test 2 of 2, Simple case:
    assert test_case_0() == None


# Generated at 2022-06-25 15:25:58.124377
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == 'cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:26:00.091476
# Unit test for function find_template
def test_find_template():
    dict_0 = "C:\\Users\\m\\Desktop\\cookiecutter-django-crud\\{{cookiecutter.project_slug}}"   # Security check.
    var_0 = find_template(dict_0)
    assert var_0 == dict_0

# Generated at 2022-06-25 15:26:00.669857
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-25 15:26:16.224925
# Unit test for function find_template
def test_find_template():

    class MockLogger(object):
        def debug(self, msg):
            pass

    logger = MockLogger()

    class MockListDir(object):
        def __init__(self, data):
            self.data = data
        def __call__(self, path):
            return self.data

    class MockPathJoin(object):
        def __init__(self, data):
            self.data = data
        def __call__(self, *args):
            return self.data

    from cookiecutter.exceptions import NonTemplatedInputDirException

    # raise exception when template not found
    list_dir = MockListDir(['item1', 'item2'])
    os.listdir = list_dir

    path_join = MockPathJoin(None)
    os.path.join = path_join


# Generated at 2022-06-25 15:26:18.030769
# Unit test for function find_template
def test_find_template():
    assert('0' == find_template('0'))


# Generated at 2022-06-25 15:26:19.599951
# Unit test for function find_template
def test_find_template():
    dict_0 = None
    assert find_template(dict_0) == NonTemplatedInputDirException

# Generated at 2022-06-25 15:26:24.660448
# Unit test for function find_template
def test_find_template():
    dict_1 = 'D:\Cookiecutter\Cookiecutter-pylibrary\tests\test-repo-pre'
    var_1 = find_template(dict_1)
    assert var_1 == 'D:\\Cookiecutter\\Cookiecutter-pylibrary\\tests\\test-repo-pre\\{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:26:25.682781
# Unit test for function find_template
def test_find_template():
    dict_0 = None
    var_0 = find_template(dict_0)
    assert isinstance(var_0, str)
# Unit test 2 for function find_template

# Generated at 2022-06-25 15:26:30.849380
# Unit test for function find_template
def test_find_template():
    assert find_template("Test case 0") == NonTemplatedInputDirException
    assert find_template("Test case 1") == NonTemplatedInputDirException
    assert find_template("Test case 2") == NonTemplatedInputDirException
    assert find_template("Test case 3") == NonTemplatedInputDirException
    assert find_template("Test case 4") == NonTemplatedInputDirException


# Generated at 2022-06-25 15:26:31.997991
# Unit test for function find_template
def test_find_template():
    assert find_template(dict_0) == NonTemplatedInputDirException

test_find_template()

# Generated at 2022-06-25 15:26:39.223714
# Unit test for function find_template
def test_find_template():
    try:
        assert func_ret_val_0 == var_0
    except AssertionError as e:
        raise(e)

    try:
        assert func_ret_val_1 == var_1
    except AssertionError as e:
        raise(e)

    try:
        assert func_ret_val_2 == var_2
    except AssertionError as e:
        raise(e)

test_case_0()

# Generated at 2022-06-25 15:26:46.143943
# Unit test for function find_template
def test_find_template():

    # Setup
    repo_dir = 'C:\\Users\\cjros\\PynamoDB\\cookiecutter-pynamodb'
    # Exercise
    project_template = find_template(repo_dir)
    # Verify
    assert project_template == 'C:\\Users\\cjros\\PynamoDB\\cookiecutter-pynamodb\\{cookiecutter.repo_name}'

    # Cleanup - none necessary
    # The only way this test could fail is if the directory structure is changed
    # and the above line is updated.

# Generated at 2022-06-25 15:26:49.161862
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template({})
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('Expected NonTemplatedInputDirException')

# Test the test case

# Generated at 2022-06-25 15:27:03.199966
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)


# Generated at 2022-06-25 15:27:09.757430
# Unit test for function find_template
def test_find_template():
    dict_0 = 'repo_dir'
    var_1 = None
    var_0 = find_template(dict_0)
    if var_0 != var_1:
        raise Exception(
            "Return value is not what we expected.\n\nExpected:\n{0}\n\nGot:\n{1}\n".format(
                var_1, var_0
            )
        )


if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:27:17.483102
# Unit test for function find_template
def test_find_template():
    import sys
    import traceback
    import io

    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    try:
        test_case_0()
    except:
        stack_trace = traceback.format_exc()
        print(stack_trace)
        assert(False)
    sys.stdout = sys.__stdout__
    print('test_find_template passed')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:27:20.584123
# Unit test for function find_template
def test_find_template():
    path_0 = "tests/fixtures/non-templated-repo"
    path_0 = None
    # Call the tested function
    var_0 = find_template(path_0)
    var_0 = None

# mock functions

# Generated at 2022-06-25 15:27:24.105942
# Unit test for function find_template
def test_find_template():
    dict_0 = "cookiecutter.json"
    var_0 = find_template(dict_0)
    assert var_0 == "cookiecutter.json"
    assert var_0 is not None


# Generated at 2022-06-25 15:27:28.069321
# Unit test for function find_template
def test_find_template():
    dirs = ['tests/fixtures/empty', 'tests/fixtures/test-template']
    assert (
        find_template(dirs[0]) ==
        find_template(dirs[1])
    )



# Generated at 2022-06-25 15:27:31.470464
# Unit test for function find_template
def test_find_template():

    # Set the variable "repo_dir" to an appropriate value
    repo_dir = ''
    # Invoke the function with arguments repo_dir
    assertRaises(Exception, find_template(repo_dir))

# Generated at 2022-06-25 15:27:32.890113
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'project_template'

# Generated at 2022-06-25 15:27:37.380044
# Unit test for function find_template
def test_find_template():
    # Test for instance where a file does not exist
    try:
        find_template("")
    except:
        pass
        #assert False
    finally:
        pass
    # Test for instance where a file does exist
    try:
        find_template("../tests/test-repo-pre/")
    except:
        #assert False
        pass
    finally:
        pass



# Generated at 2022-06-25 15:27:40.113477
# Unit test for function find_template
def test_find_template():
    test_case_0()
    try:
        assert find_template("./tests") == "./tests/cookiecutter-pypackage-2016.06.01"
    except:
        assert find_template("./tests") == "./tests/cookiecutter-pypackage"


# Generated at 2022-06-25 15:28:14.293697
# Unit test for function find_template
def test_find_template():
    dict = {"cookiecutter-pypackage": [], "hooks": [], "tests": [], "tox.ini": [], ".coveragerc": [], "tests/": [], ".git/": [], ".gitignore": [], ".cookiecutterrc": []}
    var = find_template(dict)

    if(var == ".cookiecutterrc"):
        print("pass")
    else:
        print("fail")


# Generated at 2022-06-25 15:28:16.805698
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None


# Generated at 2022-06-25 15:28:17.949536
# Unit test for function find_template
def test_find_template():
    raise NotImplementedError



# Generated at 2022-06-25 15:28:21.218062
# Unit test for function find_template
def test_find_template():
    assert find_template('/fake/path/to/newly/cloned/repo') == \
        'fake/path/to/newly/cloned/repo/cookiecutter{{cookiecutter.repo}}'

# Generated at 2022-06-25 15:28:22.068769
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:28:25.038419
# Unit test for function find_template
def test_find_template():

    test_case_0()

# run test and print to log
test_find_template()
print('test_find_template() completed')

# Generated at 2022-06-25 15:28:33.872645
# Unit test for function find_template
def test_find_template():

    # Figure out where the script is being executed so we can find the testdata
    # for this unit test
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data = os.path.join(test_dir, 'testdata')
    repo_dir = os.path.join(test_data, 'repos', 'good_repo', 'unrendered')

    # Expected value for find_template
    return_value = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Call function
    var_0 = find_template(repo_dir)

    # Check value
    assert var_0 == return_value

# Generated at 2022-06-25 15:28:36.634418
# Unit test for function find_template

# Generated at 2022-06-25 15:28:44.225458
# Unit test for function find_template
def test_find_template():
    try:
        assert callable(find_template)
    except:
        print("Calling find_template() fails.")
        return False
    
    try:
        assert isinstance(find_template("tests/fake-repo-pre/"), str)
    except:
        print("The function find_template does not return the correct type. The function takes the argument tests/fake-repo-pre/ and should return a string.")
        return False


# Generated at 2022-06-25 15:28:46.084461
# Unit test for function find_template
def test_find_template():
    # Input parameters
    # repo_dir = ''

    # Output
    # Success
    assert(True)

# Generated at 2022-06-25 15:29:47.405567
# Unit test for function find_template
def test_find_template():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 15:29:56.759458
# Unit test for function find_template
def test_find_template():
    dict_0 = None
    dict_1 = {}
    dict_2 = []
    dict_3 = ()
    dict_4 = "abcd"
    dict_5 = "repo_dir"
    dict_6 = False
    dict_7 = 0.0
    dict_8 = 0
    dict_9 = 0
    dict_10 = list()

# Generated at 2022-06-25 15:29:58.779770
# Unit test for function find_template
def test_find_template():
    assert find_template('~/test') == "~/test/cookiecutter-{{cookiecutter.repo_name}}"


# Generated at 2022-06-25 15:30:05.422963
# Unit test for function find_template
def test_find_template():
    dict_0 = None
    var_0 = find_template(dict_0)
    dict_1 = None
    var_1 = find_template(dict_1)
    dict_2 = None
    var_2 = find_template(dict_2)
    dict_3 = None
    var_3 = find_template(dict_3)
    dict_4 = None
    var_4 = find_template(dict_4)
    dict_5 = None
    var_5 = find_template(dict_5)
    dict_6 = None
    var_6 = find_template(dict_6)
    dict_7 = None
    var_7 = find_template(dict_7)
    dict_8 = None
    var_8 = find_template(dict_8)
    dict_9 = None
    var_

# Generated at 2022-06-25 15:30:13.123711
# Unit test for function find_template
def test_find_template():
    project_template = find_template('/var/folders/./82vlkc1s4kzc47724_4_4z2m0000gn/T//tmppx2x29q')
    assert project_template == '/var/folders/./82vlkc1s4kzc47724_4_4z2m0000gn/T//tmppx2x29q/cookiecutter-pypackage'
# unit teast for function test_case_0

# Generated at 2022-06-25 15:30:14.976558
# Unit test for function find_template
def test_find_template():
    dict_0 = 'C:\\Users\\Ricardo\\PycharmProjects\\numpy\\'
    var_0 = find_template(dict_0)

# Generated at 2022-06-25 15:30:18.440203
# Unit test for function find_template
def test_find_template():
    dict_1 = None

# Generated at 2022-06-25 15:30:24.715771
# Unit test for function find_template
def test_find_template():

    a = find_template('/Users/gleb/.pyenv/versions/3.6.1/envs/cookiecutter/lib/python3.6/site-packages/cookiecutter/repos/cookiecutter-pypackage/')
    print(a)

test_find_template()

# Generated at 2022-06-25 15:30:25.826491
# Unit test for function find_template
def test_find_template():
    with pytest.raises(TypeError):
        test_case_0()


# Generated at 2022-06-25 15:30:26.776114
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)
