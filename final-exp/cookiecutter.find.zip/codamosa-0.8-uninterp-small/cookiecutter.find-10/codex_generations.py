

# Generated at 2022-06-25 15:22:04.149574
# Unit test for function find_template
def test_find_template():
    # Setup
    float_0 = -220.543458
    float_to_s = str(float_0)

    var_0 = find_template(float_to_s)

    # Exercise
    float_0 = -220.543458
    float_to_s = str(float_0)

    var_0 = find_template(float_to_s)

    # Verify
    assert abs(var_0 - -220.543458) <= 1e-06

    # Cleanup
    float_0 = -220.543458
    float_to_s = str(float_0)

    var_0 = find_template(float_to_s)

# Generated at 2022-06-25 15:22:06.451571
# Unit test for function find_template
def test_find_template():
    assert find_template(str) == None
    assert find_template(int) == None
    assert find_template(float) == None

# Test case for the function find_template

# Generated at 2022-06-25 15:22:16.363189
# Unit test for function find_template
def test_find_template():
    string_0 = '{{cookiecutter.project_slug}}'
    assert find_template(string_0) == '{{cookiecutter.project_slug}}'
    string_1 = '{{cookiecutter.author}}'
    assert find_template(string_1) == '{{cookiecutter.author}}'
    string_2 = '{{cookiecutter.project_name}}'
    assert find_template(string_2) == '{{cookiecutter.project_name}}'
    string_3 = '{{cookiecutter.description}}'
    assert find_template(string_3) == '{{cookiecutter.description}}'
    string_4 = '{{cookiecutter.version}}'
    assert find_template(string_4) == '{{cookiecutter.version}}'

# Generated at 2022-06-25 15:22:18.377229
# Unit test for function find_template
def test_find_template():
    float_0 = -220.543458
    var_0 = find_template(float_0)


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:22:22.379126
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception:
        print(False)

test_find_template()

# Generated at 2022-06-25 15:22:28.225677
# Unit test for function find_template
def test_find_template():
    template_dir = find_template(os.path.abspath(os.path.dirname(__file__)))
    assert os.path.exists(template_dir)

# Generated at 2022-06-25 15:22:31.964259
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print('NonTemplatedInputDirException:', 'incorrect input provided')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:22:32.997071
# Unit test for function find_template
def test_find_template():
    float_0 = 0.0
    find_template(float_0)



# Generated at 2022-06-25 15:22:34.689036
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template('test/fixtures/bad-repo-tmpl-missing') is None
    except NonTemplatedInputDirException as e:
        print(e)

# Generated at 2022-06-25 15:22:35.523212
# Unit test for function find_template
def test_find_template():
    test_case_0()
    
    

# test_case_0()

# Generated at 2022-06-25 15:22:42.044913
# Unit test for function find_template
def test_find_template():
    assert find_template('/extra/lib') == '/extra/lib/cookiecutter-{{cookiecutter.repo_name}}'
#
# # Unit test for function find_template
# def test_find_template():
#     assert find_template('jkl') == '/extra/lib/cookiecutter-{{cookiecutter.repo_name}}'


import os
import sys
import mock
import pytest
import cookiecutter.main
from click.testing import CliRunner
from cookiecutter import utils



# Generated at 2022-06-25 15:22:42.744542
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)


# Generated at 2022-06-25 15:22:43.473407
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)


# Generated at 2022-06-25 15:22:54.522883
# Unit test for function find_template
def test_find_template():
    var_5 = find_template("[\"cookiecutter?=project_name?={{cookiecutter.project_name}}\"]")
    print("%s" % str(var_5 == "cookiecutter?=project_name?={{cookiecutter.project_name}}"))
    var_5 = find_template("[\"cookiecutter?=project_name?={{cookiecutter.project_name}}\"]")
    print("%s" % str(var_5 == "cookiecutter?=project_name?={{cookiecutter.project_name}}"))
    var_5 = find_template("[\"cookiecutter?=project_name?={{cookiecutter.project_name}}\"]")

# Generated at 2022-06-25 15:23:00.621498
# Unit test for function find_template
def test_find_template():
    var_0 = find_template('./tests/fake-repo-tmpl')
    assert var_0 == './tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    var_1 = find_template('./tests/fake-repo-pre')
    assert var_1 == './tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    var_2 = find_template('./tests/fake-repo-post')
    assert var_2 == './tests/fake-repo-post/{{cookiecutter.repo_name}}'

    return 0

# Generated at 2022-06-25 15:23:02.763896
# Unit test for function find_template

# Generated at 2022-06-25 15:23:11.573394
# Unit test for function find_template
def test_find_template():
    float_3 = -220.543458
    float_1 = -220.543458
    float_2 = -220.543458
    float_0 = -220.543458
    float_5 = -220.543458
    float_4 = -220.543458

    # Call function
    find_template(float_0)

    assert (float_1 == float_2)
    assert (float_3 == float_4)
    assert (float_3 != float_0)
    assert (float_1 != float_4)
    assert (float_2 != float_5)
    assert (float_4 != float_0)
    assert (float_0 != float_5)
    assert (float_5 != float_2)
    assert (float_1 != float_0)

# Generated at 2022-06-25 15:23:17.614497
# Unit test for function find_template
def test_find_template():
    test_path = os.path.join(
        os.path.dirname(__file__), 'test_find_template_in')
    template_path = find_template(test_path)
    assert os.path.basename(template_path) == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:23:21.027156
# Unit test for function find_template
def test_find_template():
    """Assert that correct Cookiecutter template directory is found"""
    test_case_0()


# Generated at 2022-06-25 15:23:24.822240
# Unit test for function find_template
def test_find_template():
    try:
        # test case 0
        test_case_0()
        print("The function 'find_template' passed test case 0!")
    except Exception as e:
        print("Error in function 'find_template' with message:")
        print(e)



# Generated at 2022-06-25 15:23:30.974949
# Unit test for function find_template
def test_find_template():
    """
    Test for the function find_template
    """

    str_0 = 'Assert that correct Cookiecutter template directory is found'
    repo_dir = r'C:\Users\ddunbar.DATACORE\Desktop\Cookiecutter'
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)

# Generated at 2022-06-25 15:23:34.099219
# Unit test for function find_template
def test_find_template():
    test_dir_0 = "./tests/test-case-0/"
    result_0 = find_template(test_dir_0)
    assert (result_0 == "./tests/test-case-0/cookiecutter-project-template"), test_case_0()

# Generated at 2022-06-25 15:23:38.642857
# Unit test for function find_template
def test_find_template():
    assert(find_template('./tests_dir/input/') == './tests_dir/input/{{cookiecutter.repo_name}}/')
    print('Test for find template: Success')

test_case_0()
test_find_template()

# Generated at 2022-06-25 15:23:41.791728
# Unit test for function find_template
def test_find_template():
    os.chdir('../tests/fake-repo-pre')
    assert find_template('.') == './{{cookiecutter.repo_name}}'
    del os


# Generated at 2022-06-25 15:23:46.499373
# Unit test for function find_template
def test_find_template():

    # fixture
    repo_dir = '../tests/fake-repo-pre'
    expected_file_name = '../tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    # test
    ret_val = find_template(repo_dir)

    # assert
    assert ret_val == expected_file_name
    print('test_case_0: test_find_template() pass!')

# Generated at 2022-06-25 15:23:50.028773
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/test-case-0'
    project_template = './tests/test-case-0/cookiecutter-pypackage{{cookiecutter.version}}'

    # This should work
    assert(find_template(repo_dir) == project_template)

# Generated at 2022-06-25 15:23:55.925853
# Unit test for function find_template
def test_find_template():

    # if try to find template in a folder where no template exists
    with pytest.raises(NonTemplatedInputDirException):
        find_template('no_cookiecutter_template')
    # if try to find template in root directory
    with pytest.raises(NonTemplatedInputDirException):
        find_template('')
    # if try to find template in a folder where the template is the only file
    assert(find_template('template_only') == 'template_only/cookiecutter-{{cookiecutter.repo_name}}')
    # if try to find template in a folder with multiple files and directories
    assert(find_template('multiple_files') == 'multiple_files/cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:23:58.832946
# Unit test for function find_template
def test_find_template():
    template_directory = '../cookiecutter-template/'
    result = find_template(template_directory)
    assert result == template_directory + '{{cookiecutter.project_name}}', test_case_0()



# Generated at 2022-06-25 15:24:04.058634
# Unit test for function find_template
def test_find_template():
    path_to_test_repo_dir = os.path.join(
        os.path.dirname(__file__), 'test_files', 'placeholder_repo'
    )
    test_repo_dir = os.path.normpath(os.path.realpath(path_to_test_repo_dir))

    expected_template_dir = os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')

    template_dir = find_template(test_repo_dir)

    assert template_dir == expected_template_dir

# Generated at 2022-06-25 15:24:07.251990
# Unit test for function find_template
def test_find_template():
    print('test_find_template =====================================')
    # test_case_0()
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:15.773083
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/qinhan/PycharmProjects/cookiecutter-master/tests/files/fake-repo'
    test_case_0()
    print(str(find_template(repo_dir)))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:22.979839
# Unit test for function find_template
def test_find_template():
    b = find_template("/Users/anilraj/OneDrive/Documents/GitHub/cookiecutter-component-library/cookiecutter/cookiecutter-component-library/{{ name }}")

# Generated at 2022-06-25 15:24:32.808317
# Unit test for function find_template
def test_find_template():
    import os
    import shutil

    # create temporary folder
    test_dir = os.path.join(os.getcwd(), 'tmp')

    # recursive create several sub-folders
    # which contain a cookiecutter template
    test_dir_src = os.path.join(test_dir, 'src')
    test_dir_src_cookiecutter_src = os.path.join(test_dir_src, 'cookiecutter-src')
    test_dir_src_cookiecutter_dest = os.path.join(test_dir_src, 'cookiecutter-dest')

    logger.debug('Creating directory %s', test_dir)
    os.mkdir(test_dir)

    logger.debug('Creating directory %s', test_dir_src)
    os.mkdir(test_dir_src)



# Generated at 2022-06-25 15:24:37.270467
# Unit test for function find_template
def test_find_template():

    # CASE 0
    template_dir = find_template("/test/test_dir")

# Generated at 2022-06-25 15:24:43.852659
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'test_project', 'test_input')
    project_template = find_template(repo_dir)
    project_template_path = os.path.join(os.path.dirname(__file__), '..', 'test_project', 'test_input')
    assert(project_template == project_template_path)

if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:24:49.882229
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-data/fake-repo-pre/') == 'tests/test-data/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-data/fake-repo-pre-master/') == 'tests/test-data/fake-repo-pre-master/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:24:55.040353
# Unit test for function find_template
def test_find_template():
    # Mock the directory contents
    contents = ['a', 'foo-{{cookiecutter.project_name}}-bar', 'b']

    # Mock a real filesystem directory
    class MockDirectory(object):
        def __init__(self, directory_contents):
            self.directory_contents = directory_contents
        @property
        def contents(self):
            return self.directory_contents

    # Mock the directory
    obj_directory = MockDirectory(contents)

    assert find_template(obj_directory) == 'foo-{{cookiecutter.project_name}}-bar'

# Generated at 2022-06-25 15:25:05.883705
# Unit test for function find_template
def test_find_template():
    import os
    import tempfile

    temp_folder = tempfile.mkdtemp()

    os.mkdir(os.path.join(temp_folder, "Test_Cookiecutter_Dir"))
    os.mkdir(os.path.join(temp_folder, "Test_Simple_Dir"))
    os.mkdir(os.path.join(temp_folder, "Some_Other_Dir"))

    # Case 0: Normal case
    project_template = find_template(temp_folder)
    os.rmdir(project_template)

    # Case 1: Raise exception

# Generated at 2022-06-25 15:25:17.648959
# Unit test for function find_template
def test_find_template():

    str_0 = 'Test that find template returns the correct directory'
    # Create a directory structure for testing.
    # This mimics the directory structure created in a real repo that is
    # cloned to the local filesystem.  It contains a directory called
    # `{{cookiecutter.repo_name}}` that must be returned.
    os.makedirs('test_repo')
    os.makedirs(os.path.join('test_repo', 'log'))
    os.makedirs(os.path.join('test_repo', 'tests'))
    os.makedirs(os.path.join('test_repo', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-25 15:25:20.672835
# Unit test for function find_template
def test_find_template():
    # Test case 0
    # test assertion
    repo_dir = 'tests/test-input'
    template = find_template(repo_dir)
    assert template == 'tests/test-input/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:25:34.252613
# Unit test for function find_template
def test_find_template():
    # Case 0
    try:
        find_template('/home/travis/build/audreyr/cookiecutter')
    except NonTemplatedInputDirException:
        pass
    except:
        assert False, 'test_find_template: case 0 failed'
    else:
        assert False, 'test_find_template: case 0 failed'
    try:
        find_template('/home/travis/build/audreyr/cookiecutter/cookiecutter-pypackage')
    except NonTemplatedInputDirException:
        assert True, 'test_find_template: case 0 failed'
    except:
        assert False, 'test_find_template: case 0 failed'
    else:
        assert False, 'test_find_template: case 0 failed'

# Generated at 2022-06-25 15:25:38.660779
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/files/{{cookiecutter.project_slug}}'
    result = find_template(repo_dir)
    #print(result)
    assert result == "tests/files/{{cookiecutter.project_slug}}/cookiecutter-{{cookiecutter.project_slug}}"


# Generated at 2022-06-25 15:25:43.067741
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests/files/test-repo/cookiecutter-pypackage')
    # test with cookiecutter as directory name
    assert 'cookiecutter' in find_template(repo_dir)

    repo_dir = os.path.join('tests/files/test-repo/cookiecutter-jquery')
    # test with cookiecutter-<name> as directory name
    assert os.path.basename(repo_dir) in find_template(repo_dir)

# Generated at 2022-06-25 15:25:46.378989
# Unit test for function find_template
def test_find_template():
    import shutil
    import os
    base_dir = os.path.dirname(__file__)
    cc_dir = os.path.join(base_dir, 'cc_dir')
    shutil.copytree(base_dir, cc_dir)
    assert os.path.exists(cc_dir) == True

    project_template = find_template(cc_dir)
    assert os.path.join(cc_dir, 'cookiecutter-pypackage') == project_template

    shutil.rmtree(cc_dir)

# Generated at 2022-06-25 15:25:57.798952
# Unit test for function find_template
def test_find_template():
    # Test case 0: Template containing 'cookiecutter' and '{{' and '}}'
    repo_dir = 'C:/Users/sykim/Temple'
    project_template = find_template(repo_dir)
    assert (project_template == 'C:/Users/sykim/Temple/my_cookiecutter_template'),\
        "The project template should be my_cookiecutter_template"

    # Test case 1: Template containing 'cookiecutter' and '{{' and '}}' with extra symbols
    repo_dir = 'C:/Users/sykim/Temple'
    project_template = find_template(repo_dir)

# Generated at 2022-06-25 15:26:03.550359
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/fahim/dev/python_modules/cookiecutter-pylibrary/'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/fahim/dev/python_modules/cookiecutter-pylibrary/{{cookiecutter.project_slug}}'

test_find_template()

# Generated at 2022-06-25 15:26:09.913047
# Unit test for function find_template
def test_find_template():
    path_0 = 'tests/test-templates/fake-repo-pre/cookiecutter-pypackage'
    path_1 = 'tests/test-templates/fake-repo-pre/cookiecutter-pypackage/cookiecutter'
    os.path.exists(path_0)
    os.path.exists(path_1)
    #assert find_template(find_template(path_0)) == find_template(path_1)

# Generated at 2022-06-25 15:26:10.820905
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:26:13.735005
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/sample_repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/sample_repo/cookiecutter-pypackage'


# Generated at 2022-06-25 15:26:20.019707
# Unit test for function find_template
def test_find_template():
    str_1 = 'Test to find cookiecutter template'

    repo_dir_test = '\\test_temp\\test_repo\\cookiecutter-pypackage'
    test_result = find_template(repo_dir_test)

    #assert test_result == '\\test_temp\\test_repo\\cookiecutter-pypackage\\cookiecutter-pypackage'
    assert test_result is not None



# Generated at 2022-06-25 15:26:28.475175
# Unit test for function find_template
def test_find_template():
    assert find_template('/MyWork/cookiecutter-pypackage/') == '/MyWork/cookiecutter-pypackage/{{cookiecutter.repo_name}}', test_case_0()

# Generated at 2022-06-25 15:26:37.004545
# Unit test for function find_template
def test_find_template():
    print('\nRunning unit test for find_template')
    print(
        'Assert that correct Cookiecutter template directory is found when '
        'directory contains only one Cookiecutter template directory'
    )
    template_dir_0 = '.cookiecutters/cookiecutter-pypackage/{{cookiecutter.project_name}}'
    repo_dir_0 = '/home/username/repositories/repo_0'
    os.listdir.return_value = template_dir_0
    template_path = find_template(repo_dir_0)
    assert template_path == repo_dir_0 + '/' + template_dir_0
    print('Passed')

# Generated at 2022-06-25 15:26:45.111025
# Unit test for function find_template
def test_find_template():
    current_directory = os.getcwd()
    os.chdir('tests/fake-repo-pre/')
    project_template_dir = find_template('.')
    expected_project_template_dir = os.path.abspath(
        os.path.join('.', 'fake_project_template')
    )
    os.chdir(current_directory)
    assert project_template_dir == expected_project_template_dir
    test_case_0()
    
test_find_template()

# Generated at 2022-06-25 15:26:48.352399
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    assert(find_template(repo_dir) == os.path.join(repo_dir, 'fake-repo-{{cookiecutter.project_name}}'))

if __name__ == "__main__":
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:26:50.593725
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None, "Function test_case_0() returns None"

if __name__ == '__main__':
    test_find_template()
    print('All tests passed!')

# Generated at 2022-06-25 15:26:58.361265
# Unit test for function find_template
def test_find_template():
    """Tests for find_template()"""
    repo_dir = "./tests/test-repo"
    result = find_template(repo_dir)
    expected = './tests/test-repo/{{cookiecutter.project_name}}'
    assert result == expected, "find_template() returned '%s' instead of '%s'" % (result, expected)

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:27:01.574363
# Unit test for function find_template

# Generated at 2022-06-25 15:27:02.960266
# Unit test for function find_template
def test_find_template():
    """Unit test suite for function find_template."""
    repo_dir = 'cookiecutter'

# Generated at 2022-06-25 15:27:06.364642
# Unit test for function find_template
def test_find_template():
    """ Unit test for function find_template"""
    
    repo_dir_0 = os.path.join(os.getcwd(),"tests","test_templates","template_0")
    found_dir = find_template(repo_dir_0)
    assert found_dir == os.path.join(repo_dir_0, "{{cookiecutter.repo_name}}")

# Generated at 2022-06-25 15:27:12.296614
# Unit test for function find_template
def test_find_template():

    # Test case 0
    logger.info(test_case_0.__doc__)
    from cookiecutter import main
    main.cookiecutter('tests/test-repo-tmpl/', 'tests/fake-repo-pre/', no_input=True)
    repo_dir = 'tests/fake-repo-pre/tests/test-repo-tmpl'
    out_0 = find_template(repo_dir)
    assert out_0 == 'tests/fake-repo-pre/tests/test-repo-tmpl/{{cookiecutter.repo_name}}'


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:27:29.131115
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    expected_template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    actual_template_dir = find_template(repo_dir)

    assert expected_template_dir == actual_template_dir

# Generated at 2022-06-25 15:27:39.494261
# Unit test for function find_template

# Generated at 2022-06-25 15:27:40.274060
# Unit test for function find_template
def test_find_template():
    logger.info('Entering tests')


# Generated at 2022-06-25 15:27:45.958919
# Unit test for function find_template
def test_find_template():
    """Assert that correct Cookiecutter template directory is found.
    """
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'tests/fake-repo-tmpl')
    project_template = find_template(repo_dir)

    assert os.path.join(repo_dir, '{{cookiecutter.repo_name}}') == project_template, test_case_0()


# Generated at 2022-06-25 15:27:48.310170
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre-gen/') == 'tests/fake-repo-pre-gen/{{cookiecutter.repo_name}}'

# Integration test for function find_template

# Generated at 2022-06-25 15:27:53.071559
# Unit test for function find_template
def test_find_template():

    # Test case 0: Local directory created with default values.
    #
    # Variant: Created with cookiecutter.
    # Expect: Cookiecutter template directory is found.
    str_0 = 'Assert that correct Cookiecutter template directory is found'
    print(str_0)

    test_dir = 'tests/test-dir-0'
    result_dir = 'tests/test-dir-0/cookiecutter-pypackage'
    assert find_template(test_dir) == result_dir


test_find_template()

# Generated at 2022-06-25 15:27:55.898636
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:28:00.003596
# Unit test for function find_template
def test_find_template():
    repo_dir = '/User/Documents/cookiecutter-cookiecutter-example'
    repo_dir_contents = os.listdir(repo_dir)
    assert repo_dir_contents[0] == 'cookiecutter-example'
    assert repo_dir_contents[1] == 'README.rst'
    assert repo_dir_contents[2] == 'cookiecutter.json'
    assert repo_dir_contents[3] == 'hooks'

# Generated at 2022-06-25 15:28:07.359380
# Unit test for function find_template
def test_find_template():
    cwd = os.getcwd()
    os.chdir("/home/caroline/Develop/Cookiecutter/tests/test-repo")

# Generated at 2022-06-25 15:28:16.166861
# Unit test for function find_template
def test_find_template():
    import time
    import shutil
    import subprocess

    repo_url = "git@github.com:bryan-cg/cookiecutter-django-rest-framework.git"
    repo_dir = "cookiecutter-django-rest-framework"

    # Initialize directory
    if os.path.exists(repo_dir):
        shutil.rmtree(repo_dir)

    # Clone repo
    subprocess.call(["git", "clone", repo_url, repo_dir])

    # Find template directory
    project_template = find_template(repo_dir)
    assert(project_template)

    # Cleanup
    if os.path.exists(repo_dir):
        shutil.rmtree(repo_dir)

# Generated at 2022-06-25 15:28:32.374107
# Unit test for function find_template
def test_find_template():
    """Test that the correct template is found."""
    import os
    import shutil
    import tempfile

    from cookiecutter.main import find_template

    pass


# Generated at 2022-06-25 15:28:38.344190
# Unit test for function find_template
def test_find_template():
    ret = find_template('/Users/emily/repo/cookiecutter-cookiecutter/tests/fake-repo-pre/')
    assert ret == '/Users/emily/repo/cookiecutter-cookiecutter/tests/fake-repo-pre/cookiecutter-pypackage/'

# Generated at 2022-06-25 15:28:44.689798
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/jason/Documents/cookiecutter-example/cookiecutter-{{cookiecutter.project_name}}') == '/home/jason/Documents/cookiecutter-example/cookiecutter-{{cookiecutter.project_name}}'
    assert find_template('/home/jason/Documents/cookiecutter-example/cookiecutter-resume') == None

# Generated at 2022-06-25 15:28:46.096356
# Unit test for function find_template
def test_find_template():
    test_find_template_0()


# Generated at 2022-06-25 15:28:47.007715
# Unit test for function find_template
def test_find_template():
    test_case = [test_case_0]

# Generated at 2022-06-25 15:28:53.650713
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import find_template
    from cookiecutter import __file__ as cookiecutter_filename

    cookiecutter_dir = os.path.dirname(cookiecutter_filename)
    input_dir = os.path.join(cookiecutter_dir, 'tests/test-input')
    input_dir = os.path.abspath(input_dir)

    template = find_template(input_dir)

    assert 'test-template' in template


# Generated at 2022-06-25 15:28:56.904124
# Unit test for function find_template
def test_find_template():
    dir_name = "/Users/xuefuzhang/cookiecutter-project"
    assert find_template(dir_name) == "/Users/xuefuzhang/cookiecutter-project/{{cookiecutter.repo_name}}"

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:29:00.463623
# Unit test for function find_template
def test_find_template():
    print('Checking if the find_template function works as expected')

    repo_dir = 'Examples'

    project_template_expected = os.path.join(os.getcwd(),'Examples','cookiecutter-pypackage')
    project_template_actual = find_template(repo_dir)

    assert project_template_expected == project_template_actual, 'Actual and expected directories do not match.'

# Generated at 2022-06-25 15:29:06.291286
# Unit test for function find_template
def test_find_template():
    template_dir = 'tests/fake-repo-tmpl/'
    assert find_template(template_dir) == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}/'

test_find_template()

# Generated at 2022-06-25 15:29:10.378877
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo-0'
    project_template = 'tests/test-repo-0/{{cookiecutter.repo_name}}'

    assert(find_template(repo_dir) == project_template)


# Generated at 2022-06-25 15:29:28.908898
# Unit test for function find_template
def test_find_template():
    # Test case 0
    assert find_template('/home/ccadmin/cookiecutter-data-science') == '/home/ccadmin/cookiecutter-data-science/cookiecutter-scaffold'

if __name__ == '__main__':
    test_find_template()
    print('Test Passed!')

# Generated at 2022-06-25 15:29:35.958120
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from nose.tools import raises

    # Check for correct selection
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-input/good-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Check for non-existent directory
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)),
        'tests/test-input/bad-repo'
    )
    assert find_template(repo_dir) == None

    # Check

# Generated at 2022-06-25 15:29:37.121117
# Unit test for function find_template
def test_find_template():
    template_dir = 'abc'
    project_template = find_template(template_dir)

# Generated at 2022-06-25 15:29:44.392832
# Unit test for function find_template
def test_find_template():
    repo_dir_0 = '/home/zack/git/cookiecutter-pypackage/'
    repo_dir_1 = '/home/zack/git/cookiecutter-pypackage'
    repo_dir_2 = 'cookiecutter-pypackage/'

    # Test 1
    template_dir = find_template(repo_dir_0)
    assert template_dir == '/home/zack/git/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

    # Test 2
    template_dir = find_template(repo_dir_1)
    assert template_dir == '/home/zack/git/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

    # Test 3

# Generated at 2022-06-25 15:29:48.432622
# Unit test for function find_template
def test_find_template():
    dir_name = '/dummy_dir/dummy_dir2/dir1/dir2/dir3'
    assert(find_template(dir_name) == 'None')


# Generated at 2022-06-25 15:29:58.902224
# Unit test for function find_template
def test_find_template():
    print('\ntest_find_template')
    
    # First run
    # test_case_0 thows an error: NonTemplatedInputDirException
    try:
        test_case_0()
    except Exception as e:
        print('\ntest_find_template: Test_case_0 failed')
        print(e)
        assert(e == NonTemplatedInputDirException)

    # Second run
    try:
        assert(find_template('tests/fake-repo-pre') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}')
        print('\ntest_find_template: Test_case_1 passed')
    except Exception as e:
        print('\ntest_find_template: Test_case_1 failed')
        print(e)



# Generated at 2022-06-25 15:30:04.950589
# Unit test for function find_template
def test_find_template():
    repo_dir = '../tests/test-find-template'
    project_template = 'cookiecutter-{{ cookiecutter.github_project_name }}'
    try:
        project_template_path = find_template(repo_dir)
        assert project_template is not None
        assert os.path.basename(project_template_path) == project_template
    except NonTemplatedInputDirException:
        print("Project template not found")
    except AssertionError as e:
        print("\nAssertionError, project_template not properly found: %s\n" % e.args[0])


# Generated at 2022-06-25 15:30:15.870060
# Unit test for function find_template
def test_find_template():
    print('Test case 1:')
    test_case_0()
    test_dir = '/home/user/example/cookiecutter-example-template'
    template = find_template(test_dir)
    assert template == '/home/user/example/cookiecutter-example-template/cookiecutter-example-template'
    print(template)
    print('----------------------')
    print('')

    print('Test case 2:')
    str_0 = 'Assert that correct Cookiecutter template directory is found'
    test_dir_2 = '/home/user/example/cookiecutter-example-template-master'
    template_2 = find_template(test_dir_2)
    assert template_2 == '/home/user/example/cookiecutter-example-template-master/cookiecutter-example-template'
   

# Generated at 2022-06-25 15:30:17.858429
# Unit test for function find_template
def test_find_template():
    assert 'test_dir' == find_template('/path/to/test_dir')

# Generated at 2022-06-25 15:30:25.070521
# Unit test for function find_template
def test_find_template():
    repo_dir = 'C:\\GitHub\\NIX\\cookiecutter'
    actual = find_template(repo_dir)
    expected = 'C:\\GitHub\\NIX\\cookiecutter\\{{cookiecutter.repo_name}}'
    assert actual == expected, 'Cookiecutter template directory was not found'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:31:04.632509
# Unit test for function find_template
def test_find_template():
    """Verify that correct Cookiecutter template directory is found."""
    import re
    import os
    import warnings
    import pytest
    from cookiecutter.utils import rmtree

    from scmtest import create_test_repo
    from .test_utils import TEST_COOKIE_DIR

    test_result = None

    repo_dir = os.path.join(TEST_COOKIE_DIR, 'ab')

    # Since the ab repo is cloned for all tests, just delete the contents and
    # recreate the test files
    rmtree(repo_dir)
    create_test_repo(repo_dir)


# Generated at 2022-06-25 15:31:11.586759
# Unit test for function find_template
def test_find_template():
    str_0 = 'Assert that correct Cookiecutter template directory is found'
    os.chdir('/Users/james.codd/workspace/cookiecutter/tests/test-repo/')
    file_path = find_template('/Users/james.codd/workspace/cookiecutter/tests/')
    assert file_path == '/Users/james.codd/workspace/cookiecutter/tests/test-repo/{{cookiecutter.project_name}}', str_0

# Generated at 2022-06-25 15:31:17.504400
# Unit test for function find_template
def test_find_template():
    # Test Case 0
    # Assert that correct Cookiecutter template directory is found
    #
    # Input:
    #   repo_dir: test_find_template/test_case_0
    # Expected:
    #   test_case_0/template_0
    repo_dir = './examples/test_find_template/test_case_0'
    project_template = 'template_0'
    expected_result = './examples/test_find_template/test_case_0/template_0'
    result = find_template(repo_dir)

# Generated at 2022-06-25 15:31:19.686069
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/repo_dir') == '/home/repo_dir/cookiecutter-{{ cookiecutter.repo_name }}'

# Generated at 2022-06-25 15:31:25.965785
# Unit test for function find_template
def test_find_template():
    local_dir = os.getcwd()
    
    # First make sure we can find the template
    project_template = find_template(local_dir)
    
    # Now make sure we actually found the right directory
    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:31:29.454029
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-output/tests-repo') == (
        'tests/test-output/tests-repo/{{cookiecutter.repo_name}}'
    )


# Generated at 2022-06-25 15:31:40.127933
# Unit test for function find_template
def test_find_template():
    dirs = os.listdir(os.path.dirname(__file__))
    # print dirs
    tpl_dirs = []
    for root, dirs, files in os.walk('.'):
        for file in files:
            if file.endswith('.tmpl'):
                tpl_dirs.append(root)
    # print tpl_dirs

    for dir in dirs:
        if dir.endswith('.tmpl'):
            template = find_template(os.path.join(os.path.dirname(__file__), dir))

# Generated at 2022-06-25 15:31:43.819317
# Unit test for function find_template
def test_find_template():
    assert find_template("./tests/fake-repo-pre/{{cookiecutter.repo_name}}") == "./tests/fake-repo-pre/fake-repo"
    assert find_template("./tests/fake-repo-pre/tests") == "./tests/fake-repo-pre/tests"


# Generated at 2022-06-25 15:31:47.347093
# Unit test for function find_template
def test_find_template():
    os.system('mkdir temp')
    os.chdir('temp')
    os.system('mkdir cookiecutter-temp')

    assert find_template('.') == './cookiecutter-temp'

    os.chdir('..')
    os.system('rm -rf temp')


if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:31:52.720372
# Unit test for function find_template
def test_find_template():

    # Test case 0
    test_dir = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(test_dir, 'files', 'test_template')
    # template_dir = os.path.join(test_dir, 'files', 'test_template', 'cookiecutter-pypackage')
    os.chdir(template_dir)

    # Note - code below fails, but it shouldn't
    # find_template()
    
    # template_dir = os.path.join(test_dir, 'files', 'test_template')
    # os.chdir(template_dir)
    # assert find_template(template_dir) == os.path.join(template_dir, 'cookiecutter-pypackage')