

# Generated at 2022-06-25 15:22:08.755299
# Unit test for function find_template
def test_find_template():
    with open('/tmp/find_template.txt', 'w') as target:
        target.write('jspajdiNzZb(o2F^Y%b/C90jUt%A)$#nVu')
        target.write('u\nk\n7iY#m\n^I05')
        target.write('\navboQ^t2t3$#w\nK(jo')
        target.write('2q3fhOv(kW;s8sX')
        target.write('jspajdiNzZb(o2F^Y%b/C90jUt%A)$#nVu')
        target.write('u\nk\n7iY#m\n^I05')

# Generated at 2022-06-25 15:22:17.351748
# Unit test for function find_template
def test_find_template():
    str_0 = '\navboQ^t2t3$#w\nK(jo'
    str_1 = '\x02\x17\x0e\x14rAI\x0f\x17\x1d\x0f\x04\x1d\x1b\x16"\x1f'

# Generated at 2022-06-25 15:22:17.659893
# Unit test for function find_template
def test_find_template():
    assert True == True

# Generated at 2022-06-25 15:22:27.174093
# Unit test for function find_template
def test_find_template():
    """
    Parameters:
    -----------
    param_1 : str
        Local directory of newly cloned repo.

    Returns:
    --------
    project_template : str
        A relative path to the project template.
    """
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from unittest import TestCase

    class TestFindTemplate(TestCase):
        """A test case for the ``find_template`` function."""

        def test_normalize_path(self):
            """Verify a normalization path is returned."""
            result = find_template('tests/fake-repo-pre/')
            self.assertTrue(utils.normalize_path(result).endswith(
                'tests/fake-repo-pre/fake_project'))
        # sets repo_dir to a

# Generated at 2022-06-25 15:22:28.647677
# Unit test for function find_template
def test_find_template():
    if str(test_case_0.__name__) == 'test_case_0':
        print('test case: ''test_case_0''')
    else:
        print('test case: ' + str(test_case_0.__name__))


# Generated at 2022-06-25 15:22:38.750441
# Unit test for function find_template
def test_find_template():
    var_0 = find_template('D:\\Dropbox\\Cookiecutter Automation\\cookiecutter\\tests\\test-repos\\cookiecutter-pypackage')
    assert var_0 == 'D:\\Dropbox\\Cookiecutter Automation\\cookiecutter\\tests\\test-repos\\cookiecutter-pypackage\\cookiecutter-pypackage'
    var_1 = find_template('D:\\Dropbox\\Cookiecutter Automation\\cookiecutter\\tests\\test-repos\\cookiecutter-pypackage-with-no-hooks')

# Generated at 2022-06-25 15:22:39.595690
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-25 15:22:42.607728
# Unit test for function find_template
def test_find_template():
    # Case 0
    str_0 = '\navboQ^t2t3$#w\nK(jo'
    var_0 = find_template(str_0)
    # AssertionError: NonTemplatedInputDirException('Could not find a project template in this repo')

# Generated at 2022-06-25 15:22:53.529540
# Unit test for function find_template
def test_find_template():
    str_0 = '\navboQ^t2t3$#w\nK(jo'
    var_0 = find_template(str_0)
    assert var_0 == NonTemplatedInputDirException
    str_1 = '\navboQ^t2t3$#w\nK(j%o'
    var_1 = find_template(str_1)
    assert var_1 == os.path.join(str_1, '\navboQ^t2t3$#w\nK(j%o') + '\x00'
    str_2 = '\navboQ^t2t3$#w\nK(j%o'
    var_2 = find_template(str_2)

# Generated at 2022-06-25 15:22:56.391607
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\ProgramData\Anaconda3\Lib\site-packages\cookiecutter') == 'C:\ProgramData\Anaconda3\Lib\site-packages\cookiecutter\cookiecutter-template'

# Generated at 2022-06-25 15:23:05.103352
# Unit test for function find_template
def test_find_template():
    try:
        find_template(None)
    except NonTemplatedInputDirException:
        assert True
    except TypeError:
        assert False



# Generated at 2022-06-25 15:23:07.372323
# Unit test for function find_template
def test_find_template():
    path = os.path.realpath("cookiecutter/_tests/test-repo/")
    assert(path)

# Generated at 2022-06-25 15:23:09.887225
# Unit test for function find_template
def test_find_template():
    # pass
    test_dir = os.path.dirname(__file__)
    repo_dir = os.path.join(test_dir, 'test-data', 'tests',
                            'test-case-0', 'repo')
    project_template = os.path.join(repo_dir, 'cookiecutter-pypackage')

    found_template = find_template(repo_dir)
    assert found_template == project_template


# Generated at 2022-06-25 15:23:10.511274
# Unit test for function find_template
def test_find_template():
    assert test_case_0()

# Generated at 2022-06-25 15:23:18.613010
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\\Users\\david\\code\\cookiecutter\\cookiecutter') == 'C:\\Users\\david\\code\\cookiecutter\\cookiecutter\\cookiecutter-pypackage'
    assert find_template('C:\\Users\\david\\code\\cookiecutter\\tests\\test-asdf') == 'C:\\Users\\david\\code\\cookiecutter\\tests\\test-asdf\\fake-repo-pre'
    assert find_template('C:\\Users\\david\\code\\cookiecutter\\tests\\fake-repo-tmpl') == 'C:\\Users\\david\\code\\cookiecutter\\tests\\fake-repo-tmpl\\fake-repo-tmpl'


# Generated at 2022-06-25 15:23:29.282016
# Unit test for function find_template
def test_find_template():
    assert find_template('') == None
    assert find_template('aeiou') == None
    assert find_template('aeiou') is None
    assert find_template(None) == None
    assert find_template(None) is None
    assert find_template(None) is not None
    assert find_template('') is None
    assert find_template('') is not None
    assert find_template('') != None
    assert find_template('aeiou') != None
    assert find_template(None) != None
    assert find_template(None) is not None
    assert find_template('aeiou') is not None
    assert find_template(None) is not None
    assert find_template(None) is not None
    assert find_template('') is not None

# Generated at 2022-06-25 15:23:31.332549
# Unit test for function find_template
def test_find_template():

    def test_case_0():
        bool_0 = None
        var_0 = find_template(bool_0)



# Generated at 2022-06-25 15:23:34.099091
# Unit test for function find_template
def test_find_template():
    # Find the absolute path so that on Windows, we get the
    # 'C:\', not '/' as the root.
    root = os.path.abspath('/')
    assert find_template(root).endswith('apple')


# Generated at 2022-06-25 15:23:40.528688
# Unit test for function find_template
def test_find_template():
    user_dir = os.path.expanduser('~')
    repo_dir = os.path.join(user_dir, 'cookie-repo')
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)
    os.mkdir(repo_dir)
    result = find_temp

# Generated at 2022-06-25 15:23:42.248449
# Unit test for function find_template
def test_find_template():
    assert find_template('example/') == 'example/cookiecutter-pypackage-{{cookiecutter.project_slug}}'


# Generated at 2022-06-25 15:23:48.071311
# Unit test for function find_template
def test_find_template():
    assert find_template(
        os.path.join(
            os.path.expanduser("~"),
            '.cookiecutters',
            'cookiecutter-pypackage',
            '{{cookiecutter.repo_name}}',
        )
    ) == 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-25 15:23:49.255963
# Unit test for function find_template
def test_find_template():
    try:
        assert test_case_0() == None
    except:
        pass

# Generated at 2022-06-25 15:23:53.074238
# Unit test for function find_template
def test_find_template():
    repo_dir =  os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'tests', 'fake-repo-pre')
    expected = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'tests', 'fake-repo-pre', '{{cookiecutter.project_dirname}}')
    actual = find_template(repo_dir)
    assert actual == expected, "function find_template did not return the correct value"


# Generated at 2022-06-25 15:23:54.572768
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    assert None == var_0

# Generated at 2022-06-25 15:24:08.465191
# Unit test for function find_template
def test_find_template():
    from cookiecutter.compat import WIN
    from cookiecutter import utils
    from cookiecutter.tests import MockEnvironment

    try:
        from mock import patch, MagicMock
    except ImportError:
        from unittest.mock import patch, MagicMock

    if not WIN:
        # test with '~' at the start of repo_dir
        # and that directory does not exist
        with patch('cookiecutter.prompt.read_user_yes_no', return_value=True):
            with patch('cookiecutter.main.clone') as clone_mock:
                with patch('cookiecutter.main.os.listdir') as listdir_mock:
                    listdir_mock.side_effect = [
                        FileNotFoundError,
                        [],
                    ]

# Generated at 2022-06-25 15:24:11.756179
# Unit test for function find_template
def test_find_template():
    assert os.path.exists(find_template('tests/test-repo/'))

# Generated at 2022-06-25 15:24:13.106567
# Unit test for function find_template
def test_find_template():
    assert False == False

# Connected Tests

test_case_0()

# Generated at 2022-06-25 15:24:15.546312
# Unit test for function find_template
def test_find_template():
    # No failure
    try:
        test_case_0()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-25 15:24:16.451521
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:24:20.418629
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print('Find template test case 0 failed.')
    else:
        print('Find template test case 0 passed.')


# Generated at 2022-06-25 15:24:26.365465
# Unit test for function find_template
def test_find_template():
    # First parameter is a bool, expected output is either a string or None.
    test_case_0()


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:26.961582
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-25 15:24:29.737494
# Unit test for function find_template
def test_find_template():
    try:
        var_0 = None
        find_template(var_0)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-25 15:24:35.968049
# Unit test for function find_template
def test_find_template():
    var_1 = os.listdir('/var/log/')
    var_1 = os.path.join('/var/log/', var_1)
    var_1 = os.path.abspath(var_1)
    var_1 = os.path.basename(var_1)
    print(var_1)
    print('/var/log//var/log/')
    assert (var_1 == '/var/log//var/log/')

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 15:24:38.873882
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == None


# Generated at 2022-06-25 15:24:48.713538
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    fake_repo_dir = os.path.abspath('{{cookiecutter.company_name}}/')

    try:
        find_template(fake_repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError(
            'find_template should throw an NonTemplatedInputDirException')

# Generated at 2022-06-25 15:24:50.648443
# Unit test for function find_template

# Generated at 2022-06-25 15:24:56.399037
# Unit test for function find_template
def test_find_template():
    assert find_template() == '.'
    assert find_template('.') == '.'
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/cookiecutter-pypackage'
    assert find_template('tests/fake-repo-pre') == 'tests/fake-repo-pre/cookiecutter-pypackage'
    assert find_template('tests/fake-repo-pre/.') == 'tests/fake-repo-pre/cookiecutter-pypackage'
    assert find_template('tests/fake-repo-pre/.git/') == 'tests/fake-repo-pre/cookiecutter-pypackage'

# Generated at 2022-06-25 15:25:05.519695
# Unit test for function find_template
def test_find_template():
    from cookiecutter.find import find_template
    from cookiecutter.utils import rmtree
    import os

    if not os.path.exists('tests/fake-repo-pre'):
        return 'Missing test data: tests/fake-repo-pre'

    template_dir = '/tmp/fake-repo-pre'

    from shutil import copytree
    copytree('tests/fake-repo-pre', template_dir)

    template = find_template(template_dir)

    rmtree(template_dir)

    if template != os.path.join(template_dir, 'fake-project'):
        return 'Template {} should be {}'.format(template, template_dir)

    return 'ok'

# Generated at 2022-06-25 15:25:06.780498
# Unit test for function find_template
def test_find_template():
    var_3 = find_template(None)


# Generated at 2022-06-25 15:25:16.707667
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)
    assert var_0 == find_template()

if __name__ == "__main__":
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:25:18.738283
# Unit test for function find_template
def test_find_template():
    bool_1 = None
    with pytest.raises(NonTemplatedInputDirException): assert find_template(bool_1) == bool_1

# Generated at 2022-06-25 15:25:20.059586
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)

# Generated at 2022-06-25 15:25:26.119559
# Unit test for function find_template
def test_find_template():
    template_path = os.path.normpath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            '..',
            '..',
            'tests',
            'test-find-template'
        )
    )
    template_dir = find_template(template_path)
    expected_dir = os.path.join(template_path, '{{cookiecutter.project_name}}')

    assert os.path.normpath(template_dir) == os.path.normpath(expected_dir)

# Generated at 2022-06-25 15:25:30.610773
# Unit test for function find_template
def test_find_template():
    try:
        assert callable(find_template)
    except NameError:
        return False

    try:
        test_case_0()
    except TypeError:
        return False

    return True


# Generated at 2022-06-25 15:25:31.852425
# Unit test for function find_template
def test_find_template():
    assert find_template("Test") == None


# Generated at 2022-06-25 15:25:36.211782
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\\Users\\benwi\\Documents\\GitHub\\IT490B\\src\\cookiecutter\\tests\\test_project') == 'C:\\Users\\benwi\\Documents\\GitHub\\IT490B\\src\\cookiecutter\\tests\\test_project\\{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:25:39.669074
# Unit test for function find_template
def test_find_template():
    assert None == find_template(None)

# Generated at 2022-06-25 15:25:42.353856
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:25:49.655751
# Unit test for function find_template
def test_find_template():
    assert find_template('') == None
    output = find_template('/home/benjamin/.cookiecutters/cookiecutter-pypackage');
    assert output == '/home/benjamin/.cookiecutters/cookiecutter-pypackage/cookiecutter-pypackage'
    output = find_template('/home/benjamin/.cookiecutters/cookiecutter-pypackage-master');
    assert output == '/home/benjamin/.cookiecutters/cookiecutter-pypackage-master/cookiecutter-pypackage'
    output = find_template('/home/benjamin/.cookiecutters/cookiecutter-pypackage-master/');
    assert output == '/home/benjamin/.cookiecutters/cookiecutter-pypackage-master/cookiecutter-pypackage'

# Generated at 2022-06-25 15:26:03.850361
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:26:13.612882
# Unit test for function find_template
def test_find_template():
    # These "asserts" using only for self-checking and not necessary for auto-testing
    assert find_template('/home/{{cookiecutter.project_slug}}/'
                         '{{cookiecutter.project_slug}}/'
                         '{{cookiecutter.project_slug}}/') == '/home/{{cookiecutter.project_slug}}/'
    assert find_template('{{cookiecutter.pypackage_name}}/') == '{{cookiecutter.pypackage_name}}/'

# Generated at 2022-06-25 15:26:15.042777
# Unit test for function find_template
def test_find_template():
    try:
        assert(test_case_0())
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-25 15:26:17.104779
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)


# Generated at 2022-06-25 15:26:19.896293
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        assert str(e) == 'None is not a valid path'

# Generated at 2022-06-25 15:26:26.012390
# Unit test for function find_template

# Generated at 2022-06-25 15:26:29.744051
# Unit test for function find_template
def test_find_template():
    var_0 = find_template('Input/cookiecutter-pypackage')
    # assert var_0['project_template'] == 'Input/cookiecutter-pypackage/{{cookiecutter.repo_name}}', var_0['project_template']



# Generated at 2022-06-25 15:26:32.880361
# Unit test for function find_template
def test_find_template():
    a = find_template('test')
    print(a)
    b = find_template('test2')
    print(b)
    # test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:34.403217
# Unit test for function find_template
def test_find_template():
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()


# Generated at 2022-06-25 15:26:40.835827
# Unit test for function find_template
def test_find_template():
    # AssertionError: NonTemplatedInputDirException not raised
    try:
        test_case_0()
    except Exception as e:
        assert isinstance(e, NonTemplatedInputDirException)
        print("Testing if NonTemplatedInputDirException is raised")
# End of unit test for function find_template

# Generated at 2022-06-25 15:27:09.378310
# Unit test for function find_template
def test_find_template():

    assert(find_template(os.path.dirname(__file__)) == os.path.join(os.path.dirname(__file__), 'cookiecutter-pypackage'))

# Generated at 2022-06-25 15:27:12.051302
# Unit test for function find_template
def test_find_template(): 
    assert find_template('tests/test-find-template') == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:27:18.252933
# Unit test for function find_template
def test_find_template():
    bool_0 = os.path.join('tests', 'files', 'input', '{{cookiecutter.repo_name}}')
    var_0 = find_template(bool_0)
    assert (isinstance(var_0, str))
    assert (var_0 == 'tests/files/input/{{cookiecutter.repo_name}}')


# Generated at 2022-06-25 15:27:24.873193
# Unit test for function find_template
def test_find_template():
    # Find an available port
    import socket

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 0))
    port = sock.getsockname()[1]
    sock.close()

    # Start the server
    from SimpleHTTPServer import SimpleHTTPRequestHandler
    import BaseHTTPServer

    httpd = BaseHTTPServer.HTTPServer(('localhost', port), SimpleHTTPRequestHandler)
    server_thread = threading.Thread(target=httpd.serve_forever)
    server_thread.daemon = True
    server_thread.start()

    # Perform tests
    import tempfile
    tmpdir = tempfile.mkdtemp()

    # test 1
    logger.debug('Downloading cookiecutter-pypackage')
    cmd

# Generated at 2022-06-25 15:27:26.739710
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)



# Generated at 2022-06-25 15:27:28.911943
# Unit test for function find_template
def test_find_template():
    with open('cookiecutter/tests/test-repo/README.rst') as f:
        find_template('cookiecutter/tests/test-repo')
        pass

# Generated at 2022-06-25 15:27:33.726959
# Unit test for function find_template
def test_find_template():
    try:
        assert os.path.exists(find_template('https://github.com/xingjianning/flask-blueprint.git'))
        print ('test_find_template passed.')
    except NonTemplatedInputDirException:
        print ('test_find_template failed.')


# Generated at 2022-06-25 15:27:40.075589
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException as e:
        print("Exception raised: " + str(e))
        assert True

test_find_template()

# Generated at 2022-06-25 15:27:46.378090
# Unit test for function find_template
def test_find_template():
    import os.path

    # Create a real path for tests.
    # look for template in tests/fake-repo/
    project_path = os.path.abspath(os.path.dirname(__file__))
    repo_path = os.path.join(project_path, 'fake-repo')

    # Assert that find_template is able to determined that the project template
    # is the 'fake-repo-template' directory.
    template = find_template(repo_path)
    assert 'fake-repo-template' in template

# Generated at 2022-06-25 15:27:47.956888
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 15:28:45.460474
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/runner/work/cookiecutter-django/cookiecutter-django/tests/fixtures/fake-repo') == '/home/runner/work/cookiecutter-django/cookiecutter-django/tests/fixtures/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:28:48.200102
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError("Exception was not raised (NonTemplatedInputDirException)")

# Generated at 2022-06-25 15:28:51.296273
# Unit test for function find_template
def test_find_template():
    assert find_template('test/fixtures') == 'test/fixtures/cookiecutter-{{ cookiecutter.repo_name }}'


# Generated at 2022-06-25 15:28:52.610291
# Unit test for function find_template
def test_find_template():
    test_case_0()

# print(('Tests passed'))

# Generated at 2022-06-25 15:28:56.587448
# Unit test for function find_template
def test_find_template():
    find_template
    try:
        test_case_0()
    except Exception:
        import sys
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        for line in lines:
            print(line, end='')

# Generated at 2022-06-25 15:29:02.146801
# Unit test for function find_template
def test_find_template():
    try:
        find_template(None)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError('NonTemplatedInputDirException not raised')


if __name__ == '__main__':
    import sys
    sys.exit(
        unittest.main(
            testRunner=xmlrunner.XMLTestRunner(
                output='test-reports')))

# Generated at 2022-06-25 15:29:04.757517
# Unit test for function find_template
def test_find_template():
    print('Test Case 0')
    test_case_0()


# Generated at 2022-06-25 15:29:09.153608
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()

# Generated at 2022-06-25 15:29:10.722429
# Unit test for function find_template
def test_find_template():
    bool_0 = None
    var_0 = find_template(bool_0)


# Generated at 2022-06-25 15:29:13.426248
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/paul/ceci est un test') == 'ceci est un test/cookiecutter-{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:31:10.614804
# Unit test for function find_template
def test_find_template():
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()

# Generated at 2022-06-25 15:31:16.141481
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fixtures/template-repo/{{cookiecutter.project_name}}') == 'tests/fixtures/template-repo/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:31:21.490077
# Unit test for function find_template
def test_find_template():
    # This function uses the built-in methods open() and print()
    # to write data to a file or to stdout for testing purposes.
    import StringIO
    import sys

    # Capture the output to a pipe
    new_target = StringIO.StringIO()
    old_target, sys.stdout = sys.stdout, new_target

    # Call the function
    test_case_0()

    # Restore the old stdout
    sys.stdout = old_target
    actual = new_target.getvalue()
    actual = actual.rstrip('\n')

    assert actual == expected_result

# Generated at 2022-06-25 15:31:22.320973
# Unit test for function find_template
def test_find_template():
    find_template(None)

# Generated at 2022-06-25 15:31:23.053971
# Unit test for function find_template
def test_find_template():
    var_2 = None
    find_template(var_2)

# Generated at 2022-06-25 15:31:24.875558
# Unit test for function find_template
def test_find_template():
        assert find_template('F:\GitHub\GitHubRepos\CC\cookicutter_cookie\tests\cases\files\\input') == 'F:\\GitHub\\GitHubRepos\\CC\\cookicutter_cookie\\tests\\cases\\files\\input\\project_template'

# Generated at 2022-06-25 15:31:26.290851
# Unit test for function find_template
def test_find_template():
    #test case 0
    try:
        test_case_0()
    except Exception as e:
        print(str(e))


test_find_template()

# Generated at 2022-06-25 15:31:28.964032
# Unit test for function find_template
def test_find_template():
    print(find_template('C:\\Users\\ben.ingram\\PycharmProjects\\CookiecutterTests'))



# Generated at 2022-06-25 15:31:32.217889
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None


# Generated at 2022-06-25 15:31:34.096841
# Unit test for function find_template
def test_find_template():
    print("A")
    assert test_case_0()