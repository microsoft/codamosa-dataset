

# Generated at 2022-06-25 15:22:03.384811
# Unit test for function find_template
def test_find_template():
    assert find_template("cookiecutter-pypackage/tests/test-input") == "cookiecutter-pypackage/tests/test-input"

# Generated at 2022-06-25 15:22:06.544076
# Unit test for function find_template
def test_find_template():
    assert 'template' == find_template('templates')
    assert 'template' == find_template('templates')
    assert 'template' == find_template('templates')
    assert 'template' == find_template('templates')

# Generated at 2022-06-25 15:22:10.838441
# Unit test for function find_template
def test_find_template():
    try:
        assert os.path.exists(find_template(os.getcwd()))
    except:
        print("UnitTest::find_template failed!")
        return False
    else:
        return True



# Generated at 2022-06-25 15:22:11.641314
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:14.207118
# Unit test for function find_template

# Generated at 2022-06-25 15:22:21.619626
# Unit test for function find_template
def test_find_template():
    var_1 = 'fxW8-v/@C%h2/bcB(dPb8XvKg:1\n?zp/D6TcTgw,U6-!U6pH]7V9XD,u>7VQ$s_yA,~Qex[(}i7V_'
    var_1 = os.path.expanduser(var_1)
    var_1 = os.path.expandvars(var_1)
    var_2 = find_template(var_1)
    assert var_2 == var_1 + '{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:22:24.852429
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:22:28.827952
# Unit test for function find_template
def test_find_template():
    float_2 = 3.7
    var_0 = find_template(float_2)
    assert var_0 is not None




# Generated at 2022-06-25 15:22:34.977567
# Unit test for function find_template
def test_find_template():
    here = os.path.dirname(os.path.abspath(__file__))
    input_dir = os.path.join(here, 'fake-repo/')
    expected_output = os.path.join(here, 'fake-repo/{{cookiecutter.repo_name}}')
    output = find_template(input_dir)
    assert expected_output == output

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:22:41.022994
# Unit test for function find_template
def test_find_template():
    inputs = ['dict', 'TestException', 'Fake_Input', 'real', '~', '@']
    outputs = [False, True, True, True, True, True]
    funcs = [test_case_0]

    ret = 0
    for i in range(len(funcs)):
        if not funcs[i](inputs[i]) is outputs[i]:
            print('Test case ' + str(i) + ' failed!')
            ret = -1
    if not ret == 0:
        exit(ret)

# Generated at 2022-06-25 15:22:46.527329
# Unit test for function find_template
def test_find_template():
    repo_dir = "D:\Github\Cookiecutter\Github\crilosec\cookiecutter-python-script-template"
    project_template = find_template(repo_dir)
    print(project_template)

# test_find_template()

# Generated at 2022-06-25 15:22:49.540468
# Unit test for function find_template
def test_find_template():
    if find_template('.') is None:
        test_case_0()
    else:
        assert find_template('.') is True

# Generated at 2022-06-25 15:22:56.384341
# Unit test for function find_template
def test_find_template():
    import unittest
    from unittest.mock import patch, Mock

    mock_os_listdir_object = Mock()
    mock_os_listdir_object.iterdir.return_value = ['a', 'bb', '{{', 'ccc']
    mock_os_path_object = Mock()
    mock_os_path_object.join.return_value = 'test_file'

    with patch.object(os, 'listdir') as mock_os_listdir:
        with patch.object(os.path, 'join') as mock_os_path_join:
            mock_os_listdir.return_value = mock_os_listdir_object.iterdir()
            mock_os_path_join.return_value = mock_os_path_object.join()
            assert find_template('test_dir')

# Generated at 2022-06-25 15:23:09.486986
# Unit test for function find_template
def test_find_template():
    """ check error handling in function find_template """

    # create temporary directory
    import tempfile
    temp_dir = tempfile.mkdtemp()

    # create dir named "cookiecutter" in temp_dir
    cookiecutter_dir = os.path.join(temp_dir, 'cookiecutter')
    os.mkdir(cookiecutter_dir)

    # create subdir with variable name in "cookiecutter" dir
    dummy_dir = os.path.join(cookiecutter_dir, '{{dummy}}')
    os.mkdir(dummy_dir)

    # create file with variable name in "cookiecutter" dir
    dummy_file = os.path.join(cookiecutter_dir, '{{dummy}}')
    f = open(dummy_file, 'w')
    f.close()

   

# Generated at 2022-06-25 15:23:15.498386
# Unit test for function find_template
def test_find_template():
    try:
        find_template('.')
    except Exception as e:
        assert e.__class__.__name__ == 'NonTemplatedInputDirException'
        bool_0 = True


# Generated at 2022-06-25 15:23:16.706024
# Unit test for function find_template
def test_find_template():
    assert bool_0 ==  True
    print("Test passed")

# Generated at 2022-06-25 15:23:20.832442
# Unit test for function find_template
def test_find_template():
    test_path = 'test_repo/'
    expected_path = 'test_repo/{{ cookiecutter.project_name }}'
    actual_path = find_template(test_path)

    # unit test for the equality of the path
    if actual_path == expected_path:
        test_case_0()
    else:
        print("The result of function find_template is not right")

# Generated at 2022-06-25 15:23:24.958269
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    test_path = os.path.join(utils.get_project_root(), 'tests', 'test-repo')
    test_template = find_template(test_path)
    assert test_template == os.path.join(test_path, 'cookiecutter-pypackage')

# Generated at 2022-06-25 15:23:33.997396
# Unit test for function find_template
def test_find_template():
    # Home directory
    home_dir = os.path.expanduser("~")
    # Create a new folder in home directory

# Generated at 2022-06-25 15:23:38.945502
# Unit test for function find_template
def test_find_template():
    repo_dir = "C:\\Users\\yc\\Desktop\\cookiecutter\\MyTestTemplate"
    project_template = find_template(repo_dir)
    assert(project_template==repo_dir)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:23:45.954115
# Unit test for function find_template
def test_find_template():
    """
    This function tests if find_template function locates the correct project template directory.
    """

    os.mkdir("test_case")
    os.chdir("test_case")

    # Create a directory with a name including {{ and }} for cookiecutter to recognize it as a project template.
    os.mkdir("cookiecutter-{{cookiecutter_project_dir}}")

    # Capture the search result from find_template function
    test_result = find_template(".")

    # Compare the search result with the expected project template path
    try:
        assert test_result == "./cookiecutter-{{cookiecutter_project_dir}}"
    except AssertionError as e:
        print("find_template() failed - the project template is not detected.")
        raise

    # Remove the directory created during test
    os.chdir

# Generated at 2022-06-25 15:23:53.559425
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'repo-templates', 'cookiecutter-pypackage')) is not None
    assert find_template(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'repo-templates', 'cookiecutter-python')) is not None
    assert find_template(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'repo-templates', 'cookiecutter-python-100k')) is not None

# Generated at 2022-06-25 15:23:54.775726
# Unit test for function find_template
def test_find_template():
    #TODO call find_template()
    print("TODO")


# Generated at 2022-06-25 15:23:56.209131
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:23:59.612332
# Unit test for function find_template
def test_find_template():
    """Test function find_template"""
    print("Test source code of cookiecutter")
    # Get current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    print("Current directory: " + current_dir + "\n")

    # Get path for project template
    project_template_dir = os.path.join(current_dir, "../tests/test-project-template")
    print("Project template directory: " + project_template_dir + "\n")

    # Set the path for project template to find template
    # project_template_dir = "../"
    # project_template_dir = "../tests/test-project-template"
    print("Test function find_template()")
    # function_find_template(project_template_dir)


# Generated at 2022-06-25 15:24:02.663747
# Unit test for function find_template
def test_find_template():
    os.chdir('tests')
    repo_dir = os.path.abspath('repo_with_no_hooks')

    assert find_template(repo_dir) == os.path.abspath('repo_with_no_hooks/{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:24:13.183094
# Unit test for function find_template
def test_find_template():
    repo_dir = os.getcwd()
    repo_dir_contents = os.listdir(repo_dir)
    bool_0 = False
    bool_1 = False
    bool_2 = False
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            bool_0 = True
            break
    if bool_0:
        for item_1 in repo_dir_contents:
            if 'cookiecutter' in item_1:
                bool_1 = True
                break
        for item_2 in repo_dir_contents:
            if 'cookiecutter' in item_2 and '{{' not in item_2 and '}}' not in item_2:
                bool_2 = True
                break
    assert bool

# Generated at 2022-06-25 15:24:15.013805
# Unit test for function find_template
def test_find_template():
    test_dir = os.getcwd()
    assert find_template(test_dir) == test_dir


# Generated at 2022-06-25 15:24:17.899402
# Unit test for function find_template
def test_find_template():
    # Test valid case
    template = find_template('/home/fangzhou/0-cookiecutter_api/tests/')
    print(template)

    # Test invalid case


test_find_template()

test_case_0()

# Generated at 2022-06-25 15:24:22.386720
# Unit test for function find_template
def test_find_template():
    repo_dir = 'test/test_cookiecutter'
    project_template = find_template(repo_dir)
    bool_template = os.path.exists(project_template)
    return bool_template

test_case_0()

# Generated at 2022-06-25 15:24:32.082406
# Unit test for function find_template
def test_find_template():
    print('running find_template() test...')
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(test_dir, '..', '..', 'cookiecutters')
    test_data = os.path.join(test_dir, 'flask-gulp-bower-python')
    project_template = os.path.join(test_data, '{{cookiecutter.project_name}}')
    assert find_template(test_data) == project_template

# Generated at 2022-06-25 15:24:32.764515
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:24:41.016339
# Unit test for function find_template
def test_find_template():
    print("--- Beginning find_template unit tests... ---")
    # Test 1

    repo_dir = "D:/pass/cookie"
    expected_template = "D:/pass/cookie/cookiecutter-pypackage"

    print("Test 1")

    result = find_template(repo_dir)

    if result == expected_template:
        print("--> PASSED")
    else:
        print("--> FAILED")

    # Test 2

    repo_dir = "D:/fail/cookie"
    expected_template = "D:/pass/cookie/cookiecutter-pypackage"

    print("Test 2")

    result = find_template(repo_dir)

    if result == expected_template:
        print("--> PASSED")
    else:
        print("--> FAILED")

    # Test 3



# Generated at 2022-06-25 15:24:42.183418
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None, 'Wrong value'


# Generated at 2022-06-25 15:24:44.057691
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir/cookiecutter-{{ cookiecutter.repo_name }}'

# Generated at 2022-06-25 15:24:46.182777
# Unit test for function find_template
def test_find_template():
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 15:24:51.937722
# Unit test for function find_template
def test_find_template():
    test_dir = r'd:\Source\mynodes\cookiecutter-mynodes'
    project_template = find_template(test_dir)
    assert project_template == r'd:\Source\mynodes\cookiecutter-mynodes\{{ cookiecutter.project_slug }}'

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:24:53.822208
# Unit test for function find_template
def test_find_template():
    assert find_template("test_find_template") == None



# Generated at 2022-06-25 15:24:58.866761
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/123'
    try:
        project_template = find_template(repo_dir)
    except NonTemplatedInputDirException:
        print("find_template function test successful.")
# test case 1

# Generated at 2022-06-25 15:25:07.048655
# Unit test for function find_template
def test_find_template():
    # Test case 0: Template exists
    repo_dir = "C:\\Users\\amit_\\Documents\\GitHub\\cookiecutter-example-django-app\\{{cookiecutter.project_slug}}"
    project_template_0 = "C:\\Users\\amit_\\Documents\\GitHub\\cookiecutter-example-django-app\\{{cookiecutter.project_slug}}"

    return_value_0 = find_template(repo_dir)
    assert return_value_0 == project_template_0

    # Test case 1: Template does not exist
    repo_dir_1 = "C:\\Users\\amit_\\Documents\\GitHub\\cookiecutter-example-django-app\\my django app"

# Generated at 2022-06-25 15:25:14.183528
# Unit test for function find_template
def test_find_template():
    # Case 0: valid
    assert(find_template("../") == "../cookiecutter-pypackage")

# Generated at 2022-06-25 15:25:15.276627
# Unit test for function find_template
def test_find_template():
    test_case_0()
    return True

# Generated at 2022-06-25 15:25:19.576446
# Unit test for function find_template
def test_find_template():
    # Case 0: Base Case
    repo_dir = 'project_dir/'
    assert find_template(repo_dir) == 'project_dir/'
    assert find_template('') == None

# Generated at 2022-06-25 15:25:25.245938
# Unit test for function find_template
def test_find_template():
    """Test the functionality of function find_template
    """
    # Test case 0
    repo_dir = "."
    bool_0 = False
    try:
        project_template = find_template(repo_dir)
    except Exception:
        bool_0 = True

# Generated at 2022-06-25 15:25:28.979079
# Unit test for function find_template
def test_find_template():
    assert find_template("./") == "./.cookiecutter-test"

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:25:30.341091
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:25:32.240600
# Unit test for function find_template
def test_find_template():
    assert find_template('SudokuSolver') == 'SudokuSolver/SudokuSolver'


# Generated at 2022-06-25 15:25:35.054083
# Unit test for function find_template
def test_find_template():
    logger.debug('The project template is %s.', find_template('/home/daniel/Documents/Cookiecutter-Test/'))
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 15:25:38.853383
# Unit test for function find_template
def test_find_template():
    check_0 = find_template('/home/nicola/cookiecutter')
    if check_0 == '/home/nicola/cookiecutter' + '/{{project_name}}':
        print('Test passed')
    else:
        print('Test failed')

test_case_0()
test_find_template()

# Generated at 2022-06-25 15:25:42.998320
# Unit test for function find_template
def test_find_template():
    """Function for testing that find_template returns the right value."""

    logging.basicConfig(level=logging.DEBUG)

# Generated at 2022-06-25 15:25:50.139196
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:25:59.285638
# Unit test for function find_template
def test_find_template():
    try:
        find_template(r'..\tests\test-cookiecutters\fake-repo-tmpl\fake-repo-no-cookiecutter-json')
    except NonTemplatedInputDirException:
        bool_0 = True
    except Exception as e:
        print(e)
    assert bool_0 == True
    try:
        find_template(r'..\tests\test-cookiecutters\fake-repo-tmpl\fake-repo-with-cookiecutterjson')
    except NonTemplatedInputDirException:
        bool_1 = False
    except Exception as e:
        print(e)
    assert bool_1 == False

if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:26:01.141308
# Unit test for function find_template
def test_find_template():
    # Case 0: Default case
    print("Running test_find_template()")
    repo_dir = "../tmp"
    project_template = find_template(repo_dir)
    if "{{cookiecutter.python_package_name}}" in project_template:
        print("Case 0: Passed")
    else:
        print("Case 0: Failed")

# Call unit tests
test_find_template()

# Generated at 2022-06-25 15:26:06.902058
# Unit test for function find_template
def test_find_template():
    # Mock inputs
    repo_dir = '../../tests/fake-repo-pre/'

    # Mock outputs
    project_template = '../../tests/fake-repo-pre/{{cookiecutter.repo_name}}/'

    # Run test
    assert find_template(repo_dir) == project_template


if __name__ == '__main__':
    test_case_0()
    # test_find_template()

# Generated at 2022-06-25 15:26:09.066579
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:15.320471
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/fake-repo-pre/'

    result = find_template(repo_dir)
    assert result == './tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    repo_dir = './tests/fake-repo-post/'
    result = find_template(repo_dir)
    assert result == './tests/fake-repo-post/{{cookiecutter.repo_name}}_dir'

# Tests for function generate_files()

# Generated at 2022-06-25 15:26:21.971719
# Unit test for function find_template
def test_find_template():
    cookiecutter_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'resources',
        'tests',
        'test-case-0'
    )
    try:
        project_template = find_template(cookiecutter_dir)
        assert project_template == os.path.join(cookiecutter_dir, '{{cookiecutter.repo_name}}')
    except NonTemplatedInputDirException:
        assert False

# Generated at 2022-06-25 15:26:27.922771
# Unit test for function find_template
def test_find_template():
    repo_dir = os.getcwd() + "/cookiecutter-pypackage/"
    package_template = find_template(repo_dir)
    expected_package_template = os.getcwd() + "/cookiecutter-pypackage/{{cookiecutter.repo_name}}/"
    assert package_template == expected_package_template

# Generated at 2022-06-25 15:26:30.380472
# Unit test for function find_template
def test_find_template():
    repo_dir = '../'
    find_template(repo_dir)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:31.716146
# Unit test for function find_template
def test_find_template():
    bool_1 = True
    assert bool_1 == bool_0

# Generated at 2022-06-25 15:26:47.801889
# Unit test for function find_template
def test_find_template():
    from subprocess import Popen, PIPE

    p = Popen("git clone https://github.com/pytest-dev/pytest.git", shell=True, stdout=PIPE, stderr=PIPE)
    output, err = p.communicate()
    rc = p.returncode
    template = find_template("pytest")
    assert template == "pytest/pytest"



# Generated at 2022-06-25 15:26:48.547536
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:26:50.592193
# Unit test for function find_template
def test_find_template():

    os.chdir("test/test-project")

    assert find_template("../test-project") == "test-project/{{cookiecutter.project_name}}"



# Generated at 2022-06-25 15:27:00.779097
# Unit test for function find_template
def test_find_template():
    blank_repo_dir = "cookiecutter.tests/test_repo/"
    test_project_template = "cookiecutter.tests/test_repo/cookiecutter-pypackage"
    test_template = find_template(blank_repo_dir)
    if test_template == test_project_template:
        print("Running test for find_template: Passed")
    else:
        print("Running test for find_template: Failed")
        print("Expected: ", test_project_template)
        print("Actual: ", test_template)

test_find_template()

# Generated at 2022-06-25 15:27:02.611018
# Unit test for function find_template
def test_find_template():
    bool_0 = True



# Generated at 2022-06-25 15:27:07.174220
# Unit test for function find_template
def test_find_template():
    if os.path.exists('test_dir') == False:
        os.mkdir('test_dir')
    os.system('touch test_dir/cookiecutter-{{cookiecutter.project_name}}')
    project_template = find_template('test_dir')
    assert project_template != None, "Test for function find_template failed"
    os.system('rm -rf test_dir')

# Generated at 2022-06-25 15:27:09.210806
# Unit test for function find_template
def test_find_template():
    template_path = 'test_repo'
    assert find_template(template_path) == 'test_repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:27:13.403165
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/test-cookiecutter-repo/{{cookiecutter.project_slug}}'
    assert find_template(repo_dir) == './tests/test-cookiecutter-repo/python_boilerplate'

# Check if it raises the exception if there is no template

# Generated at 2022-06-25 15:27:18.306711
# Unit test for function find_template
def test_find_template():
    try:
        find_template(".")
    except NonTemplatedInputDirException:
        print("test_find_template() --> passed!")
    else:
        print("test_find_template() --> failed!")


# Generated at 2022-06-25 15:27:22.970024
# Unit test for function find_template
def test_find_template():
    path_0 = '/home/nhatanh/Cookiecutter/cookiecutter-pytest-plugin/tests/test_find_template/case_0/fake-repo'
    result = find_template(path_0)
    assert result == '/home/nhatanh/Cookiecutter/cookiecutter-pytest-plugin/tests/test_find_template/case_0/fake-repo/{{cookiecutter.project_name}}'


# Generated at 2022-06-25 15:27:53.151072
# Unit test for function find_template
def test_find_template():
    # test example from test_case_1_template
    # https://github.com/audreyr/cookiecutter-pypackage
    repo_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'tests/fake-repo-pre/')
    actual = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert actual==expected, 'find_template function failed'
    print("find template test passed")

# Generated at 2022-06-25 15:27:55.947200
# Unit test for function find_template
def test_find_template():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 15:28:01.700903
# Unit test for function find_template
def test_find_template():
    # Create a temporary directory to simulate the project.
    test_project_dir = os.path.abspath('tests/test-project-dir')
    test_project_template_dir = os.path.join(
        test_project_dir, '{{cookiecutter.project_name}}'
    )
    test_project_template_file = os.path.join(
        test_project_template_dir, 'e'
    )

    project_template = find_template(test_project_dir)
    assert os.path.abspath(project_template) == test_project_template_dir
    os.remove(test_project_template_file)
    os.remove(test_project_template_dir)
    os.rmdir(test_project_dir)

# Generated at 2022-06-25 15:28:05.018102
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'files', 'test-template')
    actual = find_template(repo_dir)
    expected = os.path.join(repo_dir, 'cookiecutter-pypackage', '{{cookiecutter.github_project_name}}')
    assert actual == expected

# Generated at 2022-06-25 15:28:12.449933
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    # If a success is found
    # bool_0 = bool(os.path.isfile(find_template('')))
    # Assert bool_0 == True
    # if a NonTemplatedInputDirException is found
    #bool_0 = bool(os.listdir(find_template))
    #Assert bool_0 == False

# Generated at 2022-06-25 15:28:20.508642
# Unit test for function find_template
def test_find_template():
    dir = "../../tests/fake-repo-tmpl/{{cookiecutter.repo_name}}"
    assert os.path.exists(dir), "dir should exist"
    #assert finds_template(dir) is None, "dir should have no cookiecutter templates"


if __name__ == '__main__':
    #test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:28:25.560229
# Unit test for function find_template
def test_find_template():
    doctest.run_docstring_examples(find_template, globals())


# Generated at 2022-06-25 15:28:30.483692
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/celyes/Documents/projects/ZED/python-cookiecutter/tests/fake-repo-pre/{{cookiecutter.repo_name}}/'
    assert find_template(repo_dir) == '/Users/celyes/Documents/projects/ZED/python-cookiecutter/tests/fake-repo-pre/{{cookiecutter.repo_name}}/cookiecutter-pypackage'


# Generated at 2022-06-25 15:28:37.997974
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.path.dirname(__file__), 'config_files', 'test_dir')
    assert find_template(test_dir) == os.path.join(test_dir, '{{cookiecutter.project_name}}')

    test_dir = os.path.join(os.path.dirname(__file__), 'config_files', 'test_dir_no_template')
    try:
        find_template(test_dir)
        assert False
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-25 15:28:47.317567
# Unit test for function find_template
def test_find_template():
    folder_name = 'repo_dir'
    os.makedirs(folder_name)
    with open(folder_name + '/' + 'cookiecutter' + '{{cookiecutter.project_name}}' + '.txt', 'w') as f:
        pass
    assert(find_template(folder_name) == os.path.abspath(folder_name + '/' + 'cookiecutter' + '{{cookiecutter.project_name}}' + '.txt'))
    os.remove(folder_name + '/' + 'cookiecutter' + '{{cookiecutter.project_name}}' + '.txt')
    os.rmdir(folder_name)

# Generated at 2022-06-25 15:29:18.810875
# Unit test for function find_template
def test_find_template():
    path = 'C:\work\python\cookiecutter-django-project\cookiecutter-django-project'
    assert find_template(path)=='C:\work\python\cookiecutter-django-project\cookiecutter-django-project\cookiecutter-django-project'

# Generated at 2022-06-25 15:29:24.586953
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/kevin.wang/Desktop/Cookiecutter_2018'
    template_name = find_template(repo_dir)
    assert template_name == '/Users/kevin.wang/Desktop/Cookiecutter_2018/cookiecutter-{{ cookiecutter.domain_name }}', 'correct template name'


if __name__ == '__main__':
    test_find_template()
    test_case_0()

# Generated at 2022-06-25 15:29:31.123694
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/laurent.mazzone/Work/cookiecutter-retrofit') == '/Users/laurent.mazzone/Work/cookiecutter-retrofit/{{cookiecutter.project_slug}}'


# Generated at 2022-06-25 15:29:31.912305
# Unit test for function find_template
def test_find_template():
    test_case_0()
    pass

# Generated at 2022-06-25 15:29:36.810682
# Unit test for function find_template
def test_find_template():
    # Firstly, create a directory and a sub-directory which will be used to test the 'find_template' function later
    
    # Create a directory
    dir_name = "test_dir"
    try:
        os.mkdir(dir_name)
    except OSError:
        print("Creation of the directory %s failed" % dir_name)
    else:
        print("Successfully created the directory %s" % dir_name)

    # Create a sub-directory
    sub_dir_name = "test_sub_dir"
    try:
        os.mkdir(dir_name + '/' + sub_dir_name)
    except OSError:
        print("Creation of the sub-directory %s failed" % sub_dir_name)

# Generated at 2022-06-25 15:29:39.218764
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == "tests/fake-repo-pre/{{cookiecutter.repo_name}}"
    test_case_0()


# Generated at 2022-06-25 15:29:40.377415
# Unit test for function find_template
def test_find_template():
    find_template("Cookiecutter-pypackage/")

# Temp unit test for function test_case_0

# Generated at 2022-06-25 15:29:43.996546
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/zoran/Desktop/university/My_bachelor_and_master/courses/' \
            '0_bachelor/Bachelor_studies_first_semester/Ostrovski/1st_year/' \
            'MO-P3-2020-A-17-15/OA/cookiecutter-django/cookiecutter'
    project_template = find_template(repo_dir)
    result = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    assert result == project_template

# Generated at 2022-06-25 15:29:47.683205
# Unit test for function find_template
def test_find_template():
    template = 0
    template = find_template(os.path.join('test', 'test_files', 'test_find_template'))
    assert template


# Generated at 2022-06-25 15:29:58.171333
# Unit test for function find_template
def test_find_template():
    # Create a fake repo dir
    repo_dir = '/tmp/fake_repo/'
    os.mkdir(repo_dir)
    # Create another fake directory
    os.mkdir(os.path.join(repo_dir, 'fake_dir'))
    # Create a fake project_template
    proj_template = os.path.join(repo_dir, 'fake_project_template_{{cookiecutter.repo_name}}')
    open(proj_template, 'a').close()

    # Test the function
    test_proj_template = find_template(repo_dir)

    assert test_proj_template == proj_template, 'There is no project template found in the repo dir'

    # Remove fake repo dir
    #os.remove(proj_template)
    #shutil

# Generated at 2022-06-25 15:31:06.535163
# Unit test for function find_template
def test_find_template():
    # Dummy object to represent a directory
    class DummyDir:
        def __init__(self, dir_name):
            self.provided_path = dir_name
            self.contains_cookiecutter = False
            self.contains_l_brackets = False
            self.contains_r_brackets = False
            self.all_checks_pass = False

    # Test find_template with provided directory
    dir_obj_0 = DummyDir('/Dummy/Path/To/Template/directory')
    if find_template.find_template(dir_obj_0.provided_path):
        test_case_0()
    else:
        print("Test case 0 failed: Expected True, received False")
        print("find_template function's input directory was: " + dir_obj_0.provided_path)



# Generated at 2022-06-25 15:31:10.664225
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/jingyang/Desktop/cookiecutter'
    project_template = find_template(repo_dir)
    assert (os.path.basename(project_template) == 'cookiecutter-pypackage')

# Generated at 2022-06-25 15:31:11.512789
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-25 15:31:12.562033
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-templated')


# Generated at 2022-06-25 15:31:16.179297
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_project_repo'
    )
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    os.chdir(repo_dir)
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-25 15:31:21.538885
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\\Users\\t-kitta1\\Desktop') ==  'C:\\Users\\t-kitta1\\Desktop\\cookiecutter-django{{cookiecutter.project_name}}','find_template() returns the wrong value'

# Test data for test_case_1

issue_id = '{{cookiecutter.issue_id}}'


# Generated at 2022-06-25 15:31:29.614130
# Unit test for function find_template
def test_find_template():
    '''
    Test 1:  Check that returned path is project template
        (if true, passes test)
    '''

# Generated at 2022-06-25 15:31:40.525245
# Unit test for function find_template
def test_find_template():
    import pytest
    import shutil
    import tempfile
    import os.path as op

    def _create_repo(template_path, in_repo_dir=False):
        repo_dir = tempfile.mkdtemp()

        if in_repo_dir:
            template_dir = repo_dir
        else:
            template_dir = tempfile.mkdtemp()

        repo_dir = op.join(template_dir, 'test_repo')
        os.mkdir(repo_dir)
        shutil.copytree(template_path, op.join(repo_dir, 'cookiecutter-foobar'))

        return repo_dir


# Generated at 2022-06-25 15:31:42.814123
# Unit test for function find_template
def test_find_template():
    repo_dir = 'C:\\Users\\v-birhan\\Documents\GitHub\\cookiecutter-pyvault'
    project_template = find_template(repo_dir)
    assert project_template=='C:\\Users\\v-birhan\\Documents\GitHub\\cookiecutter-pyvault\\cookiecutter-pyvault'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:31:47.254796
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('/home/saumya/projects/test_projects/test_project')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    logger.debug('Testing function find_template')
    assert(find_template(repo_dir) == '/home/saumya/projects/test_projects/test_project/cookiecutter-pypackage-2019')
    