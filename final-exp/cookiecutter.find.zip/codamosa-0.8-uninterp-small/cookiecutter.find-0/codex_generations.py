

# Generated at 2022-06-25 15:22:03.952320
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == "input_dir_path"

# Generated at 2022-06-25 15:22:05.821406
# Unit test for function find_template
def test_find_template():
    filename = 'test_filename'
    assert find_template(filename) == 'test_filename'


# Generated at 2022-06-25 15:22:11.306028
# Unit test for function find_template
def test_find_template():
    """Function to test find_template() - currently only tests the exception
    """
    try:
        find_template(1)
    except NonTemplatedInputDirException as e:
        logger.debug(e)
    except Exception as e:
        logger.debug(e)
        assert False

    assert True

# Generated at 2022-06-25 15:22:17.691700
# Unit test for function find_template
def test_find_template():
    # Case 0
    try:
        test_case_0()
    except TypeError:
        pass
    # Case 1
    return_value_1 = find_template(r'D:\git\cookiecutter-pytest-plugin\tests\test_dir\dir_0')
    if return_value_1 != r'D:\git\cookiecutter-pytest-plugin\tests\test_dir\dir_0\cookiecutter-{{project_name}}':
        print('Test for \'find_template\' failed.')


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:22:26.569591
# Unit test for function find_template
def test_find_template():
    # test for correct value
    assert find_template('./') == './cookiecutter-pypackage'

    # test for empty string
    assert find_template('') == './cookiecutter-pypackage'

    # test for number
    try:
        test_case_0()
    except Exception as e:
        if type(e).__name__ == 'NonTemplatedInputDirException':
            assert True
        else:
            assert False

    # test for None
    try:
        find_template(None)
    except Exception as e:
        if type(e).__name__ == 'NonTemplatedInputDirException':
            assert True
        else:
            assert False

# Generated at 2022-06-25 15:22:28.273784
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:30.021274
# Unit test for function find_template
def test_find_template():
    assert find_template('/tmp') == '/tmp/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:22:42.044745
# Unit test for function find_template
def test_find_template():
    """
    Check if test works under normal condition
    """
    # Create a temporary folder
    import tempfile 
    import shutil 
    cwd = os.getcwd() 
    tmp_dir = tempfile.mkdtemp() 
    os.chdir(tmp_dir) 
    # Create a cookiecutter.json in the temporary folder
    with open('cookiecutter.json', 'w') as f: 
        f.write('''{
    "cookiecutter": "cookiecutter-pypackage"
}''')
    # Run find_template
    find_template(tmp_dir) 
    # Remove temporary folder
    shutil.rmtree(tmp_dir) 
    os.chdir(cwd) 


# Generated at 2022-06-25 15:22:43.435047
# Unit test for function find_template
def test_find_template():
    assert find_template("repo_dir") == "repo_dir"


# Generated at 2022-06-25 15:22:44.657925
# Unit test for function find_template
def test_find_template():
    try:
        find_template(1)
    except:
        assert True


# Generated at 2022-06-25 15:22:50.829518
# Unit test for function find_template
def test_find_template():
    # if directory is a file
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()
    # if the template is not found
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()

# Generated at 2022-06-25 15:22:54.564467
# Unit test for function find_template
def test_find_template():
    int_0 = 1
    var_0 = find_template(int_0)
    try:
        assert var_0 == 1
    except AssertionError:
        raise AssertionError("Assertion not true")
    print("great, test case passed successfully")

test_case_0()

# Generated at 2022-06-25 15:22:56.390040
# Unit test for function find_template
def test_find_template():
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()

# Generated at 2022-06-25 15:23:00.641297
# Unit test for function find_template
def test_find_template():
    assert find_template('') == None

# Generated at 2022-06-25 15:23:11.321693
# Unit test for function find_template
def test_find_template():
    result_tuple = find_template("test_input/repo")
    assert result_tuple == None
    result_tuple = find_template("test_input/repo1")
    assert result_tuple == None
    result_tuple = find_template("test_input/repo2")
    assert result_tuple == None
    result_tuple = find_template("test_input/repo3")
    assert result_tuple == "test_input/repo3/{{cookiecutter.directory_name}}"
    result_tuple = find_template("test_input/repo4")
    assert result_tuple == "test_input/repo4/{{cookiecutter.directory_name}}"
    result_tuple = find_template("test_input/repo5")
    assert result_t

# Generated at 2022-06-25 15:23:14.733292
# Unit test for function find_template
def test_find_template():
    assert find_template('../test') == "test/test_project_{{cookiecutter.repo_name}}"

# Generated at 2022-06-25 15:23:22.612452
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    import sys
    import os
    import pytest
    import logging
    import tempfile
    import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter import find

    logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    # Preparing test data
    test_dir  = os.path.dirname(os.path.abspath(__file__))
    data_dir  = os.path.join(test_dir, 'data')

# Generated at 2022-06-25 15:23:25.227246
# Unit test for function find_template
def test_find_template():
    template = find_template('tests/test-repo-pre/')
    assert template == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:23:27.661167
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\\Users\\Shivam\\Desktop\\Code\\Software-Engineering-1\\project_1\\cookiecutter-pypackage') == True


# Generated at 2022-06-25 15:23:30.793551
# Unit test for function find_template
def test_find_template():
    assert find_template() == 'fe0e9763695c4e5d5a5b2d5c5e5e5f5f5a5b5c5d5e5f5a5b'


# Generated at 2022-06-25 15:23:37.843363
# Unit test for function find_template
def test_find_template():
    try:
        find_template()
    except NonTemplatedInputDirException as e:
        print(e)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:45.734052
# Unit test for function find_template
def test_find_template():
    """Check that find_template correctly finds the right directory."""
    # Unit test for function find_template
    expected = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            'fixtures',
            'cookiecutter-pypackage'
        )
    )
    actual = os.path.abspath(
        os.path.realpath(
            find_template(
                repo_dir=os.path.join(
                    os.path.dirname(__file__),
                    'fixtures',
                    'find-template'
                )
            )
        )
    )
    assert expected == actual

# Generated at 2022-06-25 15:23:47.331073
# Unit test for function find_template
def test_find_template():
    assert '{{ project_name }}' in find_template("TESTTESTTEST")


# Generated at 2022-06-25 15:23:48.193455
# Unit test for function find_template
def test_find_template():
    var_0 = find_template()
    assert None

# Generated at 2022-06-25 15:23:52.785678
# Unit test for function find_template
def test_find_template():
    """Basic functional testing of the find_template function.
    """
    # Set up args and kwargs
    repo_dir = "/Users/jonathangraham/Projects/Cookiecutter/cookiecutter-pypackage/"



# Generated at 2022-06-25 15:23:56.210159
# Unit test for function find_template
def test_find_template():
    repo_dir = 'home/user'
    project_template = 'project_template'
    def mock_listdir(path):
        return [project_template]

    os.listdir = mock_listdir

    assert find_template(repo_dir) == f"{repo_dir}/{project_template}"

# Generated at 2022-06-25 15:23:57.030338
# Unit test for function find_template
def test_find_template():
    assert var_0 == 'foo'

# Generated at 2022-06-25 15:23:59.362269
# Unit test for function find_template
def test_find_template():
    assert find_template("/home/noor/Projects/cookiecutter-django-fido") == "/home/noor/Projects/cookiecutter-django-fido"

# Generated at 2022-06-25 15:24:01.250589
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == 'foo'


if __name__ == '__main__':
    find_template()

# Generated at 2022-06-25 15:24:05.394931
# Unit test for function find_template
def test_find_template():
    """
    >>> find_template(repo_dir="D:/Work/Projects/cookiecutter/newrepo")
    'D:/Work/Projects/cookiecutter/newrepo/{{cookiecutter.repo_name}}'
    """

# Generated at 2022-06-25 15:24:14.213478
# Unit test for function find_template
def test_find_template():
    if not isinstance(find_template((lambda x,y: x * y)), str) and find_template((lambda x: x * x)) != True and find_template((lambda x: x * x)) != False and find_template((lambda x: x * x)) != None:
        return False

    return True

print(test_find_template())

# Generated at 2022-06-25 15:24:16.366102
# Unit test for function find_template
def test_find_template():
    try:
        find_template()
        assert False
    except TypeError:
        assert True


# Unit test find_template()

# Generated at 2022-06-25 15:24:27.336071
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None
    assert find_template('/Users/johndoe/documents/cookiecutter/cookiecutter/tests/cookiecutters/fake-repo-pre/') == '/Users/johndoe/documents/cookiecutter/cookiecutter/tests/cookiecutters/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('/Users/johndoe/documents/cookiecutter/cookiecutter/tests/cookiecutters/fake-repo-post/') == '/Users/johndoe/documents/cookiecutter/cookiecutter/tests/cookiecutters/fake-repo-pre/{{cookiecutter.repo_name}}'

# test_find_template()

# Generated at 2022-06-25 15:24:28.602043
# Unit test for function find_template
def test_find_template():
     cwd = os.getcwd()
     test_case_0(cwd)

# Generated at 2022-06-25 15:24:31.196433
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template('test_case_0')
    except:
        pass

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:34.199468
# Unit test for function find_template
def test_find_template():
    os.chdir('examples')
    tuple_0 = 'cookiecutter-pypackage'
    expected_0 = None
    actual_0 = find_template(tuple_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 15:24:35.396279
# Unit test for function find_template
def test_find_template():
    tuple_0 = None
    var_0 = find_template(tuple_0)

# Generated at 2022-06-25 15:24:36.866637
# Unit test for function find_template
def test_find_template():
    tuple_0 = None
    var_0 = find_template(tuple_0)


# Generated at 2022-06-25 15:24:42.911566
# Unit test for function find_template
def test_find_template():
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-25 15:24:50.562540
# Unit test for function find_template
def test_find_template():
    # Sample input of path to local repo, and sample output of corresponding project template
    tuple_0 = "/Users/rob/projects/cookiecutter-pypackage"
    expected_output_0 = "/Users/rob/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}"
    var_0 = find_template(tuple_0)
    assert var_0 == expected_output_0

if __name__ == '__main__':
    # Unit test for function find_template
    test_find_template()

# Generated at 2022-06-25 15:25:02.551263
# Unit test for function find_template
def test_find_template():
    import cookiecutter
    import cookiecutter.main
    import inspect
    import shutil
    import tempfile
    import os
    import os.path

    source_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    test_dir = tempfile.mkdtemp()

    try:
        shutil.copytree(os.path.join(source_dir, 'cookiecutter-source-dir'), test_dir)
        cookiecutter.main.cookiecutter(test_dir)
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-25 15:25:08.363272
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    faketemplate = '{{cookiecutter.username}}/{{cookiecutter.repo_name}}'

    # Invoke the entry point main() to create a fake project from a fake
    # template in fakehome
    with main.work_in(os.path.expanduser('~')):
        main.cookiecutter('tests/fake-repo-tmpl', no_input=True)
    actual_dir = os.path.join(
        os.path.expanduser('~'),
        faketemplate.format(cookiecutter={
            'username': 'audreyr',
            'repo_name': 'fake-repo',
        }),
    )


# Generated at 2022-06-25 15:25:09.758592
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:25:10.407234
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None



# Generated at 2022-06-25 15:25:13.782890
# Unit test for function find_template
def test_find_template():
    test_cases = [0]
    for case in test_cases:
        eval("test_case_%d()" % case)

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:25:14.345033
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None

# Generated at 2022-06-25 15:25:23.798280
# Unit test for function find_template
def test_find_template():
    template_path = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'test_data', 'global_config',
        'cookiecutter-pypackage-python3', '{{cookiecutter.project_slug}}'
    ))
    assert find_template(os.path.dirname(template_path)) == template_path

# Generated at 2022-06-25 15:25:24.570215
# Unit test for function find_template
def test_find_template():
    assert find_template((None)) == None

# Generated at 2022-06-25 15:25:27.270160
# Unit test for function find_template
def test_find_template():
    assert find_template("cookiecutter-pypackage") == "cookiecutter-pypackage"

# Generated at 2022-06-25 15:25:30.247807
# Unit test for function find_template
def test_find_template():
    unit_test_0 = os.getcwd()
    assert type(find_template(unit_test_0)) == str
    return True

# Generated at 2022-06-25 15:25:41.842450
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter

    # Test with a simple repo
    output_dir = cookiecutter('tests/test-find-template-repo', no_input=True)
    expected = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template-repo')

    # Remove trailing slash to make comparison work in all OSes
    assert output_dir.rstrip(os.path.sep) == expected.rstrip(os.path.sep)

    # Test with a template dir inside a subdir.
    output_dir = cookiecutter(
        'tests/test-find-template-subdir/my-awesome-project',
        no_input=True)

# Generated at 2022-06-25 15:25:44.379672
# Unit test for function find_template
def test_find_template():

    # Setup test values

    # Invoke function
    result = find_template()

    # Verify the result
    assert result == expected

# Generated at 2022-06-25 15:25:46.384515
# Unit test for function find_template
def test_find_template():
    tuple_0 = None
    var_0 = find_template(tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:25:52.813560
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.normcase('tests/test-repo/hooks')) == os.path.normcase('tests/test-repo/hooks/{{cookiecutter.repo_name}}')
    assert find_template(os.path.normcase('tests/test-repo/fake')) == os.path.normcase('tests/test-repo/fake/{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:26:02.604674
# Unit test for function find_template
def test_find_template():
    assert find_template("C:/Users/gavin.milotta/Desktop/cookiecutter-pypackage") == 'C:/Users/gavin.milotta/Desktop/cookiecutter-pypackage/{{cookiecutter.project_slug}}'
    assert find_template("C:/Users/gavin.milotta/Desktop/cookiecutter-pypackage") != 'C:/Users/gavin.milotta/Desktop/cookiecutter-pypackage'
    assert find_template('C:\\Users\\gavin.milotta\\Desktop\\cookiecutter-pypackage') == 'C:\\Users\\gavin.milotta\\Desktop\\cookiecutter-pypackage\\{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:26:05.236056
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/.cookiecutters') == '/home/vagrant/.cookiecutters/cookiecutter-pypackage/'


# Generated at 2022-06-25 15:26:07.860693
# Unit test for function find_template
def test_find_template():
    try:
        find_template(None)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False

# Generated at 2022-06-25 15:26:10.481530
# Unit test for function find_template
def test_find_template():
    assert test_case_0()[0] == 'cases/test/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:26:15.319781
# Unit test for function find_template
def test_find_template():
    template = find_template(os.path.join(
        os.path.dirname(__file__), '../fake-repo-tmpl'
    ))
    assert template == os.path.join(
        os.path.dirname(__file__), '../fake-repo-tmpl/{{cookiecutter.repo_name}}'
    )


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:26:20.051012
# Unit test for function find_template
def test_find_template():
    repo_dir = "/Users/michaelherman/projects/cookiecutter-pypackage"
    result = find_template(repo_dir)
    assert result == '/Users/michaelherman/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:26:30.516834
# Unit test for function find_template
def test_find_template():
    tuple_0 = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    var_0 = find_template(tuple_0)
    assert var_0 == os.path.join(tuple_0, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:26:32.936794
# Unit test for function find_template
def test_find_template():
    find_template(None)


if __name__ == '__main__':
    import sys
    import nose

    argv = sys.argv[:]
    argv.append('--verbose')
    argv.append('--nocapture')
    nose.main(argv=argv, defaultTest=__file__)

# Generated at 2022-06-25 15:26:45.720499
# Unit test for function find_template
def test_find_template():
    # Test case 0:
    tuple_0 = None
    var_0 = find_template(tuple_0)
    assert var_0 is None

    # Test case 1:
    tuple_1 = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test-cases/test-1/test-1'))
    var_1 = find_template(tuple_1)
    assert var_1 == os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        'test-cases/test-1/test-1/my-cookiecutter-temp'
    ))

    # Test case 2:

# Generated at 2022-06-25 15:26:50.929791
# Unit test for function find_template
def test_find_template():
    assert find_template('/tmp/cookiecutter-10099/vagrant-puphpet') == '/tmp/cookiecutter-10099/vagrant-puphpet'
    assert find_template('/tmp/cookiecutter-10099/django-crud') == '/tmp/cookiecutter-10099/django-crud'
    assert find_template('/tmp/cookiecutter-10099/Python') == '/tmp/cookiecutter-10099/Python'
    assert find_template('/tmp/cookiecutter-10099/python') == '/tmp/cookiecutter-10099/python'



# Generated at 2022-06-25 15:26:56.001711
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/test/testjunk') == '/Users/test/testjunk/{{cookiecutter.repo_name}}-master/{{cookiecutter.repo_name}}'


# Generated at 2022-06-25 15:27:00.362420
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\\Users\\Isaac\\Documents\\GitHub\\cookiecutter-project-template') == 'C:\\Users\\Isaac\\Documents\\GitHub\\cookiecutter-project-template\\{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:27:03.045028
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None


# Generated at 2022-06-25 15:27:06.781530
# Unit test for function find_template
def test_find_template():
    tuple_0 = '/d/eclipse/test_workspace/python-cookiecutter-master/tests/fake-repo-tmpl'
    var_0 = find_template(tuple_0)
    if var_0 != '/d/eclipse/test_workspace/python-cookiecutter-master/tests/fake-repo-tmpl/{{cookiecutter.directory_name}}':
        raise Exception('Unit test failed')


# Generated at 2022-06-25 15:27:11.981040
# Unit test for function find_template
def test_find_template():
    tuple_0 = os.path.join(os.path.dirname(__file__), '../tests/fake-repo-pre/')
    var_0 = find_template(tuple_0)

    assert(var_0 == os.path.join(os.path.dirname(__file__), '../tests/fake-repo-pre/{{cookiecutter.repo_name}}/'))

if __name__ == '__main__':
    print(find_template(os.path.join(os.path.dirname(__file__), '../tests/fake-repo-pre/')))

# Generated at 2022-06-25 15:27:12.788194
# Unit test for function find_template
def test_find_template():
    assert True



# Generated at 2022-06-25 15:27:27.317903
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 15:27:27.866198
# Unit test for function find_template
def test_find_template():
    assert True

# Generated at 2022-06-25 15:27:29.556543
# Unit test for function find_template
def test_find_template():
    assert find_template(tuple_0) is None
    assert find_template(var_0) is None



# Generated at 2022-06-25 15:27:32.812504
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        logger.debug('Test passed.')
    else:
        logger.error('Test failed.')

# Generated at 2022-06-25 15:27:36.947388
# Unit test for function find_template
def test_find_template():
    print("\n*** Testing find_template() ***")
    repo_dir = 'C:\\Users\\Karthik\\Desktop'
    assert find_template(repo_dir)

    try:
        test_case_0()
    except:
        print("Error: find_template()")
        exit()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:27:40.095183
# Unit test for function find_template
def test_find_template():
    print("Test find_template...")
    try:
        # Test case 0
        test_case_0()
    except:
        print("Failed to test find_template")
        return False

    print("Passed find_template!")
    return True

# Test the find_template function (above)
test_find_template()

# Generated at 2022-06-25 15:27:41.414054
# Unit test for function find_template
def test_find_template():
    pass  # TODO: implement your test here



# Generated at 2022-06-25 15:27:47.495717
# Unit test for function find_template
def test_find_template():
    assert find_template("tuple_0") is None
    assert find_template("tuple_1") is None
    assert find_template("tuple_2") is None
    assert find_template("tuple_3") is None
    assert find_template("tuple_4") is None
    assert find_template("tuple_5") is None
    assert find_template("tuple_6") is None
    assert find_template("tuple_7") is None
    assert find_template("tuple_8") is None


# Generated at 2022-06-25 15:27:54.198010
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree

    # Setup a repo to test with
    context = {
        'cookiecutter': {
            'project_name': '{{cookiecutter.project_name}}',
            'project_slug': '{{cookiecutter.project_slug}}',
            'release_date': '{{cookiecutter.release_date}}',
        }
    }

    from cookiecutter.main import cookiecutter

    cookiecutter('tests/test-repo-pre/', no_input=True, extra_context=context)

    # Test finding the template inside with a git repo
    template_dir = find_template('tests/test-repo-pre/')
    assert os.path.isdir(template_dir) is True

    # Teardown

# Generated at 2022-06-25 15:28:03.751332
# Unit test for function find_template

# Generated at 2022-06-25 15:28:30.862805
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:28:32.226885
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)


# Generated at 2022-06-25 15:28:36.113642
# Unit test for function find_template
def test_find_template():
    try:
        tuple_0 = None
        var_0 = find_template(tuple_0)
    except TypeError as error:
        print(error)


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:28:37.464171
# Unit test for function find_template
def test_find_template():
    # Test 0
    tuple_0 = None
    var_0 = find_template(tuple_0)
    assert var_0 is None

# Generated at 2022-06-25 15:28:39.172794
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as e:
        logger.error(e)
        raise e


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:28:46.039029
# Unit test for function find_template
def test_find_template():
    # if __name__ == '__main__':
    #     test_case_0()
    global find_template
    find_template = find_template.__wrapped__

    # Testing with input
    # find_template("<input>")
    try:
        find_template(None)
    except NonTemplatedInputDirException:
        find_template = find_template.__wrapped__

# Generated at 2022-06-25 15:28:47.666844
# Unit test for function find_template
def test_find_template():
    test_case_0()


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:28:48.985094
# Unit test for function find_template
def test_find_template(): 
    assert find_template(None) == NonTemplatedInputDirException

# Generated at 2022-06-25 15:28:52.100385
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import find_template
    template, template_dir = find_template('coo')

    return True


# Generated at 2022-06-25 15:28:57.833905
# Unit test for function find_template
def test_find_template():
    """ Test case for function find_template"""
    # Should throw exception for None input
    test_case_0()

    # Should return the correct project directory for input repo
    tuple_1 = '/home/bobby/repo'
    var_1 = find_template(tuple_1)
    assert var_1 == '/home/bobby/repo/cookiecutter-foobar'

    # Should not return None
    tuple_2 = '/home/bobby'
    var_2 = find_template(tuple_2)
    assert var_2 is not None
    

# Generated at 2022-06-25 15:29:54.907575
# Unit test for function find_template
def test_find_template():
    print('Testing find_template')
    try:
        test_case_0()
    except NonTemplatedInputDirException as e:
        print(e)
    except Exception as e:
        print('Test case failed: ' + str(e))

test_find_template()

# Generated at 2022-06-25 15:29:58.890421
# Unit test for function find_template
def test_find_template():
    assert find_template('Test') is None

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:30:00.502706
# Unit test for function find_template
def test_find_template():
    assert find_template("repo_dir") == "repo_dir/{{cookiecutter.project_name}}"


# Generated at 2022-06-25 15:30:02.066969
# Unit test for function find_template
def test_find_template():
    tuple_1 = None
    var_1 = find_template(tuple_1)
    assert var_1 == None



# Generated at 2022-06-25 15:30:04.359663
# Unit test for function find_template
def test_find_template():
    assert find_template(("var_0",)) == tuple_0

# ------------ Automated Test -----------------

# Test for vars

# Generated at 2022-06-25 15:30:07.015264
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-25 15:30:14.739589
# Unit test for function find_template
def test_find_template():
    # Make the program believe we're in a fresh temporary directory,
    # so the cookiecutter-template directory is the project template.
    os.chdir(os.path.abspath(os.path.dirname(__file__)))

    project_dir = os.path.dirname(os.path.dirname(__file__))
    name_of_template_dir = os.path.basename(project_dir)
    expected_path = os.path.join(project_dir, name_of_template_dir)
    assert find_template(project_dir) == expected_path



# Generated at 2022-06-25 15:30:17.757372
# Unit test for function find_template
def test_find_template():
    assert find_template, "function find_template not found in file"

    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass

    find_template("Text")



# Generated at 2022-06-25 15:30:22.379969
# Unit test for function find_template
def test_find_template():
    assert func_2(tuple_3) == tuple_0
    assert func_2(tuple_1) == tuple_2
    assert func_2(tuple_2) == tuple_1


# Generated at 2022-06-25 15:30:29.779243
# Unit test for function find_template
def test_find_template():
    try:
        os.path.exists(os.getcwd()+'/tests/test-files/test-case-0/')
    except OSError:
        os.mkdir(os.getcwd()+'/tests/test-files/test-case-0/')