

# Generated at 2022-06-25 15:22:03.440289
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)
    # Check if the function is blocking
    with pytest.raises(NonTemplatedInputDirException):
        find_template(None)

# Generated at 2022-06-25 15:22:05.533743
# Unit test for function find_template
def test_find_template():
    float_0 = 1251.87
    # no exception was raised
    assert True


# Generated at 2022-06-25 15:22:09.796377
# Unit test for function find_template
def test_find_template():
    with pytest.raises(TypeError) as pytest_wrapped_e:
        test_case_0()
    assert pytest_wrapped_e.type == TypeError

# Generated at 2022-06-25 15:22:10.876326
# Unit test for function find_template
def test_find_template():
    assert find_template(1251.87)


# Generated at 2022-06-25 15:22:12.278854
# Unit test for function find_template
def test_find_template():
    assert find_template() == 'The project template appears to be %s', project_template

test_find_template()

# Generated at 2022-06-25 15:22:14.906339
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template("C:\foo\bar") == "C:\foo\bar\cookiecutter-cookiecutter"
    except NonTemplatedInputDirException:
        assert False

# Generated at 2022-06-25 15:22:18.234943
# Unit test for function find_template
def test_find_template():
    tmp = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), '..', '..'
    )
    assert find_template(tmp) == os.path.join(tmp, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-25 15:22:21.366327
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:23.827261
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join('tests', 'input', 'template')) == os.path.join('tests', 'input', 'template', '{{cookiecutter.project_name}}')


# Generated at 2022-06-25 15:22:24.999292
# Unit test for function find_template
def test_find_template():
    test_case_0()



# Generated at 2022-06-25 15:22:33.306983
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'templates/fake-repo-tmpl')
    project_template_expected = os.path.join(repo_dir,
                                             '{{cookiecutter.repo_name}}')
    project_template_actual = find_template(repo_dir)

    assert project_template_actual == project_template_expected



# Generated at 2022-06-25 15:22:36.134746
# Unit test for function find_template
def test_find_template():
    # Given
    repo_dir = "/home/iantuttle/PycharmProjects/Cookiecutter/tests/test-data/git-repo"

    # When
    result = find_template(repo_dir)

    # Then
    assert result == "./tests/test-data/git-repo/{{cookiecutter.project_name}}"

# Generated at 2022-06-25 15:22:43.631542
# Unit test for function find_template
def test_find_template():
    test_fixture_0 = os.path.join(
        os.path.dirname(__file__),
        '../',
        'tests/test-templates/test-template'
    )

    test_fixture_1 = os.path.join(
        os.path.dirname(__file__),
        '../',
        'tests/test-templates/test-no-template'
    )

    expected_0 = os.path.join(
        os.path.dirname(__file__),
        '../',
        'tests/test-templates/test-template/cookiecutter.project_name'
    )

    expected_1 = None

    actual_0 = find_template(test_fixture_0)
    actual_1 = find_template(test_fixture_1)

   

# Generated at 2022-06-25 15:22:46.377386
# Unit test for function find_template
def test_find_template():
    try:
        find_template()
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

# Generated at 2022-06-25 15:22:47.259543
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:22:49.586629
# Unit test for function find_template
def test_find_template():
    assert find_template() == 'pass'


# Unit test

# Generated at 2022-06-25 15:22:53.318633
# Unit test for function find_template
def test_find_template():

    # Change the value of this variable to the path of the folder
    # containing the cookiecutter.json file
    repo_dir = r'C:\Users\pkeshari\Documents\CodeBase\cookiecutter-django-crud'

    project_template = find_template(repo_dir)

    assert project_template is not None, 'Test case failed'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:22:58.434277
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    # Change to a testing directory
    os.chdir(test_dir)
    repo_dir = os.path.join(test_dir, "test.project")
    project_template = find_template(repo_dir)
    print(project_template)

if __name__ == '__main__':
    # test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:23:07.278028
# Unit test for function find_template
def test_find_template():
    """
    Test find_template
    """
    templ_dir = os.path.join(os.path.dirname(__file__), 'templates/test-template-0')
    first_file = '0post-doc-mdfile.md'
    assert os.path.basename(find_template(templ_dir)) == '{{cookiecutter.project_slug}}'
    assert os.path.isfile(os.path.join(find_template(templ_dir),'{{cookiecutter.project_slug}}',first_file))

# Generated at 2022-06-25 15:23:10.573916
# Unit test for function find_template
def test_find_template():
    find_template_out = find_template()
    find_template_exp = "<class 'cookiecutter.exceptions.NonTemplatedInputDirException'>"
    assert find_template_out == find_template_exp, 'Expected call did not match actual output'

# Generated at 2022-06-25 15:23:21.395581
# Unit test for function find_template
def test_find_template():
    """Test the function find_template()"""

    # Test basic functionality
    repo_dir = os.path.join('tests', 'fake-repo-pre')
    template_dir = os.path.join('tests', 'fake-repo-pre', 'fake-project')

    res = find_template(repo_dir)

    assert res == template_dir

    # Test non-templated input directory
    repo_dir = os.path.join('tests', 'fake-repo-post')

    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        res = True
    else:
        res = False

    assert res

# Generated at 2022-06-25 15:23:31.111667
# Unit test for function find_template
def test_find_template():
    # Test a template repo dir
    repo_dir = os.path.join(
        os.path.dirname(__file__), os.pardir, 'tests/test-repo'
    )
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == template_dir

    # Test a input_dir
    temp_input_dir = os.path.join(
        os.path.dirname(__file__), os.pardir, 'tests/fake-repo'
    )
    assert find_template(temp_input_dir) == None

    # Test a empty dir

# Generated at 2022-06-25 15:23:36.809546
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('C:/Users/lucas.rocha/Desktop/cookiecutter-pypackage-docker/')
    print(find_template(repo_dir))

# Generated at 2022-06-25 15:23:40.813773
# Unit test for function find_template
def test_find_template():
    """Test case for function 'find_template'."""
    assert find_template('./tests/test-find-repo/') == \
           './tests/test-find-repo/{{cookiecutter.project_name}}'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:49.479912
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree
    from tempfile import mkdtemp
    import os
    import shutil

    test_dir = mkdtemp()
    sample_source = 'tests/test-cases/case-0/source-repo'
    shutil.copytree(sample_source, test_dir)

    expected_dir = 'cookies'
    expected_dir_abs = os.path.join(test_dir, expected_dir)
    assert find_template(test_dir) == expected_dir_abs

    # Test that the function can handle a non-templated input
    test_dir = mkdtemp()
    sample_source = 'tests/test-cases/case-0/non-templated-input'
    shutil.copytree(sample_source, test_dir)


# Generated at 2022-06-25 15:23:52.146922
# Unit test for function find_template
def test_find_template():
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'sample_repo/')
    assert find_template(path) == os.path.join(path, '{{cookiecutter.project_name}}')


# Generated at 2022-06-25 15:23:55.555793
# Unit test for function find_template
def test_find_template():
    """Test for invalid directory."""

    from cookiecutter import find
    from cookiecutter import exceptions

    with pytest.raises(exceptions.NonTemplatedInputDirException):
        find.find_template('./tests/test-invalid-repo-tmpl')



# Generated at 2022-06-25 15:24:03.849975
# Unit test for function find_template
def test_find_template():
    # Given
    repo_dir = os.path.join('.', 'tests', 'files', 'fake-repo')

    # When
    template = find_template(repo_dir)

    # Then
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert template == expected

# Generated at 2022-06-25 15:24:13.998921
# Unit test for function find_template
def test_find_template():
    # Create a folder structure
    structure = {
        'repo_dir': {
            'cookiecutter': {
                '{{cookiecutter.project_name}}': 'templated.txt'
            },
            'non_cookiecutter': {
                'file.txt': None
            }
        }
    }
    # TODO: create test functions for get_project_name, get_template_name
    # Create dummy folder structure
    # os.makedirs('repo_dir/cookiecutter/{{cookiecutter.project_name}}')
    # os.makedirs('repo_dir/non_cookiecutter')

    # Expected result
    expected_results = 'repo_dir/cookiecutter/{{cookiecutter.project_name}}'
    print(expected_results)

    # Get actual

# Generated at 2022-06-25 15:24:14.914471
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:24:25.905755
# Unit test for function find_template
def test_find_template():
    """
    There is no return value, but the test_find_template function
    will raise a NonTemplatedInputDirException if there is a problem
    locating the directory called cookiecutter-hello-{{cookiecutter.repo_name}}
    in the specified test/fixtures/example-repo-tmpl.
    """
    # Typical root directory of a repository containing a cookiecutter template
    repo_dir = 'tests/fixtures/example-repo-tmpl'
    find_template(repo_dir)



# Generated at 2022-06-25 15:24:32.534223
# Unit test for function find_template
def test_find_template():
    # Create object to test against
    test_case_instance = TestCase()

    # Test against each path in paths
    for path in test_case_instance.paths:
        p_dir = os.path.dirname(path)
        if '{{' in path and '}}' in path:
            assert find_template(p_dir) == path
        else:
            try:
                find_template(p_dir)
                raise Exception('Test case that should have failed did not')
            except NonTemplatedInputDirException:
                pass

# Generated at 2022-06-25 15:24:33.171238
# Unit test for function find_template
def test_find_template():
    assert find_template()


# Generated at 2022-06-25 15:24:41.270088
# Unit test for function find_template
def test_find_template():
    import shutil
    # Preparing test
    try:
        shutil.rmtree('Cookiecutter-template/')
    except FileNotFoundError:
        pass


    # Test for the clone_repo function
    # clone_repo()
    # os.chdir('Cookiecutter-template/')
    # os.system('git status')
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # End of test
    # os.chdir('tests/')
    # shutil.rmtree('Cookiecutter-template/')
    # os.chdir('..')
    
    
    
    
    

# Generated at 2022-06-25 15:24:43.070566
# Unit test for function find_template
def test_find_template():
    var_0 = find_template()
    assert var_0 is None

# Generated at 2022-06-25 15:24:47.921481
# Unit test for function find_template
def test_find_template():

    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage'
    assert find_template('{{test}}') == '{{test}}'
    assert find_template('{{tests}}') == '{{tests}}'
    assert find_templa

# Generated at 2022-06-25 15:24:48.491582
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-25 15:24:55.552889
# Unit test for function find_template
def test_find_template():
    # Tests with no optional variables
    assert find_template('/Users/danielchang/Desktop/Cookiecutter-Demo') == '/Users/danielchang/Desktop/Cookiecutter-Demo/cookiecutter-pypackage'
    assert find_template('/Users/danielchang/Desktop/Cookiecutter-Demo') == '/Users/danielchang/Desktop/Cookiecutter-Demo/cookiecutter-pypackage'
    assert find_template('/Users/danielchang/Desktop/Cookiecutter-Demo') == '/Users/danielchang/Desktop/Cookiecutter-Demo/cookiecutter-pypackage'

# Generated at 2022-06-25 15:25:01.663219
# Unit test for function find_template
def test_find_template():
    # Check the absolute path
    repo_dir = os.path.abspath('{{cookiecutter.repo_name}}')

    # call function find_template
    project_template = find_template(repo_dir)

    # check the relative path
    assert project_template == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:25:03.254465
# Unit test for function find_template
def test_find_template():
    assert find_template() == "//Users/wendyie/Documents/GitHub/cookiecutter-django2"

# Generated at 2022-06-25 15:25:11.837600
# Unit test for function find_template
def test_find_template():
    """Test function"""

    # Assert function returns None when given None
    assert find_template(None) is None

    # Assert function returns None when given no arguments
    try:
        find_template()
    except TypeError:
        assert True
    else:
        assert False, "shouldn't reach this point"

# Generated at 2022-06-25 15:25:20.369830
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\Python34\Lib\site-packages\cookiecutter')
    assert find_template('C:\Python34\Lib\site-packages\cookiecutter-django')
    assert find_template('C:\Python34\Lib\site-packages\cookiecutter-django-crud')
    assert find_template('C:\Python34\Lib\site-packages\cookiecutter-pypackage')
    assert find_template('C:\Python34\Lib\site-packages\cookiecutter-pypackage-minimal')
    assert find_template('C:\Python34\Lib\site-packages\cookiecutter-pypackage-skeleton')

# Generated at 2022-06-25 15:25:21.900282
# Unit test for function find_template
def test_find_template():
    assert os.path.exists("G:/cookiecutter-pylibrary/{{cookiecutter.project_name}}")

# Generated at 2022-06-25 15:25:28.424660
# Unit test for function find_template
def test_find_template():
    # First test: non-templated input directory
    if os.path.isdir('{{cookiecutter.project_name}}'):
        os.rmdir('{{cookiecutter.project_name}}')
    os.mkdir('{{cookiecutter.project_name}}')
    try:
        find_template('{{cookiecutter.project_name}}')
        assert False
    except NonTemplatedInputDirException:
        pass
    os.rmdir('{{cookiecutter.project_name}}')
    # Second test: templated input directory
    if os.path.isdir('{{cookiecutter.project_name}}'):
        os.rmdir('{{cookiecutter.project_name}}')
    os.mkdir('{{cookiecutter.project_name}}')

# Generated at 2022-06-25 15:25:29.423466
# Unit test for function find_template
def test_find_template():
    var_0 = None
    var_1 = find_template(var_0)



# Generated at 2022-06-25 15:25:37.733681
# Unit test for function find_template
def test_find_template():
    try:
        var_0 = None
        var_1 = find_template(var_0)
        assert False
    except NonTemplatedInputDirException as e:
        assert True


# TODO: Find a way to use this test, currently doesn't work
# def test_find_template_2():
#     # Unit test for function find_template
#     var_0 = "tests/test-find-template/a"
#     var_1 = find_template(var_0)
#     assert var_1 == 'tests/test-find-template/a/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:25:42.036804
# Unit test for function find_template
def test_find_template():
    print("Test find_template (Expected result: /Users/fraga/Dropbox/dev/cookiecutter-spark-plugin/cookiecutter-spark-plugin-python)")
    print("Running Cookiecutter in the following directory: {}".format(os.path.abspath(os.curdir)))
    p = find_template(".")
    print("Result: {}".format(p))

# Generated at 2022-06-25 15:25:47.969914
# Unit test for function find_template
def test_find_template():
    # check if find_template() returns the correct value when
    # var_0 == 'C:\\Users\\cebra\\OneDrive\\Documents\\GitHub\\cookiecutter-tensorflow-tutorial'
    var_0 = 'C:\\Users\\cebra\\OneDrive\\Documents\\GitHub\\cookiecutter-tensorflow-tutorial'
    var_1 = find_template(var_0)
    assert var_1 == 'C:\\Users\\cebra\\OneDrive\\Documents\\GitHub\\cookiecutter-tensorflow-tutorial\\{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:25:51.198570
# Unit test for function find_template

# Generated at 2022-06-25 15:25:57.635776
# Unit test for function find_template
def test_find_template():
    # Arrange
    repo_dir = os.path.join(os.path.abspath(os.getcwd()), '{{cookiecutter.repo_name}}')

    # Assert
    assert find_template(repo_dir)


# Generated at 2022-06-25 15:26:05.194595
# Unit test for function find_template
def test_find_template():
    var_1 = None
    var_2 = find_template(var_1)



# Generated at 2022-06-25 15:26:08.154911
# Unit test for function find_template

# Generated at 2022-06-25 15:26:09.019844
# Unit test for function find_template
def test_find_template():
    test_case_0()


# Generated at 2022-06-25 15:26:14.931009
# Unit test for function find_template
def test_find_template():
    import os
    import os.path
    import tempfile

    temp_directory = tempfile.mkdtemp()
    template_dir = os.path.join(temp_directory, "cookiecutter-{{cookiecutter.repo_name}}")
    os.mkdir(template_dir)
    try:
        template = find_template(temp_directory)
    finally:
        os.rmdir(template_dir)
        os.rmdir(temp_directory)

    assert template == template_dir

# Generated at 2022-06-25 15:26:16.394181
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None

# Generated at 2022-06-25 15:26:19.348806
# Unit test for function find_template
def test_find_template():

    print("Testing find_template")

    # TODO assert
    test_case_0()


# Functions for scraping Cookiecutter template

# read lines from json file and extract variables

# Generated at 2022-06-25 15:26:21.117322
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/{{cookiecutter.project_slug}}') == 'tests/{{cookiecutter.project_slug}}'

# Generated at 2022-06-25 15:26:23.041600
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == None

# Generated at 2022-06-25 15:26:26.436481
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except Exception as err:
        logger.error('Test case 0 failed.')
        raise err

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:27.923679
# Unit test for function find_template
def test_find_template():
    assert callable(find_template), "Function 'find_template' not defined"

# Generated at 2022-06-25 15:26:42.396089
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir/cookiecutter-{{cookiecutter.project_slug}}'


# Generated at 2022-06-25 15:26:47.021869
# Unit test for function find_template
def test_find_template():
    var_2 = u'C:\\Users\\Jared\\Documents\\GitHub\\cookiecutter-master\\tests\\test-repos\\test-repo'
    var_3 = find_template(var_2)
    assert var_3 == u'C:\\Users\\Jared\\Documents\\GitHub\\cookiecutter-master\\tests\\test-repos\\test-repo\\test-repo-{{ cookiecutter.repo_name }}'

# Generated at 2022-06-25 15:26:50.532554
# Unit test for function find_template
def test_find_template():
    tmp_repo = "./tests/test-find-template/fake-repo"
    project_template = find_template(tmp_repo)
    assert "tests/test-find-template/fake-repo/{{cookiecutter.repo_name}}" in project_template


if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:26:51.412041
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None

# Generated at 2022-06-25 15:26:56.671334
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        assert str(NonTemplatedInputDirException) == 'A project was created without a valid context JSON.'

# Generated at 2022-06-25 15:26:58.211884
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)



# Generated at 2022-06-25 15:27:02.310945
# Unit test for function find_template
def test_find_template():
    assert find_template._test() is None

# Generated at 2022-06-25 15:27:04.528562
# Unit test for function find_template
def test_find_template():
    # Setup
    repo_dir = None
    expected_result = None

    # Exercise
    result = find_template(repo_dir)

    # Verify
    assert result == expected_result

    # Cleanup - none necessary



# Generated at 2022-06-25 15:27:05.920417
# Unit test for function find_template
def test_find_template():
    assert find_template() == None # TODO: update with real test

# Generated at 2022-06-25 15:27:12.769530
# Unit test for function find_template
def test_find_template():
    test_repo_dir = '../../tests/test-input/t0-input-not-a-dir'
    # test_repo_dir = '../../tests/test-input/t1-input-no-cookiecutter-dir'
    # test_repo_dir = '../../tests/test-input/t2-input-cookiecutter-dir-no-vars'
    # test_repo_dir = '../../tests/test-input/t3-input-cookiecutter-dir-wrapped-vars'
    # test_repo_dir = '../../tests/test-input/t4-input-cookiecutter-dir-unwrapped-vars'
    # test_repo_dir = '../../tests/test-input/t5-input-cookiecutter-dirs-

# Generated at 2022-06-25 15:27:40.114125
# Unit test for function find_template
def test_find_template():
    var_0 = None
    var_1 = find_template(var_0)

# -----------------------------------------------------------------------------
# Code below this line is for testing only and should be removed when this
# module is published to PyPI.
# -----------------------------------------------------------------------------

if __name__ == '__main__':
    import sys
    sys.exit(test_case_0())

# Generated at 2022-06-25 15:27:42.003998
# Unit test for function find_template
def test_find_template():
    var_0 = None
    var_1 = find_template(var_0)




# Generated at 2022-06-25 15:27:43.043692
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir=None)

# Generated at 2022-06-25 15:27:45.232517
# Unit test for function find_template
def test_find_template():
    test_case_0()

# logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.DEBUG)
# test_find_template()

# Generated at 2022-06-25 15:27:52.552360
# Unit test for function find_template
def test_find_template():
    from random import random
    from os.path import sep
    from os import path

    tmpl_dir = 'tmp'
    test_dir_base = f'{tmpl_dir}{sep}foo{sep}'
    test_dir_0 = test_dir_base + f'test_dir_{random()}'
    test_dir_1 = test_dir_base + f'test_dir_{random()}'
    test_dir_2 = test_dir_0 + f'{sep}test_dir_{random()}'
    test_dir_3 = test_dir_2 + f'{sep}test_dir_{random()}'
    test_dir_4 = test_dir_3 + f'{sep}test_dir_{random()}'
    test_dir_5 = test_dir_

# Generated at 2022-06-25 15:27:57.117101
# Unit test for function find_template
def test_find_template():
    # TODO: Use requests_mock
    # TODO: Improve var_0
    # TODO: Improve var_1
    var_0 = None
    var_1 = find_template(var_0)

    assert var_1



# Generated at 2022-06-25 15:27:58.907730
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == None


# Generated at 2022-06-25 15:28:02.302152
# Unit test for function find_template
def test_find_template():
    # Set up test case
    test_case = os.listdir('.')
    test_case_expected = '.'

    # Perform test
    test_case_actual = find_template(test_case)

    # Verify test
    assert test_case_actual == test_case_expected

# Generated at 2022-06-25 15:28:03.146133
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:28:05.781977
# Unit test for function find_template
def test_find_template():
    var_0 = './tests/templates'
    var_1 = find_template(var_0)
    assert var_1 == './tests/templates/my-test/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:29:05.247436
# Unit test for function find_template
def test_find_template():
    """Check the find_template function."""
    from .compat import mock, patch

    from .find import find_template

    # Check that a NonTemplatedInputDirException is raised when
    # NonTemplatedInputDirException is raised.

# Generated at 2022-06-25 15:29:09.950782
# Unit test for function find_template
def test_find_template():
    repo_dir = None
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError("Should have raised NonTemplatedInputDirException")

# Generated at 2022-06-25 15:29:16.528822
# Unit test for function find_template
def test_find_template():
    this_repo_path = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre-render'
    )
    template_path = find_template(this_repo_path)
    expected_template_path = os.path.join(
        this_repo_path,
        'fake-project-{{cookiecutter.project_name}}'
    )
    assert template_path == expected_template_path
    return

# Generated at 2022-06-25 15:29:24.029822
# Unit test for function find_template
def test_find_template():
    logger.debug('Testing function find_template')
    var_2 = '{}/tests/test_finders/test_template_repo_template'
    var_2 = var_2.format(os.getcwd())
    var_3 = find_template(var_2)
    logger.debug('Found templated directory: %s', var_3)
    assert(var_3 == '{}/tests/test_finders/test_template_repo_template/template_cookiecutter_project_name'.format(os.getcwd()))

# Generated at 2022-06-25 15:29:31.265730
# Unit test for function find_template
def test_find_template():
    x = '''cmondragon/cookiecutter-ansible-role/{{cookiecutter.repo_name}}'''
    assert find_template(x) == x
    
    #fail case
    x = '''cmondragon/cookiecutter-ansible-role/repo_name'''
    assert find_template(x) == x

# Generated at 2022-06-25 15:29:36.375780
# Unit test for function find_template
def test_find_template():
    var_0 = os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
    var_1 = find_template(var_0)
    assert var_1 == os.path.abspath(os.path.join(os.path.dirname(__file__),'..','{{cookiecutter.repo_name}}'))

# Generated at 2022-06-25 15:29:37.519190
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir/project_template'

# Generated at 2022-06-25 15:29:40.851382
# Unit test for function find_template
def test_find_template():
    assert find_template('./tests/test-template') == './tests/test-template/{{cookiecutter.repo_name}}'
    assert find_template('./samples/cookiecutters') == './samples/cookiecutters/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:29:41.907742
# Unit test for function find_template
def test_find_template():
    assert(test_case_0())

# End of function find_template

# Generated at 2022-06-25 15:29:43.745145
# Unit test for function find_template
def test_find_template():
    test_case_0()
    test_var_0 = None
    try:
        find_template(test_var_0)
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-25 15:31:38.920102
# Unit test for function find_template
def test_find_template():
    var_0 = 'Z:\\github\\personal-repositories\\cookiecutter-pypackage\\{{cookiecutter.project_name}}'
    # var_1 = find_template(var_0)
    test_case_0()


# Generated at 2022-06-25 15:31:43.856948
# Unit test for function find_template
def test_find_template():
    from cookiecutter.find import find_template
    from cookiecutter.find import NonTemplatedInputDirException
    try:
        find_template(
            'C:\\Users\\filip\\AppData\\Local\\Temp\\Cookiecutter-2r73gx0m\\test_hooks-mta0m_ex\\test_hooks')
    except NonTemplatedInputDirException:
        assert(2)

# Generated at 2022-06-25 15:31:46.203302
# Unit test for function find_template
def test_find_template():
    assert find_template("/home/ahelal/git/cookiecutter-pypackage-minimal")



# Generated at 2022-06-25 15:31:47.088463
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == NonTemplatedInputDirException

# Generated at 2022-06-25 15:31:58.416206
# Unit test for function find_template

# Generated at 2022-06-25 15:32:00.774064
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)
    assert isinstance(find_template('abcde'), str)
    assert test_case_0() is None
