

# Generated at 2022-06-25 15:22:05.345834
# Unit test for function find_template
def test_find_template():
    assert find_template('Cookiecutter-pypackage') == 'Cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-25 15:22:08.152065
# Unit test for function find_template
def test_find_template():

    assert test_case_0() == None
    return

# Generated at 2022-06-25 15:22:15.266354
# Unit test for function find_template
def test_find_template():
    bytes_1 = b'\x8b\xb0\xe7\n/b\xd6'
    assert find_template(bytes_1) == "\x8b\xb0\xe7\n/b\xd6"

#def main():
#    bytes_0 = b'\x8b\xb0\xe7\n/b\xd6'
#    assert find_template(bytes_0) == "\x8b\xb0\xe7\n/b\xd6"
#
#    test_case_1()
#    test_case_2()

#if __name__ == "__main__":
#    main()

# Generated at 2022-06-25 15:22:22.264069
# Unit test for function find_template
def test_find_template():
    # Finding file in the root of the directory
    # root_dir = os.path.join(os.path.dirname(__file__), '..')
    path = os.getcwd()
    repo_dir = os.path.join(path, 'test/test_project_dir/test-repo')
    template = find_template(repo_dir)
    assert template == os.path.join(path, 'test/test_project_dir/test-repo/{{cookiecutter.project_name}}')

    # Finding file in a subdirectory of the directory
    # root_dir = os.path.join(os.path.dirname(__file__), '..')
    path = os.getcwd()

# Generated at 2022-06-25 15:22:35.610968
# Unit test for function find_template
def test_find_template():
    # Test return value of 'foo'
    assert find_template('foo') == 'foo'
    # Test return value of bytes_0
    bytes_0 = b'\x8b\xb0\xe7\n/b\xd6'
    assert find_template(bytes_0) == 'foo'
    # Test return value of True
    assert find_template(True) == 'foo'
    # Test return value of False
    assert find_template(False) == 'foo'
    # Test return value of None
    assert find_template(None) == 'foo'
    # Test return value of empty list
    assert find_template([]) == 'foo'
    # Test return value of list of length 1
    assert find_template([1]) == 'foo'
    # Test return value of list of length 2

# Generated at 2022-06-25 15:22:37.525499
# Unit test for function find_template
def test_find_template():
    assert find_template(b'\xdc\x1c') == None


# Generated at 2022-06-25 15:22:41.103139
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join('tests', 'test-tmpl')
    project_template = os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    assert find_template(template_dir) == project_template
    print('test_find_template - ok')

# Generated at 2022-06-25 15:22:51.885638
# Unit test for function find_template
def test_find_template():
    var_0 = find_template(b"")
    assert var_0 == None, "Templates are not found in an empty input"
    var_1 = find_template(b"1")
    assert var_1 == None, "Templates are not found in an input with single character"
    var_2 = find_template(b"12")
    assert var_2 == None, "Templates are not found in an input with double characters"
    var_3 = find_template(b"123")
    assert var_3 == None, "Templates are not found in an input with triple characters"
    var_4 = find_template(b"1234")
    assert var_4 == None, "Templates are not found in an input with quadruple characters"
    var_5 = find_template(b"12345")
    assert var_5

# Generated at 2022-06-25 15:23:00.020170
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils

    repo_dir = 'tests/test-find-repo'
    project_template = 'tests/test-find-repo/tests/test-find-repo/cookiecutter-{{ cookiecutter.repo_name }}'
    assert find_template(repo_dir) == utils.normalize_path(project_template)

    repo_dir = 'tests/test-find-repo2'
    project_template = 'tests/test-find-repo2/tests/test-find-repo2/{{ cookiecutter.repo_name }}'
    assert find_template(repo_dir) == utils.normalize_path(project_template)

    repo_dir = 'tests/test-find-repo3'

# Generated at 2022-06-25 15:23:01.939169
# Unit test for function find_template
def test_find_template():
    bytes_0 = b'\x8b\xb0\xe7\n/b\xd6'
    var_0 = find_template(bytes_0)

# Generated at 2022-06-25 15:23:06.519510
# Unit test for function find_template
def test_find_template():
    # raise Exception("Test not implemented")
    # assert False
    test_case_0()


#
# Helpers
#



# Generated at 2022-06-25 15:23:12.648609
# Unit test for function find_template
def test_find_template():

    # Test 0.0
    with open("./data/templates0.0", "r") as file:
        fileText = file.read()
        fileText = fileText.rstrip()
    repo_dir = bytes(fileText, 'utf8')

    # Test 0.1
    with open("./data/templates0.1", "r") as file:
        fileText = file.read()
        fileText = fileText.rstrip()
    test_0_1 = bytes(fileText, 'utf8')

    # Test 0.2
    with open("./data/templates0.2", "r") as file:
        fileText = file.read()
        fileText = fileText.rstrip()
    test_0_2 = bytes(fileText, 'utf8')

    # Test 0.3

# Generated at 2022-06-25 15:23:16.149697
# Unit test for function find_template
def test_find_template():
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:23:19.538037
# Unit test for function find_template
def test_find_template():
    path = 'tests/files/fake-repo-tmpl'
    cur_path = os.path.abspath(path)

    var_0 = find_template(cur_path)

    assert var_0 == os.path.join(cur_path, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-25 15:23:25.763154
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.utils.paths import create_dir

    template_name = '{{cookiecutter.project_name}}'
    with tempfile.TemporaryDirectory() as repo_dir:
        template_dir = os.path.join(repo_dir, template_name)
        create_dir(template_dir)
        assert find_template(repo_dir) == template_dir, 'Did not find template in dir.'

# Generated at 2022-06-25 15:23:29.692386
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo-pre/'
    project_template = 'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template

# Check that CookiecutterException is raised when template is not detected

# Generated at 2022-06-25 15:23:32.754650
# Unit test for function find_template
def test_find_template():

    repo_path = 'tests/test-repo-pre/'
    project_template = '{{cookiecutter.repo_name}}'

    assert find_template(repo_path) == os.path.join(repo_path, project_template)

# Generated at 2022-06-25 15:23:35.982535
# Unit test for function find_template
def test_find_template():

    # Testing of inputs
    test_case_0()

# Generated at 2022-06-25 15:23:40.255707
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(
        os.path.dirname(__file__), '..', 'cookiecutter-example'
    )
    template_path = find_template(template_dir)
    assert template_path == 'tests/fixtures/cookiecutter-example/{{cookiecutter.repo_name}}', template_path


# Generated at 2022-06-25 15:23:49.180185
# Unit test for function find_template
def test_find_template():
    # Test 0
    bytes_0 = b'\x8b\xb0\xe7\n/b\xd6'
    var_0 = find_template(bytes_0)

    assert var_0 == '\x8b\xb0\xe7\n/b\xd6'

    # Test 1
    bytes_1 = b'\x8b\xb0\xe7n/b\xd6'
    var_1 = find_template(bytes_1)

    assert var_1 == '\x8b\xb0\xe7n/b\xd6'

    # Test 2
    bytes_2 = b'\x8b\xb0\xe7n/b\xd7'
    var_2 = find_template(bytes_2)


# Generated at 2022-06-25 15:23:54.332217
# Unit test for function find_template
def test_find_template():
    os.makedirs('/tmp/test_dir/cookiecutter-{{cookiecutter.project_name}}')
    result = find_template('/tmp/test_dir')
    assert result == '/tmp/test_dir/cookiecutter-{{cookiecutter.project_name}}', "test failed"

# Generated at 2022-06-25 15:23:55.165119
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:24:01.874753
# Unit test for function find_template
def test_find_template():
    repo_dir = 'src/tests'
    project_template = 'src/tests/cookiecutter-{{cookiecutter.project_name}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-25 15:24:04.053496
# Unit test for function find_template

# Generated at 2022-06-25 15:24:06.387879
# Unit test for function find_template
def test_find_template():
    find_template('../')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:18.159447
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/vjukka/Library/Application Support/Sublime Text 2/Packages/Cookiecutter/tests/files'
    project_template = find_template(repo_dir)
    assert os.path.exists('/Users/vjukka/Library/Application Support/Sublime Text 2/Packages/Cookiecutter/tests/files/{{cookiecutter.project_name}}'), 'Searching repo for the project template failed.'
    assert '{{cookiecutter.project_name}}' in project_template, 'Cookiecutter project template should contain the string {{cookiecutter.project_name}}.'

# Generated at 2022-06-25 15:24:23.206842
# Unit test for function find_template
def test_find_template():
    """Find the path of the project template."""
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    assert find_template(repo_dir) == os.path.join(repo_dir, 'fake-repo/{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:24:27.053839
# Unit test for function find_template
def test_find_template():
    '''
    >>> find_template('tests/test-py-repo')
    'tests/test-py-repo/{{cookiecutter.project_name}}'
    '''

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 15:24:36.206608
# Unit test for function find_template
def test_find_template():
    # Input directory is in tests/fixtures/fake-repo-pre/
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..', 'fixtures', 'fake-repo-pre'
    ))
    project_template = find_template(repo_dir)
    # Output should be tests/fixtures/fake-repo-pre/{{cookiecutter.project_name}}
    project_template_expected = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..', 'fixtures', 'fake-repo-pre',
        '{{cookiecutter.project_name}}'
    ))
    assert project_template == project_template_expected

# Generated at 2022-06-25 15:24:42.973591
# Unit test for function find_template
def test_find_template():
    repo_dir_1 = '/home/saurabh/workspace/cookiecutter/tests/fake-repo-pre/'
    template_1 = find_template(repo_dir_1)
    assert template_1 == '/home/saurabh/workspace/cookiecutter/tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    repo_dir_2 = '/home/saurabh/workspace/cookiecutter/tests/fake-repo-pre/subdir/'
    template_2 = find_template(repo_dir_2)
    assert template_2 == '/home/saurabh/workspace/cookiecutter/tests/fake-repo-pre/subdir/{{cookiecutter.repo_name}}'


# Generated at 2022-06-25 15:24:53.798507
# Unit test for function find_template
def test_find_template():
    template_dir_0 = 'cookiecutter-pypackage'
    template_dir_1 = 'cookiecutter-pypackage/{{cookiecutter.project_name}}'
    template_dir_2 = 'cookiecutter-pypackage-{{cookiecutter.py_major_minor_version}}'
    template_dir_3 = 'cookiecutter-pypackage-{{cookiecutter.py_major_minor_version}}/{{cookiecutter.project_name}}'
    assert find_template(template_dir_0) == 'cookiecutter-pypackage'
    assert find_template(template_dir_1) == 'cookiecutter-pypackage/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:25:04.871738
# Unit test for function find_template
def test_find_template():
    # test_case_1
    repo_dir = '/home/user/.cache/cookiecutter/tests/test-repo-pre/{{cookiecutter.project_name}}'
    assert find_template(repo_dir) == '{{cookiecutter.project_name}}'

    # test_case_2
    repo_dir = '/home/user/.cache/cookiecutter/tests/test-repo-pre/{{cookiecutter.project_name}}/other_path'
    assert find_template(repo_dir) == '{{cookiecutter.project_name}}'

    # test_case_3
    repo_dir = '/home/user/.cache/cookiecutter/tests/test-repo-pre'
    assert find_template(repo_dir) == None

# Generated at 2022-06-25 15:25:08.983174
# Unit test for function find_template
def test_find_template():
  repo_dir = '/Users/michaelrho/Dropbox/Python/cookiecutter'
  assert find_template(repo_dir) 
  return

if __name__ == '__main__':
  test_find_template()

# Generated at 2022-06-25 15:25:17.024687
# Unit test for function find_template
def test_find_template():
    tests_dir_path = os.path.dirname(os.path.abspath(__file__))
    tests_templates_dir = os.path.join(tests_dir_path, 'test-templates')
    tests_template_1 = os.path.join(tests_templates_dir, 'test-template-1')

    test_find_template_finds_template_1(tests_template_1)
    test_find_template_fails_on_template_with_no_variables(tests_templates_dir)


# Generated at 2022-06-25 15:25:25.194865
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct value."""
    # Create a temporary directory for testing
    import os
    import tempfile
    test_dir = tempfile.mkdtemp()
    os.chdir(test_dir)

    # Create a test input directory
    test_input_dir = os.path.join(test_dir, 'test_input_dir')
    os.mkdir(test_input_dir)

    # Create a test project template directory
    template_dir_name = 'cookiecutter-{{cookiecutter.project_name}}'
    project_template = os.path.join(test_input_dir, template_dir_name)
    os.mkdir(project_template)

    # Create a test non-project directory

# Generated at 2022-06-25 15:25:33.576681
# Unit test for function find_template
def test_find_template():
    import os
    import cookiecutter

    project_dir = os.path.realpath(os.path.curdir)
    repo_dir = cookiecutter.repo.determine_repo_dir(project_dir)
    find_template(repo_dir)

if __name__ == '__main__':
    print('Calling function test_case_0()...')
    test_case_0()

    print('Calling function test_find_template()...')
    test_find_template()

# Generated at 2022-06-25 15:25:38.342811
# Unit test for function find_template
def test_find_template():
    repo_dir = './../cookiecutter-pypackage/'
    project_template = find_template(repo_dir)
    assert project_template == './../cookiecutter-pypackage/{{cookiecutter.project_slug}}', "Error in find_template()"

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:25:40.912352
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/fake-repo-pre/'
    assert find_template(repo_dir).endswith('tests/fake-repo-pre/{{cookiecutter.repo_name}}')


# Generated at 2022-06-25 15:25:48.705021
# Unit test for function find_template
def test_find_template():
    """Test function find_template

    :returns: None
    """

    # Test Cases
    # Root directory of cookiecutter-pypackage is a project template
    # Test

    return None

# Generated at 2022-06-25 15:25:49.833538
# Unit test for function find_template
def test_find_template():
    assert find_template(str_0) == 'hello'

# Generated at 2022-06-25 15:25:56.128317
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == '.cookiecutter-pypackage'



# Generated at 2022-06-25 15:26:08.280857
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    repo_dir = "c:\work-spaces\cookiecutter-pypackage"
    repo_dir_contents = os.listdir(repo_dir)
    print (repo_dir_contents)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        print (project_template)
        return

# Generated at 2022-06-25 15:26:12.001755
# Unit test for function find_template
def test_find_template():
    repo_dir = 'cookiecutter-example/cookiecutter-{{cookiecutter.project_name}}'
    project_template = find_template(repo_dir)
    print (project_template)
    assert project_template == repo_dir



# Generated at 2022-06-25 15:26:13.812537
# Unit test for function find_template
def test_find_template():
    repo_dir = '.'
    res = find_template(repo_dir)
    print("test result: " + res)


# Generated at 2022-06-25 15:26:21.754940
# Unit test for function find_template
def test_find_template():
    # change directory to the root dir of this project
    os.chdir('../..')
    # get absolute path of current dir
    root_dir = os.getcwd()
    # get absolute path of project template
    template_dir = find_template(root_dir)
    # get absolute path of expected project template
    exp_template_dir = os.path.join(root_dir, '{{cookiecutter.project_name}}')
    # compare the two paths
    assert (template_dir == exp_template_dir)

if __name__ == "__main__":
    # unit test for find_template
    test_find_template()

# Generated at 2022-06-25 15:26:27.451358
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.path.dirname(__file__), 'test_find_template_data')
    os.chdir(test_dir)
    # Create a temporary directory with a subdirectory containing
    # cookiecutter.json
    find_template(test_dir)

# Generated at 2022-06-25 15:26:31.353629
# Unit test for function find_template
def test_find_template():
    path = find_template('/Users/mkennedy/Desktop/计算机科学/工具箱/Python/Python2.7.6.pkg')
    print(path)


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:34.650507
# Unit test for function find_template
def test_find_template():
    return find_template(r"E:\PYTHON_WORK\Cookiecutter\cookiecutter-django-crud\{{cookiecutter.project_name}}")

if __name__ == '__main__':
    print(test_find_template())

# Generated at 2022-06-25 15:26:42.138512
# Unit test for function find_template
def test_find_template():
    # This takes a long time
    # repo_dir = os.path.join(os.getcwd(), 'tests', 'fake-repo-pre')
    # project_template = find_template(repo_dir)
    # assert project_template == os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    assert False

# Generated at 2022-06-25 15:26:46.842578
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.dirname(os.path.dirname(__file__)) + '/cooki_cutter_test/'
    assert (find_template(template_dir) == template_dir + '{{cookiecutter.project_name}}/')


#if __name__ == '__main__':
#    test_find_template()

#if __name__ == '__main__':
#    test_case_0()

# Generated at 2022-06-25 15:27:03.780211
# Unit test for function find_template
def test_find_template():
    tmp_dir = os.path.abspath('/tmp/cookiecutter-test')
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)

    cookiecutter_str = 'cookiecutter'
    project_name_str = 'project_name'
    open_bracket_str = '{{'
    close_bracket_str = '}}'
    template_str = 'template'
    filename = '{0}-{1}-{2}-{3}-{4}'.format(cookiecutter_str,
                                            project_name_str,
                                            open_bracket_str,
                                            close_bracket_str,
                                            template_str)

    template_path = os.path.join(tmp_dir, filename)

# Generated at 2022-06-25 15:27:08.401937
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    proj_templ = find_template(repo_dir)
    assert proj_templ == os.path.abspath('tests/fake-repo-pre/{{cookiecutter.project_name}}')

# Generated at 2022-06-25 15:27:15.946467
# Unit test for function find_template
def test_find_template():
    repo_dir = r'C:\Users\Ryan\Documents\GitHub\cookiecutter-python'
    template = find_template(repo_dir)
    print(template)

if __name__ == '__main__':
    test = 'test_case_0'

    test_dict = {
        'test_case_0': test_case_0,
        'test_find_template': test_find_template,
    }

    test_dict[test]()

# Generated at 2022-06-25 15:27:20.748293
# Unit test for function find_template
def test_find_template():
    #First, check if find_template() return a string
    assert isinstance(find_template('./tests/fake-repo-pre/'), str)
    #Then, check if the return value is the real template path
    assert find_template('./tests/fake-repo-pre/') == './tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:27:30.752343
# Unit test for function find_template

# Generated at 2022-06-25 15:27:33.255892
# Unit test for function find_template
def test_find_template():
    test_dir = '/home/siyu/work/github/cookiecutter/tests/test-find-template'
    assert find_template(test_dir) == '/home/siyu/work/github/cookiecutter/tests/test-find-template/{{cookiecutter.repo_name}}'


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:27:39.052278
# Unit test for function find_template

# Generated at 2022-06-25 15:27:42.858179
# Unit test for function find_template
def test_find_template():
    # repo_dir = './test_repo_dir'
    # result = find_template(repo_dir)
    # print(result)
    str_0 = '{{cookiecutter.project_name}}'
    print(str_0.index('{{'))

# Generated at 2022-06-25 15:27:50.723463
# Unit test for function find_template
def test_find_template():
    listdir_path = '.'
    test_case_0()

    os.listdir = lambda path: []
    path = find_template(listdir_path)
    os.listdir = lambda path: ['{{cookiecutter.project_name}}']
    path = find_template(listdir_path)
    os.listdir = lambda path: ['{{cookiecutter.project_name}}', '.']
    path = find_template(listdir_path)
    os.listdir = lambda path: ['{{cookiecutter.project_name}}', '..']
    path = find_template(listdir_path)
    os.listdir = lambda path: ['{{cookiecutter.project_name}}', '.git']
    path = find_template(listdir_path)

# Generated at 2022-06-25 15:28:01.133265
# Unit test for function find_template
def test_find_template():
    test_context = {
        'cookiecutter': {
            'project_name': 'my-project',
            'project_slug': 'my_project',
            'package_name': 'my_project',
            'author_name': 'Your Name',
            'email': 'you@yourdomain.com',
            'description': 'A short description of the project.',
            'domain_name': 'example.com',
            'version': '0.1.0',
            'timezone': 'UTC',
            'use_pycharm': 'n',
            'use_docker': 'n',
            'open_source_license': 'Not open source',
            'command_line_interface': 'click',
        }
    }


# Generated at 2022-06-25 15:28:21.321432
# Unit test for function find_template
def test_find_template():
    assert find_template(r'/home/evgen/cookiecutter-django') == 'cookiecutter-django/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:28:24.308764
# Unit test for function find_template
def test_find_template():
    str = find_template('../../tests/')
    assert str == '../../tests/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:28:32.590439
# Unit test for function find_template
def test_find_template():
    # Test for case 0: Project template is a directory with no other templates inside
    # If there is only one templated directory, it will be chosen regardless of the name
    os.chdir('/tmp')
    os.system('rm -rf templatedtestrepo')
    os.system('mkdir templatedtestrepo')
    os.chdir('./templatedtestrepo')
    os.system('mkdir test_dir')
    os.chdir('/tmp')
    with open('templatedtestrepo/test_dir/some_file', 'w') as f:
        f.write('test text')
    assert find_template('/tmp/templatedtestrepo') == '/tmp/templatedtestrepo/test_dir'

# Generated at 2022-06-25 15:28:38.217203
# Unit test for function find_template
def test_find_template():
    #test_case_0()
    repo_dir = './test_folder'
    project_template = find_template(repo_dir)
    project_template = os.path.realpath(project_template)
    assert project_template == './test_folder\\{{cookiecutter.project_name}}'
    print('\n test_find_template passed')

# main test

# Generated at 2022-06-25 15:28:43.160845
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    assert find_template(repo_dir) == os.path.join(repo_dir, 'fake-project-tmpl')

# Generated at 2022-06-25 15:28:45.419597
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/nam/Documents/Github/cookiecutter-zappa-django'
    find_template(repo_dir)

# Generated at 2022-06-25 15:28:48.374357
# Unit test for function find_template
def test_find_template():
    repo_dir = os.getcwd() + "/tests"
    repo_dir_contents = os.listdir(repo_dir)
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = os.path.join(repo_dir, item)
            break
    assert(find_template(repo_dir) == project_template)

# Generated at 2022-06-25 15:28:52.611198
# Unit test for function find_template
def test_find_template():
    expected = '/home/vagrant/cookiecutter/cookiecutters/{{cookiecutter.project_name}}/'
    result = find_template('/home/vagrant/cookiecutter/cookiecutters/repo_name/')
    assert expected == result

# Generated at 2022-06-25 15:28:59.525436
# Unit test for function find_template
def test_find_template():
    repo_dir = ''
    logger.debug('Searching %s for the project template.', repo_dir)

    result = find_template(repo_dir)
    assert result

    repo_dir = 'cookiecutter-pypackage'
    logger.debug('Searching %s for the project template.', repo_dir)

    result = find_template(repo_dir)
    assert result



# Generated at 2022-06-25 15:29:07.030527
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'fake-repo-pre')
    project_template = find_template(repo_dir)
    assert project_template == repo_dir + '{{cookiecutter.briefcase_name}}'

# Generated at 2022-06-25 15:29:42.553471
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo', 'input'))
    result = find_template(repo_dir)
    assert result == os.path.join(repo_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-25 15:29:47.760917
# Unit test for function find_template
def test_find_template():
    test_repo_dir = '/home/nikhil/repo/cookiecutter-pypackage-minimal'
    test_template = '/home/nikhil/repo/cookiecutter-pypackage-minimal/{{cookiecutter.project_name}}'

    assert find_template(test_repo_dir) == test_template

# Generated at 2022-06-25 15:29:50.585207
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/shivam/Downloads/kpn_cookiecutter-master')=='/home/shivam/Downloads/kpn_cookiecutter-master/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:29:52.859571
# Unit test for function find_template
def test_find_template():
    find_template('Cookiecutter-Pypackage')

# Generated at 2022-06-25 15:29:55.119313
# Unit test for function find_template
def test_find_template():
    # Test case 0
    str_0 = '{{cookiecutter.project_name}}'
    str_1 = '{{cookiecutter.project_version}}'

# Generated at 2022-06-25 15:29:58.244247
# Unit test for function find_template
def test_find_template():
    if os.path.exists(os.path.join('cookiecutter-pypackage')):
        try:
            find_template('cookiecutter-pypackage')
        except NonTemplatedInputDirException:
            sys.exit(1)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:30:01.143111
# Unit test for function find_template

# Generated at 2022-06-25 15:30:08.439328
# Unit test for function find_template
def test_find_template():
    this_path = os.path.abspath(os.path.dirname(__file__))
    template_path = os.path.join(this_path, 'fake-repo-pre/{{cookiecutter.project_name}}')
    test_case_1()
    test_case_2()
    test_case_3()


# Test case for NonTemplatedInputDirException

# Generated at 2022-06-25 15:30:11.431209
# Unit test for function find_template
def test_find_template():
    result = find_template('/Users/Ricky/Documents/python/cookiecutter-project')
    assert result == '/Users/Ricky/Documents/python/cookiecutter-project/{{cookiecutter.project_name}}'

# Generated at 2022-06-25 15:30:14.146283
# Unit test for function find_template
def test_find_template():
    test_dir = os.getcwd().replace('/tests', '') + '/tests'
    assert find_template(test_dir) == test_dir + '/{{cookiecutter.project_name}}'


# Generated at 2022-06-25 15:31:55.926514
# Unit test for function find_template
def test_find_template():
    # prepare data
    test_cases = [
    {
    'name': '{cookiecutter.project_name}}',
    'output': '{cookiecutter.project_name}}'
    },
    {
    'name': '{{cookiecutter.project_name}}',
    'output': 'test1'
    },
    {
    'name': '{{cookiecutter.project_name}}/{{cookiecutter.project_name}}',
    'output': 'test2'
    },
    ]
    # run test
    for case in test_cases:
        assert find_template(case['name']) == case['output']

# Generated at 2022-06-25 15:31:59.452293
# Unit test for function find_template

# Generated at 2022-06-25 15:32:06.742317
# Unit test for function find_template
def test_find_template():
    # Create a temporary directory
    import os, tempfile
    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'test_template')
    os.mkdir(repo_dir)
    # Create a fake file
    f = open(os.path.join(repo_dir, 'some_file'), 'w')
    f.close()
    # Create a fake template
    template_dir = os.path.join(repo_dir,'{{cookiecutter.project_name}}')
    os.mkdir(template_dir)
    # Call find_template()
    assert find_template(repo_dir) == template_dir
    # Clean up
    import shutil
    shutil.rmtree(temp_dir)