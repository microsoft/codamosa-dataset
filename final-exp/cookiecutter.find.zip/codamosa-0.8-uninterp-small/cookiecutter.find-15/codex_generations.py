

# Generated at 2022-06-25 15:22:05.184647
# Unit test for function find_template
def test_find_template():
    # Make sure the first argument (input directory) is valid
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception("Expected NonTemplatedInputDirException to be raised.")

# Generated at 2022-06-25 15:22:06.207494
# Unit test for function find_template
def test_find_template():
    template = find_template(".git")
    assert template == ".git"

# Generated at 2022-06-25 15:22:10.227187
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
        print('Test Case 0 Passed')
    except Exception:
        print('Test Case 0 Failed')

# Run unit tests
test_find_template()

# Generated at 2022-06-25 15:22:11.518625
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:22:15.672196
# Unit test for function find_template
def test_find_template():
    import unittest
    import sys
    import random

    from tests.test_cookiecutter.test_find_repo import test_case_0

    class TestFindTemplate(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_find_template_class(self):
            self.assertEqual(test_case_0(), None)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-25 15:22:22.508117
# Unit test for function find_template
def test_find_template():
    import sys
    from cookiecutter.main import template_file
    from cookiecutter.main import repo_dir
    from cookiecutter.main import quote

    if sys.version_info.major >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    repo_url = 'https://github.com/alex/cookiecutter-pypackage.git'

    os_devnull = os.devnull
    os.devnull = StringIO
    try:
        template_file = template_file(repo_url)
    except (NonTemplatedInputDirException, TypeError):
        template_file = template_file(repo_url)
    os.devnull = os_devnull

    repo_dir = repo_dir(repo_url)
    test_case_0()

# Generated at 2022-06-25 15:22:35.610300
# Unit test for function find_template
def test_find_template():
    import sys, os
    from random import choice
    from string import ascii_uppercase
    from shutil import rmtree
    import test_cookiecutter_structure as tcs

    # Create a temporary directory
    repo_dir = os.path.join("/home/nate/cookiecutter_repos", ''.join(choice(ascii_uppercase) for i in range(10)))
    os.makedirs(repo_dir)

    # Move into the temporary directory
    saved_path = os.getcwd()
    os.chdir(repo_dir)

    # Create the test repo
    tcs.test_create_repo()

    # Run the function
    find_template(repo_dir)

    # Remove the directory after the test

# Generated at 2022-06-25 15:22:38.093977
# Unit test for function find_template
def test_find_template():
    list_0 = []
    var_0 = find_template(list_0)
    assert var_0 == "list_0"



# Generated at 2022-06-25 15:22:39.422323
# Unit test for function find_template
def test_find_template():
    assert test_case_0() == NonTemplatedInputDirException

# Generated at 2022-06-25 15:22:40.582228
# Unit test for function find_template
def test_find_template():
    list_0 = []
    assert find_template(list_0) == None

# Generated at 2022-06-25 15:22:44.226368
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'


# Generated at 2022-06-25 15:22:51.380108
# Unit test for function find_template
def test_find_template():
    # Case 0
    root_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../tests/')
    project_template = find_template(root_dir + 'fixtures/fake-repo-pre')
    assert project_template == root_dir + 'fixtures/fake-repo-pre/{{cookiecutter.repo_name}}/'


# Generated at 2022-06-25 15:22:55.445873
# Unit test for function find_template
def test_find_template():
    template_dir = '~/dev/cookiecutter-pypackage'
    repo_dir = '/Users/warran/dev/cookiecutter-pypackage-master'
    find_template(repo_dir)

if __name__ == '__main__':
    # test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:22:58.502938
# Unit test for function find_template
def test_find_template():
    path_0 = 'tests/fake-repos/example-cookiecutter-master/'

    template = find_template(path_0)
    assert template == 'tests/fake-repos/example-cookiecutter-master/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:23:05.664801
# Unit test for function find_template
def test_find_template():
    '''
    TODO: try assert
    '''
    repo_dir = './vendors/'

    cookie_dir = find_template(repo_dir)

# Generated at 2022-06-25 15:23:07.632142
# Unit test for function find_template
def test_find_template():
    # Test case 0
    test_case_0()

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:23:09.564848
# Unit test for function find_template
def test_find_template():
    path = find_template('test_cookiecutter/test_input_template')
    assert path == 'test_cookiecutter/test_input_template/cookiecutter-pypackage'

# Generated at 2022-06-25 15:23:17.287499
# Unit test for function find_template
def test_find_template():
    str_0 = '{{ cookiecutter.repo_name }}'
    str_1 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    str_2 = 'cookiecutter-pypackage'
    str_3 = 'cookiecutter_pypackage'

    find_template(str_0)


# Generated at 2022-06-25 15:23:26.210006
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    test_dir = tempfile.mkdtemp()
    try:
        sub_dir = os.path.join(test_dir, 'cookiecutter-foobar')
        os.mkdir(sub_dir)
        template = os.path.join(sub_dir, '{{foo}}-{{bar}}')
        os.mkdir(template)
        try:
            template = find_template(test_dir)
        except NonTemplatedInputDirException:
            assert False
    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-25 15:23:33.275208
# Unit test for function find_template
def test_find_template():
    repo_dir_name = 'cookiecutter-pypackage'
    repo_dir_path = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                 repo_dir_name))
    result = find_template(repo_dir_path)
    assert result == os.path.join(repo_dir_path, '{{cookiecutter.project_name}}')


if __name__ == '__main__':
    # Run unit tests if executed as a main module
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 15:23:42.230450
# Unit test for function find_template
def test_find_template():
    repo_dir = 'test_repo_dir'
    repo_dir_content = ['test_0', 'test_1', 'test_2', 'test_3']
    project_template = 'test_3'
    project_template_full = os.path.join(repo_dir, project_template)
    os.listdir = lambda path: repo_dir_content
    assert find_template(repo_dir) == project_template_full


# Generated at 2022-06-25 15:23:50.542108
# Unit test for function find_template
def test_find_template():
    # first test case
    str_0 = 'https://github.com/alex/cookiecutter-pypackage.git'
    repo_dir = '/tmp/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/tmp/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    # second test case
    str_1 = 'https://github.com/alex/cookiecutter-ipython-notebook.git'
    repo_dir = '/tmp/cookiecutter-ipython-notebook'
    project_template = find_template(repo_dir)
    assert project_template == '/tmp/cookiecutter-ipython-notebook/{{cookiecutter.repo_name}}'


# Generated at 2022-06-25 15:23:56.992474
# Unit test for function find_template
def test_find_template():
    # Test where the repo_dir contains a directory that is a project template.
    repo_dir = 'cookiecutter-pypackage/'
    project_template = find_template(repo_dir)
    assert project_template == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    # Test where the repo_dir does not contain a project template.
    repo_dir = 'tests/fake-repo/'
    try:
        project_template = find_template(repo_dir)
        assert False
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-25 15:24:00.807464
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:09.172111
# Unit test for function find_template
def test_find_template():
    test_case=0
    repo_dir = 'tests/files/fake-repo'
    repo_dir_list = os.listdir(repo_dir)
    project_template = None
    for item in repo_dir_list:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break
    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template
    else:
        raise NonTemplatedInputDirException


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:13.590119
# Unit test for function find_template
def test_find_template():
    str_0 = '/Users/alex/cookiecutter-pypackage'
    find_template(str_0)
    # return True if find_template() works as expected


# Generated at 2022-06-25 15:24:16.770497
# Unit test for function find_template
def test_find_template():
    repo_dir = 'C:\\Users\\luoyany\\AppData\\Local\\Temp\\tmpf0nxlg9v'
    find_template(repo_dir)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:24:27.427442
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/user/cookiecutter_project_template'
    repo_dir_contents = ['a.txt', 'b.txt', 'cookiecutter-pypackage{{xxx}}']
    os.path.join = lambda a, b: os.path.join(a, b)
    os.listdir = lambda a: repo_dir_contents

    project_template = find_template(repo_dir)
    expected_str = '/home/user/cookiecutter_project_template/cookiecutter-pypackage{{xxx}}'
    assert(expected_str == project_template)

if __name__ == '__main__':
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:24:29.121553
# Unit test for function find_template
def test_find_template():
    assert os.path.exists(find_template('cookiecutter-pypackage'))

if __name__ == "__main__":
    test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:24:35.437769
# Unit test for function find_template
def test_find_template():
    real_dir = os.path.dirname(os.path.realpath(__file__))
    repo_dir = real_dir + '/test/test_dir_cookiecutter_json'
    print('repo: {}'.format(repo_dir))
    file = find_template(repo_dir)
    if file == 'cookiecutter-pypackage':
        print('test pass')
    else:
        print('test fail')

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:24:45.194838
# Unit test for function find_template
def test_find_template():
    test_dir = '/Users/alex/src/github.com/alex/cookiecutter-pypackage'
    template = find_template(test_dir)
    assert template == '/Users/alex/src/github.com/alex/cookiecutter-pypackage/{{cookiecutter.repo_name}}/'


# Generated at 2022-06-25 15:24:51.319727
# Unit test for function find_template
def test_find_template():
    logger.debug('test_find_template start')
    #repo_dir = '/tmp/cookiecutter-test'
    repo_dir = '/home/tools/repo/cookiecutter-qemu'
    project_template = find_template(repo_dir)
    print(project_template)

if __name__ == '__main__':
    #test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:24:53.020689
# Unit test for function find_template
def test_find_template():
    test_case_0()

# Generated at 2022-06-25 15:25:03.917968
# Unit test for function find_template
def test_find_template():
    repo_dir = 'https://github.com/alex/cookiecutter-pypackage.git'
    test_tempalte_1 = find_template(repo_dir)
    assert test_tempalte_1 == 'https://github.com/alex/cookiecutter-pypackage.git/{{cookiecutter.repo_name}}'

    repo_dir = 'https://github.com/alex/cookiecutter-pypackage'
    test_tempalte_2 = find_template(repo_dir)
    assert test_tempalte_2 == 'https://github.com/alex/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-25 15:25:09.180491
# Unit test for function find_template
def test_find_template():
    testing_path = '/Users/kang/Documents/cookiecutter-examples'
#    testing_path = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    print('Testing path is {0}'.format(testing_path))
    template = find_template(testing_path)
    print('Find template to be {0}'.format(template))

# Generated at 2022-06-25 15:25:13.639314
# Unit test for function find_template
def test_find_template():
    test_cases = list()
    test_cases.append(test_case_0)

# Generated at 2022-06-25 15:25:19.876753
# Unit test for function find_template
def test_find_template():
    str_0 = 'https://github.com/alex/cookiecutter-pypackage.git'

if __name__ == '__main__':
    # test_case_0()
    test_find_template()

# Generated at 2022-06-25 15:25:24.062484
# Unit test for function find_template
def test_find_template():
    str_1 = '/home/alex/code/cookiecutter-django'
    str_2 = '{{cookiecutter.repo_name}}'
    assert find_template(str_0) == True
    assert find_template(str_1) == False



# Generated at 2022-06-25 15:25:32.857480
# Unit test for function find_template
def test_find_template():

    import mock
    import shutil

    repo_dir = 'https://github.com/alex/cookiecutter-pypackage.git'

    # create a repository with a 'cookiecutter' directory
    shutil.copytree('tests/fake-repo-tmpl/', 'tests/fake-repo-0/')

    ret = find_template('tests/fake-repo-0/')

    shutil.rmtree('tests/fake-repo-0/')

    assert ret == 'tests/fake-repo-0/cookiecutter'


# Generated at 2022-06-25 15:25:36.835173
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/fake-repo/'
    result = find_template(repo_dir)
    print(result)
    assert result == './tests/fake-repo/fake-project/'

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:25:44.361438
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'test_data')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:25:48.704401
# Unit test for function find_template
def test_find_template():
    # Prepare data
    repo_dir = os.path.join(os.path.dirname(__file__),
                            "templates/cookiecutter-pypackage")
    project_template = os.path.join(os.path.dirname(__file__),
                                    "templates/cookiecutter-pypackage/{{cookiecutter.project_slug}}")

    # Execute test function
    result = find_template(repo_dir)

    # Check if result is correct
    assert result == project_template

# Generated at 2022-06-25 15:25:51.526010
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tmp/{{cookiecutter.repo_name}}'
    project_template = find_template(repo_dir)

# Generated at 2022-06-25 15:26:01.353018
# Unit test for function find_template
def test_find_template():
    # repo_dir_contents = os.listdir(repo_dir)
    repo_dir = '/workspaces/my_docs/my_docs/cookiecutter/tests/test-find-template'

    # for item in repo_dir_contents:
    #     if 'cookiecutter' in item and '{{' in item and '}}' in item:
    #         project_template = item
    #         break

    project_template = find_template(repo_dir)
    print ('project_template: ', project_template)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:04.618372
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/zw/git/cookiecutter-pypackage'
    find_template(repo_dir)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:06.423746
# Unit test for function find_template
def test_find_template():
    # Test case
    test_case_0()


if __name__ == '__main__':
    # Unit test
    test_find_template()

# Generated at 2022-06-25 15:26:10.833775
# Unit test for function find_template
def test_find_template():

    repo_dir = os.path.join('tests', 'test-repo', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.join('tests', 'test-repo', 'fake-repo-no-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == None


test_find_template()

# Generated at 2022-06-25 15:26:17.089082
# Unit test for function find_template
def test_find_template():
    path = '../tests/fake-repo-tmpl'
    output = find_template(path)
    assert output == '../tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    path = '../tests/fake-repo-pre'
    output = find_template(path)
    assert output == '../tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    path = '../tests/fake-repo-post'
    output = find_template(path)
    assert output == '../tests/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-25 15:26:19.617542
# Unit test for function find_template
def test_find_template():
    str_1 = os.listdir(str_0)
    str_1 = str_1/[2]
    if (str_1 == 'cookiecutter-pypackage') :
        print('OK')
    else :
        print('NO')


if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-25 15:26:23.974667
# Unit test for function find_template
def test_find_template():
    dir_path = os.path.join(os.getcwd(), 'tests', 'test-repo-tmpl')
    tmpl_path = find_template(dir_path)
    assert tmpl_path == os.path.join(dir_path, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-25 15:26:37.011431
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-25 15:26:47.463841
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/wangqiang/Documents/git/cookiecutter/tests/test-find-template-dir'
    assert find_template(repo_dir) == 'tests/test-find-template-dir/cookiecutter-{{cookiecutter.project_slug}}'
    repo_dir = '/Users/wangqiang/Documents/git/cookiecutter/tests/test-find-template-dir2'
    assert find_template(repo_dir) == 'tests/test-find-template-dir2/cookiecutter-pypackage'
    repo_dir = '/Users/wangqiang/Documents/git/cookiecutter/tests/test-find-template-dir3'

# Generated at 2022-06-25 15:26:47.943817
# Unit test for function find_template
def test_find_template():
    assert 1 == 1

# Generated at 2022-06-25 15:26:49.428978
# Unit test for function find_template
def test_find_template():
    repo_dir = '.'
    find_template(repo_dir)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:26:55.380705
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/alex/ProgrammingProjects/Python/Cookiecutter') == '/home/alex/ProgrammingProjects/Python/Cookiecutter/cookiecutter-pypackage'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:27:00.608768
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.getcwd(), 'tests/test-repos/cookiecutter-pypackage')
    template_path = find_template(repo_dir)
    assert (template_path == os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))


# Generated at 2022-06-25 15:27:05.589531
# Unit test for function find_template
def test_find_template():

    # Test case 0
    repo_dir = "https://github.com/alex/cookiecutter-pypackage.git"
    abs_path = find_template(repo_dir)

# Generated at 2022-06-25 15:27:09.687477
# Unit test for function find_template
def test_find_template():
    str_0 = 'https://github.com/alex/cookiecutter-pypackage.git'
    str_1 = '/Users/zhajie/git_space/cookiecutter-pypackage'
    print(find_template(str_1))


if __name__ == "__main__":
    # test_find_template()
    test_case_0()

# Generated at 2022-06-25 15:27:17.106265
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = os.listdir('/Users/Bing/CookiesTest/d-template/')
    for item in repo_dir_contents:
        print(item)
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            print(item)
            break
    print(repo_dir_contents)

# test_case_0()
test_find_template()

# Generated at 2022-06-25 15:27:21.478119
# Unit test for function find_template
def test_find_template():
    """
    This is a unit test case for function find_template.
    """
    repo_dir_0 = '/Users/Alex/Downloads/cookiecutter-pypackage-master'
    project_template_0 = find_template(repo_dir_0)

# Generated at 2022-06-25 15:27:46.537523
# Unit test for function find_template
def test_find_template():
    import sys
    import os

    # set up

    dir = 'test'

    # test

    try:
        os.mkdir(dir)
    except OSError:
        print ("Creation of the directory %s failed" % dir)
    else:
        print ("Successfully created the directory %s " % dir)

    cwd = os.getcwd()
    path = os.path.join(cwd, dir)
    os.chdir(path)
    the_file = open("cookiecutter-{{cookiecutter.project_slug}}", "w")
    the_file.close()

    try:
        print("\n1 test")
        find_template('test')
    except:
        print("Exception")


# Generated at 2022-06-25 15:27:53.502214
# Unit test for function find_template
def test_find_template():
    var_1 = "mU6JdjM6mQ"
    var_2 = "coovor-L6"
    var_3 = "cookiecutter-L6"
    var_4 = "{{cookiecutter.project_slug}}-L6"
    var_5 = "cookiecutter-{{cookiecutter.project_slug}}-L6"
    var_4 = "{{cookiecutter.project_slug}}"
    var_5 = "cookiecutter-{{cookiecutter.project_slug}}"
    var_6 = "cookiecutter"
    var_7 = "+6QhL6"
    printed = "The project template appears to be %s" % var_4
    printed = "The project template appears to be %s" % var_5



# Generated at 2022-06-25 15:27:59.403187
# Unit test for function find_template
def test_find_template():
    # Setup
    template_root = 'tests/templates/template-with-hooks'
    template_path = os.path.join(template_root, '{{cookiecutter.variable}}')
    assert os.path.exists(template_path)
    # Test
    result = find_template(template_root)
    # Verify
    assert result == template_path

# Generated at 2022-06-25 15:28:10.461456
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter import generate
    from cookiecutter.exceptions import RepositoryNotFound
    from cookiecutter.exceptions import InvalidMode
    assert find_template("https://github.com/audreyr/cookiecutter-pypackage.git") == "CookiecutterPypackage"
    assert find_template("git@github.com:audreyr/cookiecutter-pypackage.git") == "CookiecutterPypackage"
    assert find_template("https://github.com/audreyr/cookiecutter-pypackage.git") == "CookiecutterPypackage"
    assert find_template("https://github.com/audreyr/cookiecutter-pypackage.git")

# Generated at 2022-06-25 15:28:11.918544
# Unit test for function find_template
def test_find_template():
    # Failure test case
    assert test_case_0() == None

# Generated at 2022-06-25 15:28:13.252520
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass



# Generated at 2022-06-25 15:28:16.971745
# Unit test for function find_template
def test_find_template():
    template = find_template(os.getcwd())
    assert 'cookiecutter-pypackage' in template

# Generated at 2022-06-25 15:28:20.895328
# Unit test for function find_template
def test_find_template():
    try:
        tuple_0 = None
        assure_dir_exists(tuple_0)
        tuple_1 = None
        assure_dir_exists(tuple_1)
    except:
        return False

    return True



# Generated at 2022-06-25 15:28:28.124173
# Unit test for function find_template
def test_find_template():
    mock_repo_dir = None
    expected_var_0 = None
    with patch('cookiecutter.repository.find_template',
               return_value=expected_var_0):
        # Call the tested function
        var_0 = find_template(mock_repo_dir)
        # Ensure all arguments passed to patched function
        assert find_template.call_count == 1
        # Ensure the expected return value is the one returned
        assert var_0 is expected_var_0
        # Ensure all patched methods were called as expected
        find_template.assert_called_once_with(mock_repo_dir)
        # Ensure all patched attributes were accessed as expected
        assert find_template.call_count == 1

# Generated at 2022-06-25 15:28:33.562299
# Unit test for function find_template
def test_find_template():
    # Raise exception to see if it's being caught or not.
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        pass


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-25 15:28:46.211237
# Unit test for function find_template
def test_find_template():
    try:
        find_template(None)
    except NonTemplatedInputDirException:
        return True
    except Exception:
        return False

if __name__ == '__main__':
    print('Testing find_template')
    print('test_find_template() returned ', test_find_template())

# Generated at 2022-06-25 15:28:56.068894
# Unit test for function find_template
def test_find_template():
    import mock
    import os
    import tempfile
    import shutil


# Generated at 2022-06-25 15:28:58.210141
# Unit test for function find_template
def test_find_template():
    assert find_template("foo") == "foo"


# Generated at 2022-06-25 15:29:02.910752
# Unit test for function find_template
def test_find_template():
    paren_0 = None
    value_0 = find_template(paren_0)
    assert paren_0 == value_0
    param_0 = None
    value_1 = find_template(param_0)
    assert param_0 == value_1
    string_0 = None
    value_2 = find_template(string_0)
    assert string_0 == value_2

# Generated at 2022-06-25 15:29:08.781715
# Unit test for function find_template
def test_find_template():
    assert callable(find_template), "Function 'find_template(repo_dir)' not defined"


# Generated at 2022-06-25 15:29:10.720438
# Unit test for function find_template
def test_find_template():
    logger.info('')

    # test_case_0()

    logger.info('')

    logger.info('Done')

# Generated at 2022-06-25 15:29:12.573200
# Unit test for function find_template
def test_find_template():
    if find_template == None:
        return False
    else:
        return True

# Generated at 2022-06-25 15:29:16.125934
# Unit test for function find_template
def test_find_template():
    filter_0 = None
    buffer = test_case_0()
    # Assertion
    try:
        assert(buffer == filter_0)
    except AssertionError:
        raise AssertionError(buffer)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:29:25.412371
# Unit test for function find_template
def test_find_template():
    from mock import patch, MagicMock, call

    tuple_0 = None
    var_0 = find_template(tuple_0)

    with patch('cookiecutter.repository.find_repo_dir') as mock_find_repo_dir:
        var_1 = mock_find_repo_dir(tuple_0)
        mock_find_repo_dir.return_value = 'dir_0'
        with patch('os.listdir') as mock_listdir:
            var_2 = mock_listdir('dir_0')
            mock_listdir.return_value = ['dir_1', 'dir_2', 'dir_3']
            with patch('os.path.join') as mock_join:
                var_0 = find_template('dir_0')

# Generated at 2022-06-25 15:29:31.110991
# Unit test for function find_template
def test_find_template():
    assert '{{ cookiecutter.name }}' == find_template('cookiecutter-pypackage')
    assert '{{ cookiecutter.name }}' == find_template('cookiecutter-pypackage')



# Generated at 2022-06-25 15:29:50.300946
# Unit test for function find_template
def test_find_template():
    try:
        tuple_1 = None
        var_1 = find_template(tuple_1)
    except NonTemplatedInputDirException:
        assert True



# Generated at 2022-06-25 15:29:54.591842
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)
    assert test_case_0() is None

if __name__ == '__main__':
    logging.basicConfig(format='%(message)s', level=logging.DEBUG)
    test_find_template()

# Generated at 2022-06-25 15:29:58.473989
# Unit test for function find_template
def test_find_template():
    assert find_template(tuple_0) == Project_template

# Generated at 2022-06-25 15:30:04.476425
# Unit test for function find_template
def test_find_template():

    mock_args = {}
    mock_args['repo_dir'] = '__filename__'
    mock_args['no_input'] = False
    mock_args['extra_context'] = '__default__'
    mock_args['output_dir'] = '__filename__'
    assert find_template(**mock_args) == None, "Expected find_template() to return None"

    # Call function with args instead of kwargs for test coverage
    try:
        assert find_template(mock_args) == None, "Expected find_template() to return None"
    except TypeError:
        pass

# Generated at 2022-06-25 15:30:09.724322
# Unit test for function find_template
def test_find_template():
    logging.basicConfig(format='%(asctime)s %(levelname)s %(message)s', level=logging.DEBUG)
    test_case_0()

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-25 15:30:14.841504
# Unit test for function find_template
def test_find_template():
    import cookiecutter
    # This takes the path of the current file and goes up 2 directories to find the example_repos directory
    repo_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    project_template_dir = find_template(repo_dir)
    print(project_template_dir)

# Generated at 2022-06-25 15:30:26.684910
# Unit test for function find_template
def test_find_template():
    # Test for a valid case
    # Try to find the template in the current directory
    try:
        find_template(".")
    except Exception as e:
        find_template(".")
    # Test for a valid case
    # Try to find the template in the current directory
    try:
        find_template(".")
    except Exception as e:
        find_template(".")
    # Test for a valid case
    # Try to find the template in the current directory
    try:
        find_template(".")
    except Exception as e:
        find_template(".")
    # Test for a valid case
    # Try to find the template in the current directory
    try:
        find_template(".")
    except Exception as e:
        find_template(".")
    # Test for a valid case
    # Try to find the template in the current directory

# Generated at 2022-06-25 15:30:28.310506
# Unit test for function find_template
def test_find_template():
    with pytest.raises(NonTemplatedInputDirException):
        test_case_0()

# Generated at 2022-06-25 15:30:38.656561
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/code/cookiecutter-pypackage') == '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('/home/audreyr/code/cookiecutter-pypackage') == '/home/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('') == '{{cookiecutter.repo_name}}'
    assert find_template(None) == None

# Generated at 2022-06-25 15:30:44.976374
# Unit test for function find_template
def test_find_template():
    try:
        test_case_0()
    except NonTemplatedInputDirException:
        print('Test passed')
    else:
        print('Unit test failed')

# Generated at 2022-06-25 15:31:12.453259
# Unit test for function find_template
def test_find_template():
    import inspect

    # Arguments
    tuple_0 = None

    # Function call
    result = find_template(tuple_0)

    # Return type
    assert isinstance(result, str)
    assert not result

    # Return value
    assert result == ""
    assert result == ""
    assert result == ""
    assert result == ""
    assert result == ""
    assert result == ""
    assert result == ""
    assert result == ""
    assert result == ""
    assert result == ""



# Generated at 2022-06-25 15:31:13.760997
# Unit test for function find_template
def test_find_template():
    assert find_template(None) == None
    # assert find_template(None) == NonTemplatedInputDirException

# Generated at 2022-06-25 15:31:20.824837
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/johndoe/projects/cookiecutter-pypackage') == '/home/johndoe/projects/cookiecutter-pypackage/pypackage'
    assert find_template('/home/johndoe/projects/cookiecutter-pypackage/') == '/home/johndoe/projects/cookiecutter-pypackage/pypackage'
    assert find_template('/home/johndoe/projects/cookiecutter-pypackage/pypackage') == '/home/johndoe/projects/cookiecutter-pypackage/pypackage'

# Generated at 2022-06-25 15:31:25.768731
# Unit test for function find_template
def test_find_template():
    assert find_template(('tests/files/fake-repo-pre/',)) == 'tests/files/fake-repo-pre/{{cookiecutter.repo_name}}/'

# Lint as: python -m unittest discover -s tests/ -p test_finders.py

# Generated at 2022-06-25 15:31:33.309033
# Unit test for function find_template
def test_find_template():
    assert find_template == 'cookiecutter/'

# Function to get the directories of the project
# Function to get the files in the project_directory
# Function to get the cookies in the files of the project
# Function to get the directories of the input_directory
# Function to get the files in the input_directory
# Function to get the cookies in the files of the input_directory
# Function to compare the files and directories of the project_directory to the input_directory
# Function to compare the cookies of the project_directory to the input_directory
# Function to get the directories of the generated_directory
# Function to get the files in the generated_directory
# Function to get the cookies in the files of the generated_directory
# Function to compare the files and directories of the input_directory to the generated_directory
# Function to compare the cookies of the input_directory to the generated_directory


# Generated at 2022-06-25 15:31:36.295021
# Unit test for function find_template
def test_find_template():
    
    try:
        test_case_0()
    except Exception as e:
        print("Exception Raised:",e)
    else:
        print("Test Case 0 passed")


test_find_template()

# Generated at 2022-06-25 15:31:37.383041
# Unit test for function find_template
def test_find_template():
    assert callable(find_template)

# Generated at 2022-06-25 15:31:38.145192
# Unit test for function find_template
def test_find_template():
    assert find_template(tuple_0) == None

# Generated at 2022-06-25 15:31:43.581402
# Unit test for function find_template
def test_find_template():
    os.chdir('C:\\Users\\Mateusz\\PycharmProjects')
    tmp_path = os.path.join('C:\\Users\\Mateusz\\')
    tmp_dir = 'cookiecutter-django'
    tmp = find_template(tmp_path + tmp_dir )
    assert tmp == tmp_path + 'cookiecutter-django\\{{cookiecutter.repo_name}}'




# Generated at 2022-06-25 15:31:44.849789
# Unit test for function find_template
def test_find_template():
    tuple_1 = None
    var_1 = find_template(tuple_1)

