

# Generated at 2022-06-21 10:42:01.527445
# Unit test for function find_template
def test_find_template():
    test_context = '../cookiecutter-pypackage/cookiecutter.json'
    test_tmpl_dir = 'cookiecutter-pypackage'
    test_tmpl_dir_long = 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    test_tmpl_dir_found = find_template(test_context)
    assert test_tmpl_dir == test_tmpl_dir_found
    test_tmpl_dir_found = find_template(test_tmpl_dir)
    assert test_tmpl_dir_long == test_tmpl_dir_found

    # Test exception
    test_context_exception = 'cookiecutter-demo'
    import pytest
    with pytest.raises(NonTemplatedInputDirException):
        find

# Generated at 2022-06-21 10:42:02.957761
# Unit test for function find_template
def test_find_template():
    import tempfile
    assert find_template(tempfile.mkdtemp())
    assert find_template('../c')

# Generated at 2022-06-21 10:42:07.595250
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    template = '{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == template

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:42:08.267691
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:42:16.053680
# Unit test for function find_template
def test_find_template():
    """Test `find_template()`."""
    template_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-tmpl'
    )
    template_path = find_template(template_dir)
    assert template_path == os.path.join(
        template_dir,
        '{{cookiecutter.repo_name}}{{cookiecutter.repo_name_suffix}}'
    )

# Generated at 2022-06-21 10:42:20.158910
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre')
    project_template = find_template(repo_dir)
    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:22.680867
# Unit test for function find_template
def test_find_template():
    """Verify proper propagation of exception."""
    try:
        find_template('/does/not/exist')
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-21 10:42:30.560422
# Unit test for function find_template
def test_find_template():
    from tempfile import mkdtemp
    from shutil import rmtree

    project_template = 'my-project-template'
    other_dir = 'not_the_template'

    repo_dir = mkdtemp()
    for dirname in project_template, other_dir:
        os.mkdir(os.path.join(repo_dir, dirname))

    found_project_template = find_template(repo_dir)
    assert found_project_template == os.path.join(repo_dir, project_template)
    rmtree(repo_dir)

# Generated at 2022-06-21 10:42:38.810949
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template function."""

    template_path = find_template(os.path.join(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'),
        '{{cookiecutter.repo_name}}'
    ))

    assert template_path == os.path.join(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'),
        'fake-repo'
    )

# Generated at 2022-06-21 10:42:41.917034
# Unit test for function find_template
def test_find_template():
    repo_dir = '{{cookiecutter.project_slug}}'
    result = find_template(repo_dir)
    assert '{{cookiecutter.project_slug}}' in result

# Generated at 2022-06-21 10:42:50.227488
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fixtures', 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:43:01.706231
# Unit test for function find_template
def test_find_template():
    """
    Verify that the correct template subdirectory is returned when
    the input directory is an actual cookiecutter template.
    """
    import tempfile

    def _cleanup_files(files):
        """Delete temporary files when done"""
        for sfile in files:
            os.remove(sfile)

    def _make_temp_dir(dirname):
        """Create a tempdir and its contents"""
        try:
            os.mkdir(dirname)
        except OSError as e:
            if e.errno == 17:
                logger.debug("Directory %s already exists.", dirname)
        else:
            logger.debug("Created directory %s", dirname)
        return dirname

    def _make_temp_file(filename):
        """Create a tempfile"""
        dirname = os.path.dirname

# Generated at 2022-06-21 10:43:10.169177
# Unit test for function find_template
def test_find_template():
    """Test that `find_template` is able to locate the project template."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        '{{cookiecutter.repo_name}}',
    )
    assert find_template(repo_dir) == os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.project_slug}}'
    )



# Generated at 2022-06-21 10:43:18.795233
# Unit test for function find_template
def test_find_template():
    # Fixtures
    repo_dir = '/my/faux/dir/{{cookiecutter.repo_name}}'
    template_dir = '/my/faux/dir/{{cookiecutter.repo_name}}/cookiecutter-{{cookiecutter.repo_name}}'

    # Setup
    os.mkdir(repo_dir)
    os.mkdir(template_dir)

    assert find_template(repo_dir) == template_dir

    # Teardown
    os.rmdir(template_dir)
    os.rmdir(repo_dir)

# Generated at 2022-06-21 10:43:29.836648
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/test-hooks/fake-repo')
    # Test non templated exceptional case
    non_templated = os.path.join(repo_dir, 'non-templated')
    try:
        _ = find_template(non_templated)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'Should have raised NonTemplatedInputDirException'

    # Test templated case
    templated = os.path.join(repo_dir, 'templated')
    project_template = find_template(templated)
    assert project_template == os.path.join(templated, '{{cookiecutter.project_name}}')

# Generated at 2022-06-21 10:43:34.124317
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), 'test_template'))
    user_config_file = os.path.join(os.path.expanduser('~'), '.cookiecutterrc')
    if os.path.isfile(user_config_file):
        os.remove(user_config_file)
    template_path = find_template(template_dir)
    assert 'test' in template_path
    assert '{{ cookiecutter.repo_name }}' in template_path
    assert '{{ cookiecutter.repo_name }}' not in os.path.basename(template_path)
    assert '__pycache__' not in template_path



# Generated at 2022-06-21 10:43:42.408010
# Unit test for function find_template
def test_find_template():
    assert ('cookiecutter-pypackage') == find_template('/Users/audreyr/cookiecutter-pypackage')
    assert ('cookiecutter-pypackage/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}') == find_template('/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:43:53.709021
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.exceptions import NonTemplatedInputDirException

    with TemporaryDirectory() as tmpdir:
        repo_dir = os.path.join(tmpdir, 'test-repo')

        os.mkdir(repo_dir)

        # Empty dir
        assert False == find_template(repo_dir)

        # Dir with files
        shutil.copy('tests/files/fake-repo/README.rst', repo_dir)
        shutil.copy('tests/files/fake-repo/goodbye.py', repo_dir)
        assert False == find_template(repo_dir)

        # Dir with dirs

# Generated at 2022-06-21 10:43:58.009329
# Unit test for function find_template
def test_find_template():
    new_dir = 'test_find_template_dir'
    cookiecutter_json = os.path.join(new_dir, 'cookiecutter.json')
    os.makedirs(new_dir)
    open(cookiecutter_json, 'a').close()
    template_dir = find_template(new_dir)
    assert template_dir == new_dir

# Generated at 2022-06-21 10:43:59.391733
# Unit test for function find_template
def test_find_template():
    find_template('/Users/hackebrot/.cookiecutters')

# Generated at 2022-06-21 10:44:09.756637
# Unit test for function find_template
def test_find_template():
    """.
    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    assert find_template('./tests/test-repo-tmpl') == './tests/test-repo-tmpl/{{cookiecutter.repo_name}}'

    try:
        find_template('./tests/fake-repo-tmpl')
        assert False, "find_template should throw exeption"
    except NonTemplatedInputDirException:
        return

# Generated at 2022-06-21 10:44:18.262574
# Unit test for function find_template
def test_find_template():
    # assert find_template(repo_dir) == project_template

    # Fake "repo_dir"
    repo_dir = os.path.join(os.getcwd(), 'tests/fake-repo-tmpl')
    project_template = os.path.join(os.getcwd(), 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == project_template

    # Fake "repo_dir" with no templated directory
    repo_dir = os.path.join(os.getcwd(), 'tests/fake-repo-no-tmpl')
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

# Generated at 2022-06-21 10:44:22.861965
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/projects/cookiecutter-pypackage') == (
        '/Users/audreyr/projects/cookiecutter-pypackage/cookiecutter-pypackage'
    )

# Generated at 2022-06-21 10:44:24.103588
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-21 10:44:29.065079
# Unit test for function find_template
def test_find_template():

    repo_dir = os.path.join('tests', 'fake-repo-pre')

    expected_project_template = os.path.join(repo_dir, 'fake-project-template/')
    project_template = find_template(repo_dir)

    assert expected_project_template == project_template



# Generated at 2022-06-21 10:44:31.221603
# Unit test for function find_template
def test_find_template():
    find_template('/Users/Julien/github/cookiecutter/cookiecutter-pypackage')
    #find_template('cookiecutter-pypackage')

# Generated at 2022-06-21 10:44:31.737432
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:44:35.036562
# Unit test for function find_template
def test_find_template():
    # Mock the repo_dir
    repo_dir = 'tests/test-output/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-output/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:47.671310
# Unit test for function find_template
def test_find_template():
    """Check that we can find the right project template"""
    import pytest
    from cookiecutter.main import cookiecutter
    import shutil
    import tempfile

    # Create a temporary directory to work in
    tmp_dir = tempfile.mkdtemp()

    # Quickly make our own template
    context = {
        'project_name': 'Test Project',
        'project_slug': 'test_project',
        'author_name': 'Test Author',
    }

    # Run our own template through cookiecutter
    cookiecutter(
        'tests/fake-repo-pre/',
        no_input=True,
        output_dir=tmp_dir, context=context)

    # Test that find_template finds the project template

# Generated at 2022-06-21 10:44:58.786484
# Unit test for function find_template
def test_find_template():
    """Unit test to ensure that the function find_template is working
    properly.
    """
    import tempfile
    from shutil import rmtree

    repo_dir = tempfile.mkdtemp()

    f = open(os.path.join(repo_dir, 'cookiecutter-templated'), 'w')
    f.close()

    f = open(os.path.join(repo_dir, 'cookiecutter-not-templated'), 'w')
    f.close()

    assert(find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-templated'))

    rmtree(repo_dir)

    return 0

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:45:06.504804
# Unit test for function find_template
def test_find_template():
    """
    Return the path to the directory that contains the template files.
    """
    best_template_path = find_template('test/test-repo-pre/')
    assert 'test-repo-pre/' in best_template_path


# Generated at 2022-06-21 10:45:14.107567
# Unit test for function find_template
def test_find_template():
    """
    Tests to ensure that the find_template function is working properly
    """
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        'tests',
        'fake-repo-tmpl',
    )
    expected_result = os.path.join(repo_dir, 'fake-project-tmpl')
    
    result = find_template(repo_dir)

    assert result == expected_result

# Generated at 2022-06-21 10:45:19.000713
# Unit test for function find_template
def test_find_template():
    repo_dir = "/Users/audreyr/projects/cookiecutter-pypackage/"
    template_dir = find_template(repo_dir)
    assert template_dir == "/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}"


# Generated at 2022-06-21 10:45:29.770255
# Unit test for function find_template
def test_find_template():
    import json
    import shutil
    from cookiecutter import utils
    from cookiecutter.prompt import read_user_variable

    fixtures = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fixtures'))
    json_file = os.path.join(fixtures, 'fake-repo', 'cookiecutter.json')
    with open(json_file) as f:
        context = json.load(f)
    repo_dir = os.path.join(fixtures, 'fake-repo')
    extra_context = {
        'full_name': 'Firstname Lastname',
        'email': 'firstname.lastname@example.com',
        'github_username': 'firstname-lastname'
    }
    context

# Generated at 2022-06-21 10:45:40.998211
# Unit test for function find_template
def test_find_template():
    """Test for function `find_template`"""
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), '../tests/test-find-template'
    )
    template_in_question = 'cookiecutter-tests/{{cookiecutter.repo_name}}'
    if not os.path.exists(test_dir):
        os.mkdir(test_dir)
    os.chdir(test_dir)
    assert os.path.exists(test_dir)
    os.system(
        'git clone git@github.com:wdm0006/cookiecutter.git ' + template_in_question
    )
    assert os.path.exists(template_in_question)

# Generated at 2022-06-21 10:45:50.297930
# Unit test for function find_template
def test_find_template():
    """Verify the expected output of find_template."""
    import shutil
    import tempfile
    import textwrap

    input_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 10:45:53.500478
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-repo/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:45:59.240021
# Unit test for function find_template
def test_find_template():
    """Test if find_template finds the project template."""
    from cookiecutter.tests.test_utils import make_repo

    repo_path = make_repo()
    template_path = find_template(repo_path)
    assert template_path == os.path.join(repo_path, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:46:03.946189
# Unit test for function find_template
def test_find_template():
    start = os.getcwd()
    assert find_template(os.path.join(start, "tests/test-input")) == \
        os.path.join(start, "tests/test-input/tests/cookiecutter-tests/cookiecutter-pypackage")

# Generated at 2022-06-21 10:46:13.884419
# Unit test for function find_template
def test_find_template():
    import pytest

    # Test invalid non-templated dir

    non_templated_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            'fixtures',
            'non-templated-repo'
        )
    )

    with pytest.raises(NonTemplatedInputDirException):
        find_template(non_templated_dir)

    # Test valid templated dir

    templated_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            'fixtures',
            'fake-repo',
        )
    )


# Generated at 2022-06-21 10:46:29.713183
# Unit test for function find_template
def test_find_template():
    """Verify expected behavior from find_template function"""
    # Test 1: project template is named as expected
    # expect that function finds template directory name in repo_dir
    repo_dir = '/Users/unittest/fake_repo_dir'
    project_template = 'my_project_template'
    os.listdir = lambda x: ['some_other_file', project_template]
    assert find_template(repo_dir) == os.path.join(repo_dir, project_template)

    # Test 2: template found in subdirectory of repo_dir
    # expect that function finds template directory name in subdirectory of repo_dir
    repo_dir = '/Users/unittest/fake_repo_dir'
    project_template = 'my_project_template'

# Generated at 2022-06-21 10:46:35.151767
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('./tests/fake-repo-tmpl')

    expected_result = os.path.abspath('./tests/fake-repo-tmpl/'
                                      '{{cookiecutter.repo_name}}')
    result = find_template(repo_dir)

    assert result == expected_result

# Generated at 2022-06-21 10:46:42.220294
# Unit test for function find_template
def test_find_template():
    """Verify proper project template location is returned."""
    # Create a directory with a made up template
    os.makedirs('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')

    # Make sure correct template file is returned
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:46:48.429954
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import os
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-foobar')
    shutil.rmtree(repo_dir)

# Generated at 2022-06-21 10:47:01.098413
# Unit test for function find_template
def test_find_template():
    """test function find_template"""
    assert find_template('test1') == 'test1/cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template('test2') == 'test2/cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template('test3') == 'test3/cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template('test4') == 'test4/cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template('test5') == 'test5/cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template('test6') == 'test6/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:47:06.942423
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    project_template = '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template



# Generated at 2022-06-21 10:47:09.356087
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == './my-cookiecutter-test/{{cookiecutter.project_slug}}'


# Generated at 2022-06-21 10:47:13.329865
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:47:19.608552
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import pytest

    import cookiecutter.config as cc_config

    cc_config.REPO_DIR = 'tests/test-find-template'
    assert os.path.isdir('tests/test-find-template')
    find_template(cc_config.REPO_DIR)

# Generated at 2022-06-21 10:47:30.941739
# Unit test for function find_template
def test_find_template():
    # Test a valid template
    current_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(current_dir, 'fake-repo-pre-rendered')
    expected_project_template = os.path.join(repo_dir,'{{cookiecutter.repo_name}}')
    found_project_template = find_template(repo_dir)
    assert found_project_template == expected_project_template

    # Test an invalid template with {{cookiecutter.repo_name}}
    repo_dir = os.path.join(current_dir, 'fake-repo-templated-repo_name')

# Generated at 2022-06-21 10:47:45.697936
# Unit test for function find_template
def test_find_template():
    """Test find_template, the function that finds the template in the local
    repo.
    """
    from cookiecutter import tempdir
    from cookiecutter.tests.test_find import (
        git_clone_url,
        template_repo_name
    )
    with tempdir.tempdir() as tmp_dir:
        repo_dir = tmp_dir.makedir(template_repo_name)
        with open(os.path.join(repo_dir, 'thing.py'), 'w') as f:
            f.write('A thing')
        with open(os.path.join(repo_dir, 'thing.txt'), 'w') as f:
            f.write('A thing')

# Generated at 2022-06-21 10:47:54.017335
# Unit test for function find_template
def test_find_template():
    repo_dir = 'some_new_dir'
    item1 = 'some_file'
    item2 = 'cookiecutter-{{cookiecutter.project_name}}'
    item3 = 'cookiecutter-myproject'
    item4 = 'cookiecutter-{cookiecutter.project_name}'

    with mock.patch('cookiecutter.find.os.listdir') as mock_listdir:
        mock_listdir.return_value = [item1, item2, item3, item4]

        template = find_template(repo_dir)
        assert template == os.path.join(repo_dir, item2)

# Generated at 2022-06-21 10:48:00.647673
# Unit test for function find_template
def test_find_template():
    """Test that find_template finds the correct directory"""
    from .compat import mock

    mock_repo_dir = os.path.abspath('tests/fake-repo-pre/')

    with mock.patch('os.listdir', return_value=['fake-repo-pre']):
        template = find_template(mock_repo_dir)
        assert template == os.path.abspath('tests/fake-repo-pre')

# Generated at 2022-06-21 10:48:09.947666
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works properly."""
    import tempfile
    import shutil

    # Create a temporary directory to store the repo contents.
    temp_repo_dir = tempfile.mkdtemp()

    # Create a child directory within the temporary directory.
    temp_repo_contents = tempfile.mkdtemp(dir=temp_repo_dir)

    # Return the name of this directory.
    temp_name = os.path.basename(temp_repo_contents)

    # Set a template name
    TEMPLATE = '{{ cookiecutter.repo_name }}'

    # Determine path to the temporary directory as if it were a repo.
    project_template = os.path.join(
        temp_repo_contents,
        TEMPLATE
    )

    # Create

# Generated at 2022-06-21 10:48:21.782481
# Unit test for function find_template
def test_find_template():
    """Verify the correct template is found in the given repo."""
    import tempfile

    repo_dir = tempfile.mkdtemp()
    logger.debug('Created temporary directory %s', repo_dir)
    os.mkdir(os.path.join(repo_dir, 'foo'))
    os.mkdir(os.path.join(repo_dir, 'bar'))
    os.mkdir(os.path.join(repo_dir, 'baz'))
    os.mkdir(os.path.join(repo_dir, 'bizz'))
    os.mkdir(os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-21 10:48:28.570418
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    template = find_template(os.path.dirname(test_dir))
    assert os.path.abspath(template) == os.path.abspath(test_dir)



# Generated at 2022-06-21 10:48:37.332780
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-repo-tmpl'))
    template_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-repo-tmpl', 'cookiecutter-{{repo_name}}'))
    assert find_template(repo_dir) == template_path

# Generated at 2022-06-21 10:48:43.712954
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    os.chdir(os.path.dirname(__file__))

    # No templated directories
    repo_dir = 'tests/fake-repo-nontemplated-dir'
    os.chdir(repo_dir)
    try:
        logger.debug('Changing working directory to %s', os.getcwd())
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        success = True
    else:
        success = False
    os.chdir('..')

    assert success

    # One templated directory
    repo_dir = 'tests/fake-repo-one-templated-dir'
    os.chdir(repo_dir)

# Generated at 2022-06-21 10:48:53.448151
# Unit test for function find_template
def test_find_template():
    """
    Determine which child directory of `repo_dir` is the project template.
    """
    if not os.path.isdir(os.path.expanduser('~/cookiecutter-django1.7')):
        import subprocess
        subprocess.call([
            'git',
            'clone',
            'https://github.com/pydanny/cookiecutter-django1.7.git',
            os.path.expanduser('~/cookiecutter-django1.7')
        ])
    repo_dir = os.path.expanduser('~/cookiecutter-django1.7')
    project_template = find_template(repo_dir)
    assert 'cookiecutter-django1.7/{{cookiecutter.repo_name}}' == project_template

# Generated at 2022-06-21 10:48:55.342315
# Unit test for function find_template
def test_find_template():
    # TODO
    pass

# Generated at 2022-06-21 10:49:09.489670
# Unit test for function find_template
def test_find_template():
    """Used for testing find_template
    """

    repo_dir = "/home/user/project/python_cookiecutter"
    assert find_template(repo_dir) == "/home/user/project/python_cookiecutter/{{cookiecutter.repo_name}}"



# Generated at 2022-06-21 10:49:11.980362
# Unit test for function find_template
def test_find_template():
    repo_dir = r'C:/Users/Administrator/Desktop/cookiec/cookiec/tests/fixtures/fake-repo'
    find_template(repo_dir)  # Should not raise exception


# Generated at 2022-06-21 10:49:18.160657
# Unit test for function find_template
def test_find_template():
    local_repo_path = os.path.join(os.path.dirname(__file__), '../test_templates/fake-repo-tmpl')
    template_dir = find_template(local_repo_path)
    expected_path = os.path.join(local_repo_path, '{{cookiecutter.repo_name}}')
    assert template_dir == expected_path

# Generated at 2022-06-21 10:49:21.028949
# Unit test for function find_template
def test_find_template():
    find_template('/home/sjj/cookiecutter-django')

# Generated at 2022-06-21 10:49:25.155147
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/user/my-project/'
    find_template(repo_dir)
    assert find_template(repo_dir) == '/home/user/my-project/cookiecutter-{{cookiecutter.repo_name}}/'
    return find_template(repo_dir)

# Generated at 2022-06-21 10:49:26.957353
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns correct path."""
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:49:27.466178
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:49:30.918318
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns 'crud' if cookiecutter-django is in ./crud/"""
    assert find_template('../repos/cookiecutter-django/') == '../repos/cookiecutter-django/crud'

# Generated at 2022-06-21 10:49:43.005518
# Unit test for function find_template
def test_find_template():
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template
    else:
        raise NonTemplatedInputDirException


# Generated at 2022-06-21 10:49:43.592147
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-21 10:50:43.517038
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function returns the correct project template."""
    template_dir = os.path.dirname(os.path.dirname(__file__))
    test_template = os.path.join(template_dir, 'tests', 'fake-repo-tmpl')

    project_template = find_template(test_template)
    expected_project_template = os.path.join(
        test_template,
        '{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-21 10:50:46.147469
# Unit test for function find_template
def test_find_template():
    # This can be made much more thorough if necessary.
    assert find_template('/path/to/template') == '/path/to/template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:50:47.735327
# Unit test for function find_template
def test_find_template():
    assert find_template('example') == ['example/{{cookiecutter.repo_name}}']


# Generated at 2022-06-21 10:50:56.271933
# Unit test for function find_template
def test_find_template():
    """Unit tests for function find_template."""
    # Test for correct directory
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests/test-output/fake-repo'
        )
    )
    found_project_template = find_template(repo_dir)
    assert 'fake-project-template' in found_project_template

    # Test for directory that doesn't contain template string
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests/test-output/fake-repo/fake-project-template'
        )
    )
    found_project_template = find_

# Generated at 2022-06-21 10:51:07.770215
# Unit test for function find_template
def test_find_template():
    """
    Assert that function find_template() can evalate if a file matches the input directory.
    """
    input_list = "cookiecutter-pypackage"
    assert find_template(input_list) == os.path.join(input_list, "{{cookiecutter.repo_name}}")
    input_list = "cookiecutter-pypackage-master"
    assert find_template(input_list) == os.path.join(input_list, "{{cookiecutter.repo_name}}")
    input_list = "cookiecutter-pypackage"
    assert find_template(input_list) == os.path.join(input_list, "{{cookiecutter.repo_name}}")
    input_list = "cookiecutter-pypackage-master"

# Generated at 2022-06-21 10:51:13.373822
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test-template-repo')
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'test-{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:51:19.690385
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.expanduser('~/.cookiecutters/cookiecutter-pypackage')
    project_template = find_template(repo_dir)
    assert (
        project_template ==
        os.path.expanduser('~/.cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}')
    )

# Generated at 2022-06-21 10:51:30.537433
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.compat import unicode
    from cookiecutter import utils

    new_repo_path = '/tmp/cookiecutter-find-repo-test'
    project_dir = os.path.join(new_repo_path, '{{cookiecutter.repo_name}}')
    project_dir_escaped = os.path.join(new_repo_path, '{{cookiecutter.repo_name}}')

    if not os.path.exists(project_dir):
        utils.make_sure_path_exists(project_dir)

    project_dir_escaped = unicode(project_dir)
    project_dir_escaped = project_dir_escaped.replace('{{', '{{ cookiecutter.openbrace }}')
    project_dir_esc

# Generated at 2022-06-21 10:51:36.729030
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the correct directory."""
    temp_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    )
    expected = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    actual = find_template(temp_dir)
    assert actual == expected

    try:
        find_template(os.path.expanduser('~'))
        assert False
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-21 10:51:42.680131
# Unit test for function find_template
def test_find_template():
    # Test directory
    repo_dir = "{{ cookiecutter.repo_name}}"
    project_template = find_template(repo_dir)
    assert project_template == "{{ cookiecutter.repo_name}}"

# Test the exception