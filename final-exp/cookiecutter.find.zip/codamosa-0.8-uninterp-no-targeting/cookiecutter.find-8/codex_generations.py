

# Generated at 2022-06-21 10:41:51.656764
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:41:56.012828
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    cur_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(cur_dir, '..', '..', 'tests', 'test-data', 'fake-repo')
    find_template(repo_dir)

# Generated at 2022-06-21 10:41:59.686815
# Unit test for function find_template
def test_find_template():
    template = find_template('/Users/me/code/me/cookiecutter-pypackage')
    assert template == '/Users/me/code/me/cookiecutter-pypackage/{{cookiecutter.package_name}}'

find_template()

# Generated at 2022-06-21 10:42:06.941002
# Unit test for function find_template
def test_find_template():
    """Verify template detection."""
    import json

    import pytest
    import tempfile
    from cookiecutter.main import cookiecutter
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a cookiecutter styled temporary directory
    temp_dir = tempfile.mkdtemp()
    output = cookiecutter(
        'tests/test-generate-files/project_template',
        extra_context={'repo_name': 'my-repo-name'},
        no_input=True,
        checkout=None,
        reuse_dir=True,
        overwrite_if_exists=True,
        output_dir=temp_dir,
        config_file=None
    )
    # Determine the project template from the temporary directory
    project_template = find_template(output)
   

# Generated at 2022-06-21 10:42:08.472234
# Unit test for function find_template
def test_find_template():
    find_template("/home/safia/Cookiecutter/cookiecutter" )

# Generated at 2022-06-21 10:42:09.161468
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:42:15.334661
# Unit test for function find_template
def test_find_template():
    """Test if find_template() works properly."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                            '../tests/fake-repo-pre/'))
    assert find_template(repo_dir) == os.path.join(repo_dir, 'fake_template')



# Generated at 2022-06-21 10:42:23.797967
# Unit test for function find_template
def test_find_template():
    """ Test the find_template function """
    import os
    import shutil
    import tempfile
    template_dir = 'my_template'

    # Create temp dir to do tests
    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 10:42:29.093421
# Unit test for function find_template
def test_find_template():
    repo_dir = 'foo/bar/baz'
    repo_dir_contents = ['xxx', 'cookiecutter-{{project_name}}', 'yyy']
    result = find_template(repo_dir, repo_dir_contents)
    assert result == 'foo/bar/baz/cookiecutter-{{project_name}}'

# Generated at 2022-06-21 10:42:33.599768
# Unit test for function find_template
def test_find_template():
    """Ensure that `find_template` returns the correct value."""
    import os
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter

    repo_dir = None
    try:
        template_dir = tempfile.mkdtemp()
        os.mkdir(os.path.join(template_dir, 'cookiecutter-foobar'))
        repo_dir = cookiecutter(template_dir)
        project_template = find_template(repo_dir)
    finally:
        if repo_dir:
            shutil.rmtree(repo_dir)
        shutil.rmtree(template_dir)


# Generated at 2022-06-21 10:42:37.341475
# Unit test for function find_template
def test_find_template():
    repo_dir = 'examples/git-repo'
    project_template = 'cookiecutter-pypackage'
    assert find_template(repo_dir) == os.path.join(repo_dir, project_template)

# Generated at 2022-06-21 10:42:41.218884
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    assert find_template( 'cookiecutter/tests/test-data/git-repos/multiple-templates') == 'cookiecutter/tests/test-data/git-repos/multiple-templates/{{ cookiecutter.repo_name }}'

# Generated at 2022-06-21 10:42:42.089439
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:42:44.821056
# Unit test for function find_template
def test_find_template():
    fake_repo_dir = '/home/audreyr/fake-repo'
    assert find_template(fake_repo_dir) ==  '/home/audreyr/fake-repo/cookiecutter-pypackage'


# Generated at 2022-06-21 10:42:51.028364
# Unit test for function find_template
def test_find_template():
    """ Unit test for find_template """
    repo_dir = "C:\\Users\\Kartheek\\Documents\\cookiecutters\\cookiecutter-pypackage"
    project_template = "{{cookiecutter.project_name}}"
    project_template = os.path.join(repo_dir, project_template)
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:43:01.829179
# Unit test for function find_template
def test_find_template():
    """Verify `find_template` function."""
    import shutil
    import tempfile
    import textwrap

    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter import utils

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake project template
    project_dir = os.path.join(
        temp_dir,
        DEFAULT_CONFIG['repo_dir'],
        DEFAULT_CONFIG['default_context']['project_slug']
    )
    os.makedirs(project_dir)
    readme = textwrap.dedent("""
        project_name
        =============

        project_name is a short and sweet name for your project.
    """)

# Generated at 2022-06-21 10:43:08.505224
# Unit test for function find_template
def test_find_template():
    repo_dir = 'test/test-repo-tmpl/{{cookiecutter.repo_name}}'
    project_template = find_template(repo_dir)

    # Check that result is a string
    assert isinstance(project_template, str)

    # Check that result is the expected value
    expected_result = 'test/test-repo-tmpl/{{cookiecutter.repo_name}}/{{cookiecutter.project_name}}'
    assert project_template == expected_result


# Generated at 2022-06-21 10:43:09.856662
# Unit test for function find_template
def test_find_template():
    """Verify function find_template works as expected."""
    pass

# Generated at 2022-06-21 10:43:21.472339
# Unit test for function find_template
def test_find_template():
    """Verify `find_template` finds a project template in a mock repo."""
    import tempfile
    from cookiecutter.utils import rmtree

    td = tempfile.mkdtemp()
    logger.debug('Creating a mocked project in %s', td)

    fake_repo = os.path.join(td, "fake-repo")
    os.makedirs(fake_repo)

    fake_project_template = os.path.join(fake_repo, "fake_project_template")
    os.makedirs(fake_project_template)

    os.makedirs(os.path.join(fake_repo, "fake_folder"))

    fake_repo_contents = os.listdir(fake_repo)
    assert "fake_project_template" in fake_repo_contents

# Generated at 2022-06-21 10:43:27.250069
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo', 'cookiecutter-{{cookiecutter.repo_name}}', '')  # noqa
    )
    assert find_template('..\tests\fake-repo') == template_dir

# Generated at 2022-06-21 10:43:33.987806
# Unit test for function find_template
def test_find_template():
    """Tests that function correctly finds template in repo."""

    import tempfile
    import shutil

    # Create a temp directory and change into it.
    # We change into the temp directory so
    # that we can be sure that find_template is
    # finding the repo in the current directory,
    # not in the parent directory.
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Here we create a dummy template called 'custom_template'.
    # We use curly braces in the template name to make sure
    # that they don't interfere with the generation of the
    # actual template directory during --no-input runs.

# Generated at 2022-06-21 10:43:37.108349
# Unit test for function find_template
def test_find_template():
    """Function that tests the find_template function."""
    pass

# Generated at 2022-06-21 10:43:42.407053
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.expanduser('~/.cookiecutters/cookiecutter-pypackage')
    test = find_template(repo_dir)
    assert isinstance(test, str)
    assert 'cookiecutter' in test
    assert '{{' in test
    assert '}}' in test

# End of Unit test for function find_template

# Generated at 2022-06-21 10:43:45.183547
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils.paths import unfrackpath
    assert isinstance(find_template(unfrackpath('tests/fake-repo-pre/')), str)

# Generated at 2022-06-21 10:43:56.063685
# Unit test for function find_template
def test_find_template():
    from tests.test_utils import remove_dir
    from tests.test_utils import workdir
    from tests.test_utils import create_clean_git_repo
    from tests.test_utils import master_branch_template

    cwd = os.getcwd()
    template_dir = os.path.join(cwd, 'test-template')

    with workdir(cwd):
        logger.debug('Creating git repository...')
        repo_dir = create_clean_git_repo()

        with workdir(repo_dir):
            logger.debug('Creating master branch template...')
            master_branch_template(repo_dir)

        with workdir(cwd):
            logger.debug('Cloning git repo to a temporary directory...')

# Generated at 2022-06-21 10:44:01.690295
# Unit test for function find_template
def test_find_template():
    """ Find the project template
    """
    repo_dir = '/home/pyladies/Desktop/Cookiecutter-Pyladies-Project/{{cookiecutter.project_name}}'
    assert find_template(repo_dir) == '/home/pyladies/Desktop/Cookiecutter-Pyladies-Project/{{cookiecutter.project_name}}'

# Generated at 2022-06-21 10:44:05.880593
# Unit test for function find_template
def test_find_template():
    """Quick test of find_template."""
    template_dir = '/tmp/cookiecutter-test/cookiecutter-pypackage'
    assert find_template(repo_dir=template_dir) == template_dir

# Generated at 2022-06-21 10:44:15.328551
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException

    temp_dir = tempfile.mkdtemp()

    os.mkdir(os.path.join(temp_dir, "simple"))
    os.mkdir(os.path.join(temp_dir, "simple", "cookiecutter-simple"))
    os.mkdir(os.path.join(temp_dir, "simple", "cookiecutter-simple.bak"))
    os.mkdir(os.path.join(temp_dir, "simple", "simple_project"))
    os.mkdir(os.path.join(temp_dir, "simple", "cookiecutter-simple-{{cookiecutter.repo_name}}"))

# Generated at 2022-06-21 10:44:21.582515
# Unit test for function find_template
def test_find_template():
    """Testing finding a template.""" 
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'tests/fake-repo-tmpl'))

    project_template = find_template(repo_dir)
    assert "fake-repo-tmpl/{{cookiecutter.repo_name}}" == project_template

# Generated at 2022-06-21 10:44:26.778041
# Unit test for function find_template
def test_find_template():
    """Ensure find_template finds the project template."""
    repo_dir = 'tests/files/fake-repo-tmpl'
    project_template = find_template(repo_dir)

    assert 'tests/files/fake-repo-tmpl/{{cookiecutter.repo_name}}' == project_template



# Generated at 2022-06-21 10:44:36.213822
# Unit test for function find_template
def test_find_template():
    """
    Verify that the function is returning the correct filename in each case

    """
    repo_dir = ''
    file_name = 'cookiecutter-pypackage'
    repo_dir_contents = [
        os.path.join(repo_dir, file_name),
        os.path.join(repo_dir, 'cookiecutter-pypackage-cookiecutter'),
        os.path.join(repo_dir, 'cookiecutter-pypackage-cookiecutter.py')
    ]
    project_template = find_template(repo_dir, repo_dir_contents)
    assert isinstance(project_template, str)
    assert project_template == os.path.join(repo_dir, file_name)



# Generated at 2022-06-21 10:44:36.788007
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:44:37.575279
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-21 10:44:42.680142
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests','fake-repo', '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == 'tests/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:49.415711
# Unit test for function find_template
def test_find_template():
    """
    Test for find_template()

    Test for suggested directory name for project template and
    for a given repository.

    Test for correct suggsted path to project template.
    """
    import tempfile

    repo_dir = tempfile.mkdtemp()
    template_name = 'cookiecutter-{{ cookiecutter.repo_name }}'
    template_path = os.path.join(repo_dir, template_name)

    os.mkdir(template_path)

    assert find_template(repo_dir) == template_path

test_find_template()

# Generated at 2022-06-21 10:44:59.302889
# Unit test for function find_template
def test_find_template():
    _templated_repo_path = os.path.abspath(
        os.path.join(
            'tests',
            'test-repo-pre',
            '{{cookiecutter.repo_name}}'
        )
    )

    _non_templated_repo_path = os.path.abspath(
        os.path.join(
            'tests',
            'test-repo-no-templated-dir'
        )
    )

    assert find_template(_templated_repo_path) == _templated_repo_path
    assert find_template(_non_templated_repo_path)

# Generated at 2022-06-21 10:45:05.085654
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests/fixtures/fake-repo-tmpl/"
    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(repo_dir,
                                             'fake-project-tmpl')

    assert project_template == expected_project_template

# Generated at 2022-06-21 10:45:11.238814
# Unit test for function find_template
def test_find_template():
    """Verify that the correct project template is identified."""
    test_dir = 'tests/files/fake-repo-pre/'
    template = find_template(test_dir)
    assert os.path.basename(template) == 'cookiecutter-pypackage'
    assert template == os.path.join(test_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:45:12.056047
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:16.142239
# Unit test for function find_template
def test_find_template():
    from tests import ROOT_DIR

    # Use the test repo as the repo dir
    repo_dir = os.path.join(ROOT_DIR, 'fake-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:45:20.352141
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:30.518261
# Unit test for function find_template
def test_find_template():
    """Test to make sure the find_template function returns the correct value"""
    repo_dir = "/home/josh/Desktop/cookiecutter-pypackage-min"
    expected = "/home/josh/Desktop/cookiecutter-pypackage-min/{{cookiecutter.repo_name}}"
    repo_dir_contents = os.listdir(repo_dir)
    logger.debug(repo_dir_contents)
    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break
    logger.debug(project_template)
    logger.debug(type(project_template))

# Generated at 2022-06-21 10:45:38.707069
# Unit test for function find_template
def test_find_template():
    repo_dir_list = os.listdir('./tests/fake-repo-pre/')
    for repo_item in repo_dir_list:
        if 'cookiecutter' in repo_item and '{{' in repo_item and '}}' in repo_item:
            project_template = repo_item
            break

    assert(find_template('./tests/fake-repo-pre/') == './tests/fake-repo-pre/' + project_template)

# Generated at 2022-06-21 10:45:48.495924
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    import shutil
    from cookiecutter.utils.paths import ensure_dir
 
    TEST_DIR = os.path.join(
        os.path.expanduser('~'), 'cookiecutter-test-template'
    )
    TEMPLATE_DIR = os.path.join(TEST_DIR, '{{cookiecutter.project_name}}')
    ensure_dir(TEMPLATE_DIR)

    try:
        assert find_template(TEST_DIR) == TEMPLATE_DIR
    finally:
        shutil.rmtree(TEST_DIR)

# Generated at 2022-06-21 10:45:52.510992
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template

    """
    logger.info('Running test_find_template')
    find_template('/Users/user/dev/bootcamp/cookiecutter-project') == 'TODO'

# Generated at 2022-06-21 10:46:04.384288
# Unit test for function find_template
def test_find_template():
    """Test function for finding a Cookiecutter project template."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    repo_dir = repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..', '..', 'tests', 'test-repos', 'local-repository',
        )
    )
    result = cookiecutter(repo_dir, no_input=True)
    rmtree(result[1])
    # Find the project template
    project_template = find_template(result[0])
    # Assert that the project template found is the same as the repo_dir
    assert project_template == repo_dir


# Generated at 2022-06-21 10:46:13.041102
# Unit test for function find_template
def test_find_template():
    """Test the find_template function given a sample project template."""
    test_repo = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-input-project-repo'
    )
    
    test_template = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-input-project-repo',
        '{{cookiecutter.repo_name}}'
    )
    
    assert find_template(test_repo) == test_template

# Generated at 2022-06-21 10:46:20.104687
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template` works correctly."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-fake-repo'
    )
    project_template = find_template(repo_dir)

    assert (
        project_template ==
        os.path.join(repo_dir, 'cookiecutter-pypackage')
    )

# Generated at 2022-06-21 10:46:23.535305
# Unit test for function find_template
def test_find_template():
    """Test whether find_template returns an existing directory."""
    if os.path.exists(find_template("tests/fake-repo/")) == True:
        pass

# Generated at 2022-06-21 10:46:31.218889
# Unit test for function find_template
def test_find_template():
    """
    Define a test directory and test_files and check if function finds the
    tempalate
    """
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_dir',
        'find_template'
    )
    test_files = [
        '{{cookiecutter.project_slug}}',
        'other_file',
        'third_file',
        '{{cookiecutter.other}}'
    ]
    for test_file in test_files:
        os.mkdir(os.path.join(test_dir, test_file))

    template = find_template(test_dir)


# Generated at 2022-06-21 10:46:48.109209
# Unit test for function find_template
def test_find_template():
    """ Test if find_template function can find template "{{cookiecutter.template}}" from current directory """
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import join
    import sys

    print("Running find_template test:", end='')
    test_dir = mkdtemp()
    try:
        template_dir = join(test_dir, "{{cookiecutter.template}}")
        os.makedirs(template_dir)

        assert find_template(test_dir) == template_dir
        print("OK")
    except:
        print("Fail")
        raise
    finally:
        rmtree(test_dir)


test_find_template()

# Generated at 2022-06-21 10:46:53.926782
# Unit test for function find_template
def test_find_template():
    """Test find_template() for finding the template directory."""
    template = find_template('tests/fake-repo-pre/')
    assert template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:46:56.762828
# Unit test for function find_template
def test_find_template():
    assert find_template("../cookiecutter-pypackage") == "../cookiecutter-pypackage/{{cookiecutter.repo_name}}"

# Generated at 2022-06-21 10:47:02.552821
# Unit test for function find_template
def test_find_template():
    os.mkdir('tests/fake-repo')
    os.mkdir('tests/fake-repo/{{cookiecutter.repo_name}}')
    assert find_template('tests/fake-repo') == 'tests/fake-repo/{{cookiecutter.repo_name}}'
    logger.debug('test_find_template passed.')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:47:11.044053
# Unit test for function find_template
def test_find_template():
    """Verify the expected project template is found."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..',
        '..',
        'tests',
        'test-repo-tmpl',
        '{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:47:17.828355
# Unit test for function find_template
def test_find_template():
    """Simple unit test for function find_template."""

    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'tests', 'test-find-template'
    )
    template = find_template(repo_dir)
    expected_template = os.path.join(repo_dir, 'cookiecutter-pypackage')

    assert template == expected_template

# Generated at 2022-06-21 10:47:25.465656
# Unit test for function find_template
def test_find_template():
    assert find_template("tests/fake-repo-pre/") == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    try:
        find_template("tests/fake-repo-post")
    except NonTemplatedInputDirException as e:
        assert 1
    assert find_template("tests/fake-repo-post/") == 'tests/fake-repo-post/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-21 10:47:28.984819
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.expanduser("~"),
        'code/cookiecutter-pypackage-minimal'
    )

    project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:47:41.010788
# Unit test for function find_template
def test_find_template():
    """
    Unit test for find_template()
    """
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create subdirectory within it
    sub_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(sub_dir)

    # Create a file within it
    fh = open(os.path.join(sub_dir, 'somefile.txt'), 'w')
    fh.write('This is a test file')
    fh.close()

    # Test that find_template correctly finds sub_dir
    assert find_template(temp_dir) == sub_dir

    # Clean up
    shutil.rmtree(temp_dir)


# Generated at 2022-06-21 10:47:47.017572
# Unit test for function find_template
def test_find_template():
    """Verify that a directory with the expected structure yields a valid result."""
    test_root = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test_find_template')
    cwd = os.getcwd()
    
    os.chdir(test_root)
    expected = '{{cookiecutter.repo_name}}'
    actual = find_template('.')
    os.chdir(cwd)
    
    assert expected == actual, "The find_template function did not identify the template correctly."
        

# Generated at 2022-06-21 10:48:05.072028
# Unit test for function find_template
def test_find_template():
    test_template_dir = os.path.join(
        os.path.abspath(
            os.path.dirname(
                __file__
            )
        ),
        'test-template'
    )
    test_output = find_template(test_template_dir)
    assert test_output == 'test-template'

# Generated at 2022-06-21 10:48:11.953859
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    from cookiecutter.utils.paths import normalize_path

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    tmp_repo = tempfile.mkdtemp(dir=tmp_dir)

    # Create two identical subdirectories
    first_subdir = 'foo-{{cookiecutter.repo_name}}'
    second_subdir = 'bar-{{cookiecutter.repo_name}}'

    os.makedirs(os.path.join(tmp_repo, first_subdir))
    os.makedirs(os.path.join(tmp_repo, second_subdir))

    # Test with normal path separators
    first_subdir_found = find_template(tmp_repo)
    second_subdir_found

# Generated at 2022-06-21 10:48:13.971782
# Unit test for function find_template
def test_find_template():
    """
    Test function find_template
    """
    repo_dir = os.path.dirname(__file__)
    repo_dir = os.path.abspath(os.path.join(repo_dir, 'tests', 'test-input', 'fake-repo-tmpl'))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:48:14.645737
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:48:17.016356
# Unit test for function find_template
def test_find_template():
    repo_dir = 'content'
    assert find_template(repo_dir) == 'content/cookiecutter-pypackage'

# Generated at 2022-06-21 10:48:21.496744
# Unit test for function find_template
def test_find_template():
    """Test if the find_template function works as expected."""
    repo_dir = 'tests/test-repo'
    project_template = find_template(repo_dir)
    exp = 'tests/test-repo/{{cookiecutter.repo_name}}/'
    assert project_template == exp

# Generated at 2022-06-21 10:48:22.620962
# Unit test for function find_template
def test_find_template():
    """Verify we can locate a template."""
    pass

# Generated at 2022-06-21 10:48:27.489836
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = 'tests/fake-repo/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:48:28.323580
# Unit test for function find_template
def test_find_template():
    # TODO
    pass



# Generated at 2022-06-21 10:48:35.614546
# Unit test for function find_template
def test_find_template():
    """Test the find_template function located in the repo module.

    This function returns a relative path to the directory that holds the project
    template. This test ensures that this relative path is correct.
    """
    from cookiecutter import repo

    test_dir = 'Tests/test-find-template'
    assert repo.find_template(test_dir) == os.path.join(test_dir, 'fake-project')

# Generated at 2022-06-21 10:49:11.380158
# Unit test for function find_template
def test_find_template():
    """Test if tempalte found when it should be and not found when it shouldn't"""

    repo_dir = 'tests/fake-repo-pre/'
    assert find_template(repo_dir) == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    repo_dir = 'tests/fake-repo-post'
    assert find_template(repo_dir) == 'tests/fake-repo-post/{{cookiecutter.repo_name}}'

    repo_dir = 'tests/fake-repo-no-template'
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False


# Generated at 2022-06-21 10:49:21.108333
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils.paths import normalize_path

    normalize_path()

    out_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    template_dir = find_template(os.path.normpath(out_dir))
    expected_template_dir = os.path.normpath(
        'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    )
    assert template_dir == expected_template_dir

    os.remove('tests/fake-repo-tmpl/fake-repo-name-3fd5d94/foobar.txt')
    os.rmdir

# Generated at 2022-06-21 10:49:29.870073
# Unit test for function find_template
def test_find_template():
    """Verify function find_template() works as expected."""

    def mock(listdir=[]):
        os.listdir = lambda *args: listdir

    # Check that an exception is raised when no template is found
    mock()
    try:
        find_template('.')
        assert False
    except NonTemplatedInputDirException:
        pass

    # Check that the non templated directory isn't returned
    mock(['foo', 'bar', 'cookiecutter.json'])
    assert find_template('.') == 'cookiecutter.json'

    # Check that a directory containing 'cookiecutter' but not '{{' or '}}'
    # isn't returned
    mock(['foo', 'bar', 'cookiecutter.json'])
    assert find_template('.') == 'cookiecutter.json'

# Generated at 2022-06-21 10:49:32.460570
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-pypackage')


# Generated at 2022-06-21 10:49:43.154071
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory"""
    from shutil import copytree
    from os.path import exists, realpath, join

    from . import main, utils

    tmp_dir_name = utils.make_tmp_dir()
    test_repo_dir = join(tmp_dir_name, 'test_repo')
    test_project_template_dir = join(
        test_repo_dir,
        '{{cookiecutter.repo_name}}'
    )
    os.makedirs(test_project_template_dir)
    assert exists(test_project_template_dir)
    assert find_template(test_repo_dir) == realpath(test_project_template_dir)

# Generated at 2022-06-21 10:49:47.810130
# Unit test for function find_template
def test_find_template():
    assert find_template('templates/test_template-{{cookiecutter.repo_name}}') == 'templates/test_template-{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:49:53.901023
# Unit test for function find_template
def test_find_template():
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    test_input_dir = os.path.join(root_dir, 'tests', 'fake-repo-pre', 'cookiecutter-pypackage')
    assert find_template(test_input_dir) == os.path.join(test_input_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:50:00.410105
# Unit test for function find_template
def test_find_template():
    import tempfile

    os.chdir(tempfile.mkdtemp())
    os.mkdir('my_repo')
    os.mkdir('my_repo/{{cookiecutter.repo_name}}')
    os.mkdir('my_repo/foo')

    assert find_template('my_repo') == 'my_repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:50:01.288898
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:50:04.329942
# Unit test for function find_template
def test_find_template():
    find_template("C:\\Users\\C00179113\\Documents\\GitHub\\cookiecutter-simple-project\\simple-project")

# Generated at 2022-06-21 10:51:07.491680
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    from tests.test_finders import TESTS_DIR
    repo_dir = os.path.join(TESTS_DIR, 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template

# Generated at 2022-06-21 10:51:19.367496
# Unit test for function find_template
def test_find_template():
    """Test that find_template works as expected."""
    from cookiecutter.repository import find_template
    from cookiecutter.exceptions import NonTemplatedInputDirException

    try:
        find_template('/Users/audreyr/code/cookiecutter-pypackage/')
    except NonTemplatedInputDirException:
        assert False, 'find_template raised NonTemplatedInputDirException'

    try:
        find_template('tests/test-repos/fake-repo-tmpl')
    except NonTemplatedInputDirException:
        assert False, 'find_template raised NonTemplatedInputDirException'

if __name__ == '__main__':
    logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.DEBUG)
    test

# Generated at 2022-06-21 10:51:29.237395
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.expanduser('~/'), 'my-repo')
    os.mkdir(repo_dir)
    project_template_name = 'cookiecutter-{{cookiecutter.project_name}}'
    project_template_dir = os.path.join(repo_dir, project_template_name)
    os.mkdir(project_template_dir)

    # Unit test function
    template = find_template(repo_dir)

    # Clean up
    os.rmdir(project_template_dir)
    os.rmdir(repo_dir)

    return template == os.path.join(repo_dir, project_template_name)

# Generated at 2022-06-21 10:51:31.438493
# Unit test for function find_template
def test_find_template():
	repo_dir = os.path.abspath('/tmp/cookiecutter-jQuery-plugin')
	assert find_template(repo_dir) == repo_dir

# Generated at 2022-06-21 10:51:33.509731
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:51:37.107201
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__), 'fake-repo', 'tests', 'test-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:51:47.070723
# Unit test for function find_template
def test_find_template():
    """Checks find_template function for proper return value."""
    from pytest import raises
    from cookiecutter.utils import rmtree
    from tests.test_utils import TEST_TEMPLATE_DIR

    # Test when input_dir is a non-templated directory
    tmp_dir = TEST_TEMPLATE_DIR + '__pytest__'
    os.makedirs(tmp_dir)
    test_file = os.path.join(tmp_dir, 'test.txt')
    with open(test_file, 'w') as f:
        f.write('test')
    with raises(NonTemplatedInputDirException):
        find_template(tmp_dir)
    rmtree(tmp_dir, ignore_errors=True)

# Generated at 2022-06-21 10:51:49.109274
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'