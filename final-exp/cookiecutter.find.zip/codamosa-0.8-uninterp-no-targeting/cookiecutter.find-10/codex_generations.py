

# Generated at 2022-06-21 10:41:56.067786
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '../tests/fake-repo-tmpl')

    project_template = find_template(repo_dir)
    assert 'fake-repo-tmpl/{{cookiecutter.repo_name}}' == project_template

# Generated at 2022-06-21 10:41:59.691919
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    try:
        find_template('tests/fake-repo-pre/non-templated')
    except NonTemplatedInputDirException:
        find_template('tests/fake-repo-pre/detault')

# Generated at 2022-06-21 10:42:06.943429
# Unit test for function find_template
def test_find_template():
    """Verify the directory to be used as a Cookiecutter template is correctly
    identified.
    """
    # Test a repo with a single directory.
    repo_dir = 'tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    # Test a repo with a single directory.
    repo_dir = 'tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    # Test a repo with two directories, one of which is a template.

# Generated at 2022-06-21 10:42:13.364935
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test_find_template'
    )
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    actual = find_template(repo_dir)
    assert actual == expected

# Generated at 2022-06-21 10:42:19.797866
# Unit test for function find_template
def test_find_template():
    """
    Find a directory with "{{cookiecutter.repo_name}}" in its name.
    """

    template_dir = '/tmp/does_not_exist'
    os.makedirs(template_dir)
    template = '{{cookiecutter.repo_name}}'
    os.mkdir(os.path.join(template_dir, template))

    assert find_template(template_dir) == os.path.join(template_dir, template)

# Generated at 2022-06-21 10:42:23.931544
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/projects/cookiecutter-pypackage/'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:24.781310
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function."""
    pass

# Generated at 2022-06-21 10:42:36.950975
# Unit test for function find_template
def test_find_template():
    # Create test dir
    testdir = tmpdir.mkdir('template')
    # Create fake cookiecutter.json file
    touch(testdir.join('cookiecutter.json'))
    # Create fake project dir
    testdir.mkdir('project_dir')
    # Create fake project dir that is a cookiecutter template
    testdir.mkdir('project_dir_templated')
    touch(testdir.join('project_dir_templated/cookiecutter.json'))
    # Create fake project dir that is a cookiecutter template
    # with jinja variables
    testdir.mkdir('project_dir_templated_with_jinja')
    touch(testdir.join('project_dir_templated_with_jinja/cookiecutter.json'))

# Generated at 2022-06-21 10:42:39.747892
# Unit test for function find_template
def test_find_template():
    template = find_template("/Users/mikaelkall/Development/python/cookiecutter-django")
    print("template = " + template)

test_find_template()

# Generated at 2022-06-21 10:42:45.509791
# Unit test for function find_template
def test_find_template():
    """Verify ``find_template`` finds the project template."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write('')

    project_template = find_template(repo_dir)

    assert os.path.basename(project_template) == 'cookiecutter.json'

    shutil.rmtree(repo_dir)

# Generated at 2022-06-21 10:42:53.340602
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template`."""
    from cookiecutter.compat import TemporaryDirectory

    expected_template_dir = os.path.join(
        'tests/files/foobar-cookiecutter',
        '{{cookiecutter.repo_name}}-cookiecutter'
    )

    with TemporaryDirectory() as tmpdir:
        tmpdir = os.path.abspath(tmpdir)
        template_dir = find_template(tmpdir)

    assert(expected_template_dir == template_dir)

# Generated at 2022-06-21 10:42:57.839083
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(test_dir, 'fake-repo-pre-gen')
    template = find_template(path)
    assert template == os.path.join(path, 'cookiecutter-pypackage'), template

# Generated at 2022-06-21 10:43:05.679912
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    template = 'tests/test-cookiecutter-template/'
    output_dir = 'foobar'

    logger.debug('Running end-to-end test of find_template')

    main.cookiecutter(template, no_input=True, output_dir=output_dir)
    repo_dir_contents = os.listdir(output_dir)

    try:
        assert len(repo_dir_contents) == 1
        assert os.path.exists(os.path.join(output_dir, repo_dir_contents[0]))
    finally:
        rmtree(output_dir)

# Generated at 2022-06-21 10:43:17.153294
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct path for project template."""
    import tempfile
    from cookiecutter import utils
    import pytest

    # Create a temp directory and cd into it.
    with utils.work_in(tempfile.mkdtemp()):
        # Create some dummy directories
        os.mkdir('cookiecutter-pellmell')
        os.mkdir('cookiecutter-dictionary')
        os.mkdir('cookiecutter')

        # Create some dummy files
        path = 'cookiecutter-{{cookiecutter.repo_name}}'
        utils.make_readme(path)

        assert find_template('.') == os.path.join('.', path)

        os.remove('README.rst')
        os.remove(path)


# Generated at 2022-06-21 10:43:18.159114
# Unit test for function find_template
def test_find_template():
    assert find_template('abc') is None

# Generated at 2022-06-21 10:43:21.979529
# Unit test for function find_template
def test_find_template():
    """Function to test find_template()"""
    assert find_template('repo_dir') == 'repo_dir/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:32.268252
# Unit test for function find_template
def test_find_template():
    """Make sure that a Cookiecutter project template is found."""
    import tempfile
    import shutil
    import cookiecutter.utils as utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()
    utils.make_sure_path_exists(repo_dir)


# Generated at 2022-06-21 10:43:44.186552
# Unit test for function find_template
def test_find_template():
    """Verify ``find_template`` is finding the correct directory name."""
    import os
    import tempfile

    temp_directory = tempfile.mkdtemp()


# Generated at 2022-06-21 10:43:48.811252
# Unit test for function find_template
def test_find_template():
    """Verify find_template method returns correct template folder.

    This uses the repo at git@github.com:audreyr/cookiecutter-pypackage.git.
    It must be reachable from your current git remote. You must have commit
    rights to this repo for the test to pass.
    """
    repo_dir = '~/code/cookiecutter-pypackage'
    project_template = 'pypackage'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:43:49.808830
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-21 10:43:58.236721
# Unit test for function find_template
def test_find_template():
    """Verify find_template correctly finds the project template."""
    from shutil import copytree, rmtree
    from tempfile import mkdtemp

    from .environment import TEST_COOKIECUTTER_REPO

    repo_dir = mkdtemp()
    copytree(TEST_COOKIECUTTER_REPO, repo_dir)

    tmpl_dir = find_template(repo_dir)

    assert '{{' in tmpl_dir
    assert '}}' in tmpl_dir

    rmtree(repo_dir)


# Generated at 2022-06-21 10:44:09.719137
# Unit test for function find_template
def test_find_template():
    print('Testing find_template')

    # Set up
    import os
    import shutil
    import tempfile

    # Set up a temporary directory
    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.mkdir(repo_dir)
    os.mkdir(os.path.join(repo_dir, 'not-the-project-template'))
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    # Test
    result = find_template(repo_dir)

    # Assert
    expected_result = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert result == expected_

# Generated at 2022-06-21 10:44:18.231784
# Unit test for function find_template
def test_find_template():
    """
    Test for the find_template function.

    Function takes in a directory and returns the location of the template in
    that directory.
    """
    assert find_template('/home/brian/dev/cookiecutter/tests/fake-repo-tmpl') == '/home/brian/dev/cookiecutter/tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template('/home/brian/dev/cookiecutter/tests/fake-repo-pre') == '/home/brian/dev/cookiecutter/tests/fake-repo-pre/my-fake-project'

# Generated at 2022-06-21 10:44:28.713870
# Unit test for function find_template
def test_find_template():
    """Test for `find_template` function."""
    template_name = 'cookiecutter-pypackage'
    regex_match = '{{([^}]+)}}'
    template_dir = os.path.join(os.getcwd(), 'tests/files', template_name)
    project_template = find_template(template_dir)

    # Make sure the template's name is what we expected.
    assert os.path.basename(project_template) == template_name

    with open(project_template, 'r') as fh:
        text = fh.read()

    # Make sure that the template's text has a Jinja var.
    assert regex_match in text

# Generated at 2022-06-21 10:44:34.698756
# Unit test for function find_template
def test_find_template():
    repo_url = "https://github.com/audreyr/cookiecutter-pypackage.git"
    checkout = 'develop'
    clone_to_dir = 'tests/fake-repo-tmpl/'
    logger.debug(clone_to_dir)
    repo_dir = (
        'tests/fake-repo-tmpl/tests/fake-repo-tmpl/'
        'cookiecutter-pypackage/'
    )

    assert find_template(repo_dir) == (
        repo_dir + "cookiecutter-pypackage/{{cookiecutter.repo_name}}"
    )

# Generated at 2022-06-21 10:44:40.819534
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    subdir = os.path.join(os.path.dirname(__file__), '..', 'tests/fake-repo-tmpl')
    out = find_template(subdir)
    assert out == subdir + '/cookiecutter-pypackage'

# Generated at 2022-06-21 10:44:49.507174
# Unit test for function find_template
def test_find_template():
    """
    Test function for find_template
    """
    test_dir = './tests/fake-repo-tmpl'
    try:
        find_template(test_dir)
    except NonTemplatedInputDirException as e:
        assert True
    else:
        print("find_template failed: NonTemplatedInputDirException not raised")
        assert False
    another_test_dir = './tests/fake-repo-pre'
    try:
        find_template(another_test_dir)
    except NonTemplatedInputDirException as e:
        assert False
    else:
        assert True

# Uncomment below to run unit test.
#test_find_template()

# Generated at 2022-06-21 10:44:57.348596
# Unit test for function find_template
def test_find_template():
    path = os.path.abspath(os.path.dirname(__file__))
    examples_path = os.path.join(path, '..', 'tests', 'examples')
    local_checkout = os.path.join(examples_path, 'local-checkout')
    project_template = find_template(local_checkout)

    assert 'cookiecutter-pypackage' in project_template
    assert '{{cookiecutter.project_name}}' in project_template

# Generated at 2022-06-21 10:45:02.121755
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path for the template."""
    template_name = find_template('tests/test-repo-pre/')
    assert template_name == 'tests/test-repo-pre/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-21 10:45:07.358339
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:45:21.899464
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    import uuid
    import shutil
    import tempfile

    # Make a temporary directory to do stuff in
    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'repo_dir_contents'))
    os.makedirs(os.path.join(repo_dir, 'repo_dir_contents', 'cookiecutter-{{ cookiecutter.foo }}'))
    os.makedirs(os.path.join(repo_dir, 'repo_dir_contents', 'cookiecutter-{{ cookiecutter.foo }}', 'cookiecutter'))

# Generated at 2022-06-21 10:45:31.921787
# Unit test for function find_template
def test_find_template():
    """A unit test for ``find_template``."""

    # Tree structure for testing:
    #
    # cookiecutter_demo_repo
    # |-- cookiecutter.json
    # |-- {{cookiecutter.project_name}}
    # |   |-- README.rst
    # |   |-- LICENSE
    # |   |-- foo
    # |   |   |-- bar
    # |   |   |   |-- baz
    # |   |   |   |   |-- setup.py
    # |   |   |   |-- qux
    # |   |   |   |   |-- Makefile
    # |   |   |-- setup.py
    # |   |-- hello_world
    # |   |   |-- {{cookiecutter.python_package}}
    # |   |   |   |-- main.py
    #

# Generated at 2022-06-21 10:45:37.916291
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct relative path."""
    # FIXME: this needs to be fixed
    assert find_template('tests/fake-repo-pre/') == \
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:45:42.486042
# Unit test for function find_template
def test_find_template():
    """If the `repo_dir` is correctly provided, a valid project template
    should be found."""
    # TODO: Find a way to mock this
    repo_dir = os.path.abspath(os.path.join(
                os.path.dirname(__file__), 'templates', 'fake-repo-pre'))
    template = find_template(repo_dir)
    assert os.path.exists(template)

# Generated at 2022-06-21 10:45:50.468230
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find the template in a local repo."""
    from cookiecutter import utils

    test_input_path = os.path.join(
        utils.WORKING_DIR,
        'tests/test-input/non-templated-input-dir'
    )

    utils.make_sure_path_exists(test_input_path)

    test_repo_dir = os.path.join(test_input_path, 'test-repo')
    project_template = os.path.join(test_repo_dir, 'project_template')

    utils.make_sure_path_exists(project_template)

    assert find_template(test_repo_dir) == project_template



# Generated at 2022-06-21 10:45:56.232819
# Unit test for function find_template
def test_find_template():
    """Verifies that the find_template function can find the templates.

    In order to run this test successfully, the project structure must be
    identical to cookiecutter-pypackage.
    """

    repo_dir = '/home/audreyr/cookiecutter-pypackage/cookiecutter-pypackage'
    project_template = find_template(repo_dir)

    assert project_template == '/home/audreyr/cookiecutter-pypackage/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:45:57.446014
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:59.119937
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    find_template('.')



# Generated at 2022-06-21 10:46:06.972157
# Unit test for function find_template
def test_find_template():
    temp_repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-repo'))

    assert find_template(temp_repo_dir) == os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-repo',
        '{{cookiecutter.repo_name}}'))



# Generated at 2022-06-21 10:46:07.602040
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:46:14.234484
# Unit test for function find_template
def test_find_template():
    templates = [
        'cookiecutter-pypackage',
        'cookiecutter-django/',
        'cookiecutter-pyvows',
        'cookiecutter-pymodule',
        'cookiecutter-tryton'
    ]

    for tmpl in templates:
        assert find_template(tmpl) == tmpl

# Generated at 2022-06-21 10:46:21.869357
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'tests/fake-repo-tmpl')
    assert find_template(repo_dir) == repo_dir + '/fake-project-tmpl'

    repo_dir = os.path.join(os.path.dirname(__file__), 'tests/fake-repo-pre')
    assert find_template(repo_dir) == repo_dir + '/fake-project-pre'

# Generated at 2022-06-21 10:46:24.071679
# Unit test for function find_template
def test_find_template():
    """Tests find_template function."""
    os.path.exists("cookiecutter") == True

# Generated at 2022-06-21 10:46:27.900169
# Unit test for function find_template
def test_find_template():
    """
    Tests the find_template function.

    Returns:
        None

    """
    template_dir = os.path.abspath('tests/test-template')
    result_dir = find_template(template_dir)
    assert result_dir.endswith('tests/test-template/project_template')

# Generated at 2022-06-21 10:46:38.829368
# Unit test for function find_template
def test_find_template():
    """Test function to find template from a repository"""
    from cookiecutter.utils import rmtree
    import shutil
    # Testing find template from a github repository
    repo_dir = r'https://github.com/audreyr/cookiecutter-pypackage'
    template = find_template(repo_dir)
    assert "cookiecutter-pypackage/{{cookiecutter.repo_name" in template, "Error"

    # Testing find template from a local repository
    repo_dir = "tests/test-repo/{{cookiecutter.repo_name}}-1/"
    template = find_template(repo_dir)

# Generated at 2022-06-21 10:46:44.191850
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'files', 'cookiecutters_dir')
    assert find_template(repo_dir) == os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-21 10:46:53.000593
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter Dir can be found by find_template method"""
    from cookiecutter import main
    from cookiecutter.utils import rmtree
    from tempfile import mkdtemp

    # Create a temporary directory to store our dummy Cookiecutter template in
    temp_dir = mkdtemp()

    # Clone the dummy repo into a directory
    main.cookiecutter('tests/test-cookiecutter-template/', no_input=True, output_dir=temp_dir)

    new_dir = os.listdir(temp_dir)[0]
    new_dir = os.path.join(temp_dir, new_dir)
    # Make sure the template directory was created properly
    assert os.path.isdir(new_dir)

    template_dir = find_template(new_dir)

    assert template_dir == new

# Generated at 2022-06-21 10:46:59.820105
# Unit test for function find_template
def test_find_template():
    # Test a template folder with an underscore at the beginning.
    repo_dir = '/tmp/tests/great_project_name'
    os.makedirs(repo_dir)
    os.makedirs(os.path.join(repo_dir, '_my_template'))

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '_my_template')

# Generated at 2022-06-21 10:47:07.106003
# Unit test for function find_template
def test_find_template():
    # This is a vanilla Cookiecutter template
    template_path = find_template('tests/test-templates/test-template1')
    assert 'tests/test-templates/test-template1' in template_path
    assert 'cookiecutter' in template_path
    assert '{{' in template_path
    assert '}}' in template_path

    # The template name has a dash in it
    template_path = find_template('tests/test-templates/test-template3')
    assert 'tests/test-templates/test-template3' in template_path
    assert 'cookiecutter' in template_path
    assert '{{' in template_path
    assert '}}' in template_path

    # This template has a nested directory in it.

# Generated at 2022-06-21 10:47:16.986456
# Unit test for function find_template
def test_find_template():
    """Test function for find_template."""
    from cookiecutter import main
    from .utils import temp_chdir
    from .utils import make_sure_path_exists
    from .tests import USER_CONFIG

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, 'test-project-{{cookiecutter.repo_name}}')
    make_sure_path_exists(template_dir)

    with temp_chdir(repo_dir):
        main.cookiecutter(
            '.',
            no_input=True,
            user_config_path=USER_CONFIG
        )

# Generated at 2022-06-21 10:47:27.479671
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo/'
    result = find_template(repo_dir)
    correct_result = 'tests/fake-repo/{{cookiecutter.project_name}}'
    assert result == correct_result

# Generated at 2022-06-21 10:47:38.712461
# Unit test for function find_template
def test_find_template():
    from tempfile import mkdtemp
    from shutil import rmtree

    # Create a dummy templated repo
    full_temp_path = mkdtemp()
    os.makedirs(os.path.join(full_temp_path, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(full_temp_path, '{{cookiecutter.repo_name2}}'))
    os.makedirs(os.path.join(full_temp_path, 'unwanted1'))
    os.makedirs(os.path.join(full_temp_path, 'unwanted2'))

    template = find_template(full_temp_path)

# Generated at 2022-06-21 10:47:45.527020
# Unit test for function find_template
def test_find_template():
    """Verify find_template finds project template."""
    import tempfile
    from cookiecutter.utils import work_in

    repo_dir = tempfile.mkdtemp()
    with work_in(repo_dir):
        os.makedirs('cookiecutter-pypackage/{{cookiecutter.repo_name}}')
        template = find_template(repo_dir)

    assert template == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    os.remove(template)

# Generated at 2022-06-21 10:47:47.464685
# Unit test for function find_template
def test_find_template():
    assert find_template('fixtures') == 'fixtures/{{cookiecutter.repo_name}}'


# Generated at 2022-06-21 10:47:49.105326
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns a valid path."""


# Generated at 2022-06-21 10:47:55.883560
# Unit test for function find_template
def test_find_template():
    """Check that find_template function works properly."""
    test_repo_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_find_template'
    )
    correct_answer = os.path.join(test_repo_path, 'cookiecutter-pypackage')
    assert find_template(test_repo_path) == correct_answer
    assert os.path.exists(correct_answer)


# Generated at 2022-06-21 10:48:02.368126
# Unit test for function find_template
def test_find_template():
    import tempfile
    repo_dir = tempfile.mkdtemp()
    with open(os.path.join(repo_dir, 'cookiecutter-templates/test-template.txt'), 'w') as file:
        file.write('test')
    result = find_template(repo_dir)
    assert result == os.path.join(repo_dir, 'cookiecutter-templates')


# Generated at 2022-06-21 10:48:10.398944
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import shutil
    import tempfile

    dir_name = tempfile.mkdtemp()

    f = open('{0}/cookiecutter.zip'.format(dir_name), 'w')
    f.close()

    f = open('{0}/cookiecutter.tgz'.format(dir_name), 'w')
    f.close()

    os.makedirs('{0}/cookiecutter-cool-project'.format(dir_name))
    project_template = find_template(dir_name)
    assert project_template == '{0}/cookiecutter-cool-project'.format(dir_name)

    shutil.rmtree(dir_name)

# Generated at 2022-06-21 10:48:19.886712
# Unit test for function find_template
def test_find_template():
    """
    For Cookiecutter to function correctly, the template repository
    must have a directory whose name is rendered correctly with the
    default context. That directory is called the project template
    directory. This test makes sure that we can find it.
    """
    from tests.test_repos import cookiecutter_py_template
    from cookiecutter.utils import rmtree

    try:
        template_dir = find_template(cookiecutter_py_template)
        assert template_dir == cookiecutter_py_template + '/cookiecutter-pypackage'
    finally:
        rmtree(cookiecutter_py_template)

# Generated at 2022-06-21 10:48:22.673396
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-data/fake-repo/') == 'tests/test-data/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:48:39.090974
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-output/fake-repo'
    expected = 'tests/test-output/fake-repo/fake-repo-{{cookiecutter.repo_name}}'
    actual = find_template(repo_dir)
    assert expected == actual


# Generated at 2022-06-21 10:48:50.114208
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter finds project template correctly."""
    project_dir = os.path.abspath(os.path.dirname(__file__))
    output_dir = os.path.join(
        project_dir, os.pardir, 'tests', 'test-output', 'find-template'
    )
    try:
        os.makedirs(output_dir)
    except OSError:
        # directory already exists
        pass

    repo_dir = os.path.join(output_dir, 'fake-repo-tmpl')
    os.makedirs(repo_dir)
    tmpl_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(tmpl_dir)

# Generated at 2022-06-21 10:48:57.349989
# Unit test for function find_template
def test_find_template():
    """Verify normal behaviour of find_template()."""
    import tempfile

    # inside the temporary directory, create a directory for the repo,
    # and create a subdirectory that looks like a non-templated project
    with tempfile.TemporaryDirectory() as tmpdir:
        repo_dir = tempfile.mkdtemp(dir=tmpdir)
        non_temp_dir = os.path.join(repo_dir, 'my_project')
        os.mkdir(non_temp_dir)

        # now create a subdirectory that looks like a templated project
        temp_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
        os.mkdir(temp_dir)

        # now check that find_template() returns the expected value

# Generated at 2022-06-21 10:49:05.978952
# Unit test for function find_template
def test_find_template():
    """Return template path given existing directory path."""
    repo_dir_contents = os.listdir('tests/fake-repo-tmpl')
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break
    template_path = os.path.abspath(os.path.join('tests/fake-repo-tmpl', item))
    assert(template_path == find_template('tests/fake-repo-tmpl'))
    print(find_template('tests/fake-repo-tmpl'))

# Generated at 2022-06-21 10:49:11.195559
# Unit test for function find_template
def test_find_template():
    """ Check the return value of find_template when used with template_repo. """
    expected_project_template_dir = os.path.join(os.getcwd(),'cookiecutter-pypackage')
    actual_project_template_dir = find_template(os.getcwd())
    assert expected_project_template_dir == actual_project_template_dir

# Generated at 2022-06-21 10:49:20.866961
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter

    # Create a temporary directory to store the cloned repo
    temp_repo_dir = tempfile.mkdtemp()

    # Create a "fake" project repo that Cookiecutter will clone
    project_dir = 'tests/fake-repo'
    project_repo_dir = cookiecutter(project_dir, output_dir=temp_repo_dir)

    assert os.path.isdir(project_repo_dir)

    project_template = find_template(project_repo_dir)

    assert project_template == os.path.join(project_repo_dir, '{{cookiecutter.repo_name}}')

    shutil.rmtree(temp_repo_dir)

# Generated at 2022-06-21 10:49:24.343211
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_find_template'
    )
    assert 'project_name' in find_template(test_dir)

# Generated at 2022-06-21 10:49:25.581789
# Unit test for function find_template
def test_find_template():
    """
    Test if find_template consists of {{cookiecutter.name}}.
    """
    assert find_template() == 'Cookiecutter-tool'

# Generated at 2022-06-21 10:49:31.257376
# Unit test for function find_template
def test_find_template():
    # Using the toy project in the test/fixtures directory
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'fixtures',
        'toy-project'
    )

    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(
        repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-21 10:49:43.208647
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter's template-finding algorithm."""
    here = os.path.abspath(os.path.dirname(__file__))

    test_dir = os.path.join(here, 'fixtures', 'test-template')
    assert find_template(test_dir) == os.path.join(test_dir, '{{cookiecutter.repo_name}}')

    test_dir = os.path.join(here, 'fixtures', 'test-repo')
    assert find_template(test_dir) == os.path.join(test_dir, 'cookiecutter-pypackage')

    test_dir = os.path.join(here, 'fixtures', 'test-template-without-wrap')

# Generated at 2022-06-21 10:50:11.523070
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/pydanny/code/personal/cookiecutter-django'
    project_template = '/Users/pydanny/code/personal/cookiecutter-django/{{ cookiecutter.github_repo_name }}'
    returned_project_template = find_template(repo_dir)
    assert project_template == returned_project_template

# Generated at 2022-06-21 10:50:23.286886
# Unit test for function find_template
def test_find_template():
    import platform
    import shutil
    import tempfile

    from cookiecutter.generate import generate_context

    if platform.system() == 'Windows':
        project_temp = os.path.join(tempfile.gettempdir(), 'cookiecutter-foobar')
    else:
        project_temp = os.path.join('/tmp/cookiecutter-foobar')

    context = generate_context({'full_name': 'Audrey Roy'})
    logger.debug('context is %s' % context)

    os.mkdir(project_temp)
    template_dir = os.path.join(project_temp, '{{cookiecutter.repo_name}}')
    shutil.copytree('tests/test-data/bakery-scaffold', template_dir)
    template_dir_contents = os.list

# Generated at 2022-06-21 10:50:29.656090
# Unit test for function find_template
def test_find_template():
    os.mkdir('fake_repo')
    os.mkdir('fake_repo/cookiecutter-pypackage')
    os.mkdir('fake_repo/cookiecutter-pypackage/{{cookiecutter.repo_name}}')
    assert find_template('fake_repo') == 'fake_repo/cookiecutter-pypackage'
    os.rmdir('fake_repo/cookiecutter-pypackage/{{cookiecutter.repo_name}}')
    os.rmdir('fake_repo/cookiecutter-pypackage')
    os.rmdir('fake_repo')

# Generated at 2022-06-21 10:50:31.809312
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    # TODO: Add unit test for function find_template
    pass

# Generated at 2022-06-21 10:50:38.899471
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-templated') == 'tests/fake-repo-templated/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-prettified') == 'tests/fake-repo-prettified/cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-no-templating') == None

# Generated at 2022-06-21 10:50:39.487314
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:50:40.872755
# Unit test for function find_template
def test_find_template():

    find_template('./tests/fake-repo-pre/')

# Generated at 2022-06-21 10:50:46.517226
# Unit test for function find_template
def test_find_template():
    """Test that a parallel directory structure is created appropriately."""
    from cookiecutter.tests.test_utils import make_bare_project_dir

    name = 'faux-project'
    bare_project = make_bare_project_dir(name)

    template = find_template(bare_project)

    assert template == '{0}/{{cookiecutter.repo_name}}'.format(bare_project)

# Generated at 2022-06-21 10:50:55.480251
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.main import cookiecutter

    # Create a temp repo
    tmp_repo = tempfile.mkdtemp()

    # Create a real template inside it
    template = cookiecutter(
        'tests/test-data/',
        no_input=True,
        extra_context={'repo_name': 'fakerepo'},
        output_dir=tmp_repo
    )
    repo_dir = os.path.join(tmp_repo, 'fakerepo')

    project_template = find_template(repo_dir)

    assert os.path.isfile(os.path.join(project_template, 'README.rst'))
    os.remove(os.path.join(project_template, 'README.rst'))
    os.rmdir

# Generated at 2022-06-21 10:51:01.504525
# Unit test for function find_template
def test_find_template():
    os.environ['TEST_WORKING_DIR'] = os.path.dirname(os.path.abspath(__file__))
    template_dir = os.path.join(os.environ['TEST_WORKING_DIR'], 'fake-repo-pre-gen')
    template_dir = find_template(template_dir)
    assert template_dir == 'fake-repo-pre-gen/cookiecutter-pypackage'