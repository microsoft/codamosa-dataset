

# Generated at 2022-06-21 10:41:56.361077
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    repo_dir = 'c:\\Users\\Me\\Documents\\GitHub\\cookiecutter-django'
    project_template = find_template(repo_dir)
    assert project_template == 'c:\\Users\\Me\\Documents\\GitHub\\cookiecutter-django\\{{cookiecutter.repo_name}}'
    assert(type(project_template) == type("string"))

# Generated at 2022-06-21 10:41:58.044728
# Unit test for function find_template
def test_find_template():
    find_template('/home/jduckles/work/cookiecutter/cookiecutter-pypackage')

# Generated at 2022-06-21 10:42:05.788881
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

    test_repo_dir = os.path.join(temp_dir, 'testing_repo')
    os.mkdir(test_repo_dir)

    good_dir_1 = os.path.join(test_repo_dir, 'dir_1')
    os.mkdir(good_dir_1)

    good_dir_2 = os.path.join(test_repo_dir, 'dir_2')
    os.mkdir(good_dir_2)

    bad_dir_1 = os.path.join(test_repo_dir, 'dir_3')
    os.mkdir(bad_dir_1)


# Generated at 2022-06-21 10:42:13.968901
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre/{{cookiecutter.repo_name}}') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:24.377979
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        print(item)
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)


# Generated at 2022-06-21 10:42:24.904527
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-21 10:42:36.994310
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    import os

    test_dir = tempfile.mkdtemp()
    assert os.path.isdir(test_dir)
    one_dir = os.path.join(test_dir, 'dir1')
    os.mkdir(one_dir)
    assert os.path.isdir(one_dir)
    two_dir = os.path.join(test_dir, 'dir2')
    os.mkdir(two_dir)
    assert os.path.isdir(two_dir)
    good_dir = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(good_dir)
    assert os.path.isdir(good_dir)

    project_dir = find_template(test_dir)
   

# Generated at 2022-06-21 10:42:42.595282
# Unit test for function find_template
def test_find_template():
    """Check that the template directory has been found."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'test-files', 'fake-repo')
    result = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert result == expected

# Generated at 2022-06-21 10:42:44.684362
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:42:49.416938
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    project_template = find_template(os.path.join(os.path.dirname(__file__), 'test_find_template'))
    assert project_template == (os.path.join(os.path.dirname(__file__), 'test_find_template', '{{cookiecutter.repo_name}}'))

    try:
        project_template = find_template(os.path.join(os.path.dirname(__file__), 'test_find_template_no_template'))
        assert False
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-21 10:42:54.370110
# Unit test for function find_template
def test_find_template():
    result = find_template('tests/test-input')
    assert result == 'tests/test-input/{{cookiecutter.project_directory_name}}'

# Generated at 2022-06-21 10:43:03.680908
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException

    temp_repo_dir = tempfile.mkdtemp(prefix="cookiecutter-")
    with open(os.path.join(temp_repo_dir, 'file1'), 'w') as f1:
        f1.write('')
    with open(os.path.join(temp_repo_dir, 'file2'), 'w') as f2:
        f2.write('')
    with open(os.path.join(temp_repo_dir, 'cookiecutter{{cookiecutter.foo}}'), 'w') as f3:
        f3.write('')

    template_dir = find_template(temp_repo_dir)

# Generated at 2022-06-21 10:43:10.009809
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-tmpl')

    project_template = find_template(repo_dir)
    assert project_template == repo_dir

    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-pre')

    project_template = find_template(repo_dir)
    assert project_template == repo_dir

    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-post')

    project_template = find_template(repo_dir)
    assert project_template == repo_dir

# Generated at 2022-06-21 10:43:14.785976
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/foo/cookiecutter-pypackage-master'
    template_path = find_template(repo_dir)
    assert (template_path == '/home/foo/cookiecutter-pypackage-master/'
            '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:43:22.568940
# Unit test for function find_template
def test_find_template():
    # Setup
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '..', 'tests', 'test-repo-tmpl')
    # Exercise
    tmpl_dir = find_template(repo_dir)
    # Verify
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert tmpl_dir == expected
    # Cleanup - none necessary

# Generated at 2022-06-21 10:43:27.199105
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/files/fake-repo-tmpl/'
    project_template = find_template(repo_dir)
    assert project_template == './tests/files/fake-repo-tmpl/{{cookiecutter.repo_name}}', \
        project_template

# Generated at 2022-06-21 10:43:31.503024
# Unit test for function find_template
def test_find_template():
    fake_repo = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo'
    ))

    tpl_dir_name = find_template(fake_repo)
    assert 'fake-repo-tmpl' in tpl_dir_name

# Generated at 2022-06-21 10:43:35.784741
# Unit test for function find_template
def test_find_template():
    """Verify function find_template."""

    # Setup
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo'
    ))
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Run
    result = find_template(repo_dir)

    # Verify
    assert result == expected

# Generated at 2022-06-21 10:43:41.515418
# Unit test for function find_template
def test_find_template():
    from unittest import TestCase
    from cookiecutter.tests.test_find_template import (
        TEST_REPO_DIR,
        TEST_TEMPLATE_DIR
    )
    repo_dir = TEST_REPO_DIR
    assert find_template(repo_dir) == TEST_TEMPLATE_DIR

# Generated at 2022-06-21 10:43:47.596903
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/fake-repo-pre/'
        )
    ) == os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'
        )

# Generated at 2022-06-21 10:43:52.684089
# Unit test for function find_template
def test_find_template():
    actual = find_template('/home/vagrant/cookiecutters/cookiecutter-pypackage')
    expected = '/home/vagrant/cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert actual == expected

# Generated at 2022-06-21 10:43:56.515275
# Unit test for function find_template
def test_find_template():
    project_template = find_template("/Users/meganl/Documents/Github/cookiecutter-pypackage")
    assert project_template == "/Users/meganl/Documents/Github/cookiecutter-pypackage/{{cookiecutter.repo_name}}"

test_find_template()

# Generated at 2022-06-21 10:44:08.309401
# Unit test for function find_template
def test_find_template():
    """Test whether it is possible to find template in a repo."""
    this_dir, this_filename = os.path.split(__file__)
    repo_with_template = os.path.join(this_dir, '..', 'fake-repo-pre/')
    repo_without_template = os.path.join(this_dir, '..', 'fake-repo-post/')
    expected_template = os.path.join(this_dir, '..', 'fake-repo-pre/{{cookiecutter.repo_name}}/')

    template = find_template(repo_with_template)
    assert template == expected_template

    try:
        template = find_template(repo_without_template)
    except Exception as e:
        assert e.message == 'Failed to find template in repo.'

# Generated at 2022-06-21 10:44:15.091846
# Unit test for function find_template
def test_find_template():
    # Mock the contents of the directory, including one file with cookiecutter
    import mock
    from cookiecutter import __file__ as cookiecutter_path

    repo_dir = os.path.dirname(cookiecutter_path)
    mock_listdir = mock.Mock(return_value=['cookiecutter', 'setup.py'])

    with mock.patch('os.listdir', mock_listdir):
        project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'cookiecutter')

# Generated at 2022-06-21 10:44:17.340464
# Unit test for function find_template
def test_find_template():
    repo = 'tests/test-data/fake-repo/'
    assert 'tests/test-data/fake-repo/{{cookiecutter.repo_name}}' == find_template(repo)

# Generated at 2022-06-21 10:44:21.971054
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'test-find-template-repo')
    project_template = find_template(repo_dir)
    assert os.path.basename(project_template) == 'cookiecutter-django'

# Generated at 2022-06-21 10:44:23.832531
# Unit test for function find_template
def test_find_template():
    find_template("/home/ishtiaq/python/workspace/cookiecutter/cookiecutter")

# Generated at 2022-06-21 10:44:33.318782
# Unit test for function find_template
def test_find_template():
    """Test `find_template` function.

    Replicate the directory structure that Cookiecutter creates when a
    non-templated input dir has been specified.
    """
    logging.disable(logging.CRITICAL)

    input_dir = 'fake-repo'
    os.makedirs(os.path.join(input_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(
        input_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}'
    ))

    project_template = find_template(input_dir)
    find_template_output = os.path.join(
        input_dir, '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-21 10:44:36.289735
# Unit test for function find_template
def test_find_template():
    """verify that find_template returns a directory that exists"""
    repo_dir = '.travis.yml'
    assert repo_dir is find_template(repo_dir)


# Generated at 2022-06-21 10:44:43.789814
# Unit test for function find_template
def test_find_template():
    """Sample unit test for function find_template."""
    test_repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'cookiecutter-project-template'
    )
    project_template = find_template(test_repo_dir)
    assert os.path.exists(project_template)

# Generated at 2022-06-21 10:45:01.408882
# Unit test for function find_template
def test_find_template():
    """
    Make a test repo directory, with a templated dir inside of it.
    Then try to find the templated directory's path.
    """
    # Make directory to clone into
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()
    try:
        templated_dir = os.path.join(temp_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
        os.makedirs(templated_dir)
        assert find_template(temp_dir) == os.path.join(temp_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-21 10:45:09.777124
# Unit test for function find_template
def test_find_template():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    test_dir = os.path.join(base_dir, 'tests')
    test_template_dir = os.path.join(test_dir, 'test-template')
    project_template = find_template(test_template_dir)
    assert project_template == os.path.join(
        test_template_dir, 'cookiecutter-test-template')

# Generated at 2022-06-21 10:45:14.697113
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/projects/cookiecutter-pypackage'
    actual = find_template(repo_dir)
    expected = '/home/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert actual == expected


# Generated at 2022-06-21 10:45:21.473665
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template'
    ))
    expected_template = os.path.join(test_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    actual_template = find_template(test_dir)
    assert expected_template == actual_template

# Generated at 2022-06-21 10:45:23.764507
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'


# Generated at 2022-06-21 10:45:28.705646
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo/'
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)
    assert os.path.basename(project_template) == '{{cookiecutter.project_name}}'
    
test_find_template()

# Generated at 2022-06-21 10:45:35.899118
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import os.path


# Generated at 2022-06-21 10:45:36.304348
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:42.343923
# Unit test for function find_template
def test_find_template():
    """Test which find_template is able to find a project template.
    """
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo',
    ))
    project_template = find_template(repo_dir)
    assert os.path.abspath(project_template) == os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}'
    )



# Generated at 2022-06-21 10:45:50.646540
# Unit test for function find_template
def test_find_template():
    """Test find_template function only accepts templated directories."""
    import shutil
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException

    temp_dir = tempfile.mkdtemp()
    temp_dir_contents = [
        'good_project',
        '{{cookiecutter.project_name}}',
        '{{cookiecutter.project_name}}_with_more_stuff',
        'bad_project_without_{{',
    ]

    for item in temp_dir_contents:
        item_dir = os.path.join(temp_dir, item)
        os.makedirs(item_dir)


# Generated at 2022-06-21 10:46:13.703454
# Unit test for function find_template
def test_find_template():
    repo_dir = 'dummy_repo_dir'
    repo_dir_contents = ['cookiecutter-pypackage',
                         '{{cookiecutter.project_name}}',
                         'README.md',
                         'LICENSE']
    # with patch('os.listdir', MagicMock(return_value=repo_dir_contents)):
    #     project_template = find_template(repo_dir)
    #     assert project_template == '{{cookiecutter.project_name}}'

    repo_dir_contents = ['cookiecutter-pypackage',
                         'README.md',
                         'LICENSE']
    # with patch('os.listdir', MagicMock(return_value=repo_dir_contents)):
    #     with raises(NonTemplated

# Generated at 2022-06-21 10:46:18.315276
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')




# Generated at 2022-06-21 10:46:26.946545
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/code/cookiecutter-pypackage'
    project_template = '/Users/audreyr/code/cookiecutter-pypackage/cookiecutter-pypackage'
    assert find_template(repo_dir) == project_template
    repo_dir = '/Users/audreyr/code/cookiecutter-feed-seven-of-nine'
    project_template = '/Users/audreyr/code/cookiecutter-feed-seven-of-nine/feed-seven-of-nine'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:46:31.245487
# Unit test for function find_template
def test_find_template():
    """Verify the correct directory is found for the project template."""
    templates = [
        '{{cookiecutter.repo_name}}',
    ]
    for template in templates:
        this_dir = os.path.dirname(os.path.abspath(__file__))
        repo_dir = os.path.join(this_dir, 'fake-repo')
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, template)

# Generated at 2022-06-21 10:46:37.851287
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    repo_dir = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == repo_dir

# Generated at 2022-06-21 10:46:43.201373
# Unit test for function find_template
def test_find_template():
    repo_dir = "cookiecutter_test/Bare-repo-template"
    project_template = find_template(repo_dir)

# Generated at 2022-06-21 10:46:44.974499
# Unit test for function find_template
def test_find_template():
    find_template('C:\cookiecutter-pypackage')

# Generated at 2022-06-21 10:46:49.939706
# Unit test for function find_template
def test_find_template():
    test_repo = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                '..', 'tests', 'fake-repo-tmpl'))
    test_result = find_template(test_repo)

    assert test_result == os.path.join(test_repo,
                     '{{cookiecutter.repo_name}}'), 'Template not correctly identified'



# Generated at 2022-06-21 10:46:51.082611
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:46:55.973985
# Unit test for function find_template
def test_find_template():
    """Tests for find_template function
    """
    # import pytest
    # f = find_template(r'C:\Users\Zoltan\Project\cookiecutter_django_rest')
    # print(f)
    pass

# Generated at 2022-06-21 10:47:33.744240
# Unit test for function find_template
def test_find_template():
    """
    Test if find_template returns the correct path to the template folder.
    """

    def _create_test_file(path):
        string_line1 = "This is a test file"
        string_line2 = "This is the second line"
        string_line3 = "Cookiecutter is awesome"
        f = open(path, 'w')
        f.write(string_line1)
        f.write('\n')
        f.write(string_line2)
        f.write('\n')
        f.write(string_line3)
        f.write('\n')
        f.close()

    # Create a temporary folder for the test
    import tempfile
    temp_dir = tempfile.mkdtemp()

    # Create a test file inside the temp_dir

# Generated at 2022-06-21 10:47:34.378350
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:47:36.048997
# Unit test for function find_template
def test_find_template():
    """Show that function find_template returns the correct directory."""
    assert find_template('/home/foo/code') == '/home/foo/code/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:47:44.768615
# Unit test for function find_template
def test_find_template():
    """Verify `find_template` works properly."""
    from cookiecutter import utils

    logger.info('Verifying `find_template` function')

    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            '..',
            'tests',
            'fake-repo-pre-rendered'
        )
    )
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    utils.find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:47:50.120466
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.basename(os.path.join(os.path.dirname(__file__), 'repo104'))
    expected_result = os.path.join(os.path.dirname(__file__), 'repo104/{{cookiecutter.project_name}}')
    result = find_template(repo_dir)
    assert expected_result == result

# Generated at 2022-06-21 10:47:51.715480
# Unit test for function find_template
def test_find_template():
    find_template('/Users/adamchainz/projects/github_cookiecutters/python_project')

# Generated at 2022-06-21 10:48:00.822724
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '../',
            'tests/test-repo/'
        )
    )
    result = find_template(repo_dir)
    expected = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '../',
            'tests/test-repo/{{cookiecutter.repo_name}}/'
        )
    )
    assert result == expected

# Generated at 2022-06-21 10:48:06.790802
# Unit test for function find_template
def test_find_template():
    """
    Test that a call with a valid directory returns the correct project_template
    """
    import tempfile
    test_dir = tempfile.mkdtemp()

    # Add a valid project_template to the directory
    project_template = os.path.join(test_dir, 'valid_project_template')
    open(project_template, 'a').close()

    result = find_template(test_dir)
    assert result == project_template

# Generated at 2022-06-21 10:48:09.236132
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/dev/cookiecutter-pypackage'
    assert 'cookiecutter-pypackage' in find_template(repo_dir)

# Generated at 2022-06-21 10:48:21.360519
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function.
    """
    from cookiecutter import find
    assert find.find_template('fixtures/fake-repo-tmpl') == 'fixtures/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find.find_template('docs') == 'docs/cookiecutter-pypackage'
    assert find.find_template('docs/cookiecutter-pypackage') == 'docs/cookiecutter-pypackage'
    assert find.find_template('docs/cookiecutter-pypackage/{{cookiecutter.repo_name}}') == 'docs/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:49:17.888888
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(os.path.dirname(__file__), 'test-repo-tmpl')
    logger.debug('test_find_template: %s', template_dir)

    assert find_template(template_dir) == template_dir

# Generated at 2022-06-21 10:49:23.226250
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'test-dir'
    )
    assert find_template(test_dir) == os.path.join(test_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-21 10:49:23.658230
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:49:24.411978
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-21 10:49:26.225558
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    os.path.exists('{{cookiecutter.repo_name}}')
    os.path.exists('cookiecutter-pypackage')

find_template('tests/test-repo/')

# Generated at 2022-06-21 10:49:28.533009
# Unit test for function find_template
def test_find_template():
    """Unit test for function ``find_template``."""
    temp_directory = 'tests/files/fake-repo'

    template_path = find_template(temp_directory)
    expected = os.path.join(os.path.abspath(temp_directory), '{{cookiecutter.repo_name}}')
    assert template_path == expected

# Generated at 2022-06-21 10:49:34.080147
# Unit test for function find_template
def test_find_template():
    import os
    from cookiecutter.main import cookiecutter

    # Create a project from an example repo
    example_repo = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    cookiecutter(example_repo, no_input=True, extra_context={'repo_name': 'hello'})

    # Get the path to the project template
    project_template = os.path.abspath(os.path.join(os.getcwd(), 'hello'))

    # If the find_template function works, the result should be a directory.
    assert os.path.isdir(project_template) == True
    assert os.path.isfile(project_template) == False

# Generated at 2022-06-21 10:49:38.380427
# Unit test for function find_template
def test_find_template():
    import tempfile
    template_dir = tempfile.mkdtemp()
    project_template = os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template)
    assert project_template == find_template(template_dir)

# Generated at 2022-06-21 10:49:43.005217
# Unit test for function find_template
def test_find_template():
    test_repo = os.path.join(os.path.dirname(__file__),
                             "_tests/test-repo-pre-gen/")
    os.chdir(test_repo)
    find_template(test_repo)

# Generated at 2022-06-21 10:49:54.237979
# Unit test for function find_template
def test_find_template():
    """Test the function find_template."""
    import shutil
    import tempfile

    # Create a temp dir and clone the Cookiecutter repo into it
    tmp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmp_dir, 'cookiecutter-example'))

    # Both the project template and a non-project template subdirectory
    os.makedirs(
        os.path.join(tmp_dir, 'cookiecutter-example', '{{cookiecutter.repo_name}}')
    )
    os.makedirs(
        os.path.join(
            tmp_dir, 'cookiecutter-example', 'not-a-project-template'
        )
    )

    # Mock project template should be found