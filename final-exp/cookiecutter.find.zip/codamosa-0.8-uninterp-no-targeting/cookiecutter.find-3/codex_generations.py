

# Generated at 2022-06-21 10:41:47.551470
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:41:53.525850
# Unit test for function find_template
def test_find_template():
    base_dir = os.path.dirname(os.path.dirname(__file__))
    repo_dir = os.path.join(base_dir, 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:42:00.550391
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    # Create temp dir
    temp_dir = tempfile.mkdtemp()

    # Put two directories inside temp dir
    os.mkdir(os.path.join(temp_dir, 'my_template'))
    os.mkdir(os.path.join(temp_dir, 'my_dir'))

    # Find_template should return the first directory
    assert find_template(temp_dir) == os.path.join(temp_dir, 'my_template')

    # Clean up temp dir
    shutil.rmtree(temp_dir)


# Generated at 2022-06-21 10:42:04.730046
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(
        os.path.dirname(__file__), 'fake-repo-pre-gen')) == os.path.join(
        os.path.dirname(__file__),
        'fake-repo-pre-gen',
        '{{cookiecutter.repo_name}}{{cookiecutter.test1}}'
    )



# Generated at 2022-06-21 10:42:10.373703
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = 'tests/test-find-template/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-find-template/fake-repo/{{cookiecutter.repo_name}}'


# Generated at 2022-06-21 10:42:12.213861
# Unit test for function find_template
def test_find_template():
    assert find_template('Users/username/cookiecutter-pypackage') == 'Users/username/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:20.470275
# Unit test for function find_template
def test_find_template():
    """Check if the function works correctly."""
    from cookiecutter import utils
    utils.set_verbosity(True)
    assert find_template(os.path.expanduser('~/cookie_test')) == \
        os.path.expanduser('~/cookie_test/tests/files/templated-cookiecutter')
    assert find_template(os.path.expanduser('~/cookie_test/tests/files/templated-cookiecutter')) == \
        os.path.expanduser('~/cookie_test/tests/files/templated-cookiecutter/{{cookiecutter.project_name}}')

# Generated at 2022-06-21 10:42:23.349299
# Unit test for function find_template
def test_find_template():
    input = './tests/test-find-template'
    output = './tests/test-find-template/cookiecutter-pypackage'
    assert find_template(input) == output

# Generated at 2022-06-21 10:42:24.215960
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-21 10:42:32.366129
# Unit test for function find_template
def test_find_template():
    here = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(here, 'tests/test-find-template/repo_dir')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_find_template()

# Generated at 2022-06-21 10:42:40.758762
# Unit test for function find_template
def test_find_template():
    """Test that find_template() returns the correct template directory."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    result = find_template(repo_dir)

    assert result == expected

# Generated at 2022-06-21 10:42:44.633571
# Unit test for function find_template
def test_find_template():
    project_template = find_template('/Users/audreyr/projects/cookiecutter-pypackage/test_dir')
    assert project_template == '/Users/audreyr/projects/cookiecutter-pypackage/test_dir/{{cookiecutter.repo_name}}/'


# Generated at 2022-06-21 10:42:54.416009
# Unit test for function find_template
def test_find_template():
    """Verify expected behavior of find_template()."""
    def test_dir_contents(dir_contents):
        repo_dir = '/tmp'
        os.listdir = lambda path: dir_contents

        if dir_contents:
            project_template = find_template(repo_dir)
            assert project_template == os.path.join(repo_dir, dir_contents[0])
        else:
            try:
                find_template(repo_dir)
            except NonTemplatedInputDirException:
                pass
            else:
                assert False, 'NonTemplatedInputDirException not raised.'

    test_dir_contents(dir_contents=[])

# Generated at 2022-06-21 10:43:03.679876
# Unit test for function find_template
def test_find_template():
    os.startup_dir = os.path.dirname(os.path.abspath(__file__))
    os.repo_dir = os.path.dirname(os.path.dirname(os.startup_dir))
    os.project_dir = os.path.dirname(os.path.dirname(os.repo_dir))

    os.sample_repo = os.path.join(os.project_dir, 'fixtures/fake-repo')
    os.fake_repo = os.path.join(os.project_dir, 'fixtures/fake-repo-fake')

    assert find_template(os.sample_repo) == os.path.join(os.sample_repo, '{{cookiecutter.repo_name}}')
    # try:
    #     find_

# Generated at 2022-06-21 10:43:04.162703
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:43:10.284758
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree
    from cookiecutter import main
    import tempfile
    import subprocess

    repo_dir = tempfile.mkdtemp()
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    subprocess.call(['git', 'clone', repo_url, repo_dir])

    project_dir = find_template(repo_dir)
    assert project_dir == '{}/{{cookiecutter.repo_name}}'.format(repo_dir)

    new_dir = os.path.join(os.path.dirname(repo_dir), 'cookiecutter-new-repo')
    main.cookiecutter(project_dir, new_dir, no_input=True)


# Generated at 2022-06-21 10:43:14.125996
# Unit test for function find_template
def test_find_template():
   assert find_template('cookiecutter/tests/test-data/fake-repo-tmpl/') == 'cookiecutter/tests/test-data/fake-repo-tmpl/{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:43:23.276447
# Unit test for function find_template
def test_find_template():
    """
    Given a path to a newly cloned repo, find_templated_dir should
    return the path to the project template.
    """
    BASE_PATH = os.path.abspath(os.path.dirname(__file__))
    SAMPLE_REPO_PATH = os.path.join(BASE_PATH, '..', 'tests', 'test-repo')
    TEMPLATE_PATH = os.path.join(SAMPLE_REPO_PATH, '{{ cookiecutter.repo_name }}')

    assert find_template(SAMPLE_REPO_PATH) == TEMPLATE_PATH

# Generated at 2022-06-21 10:43:31.459683
# Unit test for function find_template
def test_find_template():
    """
    Ensure non-templated directory raises an exception.
    """
    from cookiecutter.main import cookiecutter

    repo_dir = cookiecutter('tests/fake-repo-tmpl').strip()
    find_template(repo_dir)

    os.chdir(repo_dir)
    os.system('git checkout no-templated-dir')

    repo_dir = cookiecutter('tests/fake-repo-tmpl').strip()
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

# Generated at 2022-06-21 10:43:43.135224
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Use the existing 'not-really-a-project' test repo
    input_path = 'tests/fake-repo-tmpl'

    # Test the 'not-really-a-project' test repo
    try:
        cookiecutter(
            input_path,
            no_input=True,
            extra_context={'repo_name': 'foobar'},
            output_dir='tests/test-find-template-output',
        )
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

    # Test passing in a real template directory

# Generated at 2022-06-21 10:43:47.782025
# Unit test for function find_template
def test_find_template():
    find_template('/home/cookiecutter/cookiecutter-pypackage')

# Generated at 2022-06-21 10:43:53.565309
# Unit test for function find_template
def test_find_template():
    cwd = os.getcwd()
    os.chdir(os.path.join('tests', 'test-drive-cookiecutter'))
    assert find_template(os.getcwd()) == os.path.join(os.getcwd(), 'cookiecutter-{{ cookiecutter.repo_name }}')
    os.chdir(cwd)

# Generated at 2022-06-21 10:43:56.596914
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    pt = find_template(repo_dir)

    assert pt == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'


# Generated at 2022-06-21 10:44:05.046110
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    template_path = os.path.abspath(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests', 'files', 'fake-repo'
    ))
    project_template = find_template(template_path)
    assert (
        'fake-repo/real-project' ==
        os.path.relpath(project_template, template_path)
    )

# Generated at 2022-06-21 10:44:09.162846
# Unit test for function find_template
def test_find_template():
    repo_dir = '.' # TODO: replace with example dir
    os.listdir(repo_dir)
    for item in os.listdir(repo_dir):
        assert '.--' in item
        assert '--' in item

# Test for find_template
test_find_template()

# Generated at 2022-06-21 10:44:17.828387
# Unit test for function find_template
def test_find_template():
    """
    Verify that find_template finds the template directory within a nested directory structure
    """

    # Create a nested directory structure
    test_dir = os.path.join(os.getcwd(), 'test_template')
    os.mkdir(test_dir)
    os.mkdir(os.path.join(test_dir, 'abc'))
    os.mkdir(os.path.join(test_dir, 'xyz'))
    os.mkdir(os.path.join(test_dir, 'abc', 'def'))
    os.mkdir(os.path.join(test_dir, 'abc', 'ghi'))
    os.mkdir(os.path.join(test_dir, 'abc', 'ghi', 'cookiecutter-{{cookiecutter.repo_name}}'))
    os

# Generated at 2022-06-21 10:44:29.109258
# Unit test for function find_template
def test_find_template():
    from cookiecutter import repo
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    output = 'tests/files/test-repo-pre/{{cookiecutter.repo_name}}'
    context = main.generate_context(
        repo_dir='tests/files/test-repo-pre',
        context_file='tests/files/test-repo-pre/cookiecutter.json',
    )
    repo_dir = repo.generate_files(
        repo_dir='tests/files/test-repo-pre',
        context=context,
        output_dir='tests/render',
    )
    assert output == find_template(repo_dir)
    rmtree('tests/render')

# Generated at 2022-06-21 10:44:39.711726
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    import os
    import shutil

    from cookiecutter.config import DEFAULT_CONFIG

    # Create a project template
    try:
        os.makedirs('fake_cookiecutter_template/fake_project_tmpl')
        fake_template_dir = 'fake_cookiecutter_template/fake_project_tmpl'
        fake_template_full_path = os.path.abspath(fake_template_dir)
    except OSError:
        pass

    # Create a few dummy directories

# Generated at 2022-06-21 10:44:45.639611
# Unit test for function find_template
def test_find_template():
    """Ensure find_template function returns the correct project template."""
    expected_template = './tests/test-data/fake-repo-pre/fake-project-tmpl'
    repo_dir = './tests/test-data/fake-repo-pre'
    template = find_template(repo_dir)
    assert template == expected_template

# Generated at 2022-06-21 10:44:52.711802
# Unit test for function find_template
def test_find_template():
    """Test function find_template"""
    project_dir = os.path.join(os.path.dirname(__file__), '..', '..')
    logging.basicConfig(filename=os.path.join(project_dir, 'log', 'test.log'), level=logging.INFO)
    logger.info('Starting unit test for function find_template')
    repo_dir = os.path.join(project_dir, 'tests', 'test-repo-tmpl')
    template_found = find_template(repo_dir)
    logger.info('The input repo_dir is %s', repo_dir)
    logger.info('The found template is %s', template_found)
    if os.path.exists(template_found):
        logger.info('The template exists')

# Generated at 2022-06-21 10:45:03.243082
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter import repo

    template_dir = tempfile.mkdtemp()
    repo.generate_files(context={'cookiecutter': {'repo_dir': 'oh-my-zsh'}},
                        repo_dir=template_dir,
                        overwrite_if_exists=True)

    template = find_template(template_dir)
    assert template == os.path.join(template_dir, 'oh-my-zsh')

# Generated at 2022-06-21 10:45:10.698091
# Unit test for function find_template
def test_find_template():
    # Testing repo with cookiecutter.json in parent dir
    try:
        find_template('tests/test-data/fake-repo')
    except NonTemplatedInputDirException as e:
        assert False

    # Testing repo without cookiecutter.json in parent dir
    try:
        find_template('tests/test-data/fake-repo-no-json')
    except NonTemplatedInputDirException as e:
        assert True

# Generated at 2022-06-21 10:45:15.055241
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'test-find-template', 'fake-repo')
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, 'cookiecutter-pypackage')
    assert project_template == expected

# Generated at 2022-06-21 10:45:18.147120
# Unit test for function find_template
def test_find_template():
    assert find_template('../tests/test-repo-pre/') == '../tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:45:23.679426
# Unit test for function find_template
def test_find_template():
    """Test :function:`find_template`."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo'))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-repo')

# Generated at 2022-06-21 10:45:27.984649
# Unit test for function find_template
def test_find_template():
    """Verify find_template works."""
    input_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    assert 'fake-repo' in find_template(input_dir)

# Generated at 2022-06-21 10:45:30.558002
# Unit test for function find_template
def test_find_template():
    """Test the function find_template()."""
    assert find_template('tests/fake-repo/') == 'tests/fake-repo/{{cookiecutter.repo_name}}/'



# Generated at 2022-06-21 10:45:36.550330
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.abspath(os.path.join(
        os.path.dirname(__file__), '../tests/test-input/')))
    assert find_template('.') == './fake-repo-tmpl'

# Generated at 2022-06-21 10:45:44.199490
# Unit test for function find_template
def test_find_template():
    """Check that ``find_template`` function properly finds the template
    inside the repo.
    """
    from cookiecutter.compat import NamedTemporaryFile

    expected_template_repo_dir = os.path.join(
        '{{ cookiecutter.repo_name }}',
        '{{ cookiecutter.repo_name }}',
    )

    expected_template_dir = os.path.join(
        expected_template_repo_dir,
        '{{ cookiecutter.repo_name }}'
    )
    with NamedTemporaryFile() as tf:
        project_dir = tf.name
        os.mkdir(project_dir)
        os.mkdir(expected_template_repo_dir)
        os.mkdir(expected_template_dir)


# Generated at 2022-06-21 10:45:45.979627
# Unit test for function find_template
def test_find_template():
    os.path.exists(os.path.join('tests', 'fake-repo-tmpl'))
    repo_dir = os.path.abspath(os.path.join('tests', 'fake-repo-tmpl'))
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:45:52.420741
# Unit test for function find_template
def test_find_template():
    assert find_template('tests')

# Generated at 2022-06-21 10:46:00.418883
# Unit test for function find_template
def test_find_template():
    project_template = find_template('sample_repos/repo_cookiecutter_jquery')
    assert project_template == 'sample_repos/repo_cookiecutter_jquery/{{cookiecutter.repo_name}}'

    # raise NonTemplatedInputDirException
    try:
        project_template = find_template('sample_repos/repo_no_cookiecutter')
    except Exception as e:
        assert type(e) == NonTemplatedInputDirException

# Generated at 2022-06-21 10:46:09.957381
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter

    user_config = {
        'replay_dir': '',
        'default_context': {},
        'abbreviations': {},
        'update': False,
    }

    cookiecutter('tests/fake-repo-tmpl', no_input=True, extra_context={'project_name': 'Foo Bar Project'},
                 user_config_dict=user_config)

    repo_dir = os.path.expanduser('~/.cookiecutters/fake-repo-tmpl')
    assert find_template(repo_dir) == repo_dir + '/fake-repo'

# Generated at 2022-06-21 10:46:12.798786
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/Documents/projects/cookiecutter-pypackage') == '/Users/audreyr/Documents/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:46:18.999010
# Unit test for function find_template
def test_find_template():
    """Test to see if we can find a template folder."""
    template_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-template'
    )
    template = find_template(template_dir)
    assert template == os.path.join(template_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:46:23.030429
# Unit test for function find_template
def test_find_template():
    repo_dir = '<path>'
    project_template = find_template(repo_dir)

# Generated at 2022-06-21 10:46:27.028828
# Unit test for function find_template
def test_find_template():
    """Find the project template inside a repo."""
    repo_dir = 'tests/test-repo-pre/'
    project_template = 'tests/test-repo-pre/{{cookiecutter.repo_name}}/'
    assert project_template == find_template(repo_dir)

# Generated at 2022-06-21 10:46:37.569974
# Unit test for function find_template
def test_find_template():
    """Tests for function `find_template`."""
    import tempfile
    import shutil
    import os

    test_repo_dir = 'fake-repo'

    # Make a temp dir and change to it.
    tmp_dir = tempfile.mkdtemp()
    old_dir = os.getcwd()
    os.chdir(tmp_dir)

    # Make a test repo dir
    os.mkdir(test_repo_dir)
    os.chdir(test_repo_dir)

    # Make a fake project template with a cookiecutter dir
    os.mkdir('fake-project-template')
    os.mkdir(os.path.join('fake-project-template', 'cookiecutter'))

    # The project template should be the only cookiecutter dir

# Generated at 2022-06-21 10:46:41.939944
# Unit test for function find_template
def test_find_template():
    """Searches for template in given directory"""
    assert find_template("tests/test_repo/test_template") == "tests/test_repo/test_template/{{cookiecutter.project_slug}}"

# Generated at 2022-06-21 10:46:42.570816
# Unit test for function find_template
def test_find_template():
    assert True

# Generated at 2022-06-21 10:46:56.619500
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'tests', 'foobar')
    exp_project_template = os.path.join(repo_dir, 'cookiecutter-foobar-{{cookiecutter.app_name}}')
    find_template1 = find_template(repo_dir)
    assert find_template1 == exp_project_template


# Generated at 2022-06-21 10:47:00.153335
# Unit test for function find_template
def test_find_template():
    find_template('https://github.com/rhythmictech/cookiecutter-pypackage.git')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:47:03.575470
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = find_template(repo_dir)
    expected_path = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_path

# Generated at 2022-06-21 10:47:08.097495
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template."""
    test_dir = 'tests/test-dir/'
    result = find_template(test_dir)
    assert result == 'tests/test-dir/cookiecutter-pypackage'

# Generated at 2022-06-21 10:47:09.743411
# Unit test for function find_template
def test_find_template():
    """Basic test for `find_template`."""
    pass



# Generated at 2022-06-21 10:47:15.306251
# Unit test for function find_template
def test_find_template():
    filename = find_template('/Users/sarareimers/Dropbox (Personal)/Cookiecutter/Projects/cookiecutter-github-user')
    assert filename == '/Users/sarareimers/Dropbox (Personal)/Cookiecutter/Projects/cookiecutter-github-user/cookiecutter-github-user'

# Generated at 2022-06-21 10:47:27.668640
# Unit test for function find_template
def test_find_template():
    import mock
    import tempfile
    from cookiecutter.compat import open

    with tempfile.NamedTemporaryFile(mode='w+') as template:
        repo_dir = os.path.dirname(template.name)
        project_template = '{{cookiecutter.hello}}'
        template.write(project_template)
        template.flush()

        with mock.patch('os.listdir', lambda x: [u'foo', u'bar', u'baz']):
            assert find_template(repo_dir) == template.name

        with mock.patch('os.listdir', lambda x: [u'foo', u'bar', u'baz']):
            assert find_template(repo_dir) == template.name

        template.close()

# Generated at 2022-06-21 10:47:31.354540
# Unit test for function find_template
def test_find_template():
    # directory is already created in a test before this so we can use it
    # for this test 
    assert find_template('test/test-repo-tmpl') == 'test/test-repo-tmpl/test-prj-tmpl'

# Generated at 2022-06-21 10:47:36.772115
# Unit test for function find_template
def test_find_template():
    # Testing for the presence of the "cookiecutter" string
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    expected_result = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert project_template == expected_result

# Generated at 2022-06-21 10:47:41.552221
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/djangopackage'
    project_template = find_template(repo_dir)
    assert '/home/audreyr/djangopackage/{{cookiecutter.repo_name}}' in project_template

# Generated at 2022-06-21 10:48:02.325324
# Unit test for function find_template
def test_find_template():
    """Test for `find_template` function."""
    import tempfile

    repo_dir = tempfile.mkdtemp()
    try:
        os.mkdir(os.path.join(repo_dir, 'cookiecutter-foobar'))
    except OSError:
        pass
    logger.info('repo_dir: {0}'.format(repo_dir))
    template_path = find_template(repo_dir)
    assert template_path.endswith(os.path.join(
        'cookiecutter-foobar', '{{cookiecutter.repo_name}}')
    )

# Generated at 2022-06-21 10:48:02.902506
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:48:08.052397
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            os.pardir,
            'tests',
            'test-find-template'
        )
    )

    result = find_template(test_dir)
    assert result == os.path.join(test_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:48:14.294990
# Unit test for function find_template
def test_find_template():
    """Testing the function find_template.

    TODO: Could be a bit more robust.
    """
    template_dir = os.path.join('tests', 'test-template-repo', 'other')
    template = find_template(template_dir)

    assert template.endswith('tests/test-template-repo/other/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:48:19.214117
# Unit test for function find_template
def test_find_template():
    template_name = '{{cookiecutter.repo_name}}'
    template_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                '..',
                                                'templates',
                                                template_name))
    assert find_template(template_dir) == template_dir

# Generated at 2022-06-21 10:48:28.831147
# Unit test for function find_template
def test_find_template():
    """Test if template can be found with function find_template"""

    # New Temp Directory
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_temp")

    test_template = """my_new_template-{{cookiecutter.author}}"""
    test_template_path = os.path.join(repo_dir,test_template)

    os.makedirs(test_template_path)
    logger.debug(repo_dir)
    assert test_template_path == find_template(repo_dir)

    # Delete Temp Directory
    os.removedirs(test_template_path)

# Generated at 2022-06-21 10:48:40.132001
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    import tempfile
    import shutil

    def _create_test_dir(test_dir, test_dir_content):
        """
        Create a test directory with given content.
        """
        os.mkdir(test_dir)
        for item in test_dir_content:
            filename = os.path.join(test_dir, item)
            open(filename, 'w').close()


# Generated at 2022-06-21 10:48:46.469796
# Unit test for function find_template
def test_find_template():
    """ Testing function find_template.
    """
    assert find_template('tests/test-repo/') == 'tests/test-repo/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-repo-non-templated/') == 'tests/test-repo-non-templated/cookiecutter-pypackage'

# Generated at 2022-06-21 10:48:53.603109
# Unit test for function find_template
def test_find_template():
    """
    Make sure the function finds the template
    """
    from cookiecutter.main import cookiecutter
    # Use the tests/fake-repo-tmpl/ directory as a template
    result = cookiecutter(
        'tests/fake-repo-tmpl/',
        no_input=True,
        output_dir='tests/fake-repo-pre/'
    )
    dirname = os.path.dirname(result)
    assert os.path.exists(dirname) == True
    project_dir = os.path.join(dirname, 'foobar')
    assert os.path.exists(project_dir) == True

# Generated at 2022-06-21 10:49:05.385486
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    temp_folder = tempfile.mkdtemp()
    context = {}

    # No exception is expected, because the path contains a cookiecutter template
    try:
        utils.find_template(temp_folder)
    except NonTemplatedInputDirException:
        assert False

    # Create a new directory with a nested template
    nested_template_dir = os.path.join(temp_folder, 'nested-template-dir')
    os.mkdir(nested_template_dir)

# Generated at 2022-06-21 10:49:37.641938
# Unit test for function find_template
def test_find_template():
    """Verify expected behavior of find_template.
    """
    import os
    import shutil
    import tempfile

    # Setup
    parent_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(parent_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(repo_dir)
    expected = repo_dir

    # Exercise
    actual = find_template(parent_dir)

    # Verify
    assert expected == actual

    # Cleanup
    shutil.rmtree(parent_dir)

# Generated at 2022-06-21 10:49:44.636492
# Unit test for function find_template
def test_find_template():
    template_dir = find_template("/Users/ziyuemiao/Documents/SUTD/SUTDSLE/T1-2017/50.005/18/Cookiecutter-SLE/cookiecutter-SLE-repo-template")
    logger.debug("The template dir is %s", template_dir)
    assert template_dir

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-21 10:49:55.310821
# Unit test for function find_template
def test_find_template():
    logger.debug('Running tests for find_template')
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.tests.test_find_tools import generate_files


# Generated at 2022-06-21 10:50:07.786272
# Unit test for function find_template
def test_find_template():
    # Mock in a file structure
    import tempfile
    from cookiecutter.utils import rmtree
    from cookiecutter.repository import determine_repo_dir
    # Create a temp dir
    tmp_dir = tempfile.mkdtemp()
    # Create a fake repo
    cookiecutter_dir = os.path.join(tmp_dir, 'fake-repo-tmpl')
    os.makedirs(cookiecutter_dir)
    open(os.path.join(cookiecutter_dir, 'cookiecutter.json'), 'w').close()

    # Create a dummy project template
    project_dir = os.path.join(cookiecutter_dir, 'project_tmpl')
    os.makedirs(project_dir)

# Generated at 2022-06-21 10:50:18.016739
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import os
    from cookiecutter.main import cookiecutter
    from jinja2 import TemplateSyntaxError
    
    repo = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    templ_dir = tempfile.mkdtemp()
    cookiecutter(repo, no_input=True, output_dir=templ_dir)
    template = find_template(templ_dir)

    # Test for valid temp dir
    assert len(os.listdir(template)) > 0

    # Test for malformed input
    shutil.rmtree(template)
    try:
        find_template(templ_dir)
    except TemplateSyntaxError:
        pass

# Generated at 2022-06-21 10:50:27.669852
# Unit test for function find_template
def test_find_template():

    # find_template should find the template in this repo
    test_repo = os.path.join(os.path.dirname(__file__), 'templates/fake-repo-pre')
    assert find_template(test_repo) == '%s/{{cookiecutter.repo_name}}' % test_repo

    # find_template should not find a template in this repo
    test_repo = os.path.join(os.path.dirname(__file__), 'templates/fake-repo-no-template')

    try:
        find_template(test_repo)
        assert False, 'find_template should not have found a template in %s' % test_repo
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-21 10:50:39.748471
# Unit test for function find_template
def test_find_template():
    import tempfile

    django_app_dir = os.path.join(os.path.dirname(__file__), 'test-data', 'cookiecutters', 'django-app')
    repo_dir = tempfile.mkdtemp()
    assert not os.listdir(repo_dir)
    from cookiecutter.utils.prompt import query_yes_no
    if query_yes_no("Do you want to test find_template with a real clone?", default="no") == 'yes':
        clone_from_repo(django_app_dir, repo_dir)
        assert os.listdir(repo_dir)
        assert find_template(repo_dir) == django_app_dir

# Generated at 2022-06-21 10:50:49.681654
# Unit test for function find_template
def test_find_template():
    """ Verify the find_template() function works as designed """
    from unittest import TestCase
    import tempfile
    import shutil

    class TestFindTemplate(TestCase):

        def setUp(self):
            self.tmpdir_path = tempfile.mkdtemp()
            self.tmpdir = os.path.basename(self.tmpdir_path)

        def test_find_template_1(self):
            """ Find a template among templated directories """
            os.mkdir(os.path.join(self.tmpdir_path, '{{ cookiecutter.project_name }}'))
            project_template = find_template(self.tmpdir)
            self.assertEqual(project_template, os.path.join(self.tmpdir_path, '{{ cookiecutter.project_name }}'))


# Generated at 2022-06-21 10:50:55.002143
# Unit test for function find_template
def test_find_template():
    """For testing that find_template can find the project template."""
    test_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_template'
    )
    expected = os.path.join(
        test_path,
        '{{ cookiecutter.project_name }}'
    )
    result = find_template(test_path)
    assert result == expected

# Generated at 2022-06-21 10:51:06.802028
# Unit test for function find_template
def test_find_template():
    """
    If the input directory contains a directory starting with cookiecutter
    and ending with {{ and }}, find_template should return that directory.
    """
    import tempfile
    from shutil import rmtree
    from cookiecutter.main import cookiecutter

    logger.debug('Testing find_template function.')