

# Generated at 2022-06-21 10:41:54.778398
# Unit test for function find_template
def test_find_template():

    repo_dir = '~/dev/cookiecutter-pypackage-tests/tests/fake-repo-templated'
    repo_dir_contents = os.listdir(repo_dir)

# Generated at 2022-06-21 10:41:57.717323
# Unit test for function find_template
def test_find_template():
    joined = os.path.join('tests', 'fake-repo-tp')
    assert find_template('tests/fake-repo-tp') == joined
    assert find_template(joined) == joined

# Generated at 2022-06-21 10:42:01.348828
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template`."""
    path = 'tests/files/find'
    result = find_template(path)
    expected = os.path.join(path, 'cookiecutter-{{cookiecutter.project_name}}')
    assert result == expected

# Generated at 2022-06-21 10:42:05.347088
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(__file__)
    repo_dir = os.path.join(repo_dir, 'test-repo')
    project_template = find_template(repo_dir)

    assert 'test-repo' in project_template
    assert 'cookiecutter' in project_template
    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-21 10:42:13.967554
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    dest_dir = tempfile.mkdtemp()
    filepath = os.path.join(dest_dir, 'cookiecutter-pypackage')
    os.mkdir(filepath)
    os.mkdir(os.path.join(dest_dir, 'cookiecutter-otherpackage'))

    assert find_template(dest_dir) == os.path.join(dest_dir, 'cookiecutter-pypackage')

    shutil.rmtree(dest_dir)

# Generated at 2022-06-21 10:42:14.535026
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:42:24.700551
# Unit test for function find_template
def test_find_template():
    # mkdtemp is unit tested in CPython test_tempfile.py
    from tempfile import mkdtemp
    import shutil

    repo_dir = mkdtemp()  # Create a temp directory

    # Create a nested temp directory that will be our template
    # It shouldn't require any special file contents to be a template
    project_temp = mkdtemp(prefix='cookiecutter-', dir=repo_dir)
    project_template = os.path.relpath(project_temp, repo_dir)
    expected_project_template = os.path.join(repo_dir, 'cookiecutter-*')

    # Call our function to find the template
    found_project_template = find_template(repo_dir)

    assert expected_project_template, found_project_template

# Generated at 2022-06-21 10:42:31.031956
# Unit test for function find_template
def test_find_template():
    """Find a template in a directory."""
    repo_dir = os.path.dirname(__file__)
    repo_dir = os.path.join(repo_dir, 'fake-repo')

    template_found = find_template(repo_dir)
    assert template_found == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:42:42.384363
# Unit test for function find_template
def test_find_template():
    """Check that the function correctly resolves the template directory.

    Testing for the unlikely condition of multiple directories
    containing the string '{{' and '}}'.
    """

    # set up test dir
    from cookiecutter import utils
    root_dir = os.path.abspath(os.path.dirname(utils.__file__))
    utils_dir = os.path.join(root_dir, 'utils')
    test_root_dir = os.path.join(utils_dir, 'tests', 'test-find-template')
    repo_dir = os.path.join(test_root_dir, '{{cookiecutter.repo_name}}')

    # create the test dir
    if not os.path.isdir(test_root_dir):
        os.makedirs(test_root_dir)

    #

# Generated at 2022-06-21 10:42:45.023522
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-21 10:42:50.585198
# Unit test for function find_template
def test_find_template():
    # Test 1: If repo_dir exists, template should be returned
    repo_dir = 'faker'
    template = find_template(repo_dir)
    assert repo_dir in template

# test_find_template()


# Generated at 2022-06-21 10:42:56.731077
# Unit test for function find_template
def test_find_template():
    """
    Make sure that the find_template function returns '.' when no
    template is present
    """
    from .utils import temporary_directory

    with temporary_directory() as tmpdir:
        dummy_dir = os.path.join(tmpdir, 'dummy_dir')
        os.makedirs(dummy_dir)
        assert find_template(dummy_dir) == '.'

# Generated at 2022-06-21 10:43:02.244884
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter

    # This is the local path to the cookiecutter-pypackage/ folder.
    repo_dir = cookiecutter('.')
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)
    assert os.path.isdir(project_template)
    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-21 10:43:06.484855
# Unit test for function find_template
def test_find_template():
    """Tests for the find_template function"""
    # Fixture for function
    repo_dir = 'tests/files/fake-repo'

    # Asserts
    assert find_template(repo_dir) == 'tests/files/fake-repo/{{cookiecutter.repo_name}}'

test_find_template()

# Generated at 2022-06-21 10:43:08.727589
# Unit test for function find_template
def test_find_template():
    find_template("/Users/pievis1/Documents/cs-training/cookiecutter-reddit/reddit_post")

# Generated at 2022-06-21 10:43:20.045508
# Unit test for function find_template
def test_find_template():
    # Mock object for repo_dir
    repo_dir_mock = 'test/testfolder'
    odir = os.getcwd()
    repo_dir = os.path.join(odir, repo_dir_mock)

    # Mock object for repo_dir_contents
    project_template_mock = 'cookiecutter-{{cookiecutter.python_package}}'
    repo_dir_contents_mock = [project_template_mock, 'someotherfile']

    # Mock function os.listdir
    def listdir_mock(repo_dir_contents_mock):
        return repo_dir_contents_mock

    # Monkey patch function os.path.join
    original_path_join = os.path.join

# Generated at 2022-06-21 10:43:30.984938
# Unit test for function find_template
def test_find_template():

    import io
    import sys
    from cookiecutter.utils import rmtree

    from .utils import make_repo

    other_repo_dir, unused = make_repo('tests/test-find-template')
    repo_dir = os.path.join(other_repo_dir, 'tests/test-find-template')

    orig_stdout = sys.stdout
    sys.stdout = io.StringIO()


# Generated at 2022-06-21 10:43:35.498240
# Unit test for function find_template
def test_find_template():
    """Test finding the template directory in a git repo."""
    this_dir = os.path.dirname(__file__)
    repo_dir = os.path.abspath(
        os.path.join(this_dir, 'tests', 'test-repo-tmpl')
    )
    result = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert result == expected

# Generated at 2022-06-21 10:43:39.440777
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests"
    project_template = find_template(repo_dir)
    assert project_template=="tests/{{cookiecutter.project_name}}"

# Generated at 2022-06-21 10:43:43.335208
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    tested_template = find_template("./tests/fake-repo-pre/")
    assert tested_template == "./tests/fake-repo-pre/{{cookiecutter.repo_name}}"

# Generated at 2022-06-21 10:43:46.828694
# Unit test for function find_template
def test_find_template():
    """Test ability to determine which folder is the project template."""
    from cookiecutter.main import cookiecutter

    project_template = cookiecutter('.', no_input=True)
    assert project_template == 'fake-repo'

# Generated at 2022-06-21 10:43:51.912634
# Unit test for function find_template
def test_find_template():
    def test_path(path):
        try:
            out = find_template(path)
            assert out is not None
            assert os.path.exists(os.path.join(path, out))
        except NonTemplatedInputDirException:
            assert os.path.exists(path)

# Generated at 2022-06-21 10:44:00.532181
# Unit test for function find_template
def test_find_template():
    print('Testing function find_template...')
    repo_dir = ''

    def test_find_template_proper_input(repo_dir):
        """
        Test find_template function with proper input.
        Should return output.
        """
        print('Testing find_template with proper input...')
        expected = '../../temp/cookiecutter-pypackage/{{cookiecutter.project_slug}}'
        actual = find_template(repo_dir)
        actual = actual.replace('\\', '/')
        try:
            assert actual == expected
            print('Passed')
        except AssertionError:
            print('Failed')
            print('Output: {0}'.format(actual))
            print('Expected output: {0}'.format(expected))


# Generated at 2022-06-21 10:44:06.780301
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    repo_dir = "./tests"
    project_template = find_template(repo_dir)

    assert project_template == './tests/{{cookiecutter.repo_name}}'
    print("test_find_template PASSED")

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-21 10:44:13.513599
# Unit test for function find_template
def test_find_template():
    from tempfile import mkdtemp
    from shutil import rmtree, copytree

    d = mkdtemp()

    # create a template dir
    template = d + '/{{cookiecutter.repo_name}}'
    os.mkdir(template)

    # create a non-template dir
    not_template = d + '/not_a_template'
    os.mkdir(not_template)

    t = find_template(d)
    assert t == template

    rmtree(d)



# Generated at 2022-06-21 10:44:19.273904
# Unit test for function find_template
def test_find_template():
    """Test if a template can be found in a repo."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), os.pardir, os.pardir, 'tests',
        'fake-repo'))
    project_template = find_template(repo_dir)
    expected = os.path.abspath(os.path.join(
        os.path.dirname(__file__), os.pardir, os.pardir, 'tests',
        'fake-repo', 'fake_project'))
    assert project_template == expected



# Generated at 2022-06-21 10:44:21.003019
# Unit test for function find_template
def test_find_template():
    repo_dir = 'fake_repo_dir'

# Generated at 2022-06-21 10:44:22.810757
# Unit test for function find_template
def test_find_template():
    # TODO: Write tests for `find_template`
    pass

# Generated at 2022-06-21 10:44:26.731052
# Unit test for function find_template
def test_find_template():
    """
    Test find_template()
    """

    test_dir = 'tests/test-input-dir'
    assert find_template(test_dir) == 'tests/test-input-dir/{{cookiecutter.project_name}}'

# Generated at 2022-06-21 10:44:29.449309
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-tmpl/')=='tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:36.426022
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/Code/cookiecutter-pypackage'
    project_template = find_template(repo_dir)

    assert project_template == '/Users/audreyr/Code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:47.173020
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns expected path."""
    # Given:
    from cookiecutter import tests
    from cookiecutter.compat import which

    def mock_which(path):
        return path

    repo_dir = tests.HERE
    repo_dir_contents = os.listdir(repo_dir)
    project_template = None
    with which.patched_which(mock_which):
        # When:
        project_template = find_template(repo_dir)

    # Then:
    assert project_template is not None
    assert '{{ cookiecutter.repo_name }}' in project_template

# Generated at 2022-06-21 10:44:47.755061
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:44:51.745861
# Unit test for function find_template
def test_find_template():
    # Test similar to the test from cookiecutter/tests/test_main.py
    # The difference is here we test the special case where the
    # repo we are cookiecutting already has a cookiecutter.json in it.
    pass

# Generated at 2022-06-21 10:44:57.453509
# Unit test for function find_template
def test_find_template():
    """Verify correct template is found."""
    repo_dir = os.path.expanduser(
        '~/Development/cookiecutter-pypackage')
    assert find_template(repo_dir) == os.path.expanduser(
        '~/Development/cookiecutter-pypackage/{{cookiecutter.repo_name}}')


# Generated at 2022-06-21 10:45:04.065793
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..', '..', 'tests', 'test-find-template'
    )
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-21 10:45:08.362565
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:45:15.809283
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns expected results."""
    template_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    )
    expected = os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    repo_dir = os.path.join(template_dir, 'fake-repo')
    assert find_template(repo_dir) == expected

# Generated at 2022-06-21 10:45:18.102488
# Unit test for function find_template
def test_find_template():
    assert '/my/template' == find_template('/my/repo', 'cookiecutter-')

# Generated at 2022-06-21 10:45:25.994075
# Unit test for function find_template
def test_find_template():
    """Test that the find_template function returns the correct directory"""
    from cookiecutter.main import cookiecutter
    from hashlib import md5
    repo_dir = cookiecutter('https://github.com/audreyr/cookiecutter-pypackage.git')
    project_template = find_template(repo_dir)
    checksum = md5(project_template.encode()).hexdigest()
    assert checksum == 'a5a3737c395b2e15a5c8ae9c191b09c5'

# Generated at 2022-06-21 10:45:37.109748
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function works."""
    logger.info('verify that find template works')

    assert(1 == 1)
    # TODO: create a test repo, clone it, then verify


# Generated at 2022-06-21 10:45:39.709439
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds a template.

    This is a unit test for the function find_template.
    """
    assert os.path.isfile(find_template(os.getcwd()))

# Generated at 2022-06-21 10:45:41.431334
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:50.497288
# Unit test for function find_template
def test_find_template():
    # When repo_dir is a root cookiecutter-template dir
    repo_dir = 'tests/fake-repo/'
    assert find_template(repo_dir) == 'tests/fake-repo/{{cookiecutter.repo_name}}'

    # When repo_dir is a subdir of a cookiecutter-template dir
    repo_dir = 'tests/fake-repo/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == 'tests/fake-repo/{{cookiecutter.repo_name}}'

    # When repo_dir is a root dir without a cookiecutter-template dir
    repo_dir = 'tests/fake-repo-no-template/'
    assert find_template(repo_dir) == None


# Generated at 2022-06-21 10:45:54.527063
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = 'C:\PycharmProjects\Cookiecutter\tests\test-find-template'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:46:02.534780
# Unit test for function find_template
def test_find_template():
    repo_dir = "/your/local/clone/directory"
    repo_dir_contents = os.listdir(repo_dir)
    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item

    assert project_template == os.path.join(repo_dir, project_template)

# Generated at 2022-06-21 10:46:11.312919
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo-pre-gen'
    )
    expected_output = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo-pre-gen',
        '{{cookiecutter.project_slug}}'
    )

    actual_output = find_template(repo_dir=repo_dir)
    assert expected_output == actual_output



# Generated at 2022-06-21 10:46:17.155834
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'repos', 'djangocms_installer-cookiecutter-template')
    template_path = os.path.join(repo_dir, 'cookiecutter-djangocms-{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == template_path


# Generated at 2022-06-21 10:46:28.010666
# Unit test for function find_template
def test_find_template():
    """Run the tests for find_template."""
    from cookiecutter import utils
    from nose.tools import raises
    from git import Repo

    path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests'))

    repo_dir = os.path.join(path, 'fake-repo-tmpl')
    project_template = utils.find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test that it works when the repo's name is cookiecutter-something
    repo_dir = os.path.join(path, 'fake-repo-py')

# Generated at 2022-06-21 10:46:28.668645
# Unit test for function find_template
def test_find_template():
  pass

# Generated at 2022-06-21 10:46:43.239707
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo-tmpl') == 'tests/test-repo-tmpl/cookiecutter-pypackage'

# Generated at 2022-06-21 10:46:50.500643
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo-templated',
    )

    template_dir = find_template(repo_dir)

    assert template_dir

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo-non-templated',
    )

    try:
        template_dir = find_template(repo_dir)
    except NonTemplatedInputDirException:
        # Expected
        pass
    else:
        assert False

# Generated at 2022-06-21 10:46:58.057071
# Unit test for function find_template
def test_find_template():
    template = "{{cookiecutter.project_name}}"
    repo_dir = "https://github.com/audreyr/cookiecutter-pypackage.git"
    assert find_template(template) == template
    assert find_template(repo_dir) == \
        "https://github.com/audreyr/cookiecutter-pypackage.git/{{cookiecutter.project_name}}"

# Generated at 2022-06-21 10:47:02.915772
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    find_template('/tmp/tests/input_dir/')
    find_template('/tmp/tests/input_dir')

    try:
        find_template('/tmp/tests/input_dir2/')
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError('This repo should not contain a template.')

# Generated at 2022-06-21 10:47:10.555245
# Unit test for function find_template
def test_find_template():
    # TODO: Reorganize tests so this test doesn't assume that the tests
    # are being run from the module's parent directory.
    # TODO: Need to have a test for failure case as well
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), 'fake-repo-pre'
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:47:20.301882
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        '..',
        'tests',
        'test-find-template')
    expected_template_dir = os.path.join(
        repo_dir,
        'cookiecutter-{{cookiecutter.repo_name}}')
    project_template_dir = find_template(repo_dir)
    assert expected_template_dir == project_template_dir

# Generated at 2022-06-21 10:47:28.760654
# Unit test for function find_template
def test_find_template():
    # Project template as first item in directory
    project_template = find_template('tests/fake-repo-pre/')
    expected_template = os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert project_template == expected_template

    # Project template as second item in directory
    project_template = find_template('tests/fake-repo-post/')
    expected_template = os.path.abspath('tests/fake-repo-post/{{cookiecutter.repo_name}}')
    assert project_template == expected_template

# Generated at 2022-06-21 10:47:30.100033
# Unit test for function find_template
def test_find_template():
    find_template('tests/test-find-template/fake-repo-tmpl')

# Generated at 2022-06-21 10:47:33.006388
# Unit test for function find_template
def test_find_template():
    """Check that the correct project template is found."""
    find_template('/Users/audreyr/projects/cookiecutter-pypackage')

# Generated at 2022-06-21 10:47:37.106021
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)

    full_test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'tests/test-repo-pre/')
    expected_template = os.path.join(
        full_test_dir, '{{cookiecutter.repo_name}}'
    )

    assert project_template == expected_template

# Generated at 2022-06-21 10:48:05.735987
# Unit test for function find_template
def test_find_template():
    import os
    repo_dir = os.path.abspath('tests' + os.sep + 'test-repo-pre')
    project_template = find_template(repo_dir)

# Generated at 2022-06-21 10:48:07.327938
# Unit test for function find_template
def test_find_template():
    assert find_template('testdir') == 'testdir/testdir/yourproject'

# Generated at 2022-06-21 10:48:13.944524
# Unit test for function find_template
def test_find_template():
    """Test to find_template function """
    os.chdir("..")
    repo_dir = os.getcwd()
    os.chdir("tests")
    assert 'cookiecutter-pypackage' == os.path.basename(find_template(repo_dir))
    assert 'cookiecutter-pypackage' == os.path.basename(find_template('../'))
    
    



# Generated at 2022-06-21 10:48:17.227188
# Unit test for function find_template
def test_find_template():
    from tests.test_utils import fixture

    assert find_template(fixture('non-template')) == \
        os.path.abspath(fixture('non-template', 'mytemplate'))



# Generated at 2022-06-21 10:48:18.128594
# Unit test for function find_template
def test_find_template():
    find_template(os.getcwd())

# Generated at 2022-06-21 10:48:19.001019
# Unit test for function find_template
def test_find_template():
    assert os.path.join(os.getcwd(), 'foo') == find_template('foo')

# Generated at 2022-06-21 10:48:25.906348
# Unit test for function find_template
def test_find_template():
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as repo_dir:
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-pypackage'))
        project_dir = find_template(repo_dir)
        assert project_dir == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:48:31.816823
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/Documents/dev/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/Documents/dev/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:48:35.979139
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..')
    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:48:36.385362
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:49:28.383984
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fixtures', 'fake-repo')
    find_template(repo_dir)

# Generated at 2022-06-21 10:49:30.459780
# Unit test for function find_template
def test_find_template():

    repo_dir = '~/cookiecutters/foo'
    assert find_template(repo_dir) == 'foo'



# Generated at 2022-06-21 10:49:42.209430
# Unit test for function find_template
def test_find_template():
    """Verify function find_template()."""
    import tempfile
    import shutil
    import os

    os_name = os.name
    test_cookiecutter_template_name = 'cookiecutter_template'
    test_cookiecutter_template_path = os.path.join(
        tempfile.mkdtemp(),
        test_cookiecutter_template_name
    )

    if os_name == 'nt':
        test_cookiecutter_template_path = test_cookiecutter_template_path.replace(
            '\\',
            '/'
        )
    os.makedirs(test_cookiecutter_template_path)
    test_cookiecutter_template_path = os.path.dirname(
        test_cookiecutter_template_path
    )


# Generated at 2022-06-21 10:49:44.635872
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/repo') == '/home/vagrant/repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:49:50.169756
# Unit test for function find_template
def test_find_template():
    """
    Test find_template
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests')
    assert find_template(repo_dir) == os.path.join(repo_dir, 'fake-repo-pre')

# Generated at 2022-06-21 10:49:55.212447
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/Documents/projects'
    project_template_name = 'cookiecutter-pypackage-1'
    test_template_path = '/Users/audreyr/Documents/projects/cookiecutter-pypackage-1/{{cookiecutter.repo_name}}'

    test_template = find_template(repo_dir)

    assert test_template == test_template_path

# Generated at 2022-06-21 10:50:03.189788
# Unit test for function find_template
def test_find_template():
    """Verify function find_template."""
    from cookiecutter import repo

    template_name = 'fake_repo'
    cloned_repo = repo.clone(template_name)

    # Run function under test
    template_dir = find_template(cloned_repo)

    assert template_dir


# TODO: Refactor this function. Can we make it even more straightforward?

# Generated at 2022-06-21 10:50:03.835220
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:50:09.398736
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from .testutils import TEST_FIXTURE_DIR, TEST_REPO_DIR, TEST_TEMPLATE_DIR
    repo_dir = os.path.join(TEST_FIXTURE_DIR, TEST_REPO_DIR)
    result = find_template(repo_dir)
    expected = os.path.join(repo_dir, TEST_TEMPLATE_DIR)
    assert result == expected

# Generated at 2022-06-21 10:50:11.760143
# Unit test for function find_template
def test_find_template():
    assert find_template('~/cookiecutters/python_boilerplate/tests') == 'tests/{{ cookiecutter.repo_name }}'