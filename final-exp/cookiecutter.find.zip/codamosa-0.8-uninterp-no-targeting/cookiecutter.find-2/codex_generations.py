

# Generated at 2022-06-21 10:41:56.580182
# Unit test for function find_template
def test_find_template():
    """
    find_template returns the project template
    """
    import pytest

    repo_dir = 'tests/fake-repo-pre/'
    res = find_template(repo_dir)
    assert res == os.path.join(repo_dir, '{{cookiecutter.project_name}}')


# Generated at 2022-06-21 10:41:58.245425
# Unit test for function find_template
def test_find_template():
    find_template('/home/username/workspace/ProjectA/cookiecutter-ProjectA')

# Generated at 2022-06-21 10:42:04.075052
# Unit test for function find_template
def test_find_template():
    """Find the project template in a newly cloned repo."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), 'tests', 'test-find-template', 'cookiecutter-test'
    )

    project_template = find_template(repo_dir)

    expected = os.path.join(
        os.path.dirname(__file__), 'tests', 'test-find-template', 'cookiecutter-test', '{{cookiecutter.repo_name}}'
    )
    assert project_template == expected

# Generated at 2022-06-21 10:42:04.640437
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:42:06.640507
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir='') == None


# Generated at 2022-06-21 10:42:10.072213
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template"""
    assert find_template('tests/fake-repo-pre/') == \
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:42:15.434835
# Unit test for function find_template
def test_find_template():
    """
    Tests the find_template function against the fakerepo fixture.
    """
    from cookiecutter.tests.test_replay import fixture

    result = find_template(fixture('fakerepo'))
    assert result == fixture('fakerepo/fake-repo')

# Generated at 2022-06-21 10:42:19.246452
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/test-find-template'
    project_template = find_template(repo_dir)
    assert project_template == './tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:29.627432
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    from cookiecutter import utils
    from cookiecutter.tests import fake_repo
    from cookiecutter import repository

    original_cwd = os.getcwd()
    fake_repo.bake()

    # Add another random child dir to `fake_repo`
    os.makedirs(os.path.join(utils.workdir, 'random'))

    template = repository.determine_repo_dir('file:///fake-repo-tmpl',
                                             checkout=None)

    assert os.path.isdir(template)

    shutil.rmtree(fake_repo.root_dir)
    os.chdir(original_cwd)

# Generated at 2022-06-21 10:42:31.792450
# Unit test for function find_template
def test_find_template():
    """Verify find_template() function."""
    find_template('tests/test-repo-pre/')

# Generated at 2022-06-21 10:42:39.572371
# Unit test for function find_template
def test_find_template():
    here = os.path.abspath(os.path.dirname(__file__))
    fixture_path = os.path.join(here, 'test-data/test-repo', '{{cookiecutter.repo_name}}')

    assert find_template(
        repo_dir=os.path.join(here, 'test-data/test-repo')
    ) == fixture_path


# Generated at 2022-06-21 10:42:44.813469
# Unit test for function find_template
def test_find_template():
    """Verify CookiecutterDjango/tests/test-cookiecutter-repo."""
    repo_dir = 'CookiecutterDjango/tests/test-cookiecutter-repo'
    project_template = '/localdev/git/CookiecutterDjango/tests/test-cookiecutter-repo/{{cookiecutter.project_slug}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:42:47.460262
# Unit test for function find_template
def test_find_template():
    """Assert that it correctly finds 'project_template' dir name"""
    template_dir = 'tests/test-input/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-input/fake-repo-pre') == template_dir

# Generated at 2022-06-21 10:42:51.596305
# Unit test for function find_template
def test_find_template():
    """Find the cookiecutter-pypackage template in a git repo."""
    assert(os.path.join('cookiecutter-pypackage', '{{cookiecutter.repo_name}}')) in \
        find_template('tests/test-repo-pre/')

# Generated at 2022-06-21 10:42:56.428730
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template(repo_dir = 'tests/fake-repo-pre/') is not None
    assert find_template(repo_dir = 'tests/fake-repo-pre/') == 'tests/fake-repo-pre/fake-project-template'

# Generated at 2022-06-21 10:43:03.304975
# Unit test for function find_template
def test_find_template():
    """Tests for the function find_template"""
    import tempfile
    temp_dir = tempfile.mkdtemp()

    os.mkdir(os.path.join(temp_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(temp_dir, '.git'))
    os.mkdir(os.path.join(temp_dir, 'README.md'))

    assert find_template(temp_dir) == os.path.join(temp_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:43:09.159056
# Unit test for function find_template
def test_find_template():
    """Ensure that find_template is working correctly."""
    from cookiecutter.main import cookiecutter
    import shutil

    # Create a fake cookiecutter template in tmp
    tmp_dir = os.path.realpath(os.path.join('tests', 'fake-repo-pre'))
    shutil.copytree(os.path.join(tmp_dir, '{{cookiecutter.repo_name}}'),
                    os.path.join(tmp_dir, 'tests'))

    result = cookiecutter(
        'tests',
        no_input=True,
        extra_context={
            'repo_name': 'tests',
        },
    )
    assert os.path.exists(result)

# Generated at 2022-06-21 10:43:12.369027
# Unit test for function find_template
def test_find_template():
    from cookiecutter.generate import test_find_template
    if test_find_template():
        logger.debug("function find_template: passed")
    else:
        logger.debug("function find_template: failed")

# Generated at 2022-06-21 10:43:23.817830
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.utils import rmtree

    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'fake-repo')

    # Repo dir is a non-templated dir
    with pytest.raises(NonTemplatedInputDirException):
        find_template(repo_dir)

    # Repo dir is a templated dir
    with pytest.raises(NonTemplatedInputDirException):
        find_template(os.path.join(repo_dir, 'fake_project'))
    rmtree(os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', '.cookiecutters'))

# Generated at 2022-06-21 10:43:26.685140
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-21 10:43:31.781857
# Unit test for function find_template
def test_find_template():
    path = os.path.expanduser('~/workspace/cookiecutter-demo')
    template_path = os.path.expanduser('~/workspace/cookiecutter-demo/{{package_name}}')
    assert find_template(path) == template_path

# Generated at 2022-06-21 10:43:41.896354
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works properly."""
    import tempfile
    from cookiecutter import utils
    template_dir = os.path.join(tempfile.gettempdir(), 'cookie', 'cookiecutter-pypackage')
    os.makedirs(template_dir)
    repo_dir = os.path.join(tempfile.gettempdir(), 'cookie')
    utils.make_sure_path_exists(repo_dir)
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
            repo_dir,
            'cookiecutter-pypackage'
    )

# Generated at 2022-06-21 10:43:46.936250
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() finds the template dir in a git repo.

    Currently this test is a dummy that just calls the function and asserts
    that no exception is thrown.
    """
    test_repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo', 'input')
    find_template(test_repo_dir)

# Generated at 2022-06-21 10:43:57.546260
# Unit test for function find_template
def test_find_template():
    """
    Test that find_template() works properly.
    """
    import json
    import tempfile
    from random import randrange
    from sys import version_info
    from cookiecutter.generate import generate_context

    # Make a temporary working directory
    basepath = tempfile.mkdtemp()

    # Clone cookiecutter-pypackage into temporary directory
    if version_info[0] == 2:
        from commands import getstatusoutput
        getstatusoutput('git clone '
                        'https://github.com/audreyr/cookiecutter-pypackage.git '
                        '{0}'.format(basepath))
    else:
        import subprocess

# Generated at 2022-06-21 10:43:58.941979
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    pass

# Generated at 2022-06-21 10:44:05.092243
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/olga/cookiecutter-django-crud/{{cookiecutter.app_name}}/{{cookiecutter.package_name}}') =='/home/olga/cookiecutter-django-crud/{{cookiecutter.app_name}}/{{cookiecutter.package_name}}'

# Generated at 2022-06-21 10:44:08.928290
# Unit test for function find_template
def test_find_template():
    repo_dir = ('/Users/hong/.cookiecutters/repo-name')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:44:17.657621
# Unit test for function find_template
def test_find_template():
    """Verify find_template() correctly finds the project template.

    Create a fake repository that contains a project template.
    """
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter import generate

    # Create fake repo
    temp_repo_dir = tempfile.mkdtemp()
    logger.debug('temp_repo_dir = %s', temp_repo_dir)
    repo_contents = [
        'this/is/not/the/template/project/',
        'neither/is/this/one/',
        '{{cookiecutter.repo_name}}/'
    ]
    for item in repo_contents:
        item_dir = os.path.join(temp_repo_dir, item)

# Generated at 2022-06-21 10:44:29.654565
# Unit test for function find_template
def test_find_template():
    fake_repo_dir = 'tests/fake-repo-pre/'
    fake_repo_dir_contents = os.listdir(fake_repo_dir)
    logger.debug(fake_repo_dir_contents)
    assert os.path.isdir('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert os.path.isdir('tests/fake-repo-pre/{{cookiecutter.repo_name}}/{{cookiecutter.project_name}}')
    assert os.path.isdir('tests/fake-repo-pre/{{cookiecutter.repo_name}}/{{cookiecutter.project_name}}/{{cookiecutter.project_name}}')

# Generated at 2022-06-21 10:44:30.182538
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:44:43.789596
# Unit test for function find_template
def test_find_template():
    """Find template in a directory"""
    from cookiecutter import utils

    with utils.work_in(
            os.path.join(os.path.dirname(__file__), 'fake-repo')
    ):
        template_path = find_template(os.getcwd())
        assert template_path == os.path.join(os.getcwd(), '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:44:50.765549
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree
    from git import Repo

    path = '/tmp/non_templated_input_dir_exception_test'
    rmtree(path)

    logger.debug('Cloning test repo into %s', path)
    Repo.clone_from(
        'https://github.com/audreyr/cookiecutter-pypackage.git', path
    )

    try:
        find_template(path)
    except NonTemplatedInputDirException:
        os.rmdir(path)
        return True
    else:
        os.rmdir(path)
        raise AssertionError('NonTemplatedInputDirException not raised')

# Generated at 2022-06-21 10:44:54.029027
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-find-template/bad-cookiecutter-jhsingle-12345'
    assert find_template(repo_dir)



# Generated at 2022-06-21 10:44:57.918932
# Unit test for function find_template
def test_find_template():
    logger.debug('Testing find_template')
    assert find_template('tests/fake-repo-pre/') == os.path.abspath(
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}/')

# Generated at 2022-06-21 10:45:07.308335
# Unit test for function find_template
def test_find_template():
    """Basic unit test for function find_template()."""
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'


# For the following test to pass, a directory named `repo_dir` must be created
# in the root dir of this project, containing a `tests/fake-repo-pre` directory
# (which contains a `README.md` file) and a `tests/fake-repo-post` directory
# (which contains a `README.md` file).

# Generated at 2022-06-21 10:45:19.052859
# Unit test for function find_template
def test_find_template():
    """
    Unit test for :function find_template.
    """
    from unittest import TestCase
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    class TestFixtures(TestCase):
        def setUp(self):
            self.cwd = os.getcwd()

            self.tempdir = tempfile.mkdtemp()
            os.chdir(self.tempdir)

            os.makedirs('foo')
            open('foo/cookiecutter.json', 'w').close()
            os.mkdir('bar')
            open('foo/README.md', 'w').close()

        def tearDown(self):
            os.chdir(self.cwd)
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-21 10:45:23.637031
# Unit test for function find_template
def test_find_template():
    import os
    import pkg_resources

    test_file = pkg_resources.resource_filename('cookiecutter', 'tests/test-find-template/')
    assert find_template(test_file) == os.path.join(test_file, 'good-cookiecutter-{{cookiecutter.author}}')



# Generated at 2022-06-21 10:45:27.168739
# Unit test for function find_template
def test_find_template():
    os.chdir('tests/fake-repo-pre/')

# Generated at 2022-06-21 10:45:29.518839
# Unit test for function find_template
def test_find_template():
    """Test that find_template works correctly."""
    assert find_template('/home/myuser/myrepo') == '/home/myuser/myrepo'


# Generated at 2022-06-21 10:45:33.061455
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/jonathanchang/Desktop/github/cookiecutter-project/tests/sample_repos/non_templated/'
    project_template = find_template(repo_dir)
    print(project_template)
    # assert repo_dir_contents == ['fake_repo']


# Generated at 2022-06-21 10:45:50.005743
# Unit test for function find_template
def test_find_template():
    try:
        os.chdir(os.path.dirname(__file__))
    except:
        pass
    os.chdir('../tests')

    os.chdir('fake-repo-tmpl')
    repo_dir = os.getcwd()
    project_template = find_template(repo_dir)
    assert project_template == 'fake-repo-tmpl/{{cookiecutter.repo_name}}'
    os.chdir('../..')

# test_find_template()

# Generated at 2022-06-21 10:45:55.507795
# Unit test for function find_template
def test_find_template():
    """ Find template inside src/cookiecutter/tests/test-repo """
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            'test-repo',
        )
    )
    project_template_path = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    project_template = find_template(repo_dir)
    assert project_template == project_template_path

# Generated at 2022-06-21 10:45:59.396150
# Unit test for function find_template
def test_find_template():
    find_template(os.path.join(os.getcwd(), "cookiecutter/tests/fake-repo-pre/{{cookiecutter.repo_name}}"))

# Generated at 2022-06-21 10:46:03.304636
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    with pytest.raises(NonTemplatedInputDirException):
        find_template('cheesecake')

# Generated at 2022-06-21 10:46:13.413578
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template


# Generated at 2022-06-21 10:46:25.439869
# Unit test for function find_template
def test_find_template():
    # Create a temporary directory
    import tempfile
    temp_dir = tempfile.mkdtemp()
    # Create a temporary git repo
    import git
    temp_repo = git.Repo.init(temp_dir)
    # Create a file in this repo
    target_file = os.path.join(temp_dir, "target.txt")
    with open(target_file, "w") as f:
        f.write('A file in a repository')
    temp_repo.index.add([target_file])
    temp_repo.index.commit("Add target file")

    # Generate a template for this target file
    template = os.path.join(temp_dir, "cookiecutter-project")
    os.makedirs(template)

# Generated at 2022-06-21 10:46:29.342117
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/user/code/some-great-project/'
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)
    assert os.path.join('{{cookiecutter.repo_name}}',
                        '{{cookiecutter.repo_name}}',
                        '{{cookiecutter.repo_name}}.py')



# Generated at 2022-06-21 10:46:29.919183
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:46:30.460698
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-21 10:46:33.663522
# Unit test for function find_template
def test_find_template():
    assert find_template('/tmp') == None

    assert find_template('/tmp/cookiecutter-pypackage') == '/tmp/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:46:58.869168
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-21 10:47:10.111603
# Unit test for function find_template
def test_find_template():
    """Test the function find_template."""

    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    file1 = os.path.join(repo_dir, 'file')
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    file2 = os.path.join(repo_dir, 'file2')

    try:
        # Create three files
        for path in (file1, project_template, file2):
            fh = open(path, 'w')
            fh.close()

        # Find the templated project
        found_template = find_template(repo_dir)

        assert found_template == project_template
    finally:
        shutil.rmtree(repo_dir)


# Generated at 2022-06-21 10:47:22.803695
# Unit test for function find_template
def test_find_template():
    from tempdir import tempdir
    from shutil import copytree

    from cookiecutter.config import USER_CONFIG_PATH
    from cookiecutter import utils

    with tempdir() as template_dir:
        os.mkdir(os.path.join(template_dir, 'test_template'))
        os.mkdir(os.path.join(template_dir, 'test_template', '{{cookiecutter.repo_name}}'))
        os.mkdir(os.path.join(template_dir, 'test_template', 'not_project_template'))
        os.mkdir(os.path.join(template_dir, 'test_template', '{{cookiecutter.repo_name}}', '{{cookiecutter.dir_name}}'))

# Generated at 2022-06-21 10:47:27.712765
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__),'..','..','tests','test-repo-pre')
    assert find_template(repo_dir) == os.path.join(repo_dir,'{{cookiecutter.repo_name}}')



# Generated at 2022-06-21 10:47:37.031097
# Unit test for function find_template
def test_find_template():
    os.makedirs(r'C:\Users\james\Documents\GitHub\cookiecutter-pypackage\{{cookiecutter.package_name}}')
    fs = [
        os.path.join(r'C:\Users\james\Documents\GitHub', 'cookiecutter-pypackage'),
        os.path.join(r'C:\Users\james\Documents\GitHub', 'cookiecutter-pypackage', '{{cookiecutter.package_name}}')
    ]
    path = find_template(r'C:\Users\james\Documents\GitHub\cookiecutter-pypackage')
    assert path in fs

# Generated at 2022-06-21 10:47:42.451496
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, 'tests', 'fake-repo')
    correct_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == correct_template

# Generated at 2022-06-21 10:47:46.219197
# Unit test for function find_template
def test_find_template():
    """Ensure that find_template returns the correct directory name"""
    from cookiecutter.main import cookiecutter
    example_path = cookiecutter('tests/test-cookiecutter-repos/simple', no_input=True)
    assert os.path.join(example_path, 'crazy-project') == find_template(example_path)



# Generated at 2022-06-21 10:47:52.669567
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests', 'test-repo')
    print(repo_dir)
    template_dir = find_template(repo_dir)
    print(template_dir)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:47:53.194958
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:47:54.099306
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:48:18.278374
# Unit test for function find_template
def test_find_template():
    repo_dir = 'pull'
    find_template(repo_dir)

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:48:25.959370
# Unit test for function find_template
def test_find_template():
    with open('/home/nikhil/Documents/python_project/Cookiecutter-master/cookiecutter/tests/test-find-template-repo/README.rst', 'r+') as fix:
        text = fix.read()
        text = text.replace('{{cookiecutter.project_name}}', '{{cookiecutter.project_name}}')
        fix.seek(0)
        fix.write(text)
        fix.truncate()

# Generated at 2022-06-21 10:48:35.932171
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    assert utils.find_template('tests/files/fake-repo-pre/') == 'tests/files/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert utils.find_template('tests/files/fake-repo-post/') == 'tests/files/fake-repo-post/'

if __name__ == "__main__":
    logging.basicConfig(
        format='%(levelname)s: %(message)s', level=logging.DEBUG
    )
    test_find_template()

# Generated at 2022-06-21 10:48:37.292169
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    pass



# Generated at 2022-06-21 10:48:41.105972
# Unit test for function find_template
def test_find_template():
    """Ensure that we can find the project template."""
    repo_dir = 'tests/test-repo/{{cookiecutter.repo_name}}'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-repo/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:48:43.117394
# Unit test for function find_template
def test_find_template():
    assert find_template('../') == '../{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:48:52.592446
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    test_dir = os.path.join(utils.get_user_dir(), 'tests/test-find-template')
    test_dir = os.path.normpath(test_dir)
    expected = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    expected = os.path.normpath(expected)
    url = 'https://github.com/hackebrot/cookiecutter-pypackage.git'
    template_dir = utils.check_and_clone(url, no_input=True)
    found = find_template(template_dir)
    expected = os.path.normpath(expected)
    found = os.path.normpath(found)
    assert found == expected

# Generated at 2022-06-21 10:48:59.089839
# Unit test for function find_template
def test_find_template():
    test_dir = 'tests/test-find-template'
    print('\n')

    # Test a template with a default config.
    print('Testing the template directory with a default config.')

    repo_dir = 'tests/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo/{{cookiecutter.repo_name}}'

    # Test a template with a default config.
    print('Testing the template directory with a custom config.')

    repo_dir = 'tests/fake-repo-custom-config'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-custom-config/{{project_name}}'


# # Check to see if function is being imported or run as

# Generated at 2022-06-21 10:49:05.129534
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the expected value when a template exists."""
    file_dir = os.path.dirname(__file__)
    repo = os.path.join(file_dir, 'test-templates')
    repo_dir = os.path.dirname(repo)
    project_template = find_template(repo_dir)
    assert project_template == (repo)

# Generated at 2022-06-21 10:49:13.966579
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    assert(find_template(os.path.join(os.path.dirname(__file__),
                          'fake-repo-pre/fake_repo')) ==
           os.path.join(os.path.dirname(__file__),
                        'fake-repo-pre/fake_repo/my-awesome-project'))
    try:
       find_template(os.path.join(os.path.dirname(__file__),
                                  'fake-repo-pre/non-templated'))
       assert False, 'Should have thrown an exception!'
    except NonTemplatedInputDirException:
       assert True
    else:
       assert False, 'Should have thrown an exception!'

# Generated at 2022-06-21 10:49:56.941032
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil

    dir_content = {'regular_dir': {'child_dir': {}},
                   'cookiecutter.json': None,
                   '{{cookiecutter.json}}': None,
                   'cookiecutter': {'cookiecutter.json': None}}

    temp_dir = tempfile.mkdtemp()
    create_dir_structure(temp_dir, dir_content)
    template_dir = find_template(temp_dir)

    assert os.path.join(temp_dir, dir_content.keys()[2]) == template_dir

    shutil.rmtree(temp_dir)



# Generated at 2022-06-21 10:50:01.669822
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/fake-repo-pre/'
    project_template = find_template(repo_dir)

    assert project_template == './tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:50:04.584750
# Unit test for function find_template
def test_find_template():
    assert '{{' in find_template('/Users/wilsonmar/Documents/GitHub/cookiecutter-pypackage/python-project')

# Generated at 2022-06-21 10:50:08.728322
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('./tests/test-find-template-repo')
    result = find_template(repo_dir)
    assert result == os.path.abspath('./tests/test-find-template-repo/cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:50:14.442146
# Unit test for function find_template
def test_find_template():
    """Check that the path is found and returned."""
    from cookiecutter.main import cookiecutter
    project_temp = '/Users/audreyr/Source/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    repo_dir = '/Users/audreyr/Source/cookiecutter-pypackage'
    assert find_template(repo_dir) == project_temp


# Generated at 2022-06-21 10:50:24.289011
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(os.path.dirname(current_dir)) == 'tests':
        repo_dir = os.path.abspath(os.path.join(current_dir, '../tests'))
    else:
        repo_dir = os.path.abspath(os.path.join(current_dir, 'tests'))

    template_dir = os.path.join(repo_dir, 'cookiecutter-project-template')

    assert find_template(repo_dir) == template_dir

# Generated at 2022-06-21 10:50:33.934902
# Unit test for function find_template
def test_find_template():
    """Test that function find_template returns proper working directory."""
    template_dir_name = '{{ cookiecutter.repo_name }}'
    template_dir_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        '..',
        'tests',
        'fake-repo',
        template_dir_name
    )

    result_dir_path = find_template(
        repo_dir=os.path.dirname(template_dir_path)
    )

    assert os.path.exists(result_dir_path)
    assert result_dir_path == template_dir_path

# Generated at 2022-06-21 10:50:34.524878
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:50:38.053442
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/test_repo'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:50:41.041394
# Unit test for function find_template
def test_find_template():
    """Test that find_template finds the correct project template directory."""
    assert find_template('tests/test-checkout') == 'tests/test-checkout/{{cookiecutter.repo_name}}'