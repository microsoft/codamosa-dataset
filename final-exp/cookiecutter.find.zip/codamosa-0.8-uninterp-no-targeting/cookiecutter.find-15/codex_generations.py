

# Generated at 2022-06-21 10:41:53.630497
# Unit test for function find_template
def test_find_template():
    path = None
    project_template = find_template('/Users/valerie/Desktop/cookiecutter-django/tests/')
    assert project_template == "/Users/valerie/Desktop/cookiecutter-django/tests/{{cookiecutter.repo_name}}"


# Generated at 2022-06-21 10:41:59.038494
# Unit test for function find_template
def test_find_template():
    """Test function find_template"""

    import os
    import shutil
    from cookiecutter import utils

    repository_dir = os.path.join(os.path.dirname(__file__), '..', '..')
    template_dir = utils.find_template(repository_dir)
    assert template_dir == os.path.join(repository_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:42:02.997179
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), "..", "tests", "fake-repo")
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-repo', 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:42:15.024431
# Unit test for function find_template
def test_find_template():
    import os
    os.mkdir('repo_dir')

# Generated at 2022-06-21 10:42:18.546994
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/code/cookiecutter-pep8') == '/home/audreyr/code/cookiecutter-pep8/cookiecutter-pep8'


# Generated at 2022-06-21 10:42:29.532712
# Unit test for function find_template
def test_find_template():
    """A unit test for find_template."""

    import tempfile

    test_template_dir = tempfile.mkdtemp()
    test_parent_dir = tempfile.mkdtemp()
    test_directory_input = tempfile.mkdtemp()

    test_parent_dir_contents = ['dummy_dir', 'dummy_file.py']
    for item in test_parent_dir_contents:
        os.chdir(test_parent_dir)
        with open(item, 'w') as f:
            pass

    test_dir_contents = [
        'README.md',
        'cookiecutter.json',
        '{{cookiecutter.project_name}}',
        'dummy_dir',
        'dummy_file.py'
    ]

# Generated at 2022-06-21 10:42:30.560291
# Unit test for function find_template
def test_find_template():
    # TODO
    return

# Generated at 2022-06-21 10:42:35.081078
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'tests', 'fake-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:42:35.909739
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template.
    """
    pass

# Generated at 2022-06-21 10:42:38.609426
# Unit test for function find_template
def test_find_template():
    """Section to test function find_template"""
    os.chdir(os.path.join(
        os.path.abspath(os.path.join(os.path.dirname(__file__), '..')),
        'tests',
        'files',
        'test_find_template'
))
    find_template()

# Generated at 2022-06-21 10:42:43.875913
# Unit test for function find_template
def test_find_template():
    """Find template in local input directory."""
    repo_dir = os.getcwd()
    project_template = find_template(repo_dir)
    assert project_template == '{{ cookiecutter.project_slug }}'

# Generated at 2022-06-21 10:42:49.783513
# Unit test for function find_template
def test_find_template():
    """Verify function find_template."""
    import shutil
    import tempfile

    # Create a fake project template in a temporary directory
    temp_dir = tempfile.mkdtemp()
    temp_subdir = os.path.join(temp_dir, 'cookiecutter-{{project_name}}')
    os.makedirs(temp_subdir)

    # Test if the directory is found
    try:
        template_dir = find_template(temp_dir)
    except NonTemplatedInputDirException:
        template_dir = None

    assert template_dir == temp_subdir

    # Test if the directory isn't found
    os.remove(os.path.join(temp_subdir, 'cookiecutter.json'))

# Generated at 2022-06-21 10:42:51.376746
# Unit test for function find_template
def test_find_template():
    project_template = find_template(r'c:\gitrepos\todomvc_django')

# Generated at 2022-06-21 10:42:55.354757
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/barry/cookiecutters/pycon2015-pyramid') == '/home/barry/cookiecutters/pycon2015-pyramid/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:58.345813
# Unit test for function find_template
def test_find_template():
    print(find_template("/home/dev/test_cookiecutter_cookiecutter/test_cookiecutter/dummy_repo/cookiecutter-pypackage"))


# Generated at 2022-06-21 10:43:05.239273
# Unit test for function find_template
def test_find_template():
    import tempfile

    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, '_cookiecutter'))
    os.mkdir(os.path.join(temp_dir, 'hello-world'))
    os.mkdir(os.path.join(temp_dir, 'hello-{{cookiecutter.who}}'))

    project_template = find_template(temp_dir)

    expected_template = os.path.join(temp_dir, 'hello-{{cookiecutter.who}}')
    assert project_template == expected_template, 'unexpected template: {}'.format(project_template)

# Generated at 2022-06-21 10:43:10.217368
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    from cookiecutter.tests.test_utils import make_temporary_directory

    with make_temporary_directory() as temp_dir:
        test_dir = os.path.join(temp_dir, 'fake_repo')
        os.makedirs(test_dir)
        project_template = os.path.join(test_dir, 'cookiecutter-pipproject')
        os.makedirs(project_template)

        full_test_dir = find_template(test_dir)

    assert full_test_dir == os.path.join(test_dir, 'cookiecutter-pipproject')

# Generated at 2022-06-21 10:43:10.957660
# Unit test for function find_template
def test_find_template():
    assert False

# Generated at 2022-06-21 10:43:17.862926
# Unit test for function find_template
def test_find_template():
    here = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(here, '..', 'tests', 'fake-repo-tmpl/')
    expected_repo_dir = os.path.join(here, '..', 'tests', 'fake-repo-tmpl', 'cookiecutter-pypackage/')
    assert find_template(repo_dir) == expected_repo_dir

# Generated at 2022-06-21 10:43:23.972097
# Unit test for function find_template
def test_find_template():
    """Verify `find_template` function logic."""
    repo_dir = os.path.join(os.getcwd(), 'tests/fake-repo')
    template_path = find_template(repo_dir)
    template_name = os.path.basename(template_path)

    assert template_name == 'cookiecutter-pypackage'

# Generated at 2022-06-21 10:43:29.032199
# Unit test for function find_template
def test_find_template():
    pass
    # TODO: unit test for fin_template



# Generated at 2022-06-21 10:43:30.247620
# Unit test for function find_template
def test_find_template():
    """Verify the 'find_template' function works correctly."""
    pass

# Generated at 2022-06-21 10:43:33.115107
# Unit test for function find_template
def test_find_template():
    github_repo = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir = 'audreyr-cookiecutter-pypackage'
    project_template = find_template('/home/audreyr/git/' + repo_dir)
    assert project_template == '/home/audreyr/git/audreyr-cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:35.817555
# Unit test for function find_template
def test_find_template():
    assert find_template('test/fake-repo-pre/') == 'test/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:45.319091
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = ['cookiecutter-pypackage',
                         'cookiecutter-example',
                         'cookiecutter-pypackage-egg',
                         'cookiecutter-example-1',
                         'cookiecutter-example-2',
                         'cookiecutter-{{cookiecutter-example-3}}']

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    assert project_template == 'cookiecutter-{{cookiecutter-example-3}}'

# Generated at 2022-06-21 10:43:46.709506
# Unit test for function find_template
def test_find_template():
    assert find_template('/some/dir') == None

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:43:49.752360
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:43:53.806857
# Unit test for function find_template
def test_find_template():
    repo_dir = 'cookiecutter-pypackage-master'
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-21 10:43:57.145626
# Unit test for function find_template
def test_find_template():
    """ Test find template function """
    repo_dir = 'tests/test-repo'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:44:00.018248
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-find-template/'
    expected_project_template = 'tests/test-find-template/{{cookiecutter.project_name}}/'
    project_template = find_template(repo_dir)
    assert project_template == expected_project_template

# Generated at 2022-06-21 10:44:09.304156
# Unit test for function find_template
def test_find_template():
    print('Testing find_template...')
    assert find_template('') == None
    print('Done!')

# Generated at 2022-06-21 10:44:10.658457
# Unit test for function find_template
def test_find_template():
    """Test find_template method."""
    pass



# Generated at 2022-06-21 10:44:15.210559
# Unit test for function find_template
def test_find_template():
    """Run unit test for find_template function."""
    os.chdir(os.path.abspath('.'))
    dirname = os.path.join('tests', 'test-find-template')
    template = find_template(dirname)
    assert template == os.path.join(dirname, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-21 10:44:15.711918
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:44:25.906757
# Unit test for function find_template
def test_find_template():
    """
    Determines which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    cwd = os.getcwd()
    try:
        os.chdir("./tests/test-files/dummy-repo")
        assert find_template("./tests/test-files/dummy-repo") == './tests/test-files/dummy-repo/cookiecutter-{{cookiecutter.repo_name}}'
    finally:
        os.chdir(cwd)

# Generated at 2022-06-21 10:44:30.016282
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template."""
    repo_dir = './tests/files/fake-repo'
    expected = './tests/files/fake-repo/cookiecutter-{{cookiecutter.repo_name}}'
    result = find_template(repo_dir)
    assert result == expected

# Generated at 2022-06-21 10:44:32.143753
# Unit test for function find_template
def test_find_template():
    project_template = find_template('tests/test-find-template')
    assert project_template == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:44.450229
# Unit test for function find_template
def test_find_template():
    from os import path
    import shutil
    from shutil import rmtree
    from tempfile import mkdtemp
    from testing import test_dir

    templated_dir = path.join(test_dir, '_templated_dir')

    shutil.copytree(
        templated_dir,
        mkdtemp(suffix='-templated_dir_with_template')
    )
    template_dir = find_template(templated_dir)
    assert template_dir == path.join(templated_dir, '{{cookiecutter.repo_name}}')

    rmtree(templated_dir)
    shutil.copytree(
        templated_dir,
        mkdtemp(suffix='-templated_dir_no_template')
    )

# Generated at 2022-06-21 10:44:49.264863
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/ben/dev/cookiecutter-pypackage') == '/home/ben/dev/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    try:
        find_template('/home/ben/dev/cookiecutter-github')
        assert False
    except NonTemplatedInputDirException as e:
        assert True


# Generated at 2022-06-21 10:44:56.134825
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join('tests', 'fake-repo-pre')) == os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    assert find_template(os.path.join('tests', 'fake-repo-post')) == os.path.join('tests', 'fake-repo-post', '{{cookiecutter.repo_name}}')



# Generated at 2022-06-21 10:45:13.466994
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/')
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:45:14.846914
# Unit test for function find_template
def test_find_template():
    find_template('/Users/kapadia/Work/cookiecutter')

# Generated at 2022-06-21 10:45:22.617810
# Unit test for function find_template
def test_find_template():
    """Tests function `find_template`."""
    print("Test find_template")
    from cookiecutter import generate
    from cookiecutter import prompt

    answers_1 = prompt.read_user_variable('cookiecutter.json')
    repo_dir = os.path.join(
        generate.DEFAULT_LOCAL_TEMPLATE_DIR,
        answers_1['repo_dir']
    )
    project_template = find_template(repo_dir)
    assert isinstance(project_template, str)



# Generated at 2022-06-21 10:45:31.659163
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the correct template, even if it's
    in a subdirectory."""
    root_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-tmpl')
    template_dir = os.path.join(root_dir, '{{cookiecutter.repo_name}}')
    template_dir_subdir = os.path.join(template_dir, 'subdir')

    # Test that find_template works in the root directory
    assert find_template(root_dir) == template_dir
    # Test that find_template works in a subdirectory
    assert find_template(template_dir_subdir) == template_dir

# Generated at 2022-06-21 10:45:38.132668
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    project_template = tempfile.mkdtemp(dir=repo_dir)

    assert find_template(repo_dir) == project_template

    shutil.rmtree(repo_dir)



# Generated at 2022-06-21 10:45:38.708463
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:41.995870
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.expanduser('~'), 'dev', 'cookiecutter',
                            'tests', 'test-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:45:46.836160
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works as expected."""
    # Setup
    from tests.test_utils import TEST_TEMPLATE_DIR

    # Tests
    test = find_template(TEST_TEMPLATE_DIR)
    assert "cookiecutter-pypackage/" in test
    assert "cookiecutter.json" in test

# Generated at 2022-06-21 10:45:50.476077
# Unit test for function find_template

# Generated at 2022-06-21 10:45:57.101540
# Unit test for function find_template
def test_find_template():
    """A basic smoke test for the find_template function
    """
    import tempfile
    from cookiecutter.main import cookiecutter
    from shutil import rmtree
    from os import listdir

    def _test_fn(tmpdir):
        input_dir = tempfile.mkdtemp()
        cookiecutter(
            str(tmpdir),
            no_input=True,
            overwrite_if_exists=True,
            output_dir=input_dir
        )
        template = find_template(input_dir)
        assert 'cookiecutter' in listdir(template)

    tmpdir = tempfile.mkdtemp()
    _test_fn(tmpdir)
    rmtree(tmpdir)

# Generated at 2022-06-21 10:46:28.372069
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:46:35.902970
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns correct location."""
    from cookiecutter import utils

    user_config = utils.get_user_config()
    repo_dir = user_config['cookiecutters_dir']
    repo_dir = os.path.join(repo_dir, 'cookiecutter-pypackage', '')

    project_template = find_template(repo_dir)
    assert(project_template ==
           os.path.join(repo_dir, '{{cookiecutter.repo_name}}', ''))

# Generated at 2022-06-21 10:46:45.161858
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    with pytest.raises(NonTemplatedInputDirException) as exc:
        find_template("tests/fake-repo-tmpl")
    assert 'doesn\'t appear to be a valid' in exc.value.args[0]

    assert find_template("tests/fake-repo-pre/{{cookiecutter.repo_name}}") == "tests/fake-repo-pre/{{cookiecutter.repo_name}}"

# Generated at 2022-06-21 10:46:46.172727
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template."""
    pass

# Generated at 2022-06-21 10:46:57.120175
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    
    # Setup
    os.chdir(os.path.realpath(os.path.curdir))
    repo_dir = os.path.join('tests','fake-repo','{{cookiecutter.repo_name}}')
    relative_path_to_project_template = '{{cookiecutter.repo_name}}'
    
    # Test and verify
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)
    assert os.path.isdir(project_template)
    assert os.path.basename(project_template) == relative_path_to_project_template

# Generated at 2022-06-21 10:47:00.600660
# Unit test for function find_template
def test_find_template():
    pwd = os.getcwd()
    os.chdir('tests/test-find-template')
    assert find_template('.') == './{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:47:02.691465
# Unit test for function find_template
def test_find_template():
    """Verify template directory is found"""

    assert find_template('/home/user/dir') == '/home/user/dir/{{ cookiecutter.repo_name }}'

# Generated at 2022-06-21 10:47:15.106199
# Unit test for function find_template
def test_find_template():
    # Set up dirs
    template_dir = os.path.join(
        os.path.dirname(__file__), 'tests', 'test-template-dir'
    )
    os.makedirs(template_dir)
    template_name = os.path.join(
        os.path.dirname(__file__), 'tests', 'test-template-dir', 'cookiecutter-{{cookiecutter.repo_name}}'
    )
    f = open(template_name, 'w')
    f.close()
    template_name = os.path.join(
        os.path.dirname(__file__), 'tests', 'test-template-dir', 'cookiecutter-{{cookiecutter.repo_name}}', 'cookiecutter.json'
    )

# Generated at 2022-06-21 10:47:24.819195
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.utils import rmtree

    temp_dir = tempfile.mkdtemp()
    try:
        test_sub_dir = os.path.join(temp_dir, 'test_sub_dir')
        test_template_dir = os.path.join(test_sub_dir, '{{cookiecutter.repo_name}}')
        os.makedirs(test_template_dir)

        result = find_template(test_sub_dir)

        assert result == test_template_dir
    finally:
        rmtree(temp_dir)



# Generated at 2022-06-21 10:47:31.911924
# Unit test for function find_template
def test_find_template():
    import cookiecutter
    import os
    import shutil
    from cookiecutter.main import cookiecutter

    cookiecutter('tests/fake-repo-tmpl', output_dir='tests/fake-repo')
    repo_dir = 'tests/fake-repo/fake-repo-tmpl'
    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-pypackage')

    shutil.rmtree('tests/fake-repo')

# Generated at 2022-06-21 10:48:38.792048
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-tmpl',
    )
    assert os.path.join(test_repo_dir, 'fake-project-tmpl') == find_template(test_repo_dir)



# Generated at 2022-06-21 10:48:43.441859
# Unit test for function find_template
def test_find_template():
    repo_dir = '/tmp/cookiecutter-test/some-fake-repo/'
    project_template = find_template(repo_dir)
    assert project_template == '/tmp/cookiecutter-test/some-fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:48:53.191088
# Unit test for function find_template
def test_find_template():
    """
    A test for the find_template function to ensure that the function can find
    a directory in a repo that contains a Cookiecutter template.
    """
    from cookiecutter import main
    from cookiecutter.utils.paths import get_repo_dir
    from cookiecutter.config import CONFIG_DEFAULTS

    full_config = CONFIG_DEFAULTS.copy()


# Generated at 2022-06-21 10:48:59.372520
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    import unittest

    class TestFindTemplate(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_plain_dir(self):
            os.makedirs(os.path.join(self.tempdir, 'foobar'))
            self.assertRaises(
                NonTemplatedInputDirException,
                find_template,
                self.tempdir
            )

        def test_templated_dir(self):
            os.makedirs(os.path.join(self.tempdir, '{{cookiecutter.foobar}}'))
            result = find_template(self.tempdir)
           

# Generated at 2022-06-21 10:49:10.254968
# Unit test for function find_template
def test_find_template():
    """
    Test function `find_template`
    """
    from cookiecutter.utils import workdir
    from cookiecutter.main import cookiecutter

    result = cookiecutter(
        'tests/test-templates/{{cookiecutter.project_name}}',
        no_input=True,
        extra_context={'cookiecutter': {'project_name': 'code'}}
    )
    assert isinstance(result, dict)

    repo_dir = os.path.join(workdir, 'code')
    repo_dir_contents = os.listdir(repo_dir)
    assert 'cookiecutter.json' in repo_dir_contents

    project_template = find_template(repo_dir)


# Generated at 2022-06-21 10:49:16.656928
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}/'
    assert find_template('tests/test-repo-post/') == 'tests/test-repo-post/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-21 10:49:23.239005
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('test_find_template')
    if not os.path.isdir('test_find_template'):
        os.mkdir('test_find_template')
    os.mkdir(os.path.join('test_find_template', 'test_cookiecutter'))
    project_template = find_template(repo_dir)
    assert project_template == (
        os.path.abspath(os.path.join(
            'test_find_template',
            'test_cookiecutter'
        ))
    )
    os.remove('test_find_template/test_cookiecutter')
    os.rmdir('test_find_template')
    assert not os.path.isdir('test_find_template')

# Generated at 2022-06-21 10:49:25.331603
# Unit test for function find_template
def test_find_template():
    repo_dir = ''
    project_template = find_template(repo_dir)
    assert project_template == None  # should be False

# Generated at 2022-06-21 10:49:32.614081
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""
    from .compat import TemporaryDirectory
    from .main import cookiecutter

    with TemporaryDirectory() as tmpdir:

        # Create a repo containing a single template directory
        template_dir = os.path.join(tmpdir, 'fake-repo', 'cookiecutter-pypackage')
        os.makedirs(template_dir)
        output = cookiecutter(template_dir)

        assert output['project_name'] == 'pypackage'
        assert os.path.isdir(os.path.join(tmpdir, 'fake-repo', 'cookiecutter-pypackage'))

        # Create a repo containing multiple directories
        template_dir = os.path.join(tmpdir, 'fake-repo-2')

# Generated at 2022-06-21 10:49:33.804312
# Unit test for function find_template
def test_find_template():
    pass

# Not unit testable