

# Generated at 2022-06-21 10:41:57.248460
# Unit test for function find_template
def test_find_template():
    """
    Test find_template with several paths.
    """
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    assert(find_template(repo_dir) == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}')

    repo_dir = '/home/audreyr/cookiecutter-pypackage_test'
    assert(find_template(repo_dir) == '/home/audreyr/cookiecutter-pypackage_test/{{cookiecutter.repo_name}}')

    repo_dir = '/home/audreyr/cookiecutter-pypackage_again'

# Generated at 2022-06-21 10:42:00.665882
# Unit test for function find_template
def test_find_template():
    directory_pre = os.getcwd()
    os.chdir("tests/test-find-repo/fake-repo")
    path = find_template(".")
    assert path == "./{{cookiecutter.project_name}}", "test_find_template failed"
    os.chdir(directory_pre)

# Generated at 2022-06-21 10:42:05.849291
# Unit test for function find_template
def test_find_template():
    dir_to_search = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'tests',
        'fixtures', 'fake-repo'
    )

    dir_to_compare = os.path.join(dir_to_search, '{{cookiecutter.repo_name}}')

    # Ensure we get the expected project template
    assert find_template(dir_to_search) == dir_to_compare


# Generated at 2022-06-21 10:42:10.777404
# Unit test for function find_template
def test_find_template():
    work = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    project_template = find_template(work)
    assert project_template == os.path.join(work, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-21 10:42:15.791240
# Unit test for function find_template
def test_find_template():
    """Test function find_template()."""
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    find_template(os.path.join(root_dir, 'tests', 'fake-repo-tmpl'))



# Generated at 2022-06-21 10:42:16.771570
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:42:21.990223
# Unit test for function find_template
def test_find_template():
    # project_template = find_template('/Users/audreyr/work/cookiecutter-pypackage')
    project_template = find_template('/Users/audreyr/work/peter-cookiecutter')
    assert project_template == '/Users/audreyr/work/peter-cookiecutter/{{cookiecutter.project_slug}}'



# Generated at 2022-06-21 10:42:24.821438
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests')
    assert find_template(repo_dir) == os.path.join(repo_dir, 'my-fake-project')

# Generated at 2022-06-21 10:42:26.232339
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    pass

# Generated at 2022-06-21 10:42:33.327196
# Unit test for function find_template
def test_find_template():
    """Test whether function find_template returns the correct path."""

    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-data',
        'example-repo'
    )

    project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:42:41.442252
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works properly."""
    from cookiecutter import utils
    import os.path
    import tempfile

    template_dirs = ('templates', '{{ cookiecutter.repo }}')
    temp_dir = tempfile.mkdtemp(suffix='cookiecutter')
    utils.work_in(temp_dir)
    os.mkdir(template_dirs[0])
    os.mkdir(template_dirs[1])

    template_path = find_template(temp_dir)
    assert template_path == os.path.join(temp_dir, template_dirs[1])
    utils.make_sure_path_exists(os.path.join(temp_dir, template_dirs[0]))

    template_path = find_template(temp_dir)

# Generated at 2022-06-21 10:42:52.806568
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works."""
    # Create a temp directory
    tmp_dir = tempfile.mkdtemp()
    tmp_repo_dir = os.path.join(tmp_dir, 'fake-repo')

    os.mkdir(tmp_repo_dir)
    os.mkdir(os.path.join(tmp_repo_dir, 'foobar'))

    # Create a file
    fh, abs_path = tempfile.mkstemp()

    with open(abs_path, 'w') as f:
        f.write('contents')

    with open(os.path.join(tmp_repo_dir, 'foobar', 'contents.txt'), 'w') as f:
        f.write('fake-contents')


# Generated at 2022-06-21 10:42:55.861256
# Unit test for function find_template
def test_find_template():
    assert find_template('/project/tests/fixtures/fake-repo-tmpl') == '/project/tests/fixtures/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:59.296967
# Unit test for function find_template
def test_find_template():
    assert (find_template('/src/cookiecutter/tests/test_repo/fake-repo') ==
            '/src/cookiecutter/tests/test_repo/fake-repo/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:43:04.161979
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__),
                     '..',
                     'tests',
                     'test-data',
                     'fake-repo-pre-render'))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}'), project_template

# Generated at 2022-06-21 10:43:06.662823
# Unit test for function find_template
def test_find_template():
    """Test function find_template.
    """
    assert find_template('tests/fake-repo-templated/') == \
        'tests/fake-repo-templated/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-21 10:43:07.374411
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:43:13.451677
# Unit test for function find_template
def test_find_template():
    """Test `find_template` function."""
    print("Find template test")
    # assert find_template('cookiecutter-pypackage') == ['cookiecutter-pypackage/{{cookiecutter.repo_name}}']
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:14.639555
# Unit test for function find_template
def test_find_template():
    find_template('~/.cookiecutters')

# Generated at 2022-06-21 10:43:22.329459
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the correct path to the project template."""
    project_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), os.pardir, os.pardir, os.pardir, 'tests', 'fake-repo-pre'))
    assert find_template('{{cookiecutter.project_name}}', project_dir) == os.path.join(project_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-21 10:43:28.622168
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/code/cookiecutter-python') == '/Users/audreyr/code/cookiecutter-python/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:32.748320
# Unit test for function find_template
def test_find_template():
    """Validate that find_template returns correct template."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), '..', 'tests', 'fake-repo'
        )
    )
    project_template = os.path.abspath(
        os.path.join(
            repo_dir, 'cookiecutter-pypackage'
        )
    )

    template = find_template(repo_dir)
    assert template == project_template

# Generated at 2022-06-21 10:43:40.090208
# Unit test for function find_template
def test_find_template():
    """Verify that the project template is at the top level of the repo."""

    os.chdir('tests/fake-repo-pre/')
    repo_dir = os.getcwd()
    project_template = find_template(repo_dir)

    assert repo_dir in project_template
    assert '{{cookiecutter.project_name}}' in project_template

    os.chdir('../..')



# Generated at 2022-06-21 10:43:47.297829
# Unit test for function find_template
def test_find_template():
    """Validate find_template function works as expected."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_data', 'fake-repo'
    )
    expected_project_template = os.path.join(
        repo_dir, 'fake-repo', '{{cookiecutter.repo_name}}'
    )

    project_template = find_template(repo_dir)

    assert project_template == expected_project_template

# Generated at 2022-06-21 10:43:57.777782
# Unit test for function find_template
def test_find_template():
    """Test `find_template`. Return `True` if tests pass without errors.
    Should be called from the repository root directory.
    """
    # test normal
    find_template('tests/fake-repo-pre/')

    # test empty
    find_template('tests/fake-repo-no-repo/')

    # test no template found
    try:
        find_template('tests/fake-repo-no-template/')
        return False  # No template found, but should have raised an error
    except NonTemplatedInputDirException:
        pass

    # test template in sub-directory
    find_template('tests/fake-repo-subdir/')

    # test template in sub-directory with name containing curly braces
    find_template('tests/fake-repo-subdir-curly-braces/')

# Generated at 2022-06-21 10:44:04.948817
# Unit test for function find_template
def test_find_template():
    """Test that find_template() can find a project_template."""
    test_dir = os.path.join(os.path.dirname(__file__), 'test-repo-tmpl')
    result = find_template(test_dir)
    expected = os.path.join(test_dir, 'awesome-project-{{cookiecutter.repo_name}}')
    assert result == expected

# Generated at 2022-06-21 10:44:10.009739
# Unit test for function find_template
def test_find_template():
    """Assert that find_template returns correct template."""
    d = os.path.join(
        os.path.abspath(
            os.path.dirname(__file__)),
        'fake-repo-tmpl')
    tmpl_found = find_template(d)
    assert tmpl_found == os.path.join(d, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:44:15.644011
# Unit test for function find_template
def test_find_template():
    with open(os.path.join(os.path.dirname(__file__), 'test_data', 'test_repo', 'cookiecutter.json')) as f:
        assert find_template(os.path.abspath(os.path.join(os.path.dirname(__file__), 'test_data', 'test_repo'))).endswith('test_repo/{{cookiecutter.project_dir_name}}')

# Generated at 2022-06-21 10:44:19.339199
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/sync/cookiecutter-pypackage') == '/home/vagrant/sync/cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-21 10:44:24.104587
# Unit test for function find_template
def test_find_template():
    project_template = find_template('/Users/audreyr/cookiecutter-pypackage/')
    assert project_template == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:42.634893
# Unit test for function find_template
def test_find_template():
    """Test the find_template function"""
    import shutil
    import tempfile
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    temp_dir = utils.make_empty_dir()

    # Create a fake cookiecutter.json file, so that a fake template
    # can be created.
    fake_json = os.path.join(temp_dir, 'cookiecutter.json')
    with open(fake_json, 'w') as f:
        f.write('')

    # Create a fake template.
    fake_template = os.path.join(temp_dir, '{{ cookiecutter.repo_name }}')
    shutil.copytree(temp_dir, fake_template)

    # Create a temporary directory for the unit test.
    temp_

# Generated at 2022-06-21 10:44:49.140825
# Unit test for function find_template
def test_find_template():
    """
    Return the given directory and files as a mock clone of the repo.

    :param repo_dir: Local directory of newly cloned repo.
    :param repo_url: Network location of a repo containing a project template.
    :returns mock_repo_dir: Directory containing Cookiecutter project template.
    """
    repo_dir = os.path.abspath(os.path.join('tests', 'fixtures', 'fake-repo-tmpl'))
    find_template(repo_dir=repo_dir)


# Generated at 2022-06-21 10:44:56.488781
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.dirname(__file__)

    project_template = find_template(test_repo_dir)

    assert 'tests/fake-repo' in project_template
    assert os.path.exists(project_template)
    assert os.path.isdir(project_template)
    assert 'cookiecutter' in project_template
    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-21 10:45:02.122089
# Unit test for function find_template
def test_find_template():
    """Test behavior of find_template function."""
    test_template_path = os.path.join(os.path.abspath(os.curdir), 'tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert find_template('tests/fake-repo-pre') == test_template_path

# Generated at 2022-06-21 10:45:02.879815
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:04.740629
# Unit test for function find_template
def test_find_template():
    # TODO: Create unit test for finding the template for cookiecutter
    pass

# Generated at 2022-06-21 10:45:10.002164
# Unit test for function find_template
def test_find_template():
    dir_to_search = '/home/vagrant/cookiecutter-pypackage/{{cookiecutter.project_slug}}'
    assert find_template(dir_to_search) == '/home/vagrant/cookiecutter-pypackage/{{cookiecutter.project_slug}}'


# Generated at 2022-06-21 10:45:18.146717
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..', 'tests', 'fixtures', 'fake-repo', '{{cookiecutter.repo_name}}'
    )
    template_dir = find_template(repo_dir)
    assert os.path.normpath(os.path.dirname(template_dir)) == os.path.normpath(repo_dir)
    assert os.path.basename(template_dir) == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:45:29.171042
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    from cookiecutter.main import cookiecutter
    # Given
    repo_path = 'tests/test-repo-tmpl'
    user_config_data = {'full_name': 'Your Name', 'email': 'your@email.com'}

    # When
    context = cookiecutter(
        repo_path,
        no_input=True,
        extra_context=user_config_data,
    )
    logger.debug(context)
    # Then
    assert context['cookiecutter']['full_name'] == 'Your Name'
    assert context['cookiecutter']['email'] == 'your@email.com'
    assert context['project_name'] == 'Cookiecutter'
    assert context['project_slug'] == 'cookiecutter'
    assert context

# Generated at 2022-06-21 10:45:34.128479
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template function works correctly."""

    # Test a directory with a standard structure
    assert find_template('tests/fake-repo-pre/') == \
           'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'

    # Test a directory without a standard structure
    try:
        find_template('tests/fake-repo-post/')
    except NonTemplatedInputDirException:
        pass
    else:
        assert False

# Generated at 2022-06-21 10:45:52.598390
# Unit test for function find_template
def test_find_template():
    """Test function for find_template"""
    find_template(repo_dir)

    # Testing find_template function
    assert find_template(repo_dir) == 'my_project_template'
    assert not find_template(repo_dir) == 'my_project_template'

# Generated at 2022-06-21 10:46:04.927601
# Unit test for function find_template
def test_find_template():
    """Test the find_template function.

    1. Normal usage
    2. Require `cookiecutter` in the name
    3. Require `{{` and `}}` in the name

    """
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    output = find_template(repo_dir)
    assert os.path.join(repo_dir, 'cookiecutter-pypackage') == output

    os.remove(os.path.join(repo_dir, 'cookiecutter-pypackage'))
    os.rename(os.path.join(repo_dir, 'cc-pypackage'),
              os.path.join(repo_dir, 'cookiecutter-pypackage'))
    output = find

# Generated at 2022-06-21 10:46:11.270598
# Unit test for function find_template
def test_find_template():
    from cookiecutter import repo

    fixtures_dir = 'tests/fixtures/git/git-v1/fake-repo-tmpl'

    expected_project_template = os.path.realpath(
        os.path.join(fixtures_dir, '{{cookiecutter.repo_name}}')
    )

    project_template = find_template(fixtures_dir)

    assert expected_project_template == project_template

# Generated at 2022-06-21 10:46:15.560060
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/projects/cookiecutter/tests/test-repo/foobar'

    template = find_template(repo_dir)

    assert '/Users/audreyr/projects/cookiecutter/tests/test-repo/{{cookiecutter.repo_name}}' == template

# Generated at 2022-06-21 10:46:24.376951
# Unit test for function find_template
def test_find_template():
    # repo_dir = r"C:\Users\Eric\PycharmProjects\tangent-tangent-tangent\tangent-tangent-tangent\tests\test-repo-pre"
    repo_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "test-repo-pre")
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:46:26.445281
# Unit test for function find_template
def test_find_template():
    dir = os.path.join(os.path.dirname(__file__), '..')
    assert find_template(dir) == os.path.join(dir, 'cookiecutter-django')

# Generated at 2022-06-21 10:46:27.329852
# Unit test for function find_template
def test_find_template():
    result = find_template("C:\\personal")

# Generated at 2022-06-21 10:46:33.075227
# Unit test for function find_template
def test_find_template():
    ''' Unit test for find_template. '''

    import shutil

    from cookiecutter import utils

    # Create a fake git repository
    user_config_path = utils.user_config_path()
    repo_dir = os.path.join(user_config_path, 'fake-repo')
    os.mkdir(repo_dir)

    input_dir = os.path.join(repo_dir, 'fake-project-template')
    os.mkdir(input_dir)
    with open(os.path.join(input_dir, 'cookiecutter.json'), 'w') as f:
        f.write('{"a":"b"}')

    os.chdir(repo_dir)
    project_template = find_template(repo_dir)


# Generated at 2022-06-21 10:46:38.056784
# Unit test for function find_template
def test_find_template():
    """
    >>> from mock import Mock
    >>> os.path.isdir = Mock(return_value=True)
    >>> os.listdir = Mock(return_value=['cookiecutter-pypackage'])
    >>> find_template('.')
    './cookiecutter-pypackage'
    """

# Generated at 2022-06-21 10:46:38.683628
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:47:12.165002
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        '..',
        'tests',
        'test-repo',
    )
    repo_dir = os.path.abspath(repo_dir)
    logger.debug('Looking for the project template in %s', repo_dir)

    assert find_template(repo_dir)

# Generated at 2022-06-21 10:47:22.239986
# Unit test for function find_template
def test_find_template():
    """Ensure this function finds a project template directory."""
    import tempfile
    import shutil
    import string

    # Create a test directory with a real template in it
    tmp_dir = tempfile.mkdtemp()
    template_dir = os.path.join(tmp_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)

    found_template = find_template(tmp_dir)
    shutil.rmtree(tmp_dir)

    assert os.path.abspath(tmp_dir) in string.Template(found_template)

# Generated at 2022-06-21 10:47:25.820294
# Unit test for function find_template
def test_find_template():
    template_dir = 'tests/test-templates/input/{{cookiecutter.repo_name}}'
    project_template = find_template(template_dir)

    assert project_template == template_dir

# Generated at 2022-06-21 10:47:27.668936
# Unit test for function find_template
def test_find_template():
    from tests.cookiecutter import project_dir

    find_template(project_dir)



# Generated at 2022-06-21 10:47:31.354587
# Unit test for function find_template
def test_find_template():
    """Test that a project template is properly found."""
    assert find_template('tests/test-repo-tmpl/') == (
        'tests/test-repo-tmpl/{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-21 10:47:42.765040
# Unit test for function find_template
def test_find_template():
    """Test if the find_template function works."""
    import os
    import shutil
    import tempfile
    import textwrap

    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    def test_file(
        filename='',
        path='',
        content='',
        cookiecutter_path=False,
        cookiecutter_content=False
    ):
        """Create a test file."""
        file_path = os.path.join(path, filename)
        with open(file_path, 'w') as fh:
            fh.write(content)
        if cookiecutter_path:
            assertion_string = 'The project template appears to be {0}'.format(
                file_path
            )
        elif cookiecutter_content:
            assertion

# Generated at 2022-06-21 10:47:45.568040
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'test-data', 'repo-tmpl')
    find_template(repo_dir)

# Generated at 2022-06-21 10:47:46.611537
# Unit test for function find_template
def test_find_template():
    assert 'bar' == find_template('foo')

# Generated at 2022-06-21 10:47:49.954799
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    template = find_template('/Users/sid/.cookiecutters')
    print (template)
    #assert template == '/Users/sid/.cookiecutters/boilerplate'

# Generated at 2022-06-21 10:47:52.589694
# Unit test for function find_template
def test_find_template():
    repo_dir = 'cookiecutter-pypackage'
    assert find_template(repo_dir) == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:48:50.048998
# Unit test for function find_template
def test_find_template():
    """Assert that the template was successfully determined."""
    from cookie_jar import ROOT_DIR
    repo_dir = os.path.join(ROOT_DIR, 'tests/fake-repo-pre')
    print(ROOT_DIR)
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:48:52.512597
# Unit test for function find_template
def test_find_template():
    """Tests if find_template finds a project template."""
    repo_dir = os.path.join('tests', 'fake-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:48:56.087974
# Unit test for function find_template
def test_find_template():
    executable_path = os.path.abspath(os.path.join(__file__, '..', '..', '..', 'tests', 'test-repo-pre'))
    assert find_template(executable_path) == os.path.abspath(os.path.join(executable_path, '{{cookiecutter.repo_name}}'))



# Generated at 2022-06-21 10:49:04.443751
# Unit test for function find_template
def test_find_template():
    """Testing find_template"""
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    output_dir = 'tests/fake-repo-tmpl'
    repo_dir = 'tests/fake-repo'

    main.cookiecutter(
        repo_dir,
        no_input=True
    )

    project_template = find_template(output_dir)

    # Clean up our mess
    rmtree(output_dir)

    assert project_template == 'tests/fake-repo-tmpl/cookiecutter-pypackage'



# Generated at 2022-06-21 10:49:07.993230
# Unit test for function find_template
def test_find_template():
    """ Verify that find_template returns the correct value for a valid input """
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-21 10:49:13.452645
# Unit test for function find_template
def test_find_template():
    """Tests the find_template function.
    """
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..', 'tests', 'test-find-template'
        )
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:49:20.701891
# Unit test for function find_template
def test_find_template():
    import os
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.join(os.getcwd(), 'tests/test-repo-pre/')

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'hooks')

    repo_dir = os.path.join(os.getcwd(), 'tests/test-repo-post/')
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False

# Generated at 2022-06-21 10:49:22.993030
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/some-random-dir') == ('/home/some-random-dir/cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:49:25.404326
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-tmpl')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:49:26.988793
# Unit test for function find_template
def test_find_template():
    template = find_template('.')
    assert template == os.path.join('.', '{{cookiecutter.repo_name}}')


# Generated at 2022-06-21 10:51:28.861110
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    pass

# Generated at 2022-06-21 10:51:32.456446
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}'
    ))
    find_template(repo_dir)

# Generated at 2022-06-21 10:51:40.486914
# Unit test for function find_template
def test_find_template():
    assert (
        find_template('cookiecutter-pypackage/tests/test-input/{{cookiecutter.repo_name}}')
        == 'cookiecutter-pypackage/tests/test-input/{{cookiecutter.repo_name}}/cookiecutter-pypackage'
    )
    assert (
        find_template('cookiecutter-pypackage/tests/test-input/cookiecutter-pypackage')
        == 'cookiecutter-pypackage/tests/test-input/cookiecutter-pypackage/cookiecutter-pypackage'
    )

# Generated at 2022-06-21 10:51:46.168355
# Unit test for function find_template
def test_find_template():
    current_directory = os.path.dirname(os.path.abspath(__file__))
    sample_repo = os.path.join(current_directory, '..', 'tests', 'sample_repo')
    project_template = find_template(sample_repo)

    assert project_template == os.path.join(sample_repo, '{{cookiecutter.repo_name}}')
