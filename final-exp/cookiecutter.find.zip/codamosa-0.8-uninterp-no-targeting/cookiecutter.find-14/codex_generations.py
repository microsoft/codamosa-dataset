

# Generated at 2022-06-21 10:41:52.494702
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the proper string."""
    assert find_template('.') == './{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:01.528374
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a directory in the temporary directory
    repo_dir = tempfile.mkdtemp(dir=temp_dir)

    # Create a directory that could be a template and a file
    not_template_dir = tempfile.mkdtemp(dir=repo_dir)
    not_template_file = tempfile.NamedTemporaryFile(dir=repo_dir)

    # Create a directory that is a template and a file
    temp_template = 'cookiecutter-{{cookiecutter.repo_name}}'
    template = tempfile.mkdtemp(dir=repo_dir, suffix=temp_template)
    template_file = tempfile.Named

# Generated at 2022-06-21 10:42:04.261642
# Unit test for function find_template
def test_find_template():
    """Verify that find_template locates the project template."""
    assert find_template(repo_dir) == 'cookiecutter-pypackage'

# Generated at 2022-06-21 10:42:13.659840
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    from cookiecutter import utils
    expected = os.path.abspath(os.path.join(
        os.path.dirname(utils.__file__),
        'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    ))
    assert expected == find_template(
        os.path.abspath(os.path.join(
            os.path.dirname(utils.__file__),
            'tests/test-repo-pre'
        ))
    )


# Generated at 2022-06-21 10:42:22.797324
# Unit test for function find_template
def test_find_template():
    import os
    from tempfile import mkdtemp

    from cookiecutter.utils import rmtree

    repo_dir = mkdtemp()

    try:
        os.makedirs(os.path.join(repo_dir, 'cookiecutter-project-template'))
        os.makedirs(os.path.join(repo_dir, 'other-project-template'))
        os.makedirs(
            os.path.join(repo_dir, 'other-project-template', '{{cookiecutter.project_slug}}')
        )

        template_dir = find_template(repo_dir)
        assert(os.path.basename(template_dir) == 'other-project-template')
    finally:
        rmtree(repo_dir)


# Generated at 2022-06-21 10:42:27.737943
# Unit test for function find_template
def test_find_template():
    path_abs = os.path.abspath('tests/fake-repo-templated/{{cookiecutter.repo_name}}')
    print(path_abs)
    print(find_template('tests/fake-repo-templated'))
    assert path_abs == find_template('tests/fake-repo-templated')

# Generated at 2022-06-21 10:42:28.893478
# Unit test for function find_template

# Generated at 2022-06-21 10:42:33.411411
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    expected = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    actual = find_template(repo_dir)
    assert actual == expected



# Generated at 2022-06-21 10:42:44.046737
# Unit test for function find_template
def test_find_template():
    """Verify that we can find a template in a directory."""
    from os.path import dirname, join, abspath
    import shutil
    from tempfile import mkdtemp
    from unittest import TestCase

    class FindTemplateTests(TestCase):

        def test_happy_path(self):
            """Verify find_template works with template dir containing
            cookiecutter, but also some other directories that don't.
            """
            repo_dir = abspath(join(dirname(__file__), '..', 'fake-repo'))
            temp_dir = mkdtemp()
            shutil.copytree(repo_dir, temp_dir)
            expected = join(temp_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:42:44.960267
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:42:55.977215
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template


# Generated at 2022-06-21 10:42:56.555601
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:43:05.496586
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_utils import TEST_COOKIECUTTERS_DIR
    from cookiecutter.tests.test_utils import TEST_OUTPUT_DIR
    from cookiecutter.tests.test_utils import TEST_REPO_DIR
    from cookiecutter.utils import make_sure_path_exists
    
    logger.debug('TEST_COOKIECUTTERS_DIR')
    logger.debug(TEST_COOKIECUTTERS_DIR)
    logger.debug('TEST_OUTPUT_DIR')
    logger.debug(TEST_OUTPUT_DIR)
    logger.debug('TEST_REPO_DIR')
    logger.debug(TEST_REPO_DIR)


# Generated at 2022-06-21 10:43:07.288430
# Unit test for function find_template
def test_find_template():
    """Check that function find_template works as expected"""
    #TODO
    pass

# Generated at 2022-06-21 10:43:11.962711
# Unit test for function find_template
def test_find_template():
    """Verify that the correct dir is recognized as the project template."""
    repo_dir = os.path.join('tests', 'non-fruit-template')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:43:18.373606
# Unit test for function find_template
def test_find_template():
    """
    Test that function is returning expected directory
    """
    repo_dir = "/home/brent/personal/cookiecutter-pypackage"
    expected_return_value = "/home/brent/personal/cookiecutter-pypackage/{{cookiecutter.repo_name}}"
    actual_return_value = find_template(repo_dir)
    assert expected_return_value == actual_return_value


# Generated at 2022-06-21 10:43:24.125990
# Unit test for function find_template
def test_find_template():
    """Test finding a non-templated directory."""
    import cookiecutter.utils as cutils
    import pytest
    input_dir = os.path.join('tests', 'test-input-dir')

    with pytest.raises(NonTemplatedInputDirException):
        cutils.find_template(input_dir)

# Generated at 2022-06-21 10:43:31.110783
# Unit test for function find_template
def test_find_template():
    """Verify that find_template return expected value."""
    import tempfile
    from cookiecutter.utils import rmtree

    # setup: create a temp dir and a nested fake project template
    temp_dir = tempfile.mkdtemp()
    fake_project = os.path.join(temp_dir, 'fake-project-{{foo}}')
    os.makedirs(fake_project)

    # test
    assert find_template(temp_dir) == fake_project

    # teardown test
    rmtree(temp_dir)



# Generated at 2022-06-21 10:43:34.676066
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    project_template_dir = find_template(repo_dir)
    assert project_template_dir == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:39.686708
# Unit test for function find_template
def test_find_template():
    repo_dir = 'fixtures/tests/fake-repo/'
    assert find_template(repo_dir) == 'fixtures/tests/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:48.679633
# Unit test for function find_template
def test_find_template():
    """Test that the find_template() function works with a variety of inputs"""
    repo_dir = os.path.join(os.getcwd(), 'tests', 'test-find-template')
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.project_slug}}')
    assert project_template == expected

# Generated at 2022-06-21 10:43:54.303133
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/foo'
    template_dir = 'cookiecutter-pypackage'
    template_dir_full_path = os.path.join(repo_dir, template_dir)
    os.mkdir(template_dir_full_path)
    assert find_template(repo_dir) == template_dir_full_path

# Generated at 2022-06-21 10:44:00.868817
# Unit test for function find_template
def test_find_template():
    temp_dir = "/tmp/cookiecutter-test-find-template-{{cookiecutter.repo_name}}"
    template = find_template(temp_dir)
    assert template == "/tmp/cookiecutter-test-find-template-{{cookiecutter.repo_name}}/cookiecutter-test-find-template-{{cookiecutter.repo_name}}"

    # Clean up
    os.rmdir(template)

# Generated at 2022-06-21 10:44:09.238950
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/user/repos/cookie'
    repo_dir_contents = [
        'cookiecutter', 'cookiemonster', 'cookies.txt',
        '{{cookiecutter.project_name}}'
    ]
    assert find_template(repo_dir) == '/home/user/repos/cookie/{{cookiecutter.project_name}}'

    repo_dir_contents = [
        'cookiecutter', 'cookiemonster', 'cookies.txt'
    ]
    assert find_template(repo_dir) == None

# Generated at 2022-06-21 10:44:12.301184
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/cookiecutter-pypackage') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:14.536036
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir='tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:15.680339
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    find_template("/")

# Generated at 2022-06-21 10:44:19.390921
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    project_template = 'fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:44:25.092968
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..', 'tests', 'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)



# Generated at 2022-06-21 10:44:29.065199
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""

# Generated at 2022-06-21 10:44:47.865917
# Unit test for function find_template
def test_find_template():
    """Verify find_template function works as expected."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    class cd:
        """Context manager for changing the current working directory"""
        def __init__(self, newPath):
            self.newPath = os.path.expanduser(newPath)

        def __enter__(self):
            self.savedPath = os.getcwd()
            os.chdir(self.newPath)

        def __exit__(self, etype, value, traceback):
            os.chdir(self.savedPath)

    # Setup
    temp_dir = tempfile.mkdtemp()
    temp_repo_path = os.path.join(temp_dir, 'fake-repo')

    os.mk

# Generated at 2022-06-21 10:44:59.451830
# Unit test for function find_template
def test_find_template():

    from cookiecutter.tests.test_cookiecutter import replace_jinja_variables_in_file

    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    cookiecutter_dir = tempfile.mkdtemp()

    os.makedirs(cookiecutter_dir + '/cookiecutter-{{package_name}}')

    # Test for a non-templated input directory
    try:
        find_template(tmp_dir)
        assert False, 'find_template() should throw an exception for non-templated input directory'
    except NonTemplatedInputDirException:
        pass

    # Test for a templated input directory
    result = find_template(cookiecutter_dir)

# Generated at 2022-06-21 10:45:12.592715
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir'
    assert find_template('repo_dir/cookiecutter') == 'repo_dir'
    assert find_template('repo_dir/{{cookiecutter.repo_name}}') == 'repo_dir'
    assert find_template('repo_dir/test') == 'repo_dir/test'
    assert find_template('repo_dir/') == 'repo_dir/'
    assert find_template('repo_dir/test/') == 'repo_dir/test/'
    assert find_template('{{repo_dir}}/') == '{{repo_dir}}/'
    assert find_template('{{repo_dir}}') == '{{repo_dir}}'

find_template('repo_dir')

# Generated at 2022-06-21 10:45:13.185564
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:16.459298
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works with a templated and a non-templated
    directory."""
    from cookiecutter import main

    main.cookiecutter('tests/fake-repo-pre/', no_input=True)

# Generated at 2022-06-21 10:45:20.253494
# Unit test for function find_template
def test_find_template():
    assert find_template(
        repo_dir='tests/test-output/input-repo'
    ) == 'tests/test-output/input-repo/python-project'

# Generated at 2022-06-21 10:45:25.571626
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct value."""
    repo_dir = os.path.join('tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join('tests', 'fake-repo-tmpl', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:45:34.028310
# Unit test for function find_template
def test_find_template():

    # Setup
    repo_dir = os.path.abspath('./tests/fake-repo-pre-gen')
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        raise AssertionError('NonTemplatedInputDirException was raised when '
                             'it should not have been.')

    repo_dir = os.path.abspath('./tests/fake-repo-no-templatedir')
    try:
        find_template(repo_dir)
        raise AssertionError('NonTemplatedInputDirException was not raised when '
                             'it should have been.')
    except NonTemplatedInputDirException:
        pass

if __name__ == '__main__':
    test_find_template()



# Generated at 2022-06-21 10:45:36.066514
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:47.459181
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_utils import remove_created_dirs
    from cookiecutter.tests.test_utils import (
        create_fake_repo, create_fake_template)
    from cookiecutter.utils import rmtree

    fake_user_config = {
        'cookiecutters_dir': 'fake-cookiecutters-dir',
    }

    make_sh_tmpl = "make.sh"
    fake_template_name = 'foobar'
    fake_template_path = 'fake-cookiecutters-dir/' + fake_template_name
    # create fake repo
    if os.path.isdir(fake_template_path):
        rmtree(fake_template_path)

    create_fake_repo(
        fake_template_name, make_sh_tmpl
    )

# Generated at 2022-06-21 10:46:04.926302
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    repo_dir = os.path.join('tests', 'test-find-template')
    template_path = find_template(repo_dir)
    assert template_path == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:46:08.084434
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/jane/pycon-django-skeleton/') == '/home/jane/pycon-django-skeleton/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:46:10.016117
# Unit test for function find_template
def test_find_template():
    assert find_template("test_input") == "test_input\\test_template"

# Generated at 2022-06-21 10:46:13.379410
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/projects/cookiecutter-pypackage'
    return find_template(repo_dir)
    # expected result:
    # '/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:46:25.390332
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()

    # Make a project template.
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    logger.debug('Creating %s', project_template)
    os.mkdir(project_template)

    assert find_template(repo_dir) == project_template

    # Make a second project template
    project_template2 = os.path.join(repo_dir, '{{cookiecutter.repo_name2}}')
    logger.debug('Creating %s', project_template2)
    os.mkdir(project_template2)

    assert find_template(repo_dir) == project_template

    shutil

# Generated at 2022-06-21 10:46:27.656007
# Unit test for function find_template
def test_find_template():
    repo = os.path.join(os.getcwd(), 'tests', 'fake-repo-pre-gen')
    template = find_template(repo)
    assert template == os.path.join(repo, 'pypackage-{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:46:30.961174
# Unit test for function find_template
def test_find_template():
    repo_dir = '/my/dir/{{cookiecutter.repo_name}}/'
    expected_result = '/my/dir/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == expected_result

# Generated at 2022-06-21 10:46:35.510550
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template`."""
    testing_dir = 'tests/test-find-template/'
    assert find_template(testing_dir) == os.path.join(
        testing_dir, '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-21 10:46:37.068759
# Unit test for function find_template
def test_find_template():
    find_template('/home/pj/project_templates/python_app/')

# Generated at 2022-06-21 10:46:42.266976
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-pre-gen')
    project_template = find_template(repo_dir)
    assert '{{cookiecutter.repo_name}}' in project_template

# Generated at 2022-06-21 10:47:20.529133
# Unit test for function find_template
def test_find_template():
    """Verify behaviour of find_template()."""
    import shutil
    import tempfile

    template_dir, new_dir = None, None

    try:
        # Create a temporary directory, change to it
        template_dir = tempfile.mkdtemp()
        os.chdir(template_dir)

        # Create a project template in the temporary directory
        new_dir = os.path.join(template_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
        os.makedirs(new_dir)

        # Call find_template() and compare to original template
        template = find_template(template_dir)
        assert template == new_dir

    finally:
        # Remove temporary directory and contents
        os.chdir(template_dir)
        shutil.rmtree(template_dir)

# Generated at 2022-06-21 10:47:31.718444
# Unit test for function find_template
def test_find_template():
    """Test that the function `find_template` works."""
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a barebones cookiecutter project with the following
    # directory structure:
    #
    #   temp_dir/
    #       cookiecutter.json
    #       test_project/
    #           test_file.txt
    #       not-a-template/
    #           test_file.txt
    #

    # Create a test project dir
    test_project_dir = os.path.join(temp_dir, 'test_project')
    os.makedirs(test_project_dir)
    test_project_dir_contents = os.listdir(test_project_dir)

# Generated at 2022-06-21 10:47:35.016667
# Unit test for function find_template
def test_find_template():
    template_name = find_template('/Users/sarah/Desktop/test')
    assert template_name == '/Users/sarah/Desktop/test/{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:47:38.510613
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works."""
    assert find_template('tests/test-data') == 'tests/test-data/{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:47:41.334203
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/jason/git/cookiecutter-pypackage') == '{{cookiecutter.package_name}}'

# Generated at 2022-06-21 10:47:46.179592
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo'
    )
    test_template_path = find_template(repo_dir)
    assert '{{' in test_template_path
    assert '}}' in test_template_path
    assert 'cookiecutter' in test_template_path

# Generated at 2022-06-21 10:47:50.239978
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-data/fake-repo'
    project_template = 'fake-repo/cookiecutter-{{cookiecutter.repo_name}}'
    template = find_template(repo_dir)
    assert project_template == template

# Generated at 2022-06-21 10:47:51.451964
# Unit test for function find_template
def test_find_template():
    find_template('/Users/me/cookiecutters/gitignore.git')

# Generated at 2022-06-21 10:47:57.129215
# Unit test for function find_template
def test_find_template():
    """
    Make sure that find_template works as expected
    """

    dir_name = os.path.dirname(__file__)
    test_dir = os.path.join(dir_name, 'test-repo-tmpl')
    result = find_template(test_dir)
    expected = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    assert result == expected

# Generated at 2022-06-21 10:48:04.806856
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from nose.tools import eq_
    from .test_files.fake_repo import fake_repo
    
    repo_dir = fake_repo.clone()
    template_dir = cookiecutter.find_template(repo_dir)
    eq_(template_dir, os.path.join(repo_dir, 'fake-project-{{cookiecutter.repo_name}}'))
    fake_repo.remove_repo()

# Generated at 2022-06-21 10:49:07.841129
# Unit test for function find_template
def test_find_template():
    import tempfile

    temp_dir = tempfile.mkdtemp()
    cookiecutter_templated_repo = os.path.abspath(
        'tests/test-cookiecutters/fake-repo'
    )
    os.chdir(temp_dir)

    os.system('cp -r {0} {1}'.format(
        cookiecutter_templated_repo,
        temp_dir
    ))
    os.system('mv {0}/fake-repo {0}/cookiecutter-templated-repo'.format(temp_dir))

    repo_dir = os.path.join(temp_dir, 'cookiecutter-templated-repo')
    project_templ = find_template(repo_dir)
    assert project_templ == os.path

# Generated at 2022-06-21 10:49:16.237038
# Unit test for function find_template
def test_find_template():
    import os
    from .exceptions import NonTemplatedInputDirException
    from .prompt import read_user_yes_no

    # Get the path to this function
    this_func_path = os.path.dirname(os.path.abspath(test_find_template.__code__.co_filename))

    # Create a directory with a Cookiecutter project template and a file
    create_dir_contents = '''mkdir -p cc_dir/project_dir
cd cc_dir
touch non_project_file
touch {{cookiecutter.project_name}}
'''
    os.system(create_dir_contents)

    project_template = find_template(this_func_path)
    project_name = project_template.split('/')[-1]

# Generated at 2022-06-21 10:49:16.990489
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template function."""
    pass

# Generated at 2022-06-21 10:49:23.542961
# Unit test for function find_template
def test_find_template():
    # Given
    _tempdir = tempfile.mkdtemp()
    repo_dir = os.path.join(_tempdir, 'my-repo')


# Generated at 2022-06-21 10:49:31.517494
# Unit test for function find_template
def test_find_template():
    """Routine to test function find_template.
    """
    import tempfile
    from shutil import rmtree
    from cookiecutter.compat import text_type

    tmp_dir = tempfile.mkdtemp(suffix='tmp_cookiecutter_tests')

    # Create temporary test directory
    foo_dir = os.path.join(tmp_dir, 'foo-{{cookiecutter.repo_name}}')
    os.mkdir(foo_dir)

    with open(os.path.join(foo_dir, 'cookiecutter.json'), 'w') as f:
        f.write(text_type(''))

    # Check that it is properly detected
    assert find_template(tmp_dir) == foo_dir

    # Cleanup
    rmtree(tmp_dir)

# Generated at 2022-06-21 10:49:35.356458
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo/{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:49:48.158180
# Unit test for function find_template
def test_find_template():
    """Verify if find_template works."""
    from cookiecutter import utils
    from cookiecutter import exceptions
    import os
    import shutil
    import tempfile
    import filecmp
    import sys

    # set up
    if sys.version_info[0] == 3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    # create a repo
    temp_dir = tempfile.mkdtemp()
    template_repo_dir = os.path.join(temp_dir, 'template_repo')
    os.makedirs(template_repo_dir)
    project_template = os.path.join(template_repo_dir, 'cookiecutter')

# Generated at 2022-06-21 10:49:52.842097
# Unit test for function find_template
def test_find_template():
    test_dirs = [
        'tests/test-repo-pre/',
        'tests/test-repo-post/',
    ]

    for test_dir in test_dirs:
        proj_tmpl = find_template(test_dir)
        assert 'tests/fake-repo-tmpl' in proj_tmpl

# Generated at 2022-06-21 10:50:04.958826
# Unit test for function find_template
def test_find_template():
    from tests.test_utils import AbstractDirTest

    class TestTemplatedDir(AbstractDirTest):

        def __init__(self):
            self.test_dir = os.path.join(self.abs_test_dir, 'templated_dir')
            self.template_dir = os.path.join(self.test_dir, 'cookiecutter-foobar')
            self.other_dir = os.path.join(self.test_dir, 'not-this-one')
            self.non_templated_dir = os.path.join(self.test_dir, 'no-template')

        def mk_template_dir(self):
            self.make_directories(self.template_dir)

        def mk_other_dir(self):
            self.make_directories(self.other_dir)



# Generated at 2022-06-21 10:50:08.772543
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.curdir, 'tests/fake-repo-pre/')
    project_template = find_template(repo_dir)
    assert(project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))