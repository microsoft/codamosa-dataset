

# Generated at 2022-06-21 10:41:48.706482
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:41:55.914648
# Unit test for function find_template
def test_find_template():
    repo_dir=r"/Users/yangwanxiang/PycharmProjects/cookiecutter/tests/fake-repo-pre/{{cookiecutter.repo_name}}"
    assert os.path.exists(repo_dir)
    assert find_template(repo_dir) == "/Users/yangwanxiang/PycharmProjects/cookiecutter/tests/fake-repo-pre/{{cookiecutter.repo_name}}/cookiecutter-pypackage"


# Generated at 2022-06-21 10:42:02.246243
# Unit test for function find_template
def test_find_template():
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    TEST_REPO_DIR = os.path.join(BASE_DIR, 'tests', 'test-repo')

    PROJECT_TEMPLATE = os.path.join(TEST_REPO_DIR, '{{cookiecutter.repo_name}}')

    assert find_template(TEST_REPO_DIR) == PROJECT_TEMPLATE

# Generated at 2022-06-21 10:42:07.958362
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template
    """
    repo_dir = "tests/test-repo"
    repo_dir_contents = os.listdir(repo_dir)
    assert find_template(repo_dir) == os.path.join(repo_dir, repo_dir_contents[0])


# Generated at 2022-06-21 10:42:09.613362
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    pass

# Generated at 2022-06-21 10:42:16.932376
# Unit test for function find_template
def test_find_template():
    """Should find the templated directory."""
    cwd = os.getcwd()
    repo_dir = os.path.join(cwd, 'tests/test-repo-pre/')
    output = find_template(repo_dir)
    assert output == 'tests/test-repo-pre/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-21 10:42:21.126069
# Unit test for function find_template
def test_find_template():
    """Unit test function."""
    template_dir = os.path.join('tests', 'files', 'test-template')

    project_template = find_template(template_dir)
    assert project_template == os.path.join(
        template_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-21 10:42:23.392244
# Unit test for function find_template
def test_find_template():
    assert os.path.basename(
        find_template(
            repo_dir='tests/fake-repo-pre/')) == 'python_project'



# Generated at 2022-06-21 10:42:29.385443
# Unit test for function find_template
def test_find_template():
    """Find template dir."""
    repo_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo')
    )
    project_template = find_template(repo_dir)
    assert 'fake-repo/{{cookiecutter.project_name}}-master' in project_template

# Generated at 2022-06-21 10:42:40.672948
# Unit test for function find_template
def test_find_template():
    """Validate the find_template function."""
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory in the temporary directory that
    # is not a valid input directory
    temp_subdir = os.path.join(temp_dir, 'my-fake-repo')
    os.makedirs(temp_subdir)

    # Try to find a template in the temporary directory;
    # an exception should be raised
    try:
        find_template(temp_dir)
    except NonTemplatedInputDirException:
        pass
    except Exception as e:
        msg = "The find_template function did not behave as expected: %s"
        msg = msg % e
        raise Exception(msg)

# Generated at 2022-06-21 10:42:48.842133
# Unit test for function find_template
def test_find_template():
    import tempfile
    from shutil import copytree, rmtree
    from cookiecutter.generate import generate_files

    repo_dir = tempfile.mkdtemp()
    project_dir = os.path.join(repo_dir, 'cookiecutter-foobar')
    os.makedirs(project_dir)
    test_file = os.path.join(project_dir, 'test_file.txt')
    with open(test_file, 'w') as f:
        f.write('A test file')

    zipped_project_dir = os.path.join(repo_dir, '{{ cookiecutter.project_slug }}')
    os.makedirs(zipped_project_dir)

# Generated at 2022-06-21 10:42:53.674541
# Unit test for function find_template
def test_find_template():
    """
    Test `find_template` function with a test repo.
    """
    # Setup
    from cookiecutter.tests.test_find import make_repo
    make_repo('tests/test-find/')

    # Run
    find_template('tests/test-find/fake-repo-tmpl')

    # Teardown
    os.rmdir('tests/test-find/fake-repo-tmpl')

# Generated at 2022-06-21 10:43:03.151598
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    from os.path import join

    def _make_repo(name):
        repo_dir = join(base_dir, name)
        os.mkdir(repo_dir)
        return repo_dir

    def _write_file(path, content):
        fh = open(path, 'w')
        fh.write(content)
        fh.close()

    base_dir = tempfile.mkdtemp()

    # Create a repo without a templated dir
    find_template(_make_repo('notemplate'))

    # Create a repo with a templated dir
    repo = _make_repo('withtemplate')
    _write_file(join(repo, 'cookiecutter-{{name}}'), '')


# Generated at 2022-06-21 10:43:06.794237
# Unit test for function find_template
def test_find_template():
    """The find_template() function should return a relative path to the project template."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo2'))
    project_template = find_template(repo_dir)
    assert 'py-module' in project_template



# Generated at 2022-06-21 10:43:08.990708
# Unit test for function find_template
def test_find_template():
    """ Test cases to find the project template"""

    find_template('/home/user/cookiecutter-project/')

# Generated at 2022-06-21 10:43:16.699360
# Unit test for function find_template
def test_find_template():
    """Test find_template returns the right template."""
    find_template('test/test_template_repo/repo')

    # Test non templated directory
    try:
        find_template('test/test_template_repo/repo_without_template')
    except NonTemplatedInputDirException:
        assert True
        pass

    # Test empty directory
    try:
        find_template('test/test_template_repo/repo_empty')
    except NonTemplatedInputDirException:
        assert True
        pass

# Generated at 2022-06-21 10:43:24.436545
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_user_config import TESTS_DIR
    import os
    test_dir = os.path.join(TESTS_DIR, 'test-input-notemplate')
    test_result = find_template(test_dir)
    test_true_result = os.path.join(test_dir, 'cookiecutter-pypackage-test', '{{cookiecutter.project_slug}}')
    assert test_result == test_true_result


# Generated at 2022-06-21 10:43:29.567346
# Unit test for function find_template
def test_find_template():
    repo_dir = 'C:\\Users\\me\\src\\cookie\\test_dir\\cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == 'C:\\Users\\me\\src\\cookie\\test_dir\\cookiecutter-pypackage\\{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:32.201608
# Unit test for function find_template
def test_find_template():
    """
    This functions tests find_template()
    """
    repo_dir = "https://github.com/audreyr/cookiecutter-pypackage"
    project_template = find_template(repo_dir)

    assert project_template == "https://github.com/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}"

# Generated at 2022-06-21 10:43:38.053287
# Unit test for function find_template
def test_find_template():
    """Test find_template() with a template inside a directory."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, 'fake-template')



# Generated at 2022-06-21 10:43:46.030050
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.abspath('.')
    test_project_template = '{{cookiecutter.repo_name}}'
    expected_project_template = os.path.join(
        test_repo_dir,
        test_project_template,
        )

    assert find_template(test_repo_dir) == expected_project_template

# Generated at 2022-06-21 10:43:50.290326
# Unit test for function find_template
def test_find_template():
    test_repo_dir = '/home/danny/cookiecutter-test/cookiecutter-pypackage'
    result = find_template(test_repo_dir)
    print(result)

test_find_template()

# Generated at 2022-06-21 10:43:59.454438
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import tempfile
    import shutil
    import mock

    # Make a non-templated directory
    non_templated_dir = tempfile.mkdtemp()


# Generated at 2022-06-21 10:44:06.580376
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join('tests', 'fake-repo-tmpl')
    real_dir = os.path.realpath(test_dir)
    assert real_dir.split(os.path.sep)[-1] == 'tests'
    assert find_template(test_dir) == os.path.join(real_dir, 'fake-repo-tmpl')


# Generated at 2022-06-21 10:44:10.464645
# Unit test for function find_template
def test_find_template():
    """Verify a directory can be found inside a template repo."""
    try:
        find_template('tests/test-data/fake-repo-tmpl')
    except NonTemplatedInputDirException:
        assert False
    except OSError:
        assert False

    assert True

# Generated at 2022-06-21 10:44:15.680803
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), 'tests/fake-repo-tmpl/'))
    project_template = find_template(repo_dir)
    expected_project_template = repo_dir + '/{{ cookiecutter.repo_name }}'
    assert project_template == expected_project_template

test_find_template()

# Generated at 2022-06-21 10:44:20.488126
# Unit test for function find_template
def test_find_template():
    template_dir = "tests/test-repos/cookiecutter-pypackage/"
    assert find_template(template_dir) == "tests/test-repos/cookiecutter-pypackage/cookiecutter-{{cookiecutter.repo_name}}"

# Generated at 2022-06-21 10:44:23.538344
# Unit test for function find_template
def test_find_template():
    out = find_template("tests/fake-repo-pre/")
    assert out == "tests/fake-repo-pre/{{cookiecutter.repo_name}}"

# Generated at 2022-06-21 10:44:25.906661
# Unit test for function find_template
def test_find_template():
    assert find_template('fake_repo') == 'fake_repo/fake_project'


# Generated at 2022-06-21 10:44:31.300675
# Unit test for function find_template
def test_find_template():
    """Tests for find_template function."""
    from tests.test_utils import TEST_COOKIECUTTERS_DIR

    input_dir = os.path.join(TEST_COOKIECUTTERS_DIR, 'abbreviated')

    project_template = find_template(input_dir)
    assert project_template == os.path.join(input_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:44:40.544940
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-tmpl',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:44:48.579977
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the correct project template."""
    # Setup
    temp_directory = os.path.join(
        os.path.dirname(__file__), 'test-find-template'
    )
    os.mkdir(temp_directory)
    # Expected output
    expected_output = os.path.join(temp_directory, '{{cookiecutter.repo_name}}')
    # Unit under test
    output = find_template(temp_directory)
    # Verify
    assert output == expected_output
    # Teardown
    os.removedirs(temp_directory)

# Generated at 2022-06-21 10:44:58.989024
# Unit test for function find_template
def test_find_template():
    fake_repo_dir = os.path.abspath('tests/fake-repo-tmpl')
    repo_dir_contents = os.listdir(fake_repo_dir)
    assert '{{cookiecutter.repo_name}}' in repo_dir_contents
    assert '{{cookiecutter.repo_name}}_hooks' in repo_dir_contents
    assert 'README.rst' in repo_dir_contents
    assert 'LICENSE' in repo_dir_contents
    project_template = find_template(fake_repo_dir)
    assert 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}' == project_template

# Generated at 2022-06-21 10:45:01.710602
# Unit test for function find_template
def test_find_template():
    """
    Test that find_template works.
    """
    repo_dir = os.path.abspath('tests/test-repo-pre/')
    repo_dir_contents = ['not_a_project_template']
    template = 'project_template'
    project_template = find_template(repo_dir)
    assert template == os.path.basename(project_template)

# Generated at 2022-06-21 10:45:03.294656
# Unit test for function find_template
def test_find_template():
    assert(find_template('/home/vagrant/repos') == None)

# Generated at 2022-06-21 10:45:15.305705
# Unit test for function find_template
def test_find_template():
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter import utils

    # create a temp working dir
    with TemporaryDirectory() as tmpdir:
        # create a fake cookie template
        cookie_name_template = 'cookiecutter-{{cookiecutter.repo_name}}'
        cookie_path = os.path.join(tmpdir, cookie_name_template)
        os.makedirs(cookie_path)

        # create a fake project template
        proj_name_template = '{{cookiecutter.repo_name}}-proj'
        proj_path = os.path.join(cookie_path, proj_name_template)
        os.makedirs(proj_path)

        # create a fake extra template
        extra_path = os.path.join(cookie_path, 'extra')

# Generated at 2022-06-21 10:45:27.016611
# Unit test for function find_template
def test_find_template():
    """Verify that the expected project template is found."""
    from cookiecutter import utils
    from cookiecutter.tests import mock
    from cookiecutter.tests.test_find import expected_dir, expected_dir_url

    def mock_clone(*args, **kwargs):
        # Make a temporary repo dir with a template
        template = 'cookiecutter-{{cookiecutter.repo_name}}'
        temp_repo_dir = utils.make_sure_path_exists(template)
        return temp_repo_dir

    with mock.patch('cookiecutter.vcs.clone') as git_clone:
        git_clone.side_effect = mock_clone

# Generated at 2022-06-21 10:45:31.394207
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter finds potential project templates in non-repo dir."""
    from cookiecutter.tests.test_repositories import normal

    os.chdir(os.path.dirname(normal))
    project_template = find_template(os.getcwd())

    assert '{{cookiecutter.repo_name}}' in project_template

# Generated at 2022-06-21 10:45:39.470203
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    from cookiecutter import utils
    utils.paths.SETTINGS_DIR = os.path.join('tests', 'test-find-template')
    template_dir = os.path.join(utils.paths.SETTINGS_DIR, 'fake-repo')
    output = find_template(template_dir)
    assert output == os.path.join(template_dir, 'cookiecutter-pypackage')


# Generated at 2022-06-21 10:45:45.384831
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    this_dir = os.path.dirname(__file__)
    temp_dir = tempfile.mkdtemp('cookiecutter-temp')

    template_dir = os.path.join(
        temp_dir,
        'tests/test-find-template-repo/'
    )
    shutil.copytree(
        os.path.join(this_dir, 'test-find-template-repo'),
        template_dir
    )

    project_template = find_template(template_dir)

    assert project_template == os.path.join(
        template_dir,
        'cookiecutter-{{cookiecutter.project_name}}/'
    )

# Generated at 2022-06-21 10:46:05.084607
# Unit test for function find_template
def test_find_template():
    """Test find_template function with a mocked repo_dir.

    Should return a relative path to the project template.
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tests/fake-repo-tmpl'
    )

    expected_template = os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}'
    )

    assert find_template(repo_dir) == expected_template

# Generated at 2022-06-21 10:46:14.430413
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from tempfile import mkdtemp

    repo_dir = os.path.join(utils.get_project_root(), 'tests', 'fake-repo-tmpl')
    repo_dir_contents = ['testing', 'testing-{{cookiecutter.repo_name}}', 'testing-nope']

    # Test that a project template is returned
    with utils.work_in(mkdtemp()) as temp_dir:
        for item in repo_dir_contents:
            os.mkdir(os.path.join(temp_dir, item))
        result = find_template(temp_dir)
        assert result == os.path.join(temp_dir, repo_dir_contents[1])

    # Test that

# Generated at 2022-06-21 10:46:26.321980
# Unit test for function find_template
def test_find_template():
    """Test function for find_template
    """
    ### Test for the case when the repo_dir does not contain template
    # Create a temp dir
    temp_dir = tempfile.mkdtemp()
    # Create a dir inside it
    temp_subdir = os.path.join(temp_dir,'subdir')
    os.mkdir(temp_subdir)
    # Create a temp file inside it
    temp_file = tempfile.mkstemp(suffix="_sample_file.txt", dir=temp_subdir)
    # Return an error if the repo_dir doesn't contain template
    with pytest.raises(NonTemplatedInputDirException):
        find_template(temp_subdir)
    os.remove(temp_file[1])
    os.rmdir(temp_subdir)
    os.r

# Generated at 2022-06-21 10:46:29.651623
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    project_tmpl = find_template(repo_dir)
    assert project_tmpl == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}/{{cookiecutter.project_slug}}'

# Generated at 2022-06-21 10:46:33.544800
# Unit test for function find_template
def test_find_template():
    input_dir = './tests/fake-repo-pre/'
    expected_output = './tests/fake-repo-pre/{{cookiecutter.repo_name}}/'
    actual_output = find_template(input_dir)
    assert expected_output == actual_output

# Generated at 2022-06-21 10:46:46.429053
# Unit test for function find_template
def test_find_template():
    """ Unit test for function find_template
    """
    import os
    from Cookiecutter import setup_test_repos_clones
    from Cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = setup_test_repos_clones.git_checkout()

    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert False

    repo_dir = setup_test_repos_clones.hg_checkout()

    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert False

    repo_dir = setup_test_repos_clones.normal_checkout()


# Generated at 2022-06-21 10:46:59.221485
# Unit test for function find_template
def test_find_template():
    from cookiecutter import _find
    from .compat import mock, patch
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = '/Users/audreyr/projects/cookiecutter-pypackage'

    # Mock out os.listdir and os.path.isdir to return the contents we want
    fake_repo_dir_contents = [
        'cookiecutter-pypackage',
        '{{cookiecutter.project_name}}',
        'foobar',
    ]
    with patch('os.listdir') as mock_listdir:
        mock_listdir.return_value = fake_repo_dir_contents
        with patch('os.path.isdir') as mock_isdir:
            mock_isdir.return_value = True
            project_template

# Generated at 2022-06-21 10:47:04.256590
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter finds the project template."""
    test_repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..', '..', 'tests', 'test-find-template'
        )
    )

    project_template = find_template(test_repo_dir)

    assert 'test-find-template/{{cookiecutter.repo_name}}' == project_template



# Generated at 2022-06-21 10:47:09.886990
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    test_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-find-template')
    result = find_template(test_dir)
    expected = os.path.join(test_dir, '{{cookiecutter.dir_name}}')

    assert result == expected

# Generated at 2022-06-21 10:47:15.106550
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:47:42.492456
# Unit test for function find_template
def test_find_template():
    """Function to test find_template function."""
    test_repo_dir = 'tests/test-dir/fake-repo'
    assert find_template(test_repo_dir) == 'tests/test-dir/fake-repo/cookiecutter-pypackage'

# Generated at 2022-06-21 10:47:52.476046
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import pytest

    # Test with a templated directory
    input_dir = 'tests/test-input/fake-repo'
    expected_template_dir = 'tests/test-input/fake-repo/bakery_project-{{cookiecutter.github_repo}}'

    template_dir = find_template(input_dir)

    assert template_dir == expected_template_dir

    # Test with a non-templated directory
    input_dir_notempl = 'tests/test-input/fake-repo-nodir'
    expected_exception = 'NonTemplatedInputDirException'

    with pytest.raises(NonTemplatedInputDirException) as excinfo:
        find_template(input_dir_notempl)

    assert excinfo.type

# Generated at 2022-06-21 10:48:04.227426
# Unit test for function find_template
def test_find_template():
    """
    test_find_template()

    Tests ``find_template()`` by creating a local directory, creating one or
    two files with the word 'cookiecutter' in it, and then checking which file
    is returned as the template.
    """

    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Put two or three files in our temp directory
    junk_file1 = os.path.join(tmpdir, 'cookiecutter-junk1')
    junk_file2 = os.path.join(tmpdir, 'cookiecutter-junk2')
    templated_dir = os.path.join(tmpdir, 'cookiecutter-{{cookiecutter.repo_name}}')


# Generated at 2022-06-21 10:48:08.132201
# Unit test for function find_template
def test_find_template():
    """Tests cookiecutter.find_template."""
    repo_dir = '/home/joe/src/cookiecutter-django'
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:48:18.411382
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils

    dir_to_test = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)), '../tests/fake-repo-pre/'
    )

    expected = os.path.join(
        os.path.dirname(os.path.abspath(utils.__file__)), '../tests/fake-repo-pre/cookiecutter-django/'
    )

    result = find_template(dir_to_test)

    assert os.path.normpath(result) == os.path.normpath(expected)



# Generated at 2022-06-21 10:48:26.854558
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the correct template path."""
    repo_dir = os.path.join(
        os.getcwd(),
        'tests/test-output/find-template-test-repo'
    )
    expected = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )
    actual = find_template(repo_dir)
    assert expected == actual

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:48:34.744996
# Unit test for function find_template
def test_find_template():
    """Assert that subdirectory of test_repo_pre is detected as template."""
    # TODO: package this up in a proper unit test (https://github.com/audreyr/cookiecutter/issues/20)
    project_template = find_template('tests/test-find-template/test_repo_pre')
    assert project_template == 'tests/test-find-template/test_repo_pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:48:42.483135
# Unit test for function find_template
def test_find_template():
    """
    Returns:

    """
    # test_dir = os.path.abspath(os.path.dirname(__file__))
    # # os.chdir(test_dir)
    # test_dir = os.path.join(test_dir, os.pardir, os.pardir, 'tests', 'fake-repo-tmpl')
    # print test_dir
    # print find_template(test_dir)
    # assert find_template(test_dir) == os.path.join(
    #     test_dir, '{{cookiecutter.repo_name}}'
    # )
    #
    # test_dir = os.path.join(test_dir, os.pardir, os.pardir, 'tests', 'fake-repo-pre-tmpl')
    # print test_

# Generated at 2022-06-21 10:48:45.390645
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-data/fake-repo') == 'tests/test-data/fake-repo/tests/test-data/{{cookiecutter.project_name}}'

# Generated at 2022-06-21 10:48:45.897906
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""

# Generated at 2022-06-21 10:49:36.226478
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:49:43.775539
# Unit test for function find_template
def test_find_template():
    """Find the project template from a local directory."""
    dir_contents = os.listdir('./tests/fake-repo-pre-gen')
    expected_dir = 'cookiecutter-pypackage'
    assert find_template('./tests/fake-repo-pre-gen') == os.path.join(
        './tests/fake-repo-pre-gen', expected_dir
    )
    assert expected_dir in dir_contents

# Generated at 2022-06-21 10:49:48.510957
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    assert find_template('/home/user/cookiecutter-pypackage') == '/home/user/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:49:53.289762
# Unit test for function find_template
def test_find_template():
    import pytest
    repo_dir = os.path.join(
        os.path.realpath(os.path.dirname(__file__)), 'test-repo'
    )
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert find_template(repo_dir) == project_template

    repo_dir = os.path.join(
        os.path.realpath(os.path.dirname(__file__)), 'test-repo-no-templating'
    )
    with pytest.raises(NonTemplatedInputDirException):
        find_template(repo_dir)

# Generated at 2022-06-21 10:49:57.737693
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'files', 'fake-repo')
    expected_path = os.path.join('tests', 'files', 'fake-repo',
                                 'cookiecutter-pypackage')
    assert find_template(repo_dir) == expected_path

# Generated at 2022-06-21 10:49:59.600910
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template.

    """
    pass

# Generated at 2022-06-21 10:50:05.985591
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo'
    ))

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir,
        '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:50:15.902026
# Unit test for function find_template
def test_find_template():
    """Test the find_template function.

    1. Calls find_template with a repo_dir and asserts the return value is
        'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    2. Calls find_template with a repo_dir and asserts a
        NonTemplatedInputDirException is raised
    """
    from cookiecutter.tests.test_main import TEST_TEMPLATES_DIR
    from cookiecutter.main import find_template

    # No project template was found
    non_templated_dir = os.path.join(TEST_TEMPLATES_DIR, 'invalid')

# Generated at 2022-06-21 10:50:22.885025
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'data',
        'test-repo'
    )
    project_template = os.path.join(
        repo_dir,
        'cookiecutter-pypackage'
    )

    find_template(repo_dir) == project_template



# Generated at 2022-06-21 10:50:24.329693
# Unit test for function find_template
def test_find_template():
    """Check that the template dir is found in repo_dir."""
    pass