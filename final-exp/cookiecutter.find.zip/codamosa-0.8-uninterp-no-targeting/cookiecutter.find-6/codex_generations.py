

# Generated at 2022-06-21 10:41:56.012498
# Unit test for function find_template
def test_find_template():
    # Possible strategies for testing:
    # 1. Mock open() and os.listdir()
    # 2. In a tempdir, create a bunch of directories with various names,
    #    including one with a name that should be selected.
    #    Call find_template() in the tempdir and verify the return value.
    # For now, we're just going to call find_template() directly on a tempdir
    # containing the test dirs.
    # This test must be run from the root of the repository!
    import pytest
    temp_dir = pytest.ensuretemp('tests/test-find-template')
    # OK, we have a temp dir; put our test dirs in it
    os.makedirs(os.path.join(temp_dir, 'cookiecutter-foobar'))

# Generated at 2022-06-21 10:41:58.044283
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:05.789345
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.compat import TemporaryDirectory

    repo_dir = tempfile.mkdtemp()
    template_dir = 'my_template_{{cookiecutter.filename}}'
    os.mkdir(os.path.join(repo_dir, template_dir))

    with TemporaryDirectory(suffix='_cc') as repo_dir:
        with open(os.path.join(repo_dir, 'README.rst'), 'w') as readme_fd:
            readme_fd.write('')

    with TemporaryDirectory(suffix='_cc') as repo_dir:
        with open(os.path.join(repo_dir, 'README.rst'), 'w') as readme_fd:
            readme_fd.write('')


# Generated at 2022-06-21 10:42:12.774508
# Unit test for function find_template
def test_find_template():
    repo_dir = ('/Users/audreyr/Documents/GitHub/'
                'cookiecutter-pypackage/tests/test-repo/')
    template = find_template(repo_dir)
    expected_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )
    assert template == expected_template

# Generated at 2022-06-21 10:42:19.630701
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        'test-input-repo',
    ))
    project_template = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        'test-input-repo',
        '{{cookiecutter.repo_name}}',
    ))
    assert find_template(repo_dir) == project_template



# Generated at 2022-06-21 10:42:30.510497
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create the following directory structure:
    # temp_dir/
    # ├── project_template
    #     └── cookiecutter.json
    # ├── project_template_2
    #     └── cookiecutter.json
    # └── README.rst
    repo_dir = os.path.join(temp_dir, 'project_template')
    os.makedirs(repo_dir)
    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write('')


# Generated at 2022-06-21 10:42:34.684264
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() properly handles project templates."""
    assert find_template(
        '/tmp/fake-repo'
    ) == '/tmp/fake-repo/fake-project-{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:42:37.469064
# Unit test for function find_template
def test_find_template():
    """Check find_template() function."""
    template = find_template('.')
    assert os.path.isdir(template)



# Generated at 2022-06-21 10:42:40.275762
# Unit test for function find_template
def test_find_template():
    repo_dir = os.getcwd()
    assert (find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-21 10:42:47.947773
# Unit test for function find_template
def test_find_template():
    from cookiecutter.find import find_template
    from cookiecutter.tests.test_find import expected_find_template_result
    from cookiecutter.tests.test_find import expected_find_template_exception
    from cookiecutter.tests.test_find import TESTS_DIR

    repo_dir = os.path.join(
        TESTS_DIR,
        '_tests/test-find-repo',
    )
    result = find_template(repo_dir)
    assert result == expected_find_template_result, result

    repo_dir = os.path.join(
        TESTS_DIR,
        '_tests/test-find-repo-notemplated'
    )

# Generated at 2022-06-21 10:42:52.632157
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    expected_result = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == expected_result

# Generated at 2022-06-21 10:43:02.404617
# Unit test for function find_template
def test_find_template():
    """Verify function find_template() works."""
    # Test 1
    test_path = r'c:\users\max\github\cookiecutter\tests\test-repo-pre/'
    correct_path = 'cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template(test_path) == correct_path.decode('utf-8')

    # Test 2
    test_path = r'c:\users\max\github\cookiecutter\tests\fake-repo-tmpl/'
    correct_path = 'fake-repo-tmpl-{{ cookiecutter.repo_name }}'
    assert find_template(test_path) == correct_path.decode('utf-8')

    # Test 3

# Generated at 2022-06-21 10:43:05.355276
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    result = find_template(repo_dir)
    assert result == 'tests/fake-repo-pre/fake-project-{{cookiecutter.repo_name}}/'


# Generated at 2022-06-21 10:43:10.304227
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the expected result."""
    repo_dir = "./tests/test-repo"
    expected = "./tests/test-repo/{{cookiecutter.repo_name}}"
    result = find_template(repo_dir)

    assert result == expected

# Generated at 2022-06-21 10:43:13.343284
# Unit test for function find_template
def test_find_template():
    template = find_template('tests/fake-repo-pre/')
    assert template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:43:15.331375
# Unit test for function find_template
def test_find_template():
    """Test to see if versioning is done.
    """
    assert find_template('../')

# Generated at 2022-06-21 10:43:17.758725
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find a template inside a cloned repo."""
    find_template('tests/fake-repo-tmpl/')

# Generated at 2022-06-21 10:43:18.368848
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:43:26.326276
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'
    ))

    expected_project_template = os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}', '{{cookiecutter.project_name}}'
    )

    project_template = find_template(repo_dir)

    assert project_template == expected_project_template

# Generated at 2022-06-21 10:43:32.433126
# Unit test for function find_template
def test_find_template():
    """
    Assure that find_template correctly finds the project template
    """

    # Set-up
    test_repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo/')

    # Testing
    test_project_template = find_template(test_repo_dir)
    target = os.path.join(test_repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    assert test_project_template == target

# Generated at 2022-06-21 10:43:35.010315
# Unit test for function find_template
def test_find_template():
    # TODO: Create unit tests
    assert True

# Generated at 2022-06-21 10:43:41.895048
# Unit test for function find_template
def test_find_template():
    # Create repo_dir and put project_template in it
    repo_dir = os.path.join('tests',
                            'test-find-template',
                            'input')
    template = find_template(repo_dir)

    expected_template = os.path.join(repo_dir, 'cookiecutter-pypackage')

    assert template == expected_template

# Generated at 2022-06-21 10:43:48.517473
# Unit test for function find_template
def test_find_template():
    if os.path.exists('/tmp/cookiecutter-test'):
        os.system('rm -rf /tmp/cookiecutter-test')
    os.system('git clone https://github.com/audreyr/cookiecutter-pypackage.git /tmp/cookiecutter-test')
    assert '/tmp/cookiecutter-test/{{cookiecutter.repo_name}}' == find_template('/tmp/cookiecutter-test')



# Generated at 2022-06-21 10:43:52.998025
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    assert find_template('/home/audreyr/cookiecutter-pypackage') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-21 10:44:00.085872
# Unit test for function find_template
def test_find_template():
    import os
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from cookiecutter.main import cookiecutter

    try:
        tempdir = tempfile.mkdtemp()
        clone_from = os.path.join(
            os.path.abspath(os.path.dirname(__file__)),
            '..',
            '..',
            'tests',
            'test-repo-pre',
        )
        cookiecutter(clone_from, no_input=True, output_dir=tempdir)
    except NonTemplatedInputDirException as err:
        logger.info(err.message)

# Generated at 2022-06-21 10:44:07.056593
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function
    """
    from cookiecutter.main import cookiecutter
    from cookiecutter.tests.test_find_template import test_find_template
    from cookiecutter.tests.test_find_template import template_regex
    from cookiecutter.tests.test_find_template import run_find_template_tests
    import os
    os.chdir(os.path.dirname(os.path.dirname(__file__)))
    print('Test repo directory: {0}'.format(os.getcwd()))
    results = test_find_template(cookiecutter, template_regex)
    run_find_template_tests(results)

# Generated at 2022-06-21 10:44:09.173497
# Unit test for function find_template
def test_find_template():
    find_template('/Users/jweinheimer/projects/github/cookiecutter/tests')

# Generated at 2022-06-21 10:44:17.862097
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    repo_dir = tempfile.mkdtemp(prefix='cookiecutter-')
    template_dir = tempfile.mkdtemp(dir=repo_dir)
    try:
        new_template_dir = find_template(repo_dir)
        assert new_template_dir == template_dir
    finally:
        shutil.rmtree(repo_dir)
    repo_dir = tempfile.mkdtemp(prefix='cookiecutter-')
    template_dir = tempfile.mkdtemp(dir=repo_dir, prefix='{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:44:22.915365
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    template_dir = find_template(repo_dir)
    assert template_dir == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:44:24.945968
# Unit test for function find_template
def test_find_template():
    input_dir = os.path.join(os.path.dirname(__file__), os.pardir, 'repo-tmpl')
    expected = os.path.join(input_dir, '{{ cookiecutter.repo_name }}')
    observed = find_template(input_dir)
    assert observed == expected, observed

# Generated at 2022-06-21 10:44:30.822329
# Unit test for function find_template
def test_find_template():
    input = './tests/test-data/fake-repo'
    output = './tests/test-data/fake-repo/{{cookiecutter.repo_name}}'
    assert find_template(input) == output

# Generated at 2022-06-21 10:44:34.783237
# Unit test for function find_template
def test_find_template():
    find_template('repo_dir')
    repo_dir_contents = os.listdir('repo_dir')
    for item in repo_dir_contents:
        assert 'cookiecutter' in item and '{{' in item and '}}' in item
        project_template = item
        break
    assert project_template
    project_template = os.path.join('repo_dir', project_template)
    assert project_template

# Generated at 2022-06-21 10:44:45.458603
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    import tempfile

    template_dir = tempfile.mkdtemp(prefix='cookiecutter-')
    non_template_dir = os.path.join(template_dir, 'non-template')
    os.mkdir(non_template_dir)
    template_dir = os.path.join(template_dir, 'blah-blah-{{cookiecutter.repo_name}}-meh')
    os.mkdir(template_dir)
    assert find_template(tempfile.gettempdir()) == template_dir
    shutil.rmtree(tempfile.gettempdir())

# Generated at 2022-06-21 10:44:49.598286
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/Sophie/Projects/cookiecutter-beats'
    expected_returns = '/Users/Sophie/Projects/cookiecutter-beats/cookiecutter-{{cookiecutter.project_type}}'
    actual_returns = find_template(repo_dir)
    assert expected_returns, actual_returns

# Generated at 2022-06-21 10:44:56.028879
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tests',
        'test-input-dir-repo'
    )

    output_dir = find_template(test_dir)

    expected_output = os.path.join(test_dir, 'cookiecutter-pypackage')

    assert output_dir == expected_output

# Generated at 2022-06-21 10:44:58.610276
# Unit test for function find_template
def test_find_template():
    from pytest import raises
    from .compat import TemporaryDirectory

    repo_dir = TemporaryDirectory()
    os.chdir(repo_dir.name)
    os.mkdir('{{cookiecutter.repo_name}}')
    os.mkdir('some_repo')

    assert find_template(repo_dir.name) == os.path.join(repo_dir.name, '{{cookiecutter.repo_name}}')

    with raises(NonTemplatedInputDirException):
        find_template(repo_dir.name + '/some_repo')

# Generated at 2022-06-21 10:45:06.102304
# Unit test for function find_template
def test_find_template():

    # Setting variables
    repo_dir = 'fake-repo'
    repo_dir_contents = ['cookiecutter-cookiecutter', 'README.rst', 'licence.txt']
    os.listdir = lambda x: repo_dir_contents

    # Call function
    result = find_template(repo_dir)

    # Check result
    assert result == 'fake-repo/cookiecutter-cookiecutter'

# Generated at 2022-06-21 10:45:09.485342
# Unit test for function find_template
def test_find_template():
    assert find_template('/path/to/cookiecutter-pypackage') == '/path/to/cookiecutter-pypackage{{cookiecutter.project_slug}}'

# Generated at 2022-06-21 10:45:21.172695
# Unit test for function find_template
def test_find_template():
    from cStringIO import StringIO
    import tempfile
    import shutil
    import cookiecutter

    repo_dir = os.path.abspath(os.path.dirname(cookiecutter.__file__))
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Temp dir within which to perform the test
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory within the temp dir
    temp_subdir = os.path.join(temp_dir, 'foo')
    os.mkdir(temp_subdir)

    # Create two files within the temp subdir
    barfile = os.path.join(temp_subdir, 'bar')

# Generated at 2022-06-21 10:45:25.815030
# Unit test for function find_template
def test_find_template():
    """Verify that the function `find_template` is working correctly."""
    os.chdir('tests/test-find-template/')

    assert find_template('.') == 'test/test-repo/{{cookiecutter.repo_name}}'

    os.chdir('..')

# Generated at 2022-06-21 10:45:37.877141
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/Projects/cookiecutter/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    project_template = 'find_template'
    assert project_template == find_template(repo_dir)

# Generated at 2022-06-21 10:45:40.737005
# Unit test for function find_template
def test_find_template():
    project_template = find_template('/home/audreyr/cookiecutter-pypackage')
    assert project_template == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:45:44.964977
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    assert find_template("test_cookiecutter/fake-repo") == "test_cookiecutter/fake-repo/{{cookiecutter.repo_name}}"

# Generated at 2022-06-21 10:45:48.949759
# Unit test for function find_template
def test_find_template():
    from cookiecutter.operations import find_template

    repo_dir = os.path.abspath('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:45:51.723871
# Unit test for function find_template
def test_find_template():
    """Verify correct Cookiecutter template is identified."""

    from cookiecutter.tests.test_find import TEMPLATE

    test_dir = os.path.join('cookiecutter', 'tests', 'fake-repo-tmpl')
    project_template = find_template(test_dir)
    assert project_template == TEMPLATE

# Generated at 2022-06-21 10:45:54.799679
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    project_template = find_template(repo_dir)
    assert 'fake-repo-pre/cookiecutter-pypackage' == project_template


# Generated at 2022-06-21 10:46:02.442654
# Unit test for function find_template
def test_find_template():
    """Test `find_template` in context of a case where a template is present."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'tests',
        'test-find-template-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir,
        '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:46:07.257559
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/vagrant/cookiecutter-pypackage'
    expected = '/home/vagrant/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

    assert find_template(repo_dir) == expected

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:46:15.458338
# Unit test for function find_template
def test_find_template():
    """Tests the find_template function by running it on a variety of
    different directory trees.

    """
    def _inner_test(expected, repo_dir):
        assert expected == find_template(repo_dir)

    base_path = os.path.abspath('tests/test-find-template')

    _inner_test(os.path.join(base_path, 'one-level-deep/{{cookiecutter.repo_name}}'),
                os.path.join(base_path, 'one-level-deep'))
    _inner_test(os.path.join(base_path, 'five-levels-deep/{{cookiecutter.repo_name}}/a/b/c/d'),
                os.path.join(base_path, 'five-levels-deep'))
    _inner_test

# Generated at 2022-06-21 10:46:21.062322
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.dirname(os.path.abspath(__file__))
    template_dir = os.path.join(template_dir, 'templates/fake-repo')
    template = find_template(template_dir)
    assert template == template_dir + '/fake-project-{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:46:36.867721
# Unit test for function find_template
def test_find_template():
    find_template("/Users/julianxing/Documents/Projects/Cookiecutter/cookiecutter-pypackage")


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:46:37.998087
# Unit test for function find_template
def test_find_template():

    find_template('local_dir/hello')

# Generated at 2022-06-21 10:46:46.960206
# Unit test for function find_template
def test_find_template():
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.main import cookiecutter

    with TemporaryDirectory() as tmpdir:
        cookiecutter("tests/fake-repo-tmpl",
                     no_input=True, output_dir=tmpdir)
        repo_dir = os.path.join(tmpdir, 'fake-repo-tmpl')
        assert find_template(repo_dir) == os.path.join(tmpdir, 'fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:46:56.569183
# Unit test for function find_template
def test_find_template():
    """Ensure that find_template() works as expected.
    """

    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test-templates')
    )

    project_template = find_template(repo_dir)

    expected_template = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test-templates/{{ cookiecutter.repo_name }}')
    )

    assert project_template == expected_template

# Generated at 2022-06-21 10:47:02.451010
# Unit test for function find_template
def test_find_template():
    """Verify that we can determine that 'project_name/{{cookiecutter.repo_name}}'
    is a template directory.
    """
    test_dir = 'tests/test-find-template'
    template_dir = 'project_name/{{cookiecutter.repo_name}}'
    test_template = os.path.join(test_dir, template_dir)
    assert find_template(test_dir) == test_template

# Generated at 2022-06-21 10:47:09.975608
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns a valid project template path.
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre',
    )
    expected_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}',
    )

    assert find_template(repo_dir) == expected_template

# Generated at 2022-06-21 10:47:13.221567
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the relative path to a template."""
    # TODO: make some directories, then assert find_template() returns a
    # relative path
    pass

# Generated at 2022-06-21 10:47:19.109737
# Unit test for function find_template
def test_find_template():
    """
    Test function find_template.
    """
    actual_result = find_template('tests/fixtures/fake-repo-tmpl')
    assert actual_result == 'tests/fixtures/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:47:29.970033
# Unit test for function find_template
def test_find_template():
    # ICYMI: This is an integration test
    import os
    import shutil
    import tempfile

    from cookiecutter.exceptions import NonTemplatedInputDirException

    def cleanup_tempdir():
        if os.path.isdir(temp_dir):
            shutil.rmtree(temp_dir)

    # Create temporary directory, and a repo inside it.
    temp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir, 'foobar'))
    os.makedirs(os.path.join(temp_dir, 'foobar', 'some'))
    os.makedirs(os.path.join(temp_dir, 'foobar', 'other'))

# Generated at 2022-06-21 10:47:39.152293
# Unit test for function find_template
def test_find_template():
    import tempfile

    cookiecutters_dir = tempfile.mkdtemp()
    adult = """
    {{cookiecutter.email}}
    {{cookiecutter.name}}
    """
    child = """
    {{cookiecutter.email}}
    {{cookiecutter.square_name}}
    """

    open(os.path.join(cookiecutters_dir, 'adult'), 'w').write(adult)
    open(os.path.join(cookiecutters_dir, 'child'), 'w').write(child)

    assert 'adult' == os.path.basename(find_template(cookiecutters_dir))

# Generated at 2022-06-21 10:48:07.665004
# Unit test for function find_template
def test_find_template():
    """
    Check that the right template is discovered inside a test repo.
    """
    test_repo_dir = 'tests/test-repo-pre/'
    assert find_template(test_repo_dir) == \
        os.path.join(test_repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:48:19.256182
# Unit test for function find_template
def test_find_template():
    """Test find_template function with a simple existing directory."""
    # In this unit test we are going to create a temporary directory.
    # When the unit test is done we will remove this directory and all of its
    # contents.
    from cookiecutter.tests.mock import mock_repo
    from cookiecutter.utils import rmtree
    from cookiecutter.utils import work_in

    mock_repo()
    test_template_dir = 'fake-repo-tmpl'
    template_search_path = [
        'fake-repo',
        os.path.join('fake-repo', test_template_dir),
    ]

    assert find_template('fake-repo') == template_search_path[1]

    rmtree('fake-repo')

# Generated at 2022-06-21 10:48:26.585033
# Unit test for function find_template
def test_find_template():
    # Set up
    input_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')

    # Run function
    project_template = find_template(input_dir)

    # Verify
    expected_project_template = os.path.join(input_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_project_template

# Generated at 2022-06-21 10:48:27.751735
# Unit test for function find_template
def test_find_template():
    assert find_template('/blah') == 10

# Generated at 2022-06-21 10:48:37.292823
# Unit test for function find_template
def test_find_template():
    # repo_dir of non-templated project
    repo_dir = os.path.expanduser('~/tests/non-templated')
    try:
        find_template(repo_dir)
    except Exception as e:
        assert isinstance(e, NonTemplatedInputDirException)
    # repo_dir of templated project
    repo_dir = os.path.expanduser('~/tests/fake-repo')
    try:
        find_template(repo_dir)
    except Exception as e:
        assert isinstance(e, NonTemplatedInputDirException) == False

# Generated at 2022-06-21 10:48:38.360824
# Unit test for function find_template
def test_find_template():
    find_template('templates/test-python-package')

# Generated at 2022-06-21 10:48:43.490493
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    :return:
    """
    repo_dir = "C:\\Users\\dyachen\\PycharmProjects\\Test_1\\cookiecutter-pypackage-minimal"

    result = find_template(repo_dir)
    print(result)


test_find_template()

# Generated at 2022-06-21 10:48:44.952785
# Unit test for function find_template
def test_find_template():
    project_template = find_template("cc-repo-jjl")

# Generated at 2022-06-21 10:48:48.427974
# Unit test for function find_template
def test_find_template():
    path = find_template('./tests/test-find-template')
    assert path == './tests/test-find-template/{{cookiecutter.repo_name}}'

test_find_template()

# Generated at 2022-06-21 10:48:51.289825
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.getcwd(), 'tests/test-find-template')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:49:50.746143
# Unit test for function find_template
def test_find_template():
    test_dict = {}
    test_dict['repo_dir'] = '/home/vagrant/git_repos/'
    test_dict['repo_dir_contents'] = ['cookiecutter-pypackage',
                                      'cookiecutter-pypackage/{{cookiecutter.project_name}}']
    assert find_template(test_dict['repo_dir']) == '/home/vagrant/git_repos/cookiecutter-pypackage/{{cookiecutter.project_name}}'

# Generated at 2022-06-21 10:49:53.983547
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    out = 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == out

# Generated at 2022-06-21 10:50:06.296067
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    # Test passing a repo_dir with a template
    repo_dir = '/Users/audreyr/cookiecutters/sprinkles'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/cookiecutters/sprinkles/sprinkles-{{cookiecutter.project_slug}}'
    # Test passing a repo dir without a template
    repo_dir = '/Users/audreyr/cookiecutters/banana_bread'
    try:
        find_template(repo_dir)
        raise Exception('Expected to raise a NonTemplatedInputDirException')
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('Expected to raise a NonTemplatedInputDirException')

# Generated at 2022-06-21 10:50:07.258070
# Unit test for function find_template
def test_find_template():
    # TODO: write a test case
    pass

# Generated at 2022-06-21 10:50:08.519996
# Unit test for function find_template
def test_find_template():
    # When no project template is detected
    # When a project template is detected
    pass

# Generated at 2022-06-21 10:50:10.364110
# Unit test for function find_template
def test_find_template():
    input_dir = os.path.join(os.path.dirname(__file__), 'input/tests')
    assert 'tests' == find_template(input_dir)

# Generated at 2022-06-21 10:50:14.773186
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/michaelkotzjan/cookies/cookiecutter-django') == '/Users/michaelkotzjan/cookies/cookiecutter-django/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:50:25.915128
# Unit test for function find_template
def test_find_template():
    # no need for py.test, as unittest would do.
    # here is just to show the usage of the find_template function.
    from os.path import exists, isdir
    from shutil import rmtree
    from tempfile import mkdtemp
    from textwrap import dedent

    # Prepare a repo with different directory structures
    # and verify that the template is found.

# Generated at 2022-06-21 10:50:37.665051
# Unit test for function find_template
def test_find_template():
    # Test when `repo_dir` is a git repo
    assert find_template('tests/fake-repo-pre/') == os.path.abspath(
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'
    )

    # Test when `repo_dir` is a project template
    assert find_template('tests/fake-repo-pre/fake-project-template/') == os.path.abspath(
        'tests/fake-repo-pre/fake-project-template/'
    )

    # Test when `repo_dir` is a project already generated from a project template

# Generated at 2022-06-21 10:50:45.302500
# Unit test for function find_template
def test_find_template():
    """Test function find_template.

    Create a test directory. Populate it with an example directory structure to
    simulate a repo. Run the function to find the template within the test
    directory.
    """
    project_dir = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(project_dir, 'tests', 'fake-repo', '{{cookiecutter.repo_name}}')

    assert find_template(os.path.join(project_dir, 'tests', 'fake-repo')) == template_dir