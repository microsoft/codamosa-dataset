

# Generated at 2022-06-21 10:41:53.270275
# Unit test for function find_template
def test_find_template():
    """
    Test the function find_template.
    """
    repo_dir = "./tests/test-find-template"
    assert find_template(repo_dir) == "./tests/test-find-template/cookiecutter-pypackage"

# Generated at 2022-06-21 10:41:57.114029
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    assert find_template('/tmp/cookiecutter-{cookiecutter.project_name}') ==\
        '/tmp/cookiecutter-{cookiecutter.project_name}/cookiecutter-{cookiecutter.project_name}'

# Generated at 2022-06-21 10:41:57.676316
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-21 10:41:59.508064
# Unit test for function find_template
def test_find_template():
    assert '/foo/bar/cookiecutter-pypackage{{cookiecutter.project_name}}' == find_template('/foo/bar')

# Generated at 2022-06-21 10:42:03.363114
# Unit test for function find_template
def test_find_template():
    expected_result = os.path.join(
        'tests', 'files', 'test-repo', '{{cookiecutter.repo_name}}'
    )
    result = find_template(
        os.path.join('tests', 'files', 'test-repo')
    )
    assert result == expected_result

# Generated at 2022-06-21 10:42:13.814333
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import pytest
        
    #test with a valid project template directory
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/test-prj-tmpl'
    )
    project_template = find_template(test_dir)
    assert project_template == os.path.join(test_dir, '{{cookiecutter.project_slug}}')
    
    #test with an invalid project template directory
    with pytest.raises(NonTemplatedInputDirException):
        project_template = find_template('.')

# Generated at 2022-06-21 10:42:22.911615
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter

    def get_template_dir_name(repo):
        cached_repo = os.path.join(cookiecutter.USER_CACHE_PATH, repo)
        template = find_template(cached_repo)
        return os.path.basename(template)

    # Default cookiecutter template
    assert get_template_dir_name('https://github.com/audreyr/cookiecutter-pypackage.git') == '{{cookiecutter.repo_name}}'

    # The default project template directory should match the one found
    # not match the repo slug
    repo = 'git@github.com:pytest-dev/cookiecutter-pytest-plugin.git'

# Generated at 2022-06-21 10:42:27.662947
# Unit test for function find_template
def test_find_template():
    import os
    from cookiecutter import main

    # Create a project from a fixture and run cookiecutter on it
    filepath = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-data', 'twolevel-repo')
    main.cookiecutter(filepath)

    # Test to ensure correct project template found
    repo_dir = 'twolevel-repo'

    repo_dir_contents = os.listdir(repo_dir)
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item

    assert project_template == 'twolevel-cookiecutter-template'


# Generated at 2022-06-21 10:42:28.274602
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-21 10:42:32.988988
# Unit test for function find_template
def test_find_template():
    repo_dir = "/home/user/cookiecutter-project/{{cookiecutter.repo_name}}/"
    template_directory = find_template(repo_dir)
    assert template_directory == "/home/user/cookiecutter-project/{{cookiecutter.repo_name}}/"



# Generated at 2022-06-21 10:42:37.637511
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = [
        'jquery',
        'jquery-{{cookiecutter.repo_name}}',
        'backbone',
        'cookiecutter-jquery',
        '.git',
        'README.md'
    ]

    for item in repo_dir_contents:
        assert find_template(item) == os.path.join(repo_dir_contents, item)

# Generated at 2022-06-21 10:42:46.902760
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import shutil
    import tempfile
    import unittest

    class FindTemplateTestCase(unittest.TestCase):

        def setUp(self):
            self.repo_dir = tempfile.mkdtemp()
            os.makedirs(os.path.join(self.repo_dir, 'cookiecutter-foobar'))
            os.makedirs(os.path.join(self.repo_dir, 'cookiecutter-{{name}}'))
            os.makedirs(os.path.join(self.repo_dir, 'cookiecutter'))
            os.makedirs(os.path.join(self.repo_dir, 'cookiecutter-nada'))

# Generated at 2022-06-21 10:42:52.907712
# Unit test for function find_template
def test_find_template():
    output_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'tests/fake-repo-pre/',
    )
    repo_dir = os.path.join(os.path.dirname(output_dir), '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == os.path.join(output_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:42:55.608872
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}-master'

# Generated at 2022-06-21 10:43:02.879575
# Unit test for function find_template
def test_find_template():
    logger.debug('Testing function find_template.')

    repo_dir_contents = [
        '.git',
        'README.md',
        'hooks',
        'LICENSE',
        'cookiecutter-pypackage'
    ]

    repo_dir = '/Users/audreyr/code/cookiecutters/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/code/cookiecutters/cookiecutter-pypackage/cookiecutter-pypackage'



# Generated at 2022-06-21 10:43:03.433537
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:43:07.512784
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test-repo-tmpl',
    )
    template_dir = template_dir.replace('\\', '/')

    project_template = find_template(template_dir).replace('\\', '/')
    assert project_template == template_dir + '/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:08.550896
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:43:12.523728
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'fake-repo-pre')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-21 10:43:13.748789
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass



# Generated at 2022-06-21 10:43:21.419805
# Unit test for function find_template
def test_find_template():
    # This assumes that the current working directory is tests/fixtures/fake-repo-pre/.
    # This is the case if test_find_template() is called from test_context.py.
    template_path = find_template(os.path.join(os.getcwd()))
    assert template_path.endswith('fake-repo-pre/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:43:25.553725
# Unit test for function find_template
def test_find_template():
    search_dir = 'tests/files/fake-repo/'
    found_template = find_template(search_dir)
    assert found_template == 'tests/files/fake-repo/{{cookiecutter.project_slug}}'

# Generated at 2022-06-21 10:43:28.201945
# Unit test for function find_template
def test_find_template():
    print(find_template('/home/pranav/CookieCutter/cookiecutter'))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:43:31.975009
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = './tests/files/fake-repo-pre/'
    assert find_template(repo_dir) == './tests/files/fake-repo-pre/{{cookiecutter.repo_name}}-pre/'

# Generated at 2022-06-21 10:43:34.060213
# Unit test for function find_template
def test_find_template():
    assert find_template("../cookiecutter-pypackage") == "../cookiecutter-pypackage/{{cookiecutter.repo_name}}"

# Generated at 2022-06-21 10:43:37.629972
# Unit test for function find_template
def test_find_template():
    assert find_template('my_template') == 'my_template/cookiecutter-my_template'

# Generated at 2022-06-21 10:43:39.238734
# Unit test for function find_template
def test_find_template():
    # TODO: create a 'fake' repository with a template in it.
    pass

# Generated at 2022-06-21 10:43:42.705950
# Unit test for function find_template
def test_find_template():
    """
    Test for function find_template
    :return:
    """
    assert find_template('./tests/fake-repo-template') == './tests/fake-repo-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:48.517320
# Unit test for function find_template
def test_find_template():
    """Test if `find_template` by returning a valid template path."""
    assert find_template("/Users/sophialiu/anaconda/envs/cookiecutter")
    assert find_template("/Users/sophialiu/anaconda/envs")
    assert find_template("/Users/sophialiu/anaconda")
    assert find_template("/Users/sophialiu")

# Generated at 2022-06-21 10:43:53.804424
# Unit test for function find_template
def test_find_template():
    logger.debug('Testing function find_template')
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    expected = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    actual = find_template(repo_dir)
    assert actual == expected



# Generated at 2022-06-21 10:44:00.595661
# Unit test for function find_template
def test_find_template():
    directory = os.path.join(os.path.dirname(__file__), 'fake-repo-pre')
    project_template = find_template(directory)

    # This is the expected project template based on the fake repo as it is.
    assert_project_template = os.path.join(directory, '{{cookiecutter.repo_name}}')

    assert project_template == assert_project_template


# Generated at 2022-06-21 10:44:06.426395
# Unit test for function find_template
def test_find_template():
    """Test for find_template function."""
    repo_dir = '/home/foo/.cookiecutters/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/home/foo/.cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:07.469960
# Unit test for function find_template
def test_find_template():
    find_template('testrepo')
#


# Generated at 2022-06-21 10:44:10.796446
# Unit test for function find_template
def test_find_template():
    """
    Test for function find_template
    """
    assert find_template("/home/joe/repo-cookiecutter") == "/home/joe/repo-cookiecutter/cookiecutter-pip"



# Generated at 2022-06-21 10:44:14.334765
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests/fake-repo-pre/"
    project_template = find_template(repo_dir)
    assert project_template == os.path.abspath("tests/fake-repo-pre/{{cookiecutter.repo_name}}")

# Generated at 2022-06-21 10:44:17.517131
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-tmpl/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.abspath('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:44:24.514272
# Unit test for function find_template
def test_find_template():
    from .compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, 'foo'))
        os.makedirs(os.path.join(tmpdir, '{{cookiecutter.repo_name}}'))

        assert '{{cookiecutter.repo_name}}' == os.path.basename(find_template(tmpdir))



# Generated at 2022-06-21 10:44:33.592498
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter

    # FIXME: use the tempdir fixture from pytest
    tmpdir = tempfile.mkdtemp()
    repo_dir = os.path.join(tmpdir, 'fake-repo')
    os.mkdir(repo_dir)
    template = os.path.join(repo_dir, 'foobar{{cookiecutter.foobar}}baz')
    os.mkdir(template)
    logger.debug(template)

    repo = 'file://{}'.format(repo_dir)
    logger.debug(repo)

    with pytest.raises(NonTemplatedInputDirException):
        cookiecutter(repo)

    open(os.path.join(repo_dir, 'cookiecutter.json'), 'w')
    result = cookiecut

# Generated at 2022-06-21 10:44:35.256481
# Unit test for function find_template
def test_find_template():
    find_template('tests/Fixtures/cookiecutters/fake-repo')

# Generated at 2022-06-21 10:44:41.962945
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        "input_example"
    )
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)

# Generated at 2022-06-21 10:44:48.278895
# Unit test for function find_template
def test_find_template():
    """Testing for find_template()."""
    pass

# Generated at 2022-06-21 10:44:49.487726
# Unit test for function find_template
def test_find_template():
    raise NotImplementedError

# Generated at 2022-06-21 10:44:54.878722
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function in utils.py.
    """
    repo_dir = '/Users/audreyr/Documents/code/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert 'cookiecutter-pypackage' in project_template

# Generated at 2022-06-21 10:45:05.137256
# Unit test for function find_template
def test_find_template():
    from tempdir import tempdir
    search_dir = os.path.join(tempdir, 'repo_dir')
    os.makedirs(search_dir)
    os.mkdir(os.path.join(search_dir, '{{test_template}}'))
    assert find_template(search_dir) == os.path.join(search_dir, '{{test_template}}')
    os.mkdir(os.path.join(search_dir, '{{test_template}}-1'))
    try:
        find_template(search_dir)
        assert False # should raise exception
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-21 10:45:05.749281
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:45:12.121971
# Unit test for function find_template
def test_find_template():
    """A test for the find_template function."""

    path = os.path.normpath(os.path.join(
        os.path.dirname(__file__),
        '..', 'tests', 'test-find-template'
    ))

    assert find_template(path) == os.path.join(path, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:45:22.575913
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.utils import rmtree
    from git import Repo

    from cookiecutter import main

    test_repo = 'tests/test-templates/fake-repo-tmpl'
    test_repo_output = 'tests/test-output/fake-repo-tmpl'
    shutil.copytree(test_repo, test_repo_output)

    repo = Repo.clone_from(test_repo, test_repo_output)

    project_template = find_template(test_repo_output)
    assert project_template == os.path.join(test_repo_output, '{{cookiecutter.repo_name}}'), project_template

    rmtree(test_repo_output)

# Generated at 2022-06-21 10:45:25.078768
# Unit test for function find_template
def test_find_template():
    find_template('/tmp/cookiecutter-pypackage-template/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:45:30.178174
# Unit test for function find_template
def test_find_template():
    """
    Given a single repo with a single template, find the template.
    """
    repo_local_path = os.path.join(os.getcwd(), 'tests/test-repo-pre/')
    result = find_template(repo_local_path)
    truth = os.path.join(repo_local_path, 'cookiecutter-pypackage')
    assert result == truth

# Generated at 2022-06-21 10:45:41.432502
# Unit test for function find_template
def test_find_template():
    """Test `find_template` function."""
    # input_dir = os.path.join(
    #     'tests', 'assets', 'test-repo-pre', 'test-repo-templated'
    # )
    input_dir = 'tests/assets/test-repo-pre/test-repo-templated'
    assert find_template(input_dir) == os.path.join(
        input_dir, '{{cookiecutter.repo_name}}'
    )

    # input_dir = os.path.join(
    #     'tests', 'assets', 'test-repo-pre', 'test-repo-no-templated'
    # )
    input_dir = 'tests/assets/test-repo-pre/test-repo-no-templated'


# Generated at 2022-06-21 10:45:58.081876
# Unit test for function find_template
def test_find_template():
    # Create a fake repo with tmp
    os.makedirs('/tmp/repo/{{cookiecutter.repo_name}}')
    assert find_template('/tmp/repo') == '/tmp/repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:45:58.873481
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:46:04.555385
# Unit test for function find_template
def test_find_template():
    """Test function find_template"""
    fake_repo_dir = [
        '{{cookiecutter.project_name}}_my_project',
        'cookiecutter-my-project'
    ]
    assert find_template(fake_repo_dir) == '{{cookiecutter.project_name}}_my_project'

# Generated at 2022-06-21 10:46:10.973295
# Unit test for function find_template
def test_find_template():
    template_path = find_template("/Users/mikkel/git/cookiecutter/tests/test-repo/input")
    assert(template_path == "/Users/mikkel/git/cookiecutter/tests/test-repo/input/{{cookiecutter.repo_name}}")

# test = find_template("/Users/mikkel/git/cookiecutter/tests/test-repo/input")
# print(test)

# Generated at 2022-06-21 10:46:16.911609
# Unit test for function find_template
def test_find_template():
    # Project template at top level
    assert os.path.split(find_template('tests/fake-repo-tmpl'))[1] == 'fake-repo-pre'

    # Project template in sub-directory
    assert os.path.split(find_template('tests/fake-repo-pre/fake-repo-tmpl'))[1] == 'fake-repo-post'

# Generated at 2022-06-21 10:46:17.503331
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:46:23.629344
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/vanessa/my_repos/test-cookiecutter-pypackage'
    project_template = os.path.join(repo_dir,'{{cookiecutter.project_slug}}')
    actual_project_template = find_template(repo_dir)
    assert project_template == actual_project_template

test_find_template()

# Generated at 2022-06-21 10:46:31.273670
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import shutil
    import tempfile

    logger.debug('Creating temp directory.')
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 10:46:31.805791
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:46:39.274679
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/python/repo'
    repo_dir_contents = ['foo', 'bar', 'cookiecutter-{{cookiecutter.repo_name}}']
    os.path.isfile = lambda x: False
    os.listdir = lambda x: repo_dir_contents

    template = find_template(repo_dir)
    expected = '/home/python/repo/cookiecutter-{{cookiecutter.repo_name}}'
    assert template == expected


# Generated at 2022-06-21 10:47:02.381817
# Unit test for function find_template
def test_find_template():
    """Test find_template function"""

    dir_items = ['cookiecutter', 'cookiecutter-django', 'cookiecutter-django/{{cookiecutter.repo_name}}/js', 'cookiecutter-django/{{cookiecutter.repo_name}}/css']

    dir_items_contents = [
        (dir_items[0], ['README.md', 'cookiecutter.json']),
        (dir_items[1], ['README.md', 'cookiecutter.json']),
        (dir_items[2], ['{{cookiecutter.repo_name}}', 'README.md']),
        (dir_items[3], ['{{cookiecutter.repo_name}}', 'README.md'])
    ]

    # Mock result of os.listdir()

# Generated at 2022-06-21 10:47:14.771937
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import tempfile
    from cookiecutter.utils.paths import ensure_dir
    from cookiecutter.main import cookiecutter

    tempdir = tempfile.mkdtemp()

    fake_repo = os.path.join(tempdir, 'fake-repo')

    ensure_dir(fake_repo)

    # create new project from this template
    ensure_dir(os.path.join(fake_repo, 'fake-cookiecutter-template'))
    os.makedirs(os.path.join(fake_repo, 'fake-cookiecutter-template', '{{cookiecutter.repo_name}}'))


# Generated at 2022-06-21 10:47:15.906077
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == os.path.join('repo_dir', 'item')

# Generated at 2022-06-21 10:47:16.548101
# Unit test for function find_template
def test_find_template():
    assert find_template()

# Generated at 2022-06-21 10:47:19.508636
# Unit test for function find_template
def test_find_template():
    dict = find_template("/home/aman/Desktop/new3")

# Generated at 2022-06-21 10:47:25.312528
# Unit test for function find_template
def test_find_template():
    repo_dir = "/Users/audreyr/src/cookiecutter/tests/fake-repo-pre/{{cookiecutter.repo_name}}/"
    project_dir = "/Users/audreyr/src/cookiecutter/tests/fake-repo-pre/pyproject"
    assert find_template(repo_dir) == project_dir


# Generated at 2022-06-21 10:47:28.296086
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo'
    project_template = 'tests/test-repo/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:47:40.147720
# Unit test for function find_template
def test_find_template():
    """
    Unit testing:
    1.  Looking for the project template in a repo containing junk files
        like .DS_Store.
    2.  Looking for the project template in a repo containing only a
        template.
    3.  Looking for the project template when the repo doesn't have a
        template.
    """
    import shutil
    import tempfile

    # Setup: mkdir and cd into a temp directory
    temp_dir = tempfile.mkdtemp()
    temp_repo_dir = os.path.join(temp_dir, 'repo')
    os.mkdir(temp_repo_dir)
    assert os.path.isdir(temp_repo_dir)

    # 1. Looking for the project template in a repo containing junk files like
    #    .DS_Store.

# Generated at 2022-06-21 10:47:44.002099
# Unit test for function find_template
def test_find_template():
    """Tests for the function find_template"""
    import pytest
    from cookiecutter import utils

    with pytest.raises(NonTemplatedInputDirException):
        utils.find_template(os.path.join(
            os.path.dirname(__file__), 'test-find-template'))

# Generated at 2022-06-21 10:47:52.298781
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""

    import shutil
    import tempfile
    repo_dir = tempfile.mkdtemp()
    subdir = os.path.join(repo_dir, 'cookiecutter-pypackage')
    os.mkdir(subdir)
    logger.debug('Made a subdirectory: %s', subdir)
    logger.debug('Which is a directory? %s', os.path.isdir(subdir))

    template = find_template(repo_dir)

    shutil.rmtree(repo_dir)

    assert template == subdir


# Generated at 2022-06-21 10:48:26.853156
# Unit test for function find_template
def test_find_template():
    """Test that find_template finds project template."""
    repo_dir = os.path.abspath('tests/test-repo/')
    project_template = find_template(repo_dir)
    expected_template = os.path.abspath('tests/test-repo/{{cookiecutter.repo_name}}/')
    assert project_template == expected_template



# Generated at 2022-06-21 10:48:29.653577
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:48:37.254424
# Unit test for function find_template
def test_find_template():
    """Find the project template in the folder provided"""
    repo_dir = ("/Users/cflagg/Documents/projects/"
                "cookiecutter-demo/cookiecutter-demo/")

    template_dir = find_template(repo_dir)

    if template_dir:
        print("Found the project template in: {}".format(template_dir))
    else:
        print("Did not find the project template")

# Run the unit test
test_find_template()

# Generated at 2022-06-21 10:48:39.796680
# Unit test for function find_template
def test_find_template():
    test_path = os.path.join('tests', 'test-repo-pre')
    assert find_template(test_path).endswith('cookiecutter-pypackage')


# Generated at 2022-06-21 10:48:50.826038
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns path to the project template."""
    from cookiecutter import main
    from cookiecutter import utils
    from unittest import TestCase
    from shutil import rmtree

    class TestFindTemplate(TestCase):

        def setUp(self):
            self.repo_dir = utils.make_repo_dir()
            self.template_dir = 'fake-project'
            self.repo_dir_contents = os.listdir(self.repo_dir)

            full_path = utils.workaround_and_create_dir(
                os.path.join(self.repo_dir, self.template_dir))
            self.repo_dir_contents = os.listdir(self.repo_dir)


# Generated at 2022-06-21 10:48:56.232146
# Unit test for function find_template
def test_find_template():
    """
    Tests that function find_template finds the correct project template, even if the repo contains
    other files.
    """
    repo_dir = r'..\tests\test-repo-pre\cookiecutter-{{cookiecutter.folder_name}}'
    project_template = find_template(repo_dir)
    assert project_template == r'..\tests\test-repo-pre\cookiecutter-{{cookiecutter.folder_name}}'



# Generated at 2022-06-21 10:48:58.556749
# Unit test for function find_template
def test_find_template():
    assert find_template(os.getcwd()) == os.path.join(os.getcwd(), 'path', 'to')


# Generated at 2022-06-21 10:49:03.079465
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    repo_dir = '~/my-cookiecutter-project'
    project_template = '~/my-cookiecutter-project/cookiecutter-project'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:49:03.637418
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:49:07.468286
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'fake-repo')
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)



# Generated at 2022-06-21 10:50:17.315413
# Unit test for function find_template
def test_find_template():
    """Test find_template()"""
    pass

# Generated at 2022-06-21 10:50:20.855892
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'



# Generated at 2022-06-21 10:50:23.372770
# Unit test for function find_template
def test_find_template():
    template = find_template('/tmp/repo-dir')
    assert template == '/tmp/repo-dir/cookiecutter-{{ cookiecutter.repo_name }}'

# Generated at 2022-06-21 10:50:23.940738
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:50:25.375449
# Unit test for function find_template
def test_find_template():
    find_template('tests/test-repo-tmpl')

# Generated at 2022-06-21 10:50:36.690265
# Unit test for function find_template
def test_find_template():
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter import find

    with TemporaryDirectory('foo') as tmp_dir:
        # Create a populated directory
        template_name = 'foo'
        os.makedirs(os.path.join(tmp_dir, template_name))
        for f in ('index.html', 'test.html', 'photo.png'):
            open(os.path.join(tmp_dir, template_name, f), 'wb').close()

        # Create an empty directory
        empty_dir_name = 'bar'
        os.makedirs(os.path.join(tmp_dir, empty_dir_name))

        assert find.find_template(tmp_dir) == os.path.join(tmp_dir, template_name)

# Generated at 2022-06-21 10:50:41.778171
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '../tests/test-input/cookiecutter-pypackage/'
    ))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:50:49.229577
# Unit test for function find_template
def test_find_template():
    _test_repo_dir = ''
    try:
        _test_template = find_template(_test_repo_dir)
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

    _test_repo_dir = '/tmp/test-repo'

    try:
        _test_template = find_template(_test_repo_dir)
    except NonTemplatedInputDirException:
        assert False
    else:
        assert (_test_template == '/tmp/test-repo/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:50:55.624128
# Unit test for function find_template
def test_find_template():
    # Arrange
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), 'tests/fake-repo'
    )
    expected_result = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'tests/fake-repo/{{cookiecutter.project_slug}}'
    )

    # Act
    result = find_template(repo_dir)

    # Assert
    assert result == expected_result

# Generated at 2022-06-21 10:51:07.366879
# Unit test for function find_template
def test_find_template():
    from tempfile import mkdtemp
    from shutil import rmtree
    from cookiecutter.utils import work_in
    from unittest import TestCase
    from os.path import join, exists

    class TestFindTemplate(TestCase):

        def setUp(self):
            self.test_prefix = mkdtemp()
            self.test_dir = join(self.test_prefix, 'input')
            os.makedirs(self.test_dir)
            self.test_file = join(self.test_dir, 'cookiecutter.json')
            open(self.test_file, 'w').write('{"foo": "bar"}')

        def tearDown(self):
            rmtree(self.test_prefix)
