

# Generated at 2022-06-21 10:41:52.145880
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir='/home') == '/home/cookiecutter-pypackage'


# Generated at 2022-06-21 10:41:56.961234
# Unit test for function find_template
def test_find_template():
    """Test that we can find a template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'fixtures/fake-repo'
    )
    project_template = find_template(repo_dir)
    assert 'cookiecutter-pypackage' in project_template

# Generated at 2022-06-21 10:42:04.694944
# Unit test for function find_template
def test_find_template():
    """Test the find_template() func."""
    import tempfile
    from cookiecutter.main import cookiecutter

    output_dir = tempfile.mkdtemp()
    repo_dir = cookiecutter('https://github.com/audreyr/cookiecutter-pypackage.git',
                            no_input=True,
                            output_dir=output_dir)

    assert os.path.isdir(repo_dir)

    project_template = find_template(repo_dir)
    assert os.path.isdir(project_template)
    assert 'cookiecutter' in project_template
    assert '{{' in project_template
    assert '}}' in project_template

    import shutil
    shutil.rmtree(output_dir)

# Generated at 2022-06-21 10:42:14.534885
# Unit test for function find_template
def test_find_template():
    
    # When the Cookiecutter template is in a subdirectory
    repo_dir = 'some/relative/path/to/cheese-shop'
    result = find_template(repo_dir)
    assert result == 'some/relative/path/to/cheese-shop/{{cookiecutter.repo_name}}'
    
    # When the Cookiecutter template is in the parent directory
    repo_dir = 'my/parent/repo-name/'
    result = find_template(repo_dir)
    assert result == 'my/parent/repo-name/repo-name'

# Generated at 2022-06-21 10:42:24.700912
# Unit test for function find_template
def test_find_template():
    """Verify find_template works in expected situations."""
    import tempfile
    import shutil


# Generated at 2022-06-21 10:42:31.745297
# Unit test for function find_template
def test_find_template():
    repo_dir = '/tmp/fake-repo'
    template_file_name = 'cookiecutter-template-{{cookiecutter.repo_name}}'
    template_file_path = os.path.join(repo_dir, template_file_name)
    os.mkdir(repo_dir)
    os.mkdir(template_file_path)
    assert find_template(repo_dir) == template_file_path

# Generated at 2022-06-21 10:42:35.697306
# Unit test for function find_template
def test_find_template():
    assert find_template('./tests/test-input/repo_with_template/') == './tests/test-input/repo_with_template/' \
                                                                      '{{cookiecutter.project_slug}}'

# Generated at 2022-06-21 10:42:39.439678
# Unit test for function find_template
def test_find_template():
    test_template_dir = 'tests/normal_project'
    template_path = find_template(test_template_dir)
    assert template_path == 'tests/normal_project/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:43.791134
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    assert find_template('/'+os.path.join('home','cookiecutter','tests','fixtures','fake-repo-pre')) == '/home/cookiecutter/tests/fixtures/fake-repo-pre/{{cookiecutter.project_name}}'



# Generated at 2022-06-21 10:42:45.710067
# Unit test for function find_template
def test_find_template():
    assert find_template('../tests/fake-repo-templated') == '../tests/fake-repo-templated/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:52.596200
# Unit test for function find_template
def test_find_template():
    import tests.test_utils
    temp_dir = os.path.join(tests.test_utils.temp_dir, 'test_find_template')
    os.makedirs(os.path.join(temp_dir, 'cookiecutter-foobar'))
    assert find_template(temp_dir) == os.path.join(
        temp_dir,
        'cookiecutter-foobar'
    )

# Generated at 2022-06-21 10:42:57.216072
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir_contents = ["cookiecutteer-{{cookiecutter.repo_name}}"]
    project_template = find_template(repo_dir_contents)
    assert project_template == "cookiecutteer-{{cookiecutter.repo_name}}"



# Generated at 2022-06-21 10:43:05.856539
# Unit test for function find_template
def test_find_template():
    """Test find_template using Travis CI repo."""
    import tempfile
    from cookiecutter.utils import check_and_make_dir, rmtree
    from cookiecutter import main

    repo_dir = tempfile.mkdtemp()
    logging.debug('The tmp dir for the test repo is at %s', repo_dir)
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    logging.debug('Cloning repo %s into dir %s', repo_url, repo_dir)
    main.cookiecutter(repo_url, no_input=True, output_dir=repo_dir)

# Generated at 2022-06-21 10:43:10.124288
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    logger.info('Running unit test for function find_template')
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:10.852405
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:43:21.582208
# Unit test for function find_template
def test_find_template():
    """Verify find_template finds the correct template directory."""
    logger.info('Verifying find_template function from local_repo')
    import tempfile
    from cookiecutter import utils
    from cookiecutter.utils import rmtree

    tmp_dir = tempfile.mkdtemp()
    template_dir = 'cookiecutter-pypackage'
    repo_dir = os.path.join(tmp_dir, template_dir)
    utils.make_sure_path_exists(repo_dir)
    os.chdir(tmp_dir)
    tmpl_dir = find_template(tmp_dir)
    assert tmpl_dir == repo_dir
    rmtree(tmp_dir)

# Generated at 2022-06-21 10:43:26.842686
# Unit test for function find_template
def test_find_template():
    """Verify the operation of find_template()."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == expected

# Generated at 2022-06-21 10:43:28.621966
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir='/Users/vincent/Desktop/DesktopCookie.git')

# Generated at 2022-06-21 10:43:31.022348
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter/tests/test-repo-pre/') == 'cookiecutter/tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:36.601880
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    from cookiecutter.utils.paths import ensure_dir

    repo_dir = '/tmp/booya/'
    shutil.rmtree(repo_dir)
    ensure_dir(repo_dir)

    repo_contents = ['hello', 'cookiecutter-{{cookiecutter.repo_name}}', 'hello2']

    for item in repo_contents:
        with open(os.path.join(repo_dir, item), 'w'):
            pass

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, repo_contents[-2])

# Generated at 2022-06-21 10:43:43.031115
# Unit test for function find_template
def test_find_template():
    """
    Template with {{ variable }
    """

    here = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(here, 'fake-repo-pre/')

    assert '{{cookiecutter.repo_name}}' in find_template(repo_dir)

# Generated at 2022-06-21 10:43:54.259751
# Unit test for function find_template
def test_find_template():
    """
    Check that the function ``find_template()``

    1. Can find a template directory in a directory
    2. Cannot find a template directory in an empty directory
    """
    import shutil
    import tempfile
    import os

    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-foobar')

    shutil.rmtree(repo_dir)
    try:
        project_template = find_template(repo_dir)
        assert False
    except NonTemplatedInputDirException:
        # The expected exception was raised.
        pass

# Generated at 2022-06-21 10:43:57.230716
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vincent/Project/jcml/cookiecutter-python-project') == '/home/vincent/Project/jcml/cookiecutter-python-project/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:01.925000
# Unit test for function find_template
def test_find_template():
    os.chdir('tests/input')
    repo_dir = os.path.abspath('.')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:44:12.306017
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter-style template directory is identified."""
    import os
    import shutil
    import tempfile
    import unittest

    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary testing directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary child directory
    temp_child = tempfile.mkdtemp(dir=temp_dir)

    # Create a test file in the temporary directory
    test_file = 'cookiecutter.json'
    test_path = os.path.join(temp_dir, test_file)

    with open(test_path, 'w') as f:
        f.write('{"key": "value"}')

    # Create another test file in the child directory
    child_file = 'cookiecutter.json'
    child

# Generated at 2022-06-21 10:44:16.016426
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/test-data/fake-repo-pre'
    project_template = find_template(repo_dir)
    assert project_template == './tests/test-data/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:24.514980
# Unit test for function find_template
def test_find_template():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    template_dir = os.path.join(base_dir, '..', 'tests', 'fake-repo', '{{cookiecutter.repo_name}}')
    template_dir = os.path.abspath(template_dir)
    template_dir = os.path.normpath(template_dir)

    assert find_template(os.path.dirname(template_dir)) == template_dir

# Generated at 2022-06-21 10:44:29.020644
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    from .utils import TEST_TEMPLATE

    project_template = find_template(TEST_TEMPLATE)
    assert os.path.join('{{cookiecutter.repo_name}}', 'cookiecutter') in project_template


# Generated at 2022-06-21 10:44:30.545758
# Unit test for function find_template
def test_find_template():
    """Test function to find a template in a repo_dir..
    """
    find_template('test')

# Generated at 2022-06-21 10:44:34.722176
# Unit test for function find_template
def test_find_template():
    example_repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-input', os.path.pardir
    )
    project_template = find_template(example_repo_dir)
    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:43.197570
# Unit test for function find_template
def test_find_template():
    """ Ensure that find_template can find the project template in the test fixture"""

    import sys
    import os

    if sys.version_info >= (3, 0):
        from unittest.mock import patch
    else:
        from mock import patch

    from cookiecutter import find
    from cookiecutter import exceptions

    with patch('cookiecutter.find.os.path.join') as mkdtemp:
        with patch('cookiecutter.find.shutil.copytree') as copytree:
            with patch('cookiecutter.find.os.listdir') as listdir:
                # Set up our mocked objects
                mkdtemp.return_value = '/fake/path'
                copytree.return_value = '/fake/path'

# Generated at 2022-06-21 10:44:47.710755
# Unit test for function find_template
def test_find_template():
    """Assert that find_template finds the template directory."""
    repo_dir = 'tests/fake-repo-tmpl'
    project_template = 'fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template
    
    

# Generated at 2022-06-21 10:44:55.188160
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""

    root_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        '..',
        'tests',
        'cookiecutters',
        'tests',
        'fake-repo-tmpl'
    )

    template = find_template(root_dir)

    assert 'fake-repo-tmpl' in template
    assert '{{' in template
    assert '}}' in template

# Generated at 2022-06-21 10:45:07.949042
# Unit test for function find_template
def test_find_template():
    """Test the find_template function.

    :returns: True if test passes, False if not.

    """
    assert find_template(os.path.join('tests', 'fake-repo-pre')) == os.path.join('tests', 'fake-repo-pre', 'cookiecutter-pypackage')
    assert find_template(os.path.join('tests', 'fake-repo-pre-master')) == os.path.join('tests', 'fake-repo-pre-master', 'cookiecutter-pypackage')
    assert find_template(os.path.join('tests', 'fake-repo-pre')) == os.path.join('tests', 'fake-repo-pre', 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:45:16.503809
# Unit test for function find_template
def test_find_template():
    """Verify function find_template."""
    import tempfile
    import shutil

    REPO_TEMPLATE_DIR = 'tests/test-in/{{cookiecutter.repo_name}}'

    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')

    shutil.copytree(REPO_TEMPLATE_DIR, repo_dir)

    project_template = find_template(repo_dir)
    assert 'cookiecutter-pypackage' in project_template

# Generated at 2022-06-21 10:45:21.044454
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    assert find_template('/Users/blais/dev/test/test_cookiecutter') == '/Users/blais/dev/test/test_cookiecutter/cookiecutter-pypackage'

# Generated at 2022-06-21 10:45:31.166023
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import make_temporary_directory

    with make_temporary_directory() as repo_dir:
        d1 = os.path.join(repo_dir, 'd1')
        d2 = os.path.join(repo_dir, 'd2')
        os.mkdir(d1)
        os.mkdir(d2)
        tf1 = os.path.join(d1, '{{cookiecutter.project_name}}.txt')
        tf2 = os.path.join(d2, 'not_a_template_file.txt')
        with open(tf1, 'w') as f1:
            f1.write('Hello world!')

# Generated at 2022-06-21 10:45:35.642029
# Unit test for function find_template
def test_find_template():
    """
    Test that project template is found correctly given a repo directory
    """
    find_template("/home/kieran/Projects/cookiecutter")



# Generated at 2022-06-21 10:45:45.056519
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    tmp_dir = tempfile.mkdtemp()
    shutil.copytree("tests/test-find-template-repo",
                    os.path.join(tmp_dir, "test-find-template-repo"))

    try:
        assert find_template(os.path.join(tmp_dir, "test-find-template-repo")) == os.path.join(tmp_dir, "test-find-template-repo", "{{cookiecutter.repo_name}}")
    except Exception:
        raise
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-21 10:45:48.495516
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-tmpl')
    expected = os.path.abspath('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')
    project_template = find_template(repo_dir)
    expected == project_template

# Generated at 2022-06-21 10:46:00.565938
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    repo_dir = utils.get_user_config_path('tests/test-repo-pre/')
    project_template = os.path.join(repo_dir, 'cookiecutter-pypackage')
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:46:08.729927
# Unit test for function find_template
def test_find_template():
    """Test the find_template function.

    Run the unit test with:
    nosetests -v --with-doctest cookiecutter/find.py
    """
    # Normal case (without a prefix), should equal `{{cookiecutter.repo_name}}`
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    result = find_template(repo_dir)
    assert result == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:46:12.358861
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns a relative path when the template is named like a template."""
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:46:16.708024
# Unit test for function find_template
def test_find_template():
    test_template_dir = 'tests/test-templates/fake-repo'
    test_result = 'tests/test-templates/fake-repo/{{cookiecutter.repo_name}}'
    assert find_template(test_template_dir) == test_result

# Generated at 2022-06-21 10:46:23.629888
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    project_tmpl = find_template(test_repo_dir)
    assert project_tmpl == os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-21 10:46:26.531496
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/cookiecutter-pypackage') == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:46:29.582889
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/hackel/Projects/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/Users/hackel/Projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:46:31.722753
# Unit test for function find_template
def test_find_template():
    repo_dir = '.'
    project_template = find_template(repo_dir)
    assert project_template == '.'

# Generated at 2022-06-21 10:46:38.391115
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/foo/bar/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/foo/bar/cookiecutter-pypackage/{{cookiecutter.repo_name}}', 'project_template should be /Users/foo/bar/cookiecutter-pypackage/{{cookiecutter.repo_name}}'  # noqa

# Generated at 2022-06-21 10:46:49.452290
# Unit test for function find_template
def test_find_template():
    import os.path
    import tempfile
    from shutil import rmtree

    test_dir = tempfile.mkdtemp()

    # Create a fake repo
    os.mkdir(os.path.join(test_dir, 'repo'))
    fake_repo = os.path.join(test_dir, 'repo')

    # Create a fake project template
    os.mkdir(os.path.join(fake_repo, '{{cookiecutter.repo_name}}'))
    fake_project_template = os.path.join(
        fake_repo, '{{cookiecutter.repo_name}}'
    )

    # Ensure the function finds the fake project template
    project_template = find_template(fake_repo)
    assert(project_template == fake_project_template)

   

# Generated at 2022-06-21 10:47:08.849542
# Unit test for function find_template
def test_find_template():
    """
    find_template should return 'pycon-speaker/hello_world'
    for the 'tests/fixtures/fake-repo-pre' directory.
    """
    assert find_template('tests/fixtures/fake-repo-pre') == \
           'tests/fixtures/fake-repo-pre/{{cookiecutter.github_username}}/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:47:09.694758
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:47:15.645801
# Unit test for function find_template
def test_find_template():
    """Verify function finds correct directory."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'fake-repo')
    )
    project_dir = find_template(repo_dir)
    assert os.path.isdir(project_dir)


# Generated at 2022-06-21 10:47:22.932482
# Unit test for function find_template
def test_find_template():
    """Unit tests for `find_template` function."""
    #   Create a test repo_dir
    #   Ensure that find_template works.
    #   Update repo_dir to have a nested directory that looks like a template.
    #   Ensure that find_template works.
    #   Update repo_dir to have no nested directory that looks like a template.
    #   Ensure that find_template raises a NonTemplatedInputDirException.
    pass

# Generated at 2022-06-21 10:47:28.895514
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        'tests',
        'fake-repo-pre'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:47:34.277981
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, os.path.pardir, 'tests', 'fake-repo-template')
    assert find_template(repo_dir) == os.path.join(repo_dir, 'project_template')

# Generated at 2022-06-21 10:47:38.461196
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(os.path.dirname(__file__))
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-21 10:47:43.717067
# Unit test for function find_template
def test_find_template():
    with testproject():
        repo_dir = '.'
        repo_dir_contents = os.listdir(repo_dir)
        assert ('{{cookiecutter.repo_name}}' in repo_dir_contents)
        project_template = find_template(repo_dir)
        assert (project_template == '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:47:49.154734
# Unit test for function find_template
def test_find_template():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    repo_dir_template = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(repo_dir_template)
    assert find_template(temp_dir) == repo_dir_template

# Generated at 2022-06-21 10:47:51.205339
# Unit test for function find_template

# Generated at 2022-06-21 10:48:28.791686
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import os
    import shutil

    TEST_DIR = '/tmp/cookiecutter_tests'

    if os.path.exists(TEST_DIR):
        shutil.rmtree(TEST_DIR)

    os.makedirs(TEST_DIR)
    os.makedirs(os.path.join(TEST_DIR, 'cookiecutter-foo'))
    os.makedirs(os.path.join(TEST_DIR, 'bar'))
    os.makedirs(os.path.join(TEST_DIR, 'cookiecutter-bar'))

    project_template = find_template(TEST_DIR)
    assert 'cookiecutter-foo' in project_template


if __name__ == '__main__':
    test_find_

# Generated at 2022-06-21 10:48:34.913042
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'test-find-template')
    project_template = find_template(repo_dir)
    # test-find-template contains a directory called 'test_project'
    assert project_template == os.path.join(repo_dir, 'test_project')

# Generated at 2022-06-21 10:48:38.905661
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests','fake-repo','{{cookiecutter.repo_name}}-master')
    project_template = find_template(repo_dir)
    assert os.path.join(repo_dir, 'fake_template') == project_template


# Generated at 2022-06-21 10:48:44.855387
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find the project template inside a repo."""
    test_repo_dir = '/Users/audreyr/Code/cookiecutter-pypackage'

    expected = '/Users/audreyr/Code/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

    actual = find_template(test_repo_dir)

    assert expected == actual



# Generated at 2022-06-21 10:48:49.044203
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/nolanbconaway/github/cookiecutter-pypackage'

    assert find_template(repo_dir) == '/Users/nolanbconaway/github/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:48:52.541822
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

    project_template = os.path.join(repo_dir, 'foo_{{ cookiecutter.project_name }}')
    with open(project_template, 'wb') as f:
        f.write('')

    assert find_template(repo_dir) == project_template

    shutil.rmtree(repo_dir)

# Generated at 2022-06-21 10:48:53.777514
# Unit test for function find_template
def test_find_template():
    """
    todo:
    :return:
    """

# Generated at 2022-06-21 10:48:54.535349
# Unit test for function find_template
def test_find_template():
    assert True

# Generated at 2022-06-21 10:49:01.156222
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    from cookiecutter.tests.test_finders import PROJECT_DIR, FIXTURES

    repo_dir = os.path.join(FIXTURES, 'project-dir')
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert(find_template(repo_dir) == project_template)

# Generated at 2022-06-21 10:49:11.418158
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template function."""
    import shutil
    from cookiecutter.operations import _validate_cookiecutter_template
    from cookiecutter import utils

    # Create a fake cookiecutter template
    tmp_dir = os.path.join(os.getcwd(), 'fake-cookiecutter-{}'.format(utils.make_random_string(10)))
    os.makedirs(tmp_dir)
    fake_cc_path = os.path.join(tmp_dir, 'fake-cookiecutter-{{ cookiecutter.fake_variable }}')
    open(fake_cc_path, 'a').close()

    # Test that the find_template function finds the fake cookiecutter template

# Generated at 2022-06-21 10:50:09.844067
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/test-data/fake-repo-tmpl'
    path = find_template(repo_dir)
    assert os.path.abspath(path) == os.path.abspath('./tests/test-data/fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:50:13.800625
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    assert find_template(repo_dir) == os.path.abspath('tests/fake-repo-pre/fake-project-repo-pre')

# Generated at 2022-06-21 10:50:24.289026
# Unit test for function find_template
def test_find_template():
    path = os.path.abspath('tests/fake-repo-pre')
    templated_path = os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    non_templated_path = os.path.abspath('tests/fake-repo-pre/cookiecutter')
    templated_bad_path = os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_n')
    non_templated_bad_path = os.path.abspath('tests/fake-repo-pre/cookiecutter')
    assert find_template(path) == templated_path

# Generated at 2022-06-21 10:50:30.921486
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test for error when there is no project template in repo
    test_repo = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'fake-repo-tmpl'
    )
    utils.work_in(test_repo)
    try:
        find_template(test_repo)
    except NonTemplatedInputDirException:
        assert True

    # Test for output when there is a project template in repo

# Generated at 2022-06-21 10:50:42.827270
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function.

    1. Mock the output from `os.listdir(repo_dir)`
    2. Test using a path with a project template
    3. Test using a path without a project template

    """
    import py.test

    import cookiecutter.find
    import cookiecutter.exceptions

    # Test using a path with a project template
    repo_dir = '/Users/audreyr/Proj/cookiecutter-pypackage'
    os.listdir = lambda _: [
        '.git',
        'pypackage',
        'README.rst',
        'hooks',
        'LICENSE',
        'tests',
        'soapbox.txt',
    ]

# Generated at 2022-06-21 10:50:48.188861
# Unit test for function find_template
def test_find_template():

    def file_mock(name):
        return MockObject(
            name=name,
            substitutable=('cookiecutter' in name and '{{' in name and '}}' in name))

    mock = MockObject(listdir=lambda: [file_mock('project_template')])

    project_template = find_template(mock)

    assert project_template == 'project_template'
    mock.listdir.assert_called_with()



# Generated at 2022-06-21 10:50:52.164326
# Unit test for function find_template
def test_find_template():
    """
    >>> find_template('/tmp/cookiecutter-j2-master/tests/test-tmpl/{{cookiecutter.project_slug}}')
    '/tmp/cookiecutter-j2-master/tests/test-tmpl/{{cookiecutter.project_slug}}'
    """
    pass



# Generated at 2022-06-21 10:50:58.848260
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """

    import pytest
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Mock out the repo_dir
    utils.find_template = lambda repo_dir: repo_dir

    # Test directory
    template_dir = 'tests/test-find-template'

    # Common inputs to find_template
    input_dir1 = os.path.join(template_dir, 't1')
    input_dir2 = os.path.join(template_dir, 't2')
    input_dir3 = os.path.join(template_dir, 't3')
    input_dir4 = os.path.join(template_dir, 't4')

# Generated at 2022-06-21 10:51:02.666148
# Unit test for function find_template
def test_find_template():
    project_template_dir = find_template('Python')
    assert os.path.isdir(project_template_dir)
    assert '{{cookiecutter.project_name}}' in os.listdir(project_template_dir)

# Generated at 2022-06-21 10:51:08.508777
# Unit test for function find_template
def test_find_template():
    repo_dir = "/Users/toddbranham/GitHub/cookiecutter/tests/fake-repo-tmpl"
    project_template = find_template(repo_dir)
    assert project_template == '/Users/toddbranham/GitHub/cookiecutter/tests/fake-repo-tmpl/fake-project-{{cookiecutter.repo_name}}'