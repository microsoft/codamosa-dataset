

# Generated at 2022-06-21 10:41:52.662998
# Unit test for function find_template
def test_find_template():
    """Verify expected behavior for function find_template."""
    results = find_template('/tmp')
    assert results == '/tmp/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:41:55.972519
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(os.getcwd(), "cookiecutter-audiowaveform")) == os.path.join(os.getcwd(), "cookiecutter-audiowaveform/{{cookiecutter.repo_name}}")

# Generated at 2022-06-21 10:42:03.416468
# Unit test for function find_template
def test_find_template():
    """Verify that templates are found in test repo."""
    input_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-repo-tmpl'
    ))
    output = find_template(input_dir)
    exp_output = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-repo-tmpl',
        'cookiecutter-pypackage'
    ))
    assert output == exp_output

# Generated at 2022-06-21 10:42:07.694559
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/projects/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:42:12.869805
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-find-template'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-find-template/cookiecutter-{{cookiecutter.repo_name}}'



# Generated at 2022-06-21 10:42:20.944626
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    import os
    import sys
    sys.path.append(os.path.abspath(os.path.dirname(__file__)))

    os.chdir(tempfile.mkdtemp())
    os.makedirs('cookiecutter-foobar')
    os.makedirs('{{cookiecutter.repo_name}}')

    template = find_template('.')

    assert template == '{{cookiecutter.repo_name}}'
    shutil.rmtree('cookiecutter-foobar')
    shutil.rmtree('{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:42:26.411507
# Unit test for function find_template
def test_find_template():
    """Make sure find_template correctly locates the project template."""

    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo')
    )

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-21 10:42:35.127871
# Unit test for function find_template
def test_find_template():
    """Verifies that find_template returns the correct path"""

    test_path = os.path.abspath(os.path.dirname(__file__))
    logger.debug('Test path is %s.', test_path)
    test_path = os.path.join(test_path, 'fake_repo_pre_gen')

    template_path = os.path.abspath(find_template(test_path))
    expected_path = os.path.join(test_path, '{{cookiecutter.repo_name}}')

    assert template_path == expected_path

# Generated at 2022-06-21 10:42:37.900757
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'test-find-template')
    assert 'simple', find_template(repo_dir)

# Generated at 2022-06-21 10:42:45.778648
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template`."""
    # Create a sample directory structure
    sample_dir = 'tests/files/fake-repo'
    os.makedirs(os.path.join(sample_dir, 'cookiecutter-{{foo}}', '{{bar}}'))
    os.makedirs(os.path.join(sample_dir, 'cookicutter-{{foo}}', '{{baz}}'))
    os.makedirs(os.path.join(sample_dir, 'cookiecutter-{{foo}}', '{{next}}'))

    assert find_template(sample_dir) == 'tests/files/fake-repo/cookiecutter-{{foo}}'

# Generated at 2022-06-21 10:42:56.293982
# Unit test for function find_template
def test_find_template():
    """Test for find_template()

    :returns None:
    """
    from tests.test_utils import TESTS_INPUT_TEMPLATE_DIR
    from tests.test_utils import TESTS_INPUT_TEMPLATE_PATH
    from tests.test_utils import TESTS_OUTPUT_DIR

    template_dir = TESTS_INPUT_TEMPLATE_DIR

    # Check if find_template returns the correct path for the project
    # template
    expected_output = TESTS_INPUT_TEMPLATE_PATH
    output = find_template(template_dir)


# Generated at 2022-06-21 10:43:03.792097
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter

    input_path = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    output_path = tempfile.mkdtemp()

    cookiecutter(
        input_path,
        checkout='v0.4.0',
        no_input=True,
        output_dir=output_path,
    )
    project_template = find_template(output_path)
    assert 'tests/files/{{cookiecutter.repo_name}}' in project_template
    shutil.rmtree(output_path)

# Generated at 2022-06-21 10:43:10.057197
# Unit test for function find_template
def test_find_template():
    """Tests the find_template function."""
    import shutil
    import tempfile
    import os

    template_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'templates'
    )

    repo_dir = tempfile.mkdtemp()
    shutil.copytree(template_dir, repo_dir)

    project_template = find_template(repo_dir)
    assert '{{cookiecutter.repo_name}}' in project_template
    shutil.rmtree(repo_dir)

    repo_dir = tempfile.mkdtemp()
    shutil.copytree(template_dir, repo_dir)

    # Move the template directory into another directory

# Generated at 2022-06-21 10:43:12.065570
# Unit test for function find_template
def test_find_template():
    assert 'fake-project', find_template('tests/test-input/fake-repo/')


# Generated at 2022-06-21 10:43:18.471139
# Unit test for function find_template
def test_find_template():
    """Test that find_template() finds the project template."""

    with temp_chdir():
        os.mkdir('./temp_project')
        os.makedirs('./temp_project/{{cookiecutter.repo_name}}')
        os.makedirs('./temp_project/other_dir')

        assert find_template('./temp_project') == './temp_project/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:23.376752
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    project_template = find_template(os.path.join('tests', 'fake-repo-pre'))
    utils.rmtree(os.path.join('tests', 'fake-repo-pre', 'fake-pre-project'))

# Generated at 2022-06-21 10:43:29.033421
# Unit test for function find_template
def test_find_template():
    """Test that the function ``find_template`` can find the template in the
    input directory."""
    # Setup
    repo_dir = 'tests/fake-repo-tmpl/'

    # Test
    project_template = find_template(repo_dir)

    # Verify
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:43:33.306946
# Unit test for function find_template
def test_find_template():
    """Ensure that find_template finds the right file."""
    repo_dir = 'tests/fake-repo'
    assert find_template(repo_dir) == 'tests/fake-repo/{{cookiecutter.repo_name}}'

    repo_dir = 'cookiecutter/tests/test-repo-pre/'
    assert find_template(repo_dir) == 'cookiecutter/tests/test-repo-pre/{{cookiecutter.repo_name}}'

    repo_dir = 'tests/fake-repo-no-templated-file'
    assert find_template(repo_dir) == None



# Generated at 2022-06-21 10:43:45.452462
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    import cookiecutter

    # Create a temp directory to be our repo_dir
    temp_repo_dir = tempfile.mkdtemp()

    # Clone the tests/test-repo into the temp repo_dir
    clone_from = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir = cookiecutter.repository.clone(clone_from, no_input=True, checkout=None)
    assert repo_dir == temp_repo_dir

    # Find the project template
    project_template = find_template(temp_repo_dir)

    # Delete our temp dir
    shutil.rmtree(temp_repo_dir)


# Generated at 2022-06-21 10:43:48.810776
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    expected = os.path.abspath(
        os.path.join('tests/fake-repo-pre/', '{{cookiecutter.repo_name}}')
    )
    found = find_template(repo_dir)
    assert expected == found


# Generated at 2022-06-21 10:43:56.012851
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/projects/cookiecutter/tests/files/fake-repo'
    template_dir = find_template(repo_dir)

    assert template_dir == '/home/audreyr/projects/cookiecutter/tests/files/fake-repo/cookiecutter-pypackage'

# Generated at 2022-06-21 10:43:59.081018
# Unit test for function find_template
def test_find_template():
    """
    Test if the find_template() function finds the right path.
    """
    try:
        find_template("/home/felix/templates/cookiecutter-pypackage")
    except NonTemplatedInputDirException:
        return False
    return True

# Generated at 2022-06-21 10:44:10.528955
# Unit test for function find_template
def test_find_template():
    
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    class MockRepo(object):
        def __init__(self, *args, **kwargs):
            self.repo_dir = os.path.normpath(os.path.abspath('fake-repo-tmpl'))
            self.clone_dir = os.path.normpath(os.path.abspath(os.curdir))
            os.makedirs(os.path.join(os.curdir, 'fake-repo-tmpl'))
            os.makedirs(os.path.join(self.repo_dir, 'fake-repo-tmpl-subdir'))

# Generated at 2022-06-21 10:44:18.717456
# Unit test for function find_template
def test_find_template():
    """Test function successfully finds template despite multiple directories."""

    import tempfile

    # Setup
    repo_dir = tempfile.mkdtemp()
    dirs_to_make = ['cookiecutter-{{cookiecutter.repo_name}}', 'my_test_dir']
    files_to_make = ['my_test_file.txt']

    for item in dirs_to_make:
        os.mkdir(os.path.join(repo_dir, item))
    for item in files_to_make:
        open(os.path.join(repo_dir, item), 'a').close()

    # Test
    project_template = find_template(repo_dir)


# Generated at 2022-06-21 10:44:30.471115
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the path to the project template"""
    import tempfile
    import shutil
    import textwrap

    repo_dir = tempfile.mkdtemp()
    file_contents = textwrap.dedent("""
        cookiecutter-cool
        cookiecutter_cool
        {{cookiecutter.repo_dir}}
        cookiecutter
    """)

    with open(os.path.join(repo_dir, 'file_list.txt'), 'w') as f:
        f.write(file_contents)

    expected = os.path.join(repo_dir, '{{cookiecutter.repo_dir}}')
    actual = find_template(repo_dir)
    assert expected == actual
    shutil.rmtree(repo_dir)

# Generated at 2022-06-21 10:44:36.623104
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function returns a valid template."""
    import pytest
    from cookiecutter.main import cookiecutter
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a non templated input directory
    test_data = '''
    name: "Cookiecutter Template"
    '''
    with open('template.yaml', 'w') as f:
        f.write(test_data)

    template = cookiecutter('.', no_input=True)

    # Verify that find_template raises an exception on a non templated input directory
    with pytest.raises(NonTemplatedInputDirException):
        find_template(template)

    os.remove('template.yaml')
    
    # Create a templated input directory

# Generated at 2022-06-21 10:44:48.589561
# Unit test for function find_template
def test_find_template():
    """Sanity check to make sure find_template is working properly."""
    from cookiecutter.prompt import read_user_yes_no
    from cookiecutter.main import cookiecutter

    dir_to_remove = 'fake-repo'

    # Clean up dir before exiting
    if os.path.isdir(dir_to_remove):
        read_user_yes_no('%s exists. Delete and re-clone? [y/N]: ' % dir_to_remove)
        shutil.rmtree(dir_to_remove)

    result = cookiecutter('tests/fake-repo-pre/', no_input=True)

    assert os.path.isdir(result)

    shutil.rmtree(dir_to_remove)


# Generated at 2022-06-21 10:44:52.336173
# Unit test for function find_template
def test_find_template():
    repo_dir = "path/to/some/dir/{{cookiecutter.repo_name}}-{{cookiecutter.repo_name_lower}}"
    assert find_template(repo_dir) == repo_dir

# Generated at 2022-06-21 10:44:56.699379
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile
    import unittest

    from cookiecutter import utils

    class TestFindTemplate(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.test_dir = os.path.join(
                self.tempdir,
                u'temp_repo',
                u'test_template'
            )
            os.mkdir(self.test_dir)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_find_template(self):
            """Verify find_template works for a normal situation."""

# Generated at 2022-06-21 10:45:09.393632
# Unit test for function find_template
def test_find_template():
    repo_dir = 'fake-repo/'
    os.makedirs('fake-repo/')
    open('fake-repo/cc_by_sa.txt', 'a').close()
    os.makedirs('fake-repo/{{cookiecutter.repo_name}}')
    open('fake-repo/{{cookiecutter.repo_name}}/README.rst', 'a').close()

    # The following is a case where the repo_dir has no {{cookiecutter}}
    # directories in it. It will raise an exception.
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        template_dir_exception_raised = True
    else:
        template_dir_exception_raised = False
    assert template_dir_exception

# Generated at 2022-06-21 10:45:26.602783
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template function is working as expected."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..', 'tests', 'files', 'test-repo'
        )
    )
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)
    assert 'test-cookiecutter-project' in project_template
    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-21 10:45:29.771079
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests/test-repo/fake-repo"
    assert find_template(repo_dir) == "tests/test-repo/fake-repo/{{cookiecutter.repo_name}}"


# Generated at 2022-06-21 10:45:39.748032
# Unit test for function find_template
def test_find_template():
    from .. import utils

    test_dir = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(test_dir, 'fake-repo-pre/')
    repo_dir = os.path.join(template_dir, 'fake-repo-pre', 'fake-repo-pre')

    p_dir = find_template(template_dir)
    print(p_dir)
    print(repo_dir)
    assert p_dir == repo_dir
    utils.rmtree(template_dir)


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:45:49.706461
# Unit test for function find_template
def test_find_template():
    """ Properly find the template in input_dir
    """
    from cookiecutter.main import get_template
    from cookiecutter import utils

    repo_dir = "test-repo"
    template_name = "{{cookiecutter.project_slug}}"
    input_dir = os.path.join(repo_dir,template_name)
    os.makedirs(input_dir)

    repo_dir = os.path.abspath(repo_dir)
    template_dirs = utils.workaround_and_ls_dir(repo_dir)
    template = get_template(template_dirs)

    assert input_dir == template
    utils.rmtree(repo_dir)



# Generated at 2022-06-21 10:45:51.752696
# Unit test for function find_template
def test_find_template():
    repo_dir = '/empty/dir'
    assert find_template(repo_dir) == True

# Generated at 2022-06-21 10:46:04.258167
# Unit test for function find_template
def test_find_template():
    """Test file search for the project template."""
    from integrationtests.resources import normal_repo
    from integrationtests.resources import normal_repo_clone
    from integrationtests.resources import normal_repo_two_templates_clone
    from integrationtests.resources import normal_repo_unicode_clone_dir

    repo_dir = normal_repo_clone
    os.listdir(repo_dir)
    template_dir = find_template(repo_dir)
    assert os.path.abspath(template_dir) == os.path.join(
        repo_dir,
        normal_repo['cookiecutter']['repo_dir'],
        normal_repo['cookiecutter']['project_template']
    )

    repo_dir = normal_repo_two_templates_clone


# Generated at 2022-06-21 10:46:11.771758
# Unit test for function find_template
def test_find_template():
    """Test for `find_template`."""
    repo_dir = 'fake_repo'
    os.mkdir(repo_dir)
    assert repo_dir in os.listdir('.')

    template_name = 'cookiecutter-pypackage'
    os.mkdir(os.path.join(repo_dir, template_name))
    assert template_name in os.listdir(repo_dir)

    assert repo_dir + '/' + template_name == find_template(repo_dir)

# Generated at 2022-06-21 10:46:23.629681
# Unit test for function find_template
def test_find_template():
    from cookiecutter import config
    from cookiecutter.prompt import read_user_yes_no

    # Create a fake project
    project = {
        '_template': 'https://github.com/audreyr/cookiecutter-pypackage.git',
        'repo_dir': 'fake_repo',
        'output_dir': 'fake_repo',
    }

    test_dir = ''
    os.mkdir(project['repo_dir'])
    os.chdir(project['repo_dir'])
    os.mkdir('cookiecutter-pypackage')
    os.mkdir('cookiecutter-pypackage/{{cookiecutter.repo_name}}')
    os.mkdir('foo-bar')
    os.mkdir('baz')

    config_

# Generated at 2022-06-21 10:46:24.935683
# Unit test for function find_template
def test_find_template():
    """Tests for function find_template"""
    assert find_template('/test') == None

# Generated at 2022-06-21 10:46:28.824754
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.path.dirname(__file__), 'myproject')
    os.chdir(test_dir)
    template =  find_template(test_dir)
    assert template == os.path.join(test_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-21 10:46:57.333048
# Unit test for function find_template
def test_find_template():
    from mock import patch, MagicMock

    repo_dir = '/path/to/repo'
    repo_dir_contents = ['foo', 'cookiecutter{{test}}', 'bar']
    os.listdir = MagicMock(return_value=repo_dir_contents)
    project_template = os.path.join(repo_dir, 'cookiecutter{{test}}')

    with patch(
        'cookiecutter.repository.os.path.join',
        MagicMock(return_value=project_template)
    ) as mock_path_join:
        assert find_template(repo_dir) == project_template
        assert mock_path_join.call_args[0][0] == repo_dir

# Generated at 2022-06-21 10:47:07.583167
# Unit test for function find_template
def test_find_template():
    """
    Tests of find_template method

    Mock a repo_dir and make sure that the correct project_template is found
    """
    # Set up mock cookiecutter repo
    from cookiecutter.vcs import vcs_checkout
    from tempfile import mkdtemp

    remote = 'gh:audreyr/cookiecutter-pypackage'
    repo_dir = mkdtemp()
    repo_dir = vcs_checkout(repo_dir, remote)

    from cookiecutter import find
    project_template = find.find_template(repo_dir)

    # Make sure it's the right project_template
    assert project_template.endswith('cookiecutter-pypackage/{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:47:15.743058
# Unit test for function find_template
def test_find_template():
    '''
    Create repo_dir and make sure find_template returns correct template name.
    '''
    repo_dir = 'repo_dir_test_find_template'
    os.mkdir(repo_dir)

    foo_dir = os.path.join(repo_dir, 'foo')
    os.mkdir(foo_dir)

    logger.debug('Searching for the project template.')
    project_template = find_template(repo_dir)
    assert project_template == foo_dir

test_find_template()

# Generated at 2022-06-21 10:47:17.426786
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""
    pass

# Generated at 2022-06-21 10:47:28.116809
# Unit test for function find_template
def test_find_template():
    # Create test repo
    os.system('mkdir new_repo')
    os.chdir('new_repo')
    os.system('mkdir cookiecutter-{{cookiecutter.name}}')
    os.system('mkdir cookiecutter-{{cookiecutter.name}}/subdir')

    # Test 1:
    result = find_template('.')
    assert result == 'cookiecutter-{{cookiecutter.name}}'

    # Test 2:
    result = find_template('cookiecutter-{{cookiecutter.name}}')
    assert result == 'subdir'

    # Clean up
    os.chdir('..')
    os.system('rm -r new_repo')

# Generated at 2022-06-21 10:47:39.954092
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function by creating a directory structure
    that looks like what we expect to get.
    """
    import shutil
    import tempfile

    # Create temporary directory
    repo_dir = tempfile.mkdtemp()

    # Create a dummy project template
    proj_tmpldir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(proj_tmpldir)
    testfile = os.path.join(proj_tmpldir, 'testfile.txt')
    with open(testfile, 'w') as f:
        f.write('foobar')

    # Create two dummy directories
    os.mkdir(os.path.join(repo_dir, 'other_dir'))

# Generated at 2022-06-21 10:47:48.118175
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_utils import TEST_COOKIE
    from cookiecutter.tests.test_utils import TEST_COOKIE_PY
    from cookiecutter.tests.test_utils import TEST_TEMPLATE
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_SRC
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_JSON
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_TXT
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_MD
    from cookiecutter.tests.test_utils import TEST_TEMPLATE_INI

    assert find_template(TEST_COOKIE) == TEST_TEMPLATE

# Generated at 2022-06-21 10:47:54.587442
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the template dir name."""
    from cookiecutter.utils import workdir
    from cookiecutter import repo
    test_repo_dir = repo.clone(
        'https://github.com/pydanny/cookiecutter-django.git',
        no_input=True
    )
    assert find_template(test_repo_dir) == '{{cookiecutter.repo_name}}'
    workdir.cleanup(test_repo_dir)

# Generated at 2022-06-21 10:47:59.333671
# Unit test for function find_template
def test_find_template():
    source_dir = os.getcwd()
    test_dir = os.path.join(source_dir, 'tests/test-template')
    template = find_template(test_dir)
    assert os.path.join(test_dir, '{{ cookiecutter.repo_name }}') == template

# Generated at 2022-06-21 10:48:09.094084
# Unit test for function find_template
def test_find_template():
    raise NotImplementedError

# def find_template_filter_files(repo_dir):
#     """Find files that contain jinja code.
#
#     This will only be needed in the future if we want to support templates
#     that do not extend from a base template.
#     """
#     filter_files = []
#     for root, dirs, files in os.walk(repo_dir):
#         for f in files:
#             filepath = os.path.join(root, f)
#             with open(filepath) as _:
#                 file_content = _.read()
#                 if '{{' in file_content and '}}' in file_content:
#                     filter_files.append(filepath)
#     return filter_files
#
# # unit test for find_template_filter

# Generated at 2022-06-21 10:49:05.896232
# Unit test for function find_template
def test_find_template():
    # Tests that function works with arbitrary file names
    def test_find_template_1():
        dir_contents = ['cookiecutter-default', 'cookiecutter-pypackage', 'cookiecutter-django', 'cookiecutter-audreyr']
        project_templates = ['cookiecutter-default', 'cookiecutter-pypackage', 'cookiecutter-django', 'cookiecutter-audreyr']
        for i, item in enumerate(dir_contents):
            template = None
            template = find_template(item)
            if template:
                assert os.path.join(item, template) == project_templates[i]

    # Tests that function works without the 'cookiecutter-' prefix

# Generated at 2022-06-21 10:49:10.808561
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_find import project_dir
    p_t = find_template(project_dir)
    assert os.path.exists(p_t)
    assert 'cookiecutter-pypackage' in p_t
    assert '{{' in p_t
    assert '}}' in p_t

# Generated at 2022-06-21 10:49:17.892542
# Unit test for function find_template
def test_find_template():
    """
    Make sure the find_template function works.
    """
    template_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(template_dir)
    expected_project_template = os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected_project_template

# Generated at 2022-06-21 10:49:18.350755
# Unit test for function find_template
def test_find_template():
    return find_template()

# Generated at 2022-06-21 10:49:27.802430
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the correct location for a project template.

    :returns msg: Pass/fail message for unittest.
    """

    test_dir = 'tests/test-find-template'
    temp_test_dir = os.path.join(
        test_dir, 'input', '{{cookiecutter.repo_name}}')
    temp_test_dir_2 = os.path.join(
        test_dir, 'input', '{{cookiecutter.repo_name}}-ex')

    try:
        find_template(test_dir)
        msg = "find_template() returned a project template when it shouldn't have."
        raise AssertionError(msg)
    except NonTemplatedInputDirException:
        pass

    assert find_template(temp_test_dir) == temp_

# Generated at 2022-06-21 10:49:30.914614
# Unit test for function find_template
def test_find_template():
    test_dir = 'tests/test-find-template'
    test_template = 'tests/test-find-template/{{project_name}}'

    assert find_template(test_dir) == test_template

# Generated at 2022-06-21 10:49:43.005365
# Unit test for function find_template
def test_find_template():
    # repo_dir0 = 'git@github.com:audreyr/cookiecutter-pypackage.git'
    repo_dir0 = './feature_requests/tests/test-repo/'
    expected_project_template0 = './feature_requests/tests/test-repo/{{cookiecutter.repo_name}}/'

    # repo_dir1 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir1 = './feature_requests/tests/test-repo/'
    expected_project_template1 = './feature_requests/tests/test-repo/{{cookiecutter.repo_name}}/'

    # repo_dir2 = 'git@github.com:audreyr/cookiecutter-pypack

# Generated at 2022-06-21 10:49:52.581146
# Unit test for function find_template
def test_find_template():
    # repo_dir = 'cookiecutter'
    # project_template = 'cookiecutter-pypackage'
    # test_dir = os.path.join(repo_dir, project_template)
    test_dir = './tests/test-find-repo/cookiecutter-pypackage'
    find_template(test_dir)
    # test_dir = os.path.join(repo_dir, project_template)
    test_dir = './tests/test-find-repo/cookiecutter-pypackage/{{cookiecutter.project_name}}'
    find_template(test_dir)


# Generated at 2022-06-21 10:49:54.216315
# Unit test for function find_template
def test_find_template():
    """Find the project template (first dir containing 'cookiecutter'), even
    if the repo has subdirectories.
    """
    pass



# Generated at 2022-06-21 10:50:00.057993
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.realpath(os.path.dirname(__file__)), 'test-cookiecutters')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')


# Generated at 2022-06-21 10:51:44.324626
# Unit test for function find_template
def test_find_template():
    """ Unit test for function find_template
    """
    assert find_template('./tests/fake-repo-pre/') == './tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('./tests/fake-repo-post/') == './tests/fake-repo-post/{{cookiecutter.repo_name}}'
    assert find_template('./tests/fake-repo-pre/') == './tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('./tests/fake-repo-no-delims/') == './tests/fake-repo-no-delims/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:51:50.504381
# Unit test for function find_template
def test_find_template():
    """Verify the directory returned by `find_template` is a template. """
    from cookiecutter.tests.test_find import make_git_repo
    from cookiecutter.find import find_template


    repo_dir, repo = make_git_repo(template=True)

    template = find_template(repo_dir)

    assert template.endswith('cookiecutter-pypackage')

