

# Generated at 2022-06-21 10:42:00.201404
# Unit test for function find_template
def test_find_template():
    """
    Tests that find_template returns the correct path to the template.
    """
    from mock import patch
    repo_dir = "/path/to/foo"
    os.listdir = lambda x: ["cookiecutterfoo-{{cookiecutter.project_slug}}",
                            "foo", "boo"]
    expected = "/path/to/foo/cookiecutterfoo-{{cookiecutter.project_slug}}"
    test_result = find_template(repo_dir)
    assert test_result == expected
    os.listdir = lambda x: ["cookiecutterbar-{{cookiecutter.project_slug}}",
                            "boo"]
    expected = "/path/to/foo/cookiecutterbar-{{cookiecutter.project_slug}}"

# Generated at 2022-06-21 10:42:01.064565
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/user/repos')

# Generated at 2022-06-21 10:42:06.776467
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns 'foo' for the following directory structure:

    /tmp/bar
    `-- cookiecutter-foo
        `-- {{cookiecutter.repo_name}}
    """
    from cookiecutter import utils
    from unittest import TestCase

    class TestFindTemplate(TestCase):

        def test_find_template(self):
            template = utils.find_template('tests/test-find-template')
            repo_name = os.path.basename(template)
            self.assertEqual(repo_name, 'foo')

    test = TestFindTemplate()
    test.test_find_template()

# Generated at 2022-06-21 10:42:18.811854
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import os
    import tempfile
    from cookiecutter.tests.test_find import is_dir
    from cookiecutter.tests.test_find import normalize

    template_name = 'my-template'
    template_dir = os.path.join('tests', 'files', 'project-template')

    # Create a fake repo_dir. We don't need to fill it with anything
    # because we only care what it contains, not the contents.
    repo_dir = tempfile.mkdtemp()

    template_dir_name = os.path.join(repo_dir, template_name)
    os.makedirs(template_dir_name)

    for item in os.listdir(template_dir):
        full_path = os.path.join(template_dir, item)


# Generated at 2022-06-21 10:42:26.231934
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        '..',
        'tests',
        'fake-repo-pre/',
    )

    try:
        project_template = find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert 1 == 2

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:42:30.608852
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    repo_dir = '{{cookiecutter.project_name}}'
    project_template = find_template(repo_dir)
    assert project_template == '{{cookiecutter.project_name}}'



# Generated at 2022-06-21 10:42:36.068436
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    assert find_template('C:\\Users\\J\\Desktop\\cookiecutter-pypackage') == 'C:\\Users\\J\\Desktop\\cookiecutter-pypackage\\{{cookiecutter.repo_name}}'
    print("test_find_template works correctly")

test_find_template()

# Generated at 2022-06-21 10:42:38.570058
# Unit test for function find_template
def test_find_template():
    """Tests for `find_template` function."""
    project_template = find_template('/Users/audreyr/projects/cookiecutter-pypackage')
    assert 'cookiecutter-pypackage/{{{cookiecutter.project_slug}}}' == project_template


# Generated at 2022-06-21 10:42:43.046033
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    project_template = 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    assert find_template(repo_dir) == project_template

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-21 10:42:43.564061
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:42:50.828342
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/cookiecutter-pypackage') == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
# Expected outcome
# The project template appears to be /Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}

# Generated at 2022-06-21 10:42:57.349133
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    cwd = os.path.dirname(os.path.abspath(__file__))
    test_repo = os.path.join(cwd, '../tests/test-repo/')

    assert find_template(test_repo) == os.path.join(test_repo, '{{ cookiecutter.repo_name }}')

# Generated at 2022-06-21 10:43:01.657018
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter

    template_dir = 'tests/test-find-template'
    output_dir = 'tests/fake-output'

    cookiecutter(template_dir, output_dir)

    assert find_template(template_dir) == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:05.238730
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import os
    os.makedirs('hello/{{cookiecutter.repo_name}}')
    try:
        assert find_template('hello') == ('hello/{{cookiecutter.repo_name}}')
    finally:
        import shutil
        shutil.rmtree('hello')

# Generated at 2022-06-21 10:43:12.523844
# Unit test for function find_template
def test_find_template():
    """Test the find_template function"""
    # Setup
    repo_dir = os.path.abspath(os.path.dirname(__file__))

    # Test
    project_template = find_template(repo_dir)

    # Verifications
    assert os.path.isdir(project_template)
    assert 'cookiecutter' in os.path.basename(project_template)
    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-21 10:43:17.636465
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.utils import make_sure_path_exists

    from .compat import patch, Mock

    repo_dir = '/Users/audreyr/Documents/Development/cookiecutter-pypackage'

    with patch('cookiecutter.prompt.read_user_choice') as mock_read_user_choice:
        mock_read_user_choice.return_value = 'y'
        test_dir = '/tmp/test_dir'
        make_sure_path_exists(test_dir)
        shutil.copytree(repo_dir, test_dir)
        assert find_template(test_dir) == os.path.join(test_dir, '{{cookiecutter.repo_name}}')

        mock_read_user_choice.return_value = 'n'
       

# Generated at 2022-06-21 10:43:18.270099
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-21 10:43:18.846264
# Unit test for function find_template
def test_find_template():

    pass

# Generated at 2022-06-21 10:43:23.325460
# Unit test for function find_template
def test_find_template():
    path = 'cookiecutter-pypackage'
    assert find_template(path) == os.path.join(os.getcwd(), path)
    logger.debug(os.path.join(os.getcwd(), path))

# Generated at 2022-06-21 10:43:26.274004
# Unit test for function find_template
def test_find_template():
    dir = '/Users/audreyr/code/cookiecutter-pypackage'
    project_template = find_template(dir)
    print(project_template)



# Generated at 2022-06-21 10:43:35.598867
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    import tempfile
    import cookiecutter

    if not os.path.exists(cookiecutter.USER_CONFIG_PATH):
        utils.make_sure_path_exists(cookiecutter.USER_CONFIG_PATH)

    tmpdir = tempfile.mkdtemp()
    testdir = os.path.join(tmpdir, 'mock_repo')
    os.mkdir(testdir)

    os.mkdir(os.path.join(testdir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(testdir, '{{cookiecutter.repo_name}}-master'))

# Generated at 2022-06-21 10:43:45.273838
# Unit test for function find_template
def test_find_template():
    from cookiecutter.repository import clean_repo_dir
    from cookiecutter.utils import rmtree

    repo_dir = 'tests/test-repo-pre/'
    project_dir = find_template(repo_dir)
    project_dir = clean_repo_dir(project_dir)
    rmtree(project_dir)

    repo_dir = 'tests/test-repo-pre-no-delims/'
    project_dir = find_template(repo_dir)
    project_dir = clean_repo_dir(project_dir)
    rmtree(project_dir)

# Generated at 2022-06-21 10:43:52.848021
# Unit test for function find_template
def test_find_template():
    """
    Tests the `find_template` function.
    """
    import cookiecutter.find as find

    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-hooks-templates')

    project_template = find.find_template(repo_dir)

    assert project_template == '/home/audreyr/code/cookiecutter/tests/test-hooks-templates/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:43:58.537434
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    test_input_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'fake-repo-pre',
    )
    assert find_template(test_input_dir) == os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'fake-repo-pre',
        '{{cookiecutter.repo_name}}',
    )

# Generated at 2022-06-21 10:44:09.940214
# Unit test for function find_template
def test_find_template():
    """
    Tests to make sure that find_template is working as expected.
    """
    if not os.path.exists('test/fake-repo-pre/fake-repo'):
        os.makedirs('test/fake-repo-pre/fake-repo')
    if not os.path.exists('test/fake-repo-pre/cookiecutter'):
        os.makedirs('test/fake-repo-pre/cookiecutter')
    with open('test/fake-repo-pre/cookiecutter/blah.txt', 'w') as f:
        f.write("blah")
    with open('test/fake-repo-pre/fake-repo/blah.txt', 'w') as f:
        f.write("blah")

# Generated at 2022-06-21 10:44:14.016055
# Unit test for function find_template
def test_find_template():
    os.environ["REPO_DIR"] = "tests/fake-repo"
    repo_dir = os.environ["REPO_DIR"]
    expected_output = "tests/fake-repo/{{cookiecutter.repo_name}}"
    find_template(repo_dir) == expected_output

# Generated at 2022-06-21 10:44:21.247593
# Unit test for function find_template
def test_find_template():
    """ Verify that a Child directory named cookiecutter_hackernews exists. """
    assert find_template('/Users/jameskirk/Dropbox/Cookiecutter_projects/cookiecutter-hackernews') == '/Users/jameskirk/Dropbox/Cookiecutter_projects/cookiecutter-hackernews/cookiecutter_hackernews'
    print("Unit test passed")

if __name__ == 'main':
    test_find_template()

# Generated at 2022-06-21 10:44:31.735393
# Unit test for function find_template
def test_find_template():
    '''
    Test function find_template()
    '''
    def mock_listdir():
        return ['cookiecutter-example', 'not-cookiecutter', 'cookiecutter-example-{{cookiecutter.template}}']

    def mock_isfile(x):
        return False

    def mock_isdir(x):
        return True

    # Mock methods os.path.isdir and os.listdir in order to test the function find_template
    def mock_path_is_dir(x):
        return True

    def mock_path_is_file(x):
        return False

    mock_isdir_path = os.path.isdir
    os.path.isdir = mock_path_is_dir
    mock_isfile_path = os.path.isfile
    os.path.isfile = mock_

# Generated at 2022-06-21 10:44:32.525542
# Unit test for function find_template
def test_find_template():
    assert 1 == 1
    
    

# Generated at 2022-06-21 10:44:34.721702
# Unit test for function find_template
def test_find_template():
    assert find_template('C:\project') == 'C:\project\cookiecutter-{{cookiecutter.project_name}}'

# End unit test

# Generated at 2022-06-21 10:44:47.259015
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    import pytest
    from pytest import raises

    with pytest.raises(NonTemplatedInputDirException):
        find_template()

    find_template(repo_dir=os.path.join(
        os.path.dirname(__file__),
        'tests/test-repo/plain-repo'
    ))

    with pytest.raises(NonTemplatedInputDirException):
        find_template(repo_dir=os.path.join(
            os.path.dirname(__file__),
            'tests/test-repo/fake-repo'
        ))

# Generated at 2022-06-21 10:44:55.499360
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir='tests/fake-repo-pre/') == \
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir='tests/fake-repo-post/') == \
        'tests/fake-repo-post/my-fake-project'
    assert find_template(repo_dir='tests/fake-repo-cli/') == \
        'tests/fake-repo-cli/{{cookiecutter.repo_name}}'

# Generated at 2022-06-21 10:44:59.353606
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-find-template/{{cookiecutter.repo_name}}') == 'tests/test-find-template/{{cookiecutter.repo_name}}/{{cookiecutter.project_name}}'

# Generated at 2022-06-21 10:45:03.902764
# Unit test for function find_template
def test_find_template():
    test_path = 'tests/fake-repo-pre/'
    assert find_template(test_path) == 'tests/fake-repo-pre/cookiecutter-pypackage{{cookiecutter.project_name}}'

# Generated at 2022-06-21 10:45:08.224602
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fixtures/fake-repo'
    project_template = 'tests/fixtures/fake-repo/{{cookiecutter.repo_name}}'

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-21 10:45:10.209468
# Unit test for function find_template
def test_find_template():
    """
    This function is not tested at the moment.
    """
    pass

# Generated at 2022-06-21 10:45:15.860452
# Unit test for function find_template
def test_find_template():
    os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test-template')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:45:17.334541
# Unit test for function find_template
def test_find_template():
    assert find_template("/home/foo/bar") != None


# Generated at 2022-06-21 10:45:23.333886
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo')
    )
    project_template = find_template(repo_dir)
    assert repo_dir in project_template
    assert 'cookiecutter-pypackage' in project_template



# Generated at 2022-06-21 10:45:31.355596
# Unit test for function find_template
def test_find_template():
    """Verify find_template() finds a templated directory in repo.

    When given a repo directory, find a directory containing the variables
    {{cookiecutter.var}}.
    """
    # Create a testing directory
    test_dir = "tests/files/find_template"
    test_contents = os.listdir(test_dir)
    test_contents.sort()

    project_template = find_template(test_dir)

    # Verify a templated directory is found
    assert 'my-fake-project' in project_template
    assert '{{cookiecutter.project_name}}' in project_template