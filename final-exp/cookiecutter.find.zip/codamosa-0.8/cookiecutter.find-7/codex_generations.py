

# Generated at 2022-06-11 20:11:38.844740
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter import config

    repo_dir = os.path.join(config.USER_CACHE_DIRECTORY, 'tests/fake-repo-tmpl')
    project_template = utils.find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:11:46.757542
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template function finds the project template."""
    template_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'fake-repo',
    )

    project_template = find_template(template_dir)

    expected_project_template = os.path.join(
        template_dir,
        'cookiecutter-pypackage',
        '{{cookiecutter.repo_name}}'
    )

    assert project_template == expected_project_template

# Generated at 2022-06-11 20:11:52.924192
# Unit test for function find_template
def test_find_template():
    """Test finding a template in a project."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                            '../tests/fake-repo/'))
    template_path = find_template(repo_dir)
    equal(
        template_path,
        os.path.abspath(os.path.join(os.path.dirname(__file__),
                                     '../tests/fake-repo/{{cookiecutter.repo_name}}/'))
    )

# Generated at 2022-06-11 20:11:55.127688
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir="~/Desktop/cookiecutter-pypackage") == 1


# Generated at 2022-06-11 20:11:59.570063
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        '..',
        'tests',
        'fake-repo'
    )
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == find_template(repo_dir)

# Generated at 2022-06-11 20:12:02.694361
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template`."""
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:09.712237
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), '..', 'tests', 'test-input',
            'log-in-gitlab-or-github'
        )
    )
    assert find_template(test_repo_dir) == os.path.abspath(
        os.path.join(
            test_repo_dir, '{{cookiecutter.repo_name}}'
        )
    )

# Generated at 2022-06-11 20:12:14.225339
# Unit test for function find_template
def test_find_template():
    repo_dir = "/root/Documents/cookiecutter-pypackage"
    project_template = find_template(repo_dir)
    expected = '/root/Documents/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert project_template == expected, 'incorrect project template'

# Generated at 2022-06-11 20:12:21.168869
# Unit test for function find_template
def test_find_template():
    from cookiecutter import repo

    tests = [
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        'https://github.com/augmentedinteractive/cookiecutter-django.git',
        'https://github.com/pydanny/cookiecutter-django.git',
        'https://github.com/pydanny/cookiecutter-django-crud.git',
        'https://github.com/ionelmc/cookiecutter-pylibrary.git',
    ]

    for repo_dir in tests:
        repo_dir = repo.generate_files(repo_dir)
        project_template = find_template(repo_dir)
        assert project_template
        logger.info('%s is the template directory', project_template)


# Generated at 2022-06-11 20:12:27.183432
# Unit test for function find_template
def test_find_template():
    test_dict = {
        'input_repo_dir': 'input_repo_dir',
        'expected_result': 'input_repo_dir/cookiecutter-{{cookiecutter.repo_name}}',
        'assert': 'equal'
    }

    test_result = find_template(test_dict['input_repo_dir'])

    assert test_result == test_dict['expected_result']

# Generated at 2022-06-11 20:12:31.313708
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/coding/cookiecutter-pypackage'
    find_template(repo_dir)

# Generated at 2022-06-11 20:12:34.458282
# Unit test for function find_template
def test_find_template():
    project_template = find_template("http://github.com/joegreen0991/cookiecutter-djangopackage")
    assert project_template == "{{ cookiecutter.repo_name }}"

# Generated at 2022-06-11 20:12:35.715854
# Unit test for function find_template
def test_find_template():
    """Test that find_template() works correctly."""
    pass

# Generated at 2022-06-11 20:12:36.579047
# Unit test for function find_template
def test_find_template():
    # FIXME: Add unit test
    pass

# Generated at 2022-06-11 20:12:41.234735
# Unit test for function find_template
def test_find_template():
    """Ensure the correct path is returned for the project template.

    Django 1.8.11
    cookiecutter_django_template/
    ├── cookiecutter.json
    └── {{cookiecutter.project_slug}}/
    """
    repo_dir = '/Users/ronny/Documents/GitHub/cookiecutter-django'
    project_dir = find_template(repo_dir)
    assert project_dir == os.path.join(repo_dir, '{{cookiecutter.project_slug}}')


# Generated at 2022-06-11 20:12:42.509399
# Unit test for function find_template
def test_find_template():
    """Test the function find_template."""
    pass

# Generated at 2022-06-11 20:12:43.518066
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-11 20:12:48.693363
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct directory."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'tests', 'fake-repo-tmpl')
    )
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == expected

# Generated at 2022-06-11 20:12:59.622313
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template


# Generated at 2022-06-11 20:13:00.342260
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:02.341336
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:05.540004
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/Audrey/projects/cookiecutter-pypackage') == '/Users/Audrey/projects/cookiecutter-pypackage/{{ cookiecutter.repo_name }}'

# Generated at 2022-06-11 20:13:10.138365
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/code/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:14.549698
# Unit test for function find_template
def test_find_template():
    """assert that the project template has the substring 'cookiecutter'."""
    repo_dir = "/home/vanessa/projects/cookiecutter-data-science/tests/fake-repo-pre"
    project_template = find_template(repo_dir)
    assert 'cookiecutter' in project_template


# Generated at 2022-06-11 20:13:18.454057
# Unit test for function find_template
def test_find_template():
    # Mock the contents of a repository
    repo_dir = '/home/audreyr/foo'
    repo_dir_contents = ['bar', 'baz', 'cookiecutter-{{cookiecutter.project_name}}', 'qux']

    project_dir = find_template(repo_dir, repo_dir_contents)

    assert project_dir == 'cookiecutter-{{cookiecutter.project_name}}'

# Generated at 2022-06-11 20:13:29.269687
# Unit test for function find_template
def test_find_template():
    from .compat import TemporaryDirectory
    from .compat import mock
    from .compat import unittest

    class TestFindTemplate(unittest.TestCase):

        def test_find_template(self):
            with TemporaryDirectory() as repo_dir:
                os.mkdir(os.path.join(repo_dir, 'project_template'))
                self.assertEqual(
                    os.path.join(repo_dir, 'project_template'),
                    find_template(repo_dir)
                )


# Generated at 2022-06-11 20:13:38.612610
# Unit test for function find_template
def test_find_template():
    """Verify function for finding project template in repo."""
    from cookiecutter import repo
    from cookiecutter import utils
    from cookiecutter.tests import fake_repo

    tmp_repo_path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), '..', 'fake-repo'
    )
    repo.clone(fake_repo.DUMMY_REPO_URL, tmp_repo_path)
    template_dir = utils.workin(tmp_repo_path, find_template)
    assert os.path.exists(template_dir)
    assert template_dir == tmp_repo_path
    assert '{{cookiecutter.repo_name}}' in template_dir

# Generated at 2022-06-11 20:13:43.831786
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), '..', 'tests', 'fake-repo'
        )
    )

    project_template = find_template(repo_dir)
    assert project_template.endswith('tests/fake-repo/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:13:44.322859
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:54.307598
# Unit test for function find_template
def test_find_template():
    """Quick and dirty unit test for function find_template."""
    from tempfile import mkdtemp
    import shutil
    from cookiecutter.main import cookiecutter

    cwd = os.getcwd()
    tmp_dir = mkdtemp()

    repo_dir = cookiecutter('tests/fake-repo-tmpl')
    os.chdir(tmp_dir)
    project_dir = os.path.join(repo_dir, 'fake-project')
    find_template(project_dir)
    os.chdir(cwd)
    # cleanup
    shutil.rmtree(repo_dir)
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-11 20:13:57.717164
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:59.980282
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/foo/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:14:04.189383
# Unit test for function find_template
def test_find_template():
    actual = find_template('/home/audreyr/cookiecutter-pypackage')
    expected = '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert actual == expected, 'Expected "{0}", got "{1}"'.format(
        expected, actual)



# Generated at 2022-06-11 20:14:07.203421
# Unit test for function find_template
def test_find_template():
    """
    Run a simple test to determine if find_template is working
    """
    assert find_template('.') == 'cookiecutter-mozilla/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:12.637481
# Unit test for function find_template
def test_find_template():
    """Ensures find_template finds the correct project template."""
    from cookiecutter import tests
    with tests.work_in(tests.TEST_REPO_DIR):
        project_template = find_template('./tests/test-repo')
        assert os.path.isfile(project_template)

# Generated at 2022-06-11 20:14:14.259217
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:15.127956
# Unit test for function find_template
def test_find_template():
    cookiecutter_find_template()

# Generated at 2022-06-11 20:14:18.428891
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl/'
    path = find_template(repo_dir)
    assert path == 'tests/fake-repo-tmpl/{{cookiecutter.project_name}}/'

# Generated at 2022-06-11 20:14:25.192684
# Unit test for function find_template
def test_find_template():
    """Find the project template in a new git checkout."""
    import tempfile
    from cookiecutter.vcs import clone

    repo_dir = tempfile.mkdtemp()
    repo = clone(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        checkout='0.1.0',
        no_input=True,
        clone_to_dir=repo_dir
    )
    assert repo.project_dir.endswith('cookiecutter-pypackage/{{cookiecutter.repo_name}}')



# Generated at 2022-06-11 20:14:32.351023
# Unit test for function find_template
def test_find_template():
    repo_dir = "/var/folders/8k/y6xvh6d942n3b2txzjwd6vbw0000gn/T/tmppBUfEP"
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, "{{cookiecutter.repo_name}}")
    assert project_template == expected

# Generated at 2022-06-11 20:14:36.163960
# Unit test for function find_template
def test_find_template():
    find_template('~/beeb')

# Generated at 2022-06-11 20:14:42.894707
# Unit test for function find_template
def test_find_template():
    """Test to make sure we can locate the template correctly."""

    # This denotes the location of the template
    test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo'
    )
    result = find_template(test_dir)

    assert result == os.path.join(test_dir, 'fake-project-{{cookiecutter.repo}}')

# Generated at 2022-06-11 20:14:50.429295
# Unit test for function find_template
def test_find_template():
    import tempfile

    with tempfile.NamedTemporaryFile() as file1:
        with tempfile.NamedTemporaryFile() as file2:
            file1.write('cookiecutter foo {{bar}}')
            file2.write('bar baz')
        repo_dir = tempfile.mkdtemp()
        os.path.join(repo_dir, file1.name)
        os.path.join(repo_dir, file2.name)
        find_template(repo_dir)

# Generated at 2022-06-11 20:14:52.054290
# Unit test for function find_template
def test_find_template():
    find_template('/home/shah/programming/python_projects/cookiecutter-pypackage/tests')

# Generated at 2022-06-11 20:14:57.313408
# Unit test for function find_template
def test_find_template():
    expected_result = '{{cookiecutter.repo_name}} (1) (1).zip'
    result = find_template('/Users/ITO/Documents/Python/PyCharmProjects/cookiecutter/tests/test-repos/')
    assert(result == expected_result)

    #expected_result = 'cookiecutter-pypackage'


# Generated at 2022-06-11 20:15:00.098351
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-find-template') == \
        os.path.abspath('tests/test-find-template/cookiecutter-pypackage')

# Generated at 2022-06-11 20:15:00.638553
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:15:09.166566
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    from cookiecutter.main import cookiecutter

    # Given a fake repo that has a templated directory
    template = os.path.join(os.path.dirname(__file__),
                            '..', 'fake-repo-tmpl', '{{cookiecutter.repo_name}}')
    logging.debug('template: %s', template)

    # When I pass that directory to cookiecutter()
    context = cookiecutter(
        template,
        no_input=True,
        overwrite_if_exists=True,
        output_dir='.',
    )

    # Then the proper directory will be identified as the project template
    logging.debug(context)


# Generated at 2022-06-11 20:15:16.098381
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage/tests/fake-repo-tmpl'
    project_template = find_template(repo_dir)
    expected_project_template = '/Users/audreyr/cookiecutter-py/tests/fake-repo-tmpl/cookiecutter-{{cookiecutter.repo_name}}'
    assert expected_project_template == project_template



# Generated at 2022-06-11 20:15:25.861452
# Unit test for function find_template
def test_find_template():
    """
    Integration test
    """

    import shutil
    import tempfile

    # Create a fake repo with a real project template in a sub-dir.
    fake_repo_dir = tempfile.mkdtemp()
    real_template_dir = tempfile.mkdtemp()
    os.rmdir(real_template_dir)
    shutil.copytree(
        os.path.join(os.path.dirname(__file__), 'fake-repo-tmpl'),
        fake_repo_dir
    )

    # Move the template dir out of the repo dir
    os.rename(
        os.path.join(fake_repo_dir, 'fake-project-tmpl'),
        real_template_dir
    )

    # Call the function under test.
    template_dir = find_template

# Generated at 2022-06-11 20:15:38.834247
# Unit test for function find_template
def test_find_template():
    # create a test dir
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    # create a template dir in the test dir
    templ_dir = os.path.join(tmp_dir,'{{cookiecutter.project_name}}')
    os.mkdir(templ_dir)
    assert find_template(tmp_dir) == templ_dir
    # remove test dir and content
    import shutil
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-11 20:15:43.546119
# Unit test for function find_template
def test_find_template():
    """Verify correct template is returned for supplied repo_dir"""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test-tmpl')
    template = find_template(repo_dir)

    assert os.path.basename(template) == '{{cookiecutter.repo_name}}', \
        'Template is not the expected one.'

# Generated at 2022-06-11 20:15:53.866086
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.prompt import read_user_variable

    template = 'tests/test-data/fake-repo-tmpl'
    template_name = 'fake-project'

    repo_dir = os.path.join(
        DEFAULT_CONFIG['replay_dir'],
        read_user_variable(template, template_name, DEFAULT_CONFIG),
        template_name,
    )
    project_template = find_template(repo_dir)

    assert project_template.endswith(
        'fake-repo-tmpl/tests/test-data/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    )


# Generated at 2022-06-11 20:15:54.342997
# Unit test for function find_template
def test_find_template():
    find_template()

# Generated at 2022-06-11 20:16:03.590576
# Unit test for function find_template
def test_find_template():
    #Setting up a dummy repo
    repo_dir = os.path.join(os.path.curdir, 'test-repo')
    os.mkdir(repo_dir)
    os.mkdir(os.path.join(repo_dir, 'foobar'))
    with open(os.path.join(repo_dir, 'foobar', 'readme.md'), 'w') as f:
        f.write("Some test file\n")
    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write("{}\n")
    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write("{}\n")


# Generated at 2022-06-11 20:16:12.311769
# Unit test for function find_template
def test_find_template():
    import tempfile

    repo_dir = tempfile.mkdtemp(prefix='cookiecutter-find-template-test')
    project_template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(project_template_dir)

    # Test for success
    assert project_template_dir == find_template(repo_dir)

    tempfile.tempdir = None

    os.remove(project_template_dir)
    os.removedirs(repo_dir)


# Generated at 2022-06-11 20:16:16.974978
# Unit test for function find_template
def test_find_template():
    """Simple unit test for the find_template function."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, u'{{cookiecutter.repo_name}}')
    assert project_template == expected

# Generated at 2022-06-11 20:16:19.436331
# Unit test for function find_template
def test_find_template():
    repo_dir = 'project_template'
    template = find_template(repo_dir)
    assert(template == 'project_template/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:16:20.029641
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:16:27.978985
# Unit test for function find_template
def test_find_template():
    """Properly finds template"""
    from cookiecutter.main import cookiecutter

    # Given: A dummy Cookiecutter template
    template = 'tests/test-cookiecutters/fake-repo-pre/'

    # When: I create a project from the template
    output_dir = cookiecutter(
        template,
        no_input=True,
        overwrite_if_exists=True
    )

    # Then: The output directory contains the rendered template
    expected_dir = os.path.join(os.path.dirname(__file__), 'expected')
    assert output_dir == expected_dir


# Generated at 2022-06-11 20:16:45.192031
# Unit test for function find_template
def test_find_template():
    """Test for find_template function."""
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)),
                            'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:16:48.145419
# Unit test for function find_template
def test_find_template():
    assert find_template('/var/www/cookiecutter') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:51.029643
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/vagrant/code/cookiecutter-pypackage') == '/home/vagrant/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:56.345225
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    assert find_template('/Users/michaelherman/projects/bitbucket/cookiecutter-pypackage') == '/Users/michaelherman/projects/bitbucket/cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:16:59.065429
# Unit test for function find_template

# Generated at 2022-06-11 20:17:06.372452
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find the project template."""
    from cookiecutter import main

    output_dir = 'tests/test-output/{{cookiecutter.repo_name}}'
    if os.path.isdir(output_dir):
        shutil.rmtree(output_dir)

    main.cookiecutter('tests/test-repo/', no_input=True)
    assert os.path.isdir(output_dir)



# Generated at 2022-06-11 20:17:09.863330
# Unit test for function find_template
def test_find_template():
    template = find_template(repo_dir='tests/fake-repo-pre/')
    assert template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:17:14.237308
# Unit test for function find_template
def test_find_template():
    """
    Tests the find_template function against a template directory
    """
    repo_dir = "./tests/test-input/test-repo"
    assert find_template(repo_dir) == "./tests/test-input/test-repo/{{cookiecutter.repo_name}}"

test_find_template()


# Generated at 2022-06-11 20:17:14.832804
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:17:16.239726
# Unit test for function find_template

# Generated at 2022-06-11 20:17:48.345119
# Unit test for function find_template
def test_find_template():
    """ Test that a NonTemplatedInputDirException is raised if no template is found. """
    import shutil
    import tempfile
    import os
    from cookiecutter.exceptions import NonTemplatedInputDirException
    tmp_dir = tempfile.mkdtemp()

    try:
        _ = find_template(tmp_dir)
    except NonTemplatedInputDirException as e:
        assert(e.message == "No template found in {0}. You can use `cookiecutter` command line to create one.".format(tmp_dir))
    finally:
        shutil.rmtree(tmp_dir)


# Generated at 2022-06-11 20:17:53.072242
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    sample_dir = utils.find_project_templates() / 'zipper'
    project_template = find_template(str(sample_dir))
    assert project_template == str(sample_dir / '{{cookiecutter.project_slug}}')


# Generated at 2022-06-11 20:17:57.429643
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template"""
    os.chdir('tests/functional/fake-repo-tmpl')
    repo_dir = os.getcwd()
    assert(find_template(repo_dir) == 'tests/functional/fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:17:59.957074
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    result = find_template('tests/test-data/fake-repo')
    assert result == 'tests/test-data/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:18:09.933560
# Unit test for function find_template
def test_find_template():
    '''Test the find_template function.'''
    import tempfile
    import shutil
    import os.path

    class TestException(Exception):
        pass

    TEST_DIR = os.path.join(tempfile.mkdtemp(), 'cookiecutter-test')


# Generated at 2022-06-11 20:18:17.472195
# Unit test for function find_template
def test_find_template():
    """
    Checks that the right template is found
    """

# Generated at 2022-06-11 20:18:23.975365
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template()."""
    import pytest

    repo_dir = 'tests/test-find-repo'
    expected = 'tests/test-find-repo/{{cookiecutter.repo_name}}'

    repo_dir_contents = os.listdir(repo_dir)
    print(repo_dir_contents)

    project_template = find_template(repo_dir)

    assert project_template == expected

# Generated at 2022-06-11 20:18:26.356140
# Unit test for function find_template
def test_find_template():
    """Verify find_template works correctly."""
    assert find_template('tests/test-input/fake-repo-tmpl') == 'tests/test-input/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:18:28.654443
# Unit test for function find_template
def test_find_template():
    assert find_template('examples/tests/fake-repo-pre/') == 'examples/tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:18:38.001741
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    test1 = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo-1'
    )
    assert find_template(test1) == os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo-1',
        'fake-project-template',
    )

    test2 = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-find-template',
        'fake-repo-2'
    )
    assert find_template

# Generated at 2022-06-11 20:19:42.883575
# Unit test for function find_template
def test_find_template():
    """Test find_template function.

    :returns: None
    """
    for line in test_find_template.__doc__.splitlines():
        print(line)

    import os
    import shutil
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    source = 'tests/test-find-template'
    target = 'tests/test-repo'

    try:
        utils.copy_files_to_folder(source, target)
        assert find_template(target) == os.path.join(target, 'templated-project')
        print('find_template works on initial state of repository')
    except NonTemplatedInputDirException:
        assert False


# Generated at 2022-06-11 20:19:49.385319
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template`."""
    import tempfile
    import shutil
    import cookiecutter.main

    repo_dir = tempfile.mkdtemp()
    logger.debug('repo_dir is %s.', repo_dir)

    cookiecutter_dict = {
        'repo_name': '{{cookiecutter.repo_name}}',
        'project_name': '{{cookiecutter.project_name}}',
        'author_name': '{{cookiecutter.author_name}}',
    }

    context_file = tempfile.NamedTemporaryFile(delete=False)
    context_file.write('{}'.format(cookiecutter_dict))
    context_file.close()
    logger.debug('context_file is %s.', context_file.name)

    cookie

# Generated at 2022-06-11 20:19:58.626645
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.
    """
    repo_dir_contents = os.listdir('/Users/anatoly/git/tst_cookiecutter/cookiecutter-pypackage')

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join('/Users/anatoly/git/tst_cookiecutter/cookiecutter-pypackage', project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template
    else:
        raise NonTemplatedInput

# Generated at 2022-06-11 20:20:07.133646
# Unit test for function find_template
def test_find_template():
    """Finds the directory which is the project template."""
    from tests.test_utils import remove_repo_dir, isolate_repo_dir
    from tests.test_utils import keep_all_dirs_after_clone
    from tests.test_utils import clone_from
    from tests.test_utils import COOKIECUTTER_REPO_DIR
    from tests.test_utils import REPO_DIR

    repo_dir = clone_from(keep_all_dirs_after_clone, COOKIECUTTER_REPO_DIR, REPO_DIR)

    project_template_dir = find_template(repo_dir)

    assert project_template_dir == 'tests/input/cookiecutter-pypackage/'

    remove_repo_dir(REPO_DIR)

# Generated at 2022-06-11 20:20:16.756967
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    with pytest.raises(NonTemplatedInputDirException):
        find_template('tests/fake-repo-tmpl')
    assert find_template('tests/fake-repo-pre/{{cookiecutter.repo_name}}') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre/{{cookiecutter.repo_name}}/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre/my-fake-repo/') == 'tests/fake-repo-pre/my-fake-repo'

# Generated at 2022-06-11 20:20:18.562045
# Unit test for function find_template
def test_find_template():
    """{% raw %}{% endraw %}"""
    # TODO: add unit tests for find_template
    pass

# Generated at 2022-06-11 20:20:24.697039
# Unit test for function find_template
def test_find_template():
    class TmpDir(object):
        def __init__(self):
            self.tmp_dir = os.path.join(os.path.expanduser('~'), 'cookiecutter_test_tmp')
            self.repo_dir = os.path.join(self.tmp_dir, 'test_repo')
            self.project_template = os.path.join(self.repo_dir, 'cookiecutter-{{project_name}}')

        def __enter__(self):
            os.makedirs(self.repo_dir)
            os.makedirs(self.project_template)
            return self

        def __exit__(self, *args):
            os.removedirs(self.project_template)
            os.removedirs(self.repo_dir)
            os.removedirs

# Generated at 2022-06-11 20:20:32.368030
# Unit test for function find_template
def test_find_template():
    """This function is used to test find_template function in find.py
    """
    from . import find
    import unittest
    import tempfile
    import shutil

    if os.path.exists('cookiecutter/tests/test_repo'):
        shutil.rmtree('cookiecutter/tests/test_repo')

    class TestFindTemplate(unittest.TestCase):
        def setUp(self):
            self.old_dir = os.getcwd()
            self.tmp_dir = tempfile.mkdtemp()
            self.repo_dir = os.path.join(self.tmp_dir, 'test_repo')
            self.repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'

# Generated at 2022-06-11 20:20:34.425989
# Unit test for function find_template
def test_find_template():
    """TODO: write this test."""
    pass

# Generated at 2022-06-11 20:20:41.353764
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function.

    Given a repo clone directory, the function find_template should return
    the relative path to a directory named "cookiecutter-<query>".
    """
    import tempfile
    from cookiecutter.utils import rmtree

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, "cookiecutter-template"))

    result = find_template(repo_dir)
    expected = os.path.join(repo_dir, "cookiecutter-template")
    assert result == expected

    rmtree(repo_dir)