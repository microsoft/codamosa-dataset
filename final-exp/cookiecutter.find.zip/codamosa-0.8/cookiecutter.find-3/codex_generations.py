

# Generated at 2022-06-11 20:11:40.468813
# Unit test for function find_template
def test_find_template():
    cwd = os.getcwd()
    os.chdir('tests/fake-repo-pre')

    project_template = find_template('.')

    # Change the current working directory back to where the tests started
    os.chdir(cwd)

    assert 'fake_project_template' in project_template

# Generated at 2022-06-11 20:11:45.307923
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.expanduser('~'))
    non_templated_dir = os.path.join('test_cookiecutter_find_template',
                                     'no_template')
    find_template(non_templated_dir)

test_find_template.__test__ = False

# Generated at 2022-06-11 20:11:50.595051
# Unit test for function find_template
def test_find_template():
    """Find the Cookiecutter template in a git repo."""
    assert find_template('tests/fake-repo-pre/') == \
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == \
        'tests/fake-repo-post/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:11:55.221908
# Unit test for function find_template
def test_find_template():
    """Test finding the correct template directory."""
    repo_dir = 'tests/test-repo-pre/'

    project_template = find_template(repo_dir)

    assert project_template == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:12:00.290855
# Unit test for function find_template
def test_find_template():
    """Verify find_template function returns correct value for Cookiecutter project."""
    repo_dir = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, os.pardir, 'tests', 'fake-repo-pre')
    assert find_template(repo_dir) == os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, os.pardir, 'tests', 'fake-repo-pre', 'fake_template_pre')



# Generated at 2022-06-11 20:12:07.729192
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-repo-pre',
    )
    expected = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}',
    )
    assert find_template(repo_dir) == expected

# Generated at 2022-06-11 20:12:13.013846
# Unit test for function find_template
def test_find_template():
    """Test find_template on a local directory.

    Assume that the current dir is the root of the test repo.
    """
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test-repo'
    )

    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-11 20:12:14.905914
# Unit test for function find_template
def test_find_template():
    os.path.join(os.path.dirname(__file__), 'tests/fake-repo')

# Generated at 2022-06-11 20:12:19.678896
# Unit test for function find_template
def test_find_template():
    """Identify project template within a mock repo."""
    import tempfile
    from cookiecutter.tests.test_find_template import make_repo

    with tempfile.TemporaryDirectory() as tmp_dir:
        repo_dir = make_repo(tmp_dir)
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, 'after')



# Generated at 2022-06-11 20:12:20.673790
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-11 20:12:27.782176
# Unit test for function find_template
def test_find_template():
    tempdir, cloned_repo_dir = init_repo()

    with cd(cloned_repo_dir):
        project_template = find_template(cloned_repo_dir)

    assert project_template == os.path.join(cloned_repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:12:35.915614
# Unit test for function find_template
def test_find_template():
    logging.disable(logging.CRITICAL)
    template_directory = os.path.join(
        os.path.dirname(__file__), 'fake-repo-tmpl',
    )
    project_template = find_template(template_directory)
    # The project template found within the fake_repo_tmpl should be
    # 'fake-repo-tmpl/{{cookiecutter.repo_name}}'.
    expected_template = os.path.join(
        template_directory,
        '{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_template

# Generated at 2022-06-11 20:12:40.613938
# Unit test for function find_template
def test_find_template():
    """Defines basic test repo to be cloned under temporary build directory."""
    from .test_utils import src_test_repo_dir
    from .test_utils import tmp_test_repo_dir

    repo_dir = tmp_test_repo_dir()
    project_template = find_template(repo_dir)
    exp_project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert project_template == exp_project_template

# Generated at 2022-06-11 20:12:44.192719
# Unit test for function find_template
def test_find_template():
    assert find_template('./tests/test-find-template') == './tests/test-find-template/{{cookiecutter.repo_name}}'
    assert find_template('./tests/fake-repo') is None

# Generated at 2022-06-11 20:12:50.134183
# Unit test for function find_template
def test_find_template():
    import nose.tools as nt
    from cookiecutter import utils
    from cookiecutter.tests.test_utils import make_bogus_cookiecutter_dir

    logger.debug('Running unit tests')

    temp_dir, project_dir = make_bogus_cookiecutter_dir()

    try:
        project_template = utils.find_template(project_dir)
        nt.assert_equal(project_template, os.path.join(project_dir, 'cookiecutter-bogus'))
    finally:
        utils.rmtree(temp_dir)

# Generated at 2022-06-11 20:12:59.212697
# Unit test for function find_template
def test_find_template():
    """Integration test for find_template.

    Verify that find_template is discovering the correct project template.
    """

    local_repo_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    project_template = find_template(local_repo_dir)

    # If this test fails, the project_template returned by find_template was
    # not correct.
    import cookiecutter.cookiecutters.python_package

    assert os.path.abspath(project_template) == os.path.abspath(
        cookiecutter.cookiecutters.python_package.__file__)

# Generated at 2022-06-11 20:13:02.704716
# Unit test for function find_template
def test_find_template():
	assert 'cookiecutter-pypackage' == find_template('cookiecutter/cookiecutters')
	assert 'cookiecutter-pypackage' == find_template('cookiecutter/cookiecutters/')

# Generated at 2022-06-11 20:13:06.926627
# Unit test for function find_template
def test_find_template():
    test_dir = '/home/vagrant/cookiecutter-test'
    result = find_template(test_dir)
    assert result == '/home/vagrant/cookiecutter-test/{{cookiecutter.repo_name}}'
    print('find_template() passed!')

# Execute the unit test
test_find_template()

# Generated at 2022-06-11 20:13:13.227193
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function works as expected
    """
    # import pudb; pu.db
    import os

    this_dir = os.path.dirname(__file__)
    expected_dir = os.path.join(this_dir, 'fake-repo', '{{cookiecutter.repo_name}}')
    repo_dir = os.path.join(this_dir, 'fake-repo')

    assert expected_dir == find_template(repo_dir)

# Generated at 2022-06-11 20:13:16.637556
# Unit test for function find_template
def test_find_template():
    """Check that if the repo directory is empty, we get an error."""
    import tempfile
    import shutil
    import pytest
    tmp_dir = tempfile.mkdtemp()
    with pytest.raises(NonTemplatedInputDirException):
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-11 20:13:20.007214
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    pass


# Generated at 2022-06-11 20:13:25.631602
# Unit test for function find_template
def test_find_template():
    """Test that find_template can find the template directory."""
    from cookiecutter.utils.paths import fixture_path
    input_path = fixture_path('fake-repo-pre/')
    result = find_template(input_path)
    assert result == input_path + '{{cookiecutter.repo_name}}/'


# Generated at 2022-06-11 20:13:33.349164
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import os

    expected_output = 'tests/test-repo/'
    test_dir = tempfile.mkdtemp()
    test_file = tempfile.NamedTemporaryFile(dir=test_dir, delete=False)
    shutil.copytree('tests/test-repo', os.path.join(test_dir, 'cookiecutter-pypackage'))
    test_file.close()

    # expected output
    assert expected_output == find_template(test_dir)
    # post-test clean up
    os.remove(test_file.name)
    shutil.rmtree(os.path.join(test_dir, 'cookiecutter-pypackage'))
    os.removedirs(test_dir)

# Generated at 2022-06-11 20:13:33.966646
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:38.701491
# Unit test for function find_template
def test_find_template():
    """Verify directory with template is found."""
    from cookiecutter.tests.test_utils import TEST_COOKIE_PATH

    test_dir = os.path.join(TEST_COOKIE_PATH, 'my_dir')
    template_dir = os.path.join(test_dir, 'my_dir')

    assert find_template(test_dir) == template_dir

# Generated at 2022-06-11 20:13:42.675615
# Unit test for function find_template
def test_find_template():
    """Sample usage of the find_template() function."""
    assert find_template('/home/audreyr/cookiecutter-pypackage') == \
        '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:43.623301
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:44.140688
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:52.898588
# Unit test for function find_template
def test_find_template():
    """Tests the find_template function.
    """
    import cookiecutter.utils

    repo_dir = os.path.abspath(
        os.path.join(
            cookiecutter.__file__,
            '..', '..', 'tests', 'test-repo'
        )
    )
    repo_dir = os.path.normpath(repo_dir)

    template = cookiecutter.utils.find_template(repo_dir)

    assert template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:13:57.210545
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    import tempfile
    import shutil

    # Set up a test repo, then use find_template to find it.
    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    os.makedirs(repo_dir)
    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write('{')
    project_template = find_template(temp_dir)
    assert os.path.exists(project_template)

    shutil.rmtree(temp_dir)

# Generated at 2022-06-11 20:14:06.322183
# Unit test for function find_template
def test_find_template():
    import time
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 20:14:11.091854
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function"""
    assert find_template("/home/me/cookiecutter-pypackage") == "/home/me/cookiecutter-pypackage/{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:14:17.287544
# Unit test for function find_template
def test_find_template():
    def check_template_path(dir_path, expected):
        assert find_template(dir_path) == expected

    test_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(test_dir, 'repo')

    check_template_path(repo_dir, os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))

# Generated at 2022-06-11 20:14:17.876237
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:22.296381
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-no-meta'))
    assert find_template(repo_dir) == 'fake-repo-no-meta/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:29.074845
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/vagrant/sync/tests/test-repo-tmpl'
    project_template = find_template(repo_dir)
    assert(project_template == '/home/vagrant/sync/tests/test-repo-tmpl/cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:14:39.198700
# Unit test for function find_template
def test_find_template():
    """E2E test for functions find_template"""
    path_to_find_template_tests = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), 'tests/find_template_tests'
        )
    )
    tests = [
        test for test in os.listdir(path_to_find_template_tests)
        if os.path.isdir(os.path.join(path_to_find_template_tests, test))
    ]
    for test in tests:
        test_dir = os.path.join(path_to_find_template_tests, test)
        test_expected = os.path.join(
            test_dir, 'expected', os.path.basename(test_dir)
        )

# Generated at 2022-06-11 20:14:46.061324
# Unit test for function find_template
def test_find_template():
    """Test find the project template."""

    import cookiedozer
    from tempfile import mkdtemp
    tempdir = mkdtemp(prefix='cookiedozer')
    cookiedozer.generate_project(
        user_config_path='tests/fake-repo/fake_user_config.yaml',
        template_dir=tempdir
    )
    project_template = find_template(tempdir)
    assert 'example-repo/' in project_template

# Generated at 2022-06-11 20:14:49.153130
# Unit test for function find_template
def test_find_template():

    assert find_template('/home/username/my-project') == '/home/username/my-project/cookiecutter-my-project'

# Generated at 2022-06-11 20:14:49.689401
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:57.261973
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join('tests', 'test-find-template')
    repo_dir = 'fake_repo_dir'
    expected = 'fake_repo_dir/fake-project{{cookiecutter.project_name}}'
    assert find_template(repo_dir) == expected

# Generated at 2022-06-11 20:15:06.960778
# Unit test for function find_template
def test_find_template():
    """Run the find_template function with a known-good test case."""
    # Create a testing directory
    temp_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'tests',
        'test-template-repo',
        '{{cookiecutter.repo_name}}',
    )
    logger.debug('Testing find_template with repo: %s', temp_dir)

    # Run the function
    project_template = find_template(temp_dir)
    logger.debug('Cookiecutter found this project_template: %s', project_template)

    # Assert that the output is correct
    assert project_template == os.path.join(temp_dir, 'right-dir')

# Generated at 2022-06-11 20:15:09.300409
# Unit test for function find_template
def test_find_template():
    print(find_template(r"D:\cookiecutter-github\cookiecutter-pypackage"))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:15:12.336059
# Unit test for function find_template
def test_find_template():
    """Verify that the function works as expected."""
    assert find_template('tests/test-repo') == 'tests/test-repo/{{cookiecutter.project_name}}'

# Generated at 2022-06-11 20:15:17.749076
# Unit test for function find_template
def test_find_template():
    assert find_template('/cholm/stig/newrepo') == '/cholm/stig/newrepo/{{cookiecutter.repo_name}}'
    assert find_template('/cholm/stig/newrepo2') != '/cholm/stig/newrepo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:21.091398
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'tests', 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template

# Generated at 2022-06-11 20:15:28.184425
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_utils import make_repo
    from cookiecutter.tests.test_utils import work_in

    with work_in(os.path.join('tests', 'files')):
        result = find_template(make_repo('foo-bar'))
        assert result == os.path.join(os.getcwd(), 'foo-bar', '{{cookiecutter.repo_name}}'), result

    with work_in(os.path.join('tests', 'files')):
        result = find_template(make_repo('baz-qux'))
        asse

# Generated at 2022-06-11 20:15:34.523033
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/.cookiecutters/cookiecutter-pypackage') == '/Users/audreyr/.cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('/Users/audreyr/.cookiecutters/cookiecutter-pypackage/') == '/Users/audreyr/.cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:38.879421
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/benno/code/cookiecutter-pypackage') == '/home/benno/code/cookiecutter-pypackage/cookiecutter-pypackage'


# Generated at 2022-06-11 20:15:45.860449
# Unit test for function find_template
def test_find_template():
    """
    Check if the template is found in good and bad conditions
    """
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    try:
        shutil.copytree('tests/test-data', temp_dir + '/test-repo')
        assert find_template(repo_dir=os.path.join(temp_dir, 'test-repo')) == os.path.join(temp_dir, 'test-repo/{{cookiecutter.repo_name}}')
    except NonTemplatedInputDirException:
        return True

# Generated at 2022-06-11 20:15:56.447781
# Unit test for function find_template
def test_find_template():
    """Test a basic example of find_template."""
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    project_template = find_template(repo_dir)

    expected_project_template = '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert project_template == expected_project_template

# Generated at 2022-06-11 20:15:57.139263
# Unit test for function find_template
def test_find_template():
    #TODO: Stub it out
    pass

# Generated at 2022-06-11 20:16:03.702374
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the correct template."""
    repo_dir = 'tests/test-find-template'
    project_template = find_template(repo_dir)
    template_expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    test_result = project_template == template_expected
    if test_result:
        print('Test passed')
    else:
        print('Test failed')
    return test_result

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:16:07.908194
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:13.727731
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-find-template')
    template_dir = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert template_dir == expected

# Generated at 2022-06-11 20:16:16.677766
# Unit test for function find_template
def test_find_template():
    project_template = find_template('/test-repos/cookiecutter-pypackage')
    assert project_template == '/test-repos/cookiecutter-pypackage/{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:16:19.147298
# Unit test for function find_template
def test_find_template():
    """ Test find_template. """
    assert find_template(repo_dir = 'test/test-repo') == 'test/test-repo/cookiecutter-pypackage'

# Generated at 2022-06-11 20:16:23.215168
# Unit test for function find_template
def test_find_template():
    from cookiecutter import repo

    repo_dir = repo.clone(
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    )
    project_template = find_template(repo_dir)
    repo_dir_listing = os.listdir(repo_dir)
    assert project_template == os.path.join(repo_dir, repo_dir_listing[0])

# Generated at 2022-06-11 20:16:31.278162
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil

    # First template with {{cookiecutter.repo_name}}
    repo_with_template_1 = tempfile.mkdtemp()
    template_1 = os.path.join(repo_with_template_1, 'template1')
    os.makedirs(template_1)
    assert find_template(repo_with_template_1) == template_1

    # Second template with {{cookiecutter.project_name}}
    repo_with_template_2 = tempfile.mkdtemp()
    template_2 = os.path.join(repo_with_template_2, 'template2')
    os.makedirs(template_2)
    assert find_template(repo_with_template_2) == template_2

    # No template
    repo_without_

# Generated at 2022-06-11 20:16:39.202046
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests import get_cwd
    from cookiecutter.tests.test_main import delete_project_folder
    from cookiecutter.tests.test_main import create_project_folder
    from cookiecutter.tests.test_main import fake_project_name

    cwd = get_cwd()
    repo_dir = os.path.join(cwd, 'tests/test-repo-pre/')
    project_dir = os.path.join(cwd, 'tests/fake-project-pre/')

    project_template = find_template(repo_dir)
    logger.debug('The project template is %s', project_template)

    delete_project_folder(project_dir, fake_project_name)
    create_project_folder(project_dir, fake_project_name)


# Generated at 2022-06-11 20:16:58.998355
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__),
                            '..',
                            'tests',
                            'fake-repo',
                            'cookiecutter-pypackage')
    cwd = os.getcwd()
    os.chdir(repo_dir)
    try:
        project_template = find_template(repo_dir)
        assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        os.chdir(cwd)

# Generated at 2022-06-11 20:17:03.983707
# Unit test for function find_template
def test_find_template():
    test_dir = 'tests/fixtures/fake-repo-tmpl'
    project_tmpl = find_template(test_dir)
    assert project_tmpl == 'tests/fixtures/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:17:08.236632
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), '..', 'tests'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir, 'tests', 'fixtures', 'fake-repo-tmpl'
    )

# Generated at 2022-06-11 20:17:14.843870
# Unit test for function find_template
def test_find_template():
    """Test find_template_dir."""
    tests = [
        ("/Users/audreyr/cookiecutter-pypackage",
         "/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}"),
        ("/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}",
         "/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}")
    ]

    for in_, out in tests:
        assert find_template(in_) == out

# Generated at 2022-06-11 20:17:22.146728
# Unit test for function find_template
def test_find_template():
    """
    Test find_template.
    """

    test_path = os.path.join(os.path.dirname(__file__), '..')
    project_template = os.path.join(test_path, os.pardir, 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    repo_dir = os.path.join(test_path, os.pardir, 'tests', 'fake-repo-pre')

    assert find_template(repo_dir) == project_template


# Generated at 2022-06-11 20:17:24.560702
# Unit test for function find_template
def test_find_template():
	template = find_template('/home/marsya/cookiecutter-pypackage')
	assert 'cookiecutter-pypackage/{{cookiecutter.project_name}}' == template

# Generated at 2022-06-11 20:17:26.845719
# Unit test for function find_template
def test_find_template():
    repo_dir = "../tests/test-repo/{{project_name}}"
    find_template(repo_dir)

# Generated at 2022-06-11 20:17:33.690098
# Unit test for function find_template
def test_find_template():
    assert (
        find_template(
            'C:/Users/user/AppData/Local/Programs/Python/Python36-32/Lib/site-packages'
            '/cookiecutter/__init__.py'
        ) == 'C:/Users/user/AppData/Local/Programs/Python/Python36-32/Lib/site-packages'
        '/cookiecutter/__init__.py'
    )

# Generated at 2022-06-11 20:17:35.266892
# Unit test for function find_template
def test_find_template():
    """Verify proper identifcation of the project template."""
    assert find_template('myproject') == 'myproject'

# Generated at 2022-06-11 20:17:40.330100
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() correctly finds the project template."""
    import tempfile

    template_name = 'cookiecutter-pypackage'
    with tempfile.TemporaryDirectory() as temp_dir:
        repo_dir = os.path.join(temp_dir, template_name)
        os.mkdir(repo_dir)

        # create file that should not be picked up as the project template
        with open(os.path.join(repo_dir, 'README.rst'), 'w') as f:
            f.write('{{ cookiecutter.project_name }}')

        # create a file that should be picked up as the project template

# Generated at 2022-06-11 20:18:13.862772
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'tests/test-repo-tmpl'
    )
    project_template = find_template(repo_dir)
    assert project_template == repo_dir



# Generated at 2022-06-11 20:18:24.543804
# Unit test for function find_template
def test_find_template():
    def cleanup():
        if os.path.isdir(repo_dir):
            import shutil
            shutil.rmtree(repo_dir)
    import sys
    import shutil
    import tempfile
    import textwrap
    from cookiecutter.utils import rmtree

    repo_dir = tempfile.mkdtemp()

    # Create a test repo
    os.makedirs(os.path.join(repo_dir, 'not_a_template'))
    open(os.path.join(repo_dir, 'not_a_template', 'README.rst'), 'w+').close()

    template_dir = os.path.join(repo_dir, '{{ cookiecutter.repo_name }}')
    os.makedirs(template_dir)


# Generated at 2022-06-11 20:18:29.365999
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo-pre-gen',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:18:31.093791
# Unit test for function find_template
def test_find_template():
    """Verify ``find_template()`` works."""
    pass

# Generated at 2022-06-11 20:18:35.301514
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the expected path."""
    test_dir = 'tests/test-input/fake-repo-tmpl'

    test_template_dir = find_template(test_dir)

    assert test_template_dir == 'tests/test-input/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:18:37.327112
# Unit test for function find_template
def test_find_template():
    # test default
    assert 'my-project' == find_template('.')

    # test custom input_dir
    assert 'my-project2' == find_template('my-project2')

# Generated at 2022-06-11 20:18:41.653274
# Unit test for function find_template
def test_find_template():
    """Test only running from the tests directory."""
    import os
    os.chdir('tests/fake-repo-pre/')
    find_template('.')
    test_dir = 'tests/fake-repo-render/'
    assert find_template(test_dir) == test_dir + '{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:18:43.988117
# Unit test for function find_template
def test_find_template():

    find_template('/home/david/Desktop/cookiecutter-pypackage/my-new-project')

# Generated at 2022-06-11 20:18:53.508724
# Unit test for function find_template
def test_find_template():

    c1 = 'github.com/audreyr/cookiecutter-pypackage'
    c2 = 'github.com/cookiecutter/cookiecutter'
    c3 = 'github.com/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    c4 = 'github.com/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}/{{cookiecutter.foo}}'
    c5 = 'github.com/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}/{{cookiecutter.foo}}/'

# Generated at 2022-06-11 20:18:57.688774
# Unit test for function find_template
def test_find_template():
    """Basic test for find_template()."""
    from tests.test_find import FIXTURES
    repo_dir = FIXTURES['no_file_repo']

    assert 'cookiecutter-no-file' in find_template(repo_dir)

# Generated at 2022-06-11 20:20:14.535504
# Unit test for function find_template
def test_find_template():
    """Find the template dir when inside a template."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'fake-repo'),
    )
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-11 20:20:18.657035
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function with valid inputs.
    """
    repo_dir = './tests/fake-repo-tmpl'
    project_template = find_template(repo_dir)
    assert project_template == './tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:20:24.314740
# Unit test for function find_template
def test_find_template():
    """Verify that a project template is found when it should be, and not
    found when it shouldn't be.
    """
    # Simple tests with incomplete dirs
    assert find_template('tests/fake-repo-tmpl') == \
        'tests/fake-repo-tmpl/fake-project-tmpl'
    try:
        find_template('tests/empty-dir-for-testing')
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

    # Complex test with dir that has other junk in it
    assert find_template('tests/fake-repo-pre') == \
        'tests/fake-repo-pre/fake-project-pre'

# Generated at 2022-06-11 20:20:32.555480
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works."""
    from cookiecutter.tests.test_utils import make_empty_dir
    from cookiecutter.tests.test_utils import remove_repo

    template_dir = make_empty_dir('tests/fake-repo-tmpl')
    fake_repo = make_empty_dir('tests/fake-repo')

    root_dir = os.path.dirname(os.path.abspath(template_dir))

    with open(os.path.join(template_dir, 'cookiecutter.json'), 'w') as f:
        f.write('')

    with open(os.path.join(template_dir, 'fake.txt'), 'w') as f:
        f.write('')


# Generated at 2022-06-11 20:20:37.100692
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    template = find_template(repo_dir='/tmp/cookiecutter-a71a5bf8')
    assert os.path.exists(template), 'Template {0} does not exist'.format(template)

# Generated at 2022-06-11 20:20:43.607204
# Unit test for function find_template
def test_find_template():
    repo_dir = 'some_directory'
    repo_dir_contents = ['cookiecutter-test-repo', 'some_other_file.txt']
    os.listdir = lambda path: repo_dir_contents

    def mocked_os_path_join(a, b):
        assert a == repo_dir
        assert b == repo_dir_contents[0]
        return os.path.join(a, b)

    os.path.join = mocked_os_path_join
    project_template = find_template(repo_dir)
    assert repo_dir in project_template
    assert repo_dir_contents[0] in project_template
    assert repo_dir_contents[1] not in project_template

    repo_dir_contents = ['some_other_file.txt']

# Generated at 2022-06-11 20:20:53.204053
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter

    tmp_dir = tempfile.mkdtemp()
    output = cookiecutter(
        'tests/fake-repo-tmpl',
        no_input=True,
        output_dir=tmp_dir,
        extra_context={'full_name': 'Benjamin E. Bean'},
    )

    full_path = os.path.join(tmp_dir, output)

    # Check the generated cookiecutter template's structure
    assert os.path.isdir(full_path)

    # Check the generated cookiecutter template's contents
    with open(os.path.join(full_path, 'README.rst')) as f:
        contents = f.read()

    assert 'Generated with Cookiecutter' in contents


# Generated at 2022-06-11 20:20:55.487262
# Unit test for function find_template
def test_find_template():
    assert find_template("/user/cookiecutter-sample") == "/user/cookiecutter-sample/{{cookiecutter.project_name}}"

# Generated at 2022-06-11 20:21:01.297219
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils

    root_dir = utils.HERE
    template_dir = os.path.join(root_dir, 'tests', 'fake-repo-tmpl')
    result = find_template(template_dir)
    expected = os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    assert result == expected

# Generated at 2022-06-11 20:21:04.449550
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-repo/{{cookiecutter.repo_name}}'