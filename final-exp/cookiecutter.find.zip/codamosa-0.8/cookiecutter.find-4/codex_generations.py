

# Generated at 2022-06-11 20:11:34.573802
# Unit test for function find_template
def test_find_template():
    template = find_template('./components')
    assert template == './components/{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:11:36.759452
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/vagrant/scripts/tests/fake-repo/'
    find_template(repo_dir)

# Generated at 2022-06-11 20:11:39.577843
# Unit test for function find_template
def test_find_template():
    find_template('/Users/emma/Downloads/re-cookiecutter-master')


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:11:40.149792
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:11:46.573493
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:11:50.379921
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/johndoe/cookiecutters_repo'
    project_template = find_template(repo_dir)
    assert project_template == '/home/johndoe/cookiecutters_repo/cookiecutter-pypackage'

# Generated at 2022-06-11 20:11:57.856352
# Unit test for function find_template
def test_find_template():
    """Test that the function finds the template in a non-templated input dir.
    """
    import tempfile
    try:
        temp_dir = tempfile.mkdtemp()
        test_input = os.path.join(temp_dir, 'cookiecutter-pypackage')
        os.makedirs(test_input)

        project_template = find_template(test_input)
        assert project_template == test_input
    finally:
        if os.path.exists(temp_dir):
            os.remove(temp_dir)

# Generated at 2022-06-11 20:12:08.398433
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template()` works."""
    import shutil
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter import generate

    with TemporaryDirectory() as tmpdir:
        template_dir = os.path.join(tmpdir, 'cookiecutter-{{cookiecutter.bad_var}}')
        os.makedirs(template_dir)

        readme_path = os.path.join(template_dir, 'README.md')
        with open(readme_path, 'w') as fh:
            fh.write('README.md file')

        logger.debug('template_dir = %s', repr(template_dir))

        found_template = find_template(tmpdir)
        logger.debug('found_template = %s', repr(found_template))

        assert found

# Generated at 2022-06-11 20:12:18.868500
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from cookiecutter.compat import TemporaryDirectory
    import os

    with TemporaryDirectory(prefix='cookiecutter-') as tmpdir:
        # Create a sample repository to test with
        test_repo_dir = os.path.join(tmpdir, 'tests/fake-repo-tmpl/')
        os.makedirs(test_repo_dir)
        utils.workaround_non_user_write_permission(test_repo_dir)
        # Create a file that should not be found
        open(os.path.join(test_repo_dir, 'README.md'), 'a').close()
        # Create a file that should be found

# Generated at 2022-06-11 20:12:22.832202
# Unit test for function find_template
def test_find_template():
    from tests.test_utils import TEST_TEMPLATE_DIR

    project_template = find_template(TEST_TEMPLATE_DIR)
    assert project_template == os.path.join(TEST_TEMPLATE_DIR, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:12:35.915222
# Unit test for function find_template
def test_find_template():
    from nose.tools import raises
    from .utils import make_dummy_project

    # Since find_template() is a small function that uses other functions
    # that are well tested, only a few unit tests are needed
    # to test the integration.
    make_dummy_project()
    assert find_template('.') == './cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template('tests/files/fake-repo-tmpl') == 'tests/files/fake-repo-tmpl/foobar'
    os.chdir('tests/files/fake-repo-pre')
    assert find_template('.') == './cookiecutter-fake-repo'
    os.chdir('../..')

# Generated at 2022-06-11 20:12:37.749040
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-repo/') == 'cookiecutter-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:44.655404
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the expected file."""
    template_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    )
    template_file = os.path.join(template_dir, 'foobar-{{cookiecutter.repo_name}}')

    assert find_template(template_dir) == template_file

# Generated at 2022-06-11 20:12:48.439316
# Unit test for function find_template
def test_find_template():
    #test with real environment
    repo_dir1 = "/Users/your/path"
    #test with virtual environment
    repo_dir2 = "/home/your/path"

    assert find_template(repo_dir1) == None
    assert find_template(repo_dir2) == None

# Generated at 2022-06-11 20:12:54.573803
# Unit test for function find_template
def test_find_template():
    """Test find_template"""
    test_dir = os.path.dirname(__file__)
    project_dir = os.path.join(test_dir, 'fake-repo-pre/')
    project_template = find_template(project_dir)
    exp_project_template = os.path.join(project_dir, 'fake-project-template')
    assert project_template == exp_project_template

# Generated at 2022-06-11 20:12:58.302433
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'files', 'fake-repo')
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:13:02.329855
# Unit test for function find_template
def test_find_template():
    """Test function by entering a directory with a cookiecutter.json file in it"""
    os.chdir('/home/thomas/Dev/cookiecutters/slideshow-cookiecutter/')
    assert find_templa

# Generated at 2022-06-11 20:13:09.317603
# Unit test for function find_template
def test_find_template():
    """Test search local directory for project template."""
    # Create a local directory
    os.makedirs('./cookiecutter-test')

    # Test a directory that doesn't have a templated input directory
    with open('./cookiecutter-test/README.md', 'w') as f:
        f.write('My README file.')

    repo_dir = './cookiecutter-test'

    from cookiecutter.config import find_template
    result = find_template(repo_dir)
    assert result == './cookiecutter-test/cookiecutter-{{cookiecutter.repo_name}}'

    # Cleanup the local directory
    subprocess.call('rm -rf ./cookiecutter-test', shell=True)

# Generated at 2022-06-11 20:13:13.729101
# Unit test for function find_template
def test_find_template():
    """Tests the find template function."""
    repo_dir = 'my_project'
    with open(os.path.join(repo_dir, 'cookiecutter.json'), 'w') as f:
        f.write('{}')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter.json')

# Generated at 2022-06-11 20:13:16.468527
# Unit test for function find_template
def test_find_template():
    """Verify that find_template function returns template dir."""
    repo_dir = '/repo/path/{{cookiecutter.repo_name}}'
    project_template = find_template(repo_dir)
    assert project_template == repo_dir

# Generated at 2022-06-11 20:13:29.151725
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.main import cookiecutter
    from test_cookiecutter import clean_up_test_dir

    test_dir = 'fake-git-repo'

    result = cookiecutter(
        'tests/fixtures/{}'.format(test_dir),
        no_input=True,
        output_dir='tests/fake-repo-pre-render',
        replay=True,
    )

    assert result
    assert os.path.exists('tests/fake-repo-pre-render/foobar')

    # Run the function to test
    test_git_repo = 'tests/fake-repo-pre-render'
    repo_dir = find_template(test_git_repo)
    assert os.path.exists(repo_dir)

    # Clean up

# Generated at 2022-06-11 20:13:36.878055
# Unit test for function find_template
def test_find_template():
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter import vcs

    with TemporaryDirectory() as repo_dir:
        repo_dir_contents = ['my_template{{- cookiecutter.project_slug -}}',
                             'normal_dir',
                             'another_dir']

        for item in repo_dir_contents:
            os.mkdir(os.path.join(repo_dir, item))

        vcs.identify_repo(repo_dir)
        assert find_template(repo_dir) == os.path.join(repo_dir,
                                                       'my_template{{- cookiecutter.project_slug -}}')

# Generated at 2022-06-11 20:13:41.127335
# Unit test for function find_template

# Generated at 2022-06-11 20:13:47.271724
# Unit test for function find_template
def test_find_template():
    """Verify that find_template can successfully find the template."""

    # setup
    from cookiecutter.utils import rmtree
    from cookiecutter import main
    import tempfile
    import re

    output_dir = tempfile.mkdtemp()
    repo_dir = main.cookiecutter('tests/test-repo/', no_input=True, output_dir=output_dir)

    assert os.path.isdir(repo_dir)
    repo_dir_contents = os.listdir(repo_dir)


# Generated at 2022-06-11 20:13:55.744275
# Unit test for function find_template
def test_find_template():
    """
    Tests for find_template function
    """
    repo_path = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo-tmpl'
    ))
    project_template = find_template(repo_path)
    assert project_template == os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo-tmpl',
        '{{cookiecutter.repo_name}}'
    ))

# Generated at 2022-06-11 20:13:59.521408
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template` returns expected results."""
    expected = 'tests/test-data/fake-repo-tmpl/fake-project-{{cookiecutter.repo_name}}'
    actual = find_template('tests/test-data/fake-repo-tmpl')
    assert actual == expected

# Generated at 2022-06-11 20:14:06.615538
# Unit test for function find_template
def test_find_template():
    """Confirms that the functional version of `find_template` works.

    Makes sure that calling find_template in the context of a unit test works.
    """
    from cookiecutter import utils
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = os.path.join(tmpdir, 'foo')
        os.makedirs(tmpdir)

        assert utils.find_template(tmpdir) is None

        templated_dir = os.path.join(tmpdir, '{{cookiecutter.repo_name}}')
        os.makedirs(templated_dir)

        assert utils.find_template(tmpdir) == templated_dir


# Generated at 2022-06-11 20:14:15.803819
# Unit test for function find_template
def test_find_template():
    """Unit testing for function find_template."""
    from .test_utils import temp_chdir
    from .test_utils import fake_repo
    from .test_utils import working_dir_path

    with temp_chdir():
        with fake_repo():
            with working_dir_path() as working_dir:
                repo_dir = os.path.join(working_dir, 'fake-repo')
                project_template = find_template(repo_dir)
                assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:14:17.239146
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == './{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:17.840818
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:27.357461
# Unit test for function find_template
def test_find_template():
    # Set the logging level to debug
    logger.setLevel(logging.DEBUG)
    # Set up the console logger
    console_logger = logging.StreamHandler()
    # Set up the formatter
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    # Add the formatter to the console logger
    console_logger.setFormatter(formatter)
    # Add the console logger to the main logger
    logger.addHandler(console_logger)
    # Where the cookiecutters are
    cookiecutters_dir = os.getcwd() + '/tests'
    # The empty repo
    repo_dir = cookiecutters_dir + '/test-empty-repo'
    # Result: the project template
    project_template = find_template(repo_dir)
    # The

# Generated at 2022-06-11 20:14:32.388083
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'fake-repo', 'fake_repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}', 'hooks')



# Generated at 2022-06-11 20:14:35.800963
# Unit test for function find_template
def test_find_template():
    """
    test case for find_template
    """
    find_template("/home/yue/Documents/Python/Cookiecutter/cookiecutter-hello/")

# Generated at 2022-06-11 20:14:37.042458
# Unit test for function find_template
def test_find_template():
    """Verify that find_template correctly identifies the project template."""
    pass

# Generated at 2022-06-11 20:14:37.841314
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:43.820881
# Unit test for function find_template
def test_find_template():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    templated_dir = os.path.join(tmpdir, 'config-{{cookiecutter.config_type}}')
    os.makedirs(templated_dir)
    assert find_template(tmpdir) == templated_dir
    os.rmdir(templated_dir)

# Generated at 2022-06-11 20:14:51.184673
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    os.chdir(os.path.join(os.path.dirname(__file__), '..', 'tests'))
    repo_dir = os.path.abspath('foobar')

    project_template = find_template(repo_dir)
    assert os.path.normcase(project_template) == os.path.normcase(
        os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    )

# Generated at 2022-06-11 20:14:55.171519
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    repo_dir = os.path.join('tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)

    if not isinstance(project_template, str):
        raise TypeError('project_template should be a string')
    elif not os.path.isdir(project_template):
        raise ValueError('project_template should be a directory path')

# Generated at 2022-06-11 20:14:58.208066
# Unit test for function find_template
def test_find_template():
    assert find_template("C:\\Users\\jbates\\PycharmProjects\\cookiecutter-django") == 'C:\\Users\\jbates\\PycharmProjects\\cookiecutter-django\\cookiecutter-django'

# Generated at 2022-06-11 20:15:01.801829
# Unit test for function find_template
def test_find_template():
    test_dir = 'tests/fixtures/fake-repo'
    template = 'tests/fixtures/fake-repo/{{cookiecutter.repo_name}}'
    assert find_template(test_dir) == template

# Generated at 2022-06-11 20:15:09.064994
# Unit test for function find_template
def test_find_template():
    import pkg_resources
    input_dir = pkg_resources.resource_filename(
        'cookiecutter', 'tests/fake-repo-pre/'
    )
    project_template = find_template(input_dir)
    assert project_template == pkg_resources.resource_filename(
        'cookiecutter', 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    )


# Generated at 2022-06-11 20:15:14.718506
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template.

    TODO: This is a hack.
    """
    repo_dir = os.path.expanduser('~/.cookiecutters/cookiecutter-pypackage')
    project_template = find_template(repo_dir)
    assert project_template

test_find_template()

# Generated at 2022-06-11 20:15:24.462650
# Unit test for function find_template
def test_find_template():
    """Unit testing for function find_template"""
    # This "repo_dir" is actually a temp directory created by fabric.
    # This test will fail if executed as a normal unit test
    # (fabric will not be called)
    repo_dir = '/var/folders/nj/2c7nk_s15_j1n8q3zq_jpgxm0000gn/T/tmp6RbE6Z'
    find_template = find_template(repo_dir)
    assert find_template == 'repo_dir/{{ cookiecutter.repo_name }}'

    # This "repo_dir" is a non-templated directory for testing
    repo_dir = 'tests/non-templated-repo'
    assert find_template(repo_dir) is None

# Generated at 2022-06-11 20:15:27.863930
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can detect the project template."""
    logging.disable(logging.CRITICAL)
    assert find_template('tests/test-find-template/') == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:31.814522
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import os
    import os.path

    tempdir = tempfile.mkdtemp()
    input_path = os.path.join(tempdir, 'cookiecutter-pypackage')
    os.makedirs(input_path)
    output_path = find_template(tempdir)
    assert type(output_path) is str
    assert os.path.basename(output_path) == 'cookiecutter-pypackage'
    shutil.rmtree(tempdir)

# Generated at 2022-06-11 20:15:42.065935
# Unit test for function find_template
def test_find_template():
    from unittest.mock import patch
    from nose.tools import assert_raises
    mock_test_dir = os.path.abspath(os.path.dirname(__file__))
    mock_test_template_dirs = ['cookiecutter-pypackage', 'cookiecutter-pypackage-{{{project}}}']
    with patch('os.listdir') as mock_listdir:
        mock_listdir.return_value = mock_test_template_dirs
        assert find_template(mock_test_dir) == os.path.join(mock_test_dir, 'cookiecutter-pypackage-{{{project}}}')
    with patch('os.listdir') as mock_listdir:
        mock_listdir.return_value = ['cookiecutter-pypackage']

# Generated at 2022-06-11 20:15:47.305309
# Unit test for function find_template
def test_find_template():
    """Verify parameters of function find_template."""
    repo_dir = '/home/colon/cookie/cookiecutter-pypackage'
    project_template = find_template(repo_dir)

    assert project_template == '/home/colon/cookie/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:15:50.674916
# Unit test for function find_template
def test_find_template():
    template = find_template('/home/user/My-Awesome-Project')
    assert template == '/home/user/My-Awesome-Project/My-Awesome-Project'

# Generated at 2022-06-11 20:15:56.659967
# Unit test for function find_template
def test_find_template():
    base_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-data'
    ))
    repo_dir = os.path.join(base_dir, 'fake-repo-tmpl')
    proj_dir = os.path.join(base_dir, 'fake-repo-tmpl', 'fake-project')

    assert find_template(repo_dir) == proj_dir


# Generated at 2022-06-11 20:15:59.534642
# Unit test for function find_template
def test_find_template():
    # TODO: test other than the default which is a directory named
    # 'cookiecutter-pypackage'
    pass

# Generated at 2022-06-11 20:16:16.298440
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter.repository import determine_repo_dir

    # Tests
    return_dir = cookiecutter('.', no_input=True)

    repo_dir = determine_repo_dir('.')
    template_dir = find_template(repo_dir)

    # Assert that template_dir is a real path
    assert os.path.exists(template_dir)

    # Assert that template_dir is within repo_dir
    assert os.path.commonprefix([template_dir, repo_dir]) == repo_dir

    # Assert that template_dir is not equal to repo_dir
    assert template_dir != repo_dir

    # Clean up repo_dir and return_dir
    if os.path.exists(repo_dir):
        shut

# Generated at 2022-06-11 20:16:21.266767
# Unit test for function find_template
def test_find_template():
    """Test that function finds a template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..', '..', 'tests', 'test-e2e', 'fake-repo', 'fake-repo'
    )
    template = find_template(repo_dir)
    assert template == 'fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:25.005178
# Unit test for function find_template
def test_find_template():
    """Test finding a template."""
    template = find_template("./tests/fake-repo-pre/")
    assert template == "./tests/fake-repo-pre/{{cookiecutter.repo_name}}"


# Generated at 2022-06-11 20:16:28.583185
# Unit test for function find_template
def test_find_template():
    import os
    repo_dir = os.path.join('tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert(project_template == os.path.join(repo_dir, 'fake-project'))

# Generated at 2022-06-11 20:16:30.992237
# Unit test for function find_template
def test_find_template():
    os.remove("cookiecutter.json")
    out = find_template(".")
    assert out == 'cookiecutter-test'

# Generated at 2022-06-11 20:16:39.101858
# Unit test for function find_template
def test_find_template():
    """Test function for finding cookiecutter template, find_template."""
    import os
    from pytest import raises
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Make sure we're not in a git repo
    utils.rmtree(os.path.join(os.getcwd(), '{{cookiecutter.repo_name}}'))

    # Make a brand new example repo
    cookiecutter('.', no_input=True)

    # Make sure we're not in a git repo
    utils.rmtree(os.path.join(os.getcwd(), 'example_repo'))

    # Make sure we don't have a repo here
    assert not os.path.isdir('example_repo')

    # Find template from master branch

# Generated at 2022-06-11 20:16:47.963498
# Unit test for function find_template
def test_find_template():
    repo_dir = '/my/repo/dir'
    repo_dir_contents = ['cookiecutter{{cookiecutter.example}}',
                         '{{cookiecutter.template}}', 'README.md']

    # Mock os.listdir
    original_listdir = os.listdir
    os.listdir = lambda _: repo_dir_contents

    # Mock os.path.join
    def mock_join(path, name):
        return '{0}/{1}'.format(path, name)
    original_join = os.path.join
    os.path.join = mock_join

    assert find_template(repo_dir) == '{0}/{1}'.format(repo_dir, '{{cookiecutter.template}}')

    # Restore os.listdir

# Generated at 2022-06-11 20:16:51.257268
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    test_dir = "tests/files/test-repo/"
    assert find_template(test_dir) == "tests/files/test-repo/{{cookiecutter.repo_name}}/"



# Generated at 2022-06-11 20:17:00.110511
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    repo_dir = None

# Generated at 2022-06-11 20:17:00.648835
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-11 20:17:15.580765
# Unit test for function find_template
def test_find_template():
    assert find_template('./tests/fake-repo-pre/') == './tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:17:24.658058
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template function works as expected."""
    from cookiecutter.tests.test_replay import make_replay_func
    from cookiecutter.tests.test_replay import make_replay_file
    from cookiecutter.tests.test_replay import replay

    @replay
    def test_function(tmpdir):
        """Verify that the find_template function works as expected."""
        # Setup a fake cookiecutter.json file
        make_replay_file(
            tmpdir.strpath,
            'cookiecutter.json',
            {
                "cookiecutter": {
                    "repo_dir": "fake-repo"
                }
            }
        )
        os.chdir(tmpdir.strpath)

        # Create a bunch of fake directory contents
        tmp

# Generated at 2022-06-11 20:17:31.389014
# Unit test for function find_template
def test_find_template():
    """Hacky, but effective unit test."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'repos',
        'non-templated-input-dir',
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:17:35.946731
# Unit test for function find_template
def test_find_template():
    """Verify that find_template correctly returns the relative path to a project template"""
    from tests.test_finders import TEST_REPO_DIR

    template_dir = find_template(TEST_REPO_DIR)
    assert template_dir == os.path.join(TEST_REPO_DIR, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:17:39.308161
# Unit test for function find_template
def test_find_template():
    assert find_template('/a/b/c/d/e/f') == '/a/b/c/d/e/f/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:17:47.271155
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import sys
    import os

    # Change the current folder to cookiecutter
    folder = os.path.dirname(os.path.abspath(__file__))
    if folder != 'cookiecutter':
        os.chdir(os.path.dirname(os.path.abspath(__file__)))

    template = find_template('tests/fake-repo-pre/')
    assert os.path.isfile(template)
    assert template.endswith(
        os.path.join('tests', 'fake-repo-pre', 'fake_project', '{{cookiecutter.repo_name}}', 'cookiecutter.json')
    )


# Generated at 2022-06-11 20:17:52.980949
# Unit test for function find_template
def test_find_template():
    root_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(root_dir, 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:17:57.360195
# Unit test for function find_template
def test_find_template():
    input_dir = '/Users/audreyr/GitHub/cookiecutter-pypackage'
    project_template = '/Users/audreyr/GitHub/cookiecutter-pypackage/{{cookiecutter.project_slug}}'
    assert find_template(input_dir) == project_template

# Generated at 2022-06-11 20:18:01.305079
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.expanduser('~/.cookiecutters/yelp-django')
    project_template = find_template(repo_dir)
    assert (
        project_template ==
        '{0}/.cookiecutters/yelp-django/{{cookiecutter.repo_name}}'.format(
            os.path.expanduser('~')
        )
    )
# End unit test

# Generated at 2022-06-11 20:18:01.870054
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:18:32.733172
# Unit test for function find_template
def test_find_template():
    project_dir = os.path.abspath(os.path.join('tests', 'fake-repo-pre'))
    expected_path = os.path.abspath(os.path.join('tests',
                                                 'fake-repo-pre',
                                                 '{{cookiecutter.repo_name}}',
                                                 ))
    assert find_template(project_dir) == expected_path

# Generated at 2022-06-11 20:18:35.797878
# Unit test for function find_template
def test_find_template():
    test_template_dir = 'tests/test-find-template'
    assert find_template(test_template_dir) == os.path.join(test_template_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-11 20:18:38.040685
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-11 20:18:47.875509
# Unit test for function find_template
def test_find_template():
    """Test find template returns the path to a directory with {{ and }}."""
    from cookiecutter.tests.test_find import os_walk
    from cookiecutter.tests.test_find import os_listdir
    from cookiecutter.tests.test_find import join
    import mock

    def mocked_os_walk(root):
        """Walk through a mocked tree of files, return an iterator."""
        return os_walk(root, [
            ('/some/dir', ['subdir1', 'subdir2'], ['some_file.txt']),
            ('/some/dir/subdir1', ['subsubdir1', 'subsubdir2'], ['file1.txt']),
            ])

    def mocked_os_listdir(directory):
        """Mock os_listdir and return a list of files in directory."""


# Generated at 2022-06-11 20:18:51.801121
# Unit test for function find_template
def test_find_template():
    """
    We don't need to know where find_template lives, we can set it as
    a variable. Testing and implementation can then be performed in
    different files (or the same file, if desired)
    """
    import  os
    from cookiecutter.vcs import clone
    find_template = __import__('cookiecutter.find', fromlist=['find_template']).find_template

    # Create a repo to clone
    # Inside that repo, create a child dir that is a template
    # Clone the repo
    # Assert find_template returns a path ending in the child dir
    # Delete the repo

    # Create a repo to clone
    # Inside that repo, create a child dir that is a template
    # Clone the repo
    # Assert find_template returns a path ending in the child dir
    # Delete the repo
    BB

# Generated at 2022-06-11 20:18:57.778147
# Unit test for function find_template
def test_find_template():
	repo_dir = 'https://github.com/audreyr/cookiecutter-pypackage'
	repo_dir_contents = ['cookiecutter-pypackage', 'cookiecutter-pypackage-ej.py']
	assert find_template(repo_dir) == repo_dir_contents

# Generated at 2022-06-11 20:19:03.443384
# Unit test for function find_template
def test_find_template():
    this_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(this_dir, '..', 'non-templated-repo')

    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        return True
    else:
        assert 0, 'No exception raised on non-templated repo.'

# Generated at 2022-06-11 20:19:04.738404
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    pass



# Generated at 2022-06-11 20:19:12.255099
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected"""

    # The directory should be the only project template in this test repo
    TEST_REPO = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..', '..', 'tests', 'test-repo-tmpl',
        )
    )
    assert TEST_REPO.endswith('test-repo-tmpl')
    assert find_template(TEST_REPO) == os.path.join(TEST_REPO, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:19:18.356110
# Unit test for function find_template
def test_find_template():
    assert find_template('~/nathankw/Dev/cookiecutter-pypackage') == '/home/nathankw/Dev/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('~/nathankw/Dev/cookiecutter-pypackage/~/nathankw/Dev/cookiecutter-pypackage') == '~/nathankw/Dev/cookiecutter-pypackage/~/nathankw/Dev/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    
if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:20:23.833587
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fixtures/fake-repo-tmpl'
    find_template(repo_dir)

# Generated at 2022-06-11 20:20:31.357486
# Unit test for function find_template
def test_find_template():
    content_dir_parts = ['cookiecutter-dummy', '{{cookiecutter.repo_name}}']
    content_dir = os.path.sep.join(content_dir_parts)
    content_dir_path = os.path.join(content_dir_parts)
    # Write the mock dir
    with open(content_dir_path, 'w') as fh:
        fh.write('Hi')

    # Get output from the function
    output = find_template(content_dir)

    # Assert function output is the same as our mock
    assert output == content_dir_path

    # Remove the mock dir
    os.remove(content_dir_path)

# Generated at 2022-06-11 20:20:40.573731
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import utils
    from unittest import TestCase

    class Test(TestCase):

        def test_find_template(self):
            repo_dir = os.path.abspath(
                os.path.join(os.path.dirname(__file__), 'cookiecutters', 'fake-repo-tmpl')
            )
            project_template = utils.find_template(repo_dir)
            self.assertTrue(project_template, os.path.join(repo_dir, '{{cookiecutter.project_name}}'))
    
    test = Test()
    test.test_find_template()

# Generated at 2022-06-11 20:20:44.308539
# Unit test for function find_template
def test_find_template():
    """Test that find_template works properly."""
    test_dir = os.path.join('tests', 'test-find-template')

# Generated at 2022-06-11 20:20:53.622589
# Unit test for function find_template
def test_find_template():
    """ Verify that the function find_template works as expected """
    repo_dir = os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, 'tests', 'test-repo-pre')
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert True

    repo_dir = os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, 'tests', 'test-repo-post')
    result = find_template(repo_dir)

# Generated at 2022-06-11 20:21:02.694976
# Unit test for function find_template
def test_find_template():
    """Find the directory with {{cookiecutter.repo_name}}."""
    import random
    import string
    import tempfile

    def _random_string(max_length):
        random_string = ''.join(
            random.choice(string.ascii_uppercase + string.digits)
            for _ in range(max_length)
        )
        return random_string

    repo_dir = tempfile.mkdtemp()

    # Make a child directory that contains the text {{cookiecutter.repo_name}}
    # These must be different to test that find_template finds the correct match

# Generated at 2022-06-11 20:21:07.197062
# Unit test for function find_template
def test_find_template():
    test_repo = '/home/vagrant/git/cookiecutter-pypackage'
    test_result = '/home/vagrant/git/cookiecutter-pypackage/cookiecutter-pypackage'
    assert find_template(test_repo) == test_result

# Generated at 2022-06-11 20:21:09.479673
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template

    This function is tested as part of test_cli.py
    """
    pass

# Generated at 2022-06-11 20:21:09.969091
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:21:14.287895
# Unit test for function find_template
def test_find_template():
    if __name__ == '__main__':
        import tempfile

        tmpdir = tempfile.mkdtemp()
        os.makedirs('%s/{{cookiecutter.project_name}}' % tmpdir)

        return_value = find_template(tmpdir)

        assert return_value == '%s/{{cookiecutter.project_name}}' % tmpdir