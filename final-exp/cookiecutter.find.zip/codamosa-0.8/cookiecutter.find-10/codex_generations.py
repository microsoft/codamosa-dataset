

# Generated at 2022-06-11 20:11:35.630444
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:11:39.335979
# Unit test for function find_template
def test_find_template():
    """
    Function returns the relative path to the project template.
    """
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:11:42.266554
# Unit test for function find_template
def test_find_template():
    assert find_template('./tests/fake-repo-tmpl') == './tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:11:42.864608
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:11:43.844548
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir='my_folder')

# Generated at 2022-06-11 20:11:46.711144
# Unit test for function find_template
def test_find_template():
    directory = 'tests/test-input/fake-repo'
    assert find_template(directory) == 'tests/test-input/fake-repo/simple'

# Generated at 2022-06-11 20:11:51.442855
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake_repo_pre_rendered'
    )

    project_template = find_template(repo_dir)
    assert '/fake_repo_pre_rendered/{{cookiecutter.repo_name}}' == project_template

# Generated at 2022-06-11 20:11:55.079695
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    project_template = find_template(repo_dir)
    expected_result = 'tests/fake-repo-tmpl/fake-project-tmpl'
    assert project_template == expected_result

# Generated at 2022-06-11 20:11:57.891941
# Unit test for function find_template
def test_find_template():
    """Validate the function find_template."""
    assert find_template('test_find_template') == '/home/vagrant/cookiecutter-pypackage-demo/{{cookiecutter.project_name}}'

# Generated at 2022-06-11 20:12:02.282397
# Unit test for function find_template
def test_find_template():
    repo_dir = 'C:\\Users\\user\\git\\cookiecutter-simple-profile'
    template = find_template(repo_dir)
    print ('project template is ', template)
    # test assert
    assert template

if __name__ == '__main__':
    # test_find_template()
    test_find_template()

# Generated at 2022-06-11 20:12:10.160540
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_utils import make_repo
    make_repo(
        'tests/test-find-template/{{cookiecutter.repo_name}}',
        'git@github.com:audreyr/cookiecutter-pypackage.git'
    )
    template_dir = find_template('tests/test-find-template')
    assert template_dir == os.path.abspath('tests/test-find-template/cookiecutter-pypackage')



# Generated at 2022-06-11 20:12:17.620193
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'tests/fake-repo-tmpl-nested/'
    )
    expected_project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}/'
    )

    project_template = find_template(repo_dir)

    assert project_template == expected_project_template

# Generated at 2022-06-11 20:12:18.879856
# Unit test for function find_template
def test_find_template():
    template = find_template(os.getcwd())
    assert type(template) is str

# Generated at 2022-06-11 20:12:23.300276
# Unit test for function find_template
def test_find_template():
    """Tests for find_template."""
    from .context import find_template
    from .compat import TMPDIR

    repo_dir = os.path.join(TMPDIR, 'tests/input-example')
    project_template = find_template(repo_dir)
    assert '{{cookiecutter.repo_name}}' in project_template

# Generated at 2022-06-11 20:12:27.973804
# Unit test for function find_template
def test_find_template():
    logger = logging.getLogger(__name__)
    logger.warning("Running find_template() unit tests.")
    find_template('/Users/wunki/git/cookiecutter-pypackage')
    print("test_find_template() is ok!")

# Generated at 2022-06-11 20:12:30.346378
# Unit test for function find_template
def test_find_template():
    find_template('/Users/mdoescher/Documents/testcookie/cookiecutter-pypackage')

# Generated at 2022-06-11 20:12:35.297515
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests',
                                'fake-repo-tmpl')
    project_template = find_template(template_dir)
    assert project_template.endswith('fake-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:12:40.222400
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template function finds a template dir correctly."""
    from cookiecutter.find import find_template

    tests_dir = 'tests/files/find'
    repo_dir = os.path.join(tests_dir, 'fake-repo-tmpl')
    project_template = os.path.join(repo_dir, 'fake-project-tmpl')

    result = find_template(repo_dir)
    assert result == project_template, 'Did not find the correct template'


# Generated at 2022-06-11 20:12:47.970129
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from unittest import TestCase

    class TestFindTemplate(TestCase):

        def setUp(self):
            self.repo_dir = utils.get_template_dir('cookiecutter-pypackage')

        def test_find_template(self):
            """Test finding the template within the repo dir."""
            result = find_template(self.repo_dir)
            self.assertEqual(result, os.path.join(self.repo_dir, '{{cookiecutter.repo_name}}'))

    return TestFindTemplate

# Generated at 2022-06-11 20:12:54.385659
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    template_dir = '/home/foo/bar'
    repo_dir_contents = [
        'cookiecutter-test',
        'cookiecutter-{{test}}',
        'cookiecutter-{{another_test}}'
    ]
    assert find_template(template_dir, repo_dir_contents) == \
           os.path.join(template_dir, 'cookiecutter-{{test}}')

# Generated at 2022-06-11 20:12:59.774878
# Unit test for function find_template
def test_find_template():
    assert find_template('file/g.cookiecutter-pypackage') == 'g.cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:05.615860
# Unit test for function find_template
def test_find_template():
    """Test for function to find the template directory"""
    assert find_template('tests/fake-repo-templated-project/') == 'tests/fake-repo-templated-project/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-non-templated-project/') == 'tests/fake-repo-non-templated-project/project_name'

# Generated at 2022-06-11 20:13:09.000911
# Unit test for function find_template
def test_find_template():
    """Test to make sure find_template finds the template in repo_dir_contents
    """

# Generated at 2022-06-11 20:13:15.868614
# Unit test for function find_template
def test_find_template():
    """Verify that find_template can find a template with Jinja2."""
    import tempfile
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 20:13:19.317290
# Unit test for function find_template
def test_find_template():
    project_template = find_template("/Users/miguelalba/Documents/cookiecutter-django-rest-framework")
    assert project_template == '/Users/miguelalba/Documents/cookiecutter-django-rest-framework/{{cookiecutter.project_name}}'

# Generated at 2022-06-11 20:13:26.874884
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template`."""
    template_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'test-find-template'
    )
    result = find_template(template_dir)
    assert result == os.path.join(template_dir, 'cookiecutter-{{cookiecutter.repo_name}}'), (
        'find_template did return the expected value'
    )

# Generated at 2022-06-11 20:13:35.259934
# Unit test for function find_template
def test_find_template():
	import tempfile
	import shutil
	from cookiecutter import _find as find
	from cookiecutter import exceptions

	test_template_dir = tempfile.mkdtemp()
	try:
		test_template = os.path.join(test_template_dir, 'project_template')
		os.mkdir(test_template)

		project_template = find.find_template(test_template_dir)
		assert project_template == test_template

	finally:
		shutil.rmtree(test_template_dir)


# Generated at 2022-06-11 20:13:35.829838
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:38.295724
# Unit test for function find_template
def test_find_template():
    """
    Unit test to cover all edge cases in find.find_template
    """
    import tempfile
    assert find_template(tempfile.mkdtemp()) == None



# Generated at 2022-06-11 20:13:46.296413
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils

    input_dir = utils.get_template("tests/fake-repo-pre/{{cookiecutter.repo_name}}")
    output_dir = os.path.join(input_dir, "fake_repo_name")

    # normal operation
    find_template(output_dir)

    shutil.rmtree(output_dir)

    # non-templated input_dir
    input_dir = utils.get_template("tests/fake-repo-no-templ/{{cookiecutter.repo_name}}")
    output_dir = os.path.join(input_dir, "fake_repo_name")

    try:
        find_template(output_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise

# Generated at 2022-06-11 20:14:01.377435
# Unit test for function find_template
def test_find_template():
    """Test that cookiecutter.find_template finds templates correctly."""
    from cookiecutter import find_template
    from cookiecutter import exceptions

    find_template('tests/fake-repo-pre/')
    find_template('tests/fake-repo-pre/{{cookiecutter.repo_name}}/')
    find_template('tests/fake-repo-post/')
    find_template('tests/fake-repo-post/{{cookiecutter.repo_name}}/')

    try:
        find_template('tests/fake-repo-no-cookiecutter-json/')
        assert False, "Expected exception"
    except exceptions.NonTemplatedInputDirException:
        pass

# Generated at 2022-06-11 20:14:04.157471
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo'
    project_template = find_template(repo_dir)
    expected = 'tests/fake-repo/cookiecutter-pypackage'
    assert project_template == expected

# Generated at 2022-06-11 20:14:05.332066
# Unit test for function find_template
def test_find_template():
    pass

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:14:13.698255
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the right string."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'fixtures/fake-repo/'
    )
    returned = os.path.normpath(find_template(repo_dir))
    expected = os.path.normpath(os.path.join(repo_dir, '{{cookiecutter.project_name}}'))

    assert returned == expected

# Generated at 2022-06-11 20:14:22.687684
# Unit test for function find_template
def test_find_template():
    my_repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tests')
    my_project_template = os.path.join(my_repo_dir, '{{cookiecutter.repo_name}}')
    my_repo_dir_contents = os.listdir(my_repo_dir)
    for item in my_repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            my_project_template = os.path.join(my_repo_dir, item)
            break
    assert find_template(my_repo_dir) == my_project_template

# Generated at 2022-06-11 20:14:26.267978
# Unit test for function find_template
def test_find_template():
    repo_dir = "/Users/audreyr/cookiecutter-pypackage"
    project_template = find_template(repo_dir)

# Generated at 2022-06-11 20:14:29.317341
# Unit test for function find_template

# Generated at 2022-06-11 20:14:35.619814
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.dirname(__file__))
    repo_dir = os.path.join(os.getcwd(), '..', '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:14:39.478265
# Unit test for function find_template
def test_find_template():
    '''
    Test find_template function returns correct path
    '''
    repo_dir = '/D/code/cookiecutter/tests/example-repo-templated/'
    project_template = '{{cookiecutter.project_slug}}'
    assert find_template(repo_dir) == \
        os.path.join(repo_dir, project_template)

# Generated at 2022-06-11 20:14:50.538193
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected."""
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_path = utils.find_repo(
        os.path.abspath('tests/fake-repo-pre/'), 'fake-repo-pre',
        False, False
    )
    template_path = find_template(repo_path)
    assert template_path == os.path.abspath('tests/fake-repo-pre/fake-project/')

    repo_without_template = os.path.abspath('tests/fake-repo-post/')
    assert find_template(repo_without_template)

    assert NonTemplatedInputDirException

# Generated at 2022-06-11 20:15:09.798905
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    import tempfile

    path = tempfile.mkdtemp()
    path1 = tempfile.mkdtemp()
    path2 = tempfile.mkdtemp()

# Generated at 2022-06-11 20:15:10.685054
# Unit test for function find_template
def test_find_template():
    # TODO: write this test
    pass



# Generated at 2022-06-11 20:15:13.374658
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/') == 'tests/cookiecutter-pypackage'

# Generated at 2022-06-11 20:15:18.153849
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.abspath('tests/test-input/fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == repo_dir + '/fake-repo-{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:15:18.696783
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:15:27.863110
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the expected result."""
    import tempfile
    import shutil
    import os

    # Setup
    d = tempfile.mkdtemp()
    repo_dir = os.path.join(d, 'repo')
    os.makedirs(repo_dir)
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-foobar'))
    os.makedirs(os.path.join(repo_dir, 'cookiecutter-{{project_name}}'))

    # Test
    project_template = find_template(repo_dir)

    # Verify
    expected_template = os.path.join(
        repo_dir,
        'cookiecutter-{{project_name}}'
    )

    assert project_template == expected

# Generated at 2022-06-11 20:15:29.872267
# Unit test for function find_template
def test_find_template():
    template = find_template('tests/test-find-template')
    assert isinstance(template, str)
    assert 'tests/test-find-template/{{cookiecutter.repo_name}}' in template


# Generated at 2022-06-11 20:15:30.777089
# Unit test for function find_template
def test_find_template():
    pass
    # TODO: Write tests for find_template

# Generated at 2022-06-11 20:15:41.220889
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter import main
    from tempfile import mkdtemp

    context = {
        'repo_name': 'my-repo',
        'project_name': 'Hello World',
        'project_slug': 'hello-world',
        'year': '2013'
    }

    # Create a fake repo with normal and odd characters in the dirname
    repo_dir = mkdtemp()
    repo_name = ''.join(['a-repo-', '{{cookiecutter.repo_name}}'])
    os.mkdir(os.path.join(repo_dir, repo_name))
    cloned_repo_dir = os.path.join(repo_dir, repo_name)


# Generated at 2022-06-11 20:15:42.412357
# Unit test for function find_template
def test_find_template():
    """Test for file: in cloned repo dir."""
    # TODO: Write this test
    pass

# Generated at 2022-06-11 20:16:08.990165
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audrey/projects/cookiecutter-pypackage') == '/home/audrey/projects/cookiecutter-pypackage/{{cookiecutter.pypackage_slug}}'

# Generated at 2022-06-11 20:16:10.271511
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-11 20:16:18.064056
# Unit test for function find_template
def test_find_template():
    """Validate the find_template function."""
    from unittest.mock import patch

    class MockOsListDir(object):
        def __iter__(self):
            yield 'aa_{{cookiecutter.repo_name}}_bb'
            yield 'cc_{{cookiecutter.repo_name}}_dd'

    with patch(
        'cookiecutter.find.os.listdir',
        MockOsListDir(),
        create=True,
    ):
        template_dir = find_template('foo')

    assert template_dir == 'foo/cc_{{cookiecutter.repo_name}}_dd'

# Generated at 2022-06-11 20:16:26.128452
# Unit test for function find_template
def test_find_template():
    os.mkdir('/tmp/inputdir')
    os.mkdir('/tmp/inputdir/{{cookiecutter.dir_name}}')
    os.chdir('/tmp')
    repo_dir = '/tmp/inputdir'
    project_template = find_template(repo_dir)
    assert project_template == '/tmp/inputdir/{{cookiecutter.dir_name}}'
    os.chdir('..')
    os.rmdir('/tmp/inputdir/{{cookiecutter.dir_name}}')
    os.rmdir('/tmp/inputdir')



# Generated at 2022-06-11 20:16:28.833697
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/projects/cookiecutter-pypackage') == '/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:29.336588
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:16:35.715000
# Unit test for function find_template
def test_find_template():
    """Function to test the find_template_function"""

    assert find_template('/home/harold/workspace/cookiecutter/cookiecutter/tests/test-data/hooks_and_templating/') == '/home/harold/workspace/cookiecutter/cookiecutter/tests/test-data/hooks_and_templating/{{cookiecutter.project_name}}'


# Generated at 2022-06-11 20:16:41.376039
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.tests.test_utils import make_bakery_project

    make_bakery_project()
    assert find_template(os.path.join(os.getcwd(), 'bakery')) == os.path.join(os.getcwd(), 'bakery', '{{cookiecutter.repo_name}}')
    shutil.rmtree('bakery')

# Generated at 2022-06-11 20:16:48.122322
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = []
    repo_dir_contents.append('cookiecutter')
    repo_dir_contents.append('{{cookiecutter.project_name}}')
    repo_dir_contents.append('.git')
    repo_dir_contents.append('README.md')
    repo_dir_contents.append('somethingelse')
    repo_dir_contents.append('.gitignore')
    repo_dir = '.'

    p = find_template(repo_dir)
    #logger.debug(p)
    assert p == '{{cookiecutter.project_name}}'

# Generated at 2022-06-11 20:16:58.170131
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() identifies a template directory."""
    from os import path
    from shutil import copy

    from cookiecutter import repo

    def _test(tmpdir):
        """
        :param py.path.local tmpdir: pytest fixture. A
          temporary directory unique to the test invocation.
        """

        dummy_template_dir = 'fake-repo'

        repo_dir = repo.generate_files(tmpdir, dummy_template_dir)
        project_template_dir = path.join(repo_dir, dummy_template_dir)
        copy(path.join(repo_dir, 'tests', 'files', 'fake-repo'),
             project_template_dir)

        actual = repo.find_template(repo_dir)

# Generated at 2022-06-11 20:17:52.981005
# Unit test for function find_template
def test_find_template():
    repo_dir = '/tmp/cookiecutter-test/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert 'cookiecutter-pypackage' in project_template
    assert '_cookiecutter' not in project_template
    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-11 20:18:01.402423
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""
    cookiecutters_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..',
            'tests',
            'test-generate-files'
        )
    )
    root_dir = os.path.dirname(cookiecutters_dir)


# Generated at 2022-06-11 20:18:02.305087
# Unit test for function find_template
def test_find_template():
    test_find_template.assert_called_with()

# Generated at 2022-06-11 20:18:10.108472
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()

    # Create a template
    template_dir = os.path.join(repo_dir, 'fake-project-{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    template = find_template(repo_dir)
    assert template == template_dir

    # Clean up
    shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:18:11.676708
# Unit test for function find_template
def test_find_template():
    """Verify find_template find_template function."""
    pass


# Generated at 2022-06-11 20:18:15.779080
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = 'tests/fake-repo-tmpl'

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-11 20:18:26.002588
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """

    import shutil
    import tempfile
    import unittest

    from cookiecutter.utils import unicode_open

    class TestFindTemplate(unittest.TestCase):

        def setUp(self):
            self.dir_without_template = tempfile.mkdtemp()
            self.dir_with_template = tempfile.mkdtemp()
            self.template_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.dir_without_template)
            shutil.rmtree(self.dir_with_template)
            shutil.rmtree(self.template_dir)


# Generated at 2022-06-11 20:18:27.980447
# Unit test for function find_template
def test_find_template():
    repo_dir = '{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == repo_dir

# Generated at 2022-06-11 20:18:37.181094
# Unit test for function find_template
def test_find_template():
    """Return True if find_template returns the right path, otherwise False."""
    repo_dir = "/Users/audreyr/cookiecutter-pypackage"
    project_template = "/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}"
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)

# Generated at 2022-06-11 20:18:41.500236
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir/'+ os.listdir('repo_dir')[0]
    assert find_template('./tests/test-repo-pre/') == './tests/test-repo-pre/' + os.listdir('./tests/test-repo-pre/')[0]

# Generated at 2022-06-11 20:20:51.068451
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template`."""
    import os
    import shutil
    import tempfile
    from cookiecutter.generate import find_template

    project_template = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_template',
    )

    # Make a copy of template repo and look for the template
    repo_dir = tempfile.mkdtemp()
    shutil.copytree(project_template, repo_dir)
    template_dir = find_template(repo_dir)

    # Verify we found the right template
    expected_result = os.path.join(repo_dir, '{{ cookiecutter.repo_name }}')
    assert os.path.exists(expected_result)

# Generated at 2022-06-11 20:21:01.553422
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    empty_dir = tempfile.mkdtemp()
    templated_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(templated_dir, '{{ cookiecutter.repo_name }}'))

    try:
        find_template(empty_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError('NonTemplatedInputDirException not raised')

    try:
        assert(find_template(templated_dir) ==
               os.path.join(templated_dir, '{{ cookiecutter.repo_name }}'))
    finally:
        shutil.rmtree(empty_dir)

# Generated at 2022-06-11 20:21:12.154527
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the expected path in the expected cases."""
    import os
    import shutil
    import tempfile

    def touch(path):
        """Create empty file at `path`."""
        open(path, 'a').close()

    repo_dir = tempfile.mkdtemp()

    project_template = tempfile.mkdtemp(dir=repo_dir)
    touch(os.path.join(project_template, 'cookiecutter.json'))

    non_templated_dir = tempfile.mkdtemp(dir=repo_dir)
    touch(os.path.join(non_templated_dir, 'cookiecutter.json'))

    # The real test
    assert project_template == find_template(repo_dir)

    # Clean up
    shutil.r

# Generated at 2022-06-11 20:21:17.620050
# Unit test for function find_template
def test_find_template():
    from cookiecutter.prompt import read_user_yes_no
    from cookiecutter.main import cookiecutter

    project_name = 'example'

    # Create a fake cookiecutter.json file in the project directory
    # so that the test doesn't throw a KeyError from reading the json file

# Generated at 2022-06-11 20:21:25.101787
# Unit test for function find_template
def test_find_template():
    """Verify that we can find the template in a cookiecutter project."""
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(temp_dir, '{{cookiecutter.repo_name}}'))

    template_dir = find_template(temp_dir)

    assert template_dir == os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    shutil.rmtree(temp_dir)

# Generated at 2022-06-11 20:21:31.460885
# Unit test for function find_template
def test_find_template():
    """Test for find_template function"""
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-11 20:21:31.871067
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-11 20:21:41.645611
# Unit test for function find_template
def test_find_template():
    """Unit test for tempalte finding."""
    from cookiecutter.tests.test_utils.output import no_log_messages

    assert find_template(
        os.path.join('tests', 'test-templates', 'tests-cookiecutter-py')
    ) == os.path.join('tests', 'test-templates', 'tests-cookiecutter-py', '{{cookiecutter.repo_name}}')

    with no_log_messages(logger):
        assert find_template(
            os.path.join('tests', 'test-repo')
        ) == os.path.join('tests', 'test-repo', 'tests-cookiecutter')