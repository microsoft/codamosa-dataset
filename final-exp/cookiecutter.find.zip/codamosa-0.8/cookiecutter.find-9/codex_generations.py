

# Generated at 2022-06-11 20:11:42.228783
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    curdir = os.path.dirname(os.path.abspath(__file__))
    here = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(here, "tests/test-input")

    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:11:48.701266
# Unit test for function find_template
def test_find_template():
    repo_dir = 'fake-repo-dir'
    repo_dir_contents = ['fake_dir', 'another_dir', '{{cookiecutter.project_name}}']

    os.path.isfile = lambda x: False
    os.listdir = lambda x: repo_dir_contents

    expected_project_template = 'fake-repo-dir/{{cookiecutter.project_name}}'
    assert(find_template(repo_dir) == expected_project_template)

# Generated at 2022-06-11 20:11:54.893215
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the expected path."""

    tmp_dir_contents = ['_ignored_file.txt',
                        'cookiecutter-xxx-{{cookiecutter.repo_name}}',
                        'cookiecutter-yyy-{{cookiecutter.repo_name}}',
                        'cookiecutter-zzz-{{cookiecutter.repo_name}}']

    def mock_listdir(path):
        del path
        return tmp_dir_contents

    expected_template_path = os.path.join(
        'tests/fake-repo-tmpl',
        tmp_dir_contents[1]
    )
    with monkeypatch_function(os, 'listdir', mock_listdir):
        assert find_template('tests/fake-repo-tmpl') == expected_template_path

# Generated at 2022-06-11 20:11:55.720872
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:11:57.925843
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    with pytest.raises(NonTemplatedInputDirException):
        find_template('tests')

# Generated at 2022-06-11 20:12:01.957076
# Unit test for function find_template
def test_find_template():
    """ Verifies that find_template returns the correct directory """
    repo_dir = '/home/vagrant/vagrant-test-env/test-repo'
    project_template = 'test-repo-master/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:12:11.486758
# Unit test for function find_template
def test_find_template():
    """Verify that `find_template` finds the template directory."""
    import inspect
    import pytest
    from cookiecutter import utils
    from cookiecutter import exceptions

    input_dir = os.path.join(
        os.path.dirname(os.path.abspath(inspect.getfile(utils))),
        'tests/test-repo/{{cookiecutter.repo_name}}',
    )

    output_dir = os.path.join(
        os.path.dirname(os.path.abspath(inspect.getfile(exceptions))),
        'tests/fake-repo-pre/{{cookiecutter.repo_name}}',
    )

    assert input_dir == find_template(input_dir)

# Generated at 2022-06-11 20:12:15.262641
# Unit test for function find_template
def test_find_template():
    """Test file

    :returns: Nothing

    """
    input_path = 'tests/fake-repo-pre/'
    result = find_template(input_path)
    assert result == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:20.092746
# Unit test for function find_template
def test_find_template():
    normalized_path = os.path.normpath(__file__)
    repo_dir = os.path.dirname(os.path.dirname(normalized_path))
    project_template = find_template(repo_dir)
    expected_template = 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert os.path.exists(project_template)
    assert os.path.basename(project_template) == expected_template

# Generated at 2022-06-11 20:12:24.990312
# Unit test for function find_template
def test_find_template():
    """Test find_template with a template that is found."""
    from cookiecutter import main
    from cookiecutter.exceptions import NonTemplatedInputDirException

    dir_template = main.cookiecutter('tests/fake-repo-templated/', no_input=True)
    assert dir_template == 'fake-project-name', 'The template is not found'



# Generated at 2022-06-11 20:12:37.401707
# Unit test for function find_template
def test_find_template():
    """Verify correct operation of the find_template function."""

    # Use real dirs with known templates
    real_dir = "C:\\Users\\bjwil\\Desktop\\python_path\\cookiecutter-pypackage-minimal"
    real_template = os.path.join(real_dir, '{{project_name}}')
    assert os.path.exists(real_template)
    assert find_template(real_dir) == real_template

    # Use made-up dirs with known templates
    fake_dir = 'c:\\fake\\path\\cookiecutter-pypackage-minimal'
    fake_template = os.path.join(fake_dir, '{{project_name}}')
    assert not os.path.exists(fake_template)
    assert find_template(fake_dir) == fake

# Generated at 2022-06-11 20:12:43.455595
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function."""
    from os import path
    from cookiecutter import utils

    tests_dir = path.abspath(path.dirname(path.dirname(__file__)))
    fixtures_dir = path.join(tests_dir, 'fixtures')
    repo_dir = path.join(fixtures_dir, 'fake-repo-tmpl')
    project_dir = path.join(fixtures_dir, 'fake-repo-pre-gen')

    result = utils.find_template(repo_dir)
    assert result == path.join(repo_dir, '{{cookiecutter.repo_name}}')

    result = utils.find_template(project_dir)
    assert result == project_dir

# Functions for handling of `cookiecutter.json`


# Generated at 2022-06-11 20:12:48.144727
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo', 'input'
    )
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:12:52.673029
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    repo_dir = "../cookiecutter-django-jmbo"
    assert find_template(repo_dir) == "../cookiecutter-django-jmbo/jmbo-project"

# Generated at 2022-06-11 20:12:53.327097
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:02.545848
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.utils import rmtree

    from .test_utils import TEST_TEMPLATES_DIR

    tmp_test_templates_dir = tempfile.mkdtemp()
    rmtree(tmp_test_templates_dir)  # make sure it doesn't exist
    test_templates_dir = os.path.join(TEST_TEMPLATES_DIR, '..')
    # Copy the test template directory to a temporary location to test
    # the function
    os.system(
        'cp -a {} {}'.format(
            test_templates_dir,
            tmp_test_templates_dir
        )
    )


# Generated at 2022-06-11 20:13:03.349639
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:07.854983
# Unit test for function find_template
def test_find_template():
    """Find template_python directory under fixtures directory."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', 'fixtures', 'fake-repo-pre'
    ))
    expected_template = os.path.join(repo_dir, 'template_python')

    template = find_template(repo_dir)
    assert template == expected_template

# Generated at 2022-06-11 20:13:10.616439
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:13:15.433885
# Unit test for function find_template
def test_find_template():
    """Verify that we can find the template in a new project."""
    test_path = os.path.join('tests', 'input', 'fake-repo')
    project_template = find_template(test_path)
    expected_path = os.path.join(test_path, 'fake', '{{cookiecutter.project_slug}}')
    assert project_template == expected_path

# Generated at 2022-06-11 20:13:27.290984
# Unit test for function find_template
def test_find_template():
    path = "/Users/mac/Desktop/test/"

    repo_dir_contents = os.listdir(path)

# Generated at 2022-06-11 20:13:33.249056
# Unit test for function find_template
def test_find_template():
# def find_template(repo_dir):
    """Determine which child directory of `repo_dir` is the project template.
    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    import os.path
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:13:37.602348
# Unit test for function find_template
def test_find_template():
    testdir = os.path.dirname(__file__)
    test_input = os.path.join(testdir, "fake-repo-pre-gen")

    outdir = find_template(test_input)
    assert outdir == os.path.join(test_input, "cookiecutter-pypackage")

# Generated at 2022-06-11 20:13:40.048546
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the correct path to the project template.
    """
    pass

# Generated at 2022-06-11 20:13:45.088161
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    msg = 'Searching {0} for the project template.'
    msg = msg.format('tests/fake-repo-pre/')
    assert find_template('tests/fake-repo-pre') == 'tests/fake-repo-pre/{{ cookiecutter.repo_name }}'
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{ cookiecutter.repo_name }}'

# Generated at 2022-06-11 20:13:52.437818
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    assert find_template('tests/fake-repo-pre') == 'tests/fake-repo-pre/cookiecutter-pypackage'

    try:
        find_template('tests/fake-repo-no-template')
    except NonTemplatedInputDirException:
        pass

    try:
        find_template('tests/fake-repo-too-many-templates')
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-11 20:13:57.866112
# Unit test for function find_template
def test_find_template():
    from . import context
    from .generate import generate_files
    from .main import cookiecutter
    from .prompt import prompt_for_config
    from .utils import rmtree


# Generated at 2022-06-11 20:14:00.420778
# Unit test for function find_template
def test_find_template():
    test_repo = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests', 'fake-repo')
    assert find_template(test_repo) == os.path.join(test_repo, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:14:03.934878
# Unit test for function find_template
def test_find_template():
    """
    Test for find template.
    """
    from cookiecutter.tests.test_find import FIXTURES
    assert find_template(FIXTURES) == os.path.join(
        FIXTURES, 'cookiecutter-pypackage-master'
    )

# Generated at 2022-06-11 20:14:11.785698
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template function returns the correct path to the project template."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo'))
    path_to_template = find_template(repo_dir)
    correct_path = os.path.join(repo_dir, 'cookiecutter-pypackage')
    assert path_to_template == correct_path

# Generated at 2022-06-11 20:14:23.562794
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-generator-repo'))
    project_template = os.path.abspath(os.path.join(repo_dir, '{{ cookiecutter.repo_name }}'))
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:14:32.780419
# Unit test for function find_template
def test_find_template():
    from .test_files import chdir_fixture_path
    from .test_files import find_template_fixture

    project_template = find_template(find_template_fixture('test_find_template'))
    assert project_template == os.path.join(find_template_fixture('test_find_template'), '_project_template')
    assert os.path.isfile(os.path.join(project_template, 'hello_world.txt'))
    assert os.path.isfile(os.path.join(project_template, 'cookiecutter.json'))

# Generated at 2022-06-11 20:14:40.171282
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    # Templates can be in subdirectories
    assert find_template('tests/input/fake-repo-tmpl') == 'tests/input/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    # The template dir must contain {{cookiecutter.something}}
    assert find_template('tests/input/fake-repo-pre') is None

    # The template dir can contain nested templates
    assert find_template('tests/input/fake-repo-post') == 'tests/input/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:42.007779
# Unit test for function find_template
def test_find_template():
    output = find_template('/Users/yuvipanda/Sites/cookiecutter-pypackage')

# Generated at 2022-06-11 20:14:42.954974
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:47.617098
# Unit test for function find_template
def test_find_template():
    assert find_template(r'C:\Users\Glyn\PycharmProjects\cookiecutter\tests\test-repo-pre') ==  r'C:\Users\Glyn\PycharmProjects\cookiecutter\tests\test-repo-pre\cookiecutter-pypackage'

# Generated at 2022-06-11 20:14:50.855734
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.main import cookiecutter

    # Create a template from a simple session
    cookiecutter('tests/test-data/simple-repo-tmpl', no_input=True)

    # Check that function find_template() can find the template
    repo_dir = 'tests/test-data/simple-repo-tmpl'
    assert os.path.join(repo_dir, 'simple-repo-tmpl') == find_template(repo_dir)

    # Clean up
    shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:14:51.389733
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:52.359437
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir)

# Generated at 2022-06-11 20:14:53.857011
# Unit test for function find_template
def test_find_template():
    #TODO: implement test
    pass

# Generated at 2022-06-11 20:15:10.549924
# Unit test for function find_template
def test_find_template():
    """
    Test for the find_template function.
    """
    from cookiecutter.main import cookiecutter

    # Create a new project from an empty template
    empty_repo = cookiecutter('tests/test-empty-repo', no_input=True)

    # Find the cookiecutter.json file in the repo
    project_template = find_template(empty_repo)

    assert project_template == os.path.join(empty_repo, 'cookiecutter.json')

# Generated at 2022-06-11 20:15:21.800557
# Unit test for function find_template
def test_find_template():
    """Verify find_template() correctly identifies the project template."""
    import shutil
    import tempfile

    # Create a temporary directory and get its absolute path.
    repo_dir = tempfile.mkdtemp()

    # Create 5 files in the temp directory.
    default_project_dir = os.path.join(repo_dir, 'cookiecutter-pypackage')
    os.makedirs(default_project_dir)

    alternate_project_dir = os.path.join(repo_dir, 'cookiecutter-djangopackage')
    os.makedirs(alternate_project_dir)

    # This is the one we want to find.
    test_project_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.maked

# Generated at 2022-06-11 20:15:22.379028
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:15:25.817321
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', '..', 'tests', 'test-find-template', 'repo'
    )

    find_template(repo_dir)

# Generated at 2022-06-11 20:15:30.914822
# Unit test for function find_template
def test_find_template():
    """Verify the expected project template is found."""
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, '{{cookiecutter.repo_name}}'))
        os.makedirs(os.path.join(tmpdir, 'not_a_template'))

        result = find_template(tmpdir)
        assert(result == os.path.join(tmpdir, '{{cookiecutter.repo_name}}'))



# Generated at 2022-06-11 20:15:41.326197
# Unit test for function find_template
def test_find_template():

    test_args = [
        ('https://github.com/audreyr/cookiecutter-pypackage.git',
         'cookiecutter-pypackage',
         'cookiecutter-{{cookiecutter.repo_name}}'),
        ('https://github.com/kennethreitz/pip-tools.git',
         'pip-tools',
         'pip-tools'),
        ('https://github.com/nvie/cookiecutter-pypackage.git',
         'cookiecutter-pypackage',
         'cookiecutter-{{cookiecutter.repo_name}}'),
        ('https://github.com/sloria/cookiecutter-flask.git',
         'cookiecutter-flask',
         'cookiecutter-flask'),
    ]

    c

# Generated at 2022-06-11 20:15:47.142019
# Unit test for function find_template
def test_find_template():
    """Test the find_template function.
    """
    # Test directory
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'fake-repo'
    )

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:15:50.507186
# Unit test for function find_template
def test_find_template():
    expected_return = "tests/test_dir/{{cookiecutter.dir_name}}"
    assert find_template("tests/test_dir") == expected_return

# Generated at 2022-06-11 20:15:57.683194
# Unit test for function find_template
def test_find_template():
    """
    Verify find_template function.
    """
    # set directory to test dir
    os.chdir('tests')

    # test unexpanded dir
    repo_dir = 'tests/fake-repo-templated'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-templated/{{cookiecutter.repo_name}}'

    repo_dir = 'tests/fake-repo-unexpected'
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-11 20:15:59.771137
# Unit test for function find_template
def test_find_template():
    """Func: find_template test"""
    
    print("find_template is tested")

# Generated at 2022-06-11 20:16:31.731501
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() correctly determines which child
    directory is the project template.
    """
    import tempfile

    # Create a temporary working directory
    workdir = tempfile.mkdtemp()

    # Create two child directories and a file
    template = 'cookiecutter-{{cookiecutter.repo_name}}'
    templated_dir = os.path.join(workdir, template)
    os.makedirs(templated_dir)
    untemplated_dir = os.path.join(workdir, 'cookiecutter-foobar')
    os.makedirs(untemplated_dir)
    file_in_root_dir = 'README.md'

# Generated at 2022-06-11 20:16:35.390072
# Unit test for function find_template
def test_find_template():
    """Test finding project template."""
    assert find_template('testing/fake-repo-pre/') == \
        'testing/fake-repo-pre/{{cookiecutter.project_name}}'


# Generated at 2022-06-11 20:16:43.403721
# Unit test for function find_template
def test_find_template():
    """
    Unit tests for function find_template
    """
    repo_dir = os.path.join(os.path.dirname(__file__), 'test-find-template')

    assert 'test-find-template' in find_template(repo_dir)

    try:
        find_template(repo_dir=os.path.join(repo_dir, 'test-find-template'))
    except NonTemplatedInputDirException:
        return
    else:
        raise AssertionError


# Generated at 2022-06-11 20:16:45.001698
# Unit test for function find_template
def test_find_template():
    """Test the function that determines which child directory is the template."""
    pass

# Generated at 2022-06-11 20:16:50.641513
# Unit test for function find_template
def test_find_template():
    """
    Should return 'my_template'
    """
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-pre'))
    assert find_template(repo_dir) == os.path.join(repo_dir, 'my_template')

# Generated at 2022-06-11 20:16:54.029571
# Unit test for function find_template
def test_find_template():
    path = find_template('tests/fake-repo-pre/')
    assert path == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:56.133667
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/sample-repo/') == 'tests/sample-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:58.510758
# Unit test for function find_template
def test_find_template():
    """Test whether find_template finds the project template."""
    pass

# Generated at 2022-06-11 20:17:01.168272
# Unit test for function find_template
def test_find_template():
    from tests.bin import create_fake_repo
    from tests.fixtures import empty_repo

    create_fake_repo.clone()

    find_template(empty_repo.working_dir)

# Generated at 2022-06-11 20:17:10.276229
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    import shutil
    import os
    import logging

    logger = logging.getLogger(__name__)

    # Create a fake cookiecutter python package
    result = cookiecutter('tests/fake-repo-tmpl')

    # Test the results
    assert os.path.isdir(result['cookiecutter']['fake_repo_dir']) == True
    assert os.path.isdir(
        result['cookiecutter']['fake_repo_dir'] + '/fake_project_dir'
    ) == True
    assert os.path.isfile(
        result['cookiecutter']['fake_repo_dir'] + '/fake_project_dir/file.txt'
    ) == True

# Generated at 2022-06-11 20:18:10.477981
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from .compat import patch, mock_open, MagicMock
    from .vendor import mock

    repo_dir = '/home/audreyr/PycharmProjects/my-awesome-cookiecutter-template/'

    with patch('cookiecutter.utils.find_template.os.listdir', new=MagicMock(return_value=['my_awesome_project', 'cookiecutter.json', 'README.md'])) as mock_listdir:
        project_template = find_template(repo_dir)

    assert project_template == '/home/audreyr/PycharmProjects/my-awesome-cookiecutter-template/my_awesome_project'
    assert mock_listdir.called


# Generated at 2022-06-11 20:18:15.774453
# Unit test for function find_template
def test_find_template():
    """Test that function `find_template` works as expected."""
    from cookiecutter import main
    from .utils import work_in

    main.cookiecutter('tests/fake-repo-tmpl')

    with work_in('fake-repo'):
        template_dir = find_template('.')
        assert 'fake-repo' in template_dir
        assert 'fake-repo-tmpl' in template_dir

# Generated at 2022-06-11 20:18:18.176012
# Unit test for function find_template
def test_find_template():
    find_template('/Users/Audrey/github/cookiecutter-pypackage')


# Generated at 2022-06-11 20:18:24.152866
# Unit test for function find_template
def test_find_template():
    """Verify ``find_template`` works correctly."""
    warnings.simplefilter('ignore')

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test-repo'
    )

    assert find_template(repo_dir) == \
        os.path.join(repo_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-11 20:18:29.151683
# Unit test for function find_template
def test_find_template():
    """
    Unit test for find_template function.
    """
    from cookiecutter import find
    import shutil
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Setup
    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'fake-repo')
    repo_dir_cookiecutter = os.path.join(repo_dir, 'cookiecutter-fake')
    os.mkdir(repo_dir)
    os.mkdir(repo_dir_cookiecutter)

    # Execute
    project_template = find.find_template(repo_dir)

    # Test

# Generated at 2022-06-11 20:18:35.227617
# Unit test for function find_template
def test_find_template():
    """Test the find_template function"""
    path = os.path.dirname(os.path.abspath(__file__))
    test_path = os.path.abspath(os.path.join(path, 'tests', 'fake-repo-pre'))
    assert find_template(test_path) == os.path.abspath(os.path.join(path, 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-11 20:18:39.448484
# Unit test for function find_template
def test_find_template():
    """Verify template name is returned."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'fake', 'template'
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:18:41.147310
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter/tests/test-repo-pre/') == 'cookiecutter/tests/test-repo-pre/_cookiecutter'
    assert find_template('cookiecutter/tests/test-repo-post/') == 'cookiecutter/tests/test-repo-post/_cookiecutter'

# Generated at 2022-06-11 20:18:50.816536
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from nose.tools import assert_equal, assert_raises
    from cookiecutter.exceptions import NonTemplatedInputDirException
    repo_dir = os.path.join(
        os.path.dirname(utils.__file__), '..', 'tests', 'fake-repo-tmpl'
    )
    project_template = os.path.join(repo_dir, 'my-fake-project')

    result = find_template(repo_dir)
    assert_equal(result, project_template)

    repo_dir = os.path.join(
        os.path.dirname(utils.__file__), '..', 'tests', 'fake-repo-prefixed'
    )

# Generated at 2022-06-11 20:18:57.273801
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    # Make a temp dir
    temp_dir = tempfile.mkdtemp()

    # Make a couple test directories
    cookiecutter_json = os.path.join(temp_dir, 'cookiecutter.json')
    shutil.copy('tests/files/fake-repo-pre/cookiecutter.json', cookiecutter_json)
    os.mkdir(os.path.join(temp_dir, 'foo'))
    os.mkdir(os.path.join(temp_dir, 'bar'))

    # Should find 'foo'
    assert find_template(temp_dir) == os.path.join(temp_dir, 'foo')

    # Clean up
    shutil.rmtree(temp_dir)



# Generated at 2022-06-11 20:21:04.096572
# Unit test for function find_template
def test_find_template():
    """Test template finder with a fake Git repo."""
    # TODO: test no project template found

    # The end result of running Cookiecutter on this repo should be a
    # 'fake_project' template with a bunch of random junk in it.
    repo_dir = '/Users/audreyr/Development/cookiecutter-development/tests/test-repos/fake-repo.git'
    template_name = find_template(repo_dir)
    assert '/Users/audreyr/Development/cookiecutter-development/tests/test-repos/fake-repo.git/fake_project' == template_name

# Generated at 2022-06-11 20:21:11.349308
# Unit test for function find_template
def test_find_template():
    """Test function find_template()"""
    assert find_template('/Users/audreyr/code/cookiecutter-pypackage')=='/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    #assert find_template('/Users/audreyr/code/cookiecutter-pypackage')=='/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:21:14.959943
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    assert find_template('/Users/danielbok/cookiecutter-django/cookiecutter-django/tests/fake-repo/') == '/Users/danielbok/cookiecutter-django/cookiecutter-django/tests/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:21:20.033820
# Unit test for function find_template
def test_find_template():
    os.chdir(os.path.abspath(os.path.dirname(__file__)))
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    assert find_template(repo_dir) == os.path.join(repo_dir, 'fake-project-tmpl')

# Generated at 2022-06-11 20:21:27.281826
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.main import cookiecutter

    temp_dir = tempfile.mkdtemp()
    test_repo = 'tests/test-repo-pre/'
    cookiecutter(test_repo, no_input=True, output_dir=temp_dir)

    repo_dir = temp_dir
    project_template = find_template(repo_dir)

    assert os.path.isdir(project_template)
    assert 'cookiecutter-pypackage' in project_template

# Generated at 2022-06-11 20:21:30.122830
# Unit test for function find_template
def test_find_template():
    """Test that the function finds a directory that is named like a project template."""
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/cookiecutter-pypackage/'


# Generated at 2022-06-11 20:21:37.441919
# Unit test for function find_template
def test_find_template():
    """Test if find_template(repo_dir) returns the correct dir"""
    template_dir = 'cookiecutter-pypackage'
    context = {'_template': template_dir}
    project_dir = template_dir.replace('cookiecutter',
                                       '{{cookiecutter.repo_name}}')
    repo_dir = os.path.join(os.path.dirname(__file__),
                            'fake-repo',
                            project_dir)
    template_dir = os.path.join(repo_dir, template_dir)
    assert find_template(repo_dir) == template_dir