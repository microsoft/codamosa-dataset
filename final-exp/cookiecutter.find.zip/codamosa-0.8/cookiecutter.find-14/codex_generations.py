

# Generated at 2022-06-11 20:11:36.524890
# Unit test for function find_template

# Generated at 2022-06-11 20:11:40.927334
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/aurooba/gitrepos/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/aurooba/gitrepos/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

# Generated at 2022-06-11 20:11:51.323439
# Unit test for function find_template
def test_find_template():
    """Evaluates function find_template's return value on a mock repo."""
    import cookiecutter.main
    import tempfile
    import py
    from click.testing import CliRunner

    cookiecutter_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    repo_dir = cookiecutter.main.clone(cookiecutter_url)
    project_template = find_template(repo_dir)

#     # Mock repo's project template appears to be
#     # '/private/var/folders/2z/b83t0dmn7cngn0mv4mz7q3q40000gn/T/tmpnhZPOi/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
#     assert project_template ==

# Generated at 2022-06-11 20:11:58.701122
# Unit test for function find_template
def test_find_template():
    # Mock a repo_dir directory
    repo_dir = '/User/audreyr/cookiecutters/cookiecutter-pypackage'
    # Mock contents
    mock_repo_dir_contents = ['cookiecutter', 'cookiecutter-tests']
    os.listdir.return_value = mock_repo_dir_contents

    # Find the project template
    find_template(repo_dir)

    # Check that the right functions were called
    os.listdir.assert_called_once_with('/User/audreyr/cookiecutters/cookiecutter-pypackage')
    assert os.path.join.called == False

# Generated at 2022-06-11 20:12:02.555680
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-11 20:12:08.222946
# Unit test for function find_template
def test_find_template():
    """Unit tests for function find_template."""
    import cookiecutter.tests.fake_repo

    template = find_template(cookiecutter.tests.fake_repo.fake_repo_dir)

    assert template == os.path.join(cookiecutter.tests.fake_repo.fake_repo_dir,
                                    '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:12:11.295310
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:12.726703
# Unit test for function find_template
def test_find_template():
    """
    Tests the find_template() function.
    """
    pass

# Generated at 2022-06-11 20:12:16.500040
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    assert find_template('tests/test-dir-pre/fake-repo-tmpl/') == 'tests/test-dir-pre/fake-repo-tmpl/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:12:17.078256
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:12:26.470484
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException
    def create_repo_dir():
        tmp_dir = tempfile.mkdtemp() + '/'
        os.mkdir(tmp_dir + '{{cookiecutter.repo_name}}')
        return tmp_dir
    template = find_template(create_repo_dir())
    assert template == '{{cookiecutter.repo_name}}'

    try:
        find_template(tempfile.mkdtemp() + '/')
    except NonTemplatedInputDirException:
        assert True



# Generated at 2022-06-11 20:12:37.358538
# Unit test for function find_template
def test_find_template():
    """Validate find_template function given a consistent set of inputs."""
    set_of_files = set([
        'home',
        'home/username/my_repo',
        'home/username/my_repo/README.rst',
        'home/username/my_repo/repo_name',
        'home/username/my_repo/repo_name/repo_name',
        'home/username/my_repo/repo_name/README.rst'
    ])
    repo_name = 'repo_name'
    base_dir = os.path.join('home', 'username', 'my_repo')
    repo_dir = os.path.join(base_dir, repo_name)

# Generated at 2022-06-11 20:12:42.143750
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    # TODO(audreyr): this needs to be mocked out (but be a real directory)
    repo_dir = '~/code/cookiecutter.git'
    project_template = find_template(repo_dir)

    assert repo_dir in project_template

# Generated at 2022-06-11 20:12:50.087813
# Unit test for function find_template
def test_find_template():
    """
    Do a basic test of find_template to make sure it can find the project template.
    :return:
    """
    import os
    import shutil
    import tempfile
    logger.debug('Testing find_template')

    # create a temporary directory
    repo_dir = tempfile.mkdtemp()
    test_template_path = os.path.join(repo_dir, 'cookiecutter-test')
    os.makedirs(test_template_path)
    logger.debug('Testing finding the project template from repo_dir: %s', repo_dir)
    logger.debug('Test template: %s', test_template_path)
    assert find_template(repo_dir) == test_template_path
    shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:13:00.721722
# Unit test for function find_template
def test_find_template():
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.prompt import read_user_choice
    from cookiecutter import utils
    from unittest.mock import patch, call
    import tempfile
    import shutil

    test_template_dir = 'tests/test-template'
    test_template_output_dir = 'tests/'

    # Test positive case
    template_repo_dir = tempfile.mkdtemp()
    shutil.copytree(test_template_dir, template_repo_dir)
    project_template = find_template(template_repo_dir)
    assert project_template.endswith('tests/test-template/cookiecutter-{{cookiecutter.repo_name}}')

    # Test NonTemplatedInputDirException
    test_template_dir

# Generated at 2022-06-11 20:13:01.458304
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:03.890558
# Unit test for function find_template
def test_find_template():
    assert find_template('./fake-repo-tmpl') == './fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:05.235845
# Unit test for function find_template
def test_find_template():
    # TODO: find_template is indirectly tested in test_replay.py
    pass

# Generated at 2022-06-11 20:13:14.529013
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.expanduser(
        '~/Development/test-projects/test-project-template'
    )

    project_template = find_template(repo_dir)

    assert project_template == os.path.expanduser(
        '~/Development/test-projects/test-project-template/{{cookiecutter.repo_name}}'
    )

    # Test non-templated directory
    repo_dir_contents = os.listdir(repo_dir)
    for item in repo_dir_contents:
        os.rename(
            os.path.join(repo_dir, item),
            os.path.join(repo_dir, 'not_a_template_directory')
        )


# Generated at 2022-06-11 20:13:18.050133
# Unit test for function find_template
def test_find_template():
    """Check that the proper template is found."""
    repo_dir = "/home/pinterest/cookiecutter-pypackage"
    project_template = "/home/pinterest/cookiecutter-pypackage/{{cookiecutter.repo_name}}"

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:13:25.577010
# Unit test for function find_template
def test_find_template():
    actual = find_template('.')
    expected = os.path.abspath(os.path.join('tests/test-repo-pre', '{{cookiecutter.repo_name}}'))
    assert(actual == expected)



# Generated at 2022-06-11 20:13:26.145189
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:29.416689
# Unit test for function find_template
def test_find_template():
    dir = os.path.join('tests', 'test-find-template')
    template = find_template(dir)
    assert template
    assert 'cookiecutter' in template
    assert '{{' in template
    assert '}}' in template
    assert 'pytest' in template

# Generated at 2022-06-11 20:13:32.930286
# Unit test for function find_template
def test_find_template():
    if os.path.isdir('tests/sample_project/{{cookiecutter.repo_name}}'):
        assert find_template('tests/sample_project') == 'tests/sample_project/{{cookiecutter.repo_name}}'
    else:
        assert find_template('tests/sample_project') == 'tests/sample_project/sample_project'


# Generated at 2022-06-11 20:13:35.566920
# Unit test for function find_template
def test_find_template():
	templates = find_template("..\\..\\_test-repo-templates\\test")
	print(templates)
	assert(templates != None)


# Generated at 2022-06-11 20:13:39.086791
# Unit test for function find_template
def test_find_template():
    """Verify functionality of find_template()."""
    find_template('/some/path/to/repo')
    try:
        find_template('')
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-11 20:13:43.585329
# Unit test for function find_template
def test_find_template():
    """Assert if cookiecutter starter project template is correctly found."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'cookiecutters',
        'cookiecutter-pypackage',
    )
    project_template = find_template(repo_dir)

    assert project_template == repo_dir

# Generated at 2022-06-11 20:13:54.811198
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    path = os.path.join(os.path.dirname(utils.__file__), 'fake-repo')
    project_template = find_template(path)

    assert project_template == os.path.join(path, '{{cookiecutter.repo_name}}'), \
        'Should find the project template.'

    path = os.path.join(os.path.dirname(utils.__file__), 'fake-repo-without-jinja')
    try:
        find_template(path)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'Should raise exception for non-templated input dir.'


# Generated at 2022-06-11 20:14:00.955504
# Unit test for function find_template
def test_find_template():
    """Test for find_template"""
    test_repo = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..', 'tests', 'fake-repo', 'input'
    )
    expected_path = os.path.join(test_repo, 'cookiecutter_{{cookiecutter.project_slug}}')
    test_path = find_template(test_repo)
    assert test_path == expected_path

# Generated at 2022-06-11 20:14:06.015462
# Unit test for function find_template
def test_find_template():
    """Return the relative path to the project template, given a copy of a
    repo that contains a project template.
    """
    tests_dir = os.path.abspath(os.path.dirname(__file__))
    fixtures_dir = os.path.join(tests_dir, 'fixtures')
    repo_dir = os.path.join(fixtures_dir, 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'foobar')



# Generated at 2022-06-11 20:14:17.922633
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works."""
    repo_dir = 'tests/test-find-template-repo'
    os.chdir(repo_dir)
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-find-template-repo/{{cookiecutter.repo_name}}'
    os.chdir('..')

# Generated at 2022-06-11 20:14:19.069299
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    pass

# Generated at 2022-06-11 20:14:22.597058
# Unit test for function find_template
def test_find_template():
    """You can use the current directory as input to Cookiecutter."""
    cwd = os.getcwd()
    if cwd.endswith('cookiecutter'):
        path = find_template('.')
        assert cwd.endswith(path)

# Generated at 2022-06-11 20:14:24.826730
# Unit test for function find_template
def test_find_template():
    find_template('/home/shuang/Desktop/ttt/cookiecutter-pypackage')

### End function find_template ###




# Generated at 2022-06-11 20:14:32.425931
# Unit test for function find_template
def test_find_template():
    """Test that the `find_template()` function works."""
    from cookiecutter import utils
    template_dir = 'tests/test-find-template'
    repo_dir = utils.make_sure_path_exists(template_dir)
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:14:37.869420
# Unit test for function find_template
def test_find_template():
    """Test the function `find_template`."""
    repo_dir = 'test/test-repo-pre/'
    project_template = find_template(repo_dir)
    expected_project_template = os.path.abspath('test/test-repo-pre/cookiecutter-pypackage')

    assert(project_template == expected_project_template)

# Generated at 2022-06-11 20:14:45.086105
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'test-fake-repo'
    )

    template_dir = find_template(repo_dir)

    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert template_dir == template_dir

# Generated at 2022-06-11 20:14:46.727440
# Unit test for function find_template
def test_find_template():
    assert find_template('../') == './cookiecutter-pypackage'

# Generated at 2022-06-11 20:14:55.318128
# Unit test for function find_template
def test_find_template():
    """Verify find_template() finds project template."""
    import requests
    import pytest
    from cookiecutter.utils.paths import temporary_directory, rmtree
    # Create a temporary directory to store the new repo in
    with temporary_directory() as repo_dir:
        # Clone the repo
        response = requests.get('https://github.com/audreyr/cookiecutter-pypackage', stream=True)
        if response.status_code == 200:
            with open(os.path.join(repo_dir, 'cookiecutter-pypackage.zip'), 'wb') as f_out:
                f_out.write(response.raw.read())
        else:
            logger.error('Cannot retrieve project template')
            pytest.fail('Cannot retrieve project template')
        # Now find the

# Generated at 2022-06-11 20:15:05.387868
# Unit test for function find_template
def test_find_template():
    """Verify that the functions can find the template directory."""
    import os
    import subprocess
    import tempfile

    # Create a temporary directory and clone the fake cookiecutter-pypackage
    # repo into it.
    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    git_check_output = subprocess.check_output(
        ['git', 'clone', 'https://github.com/audreyr/cookiecutter-pypackage.git', repo_dir]
    )

    # Get the full path to the cookiecutter-pypackage/{{cookiecutter.repo_name}}/
    # directory.
    project_template = find_template(repo_dir)
    full_project

# Generated at 2022-06-11 20:15:20.356465
# Unit test for function find_template
def test_find_template():
    import tempfile
    logger.debug('Temporary directory: %s', tempfile.gettempdir())
    repo_dir = os.path.join(tempfile.gettempdir(), 'cookiecutter-test')
    os.makedirs(repo_dir)
    project_template = 'cookiecutter-pypackage'
    os.makedirs(os.path.join(repo_dir, project_template))

    absolute_path_to_template = os.path.join(repo_dir, project_template)
    assert absolute_path_to_template == find_template(repo_dir)

# Generated at 2022-06-11 20:15:23.946919
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl/'
    repo_dir_contents = os.listdir(repo_dir)
    print(repo_dir_contents)
    project_template = find_template(repo_dir)

# Generated at 2022-06-11 20:15:31.257118
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function returns the expected directory."""
    parent_dir = '/tmp/cc_test'
    os.mkdir(parent_dir)

    os.mkdir(os.path.join(parent_dir, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(parent_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(parent_dir, 'foobar-cookiecutter'))
    os.mkdir(os.path.join(parent_dir, 'cookiecutter-{{cookiecutter.py_module}}'))

    expected = os.path.join(parent_dir, 'cookiecutter-foobar')
    actual = find_template(parent_dir)

    assert expected == actual

    os.removedirs

# Generated at 2022-06-11 20:15:37.053880
# Unit test for function find_template
def test_find_template():
    """Tests for function find_template"""
    try:
        find_template('/var/folders/l_/l_szmCDGF2e9G8fjW_1v_Zw+++TM/-Tmp-/jmxfvkvksu')
    except NonTemplatedInputDirException as e:
        assert True


# Generated at 2022-06-11 20:15:43.428589
# Unit test for function find_template
def test_find_template():
    """Test function find_template()."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    try:
        with open(os.path.join(repo_dir, 'pycon-{{cookiecutter.year}}')) as f:
            f.write('')
            test_template = find_template(repo_dir)
            assert test_template == os.path.join(repo_dir, 'pycon-{{cookiecutter.year}}')
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:15:53.792297
# Unit test for function find_template
def test_find_template():
    import tempfile
    from ..operations import init_repo
    from .generate import generate_context
    from .parse import load_configuration

    tmp_repo = os.path.join(tempfile.gettempdir(), 'cookiecutter-tmp-repo-test')
    repo_url = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), 'test-repo-tmpl'
    )
    init_repo(repo_url, tmp_repo)

    context = generate_context(tmp_repo, load_configuration(tmp_repo))
    template = find_template(tmp_repo)

# Generated at 2022-06-11 20:16:03.151326
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""

# Generated at 2022-06-11 20:16:14.446560
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a sample project for us to clone and then walk.
    context = {
        'project_dir': 'foo_project',
        'project_slug': 'foo-project',
        'doc_url': 'http://readthedocs.org/',
    }
    output = os.path.join('.tests', 'functional', 'fake_project_template')
    utils.ensure_dir(output)
    cookiecutter('.tests/fake-repo-tmpl', output_dir=output, no_input=True,
                 extra_context=context)


# Generated at 2022-06-11 20:16:18.980099
# Unit test for function find_template
def test_find_template():
    """Check that find_template returns the correct path."""
    repo_dir = os.path.join(
        'tests', 'test-repos', 'test-repo-pre-july-2017'
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:16:21.771203
# Unit test for function find_template
def test_find_template():
    repo_dir = '../tests/non-templated-project'
    project_template = '../tests/non-templated-project/{{cookiecutter.repo_name}}'

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:16:35.739776
# Unit test for function find_template
def test_find_template():
    """Test find_template() for single-directory template."""
    pass

# Generated at 2022-06-11 20:16:46.270517
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.main import cookiecutter

    # create a dummy cookiecutter template
    with TemporaryDirectory() as template:
        template = template +'cookiecutter-pypackage'
        template_path = os.path.join(template, '{{cookiecutter.repo_name}}')
        os.makedirs(template_path)
        os.makedirs(os.path.join(template_path, 'tests'))

        open(os.path.join(template_path, 'tests', 'test.txt'), 'w')
        open(os.path.join(template_path, 'README.rst'), 'w')

        dunder_init = os.path.join

# Generated at 2022-06-11 20:16:52.948060
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo',
    )
    project_template = find_template(repo_dir)
    assert os.path.join(repo_dir, 'fake_project') == project_template

# Generated at 2022-06-11 20:16:55.216404
# Unit test for function find_template
def test_find_template():
    """Test the find_template function
    """
    find_template('/Users/taylor/cookiecutter-djangopackage')

# Generated at 2022-06-11 20:16:59.814966
# Unit test for function find_template
def test_find_template():
    #mock_repo_dir = os.path.join(mock_repo_dir, 'cookiecutter-pypackage')
    #mock_repo_dir_contents = os.listdir(mock_repo_dir)
    assert True


# Generated at 2022-06-11 20:17:08.037627
# Unit test for function find_template
def test_find_template():
    expected_project_template = '{{cookiecutter.project_name}}'
    repo_dir = '/tmp/something'
    with open(os.path.join(repo_dir, expected_project_template), 'w') as f:
        f.write('')

    with open(os.path.join(repo_dir, 'other_file'), 'w') as f:
        f.write('')

    project_template = find_template('/tmp')
    assert project_template == os.path.join(repo_dir, expected_project_template)

# Generated at 2022-06-11 20:17:09.863934
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    assert find_template('/home/ronny') == '/home/ronny/cookiecutter-nombre'

# Generated at 2022-06-11 20:17:13.706535
# Unit test for function find_template
def test_find_template():
    test_project_template = find_template('/Users/audreyr/cookiecutter-pypackage')

    assert(
        '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}' == test_project_template
    )

# Generated at 2022-06-11 20:17:23.442611
# Unit test for function find_template
def test_find_template():
    import time
    import shutil
    import tempfile
    import subprocess

    repo_dir = tempfile.mkdtemp()

    project_dir = os.path.join(repo_dir, 'temp_{{cookiecutter.repo_name}}')
    os.makedirs(project_dir)

    subprocess.call(
        'cd {repo_dir} && git init'.format(repo_dir=repo_dir), shell=True
    )
    time.sleep(0.05)
    subprocess.call(
        'cd {repo_dir} && git add .'.format(repo_dir=repo_dir), shell=True
    )
    time.sleep(0.05)

# Generated at 2022-06-11 20:17:28.157766
# Unit test for function find_template
def test_find_template():
    test_repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    test_project_template = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(test_repo_dir) == test_project_template

# Generated at 2022-06-11 20:17:57.020144
# Unit test for function find_template
def test_find_template():
    assert os.path.join("/home", "fake_project") == find_template("/home")

# Generated at 2022-06-11 20:18:01.513740
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the path to the template."""
    from shutil import rmtree
    from cookiecutter.main import cookiecutter

    repo_dir = cookiecutter('tests/fake-repo-tmpl', no_input=True)

    try:
        project_template = find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert False
    else:
        assert 'fake-project' in project_template

    rmtree(repo_dir)

# Generated at 2022-06-11 20:18:05.204293
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join('tests', 'fake-repos', 'cookiecutter-pypackage')
    want = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    got = find_template(test_dir)
    assert want == got


# Generated at 2022-06-11 20:18:14.693204
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter.repository import determine_repo_dir

    result = cookiecutter('tests/fake-repo-tmpl', no_input=True)
    repo_dir = determine_repo_dir('https://github.com/audreyr/cookiecutter-pypackage.git')
    project_template = find_template(repo_dir)

    assert result is not None
    assert project_template is not None
    assert isinstance(project_template, (str, unicode))
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:18:20.732315
# Unit test for function find_template
def test_find_template():
    """Test that find_template() correctly identifies the project template.
    """
    test_repo_dir = '/home/audreyr/cookiecutter-pypackage'
    test_project_template = '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(test_repo_dir) == test_project_template

# Generated at 2022-06-11 20:18:27.704220
# Unit test for function find_template
def test_find_template():
    """
    Check that find_template raises a NonTemplatedInputDirException
    when an input directory doesn't contain a template
    """

    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template[-7:] == 'cookiecutter', 'find_template does not work correctly'
    # non-existing input dir
    repo_dir = '/Users/audreyr/cookiecutter-pypackage-faqewrqe'
    try:
        project_template = find_template(repo_dir)
    except Exception as e:
        assert type(e) == NonTemplatedInputDirException, 'find_template does not work correctly'

# Generated at 2022-06-11 20:18:36.345464
# Unit test for function find_template
def test_find_template():
    """
    This is a "test" function because it uses the unittest libary.
    :return:
    """
    import unittest
    from cookiecutter import find

    class TestFindTemplate(unittest.TestCase):
        def test_basic(self):
            """
            Test the function find_template
            :return:
            """
            repo_dir = '/cookies/c1'
            template_dir = find.find_template(repo_dir)
            self.assertIn(repo_dir, template_dir)
            self.assertIn('cookiecutter', template_dir)
            self.assertIn('{{', template_dir)
            self.assertIn('}}', template_dir)

    unittest.main()

# Generated at 2022-06-11 20:18:44.093022
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import DEFAULT_CONFIG
    
    # Create a temporary repo
    config = DEFAULT_CONFIG
    repo_dir = cookiecutter('tests/fake-repo-tmpl/', no_input=True,
                            overwrite_if_exists=True, config_file=config)
    project_template = find_template(repo_dir)

    assert os.path.join(repo_dir, 'fake-project', '{{cookiecutter.project_name}}.py') == project_template

# Generated at 2022-06-11 20:18:51.991126
# Unit test for function find_template
def test_find_template():
    """Verify that find_template correctly locates Cookiecutter dir."""
    from cookiecutter.tests.test_utils import make_fake_repo
    from cookiecutter.tests.test_utils import remove_fake_repo
    repo_dir = make_fake_repo('tests/fake-repo-tmpl')

    try:
        project_tmpl = find_template(repo_dir)
        assert project_tmpl == os.path.join(repo_dir,
                                            '{{cookiecutter.repo_name}}')
    finally:
        remove_fake_repo(repo_dir)

# Generated at 2022-06-11 20:18:57.865628
# Unit test for function find_template
def test_find_template():
    from . import exceptions

    repo_dir = os.path.join('tests', 'test-repo')
    try:
        find_template(repo_dir)
    except exceptions.NonTemplatedInputDirException:
        pass
    else:
        raise Exception('NonTemplatedInputDirException should be raised!')


# Generated at 2022-06-11 20:20:07.626868
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from .compat import patch, mock

    m = mock.Mock()
    m.listdir.return_value = ['mockrepo/cookiecutter-mockrepo/']
    m.isdir.return_value = True

    with patch('cookiecutter.config.os', m):
        utils.find_template('mockrepo') == 'mockrepo/cookiecutter-mockrepo/'


# Generated at 2022-06-11 20:20:17.194881
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    import inspect
    import os
    import tempfile

    from cookiecutter import utils

    def listdir_side_effect(path):
        this_dir = os.path.dirname(
            os.path.abspath(
                inspect.getfile(test_find_template)
            )
        )
        return os.listdir(os.path.join(this_dir, path))

    path = os.path.join(
        'fixtures', 'find-template-project', '{{cookiecutter.repo_name}}'
    )
    project_dir = tempfile.mkdtemp()
    project_template = os.path.join(project_dir, path)

    os.listdir = listdir_side_effect
    found_template = ut

# Generated at 2022-06-11 20:20:23.867529
# Unit test for function find_template
def test_find_template():
    """Unit tests for function `find_template`."""
    from cookiecutter.tests.test_utils.fake_repo import fake_repo

    class TestException(Exception):
        pass

    with fake_repo('tests/fake-repo-pre/') as repo_dir:
        template_dir = find_template(repo_dir)
        assert template_dir.endswith('fake-repo-pre/{{cookiecutter.repo_name}}')

    try:
        with fake_repo('tests/fake-repo-post/') as repo_dir:
            find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise TestException('find_template() should have raised an exception')

# Generated at 2022-06-11 20:20:32.023352
# Unit test for function find_template
def test_find_template():
    # create a test repo
    os.mkdir("testing")
    os.mkdir("testing/my_repo")
    os.mkdir("testing/my_repo/hello_world")
    os.mkdir("testing/my_repo/hello_world__cookiecutter")
    os.mkdir("testing/my_repo/goodbye_world")
    os.mkdir("testing/my_repo/goodbye_world__cookiecutter")

    # run the function and test
    test_repo = os.path.join("testing", "my_repo")

    expected = os.path.join("testing", "my_repo", "hello_world__cookiecutter")
    assert expected == find_template(test_repo)

    # clean up

# Generated at 2022-06-11 20:20:41.724213
# Unit test for function find_template
def test_find_template():
    find_template('/home/jacek/cookiecutter-gh-pages')


#def _get_extra_context(context, extra_context):
#    """Return a list of extra context items.
#
#    :param context: A dictionary of context variables used by the
#        Cookiecutter project template.
#    :param extra_context: A dictionary of context variables IFF they do not
#        override items already in the `context`.
#        In other words, it is possible to have extra context items, but if
#        they are the same as the ones in `context` then the extra context
#        items are ignored.
#    :returns: A list of (key, value) pairs.
#    """
#    extra_list = []
#    for extra_key, extra_value in extra_context.items():
#        if

# Generated at 2022-06-11 20:20:51.691186
# Unit test for function find_template
def test_find_template():
    """
    Tests for finding the project template.
    """
    from cookiecutter.utils import rmtree
    from .utils import make_repo

    def teardown_function(function):
        """
        Removing the cloned repository.
        """
        rmtree(repo_dir)
        logger.debug('Deleted repo at %s', repo_dir)

    test_repo_dir = 'tests/test-repo'
    repo_dir = make_repo(test_repo_dir)

    result = find_template(repo_dir)
    assert result.endswith('tests/test-repo/cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:20:56.726814
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(os.path.dirname(__file__),
                                    '..',
                                    'tests',
                                    'test-find-template')
    template_name = find_template(template_dir)

    assert template_name == os.path.join(template_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:21:00.503160
# Unit test for function find_template
def test_find_template():
    # assert
    assert find_template("Repo/{{cookiecutter.repo_name}}") == "Repo/{{cookiecutter.repo_name}}"


# Generated at 2022-06-11 20:21:04.749934
# Unit test for function find_template
def test_find_template():
    allinputs = 'inputs'
    full_path = os.path.realpath(allinputs)
    print('full_path is: %s', full_path)
    mydir = find_template(full_path)
    print('mydir is: %s', mydir)


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:21:14.525916
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

    repo_dir = os.path.join(temp_dir, 'cookiecutter-pypackage')
    os.makedirs(repo_dir)

    contents = [
        'cookiecutter.json',
        'README.md',
        '.gitignore',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}/setup.py'
    ]

    for content in contents:
        f = os.path.join(repo_dir, content)
        os.makedirs(os.path.dirname(f), exist_ok=True)
        open(f, 'a').close()
