

# Generated at 2022-06-11 20:11:35.703494
# Unit test for function find_template
def test_find_template():
    template = find_template('../tests/test-input')
    print(template)
    assert '../tests/test-input/{{cookiecutter.repo_name}}' == template


# Generated at 2022-06-11 20:11:38.725891
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter

    # Setup
    tmp_dir = tempfile.mkdtemp()
    cookiecutter('tests/test-cookiecutter-templates/good-repo',
                 no_input=True, repo_dir=tmp_dir)
    good_dir = os.path.join(tmp_dir, 'good-repo')

    # Execute
    project_template = find_template(good_dir)

    # Test
    assert os.path.isdir(project_template)

    # Teardown
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-11 20:11:47.036744
# Unit test for function find_template
def test_find_template():
    import os
    os.system('cd %s' % os.getcwd())
    os.system('git clone https://github.com/cookiecutter/create-project-template-example create-project-template-example')
    repo_dir = os.getcwd() + os.sep + 'create-project-template-example'
    assert find_template(repo_dir) == 'create-project-template-example' + os.sep + '{{cookiecutter.project_name}}'
    os.system('cd ..')
    os.system('rm -rf create-project-template-example')



# Generated at 2022-06-11 20:11:53.872610
# Unit test for function find_template
def test_find_template():

    non_templated_input = os.path.join(
        os.path.expanduser('~'),
        '.cookiecutters',
        'cookiecutter-django',
        '{{cookiecutter.repo_name}}'
    )
    templated_input = os.path.join(
        os.path.expanduser('~'),
        '.cookiecutters',
        'cookiecutter-django'
    )
    assert find_template(non_templated_input) == templated_input
    assert find_template(templated_input) == templated_input


if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:11:57.857446
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-data/fake-repo'
    project_template = 'tests/test-data/fake-repo/{{cookiecutter.repo_name}}'

    template_result = find_template(repo_dir)

    assert template_result == project_template

# Generated at 2022-06-11 20:12:03.640385
# Unit test for function find_template
def test_find_template():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(base_dir, '..', 'tests', 'files', 'fake-repo')
    template_file = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    logger.debug(template_file)
    assert find_template(repo_dir) == template_file

# Generated at 2022-06-11 20:12:04.376227
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:12:07.338435
# Unit test for function find_template
def test_find_template():
    path = os.path.join("tests", "fake-repo-pre", "{{cookiecutter.repo_name}}")
    assert find_template("tests/fake-repo-pre") == path

# Generated at 2022-06-11 20:12:10.651743
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns the expected value."""
    repo_dir = '.\\tests\\fake-repo'
    project_template = '.\\tests\\fake-repo\\{{cookiecutter.repo_name}}'
    assert project_template == find_template(repo_dir)

# Generated at 2022-06-11 20:12:18.001212
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(repo_dir, 'not_the_one'))
        os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
        assert find_template(repo_dir) == os.path.join(
            repo_dir, '{{cookiecutter.repo_name}}')
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:12:22.989290
# Unit test for function find_template
def test_find_template():
    repo_dir = 'datapanel'
    assert find_template(repo_dir) == 'datapanel/cookiecutter-datapanel'

# TODO: Add other functions to retrieve other components (README, LICENCE, etc...)

# Generated at 2022-06-11 20:12:28.069497
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    expected_template_dir = os.path.join(
        os.path.dirname(__file__),
        'test-template'
    )
    result = find_template(expected_template_dir)
    assert expected_template_dir == result

# Generated at 2022-06-11 20:12:30.806727
# Unit test for function find_template
def test_find_template():
    assert find_template("/home/test/test_template") == "/home/test/test_template/cookiecutter-test"

# Generated at 2022-06-11 20:12:39.665214
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    from pytest import raises
    from .utils import temp_chdir

    with temp_chdir() as d:
        main.cookiecutter('tests/fake-repo-pre/', no_input=True)
        assert os.path.isdir('fake-repo-pre')
        assert 'fake-repo-pre/{{cookiecutter.repo_name}}' == find_template('fake-repo-pre')

        main.cookiecutter('tests/fake-repo-post/', no_input=True)
        assert os.path.isdir('fake-repo-post')
        assert 'fake-repo-post/{{cookiecutter.repo_name}}' == find_template('fake-repo-post')


# Generated at 2022-06-11 20:12:47.862768
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the template directory."""
    import tempfile
    from cookiecutter import utils

    project_dir = tempfile.mkdtemp()

    try:
        utils.makedirs(os.path.join(project_dir, 'my_project'))
        utils.makedirs(os.path.join(project_dir, 'something_else'))

        project_template = find_template(project_dir)
        assert project_template == os.path.join(project_dir, 'my_project')

    finally:
        # Teardown
        utils.rmtree(project_dir)

# Generated at 2022-06-11 20:12:51.506804
# Unit test for function find_template
def test_find_template():
    """
    Check that find_template locates the correct directory within the repo_dir.
    """
    project_template = find_template('.')
    assert project_template == './{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:01.649669
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works properly."""
    from cookiecutter.main import cookiecutter
    result = cookiecutter('tests/test-cookiecutter-repo/')
    assert find_template(result['repo_dir']) == 'tests/test-cookiecutter-repo/{{cookiecutter.repo_name}}'

    result = cookiecutter('tests/fake-repo-tmpl/')
    assert find_template(result['repo_dir']) == 'tests/fake-repo-tmpl/fake-project'

    result = cookiecutter('tests/fake-repo-tmpl-2/')
    assert find_template(result['repo_dir']) == 'tests/fake-repo-tmpl-2/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:05.236383
# Unit test for function find_template
def test_find_template():
    """Test function: find_template"""
    # Test on test_find_repo
    directory = os.path.dirname(os.path.realpath(__file__))
    os.path.join(directory, 'repo-tmpl')

# Generated at 2022-06-11 20:13:11.641829
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the template directory."""
    os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), '..', '..', 'tests', 'test-find-template')))

    from cookiecutter.main import cookiecutter

    context = cookiecutter('.')

    assert context['cookiecutter']['project_name'] == 'Cookiecutter'

# Generated at 2022-06-11 20:13:16.889744
# Unit test for function find_template
def test_find_template():
    """Test the find template function.
    """
    repo_dir = os.path.join(
        os.path.abspath('tests/test-data/'), 'fake-repo'
    )
    # project template should be '{{cookiecutter.project_name}}'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-11 20:13:27.334763
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    logger.debug('Testing find_template.')

    repo_dir = tempfile.mkdtemp()
    template_dir = os.path.join(repo_dir, 'cookiecutter-foobar')
    os.makedirs(template_dir)

    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-foobar')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:13:32.369695
# Unit test for function find_template
def test_find_template():
    """Test find_template function from find.py"""
    from cookiecutter import find

# CodeCov does not collect stats from the test package,
# so exclude from the coverage report.
# http://coverage.readthedocs.org/en/latest/modules.html
    try:
        from package1 import find
    except ImportError:
        pass

    find.find_template('/Users/audreyr/git/cookiecutter/tests/fake-repo-pre/')
# end

# Generated at 2022-06-11 20:13:33.267224
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:37.607455
# Unit test for function find_template
def test_find_template():
    input_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-pre-gen')
    project_template = find_template(input_dir)

    assert project_template == os.path.join(
        input_dir, '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-11 20:13:41.126511
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/cookiecutter-pypackage') == \
        '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:47.271826
# Unit test for function find_template
def test_find_template():
    """Testing find_template function."""
    import tempfile

    from .compat import TemporaryDirectory

    from .environment import StrictEnvironment
    from .exceptions import NonTemplatedInputDirException

    with TemporaryDirectory() as temp_dir:
        # Create a dummy project template
        dummy_template = os.path.join(temp_dir, 'foo', 'cookiecutter-{{dummy}}')

        # Create the dummy tmpdir
        tmpdir = tempfile.mkdtemp()

        # Test that find_template raises a NonTemplatedInputDirException
        # when there are no templated directories in the project
        try:
            find_template(tmpdir)
            assert False
        except NonTemplatedInputDirException:
            assert True

        # Test that find_template returns the correct directory after
        # a valid directory gets created


# Generated at 2022-06-11 20:13:52.557246
# Unit test for function find_template
def test_find_template():
    """Test finding the project template."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), 'test-cookiecutters', 'foobar'
        )
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-foobar')

# Generated at 2022-06-11 20:13:58.028081
# Unit test for function find_template
def test_find_template():
    """Verify function find_template()"""
    import cookiecutter
    from cookiecutter.exceptions import NonTemplatedInputDirException
    import tempfile
    import os
    import shutil
    import logging

    logging.basicConfig(level=logging.DEBUG)

    temp_dir = tempfile.mkdtemp()
    logger.debug('temp_dir %s', temp_dir)

    template_dir = os.path.join(temp_dir, 'test_template')
    os.makedirs(template_dir)
    os.makedirs(os.path.join(template_dir, '{{cookiecutter.project_name}}'))

# Generated at 2022-06-11 20:14:00.766041
# Unit test for function find_template
def test_find_template():
    repo_dir = "fake_repo_dir"
    repo_dir_contents = ['cookiecutter.json', 'another_file', 'cookiecutter-{{project_name}}']

    os.path.exists(repo_dir)
    os.listdir.return_value = repo_dir_contents
    assert find_template(repo_dir) == 'cookiecutter-{{project_name}}'

# Generated at 2022-06-11 20:14:02.415077
# Unit test for function find_template
def test_find_template():
    find_template('test/fake-repo-tmpl/')

# Generated at 2022-06-11 20:14:17.054694
# Unit test for function find_template
def test_find_template():
    """Verify that find_template gets the Template from the repo directory."""
    repo_dir = os.path.join(
        os.path.dirname(
            os.path.dirname(
                os.path.dirname(
                    os.path.abspath(__file__)
                )
            )
        ),
        'tests/test-repo'
    )
    template = find_template(repo_dir)

    assert os.path.basename(template) == 'project_template{{cookiecutter.project.name}}'
# End of test_find_template

# Generated at 2022-06-11 20:14:26.077929
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    from cookiecutter import utils
    from unittest.mock import patch

    with patch('cookiecutter.main.prompt_and_delete_repo') as m_delete_repo:
        m_delete_repo.return_value = True
        with patch('cookiecutter.main.os') as mocked_os:
            mocked_os.listdir.return_value = ['foo', 'bar', '{{cookiecutter.repo_name}}']
            main.cookiecutter('.')
            mocked_os.listdir.assert_called_once_with('.')


# Generated at 2022-06-11 20:14:35.362890
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template function"""
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException
    from shutil import copytree, rmtree
    from keras_cookiecutter.utils import assert_dir_not_exists

    # Remove fake Cookiecutter repo dir if it already exists.
    cookiecutter_input_dir = 'fake-cookiecutter-input-repo'
    assert_dir_not_exists(cookiecutter_input_dir)

    # Create fake Cookiecutter repo dir and copy in files.
    repo_dir_with_templates = os.path.join(
        'tests', 'fake-repo-with-templates'
    )
    copytree(repo_dir_with_templates, cookiecutter_input_dir)
    repo_dir

# Generated at 2022-06-11 20:14:37.323862
# Unit test for function find_template
def test_find_template():
    find_template('/home/adam/Documents/Python/Cookiecutter/cookiecutter/tests/test-find-template/')

# Generated at 2022-06-11 20:14:44.677633
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    expected = os.path.join('some', '{{cookiecutter.example}}', 'dir')

    with tempfile.TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, expected))
        os.makedirs(os.path.join(tmpdir, 'not', 'the', 'template'))
        assert find_template(tmpdir) == os.path.join(tmpdir, expected)

# Generated at 2022-06-11 20:14:50.219992
# Unit test for function find_template
def test_find_template():
    """Test finding template."""
    from .generate import generate_context
    from .main import cookiecutter

    repo_dir = 'tests/fake-repo-pre/'
    context = generate_context(repo_dir)
    cookiecutter(repo_dir, no_input=True, extra_context=context)

# Generated at 2022-06-11 20:14:56.178871
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns expected results."""
    import tempfile
    from cookiecutter.compat import ConfigParser

    template_dir = tempfile.mkdtemp()

    try:
        cookiecutter_file = os.path.join(template_dir, 'cookiecutter.json')

        with open(cookiecutter_file, 'w') as fh:
            fh.write('{"hello": "world"}')

        assert os.path.isabs(template_dir)
        assert os.path.isfile(cookiecutter_file)

        assert template_dir == find_template(template_dir)
    finally:
        os.remove(cookiecutter_file)
        os.rmdir(template_dir)

# Generated at 2022-06-11 20:15:01.452482
# Unit test for function find_template
def test_find_template():
    """Tests find_template() implementation."""
    from . import utils

    input_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), 'test-input-directory-1'))
    project_template = find_template(input_dir)

    utils.check_dir_output(project_template, input_dir)



# Generated at 2022-06-11 20:15:06.564496
# Unit test for function find_template
def test_find_template():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    repo_path = os.path.join(dir_path, 'fake-repo')
    template_path = os.path.join(repo_path, 'fake-cookiecutter-project')
    os.chdir(repo_path)

    assert find_template(repo_path) == template_path

# Generated at 2022-06-11 20:15:16.573332
# Unit test for function find_template
def test_find_template():
    # create a test dir, create a subdir named cookiecutter-{{cookiecutter.project_name}}
    # test that find_template returns that dir as the template
    test_dir = "/tmp/test_find_template"
    os.mkdir(test_dir)
    os.mkdir(os.path.join(test_dir, "cookiecutter-{{cookiecutter.test}}"))

    result = find_template(test_dir)
    assert os.path.join(test_dir, "cookiecutter-{{cookiecutter.test}}") == result

    os.rmdir(os.path.join(test_dir, "cookiecutter-{{cookiecutter.test}}"))
    os.rmdir(test_dir)

# Generated at 2022-06-11 20:15:31.198187
# Unit test for function find_template
def test_find_template():
    find_template('/Users/johndoe/Documents/cookiecutter-test')

# Generated at 2022-06-11 20:15:41.570630
# Unit test for function find_template
def test_find_template():
    """Test the find_template function from cookiecutter.find.

    Create a temporary repo and test that the function finds the correct
    template.
    """
    from cookiecutter import main
    from nose.tools import raises

    empty_repo_path = os.path.join(os.path.dirname(__file__), 'empty-repo')
    main.cookiecutter(empty_repo_path, no_input=True, output_dir='/tmp')

    temp_repo = os.path.join('/tmp', 'tests', 'test-cookiecutter-find')
    assert os.path.exists(temp_repo)

    assert find_template(temp_repo) == os.path.join(temp_repo, '{{cookiecutter.repo_name}}')

    # Test non-templ

# Generated at 2022-06-11 20:15:52.558700
# Unit test for function find_template
def test_find_template():
    import shutil
    from tempfile import mkdtemp
    from cookiecutter.generate import generate_files

    # Make a temporary directory to house our 'fake' template
    temp_dir = mkdtemp()

    # Make a fake template called cookiecutter-faketemplate
    fake_template = os.path.join(temp_dir, 'fake-template')
    os.makedirs(fake_template)

    # Write a couple of fake files to templated-directory
    context_file = os.path.join(fake_template, 'fake.txt')
    with open(context_file, 'w') as f:
        f.write('This is a fake file.')

    os.makedirs(os.path.join(fake_template, 'fake_dir'))
    fake_file = os.path.join

# Generated at 2022-06-11 20:15:58.161062
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter import vcs

    test_project_dir = os.path.join(utils.workdir(), 'tests',
                                    'test-find-template')

    repo = 'git@github.com:audreyr/cookiecutter-pypackage.git'

    vcs.clone(repo, '.', no_input=True)

    project_template = find_template(test_project_dir)
    assert os.path.exists(project_template)

    assert project_template == os.path.join(test_project_dir,
                                            '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:16:05.389836
# Unit test for function find_template
def test_find_template():
    r"""Function find_template must return a project template.

    Project template should be the first directory that has
    "cookiecutter" and "{{", and "}}" in the project directory.
    """
    # Create temporary project directory
    os.chdir(os.path.expanduser('~'))
    test_project_dir = os.path.join(os.getcwd(), 'temporary-test-project-dir')
    os.makedirs(test_project_dir)

    # Create a project template in the temporary project dir
    os.chdir(test_project_dir)
    test_project_template = 'test-project-template'
    os.mkdir(test_project_template)
    # Create a file called cookiecutter.json in the temp project template dir
    # this file must be called cookiecutter.

# Generated at 2022-06-11 20:16:09.964603
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template."""
    path = "/usr/local/bin"
    assert find_template(path) == "/usr/local/bin/cookiecutter-{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:16:14.017818
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/feiwang/git/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/Users/feiwang/git/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:22.453278
# Unit test for function find_template
def test_find_template():
    """Ensures that the function find_template returns the correct path."""
    import sys
    import os
    import re
    import tempfile
    import shutil
    import mock

    if sys.version_info[:2] < (2,7):
        import unittest2 as unittest
    else:
        import unittest

    from cookiecutter.exceptions import NonTemplatedInputDirException
    def fake_os_listdir(arg):
        return ['file1', 'file2', '{{cookiecutter.project_name}}']

    class TestRepoDir(unittest.TestCase):
        def setUp(self):
            self.repo_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.repo_dir)


# Generated at 2022-06-11 20:16:25.643973
# Unit test for function find_template
def test_find_template():
    """Test whether find_template raises an exception when searching an empty directory."""
    try:
        find_template('.')
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-11 20:16:32.289557
# Unit test for function find_template
def test_find_template():
    """Verify the template finding function works when there is actually a template."""
    fake_repo_dir = '/home/fakehome/some/fake/dirs/and/files/'

    repo_dir_contents = [
        '/home/fakehome/some/fake/dirs/and/files/fake1',
        '/home/fakehome/some/fake/dirs/and/files/fake2',
        '/home/fakehome/some/fake/dirs/and/files/cookiecutter-fake',
    ]

    def mock_listdir(dir_to_list):
        return repo_dir_contents

    from cookiecutter import find
    find.os.listdir = mock_listdir


# Generated at 2022-06-11 20:17:06.516120
# Unit test for function find_template
def test_find_template():
    tests = [
        {
            'repo_dir': '/home/audreyr/cookiecutter-pypackage',
            'project_template': '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}',
        }
    ]

    for test in tests:
        assert find_template(test['repo_dir']) == test['project_template']

# Generated at 2022-06-11 20:17:14.377137
# Unit test for function find_template
def test_find_template():
    my_dir = os.path.join(os.path.dirname(__file__), 'test-test-test')
    os.makedirs(my_dir)
    open(os.path.join(my_dir, 'cookiecutter-{{project_name}}'), 'w').close()

    assert find_template(my_dir) == os.path.join(my_dir, 'cookiecutter-{{project_name}}')

    os.unlink(os.path.join(my_dir, 'cookiecutter-{{project_name}}'))
    os.rmdir(my_dir)

# Generated at 2022-06-11 20:17:17.315995
# Unit test for function find_template
def test_find_template():
    template_path = find_template('fixtures/fake-repo/')

    assert template_path == 'fake-repo/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-11 20:17:24.803427
# Unit test for function find_template
def test_find_template():
    """Test for finding the template from the repo_dir."""
    from .test_utils.test_repo import clone
    repo_dir = clone()

    repo_dir_contents = os.listdir(repo_dir)
    assert repo_dir_contents == ['example-repo', '.git']

    project_directory = find_template(repo_dir)
    assert project_directory == os.path.join(repo_dir, 'example-repo')

    for dirpath, subdirs, files in os.walk(project_directory):
        for d in subdirs:
            assert 'cookiecutter' not in d
        for f in files:
            assert 'cookiecutter' not in f


# Generated at 2022-06-11 20:17:27.292698
# Unit test for function find_template
def test_find_template():
    dir = 'tests'
    filename = '/cookiecutter-pypackage/'
    assert find_template(dir) == dir + filename


# Generated at 2022-06-11 20:17:34.472612
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'tests/test-input')
    success_test_dir = os.path.join(os.path.dirname(__file__), 'tests/test-input/{{cookiecutter.repo_name}}')
    test_dir = find_template(repo_dir)
    assert test_dir == success_test_dir, "test_find_template failed"

# Generated at 2022-06-11 20:17:38.632254
# Unit test for function find_template
def test_find_template():

    repo_dir_contents = ['cookiecutter-pypackage', 'cookiecutter-pypackage-tests', 'cookiecutter-pypackage-asdf']

    project_template = find_template(repo_dir_contents)
    assert project_template == 'cookiecutter-pypackage'

    repo_dir_contents = ['cookiecutter-asdf', 'cookiecutter-tests']

    project_template = find_template(repo_dir_contents)
    assert project_template == None


# Generated at 2022-06-11 20:17:43.548347
# Unit test for function find_template
def test_find_template():
    """Find a template in a directory. """
    # Run cookiecutter with a local directory
    local_dir = 'tests/test-find-template'
    template_dir = find_template(local_dir)
    assert os.path.exists(template_dir)
    assert 'cookiecutter-pypackage' in template_dir
    assert '{{' in template_dir
    assert '}}' in template_dir

# Generated at 2022-06-11 20:17:45.263630
# Unit test for function find_template
def test_find_template():
    template = find_template('tests/input')

# Generated at 2022-06-11 20:17:48.822018
# Unit test for function find_template
def test_find_template():
    dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    print(find_template(dir))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:18:56.629815
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter import utils
    from cookiecutter.config import DEFAULT_CONFIG

    shutil.copytree(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            '..',
            'tests',
            'test-generate-project'
        ),
        'tests/test-generate-project2'
    )

    clone_dir = utils.make_sure_path_exists(
        'tests/test-generate-project2',
        DEFAULT_CONFIG['replay_dir']
    )

    templ_dir = find_template(clone_dir)
    assert templ_dir == 'tests/test-generate-project2/{{cookiecutter.repo_name}}'

    shutil

# Generated at 2022-06-11 20:18:58.233648
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    # TODO: implement

# Generated at 2022-06-11 20:19:06.153516
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    expected_output = 'cookiecutter-pypackage'

    if os.name == 'nt':
        repo_dir = 'D:\\github-repo\\cookiecutter-pypackage\\tests\\fake-repo-tmpl'
        template_dir = find_template(repo_dir)
        assert template_dir[template_dir.rindex('\\') + 1:] == expected_output
    else:
        repo_dir = '/Users/audreyr/github-repo/cookiecutter-pypackage/tests/fake-repo-tmpl'
        template_dir = f

# Generated at 2022-06-11 20:19:10.897914
# Unit test for function find_template
def test_find_template():
    """Test find_template into cloned repo_dir"""
    repo_dir = os.path.join(os.path.dirname(__file__), "tests/fake-repo/")
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:19:13.430679
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
# end test


# Generated at 2022-06-11 20:19:19.319239
# Unit test for function find_template
def test_find_template():
    """Test the find_template function"""
    import os
    import shutil
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath('tests/test-find-template')
    if not os.path.exists(repo_dir):
        os.makedirs(repo_dir)

    # Test: No repo_dir, should raise an error.
    try:
        utils.find_template('')
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception('find_template should have raised an error'
                        ' when given an empty string.')

    # Test: repo_dir is a file, should raise an error.

# Generated at 2022-06-11 20:19:22.885692
# Unit test for function find_template
def test_find_template():
    import tempfile
    temp_directory = tempfile.mkdtemp()
    file = os.path.join(temp_directory, "cookiecutter-{{ cookiecutter.project }}")
    open(file, 'a').close()
    project_template = find_template(temp_directory)
    assert project_template == file

# Generated at 2022-06-11 20:19:30.352304
# Unit test for function find_template
def test_find_template():
    from cookiecutter.generate import generate_files
    from cookiecutter.utils import (
        rmtree,
        work_in,
    )
    test_root_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'tests', 'files')
    template_path = os.path.join(test_root_dir, 'empty-repo')
    template_name = os.path.join(test_root_dir, 'empty-repo', '{{cookiecutter.repo_name}}')
    context = {
        'repo_name': 'cookiecutter-pypackage',
        '_template': template_path,
    }
    output_dir = 'nested'

# Generated at 2022-06-11 20:19:32.368262
# Unit test for function find_template
def test_find_template():
    repo_dir = ''
    project_template = find_template(repo_dir)
    assert project_template is not None

# Generated at 2022-06-11 20:19:34.812445
# Unit test for function find_template
def test_find_template():
    assert (find_template('cookiecutter-pypackage/{{cookiecutter.repo_name}}')
            == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}')