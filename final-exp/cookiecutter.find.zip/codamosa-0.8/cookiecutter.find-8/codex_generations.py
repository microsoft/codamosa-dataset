

# Generated at 2022-06-11 20:11:36.566580
# Unit test for function find_template
def test_find_template():
    directory = 'tests/test-repo/'
    project_template = find_template(directory)
    assert project_template == os.path.join(
        os.path.abspath(directory),
        'cookiecutter-pypackage/'
    )

# Generated at 2022-06-11 20:11:42.517332
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    repo_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return find_template(repo_dir)

# Generated at 2022-06-11 20:11:52.198067
# Unit test for function find_template
def test_find_template():
    """Verify function find_template()."""
    from . import utils
    from .compat import TemporaryDirectory

    repo_json_data = {
        'cookiecutter': {
            'repo_dir': 'tests/test-repo',
            'tag': '0.1.0',
            'branch': 'master',
            'sha': '71849cda6fea20e570d3e3bab6c3cb9a9de8daf8'
        }
    }

    with TemporaryDirectory() as tmp_dir:
        os.chdir(tmp_dir)
        utils.make_sure_path_exists('tests/test-repo')

# Generated at 2022-06-11 20:12:00.231933
# Unit test for function find_template
def test_find_template():
    import time
    import shutil
    import tempfile
    from cookiecutter import generate
    from cookiecutter import main
    from cookiecutter import utils
    from cookiecutter.main import cookiecutter

    # Create a temporary directory to store our dummy Cookiecutter template in
    tmp_dir = tempfile.mkdtemp()
    repo_dir_name = 'fake-repo-{}'.format(int(time.time()))
    repo_dir = os.path.join(tmp_dir, repo_dir_name)
    os.makedirs(repo_dir)

    # Make a dummy Cookiecutter template
    logger.debug('Creating fake cookiecutter template in %s', repo_dir)
    template_dir = os.path.join(repo_dir, 'fake-cookiecutter-project')
    os

# Generated at 2022-06-11 20:12:08.018774
# Unit test for function find_template
def test_find_template():
    """Test that function `find_template` returns correct value"""
    repo_dir = 'test_find_template'
    correct_path = os.path.join(repo_dir, 'cookiecutter-test-find-template')
    if not os.path.isdir(repo_dir):
        os.makedirs(repo_dir)
    if not os.path.isdir(correct_path):
        os.makedirs(correct_path)

    real_path = find_template(repo_dir)
    assert real_path == correct_path

# Generated at 2022-06-11 20:12:10.483543
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_utils.test_finders import repo_with_template_contents_called_example
    repo_with_template_contents_called_example()


# Generated at 2022-06-11 20:12:19.760155
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/joe/new_project'
    repo_dir_contents = [
        'cookiecutter-django',
        'my_project',
        'test_cookiecutter-django',
        'test_my_project',
    ]
    project_template = 'cookiecutter-django'
    os.listdir = lambda x: repo_dir_contents
    project_template = find_template(repo_dir)
    assert project_template == '/home/joe/new_project/cookiecutter-django'
    repo_dir_contents = [
        'my_project',
        'test_my_project',
    ]
    os.listdir = lambda x: repo_dir_contents

# Generated at 2022-06-11 20:12:29.688354
# Unit test for function find_template
def test_find_template():
    """ Unit test for function find_template """
    path_template = os.path.join(os.path.abspath(os.path.dirname(__file__)),
                                 '{{cookiecutter.repo_name}}')
    test_repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)),
                                 '{{cookiecutter.repo_name}}_test')

    os.chdir(test_repo_dir)
    assert os.getcwd() == test_repo_dir
    assert find_template(test_repo_dir) == path_template

test_find_template()

# Generated at 2022-06-11 20:12:38.868312
# Unit test for function find_template
def test_find_template():
    import tempfile
    temp_dir = tempfile.gettempdir()
    repo_dir = os.path.join(temp_dir, 'cookiecutter-test-find-template')
    if not os.path.exists(repo_dir):
        os.makedirs(repo_dir)

    # repo_dir contains a non cookiecutter folder
    file_contents = """
    This is a file.
    """
    with open(os.path.join(repo_dir, 'file.txt'), 'w') as f:
        f.write(file_contents)

    assert find_template(repo_dir) == None

    # repo_dir contains a normal cookiecutter folder
    cookiecutter_dir = os.path.join(repo_dir, 'cookiecutter')
    os.maked

# Generated at 2022-06-11 20:12:42.448189
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/{{cookiecutter.repo_name}}') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:50.526166
# Unit test for function find_template
def test_find_template():
    from cookiecutter.config import DEFAULT_CONFIG
    repo_dir = os.path.abspath(
        os.path.join(
            DEFAULT_CONFIG['cookiecutters_dir'],
            'cookiecutter-pypackage'
        )
    )
    result = find_template(repo_dir)
    expected = os.path.abspath(
        os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    )
    assert result == expected,\
        "find_template('%s') returned '%s' instead of '%s'" % (
            repo_dir,
            result,
            expected,
        )

# Generated at 2022-06-11 20:12:52.263418
# Unit test for function find_template
def test_find_template():
    # TODO: fix me when we move to pytest
    pass

# Generated at 2022-06-11 20:12:55.622174
# Unit test for function find_template
def test_find_template():
    """Test find_template() function."""
    assert find_template('tests/test-repo-tmpl/') == 'tests/test-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:03.060363
# Unit test for function find_template
def test_find_template():
    """ Unit test for `find_template` """

    from cookiecutter.prompt import read_user_choice
    from cookiecutter.utils import rmtree

    repo_dir = 'tests/test-find-template'
    try:
        find_template(repo_dir)
        assert False
    except NonTemplatedInputDirException:
        pass

    template_dir = 'tests/fake-repo-pre/'
    project_dir = 'tests/fake-repo-pre/fake-project'
    project_template = '{{ cookiecutter.repo_name }}'
    assert find_template(template_dir) == project_dir
    rmtree(project_dir)


# Generated at 2022-06-11 20:13:03.840565
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:07.397277
# Unit test for function find_template
def test_find_template():
    """Test the find_template function to find the templated directory."""
    # Setup
    os.chdir('tests/files/tests')

    # Test
    project_template = find_template('.')

    # Verification
    assert project_template == './{{cookiecutter.repo_name}}'
    os.chdir('../../../')

# Generated at 2022-06-11 20:13:08.193190
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    return find_template('.')


# Generated at 2022-06-11 20:13:12.379263
# Unit test for function find_template
def test_find_template():
    tpl_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo-pre-render'
    )
    assert 'cookiecutter-pypackage' in find_template(tpl_dir)


# Generated at 2022-06-11 20:13:18.868661
# Unit test for function find_template
def test_find_template():
    """Test find_template function

    :param repo_dir: Source for cookiecutter templates (git repo)
    """

    logger.debug('Testing find_template function')

    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'tests/fake-repo-tmpl'
    )

    assert find_template(repo_dir) == os.path.join(
        os.path.dirname(__file__),
        'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-11 20:13:20.908616
# Unit test for function find_template
def test_find_template():
    find_template('/Users/danielafreeman/Scratch/cookiecutter-pypackage-min')

# Generated at 2022-06-11 20:13:31.120563
# Unit test for function find_template
def test_find_template():
    """Tests for `find_template` function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Initialize a test repo
    cookiecutter('tests/test-repo/', no_input=True, output_dir='.')

    # Test `find_template`
    repo_dir = os.path.join(utils.find_root(), 'tests', 'test-repo')
    project_template = find_template(repo_dir)

    # Delete the test repo
    os.rmdir(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:13:35.873567
# Unit test for function find_template
def test_find_template():
    """Verify find_template()."""
    repo_dir = os.path.join('tests', 'files', 'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-11 20:13:36.475972
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:45.356989
# Unit test for function find_template
def test_find_template():
    """Test find_template"""
    from unittest import TestCase

    class TestFindTemplate(TestCase):
        def test_find_template(self):
            """Test find_template"""
            from cookiecutter.utils import convert_to_filesystem

            repo_dir = 'fake-repo'
            os.mkdir(repo_dir)
            test_dir = os.path.join(repo_dir, 'test_dir')
            os.mkdir(test_dir)
            test_file = os.path.join(test_dir, 'test.txt')
            open(test_file, 'a').close()
            input_dir = convert_to_filesystem('{{cookiecutter.repo_name}}')
            output_dir = find_template(repo_dir)

# Generated at 2022-06-11 20:13:46.996024
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'test-find-repo')

    assert find_template(repo_dir) == os.path.join(
        repo_dir,
        'cookiecutter-pypackage'
    )

# Generated at 2022-06-11 20:13:50.706932
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns a proper relative path to repo."""
    assert find_template('tests/test-data/fake-repo-pre/') == \
        'tests/test-data/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:59.989930
# Unit test for function find_template
def test_find_template():
    """
    Test `find_template` function with various directory structures
    """
    from cookiecutter.utils import rmtree

    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temp dir to clone the repo into
    output_dir = tempfile.mkdtemp()
    # Create a temp dir to serve as the repo
    repo_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 20:14:02.842500
# Unit test for function find_template
def test_find_template():
    """
    Verify whether the find_template function is working properly.
    """
    assert find_template('..') == '../{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:03.274825
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:14.659498
# Unit test for function find_template
def test_find_template():

    # Test for repo_dir with no templated project dir
    repo_dir_notemplated = os.path.abspath(
        os.path.join(os.path.dirname(__file__),
            '..',
            'tests',
            'test-input-notemplated-dir'
        )
    )
    try:
        find_template(repo_dir_notemplated)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception(
            "Should have raised exception for repo dir '%s'"
            % repo_dir_notemplated
        )

    # Test for repo_dir with single templated project dir

# Generated at 2022-06-11 20:14:18.601366
# Unit test for function find_template
def test_find_template():
    assert find_template("tests") == ''

# Generated at 2022-06-11 20:14:20.486344
# Unit test for function find_template
def test_find_template():
    find_template('/Users/Yours/cookiecutters/cookiecutter-pypackage')

# Generated at 2022-06-11 20:14:21.053550
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:27.250907
# Unit test for function find_template
def test_find_template():
    """Confirm that find_template works."""
    # Setup
    import tempfile
    repo_dir = tempfile.mkdtemp()
    project_template = 'cookiecutter-{{cookiecutter.repo_name}}'
    os.makedirs(os.path.join(repo_dir, project_template))

    os.listdir(repo_dir)

    # Run
    found_project_template = find_template(repo_dir)

    # Test
    expected = os.path.realpath(os.path.join(repo_dir, project_template))
    assert found_project_template == expected

# Generated at 2022-06-11 20:14:28.036791
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:32.351403
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    find_template(repo_dir='mygit/myrepo')
    assert find_template(repo_dir='mygit/myrepo') == 'mygit/myrepo/cookiecutter-pypackage'


# Generated at 2022-06-11 20:14:38.425587
# Unit test for function find_template
def test_find_template():
    # GIVEN known template path
    import tempfile
    repo_dir = tempfile.mkdtemp()
    expected_template_path = os.path.join(repo_dir, 'my-project')
    os.mkdir(expected_template_path)

    # WHEN calling #find_template
    actual_template_path = find_template(repo_dir)

    # THEN
    assert actual_template_path == expected_template_path

# Generated at 2022-06-11 20:14:44.032797
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'run_tests/test_input'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:14:46.630318
# Unit test for function find_template
def test_find_template():
    """Verify template finding behavior."""
    # Create mock project with no template
    # Make sure that raises a custom exception.
    pass

# Generated at 2022-06-11 20:14:54.437342
# Unit test for function find_template
def test_find_template():
    """Verify find_template()."""
    import tempfile

    tmp_repo_dir = tempfile.mkdtemp()
    try:
        tmp_child_dir = tempfile.mkdtemp(prefix='child_', dir=tmp_repo_dir)
        os.rmdir(tmp_child_dir)
        tmp_child_dir = os.path.basename(tmp_child_dir)
        child_dir = find_template(tmp_repo_dir)
        assert child_dir == os.path.join(tmp_repo_dir, tmp_child_dir)
    finally:
        os.rmdir(tmp_repo_dir)

# Generated at 2022-06-11 20:15:02.970840
# Unit test for function find_template
def test_find_template():
    """Test functionality of find_template function"""

    pass
#Test non templated dir
#Test non templated dir with two dirs
#Test templated input dir with two dirs

# Generated at 2022-06-11 20:15:09.371468
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.repository import determine_repo_dir

    with TemporaryDirectory() as tmpdir:
        template_dir = os.path.join(tmpdir, '{{cookiecutter.repo_name}}')
        os.makedirs(template_dir)

        repo_dir = determine_repo_dir(template_dir)
        project_template = find_template(repo_dir)

        assert os.path.relpath(project_template, repo_dir) == '{cookiecutter.repo_name}'

# Generated at 2022-06-11 20:15:15.576485
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    assert 'fake-repo-pre' in find_template(repo_dir)
    assert 'tests' in find_template(repo_dir)
    assert '{{cookiecutter.repo_name}}' in find_template(repo_dir)

#print(test_find_template())



# Generated at 2022-06-11 20:15:18.010617
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    test_dir = '/home/me/test_dir'
    assert find_template(test_dir) is None

# Generated at 2022-06-11 20:15:21.622439
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join(
        os.path.dirname(__file__), 'fake-repo', 'input')) == os.path.join(
            os.path.dirname(__file__), 'fake-repo', 'input', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:15:25.079809
# Unit test for function find_template
def test_find_template():
    repo_dir = 'test/fake-repo-pre/'
    project_template = 'test/fake-repo-pre/cookiecutter-pypackage/'
    assert find_template(repo_dir) == project_template


# Generated at 2022-06-11 20:15:27.898683
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/cookiecutters/cookiecutter-pypackage') == '/Users/audreyr/cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:33.564866
# Unit test for function find_template
def test_find_template():
    """
    Tests that the function 'find_template' returns the correct file path when
    the directory contains a cookiecutter project template.
    """

    test_dir = 'tests/test-caution-frosted-donut'
    test_file = 'tests/test-caution-frosted-donut/{{cookiecutter.project_name}}'

    assert find_template(test_dir) == test_file



# Generated at 2022-06-11 20:15:35.872197
# Unit test for function find_template
def test_find_template():
    path = find_template("teste")

# Generated at 2022-06-11 20:15:38.924537
# Unit test for function find_template
def test_find_template():
    assert find_template('../input_dir/input_dir-cookiecutter-{{project_name}}') == '../input_dir/input_dir-cookiecutter-{{project_name}}'

# Generated at 2022-06-11 20:16:00.849902
# Unit test for function find_template
def test_find_template():
    # Setup
    class TestException(Exception):
        pass


    repo_dir_contents = ["template{{cookiecutter.year}}", "something", "test", "new{{cookiecutter.year}}"]
    expected_return_template = "template{{cookiecutter.year}}"

    # Mock
    import __builtin__
    try:
        __builtin__.open = lambda path, mode: open(path, mode)
    except ImportError:
        import builtins
        builtins.open = lambda path, mode: open(path, mode)


    orig_os_listdir = os.listdir
    os_listdir = lambda path: repo_dir_contents
    os.listdir = os_listdir

    # Run
    assert find_template(repo_dir_contents) == expected_return_template



# Generated at 2022-06-11 20:16:05.520039
# Unit test for function find_template
def test_find_template():
    repo_dir = r'C:\Users\michael\Dropbox\cookiecutters\cookiecutter-pypackage'
    template = r'C:\Users\michael\Dropbox\cookiecutters\cookiecutter-pypackage\{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == template

# test_find_template()

# Generated at 2022-06-11 20:16:12.062846
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException
    logger = logging.getLogger(__name__)

    with pytest.raises(NonTemplatedInputDirException):
        find_template('my-fake-repo-dir')

    logger.debug = lambda x: x
    logger.info = lambda x: x
    logger.critical = lambda x: x

# Generated at 2022-06-11 20:16:16.468761
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(
        os.path.dirname(__file__),
        'tests/test-find-repo/cookiecutter-pypackage'
    )
    project_template = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    assert find_template(test_dir) == project_template

# Generated at 2022-06-11 20:16:19.937140
# Unit test for function find_template
def test_find_template():
    assert (
        find_template('cookiecutter/tests/test-find-non-templated-input-dir/')
    ) == 'cookiecutter/tests/test-find-non-templated-input-dir/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:16:24.411899
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/vanessa/Desktop/cookiecutter-pypackage/'
    project_template = find_template(repo_dir)
    assert 'cookiecutter-pypackage/{{cookiecutter.repo_name}}' == project_template


# Generated at 2022-06-11 20:16:28.940972
# Unit test for function find_template
def test_find_template():
    assert find_template('/tmp/{{cookiecutter.repo_name}}') == '/tmp/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}'
    try:
        find_template('/tmp/repo')
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

# Generated at 2022-06-11 20:16:33.406114
# Unit test for function find_template
def test_find_template():
    test_path = os.path.abspath('tests/fake-repo/')
    assert find_template(test_path) == os.path.abspath('tests/fake-repo/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:16:38.240734
# Unit test for function find_template
def test_find_template():
    """Unit tests for find_template."""
    # Normal operation
    assert find_template('./tests/fake-repo-tmpl/') == './tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    # NonTemplatedInputDirException
    try:
        find_template('./tests/fake-repo-pre/')
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'Did not raise NonTemplatedInputDirException.'

# Generated at 2022-06-11 20:16:43.600523
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'fake-repo')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:17:15.778968
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import sys

    class TestNonTemplatedInputDirException(Exception):
        pass

    class TestTemplatedDir(object):
        def test_find_template_non_templated_repo(self):
            try:
                tmpdir = tempfile.mkdtemp()
                test_dir_path = os.path.join(tmpdir, 'non_templated')
                os.makedirs(test_dir_path)
                test_dir = open(test_dir_path + '/somefile', 'a')
                test_dir.close()
                find_template(test_dir_path)
            except NonTemplatedInputDirException:
                shutil.rmtree(tmpdir)
            else:
                raise TestNonTemplatedInputDirException


# Generated at 2022-06-11 20:17:23.362333
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    assert find_template(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo-tmpl',
        'fake-repo',
    )) == os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'fake-repo-tmpl',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
    )

# Generated at 2022-06-11 20:17:26.294236
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo/'
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:17:37.220574
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import pytest
    import tempfile
    import shutil

    TEST_DIR = tempfile.mkdtemp()
    os.makedirs(os.path.join(TEST_DIR, 'cookiecutter'))
    os.makedirs(os.path.join(TEST_DIR, 'cookiecutter-foo'))
    os.makedirs(os.path.join(TEST_DIR, 'cookiecutter{{cookiecutter.project_name}}'))

    expected = os.path.join(TEST_DIR, 'cookiecutter{{cookiecutter.project_name}}')
    actual = find_template(TEST_DIR)

    assert actual == expected
    shutil.rmtree(TEST_DIR, ignore_errors=True)

# Generated at 2022-06-11 20:17:41.303801
# Unit test for function find_template
def test_find_template():
    # Test should pass
    assert find_template("/Users/admin/CookiecutterTestRepos/cookiecutter-pypackage") == "/Users/admin/CookiecutterTestRepos/cookiecutter-pypackage/{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:17:42.162101
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    pass

# Generated at 2022-06-11 20:17:49.218075
# Unit test for function find_template
def test_find_template():
    import tempfile

    test_repo = tempfile.TemporaryDirectory()
    test_templates = ('{{cookiecutter.repo_name}}', '{{cookiecutter.repo_name}}-master')
    for template in test_templates:
        os.mkdir(os.path.join(test_repo.name, template))
    parent_dir = os.path.abspath(os.path.join(test_repo.name, os.pardir))
    assert find_template(test_repo.name) == os.path.join(parent_dir, test_templates[0])
    assert find_template(os.path.join(test_repo.name, test_templates[-1])) == os.path.join(parent_dir, test_templates[0])

    test_re

# Generated at 2022-06-11 20:17:57.429635
# Unit test for function find_template
def test_find_template():
    """
    Test find_template function
    """
    repo_dir = 'test_repo_dir'
    repo_dir_contents = {'test_cookiecutter_test_module'}

    os.listdir(repo_dir)

    project_template = 'test_cookiecutter_test_module'
    assert project_template == 'test_cookiecutter_test_module'
    for item in repo_dir_contents:
        assert 'cookiecutter' in item
    assert '{{' in item
    assert '}}' in item
    assert project_template is not None




# Generated at 2022-06-11 20:18:03.062876
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter import config
    from cookiecutter.main import cookiecutter

    context = {
        'full_name': 'Firstname Lastname',
        'email': 'test@example.com',
        'github_username': 'audreyr'
    }
    output = cookiecutter(
        'tests/test-driven-cookiecutter',
        no_input=True,
        extra_context=context,
        overwrite_if_exists=True,
    )
    assert os.path.isdir(output)

    project_template = find_template(output)
    assert os.path.isdir(project_template)
    assert '{{cookiecutter.repo_name}}' in project_template


# Generated at 2022-06-11 20:18:07.825320
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    os.chdir('tests/test-find-template/')
    project_template = find_template('./fake-repo-tmpl')
    assert project_template == './fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:19:07.838391
# Unit test for function find_template
def test_find_template():
    project_template = find_template('/home/audreyr/cookiecutter-pypackage/')
    assert project_template == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}/'
    project_template = find_template('/home/audreyr/cookiecutter-pypackage/cookiecutter')
    assert project_template == '/home/audreyr/cookiecutter-pypackage/cookiecutter/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-11 20:19:15.857638
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    exp_result1 = os.path.join(os.path.abspath(os.curdir), 'tests/fake-repo-tmpl/fake-repo-pre/')
    result1 = find_template('tests/fake-repo-tmpl/fake-repo-pre/')
    assert result1 == exp_result1

    exp_result2 = os.path.join(os.path.abspath(os.curdir), 'tests/fake-repo-tmpl/fake-repo-post/')
    result2 = find_template('tests/fake-repo-tmpl/fake-repo-post/')
    assert result2 == exp_result2

# Generated at 2022-06-11 20:19:19.893135
# Unit test for function find_template
def test_find_template():
    """."""
    assert find_template('/Users/micah/Desktop/Jobs/ME/Cookiecutter') == '/Users/micah/Desktop/Jobs/ME/Cookiecutter/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:19:24.709005
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    expected_template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    actual_template_dir = find_template(repo_dir)
    assert expected_template_dir == actual_template_dir

# Generated at 2022-06-11 20:19:29.069902
# Unit test for function find_template
def test_find_template():
    """Test for find_template function."""

    repo_dir = os.path.abspath(os.path.dirname(__file__))
    expected_template = os.path.join(repo_dir, 'tests', 'minimal-template-repo', '{{cookiecutter.repo_name}}')

    result = find_template(repo_dir)
    assert expected_template == result

# Generated at 2022-06-11 20:19:33.097944
# Unit test for function find_template

# Generated at 2022-06-11 20:19:35.045161
# Unit test for function find_template
def test_find_template():
    assert find_template('./tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:19:41.332448
# Unit test for function find_template
def test_find_template():
    """Test find_template function in utils."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(base_dir, 'fixtures', 'test-template')
    template_dir = find_template(test_dir)
    assert template_dir == os.path.join(test_dir, 'my-test-template')

# Generated at 2022-06-11 20:19:46.235293
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template


# Generated at 2022-06-11 20:19:51.001203
# Unit test for function find_template
def test_find_template():

    class OsDir(object):
        def __init__(self, dir_name):
            self.dir_name = dir_name

        def listdir(self, repo_dir):
            if repo_dir == 'abc':
                return 'def'
            if repo_dir == 'abc':
                return 'ghi'

    class TestCase(object):
        pass

    test_case = TestCase()
    test_case.project_dir = 'abc'
    test_case.repo_dir = 'def'

    os_dir = OsDir('dir_name')
    assert find_template(
        repo_dir=os_dir,
        repo_dir='abc',
        project_dir=os_dir,
        project_dir='abc'
    ) == 'abc'

# Source:
# https://github.com/