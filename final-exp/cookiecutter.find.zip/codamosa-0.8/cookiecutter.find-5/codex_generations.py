

# Generated at 2022-06-11 20:11:39.430766
# Unit test for function find_template
def test_find_template():
    """Sanity checks for find_template function."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'fake-repo-pre-gen')
    )
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'fake-project-template')

# Generated at 2022-06-11 20:11:43.224902
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    project_template = os.path.join(repo_dir, 'fake-project')
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:11:47.538122
# Unit test for function find_template
def test_find_template():
    test_dir = "/home/vanessa/Documents/cookiecutter-pypackage-min"
    template = find_template(test_dir)
    assert template == "/home/vanessa/Documents/cookiecutter-pypackage-min/{{cookiecutter.repo_name}}"



# Generated at 2022-06-11 20:11:54.264219
# Unit test for function find_template
def test_find_template():
    try:
        from cookiecutter.tests.test_dir_structs import NONTEMPLATED_INPUT_DIR
        find_template(NONTEMPLATED_INPUT_DIR)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, "NonTemplatedInputDirException wasn't raised for a non templated input dir"
    try:
        from cookiecutter.tests.test_dir_structs import TEMPLATED_INPUT_DIR
        find_template(TEMPLATED_INPUT_DIR)
    except NonTemplatedInputDirException:
        assert False, "NonTemplatedInputDirException was raised for a templated input dir"
    else:
        pass

# Generated at 2022-06-11 20:11:59.309906
# Unit test for function find_template
def test_find_template():
    """Verify find_template() finds cookiecutter.json in input_dir."""
    from cookiecutter.utils import rmtree
    from cookiecutter import main
    cwd = os.getcwd()
    try:
        main.cookiecutter('tests/fake-repo-tmpl/', no_input=True)
    finally:
        os.chdir(cwd)
        rmtree('fake-repo-tmpl')


# Generated at 2022-06-11 20:12:00.321467
# Unit test for function find_template
def test_find_template():
    find_template(repo_dir)


# Generated at 2022-06-11 20:12:05.967559
# Unit test for function find_template
def test_find_template():
    """
    Verify that find_template works by testing on a repo with a template.
    """
    test_dir = 'tests/test-find-template/cookiecutter-pypackage'
    project_template = find_template(test_dir)
    assert project_template == 'tests/test-find-template/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:13.562847
# Unit test for function find_template
def test_find_template():
    repo = os.path.join(os.path.dirname(__file__), "fake-repo")

    # Check that raising exception works if there is no templated directory in
    # the repository
    os.rename(os.path.join(repo, "cookiecutter-pypackage"),
              os.path.join(repo, "cookiecutter-pypackage-not-templated"))
    try:
        find_template(repo)
    except NonTemplatedInputDirException:
        pass
    else:
        raise Exception("test_find_template failed: correctly-templated "
                        "repo did not return a value.")

    # Check that raising exception works if there is no directory in the
    # repository at all
    os.rmdir(repo)

# Generated at 2022-06-11 20:12:19.533756
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter import generate

    # Create a test template
    shutil.copytree('tests/files/test-cookiecutter-root', 'test-template')
    generate.generate_files(
        repo_dir='test-template',
        context={'cookiecutter': {}}
    )
    test_template = find_template('test-template')
    assert 'tests/files/test-cookiecutter-template' in test_template

    # Remove the test template
    shutil.rmtree('test-template')

# Generated at 2022-06-11 20:12:22.500657
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.join('tests', 'fake-repo-pre')) == os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:12:29.965865
# Unit test for function find_template
def test_find_template():
    """Ensure find_template is finding the correct directory."""
    from cookiecutter import utils

    repo_dir = utils.abs_path('tests/test-data/fake-repo-pre/')
    project_template = utils.find_template(repo_dir)
    assert os.path.isdir(project_template)

# Generated at 2022-06-11 20:12:35.629851
# Unit test for function find_template
def test_find_template():
    starting_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(starting_dir, 'fake-repo-pre-gen')
    logger.debug('Testing find_template with %s', repo_dir)
    assert(find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-11 20:12:38.365470
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert(project_template == 'tests/fake-repo-pre/cookiecutter-pypackage')

# Generated at 2022-06-11 20:12:44.790932
# Unit test for function find_template
def test_find_template():
    """Return a project template that is a child of the parent."""
    repo_dir = 'tests/fake-repo-tmpl'
    assert find_template(repo_dir) == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

test_find_template.setup = lambda: os.chdir(os.path.abspath(os.path.dirname(__file__)))

# Generated at 2022-06-11 20:12:47.118643
# Unit test for function find_template
def test_find_template():
    """Verify that find_template finds the project template"""
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 20:12:55.238209
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.config import DEFAULT_CONFIG

    repo_dir = DEFAULT_CONFIG['cookiecutters_dir'] + "/cookiecutter-pypackage"
    assert find_template(repo_dir) == repo_dir + "/{{cookiecutter.repo_name}}"

    # If there is no repo, then it should raise a NonTemplatedInputDirException
    with pytest.raises(NonTemplatedInputDirException):
        find_template(repo_dir + "/foo")

# Generated at 2022-06-11 20:13:03.520028
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    temp_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')

    # If a directory named ".cookiecutters" exist in user's home directory,
    # remove it.
    if os.path.exists(temp_dir):
        utils.rmtree(temp_dir)

    # Make a directory named ".cookiecutters" in user's home directory
    os.makedirs(temp_dir)

    # Change current working directory to ".cookiecutters" in user's home directory
    os.chdir(temp_dir)

    # Run cookiecutter on url

# Generated at 2022-06-11 20:13:10.614272
# Unit test for function find_template
def test_find_template():
    """Test that find_template finds the right directory to look in"""
    repo_dir = "../cookiecutter-pypackage/"
    assert find_template(repo_dir) == "../cookiecutter-pypackage/{{cookiecutter.repo_name}}"
    repo_dir = "../cookiecutter-pypackage"
    assert find_template(repo_dir) == "../cookiecutter-pypackage/{{cookiecutter.repo_name}}"


# Generated at 2022-06-11 20:13:15.134338
# Unit test for function find_template
def test_find_template():
    """Test the behaviour of `find_template`.

    Test that the function correctly finds the project template directory.
    """
    repo_dir = 'tests/test-repo/'
    project_template = 'tests/test-repo/{{cookiecutter.repo_name}}'

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:13:18.077096
# Unit test for function find_template
def test_find_template():
    assert(find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')
    assert(find_template('tests/fake-repo-pre') == 'tests/fake-repo-pre/my-fake-project')

# Generated at 2022-06-11 20:13:23.594842
# Unit test for function find_template
def test_find_template():
    """Verify that find_template correctly finds the project template."""
    project_template = find_template('tests/test-templates/good-repo')
    assert project_template == 'tests/test-templates/good-repo/cookiecutter-pypackage'



# Generated at 2022-06-11 20:13:28.724421
# Unit test for function find_template
def test_find_template():
    test_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'cookiecutter-example', 'example-repo1'
    )
    assert find_template(test_path) == os.path.join(test_path, 'example_{{test}}')



# Generated at 2022-06-11 20:13:33.299617
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath('tests/fake-repo-tmpl/')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:13:42.036537
# Unit test for function find_template
def test_find_template():
    assert find_template('../tests/fake-repo-pre') == '../tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('../tests/fake-repo-pre/') == '../tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('../tests/fake-repo-post') == '../tests/fake-repo-post/{{cookiecutter.repo_name}}'
    assert find_template('../tests/fake-repo-post/') == '../tests/fake-repo-post/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:42.469325
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:43.862808
# Unit test for function find_template
def test_find_template():
    find_template('/tmp')

# Generated at 2022-06-11 20:13:49.427303
# Unit test for function find_template
def test_find_template():
    """Verify the correct template dir is identified"""
    repo_dir = '/Users/audreyr/cookiecutters/python-package'
    project_template = find_template(repo_dir)

# Generated at 2022-06-11 20:13:58.924127
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected."""
    from .compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        # Create a directory structure that looks like:
        #     tmpdir
        #     |-- project_template-{{cookiecutter.repo_name}}
        #     |   |-- README.rst
        repo_dir = os.path.join(tmpdir, 'repo')
        os.makedirs(repo_dir)
        project_template = os.path.join(repo_dir, 'project_template-{{cookiecutter.repo_name}}')
        os.makedirs(project_template)
        readme = os.path.join(project_template, 'README.rst')
        open(readme, 'a').close()


# Generated at 2022-06-11 20:14:03.654783
# Unit test for function find_template
def test_find_template():
    """Test for function `find_template`."""
    repo_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'fake-repo'))
    assert find_template(repo_path) == os.path.join(repo_path, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:14:06.417997
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/code/cookiecutter-pypackage') == '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:13.561716
# Unit test for function find_template
def test_find_template():  # noqa
    from cookiecutter.tests.test_utils.test_files import empty_repo

    repo_dir = empty_repo.clone()
    template_dir = find_template(repo_dir)

    assert '{{cookiecutter.repo_name}}' in template_dir

# Generated at 2022-06-11 20:14:23.317182
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import shutil
    import tempfile

    from cookiecutter.tests.test_repositories import normalize_path

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary directory that will serve as a fake
    # cookiecutter.github.io clone.
    tmp_repo_dir = os.path.join(tmp_dir, 'cookiecutter-pypackage')
    os.makedirs(tmp_repo_dir)

    # Create a temporary directory that will serve as a fake
    # cookiecutter.github.io clone with templated dir.
    tmp_templated_repo_dir = os.path.join(tmp_dir, 'cookiecutter-foo-bar')

# Generated at 2022-06-11 20:14:27.056333
# Unit test for function find_template
def test_find_template():
    """
    Unit tests for the function find_template.
    """
    test_repo_dir = os.path.abspath('tests/test-cookiecutters/fake-repo')
    expected_template = os.path.abspath('tests/test-cookiecutters/fake-repo/cookiecutter-pypackage')

    assert find_template(test_repo_dir) == expected_template

# Generated at 2022-06-11 20:14:32.008996
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..')
    template_dir = find_template(repo_dir)
    assert os.path.basename(template_dir) == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:40.766493
# Unit test for function find_template
def test_find_template():
    """Test function for finding the project template inside a repo directory."""
    from cookiecutter.tests.test_data import (
        input_repo_with_cookiecutter_json_as_subdirectory_path)
    from cookiecutter.tests.test_data import (
        input_repo_with_subdirectory_containing_jinja2_path)

    repo_with_cookiecutter_json_as_subdirectory = \
        find_template(input_repo_with_cookiecutter_json_as_subdirectory_path)
    assert 'cookiecutter-pypackage' in repo_with_cookiecutter_json_as_subdirectory
    assert 'cookiecutter.json' in repo_with_cookiecutter_json_as_subdirectory


# Generated at 2022-06-11 20:14:48.956370
# Unit test for function find_template
def test_find_template():
    """Tests which directory is the project template."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), '../tests/fake-repo/'
        )
    )

    expected_result = os.path.join(repo_dir, 'cookiecutter-pypackage/')
    result = find_template(repo_dir)

    assert result == expected_result
    assert not find_template('/fake/path/')

# Generated at 2022-06-11 20:14:50.498956
# Unit test for function find_template
def test_find_template():
    find_template('/Users/dunyakirkali/Desktop/cookiecutter-django')


# Generated at 2022-06-11 20:14:53.023803
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo-pre/'
    assert find_template(repo_dir) == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:14:55.079050
# Unit test for function find_template
def test_find_template():
    assert find_template('docs') == 'docs/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:15:05.061869
# Unit test for function find_template
def test_find_template():
    # Test for existing project template
    sample_repo_dir = '/home/vanessa/Documents/cookiecutter/tests/fake-repo-tmpl'
    actual_template_dir_name = find_template(sample_repo_dir)
    expected_template_dir_name = '/home/vanessa/Documents/cookiecutter/tests/fake-repo-tmpl/{{cookiecutter.project_name}}'
    assert actual_template_dir_name == expected_template_dir_name

    # Test for non-existing project template
    sample_repo_dir = '/home/vanessa/Documents/cookiecutter/tests/fake-repo'
    try:
        find_template(sample_repo_dir)
    except Exception as e:
        assert type(e) == NonTemplatedInputDirException

# Generated at 2022-06-11 20:15:13.819026
# Unit test for function find_template
def test_find_template():
    """Test find_template function"""
    repo_dir = os.path.abspath(os.path.expanduser('~/.cookiecutters/cookiecutter-django'))
    assert find_template(repo_dir) == os.path.abspath(os.path.expanduser('~/.cookiecutters/cookiecutter-django/cookiecutter-django'))

# Generated at 2022-06-11 20:15:23.556315
# Unit test for function find_template
def test_find_template():
    from .test_generate import create_test_directory
    test_dir_contents = {
        'foo': {
            'cookiecutter': {
                'boo': {
                    'boo': '{{ cookiecutter.foo }}'
                }
            },
            'bar_project': {
                'bar': {
                    'bar': '{{ cookiecutter.foo }}'
                }
            }
        }
    }
    test_dir = create_test_directory(test_dir_contents)


# Generated at 2022-06-11 20:15:27.093006
# Unit test for function find_template
def test_find_template():
    repo_dir = "test_repo"
    project_template = find_template(repo_dir)
    print (project_template)


if __name__ == "__main__":
    # execute only if run as a script
    test_find_template()

# Generated at 2022-06-11 20:15:30.402656
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    assert find_template('/User/xyz/Desktop/cookiecutters/cookiecutter-pypackage') == '/Users/xyz/Desktop/cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:31.603623
# Unit test for function find_template
def test_find_template():
    find_template('{{cookiecutter.repo_dir}}')

# Generated at 2022-06-11 20:15:34.326462
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    try:
        find_template('.')
        assert False
    except NonTemplatedInputDirException:
        assert True
        return

# Generated at 2022-06-11 20:15:43.853678
# Unit test for function find_template
def test_find_template():
    """Tests if find_template() returns the name of the cookiecutter-project directory"""

    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Test for a valid directory
    template_dir = find_template('tests/fake-repo-tmpl/')
    assert template_dir == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}/'

    # Test for a non-templated, valid directory
    with pytest.raises(NonTemplatedInputDirException):
        template_dir = find_template('tests/fake-repo-no-tmpl/')

    # Test for an empty directory

# Generated at 2022-06-11 20:15:45.711046
# Unit test for function find_template
def test_find_template():
    find_template('/Users/mahmoud/Desktop/COURSERA/python')



# Generated at 2022-06-11 20:15:51.714727
# Unit test for function find_template
def test_find_template():
    '''Test helper function find_template used to locate template directory in
    cookiecutter project.
    '''
    import cookiecutter
    import shutil
    import tempfile

    output_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(output_dir, 'repo')
    shutil.copytree(os.path.join(
        os.path.dirname(cookiecutter.__file__), 'repos', '_cookiecutter-pypackage'), repo_dir
    )
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:15:55.523432
# Unit test for function find_template
def test_find_template():
    """Test for find_template()."""
    assert find_template(
        '/Users/audreyr/cookiecutters/cookiecutter-pypackage'
    ) == '/Users/audreyr/cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:10.228718
# Unit test for function find_template
def test_find_template():
    os.mkdir('my_dir')
    os.mkdir(os.path.join('my_dir', 'cookiecutter_my_dir'))
    os.mkdir(os.path.join('my_dir', 'my_dir'))

    template_dir = find_template('my_dir')

    # Tear down
    os.rmdir(os.path.join('my_dir', 'my_dir'))
    os.rmdir(os.path.join('my_dir', 'cookiecutter_my_dir'))
    os.rmdir('my_dir')

    assert template_dir == 'my_dir/cookiecutter_my_dir'

# Generated at 2022-06-11 20:16:19.902930
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/home/audreyr/cookiecutter-pypackage/pymodule'

##
#def find_template_in_directory(
#        template, output_dir=None, abbreviations=None, clone_to_dir=None,
#        checkout=None, no_input=False, extra_context=None):
#    """Find a template.
#
#    :param template: A directory containing a project template directory,
#        or a URL to a git repository.
#    :param output_dir: Directory where the generated project is to be located.
#    :param abbreviations: A dictionary of abbreviations, where each key
#        is an abbreviation for

# Generated at 2022-06-11 20:16:25.836186
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        os.path.pardir,
        'tests',
        'test-repo'
    )
    project_template = find_template(repo_dir)

    assert(project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

# Generated at 2022-06-11 20:16:29.474795
# Unit test for function find_template
def test_find_template():
    """
    Testing find_template
    """
    repo_dir = './tests/fake-repo-tmpl'
    project_template = find_template(repo_dir)
    assert project_template == './tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:16:35.781476
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'fake-repo'
    )

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'fake-project/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:16:43.182782
# Unit test for function find_template
def test_find_template():
    import tempfile
    dir_name = tempfile.mkdtemp()
    path = os.path.abspath(dir_name)
    os.mkdir(os.path.join(path, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(path, 'notcookiecutter'))

    assert find_template(path) == os.path.join(path, 'cookiecutter-pypackage')

# Generated at 2022-06-11 20:16:46.163701
# Unit test for function find_template
def test_find_template():
    """Test if the template is found in the return value."""
    repo_dir = '~/.cookiecutters/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert 'cookiecutter' in project_template

# Generated at 2022-06-11 20:16:56.872726
# Unit test for function find_template
def test_find_template():
    """Check that it finds the project template."""

    # Create a fake repo directory
    temp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(temp_dir, 'cookiecutter-foobar')
    os.makedirs(repo_dir)

    # Create a fake template inside the repo
    temp_template_dir = os.path.join(temp_dir, 'foobar-{{cookiecutter.repo_name}}')
    os.makedirs(temp_template_dir)

    # Make sure the template is found
    assert find_template(repo_dir) == temp_template_dir

    # remove temporary directory
    shutil.rmtree(temp_dir)



# Generated at 2022-06-11 20:17:02.937904
# Unit test for function find_template
def test_find_template():
    import tempfile
    repo_dir = tempfile.mkdtemp()

    project_template = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    os.mkdir(project_template)
    return_value = find_template(repo_dir)
    assert return_value == project_template

# Generated at 2022-06-11 20:17:05.245575
# Unit test for function find_template
def test_find_template():
    # TODO: Test the function.
    #       Need mock object to simulate a directory structure.
    pass

# Generated at 2022-06-11 20:17:21.603989
# Unit test for function find_template
def test_find_template():
    expected = 'fake-repo/{{cookiecutter.repo_name}}'

    os.listdir = lambda x: 'fake-repo'
    os.path.join = lambda *x: ''.join(x)

    actual = find_template('fake-repo')

    assert expected == actual

# Generated at 2022-06-11 20:17:22.086299
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:17:27.076698
# Unit test for function find_template
def test_find_template():
    """Verify proper operation of the find_template function."""
    project_template = find_template(os.path.join('tests', 'fake-repo-pre'))
    assert project_template == os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}'), project_template

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:17:37.877638
# Unit test for function find_template
def test_find_template():
    """Ensure the correct template is returned."""
    from .compat import TemporaryDirectory
    from .exceptions import NonTemplatedInputDirException

    program_dir = os.getcwd()
    with TemporaryDirectory() as tmp_dir:
        os.chdir(tmp_dir)

        # Check for simple case of templated dir name
        os.mkdir('cookiecutter-foo')
        project_template = find_template('.')
        assert project_template == os.path.abspath('./cookiecutter-foo')

        # Check when there are multiple templated dir names
        os.mkdir('cookiecutter-bar')
        project_template = find_template('.')
        assert project_template == os.path.abspath('./cookiecutter-foo')

        # Check temporary dir is cleaned up

# Generated at 2022-06-11 20:17:42.326430
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/TEST') == '/home/TEST/TEST{{ cookiecutter.repo_name }}'
    assert find_template('/home/TEST2') == '/home/TEST2/TEST2{{ cookiecutter.repo_name }}'
    

# Generated at 2022-06-11 20:17:45.326437
# Unit test for function find_template
def test_find_template():
    template = find_template("/Users/gib/dev/cookiecutter")
    print("template found: " + template)
    template = find_template("/Users/gib/dev/")
    print("template found: " + template)
#test_find_template()

# Generated at 2022-06-11 20:17:48.568884
# Unit test for function find_template
def test_find_template():
    repo_dir = '~/fake-repo'
    assert find_template(repo_dir) == '~/fake-repo/fake-repo-{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:17:55.578499
# Unit test for function find_template
def test_find_template():
    """
    Test find_template funtions
    
    :Example:
    
        >>> from cookiecutter.find import find_template
        >>> import os
        >>> repo_dir = os.path.join(os.getcwd(), 'tests/fake-repo-pre/')
        >>> find_template(repo_dir)
        '/home/lide/git/cookiecutter-personal/tests/fake-repo-pre/cookiecutter-pypackage'

    """    
    
    pass

# Generated at 2022-06-11 20:17:57.317130
# Unit test for function find_template
def test_find_template():
    find_template('/Users/kushan/Documents/GitHub/cookiecutter')
    assert 1 == 1

# Generated at 2022-06-11 20:18:00.876302
# Unit test for function find_template
def test_find_template():
    """Find the project template from the Cookiecutter directory."""
    repo_dir = 'tests/files/fake-repo'
    project_template = find_template(repo_dir)

    assert isinstance(project_template, str)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-11 20:18:27.094390
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake_repo') == 'tests/fake_repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:18:33.538212
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template."""
    test_dir = os.path.abspath('/Users/Shared/workspace/cookiecutter/tests/find_template')
    repo_dir = os.path.abspath('/Users/Shared/workspace/cookiecutter/tests/find_template/foobarbaz')

    project_template = find_template(repo_dir)
    print(project_template)
    print('test_find_template')


# Generated at 2022-06-11 20:18:42.311599
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        repo_dir = tmpdir
        repo_dir_contents = {
            'cookiecutter-pypackage': '',
            'cookiecutter-pypackage-jinja': '',
        }
        expected_template = 'cookiecutter-pypackage'

        for dirname in repo_dir_contents:
            os.mkdir(os.path.join(repo_dir, dirname))

        logger.debug(
            'Created temporary directory %s for testing find_template',
            repo_dir
        )

        found_template = find_template(repo_dir)
        assert found_template == expected_template

# Generated at 2022-06-11 20:18:52.860407
# Unit test for function find_template
def test_find_template():
    """Verify find_template works as expected."""
    from cookiecutter import generate
    from cookiecutter import repository
    from cookiecutter import settings

    cwd = os.getcwd()

    settings.clear_cache()

    # Create a new, empty directory for this test
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)

    # Create a git repo from the tests/fake-repo-pre/ directory
    test_pre_repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            'fake-repo-pre',
        )
    )
    repository.run('git', 'init')

# Generated at 2022-06-11 20:18:57.732637
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/files/fake-repo'
    res_path = find_template(repo_dir)
    assert res_path == os.path.join(repo_dir, '{{cookiecutter.cookiecutter_project_name}}')


# Generated at 2022-06-11 20:19:04.205894
# Unit test for function find_template
def test_find_template():
    def mock_listdir(path):
        return ['abc', 'abcdefg', 'abc123', 'abc {{ cookiecutter.project_name }}']

    old_listdir = os.listdir
    os.listdir = mock_listdir

    repo_dir = 'fakerepo'

    try:
        template = find_template(repo_dir)
        assert template == 'fakerepo/abc {{ cookiecutter.project_name }}'
    finally:
        os.listdir = old_listdir


# Generated at 2022-06-11 20:19:05.475046
# Unit test for function find_template
def test_find_template():
    find_template('cookiecutter-gh-pages')

# Generated at 2022-06-11 20:19:09.413065
# Unit test for function find_template
def test_find_template():
    assert find_template("./tests/fake-repo-pre/") == "./tests/fake-repo-pre/cookiecutter-pypackage"
    assert find_template("./tests/fake-repo/") == "./tests/fake-repo/cookiecutter-pypackage"


# Generated at 2022-06-11 20:19:14.375468
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'tests', 'test-find-template')

    project_template = find_template(repo_dir)

    assert os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}') in project_template


# Generated at 2022-06-11 20:19:18.657020
# Unit test for function find_template
def test_find_template():
    file_dir = os.path.dirname(os.path.abspath(__file__))
    finder = os.path.join(file_dir, '..', '..', 'tests', 'test-find-template')
    project_template = find_template(finder)
    assert project_template == os.path.join(finder, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:20:24.128695
# Unit test for function find_template
def test_find_template():
    try:
        find_template('/Users/nathan/src/py2')
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

# Generated at 2022-06-11 20:20:28.204265
# Unit test for function find_template
def test_find_template():

    project_template = find_template('tests/test-repo-pre/hooks')
    project_template = os.path.split(project_template)[-1]

    assert project_template == '{{cookiecutter.repo_name}}', project_template


# Generated at 2022-06-11 20:20:30.774908
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:20:36.088324
# Unit test for function find_template
def test_find_template():
    """Verify expected project template is found."""
    from cookiecutter.tests.test_utils import TEST_COOKIE_DIR
    assert find_template(repo_dir=TEST_COOKIE_DIR) == os.path.join(
        TEST_COOKIE_DIR, 'jquery-plugin'
    )

# Generated at 2022-06-11 20:20:39.768201
# Unit test for function find_template
def test_find_template():
    os.system("mkdir -p ~/.cookiecutter/fake_repo/fake_project")
    assert find_template("~/.cookiecutter/fake_repo") == "~/.cookiecutter/fake_repo/fake_project"
    os.system("rm -rf ~/.cookiecutter")

# Generated at 2022-06-11 20:20:48.064709
# Unit test for function find_template
def test_find_template():
    """Test that a non-templated directory is not found to be a template."""
    test_dir_name = 'testdir'
    try:
        os.mkdir(test_dir_name)
        test_dir = os.path.join(os.path.abspath(os.path.curdir),
                                test_dir_name)
        assert find_template(test_dir) is None
    finally:
        os.rmdir(test_dir)

# Generated at 2022-06-11 20:20:51.935732
# Unit test for function find_template
def test_find_template():
    """Verify the correct project template is identified."""
    from cookiecutter.main import cookiecutter

    result = cookiecutter('tests/test-find-template')
    assert os.path.relpath(result, os.getcwd()) == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:21:01.670274
# Unit test for function find_template
def test_find_template():
    import tempfile
    file_dir = tempfile.mkdtemp()
    test_file = file_dir + '/testfile'
    untemplated_dir = tempfile.mkdtemp(dir=file_dir)
    templated_dir = tempfile.mkdtemp(dir=file_dir)
    templated_subdir = templated_dir + '/subdir'
    os.mkdir(templated_subdir)
    templated_subfile = templated_subdir + '/subfile'
    os.mknod(test_file)
    os.mknod(templated_subfile)

    assert find_template(file_dir) == templated_subfile

# Generated at 2022-06-11 20:21:09.812723
# Unit test for function find_template
def test_find_template():
    repo_name = 'cookiecutter-pypackage'
    repo_path = 'https://github.com/audreyr/' + repo_name
    repo_dir = os.path.join('tests', 'test-find-template', repo_name)
    # Mock repo_dir
    os.makedirs(repo_dir)

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Remove repo_dir
    os.removedirs(repo_dir)

# Generated at 2022-06-11 20:21:11.385794
# Unit test for function find_template
def test_find_template():
    """Test whether ``find_template`` works."""

