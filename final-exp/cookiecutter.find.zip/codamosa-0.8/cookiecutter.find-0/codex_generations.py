

# Generated at 2022-06-11 20:11:46.480817
# Unit test for function find_template
def test_find_template():
    """Test function find_template"""
    # Walk into test_find_template_correct and test on that folder
    path = os.path.join(os.path.dirname(__file__), 
        'test_find_template_correct')
    # Should return the correct path to cookiecutter.json
    assert find_template(path) == os.path.join(path, '{{cookiecutter.repo_name}}')

    # Walk into test_find_template_nonexist and test on that folder
    path = os.path.join(os.path.dirname(__file__), 
        'test_find_template_nonexist')
    # Should give a NonTemplatedInputDirException
    assert find_template(path) == NonTemplatedInputDirException

    # Walk into test_find_template_noc

# Generated at 2022-06-11 20:11:50.910397
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from_repo_dir = '/tmp/cookiecutter-test-repo/'
    project_template = find_template(from_repo_dir)
    assert project_template == '/tmp/cookiecutter-test-repo/{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:11:54.885565
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir/cookiecutter-{{cookiecutter.repo_name}}'
    assert find_template('repo_dir') == 'repo_dir/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:01.136503
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter.exceptions import NonTemplatedInputDirException

    cookiecutter('.', no_input=True)
    project_template = find_template('.')
    assert project_template == './{{cookiecutter.repo_name}}', project_template

    cookiecutter('./tests/fake-repo-templated/', no_input=True)
    project_template = find_template('./tests/fake-repo-templated/')
    assert project_template == './tests/fake-repo-templated/{{cookiecutter.repo_name}}'

    # Tests non-templated input dir.
    try:
        cookiecutter('.')
    except NonTemplatedInputDirException:
        assert 1 == 1

# Generated at 2022-06-11 20:12:02.094458
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    pass

# Generated at 2022-06-11 20:12:08.065601
# Unit test for function find_template
def test_find_template():
    """Verify the correct project_template directory is returned."""
    cwd = os.getcwd()
    repo_dir = os.path.join(cwd, 'tests/fake-repo-pre/')

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:12:10.225037
# Unit test for function find_template
def test_find_template():
    find_template('C:/Users/aalaei/Desktop/project')

# Generated at 2022-06-11 20:12:16.223792
# Unit test for function find_template
def test_find_template():
    """Verify that find_template can locate the project template."""
    here = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(here, 'fake-repo')
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    found = find_template(repo_dir)

    assert expected == found

# Generated at 2022-06-11 20:12:19.953310
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__),
                            '..', '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert project_template == expected

# Generated at 2022-06-11 20:12:24.089542
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.getcwd(), 'tests', 'test-find-template')
    project_template = find_template(repo_dir)
    assert 'frontend/backend' in project_template
    assert '{{' in project_template
    assert '}}' in project_template

# Generated at 2022-06-11 20:12:28.158292
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template`."""
    # TODO: write unit tests
    pass

# Generated at 2022-06-11 20:12:34.174364
# Unit test for function find_template
def test_find_template():
    template = find_template('./tests/fake-repo-pre/')
    assert template == './tests/fake-repo-pre/{{cookiecutter.repo_name}}'

    try:
        assert find_template('./tests/fake-repo-post/')
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'find_template did not raise an exception.'

# Generated at 2022-06-11 20:12:34.722425
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:12:37.599686
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find project template in repo root."""
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:47.119557
# Unit test for function find_template
def test_find_template():
    """Ensure we can find the project template."""
    logging.basicConfig(level=logging.DEBUG)
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'testing',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    try:
        project_template = find_template(repo_dir)
    except NonTemplatedInputDirException as err:
        raise err
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-11 20:12:57.074648
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the right template project."""
    cursor = os.getcwd()

    test_home = os.path.join(cursor, 'tests', 'test-find-template')
    test_sub_dir = os.path.join(test_home, 'fake-repo', '{{cookiecutter.project_slug}}')

    os.chdir(test_sub_dir)
    project_template = find_template('fake-repo')

    assert project_template == 'fake-repo/{{cookiecutter.project_slug}}', \
        'project_template should be {0}'.format(test_sub_dir)

    os.chdir(cursor)

# Generated at 2022-06-11 20:13:01.615326
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo-pre')
    project_template = 'cookiecutter-pypackage'
    assert find_template(repo_dir) == os.path.join(repo_dir, project_template)

# Generated at 2022-06-11 20:13:06.895700
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    # Create empty dir
    import tempfile
    tmp_dir = tempfile.mkdtemp()

    # Verify template
    template = find_template(tmp_dir)
    assert template == os.path.join(tmp_dir, 'cookiecutter')

    # Remove dir
    import shutil
    shutil.rmtree(tmp_dir)

# Test for function find_template
test_find_template()

# Generated at 2022-06-11 20:13:11.008670
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/projects/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/Users/audreyr/projects/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:12.160481
# Unit test for function find_template
def test_find_template():
    find_template('cookiecutter')

# Generated at 2022-06-11 20:13:15.725644
# Unit test for function find_template
def test_find_template():
    # TODO: add a test repo to cookiecutter that this test can be run against
    # assert os.path.exists(project_template)
    pass

# Generated at 2022-06-11 20:13:18.532926
# Unit test for function find_template
def test_find_template():
    test_dir = 'C:/Users/kingd/Desktop/Cookiecutter-Practice/example_templates/flat'
    project_template = find_template(test_dir)
    assert project_template == 'C:/Users/kingd/Desktop/Cookiecutter-Practice/example_templates/flat/{{cookiecutter.project_name}}'

# Generated at 2022-06-11 20:13:21.748644
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    # This is basically an integration test that covers lots of things
    assert os.path.isdir(find_template('tests/test-repo-pre/'))



# Generated at 2022-06-11 20:13:27.819804
# Unit test for function find_template
def test_find_template():
    """Test a sample directory for find_template.
    """
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'test-find-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-11 20:13:35.076459
# Unit test for function find_template
def test_find_template():
    """Verify that the project template is being found."""
    # Given: A directory with a cookiecutter project template
    target_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'fake-repo', 'cookiecutter-pypackage'
    )

    # When: find_template() is called with the directory
    result = find_template(target_dir)

    # Then: The result should be the path to the project template directory
    expected_result = os.path.join(target_dir, 'cookiecutter-pypackage')
    assert result == expected_result

# Generated at 2022-06-11 20:13:36.380579
# Unit test for function find_template

# Generated at 2022-06-11 20:13:45.305263
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    # Version 1: <input_dir> contains only non-templated directories
    assert find_template('tests/test-find-template/input1') == None
    # Version 2: <input_dir> contains only templated directories
    assert find_template('tests/test-find-template/input2') == \
        'tests/test-find-template/input2/{{cookiecutter.cookie_type}}'
    # Version 3: <input_dir> contains both templated and non-templated directories
    assert find_template('tests/test-find-template/input3') == \
        'tests/test-find-template/input3/{{cookiecutter.cookie_type}}'
    # Version 4: <input_dir> contains only non-templated

# Generated at 2022-06-11 20:13:47.001837
# Unit test for function find_template
def test_find_template():
    # TODO
    pass

# Generated at 2022-06-11 20:13:56.744901
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    repo_dir = '/home/giulia/tmp/pycon-italy-skeleton'
    logger.debug('Searching %s for the project template.', repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger

# Generated at 2022-06-11 20:14:05.112584
# Unit test for function find_template
def test_find_template():
    from cookiecutter import prompt
    from cookiecutter import repository

    clone_to_dir = 'tests/fake-repo-tmpl/'
    if not os.path.isdir(clone_to_dir):
        os.makedirs(clone_to_dir)

    try:
        repository.determine_repo_dir({'repo_dir': 'tests/fake-repo-tmpl/'},
                                      'tests/fake-repo-tmpl/')
        result = find_template('tests/fake-repo-tmpl/')
        assert result == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    except IOError:
        assert False

    rmtree('tests/fake-repo-tmpl/')
    prompt.read_user_variable

# Generated at 2022-06-11 20:14:19.356835
# Unit test for function find_template
def test_find_template():  # noqa
    from .fixtures import nikola_launcher
    from .fixtures import create_folder
    from .compat import patch
    from .compat import mock

    expected = 'fake-template'

    with patch('os.path.join') as mock_join:
        mock_join.return_value = expected
        with patch('os.listdir') as mock_listdir:
            mock_listdir.return_value = [expected,]
            result = find_template(nikola_launcher)
            assert result == expected
            assert mock_join

    with patch('os.path.join') as mock_join:
        mock_join.return_value = expected
        m = mock.Mock()
        with patch('os.listdir') as mock_listdir:
            m.side_effect = [expected,]

# Generated at 2022-06-11 20:14:20.314058
# Unit test for function find_template
def test_find_template():
    find_template('tests')

# Generated at 2022-06-11 20:14:27.833848
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    from cookiecutter.tests.test_repos import cookiecutter_py_repo
    from cookiecutter.tests.test_repos import small_repo
    from cookiecutter import utils

    # Test for case of a valid repo dir
    output_template = os.path.join(cookiecutter_py_repo,
                                   '{{cookiecutter.repo_name}}')
    # logger.debug(output_template)
    assert find_template(cookiecutter_py_repo) == output_template

    # Test for case of a repo dir with no templated dir

# Generated at 2022-06-11 20:14:34.013545
# Unit test for function find_template
def test_find_template():
    """
    this is a test for the function find_template found in find.py
    """

    repo_dir = r'C:\Users\BHodges\AppData\Local\Programs\Python\Python36\Lib\site-packages\cookiecutter\test_templates'
    project_template = r'C:\Users\BHodges\AppData\Local\Programs\Python\Python36\Lib\site-packages\cookiecutter\test_templates\simple'

    find_template(repo_dir)

# Generated at 2022-06-11 20:14:40.990808
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from shutil import rmtree

    repo_dir = 'tests/test-find-template'
    utils.make_sure_path_exists(repo_dir)
    cookiecutter(
        'tests/fake-repo-pre/',
        no_input=True,
        checkout='master',
        repo_dir=repo_dir,
        overwrite_if_exists=True
    )
    template_dir = find_template(repo_dir)
    assert template_dir == 'tests/test-find-template/{{cookiecutter.repo_name}}'

    rmtree(repo_dir)

# Generated at 2022-06-11 20:14:52.284457
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    from cookiecutter import utils

    temp_folder = 'tests/files/find_template/'
    temp_repo_dir = os.path.join(temp_folder, 'fake-repo')
    temp_template_dir = os.path.join(temp_folder, 'test-template')

    if os.path.isdir(temp_template_dir):
        shutil.rmtree(temp_template_dir)

    if os.path.isdir(temp_repo_dir):
        shutil.rmtree(temp_repo_dir)

    shutil.copytree('tests/files/test-template/', temp_repo_dir)

    # Path to template dir inside new repo

# Generated at 2022-06-11 20:15:00.457025
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    repo_dir = os.getcwd()
    repo_dir_contents = os.listdir(repo_dir)
    os.remove(os.path.join(os.getcwd(), 'tests/test_folder/test_template/{{cookiecutter.repo_name}}'))

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    assert project_template == None


# Generated at 2022-06-11 20:15:09.054332
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    # TODO: This test is failing, but I can't figure out why
    import os
    import shutil
    import tempfile
    import unittest

    from cookiecutter.exceptions import NonTemplatedInputDirException

    class TestFindTemplate(unittest.TestCase):
        """Unit test for find_template."""

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_find_template(self):
            """
            Test the find_template function.
            """
            fixtures_dir = 'tests/test-find-template'


# Generated at 2022-06-11 20:15:18.872398
# Unit test for function find_template
def test_find_template():
    """Verify that find_template correctly identifies a Cookiecutter project."""
    import shutil
    import tempfile
    new_temp_dir = os.path.join(tempfile.gettempdir(), 'cookiecutter-testing')
    shutil.copytree('tests/test-cookiecutters/{{cookiecutter.repo_name}}',
                    new_temp_dir)
    project_template = find_template(os.path.join(new_temp_dir,
                                       '{{cookiecutter.repo_name}}'))
    assert project_template.endswith('cookiecutter-testing/'
                                     '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:15:26.101147
# Unit test for function find_template
def test_find_template():
    """Test the function to find templates in a repo directory."""

    # from cookiecutter.tests.test_find import my_dir

    # my_repo_dir = '../'
    # my_repo_dir = os.path.join(my_dir, my_repo_dir)
    # my_repo_dir = os.path.abspath(my_repo_dir)

    # project_template = find_template(my_repo_dir)

    # assert project_template == os.path.join(my_repo_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-11 20:15:31.077129
# Unit test for function find_template
def test_find_template():
    """
    Test function to find the cookiecutter template in a repo
    """

    find_template(repo_dir)

# Generated at 2022-06-11 20:15:37.569917
# Unit test for function find_template
def test_find_template():
    custom_template = find_template(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'local_repo_template'))
    expected_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'local_repo_template', '{{cookiecutter.repo_name}}')
    assert custom_template == expected_path

# Generated at 2022-06-11 20:15:44.894739
# Unit test for function find_template
def test_find_template():
    repo_dir = '/src/templates/cookiecutter-pypackage'

    repo_dir_contents = os.listdir(repo_dir)
    assert repo_dir_contents == [
        '.bumpversion.cfg', 'README.rst', '{{cookiecutter.repo_name}}', 'hooks', '.travis.yml', '.gitmodules', 'tests',
        '.coveragerc', '.gitattributes', 'tox.ini', '.gitignore'
    ]

    project_template = find_template(repo_dir)
    assert project_template is not None
    assert project_template == '/src/templates/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

if __name__ == "__main__":
    test_find_template()

# Generated at 2022-06-11 20:15:51.547105
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import tempfile
    from cookiecutter import main

    repo_dir = tempfile.mkdtemp()
    main.cookiecutter('tests/test-repo-pre/', no_input=True, output_dir=repo_dir)
    template_path = find_template(repo_dir)

    assert template_path == os.path.join(repo_dir, 'fake-project-{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:15:53.371420
# Unit test for function find_template
def test_find_template():
    find_template("/Users/tommy/Projects/cookiecutter-django/cookiecutter-django")


# Generated at 2022-06-11 20:15:55.406321
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == './default_cookiecutter'
    assert find_template('..') == '../default_cookiecutter'
    assert find_template('./default_cookiecutter') == './default_cookiecutter/default_cookiecutter'

# Generated at 2022-06-11 20:15:57.278710
# Unit test for function find_template
def test_find_template():
    """
    Find template and test it
    """
    assert find_template('.') == './game-project-cookiecutter'

# Generated at 2022-06-11 20:15:59.347599
# Unit test for function find_template
def test_find_template():
    logger.info("Test find_template")
    assert find_template("/tmp")

# Generated at 2022-06-11 20:16:01.520014
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template"""
    from cookiecutter.tests.test_find_template import find_template_test

    find_template_test(find_template)

# Generated at 2022-06-11 20:16:03.855575
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    find_template(repo_dir)

# Generated at 2022-06-11 20:16:17.110018
# Unit test for function find_template
def test_find_template():
    cwd = os.getcwd()

    repo_dir = os.path.join(cwd, 'tests', 'non_repo_yet')
    os.mkdir(repo_dir)
    assert find_template(repo_dir) is None

    repo_dir = os.path.join(cwd, 'tests', 'fake-repo-tmpl')
    assert os.path.join(repo_dir, '{{cookiecutter.repo_name}}') == find_template(repo_dir)

# Generated at 2022-06-11 20:16:22.452593
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    this_dir = os.path.abspath(os.path.dirname(__file__))
    fixture_dir = os.path.join(this_dir, '../tests/fixtures/fake-repo/')

    project_template = find_template(fixture_dir)
    expected_template_dir = os.path.join(fixture_dir, 'cookiecutter-pypackage')

    assert project_template == expected_template_dir

# Generated at 2022-06-11 20:16:31.232611
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""

    # Create a temporary directory, than create a subdirectory, and
    # create a dummy "project" within that subdirectory.
    temp_dir = tempfile.mkdtemp()
    test_dir = os.path.join(temp_dir, 'test_dir')
    os.mkdir(test_dir)
    os.mkdir(os.path.join(test_dir, '{{cookiecutter.repo_name}}'))
    test_repo_dir = os.path.join(test_dir)

    # Ensure that find_template returns the correct path
    assert find_template(test_repo_dir) == os.path.join(temp_dir, 'test_dir', '{{cookiecutter.repo_name}}')

    # Clean up

# Generated at 2022-06-11 20:16:34.557560
# Unit test for function find_template
def test_find_template():
    repo_dir = 'repo'
    assert find_template(repo_dir) == 'repo/{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:16:40.023791
# Unit test for function find_template
def test_find_template():
    """ Verify the `find_template` function works as expected. """
    test_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(test_dir, 'fake-repo')

    result = find_template(repo_dir)
    assert os.path.abspath(result) == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-11 20:16:44.572322
# Unit test for function find_template
def test_find_template():
    """Test that find_template() returns the appropriate value."""
    template_dir = 'tests/fake-repo-tmpl/'
    assert 'fake-repo-tmpl/{{cookiecutter.repo_name}}' == find_template(
        template_dir)

# Generated at 2022-06-11 20:16:49.981573
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath("C:/Users/Jordi/Desktop/cookiecutter-pypackage")
    output = find_template(repo_dir)
    assert output == "C:/Users/Jordi/Desktop/cookiecutter-pypackage/{{cookiecutter.project_slug}}"

# Generated at 2022-06-11 20:16:55.685334
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.join(os.path.dirname(__file__), '..', 'tests',
                            'test-output', 'find-template-test')
    expected_template_dir = os.path.join(test_dir, 'py-module')
    template_dir = find_template(test_dir)
    assert template_dir == expected_template_dir

# Generated at 2022-06-11 20:17:00.222651
# Unit test for function find_template
def test_find_template():
    """Return the only directory with cookiecutter in the name."""
    os.listdir = lambda x: ['something', 'cookiecutter-foo']

    actual = find_template(repo_dir='foo')
    assert actual == 'foo/cookiecutter-foo'



# Generated at 2022-06-11 20:17:08.334088
# Unit test for function find_template
def test_find_template():
    import shutil
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.main import cookiecutter

    tmp_dir = TemporaryDirectory()
    try:
        cookiecutter(
            'tests/test-repo-pre/',
            no_input=True,
            output_dir=tmp_dir.name
        )
        project_template = find_template(tmp_dir.name)
        assert 'tests/test-repo-pre/{{cookiecutter.repo_name}}' == project_template
    finally:
        tmp_dir.cleanup()

# Generated at 2022-06-11 20:17:32.429456
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo-pre/') == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-repo-pre/cookiecutter-pypackage/') == 'tests/test-repo-pre/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-repo-pre/cookiecutter-pypackage') == 'tests/test-repo-pre/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:17:33.523333
# Unit test for function find_template
def test_find_template():
    # TODO: Write unit tests
    pass

# Generated at 2022-06-11 20:17:36.324312
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/code/cookiecutter-pypackage/') == '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:17:41.506567
# Unit test for function find_template
def test_find_template():
    """Test finding of project template."""
    try:
        template = find_template('/Users/audreyr/src/cookiecutter-pypackage')
    except NonTemplatedInputDirException:
        template = None

    assert template == '/Users/audreyr/src/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:17:42.034790
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:17:50.627639
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template()
    """

    # case 1: note that 'cookiecutter-pypackage-mrj' gets renamed 'cookiecutter' by the time it gets here
    dir1 = '/home/username/cookiecutter_test/cookiecutter-pypackage-mrj'
    assert find_template(dir1) == '/home/username/cookiecutter_test/cookiecutter/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    # case 2:
    dir2 = '/home/username/cookiecutter_test/cookiecutter-pypackage'
    assert find_template(dir2) == '/home/username/cookiecutter_test/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

    #

# Generated at 2022-06-11 20:17:57.057698
# Unit test for function find_template
def test_find_template():
    """
    Checks that `find_template()` returns the correct directory.
    """
    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(repo_dir, 'fake-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:18:00.937272
# Unit test for function find_template
def test_find_template():
    this_folder = os.path.dirname(os.path.abspath(__file__))
    example_project_dir = os.path.join(this_folder,
                                       'tests/test-find-template-repo/')

    assert find_template(example_project_dir) == os.path.join(
        example_project_dir, '{{cookiecutter.repo_name}}')



# Generated at 2022-06-11 20:18:02.149133
# Unit test for function find_template
def test_find_template():
    """Test suite for find_template"""
    pass


# Generated at 2022-06-11 20:18:07.037257
# Unit test for function find_template
def test_find_template():
    """Verify the correct template directory is returned."""
    test_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-pre/')
    assert find_template(test_dir) == os.path.join(test_dir, '{{cookiecutter.repo_name}}/')

# Generated at 2022-06-11 20:18:39.557869
# Unit test for function find_template
def test_find_template():
    template_dir = 'tests/fake-repo-pre/'
    project_template = find_template(template_dir)
    expected_template = os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    assert project_template == expected_template

# Generated at 2022-06-11 20:18:44.483918
# Unit test for function find_template
def test_find_template():
    here = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(here, 'fake-repo', '')
    assert find_template(repo_dir) == os.path.join(here, 'fake-repo', 'fake-project', '')



# Generated at 2022-06-11 20:18:50.047265
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns the template in the test repo"""
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-repo'))
    project_template = find_template(repo_dir)
    expected_project_template = os.path.abspath(os.path.join(repo_dir, 'tests', 'test-template'))
    assert project_template == expected_project_template

# Generated at 2022-06-11 20:18:57.264740
# Unit test for function find_template
def test_find_template():
    from cookiecutter import main
    from cookiecutter.utils import rmtree
    from git import Repo

    repo = "https://github.com/audreyr/cookiecutter-pypackage.git"
    output_dir = "tests/fake-repo"
    context_file = "tests/fake-repo/cookiecutter.json"
    options = {'checkout': 'master'}

    logger.debug('Cloning %s into %s', repo, output_dir)
    Repo.clone_from(repo, output_dir, **options)

    project_template = find_template(output_dir)

    # Clean up repo clone
    rmtree(output_dir)

    assert project_template is not None

# Generated at 2022-06-11 20:19:04.319330
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.main import cookiecutter

    repo_dir = tempfile.mkdtemp()
    try:
        cookiecutter(
            'tests/test-repo-pre/',
            no_input=True,
            output_dir=repo_dir,
        )
        template = find_template(repo_dir)
        assert os.path.basename(template) == 'bootstrap-django'
    finally:
        shutil.rmtree(repo_dir)



# Generated at 2022-06-11 20:19:07.248333
# Unit test for function find_template
def test_find_template():
    """to test find_template function"""
    repo_dir = '.'
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:19:08.584121
# Unit test for function find_template
def test_find_template():
    input_dir = 'tests'
    find_template(input_dir)

# Generated at 2022-06-11 20:19:11.307041
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests/fake-repo-pre/{{cookiecutter.repo_name}}"
    project_template = find_template(repo_dir)
    assert project_template == repo_dir


# Generated at 2022-06-11 20:19:14.705963
# Unit test for function find_template
def test_find_template():
    """Verify CookiecutterDjango's find_template function."""
    assert find_template('tests/test-output/test-cookiecutter-django') == 'tests/test-output/test-cookiecutter-django/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:19:17.944532
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/audreyr/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:20:31.919624
# Unit test for function find_template
def test_find_template():
    """Test find_template() works."""
    from tests.test_utils import TEST_TEMPLATES_DIR
    template = find_template(TEST_TEMPLATES_DIR)
    assert 'cookiecutter-pypackage' in template
    assert '{{' in template
    assert '}}' in template



# Generated at 2022-06-11 20:20:38.622045
# Unit test for function find_template
def test_find_template():
    this_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(this_dir, '../tests/fake-repo-tmpl')

    found = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert found == expected

# Generated at 2022-06-11 20:20:41.592994
# Unit test for function find_template
def test_find_template():
    path_to_test_repo = os.path.join(os.path.dirname(__file__), "test-repo")
    assert find_template(path_to_test_repo) == os.path.join(
        path_to_test_repo, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:20:51.901485
# Unit test for function find_template
def test_find_template():
    """Check that find_template can find the template directory."""
    from cookiecutter.utils import rmtree

    import pytest

    from .fixtures import cookiecutters_dir

    with cookiecutters_dir.as_cwd():

        find_template(repo_dir=os.curdir)

    # Check that find_template raises exception when a non-templated directory is given
    with cookiecutters_dir.join('no_template').as_cwd():
        with pytest.raises(NonTemplatedInputDirException):
            find_template(repo_dir=os.curdir)

    # Tidy up
    with cookiecutters_dir.as_cwd():
        rmtree('no_template')



# Generated at 2022-06-11 20:20:55.790824
# Unit test for function find_template
def test_find_template():
    """
    Find the project template if it's unzipped in the current directory.
    """
    find_template(os.path.join(os.path.dirname(__file__), '..', '..'))


# Generated at 2022-06-11 20:21:00.464884
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-find-template'
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir,
                                            '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:21:10.663072
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from cookiecutter import utils
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as repo_dir:
        template = os.path.join(repo_dir, 'simple-example')
        os.makedirs(template)
        utils.workaround_directory_traversal_on_windows(repo_dir)

        repo_dir_files = [
            os.path.join(template, 'simple-example.txt'),
            os.path.join(template, '{% raw %}simple-example-with-jinja.txt{% endraw %}'),
            os.path.join(repo_dir, 'non-template-file.txt')
        ]

# Generated at 2022-06-11 20:21:13.828943
# Unit test for function find_template
def test_find_template():

    project_template = find_template(repo_dir='/Users/audreyr/projects/cookiecutter-pypackage')

    assert 'cookiecutter' in project_template
    assert '{{' in project_template
    assert '}}' in project_template


# Generated at 2022-06-11 20:21:19.925437
# Unit test for function find_template
def test_find_template():
    """Test function find_template()."""
    new_repo_dir = 'tests/fake-repo'
    repo_dir_contents = os.listdir(new_repo_dir)
    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break
    expected_project_template = 'cookiecutter-{{cookiecutter.repo_name}}'
    assert project_template == expected_project_template

# Generated at 2022-06-11 20:21:24.925685
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    repo_dir = '/Users/hackebrot/gitrepos/cookiecutter-pypackage'
    project_template = '/Users/hackebrot/gitrepos/cookiecutter-pypackage/cookiecutter-pypackage'

    assert find_template(repo_dir) == project_template