

# Generated at 2022-06-11 20:11:35.462829
# Unit test for function find_template
def test_find_template():
    assert find_template('/Volumes/home/ctheune/Projects/Providence/python/') == '/Volumes/home/ctheune/Projects/Providence/python/{{cookiecutter.project_name}}/'

# Generated at 2022-06-11 20:11:38.306030
# Unit test for function find_template
def test_find_template():
    assert find_template('/foo/bar') == '/foo/bar/{{cookiecutter.repo_name}}'

#TODO tests for non-templated dirs

# Generated at 2022-06-11 20:11:43.223344
# Unit test for function find_template
def test_find_template():
    repo_dir = r'C:\Users\G\Desktop\Git\cookiecutter-pypackage'

    project_template = find_template(repo_dir)
    assert (project_template == r'C:\Users\G\Desktop\Git\cookiecutter-pypackage\{{cookiecutter.repo_name}}') == True

# Generated at 2022-06-11 20:11:46.437124
# Unit test for function find_template
def test_find_template():
    """Test function for function find_template"""

    assert find_template('test_example/test_example') == 'test_example/test_example/test_template'
    assert find_template('test_example/not') is None

# Generated at 2022-06-11 20:11:50.595015
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = 'tests/fake-repo-pre-gen'
    project_template = find_template(repo_dir)
    assert 'fake-repo-pre-gen/{{cookiecutter.repo_name}}' == project_template

# Generated at 2022-06-11 20:11:52.862575
# Unit test for function find_template
def test_find_template():
    repo_dir = ""
    assert find_template(repo_dir) is None

# Generated at 2022-06-11 20:11:56.770401
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/Documents/GitHub/cookiecutter-pypackage/') == '/Users/audreyr/Documents/GitHub/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:01.315743
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutters/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    expected_project_template = '/Users/audreyr/cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert project_template == expected_project_template

# Generated at 2022-06-11 20:12:07.079871
# Unit test for function find_template
def test_find_template():
    """Verify cookiecutter/cookiecutter-pypackage is detected as the project template."""
    expected = 'cookiecutter/cookiecutter-pypackage'
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    result = find_template(repo_dir)
    assert result.endswith(expected)

# Generated at 2022-06-11 20:12:11.405246
# Unit test for function find_template
def test_find_template():
  repo_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                          , 'Cookiecutter_moban')
  find_template(repo_dir)

if __name__ == '__main__':
  test_find_template()

# Generated at 2022-06-11 20:12:13.421764
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:12:20.957955
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    import os
    import nose.tools as nt
    import tempfile

    nt.assert_equal(
        find_template(
            tempfile.mkdtemp()
        ),
        None
    )

    with tempfile.NamedTemporaryFile() as dummy_file:
        nt.assert_equal(
            find_template(
                dummy_file.name
            ),
            None
        )

    with tempfile.NamedTemporaryFile() as dummy_file:
        nt.assert_equal(
            find_template(
                os.path.dirname(dummy_file.name)
            ),
            None
        )


# Generated at 2022-06-11 20:12:26.296630
# Unit test for function find_template
def test_find_template():
    current_dir = os.path.dirname(__file__)

    test_dir = os.path.join(current_dir, '..', 'tests', 'test-template')
    expected_template = os.path.join(test_dir, '{{cookiecutter.repo_name}}')

    assert find_template(test_dir) == expected_template



# Generated at 2022-06-11 20:12:27.184990
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-11 20:12:36.270292
# Unit test for function find_template
def test_find_template():
    """Verify find_template() finds the correct directory.

    Please note that this test function depends on an actual directory
    within the cookiecutter package.
    """
    repo_dir = os.path.join(
        os.path.dirname(
            os.path.abspath(__file__)
        ),
        'fake-repo'
    )
    expected_path = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    result = find_template(repo_dir)

    assert expected_path == result, (
        'Expected {0}, but got {1}'.format(expected_path, result)
    )

# Generated at 2022-06-11 20:12:38.901892
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:45.988241
# Unit test for function find_template
def test_find_template():
    """Tests for function find_template."""
    try:
        find_template('tests/test-repo-pre')
    except (NonTemplatedInputDirException, OSError):
        pass
    else:
        assert False

    template_path = find_template('tests/test-repo-tmpl')
    assert template_path == os.path.abspath('tests/test-repo-tmpl/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:12:50.093093
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo')
    assert find_template(repo_dir) == os.path.join(repo_dir, 'fake')

# Generated at 2022-06-11 20:12:56.862528
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        'tests',
        'non-root-dir-repo',
        'repo'
    )
    expected_template_path = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == expected_template_path

# Generated at 2022-06-11 20:13:04.457349
# Unit test for function find_template
def test_find_template():
    tfile = open('find_template.tmp.txt','w')
    tfile.write('template is {{cookiecutter.repo_name}}')
    tfile.close()

    logger.debug('test_find_template')
    repo_dir = '.'
    repo_dir_contents = os.listdir(repo_dir)
    logger.debug('repo_dir_contents is %s', repo_dir_contents)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    assert(project_template == 'find_template.tmp.txt')

    os.remove(tfile.name)

# Generated at 2022-06-11 20:13:14.897755
# Unit test for function find_template
def test_find_template():
    """Verify that find_template can find the project template."""
    # Set up test repo
    os.mkdir('./test')

    # Create template
    os.mkdir('./test/{{cookiecutter.repo_name}}')
    os.mkdir('./test/{{cookiecutter.repo_name}}/{{cookiecutter.project_name}}')

    # Create non-template
    os.mkdir('./test/{{cookiecutter.repo_name_wrong}}')
    os.mkdir('./test/{{cookiecutter.repo_name_wrong}}/{{cookiecutter.project_name_wrong}}')

    logger.debug('OS listdir: %s', os.listdir('./test'))

    project_template_dir = find_template('./test')


# Generated at 2022-06-11 20:13:16.949218
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:23.306518
# Unit test for function find_template
def test_find_template():
    """Verify that find_template returns correct project_template."""
    project_dir = os.path.realpath(os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..', 'tests', 'test-find-template'))
    project_template = find_template(project_dir)

    assert 'awesome' in project_template
    assert project_template.endswith('test-template')

# Generated at 2022-06-11 20:13:24.951192
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    pass

# Generated at 2022-06-11 20:13:33.042397
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    from cookiecutter.exceptions import NonTemplatedInputDirException

    template = '''
{{ cookiecutter.project_name }}
{{ cookiecutter.project_slug }}
'''
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 20:13:37.060376
# Unit test for function find_template
def test_find_template():
    import py
    test_repo_dir = str(py.path.local(__file__).join('..', 'tests', 'test-repo'))
    project_template = find_template(test_repo_dir)
    assert 'cookiecutter-pypackage' in project_template


# Generated at 2022-06-11 20:13:42.369018
# Unit test for function find_template
def test_find_template():
    """Test that the correct tempate directory is returned."""
    templates_dir = os.path.join(os.path.dirname(__file__), 'templates')
    test_template = os.path.join(templates_dir, 'abbreviated', 'abbr')
    result = find_template(templates_dir)
    assert test_template == result



# Generated at 2022-06-11 20:13:48.239055
# Unit test for function find_template
def test_find_template():
    repo_dir = 'https://github.com/audreyr/cookiecutter-pypackage.git'

    project_template = find_template(repo_dir)
    assert project_template == ''.join([repo_dir, '/', '{{cookiecutter.repo_name}}'])

# Generated at 2022-06-11 20:13:57.948659
# Unit test for function find_template
def test_find_template():
    """A function for unit testing the find-template function."""

    repo_dir = '~/cookiecutter-py/cookiecutters/code-snippet'
    logger.debug('test_find_template: searching %s for project template.',
                 repo_dir)

    repo_dir_contents = os.listdir(repo_dir)
    logger.debug('test_find_template: Contents of the repo are: %s',
                 repo_dir_contents)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            logger.debug('test_find_template: item was %s', item)
            project_template = item
            break


# Generated at 2022-06-11 20:14:00.766071
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'test-find-template'
    )
    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(
        repo_dir, '{{cookiecutter._repo}}'
    )
    assert project_template == expected_project_template

# Generated at 2022-06-11 20:14:10.754247
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-find-template')
    )
    template_dir = os.path.abspath(os.path.join(test_dir, '{{cookiecutter.project_name}}'))
    assert find_template(repo_dir=test_dir) == template_dir


# Generated at 2022-06-11 20:14:19.058023
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    os.chdir(utils.find_repo_root())
    assert find_template('tests/test-repo') == 'tests/test-repo/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/fake-repo-tmpl'
    try:
        find_template('tests/fake-repo-no-tmpl')
        assert False
    except NonTemplatedInputDirException:
        assert True

# Generated at 2022-06-11 20:14:26.531631
# Unit test for function find_template
def test_find_template():
    """Validate find_template() works."""
    from cookiecutter import utils
    from tests.test_utils_paths import fixtures_path
    import os

    template = os.path.join(
        fixtures_path('templates', 'template_with_input_dir'),
        '{{cookiecutter.input_dir}}'
    )
    template_dir = utils.find_template(template)
    assert(os.path.isdir(template_dir))

    expected_template_dir = os.path.join(
        fixtures_path('templates', 'template_with_input_dir'),
        'inner'
    )
    assert(template_dir == expected_template_dir)

# Generated at 2022-06-11 20:14:31.198611
# Unit test for function find_template
def test_find_template():
    repo_dir = '/cookiecutter-pypackage/'
    assert find_template(repo_dir) == '/cookiecutter-pypackage/{{cookiecutter.project_slug}}/'

# Generated at 2022-06-11 20:14:31.916011
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:40.741261
# Unit test for function find_template
def test_find_template():
    # for testing this function, a temporary directory is used, containing
    # an empty directory 'cookiecutter-pypackage' which is expected to be
    # returned by find_template.
    from pytest import raises, fixture
    from tempfile import TemporaryDirectory, mkdtemp

    @fixture
    def template_dir():
        return mkdtemp(prefix='cookiecutter-')

    def test_find_existing_template(template_dir):
        # create reusable temporary directory
        with TemporaryDirectory(prefix='cookiecutter-pypackage') as tmp_dir:
            template = os.path.join(template_dir, 'cookiecutter-pypackage')
            os.symlink(tmp_dir, template)

            # check that we find the template
            template_dir_path = find_template(template_dir)


# Generated at 2022-06-11 20:14:43.776306
# Unit test for function find_template
def test_find_template():
    """Tests the find_template() function."""
    test_dir = ""
    project_template = find_template(test_dir)
    assert project_template == None


# Generated at 2022-06-11 20:14:53.906959
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template`."""
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.utils import rmtree
    from . import get_test_data_dir
    from .sample_pre_generate_output_dir import make_test_data_dir

    test_data_dir = get_test_data_dir()
    temp_dir = TemporaryDirectory()

    make_test_data_dir(test_data_dir, temp_dir)

    actual_template_path = find_template(temp_dir.name)
    expected_template_path = os.path.join(temp_dir.name, '{{cookiecutter.repo_name}}')

    assert os.path.exists(actual_template_path)
    assert os.path.exists(expected_template_path)



# Generated at 2022-06-11 20:15:00.671302
# Unit test for function find_template
def test_find_template():
    """Verify correct behavior of find_template."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test-find-repo'
        )
    cookiecutter_json_path = os.path.join(
        repo_dir,
        'cookiecutter-{{cookiecutter.repo_name}}',
        'cookiecutter.json'
    )

    assert find_template(repo_dir) == cookiecutter_json_path

# Generated at 2022-06-11 20:15:09.194833
# Unit test for function find_template
def test_find_template():
    # Test 1. The example cookiecutter-pypackage directory.
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..', '..', 'tests', 'test-data', 'cookiecutters', 'cookiecutter-pypackage'
    )
    project_template = find_template(repo_dir)
    assert os.path.isfile(project_template)

    # Test 2. The example cookiecutter-pypackage directory.
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..', '..', 'tests', 'test-data', 'cookiecutters', 'cookiecutter-demo'
    )
    project_template = find_template(repo_dir)
    assert os

# Generated at 2022-06-11 20:15:21.708412
# Unit test for function find_template
def test_find_template():
    relative_path = 'tests/test-repos/multiple-project-templates'
    relative_expected_path = os.path.join(relative_path, '{{cookiecutter.repo_name}}')
    absolute_path = os.path.abspath(relative_path)
    absolute_expected_path = os.path.abspath(relative_expected_path)
    assert find_template(absolute_path) == absolute_expected_path
    assert find_template(relative_path) == os.path.abspath(relative_expected_path)

# Generated at 2022-06-11 20:15:25.521460
# Unit test for function find_template
def test_find_template():
    # TODO: Change this to a unittest
    pwd = os.getcwd()
    os.chdir(os.path.join(os.path.dirname(__file__), '..', 'tests'))
    find_template('fake-repo-tmpl')

# Generated at 2022-06-11 20:15:29.810933
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    project_template = '{{cookiecutter.repo_name}}'
    os.makedirs(os.path.join(repo_dir, project_template))

    assert find_template(repo_dir) == os.path.join(repo_dir, project_template)

    shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:15:34.230739
# Unit test for function find_template
def test_find_template():
    test_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), 'fixtures', 'config-file'
        )
    )
    assert find_template(test_dir) == os.path.join(test_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:15:40.562681
# Unit test for function find_template
def test_find_template():
    """Integration test for function find_template."""
    # This only runs if the project_template_dir is a git clone.
    # TODO: Improve integration test
    repo_dir = os.path.join('tests', 'fake-repo-pre')
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/cookiecutter-pypackage'



# Generated at 2022-06-11 20:15:43.433726
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/code/cookiecutter-pypackage') == '/Users/audreyr/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:53.791419
# Unit test for function find_template
def test_find_template():
    repo_dir_contents = os.listdir('tests/fake-repo-tmpl')
    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    template_dir = os.path.join('tests/fake-repo-tmpl', project_template)

    assert project_template == find_template('tests/fake-repo-tmpl')
    assert template_dir == find_template('tests/fake-repo-tmpl')

    from cookiecutter.exceptions import NonTemplatedInputDirException
    try:
        find_template('tests/fake-repo-no-tmpl')
    except NonTemplatedInputDirException:
        assert True
   

# Generated at 2022-06-11 20:16:01.793756
# Unit test for function find_template
def test_find_template():
    """ Test the find_template function on a given directory containing an 'old_version'
    and 'new_version' template. Check that the function is returning the correct result,
    depending on the directory's content """
    # Should return new_version
    repo_dir = './cookiecutter-example'
    assert find_template(repo_dir) == './cookiecutter-example/{{cookiecutter.project_name}}'

    # Should return old_version
    repo_dir = './cookiecutter-example-1'
    assert find_template(repo_dir) == './cookiecutter-example-1/{{ project_name }}'

# Generated at 2022-06-11 20:16:02.237100
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:16:13.737067
# Unit test for function find_template
def test_find_template():
    with temp_directory() as clone_to_dir:
        # Copy test template to a temporary directory
        repo_dir = os.path.join(clone_to_dir, 'tests/test-template-repo')
        shutil.copytree(repo_dir, clone_to_dir)

        # Check that raise if not find a template
        with pytest.raises(NonTemplatedInputDirException):
            find_template(clone_to_dir)

        # Check that return if find a template
        project_dir = 'cookiecutter-{{cookiecutter.repo}}'
        project_dir_path = os.path.join(clone_to_dir, project_dir)
        os.mkdir(project_dir_path)


# Generated at 2022-06-11 20:16:28.330545
# Unit test for function find_template
def test_find_template():
    repo_dir = 'cookiecutter-django/{{cookiecutter.repo_name}}'
    assert repo_dir[-1] == '}'

test_find_template()

# Generated at 2022-06-11 20:16:31.569083
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/cookiecutter-pypackage') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:16:32.199332
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:16:37.944582
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), os.pardir, os.pardir,
                     'test', 'fake-repo')
    )
    project_template = 'fake-project'
    templated_path = os.path.join(repo_dir, project_template)

    assert find_template(repo_dir) == templated_path

# Generated at 2022-06-11 20:16:45.513835
# Unit test for function find_template
def test_find_template():
    """
    Test to find template
    """
    repo_dir = os.path.join('tests','fake-repo')
    logger.debug('Searching %s for the project template.', repo_dir)
    repo_dir_contents = os.listdir(repo_dir)
    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break
    assert project_template == 'cookiecutter-pypackage'
    

# Generated at 2022-06-11 20:16:50.501473
# Unit test for function find_template
def test_find_template():
    """Test find template."""
    repo_dir = os.path.abspath('tests/test-repo-pre/')
    path = find_template(repo_dir)
    assert path == os.path.abspath('tests/test-repo-pre/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:16:59.636886
# Unit test for function find_template
def test_find_template():
    """Verify find_template() searching for cookiecutter template."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    repo_dir_contents = [
        os.path.join(repo_dir, 'file.txt'),
        os.path.join(repo_dir, 'cookiecutter-project'),
        os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}'),
    ]
    for item in repo_dir_contents:
        open(item, 'w').close()

    expected_template_dir = repo_dir_contents[2]
    template_dir = find_template(repo_dir)

    assert expected_template_dir == template_dir

# Generated at 2022-06-11 20:17:09.520031
# Unit test for function find_template
def test_find_template():
    """Integration test for finding a template in a repository.
    This test function may be deprecated in the future.
    """
    import tempfile
    from cookiecutter import generate
    from shutil import rmtree

    temp_dir = tempfile.mkdtemp()
    repo_path = os.path.join(temp_dir, 'cookiecutter-pypackage')
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    generate.generate_files(repo_url, repo_path, overwrite_if_exists=True)
    assert find_template(repo_path) == os.path.join(
        repo_path, '{{cookiecutter.repo_name}}')
    rmtree(temp_dir)


# Generated at 2022-06-11 20:17:16.532997
# Unit test for function find_template
def test_find_template():
    """Test that the `find_template()` function returns the expected template."""
    import shutil
    import tempfile

    # Create a temp directory
    repo_dir = tempfile.mkdtemp()

    # Create a directory that we do not expect to be the project template
    temp_dirs = [
        os.path.join(repo_dir, 'incorrect_project_template'),
        os.path.join(repo_dir, 'incorrect_project_template2'),
    ]
    for temp_dir in temp_dirs:
        os.mkdir(temp_dir)

    # Create a file that we do not expect to be the project template
    with open(os.path.join(repo_dir, 'incorrect_file.txt'), 'w') as f:
        f.write('Cookiecutter!')

# Generated at 2022-06-11 20:17:25.043913
# Unit test for function find_template
def test_find_template():
    # dir containing cookiecutter
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), 'tests', 'fake-repo-tmpl'
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter')

    # dir containing cookiecutter with an added underscore
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tests', 'fake-repo-tmpl-underscore'
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter_')

    # dir containing cookiecutter with an added hyphen
    repo_dir = os.path

# Generated at 2022-06-11 20:17:51.957851
# Unit test for function find_template
def test_find_template():
    """Test that find_template can find the project template"""

    pass


# Generated at 2022-06-11 20:17:54.118288
# Unit test for function find_template
def test_find_template():
    find_template('cookiecutter-pypackage')

# End of unit test for function find_template

# Generated at 2022-06-11 20:17:56.143232
# Unit test for function find_template
def test_find_template():
    find_template('/Users/zjunwei/Desktop/pt/cookiecutter-jira/cookiecutter-jira')

# Generated at 2022-06-11 20:17:59.506815
# Unit test for function find_template
def test_find_template():
    """
    Test find_template()
    """
    result = find_template('/some/fakedir/cookiecutter-pypackage')
    assert '/some/fakedir/cookiecutter-pypackage/{{cookiecutter.repo_name}}' == result

test_find_template()

# Generated at 2022-06-11 20:18:02.852508
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.expanduser("~/projects/cookiecutter-example-template")
    assert find_template(template_dir) == os.path.expanduser("~/projects/cookiecutter-example-template/{{cookiecutter.repo_name}}")

# Generated at 2022-06-11 20:18:04.370207
# Unit test for function find_template
def test_find_template():
    find_template('/tmp')
    find_template('C:\\tmp')

# Generated at 2022-06-11 20:18:10.282777
# Unit test for function find_template
def test_find_template():
    """Test for function `find_template`."""
    project_template = os.path.join(os.path.dirname(__file__), 'test_template')
    func_out = find_template(project_template)
    base = '.cookiecutter-{{cookiecutter.repo_name}}'
    out = os.path.join(project_template, base)
    assert func_out == out

# Generated at 2022-06-11 20:18:13.739416
# Unit test for function find_template
def test_find_template():
    template_path = find_template('tests/input/fake-repo-tmpl')
    assert 'tests/input/fake-repo-tmpl/{{cookiecutter.repo_name}}' == template_path

# Generated at 2022-06-11 20:18:17.820048
# Unit test for function find_template
def test_find_template():
    print("Testing find_template...")
    logger.debug("testing template found")
    assert find_template("../tests/test-cookiecutters/jquery") == "../tests/test-cookiecutters/jquery/cookiecutter-jquery-plugin"


# Generated at 2022-06-11 20:18:23.049512
# Unit test for function find_template
def test_find_template():
    """Return the relative path to the project template."""
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '../tests/files/test-template')

    project_template = find_template(repo_dir)
    assert project_template == 'cookiecutter-pypackage', 'project_template does not match expected.'

# Generated at 2022-06-11 20:19:19.753554
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:19:25.923570
# Unit test for function find_template
def test_find_template():
    test_repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '../tests/test-repo-pre/'
    )

    assert find_template(test_repo_dir) == os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '../tests/test-repo-pre/{{cookiecutter.repo_name}}'
    )



# Generated at 2022-06-11 20:19:30.641357
# Unit test for function find_template
def test_find_template():
    """
    Unit test for find_template function.
    :returns: Nothing. Raises an exception if a test fails.
    """
    import tempfile
    import shutil

    logger.info('Testing find_template...')

    # Create a dummy directory with a fake template directory
    temp_dir = tempfile.mkdtemp()
    try:
        template_dir = os.path.join(temp_dir, 'project_template-{{cookiecutter.repo_name}}')
        os.mkdir(template_dir)

        assert find_template(temp_dir) == template_dir
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-11 20:19:36.783858
# Unit test for function find_template
def test_find_template():
    """Verify function is able to locate project template"""

    repo_dir = "./tests/test-find-template"
    repo_dir_contents = os.listdir(repo_dir)
    assert ".cookiecutter" not in repo_dir_contents
    project_template = find_template(repo_dir)
    project_template_contents = os.listdir(project_template)
    assert ".cookiecutter" in project_template_contents
    project_template_contents.remove('.cookiecutter')
    assert project_template_contents == ['README.rst', 'default_context.yaml', '{{cookiecutter.project_name}}']

# Generated at 2022-06-11 20:19:42.267172
# Unit test for function find_template
def test_find_template():
    """Tests for `find_template` function."""
    template = find_template(os.path.join(
        'tests', 'test-find-template-repo', '{{cookiecutter.repo_name}}'
    ))
    assert template == 'tests/test-find-template-repo/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:19:45.831813
# Unit test for function find_template
def test_find_template():
    """."""
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:19:48.657476
# Unit test for function find_template
def test_find_template():
    """Test for find_template.

    Check to see if the right directory is returned.
    """
    repo_dir = 'tests/files/fake-repo'
    assert 'fake-project-template' in find_template(repo_dir)

    repo_dir = 'tests/files/fake-non-templated-repo'
    assert NonTemplatedInputDirException

# Generated at 2022-06-11 20:19:51.970622
# Unit test for function find_template
def test_find_template():
    assert find_template('~/cookiecutters/cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:20:00.166288
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template`."""
    from .compat import mock
    from .compat import unittest

    class TestFindTemplate(unittest.TestCase):
        @mock.patch('cookiecutter.find.os.listdir')
        def test_find_template(self, mock_listdir):
            """Verify the correct project template is selected."""
            repo_dir = os.path.expanduser('~/fake-repo-dir/')
            mock_listdir.return_value = [
                'fake-cookiecutter-project-name',
                'another-dir',
                'yet-another-dir'
            ]

            project_template = find_template(repo_dir)

# Generated at 2022-06-11 20:20:03.814001
# Unit test for function find_template
def test_find_template():
    
    assert find_template('../cookiecutter-pypackage') == os.path.join('../cookiecutter-pypackage', '{{cookiecutter.repo_name}}')