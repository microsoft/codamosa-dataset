

# Generated at 2022-06-11 20:11:37.617420
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.normpath('/Users/audreyr/cookiecutter-pypackage')
    template_dir = os.path.normpath('/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == template_dir

# Generated at 2022-06-11 20:11:39.042238
# Unit test for function find_template
def test_find_template():
    find_template("home/user/samples/cookiecutter-pypackage/")

# Generated at 2022-06-11 20:11:39.627083
# Unit test for function find_template
def test_find_template():
    pass



# Generated at 2022-06-11 20:11:45.638098
# Unit test for function find_template
def test_find_template():
    """Verify that the find_template function works as expected."""
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), 'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:11:51.468013
# Unit test for function find_template
def test_find_template():
    """Verify that the function can find a template directory in a dir."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '..', '..', 'tests', 'test-data', 'fake-repo'
        )
    )
    assert find_template(repo_dir) == os.path.join(
        repo_dir, 'fake-cookiecutter-project'
    )

# Generated at 2022-06-11 20:11:56.500678
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function works as expected."""
    expected_directory = os.path.join(os.path.abspath('tests/fake-repo-pre/'), '{{cookiecutter.repo_name}}')
    result = find_template(os.path.abspath('tests/fake-repo-pre/'))
    assert expected_directory == result

# Generated at 2022-06-11 20:12:00.509544
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tests',
        'test-repo-pre'
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:12:08.352173
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    fake_repo_dir = tempfile.mkdtemp()
    os.makedirs(fake_repo_dir)

    fake_template_dir = os.path.join(fake_repo_dir, '{{cookiecutter.project}}')
    os.makedirs(fake_template_dir)

    try:
        template = find_template(fake_repo_dir)

        assert(template == fake_template_dir)
    finally:
        shutil.rmtree(fake_repo_dir)

# Generated at 2022-06-11 20:12:14.580880
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-post/') == 'tests/fake-repo-post/fake-repo'

# TODO: ensure_dir is put to use after https://github.com/audreyr/cookiecutter/issues/29

# Generated at 2022-06-11 20:12:18.694258
# Unit test for function find_template
def test_find_template():
    ''' Tests the find_template function on a local directory '''
    test_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'testfiles', 'test-repo')
    assert find_template(test_dir) == os.path.join(test_dir, 'test-project')

# Generated at 2022-06-11 20:12:23.302692
# Unit test for function find_template
def test_find_template():
    """Tests the function find_template"""
    repo_dir = '.'
    assert find_template(repo_dir) == './{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:12:34.900871
# Unit test for function find_template
def test_find_template():
    """Check that ``find_template`` behaves as expected.
    """

    import shutil
    import os
    from cookiecutter.utils.paths import ensure_dir

    repo_dir = "/tmp/cookiecutter-a249e7370bbb40a1b959f3cc7e3b0d47"
    ensure_dir(repo_dir)
    project_template = os.path.join(repo_dir, 'cookiecutter-a249e7370bbb40a1b959f3cc7e3b0d47')
    ensure_dir(project_template)

    result = find_template(repo_dir)

    assert result == project_template

    shutil.rmtree(repo_dir)

    non_templated_dir_exception_raised = False

# Generated at 2022-06-11 20:12:37.748320
# Unit test for function find_template
def test_find_template():
    """Check for a project template in the repo's folder"""
    assert find_template('tests/fake-repo-tmpl/') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-11 20:12:41.692138
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/src/cookiecutter-pypackage') == \
        '/Users/audreyr/src/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:12:47.576658
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_find_template',
        'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

# Generated at 2022-06-11 20:12:50.405999
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-repo-tmpl/') == 'tests/test-repo-tmpl/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:12:56.436844
# Unit test for function find_template
def test_find_template():
    abspath = os.path.abspath(os.path.dirname(__file__))
    tmp_dir = os.path.join(abspath, '{% cookiecutter.repo_name %}')
    result = find_template(tmp_dir)
    assert result == os.path.join(tmp_dir, '{% cookiecutter.repo_name %}')



# Generated at 2022-06-11 20:13:00.216425
# Unit test for function find_template
def test_find_template():
    assert find_template('repo_dir') == 'repo_dir/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:08.705764
# Unit test for function find_template
def test_find_template():
    """Test the function find_template."""
    import tempfile
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    tmp = tempfile.mkdtemp()
    repo_name = "my-repo-name"
    repo_dir = utils.make_repo_relative_path(tmp, repo_name)

    # Create the input directory
    utils.make_sure_path_exists(repo_dir)
    # Create subdirectory "cookiecutter-my-repo-name"
    utils.make_sure_path_exists(
        os.path.join(repo_dir, "cookiecutter-" + repo_name)
    )


# Generated at 2022-06-11 20:13:15.751007
# Unit test for function find_template
def test_find_template():
    """Function for testing find_template()."""
    import tempfile
    from cookiecutter import ensure_dir
    from cookiecutter.compat import os_walk
    from cookiecutter.utils import rmtree

    repo_dir = tempfile.mkdtemp()
    ensure_dir(repo_dir)


# Generated at 2022-06-11 20:13:23.826106
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    from cookiecutter.tests.test_replay import unicode_literals

    repo_dir = unicode_literals('tests/test-repo-pre')
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:25.252555
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:29.075142
# Unit test for function find_template
def test_find_template():
    #from cookiecutter.utils import find_template
    #from cookiecutter import repo

    #result = find_template(repo.cookiecutters_dir())
    #assert result.endswith('cookiecutter-pypackage/{{cookiecutter.repo_name}}')

    pass


# Generated at 2022-06-11 20:13:31.903029
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    assert find_template(
        '/Users/audreyr/cookiecutter-pypackage'
    ) == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:36.243528
# Unit test for function find_template
def test_find_template():
    """Test find_template function to ensure it finds the correct template"""
    from tests import fixture

    template = find_template(fixture)
    exp_template = os.path.join(fixture, '{{cookiecutter.repo_name}}')
    assert template == exp_template, 'template != exp_template'

# Generated at 2022-06-11 20:13:40.502904
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/files/fake-repo'
    repo_dir_contents = os.listdir(repo_dir)
    assert find_template(repo_dir) == os.path.join(repo_dir, repo_dir_contents[0])

# Generated at 2022-06-11 20:13:44.459499
# Unit test for function find_template
def test_find_template():
    from tests.test_utils import read_file, sep, TEST_TEMPLATE_DIR
    repo_dir = TEST_TEMPLATE_DIR

    project_template = find_template(repo_dir)
    assert project_template == repo_dir + sep + '{{cookiecutter.repo_name}}'
    read_file(project_template + sep + 'README.md')

# Generated at 2022-06-11 20:13:50.745557
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-data', 'fake-repo-pre-gen')
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    result = find_template(repo_dir)
    assert result == expected

# Generated at 2022-06-11 20:13:51.727041
# Unit test for function find_template
def test_find_template():
    """Test the function find_template"""
    pass

# Generated at 2022-06-11 20:13:59.831238
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns a path ending in '/cookiecutter-pypackage'."""
    from shutil import rmtree
    from tempfile import mkdtemp
    from cookiecutter import generate
    from cookiecutter import utils

    tmp_dir = mkdtemp()
    generate.generate_files(
        repo_dir=utils.find_template('tests/fake-repo-pre/'),
        context={},
        overwrite_if_exists=False,
        output_dir=tmp_dir
    )
    assert find_template(tmp_dir) == os.path.join(tmp_dir, 'cookiecutter-pypackage')

    rmtree(tmp_dir)

# Generated at 2022-06-11 20:14:11.551663
# Unit test for function find_template
def test_find_template():
    repo_dir = '~/repo'
    project_template = '~/repo/cookiecutter-pypackage'
    repo_dir_contents = ['cookiecutter-pypackage', 'cookiecutter-coco']
    assert find_template(repo_dir, repo_dir_contents) == project_template


# Generated at 2022-06-11 20:14:16.523033
# Unit test for function find_template
def test_find_template():
    """Something something."""
    from cookiecutter.operator import _is_repo
    from cookiecutter import compressed_files
    
    repo_dir = compressed_files.extract_repo()
    project_template = find_template(repo_dir)
    
    assert os.path.exists(project_template)
    
    assert _is_repo(project_template)

# Generated at 2022-06-11 20:14:20.265516
# Unit test for function find_template
def test_find_template():
    """Test that we can find the project template in a cloned directory."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import repo
    from tempfile import mkdtemp
    from shutil import rmtree

    # Create a temporary directory and cookiecutter template in it.
    cloned_repo_dir = mkdtemp()
    cloned_repo_dir = cookiecutter(
        repo.generate_files(repo_dir=cloned_repo_dir)
    )

    # Look for the template inside
    found_project_template = find_template(cloned_repo_dir)

    # Verify that the template is in the cloned repo
    repo_contents = os.listdir(cloned_repo_dir)

# Generated at 2022-06-11 20:14:20.874399
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:23.358896
# Unit test for function find_template
def test_find_template():
    assert find_template('./tests/fake-repo-pre/') == './tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:25.037743
# Unit test for function find_template
def test_find_template():
    find_template('/Users/elax/Desktop/cookiecutter-pypackage')

# Generated at 2022-06-11 20:14:27.210102
# Unit test for function find_template
def test_find_template():
    assert find_template
    assert find_template.__name__ == 'find_template'

# Generated at 2022-06-11 20:14:34.219344
# Unit test for function find_template
def test_find_template():
    """Verify that the template is found."""
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/test-repo-pre/'
    )
    main.cookiecutter(repo_dir)
    shutil.rmtree(os.path.join(os.path.dirname(__file__), 'tests/fake-repo'))



# Generated at 2022-06-11 20:14:41.535744
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""

    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'tests',
        'test-checkouts',
        'django-cookiecutter'
    )
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'tests',
        'test-checkouts',
        'tests-cookiecutter'
    )
    project_template = find_template(repo_dir)


# Generated at 2022-06-11 20:14:42.460410
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:57.516699
# Unit test for function find_template
def test_find_template():
    """Unit test for find_template."""
    repo_dir = 'tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:06.017725
# Unit test for function find_template
def test_find_template():
    """Verify function `find_template`."""
    import tempfile

    cwd = os.getcwd()

    repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(repo_dir, 'bacon'))

    try:
        assert find_template(repo_dir) == os.path.join(
            repo_dir, '{{cookiecutter.repo_name}}')
    except NonTemplatedInputDirException:
        assert False

    os.chdir(cwd)



# Generated at 2022-06-11 20:15:12.387072
# Unit test for function find_template
def test_find_template():
    os.listdir = lambda x: ['foo/', 'bar.txt', 'cookiecutter-{{cookiecutter.repo_name}}/']
    assert find_template('./') == './cookiecutter-{{cookiecutter.repo_name}}'

    os.listdir = lambda x: ['foo/', 'bar.txt', '{{cookiecutter.repo_name}}/']
    assert find_template('./') == './{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:15:16.844303
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    from os.path import abspath

    repo_dir = abspath('tests/test-data/fake-repo')
    template = find_template(repo_dir)

    assert 'fake-repo/test' in template

# Generated at 2022-06-11 20:15:20.233982
# Unit test for function find_template
def test_find_template():
    repo_dir = "/tmp/fhws-cookiecutter-django"
    assert "/tmp/fhws-cookiecutter-django/{{cookiecutter.repo_name}}" == find_template(repo_dir)

# Generated at 2022-06-11 20:15:29.095782
# Unit test for function find_template
def test_find_template():
    """Test for finding template."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.repository import determine_repo_dir
    from binaryornot.check import is_binary

    output_dir = 'fake-repo-tmpl'
    repo_dir = determine_repo_dir('tests/fake-repo-tmpl/')

    result = cookiecutter(
        repo_dir,
        no_input=True,
        output_dir=output_dir,
    )

    assert result == {
        'full_name': 'Fake Name',
        'email': 'fn@example.com',
        'project_name': 'Fake Project',
        'project_slug': 'fake-project',
        'repo_name': 'fake-project',
    }


# Generated at 2022-06-11 20:15:31.114605
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:41.498645
# Unit test for function find_template
def test_find_template():
    # TODO: This currently only tests for the exception.
    from . import prompt, utils
    from .exceptions import NonTemplatedInputDirException
    from .config import DEFAULT_CONFIG

    repo_dir = utils.make_empty_project('tests/fake-repo-pre/', 'fake-repo')
    with pytest.raises(NonTemplatedInputDirException):
        find_template(repo_dir)

    repo_dir = utils.make_empty_project('tests/fake-repo-post/', 'fake-repo')
    template_dir = find_template(repo_dir)
    config_dict = DEFAULT_CONFIG

# Generated at 2022-06-11 20:15:49.074703
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    from shutil import rmtree
    from cookiecutter.utils import rmtree

    from tempfile import mkdtemp

    repo_dir = mkdtemp()
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    assert find_template(repo_dir) == os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}')

    rmtree(repo_dir)

# Generated at 2022-06-11 20:15:54.586192
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.getcwd(), 'tests/fake-repo-pre/')
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    try:
        result = find_template(repo_dir=repo_dir)
    except:
        print("Unit test for function find_template failed")
    assert result==project_template

# Generated at 2022-06-11 20:16:26.123372
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(
            os.path.abspath(__file__)),
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}')

    assert find_template(repo_dir) == os.path.join(
        os.path.dirname(
            os.path.abspath(__file__)),
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:16:29.871455
# Unit test for function find_template
def test_find_template():
    input_directory = 'tests/files/fake-repo/'
    expected_project_template_directory = \
        'tests/files/fake-repo/cookiecutter-pypackage'

    project_template_directory = find_template(input_directory)

    assert expected_project_template_directory == project_template_directory


# Generated at 2022-06-11 20:16:38.719865
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = './tests/fake-repo'
    repo_dir_found = './tests/fake-repo/fake_cookiecutter-{{cookiecutter.repo_name}}'
    project_dir_found = './tests/fake-repo/fake_cookiecutter-{{cookiecutter.repo_name}}/{{cookiecutter.project_name}}'

    # Check there is a cookiecutter-<repo_name> in the fake-repo
    assert os.path.exists(repo_dir_found)

    # Check it includes a {{cookiecutter.repo_name}}
    assert '{{cookiecutter.repo_name}}' in repo_dir_found

    # Check it includes a {{cookiecutter.project_name}}
   

# Generated at 2022-06-11 20:16:44.975605
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    import tempfile
    import shutil

    template_dir = tempfile.mkdtemp()
    cookiecutter_dir = os.path.join(template_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(cookiecutter_dir)
    assert find_template(template_dir) == cookiecutter_dir
    shutil.rmtree(template_dir)

# Generated at 2022-06-11 20:16:56.415729
# Unit test for function find_template
def test_find_template():
    """Ensure that the find_template function works as expected."""
    logger.debug('Testing find_template()')

    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..',
        'tests',
        'fake-repo',
        '{{cookiecutter.repo_name}}'
    )
    repo_dir_contents = os.listdir(repo_dir)
    project_template = None

    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    template = find_template(repo_dir=repo_dir)

# Generated at 2022-06-11 20:17:04.361744
# Unit test for function find_template
def test_find_template():
    """Verify the correct template is found."""
    try:
        find_template("./tests/fake-repo-pre")
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

    assert find_template("./tests/fake-repo-pre/fake-repo-post") == "./tests/fake-repo-pre/fake-repo-post/{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:17:12.803092
# Unit test for function find_template
def test_find_template():
    import tempfile
    from cookiecutter.utils import rmtree

    with tempfile.TemporaryDirectory(prefix='cookiecutter-') as temp_dir:
        template_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
        os.makedirs(template_dir)

        assert find_template(temp_dir) == template_dir

        rmtree(template_dir)
        assert os.path.exists(temp_dir)

        # Expect an exception to be raised if there is no project template
        try:
            find_template(temp_dir)
        except NonTemplatedInputDirException:
            pass
        else:
            assert False, 'Should have raised a NonTemplatedInputDirException'

# Generated at 2022-06-11 20:17:18.850064
# Unit test for function find_template
def test_find_template():
    """Verify find_template works as expected."""
    test_dir = os.path.join('tests', '{{cookiecutter.repo_name}}')
    assert find_template(test_dir) == \
        os.path.join(test_dir, '{{cookiecutter.repo_name}}')

    test_dir_notemplates = os.path.join('tests', 'test_find_template')
    assert not find_template(test_dir_notemplates)

# Generated at 2022-06-11 20:17:24.380645
# Unit test for function find_template
def test_find_template():
    """Verify the ability to find the template directory."""
    os.chdir(os.path.abspath(os.path.dirname(__file__)))
    template_dir = os.path.join('fixtures', 'fake-repo', '{{cookiecutter.repo_name}}')
    expected = os.path.join(os.getcwd(), template_dir)
    assert find_template(os.path.join('fixtures', 'fake-repo')) == expected



# Generated at 2022-06-11 20:17:29.425349
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/test-repo/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-repo/{{cookiecutter.project_name}}', 'project_template is not correct'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:18:27.100737
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    import cookiecutter
    import os.path
    import shutil

    test_dir = 'tests/files/find_template'
    project_template = os.path.join(test_dir, '{{cookiecutter.project_name}}')

    try:
        shutil.rmtree(project_template)
    except OSError:
        pass

    # This should raise an exception
    try:
        cookiecutter.find_template(test_dir)
        assert False
    except NonTemplatedInputDirException:
        pass

    # Create the template directory
    os.mkdir(project_template)

    assert cookiecutter.find_template(test_dir) == project_template


# Generated at 2022-06-11 20:18:30.922872
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template()."""
    print("\nTesting find_template()")
    find_template('~/cookiecutters/cookiecutter-pypackage')
    find_template('~/cookiecutters/cookiecutter-django-cms')

# Generated at 2022-06-11 20:18:35.154797
# Unit test for function find_template
def test_find_template():
    os.makedirs('/tmp/fake_repo/fake_repo_template')
    repo_dir = '/tmp/fake_repo/'
    project_template = find_template(repo_dir)
    assert project_template == '/tmp/fake_repo/fake_repo_template'
    os.rm

# Generated at 2022-06-11 20:18:35.651152
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:18:41.500255
# Unit test for function find_template
def test_find_template():
    """Assert that a valid project template directory is found."""
    from cookiecutter.tests import _TEST_REPO_DIR

    test_repo_dir = os.path.join(_TEST_REPO_DIR, 'fake-repo')
    assert find_template(test_repo_dir) == os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:18:47.716981
# Unit test for function find_template
def test_find_template():
    """Test function for find_template()"""
    import os

    base_dir = os.path.join(os.path.dirname(__file__), '..', 'tests')
    repo_dir = os.path.join(base_dir, 'fake-repo-pre-gen')
    project_template = find_template(repo_dir)
    expected = os.path.join(repo_dir, 'fake-project')

    assert project_template == expected

# Generated at 2022-06-11 20:18:48.629797
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-11 20:18:56.432822
# Unit test for function find_template
def test_find_template():
    """Verify that the function can find the templated input directory."""
    from cookiecutter.main import cookiecutter

    tmp_template = cookiecutter('tests/test-cookiecutter-templates/good-repo')
    tmp_template_contents = os.listdir(tmp_template)
    for item in tmp_template_contents:
        if 'cookiecutter' in item:
            os.remove(os.path.join(tmp_template, item))

    repo_dir = os.path.join(tmp_template, 'cookiecutter')
    open(repo_dir, 'a').close()

    template_dir = os.path.join(tmp_template, 'cookiecutter-{{cookiecutter.repo_name}}')
    open(template_dir, 'a').close()

    project_template

# Generated at 2022-06-11 20:18:59.480941
# Unit test for function find_template
def test_find_template():
    path = '../tests/test-repo-pre/{{cookiecutter.repo_name}}'
    assert path == find_template('../tests/test-repo-pre')



# Generated at 2022-06-11 20:19:04.205178
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    import os
    import tempfile

    tempdir = tempfile.mkdtemp()

    os.mkdir(os.path.join(tempdir, 'cookiecutter-test'))

    assert find_template(tempdir) == os.path.join(tempdir, 'cookiecutter-test')

# Generated at 2022-06-11 20:21:12.381962
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns template from given dir."""
    from cookiecutter import utils
    from cookiecutter.compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        input_dir = os.path.join(tmpdir, 'cookiecutter-foobar')
        os.makedirs(input_dir)
        with open(os.path.join(input_dir, 'foo.txt'), 'w') as f:
            f.write('content')
        project_template = utils.find_template(input_dir)
        assert project_template == input_dir
        assert os.path.isdir(project_template)
        assert os.path.isfile(os.path.join(project_template, 'foo.txt'))


# Generated at 2022-06-11 20:21:14.932811
# Unit test for function find_template
def test_find_template():
    """Test finding the project template."""

    repo_dir = 'tests/fake-repo-tmpl'
    template = find_template(repo_dir)
    assert template == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:21:18.672121
# Unit test for function find_template
def test_find_template():
    repo_dir = r'C:\Users\user\Desktop\Projects\c4d_template'
    project_template = r'C:\Users\user\Desktop\Projects\c4d_template\c4d_template'

    # Test simple dir with template
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:21:24.317842
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests', 'fake-repo-pre')
    assert os.path.exists(repo_dir)
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:21:29.222361
# Unit test for function find_template
def test_find_template():
    dir = os.path.join(os.path.dirname(__file__),"templated_projects")
    template = find_template(dir)
    assert template == os.path.join(dir, '{{cookiecutter.repo_name}}')

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:21:33.918519
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    # Should return '/home/audreyr/cookiecutters/cookiecutter-pypackage'
    assert ('/home/audreyr/cookiecutters/cookiecutter-pypackage' ==
            find_template(repo_dir='/home/audreyr/cookiecutters/cookiecutter-pypackage'))

    # Should raise exception
    import pytest
    with pytest.raises(NonTemplatedInputDirException):
        find_template(repo_dir='/home/audreyr/cookiecutters/audreyr/cookiecutter-pypackage')