

# Generated at 2022-06-11 20:11:35.334244
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    # TODO: Test not yet implemented.
    pass



# Generated at 2022-06-11 20:11:38.170099
# Unit test for function find_template
def test_find_template():
    """Verify function find_template(file_path)"""

    find_template('/home/matthew/repos/cookiecutter-pypackage')

# Generated at 2022-06-11 20:11:49.048013
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.utils import rmtree

    from .contextmanagers import temp_chdir
    from .fake_repo import make_fake_repo

    # Create a fake repo with a template directory in it
    nix_template_dir = '{{cookiecutter.repo_name}}'
    relpath_to_template = os.path.join(nix_template_dir, 'foobar')

    with make_fake_repo(nix_template_dir) as repo_dir:
        with make_fake_repo(relpath_to_template, repo_dir=repo_dir):
            project_template = find_template(repo_dir)
            assert project_template == os.path.join(repo_dir, relpath_to_template)

           

# Generated at 2022-06-11 20:11:53.237228
# Unit test for function find_template
def test_find_template():
    # TODO: test different directory structures?
    # TODO: test where repo_dir does not contain a project template?
    repo_dir = os.path.join('tests', 'files', 'dummy-repo-templated')

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, 'dummy-repo', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:11:59.417324
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    project_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(project_dir, 'tests', 'test-repo')
    expect_project_template = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}'
    )

    project_template = utils.find_template(repo_dir)
    assert project_template == expect_project_template

# Generated at 2022-06-11 20:12:08.353459
# Unit test for function find_template
def test_find_template():
    repo_dir = "cookiecutter/tests/test-artifacts"
    project_template = find_template(repo_dir)
    assert project_template == "cookiecutter/tests/test-artifacts/{{cookiecutter.repo_name}}"
    repo_dir = "tests/test-artifacts"
    project_template = find_template(repo_dir)
    assert project_template == "tests/test-artifacts/{{cookiecutter.repo_name}}"
    repo_dir = "test-artifacts"
    project_template = find_template(repo_dir)
    assert project_template == "test-artifacts/{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:12:08.796571
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:12:15.343115
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        '..',
        'cookiecutter-django'
    )
    project_template = find_template(repo_dir).split('cookiecutter-django')[1]
    assert project_template == '/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:16.407104
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    pass

# Generated at 2022-06-11 20:12:18.902079
# Unit test for function find_template
def test_find_template():
    test_input_dir = 'tests/test-find-template-project'
    assert find_template(test_input_dir) == test_input_dir + '/{{cookiecutter.template_name}}'

# Generated at 2022-06-11 20:12:32.094241
# Unit test for function find_template
def test_find_template():
    """Cookiecutter templates have 'cookiecutter' in the name."""
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter import utils
    with TemporaryDirectory() as repo_dir:
        utils.make_sure_path_exists(os.path.join(repo_dir, 'my_dir'))
        utils.make_sure_path_exists(os.path.join(repo_dir, 'cookiecutter_my'))
        utils.make_sure_path_exists(os.path.join(repo_dir, 'cookiecutter_yo'))
        utils.make_sure_path_exists(os.path.join(repo_dir, 'cookiecutter'))

# Generated at 2022-06-11 20:12:35.796496
# Unit test for function find_template
def test_find_template():
    """Sample unit test for find_template"""
    assert find_template('/home/user/.cookiecutters/cookiecutter-pypackage') == '/home/user/.cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:40.083925
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    # Passes
    assert find_template(
        'tests/test-generate-files/fake-repo-tmpl'
    ) == 'tests/test-generate-files/fake-repo-tmpl/{{cookiecutter.repo_name}}'

    # Fails
    assert find_template('tests/test-generate-files/fake-repo-no-tmpl') == None

# Generated at 2022-06-11 20:12:47.862743
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/test-find-template/fake-repo') == 'tests/test-find-template/fake-repo/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-find-template/fake-repo-2') == 'tests/test-find-template/fake-repo-2/{{cookiecutter.repo_name}}'
    assert find_template('tests/test-find-template/fake-repo-3') == 'tests/test-find-template/fake-repo-3/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:53.092169
# Unit test for function find_template
def test_find_template():
    """Find a template in a directory."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'test-bake-in-repo')
    template_dir = os.path.join(repo_dir, 'fake-project-template')
    assert find_template(repo_dir) == template_dir

# Generated at 2022-06-11 20:12:57.448659
# Unit test for function find_template
def test_find_template():
    repo_dir = 'user/repo/cookiecutter-github/{{cookiecutter.repo_name}}/'
    result = find_template(repo_dir)
    assert result == 'user/repo/cookiecutter-github/{{cookiecutter.repo_name}}/'



# Generated at 2022-06-11 20:13:03.424225
# Unit test for function find_template
def test_find_template():
    logger.debug('Finding repo_dir')
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo',
    ))
    logger.debug('Repo_dir is %s', repo_dir)

    project_template = os.path.abspath(os.path.join(
        repo_dir,
        'cookiecutter-{{cookiecutter.repo_name}}',
    ))
    result = find_template(repo_dir)
    assert project_template == result

# Generated at 2022-06-11 20:13:07.856190
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected."""
    test_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        'tests',
        'test-find-template'
    )
    project_template = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    assert find_template(test_dir) == project_template

# Generated at 2022-06-11 20:13:15.479338
# Unit test for function find_template
def test_find_template():
    test_repo = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        os.path.pardir,
        'tests',
        'test-repo'
    )

    # Test that when a template exists, the correct path is returned
    test_template = os.path.join(test_repo, 'cookiecutter-{{cookiecutter.repo_name}}')
    assert find_template(test_repo) == test_template

    # Test that when no template exists, an exception is thrown
    no_template_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        os.path.pardir,
        'tests',
        'no-template-repo'
    )



# Generated at 2022-06-11 20:13:18.251869
# Unit test for function find_template
def test_find_template():
    repo_dir = './tests/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == './tests/fake-repo/{{cookiecutter.repo_name}}'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:13:27.908519
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() works as expected."""
    import tempfile
    test_repo_dir = tempfile.mkdtemp()
    test_cookiecutter_dir = os.path.join(test_repo_dir, 'cookiecutter-django')
    os.makedirs(test_cookiecutter_dir)

    assert find_template(test_repo_dir) == test_cookiecutter_dir

# Generated at 2022-06-11 20:13:34.445501
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    def _assert_find_template(template_dir, cookiecutter_json):
        """Test the find_template function."""
        repo_dir = os.path.join(template_dir, cookiecutter_json)
        project_template = find_template(repo_dir)
        basename = os.path.basename(project_template)
        assert basename == cookiecutter_json
    _assert_find_template('tests/test-input/project_templates/', '{{cookiecutter.project_name}}.txt')



# Generated at 2022-06-11 20:13:43.512606
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'fixtures', 'fake-repo')
    template_path = find_template(repo_dir)
    assert template_path is not None
    # Make sure the template_path is within repo_dir
    assert template_path.startswith(repo_dir)
    # Make sure the template_path exists
    assert os.path.isdir(template_path)
    # Make sure the template_path has 'cookiecutter' in it
    assert 'cookiecutter' in template_path
    # Make sure the template_path has the '{{' and '}}'
    assert '{{' in template_path and '}}' in template_path

# Generated at 2022-06-11 20:13:49.769126
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..', '..', 'tests', 'test-driver', 'fake-repo'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

# Generated at 2022-06-11 20:13:59.176816
# Unit test for function find_template
def test_find_template():
    """Tests for function find_template."""
    from cookiecutter import tests
    from .compat import patch

    with patch('os.listdir', new=lambda x: [
        'README.md', '.gitignore', 'cookiecutter-pypackage'
    ]):
        with patch('os.path.isdir', new=lambda x: True):
            template_dir = find_template(tests.FIXTURES_DIR)
            assert template_dir == 'tests/fixtures/cookiecutter-pypackage'


# Generated at 2022-06-11 20:14:01.010602
# Unit test for function find_template
def test_find_template():
    """Test whether find_template works correctly."""
    find_template('tests/fake-repo-pre/')

# Generated at 2022-06-11 20:14:04.230940
# Unit test for function find_template
def test_find_template():
    """Check that the returned template is the one of the two potentially
    valid templates in this directory.
    """
    test_template = find_template("./")
    assert "{{cookiecutter.foo}}" in test_template or "{{cookiecutter.bar}}" in test_template

# Generated at 2022-06-11 20:14:05.074070
# Unit test for function find_template
def test_find_template():
    find_template('test')

# Generated at 2022-06-11 20:14:06.609186
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == './cookiecutter-pypackage'

# Generated at 2022-06-11 20:14:07.301507
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:18.601206
# Unit test for function find_template
def test_find_template():
    """Test find_template()."""
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter import generate

    repo_dir = generate.generate_files(
        repo_dir=None,
        context={
            'cookiecutter': {'name': 'cookiecutter-pypackage'},
        }
    )
    with TemporaryDirectory() as template_dir:
        new_dir = os.path.join(
            template_dir,
            'foobar-{{cookiecutter.name}}',
        )
        os.makedirs(new_dir)
        assert find_template(repo_dir) == new_dir

# Generated at 2022-06-11 20:14:19.368385
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:27.356914
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works correctly."""
    from .exceptions import NonTemplatedInputDirException
    from .compat import TemporaryDirectory
    from .main import cookiecutter

    with TemporaryDirectory() as repo_dir:
        context = {
            'full_name': 'Firstname Lastname',
            'email': 'user@example.com',
            'github_username': 'audreyr'
        }
        cookiecutter(
            'tests/fake-repo-tmpl',
            no_input=True,
            checkout='master',
            output_dir=repo_dir,
            overwrite_if_exists=True,
            extra_context=context)
        p_tmpl = find_template(repo_dir)
        assert os.path.exists(p_tmpl)

# Generated at 2022-06-11 20:14:34.638031
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected."""
    from .compat import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, 'foo'))
        os.makedirs(os.path.join(tmpdir, 'foo', 'bar'))
        os.makedirs(os.path.join(tmpdir, '{{cookiecutter.repo_name}}'))

        assert find_template(tmpdir) == os.path.join(
            tmpdir,
            '{{cookiecutter.repo_name}}'
        )



# Generated at 2022-06-11 20:14:36.916886
# Unit test for function find_template
def test_find_template():
    """Test for finding template in a non templated input directory"""

    from cookiecutter.main import cookiecutter

    output = cookiecutter('tests/test-find-template')
    assert output == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:49.336684
# Unit test for function find_template
def test_find_template():
    from tests.test_functional.test_api import test_repo
    from tests.test_functional.test_user_config import test_user_config

    project_template = find_template(test_repo.working_dir)

    # Should be an absolute path to a directory containing a subdirectory named
    # `cookiecutter-pypackage` that is not enclosed in {{..}}
    assert isinstance(project_template, str)
    assert os.path.isabs(project_template)
    assert project_template.endswith('cookiecutter-pypackage')
    assert project_template.endswith('cookiecutter')

    project_template = find_template(test_user_config.working_dir)

    # Should be an absolute path to a directory containing a subdirectory named
    # `cookiecutter-pyp

# Generated at 2022-06-11 20:14:55.047016
# Unit test for function find_template
def test_find_template():

    repo_dir = os.path.join(os.path.dirname(__file__),
                            'fake-repo-tmpl')

    project_template = find_template(repo_dir)

    # Test that the matching directory is returned
    test_matching_directory = os.path.join(os.path.dirname(__file__),
                                           'fake-repo-tmpl',
                                           '{{cookiecutter.repo_name}}')
    assert project_template == test_matching_directory

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:15:02.971141
# Unit test for function find_template
def test_find_template():
    from cookiecutter.utils import rmtree
    from cookiecutter import repo

    tests_tmp_dir = 'tests/files/tests_tmp_dir'

    # Setup
    repo.clone(
        repo_url='https://github.com/audreyr/cookiecutter-pypackage.git',
        checkout='master',
        clone_to_dir=tests_tmp_dir
    )

    template_dir = find_template(repo_dir=tests_tmp_dir)

    assert 'tests/files/tests_tmp_dir/cookiecutter-pypackage' in template_dir
    rmtree(template_dir)

# Generated at 2022-06-11 20:15:05.858987
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.dirname(os.path.abspath(__file__))
    project_template = find_template(repo_dir)
    assert os.path.exists(project_template)

# Generated at 2022-06-11 20:15:12.130781
# Unit test for function find_template
def test_find_template():
    """
    Unit test for find_template finds the project_template 
    """
    project_template = find_template('tests/fake-repo-pre/')
    assert(project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    project_template = find_template('tests/fake-repo-post/')
    assert(project_template == 'tests/fake-repo-post/fake-repo')
    return True


# Generated at 2022-06-11 20:15:21.446732
# Unit test for function find_template
def test_find_template():
    fake_repo_dir = 'tests/resources/fake-repo'

    assert find_template(fake_repo_dir) == fake_repo_dir + os.sep + '{{cookiecutter.project_slug}}'

# Generated at 2022-06-11 20:15:27.240923
# Unit test for function find_template
def test_find_template():
    """
    Make sure find_template works as expected.
    """
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    project_template = "{{cookiecutter.project_template}}"
    os.mkdir(os.path.join(temp_dir, project_template))
    assert find_template(temp_dir) == os.path.join(temp_dir, project_template)
    shutil.rmtree(temp_dir)

# Generated at 2022-06-11 20:15:34.084281
# Unit test for function find_template
def test_find_template():
    non_templated_input_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'tests/non-templated-input-dir'
    )
    templated_input_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'tests/templated-input-dir'
    )

    assert find_template(non_templated_input_dir) is None
    assert find_template(templated_input_dir)


# Generated at 2022-06-11 20:15:38.459656
# Unit test for function find_template
def test_find_template():
    """
    Finds correct local template directory in 'fake-repo' folder.
    """
    expected = 'fake-repo/{{cookiecutter.repo_name}}'
    assert find_template('fake-repo') == expected

# Generated at 2022-06-11 20:15:42.240188
# Unit test for function find_template
def test_find_template():
    """Verify find_template()."""
    print('test_find_template')

    repo_dir = os.path.abspath('tests/test-repo')
    project_template = find_template(repo_dir)

    assert project_template.endswith('tests/test-repo/{{cookiecutter.dir_name}}')



# Generated at 2022-06-11 20:15:46.411969
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.project_slug}}'

# Generated at 2022-06-11 20:15:50.293536
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.abspath('tests/fake-repo-pre/')) == os.path.abspath('tests/fake-repo-pre/{{cookiecutter.repo_name}}')
    try:
        find_template(os.path.abspath('tests/fake-repo-no-templated/'))
    except NonTemplatedInputDirException:
        pass
    else:
        assert False

# Generated at 2022-06-11 20:15:53.448181
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo/'
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:15:55.247115
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_find import check_find_template
    check_find_template()

# Generated at 2022-06-11 20:16:00.010648
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests/fake-repo-pre/"
    assert find_template(repo_dir) == 'tests/fake-repo-pre/{{cookiecutter.project_name}}'

    repo_dir = "tests/fake-repo-no-slashes/"
    assert find_template(repo_dir) == 'tests/fake-repo-no-slashes/{{cookiecutter.project_name}}'

    repo_dir = "tests/fake-repo-with-period/"
    assert find_template(repo_dir) == 'tests/fake-repo-with-period/{{cookiecutter.project_name}}'



# Generated at 2022-06-11 20:16:21.304078
# Unit test for function find_template
def test_find_template():
    """Check that it correctly determines the template directory"""
    # Create a directory for this test
    temp_dir = 'testfindtemplate' + os.path.sep
    if not os.path.exists(temp_dir):
        os.mkdir(temp_dir)

    # Make a fake template directory
    template_dir = os.path.join(temp_dir, '{{cookiecutter.repo_name}}')
    os.mkdir(template_dir)

    # We should get the fake template directory back
    assert find_template(temp_dir) == template_dir

    # Clean up
    os.rmdir(template_dir)
    os.rmdir(temp_dir)


# Generated at 2022-06-11 20:16:28.761720
# Unit test for function find_template
def test_find_template():
    """Unit test to check if find_template returns the correct directory
    """
    base_path = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(base_path, 'fixtures/fake-repo-pre/')
    input_dir = os.path.join(template_dir, 'fake_project')
    template_dir = find_template(input_dir)
    assert template_dir == os.path.join(base_path, 'fixtures/fake-repo-pre/fake_project')

# Generated at 2022-06-11 20:16:33.225601
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo/{{cookiecutter.repo_name}}/'

# Generated at 2022-06-11 20:16:37.549627
# Unit test for function find_template
def test_find_template():
    this_dir = os.path.dirname(os.path.abspath(__file__))
    test_data_dir = os.path.join(this_dir, '..', 'tests', 'test-data', 'foo-bar')
    assert find_template(test_data_dir) == os.path.join(test_data_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:16:40.953388
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import os
    import re

    # Get a temporary directory with a test repo
    tmp_repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 20:16:48.736822
# Unit test for function find_template
def test_find_template():
    """
    Determine which child directory of `repo_dir` is the project template.

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    logger.debug('Searching %s for the project template.')

    repo_dir_contents = os.listdir(repo_dir)

    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item

    if project_template:
        project_template = os.path.join(repo_dir, project_template)
        logger.debug('The project template appears to be %s', project_template)
        return project_template
    else:
        raise

# Generated at 2022-06-11 20:16:50.076228
# Unit test for function find_template
def test_find_template():
    assert find_template('/usr/local/lib')

# Generated at 2022-06-11 20:16:58.674368
# Unit test for function find_template
def test_find_template():
    """Verify find_template function.

    Runs some tests on the find_template function in order to ensure that it
    works properly.
    """
    # Successful search test
    repo_dir = 'tests/test-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == repo_dir + '{{cookiecutter.repo_name}}'

    # Test that it raises an exception when it can't find the template.
    repo_dir = 'tests/test-repo-post/'
    try:
        project_template = find_template(repo_dir)
        assert False
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-11 20:17:08.861445
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works as expected"""
    import tempfile
    import shutil
    import os
    import sys

    # Get the path to the current file.
    # We need this because we are going to change to another directory.
    file_path = os.path.dirname(os.path.realpath(__file__))

    # Create a temporary directory.
    tmp_dir = tempfile.mkdtemp()
    # Does the directory exist?
    assert os.path.isdir(tmp_dir)

    # Change to the temporary directory.
    old_dir = os.getcwd()
    os.chdir(tmp_dir)

    # Create a test directory.
    tmp_dir_template = os.path.join(tmp_dir, 'cookiecutter-test-dir-{{cwd}}')
    os

# Generated at 2022-06-11 20:17:16.242349
# Unit test for function find_template
def test_find_template():
    """
    """
    import tempfile
    test_dir = os.path.join(tempfile.gettempdir(), 'test_find_template')
    os.makedirs(test_dir)
    os.chdir(test_dir)

# Generated at 2022-06-11 20:17:36.061436
# Unit test for function find_template
def test_find_template():
    """Tests for function `find_template`."""
    from nose.tools import assert_equal
    from cookiecutter import utils

    template_dir = utils.get_template("tests/fake-repo-tmpl/")
    project_template = find_template(template_dir)
    assert_equal(project_template, template_dir + '/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:17:40.791949
# Unit test for function find_template
def test_find_template():
    """Verify function find_template."""

    from cookiecutter.main import cookiecutter
    from tempfile import mkdtemp
    from shutil import rmtree
    from cookiecutter.exceptions import NonTemplatedInputDirException

    test_dir = mkdtemp()


# Generated at 2022-06-11 20:17:45.335524
# Unit test for function find_template
def test_find_template():
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    project_template = utils.find_template(utils.WORKING_DIR)

    assert project_template

    try:
        utils.find_template(__file__)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError((
            'Expected NonTemplatedInputDirException'
            ' to be raised when trying to find a template in a directory that'
            ' does not contain a cookiecutter template'
        ))

# Generated at 2022-06-11 20:17:51.738148
# Unit test for function find_template
def test_find_template():
    """Test the find template function."""
    current_dir = os.path.dirname(os.path.realpath(__file__))
    repo_dir = os.path.join(current_dir, '..', 'tests', 'fake-repo-pre-rename')
    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, 'cookiecutter-pypackage'), template_dir

# Generated at 2022-06-11 20:17:56.502740
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert project_template == '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:17:57.355259
# Unit test for function find_template
def test_find_template():
    assert find_template('~/projects/')

# Generated at 2022-06-11 20:18:00.176381
# Unit test for function find_template
def test_find_template():
    """Test for find_template function."""
    repo_dir = '../tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == '../tests/fake-repo-pre/fake-project-template/'

# Generated at 2022-06-11 20:18:04.487898
# Unit test for function find_template
def test_find_template():
    """
    Test the find_template function.
    """
    repo_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'tests', 'fake-repo-tmpl')
    assert find_template(repo_dir) == os.path.join(repo_dir, 'cookiecutter-pypackage')

# Generated at 2022-06-11 20:18:15.168375
# Unit test for function find_template
def test_find_template():
    import shutil
    import zipfile
    import tempfile
    from cookiecutter.compat import TemporaryDirectory

    root_dir = tempfile.mkdtemp()
    test_repo = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test-repo')
    test_repo_zip = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test-repo.zip')

    z = zipfile.ZipFile(test_repo_zip)
    z.extractall(root_dir)
    test_repo = os.path.join(root_dir, 'test-repo')


# Generated at 2022-06-11 20:18:17.759613
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:18:54.314528
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil

    temp_repo_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_repo_dir, '{{cookiecutter.repo_name}}'))

    project_template = find_template(temp_repo_dir)
    expected_template = os.path.join(
        temp_repo_dir, '{{cookiecutter.repo_name}}'
    )
    assert project_template == expected_template, \
        'Expected {}, got {}.'.format(expected_template, project_template)
    shutil.rmtree(temp_repo_dir)



# Generated at 2022-06-11 20:19:00.339537
# Unit test for function find_template
def test_find_template():
    from .generate import setup_env
    setup_env()
    from cookiecutter.main import cookiecutter

    # Make a fake repo
    output_dir = cookiecutter(
        'tests/files/fake-repo-pre/',
        no_input=True,
        overwrite_if_exists=True
    )

    print(output_dir)

    # Now remove the fake repo
    shutil.rmtree(output_dir)

# Generated at 2022-06-11 20:19:08.353132
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter finds a template in a repo."""
    print("test_find_template")
    # test_repo_path = 'tests/test-repo/'
    test_repo_path = 'C:/Users/A4A/Desktop/tests/test-repo/'
    #test_repo_path = 'D:/work/test-repo/'
    print(test_repo_path)
    template = find_template(test_repo_path)
    assert template == os.path.join(test_repo_path, '{{cookiecutter.repo_name}}')

# test_find_template()

# Generated at 2022-06-11 20:19:15.454337
# Unit test for function find_template
def test_find_template():
    """Verify that find_template works as expected."""
    # Test with a valid local template
    repo_dir = 'tests/test-find-template'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/test-find-template/{{cookiecutter.repo_name}}'
    # Test with an invalid local template
    repo_dir = 'tests/fake-repo'
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        assert False, 'NonTemplatedInputDirException was not raised'

# Generated at 2022-06-11 20:19:16.485320
# Unit test for function find_template
def test_find_template():
    assert find_template('.') == './cookiecutter-pypackage/'

# Generated at 2022-06-11 20:19:20.304404
# Unit test for function find_template
def test_find_template():
    assert find_template("test_data/test_cookiecutter_repo") ==\
        "test_data/test_cookiecutter_repo/{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:19:26.171243
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    test_repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', '..', 'tests', 'test-find-template'
    ))

    result = find_template(test_repo_dir)
    expected = os.path.join(test_repo_dir, '{{cookiecutter.repo_name}}')
    assert result == expected

# Generated at 2022-06-11 20:19:27.901428
# Unit test for function find_template
def test_find_template():
    find_template('tests/fake-repo-tmpl')

# Generated at 2022-06-11 20:19:36.277649
# Unit test for function find_template
def test_find_template():
    from os.path import dirname, join
    from tempfile import mkdtemp
    from shutil import rmtree
    from subprocess import check_call
    from textwrap import dedent
    repo_dir = mkdtemp()


# Generated at 2022-06-11 20:19:41.020034
# Unit test for function find_template
def test_find_template():
    """Test function find_template.

    If the function is not successful, an exception is thrown.
    """
    input_dir = os.path.join('tests', 'test-find-template', 'input')
    find_template(repo_dir=input_dir)

# Generated at 2022-06-11 20:20:49.972190
# Unit test for function find_template
def test_find_template():
    find_template('/home/username/cookiecutter-pypackage/')

# Generated at 2022-06-11 20:20:52.037345
# Unit test for function find_template
def test_find_template():
    repo_dir = "test_find_template"
    assert find_template("test_find_template") == "test_find_template/{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:20:59.254149
# Unit test for function find_template
def test_find_template():
    """Test that find_template() can locate a template in a repo."""
    template_root = "tests/test-repos/cookiecutter-jquery"
    template_path = find_template(template_root)
    assert template_path == "tests/test-repos/cookiecutter-jquery/%7B%7Bcookiecutter.repo_name%7D%7D"

# Generated at 2022-06-11 20:21:01.670495
# Unit test for function find_template
def test_find_template():

    template_dir = find_template(repo_dir='tests/fake-repo-pre/')
    assert template_dir == 'tests/fake-repo-pre/cookiecutter-{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:21:12.267081
# Unit test for function find_template
def test_find_template():
    """Tests for find_template."""
    class MockRepoDir(object):
        """Mocked repo dir for testing find_template."""
        def __init__(self, cookiecutter_dir, cookiecutter_file, cookiecutter_file2):
            self.cookiecutter_dir = cookiecutter_dir
            self.cookiecutter_file = cookiecutter_file
            self.cookiecutter_file2 = cookiecutter_file2

        def join(self, rel_path):
            return os.path.join(self.cookiecutter_dir, rel_path)

        def listdir(self):
            return [self.cookiecutter_file, self.cookiecutter_file2]

    # Check that the file containing cookiecutter is identified as the template


# Generated at 2022-06-11 20:21:13.896744
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:21:22.972771
# Unit test for function find_template
def test_find_template():
    from cookiecutter.main import get_user_config

    test_find_template.find_template_config = get_user_config(
        context_file='tests/test-find-template/config.yaml',
        repo_dir='tests/test-find-template',
        default_config=False
    )
    test_find_template.project_template = find_template('tests/test-find-template')
    assert isinstance(test_find_template.project_template, basestring)
    assert test_find_template.project_template == 'tests/test-find-template/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:21:28.745228
# Unit test for function find_template
def test_find_template():
    """Test if the right value is being returned."""
    cur_dir = os.path.normpath(os.path.abspath('./test/test-template'))
    temp = find_template(cur_dir)
    expected = os.path.normpath(os.path.join(cur_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    assert(temp == expected)



# Generated at 2022-06-11 20:21:32.905456
# Unit test for function find_template
def test_find_template():
    """Verify find_template function."""
    local_repo_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test-repo')
    )
    project_template = find_template(local_repo_path)
    assert project_template == os.path.join(local_repo_path, '{{cookiecutter.repo_name}}')