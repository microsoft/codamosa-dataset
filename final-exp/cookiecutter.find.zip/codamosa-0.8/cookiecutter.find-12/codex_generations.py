

# Generated at 2022-06-11 20:11:40.328647
# Unit test for function find_template
def test_find_template():
    """Function searches newly cloned repository for project template."""
    from shutil import rmtree
    from .utils import TEST_REPOS

    test_repo_dir = TEST_REPOS / 'accounts'

    try:
        find_template(test_repo_dir)
    except NonTemplatedInputDirException:
        assert False
    finally:
        rmtree(test_repo_dir)

# Generated at 2022-06-11 20:11:44.501063
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    template = find_template('examples/tests/test-cookiecutter-jquery')
    assert template == 'examples/tests/test-cookiecutter-jquery/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:11:46.945065
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/cookiecutter-pypackage'

# Generated at 2022-06-11 20:11:54.325305
# Unit test for function find_template
def test_find_template():
    """Test function for finding the template directory."""
    import tempfile
    from cookiecutter.compat import unicode

    repo_dir = tempfile.mkdtemp()

    cookiecutter_py = os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.repo_name}}')
    os.mkdir(cookiecutter_py)

    cookiecutter_js = os.path.join(repo_dir, 'cookiecutter-{cookiecutter.repo_name}')
    os.mkdir(cookiecutter_js)

    output = find_template(repo_dir)
    if output != cookiecutter_py:
        raise Exception("Error")

    # Non-templated directory
    # This is used by test_fail_if_not_templated

    cookiecut

# Generated at 2022-06-11 20:11:57.349593
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/david/cookiecutter-pypackage'
    project_template = '/home/david/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:11:58.929368
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.expanduser('~/.cookiecutters/cookiecutter-pypackage'))

# Generated at 2022-06-11 20:12:00.231219
# Unit test for function find_template
def test_find_template():
    find_template()
    assert True

# Generated at 2022-06-11 20:12:08.748172
# Unit test for function find_template
def test_find_template():

    import tempfile
    repo_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(repo_dir, 'test{{test1}}'))
    os.makedirs(os.path.join(repo_dir, 'test2'))
    template = find_template(repo_dir)
    assert template == os.path.join(repo_dir, 'test{{test1}}')
    os.remove(os.path.join(repo_dir, 'test{{test1}}'))
    os.remove(os.path.join(repo_dir, 'test2'))

# Generated at 2022-06-11 20:12:13.377509
# Unit test for function find_template
def test_find_template():
    # Test with a faked out repo with files in it
    my_dir = 'tests/test-find-template'
    assert find_template(my_dir) == os.path.join(my_dir, 'my-project-{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:12:19.969578
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    import tempfile

    base_dir = os.path.abspath(os.path.dirname(__file__))
    template_dir = os.path.join(base_dir, '..', 'tests', 'test-template')
    repo_dir = tempfile.mkdtemp()
    shutil.copytree(template_dir, os.path.join(repo_dir, 'template'))
    try:
        assert 'template' == find_template(repo_dir)
    finally:
        shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:12:33.158472
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.exceptions import NonTemplatedInputDirException
    import tempfile

    # Test non-templated input directory
    templatedir = os.path.join(
        DEFAULT_CONFIG['cookiecutters_dir'],
        'cookiecutter-pypackage',
        '{{cookiecutter.repo_name}}'
    )

    # Test a dir with a single templated input

# Generated at 2022-06-11 20:12:37.557957
# Unit test for function find_template
def test_find_template():
    repo_dir = 'some_repo'
    repo_dir_contents = ['cookiecutter', 'cookiecutter-foobar', 'README', 'LICENSE']

    with mock.patch('os.listdir', return_value=repo_dir_contents):
        assert find_template(repo_dir) == 'some_repo/cookiecutter-foobar'

# Generated at 2022-06-11 20:12:45.754725
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    repo_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), 'tests/test-find-project-tpl'))
    tpl_dir = find_template(repo_dir)
    assert os.path.exists(tpl_dir)
    assert tpl_dir == os.path.join(os.path.dirname(__file__), 'tests/test-find-project-tpl/my-awesome-project')


# Generated at 2022-06-11 20:12:48.936540
# Unit test for function find_template
def test_find_template():
    """ Sanity check for find_template. """
    repo_dir = '/home/audreyr/Code/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/home/audreyr/Code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:57.074793
# Unit test for function find_template
def test_find_template():

    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-tmpl'
    )

    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'test-repo-tmpl',
        'cookiecutter-pypackage'
    )

    assert project_template == expected_project_template

# Generated at 2022-06-11 20:13:05.104652
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template()."""
    import shutil
    import tempfile

    test_root = tempfile.mkdtemp()
    test_repo = os.path.join(test_root, 'test_repo')
    os.mkdir(test_repo)
    test_templated_dir = os.path.join(test_repo, 'cookiecutter-jquery')
    shutil.copytree(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)), '..', 'tests',
            'fake-repo-pre-gen'),
        test_repo
    )
    assert find_template(test_repo) == test_templated_dir
    shutil.rmtree(test_root)

# Unit

# Generated at 2022-06-11 20:13:10.138682
# Unit test for function find_template
def test_find_template():
    """Test function for finding the project template for the repo_dir."""
    tests_dir = 'tests/fake-repo-pre/'
    project_template = '{{cookiecutter.repo_name}}'
    assert find_template(tests_dir) == os.path.join(tests_dir, project_template)

# Generated at 2022-06-11 20:13:13.772889
# Unit test for function find_template
def test_find_template():
    repo_dir = '../tests/fake-repo/'
    project_template = '../tests/fake-repo/{{cookiecutter.project_slug}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:13:15.681391
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/user/AUTHORS-cookiecutter') == '/home/user/AUTHORS-cookiecutter'

# Generated at 2022-06-11 20:13:18.945817
# Unit test for function find_template
def test_find_template():
    import tempfile, shutil
    tempdir = tempfile.mkdtemp()

    # write file called "file1.txt" into tempdir
    filepath = os.path.join(tempdir, 'testtemplate')
    os.mkdir(filepath)
    os.chdir(tempdir)


# Generated at 2022-06-11 20:13:30.540026
# Unit test for function find_template
def test_find_template():
    """
    Unit test the find_template() function.
    """
    import unittest
    import shutil
    import tempfile

    class TestFindTemplate(unittest.TestCase):

        def setUp(self):
            """
            Make a temp dir and a subdir to search for a template directory
            """
            self.current_dir = os.getcwd()
            self.temp_dir = tempfile.mkdtemp()
            os.chdir(self.temp_dir)
            self.search_dir = os.path.join(self.temp_dir, 'subdir')
            os.mkdir(self.search_dir)

        def tearDown(self):
            """
            Delete the temp directory
            """
            os.chdir(self.current_dir)

# Generated at 2022-06-11 20:13:33.094327
# Unit test for function find_template
def test_find_template():
    template_path = find_template('cookiecutter-pypackage/')
    assert template_path == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:13:34.116191
# Unit test for function find_template
def test_find_template():
    """Test find_template."""
    pass

# Generated at 2022-06-11 20:13:42.038468
# Unit test for function find_template
def test_find_template():
    import tempfile
    temp_repo_path = tempfile.mkdtemp()
    try:
        project_template_name = "cookiecutter-pypackage"
        project_template_path = os.path.join(temp_repo_path, project_template_name)
        os.mkdir(project_template_path)

        project_template = find_template(temp_repo_path)
        assert project_template == project_template_path
    finally:
        os.rmdir(project_template_path)
        os.rmdir(temp_repo_path)

# Generated at 2022-06-11 20:13:47.353900
# Unit test for function find_template
def test_find_template():
    """Test perform find_template function."""
    import tempfile

    temp_folder = tempfile.mkdtemp()

    try:
        assert find_template(temp_folder) is None
    finally:
        os.rmdir(temp_folder)



# Generated at 2022-06-11 20:13:49.097987
# Unit test for function find_template
def test_find_template():
    # TODO: Can't run this test because this function depends on inspecting
    # directory contents.
    pass

# Generated at 2022-06-11 20:13:50.526212
# Unit test for function find_template
def test_find_template():
    """
    test the function find template
    """

    pass

# Generated at 2022-06-11 20:13:55.156942
# Unit test for function find_template
def test_find_template():
    """Given a sample project template, see if we can locate it."""
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        'test-template-repo',
        'test-template'
    )
    project_template = find_template(repo_dir)

    assert project_template == repo_dir


# Generated at 2022-06-11 20:14:03.837173
# Unit test for function find_template
def test_find_template():
    """Unit test for :function:`cookiecutter.find.find_template`."""
    from cookiecutter import find
    import tempfile
    import os
    import shutil
    import logging

    repo_dir = tempfile.mkdtemp()
    project_template = os.path.join(repo_dir, 'project_template')

    os.makedirs(project_template)
    open(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'), 'a').close()

    os.chdir(repo_dir)

    assert find.find_template('.') == os.path.abspath('project_template')

    shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:14:04.348230
# Unit test for function find_template
def test_find_template():
	pass

# Generated at 2022-06-11 20:14:09.611361
# Unit test for function find_template
def test_find_template():
    template_dir = os.getcwd()
    project_template = find_template(template_dir)
    assert '{{ cookiecutter.project_name }}' in project_template

# Generated at 2022-06-11 20:14:19.190632
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    os.chdir(os.path.normpath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests'
    )))
    repo_dir = os.path.normpath(os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fake-repo'
    ))
    project_template = find_template(repo_dir)
    expected_project_template = os.path.normpath(os.path.join(
        repo_dir,
        'fake-cookiecutter-project'
    ))
    assert project_template == expected_project_template

# Generated at 2022-06-11 20:14:24.454705
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/me/dev/git/Cookiecutter-demo') == '/Users/me/dev/git/Cookiecutter-demo/{{cookiecutter.project_name}}'
    assert find_template('/Users/me/dev/git/cookiecutter-django') == '/Users/me/dev/git/cookiecutter-django/{{cookiecutter.project_name}}'

# end of functions find_template

# Generated at 2022-06-11 20:14:34.885718
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil

    # Create test directories
    repo_dir = tempfile.mkdtemp()

    try:
        # Make sure that if there are no variable-containing directories
        # the function returns None
        os.makedirs(os.path.join(repo_dir, 'basic_dir'))
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise ValueError("find_template should raise an exception if there "
                         "were no variable-containing directories in repo_dir")

    # Make sure that if there are two variable-containing directories, the
    # function returns the first one
    os.makedirs(os.path.join(repo_dir, '{{ cookiecutter.project_slug }}'))
    os.maked

# Generated at 2022-06-11 20:14:41.737028
# Unit test for function find_template
def test_find_template():
    import os
    import shutil
    import tempfile
    import cookiecutter

    repo_dir = os.path.expanduser('~')
    logger.debug('Testing find_template() with %s', repo_dir)
    try:
        project_template = cookiecutter.find_template(repo_dir)
        assert project_template is None
    except NonTemplatedInputDirException:
        pass

    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, 'cookiecutter-foobar'))
    try:
        project_template = cookiecutter.find_template(temp_dir)
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-11 20:14:50.138443
# Unit test for function find_template
def test_find_template():
    """
    Assert that ``find_template`` correctly identifies a template
    """
    if os.path.isdir("/tmp/foo"):
        os.system("rm -rf /tmp/foo")
    os.mkdir("/tmp/foo")
    os.system("echo 'some text' > /tmp/foo/{{cookiecutter.author_name}}")
    assert find_template("/tmp/foo") == '/tmp/foo/{{cookiecutter.author_name}}'
    os.system("rm -rf /tmp/foo")

# Generated at 2022-06-11 20:14:55.118106
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    import shutil
    from cookiecutter.vcs import git

    git.clone(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        'input/tests/test-find-template',
        checkout=u''
    )
    template_dir = find_template('input/tests/test-find-template')
    assert os.path.isdir(template_dir)
    shutil.rmtree('input/tests/test-find-template')

# Generated at 2022-06-11 20:15:02.731044
# Unit test for function find_template
def test_find_template():
    """
    Return directory of unzipped repo with function find_template
    """
    import os
    from cookiecutter.utils.paths import TEST_TEMPLATES_DIR
    repo_dir = os.path.abspath(TEST_TEMPLATES_DIR)
    for item in os.listdir(TEST_TEMPLATES_DIR):
        if 'cookiecutter' in item:
            project_template = item
    project_template = os.path.abspath(os.path.join(repo_dir, project_template))
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:15:09.659780
# Unit test for function find_template
def test_find_template():
    from cookiecutter.repository import git
    import os
    import shutil
    from cookiecutter.config import DEFAULT_CONFIG

    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl'))
    cloned_repo_dir = git.clone(repo_dir)
    project_template = find_template(cloned_repo_dir)
    shutil.rmtree(cloned_repo_dir)
    assert project_template == os.path.join(cloned_repo_dir, '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:15:20.844946
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    import tempfile
    import shutil

    repo_dir = tempfile.mkdtemp()
    project_template = tempfile.mkdtemp(dir=repo_dir)
    open(os.path.join(project_template, 'cookiecutter.json'), 'wb').close()

    repo_dir_contents = os.listdir(repo_dir)

    assert len(repo_dir_contents) == 2
    assert find_template(repo_dir) == project_template

    shutil.rmtree(repo_dir)

    repo_dir_contents = os.listdir(repo_dir)

    assert len(repo_dir_contents) == 0

    shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:15:26.979265
# Unit test for function find_template
def test_find_template():
    actual = find_template('/home/vagrant/code/cookiecutter-pypackage')
    expected = '/home/vagrant/code/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert actual == expected

# Generated at 2022-06-11 20:15:29.173173
# Unit test for function find_template
def test_find_template():
    assert find_template('c:\cookiecutter\cookiecutter-pypackage') == 'c:\cookiecutter\cookiecutter-pypackage\{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:32.162574
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/audreyr/cookiecutter-pypackage/') == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}/'



# Generated at 2022-06-11 20:15:36.956735
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(os.path.dirname(__file__), 'fixtures')
    test_project_template = find_template(repo_dir)
    assert test_project_template == os.path.join(repo_dir, 'project_template')

# Generated at 2022-06-11 20:15:41.968899
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() returns the full path to the
    project template.
    """

    repo_dir = os.path.abspath(os.path.join('tests', 'fake-repo'))
    expected = os.path.abspath(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    result = find_template(repo_dir)

    assert expected == result

# Generated at 2022-06-11 20:15:50.209213
# Unit test for function find_template
def test_find_template():
    """Test template dir detection."""
    import tempfile
    from cookiecutter import utils

    tmp_dir = tempfile.mkdtemp()

    repo_dir = os.path.join(tmp_dir, 'cookiecutter-pypackage')
    os.makedirs(repo_dir)

    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    utils.make_sure_path_exists(template_dir)

    assert find_template(repo_dir) == template_dir


# Generated at 2022-06-11 20:16:00.355917
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    import tempfile
    import shutil
    from cookiecutter import repository

    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, '{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(temp_dir, '{{cookiecutter.repo_name}}-abc'))

    cloned_repo = repository.clone(
        "https://github.com/audreyr/cookiecutter-pypackage.git",
        checkout='0.1.6',
        no_input=True,
        clone_to_dir=temp_dir
    )


# Generated at 2022-06-11 20:16:10.008313
# Unit test for function find_template
def test_find_template():
    """Unit test for function ``find_template``"""
    # Create a dict-like object that serves as the input context
    class Context(dict):
        pass
    input_context = Context({
        'cookiecutter': {
            'project_name': 'Awesome Project',
        }
    })

    context = Context()
    context.update(input_context)

    template_dir = find_template('./tests/fake-repo-tmpl')

    expected_template_dir = os.path.abspath(
        os.path.join('./tests/fake-repo-tmpl', '{{ cookiecutter.project_name }}')
    )

    assert template_dir == expected_template_dir

# Generated at 2022-06-11 20:16:13.724560
# Unit test for function find_template
def test_find_template():
    repo_dir = "tests/test-input/fake-repo"

    result = find_template(repo_dir)

    # in this case, the project template is the repo directory
    expected = repo_dir
    assert result == expected


# Generated at 2022-06-11 20:16:17.379982
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-tmpl'
    project_template = find_template(repo_dir)

    expected_project_template = os.path.join(repo_dir, '{{cookiecutter.project_name}}')
    assert project_template == expected_project_template

# Generated at 2022-06-11 20:16:31.159196
# Unit test for function find_template
def test_find_template():
    """Find project template in a newly cloned repo."""
    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo',
    )
    project_template = find_template(repo_dir)

    # Mocked clone directory structure:
    # fake-repo
    # ├── readme.md
    # ├── {{cookiecutter.repo_name}}
    # │   └── readme.md
    # └── {{cookiecutter.repo_name}}.py
    project_template_dir = os.path.join(
        repo_dir,
        '{{cookiecutter.repo_name}}',
    )

    assert project_template == project_template_dir

# Generated at 2022-06-11 20:16:37.464542
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil

    repo_dir = os.path.join('tests', 'fake-repo-pre-gen')

    test_dir = tempfile.mkdtemp()
    shutil.copytree(repo_dir, test_dir)

    project_template = find_template(test_dir)
    assert os.path.join(test_dir, '{{cookiecutter.repo_name}}') == project_template

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:16:39.038960
# Unit test for function find_template
def test_find_template():
    find_template('../tests/fake-repo-templated/')

# Generated at 2022-06-11 20:16:40.355592
# Unit test for function find_template
def test_find_template():
    """Unit tests for function find_template"""
    pass

# Generated at 2022-06-11 20:16:48.513856
# Unit test for function find_template
def test_find_template():
    """Test find_template function.

    Test for an exception when find_template fails.
    """
    from cookiecutter.exceptions import NonTemplatedInputDirException

    fake_project_template = os.path.join('fake', 'project', 'template')

    def _mock_listdir(path):
        return [fake_project_template]

    def _mock_isfile(path):
        return True

    orig_listdir = os.listdir
    orig_isfile = os.path.isfile
    try:
        os.listdir = _mock_listdir
        os.path.isfile = _mock_isfile

        project_template = find_template('fake/project/dir')

        assert project_template == fake_project_template

    finally:
        os.listdir = orig_listdir

# Generated at 2022-06-11 20:16:51.698290
# Unit test for function find_template
def test_find_template():
    import os
    os.chdir('tests/test-project/')
    project_template = find_template('.')
    assert project_template == '{{cookiecutter.repo_name}}'
    os.chdir('../..')

# Generated at 2022-06-11 20:16:58.305762
# Unit test for function find_template
def test_find_template():
    import tempfile
    
    with tempfile.TemporaryDirectory() as temp_dir:
        repo_dir = os.path.join(temp_dir, 'repo_dir')
        template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
        os.makedirs(template_dir)

        assert find_template(repo_dir) == template_dir

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:17:06.334241
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil

    repo_dir = os.path.join(tempfile.gettempdir(), 'fake-repo')
    os.makedirs(repo_dir)

    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    os.makedirs(template_dir)

    found_template = find_template(repo_dir)
    assert found_template == template_dir

    shutil.rmtree(repo_dir)


# Generated at 2022-06-11 20:17:11.886055
# Unit test for function find_template
def test_find_template():
    """Verify find_template() works correctly."""
    from cookiecutter.tests.test_files.fake_repo import make_fake_repo

    fake_repo_dir = make_fake_repo()
    assert find_template(fake_repo_dir) == os.path.join(
        fake_repo_dir, '{{cookiecutter.project_name}}'
    )

# Generated at 2022-06-11 20:17:13.981421
# Unit test for function find_template
def test_find_template():
    template_dir = 'tests/fake-repo-pre/'
    results = find_template(template_dir)
    assert results == template_dir + '{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:17:32.668215
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns correct path."""

    assert(
        find_template('tests/test-data/fake-repo/_tests_cookiecutter_dirs') ==
        os.path.abspath('tests/test-data/fake-repo/_tests_cookiecutter_dirs/_tests_cookiecutter_dirs')
    )

# Generated at 2022-06-11 20:17:38.199170
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    from cookiecutter.tests.test_utils import TEST_ROOT
    from cookiecutter.utils import is_repo_url

    repo_dir = os.path.join(TEST_ROOT, 'fake-repo-tmpl')
    assert not is_repo_url(repo_dir)
    result = find_template(repo_dir)
    print(result)
    expected = os.path.join(TEST_ROOT, 'fake-repo-tmpl/{{cookiecutter.repo_name}}')
    assert result == expected

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:17:42.486378
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    template = 'fake-repo/{{cookiecutter.project_slug}}/'

    assert find_template(repo_dir) == template

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:17:46.832645
# Unit test for function find_template
def test_find_template():
    """Verify that template is found in local directory."""
    from cookiecutter import main
    from cookiecutter.utils import rmtree
    repo_dir = main.cookiecutter('tests/fake-repo-tmpl/')
    actual = find_template(repo_dir)

    assert 'fake-project' in actual
    assert '{{cookiecutter.project_slug}}' in actual

    rmtree(repo_dir)

# Generated at 2022-06-11 20:17:51.871137
# Unit test for function find_template
def test_find_template():
    """Verify function finds correct path to template.
    """
    template = 'tests/fake-repo-tmpl'
    expected_result = os.path.abspath('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')
    assert(find_template(template) == expected_result)

# Generated at 2022-06-11 20:17:56.907016
# Unit test for function find_template
def test_find_template():
    this_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(this_dir, 'fake-repo-pre-gen')

    assert os.path.join(repo_dir, 'fake-project-template') == find_template(repo_dir)

# Generated at 2022-06-11 20:18:02.857907
# Unit test for function find_template
def test_find_template():
    test_template_name = 'foo'
    test_dir = os.path.join(os.getcwd(), test_template_name)

    os.mkdir(test_dir)
    test_path = os.path.join(test_dir, '{{cookiecutter.test_field}}')
    with open(test_path, 'w') as f:
        f.write('test contents')

    template_path = find_template(test_dir)
    assert template_path == test_path

    assert os.path.exists(template_path)
    assert os.path.isdir(test_dir)
    os.remove(template_path)
    assert os.path.exists(template_path) == False
    assert os.path.isdir(test_dir)

# Generated at 2022-06-11 20:18:12.639071
# Unit test for function find_template
def test_find_template():
    # Mock object
    import mock

    repo_dir_contents = ['cookiecutter-pypackage',
                         'README',
                         'LICENSE']

    repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    m = mock.Mock()
    m.listdir.return_value = repo_dir_contents
    with mock.patch('os.path', m):
        project_template = find_template(repo_dir)

        print(project_template)
        print(m.listdir.call_args)
        print(m.listdir.call_args_list)
        print(m.listdir.mock_calls)

# Generated at 2022-06-11 20:18:16.765454
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'fake-repo',
        'cookiecutter-pypackage'
    )
    assert find_template(repo_dir) == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:18:21.659506
# Unit test for function find_template

# Generated at 2022-06-11 20:18:53.107323
# Unit test for function find_template
def test_find_template():
    """
    test_find_template: Test the find_template() function.
    """
    repo_dir = "./tests/test-find-repo/"
    project_template = find_template(repo_dir)
    assert project_template == "./tests/test-find-repo/cookiecutter-{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:18:56.824521
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    template_name = find_template('tests/test-repo')
    assert template_name == 'tests/test-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:19:06.892550
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    from shutil import rmtree
    from cookiecutter.utils import rmtree
    from os.path import dirname, join

    # Make a mock repo with a templated dir in it
    input_dir = join(
        dirname(__file__), 'fake-repo-pre-gen', 'cookiecutter-pypackage'
    )
    repo_dir = 'tmp-cc-test-find-template'
    rmtree(repo_dir, ignore_errors=True)
    shutil.copytree(input_dir, join(repo_dir, '{{cookiecutter.repo_name}}'))
    assert find_template(repo_dir) == join(
        repo_dir, '{{cookiecutter.repo_name}}')
    rmt

# Generated at 2022-06-11 20:19:09.996874
# Unit test for function find_template
def test_find_template():
    repo_dir = 'ChkCookiecutter'
    project_template = '{{cookiecutter.project_name}}/{{cookiecutter.project_slug}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:19:12.676001
# Unit test for function find_template
def test_find_template():
    """Test the `find_template` function."""
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    find_template(repo_dir)

# Generated at 2022-06-11 20:19:14.449054
# Unit test for function find_template
def test_find_template():
  assert find_template("/tmp") == '/tmp/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:19:19.103711
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """
    repo_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'fake-repo'
    )
    assert find_template(repo_dir) == os.path.join(
        repo_dir, 'cookiecutter-pypackage'
    )

# Generated at 2022-06-11 20:19:26.118914
# Unit test for function find_template
def test_find_template():
    """Test that the function finds the name of the template."""
    find_template('/home/vagrant/cookiecutter-data/tests/fake-repo-pre/')
    find_template('/home/vagrant/cookiecutter-data/tests/fake-repo-pre-master/')
    find_template('/home/vagrant/cookiecutter-data/tests/fake-repo-pre-no-slash/')
    find_template('/home/vagrant/cookiecutter-data/tests/fake-repo-pre-no-slash-master/')

# Generated at 2022-06-11 20:19:31.615252
# Unit test for function find_template
def test_find_template():
    """Check that find_template is giving us the correct output."""
    tmp_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test_template')
    template = find_template(tmp_dir)
    assert template == os.path.join(tmp_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:19:34.780285
# Unit test for function find_template
def test_find_template():
    assert find_template("/Users/kylepjohnson/cookiecutter-scripts/cookiecutters/{{cookiecutter.repo_name}}") == "/Users/kylepjohnson/cookiecutter-scripts/cookiecutters/{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:20:12.388884
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    repo_dir = 'tests/fake-repo-tmpl'
    result = find_template(repo_dir)
    expected = 'tests/fake-repo-tmpl/tests/{{cookiecutter.repo_name}}'
    assert result == expected

# Generated at 2022-06-11 20:20:14.074155
# Unit test for function find_template
def test_find_template():
    # from cookiecutter.tests.test_find import test_find_template
    # test_find_template()
    pass

# Generated at 2022-06-11 20:20:14.573356
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:20:19.573464
# Unit test for function find_template
def test_find_template():
    """Normal case. Able to find template in a cloned repo."""
    assert ('tests/'
            'test-find-repo/'
            '{{cookiecutter.repo_name}}/'
            '{{cookiecutter.repo_name}}') == find_template(
        'tests/test-find-repo'
    )
    # print(find_template('tests/test-find-repo'))


# Generated at 2022-06-11 20:20:23.188513
# Unit test for function find_template
def test_find_template():
    """Verify `find_template` correctly identifies the project template."""
    good_input_path = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'good-repo-tmpl')
    assert find_template(good_input_path) == os.path.join(
        good_input_path, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:20:31.839237
# Unit test for function find_template
def test_find_template():
    import sys
    import shutil
    import tempfile
    import logging
    import os

    from cookiecutter.exceptions import NonTemplatedInputDirException

    logger.level = logging.DEBUG
    stream = logging.StreamHandler(sys.stdout)
    logger.addHandler(stream)

    d = tempfile.mkdtemp()

    with open(os.path.join(d, 'README.md'), 'w') as f:
        f.write('README')

    assert find_template(d) == None

    os.mkdir(os.path.join(d, '{{cookiecutter.repo_name}}'))
    assert find_template(d) == d + '/{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:20:38.277917
# Unit test for function find_template
def test_find_template():
    assert find_template('D:\2015\Edx\MITx\RedHat\Python-Fundamentals\Assignments\cookiecutter-mitx') == 'D:\2015\Edx\MITx\RedHat\Python-Fundamentals\Assignments\cookiecutter-mitx\\{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:20:42.601925
# Unit test for function find_template
def test_find_template():
    """
    Test that find_template works.
    """
    template_path = find_template(os.getcwd())
    assert template_path == os.path.join(os.getcwd(), 'tests/fake-repo-pre/', '{{cookiecutter.repo_name}}'), 'find_template() should return {0}, but returned {1}'.format(os.path.join(os.getcwd(), 'tests/fake-repo-pre/', '{{cookiecutter.repo_name}}'), template_path)

# Generated at 2022-06-11 20:20:50.806424
# Unit test for function find_template
def test_find_template():
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = os.path.abspath('tests/fake-repo-tmpl/')
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, 'fake-project')

    repo_dir = os.path.abspath('tests/fake-repo-pre/')
    with pytest.raises(NonTemplatedInputDirException):
        find_template(repo_dir)

# Generated at 2022-06-11 20:20:55.297112
# Unit test for function find_template
def test_find_template():
    THIS_DIR = os.path.dirname(os.path.abspath(__file__))
    EMPTY_REPO_DIR = os.path.normpath(
        os.path.join(THIS_DIR, '../', 'tests/fake-repo/empty-repo/')
    )
    NORMAL_REPO_DIR = os.path.normpath(
        os.path.join(THIS_DIR, '../', 'tests/fake-repo/normal-repo/')
    )

    assert find_template(EMPTY_REPO_DIR) == ''
    assert find_template(NORMAL_REPO_DIR) == 'normal-repo/{{cookiecutter.repo_name}}'