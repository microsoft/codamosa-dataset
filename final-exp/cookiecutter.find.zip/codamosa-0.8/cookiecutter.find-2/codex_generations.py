

# Generated at 2022-06-11 20:11:39.479130
# Unit test for function find_template
def test_find_template():
    assert find_template(os.path.abspath('tests/fake-repo-pre/')) == os.path.abspath('tests/fake-repo-pre/cookiecutter-{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:11:43.978518
# Unit test for function find_template
def test_find_template():
    repo_dir = 'test-repo'
    project_template = 'test-cookiecutter-templated'
    os.mkdir(os.path.join(repo_dir, project_template))
    assert find_template(repo_dir) == os.path.join(repo_dir, project_template)

# Generated at 2022-06-11 20:11:52.652470
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    templates_dir = os.path.join(os.path.dirname(__file__), 'templates')
    temp_dir = tempfile.mkdtemp()

    shutil.copy(os.path.join(templates_dir, 'repo-with-slash'), temp_dir)
    shutil.copy(os.path.join(templates_dir, 'repo-no-slash'), temp_dir)
    shutil.copy(os.path.join(templates_dir, 'repo-no-slash-jinja2'), temp_dir)

    assert find_template(temp_dir) == os.path.join(temp_dir, os.listdir(temp_dir)[0])

# Generated at 2022-06-11 20:11:55.222168
# Unit test for function find_template
def test_find_template():
    """Verify correct templates are found."""
    test_dir = 'tests/files/find_template'
    assert 'example' in find_template(test_dir)

# Generated at 2022-06-11 20:11:57.029993
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/') == 'tests/python-package-template{{cookiecutter.package_name}}'

# Generated at 2022-06-11 20:12:00.996352
# Unit test for function find_template
def test_find_template():
    actual = find_template(os.path.join(os.getcwd(),"tests/fake-repo-pre"))
    expected = os.path.join(os.getcwd(),"tests/fake-repo-pre/{{cookiecutter.repo_name}}")
    assert actual == expected


# Generated at 2022-06-11 20:12:10.413108
# Unit test for function find_template
def test_find_template():
    """Check searching for a project template in a cloned repo works."""
    import tempfile
    from cookiecutter.exceptions import NonTemplatedInputDirException

    repo_dir = tempfile.mkdtemp()
    test_dir = os.path.join(repo_dir, 'test_dir')
    os.mkdir(test_dir)
    os.mkdir(os.path.join(repo_dir, 'test_cookiecutter_template_project'))

    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        raise AssertionError('find_template cannot find project template')
    except:
        raise AssertionError('find_template should find project template')



# Generated at 2022-06-11 20:12:12.091807
# Unit test for function find_template
def test_find_template():
    """Verify ``find_template`` returns the correct result."""
    pass

# Generated at 2022-06-11 20:12:20.444959
# Unit test for function find_template
def test_find_template():
    """Test function for find_template function."""
    import shutil
    import tempfile
    import textwrap
    import jinja2

    template_name = 'fake_project_template'

    def fake_template_file(filename):
        """Create a fake template file in a temp directory.

        :param filename: Name of the file to be created in the temp directory.
        :returns None:
        """
        env = jinja2.Environment()
        template = env.from_string(
            textwrap.dedent("""
                # Fake template file that contains 'cookiecutter' and '{{' and
                '}}'
                # Also has a "fake_key": "fake_value" entry.
                fake_key: "fake_value"
            """)
        )

# Generated at 2022-06-11 20:12:22.621157
# Unit test for function find_template
def test_find_template():
    """
    Tests the find_template function.
    """
    assert 'bar' in find_template('tests/test-data/input')


# Generated at 2022-06-11 20:12:29.922556
# Unit test for function find_template
def test_find_template():
    repodir = os.path.abspath('tests/fake-repo-tmpl/')
    tmpl = find_template(repodir)
    assert tmpl == os.path.join(repodir,'fake-project-{{cookiecutter.repo_name}}'), tmpl

# Generated at 2022-06-11 20:12:39.006063
# Unit test for function find_template
def test_find_template():
    """ Test to check if function works properly """
    # Create a test directory
    os.mkdir('test_folder')

    # Create a templated folder
    os.mkdir('test_folder/{{cookiecutter.project_slug}}')

    # Create a non templated folder
    os.mkdir('test_folder/test_folder')

    # Check if function returns right file
    assert find_template('test_folder') == 'test_folder/{{cookiecutter.project_slug}}'

    # Remove the test files
    os.rmdir('test_folder/test_folder')
    os.rmdir('test_folder/{{cookiecutter.project_slug}}')
    os.rmdir('test_folder')


# Generated at 2022-06-11 20:12:41.628734
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:12:50.087668
# Unit test for function find_template
def test_find_template():
    """Assert that the project template is correctly determined."""
    from cookiecutter import utils
    from cookiecutter import exceptions

    #Test case 1: project template is "{{cookiecutter.repo_name}}"
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '../tests/test-repo/{{cookiecutter.repo_name}}'
        )
    )
    project_template = utils.find_template(repo_dir)
    assert project_template == repo_dir
    print(project_template)

    #Test case 2: project template isn't "{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:12:53.558529
# Unit test for function find_template
def test_find_template():
    repo_dir = None
    project_template = find_template(repo_dir)
    assert project_template == 'cookiecutter-{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:13:02.456493
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find a template in a local directory."""
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    repo_dir = os.path.join(tmp_dir, 'cookiecutter-pypackage')
    os.makedirs(repo_dir)

    os.mkdir(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))
    os.makedirs(os.path.join(repo_dir, 'some-directory'))

    project_template = find_template(repo_dir)
    shutil.rmtree(tmp_dir)

    assert project_template.endswith('{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:13:07.258480
# Unit test for function find_template
def test_find_template():
    cur_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir = os.path.join(cur_dir, 'tests', 'test-find-template', 'fake-repo')
    found = find_template(repo_dir)
    expected = os.path.join(repo_dir, 'fake-project-template')

    assert expected == found

# Generated at 2022-06-11 20:13:15.303204
# Unit test for function find_template
def test_find_template():
    import shutil
    import tempfile

    d = tempfile.mkdtemp()
    os.mkdir(os.path.join(d, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(d, 'cookiecutter-pypackage'))
    os.mkdir(os.path.join(d, 'cookiecutter'))
    os.mkdir(os.path.join(d, 'cookiecutter-{{cookiecutter.repo_name}}'))
    os.mkdir(os.path.join(d, 'test-{{cookiecutter.repo_name}}'))

    assert find_template(d) == os.path.join(
        d, 'cookiecutter-{{cookiecutter.repo_name}}'
    )

    shutil.rmt

# Generated at 2022-06-11 20:13:20.210689
# Unit test for function find_template
def test_find_template():
    import shutil
    import os
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.main import cookiecutter

    # Make a fake project to test the function
    config_dict = {}
    config_dict.update(DEFAULT_CONFIG)
    config_dict['cookiecutters_dir'] = '/tmp/fake-cc'
    fake_project = cookiecutter(
        'tests/fake-repo-tmpl',
        no_input=True,
        overwrite_if_exists=True,
        config_file=config_dict
    )

    # Test the function
    assert find_template(fake_project) == fake_project
    shutil.rmtree(fake_project, ignore_errors=True)

# Generated at 2022-06-11 20:13:23.399424
# Unit test for function find_template
def test_find_template():
    try:
        find_template('/home/dv/Documents/work/github/cookiecutter-pypackage')
    except NonTemplatedInputDirException:
        raise Exception('there is no cookiecutter template')

# Generated at 2022-06-11 20:13:28.646457
# Unit test for function find_template
def test_find_template():
    try:
        project_template = find_template('test_repo/')
    except NonTemplatedInputDirException:
        return
    else:
        raise ValueError('test_repo should not be a valid project template')

test_find_template()

# Generated at 2022-06-11 20:13:29.752546
# Unit test for function find_template
def test_find_template():
    """Verify that find_template correctly determines the project template."""
    pass

# Generated at 2022-06-11 20:13:30.192576
# Unit test for function find_template
def test_find_template():
    pass


# Generated at 2022-06-11 20:13:31.850811
# Unit test for function find_template
def test_find_template():
    try:
        assert find_template('/tmp/cookiecutter-master')
    except Exception as e:
        print (e)

# Generated at 2022-06-11 20:13:42.363453
# Unit test for function find_template
def test_find_template():
    """Verify that the correct path is returned."""
    import tempfile

    temp_dir = tempfile.mkdtemp()
    repo_contents = [
        'cookiecutter-project',
        'cookiecutter-pypackage',
        'cookiecutter-py3-project',
        'cookiecutter-test-template',
        'cookiecutter-testing',
        'cookiecutter-test-package',
        'cookiecutter-test',
        'cookiecutter-test-prefix',
        'cookiecutter-test-prefix']
    for dir_name in repo_contents:
        os.makedirs(os.path.join(temp_dir, dir_name))

    assert find_template(temp_dir) == os.path.join(temp_dir, 'cookiecutter-test-template')

# Generated at 2022-06-11 20:13:53.518293
# Unit test for function find_template
def test_find_template():
    """Test for function find_template."""
    import tempfile
    import shutil
    import cookiecutter

    repo_template = tempfile.mkdtemp()
    normal_dir = os.path.join(repo_template, 'normal_dir')
    templated_dir = os.path.join(repo_template, '{{cookiecutter.repo_name}}')
    os.mkdir(normal_dir)
    os.mkdir(templated_dir)
    try:
        expected_templated_dir = templated_dir
        templated_dir = cookiecutter.find_template(repo_template)
        assert templated_dir == expected_templated_dir
    finally:
        shutil.rmtree(repo_template)

# Generated at 2022-06-11 20:14:03.213053
# Unit test for function find_template
def test_find_template():
    """Return relative path to project template."""
    from cookiecutter.prompt import read_user_yes_no
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

    logger.debug('Making temp directory...')
    os.makedirs(os.path.join(repo_dir, 'foo'))
    os.makedirs(os.path.join(repo_dir, 'bar'))
    os.makedirs(os.path.join(repo_dir, '{{cookiecutter.repo_name}}'))

    assert find_template(repo_dir) == os.path.join(
        repo_dir, '{{cookiecutter.repo_name}}'
    )

    shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:14:14.575112
# Unit test for function find_template
def test_find_template():
    """
    Test for find_template function.
    """

    import os
    import tempfile

    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Create a temporary directory
    tempdir = tempfile.mkdtemp()
    repo_dir = os.path.join(tempdir, 'fake-repo')
    os.makedirs(repo_dir)

    # Temporarily change to this directory
    cwd = os.getcwd()
    os.chdir(tempdir)

    with open(os.path.join(repo_dir, 'README.rst'), 'w') as f:
        f.write('README')

# Generated at 2022-06-11 20:14:20.223698
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'test-data',
        'git-repos',
        'cookiecutter-pypackage'
    )
    template_dir = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert find_template(repo_dir) == template_dir

# Generated at 2022-06-11 20:14:27.789413
# Unit test for function find_template
def test_find_template():
    """Verify that find_template() can locate the project template."""
    import shutil
    from cookiecutter import utils
    from cookiecutter.exceptions import NonTemplatedInputDirException

    # Make a fake cookiecutter template
    fake_repo_dir = os.path.abspath(os.path.dirname(__file__))
    test_dir = os.path.join(fake_repo_dir, 'tests')
    fake_repo = os.path.join(test_dir, 'fake-repo-tmpl')

    fake_repo_tmpl = os.path.join(fake_repo, '{{cookiecutter.repo_name}}')
    utils.make_sure_path_exists(fake_repo_tmpl)
    
    # Make sure it can be found

# Generated at 2022-06-11 20:14:32.880169
# Unit test for function find_template
def test_find_template():
    repo_dir = 'cookiecutter-pypackage'
    project_template = 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:14:39.290694
# Unit test for function find_template
def test_find_template():
    """Verify proper template directory name."""
    repo_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            'fake-repo',
            'hook-no-cookiecutter-json'
        )
    )
    project_template = find_template(repo_dir)
    expected_project_template = os.path.join(repo_dir, 'fake-project-name')

    assert project_template == expected_project_template

# Generated at 2022-06-11 20:14:45.201693
# Unit test for function find_template
def test_find_template():
    """Test the find_template function."""
    repo_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'test-find-template')
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:14:45.926811
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:14:47.579051
# Unit test for function find_template
def test_find_template():
    find_template(".") == "./{{cookiecutter.project_name}}"

# Generated at 2022-06-11 20:14:55.664835
# Unit test for function find_template
def test_find_template():

    lookup = find_template()
    assert type(lookup) is data
    assert len(lookup) == 15
    assert lookup[0] == '2014-07-01'
    assert lookup[1] == '2014-07-02'
    assert lookup[2] == '2014-07-03'
    assert lookup[3] == '2014-07-04'
    assert lookup[4] == '2014-07-05'
    assert lookup[5] == '2014-07-06'
    assert lookup[6] == '2014-07-07'
    assert lookup[7] == '2014-07-08'
    assert lookup[8] == '2014-07-09'
    assert lookup[9] == '2014-07-10'
    assert lookup[10] == '2014-07-11'
    assert lookup[11]

# Generated at 2022-06-11 20:14:57.437782
# Unit test for function find_template
def test_find_template():
    """
    Tests the find_template function.
    """

    find_template('dummydir')

# Generated at 2022-06-11 20:15:04.269168
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        'tests/test-cookiecutter',
        'fake-repo-pre/{{cookiecutter.repo_name}}'
    )
    project_template = find_template(repo_dir)
    assert project_template == os.path.join(
        'tests/test-cookiecutter',
        'fake-repo-pre/{{cookiecutter.repo_name}}/cookiecutter-pypackage/'
    )

# Generated at 2022-06-11 20:15:09.139752
# Unit test for function find_template
def test_find_template():
    """ Test that find_template finds the template """
    from .config import Config
    from .repository import determine_repo_dir
    from .environment import StrictEnvironment

    repo_dir = determine_repo_dir(template=None)
    config_dict = Config(config_file='cookiecutter.yaml').get_config()

    assert find_template(repo_dir=repo_dir) == os.path.join(repo_dir, config_dict['project_name'])

# Generated at 2022-06-11 20:15:09.638556
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:15:22.888092
# Unit test for function find_template
def test_find_template():
    # Write the test template.
    from cookiecutter import utils
    from cookiecutter.config import DEFAULT_EXTRA_CONTEXT
    from cookiecutter.generate import generate_context
    from cookiecutter.main import cookiecutter

    tmp_dir = os.path.expanduser('~/testing_cookiecutter/tests/test-find-template')
    utils.make_sure_path_exists(tmp_dir)
    context_file = os.path.join(tmp_dir, 'context.py')

    with open(context_file, 'w') as f:
        f.write('description = "The repo to test the find_template function"')

    context = generate_context(
        context_file=context_file,
        default_context=DEFAULT_EXTRA_CONTEXT
    )
   

# Generated at 2022-06-11 20:15:23.944912
# Unit test for function find_template
def test_find_template():
    # TODO: Fix this
    pass

# Generated at 2022-06-11 20:15:28.532526
# Unit test for function find_template
def test_find_template():
    import tempfile
    from os import mkdir
    from os.path import join

    # Create temporary repo with cookiecutter dir
    repo_dir = tempfile.mkdtemp()
    template_dir = join(repo_dir, 'cookiecutter-{{package_name}}')
    mkdir(template_dir)
    # Check if template was found
    assert find_template(repo_dir) == template_dir

# Generated at 2022-06-11 20:15:30.898727
# Unit test for function find_template
def test_find_template():
    assert find_template('cookiecutter-pypackage') == 'cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:36.957370
# Unit test for function find_template
def test_find_template():
    """Test the find_template() function."""
    from cookiecutter import utils

    repo_dir = os.path.join(utils.ROOT_PROJECT_DIR, 'tests', 'test-repo')

    project_template = find_template(repo_dir)
    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:15:43.601965
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns a valid template."""
    from .compat import TemporaryDirectory

    with TemporaryDirectory() as temp_dir_path:

        project_name = 'testing'
        repo_dir = os.path.join(temp_dir_path, project_name)
        project_template = os.path.join(repo_dir, project_name)

        os.mkdir(project_template)
        with open(os.path.join(project_template, 'file.txt'), 'w') as f:
            f.write('testing')

        assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:15:53.903853
# Unit test for function find_template
def test_find_template():
    """
    Unit test for function find_template
    """

    # Test for repo
    repo_dir = os.path.expanduser("~/Code/cookiecutter-pypackage")
    res = find_template(repo_dir)
    assert res == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    # Test for non-repo
    repo_dir = os.path.expanduser("~/Code")
    try:
        find_template(repo_dir)
    except NonTemplatedInputDirException:
        assert True
    else:
        assert False

    # Test for non-existant
    repo_dir = os.path.expanduser("~/Code/cookiecutter-pypackkkkage")

# Generated at 2022-06-11 20:16:00.998637
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_find_template import (
        test_find_template,
        test_find_template_no_templates_in_input_dir,
    )
    assert find_template(test_find_template)
    try:
        find_template(test_find_template_no_templates_in_input_dir)
    except NonTemplatedInputDirException:
        pass
    else:
        raise AssertionError(
            'NonTemplatedInputDirException should be raised when no template is found.'
        )

# Generated at 2022-06-11 20:16:06.914446
# Unit test for function find_template
def test_find_template():
    template_dir = '/Users/pydanny/Documents/repos/cookiecutter-djangopackage'
    project_template = find_template(template_dir)
    expected_template = os.path.join(
        '/Users/pydanny/Documents/repos/cookiecutter-djangopackage',
        'cookiecutter-djangopackage'
    )
    assert expected_template == project_template



# Generated at 2022-06-11 20:16:09.931976
# Unit test for function find_template
def test_find_template():
    repo_dir = '/Users/jasongill/Development/github/cookiecutter-demo'

    template = find_template(repo_dir)

# Generated at 2022-06-11 20:16:19.436368
# Unit test for function find_template
def test_find_template():
    assert find_template('tests/fake-repo-pre/') == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:16:29.289203
# Unit test for function find_template
def test_find_template():
    """Mock a clone of a valid Cookiecutter template and test finding it."""
    import pytest
    import shutil
    import tempfile

    repo_dir = tempfile.mkdtemp()

    # Make sure a template is in the repo directory
    with open('{}/cookiecutter-foobar'.format(repo_dir), 'w') as f:
        f.write('should not be here')

    with open('{}/cookiecutter-{{{{cookiecutter.project_name}}}}'.format(repo_dir), 'w') as f:
        f.write('should be here')

    template_dir = find_template(repo_dir)
    assert template_dir == os.path.join(repo_dir, 'cookiecutter-{{cookiecutter.project_name}}')

    shutil.r

# Generated at 2022-06-11 20:16:35.014577
# Unit test for function find_template
def test_find_template():
    template_dir = os.path.join(
        os.path.dirname(__file__),
        '..',
        'tests',
        'fixtures',
        'fake-repo',
    )

    template = find_template(template_dir)
    assert '{{cookiecutter.repo_name}}' in template

# Generated at 2022-06-11 20:16:45.476488
# Unit test for function find_template
def test_find_template():
    """Validate that find_template returns the expected template."""
    import os
    import shutil
    import tempfile

    def touch(path):
        """Create a file at the specified path."""
        with open(path, 'w') as f:
            f.write('')

    d = tempfile.mkdtemp()
    os.mkdir(os.path.join(d, 'a'))
    touch(os.path.join(d, 'a', '{{ cookiecutter.repo_name }}'))
    os.mkdir(os.path.join(d, 'b'))
    touch(os.path.join(d, 'b', 'c'))
    os.mkdir(os.path.join(d, 'c'))

# Generated at 2022-06-11 20:16:55.258362
# Unit test for function find_template
def test_find_template():
    """
    Test that a function for finding the project template in a repo dir.
    """
    template_name = find_template(os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-repo-tmpl'
    ))

    real_name = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'tests',
        'test-repo-tmpl',
        '{{cookiecutter.repo_name}}'
    )

    assert real_name == template_name

# Generated at 2022-06-11 20:17:04.552607
# Unit test for function find_template
def test_find_template():
    """Test find_template function.

    As defined in cookiecutter.find.find_template.
    """
    repo_dir = os.path.abspath(os.path.join('tests', 'fake-repo-tmpl'))
    project_template = find_template(repo_dir)
    expected = os.path.abspath(
        os.path.join('tests', 'fake-repo-tmpl', '{{cookiecutter.repo_name}}')
    )
    assert project_template == expected

# Generated at 2022-06-11 20:17:09.617501
# Unit test for function find_template
def test_find_template():
    """Test that the find_template"""
    import pytest
    from cookiecutter.exceptions import NonTemplatedInputDirException
    repo_dir = 'tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/fake-project-{{cookiecutter.repo_name}}'
    with pytest.raises(NonTemplatedInputDirException):
        find_template('tests/fake-repo-pre/fake-project')

# Generated at 2022-06-11 20:17:16.578154
# Unit test for function find_template
def test_find_template():
    """
    Here we need a test directory that contains a subdirectory of the repo that
    is the project template.  The project template should contain at least the
    string 'cookiecutter' and a pair of double curly braces '{{' and '}}'.
    """
    import shutil
    import tempfile
    import unittest

    repo_dir = tempfile.mkdtemp()

    # Make a test subdirectory
    test_subdir = os.path.join(repo_dir, 'cookiecutter-tests')
    os.makedirs(test_subdir)

    # Make a test subdirectory that does not contain 'cookiecutter' or double
    # curly braces.
    bad_subdir = os.path.join(repo_dir, 'cookiecutter-bad')
    os.makedirs(bad_subdir)



# Generated at 2022-06-11 20:17:21.229056
# Unit test for function find_template
def test_find_template():
    print('find_template module test')
    repo_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                            '..', 'data'))
    project_template = find_template(repo_dir)
    print(project_template)

# Generated at 2022-06-11 20:17:27.691298
# Unit test for function find_template
def test_find_template():

    repo_dir = '/home/me/cookiecutter-repo'
    repo_dir_contents = ['{{cookiecutter.project_name}}', 'exclude', 'include']
    project_template = None

    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break

    assert project_template == '{{cookiecutter.project_name}}'
    assert project_template != 'exclude'
    assert project_template != 'include'



# Generated at 2022-06-11 20:17:45.188500
# Unit test for function find_template
def test_find_template():
    root_dir = os.path.join(os.path.abspath(''), 'tests/test-find-template')
    assert find_template(repo_dir=root_dir) == os.path.join(root_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:17:51.106235
# Unit test for function find_template
def test_find_template():
    """Unittest for find_template().
    """
    import os
    import pytest
    from cookiecutter import exceptions

    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-pre')

    # Make sure find_template works
    project_dir = find_template(repo_dir)
    assert project_dir == os.path.join(repo_dir, 'fake-project')
    assert os.path.isdir(project_dir)

    # Make sure find_template raises a NonTemplatedInputDirException if a
    # templated directory can't be found
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo-post')

# Generated at 2022-06-11 20:17:58.917168
# Unit test for function find_template
def test_find_template():
    """Determine which child directory of `repo_dir` is the project template.
     Unit Test

    :param repo_dir: Local directory of newly cloned repo.
    :returns project_template: Relative path to project template.
    """
    repo_dir = os.path.join('tests','test-data','simple-project')
    repo_dir_contents = os.listdir(repo_dir)

    project_template = find_template(repo_dir)
    assert os.path.basename(project_template) == "cookiecutter-{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:18:01.869236
# Unit test for function find_template
def test_find_template():
    """Find template in tests/fake-repo."""
    repo_dir = 'tests/fake-repo/'
    result = find_template(repo_dir)
    assert result == repo_dir + '{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:18:12.223863
# Unit test for function find_template
def test_find_template():
    """
    Check if find_template returns the correct directory
    """
    # Get current directory
    current = os.path.split(os.path.abspath(__file__))[0]
    # Get parent directory
    repo = os.path.split(current)[0]
    # Get repo_dir
    repo_dir = '{0}/{1}'.format(repo, "cookiecutter-pytest")
    # Get directory that find_template should return
    ans = '{0}/{1}'.format(repo_dir, "cookiecutter-pypackage")
    # compare the answers
    assert find_template(repo_dir) == ans

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:18:15.263401
# Unit test for function find_template
def test_find_template():
    repo = "./tests/fake-repo"
    template = find_template(repo)
    assert template == os.path.join(repo, "fake-repo-{{cookiecutter.repo_name}}")



# Generated at 2022-06-11 20:18:20.812928
# Unit test for function find_template
def test_find_template():
    """Test for find_template function."""
    repo_dir = os.path.join(os.getcwd(), 'tests', 'fake-repo')
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert(find_template(repo_dir) == project_template)

# Generated at 2022-06-11 20:18:24.926096
# Unit test for function find_template
def test_find_template():
    local_repo_dir = '/Users/audreyr/cookiecutter-pypackage'
    project_template = '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'
    assert find_template(local_repo_dir) == project_template

# Generated at 2022-06-11 20:18:28.019122
# Unit test for function find_template
def test_find_template():
    print(find_template('tests/test-repo-pre/'))
    print(find_template('tests/fake-repo/'))

if __name__ == '__main__':
    test_find_template()

# Generated at 2022-06-11 20:18:33.717620
# Unit test for function find_template
def test_find_template():
    """Verify that the proper template is being returned.
    """
    template_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            os.pardir, 'tests', 'fake-repo-pre-gen'
        )
    )
    template = find_template(template_dir)
    assert os.path.join(template_dir, 'fake-repo-pre-gen') == template

# Generated at 2022-06-11 20:19:07.243899
# Unit test for function find_template
def test_find_template():
    repo_dir = 'some_dir'
    find_template(repo_dir)

# Generated at 2022-06-11 20:19:11.101840
# Unit test for function find_template
def test_find_template():
    """Test function for find_template"""
    import os

    os.chdir('tests')

    template = find_template('fake-repo-pre/')
    assert template == 'fake-repo-pre/{{cookiecutter.repo_name}}'

    os.chdir('..')

# Generated at 2022-06-11 20:19:15.077882
# Unit test for function find_template
def test_find_template():
    template_path = find_template("tests/test-repo/fake-repo-tmpl/")
    assert template_path == "tests/test-repo/fake-repo-tmpl/{{cookiecutter.repo_name}}"

# find_template("tests/test-repo/fake-repo-tmpl/")

# Generated at 2022-06-11 20:19:15.505424
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:19:16.561494
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter finds the project template in the input repo."""
    pass

# Generated at 2022-06-11 20:19:21.870157
# Unit test for function find_template
def test_find_template():
    """Test for finding the template directory in a new clone."""
    repo_dir = "tests/fake-repo-tmpl"
    project_template = find_template(repo_dir)
    expected = os.path.abspath('tests/fake-repo-tmpl/{{cookiecutter.repo_name}}')
    assert project_template == expected

# Generated at 2022-06-11 20:19:28.773644
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/code/cookiecutter/tests/fake-repo-tmpl/{{cookiecutter.repo_name}}') == '/Users/audreyr/code/cookiecutter/tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    assert find_template('/Users/audreyr/code/cookiecutter/tests/fake-repo-pre/cookiecutter-pypackage') == '/Users/audreyr/code/cookiecutter/tests/fake-repo-pre/cookiecutter-pypackage'

# Generated at 2022-06-11 20:19:33.934770
# Unit test for function find_template
def test_find_template():
    """Test function find_template."""
    # FIXME: This test fails on Windows, because os.listdir doesn't return
    # absolute paths.
    assert find_template('tests/fixtures/fake-repo-pre') == \
        'tests/fixtures/fake-repo-pre/{{cookiecutter.directory_name}}'

# Generated at 2022-06-11 20:19:43.430626
# Unit test for function find_template
def test_find_template():
    from nose.tools import assert_equal
    from tempfile import mkdtemp

    repo_tmp_dir = mkdtemp()
    os.mkdir(os.path.join(repo_tmp_dir, 'cookiecutter-foobar'))
    os.mkdir(os.path.join(repo_tmp_dir, 'cookiecutter'))
    os.mkdir(os.path.join(repo_tmp_dir, 'cookiecutter-{{cookiecutter.repo_name}}'))
    template_dir = os.path.join(repo_tmp_dir, 'cookiecutter-{{cookiecutter.repo_name}}')

    result = find_template(repo_tmp_dir)
    assert_equal(result, template_dir)

# Generated at 2022-06-11 20:19:47.751617
# Unit test for function find_template
def test_find_template():
    import tempfile
    import shutil
    import os

    template_name = 'my_template'
    temp_dir = tempfile.mkdtemp('cookicutter-unittest')
    template_dir = os.path.join(temp_dir, template_name)
    os.mkdir(template_dir)

    assert find_template(temp_dir) == template_dir

    shutil.rmtree(temp_dir)

# Generated at 2022-06-11 20:21:00.172334
# Unit test for function find_template
def test_find_template():
    normal_path = os.path.join('tests', 'test-repos', 'normal_repo_no_extensions')
    template_path = find_template(normal_path)
    assert template_path == os.path.join('tests', 'test-repos', 'normal_repo_no_extensions', 'cookiecutter-pypackage')



# Generated at 2022-06-11 20:21:08.355827
# Unit test for function find_template
def test_find_template():
    with open(os.path.join(os.path.dirname(__file__), 'test_repo', '.git'), 'w') as gitfile:
        gitfile.write('test')
    try:
        testdir = os.path.join(os.path.dirname(__file__), 'test_repo')
        output = find_template(testdir)
        assert output == os.path.join(testdir, '{{cookiecutter.repo_name}}')
    finally:
        os.remove(os.path.join(os.path.dirname(__file__), 'test_repo', '.git'))

# Generated at 2022-06-11 20:21:14.525381
# Unit test for function find_template
def test_find_template():
    """Verify find_template returns ``True`` for a known case."""
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        '..', 'tests', 'test-repo-pre'
    ))
    project_template = find_template(repo_dir)

    template_name = 'asdf'
    logger.debug('Checking if %s is in %s', template_name, project_template)
    assert os.path.isfile(os.path.join(project_template, template_name))

# Generated at 2022-06-11 20:21:17.702073
# Unit test for function find_template
def test_find_template():
    assert (
        '/home/audreyr/cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}',
        find_template('/home/audreyr/cookiecutters/cookiecutter-pypackage')
    )

# Generated at 2022-06-11 20:21:27.808867
# Unit test for function find_template
def test_find_template():
    """
    Tests the proper directory is found.
    """
    import tempfile
    from shutil import rmtree

    DIRNAME = 'repo'
    DIRNAME2 = 'repo2'
    DIRNAME3 = 'repo3'

    TEMPLATE_DIRNAME = '{{cookiecutter.repo_name}}'

    TEMPLATED_DIRNAME = 'cookiecutter-pypackage'

    TEMPLATE_DIRNAME2 = 'foo'
    TEMPLATED_DIRNAME2 = 'cookiecutter-foo'

    TEMPLATE_DIRNAME3 = '{{cookiecutter.repo_name}}'


# Generated at 2022-06-11 20:21:34.013762
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the correct directory when given a mock listdir result.
    """
    from cookiecutter.utils import working_directory
    from .fake_files import fake_listdir
    from .fake_files import fake_listdir_fail

    assert find_template(fake_listdir()) == 'example/{{cookiecutter.repo_name}}'

    try:
        find_template(fake_listdir_fail())
    except NonTemplatedInputDirException:
        pass
    else:
        assert False

    # Ensure that find_template works in directory with non-ASCII characters
    # The template is called 'fake-æøå.zip'