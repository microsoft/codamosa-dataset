

# Generated at 2022-06-11 20:11:38.502003
# Unit test for function find_template
def test_find_template():
    """Verify expected exception is raised when only one subdirectory exists"""
    repo_dir = '/my/path/to/repo/'
    os.listdir(repo_dir)
    # No exception here. Should really be patched here
    assert find_template(repo_dir) == None

# Generated at 2022-06-11 20:11:39.477727
# Unit test for function find_template
def test_find_template():
    logger.debug('Testing find_template')
    pass

# Generated at 2022-06-11 20:11:50.201012
# Unit test for function find_template
def test_find_template():
    """Test find_template in a temporary folder"""

    import tempfile

    # Create temp dir
    path = tempfile.mkdtemp()

    # Write some files in the temp dir
    with open(os.path.join(path, 'cookiecutter.json'), 'w'):
        pass

    with open(os.path.join(path, 'cookiecutter'), 'w'):
        pass

    with open(os.path.join(path, 'cookiecutter-{{myvar}}'), 'w'):
        pass

    with open(os.path.join(path, 'cookiecutter-{{myvar1}}-{{myvar2}}'), 'w'):
        pass

    with open(os.path.join(path, 'myproj'), 'w'):
        pass


# Generated at 2022-06-11 20:11:57.818832
# Unit test for function find_template
def test_find_template():
    """Check that "cookiecutter-pypackage" is found when given a Cookiecutter repo."""

    from tests.test_finders import clone_fake_repo
    from cookiecutter import utils
    from cookiecutter.utils import rmtree

    fake_repo_dir = clone_fake_repo()
    try:
        template = utils.find_template(fake_repo_dir)
    finally:
        rmtree(fake_repo_dir)
    assert 'cookiecutter-pypackage' in template

# Generated at 2022-06-11 20:12:05.076487
# Unit test for function find_template
def test_find_template():
    import builtins

    repo_name_tmp = 'cookiecutter-pypackage'

    try:
        builtins.raw_input = lambda x: repo_name_tmp
        repo_dir_tmp = repo_name_tmp
        project_template = find_template(repo_dir_tmp)
        assert project_template == os.path.join(repo_dir_tmp, repo_name_tmp)
    except AttributeError:
        pass
    except NameError:
        pass
    finally:
        del builtins.raw_input

# Generated at 2022-06-11 20:12:10.449332
# Unit test for function find_template
def test_find_template():
    repo_dir = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    project_template = find_template(repo_dir)
    assert project_template == 'https://github.com/audreyr/cookiecutter-pypackage.git/cookiecutter-{% now "utc", "%Y%m%d" %}{{cookiecutter.project_slug}}'


# Generated at 2022-06-11 20:12:14.536693
# Unit test for function find_template
def test_find_template():
    from integrationtests.test_templates_repo import clone_test_repo

    repo_dir = clone_test_repo()
    project_template = find_template(repo_dir)

    assert "{{cookiecutter.repo_name}}" in project_template

# Generated at 2022-06-11 20:12:18.936829
# Unit test for function find_template
def test_find_template():
    """Test finding project template."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    expected_output = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == expected_output

# Generated at 2022-06-11 20:12:30.347777
# Unit test for function find_template
def test_find_template():
    """Verify function for determining which child directory of a
    newly cloned repo is the project template."""
    from cookiecutter.repository import make_repo_dirs
    from shutil import rmtree
    from os.path import exists

    # Make testing repo
    repo_dir = make_repo_dirs(
        project_dir='fake-repo',
        repo_dir='tests/fake-repo-tmpl',
        abbreviations={'full_name': 'Awesome Corp.'},
        clone_to_dir=None
    )

    # Test
    actual = find_template(repo_dir)

    expected = 'tests/fake-repo/{{cookiecutter.repo_name}}'

    # Teardown - remove testing repo

# Generated at 2022-06-11 20:12:35.342038
# Unit test for function find_template
def test_find_template():
    """ Test whether the find_template() function works properly.
    """

    test_template_dir = os.path.join(
        'tests', 'test-find-template', '{{cookiecutter.repo_name}}'
    )
    assert test_template_dir == find_template(
        os.path.join('tests', 'test-find-template')
    )

# Generated at 2022-06-11 20:12:40.244151
# Unit test for function find_template
def test_find_template():
    """Unit tests for function find_template."""
    import pytest
    with pytest.raises(NonTemplatedInputDirException):
        find_template('tests/fake-repo-pre/')
    find_template('tests/fake-repo/')

# Generated at 2022-06-11 20:12:45.019128
# Unit test for function find_template
def test_find_template():
    """Find the template in the repo_dir"""

    repo_dir = '/home/fakeuser/cookiecutters/cookiecutter-pypackage'
    assert find_template(repo_dir) == '/home/fakeuser/cookiecutters/cookiecutter-pypackage/{{cookiecutter.repo_name}}'




# Generated at 2022-06-11 20:12:48.906233
# Unit test for function find_template
def test_find_template():
    """Find out what function find_template returns"""
    repo_dir = os.path.join(os.getcwd(), 'cookiecutter-pypackage')
    find_template(repo_dir) == os.path.join(os.getcwd(), 'cookiecutter-pypackage', '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:12:51.938003
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""
    # Test the function for finding the project template
    find_template('/Users/david/cookiecutter-django')

# Generated at 2022-06-11 20:12:59.975342
# Unit test for function find_template
def test_find_template():
    """
    confirm find_template function is returning the correct directory
    """
    path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre'))
    expected_path= os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}'))
    returned_path = find_template(path)
    assert expected_path == returned_path

# Generated at 2022-06-11 20:13:03.934623
# Unit test for function find_template
def test_find_template():
    repo_dir = 'tests/fake-repo-pre/'
    project_template = find_template(repo_dir)
    assert project_template == 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:08.850304
# Unit test for function find_template
def test_find_template():
    """Test for function `find_template`."""
    from cookiecutter.tests.test_find import repo_path
    expected_template = os.path.join(repo_path, '{{cookiecutter.repo_name}}')
    assert find_template(repo_path) == expected_template


# Generated at 2022-06-11 20:13:12.273523
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir='cookiecutter-django/tests/test-input/fake-repo/') == \
        'cookiecutter-django/tests/test-input/fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:13:13.146900
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    pass

# Generated at 2022-06-11 20:13:16.053643
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template"""
    assert find_template("/home/oliver/githome/budgify") == "/home/oliver/githome/budgify/{{cookiecutter.repo_name}}"

# Generated at 2022-06-11 20:13:28.765730
# Unit test for function find_template
def test_find_template():
    """Find a template in a local repo."""
    import tempfile
    import shutil

    dir_template = tempfile.mkdtemp()
    try:
        os.mkdir(os.path.join(dir_template, 'cookiecutter-'))
        os.mkdir(os.path.join(dir_template, 'cookiecutter-{{cookiecutter.repo_name}}'))
        os.mkdir(os.path.join(dir_template, 'foo'))

        project_template = find_template(dir_template)
        assert project_template == os.path.abspath(
            os.path.join(dir_template, 'cookiecutter-{{cookiecutter.repo_name}}')
        )
    finally:
        shutil.rmtree(dir_template)

# Generated at 2022-06-11 20:13:34.850485
# Unit test for function find_template
def test_find_template():
    """Test for the find_template function."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from os import path

    repo_dir = cookiecutter('tests/fake-repo-tmpl', no_input=True)

    project_template = path.join(repo_dir, utils.find_template(repo_dir))

    # Ensure that the project_path is what we expect.
    assert project_template == repo_dir + '/fake-project'


# Generated at 2022-06-11 20:13:36.151355
# Unit test for function find_template
def test_find_template():
    print("This is a test of find_template")



# Generated at 2022-06-11 20:13:37.059486
# Unit test for function find_template
def test_find_template():
    """Test find_template function."""

# Generated at 2022-06-11 20:13:42.374838
# Unit test for function find_template
def test_find_template():
    """Test find_template function.

    An error will be raised if the function is unable to find a templated
    directory in a test directory.
    """
    test_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'test-find-template'
    )
    find_template(test_dir)

# Generated at 2022-06-11 20:13:50.616616
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        'test_repo/fake-template'
    ))
    project_template = find_template(repo_dir)
    assert project_template == os.path.abspath(os.path.join(
        os.path.dirname(__file__),
        'test_repo/fake-template/{{cookiecutter.repo_name}}'
    ))



# Generated at 2022-06-11 20:13:51.215728
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:13:54.268155
# Unit test for function find_template
def test_find_template():
    assert find_template(
        'tests/test-input/{{cookiecutter.repo_name}}/'
    ) == 'tests/test-input/{{cookiecutter.repo_name}}/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:14:02.335843
# Unit test for function find_template
def test_find_template():
    """ Check that find_template works """
    from cookiecutter import config
    from cookiecutter.main import cookiecutter
    from cookiecutter.vcs import clone
    from cookiecutter.utils import rmtree

    template = "tests/test-input-template"

    try:
        cookiecutter(template, no_input=True)
        repo_dir = os.path.join(config.DEFAULT_CONFIG['cookiecutters_dir'], 'tests/test-input-template')
        find_template(repo_dir)
    finally:
        rmtree(config.DEFAULT_CONFIG['cookiecutters_dir'])

# Generated at 2022-06-11 20:14:02.843703
# Unit test for function find_template
def test_find_template():
    re

# Generated at 2022-06-11 20:14:12.350394
# Unit test for function find_template
def test_find_template():

    # Setup
    repo_dir = os.path.join(os.path.dirname(__file__), 'files/project_template_example')
    expected_template_dir_name = '{{cookiecutter.project_name}}'
    expected_template_dir = os.path.join(repo_dir, expected_template_dir_name)

    # Run
    template_dir = find_template(repo_dir)

    # Test
    assert(template_dir == expected_template_dir)

# Generated at 2022-06-11 20:14:20.966222
# Unit test for function find_template
def test_find_template():
    # Templates are usually outside of repo_dir, but for testing
    # we're using a local dir
    repo_dir = os.path.normpath(
        os.path.join(
            os.path.abspath(os.path.dirname(__file__)),
            '..', '..', 'tests', 'test-data', ''
        )
    )

    project_template = find_template(repo_dir)

    assert os.path.normpath(os.path.join(repo_dir, '{{', 'cookiecutter', '}}')) == os.path.normpath(project_template)
    assert os.path.exists(project_template)



# Generated at 2022-06-11 20:14:28.108130
# Unit test for function find_template
def test_find_template():
    """Verify find_template function works as expected."""
    from cookiecutter.prompt import read_user_yes_no

    # TODO: Modify to work with mock
    # from unittest import mock
    # from cookiecutter.compat import TemporaryDirectory
    import subprocess
    from tempfile import TemporaryDirectory

    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'

    with TemporaryDirectory(prefix='cookiecutter-') as repo_dir:
        logger.debug('Temporary directory %s', repo_dir)

        # Clone the repo
        subprocess.check_call(
            ['git', 'clone', repo_url, '.'],
            cwd=repo_dir
        )

        # Find the project template

# Generated at 2022-06-11 20:14:32.674158
# Unit test for function find_template
def test_find_template():
    """Unit test for function `find_template`."""
    assert find_template('tests/fake-repo-tmpl') == 'tests/fake-repo-tmpl/{{cookiecutter.repo_name}}'
    find_template('tests/fake-repo-pre/fake-pre-gen')

# Generated at 2022-06-11 20:14:38.344846
# Unit test for function find_template
def test_find_template():
    """Tests if the list containing the path to the cookiecutter project template is returned."""

    template_path = find_template('tests/fake-repo-pre/')
    expected_path = []
    expected_path.append('tests/fake-repo-pre/project_name{{cookiecutter.project_name}}')
    assert (template_path == expected_path)


# Generated at 2022-06-11 20:14:43.265708
# Unit test for function find_template
def test_find_template():
    """
    Test scenario when there are two or more directories in the project root.
    """

    assert find_template('tests/test-output/cdr-hooks-2').endswith(
        'cdr-hooks-2/cookiecutter-cdr-hooks')


# Generated at 2022-06-11 20:14:53.532131
# Unit test for function find_template
def test_find_template():
    """Test find_template template."""
    # Non-existent directory
    if os.path.exists('/tmp/fake_dir'):
        import shutil
        shutil.rmtree('/tmp/fake_dir')
    assert find_template('/tmp/fake_dir') is None

    # Directory with no cookiecutter.json
    os.mkdir('/tmp/fake_dir')
    with open('/tmp/fake_dir/test.txt', 'w') as f:
        f.write('test')
    assert find_template('/tmp/fake_dir') is None

    # Directory with a cookiecutter.json
    with open('/tmp/fake_dir/cookiecutter.json', 'w') as f:
        f.write('{}')

# Generated at 2022-06-11 20:14:56.784145
# Unit test for function find_template
def test_find_template():
    """Verify find_template works properly"""

    test_dir = 'tests/files/fake-repo'
    assert 'tests/files/fake-repo/{{cookiecutter.project_name}}' == find_template(test_dir)

# Generated at 2022-06-11 20:15:00.943785
# Unit test for function find_template
def test_find_template():
    """Verify find_template() returns the name of the template directory."""
    assert find_template(
        '/home/audreyr/cookiecutter-pypackage'
    ) == '/home/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'



# Generated at 2022-06-11 20:15:08.381255
# Unit test for function find_template
def test_find_template():
    """Test for function find_template"""
    import pytest
    from cookiecutter import utils
    
    with pytest.raises(NonTemplatedInputDirException):
        utils.find_template('fakepath')
    
    with pytest.raises(NonTemplatedInputDirException):
        utils.find_template('cookiecutter/tests/test-fake-repo-pre/')
    
    project_template = utils.find_template('cookiecutter/tests/test-fake-repo/')
    
    assert project_template == 'cookiecutter/tests/test-fake-repo/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:15.666844
# Unit test for function find_template
def test_find_template():
    from cookiecutter.tests.test_finders import TEMPLATE_DIR

    result = find_template(TEMPLATE_DIR)
    expected = '{{cookiecutter.repo_name}}'
    assert expected in result

# Generated at 2022-06-11 20:15:20.120240
# Unit test for function find_template
def test_find_template():
    template = find_template('../tests/test-repo-pre/')
    assert template == '../tests/test-repo-pre/{{cookiecutter.repo_name}}'
    template = find_template('../tests/test-repo-post/')
    assert template == '../tests/test-repo-post/foo-bar'

# Generated at 2022-06-11 20:15:25.654417
# Unit test for function find_template
def test_find_template():
    """
    '''Check that find_template can find the project template.'''

    repo_dir = os.path.join(
        os.path.dirname(__file__), '..', 'tests', 'fake-repo', 'input'
    )

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    """

# Generated at 2022-06-11 20:15:31.961975
# Unit test for function find_template
def test_find_template():
    """Verify the find_template function is working.
    """
    from cookiecutter import utils
    import os
    import shutil
    import tempfile
    simple_dir = tempfile.mkdtemp()
    simple_dir_files = ['simple_one.txt', 'simple_two.txt', 'simple_three.txt']
    for simple_dir_file in simple_dir_files:
        utils.make_empty_file(os.path.join(simple_dir, simple_dir_file))
    test_repo_dir = tempfile.mkdtemp()
    simple_dir_name = os.path.basename(simple_dir)
    shutil.move(simple_dir, os.path.join(test_repo_dir, simple_dir_name))

# Generated at 2022-06-11 20:15:36.079574
# Unit test for function find_template
def test_find_template():
    assert (
        find_template('tests/test-input/cookiecutter-pypackage') ==
        'tests/test-input/cookiecutter-pypackage/{{cookiecutter.project_name}}'
    )

# Generated at 2022-06-11 20:15:39.433708
# Unit test for function find_template
def test_find_template():
    result = find_template('/Users/vladi/temp/example-repo-2')

# Generated at 2022-06-11 20:15:41.774963
# Unit test for function find_template
def test_find_template():
    assert find_template('/Users/audreyr/cookiecutter-pypackage') == \
        '/Users/audreyr/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:47.028124
# Unit test for function find_template
def test_find_template():
    repo_dir = '/home/vanessa/GitHub/cookiecutter-pypackage'
    project_template = find_template(repo_dir)
    assert isinstance(project_template, str)
    assert project_template == '/home/vanessa/GitHub/cookiecutter-pypackage/{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:15:47.547415
# Unit test for function find_template
def test_find_template():

    pass

# Generated at 2022-06-11 20:15:56.695207
# Unit test for function find_template
def test_find_template():

    # Create a "fake" repo_dir
    repo_dir = os.path.join('/tmp', 'find-template-test')
    os.makedirs(repo_dir)

    # Add a valid template to the directory
    template_name = '{{ cookiecutter.project_slug }}'
    template_path = os.path.join(repo_dir, template_name)
    os.makedirs(template_path)

    # Check that we find the right path
    test_project_template = find_template(repo_dir)
    assert test_project_template == template_path

    # Remove the directory we made
    import shutil
    shutil.rmtree(repo_dir)

# Generated at 2022-06-11 20:16:08.468100
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'fake-repo',
    )

    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:16:09.032025
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:16:13.425677
# Unit test for function find_template
def test_find_template():
    assert (find_template('https://github.com/audreyr/cookiecutter-pypackage.git')) == (find_template('https://github.com/audreyr/cookiecutter-pypackage.git'))

# Generated at 2022-06-11 20:16:18.273636
# Unit test for function find_template
def test_find_template():

    from cookiecutter import utils

    # Make sure find_template doesn't fail when given an input_dir that
    # doesn't contain a templated directory, i.e. a non-templated input_dir
    repo_dir = 'tests/test-find-no-template'

    # Raise for git clone repos without a templated directory

    # Raise for local repos without a templated directory



# Generated at 2022-06-11 20:16:24.937642
# Unit test for function find_template
def test_find_template():
    # Set up
    from cookiecutter import utils
    from cookiecutter.compat import TemporaryDirectory
    from shutil import copyfile

    template_dir = TemporaryDirectory()
    copyfile(
        os.path.join(utils.TESTS_DIR, 'fake-repo', '{{cookiecutter.project_name}}', 'README.rst'),
        os.path.join(template_dir.name, '{{cookiecutter.project_name}}', 'README.rst')
    )
    copyfile(
        os.path.join(utils.TESTS_DIR, 'fake-repo', 'LICENSE'),
        os.path.join(template_dir.name, 'LICENSE')
    )

# Generated at 2022-06-11 20:16:27.303378
# Unit test for function find_template
def test_find_template():
    """Check that find_template() works as expected"""
    find_template('/Users/audreyr/code/cookiecutter-pypackage')

# Generated at 2022-06-11 20:16:34.456277
# Unit test for function find_template
def test_find_template():
    """Run the test against a local copy of cookiecutter-pypackage."""
    repo_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:16:35.060114
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:16:40.811223
# Unit test for function find_template
def test_find_template():
    """Test that find_template correctly identifies the Cookiecutter template
    in the repo dir.
    """
    repo_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-tmpl')
    project_template = find_template(repo_dir)

    assert project_template == os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:16:46.227143
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test-find-template',
        '{{cookiecutter.repo_name}}'
    )
    project_template = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')

    assert find_template(repo_dir) == project_template

# Generated at 2022-06-11 20:16:59.066352
# Unit test for function find_template
def test_find_template():
    pass

# Generated at 2022-06-11 20:17:07.904309
# Unit test for function find_template
def test_find_template():
    """ """
    repo_dir_contents = ['foocookiecutter_{{cookiecutter.repo_name}}',
                         'barcookiecutter_{{cookiecutter.repo_name}}',
                         'foocookiecutter_foo_bar']
    with TemporaryDirectory() as repo_dir:
        for item in repo_dir_contents:
            open(os.path.join(repo_dir, item), 'w').close()

        template_dir = find_template(repo_dir)
        assert template_dir.endswith('foocookiecutter_{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:17:12.179769
# Unit test for function find_template
def test_find_template():
    """Verify that find_template function finds the correct template."""
    repo_dir = os.path.join(
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.project_slug}}'
    )
    assert find_template(repo_dir=repo_dir) == os.path.join(
        'tests',
        'test-repo-pre',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.project_slug}}',
        '{{cookiecutter.repo_name}}',
        '{{cookiecutter.project_slug}}'
    )

# Generated at 2022-06-11 20:17:21.898688
# Unit test for function find_template
def test_find_template():
    #Create a repo_dir, put some files in it, and make sure find_template picks the right one.
    #This tests the 'cookiecutter' in name, '{{' in name, '}}' in name rule.
    import shutil
    import tempfile
    import randomstring
    repo_dir = tempfile.mkdtemp()
    template_name = randomstring.RandomString().get_random_string()
    non_template1 = randomstring.RandomString().get_random_string()
    non_template2 = randomstring.RandomString().get_random_string()
    open(os.path.join(repo_dir, template_name),'a').close()
    open(os.path.join(repo_dir, non_template1),'a').close()

# Generated at 2022-06-11 20:17:25.727670
# Unit test for function find_template
def test_find_template():
    assert find_template(repo_dir=os.path.dirname(os.path.abspath('.'))) \
        == os.path.join(os.path.dirname(os.path.abspath('.')), '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:17:27.735849
# Unit test for function find_template
def test_find_template():
    find_template(r'E:\Python_Code\cookiecutter\cookiecutter-pypackage')



# Generated at 2022-06-11 20:17:34.472355
# Unit test for function find_template
def test_find_template():
    assert os.path.normpath(find_template('tests/fake-repo-pre/')) == os.path.normpath('tests/fake-repo-pre/fake_project_name')
    assert os.path.normpath(find_template('tests/fake-repo-post/')) == os.path.normpath('tests/fake-repo-post/fake_project_name')

# Generated at 2022-06-11 20:17:39.769937
# Unit test for function find_template
def test_find_template():
    cookiecutter_json = 'cookiecutter-pypackage'
    cookiecutter_handlebars = 'cookiecutter-{{cookiecutter.repo_name}}'
    valid_path = '/Users/audreyr/cookiecutter-pypackage/cookiecutter-pypackage'
    assert find_template('/Users/audreyr/cookiecutter-pypackage') == valid_path

# Generated at 2022-06-11 20:17:42.687452
# Unit test for function find_template
def test_find_template():
    repo_dir = '' # add local location of test data
    project_template = find_template(repo_dir)
    assert os.path.basename(project_template) == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:17:43.557368
# Unit test for function find_template
def test_find_template():
    pass

test_find_template()

# Generated at 2022-06-11 20:18:10.237848
# Unit test for function find_template
def test_find_template():
    assert find_template('/home/user/foo')

# Generated at 2022-06-11 20:18:14.020737
# Unit test for function find_template
def test_find_template():
    repo_dir = os.path.join('tests', 'fake-repo')
    test_template = find_template(repo_dir)
    assert test_template == os.path.join(repo_dir, 'fake-cookiecutter-project')

# Generated at 2022-06-11 20:18:24.660180
# Unit test for function find_template
def test_find_template():
    import tempfile
    print()
    test_dir = tempfile.mkdtemp()
    test_dir_contents = ['cookiecutter', 'cookiecutter-django', '{{cookiecutter.project_name}}']
    for item in test_dir_contents:
        os.makedirs(os.path.join(test_dir, item))

    project_template = find_template(test_dir)
    assert 'cookiecutter.project_name' in project_template
    assert os.path.isdir(project_template)
    os.rmdir(project_template)
    os.rmdir(os.path.join(test_dir, 'cookiecutter'))
    os.rmdir(os.path.join(test_dir, 'cookiecutter-django'))
    os.rmd

# Generated at 2022-06-11 20:18:28.498419
# Unit test for function find_template
def test_find_template():
    repo_dir = 'C:\\Users\\User\\Desktop\\cookiecutter-django'
    project_template = find_template(repo_dir)
    assert project_template == 'C:\\Users\\User\\Desktop\\cookiecutter-django\\cookiecutter-django'

# Generated at 2022-06-11 20:18:33.210307
# Unit test for function find_template
def test_find_template():
    """
    Tests that the find_template function returns the correct template.

    """
    template1 = "input_template"
    template2 = "{{cookiecutter.project_name}}"
    templates = [template1, template2]
    working_dir = os.getcwd()
    res = find_template(working_dir)
    assert res == templates[1]

# Generated at 2022-06-11 20:18:34.765142
# Unit test for function find_template
def test_find_template():
    """ Unit test for function find_template """
    # TODO
    assert True



# Generated at 2022-06-11 20:18:40.138550
# Unit test for function find_template
def test_find_template():
    """Unit testing for def find_template."""
    from cookiecutter.utils import rmtree
    from cookiecutter.main import cookiecutter

    TMPDIR = cookiecutter('tests/fake-repo-tmpl/')

    project_template_dir = find_template(TMPDIR)
    assert project_template_dir == os.path.join(
        TMPDIR, '{{cookiecutter.repo_name}}'
    )

    rmtree(TMPDIR)

# Generated at 2022-06-11 20:18:45.921336
# Unit test for function find_template
def test_find_template():
    """Test that find_template returns the path to the project template."""
    repo_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), 'fake-repo'
    )

    actual = find_template(repo_dir)
    expected = os.path.join(repo_dir, '{{cookiecutter.repo_name}}')
    assert actual == expected

# Generated at 2022-06-11 20:18:51.671233
# Unit test for function find_template
def test_find_template():
    """Check that find_template works as expected"""

    test_repo_dir = os.path.join(os.path.dirname(__file__), 'test-find-template')

    result = find_template(test_repo_dir)

    # Make sure the results match what is expected
    expected = os.path.join(test_repo_dir, '{{ cookiecutter.project_slug }}')
    assert result == expected

# Generated at 2022-06-11 20:19:03.217242
# Unit test for function find_template
def test_find_template():
    """Verify Cookiecutter can find the template in the repo."""
    from cookiecutter import main
    from cookiecutter import repo

    # Get path to the fake Cookiecutter template
    tests_dir = os.path.abspath(os.path.dirname(__file__))
    fake_repo_dir = os.path.join(tests_dir, 'fake-repo-pre-gen')

    # Ensure the fake repo doesn't exist
    repo.clean(fake_repo_dir)
    assert not os.path.isdir(fake_repo_dir)

    # Clone the fake repo
    repo.clone(
        repo_dir=fake_repo_dir,
        output_dir=tests_dir,
    )

    # Run the finding template function on the fake repo
    project_template = find_template

# Generated at 2022-06-11 20:20:11.815940
# Unit test for function find_template
def test_find_template():
    import tempfile
    repo_dir = tempfile.mkdtemp()

    os.mkdir(os.path.join(repo_dir, '{cookiecutter.repo_name}'))

    assert find_template(repo_dir) == os.path.join(
        repo_dir, '{cookiecutter.repo_name}'
    )


# Generated at 2022-06-11 20:20:14.888434
# Unit test for function find_template
def test_find_template():
    """Verify the right Cookiecutter template is found"""
    assert find_template('tests/test-find-template') == os.path.join('tests/test-find-template', 'cookiecutter-{{cookiecutter.project_slug}}')

# Generated at 2022-06-11 20:20:22.881982
# Unit test for function find_template
def test_find_template():
    fake_project_template = 'fake_project_template'

    # Need to change the working directory to a temporary one,
    # because by design `find_template` only looks in the current
    # directory.
    original_working_dir = os.getcwd()
    fake_working_dir = os.path.join(original_working_dir, 'fake_working_dir')
    os.makedirs(fake_working_dir)

    # Need to change the current module's path, because by design
    # `find_template` only looks at modules in the current path.
    original_module_path = os.path.abspath(__file__)
    fake_module_path = os.path.join(fake_working_dir, 'test_find_template.py')

# Generated at 2022-06-11 20:20:25.339062
# Unit test for function find_template
def test_find_template():
    expected = 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    assert find_template('tests/fake-repo-pre') == expected


# Generated at 2022-06-11 20:20:31.636373
# Unit test for function find_template
def test_find_template():
    """Test function 'find_template'."""

    repo_dir = os.path.abspath(os.path.dirname(__file__))
    repo_dir_contents = os.listdir(repo_dir)
    project_template = None
    for item in repo_dir_contents:
        if 'cookiecutter' in item and '{{' in item and '}}' in item:
            project_template = item
            break
    assert find_template(repo_dir) is not None
    assert not os.path.isdir(find_template(repo_dir))

# Generated at 2022-06-11 20:20:34.426153
# Unit test for function find_template
def test_find_template():
    try:
        find_template('~/Owlready')
    except NonTemplatedInputDirException:
        pass

# Generated at 2022-06-11 20:20:40.690207
# Unit test for function find_template
def test_find_template():
    """Unit test for function find_template."""
    from tests.test_main import TEST_USER_CONFIG_DIR
    from tests.test_main import TEST_TEMPLATE_DIR
    from tests.test_main import TEST_OUTPUT_DIR

    repo_dir_parent = os.path.join(TEST_USER_CONFIG_DIR, 'tests/test-repo')
    repo_dir = os.path.join(repo_dir_parent, 'fake-repo-tmpl')
    find_template(repo_dir)

# Generated at 2022-06-11 20:20:51.970638
# Unit test for function find_template
def test_find_template():
    logger.info('Testing the find_template function')
    repo_dir = os.path.join(os.path.dirname(__file__), 'fake-repo')
    project_template = os.path.join(repo_dir, 'cookiecutter-pypackage{{cookiecutter.opencomponent_name}}')
    actual_project_template = find_template(repo_dir)

    if actual_project_template != project_template:
        logger.error('The project template should be %s', project_template)
        logger.error('The project template is actually %s', actual_project_template)
        raise Exception
    else:
        logger.debug('Everything went fine')


# Generated at 2022-06-11 20:20:56.474381
# Unit test for function find_template
def test_find_template():
    import pytest
    with pytest.raises(NonTemplatedInputDirException):
        find_template('/no/such/dir')
    assert 'repo-template' in find_template(
        os.path.join(os.getcwd(), 'tests', 'test-repo')
    )

# Generated at 2022-06-11 20:20:59.365786
# Unit test for function find_template
def test_find_template():
    """Verify `find_template` returns correct file path."""
    pass