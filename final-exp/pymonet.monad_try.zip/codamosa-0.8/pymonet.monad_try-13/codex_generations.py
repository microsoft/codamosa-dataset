

# Generated at 2022-06-12 05:23:53.673463
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x > 1) == Try(1, False)



# Generated at 2022-06-12 05:23:57.215935
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda e: e) == Try(True, True)
    assert Try(False, True).filter(lambda e: e) == Try(False, False)



# Generated at 2022-06-12 05:24:02.035234
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter.
    """
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-12 05:24:09.260047
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(a):
        return a < 10

    def filterer_false(a):
        return a > 10

    a = Try(5, True)
    try_filter = a.filter(filterer)
    try_filter_false = a.filter(filterer_false)
    assert try_filter == Try(5, True)
    assert try_filter_false == Try(5, False)



# Generated at 2022-06-12 05:24:16.763456
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    """
    This function test behavior of filter method.
    """
    def filterer(value):
        return value % 2 == 0

    assert Try(2, True).filter(filterer).get() == 2
    assert not Try(3, True).filter(filterer).is_success
    assert Try(Exception('error'), False).filter(filterer).get() == Exception('error')


# Generated at 2022-06-12 05:24:24.024859
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> _ = test_Try_filter()
    
    """
    actual = Try.of(lambda x: x, 1).filter(lambda x: x < 2)
    expected = Try(1, True)
    assert actual == expected

    actual = Try.of(lambda x: x, 1).filter(lambda x: x < 1)
    expected = Try(1, False)
    assert actual == expected

    actual = Try.of(lambda x: x, 1 / 0).filter(lambda x: x < 2)
    expected = Try(ZeroDivisionError('division by zero'), False)
    assert actual == expected

# Generated at 2022-06-12 05:24:28.299764
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x != 1) == Try(1, False)



# Generated at 2022-06-12 05:24:34.547055
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(1, True).filter(lambda v: v > 0) == Try(1, True)
    assert Try(1, True).filter(lambda v: v < 0) == Try(1, False)
    assert Try(None, False).filter(lambda v: v < 0) == Try(None, False)



# Generated at 2022-06-12 05:24:39.001431
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1)\
        .filter(lambda x: x == 1)\
        .get_or_else(0) == 1

    assert Try.of(lambda: 1)\
        .filter(lambda x: x == 2)\
        .get_or_else(0) == 0

    assert Try.of(lambda: 1/0)\
        .filter(lambda x: x == 2)\
        .get_or_else(0) == 0


# Generated at 2022-06-12 05:24:45.631941
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(1, False).filter(lambda x: True) == Try(1, False)
    assert Try(1, False).filter(lambda x: False) == Try(1, False)


# Generated at 2022-06-12 05:24:55.562190
# Unit test for method filter of class Try
def test_Try_filter():
    assert_that(Try(2, True).filter(lambda v: v > 1), equal_to(Try(2, True)))
    assert_that(Try(2, True).filter(lambda v: v < 1), equal_to(Try(2, False)))
    assert_that(Try(2, False).filter(lambda v: v < 1), equal_to(Try(2, False)))
    print('passed')


# Generated at 2022-06-12 05:25:01.530326
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_even(number):
        return number % 2 == 0

    def is_odd(number):
        return not is_even(number)

    assert Try.of(lambda: 5).filter(is_even) == Try(5, False)
    assert Try.of(lambda: 5).filter(is_odd) == Try(5, True)



# Generated at 2022-06-12 05:25:06.203602
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value >= 10

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(20, True).filter(filterer) == Try(20, True)



# Generated at 2022-06-12 05:25:10.363323
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(4, True).filter(filterer) == Try(4, True)
    assert Try(-3, True).filter(filterer) == Try(-3, False)
    assert Try(Exception('error'), False).filter(filterer) == Try(Exception('error'), False)


# Generated at 2022-06-12 05:25:14.902289
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(val):
        return val
    
    assert(Try.of(lambda: 'some', None).filter(filterer).get_or_else(None) == 'some')
    assert(Try.of(lambda: 1, None).filter(filterer).get_or_else(None) == 1)
    assert(Try.of(lambda: 1, None).filter(lambda x: False).get_or_else(None) == None)



# Generated at 2022-06-12 05:25:19.910527
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'test').filter(lambda x: x == 'test') == Try(value='test', is_success=True)
    assert Try.of(lambda: 'test').filter(lambda x: x == 'wrong') == Try(value='test', is_success=False)


# Generated at 2022-06-12 05:25:23.007593
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return True

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, False).filter(filterer) == Try(1, False)



# Generated at 2022-06-12 05:25:26.712557
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 1

    fn = lambda: 1
    success_try = Try.of(fn)
    fail_try = Try.of(fn)
    assert success_try.filter(filterer).get() == 1
    assert fail_try.filter(filterer).is_success is False



# Generated at 2022-06-12 05:25:30.197386
# Unit test for method filter of class Try
def test_Try_filter():
    assert      Try.of(lambda: 10).filter(lambda x: x==10) == Try(10, True)
    assert not (Try.of(lambda: 10).filter(lambda x: x==100) == Try(100, False))
    assert      Try.of(lambda: 10).filter(lambda x: x==100) == Try(10, False)

# Generated at 2022-06-12 05:25:34.154022
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda x: 1, 1)\
        .map(lambda x: x + 1)\
        .filter(lambda x: x == 2)\
        .filter(lambda x: x == 3)\
        .get()

    assert result is None



# Generated at 2022-06-12 05:25:39.629844
# Unit test for method filter of class Try
def test_Try_filter():
    try_thing = Try(true, True)
    assert filter(True)(try_thing) == Try(true, True)
    assert filter(False)(try_thing) == Try(true, False)
    try_thing = Try(true, False)
    assert filter(True)(try_thing) == Try(true, False)
    assert filter(False)(try_thing) == Try(true, False)


# Generated at 2022-06-12 05:25:50.967339
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: x) == Try(True, True)
    assert Try(True, True).filter(lambda x: not x) == Try(True, False)
    assert Try(True, False).filter(lambda x: x) == Try(True, False)
    assert Try(True, False).filter(lambda x: not x) == Try(True, False)

    assert Try(False, True).filter(lambda x: x) == Try(False, False)
    assert Try(False, True).filter(lambda x: not x) == Try(False, True)
    assert Try(False, False).filter(lambda x: x) == Try(False, False)
    assert Try(False, False).filter(lambda x: not x) == Try(False, False)

    assert Try(Exception('error'), True).filter

# Generated at 2022-06-12 05:25:57.551322
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filter_positive():
        try_success = Try.of(lambda: int(1))

        assert try_success.filter(lambda x: x % 2 == 0) == Try(1, False)

    def test_filter_negative():
        try_success = Try.of(lambda: int(2))

        assert try_success.filter(lambda x: x % 2 == 0) == try_success

    def test_filter_without_success():
        try_fail = Try.of(lambda: int('x'))

        assert try_fail.filter(lambda x: x % 2 == 0) == try_fail

    test_filter_positive()
    test_filter_negative()
    test_filter_without_success()



# Generated at 2022-06-12 05:26:04.737115
# Unit test for method filter of class Try
def test_Try_filter():
    d = {1: "one", 2: "two", 3: "three"}
    def is_key_even(d):
        return list(d.keys())[0] % 2 == 0
    assert Try(d, True).filter(is_key_even).is_success == True
    assert Try(d, True).filter(is_key_even).get() == d
    assert Try(d, True).filter(lambda d: False).is_success != True
    assert Try(d, True).filter(lambda d: False).get() == d


# Generated at 2022-06-12 05:26:10.297019
# Unit test for method filter of class Try
def test_Try_filter():
    def do_func(a):
        return Try(a, True)

    def do_func_error(e):
        return Try(e, False)

    def def_func(a):
        try:
            return do_func(1 / a)
        except ZeroDivisionError as e:
            return do_func_error(e)

    def pred(a):
        return a == 5

    assert Try.of(def_func, 0).filter(pred) == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(def_func, 10).filter(pred) != Try(0.1, True)
    assert Try.of(def_func, 2).filter(pred).get_or_else(None) is None

# Generated at 2022-06-12 05:26:20.114958
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return True

    def filterer_false(value):
        return False

    successful = Try.of(lambda: 1, None)
    rejected = Try.of(lambda: 1/0, None)

    assert successful.filter(filterer) == Try(1, True), 'successful Try must be filtered and returned successfully.'
    assert successful.filter(filterer_false) == Try(1, False), 'successful Try must be filtered, returned not successfully.'
    assert rejected.filter(filterer) == Try(ZeroDivisionError(), False), 'rejected Try must be filtered, returned not successfully.'
    assert rejected.filter(filterer_false) == Try(ZeroDivisionError(), False), 'rejected Try must be filtered, returned not successfully.'


# Generated at 2022-06-12 05:26:28.983036
# Unit test for method filter of class Try
def test_Try_filter():

    def is_even(element):
        return element % 2 == 0

    # Successfully Try
    assert Try.of(int, "10").filter(is_even) == Try(10, True)
    # Not successfully Try
    assert Try.of(int, "xxx").filter(is_even) == Try("xxx", False)
    # Successfully Try
    assert Try.of(int, "10").filter(is_even).filter(is_even) == Try(10, True)
    # Not successfully Try
    assert Try.of(int, "11").filter(is_even) == Try("11", False)

if __name__ == "__main__":
    test_Try_filter()

# Generated at 2022-06-12 05:26:38.985343
# Unit test for method filter of class Try
def test_Try_filter():
    class MyException(Exception):
        pass

    def fn_raises_exception():
        raise MyException("test message")

    def fn_returns_int():
        return 1

    def filter_success_int_filterer(value):
        return value > 0

    def filter_fails_int_filterer(value):
        return value < 0

    assert Try.of(fn_raises_exception).filter(filter_success_int_filterer) == \
        Try(MyException("test message"), False)

    assert Try.of(fn_returns_int).filter(filter_success_int_filterer) == \
        Try(1, True)


# Generated at 2022-06-12 05:26:49.463062
# Unit test for method filter of class Try
def test_Try_filter():
    class IntWrapper:
        def __init__(self, value):
            self.value = value

        def filter(self, filterer):
            return Try(self.value, filterer(self.value))

        def __eq__(self, other):
            return isinstance(other, type(self)) and other.value == self.value

        def __str__(self):
            return 'IntWrapper[value={}]'.format(self.value)

    assert IntWrapper(1).filter(lambda x: x < 3) == IntWrapper(1)
    assert IntWrapper(2).filter(lambda x: x < 3) == IntWrapper(2)
    assert IntWrapper(3).filter(lambda x: x < 3) == Try(3, False)

# Generated at 2022-06-12 05:26:53.768006
# Unit test for method filter of class Try
def test_Try_filter():
    # when
    try_value = Try.of(lambda: 10 / 0, None)

    # and
    filter_result = try_value.filter(lambda x: x == 0)

    # expect
    assert filter_result == Try(ZeroDivisionError(), False)



# Generated at 2022-06-12 05:27:07.402261
# Unit test for method filter of class Try
def test_Try_filter():
    def positive_check(a):
        return a > 0

    t = Try(1, True)
    assert t.filter(positive_check) == Try(1, True)

    t = Try(0, True)
    assert t.filter(positive_check) == Try(0, False)

    t = Try(1, False)
    assert t.filter(positive_check) == Try(1, False)



# Generated at 2022-06-12 05:27:10.867737
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x > 1) == Try(2, True)
    assert Try(1, True).filter(lambda x: x > 1) == Try(1, False)


# Generated at 2022-06-12 05:27:18.876598
# Unit test for method filter of class Try
def test_Try_filter():
    from pytest import raises
    from typing import Callable
    from typing import Type
    from typing import Union
    from collections import Iterable
    from collections import Sequence

    empty_list = []
    short_list = ['A', 'B', 'C']
    long_list = ['A', 'B', 'C', 'D', 'E']

    # ---------
    # `filter`
    # ---------

    def _filter(min_count: int) -> Callable[[Iterable], bool]:
        return lambda xs: len(xs) >= min_count

    assert True == Try.of(_filter(3), short_list).filter(None).is_success
    assert False == Try.of(_filter(3), empty_list).filter(None).is_success


# Generated at 2022-06-12 05:27:25.460980
# Unit test for method filter of class Try
def test_Try_filter():
    def get_and_filter(first_value, second_value):
        return first_value + second_value
    assert Try.of(get_and_filter, 1, 2).filter(lambda i: i > 2).get_or_else(0) == 3
    assert Try.of(get_and_filter, 1, 2).filter(lambda i: i > 10).get_or_else(0) == 0


# Generated at 2022-06-12 05:27:28.908453
# Unit test for method filter of class Try
def test_Try_filter():
    try_ = Try.of(lambda: 5)
    assert try_.filter(lambda x: x > 2) == Try(5, True)
    assert try_.filter(lambda x: x > 8) == Try(5, False)

# Generated at 2022-06-12 05:27:38.512408
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_positive(number):
        return number > 0

    assert Try.of(lambda: "1").filter(is_positive) == Try("1", True)
    assert Try.of(lambda: "-1").filter(is_positive) == Try("-1", False)
    assert Try.of(lambda: 1).filter(is_positive) == Try(1, True)
    assert Try.of(lambda: -1).filter(is_positive) == Try(-1, False)
    assert Try.of(lambda: None).filter(is_positive) == Try(None, False)
    assert Try.of(lambda: None).filter(lambda x: False) == Try(None, False)
    assert Try.of(lambda: 1).filter(lambda x: False) == Try(1, False)



# Generated at 2022-06-12 05:27:42.275733
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: "success").filter(lambda s: s == "success") == Try("success", True)
    assert Try.of(lambda: "fail").filter(lambda s: s == "success") == Try("fail", False)


# Generated at 2022-06-12 05:27:46.831456
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)



# Generated at 2022-06-12 05:27:54.411535
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    value = 1
    try_1 = Try(value, True)
    try_2 = Try(value, False)
    filterer = lambda v: v == 1

    # WHEN
    try_1_result = try_1.filter(filterer)
    try_2_result = try_2.filter(filterer)

    # THEN
    assert try_1_result == Try(value, True)
    assert try_2_result == Try(value, False)

# Generated at 2022-06-12 05:27:59.178148
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    fn = lambda x: x >= 2 and x < 7

    assert Try.of(lambda: 4).filter(fn) == Try(4, True)
    assert Try.of(lambda: 8).filter(fn) == Try(8, False)



# Generated at 2022-06-12 05:28:21.627768
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, ()).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1, ()).filter(lambda x: x != 1) == Try(1, False)
    assert Try.of(lambda: 1, ()).filter(lambda x: x == 2) == Try(1, False)

    assert Try.of(lambda: None, ()).filter(lambda x: x == None) == Try(None, True)
    assert Try.of(lambda: None, ()).filter(lambda x: x != None) == Try(None, False)
    assert Try.of(lambda: None, ()).filter(lambda x: x == 1) == Try(None, False)

# Generated at 2022-06-12 05:28:25.838744
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value % 2 == 0
    assert Try(24, True).filter(filterer) == Try(24, True)
    assert Try(3, True).filter(filterer) == Try(3, False)

# Generated at 2022-06-12 05:28:32.357237
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v > 0) == Try(1, True)
    assert Try(1, True).filter(lambda v: v < 0) == Try(-1, False)
    assert Try(-1, False).filter(lambda v: v > 0) == Try(-1, False)
    assert Try(-1, False).filter(lambda v: v < 0) == Try(-1, False)

# Generated at 2022-06-12 05:28:43.528134
# Unit test for method filter of class Try
def test_Try_filter():
    """
    When filterer returns True method returns copy of monad, othercase
    not successfully Try with previous value.
    """
    print('---------------------')
    print('Unit test for method filter of class Try')
    try_success = Try(10, True)
    try_fail = Try(10, False)

    def is_even(value):
        if value % 2:
            return False
        return True

    try_success_after_filter = try_success.filter(is_even)
    try_fail_after_filter = try_fail.filter(is_even)

    print('Test 1:')
    print(try_success_after_filter == Try(10, True))

    print('Test 2:')
    print(try_fail_after_filter == Try(10, False))
    print('---------------------')



# Generated at 2022-06-12 05:28:53.710442
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1') == Try(1, True)
    assert Try.of(int, '1') == Try(1, True)
    assert Try.of(int, 's') == Try(ValueError, False)
    assert Try.of(int, 's').filter(lambda x: x > 0) == Try(ValueError, False)
    assert Try.of(int, 's').filter(lambda x: x < 0) == Try(ValueError, False)
    assert Try.of(int, '1').filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(int, '1').filter(lambda x: x < 0) == Try(1, False)

# Generated at 2022-06-12 05:28:58.862552
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, True).filter(lambda _: True) == Try(None, True)
    assert Try(None, True).filter(lambda _: False) == Try(None, False)
    assert Try(None, False).filter(lambda _: True) == Try(None, False)
    assert Try(None, False).filter(lambda _: False) == Try(None, False)


# Generated at 2022-06-12 05:29:09.651523
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try("Hello world!", True).filter(lambda x: len(x) > 0) == Try("Hello world!", True)
    assert Try("Hello world!", True).filter(lambda x: len(x) < 0) == Try("Hello world!", False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)
    assert Try("Hello world!", False).filter(lambda x: len(x) > 0) == Try("Hello world!", False)

# Generated at 2022-06-12 05:29:17.224583
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for filter method.
    """
    assert Try.of(lambda: 2).filter(lambda x: x > 1) == Try(2, True)
    assert Try.of(lambda: 2).filter(lambda x: x < 1) == Try(2, False)

    assert Try.of(lambda: 2 / 0, 0).filter(lambda x: x > 1) == Try(2, False)
    assert Try.of(lambda: 2 / 0, 0).filter(lambda x: x < 1) == Try(2, False)


# Generated at 2022-06-12 05:29:22.001471
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """
    my_tuple = (1, 4)
    try_tuple = Try.of(lambda: my_tuple[1])
    assert try_tuple.filter(lambda value: value > 2) == Try(4, True)

# Generated at 2022-06-12 05:29:30.864350
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x:x, 1).filter(lambda x: x > 1) == Try(1, False)
    assert Try.of(lambda x:x, 1).filter(lambda x: x < 1) == Try(1, False)
    assert Try.of(lambda x:x, 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda x: 1 / 0, 1).filter(lambda x: False) == Try(ZeroDivisionError("integer division or modulo by zero"), False)



# Generated at 2022-06-12 05:29:58.352417
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'a'
    assert Try('a', True).filter(filterer) == Try('a', True)
    assert Try('b', True).filter(filterer) == Try('b', False)
    assert Try('c', True).filter(filterer) == Try('c', False)
    assert Try(3, False).filter(filterer) == Try(3, False)


# Generated at 2022-06-12 05:30:03.007502
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value % 2 == 0

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, True)



# Generated at 2022-06-12 05:30:06.727816
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x + 10, 15).filter(lambda x: x < 20) == Try(25, True)
    assert Try.of(lambda x: x + 10, 15).filter(lambda x: x > 20) == Try(25, False)

# Generated at 2022-06-12 05:30:11.858838
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, False).filter(lambda x: x == 1).is_success is False
    assert Try(1, True).filter(lambda x: x == 2).is_success is False
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)

# Generated at 2022-06-12 05:30:16.131397
# Unit test for method filter of class Try
def test_Try_filter():
    print("Testing filter method of class Try")
    t1 = Try(3, True).filter(lambda x: x > 1)
    assert t1 == Try(3, True)
    print("OK")
    t2 = Try(3, True).filter(lambda x: x < 2)
    assert t2 == Try(3, False)
    print("OK")



# Generated at 2022-06-12 05:30:20.315380
# Unit test for method filter of class Try
def test_Try_filter():

    def filterer(x):
        return x > 10

    assert Try(10, True).filter(filterer) == Try(10, False)
    assert Try(11, True).filter(filterer) == Try(11, True)

# Generated at 2022-06-12 05:30:25.837665
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: str) -> bool:
        return len(value) > 3

    try_1 = Try("lorem", True)
    try_2 = Try("ipsum", True)
    assert try_1.filter(filterer) == Try("lorem", True)
    assert try_2.filter(filterer) == Try("ipsum", False)



# Generated at 2022-06-12 05:30:32.048375
# Unit test for method filter of class Try
def test_Try_filter():
    """
    This test checks that the filter returns a copy of the
    try when the filterer return True and a not successfully try when
    the filterer return False
    """
    def filterer(x: int) -> bool:
        return x > 0

    try_ = Try.of(lambda : 2)
    assert try_.filter(filterer) == Try(2, True)

    try_ = Try.of(lambda : -2)
    assert try_.filter(filterer) == Try(-2, False)

# Generated at 2022-06-12 05:30:38.605046
# Unit test for method filter of class Try
def test_Try_filter():
    age = Try.of(int, '22')
    assert(
        age
        .filter(lambda value: value > 20)
        .get() == 22
    )
    assert(
        age
        .filter(lambda value: value < 20)
        .get() == 22
    )
    assert(
        age
        .filter(lambda value: value > 20)
        .filter(lambda value: value < 22)
        .is_success == False
    )


# Generated at 2022-06-12 05:30:42.675471
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    f = Try.of(int, '2')
    g = f.filter(lambda x: x > 2)
    h = f.filter(lambda x: x == 2)
    assert f == g
    assert Try(2, True) == h



# Generated at 2022-06-12 05:31:31.667051
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 1).filter(lambda x: x != 1) == Try(1, False)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda x: 1 / 0, 1).filter(lambda x: x == 1) == Try(1, False)

# Generated at 2022-06-12 05:31:42.454871
# Unit test for method filter of class Try
def test_Try_filter():

    def _test_filter_successfully(number):
        def _test_filter_success(number):
            def _test_filter_validate(filtered_try):
                value = filtered_try.get()
                assert value == number
                assert filtered_try.is_success == True
        filtered_try = Try(number, True).filter(lambda x: x > 0)
        _test_filter_validate(filtered_try)

    def _test_filter_not_successfully(number):
        def _test_filter_fail(number):
            def _test_filter_validate(filtered_try):
                value = filtered_try.get()
                assert value == number
                assert filtered_try.is_success == False
        filtered_try = Try(number, False).filter(lambda x: x > 0)
        _test_

# Generated at 2022-06-12 05:31:49.233451
# Unit test for method filter of class Try
def test_Try_filter():
    true_func = lambda arg: arg == 1
    false_func = lambda arg: arg == 2

    assert Try(1, True).filter(true_func) == Try(1, True)
    assert Try(2, True).filter(true_func) == \
        Try(2, False)
    assert Try(3, True).filter(false_func) == \
        Try(3, False)
    assert Try(4, False).filter(false_func) == Try(4, False)



# Generated at 2022-06-12 05:31:55.525186
# Unit test for method filter of class Try
def test_Try_filter():
    # setup
    mock_filterer = MagicMock(return_value=True)

    try_result = Try.of(lambda a, b: a + b, 1, 2)

    # run method
    result = try_result.filter(mock_filterer)

    # assert
    mock_filterer.assert_called_once_with(3)

    assert(result == Try(3, True))



# Generated at 2022-06-12 05:32:03.584475
# Unit test for method filter of class Try
def test_Try_filter():
    def filterFunc(x):
        if x > 10:
            return True
        return False

    tryVal = Try(1, True)

    # when filter(lambda x: True)
    assert tryVal.filter(lambda x: True) == Try(1, True)

    # when filter(lambda x: False)
    assert tryVal.filter(lambda x: False) == Try(1, False)

    # when filter with filterFunc
    assert tryVal.filter(filterFunc) == Try(1, False)
    assert Try(11, True).filter(filterFunc) == Try(11, True)

# Generated at 2022-06-12 05:32:09.644432
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(5, True).filter(filterer) == Try(5, False)
    assert Try(5, False).filter(filterer) == Try(5, False)



# Generated at 2022-06-12 05:32:14.675118
# Unit test for method filter of class Try
def test_Try_filter(): # pragma: no cover
    import math
    try_instance = Try.of(math.sqrt, 25)
    print(try_instance)
    print(try_instance.filter(lambda value: value == 5))
    print(try_instance.filter(lambda value: value == 2))
    print(try_instance)
    try_instance = Try.of(math.sqrt, -25)
    print(try_instance)
    print(try_instance.filter(lambda value: value == 5))
    print(try_instance.filter(lambda value: value == 2))
    print(try_instance)


# Generated at 2022-06-12 05:32:20.119397
# Unit test for method filter of class Try
def test_Try_filter():
    from random import randint

    value = randint(1, 10)

    if value < 5:
        assert Try(value, True).filter(lambda x: x > 5) == Try(value, False)
    else:
        assert Try(value, True).filter(lambda x: x > 5) == Try(value, True)


# Generated at 2022-06-12 05:32:28.458711
# Unit test for method filter of class Try
def test_Try_filter():
    def div_by_two(x):  # pragma: no cover
        return x / 2

    def is_even(x):  # pragma: no cover
        return x % 2 == 0

    assert Try.of(div_by_two, 4).filter(is_even).get() == 2
    assert Try.of(div_by_two, 3).filter(is_even).get_or_else(None) is None

# Generated at 2022-06-12 05:32:34.522878
# Unit test for method filter of class Try
def test_Try_filter():
    def check_even(x):
        return x % 2 == 0

    assert Try.of(100, 100) == Try(100, True)
    assert Try.of(100, 100).filter(check_even) == Try(100, True)
    assert Try.of(100, 101).filter(check_even) == Try(101, False)



# Generated at 2022-06-12 05:33:35.521880
# Unit test for method filter of class Try
def test_Try_filter():
    try_with_none = Try.of(lambda x: x, None)
    assert try_with_none.filter(lambda x: x == None) == Try(None, True)
    assert try_with_none.filter(lambda x: x != None) == Try(None, False)

    try_with_value = Try.of(lambda x: x, 11)
    assert try_with_value.filter(lambda x: x == 11) == Try(11, True)
    assert try_with_value.filter(lambda x: x != 11) == Try(11, False)

    try_with_exception = Try.of(lambda x: x + '2', 1)
    assert try_with_exception.filter(lambda x: True) == Try(try_with_exception.value, False)
    assert try_with_ex

# Generated at 2022-06-12 05:33:45.309463
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 0

    def filterer_raise(value):
        raise ValueError('filterer raise')

    assert Try(0, True).filter(filterer) == Try(0, True)
    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(0, False).filter(filterer) == Try(0, False)
    assert Try(1, False).filter(filterer) == Try(1, False)

    assert Try(0, True).filter(filterer_raise) == Try(0, True)
    assert Try(1, True).filter(filterer_raise) == Try(1, False)
    assert Try(0, False).filter(filterer_raise) == Try(0, False)