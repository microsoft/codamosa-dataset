

# Generated at 2022-06-12 05:23:51.924745
# Unit test for method filter of class Try
def test_Try_filter():
    try_true = Try.of(lambda: True)
    try_1 = Try.of(lambda: 1)
    try_0 = Try.of(lambda: 0)

    assert try_true.filter(lambda value: value) == Try(True, True)
    assert try_true.filter(lambda value: not value) == Try(True, False)
    assert try_false.filter(lambda value: value) == Try(False, False)
    assert try_false.filter(lambda value: not value) == Try(False, False)
    assert try_1.filter(lambda value: value == 1) == Try(1, True)
    assert try_1.filter(lambda value: value == 0) == Try(1, False)
    assert try_0.filter(lambda value: value == 0) == Try(0, False)



# Generated at 2022-06-12 05:24:00.958306
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1').filter(lambda x: x == 1) == Try.of(int, '1')
    assert Try.of(int, '1').filter(lambda x: x == 2) == Try(ValueError('invalid literal for int() with base 10: \'1\''), False)
    assert Try(ValueError('invalid literal for int() with base 10: \'1\''), False).filter(lambda x: x.args[0] == 'invalid literal for int() with base 10: \'1\'') == Try(ValueError('invalid literal for int() with base 10: \'1\''), False)



# Generated at 2022-06-12 05:24:11.211077
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x > 1) == Try(2, True)
    assert Try(1, True).filter(lambda x: x > 1) == Try(1, False)
    assert Try(None, True).filter(lambda x: x is not None) == Try(None, False)
    assert Try(None, True).filter(lambda x: x is None) == Try(None, True)
    assert Try(Exception, False).filter(lambda x: isinstance(x, Exception)) == Try(Exception, False)
    assert Try(Exception, True).filter(lambda x: isinstance(x, Exception)) == Try(Exception, False)

# Generated at 2022-06-12 05:24:17.141449
# Unit test for method filter of class Try
def test_Try_filter():
    f = lambda x: x != 4
    assert Try.of(lambda: 3).filter(f) == Try.of(lambda: 3)
    assert Try.of(lambda: 4).filter(f) == Try(4, False)

    try:
        Try.of(lambda: error).filter(f) == Try(error, False)
    except Exception as ex:
        assert Try(ex, False) == Try(ex, False)


# Generated at 2022-06-12 05:24:22.862486
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from operator import add

    def filterer(x):
        return x % 2 == 0

    assert Try(4, True) \
        .filter(filterer) \
        .get() == 4

    assert Try(4, True) \
        .map(add(1)) \
        .filter(filterer) \
        .get_or_else(1) == 1



# Generated at 2022-06-12 05:24:27.198109
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, True).filter(lambda x: True) == Try(None, True)
    assert Try(None, True).filter(lambda x: False) == Try(None, False)
    assert Try(None, False).filter(lambda x: True) == Try(None, False)
    assert Try(None, False).filter(lambda x: False) == Try(None, False)


# Generated at 2022-06-12 05:24:30.055771
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 5) == Try(1, False)
    assert Try(5, True).filter(lambda x: x > 5) == Try(5, True)


# Generated at 2022-06-12 05:24:36.635530
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    """
    Test method filter of Try class.
    """
    class TestException(BaseException):
        pass

    # return False - not successfully try
    def filterer_1(value):
        return False  # type: ignore

    # return True - successfully try
    def filterer_2(value):
        return True  # type: ignore

    # raise exception - not successfully try
    def filterer_3(value):
        raise TestException()

    # not successfully try
    try_1 = Try(1, True)
    try_2 = try_1.filter(filterer_1)

    # successfully try
    assert isinstance(try_2, Try)
    assert try_2 == Try(1, False)

    # successfully try
    try_3 = Try(1, True)

# Generated at 2022-06-12 05:24:46.522283
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True), "Test Try with positive number."

    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False), "Test Try with positive number."

    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False), "Test not successfully Try with positive number."

    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False), "Test not successfully Try with negative number."


# Generated at 2022-06-12 05:24:51.349706
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)



# Generated at 2022-06-12 05:24:59.445904
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try('', True).filter(lambda x: len(x) > 0) == Try('', False)

    assert Try('test', True).filter(lambda x: len(x) > 0) == Try('test', True)

    assert Try('test', False).filter(lambda x: len(x) > 0) == Try('test', False)



# Generated at 2022-06-12 05:25:05.398736
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x: int) -> bool:
        return x < 50

    assert Try(40, True).filter(filterer) == Try(40, True)
    assert Try(40, False).filter(filterer) == Try(40, False)
    assert Try(60, True).filter(filterer) == Try(60, False)


# Generated at 2022-06-12 05:25:13.125471
# Unit test for method filter of class Try
def test_Try_filter():
    # Test 1.1
    try_instance = Try(3, True)
    test_result = try_instance.filter(lambda x: x > 2)

    expected_result = Try(3, True)

    assert test_result == expected_result

    # Test 1.2
    try_instance = Try(1, True)
    test_result = try_instance.filter(lambda x: x > 2)

    expected_result = Try(1, False)

    assert test_result == expected_result

    # Test 1.3
    try_instance = Try(3, False)
    test_result = try_instance.filter(lambda x: x > 2)

    expected_result = Try(3, False)

    assert test_result == expected_result



# Generated at 2022-06-12 05:25:19.080957
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_func(value):
        return True

    value = Try(filter_func, True)
    assert value.filter(filter_func) == Try(filter_func, True)

    value = Try(filter_func, False)
    assert value.filter(filter_func) == Try(filter_func, False)


# Generated at 2022-06-12 05:25:22.720532
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try('x', False).filter(lambda x: True) == Try('x', False)


# Generated at 2022-06-12 05:25:26.460278
# Unit test for method filter of class Try
def test_Try_filter():

    assert Try.of(lambda: 10).filter(lambda v: v == 10) == Try(10, True)
    assert Try.of(lambda: 10).filter(lambda v: v == 11) == Try(10, False)
    assert Try.of(lambda: 10 / 0).filter(lambda v: False) == Try(10, False)


# Generated at 2022-06-12 05:25:32.298455
# Unit test for method filter of class Try
def test_Try_filter():
    # arrange
    exception_1 = Exception('Error 1')
    exception_2 = Exception('Error 2')
    try_1 = Try(1, True)
    try_2 = Try(5, True)
    try_3 = Try(None, False)
    try_4 = Try(exception_1, False)
    try_5 = Try('1+2', True)
    try_6 = Try('1+2', False)
    # act
    result_1 = try_1.filter(lambda x: x == 1)
    result_2 = try_2.filter(lambda x: x == 1)
    result_3 = try_3.filter(lambda x: x == 1)
    result_4 = try_4.filter(lambda x: x == 1)

# Generated at 2022-06-12 05:25:38.523967
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try(0, True).filter(lambda x: x == 0) == Try(0, True)
    assert Try(0, False).filter(lambda x: x == 0) == Try(0, False)
    assert Try(0, True).filter(lambda x: x == 1) == Try(0, False)
    assert Try(0, False).filter(lambda x: x == 1) == Try(0, False)

# Generated at 2022-06-12 05:25:43.811024
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 5).filter(lambda x: x > 4) == Try(5, True)
    assert Try.of(lambda x: x, 5).filter(lambda x: x > 6) == Try(5, False)
    assert Try.of(lambda x: x, 5).filter(lambda x: x < 6) == Try(5, True)



# Generated at 2022-06-12 05:25:50.579015
# Unit test for method filter of class Try
def test_Try_filter():
    gte0 = lambda x: x >= 0
    lt0 = lambda x: x < 0

    assert Try(0, True).filter(gte0).is_success == True
    assert Try(0, True).filter(lt0).is_success == False
    assert Try(-1, True).filter(gte0).is_success == False
    assert Try(-1, True).filter(lt0).is_success == True

# Generated at 2022-06-12 05:25:59.294331
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True) == Try(3, True).filter(lambda x: x > 1)
    assert Try(3, False) == Try(3, True).filter(lambda x: x < 1)



# Generated at 2022-06-12 05:26:03.766966
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def test_func(a):
        if a == 1:
            return True
        raise Exception('error')
    assert Try.of(test_func, 1).filter(bool) == Try(1, True)
    assert Try.of(test_func, 2).filter(bool) == Try(Exception('error'), False)

# Generated at 2022-06-12 05:26:08.888234
# Unit test for method filter of class Try
def test_Try_filter():
    def test_case(test_text, test_value, test_result):
        assert test_result == Try.of(lambda: test_value, 0).filter(lambda _: test_value > 0).is_success

    test_case('when is successfully and filterer returns true', 2, True)
    test_case('when is successfully and filterer returns false', 2, False)
    test_case('when is not successfully', -1, False)



# Generated at 2022-06-12 05:26:14.978687
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)



# Generated at 2022-06-12 05:26:18.979953
# Unit test for method filter of class Try
def test_Try_filter():
    def _id(value):
        return value

    def _is_even(value):
        return value % 2 == 0

    assert Try(1, True).filter(_is_even) == Try(1, False)
    assert Try(2, True).filter(_is_even) == Try(2, True)



# Generated at 2022-06-12 05:26:24.127050
# Unit test for method filter of class Try
def test_Try_filter():
    for_test = Try(1, True)

    result = for_test.filter(lambda a: a > 0)
    expected = Try(1, True)

    assert result == expected

    result = for_test.filter(lambda a: a < 0)
    expected = Try(1, False)

    assert result == expected


# Generated at 2022-06-12 05:26:36.538865
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, True).filter(lambda x=None: x is not None).is_success is False
    assert Try(None, True).filter(lambda x=None: x is None).is_success is True
    assert Try('value', True).filter(lambda x='value': x is not None).is_success is True
    assert Try('', True).filter(lambda x='': x is not None).is_success is True
    # Othercase
    assert Try(None, False).filter(lambda x=None: x is not None).is_success is False
    assert Try(None, False).filter(lambda x=None: x is None).is_success is False
    assert Try('value', False).filter(lambda x='value': x is not None).is_success is False

# Generated at 2022-06-12 05:26:43.001883
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0
    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(-10, True).filter(filterer) == Try(-10, False)
    assert Try(-10, False).filter(filterer) == Try(-10, False)
    assert Try(Exception, False).filter(filterer) == Try(Exception, False)


# Generated at 2022-06-12 05:26:48.484683
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(1, False).filter(lambda x: True) == Try(1, False)
    assert Try('error', False).filter(lambda x: True) == Try('error', False)


# Generated at 2022-06-12 05:26:52.450283
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0)\
        == Try(1, True)
    assert Try(1, True).filter(lambda x: x > 1)\
        == Try(1, False)


# Generated at 2022-06-12 05:27:05.748735
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of Try class.

    :returns: None
    :rtype: None
    """
    # arrange
    value = 1

    # act
    m = Try.of(int, '1')

    # assert
    assert m.filter(lambda item: item == 1).get_or_else(-1) == value



# Generated at 2022-06-12 05:27:13.240817
# Unit test for method filter of class Try
def test_Try_filter():
    class DummyException(Exception):
        pass

    def even(x):
        return x % 2 == 0

    def raise_if(cond, ex):
        if cond:
            raise ex

    def test(x):
        raise_if(x == 3, DummyException())
        return x

    assert Try.of(test, 1).filter(even) == Try(1, True)
    assert Try.of(test, 2).filter(even) == Try(2, True)
    assert Try.of(test, 3).filter(even) == Try(DummyException(), False)
    assert Try.of(test, 4).filter(even) == Try(4, True)



# Generated at 2022-06-12 05:27:19.554496
# Unit test for method filter of class Try
def test_Try_filter():
    def f1(value):
        return True
    def f2(value):
        return False

    assert Try.of(lambda: 42/0) == Try(ZeroDivisionError(), False)
    assert Try(42/0, False).filter(f1) == Try(ZeroDivisionError(), False)
    assert Try(42/0, False).filter(f2) == Try(ZeroDivisionError(), False)
    assert Try(42, True).filter(f1) == Try(42, True)
    assert Try(42, True).filter(f2) == Try(42, False)
    try:
        assert Try(42/0, False).filter(f1) == Try(42/0, False)
        assert False
    except ZeroDivisionError:
        assert True


# Generated at 2022-06-12 05:27:26.441600
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of Try class.
    """
    assert Try(2, True).filter(lambda x: x % 2 is 0) == Try(2, True)
    assert Try(2, True).filter(lambda x: x % 2 is 1) == Try(2, False)
    assert Try('some error', False).filter(lambda x: x % 2 is 0) == Try('some error', False)
    assert Try(2, False).filter(lambda x: x % 2 is 0) == Try(2, False)

# Generated at 2022-06-12 05:27:31.637136
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda a: a == 2) == Try(2, True)
    assert Try(2, True).filter(lambda a: a == 1) == Try(2, False)
    assert Try(2, False).filter(lambda a: a == 1) == Try(2, False)


# Generated at 2022-06-12 05:27:38.751031
# Unit test for method filter of class Try
def test_Try_filter():
    def inc(value):
        return value + 1

    def checking(value):
        return value == 5

    def checking_fail(value):
        return value == 7

    assert Try(5, True).filter(checking).get() == 5
    assert Try(6, True).filter(checking).is_success == False
    assert Try(6, False).filter(checking).is_success == False

    assert Try(5, True).filter(checking_fail).get() == 5
    assert Try(7, True).filter(checking_fail).is_success == False
    assert Try(7, False).filter(checking_fail).is_success == False



# Generated at 2022-06-12 05:27:43.977322
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1').filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(int, '1').filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(int, '').filter(lambda x: x == 1) == Try('', False)


# Generated at 2022-06-12 05:27:54.132297
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.

    :return:
    """
    assert Try.of(lambda a, b, c: a + b + c, 1, 2, 3)\
           .filter(lambda v: v > 3)\
           == Try(6, True)

    assert Try.of(lambda a, b, c: a + b + c, 1, 2, 3)\
           .filter(lambda v: v > 6)\
           == Try(6, False)

    assert Try.of(lambda a, b, c: a + b + c, 1, 2, 3)\
           .filter(lambda v: v / 0)\
           == Try(6, False)



# Generated at 2022-06-12 05:28:00.073520
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value, start_value):
        return value > start_value

    try_1 = Try(1, True)
    try_2 = Try.of(lambda x: x, 2)
    try_3 = Try.of(lambda x: x, 2)

    assert try_1.filter(lambda x: filterer(x, 2)) == Try(1, False)
    assert try_2.filter(lambda x: filterer(x, 2)) == try_3

# Generated at 2022-06-12 05:28:03.934975
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 7, None).filter(lambda x: x == 7) == Try(7, True)
    assert Try.of(lambda: 7, None).filter(lambda x: x == 8) == Try(7, False)



# Generated at 2022-06-12 05:28:25.986631
# Unit test for method filter of class Try
def test_Try_filter():
    # setup
    try_1 = Try(1, True)
    try_2 = Try(2, False)
    try_3 = Try(-1, True)
    # start
    assert try_1.filter(lambda x: x > 0).get() == 1, 'Try.filter() method is incorrect'
    assert try_2.filter(lambda x: x > 0).get() == 2, 'Try.filter() method is incorrect'
    assert try_3.filter(lambda x: x > 0).get() == -1, 'Try.filter() method is incorrect'
    assert try_1.filter(lambda x: x > 0).is_success is True, 'Try.filter() method is incorrect'
    assert try_2.filter(lambda x: x > 0).is_success is False, 'Try.filter() method is incorrect'

# Generated at 2022-06-12 05:28:32.617407
# Unit test for method filter of class Try
def test_Try_filter():
    """Unit test for method filter of class Try"""
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try.of(lambda: 1)
    assert Try.of(lambda: 1).filter(lambda x: x != 1) == Try(ValueError(), False)
    assert Try(RuntimeError(), False).filter(lambda x: x == 1) == Try(RuntimeError(), False)

# Generated at 2022-06-12 05:28:40.209442
# Unit test for method filter of class Try
def test_Try_filter():
	def method_with_try(num):
		return Try.of(int, num)

	assert method_with_try('1').filter(lambda x: x == 1) == Try(1, True)
	assert method_with_try('1').filter(lambda x: x == 2) == Try('1', False)

	def method_with_try2(num):
		return Try.of(int, num)

	assert method_with_try2('foo').filter(lambda x: x == 2) == Try('foo', False)

# Generated at 2022-06-12 05:28:44.703108
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try('error', False).filter(lambda _: False) == Try('error', False)



# Generated at 2022-06-12 05:28:56.404678
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Function tests filter method of Try class.

    :returns: boolean, true when tests passed, othercase false.
    :rtype: Boolean
    """
    def exception_method():
        raise Exception('Some exception')

    result = Try.of(exception_method)

    # test 1
    # test when value is not exception
    try:
        result.filter(lambda x: False)
    except:
        return False

    # test 2
    # test when value is exception
    if result.filter(lambda x: True).is_success:
        return False

    # test 3
    # test when value is not exception
    condition = result.filter(lambda x: True).is_success
    if condition:
        return False

    return True


# Generated at 2022-06-12 05:29:01.093401
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(100, True).filter(lambda x: x == 100) == Try(100, True)
    assert Try(100, True).filter(lambda x: x == 101) == Try(100, False)
    assert Try(100, False).filter(lambda x: x == 100) == Try(100, False)
    assert Try(100, False).filter(lambda x: x == 101) == Try(100, False)



# Generated at 2022-06-12 05:29:09.204310
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    is_positive = lambda x: x > 0

    # WHEN
    success_try = Try.of(lambda x: 1)
    not_success_try = Try.of(lambda x: 0)
    success_try_without_filter = Try.of(lambda x: 1)
    not_success_try_without_filter = Try.of(lambda x: 0)

    # THEN
    assert success_try.filter(is_positive) == success_try_without_filter
    assert not_success_try.filter(is_positive) != not_success_try_without_filter


# Generated at 2022-06-12 05:29:15.390382
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(False, True).filter(lambda x: False) == Try(False, True)

    assert Try(Exception('test exception'), False).filter(lambda x: True) == Try(Exception('test exception'), False)


# Generated at 2022-06-12 05:29:20.741280
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully Try with string value
    successfully_str_try = Try(str('abc'), True)

    # Successfully Try with boolean value
    successfully_boolean_try = successfully_str_try.filter(lambda x: True)

    # Successfully Try with boolean value
    not_successfully_boolean_try = successfully_str_try.filter(lambda x: False)

    assert successfully_boolean_try == Try(str('abc'), True)
    assert not_successfully_boolean_try == Try(str('abc'), False)


# Generated at 2022-06-12 05:29:26.357269
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        if x < 5:
            return True
        return False
    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(5, True).filter(filterer) == Try(5, False)
    assert Try(5, False).filter(filterer) == Try(5, False)


# Generated at 2022-06-12 05:29:52.497577
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(42, True).filter(lambda x: x % 2 == 0) == Try(42, True)
    assert Try(42, True).filter(lambda x: x > 0) == Try(42, True)
    assert Try(42, True).filter(lambda x: x < 0) == Try(42, False)
    assert Try(42, False).filter(lambda x: x % 2 == 0) == Try(42, False)
    assert Try(42, False).filter(lambda x: x > 0) == Try(42, False)
    assert Try(42, False).filter(lambda x: x < 0) == Try(42, False)


# Generated at 2022-06-12 05:29:57.043669
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(2, True).filter(lambda x: x == 1) == Try(2, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-12 05:30:05.383494
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    try_fail = Try(Exception(), False)
    try_empty_string = Try('', True)
    try_number = Try(1, True)
    try_string = Try('ABC', True)

    # THEN
    assert Try.of(lambda: 1 / 0).filter(lambda x: False) == Try(ZeroDivisionError(), False)
    assert try_fail.filter(lambda x: False) == try_fail
    assert try_empty_string.filter(lambda x: x) == Try('', False)
    assert try_number.filter(lambda x: x) == try_number
    assert try_string.filter(lambda x: x) == try_string
    assert try_string.filter(lambda x: len(x)) == try_string

# Generated at 2022-06-12 05:30:11.908160
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(123, True).filter(lambda x: x > 100)\
        == Try(123, True), "Filter should return successful Try when filterer returns True"

    assert Try(123, True).filter(lambda x: x < 10)\
        == Try(123, False), "Filter should return failed Try when filterer returns False"

    assert Try(Exception, False).filter(lambda x: x > 100)\
        == Try(Exception, False), "Filter should return same Try when filterer is called on not successful Try"


# Generated at 2022-06-12 05:30:16.159283
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: '1').filter(lambda x: x == '1') == Try('1', True)
    assert Try.of(lambda: '0').filter(lambda x: x == '1') == Try('0', False)
    assert Try.of(lambda: 1 / 0).filter(lambda x: x == '1') == Try(ZeroDivisionError(), False)

# Generated at 2022-06-12 05:30:19.802784
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)



# Generated at 2022-06-12 05:30:27.266090
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter(filterer) of class Try.
    """
    def test_len_filter(x: int) -> bool:
        return len([0] * x) == x

    # Call filter method
    def try_filter(x: int) -> Try:
        return Try(x, True).filter(test_len_filter)

    # Test successful filter
    assert try_filter(5) == Try(5, True)
    # Test unsuccessful filter
    assert try_filter(0) == Try(0, False)


# Generated at 2022-06-12 05:30:32.081060
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer_1(x):
        return x == 'ok'

    def filterer_2(x):
        return x != 'ok'

    assert(Try('not ok', True).filter(filterer_1) == Try('not ok', False))
    assert(Try('not ok', True).filter(filterer_2) == Try('not ok', True))


# Generated at 2022-06-12 05:30:42.530838
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 7).filter(lambda x: x == 7) == Try(7, True)
    assert Try.of(lambda x: x, 7).filter(lambda x: x >= 7) == Try(7, True)
    assert Try.of(lambda x: x, 7).filter(lambda x: x <= 7) == Try(7, True)
    assert Try.of(lambda x: x, 7).filter(lambda x: x > 8) == Try(7, False)
    assert Try.of(lambda x: x, 7).filter(lambda x: x < 8) == Try(7, True)
    assert Try.of(lambda x: x, 7).filter(lambda x: x >= 8) == Try(7, False)

# Generated at 2022-06-12 05:30:49.265929
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for filter method.
    """
    def filterer(value):
        return value > 2

    def not_filterer(value):
        return value < 2

    try_ = Try.of(lambda: 1)
    result = try_.filter(filterer)
    assert result == Try(1, False)

    try_ = Try.of(lambda: 3)
    result = try_.filter(filterer)
    assert result == Try(3, True)

    try_ = Try.of(lambda: 3)
    result = try_.filter(not_filterer)
    assert result == Try(3, False)

# Generated at 2022-06-12 05:31:33.155352
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Function for test method filter of class Try.

    Function test method filter for different cases.
    """
    def is_lower_than_zero(x):
        return x < 0

    assert Try(10, True).filter(is_lower_than_zero) == Try(10, False),\
        'Result of Try(10, True).filter(is_lower_than_zero) is not Try(10, False)'

    assert Try(-10, True).filter(is_lower_than_zero) == Try(-10, True),\
        'Result of Try(-10, True).filter(is_lower_than_zero) is not Try(-10, True)'


# Generated at 2022-06-12 05:31:38.951292
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value != 1

    assert Try(None, True).filter(filterer) == Try(None, True)
    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)



# Generated at 2022-06-12 05:31:43.218816
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) != Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-12 05:31:48.588746
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: False).is_success == False
    assert Try(1, True).filter(lambda v: True).is_success == True
    assert Try(1, False).filter(lambda v: True).is_success == False
    assert Try(1, False).filter(lambda v: False).is_success == False


# Generated at 2022-06-12 05:31:54.462432
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(3, True).filter(lambda x: x % 2 == 0) == Try(3, False)
    assert Try(ValueError('test'), False).filter(lambda x: True) == Try(ValueError('test'), False)


# Generated at 2022-06-12 05:32:03.349131
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 2

    def filterer1(x):
        return x < 2

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(4, True).filter(filterer) == Try(4, True)
    assert Try(4, True).filter(filterer1) == Try(4, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-12 05:32:10.749285
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 4

    # successfully
    assert Try(5, True).filter(filterer) == Try(5, True)

    # not successfully
    assert Try(5, False).filter(filterer) == Try(5, False)

    # value not passed filterer
    assert Try(2, True).filter(filterer) == Try(2, False)



# Generated at 2022-06-12 05:32:20.076275
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """
    def test_function(value: int) -> int:
        """
        Simple test function.
        """
        return value

    def test_filterer(value) -> bool:
        """
        Simple filterer function.
        """
        return value > 4

    assert Try.of(test_function, 5).filter(test_filterer) == Try(5, True)
    assert Try.of(test_function, 3).filter(test_filterer) == Try(3, False)


# Generated at 2022-06-12 05:32:30.080129
# Unit test for method filter of class Try

# Generated at 2022-06-12 05:32:34.765935
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, is_success=True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, is_success=False)


# Generated at 2022-06-12 05:33:20.289084
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(0, True).filter(lambda x: x > 0) == Try(0, False)
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(Exception('Error'), False).filter(lambda x: x > 0) == Try(Exception('Error'), False)


# Generated at 2022-06-12 05:33:26.828384
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x == 5) == Try(5, True)
    assert Try(5, True).filter(lambda x: x == 6) == Try(5, False)
    assert Try(5, False).filter(lambda x: x == 5) == Try(5, False)
    assert Try(5, False).filter(lambda x: x == 6) == Try(5, False)


# Generated at 2022-06-12 05:33:33.030478
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filterer(value):
        return value > 10

    assert Try(10, True).filter(test_filterer) == Try(10, False)
    assert Try(10, False).filter(test_filterer) == Try(10, False)
    assert Try(11, True).filter(test_filterer) == Try(11, True)
    assert Try(11, False).filter(test_filterer) == Try(11, False)


# Generated at 2022-06-12 05:33:36.818310
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x < 10) == Try(5, True)
    assert Try(5, True).filter(lambda x: x >= 10) == Try(5, False)
    assert Try(Exception('error'), False).filter(lambda x: x < 10) == Try(Exception('error'), False)



# Generated at 2022-06-12 05:33:46.839093
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for filter.
    """
    assert Try(-1, True).filter(lambda x: x > 2) == Try(-1, False)
    assert Try(-1, True).filter(lambda x: x < 2) == Try(-1, True)
    assert Try(-1, True).filter(lambda x: x < 0) == Try(-1, True)
    assert Try(1, True).filter(lambda x: x > 2) == Try(1, False)
    assert Try(2, True).filter(lambda x: x > 2) == Try(2, False)
    assert Try(2, True).filter(lambda x: x == 2) == Try(2, True)
    assert Try(True, True).filter(lambda x: x) == Try(True, True)