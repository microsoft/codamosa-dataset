

# Generated at 2022-06-12 05:23:56.342746
# Unit test for method filter of class Try
def test_Try_filter():
    value = 'string'
    def filterer(x):
        return x == value
    # when monad is successfully and filterer return True
    assert Try.of(lambda: value, None).filter(filterer) == Try(value, True)
    # when monad is not successfully
    assert Try.of(Exception, None).filter(filterer) == Try('Exception', False)
    # when monad is successfully and filterer return False
    assert Try.of(lambda: '', None).filter(filterer) == Try('', False)


# Generated at 2022-06-12 05:23:58.844529
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x + 1, 1).filter(lambda x: x > 1) == Try(2, True)
    assert Try.of(lambda x: x + 1, 1).filter(lambda x: x <= 1) == Try(2, False)


# Generated at 2022-06-12 05:24:03.076422
# Unit test for method filter of class Try
def test_Try_filter():
    def t_a(a):
        return a == 'a'

    assert Try('a', True).filter(t_a) == Try('a', True)
    assert Try('a', False).filter(t_a) == Try('a', False)
    assert Try('b', True).filter(t_a) == Try('b', False)


# Generated at 2022-06-12 05:24:14.954672
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """
    value = 10
    try_filter_value = Try.of(lambda x: x, value)

    # test for successfully monad
    try_filter_result = try_filter_value.filter(lambda x: x < 10)
    assert try_filter_result == Try(value, False)

    # test for not successfully monad
    try_filter_value = Try(value, False)
    try_filter_result = try_filter_value.filter(lambda x: x < 10)
    assert try_filter_result == Try(value, False)

    # test for successfully monad when filterer return True
    try_filter_value = Try.of(lambda x: x, value)

# Generated at 2022-06-12 05:24:25.138751
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def positive_number(number):  # check is positive number
        return number > 0

    def first_letter_equal_letter_a(name):  # check is name starts with letter a
        return name[0] == 'a'

    def get_number_from_string(number_as_string):  # returns int from string
        return int(number_as_string)

    assert Try.of(get_number_from_string, '123').filter(positive_number) == Try(123, True)
    assert Try.of(get_number_from_string, '-123').filter(positive_number) == Try(-123, False)
    assert Try.of(get_number_from_string, 'a123').filter(positive_number) == Try('a123', False)

# Generated at 2022-06-12 05:24:31.245259
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN Try(2, True)
    try_ = Try(2, True)
    # WHEN call method filter
    try_ = try_.filter(lambda value: value > 1)
    # THEN try_.is_success is True
    # AND try_.value is 2
    assert try_.is_success is True and try_.value == 2


# Generated at 2022-06-12 05:24:37.780377
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully Try
    t1 = Try(True, True)
    t2 = t1.filter(lambda x: True)
    assert t2 == t1

    t2 = t1.filter(lambda x: False)
    assert t2 == Try(False, False)

    # Not successfully Try
    t1 = Try(True, False)
    t2 = t1.filter(lambda x: True)
    assert t2 == t1

    t2 = t1.filter(lambda x: False)
    assert t2 == t1


# Generated at 2022-06-12 05:24:44.369059
# Unit test for method filter of class Try
def test_Try_filter():
    input_value = 1

# Generated at 2022-06-12 05:24:52.284651
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    class MyError(Exception):
        pass
    def throw_exception_if_divide_by_zero(value):
        if value == 0:
            raise MyError
    def is_not_zero(value):
        return value != 0

    # When
    successfully = Try.of(lambda x: x, 1).filter(is_not_zero)
    not_successfully = Try.of(lambda x: x, 0).filter(is_not_zero)
    successfully_with_exception = Try.of(throw_exception_if_divide_by_zero, 0).filter(is_not_zero)

    # Then
    assert successfully.is_success
    assert not not_successfully.is_success
    assert not successfully_with_exception.is_success
    assert successfully.value == 1

# Generated at 2022-06-12 05:24:58.371632
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    Success case.
    """
    success_value = 5
    try_object = Try(success_value, True)

    def common_filterer(value):
        assert value == success_value
        return True

    result = try_object.filter(common_filterer)
    assert result == Try(success_value, True)



# Generated at 2022-06-12 05:25:05.776280
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(42, True).filter(lambda x: x % 2 == 0) == Try(42, True)
    assert Try(42, True).filter(lambda x: x % 2 != 0) == Try(42, False)
    assert Try(41, True).filter(lambda x: x % 2 == 0) == Try(41, False)


# Generated at 2022-06-12 05:25:09.769615
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x > 3) == Try(5, True)
    assert Try(2, True).filter(lambda x: x > 3) == Try(2, False)
    assert Try(5, False).filter(lambda x: x > 3) == Try(5, False)


# Generated at 2022-06-12 05:25:14.578864
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_fail(value):
        return False

    def filter_pass(value):
        return True

    assert Try(1, True).filter(filter_pass) == Try(1, True)
    assert Try(1, True).filter(filter_fail) == Try(1, False)
    assert Try(1, False).filter(filter_pass) == Try(1, False)
    assert Try(1, False).filter(filter_fail) == Try(1, False)


# Generated at 2022-06-12 05:25:17.379265
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True).filter(lambda _: _ > 3) == Try(3, False)
    assert Try(3, True).filter(lambda _: _ == 3) == Try(3, True)



# Generated at 2022-06-12 05:25:26.303963
# Unit test for method filter of class Try
def test_Try_filter():

    # When monad is not successfully and filterer returns True
    t1 = Try(1, False)
    f1 = t1.filter(lambda x: x == 1)
    assert not f1.is_success
    assert f1.value == 1

    # When monad is not successfully and filterer returns False
    t2 = Try(1, False)
    f2 = t2.filter(lambda x: x == 2)
    assert not f2.is_success
    assert f2.value == 1

    # When monad is successfully and filterer returns True
    t3 = Try(1, True)
    f3 = t3.filter(lambda x: x == 1)
    assert f3.is_success
    assert f3.value == 1

    # When monad is successfully and filterer returns False
   

# Generated at 2022-06-12 05:25:31.460909
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filter_with_true_predicate():
        assert Try.of(lambda: 1) \
                .filter(lambda x: True) \
                .get_or_else(None) == 1

    def test_filter_with_false_predicate():
        assert Try.of(lambda: 1) \
                    .filter(lambda x: False) \
                    .get_or_else(None) is None

    def test_filter_with_exception():
        try:
            Try.of(lambda: 1/0) \
                .filter(lambda x: False) \
                .get_or_else(None) is None
        except Exception as e:
            pass

# Generated at 2022-06-12 05:25:36.938286
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for filter function.

    :returns: None
    :rtype: None
    """
    assert Try.of(lambda x: x/2, 4).filter(lambda x: x == 2) == Try(2, True)
    assert Try.of(lambda x: x/2, 4).filter(lambda x: x == 1) == Try(2, False)


# Generated at 2022-06-12 05:25:43.856449
# Unit test for method filter of class Try
def test_Try_filter():
    value = 5
    try_ = Try(value, True)

    def _filter(value):
        return value > 3

    assert Try.filter(try_, _filter) == Try(value, True)

    try_ = Try(value, False)
    assert Try.filter(try_, _filter) == Try(value, False)

    def _filter(value):
        return value > 10

    assert Try.filter(try_, _filter) == Try(value, False)


# Generated at 2022-06-12 05:25:49.445168
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(3, True).filter(lambda x: x % 2 == 0) == Try(3, False)
    assert Try(2, False).filter(lambda x: x % 2 == 0) == Try(2, False)

# Generated at 2022-06-12 05:25:52.291632
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda _: True) == Try(1, True)
    assert Try(1, True).filter(lambda _: False) == Try(1, False)



# Generated at 2022-06-12 05:26:03.881088
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, 3).filter(lambda i: i > 2) == Try(1, False)
    assert Try.of(lambda: 1, 4).filter(lambda i: i > 2) == Try(1, True)
    assert Try.of(lambda: 1, 3).filter(lambda i: i > 2).get_or_else(0) == 0
    assert Try.of(lambda: 1, 4).filter(lambda i: i > 2).get_or_else(0) == 1


# Generated at 2022-06-12 05:26:07.721213
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(Exception('a'), False).filter(lambda x: x < 0) == Try(Exception('a'), False)


# Generated at 2022-06-12 05:26:15.182210
# Unit test for method filter of class Try
def test_Try_filter():
    run_test = lambda x: 0 <= x <= 100
    t1 = Try(80, True)
    t1_res = t1.filter(run_test)
    t2 = Try(200, True)
    t2_res = t2.filter(run_test)
    assert t1_res == Try(80, True)
    assert t2_res == Try(200, False)
    print('test_Try_filter -- ok')


# Generated at 2022-06-12 05:26:25.668622
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x >= 2) == Try(2, True), "Test 1.1.1 passed"
    assert Try(1, True).filter(lambda x: x >= 2) == Try(1, False), "Test 1.1.2 passed"
    assert Try(1, False).filter(lambda x: x >= 2) == Try(1, False), "Test 1.1.3 passed"

    # Test for checking when filterer function raise Exception
    assert Try(1, True).filter(lambda x: 1 / 0) == Try(1, False), "Test 1.1.4 passed"

    # Test for checking when filterer function return None
    assert Try(1, True).filter(lambda x: None) == Try(1, False), "Test 1.1.5 passed"



# Generated at 2022-06-12 05:26:34.025131
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 3

    minimal_successfull_monad = Try(5, True)
    maximal_successfull_monad = Try(1, True)

    assert minimal_successfull_monad.filter(filterer) == Try(5, True)
    assert maximal_successfull_monad.filter(filterer) == Try(1, False)



# Generated at 2022-06-12 05:26:39.648799
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> test_Try_filter()
    Try[value=1, is_success=False]
    >>> test_Try_filter()
    Try[value=2, is_success=True]
    """
    random_number = random.randint(0, 2)
    if random_number == 1:
        print(Try(2, True).filter(lambda x: x == 2))
    else:
        print(Try(1, False).filter(lambda x: x == 2))

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 05:26:46.274575
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Only one unit test for filter example.
    """
    is_even_number = lambda number: number % 2 == 0
    assert (Try(7, True).filter(is_even_number) == Try(7, False))
    assert (Try(8, True).filter(is_even_number) == Try(8, True))
    assert (Try(7, False).filter(is_even_number) == Try(7, False))

# Generated at 2022-06-12 05:26:52.550232
# Unit test for method filter of class Try
def test_Try_filter():
    option = Try.of(lambda: 'value').filter(lambda x: x == 'value')
    assert option == Try('value', True)

    option = Try.of(lambda: 'value').filter(lambda x: x != 'value')
    assert option == Try('value', False)

    option = Try.of(lambda: 1 / 0).filter(lambda x: x == 'value')
    assert option == Try(ZeroDivisionError(), False)


# Generated at 2022-06-12 05:26:58.897048
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'success').filter(lambda x: True) == Try('success', True)
    assert Try.of(lambda: 'success').filter(lambda x: False) == Try('success', False)
    assert Try.of(lambda: 1 / 0).filter(lambda x: True) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0).filter(lambda x: False) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-12 05:27:05.342027
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(a):
        return a == 1

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, False)



# Generated at 2022-06-12 05:27:21.076118
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    try1 = Try(1, True)
    try2 = Try(0, True)

    assert try1.filter(filterer) == Try(1, True)
    assert try2.filter(filterer) == Try(0, False)


# Generated at 2022-06-12 05:27:29.152856
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from nose.tools import assert_equals

    # Case: filter on succeeded
    assert_equals(
        Try(10, True).filter(lambda x: x > 5),
        Try(10, True)
    )

    # Case: filter on failed
    assert_equals(
        Try(10, False).filter(lambda x: x > 5),
        Try(10, False)
    )

    # Case: filter on succeeded, but don't passed
    assert_equals(
        Try(10, True).filter(lambda x: x < 5),
        Try(10, False)
    )

    # Case: filter on failed, but don't passed
    assert_equals(
        Try(10, False).filter(lambda x: x < 5),
        Try(10, False)
    )

# Generated at 2022-06-12 05:27:33.287875
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Function for testing Try class filter function.
    """

    def divide(x, y):
        """
        Divide function, not safely.

        :params x: first number
        :type x: Integer
        :params y: second number
        :type y: Integer
        :returns: result of x / y
        :rtype: Integer
        """
        return x / y

    def is_positive(x):
        """
        Check is number positive

        :params x: number
        :type x: Integer
        :returns: True when x is positive, othercase False
        :rtype: Boolean
        """
        return x > 0

    print('Test Try filter')

# Generated at 2022-06-12 05:27:43.837486
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)
    assert Try(10, True).filter(lambda x: x > 15) == Try(10, False)
    assert Try(5, True).filter(lambda x: x < 15) == Try(5, True)
    assert Try(5, True).filter(lambda x: x > 15) == Try(5, False)
    assert Try(5, True).filter(lambda x: x > 15) == Try(5, False)
    assert Try(5, False).filter(lambda x: x > 15) == Try(5, False)


# Generated at 2022-06-12 05:27:55.597228
# Unit test for method filter of class Try
def test_Try_filter():
    test_value = 1
    try_is_success = True
    t = Try(test_value, try_is_success)

    # test for successfully filter
    def filter_succesfully(value):
        return value == test_value
    t = t.filter(filter_succesfully)
    assert Try(test_value, try_is_success) == t

    # test for not successfully filter
    def filter_not_succesfully(value):
        return value > test_value
    t = t.filter(filter_not_succesfully)
    assert Try(test_value, not try_is_success) == t

    # test for successfully filter of not successfull Try
    t = Try(test_value, not try_is_success)
    t = t.filter(filter_succesfully)

# Generated at 2022-06-12 05:28:00.830209
# Unit test for method filter of class Try
def test_Try_filter():
    def func_a():
        return 1

    def func_b():
        raise ZeroDivisionError()

    assert Try.of(func_a).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(func_a).filter(lambda x: x == 2) == Try(1, False)

    assert Try.of(func_b).filter(lambda x: x == 1) == Try(ZeroDivisionError(), False)

# Generated at 2022-06-12 05:28:10.194008
# Unit test for method filter of class Try
def test_Try_filter():
    # Successful Try
    try_successful = Try.of(lambda: "success_value", None)
    # Unsuccessful Try
    try_unsuccessful = Try.of(lambda: 1 / 0, None)

    # Successful value
    try_successful.filter(lambda v: v == "success_value")
    # Unsuccessful value
    try_successful.filter(lambda v: v == "unsuccessful_value")
    # Unsuccessful value
    try_unsuccessful.filter(lambda v: v == "success_value")
    # Unsuccessful value
    try_unsuccessful.filter(lambda v: v == "unsuccessful_value")


# Generated at 2022-06-12 05:28:16.858985
# Unit test for method filter of class Try
def test_Try_filter():
    fn = lambda x: x > 5
    assert Try(6, True).filter(fn) == Try(6, True)
    assert Try(6, True).filter(fn) != Try(6, False)

    assert Try(4, True).filter(fn) == Try(4, False)
    assert Try(4, True).filter(fn) != Try(4, True)


# Generated at 2022-06-12 05:28:20.899322
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(a):
        return a == 1

    def on_success(a):
        pass

    try_monad = Try(1, True)
    assert try_monad.filter(filterer).on_success(on_success) == Try(1, True)
    assert try_monad.filter(lambda a: a == 2).on_success(on_success) == Try(1, False)


# Generated at 2022-06-12 05:28:26.861203
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x < 2) == Try(1, True)
    assert Try(1, True).filter(lambda x: x > 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 2) == Try(1, False)



# Generated at 2022-06-12 05:28:58.127234
# Unit test for method filter of class Try
def test_Try_filter():
    try_one = Try.of(float, "1.0")
    try_two = Try.of(float, "one")
    try_three = Try.of(float, "3.0")
    try_four = Try.of(float, "4.0")

    assert try_one.filter(lambda x: x == 1.0) == Try(1.0, True)
    assert try_two.filter(lambda x: x == 1.0) == Try(ValueError("could not convert string to float: 'one'"), False)
    assert try_three.filter(lambda x: x == 1.0) == Try(ValueError("could not convert string to float: '3.0'"), False)

# Generated at 2022-06-12 05:29:08.764633
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x > 2) == Try(1, False)
    assert Try.of(lambda: 3).filter(lambda x: x > 2) == Try(3, True)
    assert Try.of(lambda: 3).filter(lambda x: x > 2).filter(lambda x: x > 6) == Try(3, False)
    assert Try.of(lambda: 3).filter(lambda x: x > 2).filter(lambda x: x > 2) == Try(3, True)

    assert Try.of(lambda: 1).filter(lambda x: x > 2).on_success(lambda x: x+1) == Try(1, False)

# Generated at 2022-06-12 05:29:12.565558
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x > 4) == Try(5, True)
    assert Try(5, True).filter(lambda x: x > 5) == Try(5, False)


# Generated at 2022-06-12 05:29:14.053591
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(_is_odd) == Try(1, True)
    assert Try.of(lambda: 2).filter(_is_odd) == Try(2, False)



# Generated at 2022-06-12 05:29:20.471167
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try.of(lambda: 1, 'parameter', 'not used').filter(lambda x: x != 5)\
        == Try(1, True)
    assert Try.of(lambda: 1, 'parameter', 'not used').filter(lambda x: x == 5)\
        == Try(1, False)
    assert Try(Exception('message'), False).filter(lambda x: True)\
        == Try(Exception('message'), False)
    assert Try(Exception('message'), False).filter(lambda x: False)\
        == Try(Exception('message'), False)


# Generated at 2022-06-12 05:29:27.788299
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-12 05:29:29.644591
# Unit test for method filter of class Try
def test_Try_filter():
    assert_class_and_method_are_there(Try, 'filter')


# Generated at 2022-06-12 05:29:32.782257
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(123, True).filter(lambda x: x > 100) == Try(123, True)
    assert Try(123, True).filter(lambda x: x < 100) == Try(123, False)


# Generated at 2022-06-12 05:29:40.934806
# Unit test for method filter of class Try
def test_Try_filter():
    # Test filter with boolean functions
    assert Try(True, True).filter(lambda x: x) is Try(True, True)
    assert Try(False, True).filter(lambda x: x) is Try(False, False)
    assert Try(False, True).filter(lambda x: not x) is Try(False, True)
    assert Try(True, True).filter(lambda x: not x) is Try(True, False)

    # Test filter with exception functions
    def division_by_zero():
        1 / 0
    assert Try.of(division_by_zero).filter(lambda _: True) is Try(division_by_zero, False)
    assert Try.of(division_by_zero).filter(lambda _: False) is Try(division_by_zero, False)



# Generated at 2022-06-12 05:29:51.688286
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 5,).filter(lambda x: x > 4)\
        == Try(5, True)
    assert Try.of(lambda: 5,).filter(lambda x: x > 6)\
        == Try(5, False)
    assert Try.of(lambda: 5,).filter(lambda x: x > 5)\
        == Try(5, False)
    assert Try.of(lambda: 5,).filter(lambda x: x > 3)\
        == Try(5, True)
    assert Try.of(lambda: 5,).filter(lambda x: x == 5)\
        == Try(5, True)
    assert Try.of(lambda: 5,).filter(lambda x: x != 5)\
        == Try(5, False)

# Generated at 2022-06-12 05:30:16.754626
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x != 1) == Try(1, False)


# Generated at 2022-06-12 05:30:27.914583
# Unit test for method filter of class Try
def test_Try_filter():
    def some_filterer(value):
        return value == 5
    some_monad = Try(5, True)
    assert some_monad.filter(some_filterer) == Try(5, True), \
        'Expected Try[value=5, is_success=True], got {}'.format(some_monad)
    some_monad = Try(5, False)
    assert some_monad.filter(some_filterer) == Try(5, False), \
        'Expected Try[value=5, is_success=False], got {}'.format(some_monad)
    some_monad = Try(4, True)

# Generated at 2022-06-12 05:30:31.816376
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x + 1, 5).filter(lambda x: x > 5).get_or_else(-1) == 6
    assert Try.of(lambda x: x + 1, 5).filter(lambda x: x < 5).get_or_else(-1) == -1


# Generated at 2022-06-12 05:30:38.687140
# Unit test for method filter of class Try
def test_Try_filter():
    value = "It's work!"
    filterer = lambda value: False

    try_obj = Try.of(lambda: value)

    #This Try don't have to change
    assert try_obj == try_obj.filter(filterer)

    #This Try have to change in not successfully
    try_obj_filtered = try_obj.filter(filterer)
    assert not try_obj_filtered.is_success
    assert try_obj_filtered.value == value


# Generated at 2022-06-12 05:30:48.381390
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(v):
        return v == 0
    # Successful
    assert(Try(0, True).filter(filterer).get())
    assert(Try(0, True).filter(filterer).is_success)

    assert(Try(0, True).filter(lambda v: v == 0).get())
    assert(Try(0, True).filter(lambda v: v == 0).is_success)

    # Not successful
    assert(Try(1, True).filter(filterer).get() == 1)
    assert(not Try(1, True).filter(filterer).is_success)

    assert(Try(1, True).filter(lambda v: v == 0).get() == 1)
    assert(not Try(1, True).filter(lambda v: v == 0).is_success)


# Generated at 2022-06-12 05:31:00.344816
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for filter method of Try class.
    """
    assert Try.of(lambda x: x + 2, 2)\
        .filter(lambda x: x == 4)\
        .get_or_else(None) is None

    assert Try.of(lambda x: x + 2, 2)\
        .filter(lambda x: x == 4)\
        .is_success is False

    assert Try.of(lambda x: x + 2, 2)\
        .filter(lambda x: x == 4)\
        .get() == 4

    assert Try.of(lambda x: x + 2, 2)\
        .filter(lambda x: x == 4)\
        .value == 4

    assert Try.of(lambda x: x + 2, 2)\
        .filter(lambda x: x == 4)\
        == Try(4, False)

# Generated at 2022-06-12 05:31:05.597396
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try('2', True).filter(lambda x: x.isalpha()) == Try('2', True)
    assert Try('2', True).filter(lambda x: x.isdigit()) == Try('2', False)
    assert Try('2', False).filter(lambda x: x.isdigit()) == Try('2', False)



# Generated at 2022-06-12 05:31:11.427572
# Unit test for method filter of class Try
def test_Try_filter():
    def add(a, b):
        return a + b

    def divide(a, b):
        if b == 0:
            raise RuntimeError('Division by zero')
        return a / b

    def test_mapper(a):
        return a ** 2

    def test_binder(a):
        return Try.of(add, a, a)

    def test_filterer(a):
        return True if a % 2 == 0 else False

    def test_success_callback(a):
        print('Success!')

    def test_fail_callback(a):
        print('Fail!')

    t = Try.of(divide, 2, 0).filter(test_filterer)
    assert t == Try(Exception('Division by zero'), False)


# Generated at 2022-06-12 05:31:20.151082
# Unit test for method filter of class Try
def test_Try_filter():
    assert_that(
        Try('othervalue', False).filter(lambda x: False),
        equal_to(Try('othervalue', False))
    )
    assert_that(
        Try('value', False).filter(lambda x: True),
        equal_to(Try('value', False))
    )
    assert_that(
        Try('value', True).filter(lambda x: False),
        equal_to(Try('value', False))
    )
    assert_that(
        Try('value', True).filter(lambda x: True),
        equal_to(Try('value', True))
    )

# Generated at 2022-06-12 05:31:24.246009
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(4, True).filter(lambda x: x >= 5) == Try(4, False)
    assert Try(5, True).filter(lambda x: x >= 5) == Try(5, True)

# Generated at 2022-06-12 05:31:55.055126
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value < 10

    assert Try(5, True).filter(filterer).get() == 5
    assert Try(5, True).filter(filterer).is_success is True
    assert Try(5, False).filter(filterer).get() == 5
    assert Try(5, False).filter(filterer).is_success is False

    assert Try(15, True).filter(filterer).get() == 15
    assert Try(15, True).filter(filterer).is_success is False
    assert Try(15, False).filter(filterer).get() == 15
    assert Try(15, False).filter(filterer).is_success is False


# Generated at 2022-06-12 05:32:02.299943
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)
    assert Try(Exception, False).filter(lambda x: x == Exception) == Try(Exception, False)


# Generated at 2022-06-12 05:32:13.311455
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """
    def success_filterer(value):
        """
        Filterer which returns value
        """
        return value

    def failed_filterer(value):
        """
        Filterer which returns None
        """
        return None

    # case 1
    assert Try(10, True)\
        .filter(success_filterer)\
        .get_or_else(None) == 10

    # case 2
    assert Try(10, True)\
        .filter(failed_filterer)\
        .get_or_else(None) is None

    # case 3
    assert Try(None, False)\
        .filter(success_filterer)\
        .get_or_else(None) is None


# Generated at 2022-06-12 05:32:19.968426
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try

    """
    assert Try(10, True)\
        .filter(lambda value: value > 5)\
        == Try(10, True)
    assert Try(10, True)\
        .filter(lambda value: value < 5)\
        == Try(10, False)
    assert Try(10, False)\
        .filter(lambda value: value < 5)\
        == Try(10, False)

# Generated at 2022-06-12 05:32:30.928771
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully monad
    assert Try.of(lambda x: '{}+2'.format(x), '1').filter(lambda x: int(x) > 0)\
        == Try('1+2', True)

    # not successfully monad
    assert Try.of(lambda x: '{}+2'.format(x), '1').filter(lambda x: int(x) == 0)\
        == Try('1+2', False)

    # Fail because raise exception
    assert Try.of(lambda x: '{}/0'.format(x), '1').filter(lambda x: int(x) == 0)\
        == Try(ZeroDivisionError("division by zero"), False)



# Generated at 2022-06-12 05:32:41.430277
# Unit test for method filter of class Try
def test_Try_filter():
    def throw_exception():
        raise Exception()

    try_success_true = Try.of(int, '10')
    try_success_false = Try.of(int, 'a')
    try_fail = Try.of(throw_exception)

    assert try_success_true.filter(lambda v: v % 2 == 0) == Try(10, True)
    assert try_success_true.filter(lambda v: v % 2 != 0) == Try(10, False)
    assert try_success_false.filter(lambda v: v % 2 == 0) == Try(10, False)
    assert try_success_false.filter(lambda v: v % 2 != 0) == Try(10, False)
    assert try_fail.filter(lambda v: v % 2 == 0) == Try(Exception(), False)
    assert try_

# Generated at 2022-06-12 05:32:45.352566
# Unit test for method filter of class Try
def test_Try_filter():
    value = 'def'
    not_success_value = 'abc'
    not_success_Try = Try(not_success_value, False)
    success_Try = Try(value, True)

    def is_equals(char):
        return char == value

    assert not_success_Try.filter(is_equals) == Try(not_success_value, False)
    assert success_Try.filter(is_equals) == Try(value, True)
    assert success_Try.filter(is_equals) == Try(not_success_value, False)


# Generated at 2022-06-12 05:32:52.719312
# Unit test for method filter of class Try
def test_Try_filter():
    def fn(x): return x
    try_1 = Try.of(fn, 1)
    try_2 = Try.of(Exception, 'error')

    def filter_even_number(value):
        if value % 2 == 0:
            return True
        return False

    assert try_1.filter(filter_even_number) == Try(1, True)
    assert try_2.filter(filter_even_number) == Try('error', False)


# Generated at 2022-06-12 05:33:04.287309
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """
    def is_number(value):
        return type(value) == int

    def is_string(value):
        return type(value) == str

    def raise_exception():
        _ = 1/0

    t0 = Try.of(raise_exception)
    assert t0.filter(is_number) == Try(ZeroDivisionError(), False)

    t1 = Try.of(lambda: 1)
    assert t1.filter(is_number) == Try(1, True)
    assert t1.filter(is_string) == Try(1, False)

    t2 = Try.of(lambda: 'hello')
    assert t2.filter(is_number) == Try('hello', False)

# Generated at 2022-06-12 05:33:09.234061
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x % 2 == 0) == Try(10, True)
    assert Try(10, True).filter(lambda x: x % 2 == 1) == Try(10, False)
    assert Try(10, False).filter(lambda x: x % 2 == 1) == Try(10, False)
