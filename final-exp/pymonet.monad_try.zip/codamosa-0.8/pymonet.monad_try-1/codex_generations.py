

# Generated at 2022-06-12 05:23:52.978048
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """

    # When monad is successfully and filter returns True,
    # method filter should return copy of monad
    assert\
        Try.of(lambda x: x, 4)\
        .filter(lambda x: x > 0)\
        == Try(4, True)

    # When monad is successfully and filter returns False,
    # method filter should return not successfully monad
    assert\
        Try.of(lambda x: x, 4)\
        .filter(lambda x: x > 5)\
        == Try(4, False)

# Generated at 2022-06-12 05:23:58.329614
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0
    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-12 05:24:06.040335
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        # Case when value is equals 'success'
        if value == 'success':
            return True
        # Case when value is not equals 'success'
        else:
            return False

    # Case when filter is called on successfully Try with 'success' value.
    assert Try(None, True).filter(filterer).is_success == True

    # Case when filter is called on not successfully Try with 'success' value.
    assert Try(None, False).filter(filterer).is_success == False

    # Case when filter is called on successfully Try with not 'success' value.
    assert Try('not_success', True).filter(filterer).is_success == False

    # Case when filter is called on not successfully Try with not 'success' value.

# Generated at 2022-06-12 05:24:16.761434
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(6, True).filter(lambda x: True) == Try(6, True)
    assert Try(6, True).filter(lambda x: False) == Try(6, False)
    assert Try(6, True).filter(lambda x: x == 6) == Try(6, True)
    assert Try(6, True).filter(lambda x: x == 7) == Try(6, False)
    assert Try(6, False).filter(lambda x: True) == Try(6, False)
    assert Try(6, False).filter(lambda x: False) == Try(6, False)
    assert Try(6, False).filter(lambda x: x == 6) == Try(6, False)
    assert Try(6, False).filter(lambda x: x == 7) == Try(6, False)


# Generated at 2022-06-12 05:24:24.586105
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    def filterer(value):
        return value == 'EXCEPTION'
    try_success = Try('EXCEPTION', True)
    try_fail = Try('EXCEPTION', False)

    # When
    try_success_filtered = try_success.filter(filterer)
    try_fail_filtered = try_fail.filter(filterer)

    # Then
    assert try_success_filtered.is_success == True
    assert try_success_filtered.value == 'EXCEPTION'
    assert try_fail_filtered.is_success == False
    assert try_fail_filtered.value == 'EXCEPTION'


# Generated at 2022-06-12 05:24:32.715295
# Unit test for method filter of class Try
def test_Try_filter():
    success_value = True
    expect_value = True
    def filterer(value):
        return value

    def assert_fun(value):
        assert value == expect_value

    try_monad = Try.of(lambda: success_value, ())
    try_monad \
        .filter(filterer) \
        .on_success(assert_fun)
    assert_fun(try_monad.get_or_else(False))

    success_value = False
    expect_value = False
    try_monad = Try.of(lambda: success_value, ())
    try_monad \
        .filter(filterer) \
        .on_success(assert_fun)
    assert_fun(try_monad.get_or_else(True))


# Generated at 2022-06-12 05:24:36.934883
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """
    assert Try(2, True).filter(lambda x : x % 2 == 0) == Try(2, True)
    assert Try(3, True).filter(lambda x : x % 2 == 0) == Try(3, False)


# Generated at 2022-06-12 05:24:42.093243
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x): return x > 10
    assert(Try(8, True).filter(filterer) == Try(8, False))
    assert(Try(11, True).filter(filterer) == Try(11, True))


# Generated at 2022-06-12 05:24:49.768797
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda v: v > 3) == Try(5, True)
    assert Try(1, True).filter(lambda v: v > 3) == Try(1, False)
    assert Try(5, False).filter(lambda v: v > 3) == Try(5, False)
    assert Try('test', True).filter(lambda v: v != 'test') == Try('test', False)
    assert Try('test', True).filter(lambda v: v == 'test') == Try('test', True)


# Generated at 2022-06-12 05:25:01.971467
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'a').filter(lambda a: a == 'a') == Try.of(lambda: 'a')
    assert Try.of(lambda: 'a').filter(lambda a: a == 'b') == Try('b', False)
    assert not Try.of(lambda: 'a').filter(lambda a: a == 'b')
    assert not Try.of(lambda: 'a').filter(lambda a: a == 'b').is_success
    assert Try.of(lambda: 'a').filter(lambda a: a == 'b').get() == 'b'
    assert Try.of(lambda: 'a').filter(lambda a: a == 'b').get_or_else('c') == 'c'

# Generated at 2022-06-12 05:25:16.181106
# Unit test for method filter of class Try
def test_Try_filter():
    is_even = lambda v: v%2 == 0
    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(2, False).filter(is_even) == Try(2, False)
    assert Try(3, True).filter(is_even) == Try(3, False)


# Generated at 2022-06-12 05:25:21.572079
# Unit test for method filter of class Try
def test_Try_filter():
    fail_try = Try(ValueError('ArithmeticError'), False)
    assert fail_try.filter(lambda val: False == True) == Try(
        ValueError('ArithmeticError'), False)

    success_try = Try(1, True)
    assert success_try.filter(lambda val: val == 1) == Try(1, True)

    assert success_try.filter(lambda val: val == 2) == Try(
        1, False)


# Generated at 2022-06-12 05:25:27.759762
# Unit test for method filter of class Try
def test_Try_filter():
    try_monad = Try(1, True)
    try_monad2 = Try(2, True)
    try_monad3 = Try(3, False)

    assert try_monad.filter(lambda x: x < 10) == Try(1, True)
    assert try_monad.filter(lambda x: x == 10) == Try(1, False)
    assert try_monad2.filter(lambda x: x == 10) == Try(2, False)
    assert try_monad3.filter(lambda x: x == 10) == Try(3, False)



# Generated at 2022-06-12 05:25:30.918715
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.
    """
    assert Try.of(lambda: 1, ()).filter(lambda x: x < 10).get() == 1
    assert Try.of(lambda: 1, ()).filter(lambda x: x > 10).is_success is False
    assert Try.of(lambda: 1, ()).filter(lambda x: x > 10).get() == 1



# Generated at 2022-06-12 05:25:37.986429
# Unit test for method filter of class Try
def test_Try_filter():

    # When Try is not successfully
    t = Try.of(lambda: 'a').filter(lambda x: len(x) > 1)

    assert not t.is_success

    # When Try is successfully and filterer returns True
    t = Try.of(lambda: 'a').filter(lambda x: len(x) == 1)

    assert t.is_success

    # When Try is successfully and filterer returns False
    t = Try.of(lambda: 'a').filter(lambda x: len(x) < 1)

    assert not t.is_success

# Generated at 2022-06-12 05:25:49.562413
# Unit test for method filter of class Try
def test_Try_filter():
    print('\n##### UNIT TEST FOR METHOD filter() OF CLASS Try')

    def filterer(x):
        return x >= 5

    def filterer_zero(x):
        return x == 0

    try:
        assert Try(10, True).filter(filterer) == Try(10, True)
        assert Try(10, True).filter(filterer_zero) == Try(10, False)
        assert Try(4, True).filter(filterer) == Try(4, False)
        assert Try(4, True).filter(filterer_zero) == Try(4, False)

        print('OK!')
    except AssertionError as error:  # pragma: no cover
        print('FAILED!')
        print(error)



# Generated at 2022-06-12 05:25:54.997612
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def fun_filter(x):
        return x % 2 == 0

    def fun(value):
        return value

    def fun_raise_exception():
        raise Exception('Some error')

    assert Try.of(fun, 2).filter(fun_filter) == Try(2, True)
    assert Try.of(fun_raise_exception).filter(fun_filter) == Try(Exception('Some error'), False)



# Generated at 2022-06-12 05:26:05.707716
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1') == Try(1, True) # type: ignore
    assert Try.of(int, '12') == Try(12, True) # type: ignore
    assert Try.of(int, 'a') != Try(1, True) # type: ignore
    assert Try.of(int, 'a').value != TypeError
    assert Try.of(int, 'a') == Try(ValueError(), False)
    assert Try.of(int, 'a').is_success == False

    def successfully_mapper(value: int) -> int:
        return value

    def successfully_on_success(value: int) -> None:
        assert value == 1

    def successfully_binder(value: int) -> Try[int]:
        return Try(value, True)


# Generated at 2022-06-12 05:26:12.095857
# Unit test for method filter of class Try
def test_Try_filter():
    try1 = Try(1, True)
    try2 = Try(None, False)
    def filter_func(a):
        return a == 1

    # Success monad
    assert try1.filter(filter_func) == Try(1, True)
    assert try1.filter(filter_func).value == 1

    # Othercase monad
    assert try2.filter(filter_func) == Try(None, False)



# Generated at 2022-06-12 05:26:21.112736
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.

    :returns: Nothing
    :rtype: None
    """
    def foo():
        raise Exception('test')

    def bar():
        return 1

    def baz(x):
        return x > 0

    def qux(x):
        return x < 0

    # Successfully Try and successful filter
    assert Try.of(bar).filter(baz) == Try(1, True)

    # Successfully Try and unsuccessful filter
    assert Try.of(bar).filter(qux) == Try(1, False)

    # Not successfully Try and successful filter
    assert Try.of(foo).filter(baz) == Try('test', False)

    # Not successfully Try and unsuccessful filter
    assert Try.of(foo).filter(qux) == Try('test', False)

# Generated at 2022-06-12 05:26:39.318068
# Unit test for method filter of class Try
def test_Try_filter():
    try_success = Try(2, True)
    try_not_success = Try(1, False)

    assert try_success.filter(lambda x: True) == Try(2, True)
    assert try_success.filter(lambda x: False) == Try(2, False)
    assert try_not_success.filter(lambda x: True) == Try(1, False)
    assert try_not_success.filter(lambda x: False) == Try(1, False)
    assert Try.of(lambda: 2, ).filter(lambda x: 1 < x) == Try(2, True)
    assert Try.of(lambda: 2, ).filter(lambda x: 1 > x) == Try(2, False)
    assert Try.of(lambda: 2, ).filter(lambda x: 1/0).is_success == False
    assert Try

# Generated at 2022-06-12 05:26:50.263093
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test case for method filter of class Try

    When successfully Try pass filter test,
    method filter must return copy of monad,
    othercase returns not successfully Try with previous monad value.

    :returns: None
    :rtype: None
    """
    try:
        assert Try(6, True).filter(lambda x: x == 6) == Try(6, True)
    except AssertionError:
        print("When successfully Try pass filter test, method filter must return copy of monad, othercase returns not successfully Try with previous monad value.")
        return


# Generated at 2022-06-12 05:26:56.308029
# Unit test for method filter of class Try
def test_Try_filter():
    try:
        assert Try(1, True).filter(lambda v: v > 0) == Try(1, True)
        assert Try(1, True).filter(lambda v: v < 0) == Try(1, False)
        assert Try(Exception("test"), False).filter(lambda v: v == "test") == Try(Exception("test"), False)
    except AssertionError:  # pragma: no cover
        raise AssertionError("test_Try_filter is failed")



# Generated at 2022-06-12 05:27:02.011517
# Unit test for method filter of class Try
def test_Try_filter():
    # Try[value=10, is_success=True]
    try10 = Try.of(lambda: 10)

    def filterer(value):
        return value > 2

    def not_filterer(value):
        return value < 9

    # Try[value=10, is_success=True]
    result = try10.filter(filterer)
    assert result == Try(10, True)

    # Try[value=10, is_success=False]
    result = try10.filter(not_filterer)
    assert result == Try(10, False)

# Generated at 2022-06-12 05:27:08.931518
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(n):
        return n % 2 == 0

    def test1():
        return Try.of(lambda a: a, 1).filter(is_even)

    def test2():
        return Try.of(lambda a: a, 2).filter(is_even)

    assert test1() == Try(1, False)
    assert test2() == Try(2, True)



# Generated at 2022-06-12 05:27:11.674496
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(v):
        return v == 1
    try_ = Try(1, True)
    assert try_.filter(filterer) == Try(1, True)
    try_ = Try(2, True)
    assert try_.filter(filterer) == Try(2, False)


# Generated at 2022-06-12 05:27:17.142355
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_1(v):
        if v == 1:
            return True
        return False
    try_1 = Try(1, True)
    try_2 = Try(2, True)
    assert try_1 == try_1.filter(filter_1)
    assert Try(2, False) == try_2.filter(filter_1)

if __name__ == '__main__':
    test_Try_filter()

# Generated at 2022-06-12 05:27:22.739133
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(4, True).filter(lambda x: x > 3) == Try(4, True)
    assert Try(3, True).filter(lambda x: x > 3) == Try(3, False)
    assert Try(3, False).filter(lambda x: x > 3) == Try(3, False)


# Generated at 2022-06-12 05:27:28.651740
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 0, )\
        .map(lambda x: x + 1)\
        .filter(lambda x: x > 0)\
        .get() == 1

    assert Try.of(lambda: 0, )\
        .map(lambda x: x - 1)\
        .filter(lambda x: x > 0)\
        .get() == 0

    assert Try.of(lambda: raise_exception(Exception('test')), )\
        .map(lambda x: x - 1)\
        .filter(lambda x: x > 0)\
        .is_success == False


# Generated at 2022-06-12 05:27:38.330261
# Unit test for method filter of class Try
def test_Try_filter():
    initialize_tests()
    lst = [[1, 2, 3], [], [1, 2], [], [1], [1, 2, 3], []]
    lst_map = map(lambda x: Try.of(lambda y: len(y), x), lst)
    lst_filter = map(lambda x: x.filter(lambda y: y > 2), lst_map)
    assert Try.of(lambda x: len(x), [1, 2, 3]) == try_of_lambda_x(lst[0])
    assert try_of_lambda_x(lst[1]).filter(lambda x: x > 2) == Try(0, False)
    assert try_of_lambda_x(lst[2]).filter(lambda x: x > 2) == Try(0, False)
    assert try_of

# Generated at 2022-06-12 05:27:53.930436
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 3

    try_1 = Try.of(lambda: 3, ())
    try_2 = Try.of(lambda: 3, ())

    result = try_1.filter(filterer)

    if result != try_2:
        raise Exception("Expected {}, got {}".format(try_2, result))



# Generated at 2022-06-12 05:28:00.975993
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value % 2 == 0

    result_1 = Try(4, True).filter(filterer)
    result_2 = Try(3, True).filter(filterer)
    result_3 = Try(3, False).filter(filterer)

    assert result_1 == Try(4, True)
    assert result_2 == Try(3, False)
    assert result_3 == Try(3, False)


# Generated at 2022-06-12 05:28:09.969324
# Unit test for method filter of class Try
def test_Try_filter():
    def non_negative_filter(value: int) -> bool:
        return value >= 0

    assert Try(0, True).filter(non_negative_filter) == Try(0, True)
    assert Try(1, True).filter(non_negative_filter) == Try(1, True)
    assert Try(0, False).filter(non_negative_filter) == Try(0, False)
    assert Try(-1, True).filter(non_negative_filter) == Try(-1, False)
    assert Try(-1, False).filter(non_negative_filter) == Try(-1, False)


# Generated at 2022-06-12 05:28:17.371780
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def add_two(x: int) -> int:
        return x + 2

    def is_number(x: object) -> bool:
        return isinstance(x, int)

    assert Try.of(add_two, 1).filter(is_number) == Try(3, True)
    assert Try.of(add_two, '1').filter(is_number) == Try('1', False)



# Generated at 2022-06-12 05:28:22.858533
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value): return value % 2 == 0
    try_ = Try(2, True)
    assert try_.filter(filterer) == Try(2, True)
    try_ = Try(1, True)
    assert try_.filter(filterer) == Try(1, False)
    try_ = Try(2, False)
    assert try_.filter(filterer) == Try(2, False)


# Generated at 2022-06-12 05:28:30.242171
# Unit test for method filter of class Try
def test_Try_filter():
    x = Try.of(lambda: 10)
    assert x == x.filter(lambda x: x < 15)

    x = Try.of(lambda: 10)
    assert x != x.filter(lambda x: x > 15)

    x = Try.of(lambda: 10 / 0)
    assert x == x.filter(lambda x: x < 15)

    y = Try.of(lambda: 10)
    assert y == y.filter(lambda x: x < 15)

    y = Try.of(lambda: 10)
    assert y != y.filter(lambda x: x > 15)

    y = Try.of(lambda: 10 / 0)
    assert y != y.filter(lambda x: x > 15)


# Generated at 2022-06-12 05:28:36.381432
# Unit test for method filter of class Try
def test_Try_filter():
    a = Try(1, True)
    b = Try(Exception('Exception occured'), False)

    assert a.filter(lambda v: v > 0) == Try(1, True)
    assert a.filter(lambda v: v < 0) == Try(1, False)
    assert b.filter(lambda v: v > 0) == Try(Exception('Exception occured'), False)


# Generated at 2022-06-12 05:28:43.696338
# Unit test for method filter of class Try
def test_Try_filter():
    test_filterer = lambda x: x < 10
    test_value = 5
    result = Try(test_value, True).filter(test_filterer)
    assert result == Try(test_value, True)

    test_value = 20
    result = Try(test_value, True).filter(test_filterer)
    assert result == Try(test_value, False)

    result = Try(test_value, False).filter(test_filterer)
    assert result == Try(test_value, False)


# Generated at 2022-06-12 05:28:49.331386
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Method filter returns successfully Try when filterer returns True.
    And returns not successfully Try when filterer returns False.

    """
    def filterer_true(value):
        return value == 1

    def filterer_false(value):
        return value == 2

    assert Try(1, True).filter(filterer_true) == Try(1, True)
    assert Try(2, True).filter(filterer_false) == Try(2, False)
    assert Try(1, False).filter(filterer_true) == Try(1, False)
    assert Try(2, False).filter(filterer_false) == Try(2, False)



# Generated at 2022-06-12 05:28:55.042687
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(7, True).filter(lambda a: a % 2 == 1) == Try(7, True)
    assert Try(8, True).filter(lambda a: a % 2 == 1) == Try(8, False)
    assert Try('exception', False).filter(lambda a: a % 2 == 1) == Try('exception', False)



# Generated at 2022-06-12 05:29:13.300271
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x % 2 == 0

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, True)



# Generated at 2022-06-12 05:29:21.413985
# Unit test for method filter of class Try
def test_Try_filter():
    try_value = Try(10, True)
    try_value_filtered_less_20 = try_value.filter(lambda x: x < 20)
    try_value_filtered_greater_20 = try_value.filter(lambda x: x > 20)

    failed_try = Try(RuntimeError('Some error'), False)
    failed_try_filtered_less_20 = failed_try.filter(lambda x: x < 20)
    failed_try_filtered_greater_20 = failed_try.filter(lambda x: x > 20)

    assert try_value_filtered_less_20 == Try(10, True)
    assert try_value_filtered_greater_20 == Try(10, False)
    assert failed_try_filtered_less_20 == Try(RuntimeError('Some error'), False)


# Generated at 2022-06-12 05:29:27.882526
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, True).filter(lambda x: True) == Try(None, True)
    assert Try(None, True).filter(lambda x: False) == Try(None, False)
    assert Try(None, False).filter(lambda x: True) == Try(None, False)
    assert Try(None, False).filter(lambda x: False) == Try(None, False)

# Generated at 2022-06-12 05:29:31.701385
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    try_ = Try('123', True)
    assert try_.filter(lambda x: x.isdigit()) == Try('123', True)
    assert try_.filter(lambda x: x.isalpha()) == Try('123', False)



# Generated at 2022-06-12 05:29:40.605411
# Unit test for method filter of class Try
def test_Try_filter():
    def success_filterer(value):
        return False

    def fail_filterer(value):
        raise Exception('fail_filterer raises Exception')

    try_value = Try(1, True)
    assert try_value.filter(success_filterer) == Try(1, False)
    assert Try.of(Try, success_filterer, try_value.value).filter(success_filterer) == Try(1, False)

    try_value = Try(1, True)
    assert Try.of(Try, fail_filterer, try_value.value).filter(success_filterer) == Try(Exception('fail_filterer raises Exception'), False)

    try_value = Try(1, False)
    assert try_value.filter(success_filterer) == Try(1, False)


# Generated at 2022-06-12 05:29:46.196139
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        if value >= 0:
            return True
        return False
    try_1 = Try.of(lambda: 8).filter(filterer)
    try_2 = Try.of(lambda: -1).filter(filterer)
    assert try_1.is_success == True
    assert try_2.is_success == False

# Generated at 2022-06-12 05:29:50.907219
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(50, True).filter(lambda n: n > 10) == Try(50, True)
    assert Try(3, True).filter(lambda n: n > 10) == Try(3, False)
    assert Try(3, False).filter(lambda n: n > 10) == Try(3, False)


# Generated at 2022-06-12 05:29:56.466937
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Compare result of method Try::filter with expected data.
    """
    #successful Try with given value
    try_with_value = Try(100, True)

    #successful Try with given value
    try_without_value = Try(100, False)

    print('test for successful Try without filtered value')
    assert try_with_value.filter(lambda x: x >= 200) == Try(100, False)
    print('success')

    print('test for successful Try with filtered value')
    assert try_with_value.filter(lambda x: x < 200) == Try(100, True)
    print('success')

    print('test for not successful Try')
    assert try_without_value.filter(lambda x: x >= 200) == Try(100, False)
    print('success')


# Generated at 2022-06-12 05:30:02.139132
# Unit test for method filter of class Try
def test_Try_filter():
    def add(x, y):
        return x + y
    fn = lambda x, y: add(x, y)

    result = Try(add(2, 3), True).filter(lambda x: True).get()
    assert result == 5

    result = Try(fn(2, 3), True).filter(lambda x: False).get()
    assert result == None


# Generated at 2022-06-12 05:30:11.959300
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def test_filter1():
        try:
            assert Try.of(lambda x: x + 1, 2).filter(\
                lambda x: x > 10)\
                == Try(None, False)
        except Exception:
            return 'Try.of().filter() failed #1'
    def test_filter2():
        try:
            assert Try.of(lambda: None, 2).filter(\
                lambda x: x > 10)\
                == Try(None, False)
        except Exception:
            return 'Try.of().filter() failed #2'

# Generated at 2022-06-12 05:30:32.667223
# Unit test for method filter of class Try
def test_Try_filter():
    # when unit test is false
    test_value = 0
    try_value = Try(test_value, True)
    try_value = try_value.filter(lambda val: val > 0)
    assert try_value == Try(test_value, False)

    # when unit test is true
    true_value = 1
    try_value = Try(true_value, True)
    try_value = try_value.filter(lambda val: val > 0)
    assert try_value == Try(true_value, True)



# Generated at 2022-06-12 05:30:38.926480
# Unit test for method filter of class Try
def test_Try_filter():
    # This test case is successfully
    mocked_Try_success = Try(True, True)
    mocked_filterer = lambda x: x
    assert mocked_Try_success.filter(mocked_filterer) == Try(True, True)
    # This test case is not successfully
    mocked_Try_fail = Try(False, True)
    assert mocked_Try_fail.filter(mocked_filterer) == Try(False, False)

# Generated at 2022-06-12 05:30:45.706230
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: x)\
        == Try(True, True)

    assert Try(True, True).filter(lambda x: not x)\
        == Try(True, False)

    assert Try(True, False).filter(lambda x: x)\
        == Try(True, False)

    assert Try(True, False).filter(lambda x: not x)\
        == Try(True, False)


# Generated at 2022-06-12 05:30:54.367514
# Unit test for method filter of class Try
def test_Try_filter():
    # monad is successfully
    assert Try\
        .of(int, '123')\
        .filter(lambda x: x > 100)\
        == Try(123, True)
    # monad is not successfully
    assert Try\
        .of(float, '123')\
        .filter(lambda x: x > 100)\
        == Try(ValueError('could not convert string to float: \'123\''), False)
    # monad is successfully, but filterer applied to value returns False
    assert Try\
        .of(int, '10')\
        .filter(lambda x: x > 100)\
        == Try(10, False)


# Generated at 2022-06-12 05:30:58.795947
# Unit test for method filter of class Try
def test_Try_filter():
    success = Try.of(lambda: 'value', None)
    no_success = Try.of(lambda: 'value', None)

    assert success.filter(lambda value: True).is_success
    assert not no_success.filter(lambda value: True).is_success

# Generated at 2022-06-12 05:31:03.878451
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x):
        return x > 0

    assert(Try(1, True).filter(filterer) == Try(1, True))
    assert(Try(-1, True).filter(filterer) == Try(-1, False))
    assert(Try(-2, False).filter(filterer) == Try(-2, False))



# Generated at 2022-06-12 05:31:08.273896
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True).filter(lambda x: x > 0) == Try(3, True)
    assert Try(3, True).filter(lambda x: x < 0) == Try(3, False)
    assert Try(3, False).filter(lambda x: x > 0) == Try(3, False)


# Generated at 2022-06-12 05:31:19.713264
# Unit test for method filter of class Try
def test_Try_filter():
    def case_1():
        try_1 = Try(5, True)
        try_2 = try_1.filter(lambda i: True)
        assert try_1 == try_2
        assert try_1.value == 5
        assert try_1.is_success == True

    def case_2():
        try_1 = Try(5, True)
        try_2 = try_1.filter(lambda i: False)
        assert try_1.value == 5
        assert try_1.is_success == True
        assert try_2.value == 5
        assert try_2.is_success == False

    def case_3():
        try_1 = Try(5, False)
        try_2 = try_1.filter(lambda i: True)
        assert try_1 == try_2
        assert try_1

# Generated at 2022-06-12 05:31:27.372791
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, True).filter(lambda x: x == 2) != Try(2, False)


# Generated at 2022-06-12 05:31:31.690797
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def func(a, b):
        return a + b

    def filterer(a):
        return a % 2 == 0

    assert Try.of(func, 1, 2) == Try.of(func, 1, 2).filter(filterer)
    assert Try.of(func, 2, 3) != Try.of(func, 2, 3).filter(filterer)



# Generated at 2022-06-12 05:31:56.703588
# Unit test for method filter of class Try
def test_Try_filter():
    less_0 = lambda x: x < 0
    more_0 = lambda x: x > 0
    empty = lambda x: x == 0

    # return new Try because -10 filtered to True
    assert Try.of(lambda: -10).filter(less_0) == Try(-10, True)

    # return copy of self because -10 not filtered to True
    assert Try.of(lambda: -10).filter(more_0) == Try(-10, False)

    # return new Try because 0 filtered to True
    assert Try.of(lambda: 0).filter(empty) == Try(0, True)

    # return copy of self because 0 not filtered to True
    assert Try.of(lambda: 0).filter(more_0) == Try(0, False)

    # return copy of self because 10 not filtered to True

# Generated at 2022-06-12 05:32:02.913075
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> test_Try_filter().assert_success_equals(True)
    >>> test_Try_filter().assert_not_success_equals(False)
    """
    def f(arg):
        return True if arg else False

    def positive(arg):
        return arg > 0
    return Try(7, True).filter(positive)\
        .assert_success_equals(True)\
        .assert_not_success_equals(False)

# Generated at 2022-06-12 05:32:07.826543
# Unit test for method filter of class Try
def test_Try_filter():
    def f(x): return x > 10

    assert Try(10, True).filter(f) == Try(10, False)
    assert Try(20, True).filter(f) == Try(20, True)



# Generated at 2022-06-12 05:32:13.500059
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '5').filter(lambda i: i > 0) == Try(5, True)
    assert Try.of(int, '5').filter(lambda i: i < 0) == Try(5, False)
    assert Try.of(int, 'qwerty').filter(lambda i: i > 0) == Try('qwerty', False)
    assert Try.of(int, 'qwerty').filter(lambda i: i < 0) == Try('qwerty', False)



# Generated at 2022-06-12 05:32:21.456875
# Unit test for method filter of class Try
def test_Try_filter():
    try_value_1 = Try.of(int, '12')
    try_value_2 = Try.of(int, '12')
    try_value_3 = Try.of(int, '1a')

    assert try_value_1.filter(lambda x: x == 12).get_or_else(-1) == 12
    assert try_value_2.filter(lambda x: x == 13).get_or_else(-1) == -1
    assert try_value_3.filter(lambda x: x == 12).get_or_else(-1) == -1



# Generated at 2022-06-12 05:32:28.963961
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try \
        .of(lambda x: x**2, 3) \
        .filter(lambda x: x % 2 == 0) \
        .is_success == False

    assert Try \
        .of(lambda x: x**2, 2) \
        .filter(lambda x: x % 2 == 0) \
        .is_success == True
# End unit test for method filter of class Try


# Generated at 2022-06-12 05:32:40.436146
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of class Try
    """

    def func_with_exception():
        """
        Function with exception
        """
        raise Exception('Exception occurred')

    def filterer_function(value):
        """
        Filtered function
        """
        return value == 1
    # Test with successful monad
    assert Try.of(lambda: 1, )\
        .filter(filterer_function)\
        .is_success == True
    # Test with not successful monad
    assert Try.of(lambda: 2, )\
        .filter(filterer_function)\
        .is_success == False
    # Test with exception monad
    assert Try.of(func_with_exception, )\
        .filter(filterer_function)\
        .is_success == False

# Unit test

# Generated at 2022-06-12 05:32:48.251561
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(2, True).filter(lambda x: x == 2) == Try(2, True)
    assert Try(2, True).filter(lambda x: x < 2) == Try(2, False)
    assert Try(2, False).filter(lambda x: x == 2) == Try(2, False)
    assert Try(2, False).filter(lambda x: x < 2) == Try(2, False)


# Generated at 2022-06-12 05:32:55.799534
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.
    """
    def _fail_filter(value):
        return True

    def _success_filter(value):
        return True

    def _exception_filter(value):
        raise Exception('exception')

    assert Try(1, True).filter(_fail_filter) == Try(1, False)
    assert Try(1, True).filter(_success_filter) == Try(1, True)
    assert Try(1, False).filter(_success_filter) == Try(1, False)

    with pytest.raises(Exception) as e:
        Try(1, True).filter(_exception_filter)
    assert 'exception' == str(e.value)

    assert Try(Exception('exception'), False).filter(_exception_filter) == Try(Exception('exception'), False)

# Generated at 2022-06-12 05:33:01.728497
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(5, True).filter(lambda x: x == 5) == Try(5, True)
    assert Try(5, True).filter(lambda x: x != 5) == Try(5, False)
    assert Try(5, False).filter(lambda x: x == 5) == Try(5, False)

