

# Generated at 2022-06-12 05:23:54.875083
# Unit test for method filter of class Try
def test_Try_filter():
    def _filter(x):
        if x == 1:
            return True
        return False

    assert Try(1, True).filter(_filter) == Try(1, True)
    assert Try(2, True).filter(_filter) == Try(2, False)
    assert Try(1, False).filter(_filter) == Try(1, False)
    assert Try(None, False).filter(_filter) == Try(None, False)


# Generated at 2022-06-12 05:23:58.530110
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-12 05:24:06.147034
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of class Try.

    :returns: pass the test or not
    :rtype: Boolean
    """
    # Test 1:
    result = Try.of(lambda: 1)\
        .filter(lambda x: x == 1)
    expected_result = Try(1, True)
    assert result == expected_result

    # Test 2:
    result = Try.of(lambda: 1)\
        .filter(lambda x: x == 2)
    expected_result = Try(1, False)
    assert result == expected_result

    # Test 3:
    result = Try.of(lambda: 1)\
        .filter(lambda x: x == 1)\
        .map(lambda x: x + 1)
    expected_result = Try(2, True)
    assert result == expected_result

    return True



# Generated at 2022-06-12 05:24:09.980614
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True).filter(lambda v: v % 2 == 0) == Try(3, False)
    assert Try(2, True).filter(lambda v: v % 2 == 0) == Try(2, True)


# Generated at 2022-06-12 05:24:16.911331
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda: 1).filter(lambda x: x > 10)
    try:
        assert(result.get_or_else(0) == 0)
        assert(not result.is_success)
    except AssertionError as e:  # pragma: no cover
        print(e)

    result = Try.of(lambda: 1).filter(lambda x: x <= 10)
    try:
        assert(result.get_or_else(0) == 1)
        assert(result.is_success)
    except AssertionError as e:  # pragma: no cover
        print(e)



# Generated at 2022-06-12 05:24:25.638591
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, ()).filter(lambda v: v > 0) == Try(1, True)
    assert Try.of(lambda: 2, ()).filter(lambda v: v % 2 == 0) == Try(2, True)
    assert Try.of(lambda: 1, ()).filter(lambda v: v < 0) == Try(1, False)
    assert Try.of(lambda: 0, ()).filter(lambda v: v % 2 == 0) == Try(0, True)
    assert Try.of(lambda: 1, ()).filter(lambda v: v % 2 == 0) == Try(1, False)
    assert Try.of(lambda: 0, ()).filter(lambda v: v > 0) == Try(0, False)

# Generated at 2022-06-12 05:24:30.416186
# Unit test for method filter of class Try
def test_Try_filter():
    # Positive
    assert Try.of(lambda: 'Test')\
        .filter(lambda value: value == 'Test')\
        .get() == 'Test'
    assert Try.of(lambda: 10)\
        .filter(lambda value: value > 0 and value < 11)\
        .get() == 10
    # Negatives
    assert Try.of(lambda: 'Test')\
        .filter(lambda value: value != 'Test')\
        .is_success == False
    assert Try.of(lambda: 10)\
        .filter(lambda value: value > 10)\
        .is_success == False

# Generated at 2022-06-12 05:24:36.190749
# Unit test for method filter of class Try
def test_Try_filter():
    def _filterer(value: str) -> bool:
        return value == '1'
    try_ = Try.of(int, '1')
    filtered_ = try_.filter(_filterer)
    assert filtered_.is_success
    try_ = Try.of(int, '2')
    filtered_ = try_.filter(_filterer)
    assert not filtered_.is_success


# Generated at 2022-06-12 05:24:48.657824
# Unit test for method filter of class Try
def test_Try_filter():
    # when filterer return False
    def filterer(x):
        return False

    # when filterer return True
    def filterer2(x):
        return True

    # returns (1, 2)
    p = Try(1, True)
    q = p.filter(filterer)
    assert q == Try(1, True)

    # returns (2, False)
    p = Try(1, False)
    q = p.filter(filterer)
    assert q == Try(1, False)

    # returns (2, True)
    p = Try(1, True)
    q = p.filter(filterer2)
    assert q == Try(1, False)

    # returns (1, False)
    p = Try(1, False)

# Generated at 2022-06-12 05:24:59.693881
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1+1).filter(lambda x: True) == Try(2, True)
    assert Try.of(lambda: 1+1).filter(lambda x: False) == Try(2, False)
    assert Try.of(lambda: 1+1).filter(lambda x: x >= 2) == Try(2, True)
    assert Try.of(lambda: 1+1).filter(lambda x: x > 2) == Try(2, False)
    assert Try.of(lambda: 1+1).filter(lambda x: x == 1) == Try(2, False)
    assert Try.of(lambda: 1/0).filter(lambda x: x > 2) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-12 05:25:07.761115
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 5)  == Try(10, True)
    assert Try(10, True).filter(lambda x: x > 15) == Try(10, False)
    assert Try(10, False).filter(lambda x: x > 5)  == Try(10, False)
    assert Try(10, False).filter(lambda x: x > 15) == Try(10, False)



# Generated at 2022-06-12 05:25:13.087882
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(n: int) -> bool:
        return n % 2 == 0
    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(1, True).filter(is_even) == Try(1, False)
    assert Try(2, False).filter(is_even) == Try(2, False)

# Generated at 2022-06-12 05:25:20.173664
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter.

    :retruns: no return value
    """
    assert Try.of(lambda: 10, ()).filter(lambda x: x == 10) == Try(10, True)
    assert Try.of(lambda: 10, ()).filter(lambda x: x == 5) == Try(10, False)
    assert Try.of(lambda: 10, ()).filter(lambda x: x == 25) == Try(10, False)



# Generated at 2022-06-12 05:25:28.450549
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """
    # Test when value is successfully and filterer returns True
    try_ = Try(42, True)
    new_try = try_.filter(lambda x: isinstance(x, int))
    assert new_try == Try(42, True)

    # Test when value is not successfully and filterer returns True
    try_ = Try(42, False)
    new_try = try_.filter(lambda x: isinstance(x, int))
    assert new_try == Try(42, False)

    # Test when value is successfully and filterer returns False
    try_ = Try(42, True)
    new_try = try_.filter(lambda x: isinstance(x, str))
    assert new_try == Try(42, False)

    # Test when value is not

# Generated at 2022-06-12 05:25:33.227633
# Unit test for method filter of class Try
def test_Try_filter():
    def func(val):
        if val == 5:
            return Try(val + 1, True)
        return Try(val + 1, False)

    def filterer(val):
        if val == 6:
            return True
        return False

    result = Try.of(func, 5).filter(filterer)
    assert result == Try(6, True)


# Generated at 2022-06-12 05:25:38.790907
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'Hello'
    # Fail filtering
    assert Try('Hi', True).filter(filterer) == Try('Hi', False)
    assert Try(Exception('Hi'), False).filter(filterer) == Try(Exception('Hi'), False)
    # Success filtering
    assert Try('Hello', True).filter(filterer) == Try('Hello', True)


# Generated at 2022-06-12 05:25:47.444527
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, False).filter(lambda x: x) == Try(None, False)
    assert Try(None, True).filter(lambda x: x) == Try(None, False)
    assert Try(None, True).filter(lambda x: not x) == Try(None, False)
    assert Try(True, True).filter(lambda x: x) == Try(True, True)
    assert Try(False, True).filter(lambda x: not x) == Try(False, True)
    assert Try(False, True).filter(lambda x: x) == Try(False, False)


# Generated at 2022-06-12 05:25:54.825022
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return True

    def filterer_fail(x):
        return False

    try_value = "value"
    assert Try(try_value, True).filter(filterer) == Try(try_value, True)
    assert Try(try_value, True).filter(filterer_fail) == Try(try_value, False)
    assert Try(try_value, False).filter(filterer) == Try(try_value, False)
    assert Try(try_value, False).filter(filterer) == Try(try_value, False)


# Generated at 2022-06-12 05:26:03.918784
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda a: a, 42).filter(lambda a: a % 2 == 0)\
        == Try(42, True)
    assert Try.of(lambda a: a, 43).filter(lambda a: a % 2 == 0)\
        == Try(43, False)
    assert Try.of(lambda a: a, 43)\
        .filter(lambda a: a % 2 == 0)\
        .on_success(lambda a: print('success', a))\
        .on_fail(lambda a: print('fail', a)) \
        == Try(43, False)


# Generated at 2022-06-12 05:26:14.564661
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # Given
    t1 = Try(1, True)
    t2 = Try(2, True)
    t3 = Try(3, True)
    f1 = Try(1, False)
    f2 = Try(2, False)
    f3 = Try(3, False)

    def positive_filter(value):
        return value >= 2

    # When

    # Then
    assert t1.filter(positive_filter) == Try(1, False)
    assert t2.filter(positive_filter) == Try(2, True)
    assert t3.filter(positive_filter) == Try(3, True)
    assert f1.filter(positive_filter) == Try(1, False)
    assert f2.filter(positive_filter) == Try(2, False)
    assert f3

# Generated at 2022-06-12 05:26:26.471150
# Unit test for method filter of class Try
def test_Try_filter():
    try_of_result = Try.of(lambda x: x ** 2, 2)
    try_filter_result = Try.of(lambda x: x ** 2, 2)\
        .filter(lambda x: x % 2 == 0)
    try_filter_not_result = Try.of(lambda x: x ** 2, 2)\
        .filter(lambda x: x % 2 != 0)

    assert try_filter_result == try_of_result
    assert try_filter_not_result.is_success == False



# Generated at 2022-06-12 05:26:33.366591
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)
    assert Try(5, True).filter(lambda x: x > 5) == Try(5, False)
    assert Try(10, False).filter(lambda x: x > 5) == Try(10, False)



# Generated at 2022-06-12 05:26:42.663868
# Unit test for method filter of class Try
def test_Try_filter():
    """
    [x for x in range(100) if x > 10 and x < 50]
    should return integers from range 11 to 50

    """
    result = Try.of(lambda x: x).filter(lambda x: x > 10)\
        .filter(lambda x: x < 50)
    assert not result.is_success
    result = Try.of(lambda x: x).filter(lambda x: x < 10)\
        .filter(lambda x: x < 50)
    assert not result.is_success
    result = Try.of(lambda x: x).filter(lambda x: x > 10)\
        .filter(lambda x: x > 50)
    assert not result.is_success


# Generated at 2022-06-12 05:26:48.202702
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test.
    """
    # 1
    try_1 = Try.of(lambda x: x + 1, 0)
    assert try_1.filter(lambda x: x == 1).value == 1

    # 2
    try_2 = Try.of(lambda x: x + 1, 0)
    assert try_2.filter(lambda x: x == 2).is_success is False


# Generated at 2022-06-12 05:26:54.250735
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x % 2 == 0) == Try(1, False)
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(3, True).bind(lambda x: Try(x + 2, True)).filter(lambda x: x % 2 == 0) == Try(5, False)
# End of unit test for method filter of class Try

# Generated at 2022-06-12 05:27:02.650180
# Unit test for method filter of class Try
def test_Try_filter():
    success_try = Try(5, True)
    fail_try = Try('error', False)
    try1 = Try.of(lambda: 5 + 5, 12)
    try2 = Try.of(lambda: 5 / 0, 12)
    try3 = Try.of(lambda: 5 / 2, 12)

    assert success_try.filter(lambda x: x < 10) == Try(5, True)
    assert fail_try.filter(lambda x: x < 10) == Try('error', False)
    assert try1.filter(lambda x: x < 10) == Try(10, True)
    assert try2.filter(lambda x: x < 10) == Try(ZeroDivisionError(), False)
    assert try3.filter(lambda x: x < 10) == Try(2.5, True)


# Generated at 2022-06-12 05:27:04.868464
# Unit test for method filter of class Try
def test_Try_filter():
    assert True == Try(True, True).filter(lambda x: not x).is_success
    assert False == Try(True, True).filter(lambda x: x).is_success
    assert False == Try(True, False).filter(lambda x: not x).is_success
    assert False == Try(True, False).filter(lambda x: x).is_success


# Generated at 2022-06-12 05:27:10.279143
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    def func_raise():
        raise ValueError('Try monad filter test')

    # WHEN
    try_monad = Try.of(func_raise)

    # THEN
    assert try_monad.filter(lambda x: True).is_success == False
    assert try_monad.filter(lambda x: False).is_success == False

# Generated at 2022-06-12 05:27:15.269474
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, '42').filter(lambda x: x == '42') == Try.of(lambda x: x, '42')
    assert Try.of(lambda x: x, '42').filter(lambda x: x != '42') != Try.of(lambda x: x, '42')


# Generated at 2022-06-12 05:27:25.697965
# Unit test for method filter of class Try
def test_Try_filter():
    """
    The test method tests the filter method of the Try class.
    """
    def filterer(x):
        return x < 5
    assert Try(3, True).filter(filterer) == Try(3, True)
    assert Try(3, True).filter(filterer).is_success
    assert Try(7, True).filter(filterer) == Try(7, False)
    assert not Try(7, True).filter(filterer).is_success
    assert Try(3, False).filter(filterer) == Try(3, False)
    assert not Try(3, False).filter(filterer).is_success



# Generated at 2022-06-12 05:27:35.819410
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    try_example = Try(1, True)
    assert try_example.filter(lambda x: x == 1) == Try(1, True)
    assert try_example.filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)



# Generated at 2022-06-12 05:27:40.716170
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x == 10) == Try(10, True)
    assert Try(10, True).filter(lambda x: x == 11) == Try(10, False)
    assert Try(10, False).filter(lambda x: x == 11) == Try(10, False)

# Generated at 2022-06-12 05:27:46.380331
# Unit test for method filter of class Try
def test_Try_filter():
    true_value = Try(10, True)
    assert true_value.filter(lambda x: x > 5) == Try(10, True)
    assert true_value.filter(lambda x: x > 15) == Try(10, False)

    false_value = Try(10, False)
    assert false_value.filter(lambda x: x > 5) == Try(10, False)
#

# Generated at 2022-06-12 05:27:50.576120
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x == 10) == Try(10, True)
    assert Try(10, True).filter(
        lambda x: x == 10).filter(lambda x: x == 10) == Try(10, True)


# Generated at 2022-06-12 05:27:58.367214
# Unit test for method filter of class Try
def test_Try_filter():
    # Test value not filter
    actual = Try.of(int, "hello")
    actual = actual.filter(lambda x: x == 10)

    assert not actual.is_success

    # Test value not filter
    actual = Try.of(int, "10")
    actual = actual.filter(lambda x: x == 10)

    assert actual.is_success

    # Test value not filter
    actual = Try.of(int, "10")
    actual = actual.filter(lambda x: x != 10)

    assert not actual.is_success


# Generated at 2022-06-12 05:28:03.142951
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Demonstrate testing filter method of class Try.
    """
    assert Try.of(lambda x: x, 2).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try.of(lambda x: x, 2).filter(lambda x: x > 10) == Try(2, False)


# Generated at 2022-06-12 05:28:09.587383
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(42, True)\
        .filter(lambda x: x % 2 == 0)\
        == Try(42, True)

    assert Try(42, True)\
        .filter(lambda x: x % 3 == 0)\
        == Try(42, False)

    assert Try(42, False)\
        .filter(lambda x: x % 2 == 0)\
        == Try(42, False)


# Generated at 2022-06-12 05:28:16.303250
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x: int) -> bool:
        return x >= 3

    t = Try(4, True)
    assert t.filter(filterer) == Try(4, True)
    t2 = Try(2, True)
    assert t2.filter(filterer) == Try(2, False)


# Generated at 2022-06-12 05:28:19.515734
# Unit test for method filter of class Try
def test_Try_filter():
    def is_odd(x):
        return x % 2 == 1

    assert Try.of(int, "0").filter(is_odd) == Try(0, False)
    assert Try.of(int, "1").filter(is_odd) == Try(1, True)


# Generated at 2022-06-12 05:28:26.546953
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(16, True).filter(lambda x: x % 2 == 0) == Try(16, True)
    assert Try(16, True).filter(lambda x: x % 2 != 0) == Try(16, False)
    assert Try(15, True).filter(lambda x: x % 2 == 0) == Try(15, False)
    assert Try(15, False).filter(lambda x: x % 2 == 0) == Try(15, False)


# Generated at 2022-06-12 05:28:41.582366
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return True if value % 2 == 0 else False

    try_one = Try.of(lambda: 1)
    try_two = Try.of(lambda: 2)
    assert try_one.filter(filterer) == Try(1, False)
    assert try_two.filter(filterer) == Try(2, True)



# Generated at 2022-06-12 05:28:49.047828
# Unit test for method filter of class Try
def test_Try_filter():
    class Person:
        def __init__(self, first_name, age):
            self.first_name = first_name
            self.age = age

        def __eq__(self, other):
            return isinstance(other, self.__class__)\
                and self.first_name == other.first_name\
                and self.age == other.age

    def is_old(person):
        return person.age > 50

    person_success_try = Try(Person('Mike', 55), True)
    person_not_success_try = Try(Person('Mike', 15), False)

    assert person_success_try.filter(is_old).get_or_else(None) == Person('Mike', 55)
    assert person_not_success_try.filter(is_old).get_or_else(None) is None

# Generated at 2022-06-12 05:28:58.863571
# Unit test for method filter of class Try
def test_Try_filter():
    value = 1
    try_type = Try(value, True)
    filter_value = filter(lambda x: x % 2 == 0, try_type)
    assert Filter(filter_value, True) is try_type

    filter_value = filter(lambda x: x % 2 == 1, try_type)
    assert Filter(filter_value, False) is try_type

    def filterer(value):
        raise Exception("any exception")
    filter_value = filter(filterer, Try(value, True))
    assert Filter(filter_value, False) is try_type

    filter_value = filter(filterer, Try(value, False))
    assert Filter(filter_value, False) is try_type


# Generated at 2022-06-12 05:29:07.096654
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda t: Try.of(lambda x: x + 1, t), 1).filter(lambda x: x > 1) == Try(2, True)
    assert Try.of(lambda t: Try.of(lambda x: x + 1, t), 1).filter(lambda x: x < 1) == Try(2, False)
    assert Try.of(lambda t: Try.of(lambda x: x + 1, t), 1).filter(lambda x: x < 1).get() == 2


# Generated at 2022-06-12 05:29:18.302278
# Unit test for method filter of class Try
def test_Try_filter():

    # Verify filter of successfully Try
    def test_filter_success(value):
        # Arrange
        try_monad = Try(value, True)
        # Act
        actual = try_monad.filter(filterer)
        # Assert
        assert actual == Try(value, True)
    test_filter_success(2)
    test_filter_success(0)

    # Verify filter of unsuccessfully Try
    def test_filter_fail(value):
        # Arrange
        try_monad = Try(value, False)
        # Act
        actual = try_monad.filter(filterer)
        # Assert
        assert actual == Try(value, False)
    test_filter_fail('some_error')

    # Verify filter for not successfully monad

# Generated at 2022-06-12 05:29:23.054192
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 1
    assert True == Try(1, True).filter(filterer).is_success
    assert None == Try(2, True).filter(filterer).get()
    assert None == Try(None, False).filter(filterer).get()


# Generated at 2022-06-12 05:29:34.672879
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from .function import Function
    from .option import Some, Option
    from .either import Right, Either

    try_success = Try(2, True)
    try_not_success = Try(None, False)
    filterer = Function(lambda v: v % 2 == 0)
    print('Try success: ', try_success)
    print('Try not success: ', try_not_success)
    print('Filterer: ', filterer)
    print('Try success filter: ', try_success.filter(filterer))
    print('Try not success filter: ', try_not_success.filter(filterer))

    print('Try success filter with either: ', Option.of(try_success).fmap(filterer))

# Generated at 2022-06-12 05:29:37.595431
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-12 05:29:42.174562
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # The test should be successful
    assert Try.of(lambda x: x + 1, 1).filter(lambda x: x > 0) == Try(2, True)

    # The test should be successful
    assert Try.of(lambda x: x + 1, 1).filter(lambda x: x < 0) == Try(1, False)

    # The test should be successful
    assert Try.of(lambda x: x / 0, 1).filter(lambda x: x > 0) == Try(1, False)

# Generated at 2022-06-12 05:29:52.566918
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Simple unit test for method filter.
    """
    def filter_function(value):
        return (value % 2) == 0

    def filter_function2(value):
        return (value % 2) == 1

    def test_True():
        try_ = Try.of(int, '20')
        try_ = try_.filter(filter_function)
        assert try_.is_success
        assert try_.value == 20

    def test_False():
        try_ = Try.of(int, '20')
        try_ = try_.filter(filter_function2)
        assert not try_.is_success
        assert try_.value == 20

    def test_Fail():
        try_ = Try.of(int, 'p')
        try_ = try_.filter(filter_function2)
        assert not try_.is_success

# Generated at 2022-06-12 05:30:09.835069
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> x = 'abc'
    >>> Try.of(str.upper, x).filter(str.islower)\
        .on_success(lambda x: print(x))\
        .on_fail(lambda x: print('x is upper'))
    x is upper
    >>> Try.of(str.upper, x).filter(str.isupper)\
        .on_success(lambda x: print(x))\
        .on_fail(lambda x: print('x is lower'))
    ABC
    """
    pass


# Generated at 2022-06-12 05:30:13.833989
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda: 5).filter(lambda x: x > 4)
    assert result == Try(5, True)

    result = Try.of(lambda: 5).filter(lambda x: x < 4)
    assert result == Try(5, False)



# Generated at 2022-06-12 05:30:24.378269
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 0) \
            .filter(lambda x: x == 0) == Try(0, True)
    assert Try.of(lambda: 1) \
            .filter(lambda x: x == 0) == Try(1, False)
    assert Try.of(lambda: 1) \
            .filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1) \
            .filter(lambda x: x == 1) \
            .map(lambda x: 2 * x) \
            .filter(lambda x: x == 2) == Try(2, True)
    assert Try.of(lambda: 1) \
            .filter(lambda x: x == 1) \
            .map(lambda x: 2 * x) \
            .filter(lambda x: x == 3)

# Generated at 2022-06-12 05:30:29.570009
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x):
        return x == 1
    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(2, False).filter(filterer) == Try(2, False)


# Generated at 2022-06-12 05:30:32.015990
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x < 10) == Try(5, True)
    assert Try(10, True).filter(lambda x: x < 10) == Try(10, False)

# Generated at 2022-06-12 05:30:36.855282
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(1, True).filter(lambda x: x > 2).is_success == False
    assert Try(1, True).filter(lambda x: x < 2).is_success == True
    assert Try(1, False).filter(lambda x: x < 2).is_success == False

# Generated at 2022-06-12 05:30:42.334374
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_even(number):
        return number % 2 == 0

    assert Try(1, True).filter(is_even) == Try(1, False)
    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(Exception('Oops!!!'), False).filter(is_even) == Try(Exception('Oops!!!'), False)


# Generated at 2022-06-12 05:30:49.911050
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    #WHEN
    value_when_execute_filter_metod_on_successful_Try_with_tuple_of_two_numbers_as_value = Try((2, 1), True)\
        .filter(lambda num1_tuple_num2: num1_tuple_num2[0] % 2)
    value_when_execute_filter_metod_on_successful_Try_with_tuple_of_two_numbers_as_value_and_filterer_filtration = Try((2, 1), True)\
        .filter(lambda num1_tuple_num2: num1_tuple_num2[0] % 1)
    value_when_execute_filter_metod_on_successful_Try_with_tuple_of_two_numbers_as_value_

# Generated at 2022-06-12 05:30:57.976713
# Unit test for method filter of class Try
def test_Try_filter():
    @test
    def when_filter_success():
        assert Try(5, True).filter(lambda x: x > 4) == Try(5, True)

    @test
    def when_filter_none_success():
        assert Try(5, True).filter(lambda x: x < 4) == Try(5, False)

    @test
    def when_filter_none_fail():
        assert Try(5, False).filter(lambda x: x + 1 == 7) == Try(5, False)



# Generated at 2022-06-12 05:31:02.122672
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try('', True).filter(lambda x: x == 1) == Try('', False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-12 05:31:19.587149
# Unit test for method filter of class Try
def test_Try_filter():
    """Unit test for method filter of class Try"""
    def filter_func(value):
        return value == 'value'
    assert Try('value', True).filter(filter_func) == Try('value', True)
    assert Try('not_value', True).filter(filter_func) == Try('not_value', False)
    assert Try('not_value', False).filter(filter_func) == Try('not_value', False)



# Generated at 2022-06-12 05:31:27.228213
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 0

    success_try = Try(0, True)
    assert success_try.filter(filterer).is_success
    assert success_try.filter(filterer).get() == 0

    fail_try = Try(1, True)
    assert not fail_try.filter(filterer).is_success
    assert fail_try.filter(filterer).get() == 1



# Generated at 2022-06-12 05:31:30.783597
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, True).filter(lambda _: True) == Try(None, True)
    assert Try(None, False).filter(lambda _: True) == Try(None, False)
    assert Try(None, True).filter(lambda _: False) == Try(None, False)



# Generated at 2022-06-12 05:31:35.350874
# Unit test for method filter of class Try
def test_Try_filter():
    # when filterer returns false, Try should be unsuccessfully
    assert Try(12, True).filter(lambda _: False) == Try(12, False)

    # when filterer returns true, Try should be successfully
    assert Try(12, True).filter(lambda _: True) == Try(12, True)


# Generated at 2022-06-12 05:31:43.297848
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(e):
        if isinstance(e, ZeroDivisionError):
            return True
        return False
    assert Try.of(lambda: 1 / 0, ).filter(filterer) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 1, ).filter(filterer) == Try(1, True)
    assert Try.of(lambda: 1 / 0, ).filter(lambda e: True) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 1, ).filter(lambda e: True) == Try(1, True)



# Generated at 2022-06-12 05:31:48.681298
# Unit test for method filter of class Try
def test_Try_filter():
    """Unit test for method filter of class Try."""
    assert Try(1, True).filter(lambda x: x < 5) == Try(1, True)
    assert Try(10, True).filter(lambda x: x < 5) == Try(10, False)
    assert Try(1, False).filter(lambda x: x < 5) == Try(1, False)


# Generated at 2022-06-12 05:31:57.451540
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def get_test_mapper(target):
        def identity(value):
            return value == target
        return identity

    def get_test_mapper_not(target):
        def identity(value):
            return value != target
        return identity

    try_4 = Try(4, True)
    try_4_not_success = Try(4, False)
    try_2 = Try(2, True)

    assert_true(try_4.filter(get_test_mapper(4)))
    assert_true(try_4_not_success.filter(get_test_mapper(4)).is_success is False)
    assert_true(try_2.filter(get_test_mapper(4)).is_success is False)


# Generated at 2022-06-12 05:32:02.969267
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)

    message = 'error'
    try:
        raise Exception(message)
    except Exception as e:
        assert Try(e, False).filter(lambda x: True) == Try(e, False)



# Generated at 2022-06-12 05:32:13.602965
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filterer(value): return value == 1
    def test_mapper(value): return value + 1
    def test_success_callback(value): print('success {}'.format(value))
    def test_fail_callback(value): print('fail {}'.format(value))

    # Try[value=None, is_success=False]
    t1 = Try(None, False)
    print(t1)
    # Try[value=None, is_success=False]
    t2 = t1.filter(test_filterer)
    assert t2 == Try(None, False)
    print(t2)
    # Try[value=None, is_success=False]
    t1.on_fail(test_fail_callback)

    # Try[value=1, is_success=True]
    t

# Generated at 2022-06-12 05:32:21.525647
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    m = Try.of(lambda: 2)
    m2 = Try.of(lambda: "")
    m3 = Try.of(lambda: "something")
    m4 = Try.of(lambda: 2)

    n = m.filter(lambda x: x > 0)
    n2 = m2.filter(lambda x: x != "")
    n3 = m4.filter(lambda x: x == 17)

    assert n == Try(2, True)
    assert n2 == Try("", False)
    assert n3 == Try(2, False)

# Generated at 2022-06-12 05:32:53.706273
# Unit test for method filter of class Try
def test_Try_filter():
    from assertions import assert_equal

    assert_equal(
        Try.of(lambda x: x, 1).filter(lambda x: x > 0),
        Try(1, True)
    )

    assert_equal(
        Try.of(lambda x: x, 1).filter(lambda x: x < 0),
        Try(1, False)
    )

    def foo():
        try:
            1/0
        except ZeroDivisionError as e:
            return e

    assert_equal(
        Try.of(foo).filter(lambda x: x > 0),
        Try(ZeroDivisionError, False)
    )

    print('Unit test for method filter of class Try: ok')


# Generated at 2022-06-12 05:33:04.924123
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try.of(lambda: 10, ()).filter(lambda x: x > 3) == Try(10, True)
    assert Try.of(lambda: 10, ()).filter(lambda x: x < 3) == Try(10, False)
    assert Try.of(lambda: 10, ()).filter(lambda x: x > 3).on_success(lambda x: print(x)) == Try(10, True)
    assert Try.of(lambda: 10, ()).filter(lambda x: x > 3).on_fail(lambda x: print(x)) == Try(10, True)
    assert Try.of(lambda: 10, ()).filter(lambda x: x < 3).on_success(lambda x: print(x)) == Try(10, False)

# Generated at 2022-06-12 05:33:08.672096
# Unit test for method filter of class Try
def test_Try_filter():
    value = 'pavlo'
    assert Try.of(lambda: value, None).filter(lambda x: True) == Try(value, True)
    assert Try.of(lambda: value, None).filter(lambda x: False) == Try(value, False)


# Generated at 2022-06-12 05:33:19.691472
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)

    assert Try(1, True).filter(lambda x: x > 0).get() == Try(1, True).get()
    assert Try(1, True).filter(lambda x: x < 0).get() == Try(1, False).get()
    assert Try(1, False).filter(lambda x: x > 0).get() == Try(1, False).get()

    assert Try(1, True).filter(lambda x: x > 0).get_or_else(0) == Try(1, True).get_or_else

# Generated at 2022-06-12 05:33:23.889698
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(100, True).filter(lambda x: x < 500) == Try(100, False)
    assert Try(100, True).filter(lambda x: x < 150) == Try(100, True)



# Generated at 2022-06-12 05:33:30.040869
# Unit test for method filter of class Try
def test_Try_filter():
    # Test successfully Try
    assert Try(3, True).filter(lambda x: x > 2) == Try(3, True)

    # Test unsuccessfully Try
    assert Try('error', False).filter(lambda x: x > 2) == Try('error', False)

    # Test not successfully Try when filter return False
    assert Try(1, True).filter(lambda x: x > 2) == Try(1, False)

# Generated at 2022-06-12 05:33:37.409867
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(500, True).filter(lambda x: x > 300) == Try(500, True)
    assert Try(500, True).filter(lambda x: x < 300) == Try(500, False)
    assert Try(500, False).filter(lambda x: x > 300) == Try(500, False)
    assert Try(500, True).filter(lambda x: 0) == Try(500, False)
    assert Try(500, False).filter(lambda x: 0) == Try(500, False)
    assert Try(500, True).filter(lambda x: 1) == Try(500, True)
    assert Try(500, False).filter(lambda x: 1) == Try(500, False)


# Generated at 2022-06-12 05:33:45.352269
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_function(value):
        return value > 0

    # success case
    for i in range(0, 10):
        monad = Try(i, True)
        monad = monad.filter(filter_function)
        assert monad.is_success == i > 0
        assert monad.value == i

    # success case
    for i in range(0, 10):
        monad = Try(i, False)
        monad = monad.filter(filter_function)
        assert monad.is_success == False
        assert monad.value == i

