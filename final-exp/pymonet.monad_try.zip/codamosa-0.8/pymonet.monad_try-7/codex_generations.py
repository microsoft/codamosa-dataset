

# Generated at 2022-06-12 05:23:53.143950
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value.startswith('2')
    try_monad = Try(2, True)
    assert try_monad.filter(filterer) == True
    try_monad = Try(4, True)
    assert try_monad.filter(filterer) == False



# Generated at 2022-06-12 05:23:59.353258
# Unit test for method filter of class Try
def test_Try_filter():
    # When filter return true
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    # When filter return false
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    # When failed Try
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)



# Generated at 2022-06-12 05:24:01.325004
# Unit test for method filter of class Try
def test_Try_filter():
    x = Try.of(int, '1').filter(lambda t: t == 1)
    assert x == Try(1, True)



# Generated at 2022-06-12 05:24:09.523188
# Unit test for method filter of class Try
def test_Try_filter():
    try_value = Try.of(lambda: 'Hello').filter(lambda x: x is not None)
    assert try_value.is_success
    assert try_value.value == 'Hello'
    try_value = Try.of(lambda: '').filter(lambda x: x is not None)
    assert not try_value.is_success
    try_value = Try.of(lambda: None).filter(lambda x: x is not None)
    assert not try_value.is_success


# Generated at 2022-06-12 05:24:15.995622
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x + 1, 2).filter(lambda x: x + 3) == Try(None, False)
    assert Try.of(lambda x: x + 1, 2).filter(lambda x: x + 1) == Try(None, False)
    assert Try.of(lambda x: x + 1, 2).filter(lambda x: x == 3) == Try(None, False)
    assert Try.of(lambda x: x + 1, 2).filter(lambda x: x == 2) == Try(None, False)


# Generated at 2022-06-12 05:24:20.728671
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(4, True).filter(lambda value: value % 2 == 0) == Try(4, True)
    assert Try(5, True).filter(lambda value: value % 2 == 0) == Try(5, False)
    assert Try(Exception('Error'), False).filter(lambda value: True) == Try(Exception('Error'), False)


# Generated at 2022-06-12 05:24:23.146338
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    monad = Try.of(int, '444')
    # When
    new_monad = monad.filter(lambda x: x % 2 == 0)
    # Then
    assert new_monad == Try(444, True)


# Generated at 2022-06-12 05:24:26.946675
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-12 05:24:35.664482
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, ).filter(lambda value: value % 2 == 0) == Try(1, True)
    assert Try.of(lambda: 1, ).filter(lambda value: value % 2 == 1) == Try(1, False)

    def raise_error():
        raise ValueError()

    assert Try.of(lambda: 1, ).filter(raise_error) == Try(1, True)


# Generated at 2022-06-12 05:24:42.152643
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True)\
        .filter(lambda x: x > 4)\
        .get() == 5

    assert not Try(5, True)\
        .filter(lambda x: x < 5)\
        .is_success

    assert not Try(5, False)\
        .filter(lambda x: x < 5)\
        .is_success


# Generated at 2022-06-12 05:24:48.477402
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def _is_3_od(n) -> bool:
        return n % 3 == 0

    # successfully
    assert Try.of(lambda: 2).filter(_is_3_od) == Try(2, False)
    # not successfully
    assert Try.of(lambda: 2).filter(_is_3_od) == Try(2, False)

# Generated at 2022-06-12 05:24:58.420334
# Unit test for method filter of class Try
def test_Try_filter():
    # given
    def filterer(value):
        return value == 'abc'
    def success_callback(value):
        print(value, 'is success')

    # when
    successful_try = Try('abc', True)
    not_successful_try = Try('def', False)
    successful_try_filter = successful_try.filter(filterer)
    not_successful_try_filter = not_successful_try.filter(filterer)

    # then
    assert successful_try_filter.get_or_else(False) == 'abc'
    assert not_successful_try_filter.get_or_else(False) is False


# Generated at 2022-06-12 05:25:02.570938
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)

# Generated at 2022-06-12 05:25:08.049729
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 1

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(2, False).filter(filterer) == Try(2, False)



# Generated at 2022-06-12 05:25:15.876057
# Unit test for method filter of class Try
def test_Try_filter():
    """
    :returns: indicate test is passed or not.
    :rtype: Boolean
    """
    def div(a, b):
        return a / b
    def check_number(a):
        return a > 0
    def filterer(a):
        return a == 1

    # Call function div with arguments (1, 1)
    # Function don't throw exception, bind function filterer with arument 1.
    # Filterer function return True, so return Try with value 1.
    assert Try(1, True) == Try\
        .of(div, 1, 1)\
        .filter(filterer)

    # Call function div with arguments (1, 0).
    # Function throw exception and return Try with value / by zero.
    # Method filter don't call filterer function and return Try with value / by zero

# Generated at 2022-06-12 05:25:20.250704
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    value = 1
    try_ = Try(value, True)

    # When
    try_with_true = try_.filter(lambda x: True)
    try_with_false = try_.filter(lambda x: False)

    # Then
    assert try_ == try_with_true
    assert Try(value, False) == try_with_false


# Generated at 2022-06-12 05:25:23.743052
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)

# Generated at 2022-06-12 05:25:27.974615
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda v: v == 5) == Try(5, True)
    assert Try(5, True).filter(lambda v: v != 5) == Try(5, False)
    assert Try(5, False).filter(lambda v: v == 5) == Try(5, False)
    assert Try(5, False).filter(lambda v: v != 5) == Try(5, False)

# Generated at 2022-06-12 05:25:32.608878
# Unit test for method filter of class Try
def test_Try_filter():
    try_success = Try(10, True)
    try_fail = Try(10, False)

    assert try_success.filter(lambda x: x > 5) == Try(10, True)
    assert try_success.filter(lambda x: x > 15) == Try(10, False)

    assert try_fail.filter(lambda x: x > 5) == Try(10, False)

# Generated at 2022-06-12 05:25:38.080326
# Unit test for method filter of class Try
def test_Try_filter():
    def positive(value):
        return value >= 0

    result_positive = Try.of(lambda: 5).filter(positive)
    assert result_positive.is_success
    assert result_positive.get() == 5

    result_negative = Try.of(lambda: 5).filter(lambda value: value < 0)
    assert not result_negative.is_success
    assert result_negative.get() == 5



# Generated at 2022-06-12 05:25:43.151864
# Unit test for method filter of class Try
def test_Try_filter():
    # Test case 1:
    test_Try_filter_case_1()

    # Test case 2:
    test_Try_filter_case_2()



# Generated at 2022-06-12 05:25:47.108909
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """
    result = Try(2, True).filter(lambda x: x == 2)
    expected = Try(2, True)

    assert result == expected


# Generated at 2022-06-12 05:25:52.734558
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filterer(x):
        return x % 2 == 0

    assert Try(2, True).filter(test_filterer) == Try(2, True)
    assert Try(9, True).filter(test_filterer) == Try(9, False)
    assert Try(2, False).filter(test_filterer) == Try(2, False)


# Generated at 2022-06-12 05:25:56.438224
# Unit test for method filter of class Try
def test_Try_filter():
    # Test returned value
    assert Try(1, True).filter(lambda x: x < 10) == Try(1, True)
    assert Try(100, True).filter(lambda x: x < 10) == Try(100, False)
    # Test returned value when monad is not successfully
    assert Try(1, False).filter(lambda x: x < 10) == Try(1, False)



# Generated at 2022-06-12 05:26:02.533215
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, False).filter(lambda x: True) != Try(1, True)
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(3, True).filter(lambda x: x % 2 == 0) != Try(3, True)


# Generated at 2022-06-12 05:26:08.333477
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from pymonad.control import Try
    import operator

    print("Try.filter: {}".format(
        Try.of(lambda x: x, 3.14)
            .filter(lambda f: operator.lt(f, 3))
            .get_or_else("fail")
    ))
    print("Try.filter: {}".format(
        Try.of(lambda x: x, 3.14)
            .filter(lambda f: operator.gt(f, 3))
            .get_or_else("fail")
    ))


if __name__ == '__main__':  # pragma: no cover
    test_Try_filter()

# Generated at 2022-06-12 05:26:15.130902
# Unit test for method filter of class Try
def test_Try_filter():
    t = Try.of(lambda: 3).map(lambda x: x ** 2).filter(lambda x: x > 5)
    assert t.value == 9
    assert t.is_success

    t = Try.of(lambda: 3).map(lambda x: x ** 2).filter(lambda x: x < 5)
    assert t.value == 9
    assert not t.is_success


# Generated at 2022-06-12 05:26:20.026969
# Unit test for method filter of class Try
def test_Try_filter():
    def fn_filterer(x):
        return x > 10

    assert Try(None, False).filter(fn_filterer) == Try(None, False)
    assert Try(10, True).filter(fn_filterer) == Try(10, False)
    assert Try(11, True).filter(fn_filterer) == Try(11, True)


# Generated at 2022-06-12 05:26:29.255725
# Unit test for method filter of class Try
def test_Try_filter():
    """
    test_Try_filter
    """

    print('test_monad_try_filter')

    def is_odd(x):
        if x % 2 != 0:
            return True
        return False

    # success
    value = 1
    monad = Try(value, True)
    assert monad.filter(is_odd) == Try(value, True)

    # not success
    value = 1
    monad = Try(value, False)
    assert monad.filter(is_odd) == Try(value, False)

    # success
    value = 2
    monad = Try(value, True)
    assert monad.filter(is_odd) == Try(value, False)



# Generated at 2022-06-12 05:26:35.202719
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> assert Try.of(lambda: 3/2, ()).filter(lambda x: x == 1.5)\
        == Try(1.5, True)
    >>> assert Try.of(lambda: 1/0, ()).filter(lambda x: 0)\
        == Try(ZeroDivisionError('division by zero'), False)
    """
    pass



# Generated at 2022-06-12 05:26:46.461556
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'value', None) == Try('value', True)
    assert Try.of(lambda: 1 / 0, None) == Try(ZeroDivisionError(), False)

    assert Try.of(lambda: 'value', None).filter(lambda v: v == 'value') == Try('value', True)
    assert Try.of(lambda: 'value', None).filter(lambda v: v == 'value1') == Try('value', False)
    assert Try.of(lambda: 1 / 0, None).filter(lambda _: True) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-12 05:26:52.306123
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(None, False).filter(lambda x: True) == Try(None, False)
    assert Try(None, False).filter(lambda x: False) == Try(None, False)



# Generated at 2022-06-12 05:26:56.496242
# Unit test for method filter of class Try
def test_Try_filter():
    f = (lambda x: x > 10)
    assert Try.of(lambda: 10).map(f).is_success == False
    assert Try.of(lambda: 10).filter(f).is_success == False
    assert Try.of(lambda: 11).map(f).is_success == True
    assert Try.of(lambda: 11).filter(f).is_success == True


# Generated at 2022-06-12 05:27:05.236805
# Unit test for method filter of class Try
def test_Try_filter():
    # when monad is successfully, filterer returns True, filter returns copy of monad
    assert Try(5, True).filter(lambda x: x == 5) == Try(5, True)

    # when monad is successfully, filterer returns False, filter returns not successfully monad
    assert Try(5, True).filter(lambda x: x != 5) == Try(5, False)

    # when monad is not successfully, filter returns not successfully monad
    assert Try(5, False).filter(lambda x: x == 5) == Try(5, False)



# Generated at 2022-06-12 05:27:09.750579
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 3

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(5, True).filter(filterer) == Try(5, True)



# Generated at 2022-06-12 05:27:15.929808
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)
    assert Try(10, True).filter(lambda x: x <= 5) == Try(10, False)
    assert Try(10, False).filter(lambda x: x > 5) == Try(10, False)
    assert Try(10, False).filter(lambda x: x <= 5) == Try(10, False)



# Generated at 2022-06-12 05:27:21.181538
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'hello', ).filter(lambda x: len(x) > 2) == Try('hello', True)
    assert Try.of(lambda: 'hi', ).filter(lambda x: len(x) > 2) == Try('hi', False)



# Generated at 2022-06-12 05:27:25.544955
# Unit test for method filter of class Try
def test_Try_filter():
    f = lambda x: x == 1
    assert (Try.of(lambda: 1).filter(f) == Try(1, True))
    assert (Try.of(lambda: 2).filter(f) == Try(2, False))


test_Try_filter()


# Generated at 2022-06-12 05:27:30.856503
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 4).filter(lambda x: x > 3) == Try(4, True)
    assert Try.of(lambda: 4).filter(lambda x: x < 3) == Try(4, False)
    assert Try.of(lambda: None).filter(lambda x: x > 3) == Try(None, False)


# Generated at 2022-06-12 05:27:39.547232
# Unit test for method filter of class Try
def test_Try_filter():
    # Test when monad is successfully:
    def filterer(value) -> bool:
        return True
    try_1 = Try.of(lambda: 1, filterer=filterer)
    assert try_1.filter(filterer) == try_1

    # Test when monad is not successfully:
    try_2 = Try.of(lambda: 1/0, filterer=filterer)
    assert try_2.filter(filterer) != try_2

    # Test when monad is successfully and filterer is False
    def filterer(value) -> bool:
        return False
    try_3 = Try.of(lambda: 1, filterer=filterer)
    try_4 = Try(try_3.value, False)

# Generated at 2022-06-12 05:27:52.702556
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try
    """
    assert Try(2, True).filter(lambda num: num > 1) == Try(2, True)
    assert Try(2, True).filter(lambda num: num > 3) == Try(2, False)
    assert Try(2, False).filter(lambda num: num > 1) == Try(2, False)
    assert Try(2, False).filter(lambda num: num > 3) == Try(2, False)


# Generated at 2022-06-12 05:28:01.252318
# Unit test for method filter of class Try
def test_Try_filter():
    tr = Try.of(lambda x: 1 / x, 0)
    assert tr.filter(lambda x: x % 2 == 0).get_or_else(0) == 0
    assert tr.filter(lambda x: x % 2 != 0).get_or_else(0) == tr.get_or_else(0)
    tr = Try.of(lambda x: 1 / x, 1)
    assert tr.filter(lambda x: x % 2 != 0).get_or_else(0) == 1
    assert tr.filter(lambda x: x % 2 == 0).get_or_else(0) == 0


# Generated at 2022-06-12 05:28:07.858134
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1').filter(lambda i: i == 1) == Try(1, True)
    assert Try.of(int, '1').filter(lambda i: i != 1) == Try(1, False)
    assert Try.of(int, 'a').filter(lambda i: i != 1) == Try(ValueError("invalid literal for int() with base 10: 'a'"), False)

# Generated at 2022-06-12 05:28:11.934666
# Unit test for method filter of class Try
def test_Try_filter():
    def greater_than_0(x):
        return x > 0

    assert Try.of(lambda: 20).filter(greater_than_0) == Try(20, True)
    assert Try.of(lambda: -10).filter(greater_than_0) == Try(-10, False)


# Generated at 2022-06-12 05:28:19.323541
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x > 3) == Try(1, False)

    t = Try(1, False)
    assert t.filter(lambda x: x > 0) == t

    t = Try(1, True)
    assert t.filter(lambda x: x > 0) == t


# Generated at 2022-06-12 05:28:26.613963
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for Try.filter method.
    """
    def add_1(x):
        return x + 1

    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 != 0

    assert Try(1, True).filter(is_even) == Try(1, False), "Fail with value is odd"
    assert Try(1, True).filter(is_odd).map(add_1) == Try(2, True), "Fail with add 1 to value"
    assert Try(2, True).filter(is_even).map(add_1) == Try(3, True),\
        "Fail with value is even and add 1 to value"

# Generated at 2022-06-12 05:28:32.304192
# Unit test for method filter of class Try
def test_Try_filter():
    def filt(x):
        return x > 5

    assert Try(10, True).filter(filt) == Try(10, True)
    assert Try(10, False).filter(filt) == Try(10, False)
    assert Try(1, True).filter(filt) == Try(1, False)

# Generated at 2022-06-12 05:28:38.775397
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """
    assert Try(4, True).filter(lambda x: x%2==0) == Try(4, True)
    assert Try(4, True).filter(lambda x: x%2!=0) == Try(4, False)
    assert Try(Failure(None), False).filter(lambda x: x%2==0) == Try(Failure(None), False)



# Generated at 2022-06-12 05:28:43.291666
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    input_value = 4
    monad = Try.of(lambda x: x, input_value)

    # When
    method_result = monad.filter(lambda x: x % 2 == 0)

    # Then
    assert method_result == Try(input_value, True)


# Generated at 2022-06-12 05:28:47.165248
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x):
        return x > 5

    result = Try.of(lambda: 3).filter(filterer)
    expected = Try(3, False)

    assert result == expected

    result = Try.of(lambda: 6).filter(filterer)
    expected = Try(6, True)

    assert result == expected


# Generated at 2022-06-12 05:29:01.428251
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully monad
    t = Try.of(lambda x: x, 1)
    assert t.filter(lambda x: x == 1) == Try.of(lambda x: x, 1)

    # Not successfully monad
    t = Try.of(lambda x: x, 1)
    assert t.filter(lambda x: x == 2) != Try.of(lambda x: x, 1)

# Generated at 2022-06-12 05:29:08.426685
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover

    def _less_than_three(value):
        return value < 3

    assert Try(1, True).filter(_less_than_three) == Try(1, True)
    assert Try(2, True).filter(_less_than_three) == Try(2, True)
    assert Try(3, True).filter(_less_than_three) == Try(3, False)
    assert Try(1, False).filter(_less_than_three) == Try(1, False)



# Generated at 2022-06-12 05:29:19.052266
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Create successfully monad Try and filter it with filterer

    :returns: True when test pass, raises AssertionError when fails
    """
    try_filter_instance = Try('value', True)

    def filterer(value):
        return value.startswith('v')

    result = try_filter_instance.filter(filterer)
    assert result == Try('value', True)

    def filterer(value):
        return value.startswith('w')

    result = try_filter_instance.filter(filterer)
    assert result == Try('value', False)

    try_filter_instance = Try('value', False)

    def filterer(value):
        return value.startswith('w')

    result = try_filter_instance.filter(filterer)
    assert result

# Generated at 2022-06-12 05:29:26.546407
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x):
        return x == 'a'

    try_true = Try('a', True)
    try_false = Try('a', False)
    try_true_filtered = try_true.filter(filterer)
    try_false_filtered = try_false.filter(filterer)
    assert try_true_filtered == Try('a', True)
    assert try_false_filtered == Try('a', False)



# Generated at 2022-06-12 05:29:34.584152
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    monad = Try(7, True)

    assert monad.filter(filterer) == Try(7, True)

    monad = Try(3, True)

    assert monad.filter(filterer) == Try(3, False)

    assert monad.filter(filterer).get_or_else(None) is None

    monad = Try(None, False)

    assert monad.filter(filterer).get_or_else(None) is None

# Generated at 2022-06-12 05:29:40.578999
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try

    :returns: None
    :rtype: None
    """
    # When filterer return True method returns copy of monad, othercase
    # not successfully Try with previous value.
    def filterer(value):
        return value == 5

    try1 = Try(5, True)
    try2 = Try(7, True)

    assert try1.filter(filterer) == Try(5, True)
    assert try2.filter(filterer) == Try(7, False)



# Generated at 2022-06-12 05:29:46.149144
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(v):
        return v > 0

    assert Try.of(int, '10').filter(filterer) == Try(10, True)
    assert Try.of(int, '-10').filter(filterer) == Try(-10, False)

    assert Try.of(int, 'a').filter(filterer) == Try('a', False)

# Generated at 2022-06-12 05:29:50.486649
# Unit test for method filter of class Try
def test_Try_filter():
    # Prepare
    def value_is_even(value):
        return value % 2 == 0

    try_container = Try.of(int, '2')

    # Execute
    result = try_container.filter(value_is_even)

    # Verify
    assert result == Try(2, True)



# Generated at 2022-06-12 05:29:54.564154
# Unit test for method filter of class Try
def test_Try_filter():
    is_greater_than_ten = lambda x: x > 10

    assert Try.of(lambda: 15).filter(is_greater_than_ten) == Try.of(lambda: 15)
    assert Try.of(lambda: 1).filter(is_greater_than_ten) == Try(1, False)
    assert Try.of(lambda: 'a').filter(lambda x: not isinstance(x, str)) == Try('a', False)


# Generated at 2022-06-12 05:30:03.505478
# Unit test for method filter of class Try
def test_Try_filter():
    # for case of true, previous value should be returned in successfully Try
    assert Try(1, True).filter(lambda x: x <= 10) == Try(1, True)

    # for case of false, previous value should be returned in not successfully Try
    assert Try(1, True).filter(lambda x: x >= 10) == Try(1, False)

    # for case of true and not successfully Try, previous value should be returned in not successfully Try
    assert Try(1, False).filter(lambda x: x >= 10) == Try(1, False)

    # for case of true and not successfully Try, previous value should be returned in not successfully Try
    assert Try(1, False).filter(lambda x: x <= 10) == Try(1, False)

# Generated at 2022-06-12 05:30:31.883623
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(a):
        if a > 5:
            return True
        raise Exception()

    @given(st.integers())
    def test_with_generated_value(value):
        try:
            result_value = Try(value, True).filter(filterer).get()
        except Exception as e:
            result_value = e

        try:
            filterer(value)
            expected_value = value
        except Exception as e:
            expected_value = e

        assert result_value == expected_value

    test_with_generated_value()

# Generated at 2022-06-12 05:30:37.847979
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def div(a, b):
        return a / b

    def is_even(v):
        return v % 2 == 0

    print(Try.of(div, 10, 5))
    print(Try.of(div, 10, 0))
    print(Try.of(div, 10, 5).filter(is_even))
    print(Try.of(div, 10, 6).filter(is_even))

# Generated at 2022-06-12 05:30:47.978059
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try.of(lambda x: 3, None).filter(lambda x: x > 3) == Try(3, False)
    assert Try.of(lambda x: 3, None).filter(lambda x: x > 2) == Try(3, True)
    assert Try.of(lambda x: 3, None).filter(lambda x: x > 4) == Try(3, False)
    assert Try.of(lambda x: 3, None).filter(lambda x: x > 2).filter(lambda x: x > 1) == Try(3, True)
    assert Try.of(lambda x: 3, None).filter(lambda x: x > 2).filter(lambda x: x > 3) == Try(3, False)

# Generated at 2022-06-12 05:30:59.573280
# Unit test for method filter of class Try

# Generated at 2022-06-12 05:31:08.359269
# Unit test for method filter of class Try
def test_Try_filter():
    f = lambda a: a > 2
    assert Try(5, True).filter(f) == Try(5, True)
    assert Try(5, True).filter(f) != Try(2, True)
    assert Try(2, True).filter(f) != Try(5, True)
    assert Try(2, True).filter(f) != Try(2, True)
    assert Try(2, False).filter(f) != Try(5, True)
    assert Try(2, False).filter(f) != Try(2, True)
    try:
        assert Try(2, True).filter(f) != Try(2, False)
    except AssertionError:
        pass
    else:
        raise AssertionError('Try.filter failed')


# Generated at 2022-06-12 05:31:16.740082
# Unit test for method filter of class Try
def test_Try_filter():
    # for successfully monad
    example_try = Try(10, True)
    new_try = example_try.filter(lambda x: x == 10)
    assert new_try == Try(10, True)
    new_try = example_try.filter(lambda x: x == 5)
    assert new_try == Try(10, False)
    # for not successfully monad
    example_try = Try('error', False)
    new_try = example_try.filter(lambda x: x == 10)
    assert new_try == Try('error', False)

# Generated at 2022-06-12 05:31:21.208312
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def f(x: int) -> bool:
        return x % 2 == 0

    try_ = Try(2, True)\
        .filter(f)

    assert Try(2, True) == try_

    try_ = Try(3, True)\
        .filter(f)

    assert Try(3, False) == try_


# Generated at 2022-06-12 05:31:31.040009
# Unit test for method filter of class Try
def test_Try_filter():
    with pytest.raises(TypeError):
        Try(10, True).filter(100)

    # when is successfully and filterer returns True
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)

    # when is not successfully and filterer returns True
    assert Try(10, False).filter(lambda x: x > 5) == Try(10, False)

    # when is successfully and filterer returns False
    assert Try(10, True).filter(lambda x: x < 5) == Try(10, False)

    # when is not successfully and filterer returns False
    assert Try(10, False).filter(lambda x: x < 5) == Try(10, False)



# Generated at 2022-06-12 05:31:38.070189
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(None, True).filter(lambda x: x == 5) == Try(None, False)
    assert Try(5, True).filter(lambda x: x == 5) == Try(5, True)
    assert Try(5, False).filter(lambda x: x == 5) == Try(5, False)
    assert Try(5, True).filter(lambda x: x == 10) == Try(5, False)


# Generated at 2022-06-12 05:31:42.129763
# Unit test for method filter of class Try
def test_Try_filter():
    true = lambda _: True
    false = lambda _: False

    assert Try(10, True).filter(true).get() == 10
    assert Try(10, True).filter(false).is_success is False
    assert Try(10, False).filter(false).is_success is False



# Generated at 2022-06-12 05:32:10.275850
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, False).filter(lambda _: True) == Try(None, False)
    assert Try(None, True).filter(lambda _: True) == Try(None, True)
    assert Try(None, True).filter(lambda _: False) == Try(None, False)


# Generated at 2022-06-12 05:32:18.153332
# Unit test for method filter of class Try
def test_Try_filter():
    try_success = Try(2, True)
    try_not_success = Try(2, False)
    result = try_success.filter(lambda x: x == 2)
    assert result.is_success
    assert result.get() == 2
    result = try_not_success.filter(lambda x: x == 2)
    assert not result.is_success
    result = try_success.filter(lambda x: x == 1)
    assert not result.is_success


# Generated at 2022-06-12 05:32:22.612440
# Unit test for method filter of class Try
def test_Try_filter():
    res = Try.of(lambda: int('1'), '1')
    res_failed = Try.of(lambda: int('a'), 'a')

    assert res.filter(lambda x: x == 1) == Try(1, True)
    assert res.filter(lambda x: x == 2) != Try(1, True)
    assert res_failed.filter(lambda x: x == 2) == Try('a', False)

# Generated at 2022-06-12 05:32:28.315164
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)
    assert Try(5, True).filter(lambda x: x > 5) == Try(5, False)
    assert Try(0, False).filter(lambda x: x > 5) == Try(0, False)

# Generated at 2022-06-12 05:32:34.765131
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # test successfully
    # result = Try.of(lambda x: x + 1, 1)
    # assert result.filter(lambda x: x == 2).get() == 2

    # test unsuccessfully
    # result = Try.of(lambda x: x + 1, 'not number')
    # assert result.filter(lambda x: x == 2).get() != 2
    raise NotImplementedError()

# Generated at 2022-06-12 05:32:42.000091
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.filter(Try(None, False), lambda _: True) == Try(None, False)
    assert Try.filter(Try(None, False), lambda _: False) == Try(None, False)
    assert Try.filter(Try(1, False), lambda _: True) == Try(1, False)
    assert Try.filter(Try(1, False), lambda _: False) == Try(1, False)
    assert Try.filter(Try(1, True), lambda _: True) == Try(1, True)
    assert Try.filter(Try(1, True), lambda _: False) == Try(1, False)

# Generated at 2022-06-12 05:32:48.436427
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for Try filter method.
    """
    assert Try(1, True).filter(lambda x: x == 1)\
        == Try(1, True)

    assert Try(1, True).filter(lambda x: x == 2)\
        == Try(1, False)

    assert Try(Exception(), False).filter(lambda x: x == 1)\
        == Try(Exception(), False)


# Generated at 2022-06-12 05:32:51.602123
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(42, True).filter(lambda x: x == 42) == Try(42, True)
    assert Try(60, True).filter(lambda x: x == 42) == Try(60, False)


# Generated at 2022-06-12 05:32:56.614163
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Testing Try filter method.
    """

# Generated at 2022-06-12 05:33:04.605244
# Unit test for method filter of class Try
def test_Try_filter():
    def div(a, b):
        return a/b

    assert Try.of(div, 1, 0).map(lambda x: x**2).filter(lambda x: x > 1).get_or_else(0) == 0
    assert Try.of(div, 1, 1).map(lambda x: x**2).filter(lambda x: x > 1).get_or_else(0) == 1
    assert Try.of(div, 1, 2).map(lambda x: x**2).filter(lambda x: x > 1).get_or_else(0) == 4


# Generated at 2022-06-12 05:33:34.379338
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def fn(x):
        return x * 3

    def fgn(x):
        return x < 9

    fn_try = Try.of(fn, 3)
    fn_try2 = Try.of(fn, 2)

    fn_try.filter(fgn)
    print(fn_try.get())

    fn_try2.filter(fgn)
    print(fn_try2.get())

# Generated at 2022-06-12 05:33:39.673198
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try(11, True).filter(lambda x: x % 2 == 0)
    assert result == Try('Try[value=11, is_success=False]', False)

    result = Try(2, True).filter(lambda x: x % 2 == 0)
    assert result == Try(2, True)


if __name__ == '__main__':  # pragma: no cover
    test_Try_filter()

# Generated at 2022-06-12 05:33:44.264593
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    value = Try.of(lambda: 10).filter(lambda x: x == 10)
    assert value == Try(10, True)

    value = Try.of(lambda: 10).filter(lambda x: x == 9)
    assert value == Try(10, False)
