

# Generated at 2022-06-12 05:23:53.362023
# Unit test for method filter of class Try
def test_Try_filter():
    class A:
        pass

    assert Try(None, False).filter(lambda _: True) == Try(None, False)

    assert Try('value', True).filter(lambda _: True) == Try('value', True)

    a = A()
    assert Try(a, True).filter(lambda x: x == a) == Try(a, True)



# Generated at 2022-06-12 05:24:00.309089
# Unit test for method filter of class Try
def test_Try_filter():
    def try_it():
        raise Exception('test')
    assert Try.of(try_it).filter(lambda _: True) == Try(Exception('test'), False)
    assert Try.of(try_it).filter(lambda _: False) == Try(Exception('test'), False)
    assert Try(1, True).filter(lambda _: True) == Try(1, True)
    assert Try(1, True).filter(lambda _: False) == Try(1, False)


# Generated at 2022-06-12 05:24:12.102831
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Some tests.

    :returns: None
    """
    print(Try(32, True)\
            .filter(lambda x: x > 30)\
            .filter(lambda x: x % 2 == 0)\
            .filter(lambda x: x % 3 == 0)\
            .get())
    print(Try(32, True)\
            .filter(lambda x: x > 30)\
            .filter(lambda x: x % 2 == 0)\
            .filter(lambda x: x % 3 == 0)\
            .filter(lambda x: x == 5)\
            .get_or_else(10))

# Generated at 2022-06-12 05:24:17.238705
# Unit test for method filter of class Try
def test_Try_filter():
    from hypothesis import given, settings
    from hypothesis.strategies import text, integers

    @given(text())
    @settings(max_examples=1000)
    def test(text):
        try:
            assert Try.of(int, text).filter(lambda x: x > -1).get() >= 0
        except:
            assert True
    test()


# Generated at 2022-06-12 05:24:25.765780
# Unit test for method filter of class Try
def test_Try_filter():
    def add(num1: int, num2: int) -> int:
        return num1 + num2

    def sub(num1: int, num2: int) -> int:
        return num1 - num2

    def mult(num1: int, num2: int) -> int:
        return num1 * num2

    def div(num1: int, num2: int) -> int:
        return num1 / num2

    def equal_to_one(num: int) -> bool:
        return num == 1

    def equal_to_two(num: int) -> bool:
        return num == 2

    def equal_to_three(num: int) -> bool:
        return num == 3

    def equal_to_four(num: int) -> bool:
        return num == 4


# Generated at 2022-06-12 05:24:34.682801
# Unit test for method filter of class Try
def test_Try_filter():
    from pymonad.Monad import Maybe

    class Animal:
        def __init__(self, name, predator):
            self.name = name
            self.predator = predator

    class AnimalCollection:
        def __init__(self, animals):
            self.animals = animals

        def find(self, name):
            try:
                return Maybe(next((x for x in self.animals if x.name == name)))
            except StopIteration:
                return Maybe.empty()

    animals = [
        Animal('cat', True),
        Animal('cow', False),
        Animal('lion', True)
    ]
    collection = AnimalCollection(animals)


# Generated at 2022-06-12 05:24:39.076259
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def add(x, y):
        return x + y

    def sub(x, y):
        return x - y

    def filterer(x):
        return x < 0

    A = Try.of(add, 1, 2)
    B = Try.of(sub, 1, 2)

    assert A.filter(filterer) == Try(3, True)
    assert B.filter(filterer) == Try(3, False)

# Generated at 2022-06-12 05:24:45.268163
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True)\
        .filter(lambda x: x > 0)\
        == Try(1, True)

    assert Try(-1, True)\
        .filter(lambda x: x > 0)\
        == Try(-1, False)

    assert Try(1, False)\
        .filter(lambda x: x > 0)\
        == Try(1, False)



# Generated at 2022-06-12 05:24:52.746871
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, ).filter(lambda v: v == 0) == Try(1, True)
    assert Try.of(lambda: 1, ).filter(lambda v: v == 1) == Try(1, True)
    assert Try.of(lambda: 1, ).filter(lambda v: v == 2) == Try(1, False)
    assert Try.of(Exception, ).filter(lambda v: v == 2) == Try(Exception(), False)


# Generated at 2022-06-12 05:24:57.936262
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    r = Try(lambda a: a, True)
    assert r.filter(lambda a: a < 5) == Try(lambda a: a, False)

    r = Try(lambda a: a, True)
    assert r.filter(lambda a: a > 5) == Try(lambda a: a, True)


# Generated at 2022-06-12 05:25:08.209782
# Unit test for method filter of class Try
def test_Try_filter():
    def is_int(x):
        return isinstance(x, int)

    # Test with successful
    assert Try.of(lambda: 'test').filter(is_int) == Try('test', False)
    assert Try.of(lambda: 1).filter(is_int) == Try(1, True)

    # Test with error
    assert Try.of(lambda: 1 / 0).filter(is_int) == Try(ZeroDivisionError, False)

    # Test with not successful in filter
    assert Try.of(lambda: 1.0).filter(is_int) == Try(1.0, False)



# Generated at 2022-06-12 05:25:14.658181
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: "")\
        .filter(lambda v: False) == Try("", False)

    assert Try.of(lambda: "")\
        .filter(lambda v: True) == Try("", True)

    assert Try.of(lambda: 1 / 0)\
        .filter(lambda v: False) == Try(ZeroDivisionError('division by zero'), False)

    assert Try.of(lambda: "")\
        .filter(lambda v: False)\
        .filter(lambda v: True) == Try("", False)


# Generated at 2022-06-12 05:25:20.002666
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(0, True).filter(lambda x: x == 1) == Try(0, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-12 05:25:28.350471
# Unit test for method filter of class Try
def test_Try_filter():
    # Setup
    true_mock = mock.Mock(return_value=True)
    false_mock = mock.Mock(return_value=False)

    # Exercises
    try_true_true = Try(42, True)
    try_true_false = Try(42, True)
    try_false = Try(42, False)

    # Verify
    assert try_true_true.filter(true_mock) == Try(42, True)
    assert try_true_true.filter(false_mock) == Try(42, False)
    assert try_true_false.filter(true_mock) == Try(42, True)
    assert try_true_false.filter(false_mock) == Try(42, False)

# Generated at 2022-06-12 05:25:36.289772
# Unit test for method filter of class Try
def test_Try_filter():

    # When we have successfully and filterer return True
    # return Try with value and is_success set to True.
    assert Try(True, True).filter(lambda x: x == True) == Try(True, True)

    # When we have successfully and filterer return False
    # return Try with value and is_success set to False.
    assert Try(True, True).filter(lambda x: x == False) == Try(False, False)

    # When we have not successfully return Try
    # with value and is_success set to False.
    assert Try(True, False).filter(lambda x: x == True) == Try(True, False)

# Generated at 2022-06-12 05:25:44.836581
# Unit test for method filter of class Try
def test_Try_filter():
    def division(x, y):
        return Try(x / y, True)

    try:
        Try(10, True).bind(lambda x: division(x, 0)).filter(lambda x: x > 10)
        assert False
    except Exception as e:
        assert isinstance(e, ZeroDivisionError)
    assert Try(10, True).bind(lambda x: division(x, 2)).filter(lambda x: x > 5).get() == 5
    assert Try(10, True).bind(lambda x: division(x, 2)).filter(lambda x: x > 10).get() is None



# Generated at 2022-06-12 05:25:54.932026
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test Try class filter method.

    :returns: success
    """
    def filterer(result):
        return result == 'test string'

    def filterer_that_raise(result):
        raise ValueError

    try:
        assert Try('test string', True).filter(filterer) == Try('test string', True)
        assert Try('test string', True).filter(filterer_that_raise) == Try(ValueError(), False)
        assert Try('test string', False).filter(filterer) == Try('test string', False)
        assert Try('test string', False).filter(filterer_that_raise) == Try('test string', False)
        return 'Success Try class filter method test'
    except AssertionError:
        return 'Failed Try class filter method test'

# Generated at 2022-06-12 05:26:02.970129
# Unit test for method filter of class Try
def test_Try_filter():
    print('=> test Try.filter()')

    def bool_filter(val):
        return val is True

    def false_filter(val):
        return val is False

    assert Try(True, True).filter(bool_filter) == Try(True, True)
    assert Try(True, True).filter(false_filter) == Try(True, False)
    assert Try('some error', False).filter(false_filter) == Try('some error', False)

    print('<= test Try.filter()')


# Generated at 2022-06-12 05:26:09.322324
# Unit test for method filter of class Try
def test_Try_filter():
    # when:
    _Try1 = Try.of(lambda: 2 / 2)
    _Try2 = Try.of(lambda: 2 / 1)
    _Try3 = Try.of(lambda: 2 / 0)
    _Try4 = Try.of(lambda: 2 / 0)

    _Try5 = _Try1.filter(lambda x: x % 2 == 0)
    _Try6 = _Try1.filter(lambda x: x % 2 == 1)

    # then:
    assert _Try1 == Try(1, True)
    assert _Try1 != _Try2
    assert _Try2 != _Try3
    assert _Try3 == _Try4

    assert _Try5 == Try(1, True)
    assert _Try5 != _Try6
test_Try_filter()


# Generated at 2022-06-12 05:26:15.775144
# Unit test for method filter of class Try
def test_Try_filter():
    try:
        a = 5
        b = 0
        # throw exception
        c = a / b
    except Exception as e:
        try_instance = Try(e, False)
    else:
        try_instance = Try(c, True)

    assert try_instance.filter(lambda x: isinstance(x, ZeroDivisionError)) == Try(ZeroDivisionError(), False)

# Generated at 2022-06-12 05:26:26.440277
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x % 2 == 0

    try_success = Try(10, True)
    assert try_success.filter(filterer) == Try(10, True)

    try_fail = Try(11, True)
    assert try_fail.filter(filterer) == Try(11, False)

    try_exception = Try(Exception, False)
    assert try_exception.filter(filterer) == Try(Exception, False)

# Generated at 2022-06-12 05:26:34.645028
# Unit test for method filter of class Try
def test_Try_filter():
    e_times_2 = lambda x: x * 2 if x % 2 == 0 else None
    success_result = Try.of(e_times_2, 2).filter(lambda x: x == 4)
    assert Success(4) == success_result
    fail_result = Try.of(e_times_2, 2).filter(lambda x: x == 3)
    assert Failure(None) == fail_result
    raise Exception()



# Generated at 2022-06-12 05:26:40.168832
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 0, None).filter(lambda x: x == 0) == Try(0, True)
    assert Try.of(lambda: 0, None).filter(lambda x: x == 1) == Try(0, False)
    assert Try.of(lambda: 0, None).filter(lambda x: True) == Try(0, True)
    assert Try.of(lambda: 0, None).filter(lambda x: False) == Try(0, False)
    assert Try.of(lambda: 1/0, None).filter(lambda x: True) == Try(1/0, False)



# Generated at 2022-06-12 05:26:45.490854
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: Try(x, True), 1)\
        .filter(lambda x: x == 1)\
        == Try(1, True)
    assert Try.of(lambda x: Try(x, True), 1)\
        .filter(lambda x: x == 2)\
        == Try(1, False)


# Generated at 2022-06-12 05:26:48.809749
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, 1).filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(int, '1').filter(lambda x: x > 0) == Try('1', False)



# Generated at 2022-06-12 05:26:53.849938
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(2, True).filter(lambda x: x == 1) == Try(2, False)

    assert Try(Exception('Error'), False).filter(lambda x: x == 1) == Try(Exception('Error'), False)



# Generated at 2022-06-12 05:27:00.838214
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """
    assert Try.of(lambda a: a, 10).filter(lambda a: a >= 10) == Try(10, True)
    assert Try.of(lambda a: a, 10).filter(lambda a: a < 10) == Try(10, False)
    assert Try.of(lambda a: a, 10).filter(lambda a: True) == Try(10, True)
    assert Try.of(lambda a: a, 10).filter(lambda a: False) == Try(10, False)



# Generated at 2022-06-12 05:27:09.372617
# Unit test for method filter of class Try
def test_Try_filter():
    # Test when successfully and filterer return False
    m = Try(12, True)
    m = m.filter(lambda x: False)
    assert m.is_success is False

    # Test when successfully and filterer return True
    m = Try(12, True)
    m = m.filter(lambda x: True)
    assert m.is_success is True

    # Test when not successfully
    m = Try(12, False)
    m = m.filter(lambda x: True)
    assert m.is_success is False



# Generated at 2022-06-12 05:27:15.128315
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda _: True) == Try(1, True)
    assert Try(1, True).filter(lambda _: False) == Try(1, False)
    assert Try(1, False).filter(lambda _: True) == Try(1, False)
    assert Try(1, False).filter(lambda _: False) == Try(1, False)


# Generated at 2022-06-12 05:27:21.338740
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 0) == Try(10, True)
    assert Try(10, True).filter(lambda x: x > 15) == Try(10, False)
    assert Try(10, False).filter(lambda x: x > 0) == Try(10, False)

if __name__ == "__main__":
    test_Try_filter()

# Generated at 2022-06-12 05:27:38.293184
# Unit test for method filter of class Try
def test_Try_filter():
    tested_cases = [
        (Try(1, True).filter(lambda x: x == 1), True),
        (Try(1, True).filter(lambda x: x != 1), False),
        (Try(None, False).filter(lambda x: x != 1), False),
        (Try(NotImplementedError(), False).filter(lambda x: x != 1), False)
    ]

    for tested_case in tested_cases:
        assert tested_case[0].is_success == tested_case[1],\
            'Failed Try[{}].filter(lambda x: x != {})'.format(tested_case[0].value, tested_case[0].value)



# Generated at 2022-06-12 05:27:46.898749
# Unit test for method filter of class Try
def test_Try_filter():
    res1 = Try.of(lambda: 1).filter(lambda x: x > 2)
    assert res1 == Try(1, False)

    res2 = Try.of(lambda: 1).filter(lambda x: x < 2)
    assert res2 == Try(1, True)

    res3 = Try.of(lambda: 'a' == 'a').filter(lambda x: True)
    assert res3 == Try('a' == 'a', True)

    res4 = Try.of(lambda: 'a' == 'b').filter(lambda x: True)
    assert res4 == Try('a' == 'b', False)



# Generated at 2022-06-12 05:27:54.076159
# Unit test for method filter of class Try
def test_Try_filter():
    # When monad is successfully and filterer return True
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)

    # When monad is successfully and filterer return False
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)

    # When monad is not successfully
    assert Try(1, False).filter(lambda x: True) == Try(1, False)



# Generated at 2022-06-12 05:28:01.251934
# Unit test for method filter of class Try
def test_Try_filter():
    def f1():
        return 1
    def f2():
        raise Exception('Test')

    assert Try.of(f1).filter(lambda x: x == 1).get() == 1
    assert Try.of(f1).filter(lambda x: x == 2).is_success == False
    assert Try.of(f2).filter(lambda x: x == 1).is_success == False
    assert Try.of(f2).filter(lambda x: x == 1).get().args[0] == 'Test'

# Generated at 2022-06-12 05:28:12.480106
# Unit test for method filter of class Try
def test_Try_filter(): # pragma: no cover
    """
    Unit test for method filter of class Try.
    """

    assert Try(3, True).filter(lambda x: x % 2 == 0) == Try(3, False)
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(6, True).filter(lambda x: x % 2 == 0) == Try(6, True)
    assert Try(5, True).filter(lambda x: x % 2 == 0) == Try(5, False)

    assert Try(6, True).filter(lambda x: x < 10) == Try(6, True)
    assert Try(15, True).filter(lambda x: x < 10) == Try(15, False)

# Generated at 2022-06-12 05:28:18.327001
# Unit test for method filter of class Try
def test_Try_filter():
    def div(a, b):
        return a/b
    assert Try.of(div, 1, 2).filter(lambda x: x > 0) == Try(0.5, True)
    assert Try.of(div, 1, 0).filter(lambda x: x > 0) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-12 05:28:25.987455
# Unit test for method filter of class Try
def test_Try_filter():

    # When monad is successfully and filterer returns True
    def filterer(value):
        return value == 4
    value_1 = 4
    test_try_1 = Try(value_1, True)
    test_1 = test_try_1.filter(filterer)
    expected_result_1 = Try(value_1, True)
    assert test_1 == expected_result_1, 'test_1 failed'

    # When monad is successfully and filterer returns False
    value_2 = 4
    test_try_2 = Try(value_2, True)
    test_2 = test_try_2.filter(lambda value: False)
    expected_result_2 = Try(value_2, False)
    assert test_2 == expected_result_2, 'test_2 failed'

    # When

# Generated at 2022-06-12 05:28:30.500297
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x % 2 == 0) == Try(1, False)
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)


# Generated at 2022-06-12 05:28:38.317533
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(42, True).filter(lambda a: a > 24) == Try(42, True)
    assert Try(42, True).filter(lambda a: a < 24) == Try(42, False)
    assert Try(None, False).filter(lambda a: a > 24) == Try(None, False)
    assert Try(42, False).filter(lambda a: a > 24) == Try(42, False)
    assert Try(None, False).filter(lambda a: a < 24) == Try(None, False)


# Generated at 2022-06-12 05:28:43.195556
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)



# Generated at 2022-06-12 05:29:06.817574
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x == 2) == Try(2, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-12 05:29:11.280607
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> test_Try_filter()
    False
    """
    return Try.of(lambda x: 2/x, 0).filter(lambda x: x == 0) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-12 05:29:18.470165
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda _: True) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda _: False) == Try(1, False)
    assert Try.of(lambda: 1 / 0).filter(lambda _: True) == Try(1, False)
    assert Try.of(lambda: 1 / 0).filter(lambda _: False) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda _: True).filter(lambda _: False) == Try(1, False)



# Generated at 2022-06-12 05:29:27.392044
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(13, True).filter(lambda x: x % 2 == 1) == Try(13, True)
    assert Try(13, True).filter(lambda x: x % 2 == 0) == Try(13, False)
    assert Try(13, False).filter(lambda x: x % 2 == 0) == Try(13, False)
    assert Try(None, False).filter(lambda x: x == None) == Try(None, False)
    assert Try(None, True).filter(lambda x: x == None) == Try(None, True)

test_Try_filter()

# Generated at 2022-06-12 05:29:32.640258
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1)\
        == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x != 1)\
        == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x != 1)\
        == Try(1, False)


# Generated at 2022-06-12 05:29:39.089242
# Unit test for method filter of class Try
def test_Try_filter():
    import pytest
    from operator import eq

    # Filter with condition when success
    assert Try(5, True).filter(eq(5)) == Try(5, True)

    # Filter with condition when success
    assert Try(5, True).filter(eq(4)) == Try(5, False)

    # Filter with condition when failure
    assert Try(5, False).filter(eq(5)) == Try(5, False)

    # Test type of result
    assert isinstance(Try(5, True).filter(eq(5)), Try)


# Generated at 2022-06-12 05:29:43.547050
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value >= 10
    assert Try(5, True).filter(filterer) == Try(5, False)
    assert Try(20, True).filter(filterer) == Try(20, True)


# Generated at 2022-06-12 05:29:50.094406
# Unit test for method filter of class Try
def test_Try_filter():
    assert(Try(5, True).filter(lambda n: n > 2) == Try(5, True))
    assert(Try(5, True).filter(lambda n: n > 7) == Try(5, False))
    assert(Try(5, False).filter(lambda n: n > 2) == Try(5, False))
    assert(Try(5, False).filter(lambda n: n > 7) == Try(5, False))


# Generated at 2022-06-12 05:29:56.150150
# Unit test for method filter of class Try
def test_Try_filter():
    # Test 1: try-catch block return 1, when filterer return True - method return Successfully Try with 1
    assert Try.of(lambda: 1, ()).filter(lambda x: True) == Try(1, True)

    # Test 2: try-catch block return 1, when filterer return False - method return not successfully Try with 1
    assert Try.of(lambda: 1, ()).filter(lambda x: False) == Try(1, False)

    # Test 3: try-catch block raises ValueError, when filterer return True - method return not successfully Try with 1
    try:
        int('s')
    except ValueError as e:
        assert Try.of(int, ['s']).filter(lambda x: True) == Try(e, False)

    # Test 4: try-catch block raises ValueError, when filterer return

# Generated at 2022-06-12 05:30:05.013028
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: bool):
        return True

    def filterer_throw(value: bool):
        raise TypeError('Type error')

    def success(value: bool):
        return Try(value, True)

    def fail_throw(value: bool):
        raise TypeError('Type error')

    assert Try(True, True) == Try(True, True).filter(filterer)
    assert Try(False, True) == Try(False, True).filter(filterer)
    assert Try(None, False) == Try(None, True).filter(filterer)
    assert Try(None, False) == Try(None, False).filter(filterer)

    assert Try(True, True) == Try(True, True).filter(filterer_throw)

# Generated at 2022-06-12 05:30:49.823318
# Unit test for method filter of class Try
def test_Try_filter():
    test_value = 5
    assert Try.of(lambda a: a, test_value).filter(lambda x: x == 5) == Try(test_value, True)
    assert Try.of(lambda a: a, test_value).filter(lambda x: x > 5) == Try(test_value, False)
    assert Try.of(lambda a: a, test_value).filter(lambda x: x < 5) == Try(test_value, False)
    assert Try.of(lambda a: a, test_value).filter(lambda x: x >= 5) == Try(test_value, True)
    assert Try.of(lambda a: a, test_value).filter(lambda x: x <= 5) == Try(test_value, True)

# Generated at 2022-06-12 05:30:57.418232
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Try.filter
    """

    def filterer(value):
        return value == 1

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(2, False).filter(filterer) == Try(2, False)


# Generated at 2022-06-12 05:31:01.232169
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 1).filter(lambda x: x == 1) == Try(1, True)


# Generated at 2022-06-12 05:31:04.567485
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value >= 3

    Try.of(lambda: 3).filter(filterer) == Try(3, True)
    Try.of(lambda: 2).filter(filterer) == Try(2, False)

# Generated at 2022-06-12 05:31:10.322255
# Unit test for method filter of class Try
def test_Try_filter():
    """
    GIVEN: class for monad Try
    WHEN: we check filter method
    THEN: we check filter method returns copy of monad,
    when filterer function return True and we check filter method
    returns not successfully monad when filterer function return False
    """
    def filterer(value):
        return value > 3

    monad = Try.of(lambda: 4, None)
    assert monad.filter(filterer) == Try(4, True)

    monad = Try.of(lambda: 2, None)
    assert monad.filter(filterer) == Try(2, False)


# Generated at 2022-06-12 05:31:19.672557
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: True) == Try(True, True)
    assert Try(False, True).filter(lambda x: x) == Try(False, False)
    assert Try('test', True).filter(lambda x: True) == Try('test', True)
    assert Try('test', True).filter(lambda x: False) == Try('test', False)
    assert Try([1, 2, 3], True).filter(lambda x: True) == Try([1, 2, 3], True)
    assert Try([1, 2, 3], True).filter(lambda x: False) == Try([1, 2, 3], False)

# Generated at 2022-06-12 05:31:27.320911
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return True if (value % 2) == 0 else False

    assert Try.of(lambda: 10, ).filter(filterer) == Try(10, True)
    assert Try.of(lambda: 11, ).filter(filterer) == Try(11, False)
    assert Try.of(lambda: KeyError(), ).filter(filterer) == Try(KeyError(), False)


# Generated at 2022-06-12 05:31:33.565388
# Unit test for method filter of class Try

# Generated at 2022-06-12 05:31:42.373151
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v == 1) == Try(1, True)
    assert Try(1, True).filter(lambda v: v == 2) == Try(1, False)
    assert Try(1, False).filter(lambda v: v == 1) == Try(1, False)
    assert Try(1, True).filter(lambda v: v == 1).get() == 1
    assert Try(1, True).filter(lambda v: v == 2).get_or_else(4) == 4
    assert Try(1, True).filter(lambda v: v == 1).get_or_else(4) == 1



# Generated at 2022-06-12 05:31:49.705399
# Unit test for method filter of class Try
def test_Try_filter():
    try_with_10 = Try.of(lambda: 10, None)
    try_with_exception = Try.of(lambda: [][3], None)
    also_try_with_exception = try_with_exception.filter(lambda val: val > 5)
    try_with_10_and_filter = try_with_10.filter(lambda val: val > 5)
    assert try_with_exception == also_try_with_exception
    assert try_with_10 == try_with_10_and_filter

# Generated at 2022-06-12 05:33:19.983777
# Unit test for method filter of class Try
def test_Try_filter():
    """ Unit test for method filter of class Try

    Increasing from 0 to 10 and check if number is even.
    When number is even, this number condition is True, and
    returned Try should be successfully

    :params: None
    :return: None
    :raises: AssertionError
    """

# Generated at 2022-06-12 05:33:28.155293
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True)\
        .filter(lambda x: True)\
        == Try(1, True)

    assert Try(1, True)\
        .filter(lambda x: False)\
        == Try(1, False)

    assert Try(None, False)\
        .filter(lambda x: False)\
        == Try(None, False)

    assert Try(Exception('Error'), False)\
        .filter(lambda x: False)\
        == Try(Exception('Error'), False)



# Generated at 2022-06-12 05:33:32.496126
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(a):
        return a > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(-1, True).filter(filterer) == Try(-1, False)


# Generated at 2022-06-12 05:33:36.031186
# Unit test for method filter of class Try
def test_Try_filter():
    f = Try.of(lambda x: x + x, 2)
    assert f.filter(lambda x: x > 1) == Try(4, True)
    assert f.filter(lambda x: x < 1) == Try(2, False)

test_Try_filter()



# Generated at 2022-06-12 05:33:39.042805
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x: int) -> bool:
        return x == 0

    assert Try(0, True).filter(filterer) == Try(0, True)
    assert Try(1, True).filter(filterer) == Try(1, False)

# Generated at 2022-06-12 05:33:47.921931
# Unit test for method filter of class Try
def test_Try_filter():
    """
    When filterer return True, Try is successfully.
    """
    succ = Try(1, True).filter(lambda _: True)
    assert succ.get() == 1
    assert succ.is_success is True

    """
    When filterer return False, Try is not successfully.
    """
    fail = Try(1, True).filter(lambda _: False)
    assert fail.get() == 1
    assert fail.is_success is False

    """
    Filter don't change not successfully Try.
    """
    fail = Try(1, False).filter(lambda _: True)
    assert fail.get() == 1
    assert fail.is_success is False

