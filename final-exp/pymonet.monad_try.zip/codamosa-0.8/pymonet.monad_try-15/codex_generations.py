

# Generated at 2022-06-12 05:24:00.665821
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(None, True).filter(lambda x: x is None) == Try(None, True)
    assert Try(None, False).filter(lambda x: x is None) == Try(None, False)
    assert Try(None, True).filter(lambda x: x is not None) == Try(None, False)
    assert Try(100, True).filter(lambda x: x < 200) == Try(100, True)

# Generated at 2022-06-12 05:24:10.131995
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    >>> test_Try___eq__()
    """
    # Successfully
    assert Try(True, True) == Try(True, True)
    assert Try('true', True) == Try('true', True)

    # Not successfully
    assert Try(False, False) == Try(False, False)
    assert Try('false', False) == Try('false', False)

    # Othercase
    assert Try(True, True) != Try(False, False)
    assert Try('true', True) != Try('false', True)
    assert Try(True, False) != Try(False, True)



# Generated at 2022-06-12 05:24:21.145077
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def __eq__test(arg1, arg2, expected_res):
        if (Try(arg1, True) == Try(arg2, True)) != expected_res or\
            (Try(arg1, False) == Try(arg2, False)) != expected_res or\
            (Try(arg1, True) == Try(arg2, False)) != expected_res or\
            (Try(arg1, False) == Try(arg2, True)) != expected_res:
            raise Exception("Try.__eq__ test failed")

    __eq__test(1, 1, True)
    __eq__test(1, 2, False)
    __eq__test(1, "1", False)
    __eq__test([], [], True)
    __eq__test([], [1], False)

# Generated at 2022-06-12 05:24:24.410425
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(2, True) == Try(2, True)
    assert Try(2, True) != Try(3, True)
    assert Try(2, True) != Try(2, False)



# Generated at 2022-06-12 05:24:28.026636
# Unit test for method filter of class Try
def test_Try_filter():
    get_value = lambda: int('12345')
    result = Try.of(get_value).filter(lambda v: v < 12345)
    # If get_value function don't raise exception, result monad must be successful.
    assert result.is_success


# Generated at 2022-06-12 05:24:34.150625
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(None, True)
    try_2 = Try(Exception, False)
    try_3 = Try(Exception, False)
    assert try_1 == Try(None, True)
    assert try_2 == try_3
    assert try_1 != try_2


# Generated at 2022-06-12 05:24:38.169658
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda value: value < 0) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda value: value > 0) == Try(1, True)
    assert Try(Exception('Exception message'), False).filter(lambda value: True) == Try(Exception('Exception message'), False)


# Generated at 2022-06-12 05:24:49.694360
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def test_success_true(value):
        assert Try(value, True) == Try(value, True)

    def test_fail_true(value):
        assert Try(value, False) == Try(value, False)

    def test_success_false(value1, value2):
        assert Try(value1, True) != Try(value2, True)

    def test_fail_false(value1, value2):
        assert Try(value1, False) != Try(value2, False)

    test_success_true(0)
    test_success_true('qwerty')
    test_success_true([1, 2, 3])
    test_success_true({'test': 1})

    test_fail_true(0)
    test_fail_true('qwerty')

# Generated at 2022-06-12 05:24:56.916121
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert not (Try(1, True) == Try(1, False))
    assert not (Try(1, False) == Try(1, True))
    assert not (Try(1, True) == Try(2, True))
    assert not (Try(1, False) == Try(2, False))


# Generated at 2022-06-12 05:25:07.718610
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    empty_try_1 = Try(None, True)
    empty_try_2 = Try(None, True)
    assert empty_try_1.__eq__(empty_try_2), "Test fail. Empty Try's should be equal"

    not_empty_try_1 = Try(1, True)
    not_empty_try_2 = Try(1, True)
    assert not_empty_try_1.__eq__(not_empty_try_2), "Test fail. Not empty Try's should be equal"

    empty_try_3 = Try(None, True)
    not_empty_try_3 = Try(1, True)
    assert not empty_try_3.__eq__(not_empty_try_3), "Test fail. Successfully Try with different values should not be equal"


# Generated at 2022-06-12 05:25:16.886754
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_equal(x, y):
        return x == y

    try1 = Try.of(lambda: 1)
    try2 = try1.filter(is_equal)

    try3 = Try.of(lambda: 1)
    try4 = try3.filter(lambda x: x != 1)

    assert try1 == try2
    assert try3 != try4



# Generated at 2022-06-12 05:25:24.383454
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    def filterer_success(value):
        return True

    def filterer_fail(value):
        return False

    try_success = Try('success', True)
    try_fail = Try('fail', False)

    # When & Then
    assert try_success.filter(filterer_success) == Try('success', True)
    assert try_success.filter(filterer_fail) == Try('fail', False)
    assert try_fail.filter(filterer_success) == Try('fail', False)
    assert try_fail.filter(filterer_fail) == Try('fail', False)



# Generated at 2022-06-12 05:25:28.518598
# Unit test for method filter of class Try
def test_Try_filter():   # pragma: no cover
    def always_true():
        return True


    def always_false():
        return False


    def always_float():
        return float('inf')


    assert Try.of(always_true).filter(always_false) == Try(True, False)
    assert Try.of(always_true).filter(always_true) == Try(True, True)



# Generated at 2022-06-12 05:25:33.270436
# Unit test for method filter of class Try
def test_Try_filter():
    var = Try(10, True).filter(lambda x: x > 10)\
        .filter(lambda x: x < 10)\
        .bind(lambda x: Try(x + 1, True))
    if isinstance(var, Try):
        assert var == Try(11, True)
    else:
        assert False

test_Try_filter()



# Generated at 2022-06-12 05:25:37.938188
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(["test", "test"], True).filter(lambda lst: len(lst) == 2) == Try(["test", "test"], True)
    assert Try("", True).filter(lambda v: True) == Try("", False)
    assert Try("", True).filter(lambda v: False) == Try("", False)

# Generated at 2022-06-12 05:25:41.013702
# Unit test for method filter of class Try
def test_Try_filter():
    def is_equal_zero(value):
        return value == 0
    assert Try(0, True).filter(is_equal_zero) == Try(0, True)

# Generated at 2022-06-12 05:25:50.724561
# Unit test for method filter of class Try
def test_Try_filter():
    # test without exception
    assert Try.of(str, Try.of(abs, -1).value).filter(lambda x: True) == Try(str(abs(-1)), True)
    assert Try.of(str, Try.of(abs, -1).value).filter(lambda x: False) == Try('-1', False)

    # test with exception
    assert Try.of(float, Try.of(abs, -1).value).filter(lambda x: True) == Try(float('-1'), False)
    assert Try.of(float, Try.of(abs, -1).value).filter(lambda x: False) == Try(ValueError('could not convert string to float: \'-1\''), False)

# Generated at 2022-06-12 05:25:55.231088
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'hello world').filter(lambda x: len(x) > 10) == Try('hello world', True)
    assert Try.of(lambda: 'hel').filter(lambda x: len(x) > 10) == Try('hel', False)
    assert Try('hello world', False).filter(lambda x: len(x) > 10) == Try('hello world', False)


# Generated at 2022-06-12 05:25:59.757605
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1)\
        == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2)\
        == Try(1, False)



# Generated at 2022-06-12 05:26:02.585652
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda e: e == 1) == Try(1, True)
    assert Try(1, True).filter(lambda e: e != 1) == Try(1, False)
    assert Try(1, False).filter(lambda e: e != 1) == Try(1, False)
    assert Try(Exception('error'), False).filter(lambda e: True) == Try(Exception('error'), False)


# Generated at 2022-06-12 05:26:11.398685
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test Try control, filter method.
    """
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)
    assert Try(10, True).filter(lambda x: x < 5) == Try(10, False)
    assert Try(10, False).filter(lambda x: x > 5) == Try(10, False)


# Generated at 2022-06-12 05:26:18.829059
# Unit test for method filter of class Try
def test_Try_filter():
    """
    :returns: None
    :rtype: NoneType
    """
    assert Try(10, True).filter(lambda v: v > 5) == Try(10, True)
    assert Try(0, True).filter(lambda v: v > 5) == Try(0, False)
    assert Try(0, True).filter(lambda v: v > 5).get_or_else(10) == 10
    assert Try(12, True).filter(lambda v: v > 5).get_or_else(10) == 12


# Generated at 2022-06-12 05:26:24.372600
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    def filter_function(x):
        return x > 1

    # WHEN
    result1 = Try.of(lambda: 2).filter(filter_function)
    result2 = Try.of(lambda: 1).filter(filter_function)

    # THEN
    assert result1 == Try.of(lambda: 2)
    assert result2 == Try(1, False)

# Generated at 2022-06-12 05:26:35.001552
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try
    """
    test_list = [
        (Try(5, True), True),
        (Try(5, False), False),
        (Try(0, True), False),
    ]

    def filterer(value: int) -> bool:
        return value != 0

    for test_case in test_list:
        assert test_case[0].filter(filterer) == Try(test_case[0].get(), test_case[1]),\
            'Try {} should be filtered to {}'.format(test_case[0], test_case[1])



# Generated at 2022-06-12 05:26:38.680115
# Unit test for method filter of class Try
def test_Try_filter():
    def dp(x):
        return x % 2 == 0

    assert Try(5, True).filter(dp) == Try(5, False)

    assert Try(2, True).filter(dp) == Try(2, True)


# Generated at 2022-06-12 05:26:49.557687
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    """
    Test for method filter of class Try:

    1. Successfully single filter
    2. Successfully multiple filter
    3. Successfully single filter with fail value
    4. Successfully multiple filters with fail value
    5. Fail filter
    """
    class MyClass:

        def __init__(self, field: int):
            self.field = field

    def first_filter(val):
        return val.field == 1

    def second_filter(val):
        return val.field == 2

    def third_filter(val):
        return val.field == 3

    # 1.
    t = Try.of(lambda: MyClass(1))
    assert t.filter(first_filter) == Try(MyClass(1), True)

    # 2.

# Generated at 2022-06-12 05:26:58.449453
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    print('-' * 20, 'test_Try_filter', '-' * 20)

    is_positive = lambda num: num >= 0
    is_odd = lambda num: num % 2 != 0

    print('when filterer returns True')
    print('expect: copy of monad')
    print('actual:', Try(1, True).filter(is_positive))

    print('when filterer returns False')
    print('expect: not successfully Try with previous value')
    print('actual:', Try(1, True).filter(is_odd))
    print('actual:', Try(1, True).filter(is_odd))
    print('actual:', Try(1, False).filter(is_odd))
    print('actual:', Try(1, False).filter(is_odd))

# Unit

# Generated at 2022-06-12 05:27:09.480386
# Unit test for method filter of class Try
def test_Try_filter():
    try_test_0 = Try.of(lambda: 2, None)
    assert Try.of(lambda: 2, None).filter(lambda i: i == 2) == try_test_0
    assert try_test_0.filter(lambda i: i == 2) == try_test_0
    assert Try.of(lambda: 3, None).filter(lambda i: i == 2) != try_test_0
    assert Try.of(lambda: 3, None).filter(lambda i: i == 2) != try_test_0
    assert Try.of(lambda: 2, None).filter(lambda i: i == 2) == try_test_0


# Generated at 2022-06-12 05:27:18.275792
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Testing for method filter for class Try.
      When monad successful,
      when filterer return True, filter return copy of monad,
      when filterer return False, filter return not successful monad with previous value.

    :returns: None
    :rtype: NoneType
    """
    # when monad successful
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)

    # when monad not successful
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-12 05:27:26.097221
# Unit test for method filter of class Try
def test_Try_filter():
    # Test when Try is successfully
    t = Try.of(lambda: 5).filter(lambda x: x <= 6)
    assert t == Try(5, True)
    # Test when Try is not successfully
    t = Try.of(lambda: 5).filter(lambda x: x <= 3)
    assert t == Try(5, False)
    # Test when Try is in fail state
    t = Try(ValueError('test'), False).filter(lambda x: x <= 3)
    assert t == Try(ValueError('test'), False)



# Generated at 2022-06-12 05:27:36.574696
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> test_Try_filter()
    3
    """
    def is_prime(number):
        for i in range(2, number):
            if number % i == 0:
                return False
        return True

    return Try.of(int, '3').filter(is_prime).get()

# Generated at 2022-06-12 05:27:46.196108
# Unit test for method filter of class Try
def test_Try_filter():
    try:
        fn = lambda a: a
        test = lambda a: a == 2
        assert Try(2, True).filter(test).get() == 2
        assert Try(1, True).filter(test).is_success is False
        assert Try(2, True).filter(test).get() == 2
        assert Try(1, True).filter(test).is_success is False
    except AssertionError as e:
        print('test_Try_filter test-case - FAILED !')
        print('==> ', e)
    else:
        print('test_Try_filter test-case - PASSED !')
    finally:
        print('---')



# Generated at 2022-06-12 05:27:57.131636
# Unit test for method filter of class Try
def test_Try_filter():
    """
    method filter, return copy of monad for successful result of the filterer,
    and not successfully monad for unsuccessful result
    """
    try_1 = Try(5, True)
    try_2 = Try(5, True)
    try_3 = Try(5, False)
    assert try_1.filter(lambda x: x % 2 == 0) == Try(5, False)
    assert try_2.filter(lambda x: x % 2 == 1) == Try(5, True)
    assert try_2.filter(lambda x: x % 2 == 1) == try_1.filter(lambda x: x % 2 == 1)
    assert try_2.filter(lambda x: x % 2 == 1) != try_3.filter(lambda x: x % 2 == 1)


# Generated at 2022-06-12 05:28:01.910919
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(12, True).filter(lambda x: x == 0) == Try(12, False)
    assert Try(12, True).filter(lambda x: x == 12) == Try(12, True)
    assert Try(0, True).filter(lambda x: x == 0) == Try(0, True)
    assert Try(0, True).filter(lambda x: x != 0) == Try(0, False)



# Generated at 2022-06-12 05:28:08.517844
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test Try filter method.
    """
    assert Try\
        .of(lambda x: x ** 2, 2)\
        .filter(lambda x: x < 10)\
        == Try(4, True)

    assert Try\
        .of(lambda x: x ** 2, 2)\
        .filter(lambda x: x > 10)\
        == Try(4, False)

# Generated at 2022-06-12 05:28:16.400289
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda x: 1/0, 1).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-12 05:28:18.851494
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda v: v > 2) == Try(5, True)
    assert Try(1, True).filter(lambda v: v > 2) == Try(1, False)


# Generated at 2022-06-12 05:28:26.021672
# Unit test for method filter of class Try
def test_Try_filter():
    # case 1: Try with value '2' is successfully and filterer return True
    # Then method filter returns copy of try.
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)

    # case 2: Try with value '2' is successfully and filterer return False
    # Then method filter returns not successfully Try with previous value.
    assert Try(2, True).filter(lambda x: x % 2 != 0) == Try(2, False)

    # case 3: Try with value '2' is not successfully and filterer return False
    # Then method filter returns not successfully Try with previous value.
    assert Try(2, False).filter(lambda x: x % 2 != 0) == Try(2, False)



# Generated at 2022-06-12 05:28:33.082597
# Unit test for method filter of class Try
def test_Try_filter():
    success = Try.of(lambda: 1)
    fail = Try.of(lambda: 1 / 0)

    assert success.filter(lambda x: True) == Try(1, True)
    assert success.filter(lambda x: False) == Try(1, False)
    assert fail.filter(lambda x: True) == Try(ZeroDivisionError(), False)
    assert fail.filter(lambda x: False) == Try(ZeroDivisionError(), False)

# Generated at 2022-06-12 05:28:44.075294
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 1

    try_1 = Try.of(lambda x: x, 1)
    try_2 = Try.of(lambda x: x, 2)
    try_1_filtered_true = Try.of(lambda x: x, 1).filter(filterer)
    try_2_filtered_false = Try.of(lambda x: x, 2).filter(filterer)

    assert try_1 == try_1_filtered_true
    assert try_1_filtered_true.is_success is True
    assert try_1_filtered_true.value == try_1.value
    assert try_2_filtered_false.is_success is False
    assert try_2_filtered_false.value == try_2.value


# Generated at 2022-06-12 05:28:59.709898
# Unit test for method filter of class Try
def test_Try_filter():
    value = 1
    filterer = lambda x: x == 1
    expected = Try(value, True)

    assert expected == Try.of(value, True).filter(filterer)

# Generated at 2022-06-12 05:29:07.373763
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Method test_Try_filter
    """
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x > 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 1) == Try(1, False)
    assert Try(1, True).filter(lambda x: x > 1) == Try(1, False)

# Generated at 2022-06-12 05:29:13.986758
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """
    assert Try.of(lambda: 'a', 1, 2, 3).filter(lambda x: isinstance(x, str)) == Try('a', True)
    assert Try.of(lambda: 1, 1, 2, 3).filter(lambda x: isinstance(x, str)) == Try(1, False)


# Generated at 2022-06-12 05:29:19.600870
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    try_m = Try(5, True)

    try_m1 = try_m.filter(filterer)
    try_m2 = Try(6, True).filter(filterer)
    try_m3 = Try("test", False).filter(filterer)

    assert try_m1.is_success is False
    assert try_m2.is_success is True
    assert try_m3.is_success is False


# Generated at 2022-06-12 05:29:25.054742
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(4, True).filter(lambda x: x > 3) == Try(4, True)
    assert Try(4, True).filter(lambda x: x > 5) == Try(4, False)
    assert Try(4, False).filter(lambda x: x > 5) == Try(4, False)



# Generated at 2022-06-12 05:29:29.381150
# Unit test for method filter of class Try
def test_Try_filter():
    # arrange
    t = Try.of(lambda: 1 / 0, ())

    # act
    new_t = t.filter(lambda _: False)

    # assert
    assert new_t == Try(ZeroDivisionError(), False)



# Generated at 2022-06-12 05:29:36.970276
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 2).filter(lambda x: x == 2) == Try(2, True)
    assert Try.of(lambda: 2).filter(lambda x: x == 1) == Try(2, False)
    assert Try.of(lambda: None).filter(lambda x: x is None) == Try(None, True)
    assert Try.of(lambda: None).filter(lambda x: x is not None) == Try(None, False)
    assert Try.of(lambda: 1 / 0).filter(lambda x: True) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-12 05:29:40.386896
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        if value == 2:
            return True
        return False

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, True)


# Generated at 2022-06-12 05:29:46.390153
# Unit test for method filter of class Try

# Generated at 2022-06-12 05:29:52.029452
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 0

    assert Try(0, True).filter(filterer) == Try(0, True)
    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(0, True).filter(filterer) != Try(1, True)
    assert Try(0, True).filter(filterer) != Try(1, False)


# Generated at 2022-06-12 05:30:24.497766
# Unit test for method filter of class Try
def test_Try_filter():
    # Test for successfully monad
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 2) == Try(1, False)

    # Test for not successfully monad
    assert Try.of(lambda x: x / 0, 1).filter(lambda x: x == 2) == Try(1, False)

# Generated at 2022-06-12 05:30:28.912188
# Unit test for method filter of class Try
def test_Try_filter():    # pragma: no cover
    def filterer(value: int):
        return value > 5

    assert Try(3, True).filter(filterer) == Try(3, False)
    assert Try.of(lambda: 3, None).filter(filterer) == Try(3, False)


# Generated at 2022-06-12 05:30:37.489305
# Unit test for method filter of class Try
def test_Try_filter():
    """ Test for method filter of class Try """
    for i in range(50):
        try_ = Try.of(lambda x: x * 2, 5)
        try_.filter(lambda x: x % 2 == 0)
        try_.filter(lambda x: x <= 9)
        assert try_ == Try(10, True)

        try_ = Try.of(lambda x: x * 2, 5)
        try_.filter(lambda x: x % 2 == 0)
        try_.filter(lambda x: x > 10)
        assert try_ == Try(10, False)

        try_ = Try.of(lambda x: x * 2, 5)
        try_.filter(lambda x: x % 2 == 1)
        assert try_ == Try(10, False)


# Generated at 2022-06-12 05:30:41.544876
# Unit test for method filter of class Try
def test_Try_filter():
    def f(x): return x > 0
    assert Try(2, True).filter(f) == Try(2, True)
    assert Try(-1, True).filter(f) == Try(-1, False)
    assert Try(-1, False).filter(f) == Try(-1, False)

# Generated at 2022-06-12 05:30:47.259730
# Unit test for method filter of class Try
def test_Try_filter():
    def try_call(value):
        return value

    def try_call2(value):
        return value + 1

    def try_call3(value):
        return True if value > 5 else False

    # If you want to see in console all asserts, uncomment next line
    #unittest.util._MAX_LENGTH = 2000

    # Run all unit tests
    unittest.main(verbosity=2)

# Generated at 2022-06-12 05:30:58.427349
# Unit test for method filter of class Try
def test_Try_filter():
    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    assert Try(1, True)\
        .filter(is_positive) == Try(1, True)

    assert Try(-1, True)\
        .filter(is_positive) == Try(-1, False)

    assert Try(-1, True)\
        .filter(is_negative) == Try(-1, True)

    assert Try(1, True)\
        .filter(is_negative) == Try(1, False)

    assert Try(-1, False)\
        .filter(is_negative) == Try(-1, False)

    assert Try(-1, False)\
        .filter(is_positive) == Try(-1, False)



# Generated at 2022-06-12 05:31:03.616958
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 100) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 100) == Try(1, False)

# Generated at 2022-06-12 05:31:09.238600
# Unit test for method filter of class Try
def test_Try_filter():
    string = 'test'
    empty_string = ''
    string_pred = lambda x: bool(x)
    empty_string_pred = bool
    pred = lambda x: bool(x)

    assert Try.of(lambda: string).filter(string_pred) == Try(string, True)
    assert Try.of(lambda: empty_string).filter(empty_string_pred) == Try(empty_string, False)
    assert Try.of(lambda: 1/0).filter(pred) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-12 05:31:15.501289
# Unit test for method filter of class Try
def test_Try_filter():
    def plus_two(x):
        return x + 2

    def is_positive(x):
        return x > 0

    assert Try.of(plus_two, -2).filter(is_positive) == Try(-2, False)
    assert Try.of(plus_two, 2).filter(is_positive) == Try(4, True)


# Generated at 2022-06-12 05:31:23.460545
# Unit test for method filter of class Try
def test_Try_filter():
    succ_try = Try(10, True)
    succ_try2 = Try(11, True)
    fail_try = Try(100, False)
    # Test for True value
    assert succ_try.filter(lambda x: True) == succ_try
    assert succ_try2.filter(lambda x: x == 11) == succ_try2
    # Test for False value
    assert succ_try.filter(lambda _: False) == Try(10, False)
    assert succ_try2.filter(lambda _: False) == Try(11, False)
    assert fail_try.filter(lambda _: True) == fail_try
    assert fail_try.filter(lambda _: False) == fail_try
    # Test callback after filter

# Generated at 2022-06-12 05:31:49.141298
# Unit test for method filter of class Try
def test_Try_filter():
    assert (Try(1, True).filter(lambda x: x % 2 == 0) == Try(1, False))
    assert (Try(1, False).filter(lambda x: x % 2 == 0) == Try(1, False))
    assert (Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True))
    assert (Try(2, False).filter(lambda x: x % 2 == 0) == Try(2, False))



# Generated at 2022-06-12 05:31:54.909274
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    def filterer(value):
        return value % 2 == 0

    # WHEN
    try1 = Try.of(lambda: 12).filter(filterer)
    try2 = Try.of(lambda: 11).filter(filterer)

    # THEN
    assert try1 == Try(12, True)
    assert try2 == Try(11, False)

# Generated at 2022-06-12 05:32:03.707002
# Unit test for method filter of class Try
def test_Try_filter():
    def t1():
        return Try(3, True).filter(lambda v: v % 2 == 0)

    def t2():
        return Try(3, True).filter(lambda v: v % 2 == 1)

    def a1():
        return Try(3, False).filter(lambda v: v % 2 == 0)

    def a2():
        return Try(3, False).filter(lambda v: v % 2 == 1)

    assert t1() == Try(3, False)
    assert t2() == Try(3, True)
    assert a1() == Try(3, False)
    assert a2() == Try(3, False)

# Generated at 2022-06-12 05:32:12.771756
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def fn_that_raise(a):
        raise Exception('wrong')

    def int_checker(a):
        return isinstance(a, int)

    actual_try = Try.of(int_checker, 'a')
    assert Try(False, False) == actual_try.filter(int_checker)

    actual_try = Try.of(fn_that_raise)
    assert Try(Exception('wrong'), False) == actual_try.filter(int_checker)

    actual_try = Try.of(int, '1')
    assert Try(1, True) == actual_try.filter(int_checker)



# Generated at 2022-06-12 05:32:18.603048
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x >= 5) == Try(5, True)
    assert Try(3, True).filter(lambda x: x >= 5) == Try(3, False)
    assert Try(5, False).filter(lambda x: x >= 5) == Try(5, False)



# Generated at 2022-06-12 05:32:25.049539
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'a').filter(lambda v: v == 'a') == Try('a', True)
    assert Try.of(lambda: 'a').filter(lambda v: v == 'b') == Try('a', False)
    try:
        Try.of(lambda: 'a').filter(lambda v: 1/0)
        assert False
    except ZeroDivisionError:
        assert True
    assert Try.of(lambda: None).filter(lambda v: v == 'b') == Try(None, False)
    assert Try(ZeroDivisionError(), False).filter(lambda v: v == 'b') == Try(ZeroDivisionError(), False)



# Generated at 2022-06-12 05:32:27.145236
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(12, True).filter(lambda x: x > 10) == Try(12, True)
    assert Try(12, True).filter(lambda x: x < 10) == Try(12, False)

# Generated at 2022-06-12 05:32:32.963983
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer_return_True(value):
        return True

    try_ = Try.of(lambda: 1, None)
    f_try = try_.filter(filterer_return_True)
    assert f_try == Try(1, True)

    try_ = Try.of(lambda: 1, None)
    f_try = try_.filter(lambda value: value != 1)
    assert f_try == Try(1, False)

    try_ = Try.of(lambda: 1, None)
    f_try = try_.filter(lambda value: value == 1)
    assert f_try == Try(1, True)


# Generated at 2022-06-12 05:32:42.442533
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: int) -> bool:
        return value > 3

    def test(value: int) -> bool:
        return value > 3

    try_filter_1 = Try(None, True).filter(filterer)
    try_filter_2 = Try(1, True).filter(filterer)
    try_filter_3 = Try(2, True).filter(filterer)
    try_filter_4 = Try(3, True).filter(filterer)
    try_filter_5 = Try(4, True).filter(filterer)
    try_filter_6 = Try(5, True).filter(filterer)

    assert try_filter_1 == Try(None, False)
    assert try_filter_2 == Try(1, False)

# Generated at 2022-06-12 05:32:53.502022
# Unit test for method filter of class Try
def test_Try_filter():
    value = 0

    def add_1(x):
        return x + 1

    def add_2(x):
        return x + 2

    def add_3(x):
        return x + 3

    def filter_2(x):
        return x > 2

    # We have chain of monads with functions add_1, add_2 and add_3
    chain = Try.of(add_1, value).map(add_2).map(add_3)

    # We have filters that applied with monad value
    filter_chain = chain.filter(filter_2)

    # Check filter_chain is failed monad and
    # check filter_chain value is equal to previous chain value
    assert filter_chain.is_success == False
    assert filter_chain.value == chain.value

    # We have filters that applied with monad

# Generated at 2022-06-12 05:33:18.121221
# Unit test for method filter of class Try
def test_Try_filter():
    def predicate(value):
        return value > 10

    assert (Try(11, True).filter(predicate) == Try(11, True))
    assert (Try(11, False).filter(predicate) == Try(11, False))
    assert (Try(9, True).filter(predicate) == Try(9, False))


# Generated at 2022-06-12 05:33:22.421488
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x * 2, 2).filter(lambda x: x > 4) == Try(4, True)
    assert Try.of(lambda x: x * 2, 2).filter(lambda x: x > 6) == Try(4, False)



# Generated at 2022-06-12 05:33:25.648042
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(*args):
        return True

    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(10, False).filter(filterer) == Try(10, False)


# Generated at 2022-06-12 05:33:32.458779
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return isinstance(value, int)

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try('a', True).filter(filterer) == Try('a', False)
    assert Try(ValueError(), True).filter(filterer) == Try(ValueError(), True)
    assert Try(Exception(), True).filter(filterer) == Try(Exception(), False)


# Generated at 2022-06-12 05:33:37.409964
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover

    def ident(value):
        return value

    assert Try(ident(True), True).filter(ident) == Try(ident(True), True)
    assert Try(ident(False), True).filter(ident) == Try(ident(False), False)
    assert Try(ident(True), False).filter(ident) == Try(ident(True), False)
    assert Try(ident(False), False).filter(ident) == Try(ident(False), False)

# Generated at 2022-06-12 05:33:41.271426
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x % 2 == 0
    assert Try.of(int, '4').filter(filterer) == Try(4, True)
    assert Try.of(int, '5').filter(filterer) == Try(5, False)

