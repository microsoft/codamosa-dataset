

# Generated at 2022-06-12 05:23:58.626661
# Unit test for method filter of class Try
def test_Try_filter():
    # Test case: test when obj is successfully and filterer return True
    obj = Try(10, True)
    result = obj.filter(lambda v: v == 10).value
    assert result == True

    # Test case: test when obj is successfully and filterer return False
    obj = Try(10, True)
    result = obj.filter(lambda v: v == 9).value
    assert result == False

    # Test case: test when obj is not successfully
    obj = Try(10, False)
    result = obj.filter(lambda v: v == 10).value
    assert result == False



# Generated at 2022-06-12 05:24:02.931333
# Unit test for method filter of class Try
def test_Try_filter():
    def greater_zero(number):
        return number > 0

    assert Try.of(lambda x: 10).filter(greater_zero).is_success
    assert not Try.of(lambda x: 0).filter(greater_zero).is_success
    assert not Try.of(lambda x: -1).filter(greater_zero).is_success



# Generated at 2022-06-12 05:24:10.132903
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: "Success")\
        .filter(lambda value: value == "Success") == Try("Success", True)
    assert Try.of(lambda: "Success")\
        .filter(lambda value: value == "Other") == Try("Success", False)
    assert Try.of(lambda: 1 / 0)\
        .filter(lambda value: value == "Other") == Try("Other", False)


# Generated at 2022-06-12 05:24:14.819888
# Unit test for method filter of class Try
def test_Try_filter():
    fail_try = Try.of(lambda: 1 / 0, ())
    assert not fail_try.filter(lambda _: True).is_success
    assert not fail_try.filter(lambda _: False).is_success
    success_try = Try.of(lambda: 1, ())
    assert success_try.filter(lambda _: True).is_success
    assert not success_try.filter(lambda _: False).is_success

# Generated at 2022-06-12 05:24:21.678312
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.

    :returns: None
    :rtype: None
    """
    assert Try(1, True).filter(lambda x: x) == Try(1, True)
    assert Try(0, True).filter(lambda x: x) == Try(0, False)
    assert Try(0, False).filter(lambda x: x) == Try(0, False)



# Generated at 2022-06-12 05:24:28.040896
# Unit test for method filter of class Try
def test_Try_filter():
    class Error(Exception):
        pass

    def has_number(text):
        return bool(re.search(r'\d', text))

    def non_empty(string):
        if len(string) > 0:
            return True
        raise Error('String is empty.')

    def has_character(text):
        return bool(re.search(r'\S', text))

    # Try not successfully with Error exception
    # and return copy of self when run filter
    try_with_err = Try.of(non_empty, '') \
        .filter(has_character)

    assert try_with_err == Try(Error('String is empty.'), False)

    # Try not successfully with TypeError exception
    # and return copy of self when run filter

# Generated at 2022-06-12 05:24:32.014852
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(value):
        return value % 2 == 0

    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(3, True).filter(is_even) == Try(3, False)
    assert Try(Exception(), False).filter(is_even) == Try(Exception(), False)


if __name__ == "__main__":
    test_Try_filter()

# Generated at 2022-06-12 05:24:35.712975
# Unit test for method filter of class Try
def test_Try_filter():
    def even(x):
        return x % 2 == 0

    assert Try.of(lambda: 1, ).filter(even).is_success == False
    assert Try.of(lambda: 2, ).filter(even).is_success == True


# Generated at 2022-06-12 05:24:38.392276
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) is not None


# Generated at 2022-06-12 05:24:49.843766
# Unit test for method filter of class Try
def test_Try_filter():
    def random_int_array(count):
        """
        Return array with random integer numbers.

        :params count: count of numbers in array.
        :type count: int
        :returns: array with random integer numbers.
        :rtype: [int]
        """
        import random
        return [random.randint(-100, 100) for i in range(0, count)]

    assert Try.of(random_int_array, 10).filter(lambda value: all([x > 0 for x in value])) == Try([], False)
    assert Try.of(random_int_array, 10).filter(lambda value: all([x < 0 for x in value])) == Try([], False)

# Generated at 2022-06-12 05:24:58.794588
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of Try class.
    """
    def filterer(value):
        return True

    def filterer_other(value):
        return False

    try_value = Try.of(lambda: 'a', '')
    assert try_value.filter(filterer) == Try('a', True)
    assert try_value.filter(filterer_other) == Try('a', False)

# Generated at 2022-06-12 05:25:06.341036
# Unit test for method filter of class Try
def test_Try_filter():
    def t(value):
        raise RuntimeError(value)

    try_monad = Try.of(t, 'error')
    try_monad = try_monad.filter(lambda v: v == 'error')
    assert try_monad == Try('error', False)

    try_monad = Try.of(lambda v: v, 'no error')
    try_monad = try_monad.filter(lambda v: v == 'no error')
    assert try_monad == Try('no error', True)



# Generated at 2022-06-12 05:25:12.427309
# Unit test for method filter of class Try
def test_Try_filter():
    def _filter(x):
        return x == 1
    assert Try(1, True).filter(_filter) == Try(1, True)
    assert Try(1, False).filter(_filter) == Try(1, False)
    assert Try(2, True).filter(_filter) == Try(2, False)
    assert Try(2, False).filter(_filter) == Try(2, False)


# Generated at 2022-06-12 05:25:16.850689
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(1, False).filter(lambda x: False) == Try(1, False)



# Generated at 2022-06-12 05:25:21.853643
# Unit test for method filter of class Try
def test_Try_filter():
    fn = lambda x: x+1
    assert Try(0, True).filter(lambda x: x == 0).get() == 0
    assert Try(fn, True).filter(lambda x: x(0) == 1).get()(0) == 1
    assert Try(0, False).filter(lambda x: x == 0).get() == 0
    assert Try(fn, False).filter(lambda x: x(0) == 1).get() is fn

# Generated at 2022-06-12 05:25:29.298007
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: x).get_or_else(False) == True
    assert Try(True, True).filter(lambda x: x).is_success == True
    assert Try(False, True).filter(lambda x: x).get_or_else(True) == True
    assert Try(False, True).filter(lambda x: x).is_success == False
    assert Try(False, True).filter(lambda x: x).get() == False
    assert Try(True, False).filter(lambda x: x).get_or_else(True) == True
    assert Try(True, False).filter(lambda x: x).is_success == False
    assert Try(True, False).filter(lambda x: x).get() == True


# Generated at 2022-06-12 05:25:39.702848
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    """
    1. Try with successfully monad and filterer which return always true
    2. Not successfully Try and filterer which return always true
    3. Successfully Try and filterer which return always false
    4. Not successfully Try and filterer which return always false
    """
    try_success_true = Try(2, True)
    try_fail_true = Try('hello', False)
    try_success_false = Try(2, True)
    try_fail_false = Try('hello', False)

    def filterer_true(v):
        return True

    def filterer_false(v):
        return False

    # WHEN

# Generated at 2022-06-12 05:25:51.017511
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """

    def filterer(x):
        return x < 10

    def filterer_raise_error(x):
        raise Exception('filterer_raise_error')

    def success_callback_raise_error(x):
        raise Exception('success_callback_raise_error')

    assert Try.of(lambda x: x + 10, 1).filter(filterer) == Try.of(lambda x: x + 10, 1).filter(lambda x: x < 10)
    assert Try.of(lambda x: x + 10, 1).filter(lambda x: x < 10).value == 11
    assert Try.of(filterer_raise_error, 1).filter(lambda x: x < 10) == Try.of(filterer_raise_error, 1)

# Generated at 2022-06-12 05:25:56.378947
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """

    def filterer(value):
        return value == 1

    assert F(Try, 1).filter(filterer).get() == 1
    assert F(Try, 0).filter(filterer).get_or_else(-1) == -1



# Generated at 2022-06-12 05:26:05.599161
# Unit test for method filter of class Try
def test_Try_filter():
    # when filterer returns True copy of monad returns
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    # when filterer returns False not successfully Try with previous value returns
    assert Try(1, True).filter(lambda x: x > 2) == Try(1, False)
    # when monad is not successfully Try with previous value returns
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    # when monad is not successfully
    try:
        Try.of(NotImplementedError, 2).filter(lambda x: x % 2 == 0)
    except NotImplementedError as e:
        assert e == 2


# Generated at 2022-06-12 05:26:20.503357
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 10, None).filter(lambda x: x % 2 == 0) == Try(10, True)
    assert Try.of(lambda: 10, None).filter(lambda x: x % 2 == 1) == Try(10, False)
    assert Try.of(lambda: 10, None).filter(lambda x: True) == Try(10, True)
    assert Try.of(lambda: 10, None).filter(lambda x: False) == Try(10, False)

    assert Try.of(lambda: None, None).filter(lambda x: True) == Try(None, False)
    assert Try.of(lambda: None, None).filter(lambda x: False) == Try(None, False)

    assert Try.of(lambda: 10, None).filter(None) == Try(10, True)
    assert Try.of

# Generated at 2022-06-12 05:26:26.796719
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(None, True).filter(lambda x: False) == Try(None, False)
    assert Try(None, False).filter(lambda x: False) == Try(None, False)

if __name__ == "__main__":  # pragma: no cover
    test_Try_filter()

# Generated at 2022-06-12 05:26:37.763550
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    try_ = Try.of(lambda: 10)
    res = try_.filter(filterer)
    assert res == Try(10, True)

    try_ = Try.of(lambda: 10)
    res = try_.filter(lambda value: value <= 0)
    assert res == Try(10, False)

    try_ = Try.of(lambda: 'abc')
    res = try_.filter(lambda value: len(value) <= 0)
    assert res == Try('abc', False)

    try_ = Try(10, False)
    res = try_.filter(lambda value: len(value) <= 0)
    assert res == Try(10, False)



# Generated at 2022-06-12 05:26:43.493749
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """
    checkers.eq(
        Try(10, True).filter(lambda x: x > 10),
        Try(10, False)
    )

    checkers.eq(
        Try(10, True).filter(lambda x: x < 10),
        Try(10, True)
    )


# Generated at 2022-06-12 05:26:48.894467
# Unit test for method filter of class Try
def test_Try_filter():
    success_try = Try(3, True)
    failure_try = Try(3, False)
    assert success_try.filter(lambda x: x > 2) == Try(3, True)
    assert success_try.filter(lambda x: x < 2) == Try(3, False)
    assert failure_try.filter(lambda x: x > 2) == Try(3, False)




# Generated at 2022-06-12 05:26:56.709224
# Unit test for method filter of class Try
def test_Try_filter():
    t = Try.of(lambda: 1)
    assert t.filter(lambda v: True) == Try.of(lambda: 1)
    assert t.filter(lambda __: False) == Try(None, False)

    t = Try.of(lambda: None)
    assert t.filter(lambda v: True) == Try(None, False)
    assert t.filter(lambda __: False) == Try(None, False)

    t = Try.of(lambda: zero_division_error())
    assert t.filter(lambda v: True) == Try(ZeroDivisionError(), False)
    assert t.filter(lambda __: False) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-12 05:27:08.356677
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value > 100

    value = 200
    try_obj = Try.of(lambda: value, None)
    assert try_obj.filter(filterer) == Try(value, True)

    value = 50
    try_obj = Try.of(lambda: value, None)
    assert try_obj.filter(filterer) == Try(value, False)

    value = 200
    try_obj = Try(value, False)
    assert try_obj.filter(filterer) == Try(value, False)

    value = 50
    try_obj = Try(value, False)
    assert try_obj.filter(filterer) == Try(value, False)



# Generated at 2022-06-12 05:27:18.112665
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filterer(value):
        return value > 5

    assert Try.of(lambda x: x, 3).filter(test_filterer) == Try(3, False)
    assert Try.of(lambda x: x, 10).filter(test_filterer) == Try(10, True)
    assert Try.of(lambda x: x, 10.5).filter(test_filterer) == Try(10.5, True)
    assert Try.of(lambda x: x, 3.2).filter(test_filterer) == Try(3.2, False)
    assert Try.of(lambda x: x, None).filter(test_filterer) == Try(None, False)
    assert Try.of(lambda x: x, 'word').filter(test_filterer) == Try('word', False)

# Generated at 2022-06-12 05:27:26.257271
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for Try method filter.

    :return: True when successful, False when error
    :rtype: Boolean
    """
    def filterer(value):
        return True if value > 5 else False

    successful_try = Try(6, True)
    default_value = 0

    assert successful_try.filter(filterer).get() == 6
    assert successful_try.filter(filterer).get_or_else(default_value) == 6
    assert successful_try.filter(filterer).get_or_else(default_value) == 6



# Generated at 2022-06-12 05:27:34.003387
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try(True, False).filter(lambda value: value)\
        == Try(False, False)

    assert Try(False, False).filter(lambda value: value)\
        == Try(False, False)

    assert Try(True, True).filter(lambda value: value)\
        == Try(True, True)

    assert Try(False, True).filter(lambda value: value)\
        == Try(False, False)


# Generated at 2022-06-12 05:27:56.078547
# Unit test for method filter of class Try
def test_Try_filter():
    class TestException(Exception):
        pass

    def filterer_that_raise_exception(value: str) -> bool:
        raise TestException()

    def filterer_that_return_true(value: str) -> bool:
        return True

    def filterer_that_return_false(value: str) -> bool:
        return False

    assert Try("test", True).filter(filterer_that_raise_exception) == Try("test", False)
    assert Try("test", False).filter(filterer_that_raise_exception) == Try("test", False)

    assert Try("test", True).filter(filterer_that_return_false) == Try("test", False)
    assert Try("test", False).filter(filterer_that_return_false) == Try("test", False)

# Generated at 2022-06-12 05:28:02.140867
# Unit test for method filter of class Try
def test_Try_filter():
    # Test when Try is successfully and filterer return True
    def test_func1(value):
        return value < 10

    assert Try(7, True).filter(test_func1) == Try(7, True)

    # Test when Try is successfully and filterer return False
    def test_func2(value):
        return value < 7

    assert Try(7, True).filter(test_func2) == Try(7, False)

    # Test when Try is not successfully
    assert Try(7, False).filter(test_func2) == Try(7, False)



# Generated at 2022-06-12 05:28:11.170848
# Unit test for method filter of class Try
def test_Try_filter():

    def positive(value):
        return value > 0

    def negative(value):
        return value < 0

    # Filter should return self when mondad is successfully and filterer returns True
    assert Try(1, True).filter(positive) == Try(1, True)
    # Filter should return copy of self when mondad is successfully and filterer returns False
    assert Try(1, True).filter(negative).is_success == False

    # Filter should return self when mondad is not successfully
    assert Try(1, False).filter(positive).is_success == False
    assert Try(1, False).filter(negative).is_success == False

# Generated at 2022-06-12 05:28:18.327243
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(
        10, True
    ).filter(lambda x: x == 10) == Try(10, True)
    assert Try(
        10, False
    ).filter(lambda x: x == 10) == Try(10, False)
    assert Try(
        10, True
    ).filter(lambda x: x == 20) == Try(10, False)



# Generated at 2022-06-12 05:28:23.835203
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer_func(x: int) -> bool:
        return x > 0

    assert Try(1, True).filter(filterer_func) == Try(1, True)
    assert Try(1, False).filter(filterer_func) == Try(1, False)
    assert Try(-1, True).filter(filterer_func) == Try(-1, False)
    assert Try(-1, False).filter(filterer_func) == Try(-1, False)


# Generated at 2022-06-12 05:28:28.159130
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: 0 >= x) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)


# Generated at 2022-06-12 05:28:34.653669
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 1
    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(0, True).filter(filterer) == Try(0, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-12 05:28:43.146195
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(v):
        return v > 10

    # Case 1. Successfully Try with value 12, should return successfully Try with value 12
    assert Try(12, True).filter(filterer) == Try(12, True)

    # Case 2. Successfully Try with value 6, should return not successfully Try with value 6
    assert Try(6, True).filter(filterer) == Try(6, False)

    # Case 3. Not successfully Try with value 6, should return not successfully Try with value 6
    assert Try(6, False).filter(filterer) == Try(6, False)

# Generated at 2022-06-12 05:28:47.521970
# Unit test for method filter of class Try
def test_Try_filter():

    def test_on_success():
        result = Try.of(lambda: 3).filter(
            lambda a: a == 3
        )

        assert result == Try(3, True)

    def test_on_fail():
        result = Try.of(lambda: 3).filter(
            lambda a: a == 2
        )

        assert result == Try(3, False)

    test_on_success()
    test_on_fail()

# Generated at 2022-06-12 05:28:53.619698
# Unit test for method filter of class Try
def test_Try_filter():
    def plus_two(x):
        return x + 2

    def is_even(x):
        return x % 2 == 0

    assert Try.of(plus_two, 1).filter(is_even) == Try(None, False)
    assert Try.of(plus_two, 2).filter(is_even) == Try(4, True)

# Generated at 2022-06-12 05:29:19.666724
# Unit test for method filter of class Try
def test_Try_filter():
    """
    This method tests filter method.

    :retruns: None
    :rtype: None
    """
    Try.of(lambda: True).filter(lambda x: True) == Try(True, True)
    Try.of(lambda: True).filter(lambda x: False) == Try(True, False)
    Try.of(lambda: 1 / 0, ()).filter(lambda x: True) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-12 05:29:23.267882
# Unit test for method filter of class Try
def test_Try_filter():
    try_ = Try(4, True).filter(lambda value: value > 5)
    assert not try_.is_success
    assert try_.value == 4
########################################################################################################################


# Generated at 2022-06-12 05:29:34.497224
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Method filter of class Try
    """
    def f1(x: int) -> bool:
        return x > 0
    def f2(x: str) -> bool:
        return True

    source1 = Try(1, True)
    source2 = Try(2, True)
    source3 = Try(-1, True)
    source4 = Try('', True)
    source5 = Try('', False)

    assert source1.filter(f1) == Try(1, True)
    assert source2.filter(f1) == Try(2, True)
    assert source3.filter(f1) == Try(-1, False)
    assert source4.filter(f2) == Try('', True)
    assert source5.filter(f2) == Try('', False)

# Generated at 2022-06-12 05:29:39.509328
# Unit test for method filter of class Try
def test_Try_filter():
    data = [
        (Try(1, True), lambda x: x == 1, True),
        (Try(1, True), lambda x: x == 2, False),
        (Try(1, False), lambda x: True, False),
        (Try(1, False), lambda x: False, False),
    ]

    for (input, function, expected) in data:
        assert input.filter(function).is_success == expected


# Generated at 2022-06-12 05:29:45.860825
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of class Try.
    """
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)
    assert Try(5, True).filter(lambda x: x > 5) == Try(5, False)
    assert Try(10, False).filter(lambda x: x > 5) == Try(10, False)

# Generated at 2022-06-12 05:29:51.608618
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Successfully when filterer returns True or not successfully when returns False.
    """
    def filterer(value):
        return True

    assert Try.of(lambda: 1, ()).filter(filterer) == Try(1, True)

    def filterer(value):
        return False

    assert Try.of(lambda: 1, ()).filter(filterer) == Try(1, False)


# Generated at 2022-06-12 05:29:55.603367
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, False).filter(lambda x: x is not None).is_success is False
    assert Try(None, True).filter(lambda x: x is not None).is_success is False
    assert Try('value', True).filter(lambda x: x is not None).is_success is True

# Generated at 2022-06-12 05:30:02.592655
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try.of(lambda x: 5, 2).filter(lambda x: x < 0) == Try(5, False)
    assert Try.of(lambda x: 5, 2).filter(lambda x: x > 2) == Try(5, True)
    assert Try(5, False).filter(lambda x: x > 2) == Try(5, False)
    assert Try(5, True).filter(lambda x: x > 2) == Try(5, True)


# Generated at 2022-06-12 05:30:10.172106
# Unit test for method filter of class Try
def test_Try_filter():
    # given
    value = 1
    filterer = lambda x: True
    filterer_01 = lambda x: False
    # when
    try_result = Try(value, True).filter(filterer)
    try_result_01 = Try(value, True).filter(filterer_01)
    try_result_02 = Try(value, False).filter(filterer)
    # then
    assert try_result == Try(value, True)
    assert try_result_01 == Try(value, False)
    assert try_result_02 == Try(value, False)



# Generated at 2022-06-12 05:30:16.007511
# Unit test for method filter of class Try
def test_Try_filter():
    fail_value = Exception('Fail value')
    t1 = Try(fail_value, False)
    assert Try(fail_value, False) == t1.filter(lambda x: True)
    assert Try(fail_value, False) == t1.filter(lambda y: False)

    assert Try(0, True) == Try(0, True).filter(lambda x: True)
    assert Try(fail_value, False) == Try(0, True).filter(lambda x: False)



# Generated at 2022-06-12 05:31:03.217847
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'ok').filter(lambda v: isinstance(v, str)) == Try('ok', True)
    assert Try.of(lambda: 'ok').filter(lambda v: isinstance(v, int)) == Try('ok', False)
    assert Try.of(lambda: 'ok').filter(lambda v: isinstance(v, str)).value == 'ok'
    assert Try.of(lambda: None).filter(lambda v: v is not None) == Try(None, False)
    assert Try.of(lambda: None).filter(lambda v: v is not None).value is None

# Generated at 2022-06-12 05:31:07.096590
# Unit test for method filter of class Try
def test_Try_filter():
    assert [Try(1, True).filter(lambda x: True),
            Try(1, True).filter(lambda x: False),
            Try(None, False).filter(lambda x: False)] == \
           [Try(1, True), Try(1, False), Try(None, False)]


# Generated at 2022-06-12 05:31:12.917582
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(4, True).filter(lambda value: value > 3) == Try(4, True)  # True
    assert Try(3, True).filter(lambda value: value > 3) == Try(3, False)  # False
    assert Try(3, False).filter(lambda value: value > 3) == Try(3, False)  # False

# Unit test to check defaul Try behavior

# Generated at 2022-06-12 05:31:17.711787
# Unit test for method filter of class Try
def test_Try_filter():
    """ """
    assert Try.of(pow, 10, 2).filter(lambda x: x < 100).get_or_else(None) == 100
    assert Try.of(pow, 10, 2).filter(lambda x: x < 20).get_or_else(None) is None

# Generated at 2022-06-12 05:31:23.110221
# Unit test for method filter of class Try
def test_Try_filter():
    from unittest import TestCase, main
    from random import randrange
    from math import sqrt

    class Test(TestCase):
        def test_Filter(self):
            for i in range(1000):
                number = randrange(1, 1000)
                length = Try(sqrt(number), True)
                self.assertEqual(length.filter(lambda x: x < 10), Try(sqrt(number), True))
                self.assertEqual(length.filter(lambda x: x > 10), Try(sqrt(number), False))

    main()


# Generated at 2022-06-12 05:31:30.783992
# Unit test for method filter of class Try
def test_Try_filter():
    # Case 1
    def pos_number(num):
        return num > 0

    assert(Try.of(int, 'c').filter(pos_number)
        == Try(ValueError('invalid literal for int() with base 10: \'c\''), False))

    # Case 2
    assert(Try.of(int, '-1').filter(pos_number)
        == Try(ValueError('invalid literal for int() with base 10: \'-1\''), False))

    # Case 3
    assert(Try.of(int, '1').filter(pos_number)
        == Try(1, True))

# Generated at 2022-06-12 05:31:35.738558
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x == 5) == Try(5, True)
    assert Try(4, True).filter(lambda x: x == 5) == Try(4, False)
    assert Try(5, False).filter(lambda x: x == 5) == Try(5, False)


# Generated at 2022-06-12 05:31:40.917732
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 3

    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(10, False).filter(filterer) == Try(10, False)
    assert Try(1, True).filter(filterer) == Try(1, False)

# Generated at 2022-06-12 05:31:43.537991
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)


# Generated at 2022-06-12 05:31:54.872578
# Unit test for method filter of class Try

# Generated at 2022-06-12 05:33:20.203884
# Unit test for method filter of class Try
def test_Try_filter(): # pragma: no cover
    print('test_Try_filter')
    assert Try(1, True).filter(lambda i: i > 0) == Try(1, True)
    assert Try(1, True).filter(lambda i: i < 0) == Try(1, False)
    assert Try(1, False).filter(lambda i: i < 0) == Try(1, False)
    assert Try(-1, True).filter(lambda i: i < 0) == Try(-1, False)
    assert Try(-1, True).filter(lambda i: i > 0) == Try(-1, False)
    print('test_Try_filter passed')


# Generated at 2022-06-12 05:33:25.011022
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x == 'True'

    assert(Try('True', True) == Try(Try('True', True).filter(filterer), True))
    assert(Try('False', False) == Try(Try('False', True).filter(filterer), False))


# Generated at 2022-06-12 05:33:31.614633
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 10) == Try(10, False)
    assert Try(10, True).filter(lambda x: x < 10) == Try(10, False)
    assert Try(10, True).filter(lambda x: x == 10) == Try(10, True)
    assert Try(10, False).filter(lambda x: x > 10) == Try(10, False)


# Generated at 2022-06-12 05:33:38.025035
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 10

    def filterer_throw(value):
        raise ValueError('test exception')
    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(10, True).filter(filterer) == Try(10, False)
    assert Try(11, True).filter(filterer) == Try(11, True)
    assert Try(1, True).filter(filterer_throw) == Try(1, True)
    assert Try(15, True).filter(filterer_throw) == Try(ValueError('test exception'), False)

# Generated at 2022-06-12 05:33:43.583773
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, 1) == Try(1, True).filter(lambda x: x == 1)
    assert Try.of(lambda: 1, 1) != Try(1, True).filter(lambda x: x != 1)
    assert Try(1, False) == Try(1, False).filter(lambda x: x == 1)

