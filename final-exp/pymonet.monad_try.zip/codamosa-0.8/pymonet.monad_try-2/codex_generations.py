

# Generated at 2022-06-12 05:23:56.995149
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    # Successfully
    try_value = Try(6, True).filter(filterer)

    assert try_value.is_success == True
    assert try_value.get() == 6

    # Exception
    try_value = Try(5, True).filter(filterer)

    assert try_value.is_success == False
    assert try_value.get() == 5



# Generated at 2022-06-12 05:24:05.206798
# Unit test for method filter of class Try

# Generated at 2022-06-12 05:24:12.102195
# Unit test for method filter of class Try
def test_Try_filter():
    def div(a, b):
        return Try.of(lambda: a / b)

    assert div(1, 0).filter(lambda x: x == 0) == Try(ZeroDivisionError(), False)
    assert div(1, 1).filter(lambda x: x == 0) == Try(ZeroDivisionError(), False)
    assert div(1, 1).filter(lambda x: x == 1) == Try(1, True)


# Generated at 2022-06-12 05:24:15.702045
# Unit test for method filter of class Try
def test_Try_filter():
    # Setup
    obj = Try(1, True)
    # Exercise
    actual = obj.filter(lambda v: 2 < v)
    # Verify
    assert actual == Try(1, False)
    # Cleanup - none necessary


# Generated at 2022-06-12 05:24:21.064167
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    >>> assert Try(1, True).filter(lambda x: x == 0) == Try(1, False)
    >>> assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    """


# Generated at 2022-06-12 05:24:24.236200
# Unit test for method filter of class Try
def test_Try_filter():
    def is_positive(val):
        return val > 0

    assert Try.of(lambda: 5).filter(is_positive) == Try(5, True)
    assert Try.of(lambda: -5).filter(is_positive) == Try(-5, False)
    assert Try.of(lambda: 5 / 0).filter(is_positive) == Try(ZeroDivisionError(), False)

# Generated at 2022-06-12 05:24:27.254913
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 1

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, True)


# Generated at 2022-06-12 05:24:34.086312
# Unit test for method filter of class Try
def test_Try_filter():
    def some_filterer(value):
        return True
    def other_filterer(value):
        return False

    try_some_filterer = Try(1, True)
    try_other_filterer = Try(2, True)

    assert try_some_filterer.filter(some_filterer) == Try(1, True)
    assert try_some_filterer.filter(other_filterer) == Try(1, False)
    assert try_other_filterer.filter(some_filterer) == Try(2, True)
    assert try_other_filterer.filter(other_filterer) == Try(2, False)


# Generated at 2022-06-12 05:24:40.153497
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(arg):
        return arg % 2 == 0

    def monad_filterer(arg):
        return Try.of(bool, arg % 2 == 0)

    try_success = Try(10, True)
    try_fail = Try(10, False)
    assert try_success.filter(filterer) == Try(10, True)
    assert try_fail.filter(filterer) == Try(10, False)
    assert try_success.filter(filterer).bind(monad_filterer) == Try(True, True)
    assert try_fail.filter(filterer).bind(monad_filterer) == Try(10, False)



# Generated at 2022-06-12 05:24:46.472742
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(val):
        return val > 10

    assert Try(11, True).filter(filterer).get() == 11
    assert Try(1, True).filter(filterer).get_or_else(None) is None
    assert Try(11, False).filter(filterer).get_or_else(None) is None


# Generated at 2022-06-12 05:24:54.688555
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> test_Try_filter()
    True
    """
    return Try(0, True).filter(lambda x: x == 0) == Try(0, True)\
        and Try(10, True).filter(lambda x: x == 0) == Try(10, False)


# Generated at 2022-06-12 05:25:00.716564
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit testing for method filter of class Try.
    """
    inc = lambda x: x + 1

    assert Try.filter(Try(1, True), inc) == Try(1, True)
    assert Try.filter(Try(1, False), inc) == Try(1, False)
    assert Try.filter(Try(1, True), lambda x: False) == Try(1, False)



# Generated at 2022-06-12 05:25:06.757167
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value % 2 == 0

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, True)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(2, False).filter(filterer) == Try(2, False)


# Generated at 2022-06-12 05:25:09.950243
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, False).filter(lambda _: False) == Try(1, False)
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda _: False) == Try(1, False)

# Generated at 2022-06-12 05:25:16.401556
# Unit test for method filter of class Try
def test_Try_filter():
    def test_integer():
        def filterTrue(x):
            return x > 2

        def filterFalse(x):
            return x < 0

        assert Try.of(lambda: 1).filter(filterTrue) == Try(1, False)
        assert Try.of(lambda: 3).filter(filterTrue) == Try(3, True)
        assert Try.of(lambda: 1).filter(filterFalse) == Try(1, False)
        assert Try.of(lambda: -1).filter(filterFalse) == Try(-1, False)
        assert Try.of(lambda: 0).filter(filterFalse) == Try(0, False)

    def test_string():
        def filterTrue(x):
            return x == 'my_string'

        def filterFalse(x):
            return x == ''


# Generated at 2022-06-12 05:25:25.028548
# Unit test for method filter of class Try
def test_Try_filter():
    is_positive = lambda x: x > 0
    is_negative = lambda x: x < 0

    assert Try(-2, True).filter(is_positive) == Try(-2, False)
    assert Try(-2, True).filter(is_negative) == Try(-2, True)

    assert Try(2, True).filter(is_positive) == Try(2, True)
    assert Try(2, True).filter(is_negative) == Try(2, False)

    assert Try(2, False).filter(is_positive) == Try(2, False)
    assert Try(2, False).filter(is_negative) == Try(2, False)

    assert Try(-2, False).filter(is_positive) == Try(-2, False)
    assert Try(-2, False).filter(is_negative) == Try(-2, False)

# Generated at 2022-06-12 05:25:28.310190
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(5, True).filter(lambda x: x > 3) == Try(5, True)
    assert Try(1, True).filter(lambda x: x > 3) == Try(1, False)
    assert Try(5, False).filter(lambda x: x > 3) == Try(5, False)



# Generated at 2022-06-12 05:25:38.312647
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 2).filter(lambda x: x > 1) == Try(2, True)
    assert Try.of(lambda: 2).filter(lambda x: x < 1) == Try(2, False)
    assert Try.of(lambda: [1, 2, 3, 4]).filter(lambda x: all((i < 10 for i in x))) == Try([1, 2, 3, 4], True)
    assert Try.of(lambda: [1, 2, 3, 4]).filter(lambda x: all((i < 4 for i in x))) == Try([1, 2, 3, 4], False)

# Generated at 2022-06-12 05:25:44.690374
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True).filter(lambda x: x > 0) == Try(3, True)
    assert Try(3, True).filter(lambda x: x < 0) == Try(3, False)
    assert Try(3, False).filter(lambda x: x > 0) == Try(3, False)
    assert Try(Exception('error'), False).filter(lambda x: x > 0) == Try(Exception('error'), False)


# Generated at 2022-06-12 05:25:51.898810
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """
    def filterer(n):
        """
        Take number and returns True when number is even.
        """
        return n % 2 == 0
    assert Try(5, True).filter(filterer) == Try(5, False)
    assert Try(6, True).filter(filterer) == Try(6, True)
    assert Try('error', False).filter(filterer) == Try('error', False)



# Generated at 2022-06-12 05:26:00.582134
# Unit test for method filter of class Try
def test_Try_filter():
    # given
    value = 'Hello'
    # and
    checker = lambda x: x == 'Hello'

    # when
    result = Try(value, True).filter(checker)

    # then
    assert result.is_success is True
    assert result.value == value


# Generated at 2022-06-12 05:26:08.181130
# Unit test for method filter of class Try
def test_Try_filter():
    """ Basic test suite for Try.filter method """

    # Test empty try filter
    assert Try(None, True).filter(lambda v: True) == Try(None, True)
    assert Try(None, True).filter(lambda v: False) == Try(None, False)

    # Test empty try filter
    assert Try(None, False).filter(lambda v: True) == Try(None, False)
    assert Try(None, False).filter(lambda v: False) == Try(None, False)

    # Test successful try filter
    assert Try(10, True).filter(lambda v: True) == Try(10, True)
    assert Try(10, True).filter(lambda v: v == 10) == Try(10, True)
    assert Try(10, True).filter(lambda v: v == 100) == Try(10, False)

   

# Generated at 2022-06-12 05:26:14.515503
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x == 0
    try_monad = Try(0, True)
    try_monad2 = Try(10, True)
    assert try_monad.filter(filterer) == Try(0, True)
    assert try_monad2.filter(filterer) == Try(10, False)


# Generated at 2022-06-12 05:26:20.804182
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda x: x+2, 3).filter(lambda x: x % 2 == 0)
    assert result == Try.of(lambda x: x+2, 3).bind(lambda x: Try(x, x % 2 == 0))
    result = Try.of(lambda x: x+2, 4).filter(lambda x: x % 2 == 0)
    assert result == Try.of(lambda x: x+2, 4).bind(lambda x: Try(x, x % 2 == 0))

# Generated at 2022-06-12 05:26:26.232698
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: x) == Try(True, True)
    assert Try(False, True).filter(lambda x: x) == Try(False, False)
    assert Try(True, True).filter(lambda x: not x) == Try(True, False)
    assert Try(False, True).filter(lambda x: not x) == Try(False, True)


# Generated at 2022-06-12 05:26:36.839607
# Unit test for method filter of class Try
def test_Try_filter():

    # Empty value
    assert Try(None, False).filter(lambda x: x is not None) == Try(None, False)\
        , "Empty value"

    # Empty filterer
    assert Try(1, True).filter(lambda x: None) == Try(1, False)\
        , "Empty filterer"

    # Not successfully filterer
    assert Try(1, True).filter(lambda x: False) == Try(1, False)\
        , "Not successfully filterer"

    # Not successfully
    assert Try(None, False).filter(lambda x: x is not None) == Try(None, False)\
        , "Not successfully"

# Generated at 2022-06-12 05:26:47.775029
# Unit test for method filter of class Try
def test_Try_filter():
    x = Try.of(lambda: 5/0)
    fail = Try.of(lambda: 5/0)
    success = Try.of(lambda: 5/1)
    x.filter(lambda x: x == 1)
    success.filter(1)
    success.filter(lambda x: x == 1)
    x.filter(lambda x: x == 1).on_success(print).on_fail(print)
    success.filter(lambda x: x == 1).on_success(print).on_fail(print)
    x.filter(None)
    x.filter(lambda x: x == 1).on_fail(print)
    success.filter(lambda x: x == 1).on_fail(print)
    fail.filter(lambda x: False).on_success(print).on_fail(print)

# Unit test

# Generated at 2022-06-12 05:26:51.706226
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(9, True).filter(lambda x: x % 2 == 0) == Try(9, False)
    assert Try.of(lambda: 4, ()).filter(lambda x: x % 2 == 0) == Try(4, True)


# Generated at 2022-06-12 05:26:54.628805
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x == 5) == Try(5, True) \
                                                and Try(5, True).filter(lambda x: x == 6) == Try(5, False)


# Generated at 2022-06-12 05:27:00.114684
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: True) == Try(1, False)
    assert Try(1, False).filter(lambda x: False) == Try(1, False)


# Generated at 2022-06-12 05:27:11.676083
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(2, True).filter(lambda x: x % 2 == 0).value == 2
    assert Try(3, True).filter(lambda x: x % 2 == 0) == Try(3, False)
    assert Try(3, True).filter(lambda x: x % 2 == 0).value == 3


# Generated at 2022-06-12 05:27:19.185627
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 1).filter(lambda x: x == 1).filter(lambda x: x == 1) == Try(1, True)

    assert Try.of(lambda: 1).filter(lambda x: x == 1).filter(lambda x: x == 2) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 1).filter(lambda x: x == 1).filter(lambda x: x == 2) == Try(1, True)


# Generated at 2022-06-12 05:27:28.317604
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)
    assert Try(10, True).filter(lambda x: x > 15) == Try(10, False)
    assert Try(10, True).filter(lambda x: x > 15).filter(lambda x: x < 20) == Try(10, False)

    assert Try("10", False).filter(lambda x: int(x) > 5) == Try("10", False)
    assert Try("10", True).filter(lambda x: int(x) > 5) == Try("10", True)
    assert Try("10", True).filter(lambda x: int(x) > 5).filter(lambda x: int(x) > 8) == Try("10", True)

# Generated at 2022-06-12 05:27:33.866949
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1').filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(int, '-1').filter(lambda x: x > 0) == Try(-1, False)
    assert Try.of(int, 'a').filter(lambda x: x > 0) == Try('a', False)

# Generated at 2022-06-12 05:27:40.060355
# Unit test for method filter of class Try
def test_Try_filter():
    def f(n):
        return n>=0

    assert Try(4, True).filter(f) == Try(4, True)
    assert Try(4, False).filter(f) == Try(4, False)
    assert Try(-4, True).filter(f) == Try(-4, False)
    assert Try(-4, False).filter(f) == Try(-4, False)

# Generated at 2022-06-12 05:27:48.680239
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 2).filter(lambda val: val > 5) == Try(2, False)
    assert Try.of(lambda: 2).filter(lambda val: val > 1) == Try(2, True)
    assert Try.of(lambda: 'some value').filter(lambda val: val == 'some value') == Try('some value', True)
    assert Try.of(lambda: 'some value').filter(lambda val: val == 'value') == Try('some value', False)
    assert Try.of(lambda x: 1 / x, 0).filter(lambda val: val == 'value') == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(lambda x: 1 / x, -1).filter(lambda val: val == -1) == Try(ZeroDivisionError('division by zero'), False)
   

# Generated at 2022-06-12 05:27:58.927712
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover

    @Try.of
    def login_into_system(login: str, password: str):
        if login != 'admin' or password != '123':
            raise ValueError('wrong login or password')
        return 'successfully logged'

    @Try.of
    def get_user_id(token: str):
        return 1

    def get_user_id_with_filter(token: str):
        return Try(1, False)

    def validate_user_access(user_id: int):
        return user_id == 1

    # List of tests

# Generated at 2022-06-12 05:28:10.404341
# Unit test for method filter of class Try
def test_Try_filter():
    def function_that_always_raise_exception(x):
        raise Exception('test_exception')

    def function_that_never_raise_exception(x):
        return x

    def filterer_function_that_always_return_True(x):
        return True

    def filterer_function_that_always_return_False(x):
        return False

    # given
    x = 1

    # when
    # TODO: simulate for try monad
    try_function_that_always_raise_exception = Try.of(function_that_always_raise_exception, x)
    try_function_that_never_raise_exception = Try.of(function_that_never_raise_exception, x)

# Generated at 2022-06-12 05:28:19.041370
# Unit test for method filter of class Try
def test_Try_filter():
    d = date(2018, 8, 7)
    age = 15
    result = Try.of(date, 2018, 8, 7)\
        .bind(lambda x: Try.of(lambda age: age < 18, age))\
        .filter(lambda res: res)\
        .on_success(lambda res: print('OK'))\
        .on_fail(lambda res: print('Fail'))\
        .get()
    assert result
    assert age == 15
    assert d == date(2018, 8, 7)

# Generated at 2022-06-12 05:28:28.578397
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try
    """
    assert Try.of(lambda: 1, ) == Try.of(lambda: 1, ).filter(lambda x: x > 0)
    assert Try.of(lambda: 1, ) == Try.of(lambda: 1, ).filter(lambda x: x <= 0)
    assert Try.of(lambda: 1, ) != Try.of(lambda: 1, ).filter(lambda x: x < 0)
    assert Try.of(lambda: ValueError, ) != Try.of(lambda: ValueError, ).filter(lambda x: x > 0)
    assert Try.of(lambda: ValueError, ) == Try.of(lambda: ValueError, ).filter(lambda x: x < 0)


# Generated at 2022-06-12 05:28:49.107345
# Unit test for method filter of class Try
def test_Try_filter():
    # given
    counter = 0
    value = 1
    incrementer = lambda x: x + 1

    # and
    filter_true = lambda x: True
    filter_false = lambda x: False

    # when
    try_success_filter_true = Try.of(incrementer, value).filter(filter_true)
    try_success_filter_false = Try.of(incrementer, value).filter(filter_false)
    try_fail_filter_true = Try.of(lambda x: 1/0, value).filter(filter_true)
    try_fail_filter_false = Try.of(lambda x: 1/0, value).filter(filter_false)

    # then
    try_success_filter_true.on_success(lambda x: counter).on_fail(lambda x: counter + 1)

# Generated at 2022-06-12 05:28:59.500840
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v == 2) == Try(1, False)
    assert Try(1, True).filter(lambda v: v == 1) == Try(1, True)
    assert Try(1, False).filter(lambda v: v == 2) == Try(1, False)
    assert Try(1, False).filter(lambda v: v == 1) == Try(1, False)
    assert Try(1, True).filter(lambda v: False) == Try(1, False)
    assert Try(1, True).filter(lambda v: True) == Try(1, True)
    assert Try(1, False).filter(lambda v: False) == Try(1, False)
    assert Try(1, False).filter(lambda v: True) == Try(1, False)

# Generated at 2022-06-12 05:29:05.847967
# Unit test for method filter of class Try
def test_Try_filter():
    result_t = Try.of(int, '1')
    assert result_t.filter(lambda x: x == 1) == Try(1, True)
    result_f = Try.of(int, 'a')
    assert result_f.filter(lambda x: x == 1) == Try('a', False)


# Generated at 2022-06-12 05:29:11.762754
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Monad filter test
    """
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(None, False).filter(lambda x: x == 1) == Try(None, False)


# Generated at 2022-06-12 05:29:19.857130
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    def filterer(x):
        """
        This function take value x and return True if x > 0, False otherwise.

        :params x: int value
        :type x: int
        :returns: boolean value
        :rtype: Boolean
        """
        return x > 0

    assert Try.of(lambda x: x, 1).filter(filterer) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: x < 0) == Try(1, False)
    assert Try.of(lambda x: x, -1).filter(filterer) == Try(-1, False)


# Generated at 2022-06-12 05:29:23.441955
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda v: v == 1).get() == 1
    assert Try.of(lambda: 1).filter(lambda v: v == 2).is_success is False



# Generated at 2022-06-12 05:29:30.025814
# Unit test for method filter of class Try
def test_Try_filter():
    e1 = Try(1, True)
    f = lambda x: x > 0
    assert e1.filter(f) == Try(1, True)
    f = lambda x: x < 0
    assert e1.filter(f) == Try(1, False)
    e2 = Try(Exception('Test'), False)
    assert e2.filter(f) == e2


# Generated at 2022-06-12 05:29:35.798050
# Unit test for method filter of class Try
def test_Try_filter():
    def dividable_by_two(value):
        return value % 2 == 0

    print(Try(2, True).filter(dividable_by_two))
    print(Try(3, True).filter(dividable_by_two))
    print(Try(2, False).filter(dividable_by_two))
    print(Try(Exception('Error'), False).filter(dividable_by_two))


# Generated at 2022-06-12 05:29:38.853879
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1').filter(lambda v: v < 4) == Try(1, True)
    assert Try.of(int, '2').filter(lambda v: v > 4) == Try(2, False)


# Generated at 2022-06-12 05:29:43.320842
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filter(input, expected):
        assert Try(input, True).filter(
            lambda x: x >= 0)\
                == expected

    test_filter(5, Try(5, True))
    test_filter(-5, Try(-5, False))


# Generated at 2022-06-12 05:30:14.336465
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1').filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(int, '1').filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(int, 'a').filter(lambda x: x == 1) == Try('a', False)

# Generated at 2022-06-12 05:30:22.106181
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def test_func(value):
        if value is None or value == '' or value == ' ':
            return Try(None, False)
        else:
            return Try(''.join(value.split()), True)

    assert test_func(' ').filter(lambda x: x is not None and len(x) > 0) == Try(None, False)
    assert test_func(' asd ').filter(lambda x: x is not None and len(x) > 0) == Try('asd', True)



# Generated at 2022-06-12 05:30:27.506059
# Unit test for method filter of class Try
def test_Try_filter():
    def run(arg):
        return Try.of(lambda: 42 / arg)

    assert run(6).filter(lambda x: x % 2 == 0) == Try(7, True)
    assert run(6).filter(lambda x: x % 2 == 1) == Try(7, False)
    assert run(0).filter(lambda x: x % 2 == 0) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-12 05:30:29.875977
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x < 10) == Try(5, True)
    assert Try(5, True).filter(lambda x: x > 10) == Try(5, False)
    assert Try(5, False).filter(lambda x: x < 10) == Try(5, False)

# Generated at 2022-06-12 05:30:33.852799
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value.__class__ == str

    assert Try('value', True).filter(filterer).is_success

    assert not Try(1, True).filter(filterer).is_success

    assert not Try(Exception(), False).filter(filterer).is_success

    assert not Try(Exception(), False).filter(filterer).is_success

    assert not Try('value', False).filter(filterer).is_success



# Generated at 2022-06-12 05:30:45.475257
# Unit test for method filter of class Try
def test_Try_filter():
    """
    This function unit tests method filter of class Try.
    """
    def apply(e, x):
        return e == x
    try_fail = Try.of(lambda x: 3/x, 0)
    assert try_fail.filter(lambda x: x == 1).is_success is False
    assert try_fail.filter(lambda x: x == 2).is_success is False
    try_success = Try.of(lambda x: 3/x, 1)
    assert try_success.filter(lambda x: x == 1).is_success is True
    assert try_success.filter(lambda x: x == 2).is_success is False
    assert try_success.filter(lambda x: x + 1 == 2).is_success is True

# Generated at 2022-06-12 05:30:55.678222
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully executed cases
    assert Try.of(int, '3').filter(lambda x: x > 0) == Try(3, True)
    assert Try.of(int, '3').filter(lambda x, y: x == y, 3) == Try(3, True)
    assert Try.of(lambda x: x + 1, 2).filter(lambda x: x > 1) == Try(3, True)
    assert Try.of(lambda x: x + 1, 2).filter(lambda x, y: x > y, 1) == Try(3, True)

    # Not successfully executed cases
    assert Try.of(int, 's').filter(lambda x: x > 0) == Try('s', False)
    assert Try.of(int, 's').filter(lambda x: x > 0) == Try('s', False)
   

# Generated at 2022-06-12 05:31:05.727611
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda a: a is True) == Try(True, True)
    assert Try(True, True).filter(lambda a: a is False) == Try(True, False)
    assert Try(False, True).filter(lambda a: a is False) == Try(False, True)
    assert Try(False, True).filter(lambda a: a is True) == Try(False, False)
    assert Try(False, False).filter(lambda a: a is False) == Try(False, False)
    assert Try(False, False).filter(lambda a: a is True) == Try(False, False)
    try:
        Try(True, False).filter(lambda a: a is False)
        assert False
    except Exception:
        assert True


# Generated at 2022-06-12 05:31:09.530948
# Unit test for method filter of class Try
def test_Try_filter():
    def raise_exception():
        raise Exception('Oops')

    def fun(x):
        return x > 0

    assert True == Try.of(lambda: 10).filter(fun).is_success
    assert False == Try.of(raise_exception).filter(fun).is_success
    assert True == Try.of(lambda: -10).filter(fun).is_success


# Generated at 2022-06-12 05:31:17.480916
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(a):
        return a % 2 == 0

    assert Try(2, True).filter(
        is_even
    ) == Try(2, True), "Filter correctly value"
    assert Try(None, False).filter(
        is_even
    ) == Try(None, False), "Filter not successfully monad"
    assert Try(3, True).filter(
        is_even
    ) == Try(3, False), "Filter returns not successfully monad when filterer returns False"

# Generated at 2022-06-12 05:32:24.077231
# Unit test for method filter of class Try
def test_Try_filter():
    def positive(x):
        return x > 0

    assert isinstance(Try(1, True).filter(positive), Try), 'Must be instance of Try'
    assert Try(1, True).filter(positive).is_success, 'Must be successfully'
    assert Try(1, True).filter(positive).get() == 1, 'Must be eq 1'

    assert isinstance(Try(1, False).filter(positive), Try), 'Must be instance of Try'
    assert not Try(1, False).filter(positive).is_success, 'Must be not successfully'
    assert Try(1, False).filter(positive).get() == 1, 'Must be eq 1'

    assert isinstance(Try(-1, True).filter(positive), Try), 'Must be instance of Try'

# Generated at 2022-06-12 05:32:30.480420
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x: int) -> bool:
        return x < 5

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(6, True).filter(filterer) == Try(6, False)
    assert Try(6, False).filter(filterer) == Try(6, False)



# Generated at 2022-06-12 05:32:34.920458
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    try_ = Try(1, True)
    # WHEN
    new_try = try_.filter(lambda i: i > 0)
    # THEN
    assert new_try.is_success
    assert new_try.value == 1

# Generated at 2022-06-12 05:32:42.068446
# Unit test for method filter of class Try
def test_Try_filter():
    number = Try(12, True)
    string = Try('12', True)
    error = Try(ValueError(), False)

    assert number.filter(lambda x: x > 10) == Try(12, True)
    assert number.filter(lambda x: x <= 10) == Try(12, False)

    assert string.filter(lambda x: x == '12') == Try('12', True)
    assert string.filter(lambda x: x == 12) == Try('12', False)

    assert error.filter(lambda x: True) == error
    assert error.filter(lambda x: False) == error


# Generated at 2022-06-12 05:32:45.386976
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 10).filter(lambda x: x < 5) == Try(10, False)
    assert Try.of(lambda: 10).filter(lambda x: x > 5) == Try(10, True)


# Generated at 2022-06-12 05:32:50.613653
# Unit test for method filter of class Try
def test_Try_filter():
    value = 'value'
    on_success = lambda value: True
    try_value = Try.of(lambda: value)
    try_value_filtered = Try(value, True)
    assert try_value.filter(on_success) == try_value_filtered

# Generated at 2022-06-12 05:32:55.093406
# Unit test for method filter of class Try
def test_Try_filter():
    def should_filter_by(value):
        return value == 'v'

    success = Try('v', True)
    assert success.filter(should_filter_by).is_success

    success_bad = Try('bad', True)
    assert not success_bad.filter(should_filter_by).is_success

    not_success = Try('v', False)
    assert not not_success.filter(should_filter_by).is_success



# Generated at 2022-06-12 05:33:05.385112
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from typing import List

    def add(a: int, b: int) -> int:
        return a + b

    def mul(a: int, b: int) -> int:
        return a * b

    def filterer(lst: List[int]) -> bool:
        lst.append(2)
        for x in lst:
            if x == 0:
                return False
        return True

    try_add = Try.of(add, 1, 2)
    try_mul = Try.of(mul, 3, 0)

    assert try_add == Try(3, True)
    assert try_mul == Try(0, True)

    try_add = try_add.map(lambda x: x + 3)

# Generated at 2022-06-12 05:33:09.872443
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value >123

    try_one = Try(124, True)
    try_two = Try(122, True)

    assert try_one.filter(filterer) == Try(124, True)
    assert try_two.filter(filterer) == Try(122, False)


# Generated at 2022-06-12 05:33:17.902137
# Unit test for method filter of class Try
def test_Try_filter():
    # Define function that we will use for filter monad
    def test_filter(value):
        return value < 5

    # Successful case
    try_successful = Try.of(lambda: [1, 2, 3])\
        .filter(test_filter)
    assert try_successful.is_success

    # Fail case
    try_fail = Try.of(lambda: [1, 2, 3, 4, 5])\
        .filter(test_filter)
    assert not try_fail.is_success