

# Generated at 2022-06-12 05:23:55.186982
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(100, True).filter(lambda x: x > 10) == Try(100, True)
    assert Try(100, True).filter(lambda x: x < 10) == Try(100, False)
    assert Try(100, True)\
        .filter(lambda x: x < 10)\
        .on_success(lambda x: print(x))\
        .on_fail(lambda x: print(x)) == Try(100, False)



# Generated at 2022-06-12 05:24:01.644773
# Unit test for method filter of class Try
def test_Try_filter(): #pragma: no cover
    def filterer(value):
        return value > 0

    try_1 = Try(1, True)
    try_2 = Try(2, True)
    try_3 = Try(0, True)

    assert try_1.filter(filterer).is_success
    assert try_2.filter(filterer).is_success
    assert not try_3.filter(filterer).is_success


# Generated at 2022-06-12 05:24:07.679162
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda n: n > 0) == Try(1, True)
    assert Try(1, True).filter(lambda n: n < 0) == Try(1, False)
    assert Try(1, False).filter(lambda n: n < 0) == Try(1, False)



# Generated at 2022-06-12 05:24:16.994915
# Unit test for method filter of class Try
def test_Try_filter():

    def filterer(value):
        return value < 5

    assert Try.of(lambda x: x, [1, 2, 3, 4, 5]).filter(filterer).get() == [1, 2, 3, 4]
    assert Try.of(lambda x: x, [6, 7, 8, 9]).filter(filterer).get() == [6, 7, 8, 9]
    assert not Try.of(lambda x: x, [6, 7, 8, 9]).filter(filterer).is_success
    assert Try.of(lambda x: x, [6, 7, 8, 9]).filter(filterer).get() == [6, 7, 8, 9]



# Generated at 2022-06-12 05:24:22.026608
# Unit test for method filter of class Try
def test_Try_filter():
    try_with_value_5 = Try.of(lambda: 5, 1)
    filterer_less_4 = lambda value: value < 4

    assert not Try.of(lambda: 5, 1).filter(filterer_less_4).is_success
    assert try_with_value_5.filter(filterer_less_4).is_success



# Generated at 2022-06-12 05:24:25.338337
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x % 2 == 0) == Try(5, False)
    assert Try(4, True).filter(lambda x: x % 2 == 0) == Try(4, True)
    assert Try(5, False).filter(lambda x: x % 2 == 0) == Try(5, False)


# Generated at 2022-06-12 05:24:29.053226
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.
    """
    def filter_func(x):
        return x > 3
    assert Try(4, True).filter(filter_func) == Success(4)
    assert Try(0, True).filter(filter_func) == Failure(0)
    assert Try(0, False).filter(filter_func) == Failure(0)



# Generated at 2022-06-12 05:24:37.895752
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, ).map(lambda x: x+7) == Try(8, True)
    assert Try.of(lambda: 1, ).map(lambda x: x+7).filter(lambda x: x < 10) == Try(8, True)
    assert Try.of(lambda: 1, ).map(lambda x: x+7).filter(lambda x: x > 10) == Try(8, False)
    assert Try.of(lambda: 0, ).map(lambda x: x/1) == Try(0, True)
    assert Try.of(lambda: 0, ).map(lambda x: x/0) == Try(ZeroDivisionError(), False)

# Generated at 2022-06-12 05:24:42.378082
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try((lambda x: x > 0)(-1), True).filter(lambda x: x is True) == Try(True, False)
    assert Try((lambda x: x > 0)(1), True).filter(lambda x: x is True) == Try(True, True)



# Generated at 2022-06-12 05:24:51.214196
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 42

    success_try = Try(21, True)
    fail_try = Try(21, False)

    assert success_try.filter(filterer).is_success == False
    assert success_try.filter(filterer) == Try(21, False)

    assert fail_try.filter(filterer).is_success == False
    assert fail_try.filter(filterer) == Try(21, False)

    success_try = Try(42, True)

    assert success_try.filter(filterer).is_success == True
    assert success_try.filter(filterer) == Try(42, True)


# Generated at 2022-06-12 05:25:05.541287
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from pymonad.Maybe import Some, Nothing
    from pymonad.List import to_list
    from pymonad.operators import *
    from pymonad.functor import fmap

    assert (to_list | fmap(lambda x: x + 1) | fmap(Try.of(int, 'a')))(List(1, 2, 3, 4, 5))\
        == [Try(1, True), Try(2, True), Try(3, True), Try(4, True), Try(5, True)]


# Generated at 2022-06-12 05:25:11.816472
# Unit test for method filter of class Try
def test_Try_filter():
    # Test with successfully monad and filterer that return True
    try_success_true = Try(1, True)
    try_success_true.filter(lambda x: True) == Try(1, True)

    # Test with successfully monad and filterer that return False
    try_success_false = Try(1, True)
    try_success_false.filter(lambda x: False) == Try(1, False)

    # Test with not successfully monad that return false
    try_not_success = Try(1, False)
    try_not_success.filter(lambda x: True) == Try(1, False)



# Generated at 2022-06-12 05:25:14.927985
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-12 05:25:22.483419
# Unit test for method filter of class Try
def test_Try_filter():
    subtract = lambda a, b: a - b
    Try_2_2 = Try.of(subtract, 2, 2)
    Try_2_2_filtered_positive = Try_2_2.filter(lambda n: n > 0)
    Try_2_2_filtered_negative = Try_2_2.filter(lambda n: n < 0)

    assert Try_2_2_filtered_positive == Try(0, True)
    assert Try_2_2_filtered_negative == Try(0, False)



# Generated at 2022-06-12 05:25:24.726782
# Unit test for method filter of class Try
def test_Try_filter():
    def _filter_int(value):
        return value > 5

    assert Try.of(lambda: 1).filter(_filter_int) == Try(1, False)
    assert Try.of(lambda: 7).filter(_filter_int) == Try(7, True)

# Generated at 2022-06-12 05:25:26.232635
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 2 + 2, ()).filter(lambda x: x > 4) == Try(None, False)

# Generated at 2022-06-12 05:25:35.176897
# Unit test for method filter of class Try
def test_Try_filter():
    from random import shuffle
    from unittest import TestCase

    class TestTryFilter(TestCase):
        def test_filter_some_values(self):
            values = [1, 2, 3, 4]
            shuffle(values)
            _filter = lambda x: x < 3
            filtered_values = list(
                map(
                    lambda x: Try.of(int, x).filter(_filter).get_or_else(None),
                    values
                )
            )
            self.assertEqual(filtered_values, [1, 2, None, None])
            self.assertEqual(values, [1, 2, 3, 4])

        def test_filter_with_exception(self):
            try:
                raise Exception('filter test exception')
            except Exception as e:
                result = Try(e, False).filter

# Generated at 2022-06-12 05:25:40.069518
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-12 05:25:45.160309
# Unit test for method filter of class Try
def test_Try_filter():
    assert(Try.of(lambda: 1).filter(lambda v: True) == Try(1, True))
    assert(Try.of(lambda: 1).filter(lambda v: False) == Try(1, False))
    assert(Try.of(lambda: 1 / 0).filter(lambda v: True) == Try(ZeroDivisionError(), False))

# Generated at 2022-06-12 05:25:54.535203
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_zero(n):
        return n == 0
    actual = Try(0, True).filter(is_zero)
    assert actual == Try(0, True), 'should be True when is_zero is 0'

    actual = Try(0, True).filter(is_zero)
    assert actual == Try(0, True), 'should be True when is_zero is 0'

    actual = Try(1, True).filter(is_zero)
    assert actual == Try(1, False), 'should be False when is_zero is not 0'

    actual = Try(1, False).filter(is_zero)
    assert actual == Try(1, False), 'should be False when is_zero is not 0'



# Generated at 2022-06-12 05:25:59.045043
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(i):
        return isinstance(i, int)

    print(Try.of(int, '1').filter(filterer))
    print(Try.of(int, 'a').filter(filterer))

# Generated at 2022-06-12 05:26:02.683432
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def test_filter(filterer, arg, expected_result):
        try_instance = Try(arg, True)
        result = try_instance.filter(filterer)
        assert result == expected_result

    test_filter(lambda x: x == 5, 5, Try(5, True))
    test_filter(lambda x: x == 5, 3, Try(3, False))
    test_filter(lambda x: x == 5, 3, Try(3, False))
    test_filter(lambda x: x == 5, 5, Try(5, True))



# Generated at 2022-06-12 05:26:05.612134
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    """
    >>> def filtre(x):
    ...   return x == 2
    >>> assert Try.of(lambda x: x, 1).filter(filtre) == Try(1, False)
    """

# Generated at 2022-06-12 05:26:11.980924
# Unit test for method filter of class Try
def test_Try_filter():
    t1 = Try.of(lambda: 5 / 0)
    t2 = Try.of(lambda: 5 / 0).filter(lambda v: v > 0)
    t3 = Try.of(lambda: 5 * 2).filter(lambda v: v > 0)

    assert (t1 == Try(None, False))
    assert (t2 == Try(None, False))
    assert (t3 == Try(10, True))


# Generated at 2022-06-12 05:26:21.061693
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda a, b: a / b, 1, 0).filter(lambda x: x > 0)
    assert result == Try(ZeroDivisionError('division by zero',), False)

    result = Try.of(lambda a, b: a / b, 1, 2).filter(lambda x: x > 0)
    assert result == Try(0.5, True)

    result = Try.of(lambda a, b: a / b, 1, 2).filter(lambda x: x > 0).map(lambda x: x + 1)
    assert result == Try(1.5, True)

    result = Try.of(lambda a, b: a / b, 1, 0).filter(lambda x: x > 0).map(lambda x: x + 1)

# Generated at 2022-06-12 05:26:26.636427
# Unit test for method filter of class Try
def test_Try_filter():
    try:
        # asserts that when filterer return True method filter return Try with previous value
        assert Try(10, True).filter(lambda x: x > 8) == Try(10, True)
        # asserts that when filterer return Flase method filter return not successfully Try with previous value
        assert Try(10, True).filter(lambda x: x > 12) == Try(10, False)
    except Exception as err:
        print(err)



# Generated at 2022-06-12 05:26:34.283343
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)

# Generated at 2022-06-12 05:26:40.191184
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    try_monad = Try.of(int, '1')
    try_monad2 = Try.of(int, 'one')

    assert try_monad.filter(lambda x: x == 1) == Try(1, True) # True
    assert try_monad.filter(lambda x: x == 2) == Try(1, False) # False

    assert try_monad2.filter(lambda x: x == 1) == Try(ValueError(), False) # False
    assert try_monad2.filter(lambda x: x == 2) == Try(ValueError(), False) # False


# Generated at 2022-06-12 05:26:46.757069
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value == 5

    test_value = 5
    try_instance = Try.of(lambda: test_value, None)
    assert try_instance.filter(filterer).is_success

    test_value = 6
    try_instance = Try.of(lambda: test_value, None)
    assert not try_instance.filter(filterer).is_success

# Generated at 2022-06-12 05:26:56.081467
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully Try
    try_value = Try(10, True)
    try_value = try_value.filter(lambda x: x > 8)
    assert try_value.get() == 10
    assert try_value.is_success == True

    # Not successfully Try
    try_value = Try(10, False)
    try_value = try_value.filter(lambda x: x == 10)
    assert try_value.get() == 10
    assert try_value.is_success == False

    # Successfully Try with filter return False
    try_value = Try(10, True)
    try_value = try_value.filter(lambda x: x < 8)
    assert try_value.get() == 10
    assert try_value.is_success == False

# Generated at 2022-06-12 05:27:04.544008
# Unit test for method filter of class Try
def test_Try_filter():
    value = 1
    try_test = Try(value, True)
    assert try_test.filter(lambda x: x == value) == Try(value, True)
    assert try_test.filter(lambda x: x != value) == Try(value, False)


# Generated at 2022-06-12 05:27:12.906992
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filter(fn):
        tryer_of_fn = Try.of(fn, 0)
        filtered_tryer = tryer_of_fn.filter(lambda _: True)
        assert fn(0) == filtered_tryer.get()

        filtered_tryer = tryer_of_fn.filter(lambda v: v == 1)
        assert tryer_of_fn.value == filtered_tryer.value
        assert tryer_of_fn.is_success == filtered_tryer.is_success

        filtered_tryer = tryer_of_fn.filter(lambda _: False)
        assert tryer_of_fn.value == filtered_tryer.value
        assert tryer_of_fn.is_success == filtered_tryer.is_success


    test_filter(lambda _: 1)
   

# Generated at 2022-06-12 05:27:15.836151
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> assert Try(1, True).filter(lambda n: n % 2 == 0) == Try(1, False)
    """
    pass


# Generated at 2022-06-12 05:27:25.922257
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    try_1 = Try(1, True).filter(lambda x: x > 1)
    try_2 = Try(2, True).filter(lambda x: x > 1)
    try_3 = Try(1, False).filter(lambda x: x > 1)
    try_4 = Try(None, False).filter(lambda x: x > 1)

    # Then
    assert(try_1 == Try(1, False))
    assert(try_2 == Try(2, True))
    assert(try_3 == Try(1, False))
    assert(try_4 == Try(None, False))


# Generated at 2022-06-12 05:27:36.575267
# Unit test for method filter of class Try
def test_Try_filter():
    value = 'test'
    not_successful_try = Try(value, False)
    assert not_successful_try.filter(lambda x: x is value) == not_successful_try
    successful_try = Try(value, True)
    assert successful_try.filter(lambda x: x is value) == successful_try
    assert successful_try.filter(lambda x: x is not value) == Try(value, False)
    value = 10
    assert not_successful_try.filter(lambda x: x == value) == not_successful_try
    assert successful_try.filter(lambda x: x == value) == successful_try
    assert successful_try.filter(lambda x: x == value * 3) == Try(value, False)

    value = 'test'

# Generated at 2022-06-12 05:27:41.959660
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Run unit test
    """
    assert Try.of(lambda x: x + 1, 1).filter(lambda x: x > 1) == Try(2, True)
    assert Try.of(lambda x: x + 1, 1).filter(lambda x: x < 1) == Try(2, False)



# Generated at 2022-06-12 05:27:47.415920
# Unit test for method filter of class Try
def test_Try_filter():
    def positive_filter(v): return v > 0
    def negative_filter(v): return v < 0

    actual_positive = Try(1, True).filter(positive_filter)
    assert_positive = Try(1, True)
    assert actual_positive == assert_positive

    actual_negative = Try(1, True).filter(negative_filter)
    assert_negative = Try(1, False)
    assert actual_negative == assert_negative

# Generated at 2022-06-12 05:27:52.807300
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 1
    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try("1", True).filter(filterer) == Try("1", False)



# Generated at 2022-06-12 05:27:56.864971
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda n: n == 1).get() == 1
    assert Try.of(lambda: 1).filter(lambda n: n != 1).is_success == False



# Generated at 2022-06-12 05:28:00.389224
# Unit test for method filter of class Try
def test_Try_filter():
    # arrange
    x = Try.of(lambda x: x, 1)
    # act
    x_filtered = x.filter(lambda x: x % 2 == 1)
    # assert
    assert x_filtered == Try(1, True)



# Generated at 2022-06-12 05:28:14.193498
# Unit test for method filter of class Try
def test_Try_filter():
    # Arrange-Fixture
    class MyException(Exception):
        pass

    # Act & Assert
    assert Try.of(lambda x, y: x + y, 1, 2).filter(lambda x: x > 2) == Try(3, False)
    assert Try.of(lambda x, y: x + y, 5, 2).filter(lambda x: x > 2) == Try(7, True)
    assert Try.of(lambda x, y: x + y, 1, 2).filter(lambda x: x > 2).get() == 3
    assert Try.of(lambda x, y: x + y, 5, 2).filter(lambda x: x > 2).get() == 7

# Generated at 2022-06-12 05:28:20.544780
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value): return value < 10

    assert Try(5, True).filter(filterer) == Try(5, True)
    assert Try(5, False).filter(filterer) == Try(5, False)
    assert Try(15, True).filter(filterer) == Try(15, False)
    assert Try(15, False).filter(filterer) == Try(15, False)


# Generated at 2022-06-12 05:28:23.977770
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 5, 5).filter(lambda x: x == 5).is_success
    assert not Try.of(lambda: 5, 5).filter(lambda x: x == 4).is_success
    assert not Try.of(lambda: 5/0, 5).filter(lambda x: x == 4).is_success


# Generated at 2022-06-12 05:28:30.533854
# Unit test for method filter of class Try
def test_Try_filter():
    # Test successful value
    some_value = 1
    # Test filterer
    filterer = lambda value: value % 2 == 0
    # Test not successful Try
    not_successful_try = Try(some_value, False)

    # Test with not successful Try
    assert Try(some_value, False) == not_successful_try.filter(filterer)

    # Test for successful value and successful filterer
    assert Try(some_value, True) == Try(some_value, True).filter(filterer)

    # Test for successful value and not successful filterer
    assert Try(some_value, False) == Try(some_value, True).filter(lambda value: not filterer(value))


# Generated at 2022-06-12 05:28:38.369923
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try

    >>> test_Try_filter()
    ...

    """

    assert Try.of(lambda str: str.upper() + 'pam!' , 'attractive ').filter(lambda str: len(str) <= 20) == Try('ATTRACTIVE PAM!', True)
    assert Try.of(lambda str: str.upper() + 'pam!' , 'attractive ').filter(lambda str: len(str) <= 8) == Try('attractive ', False)



# Generated at 2022-06-12 05:28:45.956511
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    """
    Unit test for method filter of class Try
    """
    # When value is successfully and filterer return True
    # Should return same object
    def get_true():
        return True
    value = Try(1, True)
    assert value.filter(get_true) == value

    # When value is not successfully and filterer return True
    # Should return not successfully object
    def get_false():
        return False
    value = Try(1, False)
    assert value.filter(get_false) == Try(1, False)

    # When value is successfully and filterer return False
    # Should return not successfully object with same value
    value = Try(1, True)
    assert value.filter(get_false) == Try(1, False)

    # When value is not successfully and fil

# Generated at 2022-06-12 05:28:51.112767
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(42, True).filter(lambda x: x == 42) == Try(42, True)
    assert Try(42, True).filter(lambda x: x != 42) == Try(42, False)
    assert Try(42, False).filter(lambda x: x == 42) == Try(42, False)


# Generated at 2022-06-12 05:28:57.231017
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: int) -> bool:
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(-1, False).filter(filterer) == Try(-1, False)

# Generated at 2022-06-12 05:29:01.580870
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(False, True).filter(lambda x: x is True) == Try(False, False)
    assert Try(True, True).filter(lambda x: x is True) == Try(True, True)
    assert Try(False, True).filter(lambda x: x + 1) == Try(False, False)
    assert Try(True, True).filter(lambda x: x + 1) == Try(True, True)


# Generated at 2022-06-12 05:29:09.205175
# Unit test for method filter of class Try
def test_Try_filter():
    class ExceptionA(Exception):
        pass

    assert Try(100, True).filter(lambda x: x >= 100) == Try(100, True)
    assert Try(100, True).filter(lambda x: x < 100) == Try(100, False)
    assert Try(100, False).filter(lambda x: True) == Try(100, False)
    assert Try(ExceptionA(), False).filter(lambda x: True) == Try(ExceptionA(), False)
    assert Try(ExceptionA(), False).filter(lambda x: False) == Try(ExceptionA(), False)


# Generated at 2022-06-12 05:29:21.710992
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test Try.filter method.
    """
    success = Try(None, True)
    succes_filter_true = success.filter(lambda _: True)
    succes_filter_false = success.filter(lambda _: False)
    fail = Try(None, False)
    fail_filter = fail.filter(lambda _: True)
    assert succes_filter_true is not None
    assert succes_filter_true.is_success is True
    assert succes_filter_false is not None
    assert succes_filter_false.is_success is False
    assert fail_filter is not None
    assert fail_filter.is_success is False


# Generated at 2022-06-12 05:29:33.720498
# Unit test for method filter of class Try
def test_Try_filter():
    """
    When monad is successfully and filterer returns
    True method returns copy of monad, othercase
    not successfully Try with previous value.

    :params:
    :type:
    :returns:
    :rtype:
    """
    from python.src.monad.Try import Try

    def filterer(x):
        return x % 2

    def filterer2(x):
        return x == 0

    def filterer3(x):
        return x == ''

    assert(Try(2, True).filter(filterer) == Try(2, True))
    assert(Try(2, True).filter(filterer2) == Try(0, False))
    assert(Try(2, True).filter(filterer3) == Try('', False))


# Generated at 2022-06-12 05:29:38.809424
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 5, None)\
        .filter(lambda i: i > 3)\
        .get() == 5

    assert Try.of(lambda: 5, None)\
        .filter(lambda i: i < 3)\
        .get_or_else(None) is None

    assert Try.of(lambda: 5, None)\
        .filter(lambda i: i < 3)\
        .is_success is False



# Generated at 2022-06-12 05:29:45.812883
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(12, True).filter(lambda x: x == 12) == Try(12, True)
    assert Try(12, True).filter(lambda x: x == 13) == Try(12, False)
    assert Try(12, False).filter(lambda x: x == 12) == Try(12, False)
    assert Try(12, False).filter(lambda x: x == 13) == Try(12, False)


# Generated at 2022-06-12 05:29:52.214974
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    print('\n{}'.format(Try.of(lambda a: a / 2, 0.0)).filter(lambda a: a != 0.0).get())
    print('{}'.format(Try.of(lambda a: a / 2, 0.0).filter(lambda a: a != 0.0).get()))
    print('{}'.format(Try.of(lambda a: a / 2, 0.0).filter(lambda a: a == 0.0).get()))


# Generated at 2022-06-12 05:29:57.413418
# Unit test for method filter of class Try
def test_Try_filter():
    def assert_try_eq(actual: Try, expected):
        assert actual == expected

    assert_try_eq(
        Try.of(lambda x: x, 1).filter(lambda x: x == 1),
        Try(1, True))

    assert_try_eq(
        Try.of(lambda x: x, 1).filter(lambda x: x == 2),
        Try(1, False))



# Generated at 2022-06-12 05:30:03.368227
# Unit test for method filter of class Try
def test_Try_filter():
    """ Unit test for method filter of class Try """
    try_value = Try('Try', True)
    try_exception = Try(KeyError(), False)

    assert try_value.filter(lambda v: True) == Try('Try', True)
    assert try_value.filter(lambda v: False) == Try('Try', False)
    assert try_exception.filter(lambda v: True) == Try(KeyError(), False)



# Generated at 2022-06-12 05:30:06.727048
# Unit test for method filter of class Try
def test_Try_filter():
    def is_odd(x): return x % 2 == 1
    assert Try(20, True).filter(is_odd) == Try(20, False)
    assert Try(21, True).filter(is_odd) == Try(21, True)

# Generated at 2022-06-12 05:30:12.233677
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)



# Generated at 2022-06-12 05:30:16.484428
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: True) == Try(2, True)
    assert Try(2, True).filter(lambda x: False) == Try(2, False)
    assert Try(2, False).filter(lambda x: True) == Try(2, False)
    assert Try(2, False).filter(lambda x: False) == Try(2, False)



# Generated at 2022-06-12 05:30:39.731888
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # In this test we will test different filtering values.
    # With our first test we test that filtering working
    # when we pass correct value.
    def filterer(value):
        return isinstance(value, int) and value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    # The second test checks that we will have not successfully Try when we pass wrong value.
    assert Try(1, True).filter(lambda _: False) == Try(1, False)
    # The third test checks that we will have not successfully Try when we pass wrong value.
    assert Try(None, False).filter(filterer) == Try(None, False)



# Generated at 2022-06-12 05:30:48.866474
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(15, True).filter(lambda x: x < 10) == Try(15, False)
    assert Try(15, True).filter(lambda x: x > 10) == Try(15, True)
    assert Try(15, False).filter(lambda x: x < 10) == Try(15, False)
    assert Try(15, False).filter(lambda x: x > 10) == Try(15, False)
    assert Try(Exception, False).filter(lambda x: x < 10) == Try(Exception, False)
    assert Try(Exception, False).filter(lambda x: x > 10) == Try(Exception, False)
    assert Try(Exception, True).filter(lambda x: x < 10) == Try(Exception, False)
    assert Try(Exception, True).filter(lambda x: x > 10) == Try(Exception, False)

# Generated at 2022-06-12 05:31:00.776870
# Unit test for method filter of class Try
def test_Try_filter():
    """
    The function returns the amount of odd numbers in the list.

    :params: list to filter
    :type: List[Integer]
    :returns: amount of odd numbers in the list.
    :rtype: Integer
    """
    def foo(list):
        return len(list(filter(lambda x: x % 2 == 0, list)))

    # Value returned when the list is empty
    def foo_with_try(list):
        return Try.of(foo, list)\
            .map(lambda x: 2 * x)\
            .filter(lambda x: x > 10)\
            .get_or_else(0)

    assert foo([]) == 0
    assert foo([0, 1, 5]) == 1
    assert foo([1, 2, 3]) == 1
    assert foo([2, 4, 6]) == 3



# Generated at 2022-06-12 05:31:08.280222
# Unit test for method filter of class Try
def test_Try_filter():

    # Positive testcase
    testcase = Try(5, True)
    assert testcase.filter(lambda x: x > 2) == Try(5, True)

    # Negative testcase
    testcase = Try(5, True)
    assert testcase.filter(lambda x: x > 10) == Try(5, False)

    # Positive testcase
    testcase = Try(5, False)
    assert testcase.filter(lambda x: x > 2) == Try(5, False)

    # Negative testcase
    testcase = Try(5, False)
    assert testcase.filter(lambda x: x > 10) == Try(5, False)


# Generated at 2022-06-12 05:31:19.376931
# Unit test for method filter of class Try
def test_Try_filter():
    assert(
        Try.of(lambda: True)
        .filter(lambda x: x)
        == Try(True, True)
    )

    assert(
        Try.of(lambda: True)
        .filter(lambda x: False)
        == Try(True, False)
    )

    assert(
        Try.of(lambda: False)
        .filter(lambda x: True)
        == Try(False, False)
    )

    assert(
        Try.of(lambda: False)
        .filter(lambda x: False)
        == Try(False, False)
    )

    assert(
        Try.of(lambda: True)
        .filter(lambda x: True)
        .filter(lambda x: False)
        == Try(True, False)
    )

# Generated at 2022-06-12 05:31:30.683246
# Unit test for method filter of class Try
def test_Try_filter():
    class SomeException(Exception):
        pass

    @Try.of
    def div_by_two(number: int) -> Try[int]:
        return int(number / 2)

    assert div_by_two(6).filter(lambda x: x == 3) == Try(3, True)
    assert div_by_two(5).filter(lambda x: x == 3) == Try(5, False)
    assert div_by_two(4).filter(lambda x: x == 3) == Try(4, False)
    assert div_by_two(6).filter(lambda x: x == 3) != Try(2, False)
    assert div_by_two(3).value == 1
    assert div_by_two(3).is_success
    assert div_by_two(0).value == SomeException
    assert not div

# Generated at 2022-06-12 05:31:40.951758
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try
    """
    def is_string(x):
        return x.__class__ == str

    def is_int(x):
        return x.__class__ == int

    def is_int_of_42(x):
        return x == 42

    assert Try.of(lambda: 42).filter(is_string) == Try(42, False)
    assert Try.of(lambda: 42).filter(is_int) == Try(42, True)
    assert Try.of(lambda: 42).filter(is_int_of_42) == Try(42, False)
    assert Try.of(lambda: int("42")).filter(is_string) == Try(int("42"), False)


# Generated at 2022-06-12 05:31:52.408994
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter.

    :returns: True when test success, otherwise False
    :rtype: Boolean
    """
    def _filter(x):
        if x < 10:
            return True
        return False

    def _other_filter(x):
        if x > 10:
            return True
        return False
    try_1 = Try(1, True)
    try_2 = Try(2, True)
    try_11 = Try(11, True)
    assert (try_1.filter(_filter)) == (try_2.filter(_filter))
    assert (try_1.filter(_filter)) != (try_11.filter(_filter))
    assert (try_11.filter(_filter)) == (Try(11, False))


# Generated at 2022-06-12 05:31:57.309204
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> t = Try.of(int, '12').filter(lambda x: x > 10)
    >>> assert t.is_success
    >>> assert t.value == 12
    >>> t = Try.of(int, '1').filter(lambda x: x > 10)
    >>> assert not t.is_success
    >>> assert t.value == 1
    >>> t = Try.of(int, 'a').filter(lambda x: x > 10)
    >>> assert not t.is_success
    >>> assert isinstance(t.value, ValueError)
    """



# Generated at 2022-06-12 05:32:04.274645
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value > 10

    monad = Try(12, True)
    assert monad.filter(filterer).value == 12
    assert monad.filter(filterer).is_success

    monad = Try(10, True)
    assert monad.filter(filterer).value == 10
    assert not monad.filter(filterer).is_success

    monad = Try(10, False)
    assert monad.filter(filterer).value == 10
    assert not monad.filter(filterer).is_success


# Generated at 2022-06-12 05:32:23.213994
# Unit test for method filter of class Try
def test_Try_filter():
    # setup
    method_to_test = Try(None, False)

    def test_filterer(value):
        return True

    def other_filterer(value):
        return False

    # when
    method_to_test.filter(test_filterer)
    method_to_test.filter(other_filterer)

    # then
    assert method_to_test.is_success is False


# Generated at 2022-06-12 05:32:27.716319
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, False).filter(lambda x: True) == Try(None, False)
    assert Try(None, True).filter(lambda x: True) == Try(None, True)
    assert Try('value', True).filter(lambda x: None) == Try('value', False)
    assert Try('value', True).filter(lambda x: True) == Try('value', True)
    assert Try('value', True).filter(lambda x: False) == Try('value', False)



# Generated at 2022-06-12 05:32:32.568411
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, ()).filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(lambda: -1, ()).filter(lambda x: x > 0) == Try(-1, False)

if __name__ == '__main__':
    test_Try_filter()

# Generated at 2022-06-12 05:32:41.633667
# Unit test for method filter of class Try
def test_Try_filter():
    # given
    def even(x):
        return x % 2 == 0
    def odd(x):
        return x % 2 != 0
    # when, then
    assert Try(Success(4)).filter(even).get() == 4
    assert not Try(Success(4)).filter(odd).is_success
    assert Try(Success(5)).filter(odd).get() == 5
    assert not Try(Success(5)).filter(even).is_success
    assert Try(Failure()).filter(odd).get() == None
    assert not Try(Failure()).filter(odd).is_success
    assert not Try(Failure()).filter(even).is_success
    assert Try(Failure()).filter(even).get() == None


# Generated at 2022-06-12 05:32:48.121466
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filterer(a):
        return a > 0
    assert Try(1, True).filter(test_filterer) == Try(1, True)
    assert Try(-1, True).filter(test_filterer) == Try(-1, False)
    assert Try(ValueError, False).filter(test_filterer) == Try(ValueError, False)


# Generated at 2022-06-12 05:32:50.531352
# Unit test for method filter of class Try
def test_Try_filter():
    t0 = Try.of(lambda: 100, 0)
    t1 = t0.filter(lambda x: x > 100)
    t2 = t0.filter(lambda x: x < 500)
    assert t1 == Try(100, False)
    assert t2 == Try(100, True)


# Generated at 2022-06-12 05:32:54.858444
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(Exception(), False).filter(lambda x: x == 1) == Try(Exception(), False)



# Generated at 2022-06-12 05:33:00.664258
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(int, '12').filter(lambda v: v % 2 == 0)
    assert result == Try(12, True)

    result = Try.of(int, '13').filter(lambda v: v % 2 == 0)
    assert result == Try(13, False)


# Generated at 2022-06-12 05:33:06.035983
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(0, True).filter(lambda x: x > 0) == Try(0, False)
    assert Try(100, True).filter(lambda x: x > 0) == Try(100, True)
    assert Try(-100, True).filter(lambda x: x > 0) == Try(-100, False)
    assert Try(-100, True).filter(lambda x: x > 100) == Try(-100, False)



# Generated at 2022-06-12 05:33:16.984716
# Unit test for method filter of class Try
def test_Try_filter():
    try_success = Try(5, True)
    try_success_filtered = try_success.filter(lambda value: value > 3)
    try_success_filtered_2 = try_success.filter(lambda value: value > 8)
    assert try_success_filtered.value == 5
    assert try_success_filtered.is_success == True
    assert try_success_filtered_2.value == 5
    assert try_success_filtered_2.is_success == False

    try_fail = Try(5, False)
    try_fail_filtered = try_fail.filter(lambda value: value > 3)
    assert try_fail_filtered.value == 5
    assert try_fail_filtered.is_success == False



# Generated at 2022-06-12 05:33:38.171033
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully Try with value 3
    try_obj = Try(1, True).map(lambda x: x+5).filter(lambda x: x % 2 == 1)
    assert try_obj.is_success
    assert try_obj.get() == 6

    # Not successfully Try with value 3
    try_obj = Try(1, True).filter(lambda x: x % 2 == 0)
    assert not try_obj.is_success
    assert try_obj.get() == 1



# Generated at 2022-06-12 05:33:48.421009
# Unit test for method filter of class Try
def test_Try_filter():
    # Checking for identity law
    assert Try.of(lambda: 10).filter(lambda value: True) == Try.of(lambda: 10).filter(lambda value: True)
    # Checking for commutativity law
    assert Try.of(lambda: 10).filter(lambda value: True).get() == Try(10, True).get()
    assert Try.of(lambda: 10).filter(lambda value: False).get() == Try(10, False).get()
    # Checking for associativity law
    assert Try.of(lambda: 10).filter(lambda value: True).filter(lambda value: True).get() ==\
        Try(10, True).filter(lambda value: True).get()
    assert Try.of(lambda: 10).filter(lambda value: True).filter(lambda value: False).get() ==\
        Try(10, True).filter