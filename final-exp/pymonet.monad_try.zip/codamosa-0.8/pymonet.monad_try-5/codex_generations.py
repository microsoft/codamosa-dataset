

# Generated at 2022-06-12 05:23:59.303152
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test case

    :params:
    :retruns:
    :rtype:
    """
    try_fail = Try(error_msg, False)
    try_ok = Try(0, True)
    try_fail_filter = try_fail.filter(lambda x: x == error_msg)
    try_ok_filter = try_ok.filter(lambda x: x == 0)

    assert try_fail_filter == Try(error_msg, False)
    assert try_ok_filter == Try(0, True)
    assert Try(0, True).filter(lambda x: x == 1) == Try(0, False)



# Generated at 2022-06-12 05:24:04.827739
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_even(x):
        return x % 2 == 0

    # inputs
    some_value = Try(1, True)
    empty_value = Try(None, False)

    # logic
    is_even_some_value = some_value.filter(is_even)
    is_even_empty_value = empty_value.filter(is_even)

    # asserts
    assert is_even_some_value.is_success == False
    assert is_even_empty_value.is_success == False


# Generated at 2022-06-12 05:24:15.189128
# Unit test for method filter of class Try
def test_Try_filter():
    def setup_module():
        ...

    def teardown_module():
        ...

    def test_Try_filter_1():
        assert(Try(5, True).filter(lambda x: x > 3) == Try(5, True))

    def test_Try_filter_2():
        assert(Try(5, True).filter(lambda x: x < 3) == Try(5, False))

    def test_Try_filter_3():
        assert(Try(5, False).filter(lambda x: x > 3) == Try(5, False))

    def test_Try_filter_4():
        assert(Try('Exception', False).filter(lambda x: x > 3) == Try('Exception', False))

# Generated at 2022-06-12 05:24:19.954109
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 3).filter(lambda value: value % 2 == 0).get_or_else(None) == None
    assert Try.of(lambda: 2).filter(lambda value: value % 2 == 0).get_or_else(None) == 2

# Generated at 2022-06-12 05:24:26.469227
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v == 1)\
            ==\
        Try(1, True)

    assert Try(1, True).filter(lambda v: v != 1)\
            ==\
        Try(1, True)

    assert Try(1, False).filter(lambda v: v == 1)\
            ==\
        Try(1, False)

    assert Try(1, False).filter(lambda v: v != 1)\
            ==\
        Try(1, False)

    assert Try(1, True).filter(lambda v: v == 1)\
            ==\
        Try(1, True)

    assert Try(1, True).filter(lambda v: v != 1)\
            ==\
        Try(1, False)

    assert Try(1, False).filter(lambda v: v == 1)\
           

# Generated at 2022-06-12 05:24:31.517532
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '10').filter(lambda x: x > 0) == Try(10, True)
    assert Try.of(int, '10').filter(lambda x: x < 0) == Try(10, False)
    assert Try.of(int, 'a').filter(lambda x: x > 0).get_or_else(None) == None


# Generated at 2022-06-12 05:24:39.810189
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x):
        return x > 0

    assert Try(3, True).filter(filterer) == Try(3, True)
    assert Try(3.3, True).filter(filterer) == Try(3.3, True)
    assert Try(0, True).filter(filterer) == Try(0, False)
    assert Try(0.0, True).filter(filterer) == Try(0.0, False)
    assert Try(1.5, True).filter(filterer) == Try(1.5, True)
    assert Try(0.1, True).filter(filterer) == Try(0.1, True)
    assert Try(10, True).filter(filterer) == Try(10, True)

# Generated at 2022-06-12 05:24:50.737006
# Unit test for method filter of class Try
def test_Try_filter():
    from fp.core.try_ import Try
    from random import randint

    assert Try.of(lambda a, b: a + b, randint(0, 10), randint(0, 10)).get() < 2 * randint(0, 10)
    assert Try.of(lambda a, b: a + b, randint(0, 10), randint(0, 10)).filter(lambda a: a > 0).get() > 0
    assert not Try.of(lambda a, b: a + b, randint(0, 10), randint(0, 10)).filter(lambda a: a > 0).is_success\
        if Try.of(lambda a, b: a + b, randint(0, 10), randint(0, 10)).get() == 0 else True
    assert not Try.of(lambda: 1 / 0, ).filter

# Generated at 2022-06-12 05:24:57.948454
# Unit test for method filter of class Try
def test_Try_filter():
    def upper(word):
        return word.upper()

    def is_capitalized(word):
        return word[0].isupper()

    assert Try.of(upper, 'test').filter(is_capitalized) == Try('Test', True)
    assert Try.of(upper, 'test').filter(is_capitalized) != Try('test', False)
    assert Try.of(upper, 'test').filter(is_capitalized) != Try('Test', False)


# Generated at 2022-06-12 05:25:03.349546
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 5

    m: Try[int] = Try(2, True)
    assert m.filter(filterer) == Try(2, False)
    m: Try[int] = Try(10, True)
    assert m.filter(filterer) == Try(10, True)



# Generated at 2022-06-12 05:25:10.626455
# Unit test for method filter of class Try
def test_Try_filter():
    test_value = Try(100, is_success=True)
    test_fall_value = Try(100, is_success=False)
    def test_filter(value):
        return value > 1
    assert test_value.filter(test_filter)
    assert not test_fall_value.filter(test_filter)


# Generated at 2022-06-12 05:25:17.138126
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    """
    :returns: None
    :rtype: None
    """
    def test():
        return 'test'
    assert Try(test(), True).filter(lambda x: x() == 'test').get() == 'test'
    assert not Try(test(), True).filter(lambda x: x() == 't').is_success
    assert not Try(test(), False).filter(lambda x: x() == 't').is_success



# Generated at 2022-06-12 05:25:20.878229
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 10).filter(lambda x: x % 2 == 0) == Try(10, True)
    assert Try.of(lambda: 11).filter(lambda x: x % 2 == 0) == Try(11, False)



# Generated at 2022-06-12 05:25:28.869756
# Unit test for method filter of class Try
def test_Try_filter():

    def filterer(value):
        return value % 2 == 0

    # Test with zero
    try_monad = Try(0, True)
    try_zero = try_monad.filter(filterer)
    assert try_zero.is_success
    assert try_zero.value == 0

    # Test with one
    try_monad = Try(1, True)
    try_one = try_monad.filter(filterer)
    assert not try_one.is_success
    assert try_one.value == 1

    # Test with even
    try_monad = Try(2, True)
    try_even = try_monad.filter(filterer)
    assert try_even.is_success
    assert try_even.value == 2

    # Test with odd
    try_monad = Try

# Generated at 2022-06-12 05:25:39.144579
# Unit test for method filter of class Try
def test_Try_filter():
    assert isinstance(Try.of(lambda x: x, 4).filter(lambda x: x > 5), Try)
    assert isinstance(Try.of(lambda x: x, 6).filter(lambda x: x > 5), Try)
    assert Try.of(lambda x: x, 6).filter(lambda x: x > 5).get() == 6
    assert Try.of(lambda x: x, 7).filter(lambda x: x > 5).get() == 7
    assert Try.of(lambda x: x, 6).filter(lambda x: x > 5).is_success == True
    assert Try.of(lambda x: x, 7).filter(lambda x: x > 5).is_success == True
    assert Try.of(lambda x: x, 4).filter(lambda x: x > 5).is_success == False
    assert Try.of

# Generated at 2022-06-12 05:25:43.194661
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 0) == Try.of(lambda x: x, 1)
    assert Try.of(lambda x: x, 1).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-12 05:25:53.276978
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test Try filter method.
    """

    def test_filterer(value):
        return value != 1

    def not_filter_filterer(value):
        return value == 1

    try_1 = Try(1, True)
    try_1.filter(test_filterer)
    try_2 = Try(2, True)
    try_2.filter(test_filterer)

    assert try_1 == Try(1, False)
    assert try_2 == Try(2, True)

    try_1.filter(not_filter_filterer)
    assert try_1 == Try(1, True)

if __name__ == '__main__':
    test_Try_filter()

# Generated at 2022-06-12 05:25:59.501153
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x == 5) == Try(5, True)
    assert Try(5, True).filter(lambda x: x == 6) == Try(5, False)
    assert Try(5, False).filter(lambda x: x == 6) == Try(5, False)


# Generated at 2022-06-12 05:26:03.918594
# Unit test for method filter of class Try
def test_Try_filter():
    test = Try.of(lambda: "hello",)
    non_test = Try.of(lambda: 1 / 0)
    assert test.filter(lambda _: True) == test
    assert test.filter(lambda _: False) == non_test
    assert non_test.filter(lambda _: True) == non_test


# Generated at 2022-06-12 05:26:08.715292
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(4, True).filter(lambda x: x > 2) == Try(4, True)
    assert Try(4, True).filter(lambda x: x >= 4) == Try(4, True)
    assert Try(4, True).filter(lambda x: x < 4) == Try(4, False)
    assert Try(4, True).filter(lambda x: x == 4) == Try(4, True)


# Generated at 2022-06-12 05:26:21.257566
# Unit test for method filter of class Try
def test_Try_filter():
    # None need in when filterer is None
    assert Try(1, True).filter(None).is_success == False
    assert str(Try(1, True).filter(None)) == "Try[value=None, is_success=False]"

    # When filterer return True method should return copy of monad
    assert Try(1, True).filter(lambda _: True).is_success == True
    assert Try(1, True).filter(lambda _: True).value == 1

    # othercase not successfully monad
    assert Try(1, True).filter(lambda _: False).value == 1
    assert Try(1, True).filter(lambda _: False).is_success == False

    # When monad is not successfully method should return copy of monad

# Generated at 2022-06-12 05:26:30.408467
# Unit test for method filter of class Try
def test_Try_filter():
    test_data = [
        (1, 2), (3, 4), (5, 6)
    ]

    test_data.append((42, '42'))

    # Positive test for successful and unsuccessful filter
    for value, expected_value in test_data:
        result = Try.of(lambda: value).filter(lambda x: x == 42).get_or_else('')
        assert result == expected_value

    # Negative test for successful and unsuccessful filter
    for value, expected_value in test_data:
        result = Try.of(lambda: value).filter(lambda x: x > 42).get_or_else('')
        assert result != expected_value

    # Negative test for not successfully value

# Generated at 2022-06-12 05:26:36.422456
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda: 2**3)\
        .filter(lambda v: v >= 8)\
        .get_or_else(Error('NotOK'))
    assert result == 8

    result = Try.of(lambda: 2**3)\
        .filter(lambda v: v < 8)\
        .get_or_else(Error('OK'))
    assert result == Error('OK')


# Generated at 2022-06-12 05:26:41.210636
# Unit test for method filter of class Try
def test_Try_filter():
    # Test with True filterer
    assert Try.of(lambda: 2, ).filter(lambda x: x > 1) == Try(2, True)
    # Test with False filterer
    assert Try.of(lambda: 1, ).filter(lambda x: x > 1) == Try(1, False)

# Generated at 2022-06-12 05:26:44.483283
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x < 20) == Try(10, True)
    assert Try(10, True).filter(lambda x: x > 20) == Try(10, False)



# Generated at 2022-06-12 05:26:50.708779
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x % 2 == 0) == Try(5, False)
    assert Try(6, True).filter(lambda x: x % 2 == 0) == Try(6, True)
    assert Try(5, False).filter(lambda x: x % 2 == 0) == Try(5, False)
    assert Try(6, False).filter(lambda x: x % 2 == 0) == Try(6, False)


# Generated at 2022-06-12 05:26:54.419549
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x <= 0
    assert Try.of(lambda: 1).filter(filterer).is_success == True
    assert Try.of(lambda: -1).filter(filterer).is_success == False


# Generated at 2022-06-12 05:27:02.729247
# Unit test for method filter of class Try
def test_Try_filter():
    """
    def filter(self, filterer):

        Take filterer function, when monad is successfully call filterer with monad value.
        When filterer returns True method returns copy of monad, othercase
        not successfully Try with previous value.

        :params filterer: function to apply on monad value
        :type filterer: Function(A) -> Boolean
        :returns: Try with previous value
        :rtype: Try[A]
    """
    def filterer(x: int) -> bool:
        """
        Return True if x is even number, othercase return False.

        :params x: number to test
        :type x: int
        :returns: True if x is even number, othercase False
        :rtype: Boolean
        """
        return x % 2 == 0

    assert fil

# Generated at 2022-06-12 05:27:05.678333
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, ()).filter(lambda x: True) == Try(1, True)
    assert Try.of(lambda: 1, ()).filter(lambda x: False) == Try(1, False)

    def throw_exception():
        raise Exception('error')

    assert Try.of(throw_exception, ()).filter(lambda x: True) == Try(Exception('error'), False)
    assert Try.of(throw_exception, ()).filter(lambda x: False) == Try(Exception('error'), False)

# Generated at 2022-06-12 05:27:08.099632
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(-1, True).filter(lambda x: x > 0) == Try(-1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)

# Generated at 2022-06-12 05:27:18.794876
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> def even(value: int) -> bool:
    ...     return value % 2 == 0

    >>> assert Try(2, True).filter(even) == Try(2, True)
    >>> assert Try(2, True).filter(lambda _: True) == Try(2, True)
    >>> assert Try(2, True).filter(lambda _: False) == Try(2, False)
    >>> assert Try(2, False).filter(even) == Try(2, False)
    >>> assert Try(2, False).filter(lambda _: True) == Try(2, False)
    >>> assert Try(2, False).filter(lambda _: False) == Try(2, False)
    >>>
    """


# Generated at 2022-06-12 05:27:23.154786
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 3

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(3, True).filter(filterer) == Try(3, True)



# Generated at 2022-06-12 05:27:28.625557
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for filter method.
    """
    def safe_int(value: str) -> Try[int]:
        return Try.of(lambda: int(value))

    assert safe_int('1').bind(lambda v: safe_int('2').filter(lambda v2: v2 > v)) == Try(2, True)
    assert safe_int('1').bind(lambda v: safe_int('not_int_value').filter(lambda v2: v2 > v)) == Try(ValueError('invalid literal for int() with base 10: \'not_int_value\''), False)

# Generated at 2022-06-12 05:27:36.611030
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, None) == Try(1, True)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1, None).filter(lambda x: x != 1) == Try(1, False)
    assert Try.of(lambda: 1 / 0, None).filter(lambda x: x == 1) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0, None).filter(lambda x: x != 1) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-12 05:27:47.298109
# Unit test for method filter of class Try
def test_Try_filter():
    test_data = [1, 2, 3, 4, 5]
    expected_data = [2, 3, 4]

    # Just a function which returns True when value of element is even
    is_even = lambda x: x % 2 == 0

    try_collection = [Try(x, True) for x in test_data]
    try_filtered = list(map(lambda x: x.filter(is_even), try_collection))

    for t in try_filtered:
        assert t.is_success == True

    filtered_values = list(map(lambda x: x.get(), try_filtered))
    assert filtered_values == expected_data

    # with exception
    is_false = lambda x: False

    try_collection = [Try(x, True) for x in test_data]
    try_filtered = list

# Generated at 2022-06-12 05:27:52.236901
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)
    assert Try(10, True).filter(lambda x: x < 5) == Try(10, False)
    assert Try(10, False).filter(lambda x: x > 5) == Try(10, False)

# Generated at 2022-06-12 05:27:58.521208
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # Arrange
    filterer = lambda x: x < 0
    expected_value = -2
    expected_is_success = False
    try_monad = Try.of(lambda: 1 / 0).filter(filterer)

    # Act
    value = try_monad.value
    is_success = try_monad.is_success

    # Assert
    assert expected_value == value
    assert expected_is_success == is_success



# Generated at 2022-06-12 05:28:06.703705
# Unit test for method filter of class Try
def test_Try_filter():
    def is_positive(a):
        return a > 0

    should_be_positive = Try(1, True).filter(is_positive)
    should_be_negative = Try(1, False).filter(is_positive)
    should_be_not_positive = Try(-1, True).filter(is_positive)

    assert should_be_positive == Try(1, True)
    assert should_be_negative == Try(1, False)
    assert should_be_not_positive == Try(1, False)



# Generated at 2022-06-12 05:28:16.119315
# Unit test for method filter of class Try
def test_Try_filter():
    """
        Given:
            - is_adult: function that check is person adult
            - person: person object
        When:
            - call Try.of(is_adult, person) method
        Then:
            - return Try[person, True] when person is adult
            - return Try[person, False] when person is not adult
    """
    def is_adult(person):
        return person.age > 18

    class Person:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    person = Person('Alex', 20)
    actual = Try.of(is_adult, person).filter(lambda x: True)
    assert actual == Try(person, True)

    person = Person('Alex', 15)

# Generated at 2022-06-12 05:28:20.383982
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x == 2) == Try(2, True)
    assert Try(2, True).filter(lambda x: x == 3) == Try(2, False)
    assert Try(2, False).filter(lambda x: x == 2) == Try(2, False)
    assert Try(2, True).filter(lambda x: x == 3) == Try(3, False) # pragma: no cover

# Generated at 2022-06-12 05:28:29.682980
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Case with successfully monad
    """

    def filterer(value):
        return value == 3

    assert Try(3, True).filter(filterer) == Try(3, True)
    """
    Case with not successfully monad
    """
    assert Try(1, False).filter(filterer) == Try(1, False)
    """
    Case with successful monad and filterer returns False
    """
    assert Try(1, True).filter(filterer) == Try(1, False)



# Generated at 2022-06-12 05:28:34.537370
# Unit test for method filter of class Try
def test_Try_filter():
    from unittest import TestCase
    tc = TestCase()
    tc.assertEqual(Try(5, True).filter(lambda x: x > 5), Try(5, False))
    tc.assertEqual(Try(None, False).filter(lambda x: x > 5), Try(None, False))


# Generated at 2022-06-12 05:28:38.369357
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'hello',).filter(lambda str_: str_ == 'hello').is_success
    assert Try.of(lambda: 'hello',).filter(lambda str_: str_ == 'world').is_success is False

# Generated at 2022-06-12 05:28:43.241558
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '123').filter(lambda a: a > 100) == Try(123, True)
    assert Try.of(int, '123').filter(lambda a: a < 100) == Try(123, False)
    assert Try.of(int, 'ABC').filter(lambda a: a > 100) == Try('ABC', False)

# Generated at 2022-06-12 05:28:48.031779
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 2) == Try(1, False)
    assert Try.of(lambda x: x, 1).filter(lambda x: x < 2) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: x < 2).get() == 1
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 2).get_or_else(2) == 2

# Generated at 2022-06-12 05:28:53.382155
# Unit test for method filter of class Try
def test_Try_filter():
    ten = Try.of(lambda x: x, 10).filter(lambda x: x > 9)
    assert ten.value == 10
    assert ten.is_success
    zero = ten.filter(lambda x: x == 0)
    assert zero.value == 10
    assert not zero.is_success


# Generated at 2022-06-12 05:29:01.727097
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Filter function test.

    :returns: True when method work correctly, False otherwise
    :rtype: Boolean
    """
    # Call filter with lambda, that return True and next value
    def filterer() -> Callable:
        return lambda x: True

    # Call filter with lambda, that return True and next value
    def filterer2() -> Callable:
        return lambda x: False

    # Create successfully Try
    t = Try(1, True)

    # Call filter with lambda, that return True and next value
    t = t.filter(filterer())

    # Check is successfully
    if not t.is_success:
        return False

    # Check for correct value
    if t.get() != 1:
        return False

    # Create unsuccessfully Try
    t = Try(1, False)

    #

# Generated at 2022-06-12 05:29:10.669664
# Unit test for method filter of class Try
def test_Try_filter():
    one_div_by_zero_try = Try.of(lambda x: (1 / x), 0)
    one_div_by_something_try = Try.of(lambda x: (1 / x), 10)
    print(one_div_by_zero_try.filter(
        lambda x: isinstance(x, ZeroDivisionError)))
    print(one_div_by_zero_try.filter(
        lambda x: isinstance(x, ValueError)))
    print(one_div_by_something_try.filter(
        lambda x: isinstance(x, ZeroDivisionError)))
    print(one_div_by_something_try.filter(
        lambda x: isinstance(x, ValueError)))


# Generated at 2022-06-12 05:29:16.101101
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(3, True).filter(lambda x: x % 2 == 0) == Try(3, False)
    assert Try(2, False).filter(lambda x: x % 2 == 0) == Try(2, False)


test_Try_filter()



# Generated at 2022-06-12 05:29:22.508123
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        value = str(value)
        return 'error' not in value.lower()

    assert Try.of(lambda value: value, 3).filter(filterer) == Try(3, True)
    assert Try.of(lambda value: value, 'error').filter(filterer) == Try('error', False)


# Generated at 2022-06-12 05:29:34.714334
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-12 05:29:39.692196
# Unit test for method filter of class Try
def test_Try_filter():
    print('test_Try_filter()')
    print('test filter with successfully Try')
    assert Try.of(lambda: 5, None).filter(lambda x: x < 10) == Try(5, True)
    print('test filter with not successfully Try')
    assert Try.of(lambda: 5, None).filter(lambda x: x > 10) == Try(5, False)
    print('test_Try_filter() passed...')


# Generated at 2022-06-12 05:29:51.113491
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try('foo', True).filter(lambda v: len(v) <= 10) == Try('foo', True)
    assert Try('foo', True).filter(lambda v: len(v) >= 10) == Try('foo', False)
    assert Try('foo', True).filter(lambda v: len(v) <= 10).get() == 'foo'
    assert Try('foo', True).filter(lambda v: len(v) >= 10).get() == 'foo'
    assert Try('foo', False).filter(lambda v: len(v) <= 10) == Try('foo', False)
    assert Try('foo', True).filter(lambda v: len(v) >= 10).get() == 'foo'
    assert Try('foo', True).filter(lambda v: len(v) > 10).is_success == False

# Generated at 2022-06-12 05:29:56.552165
# Unit test for method filter of class Try
def test_Try_filter():
    from utilscon import compose

    value = Try(100, True)
    result = value.filter(lambda x: x % 2 == 0).get()
    assert result == 100

    value = Try(100, True)
    result = value.filter(lambda x: x > 100).get_or_else(None)
    assert result is None

    value = Try(100, True)
    result = value.filter(lambda x: x % 2 == 0)\
        .filter(lambda x: x > 100)\
        .get_or_else(None)
    assert result is None

    value = Try(100, True)
    result = value.filter(lambda x: x % 2 == 0)\
        .filter(lambda x: x < 100)\
        .get_or_else(None)
    assert result is None


# Generated at 2022-06-12 05:30:01.879350
# Unit test for method filter of class Try
def test_Try_filter(): # pragma: no cover
    assert Try(0, True).filter(lambda x: x > 0) == Try(0, False)
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)


# Generated at 2022-06-12 05:30:06.152299
# Unit test for method filter of class Try
def test_Try_filter():
    monad = Try(1, True)
    def filterer(value):
        return value > 0
    assert monad.filter(filterer) == Try(1, True)
    assert monad.filter(lambda value: value < 0) == Try(1, False)


# Generated at 2022-06-12 05:30:11.955671
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test on method filter of class Try
    """
    assert Try(1, True).filter(lambda x: x < 10) == Try(1, True)
    assert Try(1, False).filter(lambda x: x < 10) == Try(1, False)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(None, True).filter(lambda x: not x) == Try(None, False)



# Generated at 2022-06-12 05:30:18.531236
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """

    def _test(assert_method, message, left_value, right_value):
        """
        Private method for test Try::filter method with different
        values.

        :params assert_method: method for assert, should be assertEqual or assertNotEqual
        :type assert_method: Function
        :params message: message for assert method
        :type message: str
        :params left_value: left value for assert
        :type left_value: A
        :params right_value: right value for assert
        :type right_value: A
        """
        try_ = Try.of(lambda: 1)
        try_2 = Try.of(lambda: Exception)


# Generated at 2022-06-12 05:30:27.057590
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_func(val):
        return val < 10

    # when filter_func return True
    assert Try(7, True).filter(filter_func) == Try(7, True)
    # when filter_func return False
    assert Try(7, True).filter(lambda val: val > 10) == Try(7, False)
    # when monad is not successful
    try_monad = Try(7, False)
    assert try_monad.filter(lambda val: val < 10) == try_monad
    assert try_monad.filter(lambda val: val > 10) == try_monad


# Generated at 2022-06-12 05:30:30.753583
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try(42, True).filter(lambda x: 0 < x) == Try(42, True)
    assert Try(42, True).filter(lambda x: x < 0) == Try(42, False)

# Generated at 2022-06-12 05:30:45.353512
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-12 05:30:55.526923
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Generate two description for testing method filter.
    """
    name = 'Try.filter'

# Generated at 2022-06-12 05:31:00.538721
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    successful = Try(1, True).filter(lambda x: x == 1)
    not_successful = Try(1, True).filter(lambda x: x == 2)
    assert successful == Try(1, True)
    assert not_successful == Try(1, False)


# Generated at 2022-06-12 05:31:05.290129
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(val):
        return val >= 5

    try_data = Try(10, True)
    try_filtered = try_data.filter(filterer)
    try_not_filtered = Try(3, True).filter(filterer)

    assert try_filtered == Try(10, True)
    assert try_not_filtered == Try(3, False)


# Generated at 2022-06-12 05:31:09.267288
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method map of class Try
    """
    result = Try.of(lambda x: Try.of(lambda y: y, x), 'value').filter(lambda x: False)
    assert result.is_success is False

    result = Try.of(lambda x: Try.of(lambda y: y, x), 'value').filter(lambda x: True)
    assert result.is_success is True

# Generated at 2022-06-12 05:31:13.517801
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value > 1

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, True)

# Generated at 2022-06-12 05:31:18.937492
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    t = Try.of(lambda: None)

    # WHEN
    actual = t.filter(lambda _: True)

    # THEN
    assert actual == Try(None, True)

    # WHEN
    actual = t.filter(lambda _: False)

    # THEN
    assert actual == Try(None, False)



# Generated at 2022-06-12 05:31:30.309527
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 2) == Try(1, False)

    assert Try.of(lambda x: x, 1).filter(lambda x: x == 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 2).filter(lambda x: x == 1) == Try(1, False)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 1).filter(lambda x: x == 2) == Try(1, False)

# Generated at 2022-06-12 05:31:35.786489
# Unit test for method filter of class Try
def test_Try_filter():
    a = Try.of(lambda: 5)
    b = Try(10, False)
    assert a.filter(lambda x: x < 10) == Try(5, True)
    assert b.filter(lambda x: x < 10) == Try(10, False)
    assert b.filter(lambda x: x < 10) != Try(5, True)


# Generated at 2022-06-12 05:31:42.714727
# Unit test for method filter of class Try
def test_Try_filter():
    """
    When we have successful Try, not successfully when filterer returns False.
    When we have not successful Try, not successfully.

    :rtype: None
    """
    assert Try('Hello', True).filter(lambda i: i == 'Hello') == Try('Hello', True)
    assert Try('Hello', True).filter(lambda i: i != 'Hello') == Try('Hello', False)
    assert Try('Hello', False).filter(lambda i: i == 'Hello') == Try('Hello', False)


# Generated at 2022-06-12 05:32:12.135841
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x != 1) == Try(1, False)
    assert Try.of(lambda: 2).filter(lambda x: x == 1) == Try(2, False)
    assert Try.of(lambda: 0).filter(lambda x: x == 1) == Try(0, False)
    assert Try.of(lambda: None).filter(lambda x: x == 1) == Try(None, False)
    assert Try.of(lambda: 1/0).filter(lambda x: x == 1) == Try('division by zero', False)
    assert Try.of(lambda: 1).filter(lambda x: 1/0) == Try('division by zero', False)


# Unit test

# Generated at 2022-06-12 05:32:22.944853
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    result = Try.of(lambda: 5).filter(lambda x: x > 4)
    assert result.is_success

    result = Try.of(lambda: 5).filter(lambda x: x > 6)
    assert not result.is_success

    result = Try.of(lambda: 5).filter(lambda x: x > 4)\
        .bind(lambda x: Try.of(lambda: x * x))\
        .filter(lambda x: x == 25)\
        .map(lambda x: 'success')
    assert result.is_success
    assert result.value == 'success'


# Generated at 2022-06-12 05:32:27.641550
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1').filter(lambda c: c > 0) == Try(1, True)
    assert Try.of(int, '1').filter(lambda c: c < 0) == Try(1, False)


# Generated at 2022-06-12 05:32:37.835383
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for Try filter method.

    :returns: Nothing
    """
    t1 = Try.of(lambda: 1/0)
    t2 = Try.of(lambda: 1)
    t3 = Try.of(lambda: 'str')

    assert t1 == Try(ZeroDivisionError('division by zero'), False)
    assert t3 == Try('str', True)

    assert t2.filter(lambda x: x == 1) == t2
    assert t2.filter(lambda x: x == 2) == Try(1, False)

    assert t1.filter(lambda x: x == 1) == t1
    assert t1.filter(lambda x: x == 2) == t1

# Generated at 2022-06-12 05:32:41.496012
# Unit test for method filter of class Try
def test_Try_filter():
    value = 2
    try_obj = Try(value, True)
    assert try_obj.filter(lambda x: x == value) == Try(value, True)

    value = 2
    try_obj = Try(value, True)
    assert try_obj.filter(lambda x: x == value + 1) == Try(value, False)

# Generated at 2022-06-12 05:32:46.569696
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for Try class.
    """
    def test_empty():
        def t_filter1_result(empty):
            assert empty.filter(lambda _: True).get_or_else(None) == 1
            assert empty.filter(lambda _: False).get_or_else(None) == 1

        def t_filter2_result(empty):
            assert empty.filter(lambda _: True).get_or_else(None) == 1
            assert empty.filter(lambda _: False).get_or_else(None) == 1

        empty = Try.of(lambda _: 1)
        t_filter1_result(empty)
        t_filter2_result(Try(empty.get(), True))


# Generated at 2022-06-12 05:32:52.034934
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x == 10) == Try(10, True)
    assert Try(10, True).filter(lambda x: x != 10) == Try(10, False)
    assert Try(20, False).filter(lambda x: x == 10) == Try(20, False)



# Generated at 2022-06-12 05:32:56.051005
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda a: a, 1).filter(lambda a: a == 1) == Try.of(lambda a: a, 1)
    assert Try.of(lambda a: a, 1).filter(lambda a: a == 2) != Try.of(lambda a: a, 1)

# Generated at 2022-06-12 05:33:05.774807
# Unit test for method filter of class Try
def test_Try_filter():
    def my_filterer(value):
        """
        Return True when value is int and value is greater then 10
        """
        if not isinstance(value, int):
            return False
        return value > 10

    def my_filterer_exception_raising(value):
        """
        Raises exception when value is int and value is greater then 10
        """
        if isinstance(value, int) and value > 10:
            raise Exception()

    assert Try(10, True).filter(my_filterer) == Try(10, False)
    assert Try(11, True).filter(my_filterer) == Try(11, True)
    assert Try('10', True).filter(my_filterer) == Try('10', False)

# Generated at 2022-06-12 05:33:10.329866
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v > 0) == Try(1, True)
    assert Try(1, True).filter(lambda v: v > 1) == Try(1, False)
    assert Try(1, False).filter(lambda v: v > 0) == Try(1, False)
