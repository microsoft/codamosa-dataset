

# Generated at 2022-06-12 05:23:55.366275
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v > 0) == Try(1, True)
    assert Try(1, False).filter(lambda v: v > 0) == Try(1, False)
    assert Try(1, True).filter(lambda v: v > 10) == Try(1, False)
    assert Try('Exception', False).filter(lambda v: v > 0) == Try('Exception', False)



# Generated at 2022-06-12 05:24:02.073452
# Unit test for method filter of class Try
def test_Try_filter():
    some_value = 'some value'
    assert Try(some_value, False) == Try(some_value, False).filter(lambda val: True)
    assert Try(some_value, False) == Try(some_value, False).filter(lambda val: False)
    assert Try(some_value, True) == Try(some_value, True).filter(lambda val: True)
    assert Try(some_value, False) == Try(some_value, True).filter(lambda val: False)



# Generated at 2022-06-12 05:24:12.241053
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_ok_even(x):
        return x % 2 == 0

    def filter_fail_even(x):
        return x % 2 == 1

    def filter_fail_3_string(x):
        return x == '3'

    assert Try(2, True).filter(filter_ok_even) == Try(2, True)
    assert Try(2, True).filter(filter_fail_even) == Try(2, False)
    assert Try(2, True).filter(filter_fail_3_string) == Try(2, False)
    assert Try(2, False).filter(filter_ok_even) == Try(2, False)


# Generated at 2022-06-12 05:24:16.900559
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(100, True).filter(lambda x: x < 200) == Try(100, True)
    assert Try(100, True).filter(lambda x: x > 200) == Try(100, False)
    assert Try(100, False).filter(lambda x: x < 200) == Try(100, False)


# Generated at 2022-06-12 05:24:20.049358
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(20, True).filter(lambda x: x > 10) == Try(20, True)
    assert Try(20, True).filter(lambda x: x > 20) == Try(20, False)

# Generated at 2022-06-12 05:24:26.451342
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    is_positive = lambda x: x > 0
    is_zero = lambda x: x == 0

    # When
    # Successfully Try with value 1
    m1 = Try(1, True)

    m2 = m1.filter(is_positive)
    m3 = m1.filter(is_zero)

    # Successfully Try with value 0
    m4 = Try(0, True)

    m5 = m4.filter(is_positive)
    m6 = m4.filter(is_zero)

    # Not successfully Try with value 1
    m7 = Try(1, False)

    m8 = m7.filter(is_positive)
    m9 = m7.filter(is_zero)

    # Not successfully Try with value 0
    m10 = Try(0, False)

    m11

# Generated at 2022-06-12 05:24:31.517846
# Unit test for method filter of class Try
def test_Try_filter():
    import random

    min_value = 1
    max_value = 10

    def checker(x: int):
        return x == 5

    random_value = random.randint(min_value, max_value)
    is_equal = random_value == 5
    assert Try(random_value, is_equal).filter(checker) == Try(random_value, is_equal)

# Generated at 2022-06-12 05:24:36.373854
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True).filter(lambda value: value % 2 == 0) == Try(3, False)
    assert Try(4, True).filter(lambda value: value % 2 == 0) == Try(4, True)
    assert Try(4, False).filter(lambda value: value % 2 == 0) == Try(4, False)



# Generated at 2022-06-12 05:24:44.711583
# Unit test for method filter of class Try
def test_Try_filter():
    try_with_str = Try('21', True)
    true_result = try_with_str.filter(lambda x: x.isdigit())
    assert True == true_result.is_success
    assert '21' == true_result.get()

    false_result = try_with_str.filter(lambda x: x.isalpha())
    assert False == false_result.is_success
    assert '21' == false_result.get()


# Generated at 2022-06-12 05:24:51.125916
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(value):
        return value % 2 == 0

    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(2, True).filter(is_even).is_success == True
    assert Try(1, True).filter(is_even).is_success == False
    assert Try(1, True).filter(is_even) == Try(1, False)
    assert Try(Try(1, True), True).filter(is_even) == Try(Try(1, True), False)

# Generated at 2022-06-12 05:25:01.621694
# Unit test for method filter of class Try
def test_Try_filter():
    # Arrange
    def filterer(x):
        return x == 2

    success = Try(2, True)
    fail = Try(3, False)
    value = 2
    # Act
    result1 = success.filter(filterer)
    result2 = fail.filter(filterer)
    # Assert
    assert result1 == Try(value, True)
    assert result2 == Try(value, False)



# Generated at 2022-06-12 05:25:05.728912
# Unit test for method filter of class Try
def test_Try_filter():
    _try = Try(2, True).filter(lambda num: num > 1)
    assert _try == Try(2, True)
    _try = Try(1, True).filter(lambda num: num > 1)
    assert _try == Try(1, False)


# Generated at 2022-06-12 05:25:08.943671
# Unit test for method filter of class Try
def test_Try_filter():
    """Unit test for method filter of class Try"""
    m = Try.of(lambda a: a, 2)
    assert m.filter(lambda a: a < 4) == Try(2, True)
    assert m.filter(lambda a: a > 4) == Try(2, False)

# Generated at 2022-06-12 05:25:15.347168
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert(Try(10, True).filter(lambda x: x % 2 == 0) == Try(10, True))
    assert(Try(10, True).filter(lambda x: x % 2 != 0) == Try(10, False))
    assert(Try(10, False).filter(lambda x: x % 2 != 0) == Try(10, False))


# Generated at 2022-06-12 05:25:21.932162
# Unit test for method filter of class Try
def test_Try_filter():
    def func(a):
        if not a:
            raise Exception('a is zero!')
        if a == 1:
            raise Exception('a is one!')
        return a**2

    assert Try.of(func, 0).filter(lambda a: a ** 2 > 1).get_or_else(0) == 0
    assert Try.of(func, 1).filter(lambda a: a ** 2 > 1).get_or_else(0) == 0
    assert Try.of(func, 2).filter(lambda a: a ** 2 > 1).get() == 4


# Generated at 2022-06-12 05:25:28.652207
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x != 1) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: ZeroDivisionError("error")).filter(lambda x: x == 1) == Try(ZeroDivisionError("error"), False)
    assert Try.of(lambda: ZeroDivisionError("error")).filter(lambda x: x == 2) == Try(ZeroDivisionError("error"), False)


# Generated at 2022-06-12 05:25:37.572729
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for Try.filter method.

    :returns: True when test is passed, othercase raise Exception
    :rtype: Boolean
    """
    try_value = Try.of(lambda: 5/2).filter(lambda x: x >= 2)
    assert try_value == Try(2.5, True)

    try_value = Try.of(lambda: 5/0).filter(lambda x: x >= 2)
    assert try_value == Try(Exception('division by zero'), False)

    try_value = Try.of(lambda: 5/2).filter(lambda x: x == 2)
    assert try_value == Try(2.5, False)

    return True


# Generated at 2022-06-12 05:25:49.109495
# Unit test for method filter of class Try
def test_Try_filter():
    def test_success_filter(expected, to_test):
        assert expected == to_test
    def test_fail_filter(expected, to_test):
        assert not expected == to_test

    def filterer(x):
        return x % 2 == 0

    success_monad = Try(24, True)
    fail_monad = Try(12, False)

    # Successfully case:
    expected = Try(24, True)
    to_test = success_monad.filter(filterer)
    test_success_filter(expected, to_test)

    # Not successfully case:
    expected = Try(24, False)
    to_test = success_monad.filter(filterer)
    test_fail_filter(expected, to_test)

    # Successfully case:

# Generated at 2022-06-12 05:25:54.963307
# Unit test for method filter of class Try
def test_Try_filter():
    """
    test_Try_filter, try to filter string greater than 4
    """
    assert Try.of(lambda x: x, 10).filter(lambda x: x > 4) == Try(10, True)
    assert Try.of(lambda x: x, 3).filter(lambda x: x > 4) == Try(3, False)
    assert Try.of(lambda x: 1/0, 10).filter(lambda x: x > 4) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-12 05:25:57.576668
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(3, True).filter(lambda x: x % 2 == 0) == Try(3, False)
    assert Try(4, False).filter(lambda x: x % 2 == 0) == Try(4, False)


# Generated at 2022-06-12 05:26:08.768292
# Unit test for method filter of class Try
def test_Try_filter():
    list_of_integers = [1, 2, 3, 4, 5, 6]
    def filterer(x):
        return x % 2 == 0
    def filterer_wrong(x):
        return x % 3 == 0
    def mapper(x):
        return x * 2
    emitter = emitter_from_list(list_of_integers)
    result = emitter.map(lambda x: Try(x, True)) \
        .filter(filterer) \
        .map(mapper) \
        .filter(filterer) \
        .filter(filterer_wrong) \
        .map(mapper) \
        .filter(filterer) \
        .collect()
    expected = [4, 8, 16]
    assert result == expected



# Generated at 2022-06-12 05:26:13.963620
# Unit test for method filter of class Try
def test_Try_filter():
    data = Try(2, True)

    assert data.filter(lambda x: x > 0) == Try(2, True)

    assert data.filter(lambda x: x < 0) == Try(2, False)  # filter returns not successful Try with value = 2



# Generated at 2022-06-12 05:26:23.983732
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(20, True).filter(filterer) == Try(20, True)
    assert Try(10, True).filter(filterer) == Try(20, True)
    assert Try(10, False).filter(filterer) == Try(10, False)
    assert Try(20, False).filter(filterer) == Try(20, False)
    assert Try(5, False).filter(filterer) == Try(5, False)
    assert Try(10, True).filter(filterer).value == 10
    assert Try(20, True).filter(filterer).value == 20

# Generated at 2022-06-12 05:26:29.477707
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 7).map(lambda x: x * 2).filter(lambda x: x > 10) == Try(7 * 2, True)
    assert Try.of(lambda: 7).map(lambda x: x * 2).filter(lambda x: x < 10) == Try(7 * 2, False)

# Generated at 2022-06-12 05:26:34.998944
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value < 0

    assert Try(2, True).filter(filterer) == Try(2, False), 'Error: Try.filter method'
    assert Try(-5, True).filter(filterer) == Try(-5, True), 'Error: Try.filter method'


# Generated at 2022-06-12 05:26:41.357393
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    class Invoker:
        def invoke(self, val) -> bool:
            return val == 'a'
    invoker = Invoker()

    def _return_a(val) -> Try:
        return Try('a', True)

    def _return_b(val) -> Try:
        return Try('b', True)

    def _return_c(val) -> Try:
        return Try('c', True)

    # WHEN
    filtered_a = Try.of(_return_a).filter(invoker.invoke)
    filtered_b = Try.of(_return_b).filter(invoker.invoke)
    filtered_c = Try.of(_return_c).filter(invoker.invoke)

    # THEN
    assert filtered_a.value == 'a'

# Generated at 2022-06-12 05:26:44.654495
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x < 10).get() == 5
    assert Try(5, True).filter(lambda x: x > 10).is_success == False



# Generated at 2022-06-12 05:26:49.932479
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from hamcrest import assert_that, equal_to
    from common.test_utils import get_String_stub

    try_ = get_String_stub(Try.of, 'Hello')\
            .filter(lambda string: len(string) == 5)

    assert_that(try_, equal_to(Try(get_String_stub('Hello'), True)))

# Generated at 2022-06-12 05:26:55.611574
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test Try.filter method.
    """
    def is_positive(value):
        return value > 0

    assert Try.of(lambda x: x, 1).filter(is_positive) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: False) == Try(1, False)

if __name__ == '__main__':
    test_Try_filter()  # pragma: no cover

# Generated at 2022-06-12 05:27:03.114640
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully Try with number: True
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    # Not successfully Try with number: True
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    # Successfully Try with number: False
    assert Try(1, True).filter(lambda x: x <= 0) == Try(1, False)

    # Successfully Try with None: True
    assert Try(None, True).filter(lambda x: x is None) == Try(None, True)
    # Not successfully Try with None: True
    assert Try(None, False).filter(lambda x: x is None) == Try(None, False)
    # Successfully Try with None: False

# Generated at 2022-06-12 05:27:14.730396
# Unit test for method filter of class Try
def test_Try_filter():
    add_two = lambda val: val + 2
    is_even = lambda val: val % 2 == 0

    assert Try(4, True).filter(is_even) == Try(4, True)
    assert Try(4, True).map(add_two).filter(is_even) == Try(6, True)
    assert Try(3, True).filter(is_even) == Try(3, False)
    assert Try(3, True).map(add_two).filter(is_even) == Try(5, False)


# Generated at 2022-06-12 05:27:26.191322
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for filter method.
    """
    # Define filterer
    def filterer(value):
        return value > 5

    # Call Try.of with arguments, when first argument raising ValueError,
    # that means Try.of return not successfully Try.
    try_to_test = Try.of(int, 'hello')

    # Apply filter function to try_to_test
    try_filtered = try_to_test.filter(filterer)

    # When try_to_test not successfully, try_filtered must be not successfully too.
    assert try_filtered == Try(value=ValueError('invalid literal for int() with base 10: \'hello\''),
                               is_success=False)

    # When try_to_test is successfully, try_filtered must be not successfully when filterer return

# Generated at 2022-06-12 05:27:31.889998
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.
    """
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 0) == Try(1, False)
    assert Try(Exception, False).filter(lambda x: False) == Try(Exception, False)



# Generated at 2022-06-12 05:27:35.121365
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda i: i == 1) == Try(1, True)
    assert Try(1, True).filter(lambda i: i == 2) == Try(1, False)

# Generated at 2022-06-12 05:27:40.011131
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, True).filter(lambda _: True) == Try(None, True)
    assert Try(None, True).filter(lambda _: False) == Try(None, False)
    assert Try(None, False).filter(lambda _: True) == Try(None, False)


# Generated at 2022-06-12 05:27:46.898755
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Create successfully monad Try with integer value 1 and not successfully
    with exception and call filter method, when successfully returns Try with value and when not successfully returns Try with exception.
    """
    def filterer(value):
        return True
    successfully = Try(1, True)
    not_successfully = Try(ValueError(), False)
    assert successfully.filter(filterer) == Try(1, True)
    assert not_successfully.filter(filterer) == Try(ValueError(), False)



# Generated at 2022-06-12 05:27:51.591812
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '6').filter(lambda x: x > 5) == Try.of(int, '6')
    assert Try.of(int, '6').filter(lambda x: x < 5) == Try(Exception(), False)


# Generated at 2022-06-12 05:27:57.625939
# Unit test for method filter of class Try
def test_Try_filter():
    """
    test_Try_filter method try to execute those cases:
            + =============Try[value=12, is_success=True]=============
            + =============Try[value=12, is_success=False]=============
    :returns: None
    :rtype: None
    """
    assert Try.of(lambda: 12).filter(lambda v: True) == Try(12, True)
    assert Try.of(lambda: 12).filter(lambda v: False) == Try(12, False)



# Generated at 2022-06-12 05:28:03.932477
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    value = 'a'
    t = Try(value, True)

    def filterer(v):
        return v == value

    new_t = t.filter(filterer)
    assert t == new_t
    assert new_t.value == value
    assert new_t.is_success
    assert t.value == value
    assert t.is_success

    def filterer_fail(v):
        return v != value

    new_t = t.filter(filterer_fail)
    assert new_t.value == t.value
    assert new_t.is_success == False
    assert t.value == value
    assert t.is_success

    value = 'b'
    t = Try(value, False)


# Generated at 2022-06-12 05:28:10.363257
# Unit test for method filter of class Try
def test_Try_filter():
    def divide(a, b):
        return a/b

    assert Try.of(divide, 5, 1).filter(lambda x: x == 5) == Try(5, True)
    assert Try.of(divide, 5, 1).filter(lambda x: x < 5) == Try(5, False)
    assert Try.of(divide, 5, 0).filter(lambda x: x == 5) == Try(ZeroDivisionError, False)

# Generated at 2022-06-12 05:28:38.640075
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Create monad and call filter function.
    Check if monad value is not change.
    """
    assert Try.of(lambda x: x, 100).filter(lambda x: x > 1) == Try(100, True)
    assert Try.of(lambda x: x, 100).filter(lambda x: x > 1000) == Try(100, False)
    assert Try.of(lambda x: x, 100).filter(lambda x: None).filter(
        lambda x: x + 1) == Try(100, False)
    assert Try.of(lambda x: 1 / 0, 100).filter(lambda x: x > 1) == Try(100, False)



# Generated at 2022-06-12 05:28:43.517268
# Unit test for method filter of class Try
def test_Try_filter():
    fn = lambda a: a + 10
    success = Try.of(fn, 100)
    fail = Try.of(fn, 0)
    filterer = lambda a: a >= 110
    assert success.filter(filterer) == Try(fn(100), True)
    assert fail.filter(filterer) == Try(fn(0), False)

# Generated at 2022-06-12 05:28:47.551194
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '4')\
        .filter(lambda x: x > 0) == Try(4, True)

    assert Try.of(int, '-4')\
        .filter(lambda x: x > 0) == Try(-4, False)

    assert Try.of(int, 'a')\
        .filter(lambda x: x > 0) == Try('a', False)



# Generated at 2022-06-12 05:28:53.661117
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 1) == Try(10, True)
    assert Try(10, True).filter(lambda x: x > 10) == Try(10, False)
    assert Try(10, False).filter(lambda x: x > 10) == Try(10, False)



# Generated at 2022-06-12 05:28:57.781183
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(1, False).filter(lambda x: False) == Try(1, False)



# Generated at 2022-06-12 05:29:01.400349
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(1, True).filter(lambda v: v % 2 == 0) == Try(1, False)
    assert Try(2, True).filter(lambda v: v % 2 == 0) == Try(2, True)
    assert Try(1, False).filter(lambda v: v % 2 == 0) == Try(1, False)


# Generated at 2022-06-12 05:29:10.535598
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value): return value > 10

    @Try.of
    def div(a, b):
        return a / b

    assert div(1, 0).filter(filterer) == Try(ZeroDivisionError(), False)
    assert div(12, 6).filter(filterer) == Try(2, True)
    assert div(12, 6).filter(filterer).get() == 2
    assert div(12, 6).filter(filterer).get_or_else(11) == 2
    assert div(12, 0).filter(filterer) == Try(ZeroDivisionError(), False)
    assert div(12, 0).filter(filterer).get_or_else(11) == 11

# Generated at 2022-06-12 05:29:13.025419
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> test_Try_filter()
    True
    """
    return Try(True, True).filter(lambda x: x).is_success

# Generated at 2022-06-12 05:29:17.488536
# Unit test for method filter of class Try
def test_Try_filter():
    # Arrange
    m_try = Try.of(lambda x: x * 2, 4)
    m_function = lambda x: True if x < 10 else False
    m_result = Try(8, True)

    # Act
    result = m_try.filter(m_function)

    # Assert
    assert result == m_result


# Generated at 2022-06-12 05:29:24.905300
# Unit test for method filter of class Try
def test_Try_filter():
    # Setup
    lst = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    actual = list(map(
        lambda val: Try(val, True).filter(lambda v: v % 2 == 0).get(),
        lst
    ))
    expected = [2, 4, 6, 8, 10, None, None, None, None, None]

    # Exercise
    assert actual == expected, "expected {} but got {}".format(expected, actual)


# Generated at 2022-06-12 05:30:05.056067
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Testing Try method filter
    """
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(-1, True).filter(lambda x: x > 0) == Try(-1, False)
    assert Try(-1, True).filter(lambda x: x < 0) == Try(-1, True)
    assert Try(-1, False).filter(lambda x: x < 0) == Try(-1, False)

# Generated at 2022-06-12 05:30:09.835568
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x == 4

    assert Try(5, True).filter(filterer) == Try(5, False)
    assert Try(4, True).filter(filterer) == Try(4, True)
    assert Try(4, False).filter(filterer) == Try(4, False)

    # Unit test for method bind of class Try

# Generated at 2022-06-12 05:30:15.305412
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    print('test_Try_filter')
    x = Try(5, True)
    y = Try(5, False)
    assert x.filter(lambda x: x == 5) == Try(5, True)
    assert x.filter(lambda x: x != 5) == Try(5, False)
    assert y.filter(lambda x: x == 5) == Try(5, False)


# Generated at 2022-06-12 05:30:19.345397
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def f(value):
        return value >= 5

    assert Try(3, True).filter(f) == Try(3, False)
    assert Try(7, True).filter(f) == Try(7, True)

# Generated at 2022-06-12 05:30:26.300785
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 'You are handsome',) \
        .filter(lambda x: len(x) > 6) \
        .get() == 'You are handsome'

    assert not Try.of(lambda: 'You are handsome',) \
        .filter(lambda x: len(x) < 6).is_success

    assert Try.of(lambda: 'You are handsome',) \
        .filter(lambda x: len(x) < 6).get() == 'You are handsome'



# Generated at 2022-06-12 05:30:34.054215
# Unit test for method filter of class Try
def test_Try_filter():
    """
    :returns: None
    """
    # Successfully Try
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, True).filter(lambda x: x != 2) == Try(1, True)

    # Successfully Try
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)

# Generated at 2022-06-12 05:30:37.618746
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filterer(value):
        return False

    expected_result = Try(None, False)
    try_ = Try(None, True)

    assert expected_result == try_filter(try_, test_filterer)


# Generated at 2022-06-12 05:30:41.952878
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    value = Try.of(lambda x, y: x + y, 5, 10)
    assert value.filter(lambda x: x > 10).get() == 15
    assert value.filter(lambda x: x > 20) == Try(15, False)

# Generated at 2022-06-12 05:30:48.405591
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 42, None) \
        .filter(lambda x: x % 2 == 0) \
        == Try(42, True)
    assert Try.of(lambda: 42, None) \
        .filter(lambda x: x % 2 == 1) \
        == Try(42, False)
    assert Try.of(lambda: 42, None) \
        .filter(lambda x: x % 2 == 1) \
        .filter(lambda x: x % 2 == 0) \
        == Try(42, False)


# Generated at 2022-06-12 05:30:57.625312
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(None, True).filter(lambda x: True) == Try(None, True)
    assert Try(None, True).filter(lambda x: False) == Try(None, False)
    assert Try(True, True).filter(lambda x: True) == Try(True, True)
    assert Try(5, True).filter(lambda x: True) == Try(5, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(None, False).filter(lambda x: True) == Try(None, False)



# Generated at 2022-06-12 05:32:22.970429
# Unit test for method filter of class Try
def test_Try_filter():
    d = Try.of(lambda: 1 / 1)
    d_fail = Try.of(lambda: 1 / 0)  # division by zero

    def is_int(value):
        return type(value) == int
    assert d.filter(is_int).get() == 1
    assert d_fail.filter(is_int).is_success is False
    assert d_fail.filter(is_int).get() == ZeroDivisionError

    def is_float(value):
        return type(value) == float
    assert d.filter(is_float).is_success is False
    assert d.filter(is_float).get() == 1
    assert d_fail.filter(is_float).is_success is False
    assert d_fail.filter(is_float).get() == ZeroDivisionError


# Generated at 2022-06-12 05:32:29.613548
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)

# Generated at 2022-06-12 05:32:38.345958
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_true(value):
        return True
    def filter_false(value):
        return False

    assert Try("some_value", True).filter(filter_true) == Try("some_value", True)
    assert Try("some_value", True).filter(filter_false) == Try("some_value", False)
    assert Try("some_value", False).filter(filter_false) == Try("some_value", False)
    assert Try("some_value", False).filter(filter_true) == Try("some_value", False)



# Generated at 2022-06-12 05:32:43.946698
# Unit test for method filter of class Try
def test_Try_filter():
    # Arrange
    success_value = 10
    not_success_value = 10
    success_try = Try(success_value, True)
    not_success_try = Try(not_success_value, False)

    def filterer(val):
        return val % 2 == 0

    # Act
    success_filtered = success_try.filter(filterer)
    not_success_filtered = not_success_try.filter(filterer)

    # Assert
    assert success_filtered.get() == success_value
    assert not_success_filtered.get() == not_success_value


# Generated at 2022-06-12 05:32:48.436637
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    assert Try(4, True).filter(filterer) == Try(4, False)
    assert Try(6, True).filter(filterer) == Try(6, True)

# Generated at 2022-06-12 05:32:51.974261
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, True).filter(lambda x: x is not None) == Try(None, False)
    assert Try(None, True).filter(lambda x: x is None) == Try(None, True)


# Generated at 2022-06-12 05:33:03.214042
# Unit test for method filter of class Try
def test_Try_filter():
    positive = Try(17, True)
    negative = Try(17, False)
    assert (positive.filter(lambda t: t > 0) == positive, 'Try[17, True].filter(t > 0) == Try[17, True]')
    assert (positive.filter(lambda t: t < 0) == Try(17, False), 'Try[17, True].filter(t < 0) == Try[17, False]')
    assert (negative.filter(lambda t: t > 0) == negative, 'Try[17, False].filter(t > 0) == Try[17, False]')
    assert (negative.filter(lambda t: t < 0) == negative, 'Try[17, False].filter(t < 0) == Try[17, False]')


# Generated at 2022-06-12 05:33:09.915814
# Unit test for method filter of class Try
def test_Try_filter():
    _ = Try.of(lambda x: x + 1, 1)
    _.filter(lambda x: x == 2).on_success(print)
    _.filter(lambda x: x == 1).on_fail(print)
    assert _.filter(lambda x: x == 2) == Try(1, True)
    assert _.filter(lambda x: x == 1) == Try(1, False)

# Generated at 2022-06-12 05:33:15.564852
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(42, True).filter(lambda x: x == 42) == Try(42, True)
    assert Try(42, True).filter(lambda x: x == 24) == Try(42, False)
    assert Try(42, False).filter(lambda x: x == 24) == Try(42, False)



# Generated at 2022-06-12 05:33:18.453184
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x % 2 == 0

    assert Try.of(lambda: 10).filter(filterer) == Try(10, True)
    assert Try.of(lambda: 11).filter(filterer) == Try(11, False)
    assert Try.of(lambda: 10 / 0).filter(filterer) == Try(ZeroDivisionError(), False)

