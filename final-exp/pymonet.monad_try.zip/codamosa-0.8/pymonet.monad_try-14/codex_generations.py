

# Generated at 2022-06-12 05:24:00.705984
# Unit test for method filter of class Try
def test_Try_filter():
    print('Test for method filter of class Try')
    assert (Try.of(lambda : 5, None).filter(lambda x: x > 0) == Try(5, True))
    assert (Try.of(lambda : 5, None).filter(lambda x: x > 3) == Try(5, True))
    assert (Try.of(lambda : 5, None).filter(lambda x: x > 6) == Try(5, False))
    assert (Try.of(lambda : '', None).filter(lambda x: len(x) > 0) == Try('', False))
    assert (Try.of(lambda : '', None).filter(lambda x: len(x) < 1) == Try('', False))
    assert (Try.of(lambda : '', None).filter(lambda x: len(x) > 1) == Try('', False))
   

# Generated at 2022-06-12 05:24:12.651530
# Unit test for method filter of class Try
def test_Try_filter():
    actual_result: Try[int] = Try.of(int, '1').filter(lambda x: x == 1)
    expected_result: Try[int] = Try(1, True)
    assert actual_result == expected_result, 'When Try is successfully and filterer returns True, filter returns copy of monad'

    actual_result: Try[int] = Try.of(int, '1').filter(lambda x: x == 2)
    expected_result: Try[int] = Try(1, False)
    assert actual_result == expected_result, 'When Try is successfully and filterer returns False, filter returns not successfully Try with previous value'

    actual_result: Try[int] = Try.of(int, 'a').filter(lambda x: x == 1)

# Generated at 2022-06-12 05:24:19.855512
# Unit test for method filter of class Try
def test_Try_filter():
    from operators_monads.monads.maybe import Maybe

    a = Try(2, True)
    b = Try(1, True)
    c = Try(3, True)

    def filterer(value):
        return value % 2 == 0

    a_filterer = a.filter(filterer)
    assert isinstance(a_filterer, Try)
    assert a_filterer == Try(2, True)

    b_filterer = b.filter(filterer)
    assert isinstance(b_filterer, Try)
    assert b_filterer == Try(1, False)

    c_filterer = c.filter(filterer)
    assert isinstance(c_filterer, Try)
    assert c_filterer == Try(3, False)


# Unit

# Generated at 2022-06-12 05:24:25.152661
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda _: True) == Try(1, True)
    assert Try(1, True).filter(lambda _: False) == Try(1, False)
    assert Try(1, False).filter(lambda _: True) == Try(1, False)


# Generated at 2022-06-12 05:24:34.301422
# Unit test for method filter of class Try
def test_Try_filter():
    class CustomException(Exception):
        pass

    def greater_zero(x):
        return x > 0

    def not_raise(x):
        return x

    def raise_exception(x):
        raise CustomException()

    assert(Try.of(not_raise, 1).filter(greater_zero) == Try.of(not_raise, 1))
    assert(Try.of(not_raise, 1).filter(lambda _: False) == Try(1, False))
    assert(Try.of(not_raise, -1).filter(greater_zero) == Try(-1, False))
    assert(Try.of(raise_exception, 1).filter(greater_zero) == Try.of(raise_exception, 1))


# Generated at 2022-06-12 05:24:38.877805
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'david'

    b = Try('david', True)
    a = b.filter(filterer)
    assert a == Try('david', True), 'when filterer returns True method returns copy of monad'

    b = Try('felipe', True)
    a = b.filter(filterer)
    assert a == Try('felipe', False), 'othercase not successfully Try with previous value'


# Generated at 2022-06-12 05:24:47.734816
# Unit test for method filter of class Try
def test_Try_filter():
    # Test for successfully filter
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)

    # Test for not successfully filter
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)

    # Test for successfully not filter
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)

    # Test for not successfully not filter
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-12 05:24:51.326278
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True).filter(lambda x: x == 3) == Try(3, True)
    assert Try(3, False).filter(lambda x: x == 3) == Try(3, False)
    assert Try(2, True).filter(lambda x: x == 3) == Try(2, False)


# Generated at 2022-06-12 05:24:59.515834
# Unit test for method filter of class Try
def test_Try_filter():
    def bool_int(val):
        return type(val) is int

    assert Try.of(lambda: 1).filter(bool_int).is_success == True
    assert Try.of(lambda: "").filter(bool_int).is_success == False
    assert Try.of(lambda: []).filter(bool_int).is_success == False
    assert Try.of(lambda: {}).filter(bool_int).is_success == False
    assert Try.of(lambda: None).filter(bool_int).is_success == False


# Generated at 2022-06-12 05:25:04.744298
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-12 05:25:12.729607
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value): return True
    assert Try.of(int, '1').filter(filterer) == Try(1, True)
    assert Try.of(int, 'a').filter(filterer) == Try(ValueError('invalid literal for int() with base 10: \'a\''), False)

# Generated at 2022-06-12 05:25:23.253823
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda: 5,).filter(lambda x: x == 5)
    assert result == Try(5, True)

    result = Try.of(lambda: 5,).filter(lambda x: x == 6)
    assert result == Try(5, False)

    f = lambda x: x == 5
    result = Try.of(lambda: 5,).filter(f)
    assert result == Try(5, True)

    f = lambda x: x == 6
    result = Try.of(lambda: 5,).filter(f)
    assert result == Try(5, False)

    assert Try.of(lambda: 1,).filter(lambda x: x == 5) == Try(1, False)
    assert Try.of(lambda: 5,).filter(lambda x: x == 1) == Try(5, False)
   

# Generated at 2022-06-12 05:25:30.397474
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def less_than_100(num):
        return num < 100

    assert Try.of(lambda: [1, 2, 3]).filter(less_than_100) == Try([1, 2, 3], True)
    assert Try.of(lambda: [1, 200, 3]).filter(less_than_100) == Try([1, 200, 3], False)
    assert Try.of(lambda: []).filter(less_than_100) == Try([], True)
    assert Try.of(lambda: None).filter(less_than_100) == Try(None, False)
    assert Try.of(lambda: 1).filter(less_than_100) == Try(1, True)
    assert Try.of(lambda: 200).filter(less_than_100) == Try(200, False)

#

# Generated at 2022-06-12 05:25:36.602338
# Unit test for method filter of class Try
def test_Try_filter():
    def positive_number(num):
        return num > 0

    # Test 1
    result = Try.of(lambda: 10).filter(positive_number)
    assert result == Try(10, True)
    print('test_Try_filter: test 1 passed')

    # Test 2
    result = Try.of(lambda: 10).filter(lambda arg: arg > 20)
    assert result == Try(10, False)
    print('test_Try_filter: test 2 passed')



# Generated at 2022-06-12 05:25:42.981455
# Unit test for method filter of class Try
def test_Try_filter():
    """
    When filterer returns True method returns copy of monad, othercase
    not successfully Try with previous value.
    """
    assert Try(2, True).filter(lambda x: True) == Try(2, True)
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(2, False).filter(lambda x: True) == Try(2, False)



# Generated at 2022-06-12 05:25:49.299224
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> def filterer(val):
    ...     return val == 2
    >>> t = Try.of(lambda x: x, 2)
    >>> t.filter(filterer) == Try(2, True)
    True
    >>> a = Try(2, False)
    >>> a.filter(filterer) == Try(2, False)
    True
    """


# Generated at 2022-06-12 05:25:53.236684
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filter(input_, number):
        return input_ > number

    assert Try(5, True).filter(test_filter, 3) == Try(5, True)
    assert Try(5, True).filter(test_filter, 6) == Try(5, False)


# Generated at 2022-06-12 05:26:02.731066
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(3, True).filter(lambda x: x > 1) == Try(3, True)
    assert Try(3, True).filter(lambda x: x < 1) == Try(3, False)
    assert Try(None, True).filter(lambda x: x is not None) == Try(None, True)
    assert Try(None, True).filter(lambda x: x is None) == Try(None, False)
    assert Try(Exception('ddd'), False).filter(lambda x: hasattr(x, 'message')) == Try(Exception('ddd'), False)

# Generated at 2022-06-12 05:26:05.419013
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: -1).filter(lambda x: x >= 0) == Try(-1, False)
    assert Try.of(lambda: 1).filter(lambda x: x >= 0) == Try(1, True)

# Generated at 2022-06-12 05:26:15.725739
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter on class Try.
    """
    assert Try.of(lambda: 2, None) == Try(2, True)
    assert Try.of(lambda: 2, None).filter(lambda x: x < 3) == Try(2, True)
    assert Try(2, False).filter(lambda x: x < 3) == Try(2, False)
    assert Try(None, True).filter(lambda x: x < 3) == Try(None, False)
    try:
        assert Try.of(lambda x: 3 / x, 0).filter(lambda x: x > 0) == Try(ZeroDivisionError, False)
        assert False, 'Error on filter'
    except ZeroDivisionError:
        assert True



# Generated at 2022-06-12 05:26:25.129019
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x > 1) == Try(1, False)
    assert Try.of(lambda: 1, 's').filter(lambda x: x > 1) == Try(1, False)


# Generated at 2022-06-12 05:26:37.592832
# Unit test for method filter of class Try
def test_Try_filter():
    """Test Try filter method"""
    t = Try.of(int, '0')
    assert t.filter(lambda x: x == 0) == Try.of(int, '0').filter(lambda x: x == 0)
    assert t.filter(lambda x: x != 0) == Try.of(int, '0').filter(lambda x: x != 0)
    assert t.filter(lambda x: x != 0) != Try.of(int, '0').filter(lambda x: x == 0)
    assert Try.of(int, '0').filter(lambda x: x != 0).is_success == False
    assert Try.of(int, '0').filter(lambda x: x == 0).is_success == True
    assert Try.of(int, '0').filter(lambda x: x != 0).value == 0
    assert Try

# Generated at 2022-06-12 05:26:48.572188
# Unit test for method filter of class Try
def test_Try_filter():
    # EXAMPLES
    add10 = lambda x: x + 10
    is_even = lambda x: x % 2 == 0

    # TESTS
    assert Try.of(add10, 5) == Try(15, True)
    assert Try.of(add10, 'str') == Try('str', False)

    assert Try.of(add10, 5).map(add10) == Try(25, True)
    assert Try.of(add10, 'str').map(add10) == Try('str', False)

    assert Try.of(add10, 5).bind(lambda x: Try(x + 10, True)) == Try(25, True)
    assert Try.of(add10, 'str').bind(lambda x: Try(x + 10, True)) == Try('str', False)

# Generated at 2022-06-12 05:26:54.596764
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(0, True).filter(lambda x: x == 1) == Try(0, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(0, False).filter(lambda x: x == 1) == Try(0, False)


# Generated at 2022-06-12 05:27:02.628042
# Unit test for method filter of class Try
def test_Try_filter():
    test_values = [(1, True), (2, True), (3, False), (4, True)]
    try_values = list(map(lambda test_value: Try(test_value[0], test_value[1]), test_values))

    def filterer(value):
        return value > 2
    try_values_filtered = list(map(lambda try_value: try_value.filter(filterer), try_values))

    expected_try_values_filtered = [Try(1, False), Try(2, False), Try(3, False), Try(4, True)]
    for i, try_value_filtered in enumerate(try_values_filtered):
        assert expected_try_values_filtered[i] == try_value_filtered


# Generated at 2022-06-12 05:27:04.374789
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_positive(number): return number > 0

    assert Try(3, True).filter(is_positive) == Try(3, True)
    assert Try(-1, True).filter(is_positive) == Try(-1, False)


# Generated at 2022-06-12 05:27:09.717589
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # Setup
    input_value = 'lorem ipsum'

    # Act
    result = Try(input_value, True) \
        .filter(lambda value: len(value) < 10) \
        .get()

    # Assert
    assert result == input_value


# Generated at 2022-06-12 05:27:16.183779
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.

    :returns: AssertionError when test has failed
    :rtype: AssertionError
    """
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(1, False).filter(lambda x: True) == Try(1, False)

# Generated at 2022-06-12 05:27:24.461299
# Unit test for method filter of class Try
def test_Try_filter():
    try_func = Try.of(lambda x: x, 2)
    try_func_not = Try.of(lambda x: x, 0)
    assert(try_func.filter(lambda x: x > 1) == Try(2, True))
    assert(try_func.filter(lambda x: x < 1) == Try(0, False))
    assert(try_func_not.filter(lambda x: x > 1) == Try(0, False))



# Generated at 2022-06-12 05:27:31.157491
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: True) == Try(1, True)
    assert Try(1, False).filter(lambda v: True) == Try(1, False)
    assert Try(1, True).filter(lambda v: False) == Try(1, False)
    assert Try(1, False).filter(lambda v: False) == Try(1, False)



# Generated at 2022-06-12 05:27:43.472427
# Unit test for method filter of class Try
def test_Try_filter():
    try_with_value = Try(10, True)
    res = try_with_value.filter(lambda x: x > 5)
    assert res == Try(10, True)

    res = try_with_value.filter(lambda x: x > 15)
    assert res == Try(10, False)



# Generated at 2022-06-12 05:27:52.366313
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return True

    def filterer2(value):
        return True
    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(1, True).filter(filterer2) == Try(1, True)
    assert Try(1, False).filter(filterer2) == Try(1, False)


# Generated at 2022-06-12 05:27:56.076974
# Unit test for method filter of class Try
def test_Try_filter():
    true_ = lambda x: True
    false = lambda x: False

    assert Try.of(lambda x: x, 1).filter(true_) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(false) == Try(1, False)

# Generated at 2022-06-12 05:28:00.939813
# Unit test for method filter of class Try
def test_Try_filter():
    """
    :returns: None
    :rtype: None
    """
    assert Try(10, True).filter(lambda x: x > 0) == Try(10, True)
    assert Try(10, True).filter(lambda x: x <= 0) == Try(10, False)
    assert Try(10, False).filter(lambda x: x <= 0) == Try(10, False)


# Generated at 2022-06-12 05:28:04.823082
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 0) == Try(1, False)

test_Try_filter()

# Generated at 2022-06-12 05:28:15.094138
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover

    def test_filter_when_on_success_and_value_is_less_then_ten_and_filterer_return_true():
        try_value = Try(1, True)
        try_value = try_value.filter(lambda v: v < 10)
        assert try_value == Try(1, True)

    def test_filter_when_on_success_and_value_is_less_then_ten_and_filterer_return_false():
        try_value = Try(1, True)
        try_value = try_value.filter(lambda v: v > 10)
        assert try_value == Try(1, False)


# Generated at 2022-06-12 05:28:19.605833
# Unit test for method filter of class Try
def test_Try_filter():
    # arrange
    t1 = Try(0, False)

    # act
    t2 = t1.filter(lambda x: x == 0)
    t3 = t1.filter(lambda x: x == 1)

    # assert
    assert t2 == t1
    assert t3 == t1



# Generated at 2022-06-12 05:28:23.591024
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try
    """
    assert Try(1, True).filter(lambda x: x < 3) == Try(1, True)
    assert Try(4, True).filter(lambda x: x < 3) == Try(4, False)
    assert Try(3, False).filter(lambda x: x < 3) == Try(3, False)


# Generated at 2022-06-12 05:28:29.233170
# Unit test for method filter of class Try
def test_Try_filter():
    value_0 = 'string'
    value_1 = 'not_string'
    is_success = True
    is_fail = False
    t_0 = Try(value_0, is_success)
    assert t_0.filter(lambda x: type(x) == str) == Try(value_0, is_success)
    t_1 = Try(value_1, is_success)
    assert t_1.filter(lambda x: type(x) == str) == Try(value_1, is_fail)

# Generated at 2022-06-12 05:28:36.815995
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(4, True).filter(lambda x: x % 2 == 0) == Try(4, True)
    assert Try(4, True).filter(lambda x: x % 2 == 1) == Try(4, False)
    assert Try(4, False).filter(lambda x: x % 2 == 0) == Try(4, False)
    assert Try(4, False).filter(lambda x: x % 2 == 1) == Try(4, False)


test_Try_filter()

# Generated at 2022-06-12 05:28:55.680646
# Unit test for method filter of class Try
def test_Try_filter():
    fn = lambda x: x < 4
    assert Try(2, True).filter(fn) == Try(2, True)
    assert Try(5, True).filter(fn) == Try(5, False)
    assert Try(5, False).filter(fn) == Try(5, False)
    assert Try(7, False).filter(fn) == Try(7, False)
    assert Try(0, True).filter(fn) == Try(0, True)

# Generated at 2022-06-12 05:29:01.750000
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda val: True) == Try(10, True)
    assert Try(10, True).filter(lambda val: val > 1) == Try(10, True)
    assert Try(10, True).filter(lambda val: val > 11) == Try(10, False)
    assert Try(10, False).filter(lambda val: True) == Try(10, False)
    assert Try(10, False).filter(lambda val: val > 1) == Try(10, False)
    assert Try(10, False).filter(lambda val: val > 11) == Try(10, False)



# Generated at 2022-06-12 05:29:10.111931
# Unit test for method filter of class Try
def test_Try_filter():
    def test_case(value, expected):
        assert Try(value, True).filter(lambda _: True).value == expected

    test_case(True, True)
    test_case(False, False)
    test_case(None, None)
    test_case(0, 0)
    test_case(1, 1)
    test_case(0.1, 0.1)
    test_case([], [])
    test_case(['1'], ['1'])
    test_case({'a': 1}, {'a': 1})
    test_case('', '')
    test_case('a', 'a')
    test_case(Exception, Exception)


# Generated at 2022-06-12 05:29:16.231220
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x + 200, 100).filter(lambda x: x > 10) == Try(300, True)
    assert Try.of(lambda x: x + 200, 100).filter(lambda x: x > 1000) == Try(300, False)
    assert Try.of(KeyError, 100).filter(lambda x: x > 10) == Try(KeyError(), False)



# Generated at 2022-06-12 05:29:21.257941
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """
    # Testing when monad is successfully
    exception = ValueError('Error on some operation')
    assert Try.of(lambda: exception, 0) == Try(exception, True)\
        .filter(lambda e: e.args[0] == 'Error on some operation')

    # Testing when monad is not successfully
    assert Try.of(lambda: exception, 0) == Try(exception, False)\
        .filter(lambda e: e.args[0] == 'Error on some operation')

# Generated at 2022-06-12 05:29:28.949705
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x: int) -> bool:
        return x == 1

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(2, False).filter(filterer) == Try(2, False)



# Generated at 2022-06-12 05:29:34.914861
# Unit test for method filter of class Try
def test_Try_filter():
    def _positive_number(number):
        return number > 0

    positive_number = Try.of(lambda x: x, 1)
    assert positive_number.filter(_positive_number) == Try(1, True)

    negative_number = Try.of(lambda x: x, -1)
    assert negative_number.filter(_positive_number) == Try(-1, False)

if __name__ == '__main__':
    test_Try_filter()

# Generated at 2022-06-12 05:29:38.593115
# Unit test for method filter of class Try
def test_Try_filter():
    def f(x):
        return x < 3

    assert Try(1, True).filter(f) == Try(1, True)
    assert Try(4, True).filter(f) == Try(4, False)
    assert Try(4, False).filter(f) == Try(4, False)


# Generated at 2022-06-12 05:29:50.178907
# Unit test for method filter of class Try
def test_Try_filter():
    from random import random
    from datetime import datetime
    from random import randint
    from random import choice

    def try_factory(randint_num, is_success=False):
        def _fn(randint_num):
            if randint_num > 10:
                raise Exception
            return randint_num
        return Try.of(_fn, randint_num) if is_success else Try(randint_num, False)

    def gen_int():
        return randint(0, 10000)

    def gen_alpha():
        return ''.join(choice('qwertyuiopasdfghjklzxcvbnm') for x in range(randint(1, 30)))


# Generated at 2022-06-12 05:29:56.193580
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter of class Try.

    :returns: None
    :rtype: None
    """
    def filterer(x):
        return x > 5

    try_success_with_filter = Try.of(lambda x: x, 10)
    assert try_success_with_filter.filter(filterer) == Try(10, True)

    try_success_without_filter = Try.of(lambda x: x, 2)
    assert try_success_without_filter.filter(filterer) == Try(2, False)

    try_fail_with_filter = Try.of(lambda x: 1 / 0, 10)
    assert try_fail_with_filter.filter(filterer) == Try(try_fail_with_filter.value, False)


# Generated at 2022-06-12 05:30:15.938126
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1)\
        == Try(1, True)

    assert Try(1, True).filter(lambda x: x == 2)\
        == Try(1, False)

    assert Try(1, False).filter(lambda x: x == 2)\
        == Try(1, False)



# Generated at 2022-06-12 05:30:27.184793
# Unit test for method filter of class Try
def test_Try_filter():
    from datetime import datetime, timedelta

    # создаем массив случайных цен (20 элементов)
    prices = [random.random() for _ in range(20)]
    # вычисляем дату текущего дня и предыдущего
    starting_date = datetime.now()
    ending_date = starting_date - timedelta(days=1)

    # фильтруем цены, которые получены за по

# Generated at 2022-06-12 05:30:33.500060
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for methods filter of Try class.

    :returns: nothing
    :rtype: None
    """
    # Successful
    assert Try(1, True).filter(lambda x: x % 2 == 0) == Try(1, False)
    assert Try(1, True).filter(lambda x: x % 2 == 1) == Try(1, True)

    # Not successful
    assert Try(1, False).filter(lambda x: x % 2 == 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x % 2 == 1) == Try(1, False)



# Generated at 2022-06-12 05:30:45.271398
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try
    """
    def stub_filterer(x):
        return x % 2 == 0

    # Successfully monad Try with even number
    value = Try(2, True)

    # Check that Try is successfully and contains even number
    assert isinstance(value, Try) and\
        value.value == 2 and\
        value.is_success

    # Call trunc with successfully monad Try and check that value is even number
    value = value.filter(stub_filterer)

    assert isinstance(value, Try) and\
        value.value == 2 and\
        value.is_success

    # Successfully monad Try with odd number
    value = Try(1, True)

    # Check that Try is successfully and contains odd number

# Generated at 2022-06-12 05:30:54.091398
# Unit test for method filter of class Try
def test_Try_filter():
    def get_user_by_id(id: int) -> dict:
        user = {'id': id, 'name': 'example user name', 'surname': 'example user surname', 'age': 20}

        if id > 0:
            return user

        raise ValueError('Illegal user id: {}'.format(id))

    def user_age_greater_10(user: dict) -> bool:
        return user['age'] > 10

    assert Try.of(get_user_by_id, -1).filter(user_age_greater_10).is_success == False
    assert Try.of(get_user_by_id, 1).filter(user_age_greater_10).is_success == True

# Generated at 2022-06-12 05:30:58.077855
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(100, True).filter(lambda x: x > 0).get() == Try(100, True).get()
    assert Try(100, True).filter(lambda x: x < 0).get() == Try(None, False).get()



# Generated at 2022-06-12 05:31:05.965149
# Unit test for method filter of class Try
def test_Try_filter():
    filterer_return_true = lambda x: True
    filterer_return_false = lambda x: False
    assert Try(1, True).filter(filterer_return_true).get() == Try(1, True).get()
    assert Try(1, True).filter(filterer_return_false).get() == Try(1, False).get()

    assert Try(1, False).filter(filterer_return_true).get() == Try(1, False).get()
    assert Try(1, False).filter(filterer_return_false).get() == Try(1, False).get()



# Generated at 2022-06-12 05:31:09.674538
# Unit test for method filter of class Try
def test_Try_filter():
    assert(Try.of(lambda: 1, ()).filter(lambda x: x == 1) == Try(1, True))
    assert(Try.of(lambda: 1, ()).filter(lambda x: x == 2) == Try(ValueError(None), False))
    assert(Try.of(lambda: 1/0, ()).filter(lambda x: x == 2) == Try(ZeroDivisionError, False))


# Generated at 2022-06-12 05:31:17.119421
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for Try.filter(...) method.
    """
    def filter_test(value):
        return value >= 0

    def filter_test2(value):
        return False

    assert Try.of(lambda x: x, 2)\
        .filter(filter_test)\
        .get() == 2
    assert not Try.of(lambda x: x, 2)\
        .filter(filter_test2)\
        .is_success


# Generated at 2022-06-12 05:31:24.162689
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    result = (
        Try.of(lambda: 10)
        .filter(lambda x: x > 5)
        .filter(lambda x: x < 15)
        .get_or_else(0)
    )
    answer = 10
    assert result == answer

    result = (
        Try.of(lambda: 100)
        .filter(lambda x: x > 5)
        .filter(lambda x: x < 15)
        .get_or_else(0)
    )
    answer = 0
    assert result == answer

    result = (
        Try.of(lambda: 0)
        .filter(lambda x: x > 5)
        .filter(lambda x: x < 15)
        .get_or_else(0)
    )
    answer = 0
    assert result == answer



# Generated at 2022-06-12 05:32:13.313400
# Unit test for method filter of class Try
def test_Try_filter():
    print('Test Try.filter() method')

    print('Test when is_success=True and filterer returns True')
    try_with_true = Try(42, True)
    try_with_true_filterer = lambda value: value == 42
    result = try_with_true.filter(try_with_true_filterer)
    assert result == Try(42, True)
    print('Test OK')

    print('Test when is_success=True and filterer returns False')
    try_with_true = Try(42, True)
    try_with_false_filterer = lambda value: value == 43
    result = try_with_true.filter(try_with_false_filterer)
    assert result == Try(42, False)
    print('Test OK')


# Generated at 2022-06-12 05:32:18.752797
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x == 1

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(0, True).filter(filterer) == Try(0, False)
    assert Try(0, False).filter(filterer) == Try(0, False)



# Generated at 2022-06-12 05:32:20.814264
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 2).filter(lambda x: x == 1) == Try(2, False)


# Generated at 2022-06-12 05:32:31.783043
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 10

    # Test for successful monad
    actual = Try(20, True).filter(filterer)
    assert actual.get() == 20 and actual.is_success == True

    actual = Try(9, True).filter(filterer)
    assert actual.get() == 9 and actual.is_success == False

    # Test for failed monad
    actual = Try(20, False).filter(filterer)
    assert actual.get() == 20 and actual.is_success == False

    actual = Try(9, False).filter(filterer)
    assert actual.get() == 9 and actual.is_success == False



# Generated at 2022-06-12 05:32:41.047012
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    some_value = 'A'
    upper_case_value = 'A'
    lower_case_value = 'a'
    case_insensitive_filterer = lambda v: v.lower() == v.upper()
    some_Try = Try.of(lambda: some_value, None)
    upper_case_Try = Try.of(lambda: upper_case_value, None)
    lower_case_Try = Try.of(lambda: lower_case_value, None)

    # When
    actual = lower_case_Try.filter(case_insensitive_filterer)

    # Then
    assert actual != some_Try
    assert actual != upper_case_Try
    assert actual == lower_case_Try


# Generated at 2022-06-12 05:32:47.559868
# Unit test for method filter of class Try
def test_Try_filter():
    try_5 = Try.of(lambda: 5, 0)
    try_5_filtered = try_5.filter(lambda x: x >= 3)
    assert try_5_filtered == Try(5, True)

    try_5_fail_filter = try_5.filter(lambda x: x < 3)
    assert try_5_fail_filter == Try(5, False)



# Generated at 2022-06-12 05:32:54.638615
# Unit test for method filter of class Try
def test_Try_filter():

    def filterer(val):
        return val == 1

    try_true_monad = Try(1, True)
    try_false_monad = Try(1, False)

    try_true_result = try_true_monad.filter(filterer)
    assert try_true_result.is_success
    assert try_true_result == Try(1, True)
    try_false_result = try_false_monad.filter(filterer)
    assert not try_false_result.is_success
    assert try_false_result == Try(1, False)


# Generated at 2022-06-12 05:33:04.450031
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(data):
        if data % 2 == 0:  # if data is even
            return True   # pass
        return False    # not pass

    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(10, True).filter(filterer).value == 10
    assert Try(9, True).filter(filterer) == Try(9, False)
    assert Try(9, True).filter(filterer).value == 9
    assert Try(10, False).filter(filterer) == Try(10, False)
    assert Try(10, False).filter(filterer).value == 10

# Generated at 2022-06-12 05:33:10.007231
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x <= 2) == Try(1, True)
    assert Try(1, True).filter(lambda x: x <= 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: True) == Try(1, False)
    assert Try(Exception('error'), False).filter(lambda x: False) == Try(Exception('error'), False)

# Generated at 2022-06-12 05:33:19.772431
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True), '{} should be {}'.format(
            Try(1, True).filter(lambda x: x > 0), Try(1, True))
    assert Try(0, True).filter(lambda x: x > 0) == Try(0, False), '{} should be {}'.format(
            Try(0, True).filter(lambda x: x > 0), Try(0, False))
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False), '{} should be {}'.format(
            Try(1, False).filter(lambda x: x > 0), Try(1, False))
