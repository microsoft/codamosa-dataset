

# Generated at 2022-06-12 05:23:59.453676
# Unit test for method filter of class Try
def test_Try_filter():
    ugly_say_hello = lambda who: 'Hello {}!'.format(who)

    # Test check when monad value is successfully and filterer returns True
    def check_filter_True(): nonlocal ugly_say_hello
    try_result = Try.of(ugly_say_hello, 'World').filter(lambda value: True)
    assert try_result == Try('Hello World!', True)

    # Test check when monad value is successfully and filterer returns False
    def check_filter_False(): nonlocal ugly_say_hello
    try_result = Try.of(ugly_say_hello, 'World').filter(lambda value: False)
    assert try_result == Try('Hello World!', False)

    # Test check when monad value is not successfully
    def check_filter_Fail(): nonlocal ugly_say_hello
   

# Generated at 2022-06-12 05:24:06.687570
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 10) == Try(10, True)
    assert Try.of(lambda: 10).map(lambda value: value+2) == Try(12, True)
    assert Try.of(lambda: 10).filter(lambda value: value%2==0) == Try(10, True)
    assert Try.of(lambda: 10).filter(lambda value: value%2==1) == Try(10, False)
    assert Try.of(lambda: 10).on_success(lambda value: print(value)) == Try(10, True)
    assert Try.of(lambda: 10).on_fail(lambda value: print(value)) == Try(10, True)
    assert Try.of(lambda: 10).bind(lambda value: Try(value+2, True)) == Try(12, True)

# Generated at 2022-06-12 05:24:11.747896
# Unit test for method filter of class Try
def test_Try_filter():
    assert_equal(True, Try(10, True).filter(lambda x: x < 15).is_success)
    assert_equal(10, Try(10, True).filter(lambda x: x < 15).get())
    assert_equal(False, Try(10, True).filter(lambda x: x > 15).is_success)
    assert_equal(10, Try(10, True).filter(lambda x: x > 15).get())
    assert_equal(False, Try(10, False).filter(lambda x: x < 15).is_success)
    assert_equal(10, Try(10, False).filter(lambda x: x < 15).get())
    assert_equal(False, Try(10, False).filter(lambda x: x > 15).is_success)

# Generated at 2022-06-12 05:24:16.478465
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x > 4) == Try(5, True)
    assert Try(5, True).filter(lambda x: x < 4) == Try(5, False)
    assert Try(5, False).filter(lambda x: x > 4) == Try(5, False)



# Generated at 2022-06-12 05:24:23.227414
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    _list = [1]
    _try_list = Try(_list, True)
    filterer = lambda value: True
    def _test(result):
        # THEN
        assert isinstance(result, Try)
        assert result.is_success
        assert result.value == _list
    # WHEN
    _try_list.filter(filterer).on_success(_test)
    # THEN
    _try_list.filter(lambda value: False).on_fail(_test)


# Generated at 2022-06-12 05:24:27.002934
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v % 2 == 0) == Try(1, False)
    assert Try(2, True).filter(lambda v: v % 2 == 0) == Try(2, True)
    assert Try(None, False).filter(lambda v: v % 2 == 0) == Try(None, False)



# Generated at 2022-06-12 05:24:31.521532
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Tests for method filter of class Try
    """
    assert Try(10, True).filter(lambda value: value > 5) == Try(10, True)
    assert Try(1, True).filter(lambda value: value > 5) == Try(1, False)
    assert Try(10, False).filter(lambda value: value > 5) == Try(10, False)



# Generated at 2022-06-12 05:24:37.469108
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True)\
        .filter(lambda x: x == 1)\
        .get() == 1, 'Got wrong value from filter method.'

    assert not Try(1, True)\
        .filter(lambda x: x == 3)\
        .is_success, 'Got wrong value from filter method.'

    assert Try(None, False)\
        .filter(lambda x: x == 3)\
        .get() == None, 'Got wrong value from filter method.'



# Generated at 2022-06-12 05:24:49.394077
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from collections import namedtuple
    from random import uniform

    Person = namedtuple('Person', ['age', 'name', 'surname'])
    persons = [
        Person(age=int(uniform(10, 100)), name=chr(i), surname='Doe')
        for i in range(65, 91)
    ]

    over_18 = Try.of(filter, lambda p: p.age > 18, persons).get()
    assert over_18 == list(filter(lambda p: p.age > 18, persons))

    over_18_old_persons = Try.of(map, lambda p: p._replace(age=p.age + 10), over_18).get()

# Generated at 2022-06-12 05:24:54.840914
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda value: value == 1) == Try(1, True)
    assert Try(1, True).filter(lambda value: value == 2) == Try(1, False)
    assert Try(None, False).filter(lambda value: value is None) == Try(None, False)

# Generated at 2022-06-12 05:25:02.392639
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    # WHEN
    result = Try.of(lambda: 1).filter(lambda x: x == 1)

    # THEN
    assert result == Try(1, True)


# Generated at 2022-06-12 05:25:11.140976
# Unit test for method filter of class Try
def test_Try_filter():
    test_cases = [
        {
            'name': 'one',
            'input': {'filterer': lambda x: x == 10, 'value': 10},
            'expected': Try(10, True),
        },
        {
            'name': 'two',
            'input': {'filterer': lambda x: x == 10, 'value': 12},
            'expected': Try(12, False),
        },
        {
            'name': 'three',
            'input': {'filterer': lambda x: x == 10, 'value': 12},
            'expected': Try(12, False),
        },
    ]


# Generated at 2022-06-12 05:25:22.291029
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """

    # create two functions
    def filter_fn(x):
        """
        function to be applied by filter method
        """
        return x < 3

    def get_o_e(x):
        """
        Return value when it's more then 3.
        """
        if x > 3:
            return x
        return None

    # create Try monads
    one = Try(1, True)
    two = Try(2, True)
    three = Try(3, True)
    four = Try(4, True)
    five = Try(5, True)

    # create not successful Try monads
    ex = Exception()
    one_ex = Try(1, False)
    two_ex = Try(2, False)

    # add to list all monads

# Generated at 2022-06-12 05:25:23.253360
# Unit test for method filter of class Try
def test_Try_filter():
    # given
    value = 1

# Generated at 2022-06-12 05:25:25.706140
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: 1 < x).value is None
    assert Try.of(lambda: 1).filter(lambda x: x == 1).value == 1


# Generated at 2022-06-12 05:25:29.925136
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    ex_filter = Try.of(lambda x: x * x, 2)
    assrt_filter = ex_filter.filter(lambda x: x > 0)

    assert Try(4, True) == assrt_filter

    ex_filter = Try.of(lambda x: x * x, 2)
    assrt_filter = ex_filter.filter(lambda x: x < 0)

    assert Try(4, False) == assrt_filter


# Generated at 2022-06-12 05:25:34.209126
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda a: 10, 1)\
            .filter(lambda a: a % 2 == 0) == Try(10, False)
    assert Try.of(lambda a: 10, 2)\
            .filter(lambda a: a % 2 == 0) == Try(10, True)



# Generated at 2022-06-12 05:25:37.575896
# Unit test for method filter of class Try
def test_Try_filter():
    rule = lambda value: value == 5
    some = Try(5, True).filter(rule)
    none = Try(5, False).filter(rule)
    assert some == Try(5, True)
    assert none == Try(5, False)

# Generated at 2022-06-12 05:25:42.012429
# Unit test for method filter of class Try
def test_Try_filter():
    fn = lambda a: a % 2 == 0
    monad = Try(1, True).filter(fn)
    assert not monad.is_success
    monad = Try(2, True).filter(fn)
    assert monad.is_success


# Generated at 2022-06-12 05:25:45.006699
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(6, True).filter(lambda x: x == 6) == Try(6, True)
    assert Try(6, True).filter(lambda x: x != 6) == Try(6, False)
    assert Try(6, False).filter(lambda x: x == 6) == Try(6, False)
    assert Try(6, False).filter(lambda x: x != 6) == Try(6, False)


# Generated at 2022-06-12 05:25:53.795409
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(n):
        return n % 2 == 0

    # successful
    assert Try(2, True).filter(filterer) == Try(2, True)

    # failure
    assert Try(3, True).filter(filterer) == Try(3, False)
    assert Try(Exception, False).filter(filterer) == Try(Exception, False)



# Generated at 2022-06-12 05:26:05.097404
# Unit test for method filter of class Try
def test_Try_filter():
    class MyException(Exception):
        def __init__(self, message):
            super(MyException, self).__init__(message)

    def check_is_even(value):
        if value % 2 == 0:
            return True
        raise MyException(value)

    def check_is_odd(value):
        if value % 2 == 1:
            return True
        raise MyException(value)

    assert Try.of(check_is_even, 10).filter(check_is_odd).get_or_else(False) == False
    assert Try.of(check_is_even, 10).filter(check_is_even).get_or_else(False) == True
    assert Try.of(check_is_even, 11).filter(check_is_odd).get_or_else(False) == True

# Generated at 2022-06-12 05:26:11.340903
# Unit test for method filter of class Try
def test_Try_filter():
    def validator(value):
        return value > 3

    # Positive examples
    assert Try(4, True).filter(validator) == Try(4, True)
    assert Try(5, True).filter(validator) == Try(5, True)

    # Negative examples
    assert Try(2, True).filter(validator) == Try(2, False)
    assert Try(2, False).filter(validator) == Try(2, False)



# Generated at 2022-06-12 05:26:19.085191
# Unit test for method filter of class Try
def test_Try_filter():
    None #pragma: no cover
    # Successful Try
    assert Try\
        .of(lambda x: x + 1, 2)\
        .map(lambda x: x * 2)\
        .filter(lambda x: x > 2)\
        .get() == 6

    # Failing Try
    assert Try\
        .of(lambda x: x + 1, 2)\
        .map(lambda x: x * 2)\
        .filter(lambda x: x > 10)\
        .get_or_else(5) == 5

test_Try_filter()

# Generated at 2022-06-12 05:26:23.416468
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(7, True).filter(filterer) == Try(7, True)


# Generated at 2022-06-12 05:26:31.324422
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(100, True).filter(lambda x: True) == Try(100, True)
    assert Try(100, True).filter(lambda x: False) == Try(100, False)
    assert Try(ValueError('Invalid value'), False).filter(lambda x: True) == Try(ValueError('Invalid value'), False)
    assert Try(ValueError('Invalid value'), False).filter(lambda x: False) == Try(ValueError('Invalid value'), False)

# Generated at 2022-06-12 05:26:38.294161
# Unit test for method filter of class Try
def test_Try_filter():
    try:
        raise Exception('foo')
    except Exception as e:
        # when monad is not successfully method filter shouldn't affect
        try_ = Try.of(lambda: 4, 5)
        assert try_.filter(lambda value: value > 2) == Try(4, True)

        # when monad is successfully method filter should affect
        try_ = Try(4, True)
        assert try_.filter(lambda value: value > 2) == Try(4, True)
        assert try_.filter(lambda value: value < 2) == Try(4, False)


# Generated at 2022-06-12 05:26:46.946726
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: '1').filter(lambda i: i == '1') == Try('1', True)
    assert Try.of(lambda: '1').filter(lambda i: i == '2') == Try('1', False)
    assert Try.of(lambda: '1').filter(lambda i: i == '2').on_fail(
        lambda e: 'Test') == Try('1', False)
    assert Try.of(Exception('oops')).filter(lambda i: i == '2').on_fail(
        lambda e: 'Test') == Try('oops', False)



# Generated at 2022-06-12 05:26:54.817254
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    def filterer(x):
        return x == 1
    my_try = Try(value=1, is_success=True)

    # WHEN
    result = my_try.filter(filterer)

    # THEN
    assert result == Try(value=1, is_success=True)

    # GIVEN
    my_try = Try(value=2, is_success=True)

    # WHEN
    result = my_try.filter(filterer)

    # THEN
    assert result == Try(value=2, is_success=False)


# Generated at 2022-06-12 05:27:00.478746
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True).filter(lambda x: x == 3) == Try(3, True)
    assert Try(3, True).filter(lambda x: x < 2) == Try(3, False)
    assert Try(3, False).filter(lambda x: x == 3) == Try(3, False)
    assert Try(3, False).filter(lambda x: x < 2) == Try(3, False)



# Generated at 2022-06-12 05:27:12.925395
# Unit test for method filter of class Try
def test_Try_filter():
    inc = lambda x: x + 1
    add = lambda x, y: x + y
    filt = lambda x: x < 10

    success = Try(3, True)
    failed = Try(3, False)

    assert success.filter(filt) == Try(3, True)
    assert failed.filter(filt) == Try(3, False)

    assert success.map(inc).filter(filt) == Try(4, True)
    assert success.map(inc).filter(filt) == Try(4, True)

    assert success.filter(filt).map(inc) == Try(4, True)
    assert success.filter(filt).map(inc) == Try(4, True)

    assert success.map(inc).bind(lambda x: Try(add(x, 7), True)).filter(filt)

# Generated at 2022-06-12 05:27:17.367153
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(1, True).filter(lambda d: d % 2 == 0) == Try(1, False)
    assert Try(2, True).filter(lambda d: d % 2 == 0) == Try(2, True)
    assert Try(1, False).filter(lambda d: d % 2 == 0) == Try(1, False)


# Generated at 2022-06-12 05:27:24.185927
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method.
    """
    def filterer(value):
        """
        Simple filterer function
        """
        return value > 1

    t1 = Try(1, True)
    assert t1.filter(filterer) == Try(1, False)
    t2 = Try(2, True)
    assert t2.filter(filterer) == Try(2, True)


# Generated at 2022-06-12 05:27:35.970450
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 10

    def filterer_with_error(x):
        if x > 10:
            return True
        raise Exception('Error in filterer_with_error')

    try_value_11 = Try(11, True)
    try_value_10 = Try(10, True)
    try_exception = Try(Exception('test-exception'), False)

    assert try_value_11.filter(filterer) == Try(11, True)
    assert try_value_11.filter(filterer_with_error) == Try(11, True)
    assert try_value_10.filter(filterer) == Try(10, False)
    assert try_value_10.filter(filterer_with_error) == Try(10, False)

# Generated at 2022-06-12 05:27:46.866244
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from unittest import TestCase, main

    class TestTryFilter(TestCase):
        def test_filter_on_success(self):
            def filterer(value: int):
                return value > 10

            tr = Try(10, True).filter(filterer)
            assert not tr.is_success

            tr = Try(20, True).filter(filterer)
            assert tr.is_success

        def test_filter_on_fail(self):
            def filterer(value: int):
                return value > 10

            tr = Try(10, False).filter(filterer)
            assert not tr.is_success

            tr = Try(20, False).filter(filterer)
            assert not tr.is_success

    main()


# Generated at 2022-06-12 05:27:57.496752
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test positive result:
        returns successfully Try with previous value when value is correct.

    Test negative result:
        returns not successfully Try with previous value when value is incorrect.
    """
    class Animal:
        """
        Animal class for test filter method.
        """

        def __init__(self, name):
            self.name = name

    class AnimalUtils:
        """
        Utils for test filter method.
        """

        @staticmethod
        def starts_with_j(animal: Animal) -> bool:
            """
            Check if animal name starts from j.
            """
            return animal.name.startswith('j')

    # Test positive result
    try_value = Try(Animal('jack'), True)
    result = try_value.filter(AnimalUtils.starts_with_j)
    assert result

# Generated at 2022-06-12 05:28:05.370583
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    test_value = 1

    def filterer(value):
        return value == test_value

    try_with_test_value = Try(test_value, True)

    assert try_with_test_value.filter(filterer) == Try(test_value, True)

    try_without_test_value = Try(test_value - 1, True)

    assert try_without_test_value.filter(filterer) == Try(test_value - 1, False)


# Generated at 2022-06-12 05:28:13.570086
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, []).filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(lambda: -1, []).filter(lambda x: x > 0) == Try(-1, False)
    assert Try.of(lambda: 1, []).filter(lambda x: x > 0).filter(lambda x: x < 2) == Try(1, True)
    assert Try.of(lambda: -1, []).filter(lambda x: x > 0).filter(lambda x: x < 2) == Try(-1, False)


# Generated at 2022-06-12 05:28:23.591804
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test function for filter method of class Try.
    """
    def filter_fn(x):
        if x >= 3:
            return True
        return False

    class TestClass:
        """
        Test class for filter method of class Try.
        """
        def __init__(self, value) -> None:
            self.value = value

        def filter(self, x):
            if x >= 3:
                return True
            return False

    assert Try(1, True).filter(filter_fn) == Try(1, False)
    assert Try(3, True).filter(filter_fn) == Try(3, True)
    assert Try(4, True).filter(filter_fn) == Try(4, True)

    assert Try(1, True).filter(TestClass(2).filter) == Try(1, False)

# Generated at 2022-06-12 05:28:29.023082
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 5


# Generated at 2022-06-12 05:28:37.025152
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from typing import Callable
    from random import randint
    array = [1, 2, 3, 4, 5]

    def even(x):
        return x % 2 == 0

    # successfully case
    assert Try.of(lambda: array[randint(0, len(array) - 1)])\
        .filter(even)\
        .is_success

    # case with exception
    array.pop(randint(0, len(array) - 1))
    assert not Try.of(lambda: array[randint(0, len(array) - 1)])\
        .filter(even)\
        .is_success

    # case with exception
    assert not Try.of(lambda: array[-1])\
        .filter(even)\
        .is_success

# Generated at 2022-06-12 05:28:40.925766
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x * 2, 2).filter(lambda x: x > 9) == Try(4, False)
    assert Try.of(lambda x: x * 2, 2).filter(lambda x: x > 3) == Try(4, True)

# Generated at 2022-06-12 05:28:45.727351
# Unit test for method filter of class Try
def test_Try_filter():
    print('test_Try_filter')
    value = Try.of(lambda: 1)
    value = value.filter(lambda x: x == 1)
    assert value == Try(1, True)
    value = value.filter(lambda x: x == 2)
    assert value == Try(1, False)
    print('test_Try_filter passed')



# Generated at 2022-06-12 05:28:51.929377
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return isinstance(value, int)

    success = Try(1, True)
    assert success.filter(filterer) == Try(1, True), 'Success should not change'
    failure = Try('1', True)
    assert failure.filter(filterer) == Try('1', False), 'Success should be False'


# Generated at 2022-06-12 05:28:58.410058
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True)\
        .filter(lambda v: v > 2)\
        .value == 3
    assert Try(1, True)\
        .filter(lambda v: v > 2)\
        .is_success is False
    assert Try(1, False)\
        .filter(lambda v: v > 2)\
        .is_success is False
    assert Try(1, False)\
        .filter(lambda v: v > 2)\
        .value == 1

# Generated at 2022-06-12 05:29:05.698298
# Unit test for method filter of class Try
def test_Try_filter():
    # Test for successfully filter
    assert Try(2, True).filter(lambda t: t == 2) == Try(2, True)
    # Test for not successfully filter
    assert Try(2, True).filter(lambda t: t != 2) == Try(2, False)
    # Test for not successfully monad filter
    assert Try(2, False).filter(lambda t: t == 2) == Try(2, False)


# Generated at 2022-06-12 05:29:10.592477
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(1, False).filter(lambda x: True) == Try(1, False)

# Generated at 2022-06-12 05:29:16.755499
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(1, False).filter(lambda x: True) == Try(1, False)
    assert Try(1, False).filter(lambda x: False) == Try(1, False)


# Generated at 2022-06-12 05:29:21.898334
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value > 2

    try_1 = Try(1, True)
    try_1_result = try_1.filter(filterer)
    assert try_1_result == Try(1, False)


# Generated at 2022-06-12 05:29:28.306815
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x < 2) == Try(1, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(-1, True).filter(lambda x: False) == Try(-1, False)
    assert Try(-1, False).filter(lambda x: False) == Try(-1, False)

# Generated at 2022-06-12 05:29:39.396039
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(4, True).filter(lambda value: value == 4) == Try(4, True)
    assert Try(4, False).filter(lambda value: value == 4) == Try(4, False)

# Generated at 2022-06-12 05:29:44.998185
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x < 100) == Try(10, True)
    assert Try(10, True).filter(lambda x: x > 100) == Try(10, False)
    assert Try(10, False).filter(lambda x: x < 100) == Try(10, False)

# Generated at 2022-06-12 05:29:52.992205
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x == 10) == Try(10, True)
    assert Try(10, True).bind(lambda x: Try(x, x > 5)).filter(lambda x: x == 10) == Try(10, True)
    assert Try(10, True).bind(lambda x: Try(x, x > 5)).filter(lambda x: x != 10) == Try(10, False)
    assert Try(10, True).bind(lambda x: Try(x, False)).filter(lambda x: x == 10) == Try(10, False)
    assert Try(5, False).filter(lambda x: x == 10) == Try(5, False)


# Generated at 2022-06-12 05:30:02.055085
# Unit test for method filter of class Try
def test_Try_filter():
    x = 6
    def filterer(y: int) -> bool:
        return y > 5

    assert Try.of(lambda x: x, x)\
        .filter(filterer)\
        .get() == x
    assert Try.of(lambda x: x, x)\
        .filter(lambda x: x > 10)\
        .get_or_else(-1) == -1
    assert not Try.of(lambda x: x, x)\
        .filter(lambda x: x > 10).is_success
    assert Try.of(lambda x: x, x)\
        .filter(lambda x: x > 10).get_or_else(-1) == -1



# Generated at 2022-06-12 05:30:07.010282
# Unit test for method filter of class Try
def test_Try_filter():
    try_case = Try(1, True)
    assert try_case.filter(lambda x: x == 1) == Try(1, True)
    assert try_case.filter(lambda x: x == 0) == Try(1, False)

    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-12 05:30:12.678559
# Unit test for method filter of class Try
def test_Try_filter():
    from pytest import raises

    assert Try(5, True).filter(lambda x: x % 2 == 0) == Try(5, False)
    assert Try(4, True).filter(lambda x: x % 2 == 0) == Try(4, True)
    assert Try(5, True).filter(lambda x: 0) == Try(5, False)
    assert Try(5, False).filter(lambda x: x % 2 == 0) == Try(5, False)

# Generated at 2022-06-12 05:30:22.455535
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.

    :returns: True when all test is ok, False when at least one test is not ok
    :rtype: Boolean
    """
    is_ok = True

    # Test for successful Try
    is_ok &= Assert.assert_equals(
        Try.of(lambda x, y: x + y, 2, 3), Try.of(lambda x, y: x + y, 2, 3).filter(lambda x: x == 5)
    )
    is_ok &= Assert.assert_equals(
        Try(TypeError(), False), Try.of(lambda x, y: x + y, 2, 3).filter(lambda x: x == 'Test')
    )

    # Test for not successful Try

# Generated at 2022-06-12 05:30:30.331861
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    m1 = Try(1, True)
    m2 = Try(2, True)
    m3 = Try(3, False)
    m4 = Try(4, False)

    def filterer(value):
        return value % 2 == 0

    assert m1.filter(filterer) == Try(1, False)
    assert m2.filter(filterer) == Try(2, True)
    assert m3.filter(filterer) == Try(3, False)
    assert m4.filter(filterer) == Try(4, False)



# Generated at 2022-06-12 05:30:35.602860
# Unit test for method filter of class Try
def test_Try_filter():
    def is_success(value):
        return True if value > 5 else False

    assert Try(4, True).filter(is_success) == Try(4, False)
    assert Try(6, True).filter(is_success) == Try(6, True)
    assert Try(4, False).filter(is_success) == Try(4, False)


# Generated at 2022-06-12 05:30:38.297606
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1)
    assert not Try.of(lambda: 1).filter(lambda x: x == 2)



# Generated at 2022-06-12 05:31:02.285996
# Unit test for method filter of class Try
def test_Try_filter():
    try:
        raise Exception('Some exception')
    except Exception as e:
        assert Try.of(lambda: 1+1).filter(lambda value: value == 2) == Try(2, True)
        assert Try.of(lambda: 1+1).filter(lambda value: value != 2) == Try(Exception('Some exception'), False)
        assert Try(e, False).filter(lambda value: value == 2) == Try(Exception('Some exception'), False)


# Generated at 2022-06-12 05:31:07.446510
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 10

    def filterer_false(value):
        return value == 20

    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(20, True).filter(filterer) == Try(20, False)
    assert Try(10, False).filter(filterer_false) == Try(10, False)


# Generated at 2022-06-12 05:31:10.408524
# Unit test for method filter of class Try
def test_Try_filter():
    value = 3
    try_ = Try(value, True)
    assert try_.filter(lambda v: v == value).get() == value
    assert try_.filter(lambda v: v == value * 2).is_success == False

# Generated at 2022-06-12 05:31:16.630095
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 2).filter(lambda x: x == 1) == Try(2, False)
    assert Try.of(lambda: 1/0).filter(lambda x: x == 1) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-12 05:31:23.188235
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value == 'foo'

    try_success = Try(value='foo', is_success=True)
    try_fail = Try(value='foo', is_success=False)
    try_success_wrong_value = Try(value='bar', is_success=True)

    assert try_success_wrong_value.filter(filterer) == Try(value='bar', is_success=False)
    assert try_success.filter(filterer) == Try(value='foo', is_success=True)
    assert try_fail.filter(filterer) == Try(value='foo', is_success=False)

# Generated at 2022-06-12 05:31:30.851911
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filter_with_value():
        name = 'Vasya'
        result = Try.of(lambda: name).filter(lambda name: name == 'Vasya')
        assert result == Try('Vasya', True)

    def test_filter_without_value():
        name = 'Petya'
        result = Try.of(lambda: name).filter(lambda name: name == 'Vasya')
        assert result == Try('Petya', False)

    test_filter_with_value()
    test_filter_without_value()
    print('Passed test_Try_filter')


# Generated at 2022-06-12 05:31:41.873421
# Unit test for method filter of class Try
def test_Try_filter():
    def make_happy():
        def happy():
            return random.choice([True, True, True, False])
        return Try.of(happy, None)

    def make_is_month_end():
        def is_month_end():
            t = datetime.datetime.today()
            return t.day == monthrange(t.year, t.month)[1]
        return Try.of(is_month_end, None)

    def make_balance():
        def balance():
            return random.randint(0, 1000) < 30
        return Try.of(balance, None)

    def make_transaction():
        def transaction():
            return random.randint(0, 1000)
        return Try.of(transaction, None)

    def to_pay(transaction):
        return transaction + 20


# Generated at 2022-06-12 05:31:53.298235
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def _test_filtering(expected, try_, filterer):
        assert expected == try_.filter(filterer).is_success

    _test_filtering(True, Try((lambda: True)(), True), lambda value: value)
    _test_filtering(False, Try((lambda: False)(), True), lambda value: value)
    _test_filtering(True, Try((lambda: True)(), False), lambda value: value)
    _test_filtering(False, Try((lambda: False)(), False), lambda value: value)

    _test_filtering(True, Try((lambda: True)(), True), lambda value: value)
    _test_filtering(False, Try((lambda: True)(), True), lambda value: not value)

# Generated at 2022-06-12 05:32:04.420450
# Unit test for method filter of class Try
def test_Try_filter(): # pragma: no cover
    """
    Test for method filter of class Try.
    """
    assert Try.of(lambda x: x, 'value').filter(lambda x: True) == Try('value', True)
    assert Try.of(lambda x: x, 'value').filter(lambda x: False) == Try('value', False)
    assert Try.of(lambda x: x, 'value').filter(lambda x: x == 'value') == Try('value', True)
    assert Try.of(lambda x: x, 'value').filter(lambda x: x != 'value') == Try('value', False)

    assert Try.of(lambda: 1/0, 'value').filter(lambda x: True) == Try('value', False)

# Generated at 2022-06-12 05:32:11.838808
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x * 2, 2).filter(lambda x: x > 4) == Try(4, False)
    assert Try.of(lambda x: x * 2, 2).filter(lambda x: x < 4) == Try(4, True)
    assert Try.of(type, 'string').filter(lambda x: x is str) == Try(str, True)
    assert Try.of(type, 'string').filter(lambda x: x is not str) == Try(str, False)



# Generated at 2022-06-12 05:32:52.758903
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(a):
        return a > 5
    assert Try.of(lambda: 7).filter(filterer) == Try.of(lambda: 7)
    assert Try.of(lambda: 4).filter(filterer) == Try(None, False)

# Generated at 2022-06-12 05:33:04.353092
# Unit test for method filter of class Try
def test_Try_filter():
    positive_numbers_filter = lambda x: x >= 0
    negative_numbers_filter = lambda x: x < 0

    # positive number
    assert(
        Try.of(lambda: 4).filter(positive_numbers_filter)
        == Try(4, True)
    )

    # negative number
    assert(
        Try.of(lambda: -4).filter(positive_numbers_filter)
        == Try(-4, False)
    )

    # positive number(exception)
    assert(
        Try.of(lambda: raise_error, 'positive').filter(positive_numbers_filter)
        == Try('positive', False)
    )

    # negative number(exception)

# Generated at 2022-06-12 05:33:13.472345
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, False).filter(lambda _: True) == Try(None, False)
    assert Try(3, True).filter(lambda x: True) == Try(3, True)
    assert Try('a', True).filter(lambda x: x == 'a') == Try('a', True)
    assert Try('a', True).filter(lambda x: x == 'b') == Try('a', False)
    assert Try('a', True).filter(lambda x: True).filter(lambda x: True) == Try('a', True)

# Generated at 2022-06-12 05:33:18.779266
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) \
                       .filter(lambda x: x != 2) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(Exception(), False).filter(lambda x: x == 1) == Try(Exception(), False)


# Generated at 2022-06-12 05:33:25.649564
# Unit test for method filter of class Try
def test_Try_filter():
    """
    cover method filter of class Try
    """
    # pylint: disable=W0105
    assert Try(10, True).filter(lambda x: x < 20) == Try(10, True)
    assert Try(10, True).filter(lambda x: x < 5) == Try(10, False)
    assert Try(Exception("exception"), False).filter(lambda x: x < 5) == Try(Exception("exception"), False)


# Generated at 2022-06-12 05:33:29.260621
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try(42, True).filter(lambda v: v % 2 == 0)
    expected = Try(42, True)

    assert result == expected


# Generated at 2022-06-12 05:33:34.219025
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x != 1) == Try(1, False)


# Generated at 2022-06-12 05:33:38.653367
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of Try class

    test_Try_filter: Try[A] -> Void
    """
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-12 05:33:48.042744
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Method filter of class Try returns Try with same value when monad is successfully
    and filterer return True, othercase not successfully Try with same value.
    """
    def filterer(value):
        """
        Return True when value is divisible by 2.

        :params value: number
        :type value: Number
        :returns: True when number is divisible by 2.
        :rtype: Boolean
        """
        return value % 2 == 0

    assert Try(2, True).filter(filterer) == Try(2, True)
    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(Exception('fail'), False).filter(filterer) == Try(Exception('fail'), False)