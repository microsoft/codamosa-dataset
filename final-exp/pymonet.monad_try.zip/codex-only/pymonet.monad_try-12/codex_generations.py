

# Generated at 2022-06-24 00:18:53.017304
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try
    """
    assert Try('123', True) == Try('123', True)
    assert Try('123', True) != Try('456', True)
    assert Try('123', True) != Try('123', False)
    assert Try(None, True) == Try(None, True)
    assert Try(None, True) != Try('123', True)
    assert Try(None, True) != Try(None, False)
    assert Try('123', False) == Try('123', False)
    assert Try('123', False) != Try('456', False)
    assert Try('123', False) != Try('123', True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, False) != Try('123', False)

# Generated at 2022-06-24 00:18:55.366584
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    print('\nTest constructor of class Try')
    assert Try(10, True) == Try(10, True)


# Generated at 2022-06-24 00:18:58.428190
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_a = Try(2, True)
    assert try_a.get_or_else(1) == 2
    try_b = Try(2, False)
    assert try_b.get_or_else(1) == 1


# Generated at 2022-06-24 00:19:05.007754
# Unit test for method map of class Try
def test_Try_map():
    """
    Test cases for method map of class Try.
    """
    # success
    assert Try(None, True).map(lambda x: x + 1) == Try(None, True)
    assert Try(10, True).map(lambda x: x + 1) == Try(11, True)
    assert Try(20, True).map(lambda x: x + 1) == Try(21, True)
    assert Try({}, True).map(lambda x: x) == Try({}, True)
    # fail
    assert Try(None, False).map(lambda x: x + 1) == Try(None, False)
    assert Try(10, False).map(lambda x: x + 1) == Try(10, False)
    assert Try(20, False).map(lambda x: x + 1) == Try(20, False)
    assert Try

# Generated at 2022-06-24 00:19:10.386316
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Test for method on_success of class Try.
    """
    returned_value = [None]
    def success_callback(value):
        returned_value[0] = value

    def fail_callback(value):
        raise value

    def f():
        return "success"

    def f_fail():
        raise ValueError()

    Try.of(f).on_success(success_callback)
    assert returned_value[0] == 'success'
    Try.of(f_fail).on_fail(fail_callback)
    Try.of(f_fail).on_success(success_callback)
    assert returned_value[0] == 'success'


# Generated at 2022-06-24 00:19:18.860694
# Unit test for method bind of class Try
def test_Try_bind():
    def add(a: int, b: int) -> Try[int]:
        return Try.of(lambda: a + b)
    assert add(2, 3) == Try(5, True)
    assert add(2, 'a') == Try(TypeError, False)
    assert Try(5, True).bind(add)(7) == Try(12, True)
    assert Try(5, True).bind(add)('a') == Try(TypeError, False)
    assert add(2, 'a').bind(add)(7) == Try(TypeError, False)


# Generated at 2022-06-24 00:19:23.547758
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(12, True) == Try(12, True)
    assert Try('asd', False) == Try('asd', False)
    assert Try(12, True) != Try(12, False)
    assert Try('asd', False) != Try('asd', True)
    assert Try(12, True) != Try('asd', True)
    assert Try('asd', False) != Try(12, False)



# Generated at 2022-06-24 00:19:27.396169
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_1 = Try("value", True)
    assert_that(try_1.get_or_else("default"), equal_to("value"))

    try_2 = Try("value", False)
    assert_that(try_2.get_or_else("default"), equal_to("default"))


# Generated at 2022-06-24 00:19:31.562534
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    print('testing Try')
    assert Try(0, True) == Try(0, True)
    assert Try('', False) == Try('', False)
    assert Try(10, True) != Try(10, False)



# Generated at 2022-06-24 00:19:38.131329
# Unit test for method map of class Try
def test_Try_map():
    assert(Try.of(lambda: 1).map(lambda v: v + 1) == Try(2, True))
    assert(Try.of(lambda: 1).map(lambda x: 1 / x).map(lambda x: x + 1) == Try(2, True))
    assert(Try.of(lambda: 1).map(lambda x: 1 / x).map(lambda x: x + 1) == Try(2, True))
    assert(Try.of(lambda: 1).map(lambda x: 1 / x)\
        .map(lambda x: 1 / x).map(lambda x: 1 / x).map(lambda x: 1 / x)\
        .map(lambda x: x + 1) == Try(2, True))

# Generated at 2022-06-24 00:19:40.731842
# Unit test for method on_success of class Try
def test_Try_on_success():
    def on_success(value):
        on_success.called = True
        assert value == 'value'

    on_success.called = False
    Try('value', True).on_success(on_success)

    assert on_success.called


# Generated at 2022-06-24 00:19:43.469843
# Unit test for method get of class Try
def test_Try_get():
    assert Try(42, True).get() == 42
    assert Try(42, False).get() == 42


# Generated at 2022-06-24 00:19:52.220539
# Unit test for method on_success of class Try
def test_Try_on_success():
    def print_if_success(obj):
        if isinstance(obj, Try):
            print(obj.value)

    def throw_test_exception():
        raise Exception('test')

    @try_
    def foo(x, y):
        if int(x) == 0:
            return 0
        return x / y

    foo(0, 2).on_success(print_if_success)
    foo(1, 0).on_success(print_if_success)
    foo(1, 2).on_success(print_if_success)
    foo(0, 'a').on_success(print_if_success)
    foo(1, 'a').on_success(print_if_success)
    foo('a', 1).on_success(print_if_success)
    foo('a', 'a').on

# Generated at 2022-06-24 00:19:55.155292
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try0 = Try('a', True)
    try1 = Try('a', True)
    try2 = Try('a', False)
    try3 = Try('b', True)
    assert try0 == try1
    assert not try0 == try2
    assert not try0 == try3


# Generated at 2022-06-24 00:19:59.428800
# Unit test for constructor of class Try
def test_Try():
    t = Try(12, True)
    assert t.value == 12
    assert t.is_success
    assert Try(12, True) == t
    assert Try(12, True) != Try(12, False)



# Generated at 2022-06-24 00:20:04.104051
# Unit test for method map of class Try
def test_Try_map():
    def function(a):
        return a * 2
    try1 = Try.of(lambda: 2)
    try2 = try1.map(function)
    assert try2.get() == 4
    assert try2.is_success is True
    assert try2 == Try(4, True)



# Generated at 2022-06-24 00:20:12.135522
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    """
    Test filter method of Try class.

    :returns: nothing
    :rtype: None
    """
    try_value = Try(5, True)
    try_value_less_than_10 = Try(5, True).filter(lambda x: x < 10)
    try_value_more_than_10 = Try(5, True).filter(lambda x: x > 10)

    assert try_value == try_value_less_than_10
    assert try_value.is_success
    assert not try_value_more_than_10.is_success

    try_value = Try(15, True)
    try_value_less_than_10 = Try(15, True).filter(lambda x: x < 10)

# Generated at 2022-06-24 00:20:14.554155
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(0, True)) == 'Try[value=0, is_success=True]'
    assert str(Try(0, False)) == 'Try[value=0, is_success=False]'


# Generated at 2022-06-24 00:20:19.121783
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5
    assert Try('value', True).get() == 'value'


# Generated at 2022-06-24 00:20:25.152423
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, False) == Try(2, False)
    assert not Try(1, True) == Try(2, False)
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-24 00:20:26.837181
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x)) == Try(1, True)
    assert Try(1, False).on_success(lambda x: print(x)) == Try(1, False)


# Generated at 2022-06-24 00:20:29.148216
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_fn(a):
        assert a == 1
        return a

    t = Try.of(test_fn, 1)
    t.on_success(test_fn)



# Generated at 2022-06-24 00:20:40.526701
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda v: Try(v + 1, True)) == Try(2, True)
    assert Try(1, True).bind(lambda v: Try(v + 1, False)) == Try(2, False)

    assert Try(1, True).bind(lambda v: Try(v + 1, True)).bind(lambda v: Try(v + 1, True)) == Try(3, True)
    assert Try(1, True).bind(lambda v: Try(v + 1, True)).bind(lambda v: Try(v + 1, False)) == Try(3, False)

    assert Try(1, False).bind(lambda v: Try(v + 1, True)) == Try(1, False)
    assert Try(1, False).bind(lambda v: Try(v + 1, False)) == Try(1, False)

# Generated at 2022-06-24 00:20:42.897410
# Unit test for method get of class Try
def test_Try_get():
    """
    Test method Try.get().

    :returns: None
    :rtype: None
    """
    assert(Try(12, True).get() == 12)


# Generated at 2022-06-24 00:20:44.474315
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:20:45.952558
# Unit test for method get of class Try
def test_Try_get():
    value = Try(42, True).get()
    assert value == 42
    assert value is not None


# Generated at 2022-06-24 00:20:53.946178
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    def add(a, b): return a + b
    s = Try(add, 1, 2)
    assert Try(add, 1, 2) == Try(add, 1, 2)
    assert Try(add, 1, 2) != Try(add, 1, 3)
    assert Try(add, 1, 2) != Try(add, 2, 2)

    def add(a, b): return a + b
    def err(a, b): return a / 0
    assert Try(err, 1, 2) != Try(add, 1, 2)
    assert Try(add, 1, 2) != Try(err, 1, 2)

    assert Try(add, 1, 2) != Try(add, 1, 2).map(lambda x: x)

# Generated at 2022-06-24 00:20:59.980096
# Unit test for constructor of class Try
def test_Try():
    assert Try('a', True) == Try('a', True)
    assert Try('a', False) == Try('a', False)
    assert Try('a', True) != Try('b', True)
    assert Try('a', False) != Try('b', False)
    assert Try('a', True) != Try('a', False)
    assert Try('b', False) != Try('a', True)


# Generated at 2022-06-24 00:21:02.863847
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(None, False).get_or_else(0) == 0



# Generated at 2022-06-24 00:21:07.873229
# Unit test for method __str__ of class Try
def test_Try___str__():
    # given
    try_ = Try(2, True)
    # when
    actual = try_.__str__()
    # then
    assert actual == 'Try[value=2, is_success=True]'


# Generated at 2022-06-24 00:21:19.608113
# Unit test for method bind of class Try
def test_Try_bind():
    def add(value):
        return Try.of(lambda: value + 2)

    def mul(value):
        return Try.of(lambda: value * 3)

    def eq(value):
        return Try.of(lambda: value == 8)

    assert Try.of(1).bind(add).bind(mul).bind(eq) == Try(False, True)
    assert Try.of(1).bind(add).bind(mul).bind(eq).is_success is True
    assert Try.of(1).bind(add).bind(mul).bind(eq).value is False
    assert Try.of(2).bind(add).bind(mul).bind(eq) == Try(True, True)
    assert Try.of(2).bind(add).bind(mul).bind(eq).is_success is True

# Generated at 2022-06-24 00:21:23.452791
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda: 1, None).get_or_else('a') == 1
    assert Try.of(lambda: 1 / 0, None).get_or_else('a') == 'a'



# Generated at 2022-06-24 00:21:32.590590
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(42, True)) == 'Try[value=42, is_success=True]'
    assert 'Try[value=42, is_success=True]' != 'Try[value=43, is_success=True]'
    assert str(Try(42, False)) == 'Try[value=42, is_success=False]'
    assert 'Try[value=42, is_success=False]' != 'Try[value=43, is_success=False]'



# Generated at 2022-06-24 00:21:35.450317
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    a = Try.of(lambda: 1)
    b = Try.of(lambda: 1/0)
    assert a.get_or_else(0) == 1
    assert b.get_or_else(0) == 0


# Generated at 2022-06-24 00:21:40.895520
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    monad = Try.of(lambda: 1/0)
    assert monad.get_or_else(0) == 0
    monad = Try.of(lambda: 1 + 1)
    assert monad.get_or_else(0) == 2


# Generated at 2022-06-24 00:21:46.979236
# Unit test for constructor of class Try
def test_Try():
    assert(Try('a', True) == Try('a', True))
    assert(Try(1, True) == Try(1, True))
    assert(Try(None, True) == Try(None, True))
    assert(Try(1, False) == Try(1, False))
    assert(Try('a', False) == Try('a', False))
    assert(Try(None, False) == Try(None, False))
    assert(Try('a', True) != Try('a', False))
    assert(Try(1, True) != Try(1, False))


# Generated at 2022-06-24 00:21:48.388035
# Unit test for method get of class Try
def test_Try_get():
    value = 1
    assert Try(value, True).get() == value



# Generated at 2022-06-24 00:21:52.483082
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:21:57.047024
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-24 00:22:01.185376
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v == 1) == Try(1, True)
    assert Try(1, True).filter(lambda v: v == 2) == Try(1, False)
    assert Try(None, False).filter(lambda v: True) == Try(None, False)

# Generated at 2022-06-24 00:22:05.897139
# Unit test for method map of class Try
def test_Try_map():
    assert Try(5, True).map(lambda x: x + 1) == Try(6, True)
    assert Try(2, True).map(lambda x: x * 2) == Try(4, True)

    assert Try(2, True).map(lambda x: x / 0) == Try(ZeroDivisionError, False)

    assert Try(3, False).map(lambda x: x / 2) == Try(3, False)
    assert Try(4, False).map(lambda x: x * 2) == Try(4, False)



# Generated at 2022-06-24 00:22:16.602203
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1, ).bind(lambda x: Try(x, True)) == Try(1, True)
    assert Try.of(lambda: 1, ).bind(lambda x: Try('error', False)) == Try(1, True)
    assert Try.of(lambda: 1, ).bind(lambda x: Try(x, False)) == Try(1, True)
    assert Try.of(lambda: 1 / 0, ).bind(lambda x: Try('error', False)) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0, ).bind(lambda x: Try(x, True)) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0, ).bind(lambda x: Try(x, False)) == Try(ZeroDivisionError(), False)


# Unit test

# Generated at 2022-06-24 00:22:19.445286
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    class Error(Exception): pass

    def method():
        pass
        raise Error()

    try_monad = Try.of(method)


# Generated at 2022-06-24 00:22:21.390731
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(123, True)) == 'Try[value=123, is_success=True]'
    assert str(Try(321, False)) == 'Try[value=321, is_success=False]'


# Generated at 2022-06-24 00:22:27.920036
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Unit test for method on_fail of class Try
    """

# Generated at 2022-06-24 00:22:29.072303
# Unit test for constructor of class Try
def test_Try():
    assert Try(5, True) == Try(5, True)



# Generated at 2022-06-24 00:22:35.054653
# Unit test for constructor of class Try
def test_Try():
    """
    Unit test for constructor of class Try

    :returns: None
    :rtype: None
    """
    try_ = Try(42, True)
    assert(try_.value == 42)
    assert(try_.is_success == True)



# Generated at 2022-06-24 00:22:40.920373
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = 1
    fn = lambda x: x + 1
    result = Try.of(fn, value).on_success(lambda x: print(x))
    expected = Try(2, True)
    assert result == expected



# Generated at 2022-06-24 00:22:46.297243
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try.of(lambda x: x, 1)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-24 00:22:48.129133
# Unit test for constructor of class Try
def test_Try():
    assert Try(7, True) == Try(7, True)


# Generated at 2022-06-24 00:22:49.449200
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1

    assert Try(None, False).get_or_else(1) == 1

# Generated at 2022-06-24 00:22:53.840204
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    class MyException(Exception):
        pass


# Generated at 2022-06-24 00:22:57.443162
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test on_fail method of Try monad

    :returns: result of test
    :rtype: Boolean
    """
    def fail_callback(error):
        assert error == 'ERROR'

    def success_callback(value):
        assert False

    Try(None, False).on_fail(fail_callback).on_success(success_callback)
    return True

# Generated at 2022-06-24 00:22:59.894527
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    a = Try(5, True)
    b = Try(5, True)
    c = Try(5, False)
    assert a == b
    assert not a == c
    assert not a == 0


# Generated at 2022-06-24 00:23:02.911999
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        assert value

    def fail_callback(value):
        assert not value

    assert Try(True, True).on_success(success_callback).is_success
    assert Try(False, False).on_fail(fail_callback).is_success is False



# Generated at 2022-06-24 00:23:04.590135
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:23:10.297656
# Unit test for method map of class Try
def test_Try_map():
    x = Try.of(lambda: 10)
    assert x == Try(10, True)
    assert x.map(lambda x: x ** 2) == Try(100, True)



# Generated at 2022-06-24 00:23:18.401756
# Unit test for method map of class Try
def test_Try_map():
    def test_function(value):
        return Try.of(lambda v: v ** 2, value)

    assert Try(1, True).map(lambda value: value ** 2) == Try(1, True).bind(test_function)
    assert Try(1, True).map(lambda value: value ** 2) == Try(1, True).bind(test_function)

    assert Try(1, True).map(lambda value: value ** 2) == Try(1, True)
    assert Try(1, True).map(lambda value: value ** 2) != Try(1, False)
    assert Try(1, True).map(lambda value: value ** 2) != Try(2, True)
    assert Try(1, True).map(lambda value: value ** 2) != Try(4, False)


# Generated at 2022-06-24 00:23:24.880829
# Unit test for method filter of class Try
def test_Try_filter():
    def is_positive(x):
        return x > 0
    def is_negative(x):
        return x < 0

    negative = Try(1, True).filter(is_positive)
    assert negative.is_success
    assert negative.get() == 1

    positive = Try(1, True).filter(is_negative)
    assert not positive.is_success
    assert positive.get() == 1

    positive = Try(-1, True).filter(is_negative)
    assert positive.is_success
    assert positive.get() == -1

# Generated at 2022-06-24 00:23:26.711499
# Unit test for method __str__ of class Try
def test_Try___str__():
    val = Try(1, True)
    assert 'Try[value=1, is_success=True]' == str(val)


# Generated at 2022-06-24 00:23:35.071160
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try.
    """

    def add(x, y):
        return x + y

    assert Try.of(add, 5, 5).get_or_else(0) == 10

    assert Try.of(add, 5, '5').get_or_else(0) == 0
    assert Try.of(add, 5, '5').get_or_else(0) == 0

    assert Try.of(add, 5, 5).get_or_else(-1) == 10
    assert Try.of(add, 5, '5').get_or_else(-1) == -1



# Generated at 2022-06-24 00:23:42.144553
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test Try.on_fail method.
    """
    assert Try('success', True).on_fail(lambda _: None) == Try('success', True)
    assert Try('fail', False).on_fail(lambda _: None) == Try('fail', False)
    assert Try('fail', False).on_fail(lambda e: print(e)) == Try('fail', False)



# Generated at 2022-06-24 00:23:46.565717
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: None) == Try(1, True)
    assert Try(1, False).on_fail(lambda x: None) == Try(1, False)


# Generated at 2022-06-24 00:23:52.754276
# Unit test for constructor of class Try
def test_Try():
    value = 5
    is_success = True
    try_monad = Try(value, is_success)
    assert try_monad.value == value
    assert try_monad.is_success == is_success
    assert try_monad == Try(value, is_success)


# Generated at 2022-06-24 00:23:56.370041
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:23:57.800363
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-24 00:24:03.109371
# Unit test for method bind of class Try
def test_Try_bind():
    def _binder(value):
        print('in binder with value = {}'.format(value))
        return Try(value, True)

    assert Try.of(lambda: 'value', ).bind(_binder) == Try('value', True)
    assert Try.of(lambda: 1/0, ).bind(_binder) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:24:06.594133
# Unit test for method map of class Try
def test_Try_map():
    def mapper(x):
        return x * 2

    assert Try(1, True).map(mapper) == Try(2, True)
    assert Try(Exception('test'), False).map(mapper) == Try(Exception('test'), False)



# Generated at 2022-06-24 00:24:09.980230
# Unit test for method get of class Try
def test_Try_get():
    with pytest.raises(AttributeError):
        Try(5, True).get()
        Try(5, False).get()


# Generated at 2022-06-24 00:24:14.935633
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Tests for Try.bind method.
    """
    def test1():
        """
        Successfully call function.
        """
        def mapper(x):
            return x + 1
        assert Try.of(mapper, 1) == Try(2, True)

    def test2():
        """
        Failure call function.
        """
        def mapper(x):
            raise TypeError('abc')
        assert Try.of(mapper, 1) == Try(TypeError('abc'), False)

    test1()
    test2()



# Generated at 2022-06-24 00:24:20.431765
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)


# Generated at 2022-06-24 00:24:23.061681
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:24:27.995131
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1, None).get_or_else(0) == 1
    assert Try.of(lambda: None, None).get_or_else(0) == 0
    assert Try.of(lambda: 1 / 0, None).get_or_else(0) == 0


# Generated at 2022-06-24 00:24:37.195395
# Unit test for method get of class Try
def test_Try_get():
    a = 1
    assert a == Try.of(lambda a: a, a).get()
    assert a == Try.of(lambda a: a, a).filter(lambda a: a == a).get()
    assert a == Try.of(lambda a: a, a).filter(lambda a: a == a).filter(lambda a: a == a).get()
    assert a == Try.of(lambda a: a, a).filter(lambda a: a == a).filter(lambda a: a == a).filter(lambda a: a == a).get()
    assert a == Try.of(lambda a: a, a).filter(lambda a: a == a).filter(lambda a: a == a).filter(lambda a: a == a).filter(lambda a: a == a).get()

# Generated at 2022-06-24 00:24:42.465747
# Unit test for constructor of class Try
def test_Try():
    tryVal = Try(6, True)
    assert tryVal.get() == 6
    assert tryVal.is_success == True

    tryVal2 = Try(6, False)
    assert tryVal2.get() == 6
    assert tryVal2.is_success == False


# Generated at 2022-06-24 00:24:46.973289
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda i: i == 2)\
        == Try(2, True)

    assert Try(2, True).filter(lambda i: i > 2)\
        == Try(2, False)

    assert Try(Exception(), False).filter(lambda i: i == 2)\
        == Try(Exception(), False)



# Generated at 2022-06-24 00:24:50.554231
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Given
    value = 1
    is_success = True

    # When
    try_a = Try(value, is_success)
    try_b = Try(value, is_success)

    # Then
    assert try_a == try_b, "Should be equal"



# Generated at 2022-06-24 00:24:56.735182
# Unit test for method map of class Try
def test_Try_map():
    assert Try(4, True).map(lambda x: x * 2) == Try(8, True)
    assert Try(4, False).map(lambda x: x * 2) == Try(4, False)

    def raise_exception(x):
        raise Exception('test')

    assert Try(4, False) == Try(4, False).map(raise_exception)
    assert Try(4, True) != Try(4, True).map(raise_exception)



# Generated at 2022-06-24 00:25:05.605203
# Unit test for method bind of class Try
def test_Try_bind():
    def sum_five(x):
        return Try(x + 5, True)
    # Try(5, True).bind(sum_five) = Try(10, True)
    assert Try(5, True).bind(sum_five) == Try(10, True)
    assert Try(5, True).bind(sum_five) != Try(10, False)
    assert Try(5, True).bind(sum_five) != Try(5, True)
    # Try(-5, False).bind(sum_five) = Try(-5, False)
    assert Try(-5, False).bind(sum_five) == Try(-5, False)
    assert Try(-5, False).bind(sum_five) != Try(-10, False)
    assert Try(-5, False).bind(sum_five) != Try(-5, True)

# Unit

# Generated at 2022-06-24 00:25:11.200835
# Unit test for method on_success of class Try
def test_Try_on_success():
    def _success_callback(value):
        assert value == 'some_value'

    def _fail_callback(value):
        assert False

    Try('some_value', True).on_success(_success_callback).on_fail(_fail_callback)
    Try(RuntimeError(), False).on_success(_fail_callback).on_fail(_success_callback)
# End unit test


# Generated at 2022-06-24 00:25:20.048530
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(5, True).on_success(lambda x: x + 1) == Try(5, True)
    assert Try(5, True).on_success(lambda x: x + 1).get() == 6
    assert Try(RuntimeError('test'), False).on_success(lambda x: x + 1) == Try(RuntimeError('test'), False)
    assert Try(RuntimeError('test'), False).on_success(lambda x: x + 1).get() == RuntimeError('test')


# Generated at 2022-06-24 00:25:25.350292
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_callback(value):
        assert value == 'test'
    Try.of(lambda x: 'test', True).on_success(test_callback)
    assert Try.of(lambda x: 'test', True).on_success(test_callback) == Try.of(lambda x: 'test', True)


# Generated at 2022-06-24 00:25:31.986732
# Unit test for method map of class Try
def test_Try_map():
    # given
    def fn1(n):
        return str(n)
    def fn2(n):
        raise Exception('error')
    try1 = Try.of(fn1, 1)
    try2 = Try.of(fn2, 1)

    # when
    result1 = try1.map(fn1)
    result2 = try2.map(fn1)

    # then
    print('Try.map: ', (result1 == Try('1', True)) and (result2 == Try(Exception('error'), False)))


# Generated at 2022-06-24 00:25:37.320373
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(0, True).on_fail(lambda x: x + 1) == Try(0, True)
    assert Try(None, False).on_fail(lambda x: x) == Try(None, False)
    assert Try(0, False).on_fail(lambda x: x + 1) == Try(1, False)



# Generated at 2022-06-24 00:25:39.710132
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-24 00:25:47.546223
# Unit test for method map of class Try
def test_Try_map():

    class A:
        pass
    a = A()

    class B:
        pass
    new_b = B()

    def mapper(x):
        assert x == a
        return new_b

    # 1. Successfully Try
    try_a = Try(a, True)
    try_b = try_a.map(mapper)
    assert try_b.is_success and try_b.value == new_b
    
    # 2. Not successfully Try
    try_a = Try(a, False)
    try_b = try_a.map(mapper)
    assert not try_b.is_success and try_b.value == a



# Generated at 2022-06-24 00:25:52.159813
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:26:01.227276
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    def fn():
        return 1234

    try1 = Try.of(fn)
    print(try1)
    try2 = Try.of(fn).map(lambda x: x * 2)
    print(try2)
    try3 = Try.of(fn).bind(lambda x: Try.of(fn).map(lambda y: x * y))
    print(try3)
    try4 = Try.of(fn).bind(lambda x: Try.of(fn)
                           .filter(lambda y: y == 1234).map(lambda z: x * z))
    print(try4)
    try5 = Try.of(fn).bind(lambda x: Try.of(fn).filter(lambda y: y == 12)
                           .map(lambda z: x * z))

# Generated at 2022-06-24 00:26:03.923446
# Unit test for method get of class Try
def test_Try_get():
    half_of_number = lambda n: n/2
    Success(10).map(half_of_number).get() == 5


# Generated at 2022-06-24 00:26:09.419809
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(7, True).get_or_else(0) == 7
    assert Try(7, False).get_or_else(0) == 0
    assert Try('', False).get_or_else('default') == 'default'
    assert Try(None, False).get_or_else('default') == 'default'


# Generated at 2022-06-24 00:26:13.365238
# Unit test for method map of class Try
def test_Try_map():
    assert Try(10, True).map(lambda x: x + 10) == Try(20, True)
    assert Try(None, True).map(lambda x: x + 10) == Try(None, True)
    assert Try('error', False).map(lambda x: x + 10) == Try('error', False)


# Generated at 2022-06-24 00:26:20.071082
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def greater_than_zero(x):
        return x > 0

    def throw_exception():
        raise Exception('Failure')

    def is_not_zero(x):
        return x != 0

    def is_empty(x):
        return not x

    assert Try.of(throw_exception).filter(greater_than_zero) == Try(Exception('Failure'), False)
    assert Try.of(throw_exception).filter(greater_than_zero) != Try(Exception('Failure'), True)

    assert Try.of(lambda: 11).filter(greater_than_zero) == Try(11, True)
    assert Try.of(lambda: 11).filter(greater_than_zero) != Try(11, False)


# Generated at 2022-06-24 00:26:25.194999
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_with_value = Try(2, True)
    try_without_value = Try(None, False)
    list_with_values = []

    # call method on_success from class Try with function store_two_times_value
    # when monad is successfully
    try_with_value.on_success(store_two_times_value(list_with_values))

    # call method on_success from class Try with function store_two_times_value
    # when monad is not successfully
    try_without_value.on_success(store_two_times_value(list_with_values))

    assert list_with_values == [4]



# Generated at 2022-06-24 00:26:27.072828
# Unit test for method __str__ of class Try
def test_Try___str__():
    ex = Exception('error')
    try1 = Try(1, True)
    try2 = Try(ex, False)

    assert str(try1) == 'Try[value=1, is_success=True]'
    assert str(try2) == 'Try[value=Exception("error"), is_success=False]'


# Generated at 2022-06-24 00:26:37.109795
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer1(n):
        return n == 1
    def filterer2(n):
        return n != 1
    def filterer3(n):
        raise Exception('error')

    try_1 = Try(1, True)
    try_2 = Try(2, True)

    assert (try_1.filter(filterer1) == Try(1, True))
    assert (try_1.filter(filterer2) == Try(1, False))
    assert (try_1.filter(filterer3) == Try(1, False))
    assert (try_2.filter(filterer1) == Try(2, False))
    assert (try_2.filter(filterer2) == Try(2, True))

# Generated at 2022-06-24 00:26:39.099930
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(2, True) == Try(2, True)
    assert Try(Exception, False) == Try(Exception, False)


# Generated at 2022-06-24 00:26:42.861143
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_handler(e):
        raise Exception('Exception occured: {}'.format(e))

    assert Try(1, True).on_fail(fail_handler) == Try(1, True)
    assert Try('Exception', False).on_fail(fail_handler) == Try('Exception', False)



# Generated at 2022-06-24 00:26:51.230259
# Unit test for method map of class Try
def test_Try_map():
    t1 = Try(1, True)
    t2 = Try(2, True)
    t3 = Try(3, True)
    t4 = Try(4, False)

    fail_function = lambda x: x / 0

    def map_function(x):
        if x == 1:
            return fail_function(x)
        return x + 1
    assert t1.map(map_function) == Try(1, False)
    assert t2.map(map_function) == Try(3, True)
    assert t3.map(map_function) == Try(4, True)
    assert t4.map(map_function) == Try(4, False)



# Generated at 2022-06-24 00:26:53.686680
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert 'Try[value={}, is_success={}]'.format('foo', True) == Try('foo', True).__str__()


# Generated at 2022-06-24 00:26:56.978681
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:26:58.459622
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(42, True)) == "Try[value=42, is_success=True]"

# Generated at 2022-06-24 00:27:01.519690
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(int, '3').get() == 3
    assert Try.of(int, 'not number').get() == 'not number'


# Generated at 2022-06-24 00:27:04.541086
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Given
    def assert_fun(e):
        assert e == exception
    exception = Exception('This is test exception')
    try_monad = Try(0, False)

    # When
    try_monad.on_fail(assert_fun)

    # Then
    assert try_monad.is_success == False


# Generated at 2022-06-24 00:27:05.949754
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-24 00:27:13.489535
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1, ).map(lambda x: x + 1)\
               == Try(2, True)
    assert Try.of(lambda: 'a', ).map(lambda x: x + 'b')\
               == Try('ab', True)
    assert Try.of(lambda: 'a', ).map(lambda _: raise_exception('a')).is_success == False
    assert Try.of(lambda: 'a', ).map(lambda _: raise_exception('a')) == Try(raise_exception('a'), False)


# Generated at 2022-06-24 00:27:18.919701
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_function(value):
        assert value == 1

    Try.of(lambda: 1, None).on_success(test_function)



# Generated at 2022-06-24 00:27:22.249396
# Unit test for method get of class Try
def test_Try_get():
    f = lambda x, y: x + y
    t = Try.of(f, 1, 2)
    assert t.get() == 3

    # test get on fail
    f = lambda x, y: x / y
    t = Try.of(f, 1, 0)
    assert t.get() == ZeroDivisionError


# Generated at 2022-06-24 00:27:29.150859
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda v: None) == Try(1, True)
    assert Try(1, False).on_fail(lambda v: None) == Try(1, False)
    x = []
    assert Try(1, True).on_fail(lambda v: x.append(v)) == Try(1, True)
    assert x == []
    assert Try(1, False).on_fail(lambda v: x.append(v)) == Try(1, False)
    assert x == [1]



# Generated at 2022-06-24 00:27:31.110359
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """Unit test for method on_fail of class Try.
    """


# Generated at 2022-06-24 00:27:33.435957
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, False) == Try(1, True)
    assert not Try(1, True) == 1
    assert not Try(1, True) == Try(2, True)


# Generated at 2022-06-24 00:27:38.696331
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception(), False) == Try(Exception(), False)
    assert Try(1, True) != Try(1, False)
    assert Try(Exception(), True) != Try(Exception(), False)


# Generated at 2022-06-24 00:27:44.201316
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(x):  # pylint: disable=W0613
        success_callback.called = True

    success_callback.called = False

    assert Try(0, True).on_success(success_callback).get() == 0
    assert success_callback.called


# Generated at 2022-06-24 00:27:51.383115
# Unit test for method bind of class Try
def test_Try_bind():
    def fn_mapper(value):
        return value + 1

    def fn_binder(value):
        return Try(value + 5, True)

    try1 = Try(5, True)
    try2 = Try(5, False)

    assert try1.bind(fn_binder) == Try(10, True)
    assert try2.bind(fn_binder) == Try(5, False)


# Generated at 2022-06-24 00:27:58.764922
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) is not Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) != Try(2, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:27:59.745377
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(42, True)) == 'Try[value=42, is_success=True]'



# Generated at 2022-06-24 00:28:03.253682
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception('test'), False)) == 'Try[value=test, is_success=False]'


# Generated at 2022-06-24 00:28:10.606737
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda v: v) == Try(1, True)
    assert Try(1, True).on_fail(lambda v: v) == Try(1, True)
    assert Try(Exception(), False).on_fail(lambda v: v) == Try(Exception(), False)
    assert Try(Exception(), False).on_fail(lambda v: v) == Try(Exception(), False)


# Generated at 2022-06-24 00:28:14.416485
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    t = Try.of(lambda: 1 / 0)

    def fail_callback(e):
        raise e
    t.on_fail(fail_callback)

    try:
        t.get()
    except ZeroDivisionError:
        assert True
        return
    assert False



# Generated at 2022-06-24 00:28:18.020488
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda x: x, 1).on_fail(lambda x: x) == Try(1, True)
    assert Try.of(lambda x: raise_exception(x), 1).on_fail(lambda x: print(x)) == Try(Exception('test exception'), False)



# Generated at 2022-06-24 00:28:24.311748
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(None, True) == Try(None, True)
    assert not Try(None, False) == Try(None, True)
    assert not Try(Exception, False) == Try(None, False)
    assert Try(Exception, False) == Try(Exception, False)


# Generated at 2022-06-24 00:28:26.809147
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)
    assert Try(None, False) != Try(None, True)


# Generated at 2022-06-24 00:28:33.783821
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    a_def_val = 'foo'
    a_other_val = 'bar'
    assert Try.of(lambda: a_other_val).get_or_else(a_def_val) == a_other_val
    assert Try.of(lambda: int(a_other_val)).get_or_else(a_def_val) == a_def_val

# Generated at 2022-06-24 00:28:43.460454
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Arrange
    a_try = Try(10, True)
    b_try = Try(10, True)
    c_try = Try(20, True)
    d_try = Try(20, False)
    e_try = Try(10, False)
    f_try = Try(20, False)
    g_try = Try(None, False)

    # Action
    actual_1 = a_try == b_try
    actual_2 = a_try == c_try
    actual_3 = a_try == d_try
    actual_4 = a_try == e_try
    actual_5 = a_try == f_try
    actual_6 = a_try == g_try

    # Assert
    assert actual_1 is True
    assert actual_2 is False
    assert actual_3 is False