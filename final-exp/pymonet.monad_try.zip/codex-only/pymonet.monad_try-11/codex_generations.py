

# Generated at 2022-06-24 00:18:53.134005
# Unit test for method bind of class Try
def test_Try_bind():

    def validate_string(str):
        if len(str) > 0:
            return Try(str, True)
        return Try('Empty string', False)

    def exception_fn(str):
        raise Exception('Exception!')

    def exception_fn_with_args(str, arg):
        raise Exception('Exception!')

    def exception_fn_with_args_try(str, arg):
        return Try(str, True)


    # Success
    assert Try.of(validate_string, 'abc').map(lambda x: x + 'def').bind(validate_string) == Try('abcdef', True)
    # Fail
    assert Try.of(validate_string, '').map(lambda x: str(x) + 'def').bind(validate_string) == Try('Empty string', False)

    # Success


# Generated at 2022-06-24 00:18:54.711399
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(Exception('Some exception'), False).get() == Exception('Some exception')



# Generated at 2022-06-24 00:19:00.213835
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(number):
        return number % 2 == 0

    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(3, True).filter(is_even) == Try(3, False)
    assert Try('error', False).filter(is_even) == Try('error', False)



# Generated at 2022-06-24 00:19:03.839308
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)



# Generated at 2022-06-24 00:19:06.624342
# Unit test for method on_success of class Try
def test_Try_on_success():
    x = Try(2, True)
    y = Try(None, False)


# Generated at 2022-06-24 00:19:10.036576
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(42, True).filter(lambda x: x == 42) == Try(42, True)
    assert Try(42, True).filter(lambda x: x != 42) == Try(42, False)
    assert Try(42, False).filter(lambda x: x == 42) == Try(42, False)
    assert Try(42, False).filter(lambda x: x != 42) == Try(42, False)


# Generated at 2022-06-24 00:19:16.047832
# Unit test for method bind of class Try
def test_Try_bind():
    """Test for Try method bind."""
    #GIVEN
    test_monad_success = Try(1, True)
    test_monad_fail = Try(1, False)
    def binder(value):
        return Try(value + 1, True)

    #WHEN
    result_success = test_monad_success.bind(binder)
    result_fail = test_monad_fail.bind(binder)

    #THEN
    assert result_success == Try(2, True)
    assert result_fail == Try(1, False)


# Generated at 2022-06-24 00:19:25.956291
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test for method map of class Try.
    """
    def square(n):
        return n * n
    assert Try(1, True)\
        .map(square)\
        == Try(square(1), True)

    def square(n):
        return n * n
    assert Try(1, True)\
        .map(square)\
        .map(str)\
        == Try(str(square(1)), True)

    def square(n):
        raise Exception('error')
    assert Try(1, True)\
        .map(square)\
        == Try(1, True)

    assert Try(Exception('error'), False)\
        .map(square)\
        == Try(Exception('error'), False)



# Generated at 2022-06-24 00:19:31.197324
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    """
    Test for method on_success.
    """
    def f(x):
        assert x == 'Test'

    value = Try('Test', True)
    value.on_success(f)

    with pytest.raises(Exception):
        value = Try('Test', False)
        value.on_success(f)



# Generated at 2022-06-24 00:19:37.881693
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    assert Try(10, True).bind(lambda x: Try(x + 1, True)) == Try(11, True)
    assert Try(10, True).bind(lambda x: Try(x + 1, False)) == Try(11, False)
    assert Try(10, False).bind(lambda x: Try(x + 1, True)) == Try(10, False)
    assert Try(10, False).bind(lambda x: Try(x + 1, False)) == Try(10, False)
    assert Try.of(lambda: 10).bind(lambda x: Try(x + 1, True)) == Try(11, True)
    assert Try.of(lambda: 10).bind(lambda x: Try(x + 1, False)) == Try(11, False)

# Generated at 2022-06-24 00:19:41.013124
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(2, True).on_success(lambda x: x * 2) == Try(4, True)
    assert Try(2, True).on_success(lambda x: x / 0) == Try(2, True)
    assert Try(2, False).on_success(lambda x: x * 2) == Try(2, False)
    assert Try(2, False).on_success(lambda x: x / 0) == Try(2, False)



# Generated at 2022-06-24 00:19:42.561875
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-24 00:19:48.405688
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:19:50.230586
# Unit test for method get of class Try
def test_Try_get():
    """
    Test for method get of class Try.

    :returns: None
    :rtype: None
    """
    assert Try(5, True).get() == 5
    assert Try('value', False).get() == 'value'


# Generated at 2022-06-24 00:19:54.853085
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) != Try(None, True)
    assert Try(None, False) != Try('test', False)
    try:
        _ = Try(None, False) == None
        assert False, 'TypeError exception doesn\'t raised.'
    except TypeError:
        assert True


# Generated at 2022-06-24 00:20:01.819866
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    """
    The test_Try___str__ function returns:
    :rtype: None
    """
    try_success = Try(value=1, is_success=True)
    assert str(try_success) == 'Try[value=1, is_success=True]'
    try_fail = Try(value=1, is_success=False)
    assert str(try_fail) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:20:04.504047
# Unit test for method get of class Try
def test_Try_get():
    """
    Test method get of class Try.
    """
    assert Try(2, True).get() == 2
    assert Try(None, False).get() == None


# Generated at 2022-06-24 00:20:08.669579
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-24 00:20:11.731138
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:20:14.478318
# Unit test for method __str__ of class Try
def test_Try___str__():  # test_Try___str__
    assert 'Try[value=1, is_success=True]' == str(Try(1, True))
    assert 'Try[value=1, is_success=False]' == str(Try(1, False))



# Generated at 2022-06-24 00:20:18.151623
# Unit test for method map of class Try
def test_Try_map():
    # Given
    try_success = Try(10, True)
    try_fail = Try(10, False)

    # When
    double = lambda x: x * 2
    result_1 = try_success.map(double)
    result_fail = try_fail.map(double)

    # Then
    assert result_1 == Try(20, True)
    assert result_fail == Try(10, False)



# Generated at 2022-06-24 00:20:20.440000
# Unit test for method map of class Try
def test_Try_map():
    # Test successful
    assert Try(2, True).map(lambda x: x * 2) == Try(4, True)
    # Test not successful
    assert Try(Exception, False).map(lambda x: x * 2) == Try(Exception, False)


# Generated at 2022-06-24 00:20:23.929372
# Unit test for method on_success of class Try
def test_Try_on_success():
    def on_success_test(value):
        assert value == 10

    assert Try(10, True).on_success(on_success_test).is_success == True
    assert Try(10, False).on_success(on_success_test).is_success == False


# Generated at 2022-06-24 00:20:30.885041
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda x: x * 2, 3) == Try(6, True)
    assert Try.of(lambda x: x * 2, 3).bind(lambda x: Try(x * 2, True)) == Try(12, True)
    assert Try.of(lambda x: x * 2, 3).bind(lambda x: Try(x * 2, False)) == Try(12, False)
    assert Try.of(lambda x: x / 0, 3).bind(lambda x: Try(x * 2, True)) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:20:35.405023
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        if value:
            return True
        return False

    assert Try(None, True).filter(filterer) == Try(None, False)
    assert Try(1, True).filter(filterer) == Try(1, True)


# Generated at 2022-06-24 00:20:40.847694
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert 'Try[value=2, is_success=True]' == str(Try(2, True))
    assert 'Try[value=2, is_success=False]' == str(Try(2, False))



# Generated at 2022-06-24 00:20:45.201892
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    try_success = Try(1, True)
    try_not_success = Try(Exception('Error'), False)

    assert try_success == Try(1, True)
    assert try_success != Try(2, True)

    assert try_not_success == Try(Exception('Error'), False)
    assert try_not_success != Try(Exception('Error'), True)


# Generated at 2022-06-24 00:20:49.039073
# Unit test for method bind of class Try
def test_Try_bind():
    def add(a, b):
        return a + b

    result = Try.of(add, 1, 2).bind(
        lambda a: Try.of(add, a, 3)
    ).bind(
        lambda a: Try.of(add, a, 4)
    )

    assert result == Try(10, True)


# Generated at 2022-06-24 00:20:53.834585
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(5, False)) == 'Try[value=5, is_success=False]'
    assert str(Try(3, True)) == 'Try[value=3, is_success=True]'
    assert str(Try('Hello World!', False)) == 'Try[value=Hello World!, is_success=False]'
    assert str(Try('Hello World!', True)) == 'Try[value=Hello World!, is_success=True]'
    assert str(Try((1, 2, 3), False)) == 'Try[value=(1, 2, 3), is_success=False]'

# Generated at 2022-06-24 00:20:57.182613
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('1', True)) == 'Try[value=1, is_success=True]'
    assert str(Try('2', False)) == 'Try[value=2, is_success=False]'


# Generated at 2022-06-24 00:21:01.444907
# Unit test for method __str__ of class Try
def test_Try___str__():
    test_value = 'test_value'
    assert str(Try(test_value, True)) == 'Try[value={}, is_success={}]'.format(test_value, True)
    assert str(Try(test_value, False)) == 'Try[value={}, is_success={}]'.format(test_value, False)


# Generated at 2022-06-24 00:21:07.836779
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = 'test'
    try_monad = Try(value, True)

    def test_success_callback(v):
        assert v == value

    try_monad.on_success(test_success_callback)
    assert try_monad.on_success(test_success_callback) == try_monad



# Generated at 2022-06-24 00:21:10.210154
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Test for method __str__ of class Try.
    """
    value = 'result'
    is_success = True
    res = str(Try(value, is_success))
    assert res == 'Try[value=result, is_success=True]', "Assert error"


# Generated at 2022-06-24 00:21:18.154045
# Unit test for method __str__ of class Try
def test_Try___str__():
    try:
        assert Try(2, True).__str__() == 'Try[value=2, is_success=True]'
        assert Try(2, False).__str__() == 'Try[value=2, is_success=False]'

        assert Try(Exception, True).__str__() == 'Try[value=Exception(), is_success=True]'
        assert Try(Exception, False).__str__() == 'Try[value=Exception(), is_success=False]'
    except Exception as e:
        print('Failed on test_Try___str__, error: {}'.format(e))



# Generated at 2022-06-24 00:21:23.102293
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_instance = Try(2, True)
    assert str(try_instance) == 'Try[value=2, is_success=True]'
    try_instance = Try(2, False)
    assert str(try_instance) == 'Try[value=2, is_success=False]'



# Generated at 2022-06-24 00:21:28.098899
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda x: Try(x + 2, True)) == Try(3, True)


# Generated at 2022-06-24 00:21:32.083388
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def _try_success():
        return Try(10, True)

    def _try_fail():
        return Try(10, False)

    assert _try_success().get_or_else(100) == 10
    assert _try_fail().get_or_else(100) == 100



# Generated at 2022-06-24 00:21:39.452819
# Unit test for method filter of class Try
def test_Try_filter():
    value = "Hello world!"
    def fn_filterer(value):
        return True

    def fn_mapper(value):
        return value + "!"

    def fn_binder(value):
        return Try(value + "!!", True)

    def fn_success_callback(value):
        return print(value)

    def fn_fail_callback(value):
        return print(value)

    try_object = Try(value, True)

    try_object.map(fn_mapper).filter(fn_filterer).bind(fn_binder) \
        .on_success(fn_success_callback).on_fail(fn_fail_callback)

    assert try_object.get() == value
    assert try_object.get_or_else("Other value") == value


# Generated at 2022-06-24 00:21:41.869638
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    result = Try.of(int, '10').on_fail(lambda x: print(x))
    assert result == Try(10, True)



# Generated at 2022-06-24 00:21:45.405398
# Unit test for method map of class Try
def test_Try_map():
    assert Try(value=10, is_success=True).map(lambda value: value + 5) == Try(value=15, is_success=True)
    assert Try(value=10, is_success=False).map(lambda value: value + 5) == Try(value=10, is_success=False)


# Generated at 2022-06-24 00:21:49.408113
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(2/2, True).on_fail(lambda e: None) == Try(1, True)
    assert Try(None, False).on_fail(lambda e: None) == Try(None, False)
    success_call_count = 0
    def success_callback(value):
        nonlocal success_call_count
        success_call_count = success_call_count + 1
    assert Try(None, False).on_fail(success_callback) == Try(None, False)
    assert success_call_count == 1


# Generated at 2022-06-24 00:21:51.395312
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2

# Generated at 2022-06-24 00:21:57.323671
# Unit test for method bind of class Try
def test_Try_bind():
    """
        :returns: True if Try.bind() is working correctly
        :rtype: Boolean
    """

    def square(x):
        """
        Test function for square param.

        :params x: the number to square
        :type x: Number
        :returns: x**2
        :rtype: Number
        """
        return x**2

    def square_root(x):
        """
        Test function for square root param.

        :params x: the number to square
        :type x: Number
        :returns: x**(1/2)
        :rtype: Number
        """
        return x**(1/2)


# Generated at 2022-06-24 00:21:58.582255
# Unit test for constructor of class Try
def test_Try():
    assert Try(5, True) == Try(5, True)
    assert Try(5, True).is_success == True
    assert Try(5, False).is_success == False



# Generated at 2022-06-24 00:22:01.675669
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: x + 1).get() == 2
    assert Try(1, False).on_success(lambda x: x + 1).get() == 1


# Generated at 2022-06-24 00:22:12.518866
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, False)
    assert Try("1", False) != Try(1, False)
    assert Try("1", True) != Try(1, True)
    assert Try("1", False) != Try("2", False)
    assert Try("1", True) != Try("2", True)
    assert Try("1", False) != Try("1", True)
    assert Try("1", True) != Try("2", False)


# Generated at 2022-06-24 00:22:14.759632
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-24 00:22:20.747006
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert 'Try[value=123, is_success=True]' == str(Try(123, True))
    assert 'Try[value=123, is_success=False]' == str(Try(123, False))
    assert 'Try[value=123, is_success=True]' == str(Try(123, True))
    assert 'Try[value=123, is_success=False]' == str(Try(123, False))
    assert 'Try[value=321, is_success=True]' == str(Try(321, True))
    assert 'Try[value="try.py", is_success=False]' == str(Try("try.py", False))


# Generated at 2022-06-24 00:22:26.408650
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:22:33.431397
# Unit test for method on_success of class Try
def test_Try_on_success():
    success_callback = mock.Mock()
    not_success_callback = mock.Mock()
    Try(1, True).on_success(success_callback)
    Try(ValueError(), False).on_success(success_callback)
    success_callback.assert_called_with(1)
    not_success_callback.assert_not_called()



# Generated at 2022-06-24 00:22:42.215594
# Unit test for method filter of class Try
def test_Try_filter():
    expected_try = Try(1, True)
    unexpected_try = Try(1, False)

    assert Try.of(lambda: 1, None).filter(lambda x: True) == expected_try
    assert Try.of(lambda: 1, None).filter(lambda x: False) == unexpected_try
    assert Try(1, False).filter(lambda x: True) == Try(1, False)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try.of(lambda: 1, None).filter(lambda x: True)\
        .is_success is True
    assert Try.of(lambda: 1, None).filter(lambda x: False)\
        .is_success is False
    assert Try.of(lambda: 1, None).filter(lambda x: True)\
        .value == 1

# Generated at 2022-06-24 00:22:45.171136
# Unit test for method filter of class Try
def test_Try_filter():
    assert (Try.of(lambda x: x + 1, 1).filter(lambda x: x == 2)) == Try(2, True)
    assert (Try.of(lambda x: x + 1, 1).filter(lambda x: x == 3)) == Try(2, False)


# Generated at 2022-06-24 00:22:50.437359
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def safe_division(x, y):
        def divide(x, y):
            return x / y
        return Try.of(divide, x, y)

    def unsage_division(x, y):
        return Try.of(lambda: x / y)

    zeros = (0, 0)
    assert safe_division(*zeros).bind(lambda _: Try(1, True)) == Try(1, True)
    assert unsage_division(*zeros).bind(lambda _: Try(1, True)) == Try(1, False)



# Generated at 2022-06-24 00:22:54.627253
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert(Try(1, True).get_or_else(0) == 1)
    assert(Try(Exception, False).get_or_else(0) == 0)
    assert(Try(Exception, False).get_or_else(1) == 1)


# Generated at 2022-06-24 00:22:58.413784
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def fault_func():
        raise Exception('fault_func')
    # true value
    assert Try.of(lambda: 1, None).get_or_else(2) == 1
    # false value
    assert Try.of(fault_func, None).get_or_else(2) == 2


# Generated at 2022-06-24 00:23:03.987302
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        assert value == 'mocked_value'

    def fail_callback(value):
        assert False

    mocked_value = 'mocked_value'
    monad_success = Try(mocked_value, True)
    assert mocked_value == monad_success.get()
    assert monad_success.on_success(success_callback) == monad_success
    monad_fail = Try(Exception, False)
    assert monad_fail.on_success(success_callback) == monad_fail
    monad_fail.on_fail(fail_callback)



# Generated at 2022-06-24 00:23:06.821653
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(0, True).filter(filterer) == Try(0, False)
    assert Try(0, False).filter(filterer) == Try(0, False)



# Generated at 2022-06-24 00:23:08.967580
# Unit test for method get of class Try
def test_Try_get():
    # GIVEN
    value = 'Hello world'
    expected = value

    # WHEN
    actual = Try(value, True).get()

    # THEN
    assert value == expected


# Generated at 2022-06-24 00:23:11.149436
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_ = Try(1, True)
    other = Try(1, True)
    assert(try_ == other)


# Generated at 2022-06-24 00:23:16.037022
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(55, True)) == 'Try[value=55, is_success=True]'
    assert str(Try('Hello', False)) == 'Try[value=Hello, is_success=False]'


# Generated at 2022-06-24 00:23:21.384137
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # set up
    success = Try(1, True)
    fail = Try(1, False)

    # assert
    assert success.get_or_else(2) == 1
    assert fail.get_or_else(2) == 2


# Generated at 2022-06-24 00:23:24.325861
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:23:28.548188
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Test for successful monad
    assert Try(1, True)\
        .on_fail(lambda x: print('Exception: ', x))\
        .get() == 1

    # Test for not successful monad
    assert Try(1, False)\
        .on_fail(lambda x: print('Exception: ', x))\
        .get() == 1


# Generated at 2022-06-24 00:23:36.895815
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    '''
    Monad Try

    Test method get_or_else of class Try
    '''
    def get_value(in_list, in_index):
        return in_list[in_index]

    def get_index(in_list, in_index):
        return in_index

    def get_value_from_non_empty_list():
        """
        Test when list is not empty and index is valid,
        """
        list_value = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        index = 4
        assert Try.of(get_value, list_value, index).get_or_else(None) == list_value[index]


# Generated at 2022-06-24 00:23:42.878234
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(123, True)) == 'Try[value=123, is_success=True]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(123, False)) == 'Try[value=123, is_success=False]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'


# Generated at 2022-06-24 00:23:46.536234
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(3, True).get_or_else(8) == 3
    assert Try(None, False).get_or_else(8) == 8

# Generated at 2022-06-24 00:23:49.716506
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 2

    assert Try(1, True).filter(filterer).is_success == False
    assert Try(2, True).filter(filterer).is_success == False
    assert Try(3, True).filter(filterer).is_success == True


# Generated at 2022-06-24 00:23:53.456469
# Unit test for method bind of class Try
def test_Try_bind():
    def fn1(x: int) -> int:
        return x + 10

    def fn2(x: int) -> Try[int]:
        return Try(x + 10, True)

    assert Try.of(fn1, 1).bind(fn2) == Try.of(fn1, 1).map(fn2).get()

    fn3 = lambda x: x
    assert Try.of(fn1, 1).bind(fn3) == Try.of(fn1, 1)



# Generated at 2022-06-24 00:23:57.100773
# Unit test for method on_success of class Try
def test_Try_on_success():
    f = lambda x: x + 1
    assert Try(1, True).on_success(f) == Try(1, True)
    assert Try(1, True).on_success(f).get() == 2

# Generated at 2022-06-24 00:23:59.464838
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2



# Generated at 2022-06-24 00:24:04.217638
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Test function for method __str__ of class Try
    """
    assert str(Try(3, True)) == 'Try[value=3, is_success=True]'
    assert str(Try(3, False)) == 'Try[value=3, is_success=False]'


# Generated at 2022-06-24 00:24:11.878554
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try
    """

    assert Try('success', True) == Try('success', True)
    assert Try('fail', False) == Try('fail', False)
    assert Try('success', True) != Try('success', False)
    assert Try('success', True) != Try('fail', True)
    assert Try('fail', False) != Try('success', False)


# Generated at 2022-06-24 00:24:18.860666
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert(Try(1, True).get_or_else(0) == 1)
    assert(Try('monad', False).get_or_else(0) == 0)
    assert(Try('monad', False).map(lambda x: x.lower()).get_or_else(0) == 0)



# Generated at 2022-06-24 00:24:26.247015
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(2, True)\
        .bind(lambda n: Try(n + 1, True)) == Try(3, True)
    assert Try(2, True)\
        .bind(lambda n: Try(n + 1, False)) == Try(3, False)
    assert Try(2, False)\
        .bind(lambda n: Try(n + 1, True)) == Try(2, False)
    assert Try(2, False)\
        .bind(lambda n: Try(n + 1, False)) == Try(2, False)


# Generated at 2022-06-24 00:24:32.444153
# Unit test for method on_fail of class Try

# Generated at 2022-06-24 00:24:33.943325
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 'value', None).get() == 'value'


# Generated at 2022-06-24 00:24:41.084452
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 10, ()).get_or_else(0) == 10
    assert Try.of(lambda: 10, ()).get_or_else(lambda: 0)() == 10
    assert Try.of(lambda: 0 / 0, ()).get_or_else(0) == 0
    assert Try.of(lambda: 0 / 0, ()).get_or_else(lambda: 0)() == 0


# Generated at 2022-06-24 00:24:46.360760
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) != Try(2, True)



# Generated at 2022-06-24 00:24:52.971036
# Unit test for method filter of class Try
def test_Try_filter():
    class MyException(Exception):
        pass
    def _filterer(x):
        return x == 'hello'
    def _filterer_raise_exception(x):
        raise MyException
    # method filter return copy of self
    try:
        assert Try(1, False).filter(_filterer) == Try(1, False)
        assert Try(2, True).filter(_identity) == Try(2, True)
    except Exception:
        assert False
    # method filter return not successfully Try when filterer raise exception
    try:
        assert Try(1, False).filter(_filterer_raise_exception) == Try(1, False)
        assert Try(2, True).filter(_filterer_raise_exception) == Try(MyException(), False)
    except Exception:
        assert False
    #

# Generated at 2022-06-24 00:24:57.375293
# Unit test for method map of class Try
def test_Try_map():
    def fn(x):
        return x*x

    assert Try.of(fn, 2).map(fn) == Try(16, True)
    assert Try.of(lambda x: x/0, 2).map(fn) == Try(ZeroDivisionError, False)



# Generated at 2022-06-24 00:25:03.142039
# Unit test for method map of class Try
def test_Try_map():
    # Test case of successfully Try with apply map with mapper
    assert(Try(1, True).map(lambda x: x + 1) == Try(2, True))
    # Test case of not successfully Try with apply map with mapper
    assert(Try(1, False).map(lambda x: x + 1) == Try(1, False))


# Generated at 2022-06-24 00:25:06.882738
# Unit test for method map of class Try
def test_Try_map():
    # Setup
    def add(a):
        return a + 1

    # Exercise
    result = Try.of(add, 1).map(add)

    # Verify
    assert result == Try(3, True)



# Generated at 2022-06-24 00:25:11.156345
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        raise Exception('error')
    except Exception as error:
        _try = Try(error, False)

    def fail_callback(value):
        assert value == error

    _try.on_fail(fail_callback)

# Generated at 2022-06-24 00:25:16.424141
# Unit test for method get of class Try
def test_Try_get():
    try_ = Try.of(lambda x: x, 6)
    assert try_.get() == 6
    assert try_.get() == Try(6, True).get()


# Generated at 2022-06-24 00:25:25.958835
# Unit test for method bind of class Try
def test_Try_bind():
    """
    The bind method of the Try class.
    This method is described by the following Monad laws

     - left identity:
     try_monad.bind(lambda x: Try.of(f, x)) ==
     Try.of(f, try_monad.get())

     - right identity:
     try_monad.bind(lambda x: Try.of(x)) ==
     try_monad

     - associativity:
     try_monad.bind(f).bind(g) ==
     try_monad.bind(lambda x: f(x).bind(g))
    """
    # Case for method bind with left identity law
    def f(x):
        return x + 1

    try_monad = Try.of(f, 1)

# Generated at 2022-06-24 00:25:33.146787
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def check_ok(value: int) -> None:
        assert value == 100
        assert True

    def check_ok_2(value: int) -> None:
        assert value == 101
        assert True

    def check_ok_3(value: int) -> None:
        assert value == 111
        assert True

    def check_fail(value: Exception) -> None:
        assert value.__class__ == ValueError
        assert True

    def check_fail_2(value: Exception) -> None:
        assert value.__class__ == ValueError
        assert False

    def check_fail_3(value: Exception) -> None:
        assert value.__class__ == ValueError
        assert True

    def check_ok_and_check_fail(value: int) -> None:
        check_ok(value)
        check_fail

# Generated at 2022-06-24 00:25:36.907369
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    value = 1
    default_value = 2
    assert Try.of(lambda: value, ()).get_or_else(default_value) == value

# Generated at 2022-06-24 00:25:39.529532
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(None, False).get_or_else(None) is None
    try:
        assert Try(None, False).get_or_else(1 / 0) is None
    except ZeroDivisionError:
        pass



# Generated at 2022-06-24 00:25:43.421680
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(lambda x: x, 123)) == 'Try[value=123, is_success=True]'
    assert str(Try(123, True)) == 'Try[value=123, is_success=True]'
    assert str(Try(Exception(), False)) == 'Try[value=Exception(), is_success=False]'


# Generated at 2022-06-24 00:25:47.366548
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try_value = Try(True, True)

    @my_decorator
    def success_callback(value):
        print(value)

    @my_decorator
    def fail_callback(value):
        print(value)

    assert try_value.on_fail(fail_callback) == try_value

    try_value = Try(True, False)

    assert try_value.on_fail(fail_callback) != try_value



# Generated at 2022-06-24 00:25:51.692117
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, False) == Try(1, True)
    assert Try(1, True) != Try(1, False)



# Generated at 2022-06-24 00:25:54.601669
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(5, True).get_or_else(10) == 5
    assert Try(5, False).get_or_else(10) == 10


# Generated at 2022-06-24 00:25:58.534944
# Unit test for constructor of class Try
def test_Try():
    """
    Test Try constructor.
    """
    assert False == Try(None, False).is_success
    assert None == Try(None, False).value
    assert True == Try(None, True).is_success
    assert None == Try(None, True).value

    assert False == Try(Exception, False).is_success
    assert isinstance(Try(Exception, False).value, Exception)
    assert True == Try(Exception, True).is_success
    assert isinstance(Try(Exception, True).value, Exception)



# Generated at 2022-06-24 00:26:03.655469
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    value = 1

    def fail_callback(e):
        assert False, "test fail_callback"

    def success_callback(v):
        assert False, "test success_callback"

    try:
        1/0
    except Exception as e:
        assert Try(e, False).on_fail(fail_callback).on_success(success_callback) == Try(e, False)


# Generated at 2022-06-24 00:26:06.690927
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(7, True).on_success(lambda v: print(v)).is_success
    assert not Try('value', True).on_success(lambda v: print(v)).is_success

# Generated at 2022-06-24 00:26:10.439744
# Unit test for method on_success of class Try
def test_Try_on_success():
    def callback(v):
        print(v)

    value = Try.of(lambda x: 1, 0)
    assert value.on_success(callback) == value
    assert value.is_success == True


# Generated at 2022-06-24 00:26:13.051169
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1, ).get_or_else(0) == 1
    assert Try.of(lambda: 1 / 0, ).get_or_else(0) == 0


# Generated at 2022-06-24 00:26:18.467368
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:26:22.005349
# Unit test for constructor of class Try
def test_Try():
    # Test for successfully Try
    value = 'value'
    try_ = Try(value, True)
    assert try_.value == value
    assert try_.is_success
    # Test for not successfully Try
    value = 'value'
    try_ = Try(value, False)
    assert try_.value == value
    assert not try_.is_success

# Unit tests for class Try's method of

# Generated at 2022-06-24 00:26:31.254469
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(10, True).bind(lambda x: Try(x + 5, True)) == Try(15, True)
    assert Try(10, True).bind(lambda x: Try(x + 5, False)) == Try(15, False)
    assert Try(10, False).bind(lambda x: Try(x + 5, True)) == Try(10, False)
    assert Try(10, False).bind(lambda x: Try(x + 5, False)) == Try(10, False)
    assert Try(10, False).bind(lambda x: Try(x + 5, False).bind(lambda x: Try(x + 7, False))) == Try(10, False)


# Generated at 2022-06-24 00:26:34.097704
# Unit test for method map of class Try
def test_Try_map():
    test_try = Try.of(lambda x: x, 1)
    assert test_try.map(lambda x: x + 1).on_success(
        lambda x: print(x)).get() == 2



# Generated at 2022-06-24 00:26:39.311903
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def divide(a, b):
        if b == 0:
            raise Exception('Division by zero')
        return a / b

    assert Try.of(divide, 1, 0).bind(lambda a: Try(a, True)) == Try(Exception('Division by zero'), False)
    assert Try.of(divide, 1, 2).bind(lambda a: Try(a, True)) == Try(0.5, True)


# Generated at 2022-06-24 00:26:49.090435
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for function filter of class Try.
    """
    from random import randint

    def filterer(n: int) -> bool:
        return n % 2 == 0

    def not_filterer(n: int) -> bool:
        return n % 2 != 0

    n = randint(1, 50)
    assert Try.of(filterer, n).filter(not_filterer).is_success == filterer(n)
    assert Try.of(not_filterer, n).filter(filterer).is_success == filterer(n)
    assert Try.of(filterer, n).filter(filterer).is_success == filterer(n)
    assert Try.of(not_filterer, n).filter(not_filterer).is_success == filt

# Generated at 2022-06-24 00:26:51.776817
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0

# Generated at 2022-06-24 00:26:55.005600
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Call method filter on successfully Try.
    When filterer returns True expected returned successfully Try with previous value.

    :returns: True when all test passed, othercase False
    :rtype: Boolean
    """
    def filterer(value):
        return value > 10
    a = Try(15, True).filter(filterer)

    return a == Try(15, True)



# Generated at 2022-06-24 00:26:58.885208
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    value = Try.of(lambda x: 1 / x, 0) \
        .on_fail(lambda x: print(x)) \
        .on_fail(lambda x: print('second fail')) \
        .on_success(lambda x: print(x)) \
        .get()

    assert value == ZeroDivisionError


# Generated at 2022-06-24 00:27:01.552585
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    >>> str(Try('test data', True))
    "Try[value='test data', is_success=True]"
    """
    pass



# Generated at 2022-06-24 00:27:07.202573
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: x) == Try(1, True)
    assert Try(1, False).on_success(lambda x: x) == Try(1, False)


# Generated at 2022-06-24 00:27:13.239366
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(2, True) != Try(1, True)
    assert Try(2, False) != Try(1, False)


# Generated at 2022-06-24 00:27:15.367009
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(0, True).get_or_else(10) == 0
    assert Try(None, False).get_or_else(10) == 10


# Generated at 2022-06-24 00:27:17.245381
# Unit test for method __str__ of class Try
def test_Try___str__():
    f = Try(2, True)
    assert 'Try[value=2, is_success=True]' == str(f)


# Generated at 2022-06-24 00:27:20.371590
# Unit test for constructor of class Try
def test_Try():
    assert Try(0, True) == Try(0, True)
    assert Try(0, False) == Try(0, False)
    assert Try(0, True) != Try(0, False)
    assert not Try(0, True).is_success
    assert Try(0, False).is_success

# Generated at 2022-06-24 00:27:25.940538
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    not_successful = Try(Exception("Not successful"), False)
    assert not_successful.is_success is False
    assert not_successful.value == Exception("Not successful")

    successful = Try(1, True)
    assert successful.is_success is True
    assert successful.value == 1



# Generated at 2022-06-24 00:27:29.149434
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 'value', None).get() == 'value'


# Generated at 2022-06-24 00:27:39.337087
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_helloworld(msg):
        assert msg == 'hello world'

    def fail_helloworld(exception):
        assert type(exception) == Exception
        assert str(exception) == 'hello world'

    success_hello_world = Try.of(lambda: 'hello world', None)
    fail_hello_world = Try.of(lambda: raise_exception('hello world'), None)

    assert success_hello_world.on_success(success_helloworld) == success_hello_world
    assert fail_hello_world.on_success(success_helloworld) == fail_hello_world
    assert success_hello_world.on_fail(fail_helloworld) == success_hello_world
    assert fail_hello_world.on_fail(fail_helloworld) == fail_hello_world



# Generated at 2022-06-24 00:27:46.548682
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(val):
        if val == 2:
            return True
        raise Exception('Failure')

    def fail_callback(val):
        if val == 1:
            return True
        raise Exception('Failure')

    try:
        Try(2, True).on_success(success_callback)
    except Exception as e:
        assert False, 'Expect success'

    try:
        Try(2, False).on_success(success_callback)
    except Exception as e:
        assert False, 'Expect success'

    try:
        Try(1, False).on_success(success_callback)
        assert False, 'Expect failure'
    except Exception as e:
        pass


# Generated at 2022-06-24 00:27:50.864803
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Test with same value
    try_1 = Try(True, True)
    try_2 = Try(True, True)
    assert try_1 == try_2

    # Test with different values with same type
    try_1 = Try('3', True)
    try_2 = Try('4', True)
    assert not (try_1 == try_2)

    # Test with different values with different type
    try_1 = Try('3', True)
    try_2 = Try(4, True)
    assert not (try_1 == try_2)



# Generated at 2022-06-24 00:28:01.267531
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(int, '123').bind(lambda i: Try(i + 1, True)) == Try(124, True)
    assert Try.of(int, 'bad').bind(lambda i: Try(i + 1, True)) == Try('bad', False)
    assert Try.of(int, 'bad').bind(lambda i: Try(i + 1, True)).bind(lambda i: Try(i + 1, True)) == Try('bad', False)
    assert Try.of(int, 'bad').bind(lambda i: Try(i + 1, True)).bind(lambda i: Try(i + 1, True)).bind(lambda i: Try(i + 1, True)) == Try('bad', False)

# Generated at 2022-06-24 00:28:07.542037
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    e = Exception('exception')
    t = Try(e, False)

    def success_callback(value):
        assert False

    def fail_callback(value):
        assert True

    assert t.on_success(success_callback) == t
    assert t.on_fail(fail_callback) == t


# Generated at 2022-06-24 00:28:10.816437
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)


# Generated at 2022-06-24 00:28:19.076568
# Unit test for method on_success of class Try
def test_Try_on_success():
    def some_function(i: int) -> int:
        return i

    def some_function_with_exception(i: int) -> int:
        raise Exception()

    def success_callback(i: int) -> None:
        pass

    some_function_of_Try = Try.of(some_function, 1)
    some_function_with_exception_of_Try = Try.of(some_function_with_exception, 1)

    assert Try.of(some_function, 1).map(some_function).on_success(success_callback) ==\
           Try.of(some_function, 1).map(some_function)

# Generated at 2022-06-24 00:28:20.531989
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 5, ).get() == 5


# Generated at 2022-06-24 00:28:26.750874
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Write test for method on_fail
    # Test should check that method on_fail call fail_callback
    # when monad is not successfully
    def success_callback(value):
        raise Exception("Success callback is called on not successfully monad")

    def fail_callback(value):
        assert isinstance(value, Exception)
        assert True

    value = 10
    Try(value, True).on_fail(fail_callback).on_success(success_callback)
    assert True


# Generated at 2022-06-24 00:28:34.260614
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_monad = Try(1, True)
    try_monad_1 = Try(1, True)
    assert try_monad == try_monad_1

    try_monad_2 = Try(1, False)
    assert try_monad != try_monad_2

    try_monad_3 = Try(2, True)
    assert try_monad != try_monad_3



# Generated at 2022-06-24 00:28:36.399416
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2
    assert Try(2, False).get() == 2



# Generated at 2022-06-24 00:28:42.838298
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Test True cases
    assert Try(None, True) == Try(None, True)
    assert Try("123", True) == Try("123", True)
    assert Try("123", False) == Try("123", False)

    # Test False cases
    assert Try("123", True) != Try("123", False)
    assert Try("123", False) != Try("123", True)
    assert Try("123", True) != Try("1234", True)
    assert Try("123", False) != Try("123", False)
