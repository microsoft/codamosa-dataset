

# Generated at 2022-06-24 00:18:48.060534
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def func1(value):
        if value == 10:
            raise Exception('value is 10')
        return value
    def func2(value):
        return Try(value, True)

    assert Try(10, True).bind(func1) == Try(Exception('value is 10'), False)
    assert Try(10, True).bind(func2) == Try(func2(10).value, func2(10).is_success)



# Generated at 2022-06-24 00:18:52.855317
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(2, True).on_success(print) == Try(2, True)
    assert Try(Exception(), False).on_success(print) == Try(Exception(), False)

# Generated at 2022-06-24 00:18:59.546042
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: x) == Try(True, True)
    assert Try(True, True).filter(lambda x: False) == Try(True, False)

    assert Try(False, True).filter(lambda x: x) == Try(False, False)
    assert Try(False, True).filter(lambda x: not x) == Try(False, True)

    assert Try(True, False).filter(lambda x: x) == Try(True, False)
    assert Try(True, False).filter(lambda x: not x) == Try(True, False)



# Generated at 2022-06-24 00:19:02.699516
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Function test_Try_on_success.
    """
    success_called = False
    fail_called = False
    Try.of(lambda: 4).on_success(lambda x: success_called.__setitem__(x, True)).on_fail(lambda e: fail_called.__setitem__(e, True))
    assert success_called is True
    assert fail_called is False


# Generated at 2022-06-24 00:19:04.810158
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try

    :return: None
    :rtype: None
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-24 00:19:08.000452
# Unit test for method map of class Try
def test_Try_map():
    """
    >>> st = Try.of(lambda x: x, 10)
    >>> st.map(lambda x: x * 2).get()
    20
    >>> st.map(lambda x: x / 0).is_success
    False
    >>> st.map(lambda x: x / 0).get()
    ZeroDivisionError('division by zero',)
    """

# Generated at 2022-06-24 00:19:18.079455
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try.

    :returns: nothing
    :rtype: Noe
    """
    assert True == Try(1, True) == Try(1, True)
    assert True == Try(1, False) == Try(1, False)
    assert True == Try(1, True) == Try(1, True)
    assert True == Try(1, False) == Try(1, False)
    assert False == Try(1, True) == Try(1, False)
    assert False == Try(1, True) == Try(2, True)
    assert False == Try(1, False) == Try(2, False)


# Generated at 2022-06-24 00:19:21.948744
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert (str(Try(1, True)) == "Try[value=1, is_success=True]")
    assert (str(Try(ValueError, False)) == "Try[value=ValueError(), is_success=False]")


# Generated at 2022-06-24 00:19:27.654153
# Unit test for method map of class Try
def test_Try_map():
    try_1 = Try(42, True)
    try_2 = try_1.map(lambda x: x + 1)

    assert try_2.value == 43
    assert try_2.is_success is True

    try_1 = Try(42, False)
    try_2 = try_1.map(lambda x: x + 1)

    assert try_2.value == 42
    assert try_2.is_success is False



# Generated at 2022-06-24 00:19:31.057317
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-24 00:19:36.714408
# Unit test for method map of class Try
def test_Try_map():
    # Monad is not successfully when apply map, method returns copy of monad
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)
    # Successfully monad return new successfully monad
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)


# Generated at 2022-06-24 00:19:42.153767
# Unit test for method on_success of class Try
def test_Try_on_success():
    result = Try.of(lambda: 1 + 1)
    expected = 2

    def callback(value):
        nonlocal expected, result
        assert value == expected
        result = value

    assert result == Try(expected, True)
    result.on_success(callback)


# Generated at 2022-06-24 00:19:48.654906
# Unit test for method map of class Try
def test_Try_map():
    assert Try(0, True).map(lambda x: x+1) == Try(1, True) # case: successfully, add 1 to 0
    assert Try(0, False).map(lambda x: x+1) == Try(0, False) # case: not successfully, don't apply function



# Generated at 2022-06-24 00:19:50.839684
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        f = lambda i: i ** 2
        f(1)
        f(0)
        assert False
    except BaseException as e:
        assert Try \
            .of(f, 0) \
            .on_fail(lambda ex: str(ex)) == str(e)


# Generated at 2022-06-24 00:19:56.246211
# Unit test for method map of class Try
def test_Try_map():
    """
    >>> t = Try.of(someFunction)
    >>> t.map(lambda x: someFunction(x)).map(lambda x: x + 1).get()
    3
    >>> t.map(lambda x: someFunction(x)).map(lambda x: x + 1).is_success
    True
    >>> t = Try.of(someFunctionWhichRaisedException)
    >>> t.map(lambda x: someFunction(x)).map(lambda x: x + 1).is_success
    False
    >>> t.map(lambda x: someFunction(x)).map(lambda x: x + 1).get_or_else(-1)
    -1
    """



# Generated at 2022-06-24 00:20:00.185926
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def handle_it(e):
        assert isinstance(e, Exception)
        assert e.args[0] == 'Error'
    Try.of(lambda: 10/0).on_fail(handle_it)


# Generated at 2022-06-24 00:20:08.797702
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 3

    @Try.of
    def fn(value):
        return value

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(4, True).filter(filterer) == Try(4, True)
    assert Try(exception, False).filter(filterer) == Try(exception, False)

    try:
        assert fn(exception).filter(filterer) == Try(exception, True)
    except:  # pragma: no cover
        assert fn(exception).filter(filterer) == Try(exception, False)



# Generated at 2022-06-24 00:20:14.402356
# Unit test for method map of class Try
def test_Try_map():
    assert Try(2, True).map(lambda x: x * 2) == Try(4, True)
    assert Try(2, False).map(lambda x: x * 2) == Try(2, False)
    assert Try(2, True).map(lambda x: '{}'.format(x * 2)) == Try('4', True)
    assert Try(2, False).map(lambda x: '{}'.format(x * 2)) == Try(2, False)


# Generated at 2022-06-24 00:20:18.316373
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True).value == 1
    assert Try(1, True).is_success
    assert isinstance(Try(None, True), Try)
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, True)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-24 00:20:22.171624
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: [1,2], None).get_or_else([]) == [1, 2]


# Generated at 2022-06-24 00:20:27.602316
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(0, False).filter(lambda x: x > 0) == Try(0, False)
    assert Try(0, True).filter(lambda x: x > 0) == Try(0, False)
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try('1', True).filter(lambda x: x.isdigit()) == Try('1', True)
    assert Try('1', True).filter(lambda x: x.isalpha()) == Try('1', False)


# Generated at 2022-06-24 00:20:34.044452
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test for method on_fail of class Try in case when it take function and when not.
    """
    a = 5
    assert Try(a, True).on_fail(lambda x: x + 1) == Try(a, True)
    assert Try(a, False).on_fail(lambda x: x + 1) == Try(6, False)

# Generated at 2022-06-24 00:20:37.007450
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """test_Try___eq__"""
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-24 00:20:41.999003
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def test_method(value):
        print(value)

    assert Try(None, True).on_success(test_method) == Try(None, True)
    assert Try(None, False).on_success(test_method) == Try(None, False)



# Generated at 2022-06-24 00:20:45.778234
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(1, True).get_or_else(0) == 1
    assert Try(2, False).get_or_else(0) == 0

# Generated at 2022-06-24 00:20:52.685815
# Unit test for constructor of class Try
def test_Try():
    value = 'test'
    try_test = Try(value, True)
    assert try_test.is_success == True
    assert try_test.value == value

    value = 'test'
    try_test = Try(value, False)
    assert try_test.is_success == False
    assert try_test.value == value

    value = 1
    try_test = Try(value, True)
    assert try_test.is_success == True
    assert try_test.value == value

    value = 1
    try_test = Try(value, False)
    assert try_test.is_success == False
    assert try_test.value == value


# Generated at 2022-06-24 00:20:56.189573
# Unit test for method filter of class Try
def test_Try_filter():
    def really_zero(x):
        return x == 0

    assert Try(0, True).filter(really_zero) == Try(0, True)
    assert Try(1, True).filter(really_zero) == Try(1, False)
    assert Try(1, False).filter(really_zero) == Try(1, False)


# Generated at 2022-06-24 00:21:00.849746
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Test for successful monad
    assert Try.of(lambda: 'ok').on_fail(Exception).get() == 'ok'
    # Test for not successful monad
    assert isinstance(Try.of(lambda: 1 / 0).on_fail(Exception).get(), ZeroDivisionError)


# Generated at 2022-06-24 00:21:06.766408
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:21:09.428530
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    a = Try(1, True)
    b = Try(1, True)
    c = Try(1, False)
    assert a == b
    assert a != c


# Generated at 2022-06-24 00:21:17.008804
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Run unit test on method bind of class Try.

    :returns: True if test passed, othercase False
    :rtype: Boolean
    """
    def successful_fn(x):
        return x ** 2
    def fail_fn(x):
        return 1/0

    try_success = Try(2, True)
    try_fail = Try(2, False)

    assert not Try(None, False).bind(successful_fn)\
        == Try(None, True).bind(successful_fn)

    assert Try(2, True).bind(successful_fn)\
        == Try(4, True)

    assert Try(1, True).bind(fail_fn)\
        == Try(1, False)

    return True



# Generated at 2022-06-24 00:21:24.653590
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(x):
        return x + 1

    def fail_callback(x):
        return x + 1
    assert Try(2, True).on_success(success_callback).get() == 2 + 1
    assert Try(2, False).on_success(success_callback).get() == 2
    assert Try(2, True).on_fail(fail_callback).get() == 2
    assert Try(2, False).on_fail(fail_callback).get() == 2 + 1




# Generated at 2022-06-24 00:21:29.660792
# Unit test for method get of class Try
def test_Try_get():
    try_1 = Try(1, True)
    assert try_1.get() == 1
    try_2 = Try(1, False)
    assert try_2.get() == 1


# Generated at 2022-06-24 00:21:31.021332
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else(41) == 42
    assert Try(Exception(), False).get_or_else(41) == 41


# Generated at 2022-06-24 00:21:34.228914
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, False)


# Generated at 2022-06-24 00:21:39.589203
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1).get() == 1
    assert Try(1, True).filter(lambda x: x == 2).get_or_else(0) == 0



# Generated at 2022-06-24 00:21:44.522814
# Unit test for constructor of class Try
def test_Try():
    try_ = Try(1, False)
    assert not try_.is_success
    assert try_.value == 1

    try_ = Try(1, True)
    assert try_.is_success
    assert try_.value == 1

    try_1 = Try(1, False)
    try_2 = Try(1, False)
    assert try_1 == try_2

    try_1 = Try(1, True)
    try_2 = Try(1, True)
    assert try_1 == try_2

    try_1 = Try(1, False)
    try_2 = Try(1, True)
    assert try_1 != try_2

    try_1 = Try(1, True)
    try_2 = Try(1, False)
    assert try_1 != try_2



# Generated at 2022-06-24 00:21:49.098454
# Unit test for method filter of class Try
def test_Try_filter():
    _success = Try.of(lambda: 1)
    assert _success.filter(lambda x: x == 1) == Try(1, True)
    assert _success.filter(lambda x: x != 1) == Try(1, False)

    _fail = Try.of(lambda: 1/0)
    assert _fail.filter(lambda x: x == 1) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:21:51.262030
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def print_value(val):
        print('value = {}'.format(val))

    Try.of(lambda: 1).on_fail(print_value)
    Try.of(lambda x: 1 / x, 0).on_fail(print_value)
test_Try_on_fail()

# Generated at 2022-06-24 00:21:59.935725
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    """
    Unit test for constructor of class Try.
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True).value == 1
    assert Try(1, True).is_success is True
    assert Try(1, False).value == 1
    assert Try(1, False).is_success is False


# Generated at 2022-06-24 00:22:03.308890
# Unit test for method filter of class Try
def test_Try_filter():
    # Arrange
    t = Try.of(lambda x: x, 2)
    # Act
    result = t.filter(lambda x: x % 2 == 0)
    # Assert
    assert result == Try(2, True), "Try.filter() test failed!"


# Generated at 2022-06-24 00:22:08.602744
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(2, True).filter(lambda x: x % 2 == 1) == Try(2, False)
    assert Try(2, False).filter(lambda x: x % 2 == 0) == Try(2, False)


# Generated at 2022-06-24 00:22:15.329705
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Check behavior of method filter of class Try.

    :returns: AssertionError when test failed.
    """
    assert Try(None, False).filter(lambda x: True) == Try(None, False)
    assert Try(None, True).filter(lambda x: False) == Try(None, False)
    assert Try(1, True).filter(lambda x: True) == Try(1, True)
    assert Try('', False).filter(lambda x: True) == Try('', False)


# Generated at 2022-06-24 00:22:17.517538
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'
    assert str(Try(5, False)) == 'Try[value=5, is_success=False]'


# Generated at 2022-06-24 00:22:20.152996
# Unit test for constructor of class Try
def test_Try():
    value = 42
    try_monad = Try(value, True)
    assert try_monad == Try(value, True)
    assert try_monad.is_success == True
    assert try_monad.value == value


# Generated at 2022-06-24 00:22:30.906398
# Unit test for method get of class Try
def test_Try_get():
    def safe_integer_div(a, b):
        """
        Safe integer division function.
        Function returns result when b is not 0, othercase raises ZeroDivisionError exception.

        :params a: dividend
        :type a: Int
        :params b: divisor
        :type b: Int
        :returns: a / b
        :rtype: Int
        """
        if b == 0:
            raise ZeroDivisionError("Division by zero!")
        return a / b

    assert Try.of(safe_integer_div, 1, 1) == Try(1.0, True)
    assert Try.of(safe_integer_div, 1, 0) == Try(ZeroDivisionError("Division by zero!"), False)


# Generated at 2022-06-24 00:22:38.670075
# Unit test for method bind of class Try
def test_Try_bind():
    def fun_a(arg):
        return Try(arg + 1, True)

    def fun_b(arg):
        return Try(arg - 1, True)

    def fun_c(arg):
        return Try(arg, True)

    def fun_d(arg):
        return Try('test', False)

    assert Try(1, True).bind(fun_a).bind(fun_b).get() == 1
    assert Try(1, True).bind(fun_a).bind(fun_b).bind(fun_c).get() == 2
    assert Try(2, True).bind(fun_a).bind(fun_d).get() == 1

# Generated at 2022-06-24 00:22:46.068441
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    """
    Test for constructor of class Try.
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, True)
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert Try(1, True).is_success
    assert not Try(1, False).is_success


# Generated at 2022-06-24 00:22:48.303937
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    a = Try(42, True)
    b = Try(42, False)
    assert a.get_or_else(7) == 42
    assert b.get_or_else(7) == 7

# Generated at 2022-06-24 00:22:53.479368
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 1).on_fail(lambda e: None) == Try(1, True)
    assert Try.of(lambda a: a + 1, 1).on_fail(lambda e: None) == Try(2, True)
    assert Try.of(lambda: 1 / 0).on_fail(lambda e: None) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:22:58.765289
# Unit test for method map of class Try
def test_Try_map():

    def t_case(c, v_1, v_2):
        def f(x):
            return x + v_2
        c(Try(v_1, True).map(f), v_1 + v_2)
        c(Try(v_1, False).map(f), v_1)

    t_case(TestCase.assertEqual,
        "1111",
        "1",
        "11111")


# Generated at 2022-06-24 00:23:05.926639
# Unit test for method map of class Try
def test_Try_map():
    try:
        a = int('1')
        b = a + 1
    except ValueError:
        b = 0
    assert Try.of(int, '1').map(lambda x: x + 1) == Try(b, True)
    assert Try.of(int, 'a').map(lambda x: x + 1) == Try(0, False)


# Generated at 2022-06-24 00:23:09.166076
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Given
    exception = Exception('mock exception')
    error_try = Try(exception, False)
    mock_function = Mock()

    # When
    error_try.on_fail(mock_function)

    # Then
    mock_function.assert_called_once_with(exception)



# Generated at 2022-06-24 00:23:17.749144
# Unit test for method bind of class Try
def test_Try_bind():
    # Success-success
    result = Try.of(lambda: 8).bind(
        lambda a: Try.of(lambda: a + 5)
    )
    assert result == Try(13, True)

    # Success-not successfully
    result = Try.of(lambda: 8).bind(
        lambda a: Try.of(lambda: 1 / 0)
    )
    assert result == Try(ZeroDivisionError(), False)

    # Not successfully-success
    result = Try.of(lambda: 1/0).bind(
        lambda a: Try.of(lambda: a + 5)
    )
    assert result == Try(ZeroDivisionError(), False)

    # Not successfully-not successfully
    result = Try.of(lambda: 1/0).bind(
        lambda a: Try.of(lambda: a + 1)
    )


# Generated at 2022-06-24 00:23:21.613489
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]' 
    assert str(Try(Exception('wyjatek'), False)) == "Try[value=wyjatek, is_success=False]"


# Generated at 2022-06-24 00:23:22.779454
# Unit test for constructor of class Try
def test_Try():
    assert Try(5, True) == Try(5, True)


# Generated at 2022-06-24 00:23:25.359800
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: [1, 2, 3], )\
        .map(lambda arr: arr[4])\
        .get_or_else(0) == 0


# Generated at 2022-06-24 00:23:30.016136
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return True

    def filterer_false(x):
        return False

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, True).filter(filterer_false) == Try(1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)



# Generated at 2022-06-24 00:23:35.416558
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)



# Generated at 2022-06-24 00:23:42.371211
# Unit test for constructor of class Try
def test_Try():
    success_value = Try(7, True)
    fail_value = Try(7, False)
    fail_exception = Try(RuntimeError, False)

    assert success_value.value == 7
    assert success_value.is_success
    assert fail_value.value == 7
    assert not fail_value.is_success
    assert fail_exception.value == RuntimeError
    assert not fail_exception.is_success



# Generated at 2022-06-24 00:23:49.291881
# Unit test for method map of class Try
def test_Try_map():
    def add_two_numbers(a, b):
        return a + b

    assert Try.of(add_two_numbers, [0, 1]) == Try(1, True)
    assert Try.of(add_two_numbers, [0, 1]).map(lambda x: x + 1) == Try(2, True)
    assert Try.of(add_two_numbers, [0, 1]).map(lambda x: x + 1).map(lambda x: x ** 2) == Try(4, True)


# Generated at 2022-06-24 00:23:57.141502
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    truthy_function = lambda x: x
    falsy_function = lambda x: 1/x

    assert Try(3, True) == Try(3, True)
    assert Try(3, False) == Try(3, False)
    assert Try(3, False) != Try(7, False)
    assert Try(3, False) != Try(7, True)
    assert Try.of(truthy_function, 2) == Try.of(truthy_function, 2)
    assert Try.of(truthy_function, 2) != Try.of(truthy_function, 7)
    assert Try.of(falsy_function, 0) == Try.of(falsy_function, 0)

# Generated at 2022-06-24 00:24:01.287540
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    result = Try.of(lambda x: x / 2, 5)
    assert result.on_fail(_t) == result
    result = Try.of(lambda x: x / 0, 5)
    assert result.on_fail(_t) == result



# Generated at 2022-06-24 00:24:05.356800
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_control = Try(None, True)
    assert str(try_control) == 'Try[value=None, is_success=True]'

    try_control = Try(Exception(), False)
    assert str(try_control) == 'Try[value=Exception(), is_success=False]'


# Generated at 2022-06-24 00:24:10.509459
# Unit test for method on_success of class Try
def test_Try_on_success():
    def callback(value):
        assert value == 2

    assert Try.of(lambda: 2, None).on_success(callback) == Try.of(lambda: 2, None)


# Generated at 2022-06-24 00:24:13.541903
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, False)

    # Unit test for constructor of class Try

# Generated at 2022-06-24 00:24:19.645407
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-24 00:24:30.984464
# Unit test for method map of class Try
def test_Try_map():
    try_success = Try.of(lambda: True)
    assert try_success.map(lambda x: x)\
        == Try(True, True)
    assert try_success.map(lambda x: x is True)\
        == Try(True, True)
    assert try_success.map(lambda x: x is False)\
        == Try(False, True)
    assert try_success.map(lambda x: 10)\
        == Try(10, True)
    assert try_success.map(lambda x: None)\
        == Try(None, True)
    assert try_success.map(lambda x: x + 1)\
        == Try(2, True)

    try_fail = Try.of(lambda: x + 1)

# Generated at 2022-06-24 00:24:34.780183
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test for method map of class Try
    """
    def fn_hello(text):
        return "Hello " + text
    assert Try(Exception("wrong"), False).map(fn_hello) == Try(Exception("wrong"), False)
    assert Try("John", True).map(fn_hello) == Try("Hello John", True)


# Generated at 2022-06-24 00:24:39.388072
# Unit test for method __str__ of class Try
def test_Try___str__():
    value = 'test'
    assert str(Try(value, True)) == 'Try[value=test, is_success=True]'
    assert str(Try(value, False)) == 'Try[value=test, is_success=False]'


# Generated at 2022-06-24 00:24:40.838119
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    """
    This method tested in pylint report.
    """
    pass


# Generated at 2022-06-24 00:24:42.967678
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def safe_div(a, b):
        if b != 0:
            return a / b
        raise Exception('Division by zero!')

    assert Try.of(safe_div, 1, 2).get_or_else(0) == 0.5
    assert Try.of(safe_div, 1, 0).get_or_else(0) == 0

# Generated at 2022-06-24 00:24:45.684814
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_obj = Try(10, True)
    assert try_obj.get_or_else(True) == 10

    try_obj = Try(10, False)
    assert try_obj.get_or_else(20) == 20

# Generated at 2022-06-24 00:24:47.150463
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    Try.of(lambda: 'A', ).on_fail(lambda e: e)



# Generated at 2022-06-24 00:24:52.834891
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 10

    assert Try(None, False).filter(filterer) == Try(None, False)
    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(20, True).filter(filterer) == Try(20, False)


# Generated at 2022-06-24 00:24:55.446636
# Unit test for method get of class Try
def test_Try_get():
    # S = String, A = Integer
    assert Try(1, True).get() == 1
    assert Try("Hello", True).get() == "Hello"


# Generated at 2022-06-24 00:25:05.536738
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 2

    def filterer_that_raise_exception(value):
        raise Exception('test exception')

    assert Try.of(lambda : None).filter(filterer).is_success == False
    assert Try.of(lambda : 2).filter(filterer).is_success == False
    assert Try.of(lambda : 3).filter(filterer).is_success == True

    success_Try = Try.of(lambda : 3).filter(filterer_that_raise_exception)
    assert success_Try.is_success == False

    success_Try = Try.of(lambda: 3)
    success_Try.filter(filterer_that_raise_exception)
    assert success_Try.is_success == True

# Generated at 2022-06-24 00:25:10.068335
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def get_zero():
        return 0

    def get_one():
        raise Exception()

    assert Try.of(get_zero).get_or_else(1) == 0
    assert Try.of(get_one).get_or_else(1) == 1


# Generated at 2022-06-24 00:25:14.200169
# Unit test for method on_success of class Try
def test_Try_on_success():
    def multiply_by_two(value):
        return value * 2

    assert Try(1, True).on_success(multiply_by_two).get() == 2
    assert Try(1, False).on_success(multiply_by_two).get() == 1



# Generated at 2022-06-24 00:25:18.645194
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try.of(int, 1).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2
    assert Try.of(int, 'a').get_or_else(2) == 2



# Generated at 2022-06-24 00:25:25.740050
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = 'value'
    mock = Mock()
    success_monad = Try(value, True)
    fail_monad = Try(value, False)
    success_monad.on_success(mock.call)
    fail_monad.on_success(mock.call)
    mock.call.assert_called_with(value)
    assert mock.call.call_count == 1


# Generated at 2022-06-24 00:25:30.425381
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: print(x)).is_success == True
    assert Try(1, False).on_fail(lambda x: print(x)).is_success == False
    assert Try(1, True).on_fail(lambda x: print(x)).value == 1
    assert Try(1, False).on_fail(lambda x: print(x)).value == 1


# Generated at 2022-06-24 00:25:41.673958
# Unit test for method map of class Try
def test_Try_map():
    class MockException(Exception):
        pass

    assert Try.of(lambda: True).map(lambda x: x).get() == True
    assert Try.of(lambda: 'test').map(lambda x: x).get() == 'test'
    assert Try.of(lambda: (1, 2, 3)).map(lambda x: len(x)).get() == 3
    assert Try.of(lambda: (1, 2, 3)).map(lambda x: len(x) + 1).get() == 4
    assert Try.of(lambda: 2).map(lambda x: x * x).get() == 4

    assert Try.of(lambda: 2 / 0).map(lambda x: x * x).get() == 2/0
    assert Try.of(lambda: 2 / 0).map(lambda x: x * x).is_success == False

   

# Generated at 2022-06-24 00:25:47.807160
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).\
        filter(lambda x: True).\
        get() == 1
    assert Try(1, True).\
        filter(lambda x: False).\
        get_or_else(None) is None
    assert Try(1, False).\
        filter(lambda x: True).\
        get_or_else(None) is None
    assert Try(1, False).\
        filter(lambda x: False).\
        get_or_else(None) is None



# Generated at 2022-06-24 00:25:51.006750
# Unit test for constructor of class Try
def test_Try():
    is_try = lambda monad: isinstance(monad, Try)
    is_try.__name__ = 'is_try'

    assert_that(Try(True, True), is_try())


# Generated at 2022-06-24 00:25:55.853719
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(2, False) == Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, True)



# Generated at 2022-06-24 00:26:04.416858
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 2+2, None).bind(lambda x: Try.of(lambda: str(x))).value == '4'
    assert not Try.of(lambda: 2+2, None).bind(lambda x: Try.of(lambda: str(x))).is_success
    assert Try.of(lambda: int('a'), None).bind(lambda x: Try.of(lambda: str(x))).value == 'a'
    assert not Try.of(lambda: int('a'), None).bind(lambda x: Try.of(lambda: str(x))).is_success


# Generated at 2022-06-24 00:26:14.507521
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 2).get() == 2
    assert Try.of(lambda: 2 / 0).get() == ZeroDivisionError
    assert Try.of(lambda: [1, 2, 3])\
        .bind(lambda l: Try.of(lambda: l[0])).get() == 1
    assert Try.of(lambda: "\n").bind(lambda l: Try.of(lambda: l[0])).get() == '\n'
    assert Try.of(lambda: '\n').bind(lambda l: Try.of(lambda: l[0])).get() == '\n'
    assert Try.of(lambda: "\n").bind(lambda l: Try.of(lambda: l[0]))\
        .filter(lambda l: l == "\n").get() == '\n'

# Generated at 2022-06-24 00:26:19.152789
# Unit test for constructor of class Try
def test_Try():
    value = 18
    assert Try(value, True) == Try(value, True)
    assert Try(value, False) == Try(value, False)
    assert Try(value, False) != Try(value, True)



# Generated at 2022-06-24 00:26:22.311389
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Given:
    - Successfully Try with value 1
    When:
    - Bind function on Try
    Then:
    - Returns successfully Try with value 2
    """
    assert Try(1, True).bind(lambda x: Try(x+1, True)) == Try(2, True)


# Generated at 2022-06-24 00:26:31.421608
# Unit test for method map of class Try
def test_Try_map():
    def identity(x):
        return x

    def add_one(x):
        return x + 1

    def can_raise(x):
        if x == 0:
            raise ValueError('x can\'t be zero')
        return True

    assert Try(2, True).map(identity) == Try(2, True)
    assert Try(2, True).map(add_one) == Try(3, True)
    assert Try(2, True).map(can_raise) == Try(True, True)
    assert Try(0, True).map(can_raise) == Try(ZeroDivisionError('integer division or modulo by zero'), False)



# Generated at 2022-06-24 00:26:40.097541
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_case(args, expected_output, test_description):
        print(test_description)
        print('Args: {}'.format(args))

        def fail_callback(greeting):
            print(greeting)

        output = Try(args[0], args[1]).on_fail(fail_callback)

        print('Expected output: {}'.format(expected_output))
        print('Actual output: {}'.format(output))

        try:
            assert output == expected_output
            print('Test pass.')
        except Exception as e:
            print('Test fail.\n{}'.format(e))

        print()

    test_case(('hello', True), Try('hello', True), 'Given argument is a successful monad')

# Generated at 2022-06-24 00:26:44.081820
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try('test', True)
    try_2 = Try('test', True)
    try_3 = Try('test_2', True)
    try_4 = Try('test', False)

    assert try_1 == try_2
    assert not (try_1 == try_3)
    assert not (try_1 == try_4)


# Generated at 2022-06-24 00:26:54.703144
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def some_fn(a, b):
        try:
            return int(a) / int(b)
        except:
            return Try(None, False)

    def fail_callback(value):
        raise Exception('Test fail')

    assert Try.of(some_fn, 1, 2) == Try(0.5, True)
    assert Try.of(some_fn, 1, 2).on_fail(fail_callback) == Try(0.5, True)
    assert Try.of(some_fn, 1, 0).on_fail(fail_callback) == Try(None, False)


if __name__ == '__main__':  # pragma: no cover
    test_Try_on_fail()

# Generated at 2022-06-24 00:27:01.883007
# Unit test for method filter of class Try
def test_Try_filter():
    # Example 1: filterer returns True
    test_try = Try(lambda a: a, True).filter(lambda fn: fn(10) == 10)
    assert test_try == Try(lambda a: a, True)

    # Example 2: filterer returns False
    test_try = Try(lambda a: a, True).filter(lambda fn: fn(10) == 12)
    assert test_try == Try(lambda a: a, False)

    # Example 3: filterer returns False and try is not successfully
    test_try = Try(lambda a: a, False).filter(lambda fn: fn(10) == 12)
    assert test_try == Try(lambda a: a, False)


# Generated at 2022-06-24 00:27:03.700756
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:27:09.021814
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def test_function(value):
        return value + 1

    expected = Try(2, True)
    actual = Try(1, True).map(test_function)

    assert expected == actual
    print('Monad Try with value 1 is successfully after map applied '
          'with test_function. Expected:{}, Actual:{}'.format(expected, actual))

# Generated at 2022-06-24 00:27:17.219599
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    print('test_Try_filter')

    def positive(x):
        return x > 0

    def negative(x):
        return x < 0

    test_data = [Try(None, False), Try(1, True), Try(0, True), Try(-1, True)]
    expected_value = [False, True, False, False]

    for data, expected in zip(test_data, expected_value):
        result = data.filter(positive)
        assert result.is_success == expected
        result = data.filter(negative)

# Generated at 2022-06-24 00:27:22.756011
# Unit test for method map of class Try
def test_Try_map():
    value = 'success'

    def mapper(value):
        return value + value

    success = Try.of(lambda: value, )
    assert success.map(mapper) == Try('successsuccess', True)

    def raise_exception():
        raise ValueError('It\'s error')

    not_success = Try.of(raise_exception, )
    assert success.map(mapper) == Try('successsuccess', True)
    assert not_success.map(mapper) == not_success

if __name__ == '__main__':  # pragma: no cover
    test_Try_map()

# Generated at 2022-06-24 00:27:26.934883
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda x: x)(1).get_or_else(10) == 1
    assert Try.of(lambda: 1 / 0)()\
        .on_fail(lambda err: print(err))\
        .get_or_else(10) == 10



# Generated at 2022-06-24 00:27:32.595098
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 'success',).bind(lambda _: Try.of(lambda: 'success')) == Try('success', True)
    assert Try.of(lambda: 'success',).bind(lambda _: Try.of(lambda: 1/0)) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1/0,).bind(lambda _: Try.of(lambda: 'success')) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:27:42.541946
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda x: x, True).map(lambda x: not x) == Try(False, True)
    assert Try.of(lambda x: x, True).map(lambda x: x) == Try(True, True)
    assert Try.of(lambda x: int(x), '1').map(lambda x: x + 1) == Try(2, True)
    assert Try.of(lambda x: x, True).map(lambda x: int(x)) == Try(True, True)
    assert Try.of(lambda x: 10 / x, 0).map(lambda x: x + 1) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda x: int(x), 'a').map(lambda x: x + 1) == Try(ValueError(), False)


# Generated at 2022-06-24 00:27:47.558099
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # type: () -> ()
    """
    Function tests on_fail method of class Try.
    """
    # when call on_fail with not successfully Try, call fail_callback and return self

# Generated at 2022-06-24 00:27:51.805072
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def test_binder(value):
        return Try(value ** 2, True)

    def test_binder_with_exception(value):
        return Try(value ** 2, False)

    try_1 = Try(100, True)
    try_2 = try_1.bind(test_binder)
    assert try_2 == Try(10000, True)

    try_3 = try_1.bind(test_binder_with_exception)
    assert try_3 == Try(10000, False)

    try_3 = try_3.bind(None)
    assert try_3 == Try(10000, False)

# Generated at 2022-06-24 00:27:56.374504
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    test_fail = Try(True, False) 

    def mock_on_fail_true_assert(value):
        assert not value

    test_fail.on_fail(mock_on_fail_true_assert)


# Generated at 2022-06-24 00:28:00.909659
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception('test'), False)) == 'Try[value=test, is_success=False]'


# Generated at 2022-06-24 00:28:13.072300
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test method on_fail of class Try when functional of binded
    method raise exception.

    :returns: None
    """
    test_value = 'test'

    @strict_spec
    def binder(fn: Callable) -> Try:
        """
        for test_Try_on_fail unit test

        :params fn: function to apply and return Try
        :type fn: Function(A) -> Try[A]
        :returns: Try, not successfully when function raise exception
        :rtype: Try[A]
        """
        return Try.of(fn)


# Generated at 2022-06-24 00:28:20.385023
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    def filterer(value):
        return True

    # WHEN
    result = Try(True, True).filter(filterer)

    # THEN
    assert result == Try(True, True)

    # GIVEN
    def filterer(value):
        return False

    # WHEN
    result = Try(True, True).filter(filterer)

    # THEN
    assert result == Try(True, False)



# Generated at 2022-06-24 00:28:22.275689
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-24 00:28:27.877807
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def f(x):
        return x+1

    def g(x):
        if x < 5:
            raise ValueError
        return x

    assert Try.of(f, 1).map(f) == Try(3, True)
    assert Try.of(g, 5).map(f) == Try(6, True)
    assert Try.of(g, 2).map(f) == Try(ValueError(), False)


# Generated at 2022-06-24 00:28:32.183786
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda x: 1 / x, 1).on_fail(lambda x: print('{}'.format(x))) == Try(1, True)
    assert Try.of(lambda x: 1 / x, 0).on_fail(lambda x: print('{}'.format(x))) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:28:35.671717
# Unit test for method on_success of class Try
def test_Try_on_success():

    def test(value):
        assert value == "ok"

    r = Try("ok", True)
    assert r.on_success(test) == Try("ok", True)
    r = Try("fail", False)
    assert r.on_success(test) == Try("fail", False)


# Generated at 2022-06-24 00:28:41.373572
# Unit test for method on_fail of class Try

# Generated at 2022-06-24 00:28:46.066972
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
