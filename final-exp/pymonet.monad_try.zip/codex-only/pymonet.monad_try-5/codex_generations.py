

# Generated at 2022-06-24 00:18:40.944930
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-24 00:18:46.228596
# Unit test for method get of class Try
def test_Try_get():
    try_ = Try(42, True)
    assert try_.get() == 42, "Try[value=42, is_success=True].get() == 42"
    try_ = Try(42, False)
    assert try_.get() == 42, "Try[value=42, is_success=True].get() == 42"


# Generated at 2022-06-24 00:18:51.856029
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert_that(Try.of(lambda: 1, "").get_or_else(2), equal_to(1))
    assert_that(Try.of(lambda: 1/0, "").get_or_else(2), equal_to(2))


# Generated at 2022-06-24 00:18:58.008490
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test method bind of monad Try.
    """
    # Case when we have exception
    obj1 = Try.of(lambda: x/0, 0)
    obj2 = obj1.bind(lambda x: Try.of(lambda: x + 1, x))
    assert obj2.value == ZeroDivisionError
    assert obj2.is_success == False

    # Case when we don't have exception
    obj1 = Try.of(lambda: 5, 0)
    obj2 = obj1.bind(lambda x: Try.of(lambda: x + 1, x))
    assert obj2.value == 6
    assert obj2.is_success == True

if __name__ == '__main__':
    test_Try_bind()

# Generated at 2022-06-24 00:19:04.754393
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test for method bind of class Try.
    Method bind is run function with value.
    When function returns successfully Try, method returns this Try.
    When function raises exception, method returns this exception in not successfully Try

    :returns: Nothing
    :rtype: None
    """
    def safe_int(value):
        try:
            return int(value)
        except Exception:
            raise Exception("Not a number.")

    # Case 1: int("1") is not raise exception,
    #         then result is successfully Try with value 1
    assert Try(1, True) == Try.of(safe_int, "1").bind(lambda x: Try.of(lambda y: y + 1, x))

    # Case 2: int("s") is raise exception,
    #         then result is unsuccessfully Try with exception "Not a number.\n

# Generated at 2022-06-24 00:19:05.909034
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5



# Generated at 2022-06-24 00:19:12.502841
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)
    assert Try(None, True) != Try(1, True)
    assert Try(1, False) != Try(None, False)


# Generated at 2022-06-24 00:19:22.758566
# Unit test for method bind of class Try
def test_Try_bind():
    # GIVEN
    value_1 = 1
    value_2 = 2
    value_default = 3

    @functools.lru_cache()
    def binder_1(x):
        return Try.of(lambda y: y + value_1, x)

    @functools.lru_cache()
    def binder_2(x):
        return Try.of(lambda y: y + value_2, x)

    # WHEN
    result = Try.of(lambda: 1, ).bind(binder_1).bind(binder_2).get_or_else(value_default)

    # THEN
    assert (result == value_1 + value_2)
    assert (binder_1.cache_info().hits == 1)

# Generated at 2022-06-24 00:19:30.113099
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    s_result = 'Try[value=1, is_success=True]'
    assert str(Try(1, True)) == s_result
    f_result = 'Try[value=Exception(\'a\',), is_success=False]'
    assert str(Try(Exception('a'), False)) == f_result


# Generated at 2022-06-24 00:19:37.549254
# Unit test for method bind of class Try
def test_Try_bind():
    def get_user_name():
        return 'User Name'

    def find_user(name: str) -> Try[str]:
        return Try(name, name != 'Unknown')

    assert Try(get_user_name(), True).bind(find_user) == Try(get_user_name(), True)
    assert Try(get_user_name(), False).bind(find_user) == Try(get_user_name(), False)



# Generated at 2022-06-24 00:19:40.987168
# Unit test for constructor of class Try
def test_Try():
    res = Try('res', True)
    assert res.is_success is True
    assert res.value == 'res'

    err = Try('err', False)
    assert err.is_success is False
    assert err.value == 'err'


# Generated at 2022-06-24 00:19:46.576007
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(0, True)) == 'Try[value=0, is_success=True]'\
        and str(Try(0, False)) == 'Try[value=0, is_success=False]'\
        and str(Try(Exception('err'), False)) == 'Try[value=err, is_success=False]'



# Generated at 2022-06-24 00:19:49.198246
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: x) == Try(1, True)
    assert Try(1, False).on_success(lambda x: x) == Try(1, False)


# Generated at 2022-06-24 00:19:52.990881
# Unit test for constructor of class Try
def test_Try():
    try_obj = Try(10, True)

    assert try_obj.value == 10
    assert try_obj.is_success == True


# Generated at 2022-06-24 00:19:58.148135
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    a = Try(1, True)
    b = Try(1, True)
    c = Try(1, False)
    d = Try(2, True)
    e = Try(2, False)

    assert a == b
    assert a != c
    assert a != d
    assert a != e

    assert c != d
    assert c != e

    assert d != e



# Generated at 2022-06-24 00:20:02.801585
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    # given
    def fn(a, b):
        return a + b

    # and
    a = 1
    b = 2

    # when
    result = Try.of(fn, a, b)

    # then
    assert result == Try(3, True)



# Generated at 2022-06-24 00:20:04.522368
# Unit test for method map of class Try
def test_Try_map():
    def add(x, y):
        return x + y

    tryResult = Try.of(add, 1, 2)
    tryResultMapped = tryResult.map(lambda x: x - 1)
    assert tryResult.value == 3
    assert tryResultMapped.value == 2


# Generated at 2022-06-24 00:20:05.845124
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-24 00:20:09.276048
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(value):
        return Try(value + 1, True)
    
    assert Try(0, True).bind(binder) == Try(1, True)
    assert Try(0, False).bind(binder) == Try(0, False)



# Generated at 2022-06-24 00:20:12.913116
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 3).on_fail(lambda e: print(e)) == Try(3, True)
    assert Try.of(lambda: 3 / 0).on_fail(lambda e: print(e)) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:20:20.344617
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test method bind of class Try.
    """
    # arrange
    def fn_with_exception(value):  # pragma: no cover
        raise Exception('Error in function')

    # act
    maybe = Try.of(fn_with_exception, 'exception_value')
    binded = maybe.bind(lambda x: Try('', True))

    # asserts
    assert binded == Try('', False)


# Generated at 2022-06-24 00:20:21.798682
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2


# Generated at 2022-06-24 00:20:26.701828
# Unit test for method on_success of class Try
def test_Try_on_success():
    # Case: try object is successfully and call on_success method
    try_object = Try(10, True)
    try_object.on_success(lambda x: print(x))
    # Expected: output '10'

    # Case: try object is not successfully and call on_success method
    try_object = Try(10, False)
    try_object.on_success(lambda x: print(x))
    # Expected: output nothing


# Generated at 2022-06-24 00:20:31.244160
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    The Try control gives us the ability write safe code
    without focusing on try-catch blocks in the presence of exceptions.
    """

    # Arrange
    def throw_exception():
        raise Exception("error")

    def on_fail_str(e):
        assert isinstance(e, Exception)
        assert e == "error"

    # Act
    _try = Try.of(throw_exception)
    _try.on_fail(on_fail_str)

    # Assert



# Generated at 2022-06-24 00:20:36.790640
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    error = None

    def fail_callback(e):
        nonlocal error
        error = e

    assert error is None

    Try(1/0, False).on_fail(fail_callback)

    assert error is not None
    assert isinstance(error, ZeroDivisionError)
    assert 'division by zero' == str(error)



# Generated at 2022-06-24 00:20:39.703285
# Unit test for method map of class Try
def test_Try_map():
    def adder(x):
        return x + 1
    assert Try.of(adder, 5).map(adder) == Try(7, True)
    assert Try.of(adder, '5').map(adder) == Try(adder('5'), False)



# Generated at 2022-06-24 00:20:45.535670
# Unit test for constructor of class Try
def test_Try():
    try_success = Try(10, True)

    fail_type_error = TypeError('You have a type error')
    try_fail = Try(fail_type_error, False)

    assert try_success == Try(10, True)
    assert try_fail == Try(fail_type_error, False)

    assert str(try_success) == 'Try[value=10, is_success=True]'
    assert str(try_fail) == 'Try[value=You have a type error, is_success=False]'


# Generated at 2022-06-24 00:20:50.057355
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    class MyException(Exception):
        pass

    exception = MyException()

    assert Try(exception, False).on_fail(lambda e: e).value == exception
    assert Try(exception, False).on_fail(lambda e: e) == Try(exception, False)
    assert Try(1, True).on_fail(lambda e: e) == Try(1, True)


# Generated at 2022-06-24 00:20:52.071851
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:20:54.427361
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def check(value):
        assert value == ValueError

    t = Try.of(int, 'a')
    t.on_fail(check)


# Generated at 2022-06-24 00:21:02.782351
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    success_try1 = Try(12, True)
    success_try2 = Try(12, True)
    fail_try1 = Try(12, False)
    fail_try2 = Try(12, False)
    another_try = Try(18, True)
    assert success_try1 == success_try1
    assert success_try1 == success_try2
    assert fail_try1 == fail_try1
    assert fail_try1 == fail_try2
    assert not success_try1 == another_try
    assert not success_try1 == fail_try1
    assert not fail_try1 == success_try1
    assert not fail_try1 == another_try


# Generated at 2022-06-24 00:21:09.361987
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def plus_one(n):
        return n + 1

    def plus_one_safely(n):
        return Try.of(plus_one, n)

    assert plus_one_safely(10).get_or_else(0) == 11
    assert plus_one_safely(0).get_or_else(0) == 1
    assert plus_one_safely('a').get_or_else(0) == 0


# Generated at 2022-06-24 00:21:12.984764
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        # raise error
        raise ValueError
    except Exception as e:
        # call method on_fail
        Try(e, False).on_fail(lambda value: print('raise error'))


if __name__ == '__main__':
    test_Try_on_fail()

# Generated at 2022-06-24 00:21:15.144780
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    test_result = False
    Try(1, True).on_fail(lambda e: setattr(test_result, "test_result", False))
    assert test_result is False
    Try(1, False).on_fail(lambda e: setattr(test_result, "test_result", True))
    assert test_result is True

# Generated at 2022-06-24 00:21:19.662836
# Unit test for method bind of class Try
def test_Try_bind():
    def fn(x):
        return Try(x + 1, True)

    assert Try(1, True).bind(fn) == Try(2, True)
    assert Try(1, False).bind(fn) == Try(1, False)


# Generated at 2022-06-24 00:21:24.653786
# Unit test for method on_success of class Try
def test_Try_on_success():
    f = lambda x: x + 1
    assert Try(5, True).map(f).value == 6
    assert Try(5, False).map(f).value == 5

    assert Try(5, True).on_success(f).value == 5
    assert Try(5, False).on_success(f).value == 5



# Generated at 2022-06-24 00:21:27.156232
# Unit test for method on_success of class Try
def test_Try_on_success():
    def on_success(res):
        assert res == 'test'

    def on_fail(res):
        assert False

    assert Try(None, False).on_success(on_success).on_fail(on_fail) == Try(None, False)
    assert Try('test', True).on_success(on_success).on_fail(on_fail) == Try('test', True)


# Generated at 2022-06-24 00:21:28.832413
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(101, True).get_or_else(1) == 101
    assert Try(101, False).get_or_else(1) == 1

assert test_Try_get_or_else()



# Generated at 2022-06-24 00:21:32.796838
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(NotImplementedError('exception message'), False)) == 'Try[value=NotImplementedError(\'exception message\'), is_success=False]'


# Generated at 2022-06-24 00:21:36.309497
# Unit test for constructor of class Try
def test_Try():
    try_1 = Try(9, True)
    assert try_1 == Try(9, True)
    try_2 = Try(Exception('test'), False)
    assert try_2 == Try(Exception('test'), False)


# Generated at 2022-06-24 00:21:42.407131
# Unit test for method on_success of class Try
def test_Try_on_success():
    success = Try.of(lambda: 5,())
    success.on_success(lambda x: print(x))

# Generated at 2022-06-24 00:21:47.444524
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1, []).get_or_else(2) == 1
    assert Try.of(lambda: 1 / 0, []).get_or_else(2) == 2
    assert Try.of(lambda: 1, []).get_or_else(Try.of(lambda: 2, [])) == 1
    assert Try.of(lambda: 1 / 0, []).get_or_else(Try.of(lambda: 2, [])) == 2


# Generated at 2022-06-24 00:21:55.300761
# Unit test for method bind of class Try
def test_Try_bind():
    def to_int(text):
        return int(text)

    def div(dividend, divider):
        return dividend / divider

    def safe_div(dividend, divider):
        return Try.of(div, dividend, divider)

    def safe_to_int(text):
        try:
            return Try(int(text), True)
        except Exception as e:
            return Try(e, False)

    def test_safe_div():
        assert safe_div(10, 2) == Try(5, True)
        assert safe_div(10, 0).is_success == False
        assert safe_div(10, 0).value == ZeroDivisionError

    def test_safe_to_int():
        assert safe_to_int('10') == Try(10, True)
        assert safe_to

# Generated at 2022-06-24 00:22:03.354211
# Unit test for method map of class Try
def test_Try_map():
    def func(value: int) -> int:
        return value**2

    assert Try(1, True).map(func) == Try(1, True).map(func)
    assert Try(1, True).map(func) == Try(1, True).map(func)
    assert Try(None, True).map(func) == Try(None, True).map(func)
    assert Try(None, True).map(func) == Try(None, True).map(func)
    assert Try(None, False).map(func) == Try(None, False).map(func)
    assert Try(None, False).map(func) == Try(None, False).map(func)



# Generated at 2022-06-24 00:22:11.806980
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_function(x: int, y: int) -> int:
        return x % y

    test_try_1 = Try.of(test_function, 5, 2)

    assert test_try_1.on_fail(lambda _: 'fail') == test_try_1
    assert test_try_1.on_success(lambda _: 'success') == test_try_1

    test_try_2 = Try.of(test_function, 5, 0)

    assert test_try_2.on_fail(lambda _: 'fail') == 'fail'
    assert test_try_2.on_success(lambda _: 'success') != 'success'


# Generated at 2022-06-24 00:22:19.084424
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, True).value == 1
    assert Try(1, True).is_success == True
    assert Try(1, False) == Try(1, False)
    assert Try(1, False).value == 1
    assert Try(1, False).is_success == False


# Generated at 2022-06-24 00:22:21.332514
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(123, True)) == 'Try[value=123, is_success=True]'
    assert str(Try('abc', False)) == 'Try[value=abc, is_success=False]'


# Generated at 2022-06-24 00:22:27.813528
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(lambda x: x, True).on_success(lambda x: x('foo')).get() == 'foo'
    assert Try(123, True).on_success(lambda x: x).get() == 123
    assert Try(None, True).on_success(lambda x: x).get() is None



# Generated at 2022-06-24 00:22:33.305655
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(4, True)) == 'Try[value=4, is_success=True]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try('test', False)) == 'Try[value=test, is_success=False]'


# Generated at 2022-06-24 00:22:39.689657
# Unit test for method map of class Try
def test_Try_map():
    def mapper(x):
        return x * 2

    def mapper2(x):
        return x / 2

    assert Try(5, True).map(mapper).get() == 10
    assert Try(5, False).map(mapper).get() == 5
    assert Try(6, True).map(mapper).map(mapper2).get() == 6

    def mapper3(x):
        return x + " string"

    assert Try("output: ", True).map(mapper3).get() == "output:  string"



# Generated at 2022-06-24 00:22:47.399012
# Unit test for constructor of class Try
def test_Try():
    assert Try(5, True) == Try(5, True)
    assert Try(5, True) != Try(4, True)
    assert Try(5, True) != Try(5, False)
    assert Try(5, False) != Try(4, False)
    assert Try(5, False) != Try(5, True)
    assert Try(5, True) != Try(5, True, 5)


# Generated at 2022-06-24 00:22:50.788425
# Unit test for method bind of class Try
def test_Try_bind():
    abc = 'abc'

    # successful bind
    assert Try.of(lambda a: a, abc).bind(lambda x: Try(x + 'def', True)) == Try(abc + 'def', True)
    # unsuccessful bind
    assert Try.of(lambda a: a, abc).bind(lambda x: Try(x + 'def', False)) == Try(abc, True)

# Generated at 2022-06-24 00:23:00.223416
# Unit test for method filter of class Try
def test_Try_filter():
    # Test successfully
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x > 0).filter(lambda x: x < 2) == Try(1, True)

    # Test fail
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, True).filter(lambda x: x < 0).filter(lambda x: x < 2) == Try(1, False)

    # Test not successfully monad
    assert Try(Exception(), False).filter(lambda x: x > 0) == Try(Exception(), False)
    assert Try(Exception(), False).filter(lambda x: x > 0).filter(lambda x: x < 2) == Try(Exception(), False)

# Unit test

# Generated at 2022-06-24 00:23:04.479590
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, False) == Try(2, True)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, False) == Try(2, False)
    assert Try(1, False) == Try(1, False)
    assert not Try(1, True) == "test"


# Generated at 2022-06-24 00:23:09.951488
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(Exception('fail'), False).get_or_else(0) == 0


# Generated at 2022-06-24 00:23:19.116346
# Unit test for method filter of class Try
def test_Try_filter():
    # Unit test when function not raise exception
    def function_with_no_exception(arg):
        return arg

    assert Try.of(function_with_no_exception, 1).filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(function_with_no_exception, 1).filter(lambda x: x < 0) == Try(1, False)

    # Unit test when function not raise exception
    def function_that_raise(arg):
        raise Exception('exception')

    assert Try.of(function_that_raise, 1).filter(lambda x: x > 0) == Try('exception', False)


# Generated at 2022-06-24 00:23:23.610858
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '42').filter(lambda a: a == 42) == Try(42, True)
    assert Try.of(int, '42').filter(lambda a: a == 43) == Try(42, False)
    assert Try.of(int, 'test').filter(lambda a: a == 42) == Try('test', False)


# Generated at 2022-06-24 00:23:25.894296
# Unit test for method get of class Try
def test_Try_get():
    def fn1():
        raise Exception('Ups')

    def fn2(x):
        return x

    assert Try.of(fn1).get() == Exception('Ups')
    assert Try.of(fn2, 2).get() == 2


# Generated at 2022-06-24 00:23:27.990949
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(ex):
        assert type(ex) == ValueError

    Try.of(lambda: 3 / 0, ()).on_fail(fail_callback)

# Generated at 2022-06-24 00:23:35.416923
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1, None) == Try(1, True)
    assert Try.of(lambda: 1, None).bind(lambda x: Try(x + 1, True)) == Try(2, True)
    assert Try.of(lambda: 1, None).bind(None) == Try(1, True)
    assert Try.of(None, 1).bind(lambda x: Try(x + 1, True)) == Try(None, False)
    assert Try.of(lambda: 1, None).bind(lambda x: x + 1) == Try(1, True)


# Generated at 2022-06-24 00:23:41.325647
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(x: int) -> Try[int]:
        return Try(x + 1, True)
    try_x = Try(1, True)
    try_nx = Try(1, False)
    assert(try_x.bind(binder) == Try(2, True))
    assert(try_nx.bind(binder) == Try(1, False))


# Generated at 2022-06-24 00:23:42.216323
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('value', True)) == 'Try[value=value, is_success=True]'



# Generated at 2022-06-24 00:23:47.465057
# Unit test for method filter of class Try
def test_Try_filter():
    number = 10
    assert Try(10, True).filter(lambda x: x < number) == Try(10, True)
    assert Try("10", True).filter(lambda x: x < number) == Try("10", False)
    assert Try(10, False).filter(lambda x: x < number) == Try(10, False)



# Generated at 2022-06-24 00:23:56.179566
# Unit test for method map of class Try
def test_Try_map():
    def _f(x: int) -> int:
        return x ** x

    def _g(x: str) -> int:
        return len(x)

    def _h(x: float, y: float) -> float:
        return x + y

    assert Try.of(_f, 2) == Try(4, True)
    assert Try.of(_f, 2).map(_g) == Try(2, True)
    assert Try.of(_f, 2).map(_g).map(_h) == Try(4, True)
    assert type(Try.of(_f, 2).map(_g).map(_h)) is Try
    assert Try.of(_f, 2).map(_g).map(_h) != Try.of(_f, 2)
    assert Try.of(_f, 2).map(_g).map(_h) != Try

# Generated at 2022-06-24 00:24:01.968043
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    from assertpy import assert_that

    def function_that_raises_exception(arg):
        raise ZeroDivisionError('error')

    assert_that(Try.of(function_that_raises_exception, 'any').get_or_else('default')).is_equal_to('default')
    assert_that(Try.of(lambda arg: arg, 'example').get_or_else('default')).is_equal_to('example')

# Generated at 2022-06-24 00:24:06.004852
# Unit test for method get of class Try
def test_Try_get():
    def square(x):
        return pow(x, 2)

    assert (Try.of(square, 3).get()) == 9
    assert Try.of(lambda x: pow(x, 2), 3).get() == 9
    assert Try.of(square, 'a').get() == 'a'


# Generated at 2022-06-24 00:24:08.310610
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception(), False)) == 'Try[value=Exception(), is_success=False]'


# Generated at 2022-06-24 00:24:11.965141
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(print).get() == 1
    assert Try(None, True).on_fail(print).get() is None
    assert Try([1,2,3], True).on_fail(print).get() == [1,2,3]
    try: assert Try(Exception, False).on_fail(print).get()
    except AssertionError: pass



# Generated at 2022-06-24 00:24:14.806148
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)

    assert Try(1, True).is_success
    assert not Try(1, False).is_success
    assert not Try(1, False).get()

# Unit tests for function of Try class

# Generated at 2022-06-24 00:24:19.534896
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(10, True) == Try(10, True)
    assert Try(10, True) != Try(20, True)
    assert Try(10, True) != Try(10, False)
    assert Try(20, True) != Try(10, False)
    assert Try(20, False) == Try(20, False)


# Generated at 2022-06-24 00:24:22.660951
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    error = ''
    try:
        raise Exception('error')
    except Exception as e:
        error = e

    assert Try(error, False).on_fail(lambda e: e).get() == error



# Generated at 2022-06-24 00:24:26.051402
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('1', True)) == 'Try[value=1, is_success=True]'
    assert str(Try('1', False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:24:35.827547
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    from src.utils.head import head_

    def test_method(function_to_test, input_values, expected_results):
        """
        Generic unit test. Takes function_to_test, input_values and expected_results.
        Call function_to_test with input values, compare results with expected results.

        :params function_to_test: function to test
        :type function_to_test: Function
        :params input_values: input values to function_to_test
        :type input_values: List[List]
        :params expected_results: expected results from function_to_test
        :type expected_results: List
        :returns: True when unit test successfully depth. False when not.
        :rtype: Boolean
        """
        results = []


# Generated at 2022-06-24 00:24:37.293397
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(1, False)

# Generated at 2022-06-24 00:24:47.250548
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1, None) == Try(1, True)
    assert Try.of(lambda: 1, None).get() == 1

    assert Try.of(lambda: list(), None) == Try([], True)
    assert Try.of(lambda: list(), None).get() == []

    assert Try.of(lambda: None, None) == Try(None, True)
    assert Try.of(lambda: None, None).get() is None

    assert Try.of(lambda: dict(), None) == Try({}, True)
    assert Try.of(lambda: dict(), None).get() == {}

    assert Try.of(lambda: 'a', None) == Try('a', True)
    assert Try.of(lambda: 'a', None).get() == 'a'


# Generated at 2022-06-24 00:24:58.003498
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(2, True).bind(lambda v: Try(v + 3, True)) == Try(5, True)
    assert Try(None, False).bind(lambda v: Try(v + 3, True)) == Try(None, False)
    assert Try(2, True).map(lambda v: v + 3).get() == 5
    assert Try.of(lambda v: v + 3, 2) == Try(5, True)
    assert Try.of(lambda v: v / 0, 2) == Try(ZeroDivisionError, False)
    assert Try.of(lambda v: v / 0, 2).on_fail(lambda e: 42) == Try(ZeroDivisionError, False)
    assert Try.of(lambda v: v / 0, 2).on_success(lambda x: 5) == Try(ZeroDivisionError, False)


# Generated at 2022-06-24 00:25:00.851253
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try
    """
    assert Try(5, True).get_or_else(3) == 5
    assert Try(5, False).get_or_else(3) == 3

# Generated at 2022-06-24 00:25:06.917203
# Unit test for method bind of class Try
def test_Try_bind():
    def f1(x):
        if x is 0:
            raise Exception('f1({})'.format(x))
        return x * 10

    def f2(x):
        return Try.of(f1, x)

    assert f2(0) == Try(Exception('f1(0)'), False)
    assert f2(10) == Try(100, True)



# Generated at 2022-06-24 00:25:17.725578
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def sum(a, b):
        return a + b

    def sum_or_None(a, b):
        res = Try.of(sum, a, b)
        if a == 0 or b == 0:
            return Try(None, False)
        return res

    def print_int(i):
        print(i)

    def print_None(i):
        print("None")

    # Successfully
    # Should print 15 Try[value=Try[value=15, is_success=True], is_success=True]
    result = Try.of(sum, 5, 10).bind(lambda x: sum_or_None(x, 0)).on_success(lambda x: print(x.get()))
    print(result)

    # Not successfully
    # Should print None Try[value=

# Generated at 2022-06-24 00:25:21.702577
# Unit test for method get of class Try
def test_Try_get():
    """
    The get method return monad value.

    Cases:
    """
    test_data = [
        # success
        (True, 'Test Success'),
        # fail
        (False, 'Test Fail')
    ]

    for test_value in test_data:
        is_success, data = test_value
        try_instance = Try(data, is_success)
        assert try_instance.get() == data


# Generated at 2022-06-24 00:25:27.731371
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 1, ()).on_fail(lambda x: print(x)) == Try(1, True)

    def fail_fn():
        raise Exception('fail')

    assert Try.of(fail_fn, ()).on_fail(lambda x: print(x)) != Try(1, True)

# Generated at 2022-06-24 00:25:36.473572
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # create Successfully Try with value 'A'
    t = Try(Try.of(lambda x: 'A', 'A'), True).filter(lambda x: True)
    # successfully Try with value 'A' with filterer function returning True
    assert True == t.is_success
    assert 'A' == t.value

    t = Try(Try.of(lambda x: 'A', 'A'), True).filter(lambda x: False)
    # not successfully Try with value 'A' with filterer function returning False
    assert False == t.is_success
    assert 'A' == t.value

    t = Try(Try.of(lambda x: 'A', 'A'), False).filter(lambda x: False)
    # not successfully Try with value 'A' with filterer function returning False
    assert False

# Generated at 2022-06-24 00:25:41.191312
# Unit test for method map of class Try
def test_Try_map():
    assert Try(2, True).map(lambda x: x + 2) == Try(4, True)
    assert Try(2, True).map(lambda x: x + '2') == Try('22', True)
    assert Try(2, False).map(lambda x: x + 2) == Try(2, False)
    assert Try(2, False).map(lambda x: x + '2') == Try(2, False)


# Generated at 2022-06-24 00:25:45.231832
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1).map(lambda x: x + 1) == Try(2, True)
    assert Try.of(lambda: 1).map(lambda x: x / 0) == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(lambda: 3 / 0).map(lambda x: x + 1) == Try(ZeroDivisionError('division by zero'), False)



# Generated at 2022-06-24 00:25:55.516994
# Unit test for method __str__ of class Try
def test_Try___str__():
    def info_function(s):
        assert(s == 'Try[value=test, is_success=True]')
        print(s)

    assert(Try.of(lambda: 'test',).__str__() == 'Try[value=test, is_success=True]')
    assert(Try.of(lambda: 'test',).on_success(info_function) == Try('test', True))

    assert(Try.of(lambda: 'test',)\
        .filter(lambda v: type(v) == str)\
        .__str__() == 'Try[value=test, is_success=True]')
    assert(Try.of(lambda: 'test',)\
        .filter(lambda v: type(v) == int)\
        .__str__() == 'Try[value=test, is_success=False]')


# Generated at 2022-06-24 00:25:58.562777
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(e):
        raised = e
    raised = None
    Try.of(id, 1).on_fail(fail_callback)
    Try.of((lambda x: 1/0), 1).on_fail(fail_callback)
    assert raised is None
    Try.of((lambda x: 1/0), 1).on_fail(fail_callback)
    assert type(raised) is ZeroDivisionError

# Generated at 2022-06-24 00:26:02.016211
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try(2, True)
    assert Try(1, False) != Try('Error', False)


# Generated at 2022-06-24 00:26:12.929955
# Unit test for method bind of class Try
def test_Try_bind():
    def fn(x):
        if x > 0:
            return Try(x * x, True)
        return Try(0, False)

    assert Try(25, True) == Try.of(lambda x: x, 25).bind(lambda x: Try.of(fn, x)).get()
    assert Try(0, False) == Try.of(lambda x: x, -25).bind(lambda x: Try.of(fn, x)).get()
    assert Try(0, False) == Try.of(lambda x: x, "").bind(lambda x: Try.of(fn, x)).get()
    assert Try(0, False) == Try.of(lambda x: x, None).bind(lambda x: Try.of(fn, x)).get()

# Generated at 2022-06-24 00:26:21.373104
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Unit test for method bind of class Try

    :returns: Success or fail message
    :rtype: Boolean
    """
    def add_100(x):
        return Try(x + 100, True)

    def throw_exception(x):
        raise Exception(x)

    assert Try(5, True).bind(add_100) == Try(105, True)
    assert Try(5, True).bind(throw_exception) == Try(Exception(5), False)
    return True


# Generated at 2022-06-24 00:26:24.653074
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def success(value: int) -> int:
        return value

    def fail(value: int) -> int:
        raise AttributeError()

    assert Try.of(success, 2).on_fail(lambda value: print('fail')) == Try(2, True)
    assert Try.of(fail, 2).on_fail(lambda value: print('fail')) == Try(AttributeError(), False)


# Generated at 2022-06-24 00:26:30.247842
# Unit test for method on_success of class Try
def test_Try_on_success():
    args = [
        (Try.of(lambda: 1 + 2), lambda v: v),
        (Try.of(lambda: 1 / 0), lambda v: v),
    ]
    for t, fn in args:
        assert t.on_success(fn).is_success == t.is_success
        assert t.on_success(fn).get() == t.get()


# Generated at 2022-06-24 00:26:36.319292
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('abc', True)) == 'Try[value=abc, is_success=True]'
    assert str(Try('abc', False)) == 'Try[value=abc, is_success=False]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'


# Generated at 2022-06-24 00:26:40.154802
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-24 00:26:49.459684
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from unittest import TestCase, main
    import math
    import re

    class TryTest(TestCase):

        def test_Try_filter_ok(self):
            try_data = Try(2, True)
            try_data = try_data.bind(lambda x: Try.of(math.factorial, x))
            try_data = try_data.map(lambda x: str(x))
            try_data = try_data.filter(lambda x: re.search('[02468]$', x))

            expected = Try('2', True)

            self.assertEqual(try_data, expected)

        def test_Try_filter_ok_not(self):
            try_data = Try(3, True)

# Generated at 2022-06-24 00:26:53.345623
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(5, True) == Try(5, True)
    assert Try(ValueError(), False) == Try(ValueError(), False)

    assert Try(5, True) != Try(5, False)
    assert Try(5, True) != Try(ValueError(), False)



# Generated at 2022-06-24 00:26:58.577136
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda: '1', ).get_or_else('') == '1'
    assert Try.of(lambda: 2 / 0, ).get_or_else('') == ''
    assert Try.of(lambda: '1', ).get_or_else(lambda: '') == '1'
    assert Try.of(lambda: 2 / 0, ).get_or_else(lambda: '') == ''


# Generated at 2022-06-24 00:27:03.378816
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: print(x)) == Try(1, True)
    assert Try(1, False).on_fail(lambda x: print(x)) == Try(1, False)
    assert Try(Exception(), False).on_fail(lambda x: print(x.__class__.__name__)) == Try(Exception(), False)
    assert Try(Exception(), True).on_fail(lambda x: print(x.__class__.__name__)) == Try(Exception(), True)


# Generated at 2022-06-24 00:27:11.123445
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_success_int = Try(1, True)
    try_fail_int = Try(1, False)
    assert try_success_int == Try(1, True)
    assert not try_success_int == Try(1, False)
    assert not try_success_int == Try(2, True)
    assert not try_success_int == Try(2, False)
    assert not try_success_int == try_fail_int
    assert not try_fail_int == try_success_int

    try_success_str = Try('1', True)
    try_fail_str = Try('1', False)
    assert try_success_str == Try('1', True)
    assert not try_success_str == Try('1', False)
    assert not try_success_str == Try('2', True)

# Generated at 2022-06-24 00:27:15.366618
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    res = Try.of(int, 'a').on_fail(lambda e: print(e))
    assert res.get() == 'a'
    assert res.is_success == False

    res = Try.of(int, '1').on_fail(lambda e: print(e))
    assert res.get() == 1
    assert res.is_success == True


# Generated at 2022-06-24 00:27:17.821550
# Unit test for method map of class Try
def test_Try_map():
    assert Try(0, False).map(lambda x: x + 100) == Try(0, False)
    assert Try(0, True).map(lambda x: x + 100) == Try(100, True)


# Generated at 2022-06-24 00:27:24.511394
# Unit test for method __str__ of class Try
def test_Try___str__():
    # Given
    try_unit = Try(Unit(), True)
    try_none = Try(None, True)
    try_integer = Try(123, True)
    try_float = Try(12.3, True)
    try_string = Try('hello', True)
    try_list = Try([1, 2, 3], True)
    try_tuple = Try((1, 2, 3), True)
    try_dict = Try({'1': 1, '2': 2, '3': 3}, True)
    try_function = Try(lambda x: x + 1, True)
    try_object = Try({i: i ** 2 for i in range(1, 10)}, True)
    try_exception = Try(Exception(), False)

    # When
    try_unit_str = try_unit.__str__()


# Generated at 2022-06-24 00:27:28.031465
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: x) == Try(1, True)
    assert Try(1, False).on_fail(lambda x: x) == Try(1, False)


# Generated at 2022-06-24 00:27:28.707184
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1



# Generated at 2022-06-24 00:27:32.894483
# Unit test for method map of class Try
def test_Try_map():
    assert Try(17, True).map(lambda x: x + 1) == Try(18, True)
    assert Try(17, False).map(lambda x: x + 1) == Try(17, False)
    assert Try(Exception("test"), False).map(lambda x: x + 1) == Try(Exception("test"), False)


# Generated at 2022-06-24 00:27:36.269360
# Unit test for method map of class Try
def test_Try_map():
    inc = lambda x: x + 1
    assert Try.of(inc, 3).map(inc).get() == 5
    assert Try.of(inc, 0).map(inc).get() == 1
    assert Try.of(inc, -1).map(inc).get() == 0



# Generated at 2022-06-24 00:27:39.405952
# Unit test for method filter of class Try
def test_Try_filter():
    from pymonads.Either import Left
    l = Left(1)

    assert l.filter(lambda _: True).is_success == False
    assert l.filter(lambda _: False).is_success == False


# Generated at 2022-06-24 00:27:45.734978
# Unit test for method bind of class Try
def test_Try_bind():
    def divide(dividend: int, divisor: int) -> Try[int]:
        try:
            return Try(int(dividend / divisor), True)
        except Exception as e:
            return Try(e, False)

    result = Try.of(divide, 2, 0).bind(lambda value: divide(value, 0))
    assert result != Try(ZeroDivisionError(), False)

    result = Try.of(divide, 2, 0).bind(lambda value: divide(value, 2))
    assert result == Try(1, True)



# Generated at 2022-06-24 00:27:47.064407
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(2, False).get() == 2


# Generated at 2022-06-24 00:27:49.740615
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(True, True).on_success(lambda _: True) == Try(True, True)
    assert Try(None, True).on_success(lambda _: False) == Try(None, True)
    assert Try(False, False).on_success(lambda _: True) == T

# Generated at 2022-06-24 00:27:56.331490
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(-1, True).filter(lambda e: e > 0) == Try(-1, False)
    assert Try(1, True).filter(lambda e: e > 0) == Try(1, True)
    assert Try(1, False).filter(lambda e: e > 0) == Try(1, False)


# Generated at 2022-06-24 00:28:00.643258
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 123).get_or_else('test') == 123
    assert Try.of(lambda: raise_exception()).get_or_else('test') == 'test'



# Generated at 2022-06-24 00:28:02.826386
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(print) == Try(1, True)



# Generated at 2022-06-24 00:28:07.487096
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception('asd'), False) == Try(Exception('asd'), False)
    assert Try(1, True) != Try(0, True)


# Generated at 2022-06-24 00:28:12.017156
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    try_expr = Try(2, True)
    assert try_expr == Try(2, True)
    assert try_expr != Try(3, True)
    assert try_expr != Try(2, False)
    assert try_expr != Try(3, False)


# Generated at 2022-06-24 00:28:18.830807
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1).map(lambda x: 1 + x) == Try(2, True)
    assert isinstance(Try.of(lambda: 1).map(lambda x: 1 / x).get(), float)
    assert isinstance(Try.of(lambda: 0).map(lambda x: 1 / x).get(), Exception)
    assert Try.of(lambda: 10).map(lambda x: 0 / x).get() == 0



# Generated at 2022-06-24 00:28:25.322332
# Unit test for method on_success of class Try
def test_Try_on_success():
    def callback_success(a):
        return a * 2

    def callback_fail(a):
        return 'Error'

    assert Try(1, False).on_success(callback_success) == Try(1, False)
    assert Try('a', True).on_fail(callback_fail) == Try('a', True)
    assert Try(1, True).on_success(callback_success).value == 2

# Generated at 2022-06-24 00:28:28.895034
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(value):
        assert value == 1

    Try(1, False).on_fail(fail_callback)

# Generated at 2022-06-24 00:28:32.986180
# Unit test for method filter of class Try
def test_Try_filter():
    assert(Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True))
    assert(Try(2, True).filter(lambda x: x % 2 == 1) == Try(2, False))
    assert(Try(2, False).filter(lambda x: x % 2 == 0) == Try(2, False))



# Generated at 2022-06-24 00:28:34.902905
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) is 1
    assert Try(1, False).get_or_else(2) is 2


# Generated at 2022-06-24 00:28:38.654931
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def handler(exception):
        assert exception == 'Oops'

    assert Try.of(lambda: 1, None).on_fail(handler) == Try(1, True)
    assert Try.of(lambda: 1/0, None).on_fail(handler) == Try('Oops', False)
