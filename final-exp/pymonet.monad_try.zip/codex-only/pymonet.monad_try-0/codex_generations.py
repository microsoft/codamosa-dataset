

# Generated at 2022-06-24 00:18:51.779084
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(2, True) == Try(2, True)
    assert Try("hi", False) == Try("hi", False)
    assert Try("hi", True) != Try("hi", False)
    assert Try("hi", False) != Try("hi", True)
    assert Try("hi", True) != Try("no", True)
    assert Try("hi", False) != Try("no", False)


# Generated at 2022-06-24 00:18:55.098475
# Unit test for method on_success of class Try
def test_Try_on_success():
    def callback_success(x):
        assert x == 1

    def callback_fail(x):
        assert x == 2

    try_1 = Try(1, True)
    try_1.on_success(callback_success)

    try_2 = Try(2, False)
    try_2.on_success(callback_fail)


# Generated at 2022-06-24 00:19:02.154668
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    """
    Test constructor of class Try
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-24 00:19:03.821860
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try("test", False).get_or_else("test2") == "test2"
    assert Try("test", True).get_or_else("test2") == "test"


# Generated at 2022-06-24 00:19:08.673758
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 1 / 0, ()).on_fail(lambda _: None) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0, ()).on_fail(lambda _: None).is_success is False

    def t_fail(e):
        raise e
    try:
        Try.of(lambda: 1 / 0, ()).on_fail(t_fail)
    except Exception as e:
        assert e == ZeroDivisionError()



# Generated at 2022-06-24 00:19:12.345739
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda _: print('fail')).get() == 1
    assert Try(1, False).on_fail(print).get() == 1

# Generated at 2022-06-24 00:19:16.071935
# Unit test for method map of class Try
def test_Try_map():
    assert Try(value=3, is_success=True).map(lambda x: x * 3) == Try(9, True)
    assert Try(value=3, is_success=False).map(lambda x: x * 3) == Try(3, False)



# Generated at 2022-06-24 00:19:22.156718
# Unit test for method filter of class Try
def test_Try_filter():
    success_try = Try.of(lambda: 'Hello')
    fail_try = Try.of(lambda: 1/0)
    success_filter_try = success_try.filter(lambda value: True)
    fail_filter_try = success_try.filter(lambda value: False)
    assert success_filter_try == Try('Hello', True)
    assert fail_filter_try == Try('Hello', False)
    assert fail_try == Try(ZeroDivisionError('division by zero'), False)

# Generated at 2022-06-24 00:19:31.312255
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    from unittest import TestCase
    from unittest.mock import MagicMock

    try_instance = Try(10, True)

    mock_filterer = MagicMock()
    mock_filterer.side_effect = [True, False]

    try_instance.filter(mock_filterer)
    assert try_instance.is_success is True

    try_instance.filter(mock_filterer)
    assert try_instance.is_success is False

    try_instance = Try(10, False)
    try_instance.filter(mock_filterer)
    assert try_instance.is_success is False

    print('test_Try_filter success!')

# Generated at 2022-06-24 00:19:39.658643
# Unit test for method filter of class Try
def test_Try_filter():
    def test(x):  # pragma: no cover
        def even(n): return n % 2 == 0
        def succ(n): return n + 1

        # Map with lambda function
        thunk = Try.of(succ, 100).bind(lambda n: Try(n, True))
        assert thunk.filter(even) == Try(101, False)

        # Map with def function
        thunk = Try.of(succ, 100).bind(lambda n: Try(n, True))
        assert thunk.filter(even) == Try(101, False)

    test(None)  # pragma: no cover



# Generated at 2022-06-24 00:19:47.068055
# Unit test for method map of class Try
def test_Try_map():
    def add_1(x):
        return x + 1

    assert Try.of(lambda x: x * x, 2).map(add_1) == Try(5, True)
    assert Try.of(lambda x: x + x, 2).map(add_1).map(add_1) == Try(6, True)

    # case when method fails
    assert Try.of(lambda x: x(x), lambda x: x / x)(0) == Try(Try(ZeroDivisionError(), False), False)


# Generated at 2022-06-24 00:19:50.930286
# Unit test for constructor of class Try
def test_Try():
    assert Try(234, True) == Try(234, True)
    assert Try(434, False) == Try(434, False)
    assert Try(234, True) != Try(234, False)
    assert Try(234, False) != Try(123, False)
    assert Try(234, True) != Try(123, True)


# Generated at 2022-06-24 00:19:53.716766
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x+1) == Try(2, True)
    assert Try(1, False).map(lambda x: x+1) == Try(1, False)


# Generated at 2022-06-24 00:20:04.504733
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    success_fn_result = Try.of(lambda x: x * 2, 3)
    success_fn_result_eq = Try.of(lambda x: x * 2, 3)
    success_fn_result_not_eq = Try.of(lambda x: x * 2, 4)
    fail_fn_result = Try.of(lambda x: 1 / 0, 0)
    fail_fn_result_eq = Try.of(lambda x: 1 / 0, 0)
    assert success_fn_result == success_fn_result_eq
    assert success_fn_result != success_fn_result_not_eq
    assert fail_fn_result == fail_fn_result_eq
    assert fail_fn_result != success_fn_result
    assert fail_fn_result != success_fn_result_eq
    assert fail_fn_

# Generated at 2022-06-24 00:20:11.178423
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def _filterer(x):
        return x > 10
    result = Try(8, True).filter(_filterer)
    assert not result.is_success
    assert result.get() == 8

    result = Try(8, False).filter(_filterer)
    assert not result.is_success
    assert result.get() == 8

    result = Try(18, True).filter(_filterer)
    assert result.is_success
    assert result.get() == 18


# Generated at 2022-06-24 00:20:17.105142
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, 1) == Try(1, 1)
    assert Try(1, True) != Try(2, True)
    assert Try(True, True) != Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, True)


# Generated at 2022-06-24 00:20:23.121119
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    value = Try.of(lambda: 5).get_or_else(-1)
    assert value == 5
    value = Try.of(lambda: None).get_or_else(-1)
    assert value == -1


# Generated at 2022-06-24 00:20:27.939844
# Unit test for constructor of class Try
def test_Try():
    obj = Try(1, True)

    assert obj.value == 1
    assert obj.is_success == True



# Generated at 2022-06-24 00:20:37.956600
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test for method bind

    :returns: None
    """
    def raise_exception(*args):
        """
        Raise exception.

        :returns: None
        """
        raise Exception('Catch me!')

    def return_None(*args):
        """
        Return None.

        :returns: None
        :rtype: None
        """
        return None

    assert Try.of(lambda x, y: x and y, True, True).bind(
            lambda v: Try(isinstance(v, bool), True)) == Try(True, True)
    assert Try.of(lambda x, y: x and y, True, False).bind(
        lambda v: Try(isinstance(v, bool), True)) == Try(False, True)

# Generated at 2022-06-24 00:20:40.789851
# Unit test for method on_success of class Try
def test_Try_on_success():
    def assert_success(value):
        assert value == 1

    def assert_fail(value):
        assert False

    try_success = Try(1, True)
    try_success.on_success(assert_success)

    try_fail = Try(1, False)
    try_fail.on_success(assert_fail)


# Generated at 2022-06-24 00:20:42.968749
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:20:45.990118
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)



# Generated at 2022-06-24 00:20:50.060571
# Unit test for method map of class Try
def test_Try_map():
    def divider(a, b):
        return a/b

    def mapper(x):
        return x + 1

    assert Try.of(divider, 10, 2).map(mapper) == Try(6, True)
    assert Try.of(divider, 2, 0).map(mapper) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:20:54.829750
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(None) == 1
    assert Try(1, False).get_or_else(None) is None
    assert Try(2, False).get_or_else(3) == 3
    assert Try(1, True).get_or_else(2) == 1


# Generated at 2022-06-24 00:21:00.667455
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert not Try.of(lambda x: 1 / 0, 1).on_fail(lambda x: 1)
    assert (isinstance(Try.of(lambda x: 1 / 0, 1).on_fail(lambda x: 1), Try))
    assert Try.of(lambda x: 1 / 0, 1).on_fail(lambda x: 1) == Try(ZeroDivisionError(), False)

# Generated at 2022-06-24 00:21:07.547522
# Unit test for constructor of class Try
def test_Try():
    """
    Unit test for constructor of class Try.
    """
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)


# Generated at 2022-06-24 00:21:08.402276
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1,).get() == 1


# Generated at 2022-06-24 00:21:11.980629
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    try_1 = Try(1, True)
    try_2 = Try(2, False)

    assert try_1 == try_1
    assert not (try_1 == try_2)



# Generated at 2022-06-24 00:21:14.593465
# Unit test for method __str__ of class Try
def test_Try___str__():
    # Given
    try_mock = Mock(Try(None, True))

    # When
    try_mock.__str__()

    # Then
    try_mock.__str__.assert_called_once_with()



# Generated at 2022-06-24 00:21:26.100272
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    # Test constructor with two arguments
    assert (isinstance(Try(1, True), Try) is True)\
        and (Try(1, True).value == 1)\
        and (isinstance(Try(1, True).value, int) is True)\
        and (Try(1, True).is_success is True)

    assert (isinstance(Try(1, False), Try) is True)\
        and (Try(1, False).value == 1)\
        and (isinstance(Try(1, False).value, int) is True)\
        and (Try(1, False).is_success is False)


# Generated at 2022-06-24 00:21:33.167009
# Unit test for method map of class Try
def test_Try_map():
    # Setup
    try_value = Try(1, True)
    try_none = Try(Exception, False)
    mapper = lambda _: _ + 1

    # Exercise
    try_value_mapped = try_value.map(mapper)
    try_none_mapped = try_none.map(mapper)

    # Verify
    assert try_value_mapped == Try(2, True)
    assert try_none_mapped == Try(Exception, False)



# Generated at 2022-06-24 00:21:40.085038
# Unit test for method filter of class Try
def test_Try_filter():
    exceptions = [{'error': 'File not found', 'path': '/path/to/file.txt'},
                  {'error': 'Permission denied', 'path': '/path/to/file.txt'},
                  {'error': 'File not found', 'path': '/path/to/file'}]
    try1 = Try(exceptions[0], False)
    try2 = Try(exceptions[1], False)
    try3 = Try(exceptions[2], False)
    assert try1.filter(lambda e: e['path'].endswith('.txt')) == Try(exceptions[0], False)
    assert try2.filter(lambda e: e['path'].endswith('.txt')) == Try(exceptions[1], False)

# Generated at 2022-06-24 00:21:42.034397
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(None, False) == Try(None, False)



# Generated at 2022-06-24 00:21:45.877129
# Unit test for method on_fail of class Try

# Generated at 2022-06-24 00:21:52.699010
# Unit test for constructor of class Try
def test_Try():
    try_test = Try('test', True)
    assert try_test.value == 'test'
    assert try_test.is_success is True

    try_test_exception = Try('test', False)
    assert try_test_exception.value == 'test'
    assert try_test_exception.is_success is False

    assert Try(1, True) != Try('1', True)
    assert Try('1', True) == Try('1', True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) == Try(1, False)


# Generated at 2022-06-24 00:21:58.561678
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_function(value):
        raise Exception('Failed!')

    success = Try.of(test_function, 1)
    fail = success.on_fail(lambda e: e)
    assert isinstance(fail, Try)
    assert not fail.is_success
    assert fail.value == 'Failed!'



# Generated at 2022-06-24 00:22:02.891824
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def _on_success(value):
        assert value == 1

    def _none_callback(value):
        assert False

    Try.of(lambda: 1).on_success(_on_success)
    Try.of(lambda: 1).on_success(_none_callback)
    assert True


# Generated at 2022-06-24 00:22:06.287940
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    """
    Test for constructor of class Try
    """
    a = "a"
    try_a = Try(a, True)
    assert(try_a.value == "a")
    assert(try_a.is_success)

    assert(Try("a", True) == try_a)
    assert(str(try_a) == "Try[value=a, is_success=True]")



# Generated at 2022-06-24 00:22:12.462966
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_value = Try.of(lambda x: 1, 1)
    assert try_value.get_or_else(2) == 1

    try_value = Try.of(lambda x: 1 / x, 0)
    assert try_value.get_or_else(2) == 2


# Generated at 2022-06-24 00:22:16.792119
# Unit test for method bind of class Try
def test_Try_bind():
    def is_positive(x):
        assert isinstance(x, int)
        return Try(x, x > 0)

    assert Try.of(int, '123').bind(is_positive).get_or_else(-1) == 123
    assert Try.of(int, 'abc').bind(is_positive).get_or_else(-1) == -1
    assert Try.of(int, 'abc').bind(is_positive).get() == ValueError


# Generated at 2022-06-24 00:22:22.820959
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # GIVEN
    a_try_with_exception = Try.of(None, 'divide by zero')

    # WHEN
    value = a_try_with_exception.get_or_else(None)

    # THEN
    assert value is None



# Generated at 2022-06-24 00:22:28.860577
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Successfully values handling

    # When values the same
    result = Try.of(lambda: 'foo') == Try.of(lambda: 'foo')
    assert result

    # When values different
    result = Try.of(lambda: 'foo') == Try.of(lambda: 'bar')
    assert not result

    # When types different
    result = Try.of(lambda: 'foo') == Try.of(lambda: 1)
    assert not result

    # Not successfully values handling

    # When values the same
    result = Try.of(lambda: 1 / 0) == Try.of(lambda: 1 / 0)
    assert result

    # When values different
    result = Try.of(lambda: 1 / 0) == Try.of(lambda: 2 / 0)
    assert not result

    # When different types
    result = Try.of

# Generated at 2022-06-24 00:22:36.436706
# Unit test for method map of class Try
def test_Try_map():
    def divide_by_two(x): return x / 2

    assert Try.of(divide_by_two, 2) == Try(1, True)
    assert Try.of(divide_by_two, 2).map(str) == Try('1', True)
    assert Try.of(divide_by_two, 'a').map(str) == Try('a', False)

    assert Try.of(divide_by_two, 1).map(lambda x: x + 1) == Try(2, True)
    assert Try.of(divide_by_two, 0).map(lambda x: x + 1) == Try(1, True)
    assert Try.of(divide_by_two, 1).map(lambda x: x + 1).map(lambda x: x + 1) == Try(3, True)
   

# Generated at 2022-06-24 00:22:41.030629
# Unit test for method map of class Try
def test_Try_map():
    def add_one(a):
        return a + 1

    assert Try(1, True).map(add_one).get() == 2
    assert Try(1, False).map(add_one).get() == 1
    assert Try(1, True).map(add_one).is_success
    assert not Try(1, False).map(add_one).is_success


# Generated at 2022-06-24 00:22:46.728435
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(10, True).on_fail(lambda e: e) == Try(10, True), 'Try: wrong test on_fail()'
    assert Try('error', False).on_fail(lambda e: e) == Try('error', False), 'Try: wrong test on_fail()'


# Generated at 2022-06-24 00:22:49.349010
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 5, ()).map(lambda x: x * 3) == Try(15, True)
    assert Try.of(lambda: 5, ()).map(lambda x: x / 0) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:22:53.729628
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_success = Try('success', True)
    assert try_success.get_or_else('') == 'success'

    try_fail = Try('fail', False)
    assert try_fail.get_or_else('') == ''



# Generated at 2022-06-24 00:22:56.141356
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        raise Exception()
    except Exception as e:
        assert Try.of(lambda: 5 / 0, None).on_fail(lambda err_msg: e == err_msg)

# Generated at 2022-06-24 00:23:00.066468
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(3.14, False)) == 'Try[value=3.14, is_success=False]'
    assert str(Try(True, True)) == 'Try[value=True, is_success=True]'


# Generated at 2022-06-24 00:23:02.814259
# Unit test for method __str__ of class Try
def test_Try___str__():
    a = Try('test', True)
    assert str(a) == 'Try[value=test, is_success=True]'
    a = Try('test', False)
    assert str(a) == 'Try[value=test, is_success=False]'



# Generated at 2022-06-24 00:23:09.359070
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try.of(lambda: 2, )\
        .filter(lambda x: x == 2)\
        .filter(lambda x: x % 2 == 0)\
        .on_success(print)\
        .on_fail(print) == Try(2, True)

    assert Try.of(lambda: 2, )\
        .filter(lambda x: x == 3)\
        .filter(lambda x: x % 2 == 0)\
        .on_success(print)\
        .on_fail(print) == Try(3, False)

    assert Try.of(lambda: 2, )\
        .filter(lambda x: x == 3)\
        .filter(lambda x: x % 2 == 0)\
        .filter(lambda x: x == 5)\
        .on_success(print)\
        .on_

# Generated at 2022-06-24 00:23:17.920673
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    exception = ValueError('test_Try_on_fail')
    try_value = Try(1, True)
    try_not_value = Try(exception, False)

    collect_exception_messages = []
    collect_try_not_value_messages = []
    collect_try_value_messages = []

    try_value.on_fail(lambda x: collect_exception_messages.append(x))
    try_not_value.on_fail(lambda x: collect_try_not_value_messages.append(x))
    try_value.on_fail(lambda x: collect_try_value_messages.append(x))

    assert collect_exception_messages == []
    assert collect_try_not_value_messages == [exception]
    assert collect_try_value_mess

# Generated at 2022-06-24 00:23:22.047868
# Unit test for method bind of class Try
def test_Try_bind():
    def custom_binder(value):
        if value == 5:
            return Try(value, True)
        return Try(value, False)

    result = Try.of(lambda x: x + 2, 5).bind(custom_binder)
    assert result == Try(7, True)


# Generated at 2022-06-24 00:23:26.673849
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    If Try is not successfully than overriding CatchingException in class TestCase will be raise
    """
    class TestCase:
        caught = False

        def catch(self, exp):
            self.caught = True

    test_case = TestCase()

    try:
        (Try.of(int, 'two').on_fail(test_case.catch)).get()
    except ValueError:
        assert test_case.caught



# Generated at 2022-06-24 00:23:33.665824
# Unit test for method on_fail of class Try
def test_Try_on_fail(): # pragma: no cover
    def success_callback(value):
        print('success_callback({})'.format(value))

    def fail_callback(value):
        print('fail_callback({})'.format(value))

    # case: failure
    Try(ValueError('test'), False).on_fail(fail_callback)
    # case: success
    Try(ValueError('test'), True).on_fail(fail_callback).on_fail(fail_callback)
    # case: success
    Try(ValueError('test'), True).on_success(success_callback).on_fail(fail_callback)

if __name__ == '__main__': # pragma: no cover
    test_Try_on_fail()

# Generated at 2022-06-24 00:23:41.197221
# Unit test for method filter of class Try
def test_Try_filter():
    # When filterer returns True
    assert Try.of(lambda: 20).filter(lambda _: True) == Try(20, True)
    assert Try.of(lambda: 'test').filter(lambda _: True) == Try('test', True)

    # When filterer returns False
    assert Try.of(lambda: 20).filter(lambda _: False) == Try(20, False)
    assert Try.of(lambda: 'test').filter(lambda _: False) == Try('test', False)


# Generated at 2022-06-24 00:23:44.870459
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:23:53.956371
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test for method bind in class Try.

    Test create successfully Try instance,
    store value in this Try and check that when we pass the bind function
    the result of this function will return.

    Test create not successfully Try instance with exception,
    and check that when we pass the bind function
    the result of this function will not return.

    Test create not successfully Try instance with exception,
    and check that when we pass the bind function
    the result of this function will not return.
    """
    try_func = lambda: '1'
    try_func_exception = lambda: 1 / 0
    binder1 = lambda arg: arg
    binder2 = lambda arg: 2
    success_try = Try.of(try_func)
    assert success_try.bind(binder1) == Try('1', True)
    assert success_

# Generated at 2022-06-24 00:23:58.425187
# Unit test for method get of class Try
def test_Try_get():
    # Preparation
    value = 3
    expected_result = 3

    # Execution
    result = Try(value, True).get()

    # Assertion
    assert value == expected_result

# Generated at 2022-06-24 00:24:05.965080
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        return value

    def fail_callback(value):  # pragma: no cover
        raise Exception(value)

    assert Try(2, True).on_success(success_callback) == Try(2, True)
    assert Try(2, False).on_success(success_callback) == Try(2, False)

    assert Try(2, True).on_fail(fail_callback) == Try(2, True)
    assert Try(2, False).on_fail(fail_callback) == Try(2, False)



# Generated at 2022-06-24 00:24:13.189956
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    def multiply(a, b):
        if a == 0 or b == 0:
            raise ValueError('Values can not be 0.')
        return a * b

    try_1 = Try.of(multiply, 5, 5)
    try_2 = Try.of(multiply, 5, 0)

    assert try_1.get() == 25 and not try_2.is_success and try_2.get() == ValueError('Values can not be 0.')


# Generated at 2022-06-24 00:24:16.831345
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 1 / 0).on_fail(lambda e: e) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:24:19.460186
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(10, True).get_or_else(0) == 10
    assert Try(10, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:24:25.758624
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(True, False)) == 'Try[value=True, is_success=False]'
    assert str(Try(Exception, False)) == 'Try[value=<class \'Exception\'>, is_success=False]'


# Generated at 2022-06-24 00:24:29.310572
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def my_fail_function(x):
        return x + 1

    assert Try.of(lambda: 1 / 0, None).on_fail(my_fail_function) == Try(my_fail_function.__name__, False)


# Generated at 2022-06-24 00:24:32.611511
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert "Try[value=None, is_success=True]" == str(Try(None, True))
    assert "Try[value=None, is_success=False]" == str(Try(None, False))

# Generated at 2022-06-24 00:24:34.912049
# Unit test for method on_success of class Try
def test_Try_on_success():
    called = False
    def callback(value):
        nonlocal called
        called = True

    Try(Exception('bad value'), False).on_success(callback)
    Try(1, True).on_success(callback)
    assert called, 'on_fail not called'


# Generated at 2022-06-24 00:24:37.090047
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x)) == Try(1, True)
    assert Try(None, False).on_success(lambda x: print(x)) == Try(None, False)

# Generated at 2022-06-24 00:24:46.148238
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda x: x + 1, 1).bind(lambda x: Try.of(lambda y: x + y, 1)) == Try(3, True)
    assert Try.of(lambda x: x + 1, 1).bind(lambda x: Try.of(lambda: x + 1)) == Try(3, True)
    assert Try.of(lambda x: 1 / x, 0).bind(lambda x: Try.of(lambda y: x + y, 1)) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0).bind(lambda x: Try.of(lambda y: x + y, 1)) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:24:56.336950
# Unit test for method map of class Try
def test_Try_map():
    from nose_parameterized import parameterized

    @parameterized.expand([
        (True, True),
        (True, False),
        (False, True),
        (False, False)
    ])
    def test(is_success, is_mapper_success):
        mapper = lambda x: x.value if is_mapper_success else Exception()

        # When
        result = Try(1, is_success).map(mapper)

        # Then
        assert is_success and is_mapper_success == result.is_success
        assert (is_success and is_mapper_success) and result.get() == 1 or result.get_or_else(None) is None
    test()


# Generated at 2022-06-24 00:24:58.142051
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(5, True).on_success(lambda x: x == 5) == Try(5, True)
    assert Try(Exception('error message'), False).on_success(lambda x: x == 5) == Try(Exception('error message'), False)



# Generated at 2022-06-24 00:25:03.530833
# Unit test for constructor of class Try
def test_Try():
    try_success1 = Try(1, True)
    try_fail1 = Try(1, False)
    try_success2 = Try(1, True)
    try_fail2 = Try(1, False)

    assert try_success1 == try_success2
    assert try_success1 != try_fail1
    assert try_fail1 == try_fail2


# Generated at 2022-06-24 00:25:12.774938
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    class MyException(Exception):
        pass

    try:
        raise MyException
    except MyException:
        try_ = Try(sys.exc_info()[1], False)
        try_.on_fail(lambda e: None)

    try:
        raise Exception
    except Exception:
        try_ = Try(sys.exc_info()[1], False)
        try_.on_fail(lambda e: None)

    try:
        raise Exception
    except Exception:
        try_ = Try(sys.exc_info()[1], False)
        try_.on_fail(None)



# Generated at 2022-06-24 00:25:19.771912
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Description of test:
    Try to create unsuccessfully Try with exception.
    Call method on_fail of that monad with lambda-function, which prints exception.
    When exception was handled, print #test passed#

    :returns: prints '#test passed#' when exception was handled
    """
    Try.of(int, 'abc').on_fail(
        lambda x: print('#test passed#')
    )



# Generated at 2022-06-24 00:25:26.184266
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda x: Try(x + 1, True)).value == 2
    assert Try(1, False).bind(lambda x: Try(x + 1, True)).value == 1
    assert Try(1, True).bind(lambda x: Try(x + 1, False)).value == 2
    assert Try(1, False).bind(lambda x: Try(x + 1, False)).value == 1

# Generated at 2022-06-24 00:25:33.099228
# Unit test for method map of class Try
def test_Try_map():
    success = Try(2, True)
    not_success = Try('error', False)

    def double(x):
        return x * 2

    assert success.map(double) == Try(4, True)
    assert not_success.map(double) == Try('error', False)

    success = Try('2', True)
    not_success = Try('error', False)

    def func(x):
        return int(x)

    assert success.map(func) == Try(2, True)
    assert not_success.map(func) == Try('error', False)



# Generated at 2022-06-24 00:25:35.525171
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(10, True).get_or_else(0) == 10
    assert Try(10, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:25:40.467810
# Unit test for method __str__ of class Try
def test_Try___str__():
    fn = lambda x, y: x + y
    value = Try.of(fn, 1, 2)
    assert (str(value) == 'Try[value=3, is_success=True]')
    value = Try.of(fn, 1, {})

# Generated at 2022-06-24 00:25:42.217762
# Unit test for constructor of class Try
def test_Try():
    try_obj = Try('value', True)
    assert try_obj.value == 'value' and try_obj.is_success == True


# Generated at 2022-06-24 00:25:45.820131
# Unit test for method get of class Try
def test_Try_get():
    try_monad = Try.of(lambda: 3)
    assert try_monad.get() == 3

    try_monad = Try.of(lambda: 3 / 0)
    assert str(try_monad.get()) == 'division by zero'


# Generated at 2022-06-24 00:25:48.243795
# Unit test for constructor of class Try
def test_Try():
    with pytest.raises(AssertionError):
        Try(None, False)
    assert Try(None, True) == Try(None, True)


# Generated at 2022-06-24 00:25:57.489995
# Unit test for constructor of class Try
def test_Try():
    assert True == Try(True, True).is_success
    assert False == Try(True, False).is_success

    assert True == Try(True, True).value
    assert False == Try(False, True).value

    assert Try(True, True) == Try(True, True)
    assert Try(True, False) == Try(True, False)

    assert Try(True, True) != Try(True, False)
    assert Try(True, False) != Try(False, True)

    assert str(Try(True, True)) == 'Try[value=True, is_success=True]'
    assert str(Try(True, False)) == 'Try[value=True, is_success=False]'



# Generated at 2022-06-24 00:25:59.865213
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1, "Should be 1"
    assert Try(None, False).get_or_else(2) == 2, "Should be 2"



# Generated at 2022-06-24 00:26:06.989816
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # given
    default_value = 'default'
    t: Try[str] = Try('value', True)
    t2: Try[str] = Try('error', False)
    # when
    v: str = t.get_or_else(default_value)
    v2: str = t2.get_or_else(default_value)
    # then
    assert v == t.get()
    assert v2 == default_value


# Generated at 2022-06-24 00:26:14.862984
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def add_one(x):
        return x + 1

    def fail_function(x):
        raise Exception('fail function')

    # 1. When Try is successfully return new Try with mapped value
    assert Try(1, True).map(add_one) == Try(2, True)
    # 2. When Try is not successfully return copy of self
    assert Try(1, False).map(add_one) == Try(1, False)

    # 3. When mapper function raise exception, return not successfully Try with exception
    assert Try(1, True).map(fail_function) == Try(Exception('fail function'), False)



# Generated at 2022-06-24 00:26:19.034705
# Unit test for method bind of class Try
def test_Try_bind():
    def test_func():
        return 'test'
    def test_func2(text):
        return 'test_func2 -> ' + text

    assert Try.of(test_func, None).bind(lambda text: Try.of(test_func2, text)) == Try('test_func2 -> test', True)
    assert Try.of(test_func, Exception()).bind(lambda text: Try.of(test_func2, text)) == Try(Exception(), False)



# Generated at 2022-06-24 00:26:23.465275
# Unit test for method map of class Try
def test_Try_map():
    assert Try(5, True).map(lambda x: x*2) == Try(10, True)
    assert Try(5, True).map(lambda x: x*2).map(lambda x: x+10) == Try(20, True)
    assert Try(10, False).map(lambda x: x*2) == Try(10, False)
    assert Try(None, False).map(lambda x: x*2) == Try(None, False)



# Generated at 2022-06-24 00:26:26.902629
# Unit test for method __str__ of class Try
def test_Try___str__():
    # GIVEN
    try_ = Try(10, True)
    # WHEN
    result = str(try_)
    # THEN
    assert result == 'Try[value=10, is_success=True]'


# Generated at 2022-06-24 00:26:29.076289
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(None, False) != Try(1, True)


# Generated at 2022-06-24 00:26:33.380979
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Tests for Try.filter
    :return:
    """
    class SomeClass:
        def __init__(self, a):
            self.a = a

    def is_matched(a):
        return a.a == 1

    assert Try(1, True).filter(is_matched) == Try(1, True)
    assert Try(SomeClass(1), True).filter(is_matched) == Try(SomeClass(1), True)
    assert Try(SomeClass(2), True).filter(is_matched) == Try(SomeClass(2), False)
    assert Try(SomeClass(1), False).filter(is_matched) == Try(SomeClass(1), False)
    # if self.value is None
    assert Try(None, True).filter(is_matched) == Try(None, False)
    assert Try

# Generated at 2022-06-24 00:26:36.277436
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)

# Generated at 2022-06-24 00:26:42.982540
# Unit test for method map of class Try
def test_Try_map():
    class Foo:
        pass

    class Bar:
        pass

    foo = Foo()

    assert(Try(foo, True).map(lambda v: Bar() if isinstance(v, Foo) else v) == Try(Bar(), True))

    assert(Try(foo, True).map(lambda v: Bar() if isinstance(v, Foo) else v) != Try(Foo(), True))


# Generated at 2022-06-24 00:26:45.401957
# Unit test for method bind of class Try
def test_Try_bind():
    # Arrange
    def binder(value):
        return Try(value * value * value, True)

    # Act
    try_control = Try(200, True)
    result = try_control.bind(binder)

    # Assert
    assert result == Try(8000000, True), "Result of bind method for Try control incorrect."



# Generated at 2022-06-24 00:26:49.852826
# Unit test for method filter of class Try
def test_Try_filter():
    def is_positive(x):
        return x > 0

    assert(Try(0, True).filter(is_positive) == Try(0, False))
    assert(Try(1, True).filter(is_positive) == Try(1, True))
    assert(Try(-1, True).filter(is_positive) == Try(-1, False))



# Generated at 2022-06-24 00:26:53.686968
# Unit test for method on_success of class Try
def test_Try_on_success():
    from pytest import raises

    def callback(value):
        raise Exception('Success')
    try_ = Try(1, True)
    try_.on_success(callback)
    with raises(Exception) as err:
        try_ = Try(1, False)
        try_.on_success(callback)


# Generated at 2022-06-24 00:26:59.188838
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Given
    default_value = 'Default value'
    def a():
        raise Exception('I am not successfully')

    def b():
        return 'I am successfully'

    # When
    actual_a = Try.of(a).get_or_else(default_value)
    actual_b = Try.of(b).get_or_else(default_value)

    # Then
    assert actual_a == default_value
    assert actual_b == 'I am successfully'


# Generated at 2022-06-24 00:27:04.636769
# Unit test for method map of class Try
def test_Try_map():
    def double(x: int) -> int:
        return x * 2

    def divide(x: int, y: int) -> int:
        return x / y

    successful_double, failure_double = Try.of(double, 1), Try.of(divide, 1, 0)
    successful_double2, failure_double2 = successful_double.map(double), failure_double.map(double)
    assert successful_double == Try(2, True)
    assert successful_double2 == Try(4, True)
    assert failure_double == Try(ZeroDivisionError(), False)
    assert failure_double2 == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:27:06.960211
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:27:13.281139
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 'Hello')().get() == 'Hello'
    assert Try.of(lambda: None)().get() is None
    assert Try.of(lambda: True)().get() is True
    assert Try.of(lambda: False)().get() is False
    assert Try.of(lambda: 1)().get() == 1
    assert Try.of(lambda: 3.2)().get() == 3.2



# Generated at 2022-06-24 00:27:17.076100
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(10, True).get_or_else(100) == 10
    assert Try(10, False).get_or_else(100) == 100
    assert Try(10, True).get_or_else(None) == 10
    assert Try(10, False).get_or_else(None) == None


# Generated at 2022-06-24 00:27:20.520685
# Unit test for method bind of class Try
def test_Try_bind():
    try:
        SomeNumber = 10
        result = Try.of(lambda x: x / 2, SomeNumber).bind(lambda x: Try.of(lambda y: y / 0, x))

        assert result.is_success is False
        assert isinstance(result.get(), ZeroDivisionError)
    except Exception as e:
        print(e)

# Generated at 2022-06-24 00:27:24.273663
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    instance = Try('foo', True)

    assert str(instance) == 'Try[value=foo, is_success=True]'


# Generated at 2022-06-24 00:27:33.555359
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test method bind of class Try
    """
    # Test 1: exception in binder function
    def binder(success_value):
        return Try(0, False)

    assert Try(1, True).bind(binder) == Try(0, False)

    # Test 2: not successfully monad in binder function
    def binder2(success_value):
        return Try(None, False)

    assert Try(1, True).bind(binder2) == Try(None, False)

    # Test 3: successfully monad in binder function
    def binder3(success_value):
        return Try(success_value, True)

    assert Try(1, True).bind(binder3) == Try(1, True)

    # Test 4: not successfully monad in bind method

# Generated at 2022-06-24 00:27:39.129946
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)
    assert type(Try(1, True)) is Try
    print('Try class tests passed successfully.')


# Generated at 2022-06-24 00:27:41.338166
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try.of(lambda: 1) == Try.of(lambda: 1)
    assert Try.of(lambda: 1) != Try.of(lambda: 2)


# Generated at 2022-06-24 00:27:44.006634
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: x) == Try(1, True)
    assert Try(lambda x: x, False).on_fail(lambda x: x) == Try(lambda x: x, False)


# Generated at 2022-06-24 00:27:54.054416
# Unit test for constructor of class Try
def test_Try():
    class Error(Exception):
        pass

    def fn(*args):
        if args[0] == 0:
            raise Error('Then exception')
        return args[0] + args[1]

    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)

    assert Try.of(fn, 1, 1).value == 2
    assert Try.of(fn, 1, 1).is_success is True
    assert Try.of(fn, 0, 0).value is not None
    assert Try.of(fn, 0, 0).is_success is False

# Unit

# Generated at 2022-06-24 00:28:00.966513
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Test for method __str__ of class Try.

    :returns: None
    :rtype: None
    """
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception('error'), False)) == 'Try[value=error, is_success=False]'



# Generated at 2022-06-24 00:28:03.206967
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x: x, 'test_value').get() == 'test_value'


# Generated at 2022-06-24 00:28:08.388869
# Unit test for method filter of class Try
def test_Try_filter():
    try_ = Try(8, True)
    assert try_.filter(lambda x: x > 5) == Try(8, True)
    try_ = Try(8, True)
    assert try_.filter(lambda x: x < 5) == Try(8, False)


# Generated at 2022-06-24 00:28:11.062634
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-24 00:28:14.702941
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(2, True)) == 'Try[value=2, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'



# Generated at 2022-06-24 00:28:25.811321
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Inputs
    try_1 = Try(1, True)
    try_2 = Try(1, False)
    try_3 = Try(2, True)
    try_4 = Try(1, True)

    # Call method
    result_1 = try_1 == try_2
    result_2 = try_2 == try_3
    result_3 = try_3 == try_4
    result_4 = try_1 == try_4

    # Evaluate test
    assert result_1 is False, 'The method Try.__eq__() return value error'
    assert result_2 is False, 'The method Try.__eq__() return value error'
    assert result_3 is False, 'The method Try.__eq__() return value error'

# Generated at 2022-06-24 00:28:36.181310
# Unit test for method bind of class Try
def test_Try_bind():
    def try_func(value):
        """
        Function to call by monad Try.

        :params value: value to return
        :type value: any
        :returns: value
        :rtype: Any
        """
        return value

    def try_func_with_exception(value):
        """
        Function to call by monad Try and raise Exception.

        :params value: value to return
        :type value: any
        :returns: value
        :rtype: Any
        """
        raise Exception('exception')

    def mapper(value):
        """
        Function to apply on monad value by method map of Try monad.

        :params value: value to apply
        :type value: Any
        :returns: value
        :rtype: Any
        """
        return value


# Generated at 2022-06-24 00:28:40.406194
# Unit test for method get of class Try
def test_Try_get():
    try_ = Try(1, True)
    assert 1 == try_.get()

    try_ = Try(1, False)
    assert 1 == try_.get()



# Generated at 2022-06-24 00:28:45.197708
# Unit test for method get of class Try
def test_Try_get():
    assert Try(3, True).get() == 3

