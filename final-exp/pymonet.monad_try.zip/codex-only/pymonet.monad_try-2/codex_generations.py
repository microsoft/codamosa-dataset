

# Generated at 2022-06-24 00:18:54.113335
# Unit test for method on_success of class Try
def test_Try_on_success():
    # GIVEN
    def _get_a():
        return 'a'

    def _get_b():
        return 'b'

    def _get_c():
        raise Exception('error')

    # WHEN
    a = Try.of(_get_a).on_success(lambda value: print(value))
    b = Try.of(_get_b).on_success(lambda value: print(value))
    c = Try.of(_get_c).on_success(lambda value: print(value))

    # THEN
    assert a == Try('a', True)
    assert b == Try('b', True)
    assert c == Try('error', False)


# Generated at 2022-06-24 00:18:59.217837
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, False).on_fail(lambda e: e + 1) == Try(2, False)
    assert Try(1, False).on_fail(lambda e: e + 1) is not Try(2, False)


# Generated at 2022-06-24 00:19:04.140129
# Unit test for method get of class Try
def test_Try_get():
    """
    Unit test for method get of class Try.
    """
    try_1 = Try(42, True)

    assert(Try(42, True).get()) == 42



# Generated at 2022-06-24 00:19:07.573755
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    class Test:  # pragma: no cover
        def __init__(self):
            self.values = []

        def print_value(self, value):  # pragma: no cover
            self.values.append(value)

    t = Test()
    assert Try(5, True).on_success(t.print_value) == Try(5, True)
    assert t.values == [5]


# Generated at 2022-06-24 00:19:19.522234
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Unit test for method bind of class Try
    """
    def create_try(value):
        try:
            return Try(value, True)
        except Exception as e:
            return Try(e, False)

    # Successfully bind
    t1 = Try.of(lambda x: x + 1, 1)
    t2 = t1.bind(lambda x: CreateTry(x+2))
    t3 = t2.bind(lambda x: CreateTry(x+3))

# Generated at 2022-06-24 00:19:26.132081
# Unit test for method on_success of class Try
def test_Try_on_success():
    def mock():
        pass

    try_: Try[Exception] = Try.of(lambda: 5, 2)
    assert try_.on_success(mock) == try_
    assert try_.on_success(mock).is_success

    try_: Try[Exception] = Try.of(lambda: 5 / 0)
    assert try_.on_success(mock) == try_
    assert not try_.on_success(mock).is_success



# Generated at 2022-06-24 00:19:31.026169
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    error_msg = 'error_msg'

# Generated at 2022-06-24 00:19:35.534322
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('value', True)) == "Try[value=value, is_success=True]"
    assert str(Try('value', False)) == "Try[value=value, is_success=False]"



# Generated at 2022-06-24 00:19:37.885526
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 'value').on_success(print) == Try('value', True)


# Generated at 2022-06-24 00:19:41.220288
# Unit test for method map of class Try
def test_Try_map():
    def foo(a):
        if a < 0: raise ValueError
        return a

    def add_one(a):
        return a + 1

    assert Try.of(foo, 1).map(add_one) == Try(2, True)
    assert Try.of(foo, -1).map(add_one) == Try(-1, False)


# Generated at 2022-06-24 00:19:43.555629
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5


# Generated at 2022-06-24 00:19:47.416238
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 'value').bind(lambda val: Try.of(lambda: val+'1')) == Try('value1', True)
    assert Try.of(lambda: 1).bind(lambda val: Try.of(lambda: val/0)) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:19:48.648220
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2


# Generated at 2022-06-24 00:19:53.296074
# Unit test for method map of class Try
def test_Try_map():
    assert Try(2, True).map(lambda x: x * 2) == Try(4, True)
    assert Try("Expected", False).map(lambda x: x * 2) == Try("Expected", False)
    assert Try(None, True).map(lambda x: x * 2) == Try(None, True)
    assert Try(None, False).map(lambda x: x * 2) == Try(None, False)


# Generated at 2022-06-24 00:19:59.572299
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    add_one = lambda x: x + 1

    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) != Try(1, True)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)

# Generated at 2022-06-24 00:20:06.776703
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda : 1).get() == 1
    assert Try.of(lambda : 1).map(lambda x : x + 2).get() == 3
    assert Try.of(lambda : 1).map(lambda x : x + 2).bind(lambda x : Try.of(lambda : x - 2)).get() == 1
    assert Try.of(lambda : 1).map(lambda x : x + 2).bind(lambda x : Try.of(lambda : x - 2)).map(lambda x : x + 2).get() == 3


# Generated at 2022-06-24 00:20:15.635873
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: "1", None).filter(lambda val: val == "1") == Try("1", True)
    assert Try.of(lambda: "1", None).filter(lambda val: val == "2") == Try("1", False)
    assert Try.of(lambda: "1", None).filter(lambda val: val == "2").filter(lambda val: val == "1") == Try("1", False)
    assert Try.of(lambda: "1", None).filter(lambda val: val == "1").filter(lambda val: val == "1") == Try("1", True)
    assert Try.of(lambda: "1", None).filter(lambda val: val == "1").filter(lambda val: val == "2") == Try("1", False)
    assert Try.of(lambda: "1", None).filter

# Generated at 2022-06-24 00:20:21.359404
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '100').filter(lambda v: v > 99) == Try(100, True)
    assert Try.of(int, '100').filter(lambda v: v < 99) == Try(100, False)
    assert Try.of(int, '99').filter(lambda v: v > 99) == Try(99, False)
    assert Try.of(int, '99').filter(lambda v: v < 99) == Try(99, True)
    assert Try.of(int, 'abc').filter(lambda v: v > 99) == Try('abc', False)
    assert Try.of(int, 'abc').filter(lambda v: v < 99) == Try('abc', False)


# Generated at 2022-06-24 00:20:22.973250
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(None, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:20:28.694261
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Method __eq__ of class Try.
    """
    assert str(Try(42, True)) == 'Try[value=42, is_success=True]'
    assert str(Try(Exception('Some error'), False)) == 'Try[value=Some error, is_success=False]'


# Generated at 2022-06-24 00:20:33.573212
# Unit test for method get of class Try
def test_Try_get():
    def inc(x):
        return x + 1

    assert Try.of(inc, 1).get() == 2


# Generated at 2022-06-24 00:20:35.036012
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(4, True) == Try(4, True)



# Generated at 2022-06-24 00:20:36.113206
# Unit test for method get of class Try
def test_Try_get():
    try_ = Try('', True)
    assert try_.get() == ''



# Generated at 2022-06-24 00:20:44.773561
# Unit test for method bind of class Try
def test_Try_bind():
    def n_divide_by_b(n, b):
        if b == 0:
            raise ValueError
        return n / b

    with assert_raises(ValueError):
        Try.of(n_divide_by_b, 1, 0)

    assert Try.of(n_divide_by_b, 1, 1).bind(lambda x: Try(x, True)) == Try(1, True)
    assert Try.of(n_divide_by_b, 1, 2).bind(lambda x: Try(x, True)) == Try(0.5, True)


# Generated at 2022-06-24 00:20:54.124900
# Unit test for method filter of class Try
def test_Try_filter():
    def add_one(x):
        return x+1
    def is_two(x):
        return x==2
    assert Try.of(add_one, 1).is_success
    assert Try.of(add_one, 1) == Try(2, True)
    assert Try.of(add_one, 1).filter(is_two) == Try(2, True)
    assert Try.of(add_one, 1).filter(is_two).get() == 2
    assert Try.of(add_one, 1).filter(lambda x: x==1) == Try(2, False)
    assert Try.of(add_one, 1).filter(lambda x: x==1).get() == 2
    assert Try.of(add_one, 1).filter(lambda x: x==1).get_or_else(None)

# Generated at 2022-06-24 00:20:57.282580
# Unit test for method bind of class Try
def test_Try_bind():
    def foo(a):
        return a * 2

    def bar(b):
        return Try(b + 1, True)

    assert Try(4, True).bind(bar).bind(foo).get() == 10

# Generated at 2022-06-24 00:21:05.188478
# Unit test for constructor of class Try
def test_Try():
    assert Try(4, True).map(lambda x: x + 1).get() == 5
    assert Try(4, True).map(lambda x: x + 1).is_success == True

    assert Try(4, True).filter(lambda x: x == 4)
    assert Try(4, True).filter(lambda x: x == 5).is_success == False

    assert Try(4, False).get() == 4
    assert Try(4, False).is_success == False



# Generated at 2022-06-24 00:21:10.021648
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x + 2, 2).filter(lambda x: x % 2 == 0) == Try(4, True)
    assert Try.of(lambda x: x + 2, 3).filter(lambda x: x % 2 == 0) == Try(3, False)


# Generated at 2022-06-24 00:21:12.560633
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(5, True).map(lambda x: x * 2).on_success(lambda x: print(x)) == Try(10, True)


# Generated at 2022-06-24 00:21:15.125414
# Unit test for method on_success of class Try
def test_Try_on_success():
    result = Try(True, True).on_success(lambda value: print(value))
    assert result == Try(True, True)

# Generated at 2022-06-24 00:21:17.026663
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    eq_(Try(5, True), Try(5, True))



# Generated at 2022-06-24 00:21:19.745142
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'



# Generated at 2022-06-24 00:21:21.377505
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)


# Generated at 2022-06-24 00:21:26.451184
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    test_value_1 = None
    test_value_2 = None
    test_value_3 = None

    Try.of(lambda: 1 / 0).on_fail(lambda e: setattr(test_value_1, 'value', e))\
        .on_fail(lambda e: setattr(test_value_2, 'value', e))\
        .on_fail(lambda e: setattr(test_value_3, 'value', e))

    assert test_value_1.value == test_value_2.value == test_value_3.value
    assert isinstance(test_value_3.value, ZeroDivisionError)

    test_value_1 = None
    test_value_2 = None
    test_value_3 = None


# Generated at 2022-06-24 00:21:28.361694
# Unit test for constructor of class Try
def test_Try():
    tryian = Try(123, False)
    assert not tryian.is_success
    assert tryian.value == 123
    tryian = Try(123, True)
    assert tryian.is_success
    assert tryian.value == 123


# Generated at 2022-06-24 00:21:33.809285
# Unit test for method bind of class Try
def test_Try_bind():
    """Unit test for method bind of class Try"""
    def fn(x: int) -> int:
        return x + x

    def bind_fn(x: int) -> Try[int]:
        return Try(fn(x * 2), True)
    assert Try(2, True).bind(bind_fn) == Try(6, True)
    assert Try(2, False).bind(bind_fn) == Try(2, False)



# Generated at 2022-06-24 00:21:38.260579
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    """
    Test for method get of class Try.
    Test case:
        - When monad is successfully and store int number.
        - When monad is successfully and store string.
        - When monad is not successfully and store exception 
        - When monad is not successfully and store any object
    """
    assert Try(10, True).get() == 10
    assert Try('foo', True).get() == 'foo'
    assert Try(Exception('foo'), False).get() == Exception('foo')
    assert Try('foo', False).get() == 'foo'



# Generated at 2022-06-24 00:21:40.272222
# Unit test for method get of class Try
def test_Try_get():
    success = Try.of(lambda: 5, None)
    assert success.get() == 5

    not_success = Try.of(lambda: 1 / 0, None)
    try:
        not_success.get()
        assert False
    except:
        assert True


# Generated at 2022-06-24 00:21:43.130213
# Unit test for method on_success of class Try
def test_Try_on_success():
    def add1(value):
        return value + 1

    def multiply_by_2(value):
        return value * 2

    assert Try.of(add1, 1).on_success(multiply_by_2).get() == 2
    assert Try.of(lambda x: x / 0, 1).on_success(multiply_by_2).get() == ZeroDivisionError('division by zero')



# Generated at 2022-06-24 00:21:49.905931
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 1

    def filterer2(value):
        return value == 2

    # Check for success Try with filter for success
    assert Try.of(lambda: 1).filter(filterer) == Try(1, True)

    # Check for success Try with filter for fail
    assert Try.of(lambda: 1).filter(filterer2) == Try(1, False)

    # Check for fail Try with filter
    assert Try.of(lambda: 1 / 0).filter(filterer) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:21:52.131955
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:22:01.536590
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_number(number: str) -> bool:
        try:
            int(number)
            return True
        except:
            return False

    assert(Try.of(int, '1').filter(is_number) == Try(1, True))
    assert(Try.of(int, 'a').filter(is_number) == Try('a', False))
    assert(Try.of(int, '1').filter(lambda a: a > 0) == Try(1, True))
    assert(Try.of(int, '-1').filter(lambda a: a > 0) == Try(-1, False))


# Generated at 2022-06-24 00:22:06.481125
# Unit test for method filter of class Try
def test_Try_filter():
    try_ = Try(1, False)
    new_try = try_.filter(lambda x: x > 0)
    assert not new_try.is_success
    assert new_try == try_

    try_ = Try(1, True)
    new_try = try_.filter(lambda x: x > 0)
    assert new_try.is_success
    assert new_try == try_

    try_ = Try(1, True)
    new_try = try_.filter(lambda x: x < 0)
    assert not new_try.is_success
    assert new_try != try_



# Generated at 2022-06-24 00:22:12.771265
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def on_fail_callback(exception):
        assert exception.args[0] == 'Can\'t execute this'

    # success Try
    Try.of(lambda: 'success').on_fail(on_fail_callback)

    # fail Try
    Try.of(lambda: 1/0).on_fail(on_fail_callback)

# Generated at 2022-06-24 00:22:18.317661
# Unit test for method map of class Try
def test_Try_map():
    # Testing when monad is successfully
    try_value = Try.of(lambda x: x, 1)
    try_after_map = try_value.map(lambda x: x + 1)
    assert try_after_map == Try(2, True)

    # Testing when monad is not successfully
    try_value = Try.of(lambda x, y: x / y, 1, 0)
    try_after_map = try_value.map(lambda x: x + 1)
    assert try_after_map == Try(try_value.value, False)



# Generated at 2022-06-24 00:22:25.808694
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try(10, True).__str__() == 'Try[value=10, is_success=True]'
    assert Try(None, True).__str__() == 'Try[value=None, is_success=True]'
    assert Try(10, False).__str__() == 'Try[value=10, is_success=False]'
    assert Try('test', True).__str__() == 'Try[value=test, is_success=True]'
    assert Try('test', False).__str__() == 'Try[value=test, is_success=False]'
    assert Try(10.2, True).__str__() == 'Try[value=10.2, is_success=True]'
    assert Try(10.2, False).__str__() == 'Try[value=10.2, is_success=False]'

# Generated at 2022-06-24 00:22:29.034752
# Unit test for method map of class Try
def test_Try_map():
    """
    Test for successful map Try method.
    """
    def _length(str_):
        return len(str_)

    assert Try.of(lambda: 'some string',
                  ).map(_length) == Try(12, True)



# Generated at 2022-06-24 00:22:33.610920
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter for class Try
    """
    assert Try(5, True).filter(lambda x: x % 2 == 0) == Try(5, False)
    assert Try(6, True).filter(lambda x: x % 2 == 0) == Try(6, True)
    assert Try(5, False).filter(lambda x: x % 2 == 0) == Try(5, False)
    assert Try(6, False).filter(lambda x: x % 2 == 0) == Try(6, False)



# Generated at 2022-06-24 00:22:34.977694
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)



# Generated at 2022-06-24 00:22:40.538118
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:22:45.938492
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    @Try.of
    def division(x, y):
        return x/y

    division(2, 0).on_fail(lambda x: print(x))
    division(2, 1).on_fail(lambda x: 2)



# Generated at 2022-06-24 00:22:50.973173
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def add_two_with_throw(number: int) -> int:
        if number == 10:
            raise Exception('number is equal to 10')
        return number + 2

    assert Try.of(add_two_with_throw, 10).get_or_else(10) == 10
    assert Try.of(add_two_with_throw, 8).get_or_else(10) == 10
    assert Try.of(add_two_with_throw, 8).get_or_else(3) == 3


if __name__ == '__main__':    # pragma: no cover
    test_Try_get_or_else()

# Generated at 2022-06-24 00:22:54.582652
# Unit test for method on_success of class Try
def test_Try_on_success():
    success_value = 1
    success_result = Try.of(lambda: success_value)
    result = success_result.on_success(
        lambda value: print(value))
    assert result == success_result


# Generated at 2022-06-24 00:22:59.042518
# Unit test for method bind of class Try
def test_Try_bind():
    def fun(x):
        return x + 1

    def fun_err(x):
        raise Exception('Foo')

    assert Try(2, True).bind(fun) == Try(3, True)
    assert Try(1, False).bind(fun) == Try(1, False)
    assert Try(1, True).bind(fun_err) == Try(Exception('Foo'), False)

# Generated at 2022-06-24 00:23:08.880625
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.
    """

    # Test case 1
    # Try monad with success
    value = 13
    try_monad = Try(value, True)
    assert try_monad.filter(lambda value: value == 13) == try_monad

    # Test case 2
    # Try monad with fail
    value = 13
    try_monad = Try(value, False)
    assert try_monad.filter(lambda value: value != 13) == try_monad

    # Test case 3
    # Try monad with success, filter not apply
    value = 15
    try_monad = Try(value, True)
    assert try_monad.filter(lambda value: value == 13) == Try(value, False)


# Generated at 2022-06-24 00:23:13.058207
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('foo', True)) == 'Try[value=foo, is_success=True]'
    assert str(Try('bar', False)) == 'Try[value=bar, is_success=False]'
    assert str(Try('baz', True)) == 'Try[value=baz, is_success=True]'


# Generated at 2022-06-24 00:23:15.680532
# Unit test for method get of class Try
def test_Try_get():
    value = 'value'
    try_u = Try(value, True)
    assert try_u.get() == value, 'Fail test_Try_get'



# Generated at 2022-06-24 00:23:26.679890
# Unit test for method map of class Try
def test_Try_map():
    try_test = Try(10, True)
    try_test2 = Try(20, True)
    try_test3 = Try(Exception('test'), False)

    incr_fn = lambda x: x + 1
    incr_fn2 = lambda x: x // 2

    assert try_test.map(incr_fn).__eq__(Try(11, True))
    assert try_test.map(incr_fn).map(incr_fn).__eq__(Try(12, True))
    assert try_test.map(incr_fn).map(incr_fn).map(incr_fn2).__eq__(Try(6, True))

    assert try_test2.map(incr_fn).__eq__(Try(21, True))

# Generated at 2022-06-24 00:23:32.238038
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try('Any Value', False)) == 'Try[value=Any Value, is_success=False]'
    assert str(Try('Any Value', True)) == 'Try[value=Any Value, is_success=True]'


# Generated at 2022-06-24 00:23:37.633403
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(Exception, False) == Try(Exception, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(Exception, False)


# Generated at 2022-06-24 00:23:42.875789
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    value = 1
    exp = 2  # expected value
    callback = lambda x: assertEqual(x, exp)
    # successful
    obj = Try.of(lambda x: x, value)
    obj.on_fail(callback)
    # unsuccessful
    obj = Try.of(lambda x: x/0, value)
    obj.on_fail(callback)


# Generated at 2022-06-24 00:23:48.505246
# Unit test for method bind of class Try
def test_Try_bind():
    def test(test_value):
        def mapper(value):
            return value + test_value
        return Try(3, True).bind(mapper) == Try(6, True)

    assert test(3)
    assert test(0) == (Try(3, True).bind(lambda x: x - 3) == Try(0, True))



# Generated at 2022-06-24 00:23:52.617190
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try.

    :returns: Nothing
    :rtype: None
    """
    def test(value):
        try:
            assert value
        except AssertionError:
            print("test_Try_get_or_else: FAIL")
            return

        print("test_Try_get_or_else: OK")
    test(Try(2, True).get_or_else(0) == 2)
    test(Try(None, False).get_or_else(0) == 0)


# Generated at 2022-06-24 00:23:57.518044
# Unit test for method on_fail of class Try
def test_Try_on_fail(): # pragma: no cover
    def callback(value):
        assert 3000 == value
    def raise_exception():
        raise Exception(3000)

    try_result = Try.of(raise_exception)
    try_result.on_fail(callback)
    assert try_result.is_success
    assert 3000 == try_result.get()


# Generated at 2022-06-24 00:24:07.346178
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    from unittest import TestCase, main
    from unittest.mock import Mock

    class TestTry(TestCase):
        def test_on_fail_should_call_fail_callback(self):
            # Arrange
            try_instance = Try(0, False)
            mock = Mock()

            # Act
            try_instance.on_fail(mock)

            # Assert
            self.assertEqual(mock.called, True)
            self.assertEqual(mock.call_count, 1)

        def test_on_fail_should_not_call_fail_callback(self):
            # Arrange
            try_instance = Try(0, True)
            mock = Mock()

            # Act
            try_instance.on_fail(mock)

            # Assert
            self.assertEqual

# Generated at 2022-06-24 00:24:14.187287
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    # Functional for test bind
    def test_function(num1, num2):
        return num1 + num2
    # Functional for test bind
    def filtered_function(num):
        return num > 0
    # Functional for test bind
    def success_callback(num):
        return num*2
    # Functional for test bind
    def fail_callback(exception):
        print(exception)
    # functional for test bind
    def on_fail(exception):
        print(exception)
        return exception

    # Test with successfully
    assert Try.of(test_function, 2, 5).bind(lambda value: Try.of(test_function, value, 4)).get() == 11
    # Test with not successfully

# Generated at 2022-06-24 00:24:22.260082
# Unit test for method bind of class Try
def test_Try_bind():
    """ Unit tests for method bind of class Try """
    def divide(a, b):
        if b == 0:
            raise Exception('Division by zero')
        return a / b

    def bind(x):
        return Try.of(divide, x, 0)

    assert Try(1, True).bind(bind) == Try(Exception('Division by zero'), False)
    assert Try.of(divide, 1, 3).bind(bind)\
        .map(lambda x: x ** 2).get_or_else(default_value=0)\
        == 1/3

    def bind_bind(x):
        return Try.of(divide, x, 0).bind(bind)

    assert bind_bind(1) == bind(1)



# Generated at 2022-06-24 00:24:26.827183
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(x):
        return x + x
    assert Try.of(success_callback, None).on_success(success_callback) == Try(None, False)
    assert Try.of(success_callback, 1).on_success(success_callback) == Try(2, True)


# Generated at 2022-06-24 00:24:32.276509
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda x: Try(x*2, True)) == Try(2, True)
    assert Try(1, True).bind(lambda x: Try(x/0, True)) == Try(0, False)
    assert Try(1, True).bind(lambda x: Try(x/0, False)) == Try(0, False)


# Generated at 2022-06-24 00:24:34.280099
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    res = Try.of(lambda: {}['a'])\
        .on_fail(lambda e: e == KeyError)
    assert res.value is True
    assert res.is_success is True


# Generated at 2022-06-24 00:24:42.262625
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda _: 1) == Try(1, True)

    assert Try(2, False).on_fail(lambda x: x).value == 2
    assert Try(2, False).on_fail(lambda x: x).is_success == False

    assert Try(2, False).on_fail(lambda x: x + 1).value == 3
    assert Try(2, False).on_fail(lambda x: x + 1).is_success == False


# Generated at 2022-06-24 00:24:52.233560
# Unit test for method filter of class Try
def test_Try_filter():
    class SomeClass:
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return isinstance(other, type(self)) and self.name == other.name

    def filterer(value):
        return value.name == 'test'

    class AException(Exception):
        pass

    # Successfully
    assert Try(SomeClass('test'), True).filter(filterer) == Try(SomeClass('test'), True)
    assert Try(SomeClass(''), True).filter(filterer) == Try(SomeClass(''), False)
    # Not successfully
    assert Try(AException(), False).filter(filterer) == Try(AException(), False)

# Generated at 2022-06-24 00:24:54.886718
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(None, False).get_or_else(2) == 2



# Generated at 2022-06-24 00:24:58.962357
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # GIVEN
    exception = None
    def thrower():  # type: () -> ()
        raise Exception

    def catcher(e):  # type: (Exception) -> ()
        nonlocal exception
        exception = e

    # WHEN
    Try.of(thrower).on_fail(catcher)

    # THEN
    assert isinstance(exception, Exception)



# Generated at 2022-06-24 00:25:09.981852
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test for method map of class Try.
    """
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)
    assert Try(1, True).map(None) == Try(1, True)
    assert Try(1, False).map(None) == Try(1, False)
    assert Try.of(lambda x: x + 1, 1) == Try(2, True)
    assert Try.of(lambda x: x / 0, 1) == Try(ZeroDivisionError('division by zero',), False)
    assert Try.of(lambda x: x + 1, 1).on_fail(lambda x: None) == Try(2, True)

# Generated at 2022-06-24 00:25:16.275307
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, True).filter(lambda x: x < 0).value == 1
    assert not Try(1, False).filter(lambda x: x < 0).is_success
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-24 00:25:19.175122
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(5, True) == Try(5, True)
    assert Try(5, True).__str__() == 'Try[value=5, is_success=True]'


# Generated at 2022-06-24 00:25:26.460923
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        1 / 0
    except ZeroDivisionError:
        error = sys.exc_info()[1]
        error_copy = copy.copy(error)

    called = [False]

    def on_fail(error):
        assert error_copy == error
        called[0] = True

    Try.of(lambda: 1/0).on_fail(on_fail)
    assert called[0]


# Generated at 2022-06-24 00:25:33.333604
# Unit test for method bind of class Try
def test_Try_bind():
    """ Unit testing for class Try """
    def mapper(value):
        """ a function to map """
        return value + 1

    def binder(value):
        """ a function to bind """
        return Try.of(sum, [value, 9])

    result = Try.of(mapper, 10).bind(binder)
    assert result == Try(20, True)

    result = Try.of(mapper, '10').bind(binder)
    assert result == Try('10', False)

if __name__ == "__main__":  # pragma: no cover
    test_Try_bind()

# Generated at 2022-06-24 00:25:35.777499
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert 'A' == Try('A', True).get()
    assert Exception == Try(Exception(), False).get()


# Generated at 2022-06-24 00:25:39.120604
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    value = Try(None, True).get_or_else(1)
    assert value == None
    value = Try(2, True).get_or_else(1)
    assert value == 2
    value = Try(None, False).get_or_else(1)
    assert value == 1


# Generated at 2022-06-24 00:25:43.309997
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # is_success = True
    assert Try.of(lambda : 1 + 1, None).get_or_else("default") == 2

    # is_success = False
    assert Try.of(lambda x: 1 / 0, None).get_or_else("default") == "default"
    print("test_Try_get_or_else - ok")


# Generated at 2022-06-24 00:25:45.670073
# Unit test for method map of class Try
def test_Try_map():
    def add_one(x):
        return x + 1

    assert Try(5, True).map(add_one).get() == 6
    assert Try(5, False).map(add_one).get() == 5


# Generated at 2022-06-24 00:25:48.432678
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(42, True).on_fail(lambda x: print(x)).is_success
    assert not Try(Exception(), False).on_fail(lambda x: print(x)).is_success


# Generated at 2022-06-24 00:25:52.290974
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(5, True) == Try(5, True)
    assert Try(5, False) != Try(5, True)
    assert Try(5, True) != Try(6, True)
    assert Try(5, False) != Try(6, False)


# Generated at 2022-06-24 00:25:59.439898
# Unit test for constructor of class Try
def test_Try():
    try_success = Try(1, True)
    try_fail = Try(1, False)

    assert try_success == Try(1, True)
    assert try_success != Try(2, True)
    assert try_fail == Try(1, False)
    assert try_fail != Try(2, False)
    assert try_fail != Try(3, False)
    assert str(try_success) == 'Try[value=1, is_success=True]'
    assert str(try_fail) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:26:03.770753
# Unit test for method bind of class Try
def test_Try_bind():
    class MonadTryIsSuccess(Try):
        def __init__(self):
            super().__init__(None, True)

    class MonadTryIsNotSuccess(Try):
        def __init__(self):
            super().__init__(None, False)

    def test_fn(value):
        return MonadTryIsSuccess()

    # assert_equal(MonadTryIsSuccess(), Try.of(test_fn(None)).bind(test_fn))



# Generated at 2022-06-24 00:26:07.768490
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    t1 = Try(1, True)
    t2 = Try(1, False)
    assert t1.get_or_else(2) == 1
    assert t2.get_or_else(2) == 2


# Generated at 2022-06-24 00:26:13.211004
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return True if x > 0 else False

    def filterer_false(x):
        return False

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(1, True).filter(filterer_false) == Try(1, False)
    assert Try(-1, True).filter(filterer) == Try(-1, False)



# Generated at 2022-06-24 00:26:19.979634
# Unit test for method map of class Try
def test_Try_map():
    # Test with Successfully
    value = Try(100, True).map(lambda v: v + 100).get()
    assert_equal(200, value)

    # Test with Not Successfully
    value = Try(Exception('Error'), False).map(lambda v: v + 100).get()
    assert_equal(Exception('Error'), value)


# Generated at 2022-06-24 00:26:22.177173
# Unit test for method map of class Try
def test_Try_map():
    fn = lambda arg: arg*2
    assert Try(1, True).map(fn) == Try(2, True)
    assert Try(1, False).map(fn) == Try(1, False)


# Generated at 2022-06-24 00:26:26.998857
# Unit test for method on_success of class Try
def test_Try_on_success():
    def assert_success(value):
        assert value == "some value"

    def assert_fail(value):
        assert False

    value = Try("some value", True)
    value.on_success(assert_success)

    value = Try("some value", False)
    value.on_success(assert_fail)


# Generated at 2022-06-24 00:26:30.791820
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:26:34.276263
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(None, False).get() is None
# EO test_Try_get


# Generated at 2022-06-24 00:26:36.764879
# Unit test for method on_success of class Try
def test_Try_on_success():
    # arrange
    def func(x):
        # assert
        assert x == 2

    # act
    Try(2, True).on_success(func)


# Generated at 2022-06-24 00:26:48.105063
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    """
    Unit test for method filter of class Try.

    :returns: True if all test passed, othercase False
    :rtype: Bool
    """

    # Test case when monad is successfully
    try_test = Try(1, True)
    filterer = lambda x: x == 1
    try_test_filtered = try_test.filter(filterer)

    # Check for result type
    if not isinstance(try_test_filtered, Try):
        print('Wrong result type')
        return False

    # Check for result value
    if try_test_filtered != try_test:
        print('Wrong result value')
        return False

    # Test case when monad is not successfully
    try_test = Try(1, False)
    try_test_fil

# Generated at 2022-06-24 00:26:57.153618
# Unit test for method filter of class Try
def test_Try_filter():
    # Main test
    Try.of(lambda: 'hello').filter(
        lambda x: len(x) == 5
    ).on_success(
        lambda x: print(x)
    )  # print hello

    # Test when filter returns false
    assert Try.of(lambda: 'hello').filter(
        lambda x: len(x) != 5
    ) == Try('hello', False)

    # Test when filter returns true
    assert Try.of(lambda: 'hello').filter(
        lambda x: len(x) == 5
    ) == Try('hello', True)

    # Test when try-catch is not successfully
    exception = ZeroDivisionError('division by zero')
    assert Try(exception, False).filter(
        lambda x: True
    ) == Try(exception, False)

    # Test when try-catch is

# Generated at 2022-06-24 00:26:59.131159
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception('Exception'), False)) == 'Try[value=Exception(\'Exception\',), is_success=False]'


# Generated at 2022-06-24 00:27:01.713343
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert not (Try(1, True) == Try(1, False))
    assert not (Try(1, False) == Try(1, True))
    assert Try(1, True) == Try(1, True)


# Generated at 2022-06-24 00:27:10.231576
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # When one of arguments is not instance of class Try
    assert Try(None, True) == None

    # When both of arguments is instance of class Try,
    # and is_success and value of arguments are equals.
    assert Try('success', True) == Try('success', True)

    # When both of arguments is instance of class Try,
    # and is_success of arguments aren't equals.
    assert Try('success', False) != Try('success', True)

    # When both of arguments is instance of class Try,
    # and value of arguments aren't equals.
    assert Try('success', True) != Try('failure', True)



# Generated at 2022-06-24 00:27:12.182545
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    val = Try(1, False).on_fail(lambda x: None)
    assert(val.is_success == False)


# Generated at 2022-06-24 00:27:21.282888
# Unit test for method filter of class Try
def test_Try_filter():

    # assert filter for successfully Try
    assert Try(42, is_success=True).filter(lambda x: x == 42) == Try(42, is_success=True)

    # assert filter for not successfully Try
    assert Try(42, is_success=False).filter(lambda x: x == 42) == Try(42, is_success=False)

    # assert filter for successfully Try
    assert Try(42, is_success=True).filter(lambda x: x == 24) == Try(42, is_success=False)

    # assert filter for not successfully Try
    assert Try('Exception', is_success=False).filter(lambda x: x == 42) == Try('Exception', is_success=False)

# Generated at 2022-06-24 00:27:26.740632
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    result = Try.of(lambda x: x, 2).filter(lambda x: x == 2)
    assert result == Try(2, True)
    result = Try.of(lambda x: x, 2).filter(lambda x: x == 3)
    assert result == Try(2, False)
    result = Try.of(lambda x: 2 / x, 2).filter(lambda x: x == 3)
    assert result == Try(2, True)
    result = Try.of(lambda x: 2 / x, 2).filter(lambda x: x == 3)
    assert result == Try(2, True)
    result = Try.of(lambda x: 2 / x, 0).filter(lambda x: x == 3)
    assert result == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:27:34.053409
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1 + 1).map(lambda x: x / 2).get() == 1

    assert Try.of(lambda: 1 + 1).map(lambda _: '').get() == ''

    assert Try.of(lambda: 1 + 1).map(lambda _: None).get() is None

    assert Try.of(lambda: 1 + 1).map(lambda _: True).get()

    assert Try.of(lambda: 1 + 1).map(lambda _: False).get() is False

    assert Try.of(lambda: 1 + 1).map(lambda _: []).get() == []

    assert Try.of(lambda: 1 + 1).map(lambda _: {}).get() == {}



# Generated at 2022-06-24 00:27:39.982027
# Unit test for method on_success of class Try
def test_Try_on_success():
    def foo(msg):
        print(msg)

    assert Try.of(lambda: "hello world", None)\
        .on_success(foo)\
        .is_success == True

    assert Try.of(lambda: 1/0, None)\
        .on_success(foo)\
        .is_success == False



# Generated at 2022-06-24 00:27:43.426222
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:27:45.311025
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    actual = Try('a', True)
    expected = Try('a', True)

    print(actual.__eq__(expected))



# Generated at 2022-06-24 00:27:47.515551
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:27:49.366452
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2

# Generated at 2022-06-24 00:27:54.990404
# Unit test for method get of class Try
def test_Try_get():
    def test_fn(a, b):
        return a + b
    assert Try.of(test_fn, 1, 2).get() == 3
    assert Try.of(test_fn, 1, '').get() is not None


# Generated at 2022-06-24 00:27:58.171620
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: x * 2) == Try(1, True)
    assert Try(1, False).on_success(lambda x: x * 2) == Try(1, False)



# Generated at 2022-06-24 00:28:04.255998
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    try_fail = Try(1, False)
    try_fail2 = try_fail.filter(lambda v: False)
    assert try_fail2.value == 1
    assert try_fail2.is_success == False

    try_ok = Try(1, True)
    try_ok2 = try_fail.filter(lambda v: False)
    assert try_ok2.value == 1
    assert try_ok2.is_success == False

    try_ok3 = try_fail.filter(lambda v: True)
    assert try_ok3.value == 1
    assert try_ok3.is_success == True

# Generated at 2022-06-24 00:28:12.420269
# Unit test for method bind of class Try
def test_Try_bind():
    m_1 = Try.of(int, '5')
    m_2 = m_1.bind(lambda x: Try.of(int, '5'))
    m_3 = m_2.bind(lambda x: Try.of(int, '5'))
    assert m_1.is_success
    assert m_1.value == 5
    assert m_2.is_success
    assert m_2.value == 5
    assert m_3.is_success
    assert m_3.value == 5


# Generated at 2022-06-24 00:28:16.112823
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-24 00:28:25.015228
# Unit test for method bind of class Try
def test_Try_bind():
    # Unit tests.
    t: Try[int] = Try.of(lambda x: 2 * x, 2)
    t2: Try[int] = Try.of(lambda x: 2 / x, 1)
    t3: Try[int] = Try.of(lambda x: 2 / x, 0)

    def binder(x) -> Try[int]:
        return Try(x + 1, True)

    assert t.bind(binder).get() == 5
    assert t2.bind(binder).get() == 3
    assert t3.bind(binder).is_success is False


# Unit tests for method on_success of class Try

# Generated at 2022-06-24 00:28:28.632462
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5
    assert Try(1, False).get() == 1


# Generated at 2022-06-24 00:28:30.373568
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-24 00:28:35.272544
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(value):
        assert isinstance(value, ZeroDivisionError)

    Try.of(lambda x: 1 / x, 0).on_fail(fail_callback)
    Try.of(lambda x: 1 / x, 0).on_fail(fail_callback).on_fail(fail_callback)
    Try.of(lambda x: 1 / x, 1).on_fail(fail_callback)

if __name__ == '__main__':
    test_Try_on_fail()

# Generated at 2022-06-24 00:28:42.767678
# Unit test for method bind of class Try
def test_Try_bind():
    """ If a function returns a monad, and another function takes a value and returns a monad,
    then we can compose the two and get a function that takes a value and returns a monad by using the bind method."""
    def f(value):
        return Try(value * 2, True)

    def g(value):
        return Try(value + 2, True)

    assert Try(2, True).bind(f).bind(g).get() == 8
    assert Try(3, True).bind(f).bind(g).get() == 10



# Generated at 2022-06-24 00:28:45.685288
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(value):
        assert value == 10

    try_action = Try.of(lambda x: 10 / x, 0)
    try_action.on_fail(fail_callback)
