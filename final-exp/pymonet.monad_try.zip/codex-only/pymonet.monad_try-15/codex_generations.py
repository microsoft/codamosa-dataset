

# Generated at 2022-06-24 00:18:47.048681
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(5, True).get_or_else(10) == 5
    assert Try(5, False).get_or_else(10) == 10



# Generated at 2022-06-24 00:18:49.858396
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert_that(
        Try.of(int, '1').on_fail(lambda e: assert_that(e, instance_of(ValueError))),
        equal_to(Try.of(int, '1'))
    )



# Generated at 2022-06-24 00:18:55.572295
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: x+1) == Try(1, True)
    assert Try(1, True).on_success(lambda x: x).on_success(lambda x: x+1) == Try(2, True)
    assert Try(1, False).on_success(lambda x: x+1) == Try(1, False)
    assert Try(1, False).on_success(lambda x: x).on_success(lambda x: x+1) == Try(1, False)


# Generated at 2022-06-24 00:18:59.155613
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(int, '123').bind(
        lambda _: Try(100, True)
    ) == Try(100, True)
    assert Try.of(int, 'abc').bind(
        lambda _: Try(100, True)
    ) == Try(ValueError, False)


# Generated at 2022-06-24 00:19:00.271943
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'


# Generated at 2022-06-24 00:19:05.655963
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)

    assert Try(1, True) != Try(5, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(5, False)


# Generated at 2022-06-24 00:19:08.350990
# Unit test for constructor of class Try
def test_Try():
    value = "test"
    try_success = Try(value, True)
    assert try_success.is_success
    assert try_success.value == value

    try_fail = Try(value, False)
    assert not try_fail.is_success
    assert try_fail.value == value


# Generated at 2022-06-24 00:19:19.536876
# Unit test for method bind of class Try
def test_Try_bind():
    fn1 = lambda x: x + 1
    fn2 = lambda x: Try.of(fn1, x)
    assert Try.of(lambda: 0).bind(fn2) == Try(1, True)
    assert Try.of(lambda: 0).bind(lambda x: Try.of(fn1, x)) == Try(1, True)
    assert Try.of(lambda: 0).bind(lambda x: Try.of(fn1, 1)) == Try(1, True)
    assert Try.of(lambda: 1 / 0).bind(fn2) == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(lambda: 1 / 0).bind(lambda x: Try.of(fn1, x)) == Try(ZeroDivisionError('division by zero'), False)

# Generated at 2022-06-24 00:19:23.850269
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(x):
        return Try(x, True)

    assert Try(None, True).bind(binder) == Try(None, True)
    assert Try(None, False).bind(binder) == Try(None, False)



# Generated at 2022-06-24 00:19:33.723138
# Unit test for method get of class Try
def test_Try_get():
    class Value:
        def __init__(self, v):
            self.v = v

        def __eq__(self, other):
            return isinstance(other, type(self)) and self.v == other.v

    assert Try.of(lambda: 5, None).get() == 5
    assert Try.of(lambda: None, None).get() is None
    assert Try.of(lambda: Value(5), None).get() == Value(5)
    assert Try.of(lambda: 5/0, None).get() == ZeroDivisionError('division by zero')
    assert Try.of(Value, None, 5).get() == Value(5)
    assert Try.of(Value, None, 5).get() == Value(5)
    assert Try.of(Value, None, 5).get_or_else(7) == Value

# Generated at 2022-06-24 00:19:36.895947
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(1, True).get() == 1



# Generated at 2022-06-24 00:19:41.706355
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(3, True)) == 'Try[value=3, is_success=True]'
    assert str(Try(3, False)) == 'Try[value=3, is_success=False]'



# Generated at 2022-06-24 00:19:48.268365
# Unit test for method map of class Try
def test_Try_map():
    result = Try.of(lambda x: x, [1, 2, 3])\
        .map(lambda l: l[0])
    assert result == Try(1, True)

    result = Try.of(lambda x: x, [1, 2, 3])\
        .map(lambda l: l[10000])
    assert result == Try(IndexError('list index out of range'), False)


# Generated at 2022-06-24 00:19:52.549905
# Unit test for method filter of class Try
def test_Try_filter():
    try:
        raise Exception('test_Try_filter')
    except Exception as e:
        assert Try.of(lambda: 42, ).filter(lambda x: x % 2 == 0) == Try(42, True)
        assert Try.of(lambda: 41, ).filter(lambda x: x % 2 == 0) == Try(e, False)
        assert Try.of(lambda: e, ).filter(lambda x: x % 2 == 0) == Try(e, False)
        assert Try.of(lambda: 1 / 0, ).filter(lambda x: x % 2 == 0) == Try(ZeroDivisionError(), False)
    return 'test_Try_filter done'


# Generated at 2022-06-24 00:19:55.160487
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) == Try(1, False) is False
    assert Try(1, True) == Try(2, True) is False


# Generated at 2022-06-24 00:19:58.628351
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    e = Try(Exception('Expected exception'), False)

    def fail_callback(ex):
        assert (ex.args == ('Expected exception',))

    e.on_fail(fail_callback)



# Generated at 2022-06-24 00:20:02.801609
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(dict, [['a', 1]])) == "Try[value={'a': 1}, is_success=True]"
    assert str(Try(ValueError(), False)) == "Try[value=ValueError(), is_success=False]"


# Generated at 2022-06-24 00:20:08.581293
# Unit test for method bind of class Try
def test_Try_bind():
    def check_even(value):
        if value % 2 == 0:  # pragma: no cover
            return Try.of(lambda _: value, None)
        raise ValueError(value)

    result = Try.of(lambda x: x, 1)
    assert result.bind(check_even) == Try(ValueError(1), False)

    result = Try.of(lambda x: x, 2)
    assert result.bind(check_even) == Try(2, True)

# Generated at 2022-06-24 00:20:15.772055
# Unit test for method map of class Try
def test_Try_map():
    value = Try.of(lambda: 2).map(lambda x: x + 1).get()
    expected_value = 3
    assert value == expected_value

    value = Try.of(lambda: 2).map(lambda x: x / 0).get()
    expected = ZeroDivisionError()
    assert value == expected


# Generated at 2022-06-24 00:20:17.043920
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-24 00:20:21.688340
# Unit test for method on_success of class Try
def test_Try_on_success():
    from utils.test_utils import assert_test

    def func1(m: int) -> int:
        def anon_func():
            print(m)
        return m

    assert_test(lambda: Try.of(func1, 1).on_success(anon_func), 1)
    assert_test(lambda: Try.of(func1, 0).on_success(anon_func), 0)


# Generated at 2022-06-24 00:20:25.332312
# Unit test for constructor of class Try
def test_Try():
    try_value = Try("foo", True)
    assert try_value.value == "foo"
    assert try_value.is_success == True

    try_value = Try("foo", False)
    assert try_value.value == "foo"
    assert try_value.is_success == False
    assert try_value.get() == "foo"


# Generated at 2022-06-24 00:20:28.621700
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(3, False).map(lambda x: x + 1) == Try(3, False)



# Generated at 2022-06-24 00:20:34.437720
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'



# Generated at 2022-06-24 00:20:37.641991
# Unit test for constructor of class Try
def test_Try():
    # Successfully Try
    assert Try('foo', True) == Try('foo', True)
    # Not successfully Try
    assert Try('foo', False) == Try('foo', False)
    # Successfully Try with value of exception
    assert Try.of(lambda a: 1 / a, 0) == Try(ZeroDivisionError("integer division or modulo by zero"), False)


# Generated at 2022-06-24 00:20:40.371569
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    actual = Try(1, True)
    expected = Try(1, True)
    assert actual == expected



# Generated at 2022-06-24 00:20:42.237270
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:20:47.934951
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback_results(x):
        global success_callback_results
        success_callback_results = x
    def fail_callback(x):
        pass
    try_case = Try(1, True)
    try_case.on_success(success_callback_results).on_fail(fail_callback)
    assert success_callback_results == 1


# Generated at 2022-06-24 00:20:51.345557
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    success_try = Try(1, True)
    fail_try = Try(1, False)
    assert success_try != fail_try
    assert success_try == Try(1, True)


# Generated at 2022-06-24 00:21:00.563213
# Unit test for constructor of class Try
def test_Try():
    error = Exception('Exception message')
    value = {}

    # All following function return Try with value 9
    fn1 = lambda: 9
    fn2 = lambda x: 9
    fn3 = lambda x, y, z: 9

    try_fn1 = Try(fn1, True)
    try_fn2 = Try(fn2, True)
    try_fn3 = Try(fn3, True)

    # Test Try on_success method
    try_fn1.on_success(lambda x: value.__setitem__('on_success', x()))
    assert value.get('on_success') == 9
    value. clear()
    try_fn2.on_success(lambda x: value.__setitem__('on_success', x(9)))
    assert value.get('on_success') == 9
    value. clear

# Generated at 2022-06-24 00:21:02.792889
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1



# Generated at 2022-06-24 00:21:06.446352
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda x: x, 42).get_or_else(-1) == 42
    assert Try.of(lambda: 1 / 0).get_or_else(-1) == -1

# Generated at 2022-06-24 00:21:11.881782
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    print('test_Try_filter')
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(2, True).filter(lambda x: x == 2) == Try(2, True)
    assert Try(2, False).filter(lambda x: x == 2) == Try(2, False)


# Generated at 2022-06-24 00:21:17.607120
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x % 2 == 0) == Try(5, False)
    assert Try(6, True).filter(lambda x: x % 2 == 0) == Try(6, True)
    assert Try(6, False).filter(lambda x: True) == Try(6, False)



# Generated at 2022-06-24 00:21:23.304802
# Unit test for method get of class Try
def test_Try_get():
    def f():
        return 1
    assert Try.of(f).get() == 1
    assert Try.of(1.0 / 0).get() == Try.of(1.0 / 0).get()
    assert not Try.of(1.0 / 0) == Try.of(1.0 / 0)


# Generated at 2022-06-24 00:21:31.776740
# Unit test for method map of class Try
def test_Try_map():
    test_value = "hello world"
    assert Try.of(lambda: test_value).map(lambda v: v.upper()) == Try(test_value.upper(), True)
    assert Try.of(lambda: test_value).map(lambda v: 1 / 0) == Try(test_value, True)
    assert Try.of(lambda: 1 / 0).map(lambda v: v.upper()) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: test_value).map(lambda v: 1 / 0).map(lambda v: v.upper()) == Try(test_value, True)


# Generated at 2022-06-24 00:21:33.347022
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(None, True).get() is None


# Generated at 2022-06-24 00:21:36.517454
# Unit test for method filter of class Try
def test_Try_filter():
    # Success Try
    t1 = Try.of(lambda: 'abc').filter(lambda string: True if len(string) == 3 else False)
    assert t1 == Try('abc', True)

    # Not Successfully Try
    t2 = Try.of(lambda: 'abc').filter(lambda string: True if len(string) == 4 else False)
    assert t2 == Try('abc', False)


# Generated at 2022-06-24 00:21:47.289308
# Unit test for constructor of class Try

# Generated at 2022-06-24 00:21:53.580731
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 5,).on_success(lambda x: x + 1)\
        == Try(6, True)
    assert Try.of(lambda: 5,).on_success(lambda x: x + 1)\
        != Try(6, False)
    assert Try.of(lambda: 5,).on_success(lambda x: x + 1)\
        != Try(4, True)
    assert Try.of(lambda: 5,).on_success(lambda x: x + 1)\
        != Try(4, False)



# Generated at 2022-06-24 00:22:03.178297
# Unit test for method filter of class Try
def test_Try_filter():
    print('Test Try filter method')
    data = None
    result = Try.of(lambda x: int(x), data).filter(lambda x: x > 0).is_success
    assert not result
    print('Test Try filter method with get_or_else')
    data = None
    result = Try.of(lambda x: int(x), data).filter(lambda x: x > 0).get_or_else(-1)
    assert result == -1
    print('Test Try filter method - successful')
    data = '1'
    result = Try.of(lambda x: int(x), data).filter(lambda x: x > 0).is_success
    assert result
    print('Test Try filter method - successful with get_or_else')
    data = '1'

# Generated at 2022-06-24 00:22:08.351624
# Unit test for method bind of class Try
def test_Try_bind():
    def double(x):
        return x * 2

    def always_success_binder(monad_value):
        return Try(monad_value, True)

    def always_fail_binder(monad_value):
        return Try(monad_value, False)

    def with_failure_binder(monad_value):
        return Try(monad_value, False if monad_value > 10 else True)

    assert Try.of(double, 2).bind(always_success_binder) == Try(4, True)
    assert Try.of(double, 2).bind(always_fail_binder) == Try(2, True)
    assert Try.of(double, 2).bind(with_failure_binder) == Try(4, True)


# Generated at 2022-06-24 00:22:11.591505
# Unit test for method get of class Try
def test_Try_get():
    assert Try(11, True).get() == 11
    assert Try(11, False).get() == 11


# Generated at 2022-06-24 00:22:16.065381
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(Exception, False).get() == Exception


# Generated at 2022-06-24 00:22:20.467854
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(10, True).filter(lambda x: x > 7) == Try(10, True)
    assert Try(10, True).filter(lambda x: x < 5) == Try(10, False)
    assert Try(10, False).filter(lambda x: x > 7) == Try(10, False)
    assert Try(10, False).filter(lambda x: x < 5) == Try(10, False)


# Generated at 2022-06-24 00:22:26.049621
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:22:31.748801
# Unit test for method on_success of class Try
def test_Try_on_success():
    t1 = Try(10, True)
    assert t1.value == 10
    assert t1.is_success

    t1.on_success(lambda value: print(value))
    # output: 10

    t2 = Try(10, False)
    assert t2.value == 10
    assert not t2.is_success

    t2.on_success(lambda value: print(value))
    # no output

    print('test_Try_on_success passed')



# Generated at 2022-06-24 00:22:34.605320
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    result = Try.of(lambda x: x, 123).on_fail(lambda e: e)
    assert result == Try(123, True)

    result = Try.of(lambda x: 1 / 0, 123).on_fail(lambda e: None)
    assert result == Try(ZeroDivisionError('division by zero'), False)

# Generated at 2022-06-24 00:22:41.636217
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda x, y: x + y, 4, 5) \
        .on_fail(lambda x: print(x)) \
        == Try(9, True)

    assert Try.of(lambda x, y: 'something bad', 4, 5) \
        .on_fail(lambda x: print(x)) \
        == Try('something bad', False)



# Generated at 2022-06-24 00:22:46.940510
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try.

    :returns: True when test passed, othercase False
    :rtype: Boolean
    """
    from random import randint

    def _random_value():
        return randint(1, 100)

    for _ in range(10):
        assert Try(None, False) == Try(None, False)
        assert Try(None, True) == Try(None, True)
        assert Try(_random_value(), False) == Try(_random_value(), False)
        assert Try(_random_value(), True) == Try(_random_value(), True)

    return True


# Generated at 2022-06-24 00:22:48.567320
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    a = Try(1, True)
    b = Try(1, True)
    assert a == b


# Generated at 2022-06-24 00:22:55.426827
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Here the test for Try.filter method.
    """
    # when predicate return True
    result = Try(10, True).filter(lambda x: x > 5)

    assert result == Try(10, True)

    # when predicate return False
    result = Try(10, True).filter(lambda x: x < 5)

    assert result == Try(10, False)

    # when predicate return False and Exception
    result = Try(10, False).filter(lambda x: x < 5)

    assert result == Try(10, False)


# Generated at 2022-06-24 00:22:59.158226
# Unit test for method on_success of class Try
def test_Try_on_success():
    def fn():
        raise(Exception)
    def success_callback(value):
        pass
    assert Try(100, True).on_success(success_callback) == Try(100, True)
    assert Try.of(fn).on_success(success_callback) == Try.of(fn)


# Generated at 2022-06-24 00:23:05.293966
# Unit test for constructor of class Try
def test_Try():
    # Test for constructor of class Try with successful case
    assert Try('foo', True) == Try('foo', True)
    assert Try('foo', True).value == 'foo'
    assert Try('foo', True).is_success is True
    assert str(Try('foo', True)) == 'Try[value=foo, is_success=True]'

    # Test for constructor of class Try with not successful case
    assert Try('foo', False) == Try('foo', False)
    assert Try('foo', False).value == 'foo'
    assert Try('foo', False).is_success is False
    assert str(Try('foo', False)) == 'Try[value=foo, is_success=False]'



# Generated at 2022-06-24 00:23:12.612410
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True).value == 1
    assert Try(1, True).is_success is True
    assert Try(1, False).value == 1
    assert Try(1, False).is_success is False
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)


# Generated at 2022-06-24 00:23:16.182703
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """Unit test for method Try.get_or_else."""
    assert Try('a', True).get_or_else(None) == 'a'
    assert Try('a', False).get_or_else('b') == 'b'


# Generated at 2022-06-24 00:23:18.241107
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_obj = Try(5, True)
    assert try_obj.get_or_else(4) == 5
    try_obj = Try(None, False)
    assert try_obj.get_or_else(4) == 4


# Generated at 2022-06-24 00:23:22.330071
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    try_1 = Try(1, True)
    try_2 = Try(1, True)
    try_3 = Try(2, True)
    assert try_1 == try_1
    assert try_1 == try_2
    assert try_1 != try_3


# Generated at 2022-06-24 00:23:27.015830
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_try():
        def dummy():
            raise Exception('Test Exception')

        try:
            dummy()
        except Exception as e:
            return e

    t1 = Try.of(test_try)
    t2 = Try.of(lambda: 1)

    assert t1.on_fail(lambda e: print(e)) == t1
    assert t2.on_fail(lambda e: print(e)) == t2



# Generated at 2022-06-24 00:23:33.667035
# Unit test for method map of class Try
def test_Try_map():

    def fn_raise_exception_try_map(n):
        if n > 3:
            raise RecursionError('n must be <= 3')
        return n + 1

    assert Try.of(fn_raise_exception_try_map, 1).map(lambda x: x ** 2).get() == 4
    assert Try.of(fn_raise_exception_try_map, 3).map(lambda x: x ** 2).get() == 10
    assert Try.of(fn_raise_exception_try_map, 4).map(lambda x: x ** 2).get() == RecursionError('n must be <= 3')

test_Try_map()



# Generated at 2022-06-24 00:23:35.503412
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10



# Generated at 2022-06-24 00:23:44.601847
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_with_successful(value: int, expected: int):
        actual: bool = False
        def set_actual_to_true(_):
            nonlocal actual
            actual = True
        Try(value, True).on_success(set_actual_to_true)
        assert actual == expected

    test_with_successful(0, True)

    def test_with_not_successful(value: int, expected: int):
        actual: bool = False
        def set_actual_to_true(_):
            nonlocal actual
            actual = True
        Try(value, False).on_success(set_actual_to_true)
        assert actual == expected

    test_with_not_successful(0, False)


# Generated at 2022-06-24 00:23:53.883762
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Given of:
        - class Try,
        - instance of Try with value 1 and is_success = True,
        - instance of Try with value 1 and is_success = False,
        - on_success_1 function,
        - on_success_2 function
    When:
        - call Try.on_success(on_success_1)
        - call Try.on_success(on_success_2)
    Then:
        - on_success_1 function must call with value 1
        - on_success_2 function must not call with value 1
    """
    i1 = 0
    i2 = 0

    def on_success_1(value):
        nonlocal i1
        if value == 1:
            i1 += 1

    def on_success_2(value):
        nonlocal i2

# Generated at 2022-06-24 00:24:01.462528
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    callback = lambda _: print('value is {}'.format(_))
    on_fail_result = Try.of(lambda _: _ + 1, 2).map(lambda _: _ + 2).on_fail(callback)
    assert on_fail_result.is_success

    on_fail_result = Try.of(lambda _: raise_exception(), None).map(lambda _: _ + 2).on_fail(callback)
    assert not on_fail_result.is_success



# Generated at 2022-06-24 00:24:03.602375
# Unit test for method get of class Try
def test_Try_get():
    v = 13
    assert(Try(v, True).get() == v)
    assert(Try(v, False).get() == v)

# Generated at 2022-06-24 00:24:06.669560
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'



# Generated at 2022-06-24 00:24:13.748523
# Unit test for method __eq__ of class Try
def test_Try___eq__():

    try:
        raise ValueError('error 1')
    except Exception as e1:
        try:
            raise ValueError('error 2')
        except Exception as e2:
            try:
                raise ValueError('error 3')
            except Exception as e3:
                try:
                    raise ValueError('error 4')
                except Exception as e4:
                    try:
                        raise ValueError('error 5')
                    except Exception as e5:

                        assert Try(_, True) == Try(_, True)
                        assert Try(_, False) == Try(_, False)
                        assert not Try(_, True) == Try(_, False)
                        assert not Try(_, False) == Try(_, True)

                        assert Try(e1, True) == Try(e1, True)
                        assert Try(e2, False) == Try(e2, False)


# Generated at 2022-06-24 00:24:16.947903
# Unit test for method bind of class Try
def test_Try_bind():
    # Arrange
    try_instance = Try(1, True)
    binder = lambda x: Try(x + 1, True)

    # Act
    try_instance_2 = try_instance.bind(binder)

    # Assert
    assert(try_instance_2.value == try_instance.value + 1)
    assert(try_instance_2.is_success == True)

# Generated at 2022-06-24 00:24:21.514188
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(3, True)) == 'Try[value=3, is_success=True]'
    assert str(Try(3, False)) == 'Try[value=3, is_success=False]'
    assert str(Try('error', False)) == 'Try[value=error, is_success=False]'


# Generated at 2022-06-24 00:24:23.717292
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(Exception('e'), False).get() == Exception('e')


# Generated at 2022-06-24 00:24:28.539204
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(123, True).filter(lambda x: True)\
        == Try(123, True)
    assert Try(123, True).filter(lambda x: False)\
        == Try(123, False)
    assert Try(123, False).filter(lambda x: True)\
        == Try(123, False)

# Generated at 2022-06-24 00:24:34.347535
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(123, True)) == 'Try[value=123, is_success=True]'
    assert str(Try(123, False)) == 'Try[value=123, is_success=False]'
    assert str(Try(Exception('123'), True)) == 'Try[value=123, is_success=True]'
    assert str(Try(Exception('123'), False)) == 'Try[value=123, is_success=False]'



# Generated at 2022-06-24 00:24:39.010061
# Unit test for method map of class Try
def test_Try_map():
    def add(x: int) -> int:
        return x + 1

    assert Try(1, True).map(add) == Try(2, True)
    assert Try(1, False).map(add) == Try(1, False)


# Generated at 2022-06-24 00:24:43.006970
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try('test', True).on_success(print).value == 'test'
    assert not Try('test', False).on_success(print).is_success



# Generated at 2022-06-24 00:24:46.666443
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    mock_value = 'test'
    mock_fail_callback = Mock()

    mock_fail_callback.assert_not_called()

    Try(mock_value, False).on_fail(mock_fail_callback)

    mock_fail_callback.assert_called_once_with(mock_value)



# Generated at 2022-06-24 00:24:48.337819
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1).get_or_else(2) == 1
    assert Try.of(lambda: 1/0).get_or_else(2) == 2

# Generated at 2022-06-24 00:24:50.809723
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, False)) == "Try[value=1, is_success=False]"


# Generated at 2022-06-24 00:24:59.907502
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    """
    Unit test for method bind of class Try that simulates one-level nesting of try-catch blocks.
    """

    def div(a, b):
        return a / b

    def inc(a):
        return a + 1

    def safe_div_bind(a, b):
        return Try.of(div, a, b).bind(inc)

    if __name__ == '__main__':
        # expected value: Successfully Try with value(1)
        print('1:', Try.of(div, 1, 0).bind(inc))
        # expected value: Not successfully Try with value(ZeroDivisionError)
        print('2:', Try.of(div, 0.1, 0).bind(inc))
        # expected value: Successfully Try with value(1)

# Generated at 2022-06-24 00:25:10.552314
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def add_one(a):
        return Try(a + 1, True)

    result = Try\
        .of(lambda: [1, 2, 3, 4, 5])\
        .bind(lambda a: [add_one(x) for x in a])\
        .bind(lambda a: Try(sum(x.value for x in a), True))

    assert result == Try(20, True)

    result = Try\
        .of(lambda: [Try(2, True), Try(3, True), Try(4, False), Try(5, True)])\
        .bind(lambda a: [add_one(x.value) for x in a])\
        .bind(lambda a: Try(sum(x.value for x in a), True))


# Generated at 2022-06-24 00:25:14.929222
# Unit test for constructor of class Try
def test_Try():
    result = Try(1, True)
    assert isinstance(result, Try)
    assert result == Try(1, True)
    assert result.value == 1
    assert result.is_success
    assert str(result) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-24 00:25:18.572160
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(0, False) != Try(1, True)
    assert Try(0, False) != Try(1, False)
    assert Try(1, True) != Try(1, False)



# Generated at 2022-06-24 00:25:25.394794
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    def fail_function(*args):
        return 1 / 0

    def success_function(*args):
        return args[0] + args[1]

    assert Try.of(fail_function, 1, 2).get_or_else("Fail") == "Fail"
    assert Try.of(success_function, 1, 2).get_or_else("Fail") == 3

# Generated at 2022-06-24 00:25:29.904704
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def some_function(param):
        return param + 1

    try_success = Try.of(lambda: 2, ())
    assert try_success.map(some_function).get() == 3

    try_error = Try.of(lambda: 1 / 0, ())
    assert try_error.map(some_function).get() == ZeroDivisionError



# Generated at 2022-06-24 00:25:35.686673
# Unit test for method get of class Try
def test_Try_get():
    assert_that(Try(42, True).get(), equal_to(42))
    assert_that(Try(42, False).get(), equal_to(42))


# Generated at 2022-06-24 00:25:42.395568
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def dummy_fn(a):
        raise Exception('test_Try_on_fail_Exception')
    
    def fail_fn(e):
        assert not isinstance(e, Exception)

    def fail_fn_fail(e):
        assert str(e) == 'test_Try_on_fail_Exception'

    assert Try(Try.of(dummy_fn, 11).on_fail(fail_fn_fail), False) == Try(Try.of(dummy_fn, 11).on_fail(fail_fn), False)
    # test result is not successful, because it is copy of self

test_Try_on_fail()


# Generated at 2022-06-24 00:25:47.590879
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: [1, 2, 3])\
        .on_success(lambda arr: arr.extend([4, 5]))\
        == Try([1, 2, 3, 4, 5], True)

    assert Try.of(lambda: 1 / 0)\
        .on_success(lambda arr: arr.extend([4, 5]))\
        == Try(ZeroDivisionError('division by zero'), False)



# Generated at 2022-06-24 00:25:49.976930
# Unit test for method get of class Try
def test_Try_get():
    value = 'x'
    assert Try(value, True).get() == value, 'Try must return value'


# Generated at 2022-06-24 00:25:54.352194
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(2, False) == Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)

test_Try()



# Generated at 2022-06-24 00:25:59.220928
# Unit test for constructor of class Try
def test_Try():
    """
    Test constructor of class Try
    """
    assert Try(1, True).__eq__(Try(1, True))
    assert not Try(1, True).__eq__(Try(2, True))
    assert not Try(1, True).__eq__(Try(1, False))
    assert not Try(1, False).__eq__(Try(2, False))


# Generated at 2022-06-24 00:26:02.438869
# Unit test for method map of class Try
def test_Try_map():
    assert Try(10, True).map(lambda x: x * 2) == Try(20, True)
    assert Try(10, False).map(lambda x: x * 2) == Try(10, False)


# Generated at 2022-06-24 00:26:08.025305
# Unit test for method get of class Try
def test_Try_get():
    def some_function():
        return 35

    def another_function(x):
        return x / 2

    get_result = Try.of(some_function).get()
    assert get_result == 35
    get_result = Try.of(another_function, 35).get()
    assert get_result == 17.5



# Generated at 2022-06-24 00:26:12.643104
# Unit test for method on_success of class Try
def test_Try_on_success():
    success = Try(1, True)
    result = success.on_success(lambda x: x * 2).get()
    assert result == 2
    fail = Try(ZeroDivisionError(), False)
    result = fail.on_success(lambda x: x * 2).get()
    assert result == ZeroDivisionError()



# Generated at 2022-06-24 00:26:18.111506
# Unit test for method get of class Try
def test_Try_get():
    value = 5
    try_monad = Try(value, True)

    get_value = try_monad.get()

    assert get_value == value



# Generated at 2022-06-24 00:26:21.014142
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert Try(1, True).__str__() == 'Try[value=1, is_success=True]'
    assert Try(1, False).__str__() == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:26:24.162398
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, True)


# Generated at 2022-06-24 00:26:28.395273
# Unit test for method filter of class Try
def test_Try_filter():
    try_value = Try(1, True)
    result = try_value.filter(lambda x: x > 0)
    assert result == Try(1, True)
    result = try_value.filter(lambda x: x < 0)
    assert result == Try(1, False)



# Generated at 2022-06-24 00:26:38.142186
# Unit test for method bind of class Try
def test_Try_bind():
    def test_failure_function():
        def raise_function():
            raise Exception('test failure function')
        return raise_function

    def test_function():
        some_value = 2
        def testing_function(value):
            nonlocal some_value
            some_value = some_value + value
            return some_value
        return testing_function

    def test_function_with_failure(some_value):
        try:
            if some_value % 3 == 0:
                return Try(some_value, True)
            raise Exception('test failure function')
        except Exception as e:
            return Try(e, False)

    assert Try.of(test_failure_function()).bind(lambda v: v) == Try('test failure function', False)

# Generated at 2022-06-24 00:26:39.788526
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try('', False).on_fail(lambda e: print("exception: ", e)) == Try('', False)



# Generated at 2022-06-24 00:26:41.670669
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(10, True).get_or_else(0) == 10
    assert Try(10, False).get_or_else(0) == 0

# Generated at 2022-06-24 00:26:44.716584
# Unit test for constructor of class Try
def test_Try():
    result_null = Try(None, True)
    expected_result_null = Try(None, True)
    assert (result_null == expected_result_null)

    result_exception = Try(Exception("Test"), False)
    expected_result_exception = Try(Exception("Test"), False)
    assert (result_exception == expected_result_exception)



# Generated at 2022-06-24 00:26:49.636606
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, False) == Try(1, True)
    assert not Try('a', True) == Try(1, True)
    assert not Try(1, True) == Try('a', True)
    assert not Try('a', True) == Try(1, False)


# Generated at 2022-06-24 00:26:54.159035
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x)).is_success
    assert not Try(Exception('exception'), False).on_success(lambda x: print(x)).is_success


# Generated at 2022-06-24 00:27:00.236770
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def a():
        return 10

    def b():
        raise ValueError()

    assert Try.of(a).get_or_else(0) == 10
    assert Try.of(b).get_or_else(0) == 0

    class Person:
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-24 00:27:03.898240
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_1 = Try(1, True)
    assert try_1.get_or_else(2) == 1
    assert try_1.get_or_else('default') == 1

    try_2 = Try(1, False)
    assert try_2.get_or_else(2) == 2
    assert try_2.get_or_else('default') == 'default'



# Generated at 2022-06-24 00:27:07.826533
# Unit test for method map of class Try
def test_Try_map():
    result = Try.of(lambda x, y: x + y, 100, 50).map(lambda x: x * 2)
    assert result == Try(300, True)

    result = Try.of(lambda x, y: x + y, 100, '51').map(lambda x: x * 2)
    assert result == Try('5251', False)



# Generated at 2022-06-24 00:27:12.848032
# Unit test for method get of class Try
def test_Try_get():
    value = 'foo'
    result_from_Try = Try(value, True)
    result_from_Try_not_successfully = Try(value, False)

    assert result_from_Try.get() == value
    assert result_from_Try_not_successfully.get() == value


# Generated at 2022-06-24 00:27:18.785553
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(lambda x: x, 1)) == "Try[value=1, is_success=True]"
    assert str(Try.of(lambda: 1 / 0)) == "Try[value=division by zero, is_success=False]"



# Generated at 2022-06-24 00:27:22.393190
# Unit test for method map of class Try
def test_Try_map():
    def f(x: int) -> int:
        return x + 1

    a = Try.of(f, 6)
    assert a.map(f) == Try(8, True)

    a = Try.of(f, Exception(6))
    assert a.map(f) == Try(Exception(6), False)
# end test_Try_map


# Generated at 2022-06-24 00:27:25.481427
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(12, True)
    assert str(try_) == 'Try[value=12, is_success=True]'
    try_ = Try(12, False)
    assert str(try_) == 'Try[value=12, is_success=False]'


# Generated at 2022-06-24 00:27:27.520842
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1



# Generated at 2022-06-24 00:27:29.835574
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else(1) == 42
    assert Try(42, False).get_or_else(1) == 1


# Generated at 2022-06-24 00:27:33.018114
# Unit test for constructor of class Try
def test_Try():
    Try(2, True)
    Try(RuntimeError(), False)


# Generated at 2022-06-24 00:27:34.492072
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5
    assert Try(5, False).get() == 5


# Generated at 2022-06-24 00:27:35.961946
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(None, True).get() is None


# Generated at 2022-06-24 00:27:40.829332
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(5, True).get_or_else(10) == 5
    assert Try(None, True).get_or_else(10) is None
    assert Try(*Try.of(int, '5')).get_or_else(10) == 5
    assert Try(*Try.of(int, 'a')).get_or_else(10) == 10



# Generated at 2022-06-24 00:27:44.624339
# Unit test for constructor of class Try
def test_Try():
    def succ_fn(arg):
        return "success"

    def fail_fn(arg):
        raise Exception("fail")

    assert Try.of(succ_fn, "arg") == Try("success", True)
    assert Try.of(fail_fn, "arg") == Try(Exception("fail"), False)



# Generated at 2022-06-24 00:27:47.183680
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Unit test for method on_success of class Try.

    """
    try_flow = Try.of(lambda: 1)
    assert try_flow.on_success(lambda n: n + 1).get() == 2


# Generated at 2022-06-24 00:27:48.071373
# Unit test for method get of class Try
def test_Try_get():
    assert Try(4, True).get() == 4


# Generated at 2022-06-24 00:27:52.180272
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True))=='Try[value=1, is_success=True]'
    assert str(Try(1, False))=='Try[value=1, is_success=False]'
    assert str(Try('a', True))=='Try[value=a, is_success=True]'
    assert str(Try('a', False))=='Try[value=a, is_success=False]'


# Generated at 2022-06-24 00:27:55.189504
# Unit test for method get of class Try
def test_Try_get():
    maybe_name = Try('Alice', True)
    assert maybe_name.get() == 'Alice'


# Generated at 2022-06-24 00:27:58.381823
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    example_try = Try(10, True)
    assert example_try.get_or_else(0) == 10
    example_try = Try(10, False)
    assert example_try.get_or_else(0) == 0



# Generated at 2022-06-24 00:28:01.781439
# Unit test for method map of class Try
def test_Try_map():
    success = 1
    fail = 0
    assert Try(success, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(fail, False).map(lambda x: x + 1) == Try(fail, False)



# Generated at 2022-06-24 00:28:08.654681
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False) != Try(2, True)


# Generated at 2022-06-24 00:28:11.871068
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(7, True)) == 'Try[value=7, is_success=True]'
    assert str(Try(7, False)) == 'Try[value=7, is_success=False]'


# Generated at 2022-06-24 00:28:14.129461
# Unit test for method on_success of class Try
def test_Try_on_success():
    called = False
    Try.of(lambda: 2)\
        .on_success(lambda v: setattr(called, 'value', True))
    assert called.value


# Generated at 2022-06-24 00:28:17.143928
# Unit test for method get of class Try
def test_Try_get():
    assert_that(Try(1, True).get(), equal_to(1), 'get() should return 1')
    assert_that(Try(1, False).get(), equal_to(1), 'get() should return 1')


# Generated at 2022-06-24 00:28:18.927180
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test1(x):
        assert x == 1
    def test2(x):
        assert x == 2

    assert Try(2, True).on_success(test1) == Try(2, True)
    assert Try(1, True).on_success(test2) == Try(1, True)

# Generated at 2022-06-24 00:28:25.777791
# Unit test for method bind of class Try
def test_Try_bind():
    # Given
    def f(r: int) -> Try[int]:
        return r / 2
    def g(r: int) -> Try[int]:
        return r - 5
    x = Try(5, True)

    # When
    y1 = x.bind(f)
    y2 = y1.bind(g)

    # Then
    assert y2.value == f(x.value).value / g(y1.value).value


# Generated at 2022-06-24 00:28:35.027821
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda x: Try(x, True)) == Try(1, True)
    assert Try(1, False).bind(lambda x: Try(x, True)) == Try(1, False)

    inc = lambda x: Try(x + 1, True)
    assert Try(1, True).bind(inc) == Try(2, True)
    assert Try(1, True).bind(inc).bind(inc) == Try(3, True)
    assert Try(1, True).bind(inc).bind(inc).bind(inc) == Try(4, True)



# Generated at 2022-06-24 00:28:36.978578
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    t = Try(3, True)
    assert t.get() == 3



# Generated at 2022-06-24 00:28:42.106625
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    eq_(Try('1', True), Try('1', True))
    eq_(Try(1, False), Try(1, False))
    ne_(Try(1, False), Try(2, False))
    eq_(Try(1, False), Try('1', False))
    ne_(Try(1, True), Try('1', False))
    ne_(Try(1, False), Try(2, True))



# Generated at 2022-06-24 00:28:46.301078
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, False).filter(lambda x: x != 1) == Try(1, False)
