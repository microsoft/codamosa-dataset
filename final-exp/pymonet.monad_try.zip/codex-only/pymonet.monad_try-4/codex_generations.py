

# Generated at 2022-06-24 00:18:55.605406
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Test method on_success and on_fail.

    :returns: None
    :rtype: None
    """
    a = 0
    b = 0

    def success(value):
        nonlocal a
        a = value

    def fail(value):
        nonlocal b
        b = value

    m = Try(3, True)
    m.on_success(success)\
        .on_fail(fail)
    assert a == 3
    assert b == 0

    m = Try(3, False)
    m.on_success(success)\
        .on_fail(fail)
    assert a == 3
    assert b == 3

    m = Try(3, False)
    m.on_success(success)
    assert a == 3
    assert b == 3



# Generated at 2022-06-24 00:18:58.676543
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def divide(a, b):
        return a/b

    def divide_try(a, b):
        return Try.of(divide, a, b)

    assert divide_try(2, 3) == Try(2/3, True)
    assert divide_try(1, 0) == Try(ZeroDivisionError("division by zero"), False)


# Generated at 2022-06-24 00:19:00.562288
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(2, True).get_or_else(3) == 2
    assert Try(None, False).get_or_else(3) == 3



# Generated at 2022-06-24 00:19:06.371299
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(5, True) == Try(5, True)
    assert not Try(5, True) == Try(5, False)
    assert Try(5, True) != Try(4, True)


# Generated at 2022-06-24 00:19:08.024401
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(5, True).get_or_else(0) == 5
    assert Try(5, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:19:19.525060
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda val: val + 1) == Try(1, True)
    assert Try(1, True).on_success(lambda val: val + 1).on_success(lambda val: val + 1) == Try(1, True)
    assert Try(1, True).on_success(lambda val: val + 1).on_success(lambda val: val + 1).on_success(lambda val: val + 1) == Try(1, True)
    assert Try(1, True).on_success(lambda val: val + 1).on_success(lambda val: val + 1).on_success(lambda val: val + 1).on_success(lambda val: val + 1) == Try(1, True)

# Generated at 2022-06-24 00:19:25.406254
# Unit test for method bind of class Try
def test_Try_bind():
    def f(x):
        return Try('3' + x, True)

    def g(x):
        return Try('4' + x, False)

    assert Try.of(str, 10).bind(f) == Try('310', True)
    assert Try.of(str, 10).bind(g) == Try('4', False)
    assert Try('10', False).bind(f) == Try('10', False)

# Generated at 2022-06-24 00:19:30.708183
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(10, True).bind(lambda x: Try(x*2, True)) == Try(20, True)
    assert Try(10, True).bind(lambda x: Try(x/0, True)).is_success == False
    assert Try(10, False).bind(lambda x: Try(x/0, True)) == Try(10, False)


# Generated at 2022-06-24 00:19:35.878756
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1).map(lambda i: i + 1) == Try(2, True)
    assert Try.of(lambda: 1).map(lambda i: i + 1).map(lambda i: i + 1) == Try(3, True)
    assert Try.of(lambda: 1).map(lambda i: i / 0).map(lambda i: i + 1) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0).map(lambda i: i + 1) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:19:41.027024
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        raise Exception('Error in test_Try_on_fail function')
    except Exception as e:
        _, is_success = Try.of(int, '100')\
            .on_fail(lambda _: print('Error in test_Try_on_fail function')) \
            .map(lambda _: False)\
            .bind(lambda _: Try(True, True))\
            .get_or_else(False)

        assert is_success



# Generated at 2022-06-24 00:19:43.155919
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(int, '33')) == 'Try[value=33, is_success=True]'
    assert str(Try.of(int, 'str')) == 'Try[value=invalid literal for int() with base 10: \'str\', is_success=False]'



# Generated at 2022-06-24 00:19:53.376774
# Unit test for method __str__ of class Try
def test_Try___str__():
    from unittest import TestCase
    from unittest import main

    class TestTry(TestCase):
        def test_should_return_str_correctly_when_is_successfully(self):
            value = 0
            res = Try(value, True).__str__()
            assert res == 'Try[value={}, is_success={}]'.format(value, True)

        def test_should_return_str_correctly_when_is_not_successfully(self):
            value = 0
            res = Try(value, False).__str__()
            assert res == 'Try[value={}, is_success={}]'.format(value, False)

    main(verbosity=2)


# Generated at 2022-06-24 00:19:56.315836
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Function tests get_or_else method of Try class.
    """
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2

# Generated at 2022-06-24 00:19:59.855035
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 10).get_or_else(0) == 10
    assert Try.of(lambda: int('a')).get_or_else(0) == 0



# Generated at 2022-06-24 00:20:10.287115
# Unit test for method __str__ of class Try

# Generated at 2022-06-24 00:20:16.516881
# Unit test for method on_success of class Try
def test_Try_on_success():
    def identity(x):
        return x

    def test_func(x):
        return None

    assert Try.of(identity, 10).on_success(test_func) == Try(10, True)
    assert (Try(Exception('oops'), False).on_success(test_func)
            == Try(Exception('oops'), False))


# Generated at 2022-06-24 00:20:22.311373
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(12, True).get_or_else(42) == 12
    assert Try(12, False).get_or_else(42) == 42


# Generated at 2022-06-24 00:20:30.216671
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(2, False) == Try(2, False)
    assert Try(3, True) == Try(3, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(2, False) != Try(3, True)
    assert Try(3, True) != Try(1, True)


# Generated at 2022-06-24 00:20:32.691825
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert_success = Try(1, True)
    assert_fail = Try(RuntimeError(), False)

    assert assert_success.on_fail(print) == assert_success
    assert assert_fail.on_fail(print) == assert_fail


# Generated at 2022-06-24 00:20:36.276601
# Unit test for method filter of class Try
def test_Try_filter():
    f = lambda x: x % 2 == 1
    for n in range(-100, 100):
        try_n = Try(n, True)
        assert (f(n) and try_n.filter(f) == try_n) or (not f(n) and try_n.filter(f) == Try(n, False))

# Generated at 2022-06-24 00:20:43.548122
# Unit test for method filter of class Try
def test_Try_filter():
    try_ = Try(42, True)
    assert try_.filter(lambda x: x > 30).get() == 42
    assert try_.filter(lambda x: x > 50).get() == 42
    assert try_.filter(lambda x: x > 50).is_success == False
    try_ = Try(None, False)
    assert try_.filter(lambda x: x is not None).get() == None
    assert try_.filter(lambda x: x is not None).is_success == False

# Generated at 2022-06-24 00:20:47.333048
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Should return string representation of Try instance
    """
    assert str(Try.of(lambda x: x, 3)) == 'Try[value=3, is_success=True]'
    assert str(Try.of(lambda x: x, 'Test')) == "Try[value='Test', is_success=True]"


# Generated at 2022-06-24 00:20:54.495675
# Unit test for method bind of class Try
def test_Try_bind():
    def function(x):
        return 10 / x

    def function_bind(x):
        return Try(function(x), True)

    def raise_exception(x):
        return Try(function(x), False)

    assert Try.of(function, 10).bind(function_bind) == Try(1, True)
    assert Try.of(function, 10).bind(raise_exception) == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(function, 0).bind(function_bind) == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(function, 0).bind(raise_exception) == Try(ZeroDivisionError('division by zero'), False)



# Generated at 2022-06-24 00:20:55.612529
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert 'Try[value=a, is_success=True]' == str(Try('a', True))



# Generated at 2022-06-24 00:21:01.287013
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """Test for method __eq__ of class Try"""
    assert Try(10, True) == Try(10, True)
    assert not (Try(10, True) == Try(10, False))
    assert not (Try(10, True) == Try(20, True))
    assert not (Try(10, False) == Try(20, False))


# Generated at 2022-06-24 00:21:09.359378
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(2, True) == Try(2, True), 'Try with same values must be equal'
    assert Try(2, False) == Try(2, False), 'Try with same values must be equal'
    assert Try(2, False) != Try(2, True), 'Try with different types must not be equal'
    assert Try(2, False) != Try(3, False), 'Try with different values must not be equal'
    assert Try(2, True) != Try(3, True), 'Try with different values must not be equal'


# Generated at 2022-06-24 00:21:12.984208
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(Exception('aaa'), False) == Try(Exception('aaa'), False)
    assert Try(Exception('aaa'), False) != Try(Exception('bbb'), False)



# Generated at 2022-06-24 00:21:18.757884
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_callback(x):
        test_variable.test_value = 'test'

    test_variable = TestVariable()
    test_monad = Try(1, True)
    test_monad.on_success(test_callback)
    assert test_variable.test_value == test_variable.default_value
    test_monad = Try(1, False)
    test_monad.on_success(test_callback)
    assert test_variable.test_value == test_variable.default_value



# Generated at 2022-06-24 00:21:25.100403
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    class TestException(Exception):
        pass

    def test_unexpected_error():
        raise TestException('Unexpected error')

    # Should return a inner value
    assert Try.of(lambda x: x, 12).get_or_else(None) == 12

    # Should return a given default value
    assert Try.of(test_unexpected_error).get_or_else('Exception') == 'Exception'

# Generated at 2022-06-24 00:21:30.039855
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-24 00:21:34.986018
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Unit test for method bind of class Try
    """

    # Test successfully Try when function in bind don't raise exception.
    assert Try(1, True).bind(Try.of) == Try(1, True)
    # Test Try with exception when function in bind raise exception.
    assert Try(1, True).bind(lambda x: 1 / 0) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:21:43.950093
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(2, False) != Try(1, False)
    assert Try('1', True) == Try('1', True)
    assert Try('1', False) == Try('1', False)
    assert Try('1', True) != Try('1', False)
    assert Try('1', False) != Try('1', True)
    assert Try('1', True) != Try('2', True)
    assert Try('2', False) != Try('1', False)

test_Try___eq__

# Generated at 2022-06-24 00:21:45.744782
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) != Try(1, False), "Try is true and false"
    assert Try(2, True) == Try(2, True), "Try is true and true"
    assert Try("foo", False) == Try("foo", False), "Try is false and false"


# Generated at 2022-06-24 00:21:48.219091
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 5).filter(lambda x: x > 2) == Try(5, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 2) == Try(1, False)


# Generated at 2022-06-24 00:21:55.656419
# Unit test for method bind of class Try
def test_Try_bind():
    def get_state_code(country_code):
        return {
            'USA': 1,
            'UK': 44,
            'HU': 36,
        }.get(country_code)

    def get_state_name(state_code):
        return {
            1: 'California',
            44: 'Essex',
            36: 'Szabolcs-Szatmár-Bereg',
        }.get(state_code)

    def state_code_to_state_name(country_code):
        return Try.of(get_state_code, country_code)\
            .bind(get_state_name)

    assert state_code_to_state_name('USA') == 'California'
    assert state_code_to_state_name('UK') == 'Essex'
    assert state

# Generated at 2022-06-24 00:22:03.058015
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 'result', 1) == Try('result', True)

# Generated at 2022-06-24 00:22:06.749779
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda _: print('success')) == Try(1, True)


# Generated at 2022-06-24 00:22:12.809611
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try('1', False)) == 'Try[value=1, is_success=False]'
    assert str(Try('1', True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-24 00:22:15.272890
# Unit test for method map of class Try
def test_Try_map():
    def fn(a):
        return a * 2

    assert Try.of(fn, 1).map(fn) == Try(4, True)
    assert Try.of(fn, 1).map(fn) != Try(2, True)


# Generated at 2022-06-24 00:22:17.085935
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:22:20.624102
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('success', True)) == 'Try[value=success, is_success=True]'
    assert str(Try('fail', False)) == 'Try[value=fail, is_success=False]'
    assert str(Try('fail', True)) != 'Try[value=fail, is_success=True]'


# Generated at 2022-06-24 00:22:26.925119
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    value_success_is_success = Try(1, True)
    assert value_success_is_success.get() == 1

    value_success_is_fail = Try(ValueError(), False)
    assert value_success_is_fail.get() == ValueError()


# Generated at 2022-06-24 00:22:33.210716
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Unit test for method __str__ of class Try.
    """
    assert str(Try(1, True))\
        == 'Try[value=1, is_success=True]'
    assert str(Try(1, False))\
        == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:22:35.633231
# Unit test for method on_fail of class Try
def test_Try_on_fail(): # pragma: no cover
    try:
        raise Exception('Exception')
    except Exception as e:
        t = Try(e, False)

    t.on_fail(lambda e: print(e))
    assert t.is_success == False
    assert t.value.args[0] == 'Exception'

# Generated at 2022-06-24 00:22:43.316394
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # When not successfully, method get_or_else return default value
    assert Try(None, False).get_or_else('default value') == 'default value'
    assert Try(1, False).get_or_else('default value') == 'default value'

    # When successfully, method get_or_else return value
    assert Try(1, True).get_or_else('default value') == 1
    assert Try(None, True).get_or_else('default value') is None



# Generated at 2022-06-24 00:22:50.841232
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Given
    def f():
        raise Exception('Sth go wrong')

    def success_mapper(val):
        return val + 1

    def fail_mapper(val):
        return val + 1

    def success_on_success_mapper(val):
        return val + 1

    def success_on_fail_mapper(val):
        return val + 1

    def fail_on_success_mapper(val):
        return val + 1

    def fail_on_fail_mapper(val):
        return val + 1

    # When
    success_try = Try.of(lambda: 1)
    fail_try = Try.of(f)

    # Then
    assert success_try.on_fail(fail_mapper) == Try(1, True)

# Generated at 2022-06-24 00:22:53.680103
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0



# Generated at 2022-06-24 00:22:56.587466
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try("", True).__str__() == "Try[value=, is_success=True]"
    assert Try("", False).__str__() == "Try[value=, is_success=False]"


# Generated at 2022-06-24 00:22:59.158154
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    a = Try(1, True)
    b = Try(1, False)
    print(a.get_or_else(-1), b.get_or_else(-1))


# Generated at 2022-06-24 00:23:05.053231
# Unit test for method map of class Try
def test_Try_map():
    def _get_some_int() -> int:
        return 10

    def _get_some_int_but_raise() -> int:
        raise Exception("I am try Try")

    def _sum_one(x: int) -> int:
        return x + 1

    a = Try.of(_get_some_int).map(_sum_one)
    assert a.is_success
    assert a.get() == 11

    b = Try.of(_get_some_int_but_raise).map(_sum_one)
    assert not b.is_success
    assert b.get() is not None
    assert b.get() == "I am try Try"



# Generated at 2022-06-24 00:23:13.994709
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    from collections import namedtuple
    Person = namedtuple('Person', 'name age')

    def create_person(name, age):
        if not isinstance(name, str):
            raise TypeError("name must be string")
        return Person(name, age)

    person = Try.of(create_person, 'Roman', 22)
    assert (person == Try(Person('Roman', 22), True))

    person = Try.of(create_person, 22, 22)
    assert (person == Try(TypeError("name must be string"), False))



# Generated at 2022-06-24 00:23:18.901322
# Unit test for method on_fail of class Try

# Generated at 2022-06-24 00:23:23.135565
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def get_name():
        raise ValueError("Can't get name of user")

    try_text = Try.of(lambda: "success")
    assert try_text.get_or_else("fail") == "success"

    try_fail = Try.of(get_name)
    assert try_fail.get_or_else("fail") == "fail"

# Generated at 2022-06-24 00:23:29.108094
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True)\
        .bind(lambda v: Try(v + 2, True))\
        == Try(3, True)
    assert Try(1, True)\
        .bind(lambda v: Try(v + 2, False))\
        == Try(3, False)
    assert Try(1, False).bind(lambda v: Try(v + 2, True)) == Try(1, False)
    assert Try(1, False).bind(lambda v: Try(v + 2, False)) == Try(1, False)


# Generated at 2022-06-24 00:23:32.070441
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def raise_exception(value):
        raise Exception()

    tryt = Try.of(raise_exception, 1)

# Generated at 2022-06-24 00:23:35.597275
# Unit test for method get of class Try
def test_Try_get():
    try_success = Try("OK", True)
    assert_equal("OK", try_success.get())
    try_fail = Try("not ok", False)
    assert_equal("not ok", try_fail.get())



# Generated at 2022-06-24 00:23:40.762109
# Unit test for method bind of class Try
def test_Try_bind():
    @typing.overload
    def foo(x: int) -> Try[int]:
        return None

    def foo(x):
        return Try(x, True)

    assert Try(10, True).bind(foo) == Try(10, True)
    assert Try(10, False).bind(foo) == Try(10, False)



# Generated at 2022-06-24 00:23:43.224769
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1).get_or_else(0) == 1
    assert Try.of(lambda: 1 / 0).get_or_else(0) == 0


# Generated at 2022-06-24 00:23:49.087002
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try('a', True) != Try(1, True)
    assert Try(1, True) != Try('a', True)
    assert Try('a', True) != Try(2, True)



# Generated at 2022-06-24 00:23:54.039606
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully case when value = 1500 and filterer(value) == True
    value, filterer = 1500, lambda value: value > 1000
    assert(Try(value, True).filter(filterer) == Try(value, True))

    # Not successfully case when value = 500 and filterer(value) == True
    value, filterer = 500, lambda value: value > 1000
    assert(Try(value, True).filter(filterer) == Try(value, False))

    # Not successfully case when value = 1500 and filterer(value) == False
    value, filterer = 1500, lambda value: value < 1000
    assert(Try(value, True).filter(filterer) == Try(value, False))

    # Not successfully case when value = 500 and filterer(value) == False
    value, filterer

# Generated at 2022-06-24 00:24:01.566091
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    try:
        raise Exception("Exception")
    except Exception as ex:
        assert Try(ex, False) == Try(
            ex, False), "Try: constructor don't work correctly for exception as value"

    assert Try(1, True) == Try(
        1, True), "Try: constructor don't work correctly for any value"
    assert Try(1, True) != Try(
        1, False), "Try: constructor don't work correctly for is_success argument"


# Generated at 2022-06-24 00:24:07.206542
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    >>> test_Try_get_or_else()
    """
    assert Try.of(float, '23') \
        .map(lambda value: value + 1.2) \
        .get_or_else(0.0) == 24.2

    assert Try.of(float, 'not a number') \
        .map(lambda value: value + 1.2) \
        .get_or_else('error') == 'error'


# Generated at 2022-06-24 00:24:09.415184
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 2) == Try(3, True)
    assert Try(1, False).map(lambda x: x + 2) == Try(1, False)


# Generated at 2022-06-24 00:24:11.680815
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(5, True) == Try(5, True)
    assert Try(5, False) == Try(5, False)
    assert Try(5, False) == Try(4, False)



# Generated at 2022-06-24 00:24:19.785031
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def add_10_to_value(val):
        return val + 10
    try_success = Try.of(lambda: 10)
    try_fail = Try(Exception('error'), False)
    assert try_success.map(add_10_to_value) == Try(20, True)
    assert try_fail.map(add_10_to_value) == Try(Exception('error'), False)


# Generated at 2022-06-24 00:24:28.758299
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    The test should always pass.

    :returns: True
    :rtype: Boolean
    """
    def success(val):
        assert type(val) is int
    def fail(val):
        assert type(val) is int
    assert Try(5, True).on_success(success) == Try(5, True)
    assert Try(5, False).on_success(success) == Try(5, False)
    assert Try(5, True).on_fail(fail) == Try(5, True)
    assert Try(5, False).on_fail(fail) == Try(5, False)
    return True


# Generated at 2022-06-24 00:24:32.030985
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-24 00:24:33.238971
# Unit test for method get of class Try
def test_Try_get():
    empty = Try(123, True)
    assert empty.get() == 123

# Generated at 2022-06-24 00:24:39.294108
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)



# Generated at 2022-06-24 00:24:48.561499
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def function_with_exception():
        raise ValueError()

    assert Try(1, True) == Try(1, True)
    assert Try(1, True).__eq__(Try(1, True))

    assert Try(1, True) != Try(1, False)
    assert Try(1, True).__eq__(Try(1, False))

    assert Try(1, False) != Try(1, True)
    assert Try(1, False).__eq__(Try(1, True))

    assert Try(1, False) == Try(1, False)
    assert Try(1, False).__eq__(Try(1, False))

    assert Try(1, False) != Try(2, False)
    assert Try(1, False).__eq__(Try(2, False))

    assert Try(1, True)

# Generated at 2022-06-24 00:24:52.292978
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try('value', True).get_or_else('error') == 'value'
    assert Try(Exception('error'), False).get_or_else('error') == 'error'
    assert Try('value', False).get_or_else('error') == 'error'
    assert Try(Exception('error 1'), True).get_or_else('error 2') == Exception('error 1')



# Generated at 2022-06-24 00:24:58.250032
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def success_callback(value):
        print('success', value)

    def fail_callback(value):
        print('fail', value)

    def success_function():
        return 'test'

    def fail_function():
        raise Exception('test exc')

    Try.of(success_function).on_fail(fail_callback).on_success(success_callback)
    Try.of(fail_function).on_fail(fail_callback).on_success(success_callback)

# Generated at 2022-06-24 00:25:09.475529
# Unit test for method map of class Try
def test_Try_map():
    """
    For successfully monad Try, method map must return new Try with mapped value.
    Otherwise, same monad must be returned.
    """
    value = Try(23, True)
    mapper = lambda x: x + 3

    actual_value = value.map(mapper)
    expected_value = Try(26, True)

    assert actual_value == expected_value

    value = Try("abc", True)
    mapper = lambda x: x + "cde"

    actual_value = value.map(mapper)
    expected_value = Try("abccde", True)

    assert actual_value == expected_value

    value = Try(23, False)
    mapper = lambda x: x + 3

    actual_value = value.map(mapper)
    expected_value = Try(23, False)

   

# Generated at 2022-06-24 00:25:14.667750
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def binder(x):
        if x == 5:
            return Try(x ** 2, True)
        return Try('Error', False)
    assert Try(5, True).bind(binder) == Try(25, True)
    assert Try(6, True).bind(binder) == Try('Error', False)



# Generated at 2022-06-24 00:25:18.572125
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(5, True).bind(
        lambda x: Try(x + 1, True)
    ) == Try(6, True)

    assert Try(5, False).bind(
        lambda x: Try(x + 1, True)
    ) == Try(5, False)


# Generated at 2022-06-24 00:25:20.979243
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-24 00:25:25.264055
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test get_or_else method of class Try.

    """
    assert Try(1, True).get_or_else(10) == 1
    assert Try(-1, False).get_or_else(10) == 10


# Generated at 2022-06-24 00:25:31.573252
# Unit test for method bind of class Try
def test_Try_bind():
    one = 1
    two = 2
    ten = 10
    zero = 0
    def substract(x):
        return Try(x - 1, True)

    def divide(x):
        return Try(x / zero, True)

    assert Try(one, True).bind(substract) == Try(0, True)
    assert Try(one, True).bind(divide) == Try(zero, False)
    assert Try(zero, False).bind(substract) == Try(zero, False)



# Generated at 2022-06-24 00:25:40.931124
# Unit test for method filter of class Try
def test_Try_filter():
    some_value = "some value"
    some_fail_value = "some fail value"
    some_other_fail_value = "some other fail value"
    def mock_filterer(self, value):
        return value == some_value
    assert Try.of(str, some_value).filter(mock_filterer) == Try(some_value, True)
    assert Try.of(str, some_fail_value).filter(mock_filterer) == Try(some_fail_value, False)
    assert Try.of(str, some_other_fail_value).filter(mock_filterer) == Try(some_other_fail_value, False)

# Generated at 2022-06-24 00:25:46.472202
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        print(value)

    def fail_callback(value):
        print(value)

    assert Try(42, True).on_success(success_callback) == Try(42, True)
    assert Try(42, False).on_success(success_callback) == Try(42, False)
    assert Try(ValueError('my error'), True).on_success(success_callback) == Try(ValueError('my error'), True)
    assert Try(ValueError('my error'), False).on_success(success_callback) == Try(ValueError('my error'), False)


# Generated at 2022-06-24 00:25:51.151600
# Unit test for method map of class Try
def test_Try_map():
    # invoke Success
    assert Try(1, True)\
        .map(lambda x: x + 1)\
        .get() == 2

    # invoke Fail

# Generated at 2022-06-24 00:25:56.049174
# Unit test for method bind of class Try
def test_Try_bind():
    def func(num):
        return num + 1

    def not_func(num):
        raise TypeError()

    assert Try.of(func, 1).bind(func) == Try.of(func, 2)
    assert Try.of(func, '1').bind(not_func) == Try.of(not_func, '1')


# Generated at 2022-06-24 00:26:00.874194
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 5 / 0, None).on_fail(print) == Try(ZeroDivisionError('division by zero'), False)

# Generated at 2022-06-24 00:26:11.905868
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Test for equal cases
    t1 = Try(1, True)
    t2 = Try(1, True)
    assert t1 == t2

    t3 = Try(2, True)
    t4 = Try(2, True)
    assert t3 == t4

    t5 = Try('hello', True)
    t6 = Try('hello', True)
    assert t5 == t6

    # Test for not equal cases
    t7 = Try('hello', True)
    t8 = Try('world!', True)
    assert not t7 == t8

    t9 = Try(Exception('Hello world!'), False)
    t10 = Try(Exception('Hello world!'), False)
    assert t9 == t10

    t11 = Try(Exception('Hello world!'), False)

# Generated at 2022-06-24 00:26:19.655237
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    instance_1 = Try(value=None, is_success=True)
    instance_2 = Try(value=None, is_success=True)
    instance_3 = Try(value=None, is_success=False)
    instance_4 = Try(value=1, is_success=False)

    assert instance_1 == instance_2, 'Test __eq__ with equal instances was failed.'
    assert instance_1 != instance_3, 'Test __eq__ with not equal instances was failed.'
    assert instance_1 != instance_4, 'Test __eq__ with not equal instances was failed.'
    assert instance_2 == instance_1, 'Test __eq__ with equal instances was failed.'
    assert instance_2 != instance_3, 'Test __eq__ with not equal instances was failed.'

# Generated at 2022-06-24 00:26:21.050606
# Unit test for method get of class Try
def test_Try_get():
    v = 1
    t = Try(1, True)
    assert t.get() == v



# Generated at 2022-06-24 00:26:22.641915
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == Try(2, False).get_or_else(2)



# Generated at 2022-06-24 00:26:26.354313
# Unit test for method map of class Try
def test_Try_map():
    def add(x):
        return x + x

    assert Try.of(add, 4).map(add) == Try(16, True)
    assert Try.of(add, 4).map(add) != Try(16, False)


# Generated at 2022-06-24 00:26:31.307993
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3, True).filter(lambda x: x != 2) == Try(3, True)
    assert Try(2, True).filter(lambda x: x != 2) == Try(2, False)
    assert Try(2, False).filter(lambda x: x != 2) == Try(2, False)


# Generated at 2022-06-24 00:26:37.071420
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_func(arg):
        return arg * 2

    assert ge_math.Try.of(test_func, 2).on_success(lambda value: print(value)) == ge_math.Try(4, True)
    assert not ge_math.Try.of(test_func, 'a').on_success(lambda value: print(value)) == ge_math.Try(4, True)

    print('test_Try_on_success: ok!')


# Generated at 2022-06-24 00:26:41.232955
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1).get_or_else(0) == 1
    assert Try.of(lambda: 1/0, 0).get_or_else(0) == 0


# Generated at 2022-06-24 00:26:45.595140
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2,  True).filter(lambda x: x > 1) == Try(2, True)
    assert Try(2,  True).filter(lambda x: x < 1) == Try(2, False)
    assert Try(2, False).filter(lambda x: x > 1) == Try(2, False)


# Generated at 2022-06-24 00:26:48.866085
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(5, True).on_success(lambda x: x + 2) == Try(5, True)
    assert Try(5, False).on_success(lambda x: x + 2) == Try(5, False)


# Generated at 2022-06-24 00:26:53.266415
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    value = 'value'
    default_value = 'default_value'
    assert Try.of(lambda: value).get_or_else(default_value) == value
    assert Try.of(lambda: [1, 2, 3][4]).get_or_else(default_value) == default_value


# Generated at 2022-06-24 00:26:56.568441
# Unit test for method __str__ of class Try
def test_Try___str__():
    value = 1
    is_success = True
    try_instance = Try(value, is_success)
    expected = 'Try[value=1, is_success=True]'
    print(try_instance)
    assert str(try_instance) == expected



# Generated at 2022-06-24 00:27:05.832529
# Unit test for method map of class Try
def test_Try_map():
    # Should return successfully Try with mapped value when Try is successfully
    def add5(a):
        return a + 5

    try_1 = Try.of(lambda x: x + 1, 1)
    try_1_assert = Try(2, True)
    try_1_map_assert = Try(7, True)

    assert try_1 == try_1_assert
    assert try_1.map(add5) == try_1_map_assert

    # Should return not successfully Try with mapped value when Try is not successfully
    def degree_on_3(a):
        return a ** 3

    try_2 = Try.of(lambda x: 1 / x, 0)
    try_2_assert = Try(ZeroDivisionError, False)

    assert try_2 == try_2_assert

# Generated at 2022-06-24 00:27:10.906292
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(10, True).bind(lambda x: Try(x * 2, True)).value == 20
    assert Try(10, True).bind(lambda x: Try(x / 0, True)).is_success is False
    assert Try(10, False).bind(lambda x: Try(x * 2, True)).is_success is False


# Generated at 2022-06-24 00:27:12.183599
# Unit test for method get of class Try
def test_Try_get():
    assert Try(42, True).get() == 42


# Generated at 2022-06-24 00:27:17.036393
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    :return:
    """
    # success
    t = Try(1, True)
    assert t.get_or_else(2) == 1
    # fail
    t = Try(Exception(), False)
    assert t.get_or_else(2) == 2
    # fail
    t = Try(Exception(), False)
    assert t.get_or_else(lambda: 1+1) == 2


# Generated at 2022-06-24 00:27:18.106827
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 10,).get() == 10


# Generated at 2022-06-24 00:27:20.662322
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test method get_or_else of class Try.
    """
    assert Try(2, True).get_or_else(1) == 2
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:27:23.983956
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'


# Generated at 2022-06-24 00:27:31.324342
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    class TestException(Exception):
        pass

    def fn_raise_exception():
        raise TestException()

    def fn_not_raise_exception():
        return 1


# Generated at 2022-06-24 00:27:34.144435
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    """
    >>> str(Try(10, True))
    'Try[value=10, is_success=True]'
    >>> str(Try(10, False))
    'Try[value=10, is_success=False]'
    >>> str(Try('fail', True))
    'Try[value=fail, is_success=True]'
    >>> str(Try('fail', False))
    'Try[value=fail, is_success=False]'
    """



# Generated at 2022-06-24 00:27:38.815058
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        int('a')
    except ValueError:
        assert True
    else:
        assert False
    Try.of(int, 'a').on_fail(ValueError)



# Generated at 2022-06-24 00:27:42.017087
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(None, True).get_or_else(0) is None
    assert Try(1, False).get_or_else(0) == 0
    assert Try(None, False).get_or_else(0) == 0

# Generated at 2022-06-24 00:27:46.537278
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda x: x, 1).map(lambda x: x + 1) == Try(2, True)
    assert Try.of(lambda x: x, 1) == Try.of(lambda x: x, 1).map(lambda x: None)
    assert Try.of(lambda x: x / 0, 1) == Try.of(lambda x: x / 0, 1).map(lambda x: x + 1)


# Generated at 2022-06-24 00:27:49.525654
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    value = 5
    try_success = Try(value, True)
    assert try_success == Try(value, True)

    exception = ValueError()
    try_fail = Try(exception, False)
    assert try_fail == Try(exception, False)



# Generated at 2022-06-24 00:27:55.464073
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(
        lambda value: None) == Try(1, True), 'Should not execute on_fail callback'
    assert Try(1, False).on_fail(
        lambda value: value) == Try(1, False), 'Should execute on_fail callback'

# Generated at 2022-06-24 00:27:58.973892
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(5, True)
    assert str(try_) == 'Try[value=5, is_success=True]'

    try_ = Try(None, False)
    assert str(try_) == 'Try[value=None, is_success=False]'



# Generated at 2022-06-24 00:28:02.002872
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try('a', True).get() == 'a'
    assert Try('a', False).get() == 'a'
    assert Try(Exception("Error"), False).get() == Exception("Error")


# Generated at 2022-06-24 00:28:08.926030
# Unit test for method on_success of class Try
def test_Try_on_success():
    class DummyError(Exception):
        pass

    try_1 = Try(1, True)
    try_2 = Try(DummyError(), False)


# Generated at 2022-06-24 00:28:12.950582
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    # Given
    val1 = "value"
    try1 = Try(val1, True)
    try2 = Try(val1, True)
    try3 = Try(val1, False)
    try4 = Try("value2", False)
    try5 = Try("value2", True)
    # When
    try_eq1 = try1 == try2
    try_eq2 = try3 == try4
    try_eq3 = try1 == try5
    try_eq4 = try1 == None
    try_eq5 = try2 == "value"
    # Then
    assert try_eq1 == True
    assert try_eq2 == True
    assert try_eq3 == False
    assert try_eq4 == False
    assert try_eq5 == False



# Generated at 2022-06-24 00:28:18.972495
# Unit test for method get of class Try
def test_Try_get():
    def test_monad_success():
        assert_that(Try.of(lambda: 1).get(), is_(1))

    def test_monad_fail():
        assert_that(Try.of(lambda: raise_(Exception('fail'))).get(),
                    is_('Exception: fail'))

    test_monad_success()
    test_monad_fail()


# Generated at 2022-06-24 00:28:24.646851
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    maybe_num = Try.of(float, 'abc')
    assert maybe_num.get_or_else(0.0) == 0.0

    maybe_num = Try.of(float, '1.1')
    assert maybe_num.get_or_else(0.0) == 1.1

# Generated at 2022-06-24 00:28:28.451055
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def test(value):
        return Try(value * 2, True)

    assert Try(1, True).bind(test) == Try(2, True)
    assert Try(2, True).bind(test) == Try(4, True)
    assert Try(1, False).bind(test) == Try(1, False)


# Generated at 2022-06-24 00:28:33.663477
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:28:37.517534
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda x: x + 10, 10).bind(lambda x: Try(x, True)) == Try(20, True)
    assert Try.of(lambda x: x + 10, 0).bind(lambda x: Try('error', False)) == Try('error', False)


# Generated at 2022-06-24 00:28:44.122857
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda x: x, 1).bind(lambda x: Try(x + 1, True)) == Try(2, True)
    assert Try.of(lambda x: x, "test").bind(lambda x: Try(x + "test", True)) == Try("testtest", True)
    assert Try.of(lambda x: x, "test").bind(lambda x: Try(x + "test", False)) == Try("testtest", False)
    assert Try.of(lambda x: x, 1).bind(lambda: Try(2, True)) == Try(2, True)
    assert Try.of(lambda x: x, 1).bind(lambda: Try(2, False)) == Try(2, False)

# Generated at 2022-06-24 00:28:51.117365
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    t1 = Try(2, True)
    t2 = Try(2, True)
    t3 = Try(3, False)
    t4 = Try(2, True)
    t5 = Try(ValueError(), False)
    t6 = Try(ValueError(), False)
    assert t1 == t2, 'Try() == Try()'
    assert t1 != t3, 'Try() != Try()'
    assert t2 == t4, 'Try() == Try()'
    assert t5 == t6, 'Try() == Try()'

