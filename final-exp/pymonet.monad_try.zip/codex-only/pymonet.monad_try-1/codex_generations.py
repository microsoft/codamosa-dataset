

# Generated at 2022-06-24 00:18:46.727875
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    """
    Test basic constructor of class Try.
    """
    monad = Try(True, True)
    assert monad.is_success == True
    assert monad.value == True



# Generated at 2022-06-24 00:18:49.225514
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:18:53.327687
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try('try', True).get_or_else('default') == 'try'
    assert Try(None, False).get_or_else('default') == 'default'


# Generated at 2022-06-24 00:18:56.066768
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(2, True) == Try(2, True)
    assert Try(2, True) != Try(2, False)
    assert Try(3, False) != Try(2, False)
    assert Try(3, False) == Try(3, False)



# Generated at 2022-06-24 00:18:57.724570
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(5, True) == Try(5, True)



# Generated at 2022-06-24 00:19:04.555611
# Unit test for method filter of class Try
def test_Try_filter():
    # When is successfully and filter returns False,
    # then returns not successfully Try with previous value
    assert Try(2, True)\
        .filter(lambda x: x % 2 == 1)\
        == Try(2, False)
    # When is successfully and filter returns True,
    # then returns same monad
    assert Try(2, True)\
        .filter(lambda x: x % 2 == 0)\
        == Try(2, True)
    # When is successfully and filter returns True,
    # then returns same monad
    assert Try(2, True)\
        .filter(lambda x: x % 2 == 0)\
        == Try(2, True)
    # When is not successfully and filter returns True,
    # then returns same monad

# Generated at 2022-06-24 00:19:06.292920
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1, []).get() == 1
    assert Try.of(lambda: 1/0, []).get() == 1/0


# Generated at 2022-06-24 00:19:07.336874
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1



# Generated at 2022-06-24 00:19:14.522604
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x > 4) == Try(5, True)
    assert Try(5, True).filter(lambda x: x < 4) == Try(5, False)
    assert Try(Exception('test'), False).filter(lambda x: x > 4) == Try(Exception('test'), False)



# Generated at 2022-06-24 00:19:18.368576
# Unit test for constructor of class Try
def test_Try():
    assert Try(number_not_divisible_by_zero, False) == Try(number_not_divisible_by_zero, False)


# Dummy function for test

# Generated at 2022-06-24 00:19:22.029698
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-24 00:19:23.159025
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-24 00:19:27.776911
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda: 1).get_or_else(0) == 1
    assert Try.of(lambda: None).get_or_else(0) == 0
    def f():
        raise Exception(1)
    assert Try.of(lambda: f()).get_or_else(0) == 0


# Generated at 2022-06-24 00:19:30.018228
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1, ()).get() == 1
    assert Try.of(lambda: 1 / 0, ()).get()



# Generated at 2022-06-24 00:19:37.042403
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    @pytest.fixture
    def _on_fail(*args, **kwargs):
        class MockedTry(Try):
            def on_fail(self, fail_callback):
                fail_callback(*args, **kwargs)
                return self
        return MockedTry
    def _validate(_on_fail, *args, **kwargs):
        mock_func = mock.Mock(wraps=lambda *args, **kwargs: None)
        assert _on_fail(*args, **kwargs).on_fail(mock_func) == _on_fail(*args, **kwargs)
        mock_func.assert_called_once_with(*args, **kwargs)

# Generated at 2022-06-24 00:19:39.683101
# Unit test for constructor of class Try
def test_Try():
    assert Try(42, True) == Try(42, True)
    # Function throws exception.
    assert Try(42, True) != Try(Exception('Error'), False)


if __name__ == '__main__':  # pragma: no cover
    test_Try()

# Generated at 2022-06-24 00:19:41.378088
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)



# Generated at 2022-06-24 00:19:44.423955
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1).get() == 1
    assert Try.of(lambda: 2/0, 2).get() == 2



# Generated at 2022-06-24 00:19:48.240400
# Unit test for method __str__ of class Try
def test_Try___str__():
    # when
    result = str(Try(1, True))
    # then
    assert result == 'Try[value=1, is_success=True]'

    # when
    result = str(Try(1, False))
    # then
    assert result == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:19:55.819946
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert 'Try[value=None, is_success=True]' == Try(None, True).__str__()
    assert 'Try[value=None, is_success=False]' == Try(None, False).__str__()
    assert 'Try[value=0, is_success=False]' == Try(0, False).__str__()
    assert 'Try[value=10, is_success=True]' == Try(10, True).__str__()
    assert 'Try[value=True, is_success=True]' == Try(True, True).__str__()
    assert 'Try[value=False, is_success=True]' == Try(False, True).__str__()


# Generated at 2022-06-24 00:20:02.150198
# Unit test for method bind of class Try
def test_Try_bind():
    def twice(a):
        return Try.of(lambda: a * 2)
    def bind_twice(binder):
        return Try.of(lambda: binder(2).bind(twice))
    assert bind_twice(lambda value: Try(value, True)) == Try(4, True)
    assert bind_twice(lambda value: Try(value, False)) == Try(2, False)

# Generated at 2022-06-24 00:20:05.579206
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(3, True).bind(lambda x: Try(x+1, True)) == Try(4, True)
    assert Try(2, False).bind(lambda x: Try(x+1, True)) == Try(2, False)



# Generated at 2022-06-24 00:20:07.917038
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(None, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:20:10.961944
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-24 00:20:17.583521
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 1) == Try(1, False)



# Generated at 2022-06-24 00:20:22.843545
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-24 00:20:28.414325
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    # Successfully value
    assert Try(1, True).get() == 1
    # Not successfully value
    assert Try(1, False).get() == 1


# Generated at 2022-06-24 00:20:36.953585
# Unit test for method on_success of class Try
def test_Try_on_success():
    add_two = lambda x: x + 2
    not_successful = Try.of(add_two, 'asd')
    successful = Try.of(add_two, 1)

    result = not_successful.on_success(add_two)
    assert result == Try(TypeError("unsupported operand type(s) for +: 'int' and 'str'"), False)

    result = successful.on_success(add_two)
    assert result == Try(3, True)

if __name__ == "__main__":
    test_Try_on_success()

# Generated at 2022-06-24 00:20:41.139784
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> Try.of(lambda: 1, None) \
            .bind(lambda i: Try.of(lambda: True if i==1 else False, None) \
            .bind(lambda b: Try.of(lambda: True if b else False, None)) \
            .filter(lambda b2: b2)) \
            .get()
    True
    >>> Try.of(lambda: 2, None).filter(lambda v: v==1).is_success
    False
    """
    pass


# Generated at 2022-06-24 00:20:44.850112
# Unit test for method on_success of class Try
def test_Try_on_success():
    # Arrange
    expected_result = 15
    test_value = 5
    test_try = Try(test_value, True)
    # Action
    test_try.on_success(lambda x: x + 10)
    actual_result = test_try.value

    # Assert
    assert actual_result == expected_result


# Generated at 2022-06-24 00:20:53.009084
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    add = lambda x, y: x + y
    add_list = lambda xs, n: [x + n for x in xs]

    add_1 = lambda x: Try(x + 1, True)
    add_5 = lambda x: Try(x + 5, True)
    add_10 = lambda x: Try(x + 10, True)
    add_20 = lambda x: Try(x + 20, True)

    _add_1 = lambda x: Try(x + 1, False)
    _add_5 = lambda x: Try(x + 5, False)
    _add_10 = lambda x: Try(x + 10, False)
    _add_20 = lambda x: Try(x + 20, False)


# Generated at 2022-06-24 00:20:55.457661
# Unit test for method get of class Try
def test_Try_get():
    # Arrange
    value = object()

    # Act
    try_instance = Try(value, True)

    # Assert
    assert value == try_instance.get()


# Generated at 2022-06-24 00:21:02.339482
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test for method get_or_else of class Try.
    """
    def identity(*args):
        return list(args)

    assert Try.of(identity, 1).get_or_else(2) == [1]
    assert Try.of(identity, 1, 2).get_or_else(3) == [1, 2]

    def raise_exception(*args):
        raise Exception('THe exception.')

    assert Try.of(raise_exception, 1, 2, 3).get_or_else('That is success default value.') == 'That is success default value.'


# Generated at 2022-06-24 00:21:07.186918
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:21:12.201436
# Unit test for method bind of class Try
def test_Try_bind():
    with open('test.txt', 'r') as f:
        assert Try.of(f.readline) == Try('Hello try-bind!\n', True)

    with open('test.txt', 'r') as f:
        assert Try.of(f.readline).bind(lambda x: Try.of(f.readline)) == Try('Hello try-monad!\n', True)

    with open('test.txt', 'r') as f:
        assert Try.of(f.readline).bind(lambda x: Try.of(f.readline))\
            .bind(lambda x: Try.of(f.readline)) == Try('Hello try-filter!\n', True)


# Generated at 2022-06-24 00:21:14.794461
# Unit test for method map of class Try
def test_Try_map():
    assert Try((lambda x: x + 1), True).map(lambda x: x(1)).get() == 2

    assert Try(-1, False) == Try(-1, False).map(lambda x: x ** 2)


# Generated at 2022-06-24 00:21:23.794268
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Arrange
    def side_effect(msg):
        side_effect.call_count += 1
        side_effect.call_args = (msg,)

    side_effect.call_count = 0
    side_effect.call_args = (None,)

    # Act
    Try(1 / 0, False).on_fail(side_effect)
    Try(1, True).on_fail(side_effect)

    # Assert
    assert side_effect.call_count == 1
    assert type(side_effect.call_args[0]) is ZeroDivisionError

# Generated at 2022-06-24 00:21:31.241553
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, 'a') \
        .filter(lambda a: a % 2 == 0) \
        == Try(1, False)
    assert Try.of(lambda: 2, 'a') \
        .filter(lambda a: a % 2 == 0) \
        == Try(2, True)



# Generated at 2022-06-24 00:21:34.874284
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception('fail'), False) == Try(Exception('fail'), False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)


# Generated at 2022-06-24 00:21:39.932033
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try('a', True).get() == 'a'
    assert Try(False, True).get() == False


# Generated at 2022-06-24 00:21:46.134110
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert_should_equal_true(Try(100, True) == Try(100, True))
    assert_should_equal_false(Try(100, True) == Try(100, False))
    assert_should_equal_false(Try(100, True) == Try(200, True))
    assert_should_equal_false(Try(100, True) == Try(200, False))
    assert_should_equal_false(Try(100, True) == Try(200))
    assert_should_equal_false(Try(100, True) == 100)



# Generated at 2022-06-24 00:21:53.390717
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 5).map(lambda x: x + 1) == Try(6, True)
    assert Try.of(lambda: 'test').map(lambda x: x + '1') == Try('test1', True)
    assert Try.of(lambda: {}).map(lambda x: x.update({'a': 5})) == Try({'a': 5}, True)
    assert Try.of(lambda: None).map(lambda x: x) == Try(None, True)
    assert Try.of(lambda: 5).map(lambda x: x / 0) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:21:58.402186
# Unit test for method map of class Try
def test_Try_map():
    def f(x):
        return x*x

    def f1(x):
        return 1/x

    assert Try(8, True).map(f) == Try(64, True)
    assert Try(0, True).map(f1) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:22:05.581795
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test for Try.on_fail method of Try control.

    """
    def success_callback(i: int) -> None:
        """
        Callback for on_success method

        :params i: value to print to result
        :type i: int
        """
        print(i)

    def fail_callback(i: int) -> None:
        """
        Callback for on_fail method

        :params i: value to print to result
        :type i: int
        """
        print(i)

    assert Try(2, True).on_success(success_callback).value == 2
    assert Try(2, False).on_fail(fail_callback).value == 2


# Generated at 2022-06-24 00:22:12.387818
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda x: 2*x, 2).on_success(lambda x: x+3) == Try(5, True)
    assert Try.of(lambda x: 2/x, 0).on_success(lambda x: x+3) == Try(ZeroDivisionError, False)


# Generated at 2022-06-24 00:22:16.474992
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    import random

    fn = lambda: random.randint(1, 10)

    t = Try.of(fn)
    assert t.is_success
    assert t.get_or_else(0) == t.get()

    t = Try.of(lambda: 1/0)
    assert not t.is_success
    assert t.get_or_else(0) == 0



# Generated at 2022-06-24 00:22:18.457920
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(None, False).get_or_else(0) == 0

# Generated at 2022-06-24 00:22:24.699032
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    class TestException(Exception):
        pass

    assert Try.of(lambda: 3, None) == Try(3, True)
    assert Try.of(lambda: 3, None).value == 3
    assert Try.of(lambda: 3, None).is_success == True
    assert Try.of(lambda: raise_exception(TestException), None) == Try(TestException(), False)
    assert isinstance(Try.of(lambda: raise_exception(TestException), None).value, TestException)
    assert Try.of(lambda: raise_exception(TestException), None).is_success == False



# Generated at 2022-06-24 00:22:25.652562
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, False) == Try(1, False)



# Generated at 2022-06-24 00:22:32.039732
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    try_success = Try(10, True)
    try_fail = Try(10, False)
    assert try_success.value == 10
    assert try_success.is_success == True
    assert try_fail.value == 10
    assert try_fail.is_success == False
    assert try_fail != try_success
    assert str(try_success) == 'Try[value=10, is_success=True]'
    assert str(try_fail) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-24 00:22:41.272820
# Unit test for method filter of class Try
def test_Try_filter():
    # Setup
    def filterer_function(a):
        return a[0] == 'q'
    try_to_filter = Try('qwe', True)
    try_not_to_filter = Try('asd', True)

    try_to_filter_return = Try('qwe', True)
    try_not_to_filter_return = Try('asd', False)

    # Precondition
    assert(try_to_filter == try_to_filter_return)
    assert(try_not_to_filter == try_not_to_filter_return)

    # Run method
    try_to_filter.filter(filterer_function)
    try_not_to_filter.filter(filterer_function)

    # Assert result

# Generated at 2022-06-24 00:22:45.429063
# Unit test for constructor of class Try
def test_Try():
    assert(Try(1, True) == Try(1, True))
    assert(Try(1, False) == Try(1, False))
    assert(Try(1, False) != Try(1, True))
    assert(Try(None, True) == Try(None, True))


# Generated at 2022-06-24 00:22:51.051512
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.

    :returns: None when test in successfully.
    """
    def filterer(number):
        return number == 6

    assert Try(6, True).filter(filterer) == Try(6, True)
    assert Try(7, True).filter(filterer) == Try(7, False)
    assert Try(6, False).filter(filterer) == Try(6, False)


# Generated at 2022-06-24 00:22:55.730204
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2
    assert Try(None, False).get_or_else(2) == 2
    assert Try(None, True).get_or_else(2) is None


# Generated at 2022-06-24 00:22:59.712363
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """Unit test for method get_or_else of class Try"""
    assert Try.of(lambda x: x, 1).get_or_else(1) == 1
    assert Try.of(lambda: 1/0, 1).get_or_else(1) == 1

test_Try_get_or_else()


# Generated at 2022-06-24 00:23:06.435300
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    success_monad = Try.of(lambda: 'success_monad', None)
    fail_monad = Try(Exception('fail_monad'), False)
    assert success_monad.__str__() == 'Try[value=success_monad, is_success=True]'
    assert fail_monad.__str__() == 'Try[value=fail_monad, is_success=False]'


# Generated at 2022-06-24 00:23:09.137817
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    When Try is successfully function should return value.
    When Try is not successfully function should return default value.
    """
    assert Try(10, True).get_or_else(20) == 10
    assert Try(10, False).get_or_else(20) == 20

# Generated at 2022-06-24 00:23:13.276486
# Unit test for method __str__ of class Try
def test_Try___str__():

    # Arrange
    value = 'test string'
    test_Try = Try(value, True)
    expected_value = 'Try[value={}, is_success={}]'.format(value, True)

    # Act
    result = str(test_Try)

    # Assert
    assert expected_value == result


# Generated at 2022-06-24 00:23:15.505116
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(10) == 1
    assert Try(1, False).get_or_else(10) == 10

# Generated at 2022-06-24 00:23:20.959922
# Unit test for method on_success of class Try
def test_Try_on_success():
    result = Try.of(lambda: 1 + 1)

# Generated at 2022-06-24 00:23:24.269900
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(5, True) == Try(5, True)
    assert Try(5, True) != Try(5, False)
    assert Try(5, False) != Try(5, True)
    assert Try(5, False) == Try(5, False)



# Generated at 2022-06-24 00:23:27.247764
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 0).map(lambda x: x + 1) == Try(1, True)
    assert Try.of(lambda: 1 / 0).map(lambda x: x + 1) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:23:31.767442
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1+2, ).map(lambda x: x*2).get() == 6

    assert Try.of(lambda: 1+2, ).map(lambda x: x/0).get() == 3

    assert Try.of(lambda x: 1/x, 0).map(lambda x: x*2).get() == 0


# Generated at 2022-06-24 00:23:33.314426
# Unit test for method get of class Try
def test_Try_get():
    value = 10
    assert Try.of(lambda: value, None).get() == value


# Generated at 2022-06-24 00:23:40.475088
# Unit test for method get of class Try
def test_Try_get():
    assert Try(4, True).get() == 4
    assert Try('none', False).get() == 'none'
    assert Try(True, True).get() == True
    assert Try(None, False).get() == None
    assert Try('hi', True).get() == 'hi'
    assert Try([1, 2, 3, 4], True).get() == [1, 2, 3, 4]
    assert Try(4.5, False).get() == 4.5


# Generated at 2022-06-24 00:23:47.620335
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():

    def function_raise_exception():
        raise Exception('Expected Exception')

    def function_return_42():
        return 42

    @given(st.one_of(st.integers(), st.none()))
    @settings(max_examples=100, deadline=None)
    def test_get_or_else_on_success(default_value):
        assert Try.of(function_return_42).get_or_else(default_value) == 42

    test_get_or_else_on_success()

    @given(st.integers())
    @settings(max_examples=100, deadline=None)
    def test_get_or_else_on_fail(default_value):
        assert Try.of(function_raise_exception).get_or_else(default_value) == default_value

# Generated at 2022-06-24 00:23:53.346100
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(int, '1').bind(lambda a: Try(a + 1, True)) == Try(2, True)
    assert Try.of(int, 'a').bind(lambda a: Try(a + 1, True)) == Try('a', False)



# Generated at 2022-06-24 00:24:01.204801
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_function(index):
        def success_callback(x):
            assert index == 0
            assert x == 10

        def fail_callback(x):
            assert index == 1
            assert type(x) == ZeroDivisionError

        return Try.of(lambda x: 1 / x, 10).on_success(success_callback).on_fail(fail_callback)

    assert test_function(0) == Try(10, True)
    assert test_function(1) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:24:02.519240
# Unit test for method get of class Try
def test_Try_get():
    # Given
    value = 10
    t = Try(value, True)

    # When
    result = t.get()

    # Then
    assert result == value



# Generated at 2022-06-24 00:24:05.765826
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Unit test for method on_success of class Try
    """

# Generated at 2022-06-24 00:24:11.500635
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert str(Try.of(int, '123').on_success(print)) == 'Try[value=123, is_success=True]'
    assert str(Try.of(int, 'a123').on_success(print)) == 'Try[value=a123, is_success=False]'



# Generated at 2022-06-24 00:24:17.799692
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(None) == 1
    assert Try(None, True).get_or_else(None) == None
    assert Try(Exception(), False).get_or_else(None) == None

# Generated at 2022-06-24 00:24:22.003744
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_ = Try.of(lambda x: x, 1)
    assert try_.get_or_else(2) == 1

    try_ = Try.of(lambda x: x/0, 1)
    assert try_.get_or_else(2) == 2

# Generated at 2022-06-24 00:24:27.350142
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def fail_callback(e):
        print('Fail of Try: {}'.format(e))

    def failure():
        try:
            5 / 0
        except ZeroDivisionError:
            raise

    # Expected output: Fail of Try: division by zero
    Try.of(failure).on_fail(fail_callback).get()


# Generated at 2022-06-24 00:24:34.471020
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 3).bind(
        lambda x: Try.of(lambda: x * 2)) == Try.of(lambda: 3 * 2)
    assert Try.of(lambda: True).bind(
        lambda x: Try.of(lambda: False)) == Try.of(lambda: False)
    assert Try.of(lambda: 'a').bind(
        lambda x: Try.of(lambda: 10 / 0)) == Try.of(lambda: 10 / 0)


# Generated at 2022-06-24 00:24:38.008996
# Unit test for constructor of class Try
def test_Try():
    assert Try("value", True) == Try("value", True)
    assert Try("value", False) == Try("value", False)


# Generated at 2022-06-24 00:24:42.051946
# Unit test for method map of class Try
def test_Try_map():
    assert "map_result" == Try.of(lambda: "original_result").map(lambda r: "map_result").get()
    assert "original_result" == Try.of(lambda: raise_exception()).map(lambda r: "map_result").get()



# Generated at 2022-06-24 00:24:48.122653
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try.of(lambda: 5 / 0, '').filter(lambda _: True) == Try(ZeroDivisionError('integer division or modulo by zero'), False)
    assert Try.of(lambda: 5 + 5, '').filter(lambda _: True) == Try(10, True)
    assert Try.of(lambda: 5 + 5, '').filter(lambda _: False) == Try(10, False)


# Generated at 2022-06-24 00:24:58.367594
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda x: x, 'text').map(lambda x: x.upper()) == Try('TEXT', True)

    assert Try.of(lambda x: x, 'text').map(lambda x: x.upper()) != Try('text', True)

    assert Try.of(lambda x: x, 'text').map(lambda x: x.upper()) != Try('TEXT', False)

    assert Try.of(lambda x: x, 'text').map(lambda x: x.upper()) != Try('text', False)

    assert Try.of(lambda x: x, 'text').map(lambda x: x.upper()) != Try('text', 'text')

    assert Try.of(lambda x: x, 'text').map(lambda x: x.upper()) != Try('text', 'text')


# Generated at 2022-06-24 00:25:09.571011
# Unit test for method map of class Try
def test_Try_map():
    def check_positive(value):
        return value > 0

    def square(value):
        return value ** 2

    def fail(value):
        raise ArithmeticError('Value is even')

    # Test work when is successfully and mapped value
    assert Try.of(check_positive, 3).map(square)\
        == Try(9, True)
    # Test work when is successfully and mapped value
    assert Try.of(check_positive, 5).map(square)\
        == Try(25, True)
    # Test copy of self when is not successfully and error already raised
    assert Try.of(check_positive, 2).map(square)\
        == Try(2, False)
    # Test copy of self when is successfully and error raised in mapper

# Generated at 2022-06-24 00:25:13.455493
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    try_ = Try(1, True)
    assert str(try_) == 'Try[value=1, is_success=True]'

    try_ = Try(1, False)
    assert str(try_) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-24 00:25:17.308609
# Unit test for method map of class Try
def test_Try_map():
    identity_monad = lambda x: x
    assert Try(1, True).map(identity_monad) == Try(1, True)
    assert Try(1, False).map(identity_monad) == Try(1, False)



# Generated at 2022-06-24 00:25:25.850879
# Unit test for method map of class Try
def test_Try_map():
    # Returns Successfully Try with mapped value
    assert Try.of(lambda: 1).map(lambda a: a*5) == Try(5, True)

    # Returns Successfully Try with mapped value and not successfully Try with first exception
    assert Try.of(lambda: 'a').map(lambda a: a*5) == Try('aaaaa', True)
    assert Try.of(lambda: 'a').map(lambda a: a*5) != Try(TypeError('string argument without an encoding'), False)

    # Returns Not successfully Try with exception
    assert Try.of(lambda: 1/0).map(lambda a: a*5) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:25:30.271111
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_greater_than_one(x):
        return x > 1

    assert Try(1, True).filter(is_greater_than_one) == Try(1, False)
    assert Try(2, True).filter(is_greater_than_one) == Try(2, True)


# Generated at 2022-06-24 00:25:33.100848
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(5, True).on_success(lambda x: x)\
        == Try(5, True)

    assert Try(5, False).on_success(lambda x: x)\
        == Try(5, False)



# Generated at 2022-06-24 00:25:36.184684
# Unit test for method bind of class Try
def test_Try_bind():
    def f(x):
        return Try(2 * x, True)
    assert Try(2, True) == Try(1, True).bind(f)
    assert Try(1, False) == Try(1, False).bind(f)


# Generated at 2022-06-24 00:25:38.601679
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try:
        raise Exception('Exception')
    except Exception as e:
        try1 = Try(e, False)
        try2 = Try(e, False)
        assert try1 == try2



# Generated at 2022-06-24 00:25:41.301364
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try("value", True).get_or_else("default_value") == "value"
    assert Try("value", False).get_or_else("default_value") == "default_value"


# Generated at 2022-06-24 00:25:42.787697
# Unit test for method get of class Try
def test_Try_get():
    ret = Try.of(lambda: 3)
    assert ret.get() == 3



# Generated at 2022-06-24 00:25:44.131110
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(3, True) == Try(3, True)


# Generated at 2022-06-24 00:25:48.445852
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def test_true():
        assert Try.of(lambda: 5, None).get_or_else(None) == 5

    def test_false():
        assert Try.of(lambda: raise_exc(), None).get_or_else(None) == None
        assert Try.of(lambda: raise_exc(), None).get_or_else(0) == 0

    run_test(test_true, 'test_Try_get_or_else: test_true')
    run_test(test_false, 'test_Try_get_or_else: test_false')


# Generated at 2022-06-24 00:25:57.660979
# Unit test for method bind of class Try
def test_Try_bind():
    def add(value):
        return Try(value + 1, True)

    assert Try.of(lambda: 1, ).bind(add) == Try(2, True)
    assert Try.of(lambda: 1, ).bind(lambda x: Try(x + 1, True)) == Try(2, True)
    assert Try.of(lambda: 1, ).bind(add).bind(add) == Try(3, True)

    def error():
        return Try(None, False)

    assert Try.of(lambda: 1, ).bind(error) == Try.of(lambda: 1, ).bind(error)
    assert Try.of(lambda: 1, ).bind(error) == Try(None, False)



# Generated at 2022-06-24 00:25:59.440250
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) == Try(None, True)

# Generated at 2022-06-24 00:26:04.110213
# Unit test for method __str__ of class Try
def test_Try___str__():
    """Unit test for method __str__ of class Try."""
    assert str(Try('value_1', True)) == 'Try[value=value_1, is_success=True]'
    assert str(Try('value_2', False)) == 'Try[value=value_2, is_success=False]'


# Generated at 2022-06-24 00:26:07.254615
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert(Try(1, True).get_or_else(0) == 1)
    assert(Try(None, False).get_or_else(0) == 0)


# Generated at 2022-06-24 00:26:11.704073
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(0, False) == Try(0, False)
    assert Try(0, True) == Try(0, True)
    assert Try(0, False) != Try(0, True)
    assert not Try(0, False) == None
    assert Try(Exception('error'), False) == Try(Exception('error'), False)


# Generated at 2022-06-24 00:26:14.895115
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, False) != Try(None, True)
    assert Try(None, False) != Try(1, False)



# Generated at 2022-06-24 00:26:18.148282
# Unit test for method map of class Try
def test_Try_map():
    """
    Scenario:
    * add 1 to value of successfuly Try
    * return successfuly Try with this value

    :return:
    """

    def add_1(x):
        return x + 1

    assert Try.of(lambda: 1).map(add_1) == Try(2, True)


# Generated at 2022-06-24 00:26:21.628539
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    success_one = Try(1, True)
    success_two = Try(2, True)
    fail_one = Try(1, False)

    assert success_one == success_one
    assert fail_one == fail_one

    assert success_one != success_two
    assert success_one != fail_one


# Generated at 2022-06-24 00:26:28.882378
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda x: x, 1) == Try(1, True)
    assert Try.of(lambda x: x, 1).bind(lambda x: Try(x, True)) == Try(1, True)
    assert Try.of(lambda: 1 / 0).bind(lambda x: Try(x, True)) == Try(ZeroDivisionError, False)
    assert Try.of(lambda x: 1 / x).bind(lambda x: Try(x, True))(0) == Try(ZeroDivisionError, False)



# Generated at 2022-06-24 00:26:35.319325
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:26:38.987831
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(t):
        assert isinstance(t, str)
        assert t == 'test'

    assert Try('test', False).on_fail(fail_callback) == Try('test', False)
    assert Try(12, False).on_fail(fail_callback) == Try(12, False)


# Generated at 2022-06-24 00:26:41.194325
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(0, True).on_fail(lambda x: print('fail')) == Try(0, True)
    assert Try(0, False).on_fail(lambda x: print('fail')) == Try(0, False)


# Generated at 2022-06-24 00:26:43.811522
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try(1, True).is_success
    assert not Try(1, False).is_success

# Generated at 2022-06-24 00:26:48.499233
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_ = Try(success=True, value=10)
    assert try_.get_or_else(default_value=0) == 10

    false_try_ = Try(success=False, value=20)
    assert false_try_.get_or_else(default_value=0) == 0

# Generated at 2022-06-24 00:26:51.153006
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception('foo'), False)) == 'Try[value=Exception("foo"), is_success=False]'



# Generated at 2022-06-24 00:26:54.585066
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test for method get_or_else of class Try
    """
    assert Try.of(lambda: 1).get_or_else(0) == 1
    assert Try.of(lambda: 1/0).get_or_else(0) == 0



# Generated at 2022-06-24 00:26:58.193325
# Unit test for constructor of class Try
def test_Try():
    try_1 = Try(1, True)

    assert try_1.value == 1
    assert try_1.is_success == True

    try_2 = Try(1, False)

    assert try_2.value == 1
    assert try_2.is_success == False


# Generated at 2022-06-24 00:27:04.785568
# Unit test for method on_success of class Try
def test_Try_on_success():
    def func(x):
        return x + 1

    def callback(val):
        val = val + 1
        print(val)

    # test a successful try
    assert Try(1, True).on_success(callback) == Try(1, True)
    assert Try(2, True).on_success(callback) == Try(2, True)
    assert Try(10, True).on_success(callback) == Try(10, True)
    assert Try('5', True).on_success(callback) == Try('5', True)

    # test a failing try
    assert Try(1, False).on_success(callback) == Try(1, False)
    assert Try(2, False).on_success(callback) == Try(2, False)

# Generated at 2022-06-24 00:27:11.671273
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(12, True)) == 'Try[value=12, is_success=True]'
    assert str(Try(12, False)) == 'Try[value=12, is_success=False]'
    assert str(Try('Hello', True)) == 'Try[value=Hello, is_success=True]'
    assert str(Try('Hello', False)) == 'Try[value=Hello, is_success=False]'



# Generated at 2022-06-24 00:27:12.888876
# Unit test for method get of class Try
def test_Try_get():
    value = 42
    assert Try.of(lambda: value).get() == 42
    assert Try.of(lambda: value + 4).get() == 46


# Generated at 2022-06-24 00:27:15.245391
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, True)



# Generated at 2022-06-24 00:27:23.738692
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    result = None
    Try.of(lambda x: x + 1, 1).on_fail(lambda err: err.args[0]).on_success(lambda x: result.append(x))
    assert result == None
    result = []
    Try.of(lambda x: x + 1, 1).on_fail(lambda err: result.append(err.args[0])).get()
    assert result == []
    result = []
    Try.of(lambda x: 1 / 0, 1).on_fail(lambda err: result.append(err.args[0])).get()
    assert result == [ZeroDivisionError]
    result = []

# Generated at 2022-06-24 00:27:27.930689
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) != Try(2, True)


# Generated at 2022-06-24 00:27:33.205360
# Unit test for method map of class Try
def test_Try_map():
    # given
    def partial_addition(a, b):
        return a + b

    def triple(a):
        return a * 3

    addition = functools.partial(partial_addition, 1)

    # when
    result = Try.of(addition, 2)

    # then
    assert result.map(triple) == Try(9, True)
    assert result.map(triple) != Try(8, True)



# Generated at 2022-06-24 00:27:41.826761
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(v):
        return v > 1

    assert Try(2, True).filter(filterer) == Try(2, True)
    assert Try(0, True).filter(filterer) == Try(0, False)
    assert Try(2, False).filter(filterer) == Try(2, False)
    assert Try(0, False).filter(filterer) == Try(0, False)
    assert Try(3, True).filter(filterer) == Try(3, True)
    assert Try(3, False).filter(filterer) == Try(3, False)


# Generated at 2022-06-24 00:27:44.466555
# Unit test for method on_success of class Try
def test_Try_on_success():
    def callback(*args):
        assert args == (3, 5)

    def _test():
        return Try.of(lambda x, y: x * y, 3, 5)

    _test().on_success(callback)
    assert _test().on_success(callback).get() == 15


# Generated at 2022-06-24 00:27:50.759624
# Unit test for method map of class Try
def test_Try_map():
    def five():
        return 5

    def add_two(x):
        return x+2

    assert Try.of(five).map(add_two) == Try(7, True)
    assert Try.of(lambda: 1 / 0).map(add_two) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:27:53.199601
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert Try(5, True).__str__() == 'Try[value=5, is_success=True]'


# Generated at 2022-06-24 00:27:59.783586
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    success_try = Try(1, True)
    not_success_try = Try(1, False)
    other_try = Try('1', True)

    assert success_try == success_try
    assert not_success_try == not_success_try
    assert other_try == other_try
    assert success_try != not_success_try
    assert success_try != other_try
    assert not_success_try != other_try


# Generated at 2022-06-24 00:28:02.969201
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-24 00:28:11.560515
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    When call __str__ on successfully Try[1] method return 'Try[value=1, is_success=True]'
    When call __str__ on not successfully Try[Exception('test',)] method return 'Try[value=test, is_success=False]'
    """
    assert str(Try.of(lambda x: 1, None)) == 'Try[value=1, is_success=True]'
    assert str(Try.of(lambda: 1/0, None)) == 'Try[value=division by zero, is_success=False]'



# Generated at 2022-06-24 00:28:14.414990
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(10, True).on_success(lambda x: print(x)) == Try(10, True)
    assert Try(10, False).on_success(lambda x: print(x)) == Try(10, False)



# Generated at 2022-06-24 00:28:17.143628
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-24 00:28:20.431498
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'



# Generated at 2022-06-24 00:28:25.858664
# Unit test for method __str__ of class Try
def test_Try___str__():
    from unittest.mock import patch

    with patch('sys.stdout', new=io.StringIO()) as out:
        print(Try(1, True))
        assert out.getvalue() == 'Try[value=1, is_success=True]\n', "Invalid value is printed to stdout"

test_Try___str__()


# Unit tests for method __eq__ of class Try

# Generated at 2022-06-24 00:28:28.121075
# Unit test for method get of class Try
def test_Try_get():
    import pytest

    assert Try(5, True).get() == 5
    assert Try('Hello', True).get() == 'Hello'


# Generated at 2022-06-24 00:28:32.146088
# Unit test for method bind of class Try
def test_Try_bind():
    """
    >>> Try.of(lambda: 5).get()
    5

    >>> Try.of(lambda: 5).bind(lambda v: Try(v + 2, True)).get()
    7

    >>> Try.of(lambda: 1/0).bind(lambda v: Try(v + 2, True)).get()
    0.0
    """

# Generated at 2022-06-24 00:28:34.935821
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x + 1, 2).filter(lambda x: x == 3) == Try(2, True)
    assert Try.of(lambda x: x + 1, 2).filter(lambda x: x == 2) == Try(2, False)



# Generated at 2022-06-24 00:28:38.696863
# Unit test for method map of class Try
def test_Try_map():
    """
    Testing method map of class Try

    :return:
    """
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)



# Generated at 2022-06-24 00:28:44.138637
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda value: value > 10).is_success is False
    assert Try(10, True).filter(lambda value: value < 10).is_success is False
    assert Try(10, True).filter(lambda value: value == 10).get() == 10
    assert Try('', False).filter(lambda value: isinstance(value, Exception)).is_success is False
