

# Generated at 2022-06-24 00:18:47.109730
# Unit test for method get of class Try
def test_Try_get():
    assert Try('abc', True).get() == 'abc'
    assert Try('abc', False).get() == 'abc'


# Generated at 2022-06-24 00:18:56.877528
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_success = Try(1, True)
    try_fail = Try(1, False)
    try_other_result = Try(2, True)
    try_other_success = Try(1, False)

    assert try_success == Try(1, True)
    assert not try_success == try_fail
    assert not try_success == try_other_result
    assert not try_success == try_other_success

    assert not try_fail == Try(1, True)
    assert try_fail == Try(1, False)
    assert not try_fail == try_other_result
    assert try_fail == try_other_success

    assert not try_other_result == Try(1, True)
    assert not try_other_result == try_fail
    assert try_other_result == Try(2, True)
   

# Generated at 2022-06-24 00:18:57.882183
# Unit test for method get of class Try
def test_Try_get():
    actual = Try(1, True).get()
    expect = 1
    assert actual == expect

# Generated at 2022-06-24 00:19:00.663746
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:19:07.236961
# Unit test for method get of class Try
def test_Try_get():
    def a():
        return 1
    # test successful result
    assert Try.of(a, ()).get() == 1
    # test unknown exception
    try:
        def b():
            raise ArithmeticError
        assert Try.of(b, ()).get() == 1
    except:
        pass


# Generated at 2022-06-24 00:19:15.173114
# Unit test for constructor of class Try
def test_Try():
    assert Try(5, True) == Try(5, True)
    assert Try(5, False) != Try(5, True)
    assert Try(5, True) != Try(4, False)
    assert Try(5, False) != Try(4, True)
    assert Try(5, False) != Try(4, False)
    assert Try(4, True) != Try(4, False)



# Generated at 2022-06-24 00:19:21.853654
# Unit test for method map of class Try
def test_Try_map():
    def plus(value):
        return value + 3

    monad = Try.of(float, '5')
    assert monad.map(plus) == Try(8.0, True)

    def raise_exception_func():
        raise Exception('Exception text')

    monad = Try.of(raise_exception_func)
    assert monad.map(plus) == Try(monad.value, False)



# Generated at 2022-06-24 00:19:24.343188
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'
    assert str(Try(Exception('Test exception'), False)) == 'Try[value=Test exception, is_success=False]'


# Generated at 2022-06-24 00:19:30.072408
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'

    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'

    try:
        1
    except Exception as e:
        assert str(Try(e, False)) == 'Try[value={}, is_success=False]'.format(e)


# Generated at 2022-06-24 00:19:31.218556
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-24 00:19:41.466340
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test if on_fail method of class Try works correctly.
    """
    def dummy_exception_fail_callback(exception):
        exception.message = 'Successfully'

    class DummyException(Exception):
        pass

    try_success_monad = Try(10, True)
    try_fail_monad = Try(DummyException('Error'), False)

    try_success_monad.on_fail(dummy_exception_fail_callback)
    assert try_success_monad.value == 10
    assert try_success_monad.is_success

    try_fail_monad.on_fail(dummy_exception_fail_callback)
    assert try_fail_monad.value.message == 'Successfully'
    assert not try_fail_monad.is_success


# Unit test

# Generated at 2022-06-24 00:19:45.641773
# Unit test for method filter of class Try
def test_Try_filter():
    def test_value(value):
        return value > 10

    assert Try(1, True).filter(test_value) == Try(1, False)
    assert Try(11, True).filter(test_value) == Try(11, True)

# Generated at 2022-06-24 00:19:47.282622
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-24 00:19:50.175101
# Unit test for method on_success of class Try
def test_Try_on_success():
    test_result = []
    p = lambda x: test_result.append(x)
    Try(1, True).on_success(p).on_fail(None)
    ok_(test_result == [1])


# Generated at 2022-06-24 00:19:56.557311
# Unit test for method on_success of class Try
def test_Try_on_success():
    def on_success_callback_a(x):
        assert(x == 1)

    def on_success_callback_b(x):
        assert(x == 2)

    def on_success_callback_c(x):
        assert(x == 1)

    def on_success_callback_d(x):
        assert(x == 2)

    def on_success_callback_e(x):
        assert(x == 1)

    def on_success_callback_f(x):
        assert(x == 2)

    def on_success_callback_g(x):
        assert(x == 3)

    def on_success_callback_h(x):
        assert(x == 4)

    def on_success_callback_i(x):
        assert(x == 3)


# Generated at 2022-06-24 00:20:03.672233
# Unit test for method bind of class Try
def test_Try_bind():
    binded = Try.of(lambda d: d['key'], dict({'key': 'val'})).bind(lambda d: Try.of(lambda v: v + ' test', d))
    assert binded == Try('val test', True)
    assert Try.of(lambda d: d['key1'], dict({'key': 'val'})).bind(lambda d: Try.of(lambda v: v + ' test', d)) == Try('val test', False)


# Generated at 2022-06-24 00:20:12.873887
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)

    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)

    assert Try(Exception('error'), False) == Try(Exception('error'), False)

    assert Try(Exception('error'), False) != Try(Exception('error'), True)
    assert Try(Exception('error'), False) != Try(Exception('another_error'), False)
    assert Try(Exception('error'), False) != Try(Exception('another_error'), True)

    assert Try(1, True) != None  # noqa
    assert Try(Exception('error'), False) != None  # noqa


# Generated at 2022-06-24 00:20:22.200621
# Unit test for method bind of class Try
def test_Try_bind():
    import unittest
    class TestTryBind(unittest.TestCase):

        def test_bind_try_with_exception_when_binder_raises_exception(self):
            def fn():
                raise Exception('Exception in main function')

            def fn_with_exception():
                return Try.of(fn)

            def binder(result_of_try_with_exception):
                raise Exception('Exception in binder')

            result = fn_with_exception().bind(binder)
            self.assertFalse(result.is_success)
            self.assertEqual(result.value.args[0], 'Exception in binder')


# Generated at 2022-06-24 00:20:29.543945
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    assert Try('test', True).get() == 'test'
    assert Try([1, 2, 3], True).get() == [1, 2, 3]
    assert Try('test', False).get() == 'test'
    assert Try(None, False).get() is None
    assert Try(None, True).get() is None
    assert Try(Exception('test'), False).get()


# Generated at 2022-06-24 00:20:34.360401
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def test(some_value):
        print(some_value)

    Try.of(lambda: 1 / 0).on_fail(test)



# Generated at 2022-06-24 00:20:38.321357
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda x: x, 1)\
        .bind(lambda x: Try.of(lambda x: x, x+1)) == Try(2, True)
    assert Try(ValueError(), False)\
        .bind(lambda x: Try.of(lambda x: x, x+1)) == Try(ValueError(), False)
    assert Try.of(lambda x: x, 1)\
        .bind(lambda x: Try.of(lambda x: x, ValueError()+1)) == Try(ValueError(), False)

# Generated at 2022-06-24 00:20:40.257631
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 2+2).on_success(lambda v: v == 4)

# Generated at 2022-06-24 00:20:45.910005
# Unit test for method bind of class Try
def test_Try_bind():
    """ Test Try bind method """

    # Test with successful case
    result = Try.of(lambda x: x, 1*1)\
        .bind(lambda x: Try.of(lambda y: x+y, x*3))
    assert result == Try(4, True)

    # Test with fail case
    result = Try.of(lambda x: x, 1*1)\
        .bind(lambda x: Try.of(lambda y: z+y, x*3))
    assert result == Try(NameError, False)


# Generated at 2022-06-24 00:20:49.124800
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(a):
        return (a % 2) == 0

    assert Try.of(int, '42').filter(filterer) == Try(42, True)
    assert Try.of(int, '1').filter(filterer) == Try(1, False)

# Generated at 2022-06-24 00:20:54.899857
# Unit test for method __str__ of class Try
def test_Try___str__():
    t0 = Try(None, False)
    assert str(t0) == 'Try[value=None, is_success=False]'
    t1 = Try(5, True)
    assert str(t1) == 'Try[value=5, is_success=True]'
    t2 = Try(Exception('fail'), False)
    assert str(t2) == 'Try[value=Exception: fail, is_success=False]'


# Generated at 2022-06-24 00:20:57.381783
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(11, True).get() == 11
    assert Try(11, False).get() == 11


# Generated at 2022-06-24 00:21:06.276013
# Unit test for method filter of class Try
def test_Try_filter():
	"""
	The function test the filter method of class Try.
	"""
	def filter_fn(value):
		return value > 4

	# Test with non-negative value
	test_try = Try.of(lambda: 5)
	test_try = test_try.filter(filter_fn)
	if test_try != Try(5, True):
		raise RuntimeError('should return 5')

	# Test with negative value
	test_try = Try.of(lambda: 4)
	test_try = test_try.filter(filter_fn)
	if test_try != Try(4, False):
		raise RuntimeError('should return 4')



# Generated at 2022-06-24 00:21:11.293107
# Unit test for method bind of class Try
def test_Try_bind():
    # Test successful binding
    assert Try(5, True).bind(lambda x: Try(x*2, True)) == Try(10, True)

    # Test failed binding
    try_left = Try(5, False)
    try_right = try_left.bind(lambda x: Try(x*2, True))
    assert try_right == try_left


# Generated at 2022-06-24 00:21:14.396690
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(0, True).filter(lambda x: x > 0) == Try(0, False)
    assert Try(10, True).filter(lambda x: x > 0) == Try(10, True)


# Generated at 2022-06-24 00:21:25.057890
# Unit test for constructor of class Try
def test_Try():
    """Unit test for constructor of class Try."""
    with pytest.raises(TypeError):
        Try(None, False)

    with pytest.raises(TypeError):
        Try(None, True)

    assert Try(1, False) == Try(1, False)
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(1, False)

    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:21:33.050161
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(x):
        return x % 2 == 0
    assert Try(2, True).filter(is_even).is_success
    assert not Try(2, True).filter(lambda x: x % 2 != 0).is_success
    assert Try(2, False).filter(is_even).is_success
    assert not Try(3, True).filter(is_even).is_success
    assert not Try(3, False).filter(is_even).is_success


# Generated at 2022-06-24 00:21:40.111983
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Try bind when monad is successfully
    """
    assert Try(5, True).bind(lambda x: Try(x * x, True)) == Try(25, True)
    """
    Try bind when monad is not successfully
    """
    assert Try(5, False).bind(lambda x: Try(x * x, True)) == Try(5, False)


# Generated at 2022-06-24 00:21:44.810242
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-24 00:21:46.936439
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception(), False)) == 'Try[value=Exception(), is_success=False]'


# Generated at 2022-06-24 00:21:49.052732
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-24 00:21:54.345617
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(None, True).map(lambda x: x) == Try(None, True)
    assert Try('Test', True).map(lambda x: x.upper()) == Try('TEST', True)
    assert Try(None, False).map(lambda x: x) == Try(None, False)
    assert Try(Exception, False).map(lambda x: x) == Try(Exception, False)


# Generated at 2022-06-24 00:21:59.493473
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    try_ = Try(1, True)
    assert try_ == Try(1, True)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, True) == Try(2, False)
    assert not Try(1, False) == Try(2, True)



# Generated at 2022-06-24 00:22:03.649076
# Unit test for method get of class Try
def test_Try_get():
    """
    Return monad value.
    """
    # Success
    monad_success = Try(1, True)
    assert monad_success.get() == 1

    # Failure
    monad_failure = Try(ValueError('failure'), False)
    assert monad_failure.get() == ValueError('failure')


# Generated at 2022-06-24 00:22:05.133869
# Unit test for constructor of class Try
def test_Try():
    assert Try('Hello', True) == Try('Hello', True)



# Generated at 2022-06-24 00:22:16.542843
# Unit test for method filter of class Try
def test_Try_filter():
    identity = lambda x: x
    identity_Try = lambda x: Try(x, True)
    assert identity_Try(10).filter(identity) == Try(10, True)
    assert identity_Try('test').filter(identity) == Try('test', True)
    assert identity_Try(10).map(lambda x: x + 10).filter(identity) == Try(20, True)
    assert identity_Try(10).bind(lambda x: Try(x + 10, True)).filter(identity) == Try(20, True)

    assert Try(10, False).filter(lambda x: x > 10) == Try(10, False)
    assert Try('test', False).filter(lambda x: len(x) == 4) == Try('test', False)

# Generated at 2022-06-24 00:22:19.379178
# Unit test for method map of class Try
def test_Try_map():
    assert Try(10, True)\
        .map(lambda x: x + 10)\
        .get() == 20

    assert Try(None, False)\
        .map(lambda x: x + 10)\
        .get() is None



# Generated at 2022-06-24 00:22:23.636982
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test for method map of class Try.
    """
    assert Try(3, True).map(lambda x: x * x) == Try(9, True)
    assert Try.of(lambda: 1 / 0).map(lambda x: x * x) == Try(ZeroDivisionError('division by zero'), False)



# Generated at 2022-06-24 00:22:28.954826
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Unit test for method on_success of class Try
    """
    def test():
        value = 10
        def callback(a):
            nonlocal value
            value = a
        t = Try(value, True)
        t.on_success(callback)
        assert value == t.value
        assert value == 10

    test()

# Generated at 2022-06-24 00:22:32.378288
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try('OK', True) == Try('OK', True)
    assert Try('OK', True) != Try('OK', False)
    assert Try('OK', False) != 'OK'


# Generated at 2022-06-24 00:22:36.365448
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def raise_exception(value):
        raise IndexError()

    try_value = Try.of(raise_exception, 1)
    assert isinstance(try_value, Try)
    assert try_value == Try(IndexError(), False)
    assert try_value.on_fail(lambda x: 1) == try_value
    assert try_value.on_success(lambda x: 1) == try_value
    assert try_value.get() == IndexError()
    assert try_value.get_or_else(1) == 1


# Generated at 2022-06-24 00:22:39.445526
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    first = Try(1, True)
    second = Try(1, True)
    assert first == second



# Generated at 2022-06-24 00:22:41.446202
# Unit test for method get of class Try
def test_Try_get():
    try_ = Try(100, True)
    assert try_.get() == 100
    try_ = Try(None, False)
    try_.get() is None

# Generated at 2022-06-24 00:22:42.541136
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)


# Generated at 2022-06-24 00:22:47.001866
# Unit test for method on_success of class Try
def test_Try_on_success():

    def success_callback(value):
        assert value == 111

    def fail_callback(value):
        assert value == 222

    Try(111, True)\
        .on_success(success_callback)\
        .on_success(success_callback)\
        .on_fail(fail_callback)\
        .on_fail(fail_callback)

    Try(222, False)\
        .on_success(success_callback)\
        .on_fail(fail_callback)\
        .on_fail(fail_callback)\
        .on_success(success_callback)



# Generated at 2022-06-24 00:22:48.721014
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(value):
        assert value == 'test'

    Try(1, True).on_fail(fail_callback)
    Try('test', False).on_fail(fail_callback)


# Generated at 2022-06-24 00:22:50.794288
# Unit test for method get of class Try
def test_Try_get():
    assert Try("Hello", True).get() == "Hello"
    assert Try("Hello", False).get() == "Hello"


# Generated at 2022-06-24 00:22:54.438387
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Call method get_or_else of class Try.
    """
    assert True == Try(True, True).get_or_else(False)
    assert False == Try(False, False).get_or_else(True)


# Generated at 2022-06-24 00:22:58.250679
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    t = Try(1, True)
    assert str(t) == 'Try[value=1, is_success=True]'

    t = Try('Error', False)
    assert str(t) == 'Try[value=Error, is_success=False]'



# Generated at 2022-06-24 00:23:01.220639
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:23:03.615333
# Unit test for method get of class Try
def test_Try_get():
    value = 'Value'
    try_success = Try(value, True)
    try_not_success = Try(value, False)

    assert value == try_success.get()
    assert value == try_not_success.get()


# Generated at 2022-06-24 00:23:06.461700
# Unit test for method bind of class Try
def test_Try_bind():
    actual = Try.of(lambda: 1 + 2)\
        .bind(lambda x: Try.of(lambda: x + 2))\
        .bind(lambda x: Try.of(lambda: x ** x))
    expected = Try(27, True)
    assert actual == expected, actual.__str__()



# Generated at 2022-06-24 00:23:14.120989
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    print('test_Try_filter()')
    inc = lambda n: n + 1
    s = Try.of(inc, 0)
    assert s.filter(lambda v: v > 2) == Try(1, False)
    assert s.filter(lambda v: v <= 2) == Try(1, True)
    assert Try(0, False).filter(lambda v: v > 2) == Try(0, False)
    assert Try(0, False).filter(lambda v: v <= 2) == Try(0, False)



# Generated at 2022-06-24 00:23:20.060722
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Checks if monad Try calls success callback when monad is successfully,
    othercase checks that nothing happens.

    :returns: None
    :rtype: None
    """
    assert Try.of(lambda: 1).on_success(lambda x: x / 2) == Try(0.5, True)
    assert Try.of(lambda: 1, 2).on_success(lambda x: x / 2) == Try(TypeError("unsupported operand type(s) for /: 'int' and 'tuple'"), False)
    assert Try.of(lambda: 1, 2).on_success(lambda x: x / 2).value == TypeError("unsupported operand type(s) for /: 'int' and 'tuple'")


# Generated at 2022-06-24 00:23:25.594106
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)

    assert Try(1, True).is_success
    assert not Try(1, False).is_success
    assert Try(1, False).value == 1


# Generated at 2022-06-24 00:23:31.347856
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(exc):
        assert type(exc) is ValueError
    try:
        raise ValueError()
    except ValueError as e:
        result = Try(e, False).on_fail(fail_callback)
        assert result == Try(e, False)
    try:
        raise ValueError()
    except ValueError as e:
        result = Try(e, True).on_fail(fail_callback)
        assert result == Try(e, True)


# Generated at 2022-06-24 00:23:33.910004
# Unit test for method get of class Try
def test_Try_get():
    # given
    tryy = Try.of(float, '1.0')

    # when
    result = tryy.get()

    # then
    assert result == 1.0


# Generated at 2022-06-24 00:23:39.042034
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_test(x):
        pass

    assert Try.of(lambda: 1, 1).on_fail(fail_test) == Try(1, True)
    assert Try.of(lambda: 1 / 0, 1).on_fail(fail_test) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:23:42.888179
# Unit test for method filter of class Try
def test_Try_filter():
    actual = Try\
        .of(lambda x: x + 1, 1)\
        .filter(lambda x: x > 1)\
        .on_success(print)\
        .on_fail(lambda x: print('Error:', x))

    expected = Try(None, False)

    assert actual == expected


# Generated at 2022-06-24 00:23:50.009634
# Unit test for method map of class Try
def test_Try_map():
    def add_10(value):
        return value + 10

    def devide(value):
        return 10 / value

    assert Try.of(add_10, 10).map(add_10) == Try(30, True)
    assert Try.of(add_10, 10).map(devide) == Try(1, True)
    assert Try.of(devide, 0).map(add_10) == Try(ZeroDivisionError(), False)
    assert Try.of(devide, 0).map(devide) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:23:51.879705
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 2).map(lambda x: x * 3) == Try(6, True)
    assert Try.of(lambda: 2/0).map(lambda x: x * 3) == Try('division by zero', False)


# Generated at 2022-06-24 00:23:55.640493
# Unit test for method map of class Try
def test_Try_map():
    assert Try(lambda x: x, True).map(lambda x: x + 2).get() == 2
    assert Try(lambda x: x, False).map(lambda x: x + 2).is_success == False



# Generated at 2022-06-24 00:23:57.812455
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_handler(value):
        assert value == value
    Try.of(lambda: 1 / 0, list()).on_fail(test_handler)


# Generated at 2022-06-24 00:24:06.083157
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try(Exception(), True)) == 'Try[value=Exception(), is_success=True]'
    assert str(Try(Exception(), False)) == 'Try[value=Exception(), is_success=False]'


# Generated at 2022-06-24 00:24:09.941246
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(ValueError(), False).on_fail(lambda x: print(x)) == Try(ValueError(), False)


# Generated at 2022-06-24 00:24:16.123687
# Unit test for method bind of class Try
def test_Try_bind():
    first = Try(12, True)
    second = Try(8, True)
    result = first.bind(lambda x: Try(-x, True))\
        .bind(lambda x: second.bind(lambda y: Try(x + y, True))).get()
    assert -12 == result

    first = Try(12, True)
    second = Try(8, False)
    result = first.bind(lambda x: Try(-x, True))\
        .bind(lambda x: second.bind(lambda y: Try(x + y, True)))
    assert result.is_success is False
    assert 8 == result.value

    first = Try(12, False)
    second = Try(8, True)

# Generated at 2022-06-24 00:24:19.648849
# Unit test for method map of class Try
def test_Try_map():
    """
    Test method map of class Try
    """
    value = Try(1, True).map(lambda x: x + 1)
    assert value == Try(2, True)
    value = Try(1, False).map(lambda x: x + 1)
    assert value == Try(1, False)


# Generated at 2022-06-24 00:24:22.004281
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert_that(Try.of(lambda: 0/0).on_fail(lambda _: print('some log message')))



# Generated at 2022-06-24 00:24:28.140400
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(2, True) != Try(2, False)
    assert Try(3, True) != Try(1, True)
    assert Try(4, False) != Try(2, False)
    assert Try(5, False) != Try(1, False)
    assert Try(6, False) != Try(2, True)


# Generated at 2022-06-24 00:24:31.065238
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(10, True) == Try(10, True)
    assert Try(10, False) == Try(10, False)


# Generated at 2022-06-24 00:24:33.955366
# Unit test for method get of class Try
def test_Try_get():
    # Arrange
    val = 1
    expect = 1
    try_value = Try(val, True)

    # Act
    actual = try_value.get()

    # Assert
    assert actual == expect


# Generated at 2022-06-24 00:24:37.433128
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(1, True)
    assert 'Try[value=1, is_success=True]' == str(try_)



# Generated at 2022-06-24 00:24:39.293636
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('', True)) == 'Try[value=, is_success=True]'


# Generated at 2022-06-24 00:24:42.840384
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_1 = Try(1, True)
    try_2 = Try(1, False)

    assert try_1.get_or_else(0) == 1
    assert try_2.get_or_else(0) == 0


# Generated at 2022-06-24 00:24:45.850431
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda value: value + 1) == Try(2, True)
    assert Try(1, False).map(lambda value: value + 1) == Try(1, False)



# Generated at 2022-06-24 00:24:51.463458
# Unit test for method on_success of class Try
def test_Try_on_success():
    # GIVEN
    def second_callback(value):
        assert value == 2

    def first_callback(value):
        assert value == 1
        return Try(2, True).on_success(second_callback)

    def second_fail_callback(value):
        assert value == 2

    def first_fail_callback(value):
        assert isinstance(value, Exception)
        return Try(2, False).on_success(second_fail_callback)

    # WHEN
    first_callback(1)
    first_fail_callback(Exception())



# Generated at 2022-06-24 00:25:00.348026
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(int, '35')\
        .bind(lambda x: Try.of(lambda y: x + y, 2))\
        .get() == 37

    assert Try.of(int, 'a')\
        .bind(lambda x: Try.of(lambda y: x + y, 2))\
        .get_or_else(42) == 42

    assert Try.of(int, 'a')\
        .bind(lambda x: Try.of(lambda y: x + y, 2))\
        .get() is not 42

    assert Try.of(lambda x: x + 2, 2)\
        .bind(lambda func: Try.of(func, 2))\
        .get() == 4


# Generated at 2022-06-24 00:25:06.553384
# Unit test for method bind of class Try
def test_Try_bind():
    def fn_call():
        raise Exception('Error')

    def binder(a):
        return Try(a+1, True)

    result = Try.of(fn_call).bind(binder)
    assert result == Try(Exception('Error'), False)

    result = Try.of(lambda: 2).bind(binder)
    assert result == Try(3, True)



# Generated at 2022-06-24 00:25:17.308465
# Unit test for method bind of class Try
def test_Try_bind():
    # Unit test for method bind of class Try
    # Take monad with value equals 1 and with success state
    monad = Try(1, True)
    # Take function and bind to monad, when function return new Try with value equals 2 and with success state
    monad = monad.bind(lambda x: Try(2, True))
    # Take function and bind to monad, when function return new Try with value equals 3 and with success state
    monad = monad.bind(lambda x: Try(3, True))
    # The value of monad equals 3, and monad is successfull
    assert(monad.value == 3 and monad.is_success)
    # Take monad with value equals 1 and with success state
    monad = Try(1, True)
    # Take function and bind to monad, when function return new Try with value

# Generated at 2022-06-24 00:25:20.160081
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    Try.of(lambda a, b: a / b, 1, 0)\
        .on_fail(lambda e:
                 assert_that(e, is_instance_of(ZeroDivisionError)))
# End of unit test



# Generated at 2022-06-24 00:25:27.525291
# Unit test for method map of class Try
def test_Try_map():
    def get_data(arg):
        return Try.of(lambda: arg)

    assert get_data(1).map(lambda x: x + 1) == Try(2, True)
    assert get_data(1).map(lambda x: x + 1).map(lambda x: x + 1) == Try(3, True)
    assert get_data(1).map(lambda x: x / 0) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:25:30.111275
# Unit test for method map of class Try
def test_Try_map():
    assert Try(5, True).map(lambda x: x + 1) == Try(6, True)
    assert Try(5, False).map(lambda x: x + 1) == Try(5, False)


# Generated at 2022-06-24 00:25:33.393691
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def raise_exception():
        raise Exception('Test exception')

    # Test success branch
    mock_fn = Mock()
    Try.of(lambda: 10).on_fail(mock_fn)
    mock_fn.assert_not_called()

    # Test fail branch
    mock_fn = Mock()
    Try.of(raise_exception).on_fail(mock_fn)
    mock_fn.assert_called_once()



# Generated at 2022-06-24 00:25:38.376798
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        assert value == 10

    def fail_callback(value):
        raise AssertionError('Call on_fail when monad is successfully.')

    try_1 = Try(10, True)
    try_2 = Try(ValueError('Not a number'), False)

    try_1.on_success(success_callback)
    try_2.on_success(fail_callback)


# Generated at 2022-06-24 00:25:39.590177
# Unit test for method get of class Try
def test_Try_get():
    assert Try(3, True).get() == 3


# Generated at 2022-06-24 00:25:47.009118
# Unit test for method map of class Try
def test_Try_map():
    def mapper_one(value):
        return value + 1

    def mapper_two(value):
        return value + 2

    def exception_mapper(value):
        raise Exception()

    # Test for successfully
    assert Try.of(lambda x: x, 0).map(mapper_one) == Try(1, True)
    assert Try.of(lambda x: x, 0).map(mapper_two) == Try(2, True)

    # Test for not successfully
    assert Try.of(lambda x: x / 0, 0).map(mapper_one) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda x: x / 0, 0).map(mapper_two) == Try(ZeroDivisionError(), False)

    # Test for calling exception_mapper

# Generated at 2022-06-24 00:25:53.524114
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(2, False) != Try(1, False)
    assert Try(1, True) != Try(2, False)


# Generated at 2022-06-24 00:25:58.843431
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try('error', True)) == 'Try[value=error, is_success=True]'
    assert str(Try('error', False)) == 'Try[value=error, is_success=False]'


# Generated at 2022-06-24 00:26:00.215483
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == "Try[value=1, is_success=True]"


# Generated at 2022-06-24 00:26:03.521657
# Unit test for method filter of class Try
def test_Try_filter():
    def printer(arg):
        print('Printer arg: {}'.format(arg))

    def filterer(arg):
        return arg % 2 == 0

    value = 5
    try_success = Try.of(lambda x: x, value).filter(filterer).on_success(printer)
    assert try_success.is_success == False

# Generated at 2022-06-24 00:26:10.470033
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    t1 = Try(1, True)
    t2 = Try(1, False)
    t3 = Try(2, True)
    t4 = Try(2, False)
    t5 = Try(1, True)

    assert t1 == t5
    assert t1 != t2
    assert t1 != t3
    assert t1 != t4
    assert t2 != t3
    assert t2 != t4
    assert t3 != t4


# Generated at 2022-06-24 00:26:14.054990
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)

# Generated at 2022-06-24 00:26:21.795528
# Unit test for method map of class Try
def test_Try_map():
    # Test for successfully monad
    try_monad = Try.of(lambda: '1234')
    try_monad = try_monad.map(lambda x: x + '567')
    assert try_monad == Try('1234567', True)

    # Test for not successfully monad
    try_monad = Try.of(lambda: 1/0)
    try_monad = try_monad.map(lambda x: x + '567')
    assert try_monad == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:26:24.485081
# Unit test for method __str__ of class Try
def test_Try___str__():
    _try = Try(123, True)

    assert str(_try) == 'Try[value=123, is_success=True]'



# Generated at 2022-06-24 00:26:34.961706
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Simple unit test for monad Try method on_fail.

    :returns: None
    :rtype: NoneType
    """
    def divider(divided, divider):
        """
        Normal division function.

        :params divided: number to divide
        :type divided: Integer
        :params divider: number to divide by
        :type divider: Integer
        :returns: result of division
        :rtype: Integer
        """
        return divided / divider

    def on_fail_function(error):
        """
        Fixture function for Callback.

        :params error: Exception object
        :type error: Exception
        :returns: None
        :rtype: NoneType
        """
        assert isinstance(error, ZeroDivisionError)


# Generated at 2022-06-24 00:26:36.870206
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)

    assert Try(Exception('test'), False) == Try(Exception('test'), False)



# Generated at 2022-06-24 00:26:41.194457
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:26:45.476417
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    sut = Try(1, True)
    assert sut.filter(lambda x: x == 1) == Try(1, True)
    assert sut.filter(lambda x: x != 1) == Try(1, False)


# Generated at 2022-06-24 00:26:49.637234
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:26:51.195621
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1



# Generated at 2022-06-24 00:26:54.626530
# Unit test for method filter of class Try
def test_Try_filter():
    """Test for method filter of class Try."""
    _filter = lambda x: True
    assert Try(1, True).filter(_filter) == Try(1, True)
    assert Try(None, False).filter(_filter) == Try(None, False)



# Generated at 2022-06-24 00:26:57.271484
# Unit test for method map of class Try
def test_Try_map():
    assert Try(5, True).map(lambda x: x + 5) == Try(10, True)
    assert Try("error", False).map(lambda x: x + 1) == Try("error", False)


# Generated at 2022-06-24 00:27:02.450845
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_one = Try('value', True)
    try_two = Try('value', True)
    assert(try_one == try_two)

    try_one = Try('value', False)
    try_two = Try('value', False)
    assert(try_one == try_two)


# Generated at 2022-06-24 00:27:05.104298
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try('1', False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:27:10.482594
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'
    assert str(Try(5, False)) == 'Try[value=5, is_success=False]'
    assert str(Try('error', False)) == "Try[value=error, is_success=False]"



# Generated at 2022-06-24 00:27:17.963577
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def call_and_succeed(val):
        return Try(val, True)

    def call_and_fail(val):
        return Try(val, False)

    # Test successfully monad
    assert Try(1, True).bind(call_and_succeed) == Try(1, True)
    assert Try(1, True).bind(call_and_fail) == Try(1, False)
    # Test not successfully monad
    assert Try(1, False).bind(call_and_succeed) == Try(1, False)
    assert Try(1, False).bind(call_and_fail) == Try(1, False)



# Generated at 2022-06-24 00:27:20.519562
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Execute unit test for monad Try method __str__.
    """
    result = Try('value', True)
    assert str(result) == 'Try[value=value, is_success=True]'



# Generated at 2022-06-24 00:27:27.136478
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 1) == Try.of(lambda x: x, 1)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 2) == Try.of(lambda x: x, 1).bind(lambda _: Try(Exception(), False))

# Generated at 2022-06-24 00:27:28.467190
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'
    assert str(Try(5, False)) == 'Try[value=5, is_success=False]'



# Generated at 2022-06-24 00:27:33.306162
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert(str(Try(1, True)) == 'Try[value=1, is_success=True]')
    assert(str(Try(Exception('Exception'), False)) == 'Try[value=Exception: Exception, is_success=False]')


# Generated at 2022-06-24 00:27:38.527212
# Unit test for constructor of class Try
def test_Try(): # pragma: no cover
    key = 0
    value = True
    try_true = Try(value, True)
    try_false = Try(key, False)
    assert try_true == Try(value, True)
    assert try_false == Try(key, False)


# Generated at 2022-06-24 00:27:40.837751
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_value = Try.of(int, '10')
    assert try_value == Try(10, True)
    assert try_value.get_or_else(10) == 10
    try_value = Try.of(int, 'a')
    assert try_value == Try(ValueError(), False)
    assert try_value.get_or_else(10) == 10


# Generated at 2022-06-24 00:27:43.585658
# Unit test for method map of class Try
def test_Try_map():
    # positive case
    assert Try.of(lambda value: value, 1).map(lambda value: value*2) == Try(2, True)
    # negative case, exception
    assert Try.of(lambda value: value/0, 1).map(lambda value: value*2) == Try(ZeroDivisionError('division by zero'), False)
    # negative case, not Exception
    assert Try.of(lambda value: value, 1).map(lambda value: value/0) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:27:47.210374
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value > 10

    print('test_Try_filter')
    assert Try(12, True).filter(filterer) == Try(12, True)
    assert Try(12, True).filter(lambda x: x > 15) == Try(12, False)



# Generated at 2022-06-24 00:27:49.385343
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_value = Try('monad', True).get_or_else('default value')
    assert try_value == 'monad'
    try_value = Try('monad', False).get_or_else('default value')
    assert try_value == 'default value'


# Generated at 2022-06-24 00:27:56.245746
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:27:58.893543
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: x) == Try(1, True)
    assert Try(Exception(), False).on_fail(lambda x: x) == Try(Exception(), False)

# Generated at 2022-06-24 00:28:03.396963
# Unit test for method bind of class Try
def test_Try_bind():
    """TODO: Docstring for test_Try_bind.
    :returns: TODO

    """
    assert Try(100, True).bind(lambda x: Try(x + 10, True)).value == 110
    assert not Try(100, True).bind(lambda x: Try(x + 10, False)).is_success
    assert not Try(100, False).bind(lambda x: Try(x + 10, True)).is_success



# Generated at 2022-06-24 00:28:09.314919
# Unit test for method get of class Try
def test_Try_get():
    some_val = 123
    try_with_some_val = Try(some_val, True)
    assert(some_val == try_with_some_val.get())
    no_success_try = Try(some_val, False)
    assert(some_val == no_success_try.get())


# Generated at 2022-06-24 00:28:18.744314
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(3, True).get_or_else(4) == 3, 'get_or_else: by default does not return the same value'
    assert Try(None, False).get_or_else(4) == 4, 'get_or_else: when value is None return the same value'
    assert Try(None, True).get_or_else(4) == None, 'get_or_else: when value is None return the same value'
    assert Try('test', True).get_or_else(4) == 'test', 'get_or_else: when value is None return the same value'
    assert Try('', True).get_or_else(4) == '', 'get_or_else: when value is None return the same value'

# Generated at 2022-06-24 00:28:25.321929
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(10, True).on_fail(lambda x: print(x)).is_success is True
    assert Try(10, True).on_fail(lambda x: print(x)).value == 10

    assert Try(10, False).on_fail(lambda x: print(x)).is_success is False
    assert Try(10, False).on_fail(lambda x: print(x)).value == 10



# Generated at 2022-06-24 00:28:27.282316
# Unit test for method get of class Try
def test_Try_get():
    assert_that(Try(5, True).get()).is_equal_to(5)



# Generated at 2022-06-24 00:28:35.886743
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test for method on_fail of class Try.
    """
    def fail_callback(value):  # pylint: disable=unused-argument
        # add to errors_count
        test.errors_count = test.errors_count + 1
    test.errors_count = 0
    try_monad = Try('Fail monad', False)
    try_monad.on_fail(fail_callback)
    assert test.errors_count == 1
    try_monad = Try('Successfully monad', True)
    try_monad.on_fail(fail_callback)
    assert test.errors_count == 1


# Generated at 2022-06-24 00:28:44.056325
# Unit test for method bind of class Try
def test_Try_bind():
    def fn(x: int) -> int:
        return x + 1

    def fn_raise(x: int) -> int:
        raise Exception('Error')

    print(Try.of(lambda x: x + 1, 2))  # Try[value=3, is_success=True]
    print(Try.of(lambda x: x + 1, 'a'))  # Try[value=Exception("'x' must be integer",), is_success=False]

    print(Try.of(fn, 2))  # Try[value=3, is_success=True]
    print(Try.of(fn_raise, 2))  # Try[value=Exception("Error"), is_success=False]

    # Chaining methods
    print(Try.of(fn, 4).bind(lambda x: Try.of(fn, x + 1)))

# Generated at 2022-06-24 00:28:52.807052
# Unit test for method get of class Try
def test_Try_get():
    """
    Unit test for method get of class Try

    """
    assert Try(value=0, is_success=True).get() == 0
    assert Try(value=0, is_success=False).get() == 0
    assert Try(value=[], is_success=True).get() == []
    assert Try(value=[], is_success=False).get() == []
    assert Try(value={}, is_success=True).get() == {}
    assert Try(value={}, is_success=False).get() == {}
    assert Try(value=None, is_success=True).get() is None
    assert Try(value=None, is_success=False).get() is None
