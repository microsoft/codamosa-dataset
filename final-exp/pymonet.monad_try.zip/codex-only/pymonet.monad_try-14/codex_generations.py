

# Generated at 2022-06-24 00:18:50.172337
# Unit test for method map of class Try
def test_Try_map():
    """
    Try class.
    map method.
    """
    assert Try(20, True).map(lambda x: x + 10) == Try(30, True)
    assert Try(20, True).map(lambda x: x / 0) == Try(ZeroDivisionError('division by zero'), False)
    assert Try(ZeroDivisionError('division by zero'), False).map(lambda x: x + 10) == Try(ZeroDivisionError('division by zero'), False)
    assert Try(ZeroDivisionError('division by zero'), False).map(lambda x: x / 0) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:18:52.557857
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try.of(lambda: 2, *[]).get() == 2


# Generated at 2022-06-24 00:18:57.065991
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try('value', True)) == 'Try[value=value, is_success=True]'
    assert str(Try('value', False)) == 'Try[value=value, is_success=False]'
    assert str(Try(Exception('error'), True)) == 'Try[value=error, is_success=True]'



# Generated at 2022-06-24 00:19:02.482118
# Unit test for constructor of class Try
def test_Try():
    try_1 = Try(1, True)
    try_2 = Try(2, True)
    try_3 = Try(3, False)
    try_4 = Try(Exception("a"), True)
    try_5 = Try(Exception("b"), False)

    assert try_1 == Try(1, True)

    assert try_2 == Try(2, True)

    assert try_3 == Try(3, False)

    assert try_4 == Try(Exception("a"), True)

    assert try_5 == Try(Exception("b"), False)


# Generated at 2022-06-24 00:19:06.806558
# Unit test for method map of class Try
def test_Try_map():
    def f(x):
        return x + 1

    assert Try(1, True).map(f) == Try(2, True)
    assert Try(1, False).map(f) == Try(1, False)



# Generated at 2022-06-24 00:19:12.303295
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)


# Generated at 2022-06-24 00:19:16.034090
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x)) == Try(1, True)
    assert Try(1, False).on_success(lambda x: print(x)) == Try(1, False)

# Unit tests for method on_fail of class Try

# Generated at 2022-06-24 00:19:19.916516
# Unit test for method bind of class Try
def test_Try_bind():
    # Successfully test
    assert Try(10, True).bind(lambda x: Try(x * 10, True)) == Try(100, True)
    # Fail test
    assert Try(Exception('Error'), False).bind(lambda x: Try(x * 10, True)) == Try(Exception('Error'), False)
    # Not successfully test
    assert Try(10, True).bind(lambda x: Try(x / 0, False)) == Try(ZeroDivisionError, False)



# Generated at 2022-06-24 00:19:24.961578
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    print('test_Try_get_or_else method')
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0
    assert Try(0, False).get_or_else(1) == 1


# Generated at 2022-06-24 00:19:29.651022
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():

    def success_function(arg):
        return arg

    def fail_function(arg):
        raise Exception

    assert Try.of(success_function, 1).get_or_else(2) == 1
    assert Try.of(fail_function, 3).get_or_else(2) == 2


# Generated at 2022-06-24 00:19:32.650565
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Check work of method on_fail of class Try.

    :returns: None
    :rtype: None
    """
    expected = None
    actual = Try.of(lambda: 1 / 0).on_fail(lambda error: None)
    assert actual == expected

# Generated at 2022-06-24 00:19:36.100963
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try_result = Try.of(lambda: 0 / 1)
    try_result.on_fail(lambda e: print('Error catched'))
    assert try_result.get() == ZeroDivisionError()



# Generated at 2022-06-24 00:19:42.953201
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(print) == Try(1, True)

    called = False
    def trigger_event():
        nonlocal called
        called = True

    def return_1():
        return 1

    Try(return_1, True).bind(print).on_success(trigger_event)

    assert called is True

# Generated at 2022-06-24 00:19:48.127039
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    error = Exception('error')
    try_instance = Try(error, False)

# Generated at 2022-06-24 00:19:54.524375
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        raise RuntimeError('test error')
    except RuntimeError as e:
        error = e
    error_monad = Try(error, False)
    assert error_monad is error_monad.on_fail(print)

    try:
        1 + 1
    except Exception as e:
        error = e
    success_monad = Try(error, True)
    assert success_monad is success_monad.on_fail(print)



# Generated at 2022-06-24 00:20:01.367000
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:20:08.065255
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def fail_handler(value):
        return value

    # Test for fail handler
    assert Try(None, True).on_fail(fail_handler) == Try(None, True)
    assert Try(None, False).on_fail(fail_handler) == Try(None, False)

    # Test for try-catch
    assert Try.of(lambda: 5/0, None).on_fail(fail_handler) \
        == Try(ZeroDivisionError('division by zero'), False)



# Generated at 2022-06-24 00:20:13.420839
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test for method map of class Try
    """
    def div(x, y):
        return x / y

    def add2(x):
        return x + 2

    assert Try.of(div, 1, 0).map(add2) == Try(ZeroDivisionError(), False)
    assert Try.of(div, 1, 2).map(add2) == Try(1.5, True)


# Generated at 2022-06-24 00:20:21.441369
# Unit test for constructor of class Try
def test_Try():
    assert Try(123, True) == Try(123, True)
    assert Try(123, False) == Try(123, False)
    assert Try('abc', True) == Try('abc', True)
    assert Try('abc', False) == Try('abc', False)
    assert Try(123, True) != Try(123, False)
    assert Try(123, False) != Try(124, False)
    assert Try(123, True) != Try(124, True)



# Generated at 2022-06-24 00:20:26.490652
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(12, True).get_or_else(0) == 12
    assert Try(12, False).get_or_else(0) == 0
    assert Try('12', True).get_or_else(0) == '12'
    assert Try('12', False).get_or_else(0) == 0
    assert Try(True, True).get_or_else(False) == True
    assert Try(True, False).get_or_else(False) == False
    assert Try([1, 2], True).get_or_else([0]) == [1, 2]
    assert Try([1, 2], False).get_or_else([0]) == [0]
    assert Try({'a': 1}, True).get_or_else({'b': 2}) == {'a': 1}

# Generated at 2022-06-24 00:20:31.055338
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test on_fail method of Try class.
    """
    message = 'hello world!'
    try_value = Try(None, False)
    try_fail_value = Try(Exception('test'), False)
    assert try_value.on_fail(lambda e: assert_that(message, is_('hello world!'))) == try_value
    assert try_fail_value.on_fail(lambda e: assert_that(message, is_('hello world!'))) == try_fail_value



# Generated at 2022-06-24 00:20:35.543850
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # When monad is successfully
    assert Try(1, True).get_or_else(10) == 1
    # When monad is not successfully
    assert Try("Ex", False).get_or_else(10) == 10


# Generated at 2022-06-24 00:20:41.513343
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(None, False) == Try(None, False)

    assert Try(1, True) != Try(1, False)
    assert Try(None, False) != Try(1, False)


# Generated at 2022-06-24 00:20:43.357038
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(2, True) == Try(2, True)
    assert Try(2, True) is not Try(2, True)



# Generated at 2022-06-24 00:20:47.786519
# Unit test for method __str__ of class Try
def test_Try___str__():
    my_try = Try(1, True)
    assert str(my_try) == "Try[value=1, is_success=True]"
    my_try = Try(1, False)
    assert str(my_try) == "Try[value=1, is_success=False]"



# Generated at 2022-06-24 00:20:53.076621
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, True) == Try(None, True)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:20:54.874215
# Unit test for method get of class Try
def test_Try_get():
    assert Try('ok', True).get() == 'ok'
    assert Try('fail', False).get() == 'fail'


# Generated at 2022-06-24 00:20:59.458352
# Unit test for method map of class Try
def test_Try_map():
    def add_one(a):
        return a + 1

    assert Try(10, True).map(add_one) == Try(11, True)
    assert Try(None, False).map(add_one) == Try(None, False)


# Generated at 2022-06-24 00:21:02.681120
# Unit test for method __str__ of class Try
def test_Try___str__():
    value = 1
    try_ = Try(value, True)
    assert str(try_) == "Try[value=1, is_success=True]"


# Generated at 2022-06-24 00:21:11.551865
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(x): return x % 2 == 0

    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(2, True).filter(is_even).get() == 2
    assert Try(2, True).filter(is_even).get_or_else(0) == 2

    assert Try(1, True).filter(is_even) == Try(1, False)
    assert Try(1, True).filter(is_even).get() == 1
    assert Try(1, True).filter(is_even).get_or_else(0) == 0

    assert Try(1, False).filter(is_even) == Try(1, False)
    assert Try(1, False).filter(is_even).get() == 1

# Generated at 2022-06-24 00:21:14.935731
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    e = Exception('Excepton test')
    assert Try.of(lambda: 1,0)\
        .on_fail(lambda x: print(x, flush=True))\
        .on_success(lambda x: print(x, flush=True)) == Try(1, True)
    assert Try.of(lambda: 1/0)\
        .on_fail(lambda x: print(x, flush=True))\
        .on_success(lambda x: print(x, flush=True)) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:21:16.852195
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)



# Generated at 2022-06-24 00:21:24.512080
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: x + 1).get() == 2
    assert Try(1, False).on_success(lambda x: x + 1).get() == 1
    assert Try(1, True).on_success(lambda x: x + 1).on_fail(lambda x: x + 1).get() == 2
    assert Try(1, False).on_success(lambda x: x + 1).on_fail(lambda x: x + 1).get() == 2



# Generated at 2022-06-24 00:21:28.579100
# Unit test for method get of class Try
def test_Try_get():
    assert Try(0, True).get() == 0
    assert Try(0, False).get() is 0


# Generated at 2022-06-24 00:21:33.679334
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def func_with_exception():
        raise Exception('exception in func')

    value = 'No exception'
    Try.of(func_with_exception).on_fail(
        lambda exception: test.assert_equals(exception.args[0], value))

if __name__ == '__main__':
    test = Test('Try test')
    test.run_test(test_Try_on_fail)

# Generated at 2022-06-24 00:21:35.486756
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 5, ()).get_or_else(4) == 5
    assert Try.of(lambda: 5 / 0, ()).get_or_else(4) == 4


# Generated at 2022-06-24 00:21:41.989004
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    error = Exception('error 1')

    def fail_callback(value):
        nonlocal error
        error = value

    t = Try(None, False)
    t.on_fail(fail_callback)

    assert error.args[0] == 'error 1'



# Generated at 2022-06-24 00:21:47.907168
# Unit test for method bind of class Try
def test_Try_bind():
    def test_return_value(param):
        return Try(param + 10, True)
    assert Try(10, True).bind(test_return_value) == Try(20, True)
    try:
        assert Try(10, True).bind(lambda p: 1000 / p) == Try(100, True)
        assert False
    except ZeroDivisionError as e:
        assert Try(e, False) == Try(e, False)
    assert Try(10, False).bind(test_return_value) == Try(10, False)


# Generated at 2022-06-24 00:21:54.709230
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    unit_1 = Try(1, False)
    unit_2 = Try(1, True)
    unit_3 = Try(1, False)
    success_1 = Try(2, True)
    success_2 = Try(2, True)
    success_3 = Try(3, True)

    assert unit_1 == unit_1
    assert unit_2 == unit_2
    assert success_1 == success_1

    assert unit_1 != success_1
    assert success_1 != unit_1

    assert unit_1 == unit_3
    assert success_1 == success_2
    assert success_1 != success_3
    assert success_2 != success_3



# Generated at 2022-06-24 00:21:57.736185
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:22:02.392754
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(123, True) == Try(123, True)
    assert not Try(123, True) == Try(123, False)
    assert not Try(123, True) == Try(321, True)
    assert not Try(123, True) == Try(321, False)
    assert not Try(123, True) == Try('123', True)



# Generated at 2022-06-24 00:22:11.496464
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'abc'

    with pytest.raises(AssertionError):
        Try.of(lambda: 3).filter(filterer) == Try.of(lambda: 3)
    assert Try.of(lambda: 'abc').filter(filterer).get() == 'abc'
    assert Try.of(lambda: 'ab').filter(filterer) == Try.of(lambda: 'ab', is_success=False)
    assert Try.of(lambda: 'ab', is_success=False).filter(filterer) == Try.of(lambda: 'ab', is_success=False)



# Generated at 2022-06-24 00:22:12.557745
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x: x, 1).get() == 1
    assert Try.of(lambda: raise_exception(), 1).get() == TypeError


# Generated at 2022-06-24 00:22:15.778152
# Unit test for constructor of class Try
def test_Try():
    assert Try(5, True) == Try(5, True)
    assert Try(5, True).is_success is True
    assert Try(5, False).is_success is False
    assert Try(5, False).value == 5
    assert Try(5, True).value == 5

# Generated at 2022-06-24 00:22:22.878541
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(1, False).get_or_else(1) == 1
    assert Try(1, True).get_or_else(2) == 1

    # assertions used for information about unit test.
    assert not Try(1, False).get_or_else(1) == 0
    assert not Try(1, True).get_or_else(2) == 0


# Generated at 2022-06-24 00:22:30.919712
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try.of(lambda x: x, 1) == Try.of(lambda x: x, 1)
    assert Try.of(lambda x: x, 1) == Try.of(lambda x: x, 1)
    assert Try.of(lambda x: x, 1) == Try.of(lambda x: x, 1)
    assert Try.of(lambda x: x, 2) == Try.of(lambda x: x, 2)
    assert Try.of(lambda x: x, 1) != Try.of(lambda x: x, 2)
    assert not Try.of(lambda x: x, 1).is_success
    assert Try.of(lambda x: x, 1) != Try.of(lambda x: x, 1).filter(lambda x: x == 1)

# Generated at 2022-06-24 00:22:36.317523
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:22:43.037942
# Unit test for method on_success of class Try
def test_Try_on_success():
    e = Exception('internal error')
    assert Try.of(lambda: 1 + 1, ()).on_success(lambda x: x) == Try(2, True)
    assert Try.of(lambda: 1 / 0, ()).on_success(lambda x: x) == Try(e, False)
    assert Try.of(lambda: 1, (1, 2, 3)).on_success(lambda x: x + 1) == Try(2, True)
    assert Try.of(lambda: 1/0, (1, 2, 3)).on_success(lambda x: x + 1) == Try(e, False)


# Generated at 2022-06-24 00:22:46.907096
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_equal = Try(1, True)
    assert Try(1, True) == try_equal

    assert not Try(1, True) == Try(1, False)
    assert not Try(1, False) == Try(2, False)


# Generated at 2022-06-24 00:22:51.901165
# Unit test for method on_fail of class Try
def test_Try_on_fail():

    # Define a dummy exception
    class DummyException(Exception):
        pass

    # Initialize a failed Try
    try_ = Try.of(divmod, 10, 0)

    # Call on_fail method with dummy exception

# Generated at 2022-06-24 00:22:57.194572
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Unit test for method on_success of Try

    :returns: None
    :rtype: None
    """

# Generated at 2022-06-24 00:23:01.117872
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(2, True) == Try(2, False)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, True) == Try(1, False)
    assert Try(Exception(), False) == Try(Exception(), False)


# Generated at 2022-06-24 00:23:03.526430
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def f(x):
        return x / 0
    def log_error(msg):
        print('error: {}'.format(msg))
    assert Try.of(f, 1).on_fail(log_error) == Try.of(f, 1)

# Generated at 2022-06-24 00:23:10.130470
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1).map(lambda x: x + 1) == Try(2, True)
    assert Try.of(lambda: 1).map(lambda x: x).map(lambda x: x + 1) == Try(2, True)
    assert Try.of(lambda: 1).map(lambda x: x).map(lambda x: x).map(lambda x: x + 1) == Try(2, True)
    assert Try.of(lambda: 1).map(None) == Try(1, True)
    assert Try.of(None) == Try(None, False)
    assert Try.of(lambda: 1 / 0).map(lambda x: x + 1) == Try(None, False)
    assert Try.of(lambda: None).map(lambda x: x + 1) == Try(None, False)

# Unit

# Generated at 2022-06-24 00:23:13.736876
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(123, True) == Try(123, True)
    assert Try(123, False) == Try(123, False)
    assert Try(123, True) == Try(321, True) == Try(123, False) == Try(321, False)


# Generated at 2022-06-24 00:23:15.959687
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 2 + 3)\
        .map(lambda x: x + 5)\
        == Try(10, True)



# Generated at 2022-06-24 00:23:21.382744
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:23:27.129797
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def t_success(x):
        raise ValueError('bad value')

    def t_fail(x):
        return x

    def success_callback(x):
        assert False

    def fail_callback(x):
        assert True

    Try.of(t_success, 1).on_fail(fail_callback)
    Try.of(t_fail, 1).on_fail(fail_callback)
    # should raise ValueError exception
    Try.of(t_success, 1).on_fail(fail_callback).get()


# Generated at 2022-06-24 00:23:31.473458
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 2 + 2, []).bind(lambda x: Try(x * 3, True)) == Try(12, True)
    assert Try.of(lambda: 3 / 0, []).bind(lambda x: Try(x * 4, True)) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:23:38.942947
# Unit test for method __str__ of class Try
def test_Try___str__():
    expected = 'Try[value={}, is_success={}]'.format(5, True)
    actual = str(Try(5, True))
    assert expected == actual

    expected = 'Try[value={}, is_success={}]'.format(5, False)
    actual = str(Try(5, False))
    assert expected == actual

    expected = 'Try[value={}, is_success={}]'.format('exception', False)
    actual = str(Try('exception', False))
    assert expected == actual


# Generated at 2022-06-24 00:23:41.527025
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert(Try(1, True).get_or_else(2) == 1)
    assert(Try(1, False).get_or_else(2) == 2)


# Generated at 2022-06-24 00:23:47.815950
# Unit test for method map of class Try
def test_Try_map():
    # We have a monad Try with True value
    try_success = Try(True, True)
    try_success.map(lambda x: x is True)
    # We have a monad Try with False value
    try_failure = Try(False, False)
    try_failure.map(lambda x: x is True)
    # We create a monad Try with exception in try-catch
    try_exception = Try.of(lambda: 1/0)
    try_exception.map(lambda x: x is True)
    # We create a monad Try without exception in try-catch
    try_normal = Try.of(lambda: 1/1)
    try_normal.map(lambda x: x is True)


# Generated at 2022-06-24 00:23:54.409958
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)



# Generated at 2022-06-24 00:23:57.120806
# Unit test for constructor of class Try
def test_Try():
    true_case = Try(1, True)
    assert true_case == Try(1, True)
    false_case = Try(1, False)
    assert false_case == Try(1, False)
    assert true_case != false_case
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)


# Generated at 2022-06-24 00:24:04.400429
# Unit test for method on_fail of class Try

# Generated at 2022-06-24 00:24:11.266105
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_true = Try(1, True)
    assert str(try_true) == 'Try[value=1, is_success=True]'
    try_false = Try(1, False)
    assert str(try_false) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-24 00:24:18.484713
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert(Try(1, True).on_success(print) == Try(1, True))
    assert(Try(1, True).on_success(print).value == 1)
    def callback(value):
        assert value == 1
    Try(1, True).on_success(callback)


# Generated at 2022-06-24 00:24:22.418768
# Unit test for constructor of class Try
def test_Try():
    """
    Test __init__ method of Try class

    :returns: Nothing
    :rtype: None
    """
    result = Try('foo', True)
    assert result.value == 'foo'
    assert result.is_success == True


# Generated at 2022-06-24 00:24:31.906353
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1).bind(lambda x: Try.of(lambda: x + 1)).get() == 2
    assert Try.of(lambda: 1).bind(lambda x: Try.of(lambda: x + 1)).is_success == True
    assert Try.of(lambda: 1).bind(lambda x: Try.of(lambda: x + 1)).get_or_else(0) == 2

    assert Try.of(lambda: 1).bind(lambda x: Try.of(lambda: 1 / 0)).is_success == False
    assert Try.of(lambda: 1).bind(lambda x: Try.of(lambda: 1 / 0)).get_or_else(0) == 0

# Generated at 2022-06-24 00:24:37.031669
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    t1 = Try.of(lambda: 1, None)
    t2 = Try.of(lambda: 1, None)
    assert t1 == t2
    t3 = Try.of(lambda: 1, None)
    t4 = Try.of(lambda: 2, None)
    assert t3 != t4
# /Unit test for method __eq__ of class Try


# Generated at 2022-06-24 00:24:38.168634
# Unit test for constructor of class Try
def test_Try():
    assert True is Try(None, True)
    assert False is Try(None, False)

# Generated at 2022-06-24 00:24:41.677077
# Unit test for method map of class Try
def test_Try_map():
    def add(x):
        return x + 1

    def get_try():
        return Try.of(add, 1)

    assert get_try().map(add) == Try(add(add(1)), True)


# Generated at 2022-06-24 00:24:49.537668
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    assert Try(10, True).map(lambda x: x + 10) == Try(20, True)
    assert Try(10, True).map(lambda x: x).map(lambda x: x + 10) == Try(20, True)
    assert Try(10, True).map(lambda x: x).map(lambda x: x).map(lambda x: x + 10) == Try(20, True)
    assert Try(10, False).map(lambda x: x + 10) == Try(10, False)


# Generated at 2022-06-24 00:24:59.047563
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    # when
    try_1 = Try(1, True)
    try_2 = Try(1, True)
    try_3 = Try(2, True)
    try_4 = Try(1, False)
    try_5 = Try(2, False)
    try_6 = Try(1, True)
    try_7 = Try(2, True)
    try_8 = Try(1, False)
    try_9 = Try(2, False)

    # then
    assert try_1 == try_2
    assert try_1 != try_3
    assert try_1 != try_4
    assert try_1 != try_5
    assert try_1 == try_6
    assert try_1 != try_7
    assert try_1 != try_8

# Generated at 2022-06-24 00:25:04.659989
# Unit test for constructor of class Try
def test_Try():
    try_instance = Try('success', True)
    assert try_instance == Try('success', True)
    assert try_instance != Try('fail', False)

    try_instance = Try('fail', False)
    assert try_instance == Try('fail', False)
    assert try_instance != Try('success', True)


# Generated at 2022-06-24 00:25:12.584279
# Unit test for method bind of class Try
def test_Try_bind():

    def add_exception(*args):
        return 1 / 0

    def add_2(x):
        return x + 2

    def do_bind():
        return add_exception()

    try_5 = Try(5, True)

    try_add_exception = Try.of(add_exception)
    try_add_2 = Try.of(add_2)
    try_do_bind = Try.of(do_bind)

    assert try_do_bind.bind(try_add_exception).is_success == False, "Try with bind don't catch exception"
    assert try_5.bind(try_do_bind).is_success == False, "Try with bind don't catch exception"
    assert try_5.bind(try_add_2).is_success == True, "Try with bind can't bind"

# Generated at 2022-06-24 00:25:19.316353
# Unit test for method on_fail of class Try
def test_Try_on_fail():

    def _throws():
        raise ValueError()

    result = Try.of(_throws)\
        .on_fail(lambda e: print(e))\
        .on_success(lambda x: print(x))\
        .filter(lambda x: False)\
        .get()

    assert_that(result) \
        .is_instance_of(ValueError)



# Generated at 2022-06-24 00:25:24.088772
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda v: v + 1) == Try(1, True)
    assert Try(1, False).on_success(lambda v: v + 1) == Try(1, False)



# Generated at 2022-06-24 00:25:30.772527
# Unit test for method bind of class Try
def test_Try_bind():
    mock = Mock()
    mock()  # Should call once
    Try.of(lambda: 2).bind(lambda x: mock())
    mock.assert_called_once()

    mock = Mock()
    mock()  # Should call once
    Try.of(lambda: 0).bind(lambda x: mock())
    mock.assert_called_once()

    mock = Mock()
    mock()  # Should call once
    Try.of(lambda: raise_error()).bind(lambda x: mock())
    assert not mock.called



# Generated at 2022-06-24 00:25:35.226227
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1



# Generated at 2022-06-24 00:25:38.569176
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(True, True) == Try(True, True)
    assert Try(False, True) == Try(False, True)
    assert Try(False, False) == Try(Exception('Error'), False)
    assert Try(True, False) != Try(False, False)
    assert Try(False, True) != Try(True, False)



# Generated at 2022-06-24 00:25:42.871942
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    @Try.of
    def test():
        return 2 / 0

    assert test.on_fail(lambda err: None) == Try(ZeroDivisionError(), False)

    @Try.of
    def test2():
        return 1 + 2

    assert test2.on_fail(lambda err: None) == Try(3, True)


# Generated at 2022-06-24 00:25:45.574864
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('test', True)) == 'Try[value=test, is_success=True]'
    assert str(Try('test', False)) == 'Try[value=test, is_success=False]'


# Generated at 2022-06-24 00:25:48.341371
# Unit test for method map of class Try
def test_Try_map():
    def add_one(x):
        return x + 1
    result = Try.of(int, '1').map(lambda x: add_one(x))
    assert result == Try(2, True)


# Generated at 2022-06-24 00:25:54.549711
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(message):
        return message == "Hello"

    assert Try("Hello", True).filter(filterer) == Try("Hello", True)
    assert Try("not", True).filter(filterer) == Try("not", False)
    assert Try("Hello", False).filter(filterer) == Try("Hello", False)
    assert Try("not", False).filter(filterer) == Try("not", False)


# Generated at 2022-06-24 00:25:59.366625
# Unit test for method filter of class Try
def test_Try_filter():
    # Case to test Try.filter
    def case_to_test():
        if True:
            return Try(1, True)
        else:
            return Try(0, False)

    # Unit test assert
    assert case_to_test().filter(lambda x: x == 1).get() == 1
    assert case_to_test().filter(lambda x: x == 2).get() == 0

# Generated at 2022-06-24 00:26:00.281460
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    pass


# Generated at 2022-06-24 00:26:11.544781
# Unit test for method filter of class Try
def test_Try_filter():
    no_error = Try(True, True)
    error = Try(Exception('Test Exception'), False)
    error_filtered_by_true = Try(Exception('Test Exception'), False)
    error_filtered_by_false = Try(Exception('Test Exception'), False)

    assert no_error.filter(lambda x: True).get() == True
    assert no_error.filter(lambda x: False).is_success == False

    assert error.filter(lambda x: True).is_success == False
    assert error.filter(lambda x: False).is_success == False

    assert error_filtered_by_true.filter(lambda x: True) == error_filtered_by_true
    assert error_filtered_by_false.filter(lambda x: False) == error_filtered_by_false


# Generated at 2022-06-24 00:26:13.171883
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    assert Try(10, False).get() == 10


# Generated at 2022-06-24 00:26:18.183112
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda x: x + 1, 1).on_success(lambda x: print(x)) == Try(2, True)


# Generated at 2022-06-24 00:26:23.218668
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def raise_exception():
        raise Exception('bla')

    x = Try.of(raise_exception)
    x.on_fail(lambda e: print('{}'.format(e)))
    assert not x.is_success
    assert x.value == 'bla'

    y = Try.of(lambda a: a, 'a')
    y.on_fail(lambda e: print('{}'.format(e)))
    assert y.is_success
    assert y.value == 'a'


# Generated at 2022-06-24 00:26:26.354130
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:26:32.137363
# Unit test for method on_success of class Try
def test_Try_on_success():
    class TestClass:
        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    import pytest
    test = TestClass()
    test_try = Try(1, True)
    result = test_try.on_success(lambda x: test.inc())

    assert result == test_try
    assert test.value == 1


# Generated at 2022-06-24 00:26:39.722620
# Unit test for method __eq__ of class Try
def test_Try___eq__():

    class A:
        def __init__(self, a):
            self.a = a

        def __eq__(self, other):
            return isinstance(other, type(self)) and self.a == other.a

        def __repr__(self):
            return 'A[a={}]'.format(self.a)

    a1 = A('a1')
    a2 = A('a2')
    assert a1 == a1
    assert not a1 == a2
    assert not a1 == 1

    try1 = Try(a1, True)
    assert try1 == try1
    try2 = Try(a1, False)
    assert try1 != try2



# Generated at 2022-06-24 00:26:41.824913
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(2, True).get() == 2
    assert Try(1, False).get() == 1
    assert Try(2, False).get() == 2


# Generated at 2022-06-24 00:26:44.715537
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1, 0).get_or_else(0) == 1
    assert Try.of(lambda: 1 / 0, 0).get_or_else(0) == 0


# Generated at 2022-06-24 00:26:51.191952
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) != Try(2, True)


# Generated at 2022-06-24 00:26:54.683507
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(0, False)
    assert Try(TypeError, False) != Try(0, False)


# Generated at 2022-06-24 00:26:58.959324
# Unit test for method bind of class Try
def test_Try_bind():
    def by_two(x):
        return Try(x * 2, True)

    assert Try(10, True).bind(by_two) == Try(20, True)
    assert Try(10, False).bind(by_two) == Try(10, False)



# Generated at 2022-06-24 00:27:05.236340
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'value'

    def fail_filterer(value):
        return False

    try:
        assert Try.of(lambda: 'value', None).filter(filterer) == Try('value', True)
    except:
        assert False

    try:
        assert Try.of(lambda: 'value', None).filter(filterer) != Try('value', False)
    except:
        assert False

    try:
        assert Try.of(lambda: 'value', None).filter(fail_filterer) == Try('value', False)
    except:
        assert False

    try:
        assert Try.of(lambda: 'value', None).filter(fail_filterer) != Try('value', True)
    except:
        assert False


# Generated at 2022-06-24 00:27:07.148890
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(exception(), False).get() == exception()


# Generated at 2022-06-24 00:27:14.807575
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def mapper(x):
        return x + 1

    # result of Try[A].map(Function(A) -> B) when value is successful
    assert Try(mapper(1), True) == Try(1, True).map(mapper)

    def not_successful():
        raise ValueError('This is error.')

    # result of Try[A].map(Function(A) -> B) when value is not successful
    assert Try(not_successful(), False) == Try.of(not_successful).map(mapper)


# Generated at 2022-06-24 00:27:18.749948
# Unit test for constructor of class Try
def test_Try():
    assert isinstance(Try(1, True), Try)



# Generated at 2022-06-24 00:27:21.274323
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try.of(lambda a: a, 1) == Try(1, True)
    assert Try.of(lambda a: a, 1) != Try(1, False)
    assert Try(1, True) != Try(1, False)


# Generated at 2022-06-24 00:27:26.060037
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(10) == 1
    assert Try(1, False).get_or_else(10) == 10
    assert Try(1, True).filter(lambda v: v % 2 == 0).get_or_else(10) == 10


# Generated at 2022-06-24 00:27:28.416684
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(float, '1.0').get() == 1.0


# Generated at 2022-06-24 00:27:33.447585
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(8, True).filter(lambda x: x % 2 == 0) == Try(8, True)
    assert Try(8, True).filter(lambda x: x % 2 != 0) == Try(8, False)
    assert Try(7, True).filter(lambda x: x % 2 == 0) == Try(7, False)
    assert Try(7, True).filter(lambda x: x % 2 != 0) == Try(7, True)



# Generated at 2022-06-24 00:27:39.328204
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(True, True).on_success(lambda _: True) == Try(True, True)
    assert Try(False, False).on_success(lambda _: True) == Try(False, False)

    def foo(value):
        assert value == True

    Try(True, True).on_success(foo)


# Generated at 2022-06-24 00:27:40.844627
# Unit test for method get of class Try
def test_Try_get():
    monad = Try('4', True)
    assert monad.get() == '4'


# Generated at 2022-06-24 00:27:50.253038
# Unit test for method map of class Try
def test_Try_map():
    # 1. Simple usage
    assert Try.of(lambda x: x ** 2, 4) == Try(16, True)
    assert Try.of(lambda x: x ** 2, 4).map(lambda x: x + 1) == Try(17, True)
    assert Try.of(lambda x: x ** 2, 4).map(lambda x: x - 1) == Try(15, True)
    assert Try.of(lambda x: x ** 2, 4).map(lambda x: x / 1) == Try(16, True)
    assert Try.of(lambda x: x ** 2, 4).map(lambda x: x * 1) == Try(16, True)

    # 2. When called function raise exception, and map not return correct result.

# Generated at 2022-06-24 00:27:54.783481
# Unit test for constructor of class Try
def test_Try():
    """Unit test for constructor of class Try"""
    assert Try('sharik', True) == Try('sharik', True)
    assert Try(Exception, False) == Try(Exception, False)


# Generated at 2022-06-24 00:27:57.315458
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """"""
    t_e = Try(Exception('Fail'), False)
    t_e.on_fail(print)
    assert t_e.value == Exception('Fail')

# Generated at 2022-06-24 00:28:04.747917
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try("value", True).on_success(lambda _: None) == Try("value", True)
    assert Try("value", False).on_success(lambda _: None) == Try("value", False)

# Generated at 2022-06-24 00:28:13.531326
# Unit test for method map of class Try
def test_Try_map():
    def add_one(number):
        return number + 1

    def add_one_with_exception(number):
        if number == 1:
            raise Exception('Something wrong')
        return number + 1

    assert Try.of(add_one, 1).map(add_one) == Try(2, True)
    assert Try.of(add_one_with_exception, 1).map(add_one) == Try(Exception('Something wrong'), False)
    assert Try.of(add_one_with_exception, 2).map(add_one) == Try(3, True)



# Generated at 2022-06-24 00:28:21.196803
# Unit test for constructor of class Try
def test_Try():
    # Successfully Try
    assert Try(1, True) == Try(1, True)
    # Not successfully Try
    assert Try(1, False) == Try(1, False)
    # Unit and not unit successfully Try
    assert not Try(1, True) == Try(2, True)
    # Unit and not unit not successfully Try
    assert not Try(1, False) == Try(2, False)
    # Not the same type
    assert not Try(1, True) == 1


# Generated at 2022-06-24 00:28:28.828615
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    from uuid import uuid4

    def raise_exception():
        raise Exception()

    exc = Exception()
    exc_str = uuid4()

    def success_callback(value):  # pragma: no cover
        assert False

    def fail_callback(value):
        assert isinstance(value, Exception)
        assert value.__str__() == exc_str

    # when some exception
    Try.of(lambda: raise_exception()).on_fail(fail_callback)

    # when reuse same exception

# Generated at 2022-06-24 00:28:34.371181
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():

    def __test_get_or_else__(try_value, expected_value, is_success):
        assert try_value.get_or_else(True) == expected_value
        assert try_value.is_success == is_success

    test_value = 1

    __test_get_or_else__(Try(test_value, True), test_value, True)
    __test_get_or_else__(Try(test_value, False), True, False)

    print('Try.get_or_else: ok')



# Generated at 2022-06-24 00:28:38.074495
# Unit test for method on_success of class Try
def test_Try_on_success():
    def stub():
        pass
    assert Try.of(lambda: 1).on_success(stub) == Try(1, True)
    assert Try.of(lambda: raise_exception()).on_success(stub) == Try(Exception(), False)


# Generated at 2022-06-24 00:28:41.008961
# Unit test for method on_success of class Try
def test_Try_on_success():
    def callback(value):
        assert value == 'value'
    res = Try('value', True).on_success(callback)
    assert res == Try('value', True)



# Generated at 2022-06-24 00:28:46.960488
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try('test', True).on_fail(lambda v: (v * 2)).value == 'test'
    assert not Try('test', False).on_fail(lambda v: (v * 2)).is_success
    assert Try('test', False).on_fail(lambda v: (v * 2)).value == 'testtest'

