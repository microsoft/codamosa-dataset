

# Generated at 2022-06-24 00:18:51.361978
# Unit test for method map of class Try
def test_Try_map():
    try_one = Try(1, True)
    try_one_actual = try_one.map(lambda v: v * 2)
    try_one_expected = Try(2, True)

    try_two = Try(None, False)
    try_two_actual = try_two.map(lambda v: v * 2)
    try_two_expected = Try(None, False)

    assert try_one_actual == try_one_expected
    assert try_two_actual == try_two_expected



# Generated at 2022-06-24 00:18:53.873804
# Unit test for constructor of class Try
def test_Try():
    """
    >>> test_Try()
    True
    """
    try_ = Try(1, True)
    _try = Try(1, True)

    assert try_ == _try



# Generated at 2022-06-24 00:18:59.196968
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == Try(1, True).get()
    assert Try(1, False).get() == Try(1, False).get()
    assert Try(1, True).get() != Try(1, False).get()


# Generated at 2022-06-24 00:19:01.986063
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(2, True) == Try(2, True)
    assert Try(2, False) == Try(2, False)
    assert Try(2, False) != Try(2, True)
    assert Try(2, True) != Try(3, True)
    assert Try(2, True) != Try(3, False)


# Generated at 2022-06-24 00:19:08.213880
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert 'Try[value=5, is_success=True]' == str(Try.of(lambda: 5, None))  # pragma: no cover
    assert 'Try[value=<__main__.TestException instance at 0x7f1491a2f8c0>, is_success=False]' == str(Try.of(lambda: raise_TestException(), None))  # pragma: no cover


# Generated at 2022-06-24 00:19:12.582672
# Unit test for method bind of class Try
def test_Try_bind():
    def fn(a, b):
        return a + b

    # test bind with success Try
    def test_bind_success():
        try_success = Try.of(lambda: fn(2, 3))
        assert try_success.bind(lambda x: Try(x ** 2, True)) == Try(25, True)

    # test bind with fail Try
    def test_bind_fail():
        try_fail = Try.of(lambda: fn(2, 'a'))
        assert try_fail.bind(lambda x: Try(x ** 2, True)) == try_fail

    test_bind_success()
    test_bind_fail()



# Generated at 2022-06-24 00:19:17.467677
# Unit test for method filter of class Try
def test_Try_filter():
    def fn(a):
        return a + 5

    def filterer(a):
        return a > 10

    def fail_filterer(a):
        return a < 10

    assert Try(10, True).filter(filterer).get() == 15
    assert Try(10, True).filter(fail_filterer).is_success is False


# Generated at 2022-06-24 00:19:23.229664
# Unit test for method on_success of class Try
def test_Try_on_success():
    # when success
    even = lambda a: a % 2 == 0
    result = Try.of(even, 4).on_success(lambda a: print(a))
    assert result.is_success
    assert result.__eq__(Try(True, True))
    # when fail
    result = Try.of(even, 5).on_success(lambda a: print(a))
    assert not result.is_success
    assert result.__eq__(Try(False, False))


# Generated at 2022-06-24 00:19:26.424409
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try(1, True).__str__() == 'Try[value=1, is_success=True]'
    assert Try(1, False).__str__() == 'Try[value=1, is_success=False]'



# Generated at 2022-06-24 00:19:32.797065
# Unit test for constructor of class Try
def test_Try():
    def success(val):
        return val

    try_val = Try.of(success, 5)
    assert try_val.is_success
    assert try_val.value == 5
    assert try_val.get() == 5

    def fail():
        raise Exception('fail')

    try_val = Try.of(fail)
    assert not try_val.is_success

    try_val = Try.of(fail, 5)
    assert not try_val.is_success


# Generated at 2022-06-24 00:19:35.848677
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """Test for method get_or_else of class Try"""
    # arrange
    result = Try(2, True)
    expected = 2
    # act
    actual = result.get_or_else(0)
    # assert
    assert actual == expected, 'Expected value is {}, actual {}'.format(expected, actual)


# Generated at 2022-06-24 00:19:39.549561
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)



# Generated at 2022-06-24 00:19:41.554238
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1, ()) == Try(1, True)
    assert Try.of(lambda: 1, ()).get() == 1



# Generated at 2022-06-24 00:19:48.183025
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    @Try.of
    def add(a, b):
        return a + b
    try_one = add(1, 2)
    result = try_one.on_success(lambda v: add(v, 1))
    assert result == Try(4, True)

    try_one = Try(1, True)
    result = try_one.on_success(lambda v: v + 1)
    assert result == Try(1, True)


# Generated at 2022-06-24 00:19:55.349568
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test for method bind of class Try.

    :returns: 0 if all test passed, 1 if test failed
    :rtype: int
    """
    unit_test_result = 0

# Generated at 2022-06-24 00:20:01.622839
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_1 = Try(1, True)
    assert try_1.get_or_else(0) == 1
    assert try_1.get_or_else(2) == 1

    try_2 = Try(1, False)
    assert try_2.get_or_else(0) == 0
    assert try_2.get_or_else(2) == 2


# Generated at 2022-06-24 00:20:08.752993
# Unit test for method bind of class Try
def test_Try_bind():
    def func_to_bind(a):
        return Try.of(lambda: a, a)
    assert Try.of(lambda: None, None).bind(func_to_bind) == Try(None, True)
    assert Try.of(lambda: None, None).bind(lambda _: Try(1, False)) == Try(1, False)


# Generated at 2022-06-24 00:20:17.014484
# Unit test for method bind of class Try

# Generated at 2022-06-24 00:20:24.565467
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-24 00:20:29.605814
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)



# Generated at 2022-06-24 00:20:35.882796
# Unit test for method get of class Try
def test_Try_get():
    load = Try.of(json.loads, '{"a": 1, "b": 2}')
    assert load.get() == {'a': 1, 'b': 2}

    not_load = Try.of(json.loads, '{"a": 1, "b": 2;')
    assert not_load.get() is not None


# Generated at 2022-06-24 00:20:44.063792
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try
    """
    def function_never_raise(arg) -> int:
        return arg

    def function_always_raise(arg) -> int:
        raise Exception('always raise')

    try1 = Try.of(function_never_raise, 1)
    try2 = Try.of(function_always_raise, 1)

    assert try1.get_or_else(100) == 1
    assert try2.get_or_else(100) == 100


# Generated at 2022-06-24 00:20:47.209014
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda x: x * 2, 3).get_or_else('default') == 6
    assert Try.of(lambda x: x * 2, None).get_or_else('default') == 'default'


# Generated at 2022-06-24 00:20:50.366825
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True)\
        .map(lambda x: x + 1)\
        == Try(2, True)

    assert Try(Exception('error'), False)\
        .map(lambda x: x + 1)\
        == Try(Exception('error'), False)


# Generated at 2022-06-24 00:20:52.140196
# Unit test for method on_success of class Try
def test_Try_on_success():
    # GIVEN
    value = 0
    result = ''

    # WHEN
    Try.of(lambda x: x / 0, value).on_success(lambda x: result.join(str(x)))

    # THEN
    assert result == ''



# Generated at 2022-06-24 00:20:57.090070
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Test for method __str__ of class Try

    :returns: True when is successfully, othercase raise AssertionError
    :rtype: Boolean
    """
    for value in [1, 'using string', {'using': 'dictionary'}]:
        assert str(Try(value, True)) == "Try[value={}, is_success={}]".format(value, True)
        assert str(Try(value, False)) == "Try[value={}, is_success={}]".format(value, False)
    return True


# Generated at 2022-06-24 00:21:02.019154
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def run_filterer(value: int) -> bool:
        return value == 5
    assert Try(5, True).filter(run_filterer) == Try(5, True)
    assert Try(4, True).filter(run_filterer) == Try(4, False)
    assert Try(4, False).filter(run_filterer) == Try(4, False)


# Generated at 2022-06-24 00:21:06.655197
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def callback(e):
        raise Exception('Test exception')
    assert Try(123, True).on_success(callback) == Try(123, True)

# Generated at 2022-06-24 00:21:09.305131
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 1).on_success(lambda x: x + 1).get() == 2
    assert Try.of(lambda: 0 / 1).on_success(lambda x: x + 1).get().__class__.__name__ == 'ZeroDivisionError'


# Generated at 2022-06-24 00:21:12.288135
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        raise Exception('exception')
    except:
        try_ = Try.of(int, 'str')
        try_.on_fail(lambda e: print('Exception: {}'.format(e)))


# Generated at 2022-06-24 00:21:24.373263
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Try___eq__:
    Let's test Try == Try method.

    Given
    - first Try is Success
    - second Try is Success
    - third Try is Failure

    When
    - we compare first and second Try
    - we compare first and third Try
    - we compare first and error

    Then
    - first and second Try is the same
    - first and third Try is the same
    - first and error is not the same
    """
    # given
    first_try = Try(1, True)
    second_try = Try(1, True)
    third_try = Try(1, False)
    # when
    first_and_second_is_the_same = first_try == second_try
    first_and_third_is_the_same = first_try == third_try
    first_and

# Generated at 2022-06-24 00:21:36.579467
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda x: x, 1).map(lambda x: x + 2) == Try(3, True)
    assert Try.of(lambda x: x, 1).map(lambda x: x + 2) != Try(2, True)
    assert Try.of(lambda x: x, 1).map(lambda x: x + 2) != Try(3, False)
    assert Try.of(lambda x: x, 1).map(lambda x: x + 2) != Try(2, False)

    assert Try.of(lambda x: x, 1).map(lambda x: x + 2) != 1
    assert Try.of(lambda x: x, 1).map(lambda x: x + 2) != True
    assert Try.of(lambda x: x, 1).map(lambda x: x + 2) != None

# Unit test

# Generated at 2022-06-24 00:21:39.383740
# Unit test for constructor of class Try
def test_Try():
    # When call constructor of class Try with non-exception value, Try should return monad
    # with value and True for success
    assert Try(1, True) == Try(1, True)

    # When call constructor of class Try with exception, Try should return monad
    # with exception and False for success
    assert Try(ValueError('value error'), False) == Try(ValueError('value error'), False)



# Generated at 2022-06-24 00:21:41.211240
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try('foo', True).on_success(lambda x: x+'bar') == Try('foobar', True)
    assert Try('foo', False).on_success(lambda x: x+'bar') == Try('foo', False)


# Generated at 2022-06-24 00:21:43.834584
# Unit test for method map of class Try
def test_Try_map():
    assert Try(2, True).map(lambda x: x ** 2) == Try(4, True)
    assert Try(2, False).map(lambda x: x ** 2) == Try(2, False)


# Generated at 2022-06-24 00:21:45.959263
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_fn(x):
        assert x == 'test'

    Try.of(lambda: 'test').on_success(test_fn)
    assert True


# Generated at 2022-06-24 00:21:52.519702
# Unit test for constructor of class Try
def test_Try():
    t = Try(2, True)
    assert t.value == 2
    assert t.is_success == True

    t = Try(3, False)
    assert t.value == 3
    assert t.is_success == False

    t = Try(2, True)
    s = Try(2, True)
    assert t == s

    t = Try(2, True)
    s = Try(3, True)
    assert t != s

    t = Try(3, False)
    s = Try(3, True)
    assert t != s


# Generated at 2022-06-24 00:22:03.447687
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def test_fn_raise_exception():
        raise Exception('test_fn_raise_exception')
        return True

    def test_fn_return_success():
        return True

    def test_fn_return_false():
        return False

    def test_fn_return_try_success():
        return Try(True, True)

    def test_fn_return_try_false():
        return Try(False, False)

    def test_fn_return_try_exception():
        return Try(Exception('test_fn_return_try_exception'), False)

    def test_fn_raise_exception_and_return_try_success():
        raise Exception('test_fn_raise_exception_and_return_try_success')
        return Try(True, True)


# Generated at 2022-06-24 00:22:07.448300
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def test_pos():
        assert Try(1, True) == Try(1, True)
        assert Try(1, False) == Try(1, False)
    test_pos()


# Generated at 2022-06-24 00:22:14.635847
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert not Try(1, True) == Try(2, True)
    assert not Try(2, True) == Try(1, False)
    assert not Try(1, True) == Try(1, False)
    assert not Try(None, False) == Try(None, True)
    assert not Try(None, False) == True
    assert not Try(None, False) == None


# Generated at 2022-06-24 00:22:21.768976
# Unit test for method filter of class Try

# Generated at 2022-06-24 00:22:25.479001
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1, ()).get() == 1


# Generated at 2022-06-24 00:22:31.294731
# Unit test for method map of class Try
def test_Try_map():
    """
    When monad value don't raise exception,
    and mapper return value with different type,
    new monad should be of the same type
    when monad value raise exception,
    and mapper return value with different type,
    new monad should be of the same type
    """
    assert Try(12.1, True).map(lambda x: x + 1) == Try(13.1, True)
    assert Try(Exception(), False).map(lambda x: x + 1) == Try(Exception(), False)



# Generated at 2022-06-24 00:22:38.544603
# Unit test for method map of class Try
def test_Try_map():
    def rai(e):
        raise e

    def check(instance: Try, expected_value: bool, expected_is_success: bool):
        assert instance.value == expected_value, 'when monad is successfully map return new Try with mapped result'
        assert instance.is_success == expected_is_success, 'when monad is not successfully map return copy of monad'

    def minus(x):
        return x-1

    ex1 = Try(rai, 1)
    check(ex1.map(minus), '1', False)

    ex2 = Try(4, True)
    check(ex2.map(minus), 3, True)

test_Try_map()



# Generated at 2022-06-24 00:22:45.145255
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(2, True)\
        .on_success(lambda x: x + 1) == Try(2, True)

    assert Try(2, False)\
        .on_success(lambda x: x + 1) == Try(2, False)

    assert Try(2, True)\
        .on_fail(lambda x: x + 1)\
        .on_success(lambda x: x + 1) == Try(2, True)

    assert Try(2, False)\
        .on_fail(lambda x: x + 1)\
        .on_success(lambda x: x + 1) == Try(3, False)



# Generated at 2022-06-24 00:22:47.054956
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    assert Try(10, False).get() == 10
    assert Try('', True).get() == ''
    assert Try('', False).get() == ''


# Generated at 2022-06-24 00:22:50.998095
# Unit test for method bind of class Try
def test_Try_bind():
    def success_binder(value):
        assert value == 1
        return Try(value + 1, True)

    def fail_binder(value):
        assert value == 1
        return Try(value + 1, False)

    assert Try.of(lambda: 1, ).bind(success_binder) == Try(2, True)
    assert Try.of(lambda: 1, ).bind(fail_binder) == Try(2, False)

# Generated at 2022-06-24 00:22:54.627661
# Unit test for method bind of class Try
def test_Try_bind():
    def func(x):
        return Try(x, True)
    assert Try(1, True).bind(func) == Try(1, True)
    assert Try(1, False).bind(func) == Try(1, False)


# Generated at 2022-06-24 00:23:02.782426
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    import unittest

    class Test(unittest.TestCase):
        def test_positive(self):
            class Sentry:
                pass

            sentry = Sentry()
            sentry.value = None
            Try.of(divmod, 10, 5)\
                .map(lambda t: t[0])\
                .on_fail(lambda e: setattr(sentry, 'value', e))
            self.assertEqual(sentry.value, None)
            self.assertRaises(ZeroDivisionError, lambda: Try.of(divmod, 10, 0)\
                                                            .map(lambda t: t[0])\
                                                            .on_fail(lambda e: setattr(sentry, 'value', e)))
            self.assertIsNotNone(sentry.value)
            self.assertIs

# Generated at 2022-06-24 00:23:08.345913
# Unit test for method map of class Try
def test_Try_map():
    def f1(x: str) -> str:
        return x + '-mapped'

    def f2(x: str) -> str:
        raise Exception()

    assert Try(5, True).map(str) == Try('5', True)
    assert Try(5, True).map(lambda x: x + 1) == Try(6, True)
    assert Try(5.0, True).map(int) == Try(5, True)
    assert Try('abc', True).map(f1) == Try('abc-mapped', True)
    assert Try('abc', True).map(f2) == Try(Exception(), False)
    assert Try(Exception(), False).map(f1) == Try(Exception(), False)



# Generated at 2022-06-24 00:23:10.372754
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:23:15.680524
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(10, True).on_fail(lambda _: print("fail")) == Try(10, True)
    assert Try(10, False).on_fail(lambda e: print("fail")) == Try(10, False)

# Generated at 2022-06-24 00:23:22.370529
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, False) == Try(None, False)
    assert Try(1, True) == Try(None, False)
    assert Try(2, True) == Try(None, False)
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)


# Generated at 2022-06-24 00:23:31.230748
# Unit test for method filter of class Try
def test_Try_filter():
    try_with_exception = Try.of(lambda: 1 / 0)
    assert try_with_exception.filter(lambda _: True) == Try(ZeroDivisionError(""), False)

    try_with_value = Try.of(lambda: 1).filter(lambda x: x == 1)\
        .bind(lambda x: Try.of(lambda: x * 2))\
        .filter(lambda x: x > 1)

    assert try_with_value == Try(2, True)

    try_with_value = Try.of(lambda: 1).filter(lambda x: False)\
        .bind(lambda x: Try.of(lambda: x * 2))\
        .filter(lambda x: x > 1)

    assert try_with_value == Try(2, False)


# Generated at 2022-06-24 00:23:36.101767
# Unit test for method filter of class Try
def test_Try_filter():
    assert_equal(Try(1, True).filter(lambda x: x > 0), Try(1, True))
    assert_equal(Try(1, True).filter(lambda x: x == 1), Try(1, True))
    assert_equal(Try(1, True).filter(lambda x: x < 0), Try(1, False))
    assert_equal(Try(1, False).filter(lambda x: x > 0), Try(1, False))



# Generated at 2022-06-24 00:23:45.503167
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    with patch('logging.Logger.error') as mock_logger:
        def stub_success(value):
            return Try(value, True)

        def stub_fail(value):
            return Try(value, False)

        def stub_on_fail(value):
            mock_logger.assert_called_once_with(value)

        def stub_on_success(value):
            mock_logger.assert_not_called()


# Generated at 2022-06-24 00:23:46.307563
# Unit test for method get of class Try
def test_Try_get():
    assert Try('5', True).get() == '5'


# Generated at 2022-06-24 00:23:52.489921
# Unit test for method bind of class Try
def test_Try_bind():

    # Function returning sum of two arguments or throwing exception
    def add(x, y):
        if x < 0 or y < 0:
            raise Exception('Can not add negative numbers.')
        return x + y

    # binder function for Try
    def binder(x):
        return Try.of(add, x, x)

    # test when Try is successfully
    def test_with_success():
        assert Try(3, True)\
            .bind(binder)\
            .get() == 6

    def test_with_failure():
        assert Try(3, False)\
            .bind(binder)\
            .get() == 3
        assert not Try(3, False)\
            .bind(binder)\
            .is_success

    test_with_success()
    test_with_failure()


# Unit test

# Generated at 2022-06-24 00:23:56.087554
# Unit test for method get of class Try
def test_Try_get():
    """
    Test method get of class Try.

    :returns: None
    """
    assert Try(1, True).get() == 1
    assert Try(2, False).get() == 2


# Generated at 2022-06-24 00:24:00.819224
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_instance_success = Try(None, True)
    try_instance_fail = Try("A", False)

    assert str(try_instance_success) == "Try[value=None, is_success=True]"
    assert str(try_instance_fail) == "Try[value=A, is_success=False]"


# Generated at 2022-06-24 00:24:07.417647
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(2, False) == Try(2, False)
    assert Try(2, False) != Try(1, False)
    assert Try(2, True) != Try(1, True)
    assert Try(1, True) != Try(2, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, False) == Try(2, True)


# Generated at 2022-06-24 00:24:10.172130
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # given
    try_instance = Try(None, False)

    # when
    try_instance.on_fail(lambda x: 1)

    # then
    assert try_instance.is_success == False
    assert try_instance.value is None


# Generated at 2022-06-24 00:24:15.061847
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(5, True) == Try(5, True)
    assert Try(5, False) == Try(5, False)
    assert Try(5, True) != Try(5, False)
    assert Try(5, False) != Try(5, True)
    assert Try(5, True) != Try(7, True)
    assert Try(5, False) != Try(7, False)
    assert Try(5, True) != Try(7, False)
    assert Try(5, False) != Try(7, True)



# Generated at 2022-06-24 00:24:19.232133
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test successfully and not successfully bind method.
    """
    assert Try(1, True).bind(lambda x: Try(x + 2, True)) == Try(3, True)
    assert Try(1, False).bind(lambda x: Try(x + 2, True)) == Try(1, False)


# Generated at 2022-06-24 00:24:24.308504
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def concat(a, b):
        return a + b
    # Success Try[10]
    assert Try.of(concat, 'a', 'b').get_or_else(0) == 'ab'
    # Failed Try[Exception]
    assert Try.of(concat, 1, 'b').get_or_else(0) == 0


# Generated at 2022-06-24 00:24:31.369742
# Unit test for method filter of class Try
def test_Try_filter():
    def function(a):
        return a * 2
    def filterer(a):
        return a > 2
    assert Try.of(function, 1).filter(filterer).get_or_else(None) is None
    assert Try.of(function, 2).filter(filterer).get_or_else(None) is None
    assert Try.of(function, 3).filter(filterer).get_or_else(None) == 6


# Generated at 2022-06-24 00:24:34.814262
# Unit test for method filter of class Try
def test_Try_filter():
    try_failing = Try.of(int, '5')
    try_success = Try.of(int, 5)

    assert try_failing.filter(lambda x: x == 5).is_success == False
    assert try_success.filter(lambda x: x == 5).is_success == True


# Generated at 2022-06-24 00:24:45.819578
# Unit test for method map of class Try
def test_Try_map():
    """
    Test map method of Try class.

    :returns: None
    :rtype: None

    """
    def fn(x):
        return x

    def mapper(x):
        return x


# Generated at 2022-06-24 00:24:56.750715
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # GIVEN
    test_1_value = '123'
    test_1 = Try(test_1_value, True)
    test_1_default_value = 'default'

    test_2_value = '123'
    test_2 = Try(test_2_value, False)
    test_2_default_value = 'default'

    # WHEN
    test_1_get_or_else_result = test_1.get_or_else(test_1_default_value)
    test_2_get_or_else_result = test_2.get_or_else(test_2_default_value)

    # THEN
    assert test_1_value == test_1_get_or_else_result
    assert test_2_default_value == test_2_get_or_else_result

# Generated at 2022-06-24 00:25:02.564072
# Unit test for method get of class Try
def test_Try_get():
    # GIVEN
    first = Try('value', True)
    second = Try('value', False)

    # WHEN
    first_value = first.get()
    second_value = second.get()

    # THEN
    assert first_value == 'value'
    assert second_value == 'value'



# Generated at 2022-06-24 00:25:10.261946
# Unit test for method bind of class Try
def test_Try_bind():
    result = Try.of(lambda x, y: x + y, 1, 2).bind(lambda x: Try(x * 2, True))
    assert result == Try(6, True)

    # When exception raised then not successfull result
    try:
        result = Try.of(lambda x, y: x / y, 1, 0).bind(lambda x: Try(x * 2, True))
    except Exception as e:
        assert result == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:25:17.726378
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Test the method __eq__ of class Try.
    """
    monad = Try("value", True)
    assert monad == Try("value", True)

    monad = Try("value", True)
    assert not monad == Try("value", False)

    monad = Try("value", True)
    assert not monad == Try("other value", True)

    monad = Try("value", True)
    assert not monad == Try("other value", False)

    monad = Try("value", True)
    assert not monad == Try("value", True)



# Generated at 2022-06-24 00:25:25.660354
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Test Try class method __eq__.
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, False)


# Generated at 2022-06-24 00:25:28.210625
# Unit test for method get of class Try
def test_Try_get():
    value = 5
    try_ctrl = Try(value, True)

    assert try_ctrl.get() == value



# Generated at 2022-06-24 00:25:30.773681
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:25:36.938708
# Unit test for constructor of class Try
def test_Try():
    assert Try('success', True) == Try('success', True)
    assert Try('failed', False) == Try('failed', False)
    assert Try.of(lambda: 'success') == Try('success', True)
    assert Try.of(lambda: 1/0) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:25:42.589068
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(1, True).filter(lambda x: x % 2 == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x % 2 == 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x % 2 == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x % 2 == 0) == Try(1, False)


# Generated at 2022-06-24 00:25:46.679631
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def test_true(default_value):
        return Try(7, True).get_or_else(default_value) == 7

    def test_false(default_value):
        return Try(7, False).get_or_else(default_value) == default_value

    assert test_true(5)
    assert test_false(5)

# Generated at 2022-06-24 00:25:50.613961
# Unit test for method get of class Try
def test_Try_get():
    # Try
    assert Try(10, True).get() == 10
    assert Try(10, False).get() == 10

    # Success
    assert Try(10, True).get() == 10

    # Failure
    assert Try(10, False).get() == 10



# Generated at 2022-06-24 00:25:53.366057
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(0, False).get_or_else(1) == 1
    assert Try(0, True).get_or_else(1) == 0

# Generated at 2022-06-24 00:25:55.798448
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    m_try = Try('value-1', True)
    assert m_try == Try('value-1', True)
    assert m_try != Try('value-2', True)
    assert m_try != Try('value-1', False)
    assert m_try != Try('value-2', False)


# Generated at 2022-06-24 00:26:03.575533
# Unit test for method bind of class Try
def test_Try_bind():
    from nose.tools import assert_equal
    from nose.tools import assert_raises

    def is_empty_string(string):
        return string == ''

    assert_equal(
        Try.of(is_empty_string, '').bind(lambda x: Try(x, True)),
        Try(True, True)
    )
    assert_equal(
        Try.of(is_empty_string, ' ').bind(lambda x: Try(x, True)),
        Try(False, True)
    )

    def concat_two_strings(first_str, second_str):
        return first_str + second_str

    assert_equal(
        Try.of(concat_two_strings, 'A', 'B').bind(lambda x: Try(x, True)),
        Try('AB', True)
    )
   

# Generated at 2022-06-24 00:26:09.143578
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value != 1

    assert Try(1, True).filter(filterer) == Try(1, False)

    assert Try(2, True).filter(filterer) == Try(2, True)

    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-24 00:26:17.177274
# Unit test for method filter of class Try
def test_Try_filter():
    def is_greater_than_10(value):
        return value > 10

    def is_less_than_100(value):
        return value < 100

    def is_less_than_0(value):
        return value < 0

    assert Try(11, True).filter(is_greater_than_10).is_success
    assert Try(100, True).filter(is_greater_than_10).is_success
    assert Try(10, True).filter(is_greater_than_10).is_success == False

    assert Try(11, True).filter(is_greater_than_10).filter(is_less_than_100).is_success
    assert Try(99, True).filter(is_greater_than_10).filter(is_less_than_100).is_success

# Generated at 2022-06-24 00:26:21.060677
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(1, True)
    try_2 = Try(2, False)
    try_3 = Try(3, True)
    assert try_1 == try_1
    assert try_1 != try_2
    assert try_2 == try_2
    assert try_1 != try_2
    assert try_1 != try_3
    assert try_2 != try_3


# Generated at 2022-06-24 00:26:28.003298
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) != Try(2, True)


# Generated at 2022-06-24 00:26:36.328040
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = 'Success'
    try1 = Try.of(lambda: value, )
    assert try1.value == value
    try2 = Try.of(lambda: 1)
    assert try2.value == 1
    assert try2.is_success
    assert try1.on_success(lambda x: setattr(try1, 'value', x + 'fully')) == try1
    assert try1.value == value + 'fully'
    assert try2.on_success(lambda x: setattr(try2, 'value', 'not integer')) == try2
    assert try2.value == 'not integer'



# Generated at 2022-06-24 00:26:38.399781
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(arg):
        assert arg == 'test'

    assert Try('test', True).on_success(success_callback) == Try('test', True)



# Generated at 2022-06-24 00:26:48.293524
# Unit test for method bind of class Try
def test_Try_bind(): # pragma: no cover
    """
    Unit test for method bind of class Try.
    """

    def func(value):
        return Try.of(lambda: value ** 2)

    assert (Try.of(lambda: 1).bind(func).value == 1)
    assert (Try.of(lambda: 1).bind(func).is_success == True)

    assert (Try.of(lambda: 'a').bind(func).value == 'a')
    assert (Try.of(lambda: 'a').bind(func).is_success == False)

    assert (Try.of(lambda: float('a')).bind(func).value != 'a')
    assert (Try.of(lambda: float('a')).bind(func).is_success == False)

    assert (func(2).value == 4)

# Generated at 2022-06-24 00:26:52.560579
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-24 00:27:00.843571
# Unit test for method bind of class Try
def test_Try_bind():
    def fn(*args):
        return sum(args)

    def mapper(value):
        return value + 1

    def binder(value):
        return Try(value + 1, True)

    assert Try.of(fn, 1, 2, 3).bind(binder) == Try(9, True)  # success monad, result 9
    assert Try.of(fn, 1, 2, 3).bind(binder).map(mapper) == Try(10, True)  # success monad, result 10
    assert Try.of(fn, 1, 2, 3).bind(lambda _: Try(None, False)).map(mapper) == Try(None, False)  # fail monad, result None
    assert Try.of(fn, 1, 2, 3).bind(lambda _: Try(None, False)).map(mapper).get

# Generated at 2022-06-24 00:27:06.635391
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:27:10.481472
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('something', True)) == "Try[value=something, is_success=True]"
    assert str(Try('something', False)) == "Try[value=something, is_success=False]"


# Generated at 2022-06-24 00:27:13.815322
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = 10
    try_value = Try(value, True)
    called = False

    def callback(value):
        nonlocal called
        called = True
        assert value == value

    try_value.on_success(callback)
    assert called



# Generated at 2022-06-24 00:27:15.598678
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    monad1 = Try(1, True)
    monad2 = Try(1, True)
    assert monad1 == monad2


# Generated at 2022-06-24 00:27:23.757231
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, None) \
        .map(lambda x: x + 1) \
        .filter(lambda x: x > 1) \
        == Try(2, True)

    assert Try.of(lambda: 1, None) \
        .map(lambda x: x + 1) \
        .filter(lambda x: x < 1) \
        == Try(1, False)

    assert Try.of(lambda: 1, None) \
        .map(lambda x: x + 1) \
        .filter(lambda x: True) \
        == Try(2, True)

    assert Try.of(lambda: 1, None) \
        .map(lambda x: x + 1) \
        .filter(lambda x: False) \
        == Try(1, False)


# Generated at 2022-06-24 00:27:26.527029
# Unit test for method get of class Try
def test_Try_get():
    # Arrange
    try_ = Try(1, True)

    # Act
    actual = try_.get()

    # Assert
    assert 1 == actual


# Generated at 2022-06-24 00:27:31.789252
# Unit test for method map of class Try
def test_Try_map():
    def value_1():
        return 1

    def value_exc():
        raise Exception

    def plus_one(value):
        return value + 1

    assert Try.of(value_1).map(plus_one) == Try(2, True)
    assert Try.of(value_exc).map(plus_one) == Try(Exception, False)


# Generated at 2022-06-24 00:27:37.704798
# Unit test for method bind of class Try
def test_Try_bind():
    assert(Try(None, True).bind(lambda x: Try(x + 1, True)) == Try(1, True))
    assert(Try(None, True).bind(lambda x: Try(x + 1, False)) == Try(1, False))
    assert(Try(None, False).bind(lambda x: Try(x + 1, True)) == Try(None, False))
    assert(Try(None, False).bind(lambda x: Try(x + 1, False)) == Try(None, False))


# Generated at 2022-06-24 00:27:43.802928
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(2, True).get_or_else(0) == 2
    assert Try('hey', True).get_or_else(0) == 'hey'
    assert Try(2, False).get_or_else(0) == 0
    assert Try('hey', False).get_or_else(0) == 0
    assert Try(0, False).get_or_else(2) == 2
    assert Try(2, False).get_or_else(0) == 0
    assert Try(1, False).get_or_else(0) == 0



# Generated at 2022-06-24 00:27:54.014773
# Unit test for method bind of class Try
def test_Try_bind():
    def add(a: int, b: int) -> int:
        return a + b

    def to_int(a: str) -> int:
        return int(a)

    def inc(a: int) -> int:
        return a + 1

    def inc2(a: int) -> int:
        return a + 2

    result = Try.of(add, 10, 20).bind(lambda a: Try.of(to_int, a))\
        .bind(lambda a: Try.of(inc, a))\
        .bind(lambda a: Try.of(inc2, a))

    assert result == Try(33, True)


# Generated at 2022-06-24 00:28:00.487137
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try('1234', True) == Try('1234', True)
    assert Try(1234, True) != Try(1234, False)
    assert Try(1234, False) != Try('1234', False)
    assert Try('1234', False) != Try('12345', False)

# Generated at 2022-06-24 00:28:07.487010
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    val = 1
    assert Try(val, True) == Try(val, True)
    assert Try(val, False) == Try(val, False)
    assert Try(val, True) != Try(val, False)
    assert Try(val, False) != Try(val, True)
    assert Try(val, True) != 1
    assert Try(val, False) != 1


# Generated at 2022-06-24 00:28:13.010351
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: int) -> bool:
        return value % 2 == 0

    f = Try.of(lambda: 2)
    nf = Try.of(lambda: 3)

    assert f.filter(filterer) == Try(2, True)
    assert nf.filter(filterer) == Try(3, False)

# Generated at 2022-06-24 00:28:19.451825
# Unit test for method bind of class Try
def test_Try_bind():
    """Test for `bind` method of class Try."""
    def fn():
        raise Exception('error')
    e = Try.of(fn)
    assert False == e.is_success
    assert 'error' == e.value

    def fn(s):
        return s.lower()
    assert 'a' == Try.of(fn, 'A').bind(fn).get()



# Generated at 2022-06-24 00:28:26.575179
# Unit test for method map of class Try
def test_Try_map():
    def add(x):
        return x + 3

    assert Try(1, True).map(add).get() == 4

    def raise_exception():
        raise ValueError('err')

    assert Try(1, False).map(raise_exception()).get() == 1

    def raise_exception():
        raise ValueError('err')

    assert Try(1, True).map(raise_exception).get() == 1
    assert Try('err', 1).map(raise_exception).get() == 'err'
    assert Try(add, False).map(raise_exception).get() == add


# Generated at 2022-06-24 00:28:30.269401
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    t_success = Try("success", True)
    assert(t_success.get_or_else("fail") == "success")
    t_fail = Try("fail", False)
    assert(t_fail.get_or_else("success") == "success")



# Generated at 2022-06-24 00:28:32.950145
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test function test_Try_get_or_else
    """
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2



# Generated at 2022-06-24 00:28:36.562650
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test function for get_or_else method

    :returns: None
    :rtype: None
    """
    try_with_value = Try(100, True)
    try_with_exc = Try(Exception("test"), False)

    assert try_with_value.get_or_else(0) == 100
    assert try_with_exc.get_or_else(0) == 0

# Generated at 2022-06-24 00:28:42.139940
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_exception_factory(value: int) -> ValueError:
        return ValueError(str(value))

    assert Try.of(lambda x: x, 1).on_fail(lambda x: print(x)) == Try(1, True)
    assert Try.of(test_exception_factory, 1).on_fail(lambda x: print(x)) == Try(ValueError('1'), False)


# Generated at 2022-06-24 00:28:48.008153
# Unit test for method filter of class Try
def test_Try_filter():
    is_empty_string = lambda x: len(x) == 0

    assert Try('', True).filter(is_empty_string) == Try('', True)
    assert Try('abc', True).filter(is_empty_string) == Try('abc', False)
    assert Try(None, False).filter(is_empty_string) == Try(None, False)
