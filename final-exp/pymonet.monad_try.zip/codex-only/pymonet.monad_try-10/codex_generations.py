

# Generated at 2022-06-24 00:18:48.011545
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """Unit test for method get_or_else of class Try."""
    value = Try.of(lambda: 3).get_or_else(5)
    assert value == 3

# Generated at 2022-06-24 00:18:54.552764
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def fn1(x):
        return x + 1
    def fn2(x):
        raise Exception('Some exception')

    assert Try.of(fn1, 5).map(fn1).get() == 6
    assert Try.of(fn2, 5).map(fn1).get_or_else(None) is None


# Generated at 2022-06-24 00:19:01.828311
# Unit test for method on_success of class Try
def test_Try_on_success():
    def add_one(value):
        return value + 1

    def error(value):
        raise ValueError('test')

    assert(isinstance(Try.of(add_one, 0).on_success(add_one), Try))
    assert(Try.of(add_one, 0).on_success(add_one) == Try.of(add_one, 1))

    assert(isinstance(Try.of(error, 0).on_success(add_one), Try))
    assert(Try.of(error, 0).on_success(add_one) == Try.of(error(0), False))


# Generated at 2022-06-24 00:19:08.000858
# Unit test for method bind of class Try
def test_Try_bind():
    is_success = False
    result = Try.of(lambda x: x + 1, 10).bind(lambda x: Try.of(lambda y: y + 1, x))
    if result.get() == 12 and result.is_success:
        is_success = True
    assert is_success
    is_success = False
    result = Try.of(lambda x: x + 1, 1).bind(lambda x: Try.of(lambda y: 1 / (y - 1), x))
    if result.get() is not None and not result.is_success:
        is_success = True
    assert is_success


# Generated at 2022-06-24 00:19:11.932022
# Unit test for method map of class Try
def test_Try_map():
    f = lambda x: x ** 2
    assert Try(4, True).map(f) == Try(16, True)


# Generated at 2022-06-24 00:19:15.097437
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('value', True)) == 'Try[value=value, is_success=True]'
    assert str(Try('value', False)) == 'Try[value=value, is_success=False]'


# Generated at 2022-06-24 00:19:20.595092
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x > 3) == Try(5, True)
    assert Try(2, True).filter(lambda x: x > 3) == Try(2, False)
    assert Try(5, False).filter(lambda x: x > 3) == Try(5, False)


# Generated at 2022-06-24 00:19:29.692325
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test Try.on_fail method

    :returns: True when all tests is ok
    :rtype: Boolean
    """
    try:
        _ = Try.of(1, 1).on_fail(lambda error: print('error: ', error))
        _ = Try.of(raise_exception, 1).on_fail(lambda error: print('error: ', error))
        return True
    except Exception as e:  # pragma: no cover
        print('test_Try_on_fail: ', e)
        return False



# Generated at 2022-06-24 00:19:32.391131
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    true_assert = Try(2, True) == Try(2, True)
    false_assert = Try(2, True) == Try(3, False)
    assert true_assert == True and false_assert == False


# Generated at 2022-06-24 00:19:37.548376
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, False) == Try(1, False)
    assert Try(2, True) == Try(2, True)
    assert Try(2, False) != Try(1, False)
    assert Try(1, True) == Try(1, True)
    assert Try(2, True) != Try(1, True)
    assert Try(1, True) != Try(2, True)


# Generated at 2022-06-24 00:19:45.062386
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x * x) == Try(1, True)
    assert Try(2, True).map(lambda x: x * x) == Try(4, True)
    assert Try(3, True).map(lambda x: x * x) == Try(9, True)
    assert Try(4, True).map(lambda x: x * x) == Try(16, True)
    assert Try(5, True).map(lambda x: x * x) == Try(25, True)

    assert Try(1, False).map(lambda x: x * x) == Try(1, False)
    assert Try(2, False).map(lambda x: x * x) == Try(2, False)
    assert Try(3, False).map(lambda x: x * x) == Try(3, False)

# Generated at 2022-06-24 00:19:48.094301
# Unit test for method get of class Try
def test_Try_get():
    # arrange
    succeed_try = Try(42, True)
    failed_try = Try(42, False)
    # assert
    assert succeed_try.get() == 42
    assert failed_try.get() == 42


# Generated at 2022-06-24 00:19:49.976728
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda _: 1, None).map(lambda _: 2) == Try(2, True)



# Generated at 2022-06-24 00:19:54.139308
# Unit test for method __str__ of class Try
def test_Try___str__():
    t = Try(10, True)
    assert(str(t) == 'Try[value=10, is_success=True]')
    t = Try(10, False)
    assert(str(t) == 'Try[value=10, is_success=False]')


# Generated at 2022-06-24 00:20:00.186136
# Unit test for method filter of class Try
def test_Try_filter():
    value = 'value'
    try_ = Try(value, True)
    assert try_.filter(lambda x: True) == Try(value, True)
    assert try_.filter(lambda x: False) == Try(value, False)

    def generate_exception(x):
        raise Exception(x)

    assert Try.of(generate_exception, value).filter(lambda x: False) == Try(value, False)


# Generated at 2022-06-24 00:20:03.253371
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(Exception(), False).get_or_else(0) == 0


# Generated at 2022-06-24 00:20:08.571783
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try(Exception(), False).get()


# Generated at 2022-06-24 00:20:16.676576
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Test for method __eq__ of class Try.

    :returns: None
    :rtype: None
    """
    # Different objects
    assert not Try(1, True) == Try(2, True)
    assert not Try(2, True) == Try(1, True)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, False) == Try(1, True)
    assert not Try(1, True) == Try(2, False)
    assert not Try(2, False) == Try(1, True)

    # Same objects
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)

# Unit tests for Try.of method

# Generated at 2022-06-24 00:20:24.566124
# Unit test for method map of class Try
def test_Try_map():
    t = Try.of(lambda: 2 / 0)
    t_mapped = t.map(lambda x: x + 2)
    assert t_mapped == Try(ZeroDivisionError(), False)
    t = Try.of(lambda: 5)
    t_mapped = t.map(lambda x: x - 2)
    assert t_mapped == Try(3, True)


# Generated at 2022-06-24 00:20:28.073627
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(None, False).get_or_else(2) == 2

# Generated at 2022-06-24 00:20:32.688938
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    class TestException(Exception):
        pass

    def check_value(value):
        return value == 'value'

    @try_catch
    def fn():
        raise TestException('I am error!')

    def on_fail(value):
        assert isinstance(value, TestException)
        assert check_value(value.args[0])

    def on_success(value):
        raise RuntimeError('This should not be happen!')

    Try.of(fn).on_fail(on_fail).on_success(on_success)


# Generated at 2022-06-24 00:20:36.030251
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def inc(x):
        return Try(x + 1, True)

    y = Try(1, True)

    assert y.bind(inc) == Try(2, True)
    assert y.bind(lambda x: Try(x / 0, True)) == Try(ZeroDivisionError(), False)
    assert y.bind(lambda x: Try(x / 0, False)) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:20:42.891406
# Unit test for method filter of class Try
def test_Try_filter():
    # Arrange
    test_var = 1
    try1 = Try(test_var, True)

    # Act
    try2 = try1.filter(lambda x: x == test_var)
    try3 = try1.filter(lambda x: x is None)

    # Assert
    assert try2 == Try(test_var, True)
    assert try3 == Try(test_var, False)


# Generated at 2022-06-24 00:20:45.278193
# Unit test for constructor of class Try
def test_Try():
    value = 1
    is_success = True
    try_1 = Try(value, is_success)
    try_2 = Try(value, is_success)
    assert try_1 == try_2


# Generated at 2022-06-24 00:20:49.773011
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(abs, -1).on_fail(lambda _: print('Fail')) == Try.of(abs, -1)
    assert Try.of(abs, None).on_fail(lambda _: print('Fail')) == Try.of(abs, None)
    assert Try.of(abs, -1).on_fail(lambda _: print('Fail')) != Try.of(abs, 1)

# Generated at 2022-06-24 00:20:52.972489
# Unit test for constructor of class Try
def test_Try():
    m_value = Try(5, True)
    m_err = Try("Fail", False)
    assert m_value.get() == 5
    assert m_err.get() == "Fail"
    assert m_err.is_success == False
    assert m_value.is_success == True


# Generated at 2022-06-24 00:20:55.889716
# Unit test for method filter of class Try
def test_Try_filter():
    def double(number):
        return number * 2

    def is_even(number):
        return number % 2 == 0

    assert Try.of(double, 2).filter(is_even).get() == 4
    assert Try.of(double, 3).filter(is_even).get_or_else(0) == 0


# Generated at 2022-06-24 00:20:58.444981
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5


# Generated at 2022-06-24 00:21:05.261747
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def success_callback(value):
        assert False # pragma: no cover

    def fail_callback(value):
        assert type(value) is TypeError

    def func():
        raise TypeError()

    try_monad = Try.of(func) \
        .on_success(success_callback) \
        .on_fail(fail_callback)
    assert str(try_monad) == 'Try[value=TypeError(), is_success=False]'


# Generated at 2022-06-24 00:21:14.888764
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def add(x, y):
        return x + y

    try_add_one = Try.of(add, 1, 1)
    try_add_two = Try.of(add, 2, 10)
    try_add_four = Try.of(add, 1, 3)

    assert try_add_one.map(lambda x: x * 2) == Try(4, True)
    assert try_add_two.map(lambda x: x * 2) == Try(40, True)
    assert try_add_four.map(lambda x: x * 2) == Try(10, True)

    try_add_error_one = Try.of(add, 1, "1")
    try_add_error_two = Try.of(add, 2, "2")
    try_add_error

# Generated at 2022-06-24 00:21:20.029074
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try.
    """
    assert Try('a', True).get_or_else('b') == 'a'
    assert Try('a', False).get_or_else('b') == 'b'


# Generated at 2022-06-24 00:21:24.844801
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x > 3) == Try(5, True)
    assert Try(5, False).filter(lambda x: x > 3) == Try(5, False)
    assert Try(1, True).filter(lambda x: x > 3) == Try(1, False)



# Generated at 2022-06-24 00:21:29.704349
# Unit test for method map of class Try
def test_Try_map():
    assert Try(10, True).map(lambda x: x + 10) == Try(20, True)
    assert Try(10, False).map(lambda x: x + 10) == Try(10, False)


# Generated at 2022-06-24 00:21:31.449114
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try((1, 2), True)) == 'Try[value=(1, 2), is_success=True]'
    assert str(Try('test', False)) == 'Try[value=test, is_success=False]'


# Generated at 2022-06-24 00:21:32.738006
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(10, True).get_or_else(-1) == 10
    assert Try(10, False).get_or_else(-1) == -1



# Generated at 2022-06-24 00:21:36.790901
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 5 / 0).get_or_else(0) == 0
    assert Try.of(lambda: 5 / 1).get_or_else(0) == 5
    assert Try.of(lambda: 5 / 1).get_or_else(1) == 5


# Generated at 2022-06-24 00:21:38.779203
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda a: a + 1, 0).filter(lambda a: a % 2 == 0) == Try(1, True)
    assert Try.of(lambda a: a + 1, 1).filter(lambda a: a % 2 == 0) == Try(2, False)

# Generated at 2022-06-24 00:21:40.781781
# Unit test for method filter of class Try
def test_Try_filter():
    x = Try.of(lambda x: x, 1)
    assert x.filter(lambda x: x == 1) == Try(1, True)
    assert x.filter(lambda x: x == 2) == Try(1, False)
    assert not x.is_success

# Generated at 2022-06-24 00:21:44.771322
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(int, '5').get_or_else(None) == 5
    assert Try.of(lambda x: x/0, 5).get_or_else(None) is None
    assert Try.of(lambda x: x/0, '5').get_or_else(None) is None


# Generated at 2022-06-24 00:21:48.698382
# Unit test for method bind of class Try
def test_Try_bind():
    try:
        raise Exception('Oops!')
    except Exception as e:
        assert Try.of(lambda: 5).bind(lambda a: Try(a + 7, True)) == Try(12, True)
        assert Try.of(raise_).bind(lambda a: Try(a + 7, True)) == Try(e, False)



# Generated at 2022-06-24 00:21:52.735304
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def square(x):
        return x * x

    def cube(x):
        return x * x * x

    assert(Try(5, True).map(square) == Try(25, True))
    assert(Try(0, True).map(square) == Try(0, True))

# Generated at 2022-06-24 00:22:03.628195
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test method bind of class Try.
    """
    first_success_monad = Try.of(int, 1)

    assert first_success_monad.bind(lambda x: Try.of(int, x + 1)) == Try.of(int, 2)
    assert first_success_monad.bind(lambda x: Try.of(str, str(x) + str(1))) == Try.of(str, '11')

    second_success_monad = Try.of(int, 2)

    assert second_success_monad.bind(lambda x: Try.of(int, x + 1)) == Try.of(int, 3)
    assert second_success_monad.bind(lambda x: Try.of(str, str(x) + str(1))) == Try.of(str, '21')

    first

# Generated at 2022-06-24 00:22:10.821223
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, None).filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(lambda: 1, None).filter(lambda x: x < 0) == Try(1, False)
    assert Try.of(lambda: 1, None).filter(lambda x: x < 0).filter(lambda x: x > 0) == Try(1, False)
    assert Try.of(lambda x: x / 0, 1).filter(lambda x: x > 0) == Try(ZeroDivisionError, False)

# Generated at 2022-06-24 00:22:19.474627
# Unit test for method get of class Try
def test_Try_get():
    # given
    test_value_1 = 10
    test_value_2 = 20
    test_Try_1 = Try(test_value_1, True)
    test_Try_2 = Try(test_value_2, False)
    # when
    test_result_1 = test_Try_1.get()
    test_result_2 = test_Try_2.get()
    # then
    assert test_result_1 == test_value_1
    assert test_result_2 == test_value_2


# Generated at 2022-06-24 00:22:22.559599
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Unit test for method __str__ of class Try
    """
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]',\
        'Str representation of Try is not right'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]',\
        'Str representation of Try is not right'
    assert str(Try('Test', True)) == 'Try[value=Test, is_success=True]',\
        'Str representation of Try is not right'



# Generated at 2022-06-24 00:22:24.829470
# Unit test for constructor of class Try
def test_Try():
    not_success = Try(Exception('Error'), False)
    assert not_success.value == Exception('Error')
    assert not_success.is_success == False

    success = Try(1, True)
    assert success.value == 1
    assert success.is_success == True



# Generated at 2022-06-24 00:22:26.612675
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'


# Generated at 2022-06-24 00:22:32.161094
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-24 00:22:34.560300
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # arrange
    monad_able = Try.of(lambda: 2 + 2)

    # act
    monad_not_able = Try.of(lambda: 2 + '2')

    # assert
    assert monad_able.get_or_else('empty') == 4
    assert monad_not_able.get_or_else('empty') == 'empty'


# Generated at 2022-06-24 00:22:36.909338
# Unit test for method get of class Try
def test_Try_get():
    assert Try(3, True).get() == 3



# Generated at 2022-06-24 00:22:44.188940
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    # *****
    # Test case when is not successfully
    # *****
    # Given
    t = Try(4, False)

    # When
    result = t.map(lambda v: v + 10)

    # Then
    assert result == Try(4, False)

    # *****
    # Test case when is successfully
    # *****
    # Given
    t = Try(4, True)

    # When
    result = t.map(lambda v: v + 10)

    # Then
    assert result == Try(14, True)


# Generated at 2022-06-24 00:22:49.259710
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(None, True) == Try(None, True)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)
    assert Try(None, True) != None
    assert Try(None, True) != True
    assert Try(None, True) != 1
    assert Try(None, True) != 'lorem'



# Generated at 2022-06-24 00:22:52.248816
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(-1) == 1
    assert Try(-1, False).get_or_else(1) == 1


# Generated at 2022-06-24 00:22:58.805738
# Unit test for method filter of class Try
def test_Try_filter():
    value = 7
    try_safe = Try.of(lambda: value)
    try_fail = Try.of(lambda: 1/0)

    assert try_safe.filter(lambda a: a == value).get() == value
    assert try_safe.filter(lambda a: a != value).get() == value
    assert try_fail.filter(lambda a: (a + 2) / 2 == 2).get() is False
    assert try_fail.filter(lambda a: (a + 2) / 2 == 1).get() is False


test_Try_filter()

# Generated at 2022-06-24 00:23:06.149478
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert (
        Try(ValueError("Error"), True)
        .on_fail(lambda error: print("Error:", error))
        == Try(ValueError("Error"), True)
    )

    assert (
        Try(ValueError("Error"), False)
        .on_fail(lambda error: print("Error:", error))
        == Try(ValueError("Error"), False)
    )



# Generated at 2022-06-24 00:23:11.309693
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, False) != Try(None, True)
    assert Try(None, True) != Try(None, False)


# Generated at 2022-06-24 00:23:18.469616
# Unit test for constructor of class Try
def test_Try():
    assert Try(12, True) == Try(12, True)
    assert Try(12, False) != Try(12, True)
    assert Try('hello', True) != Try('hello', False)
    assert Try('hello', False) != Try(12, False)
    assert Try(12, True) != Try('hello', True)

    assert str(Try('hello', True)) == 'Try[value=hello, is_success=True]'
    assert str(Try('hello', False)) == 'Try[value=hello, is_success=False]'


# Generated at 2022-06-24 00:23:24.555145
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test(value):
        """
        This function flag equal to True when value contains 'test'
        """
        if not isinstance(value, str):
            raise TypeError('A string is required')
        return 'test' in value
    assert Try.of(test, 'string test').on_fail(lambda *args: True) == Try('string test', True)
    assert Try.of(test, 0).on_fail(lambda *args: True) == Try(TypeError('A string is required'), False)

# Generated at 2022-06-24 00:23:27.329052
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def on_fail_callback(e):
        assert e == 'Unknown exception'

    result = Try.of(lambda: 1/0).on_fail(on_fail_callback)
    assert result == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:23:30.091238
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1).get_or_else(3) == 1
    assert Try.of(lambda: 1/0).get_or_else(3) == 3


# Generated at 2022-06-24 00:23:32.853064
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    x = Try(1, True)
    y = Try(1, True)
    z = Try(1, False)

    assert x == y
    assert x != z
    assert y != z


# Generated at 2022-06-24 00:23:36.540991
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(100, True).bind(lambda x: Try(x * 2, True)) == Try(200, True)
    assert Try(100, False).bind(lambda x: Try(x * 2, True)) == Try(100, False)



# Generated at 2022-06-24 00:23:40.570936
# Unit test for method on_success of class Try
def test_Try_on_success(): # pragma: no cover
    def print_value(value):
        print(value)

    Try(42, True).on_success(print_value)
    Try('wrong', False).on_success(print_value)


# Generated at 2022-06-24 00:23:43.067735
# Unit test for method bind of class Try
def test_Try_bind():
    result = Try.of(lambda: 'test').bind(
        lambda value: Try.of(lambda: 'value1')
    )
    assert result == Try('value1', True)


# Generated at 2022-06-24 00:23:51.704185
# Unit test for method bind of class Try
def test_Try_bind():
    def fn1(x):
        return x + 1

    def fn2(x):
        return x + 1

    def fn3(x):
        return x + 1

    def fn4(x):
        return x + 1

    def fn5(x):
        return x + 1

    def fn6(x):
        return x + 1

    def fn7(x):
        return x + 1

    def fn8(x):
        return x + 1

    def fn9(x):
        return x + 1

    def fn10(x):
        return x + 1

    def test_case1(x):
        return 1

    def test_case2(x):
        return 1

    def test_case3(x):
        return 1

    def test_case4(x):
        return 1


# Generated at 2022-06-24 00:23:55.883718
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    t1 = Try(1, True)
    assert t1 == t1
    assert t1 == Try(1, True)
    assert not t1 == Try(1, False)
    assert not t1 == 42
    assert not t1 == {'value': 1}

# Generated at 2022-06-24 00:23:59.160482
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 10, 1).on_fail(lambda _: 1) == Try(10, True)
    assert Try.of(lambda: 10/0, 1).on_fail(lambda _: 1) == Try(1, False)


# Generated at 2022-06-24 00:24:06.593875
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    test_value = ''

    def test_function():
        return 1 / 0

    def success_callback(value):
        nonlocal test_value
        test_value = 'success'

    def fail_callback(value):
        nonlocal test_value
        test_value = 'fail'

    result = Try.of(test_function).on_success(success_callback).on_fail(fail_callback)
    assert result.is_success is False
    assert str(result.value) == 'division by zero'
    assert test_value == 'fail'


# Generated at 2022-06-24 00:24:10.951307
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(1, True)
    try_2 = Try(1, True)
    try_other = Try(1, False)
    assert try_1 == try_2
    assert try_1 != try_other



# Generated at 2022-06-24 00:24:17.754671
# Unit test for constructor of class Try
def test_Try():
    assert Try(3, True) == Try(3, True)
    assert Try(3, True) != Try(3, False)
    assert str(Try(3, True)) == 'Try[value=3, is_success=True]'


# Generated at 2022-06-24 00:24:20.812745
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def mock_on_fail(v):
        return 'success'

    assert Try(1, False).on_fail(mock_on_fail) == 'success'



# Generated at 2022-06-24 00:24:31.519466
# Unit test for method on_success of class Try
def test_Try_on_success():
    # GIVEN
    def successful_on_success_test_function(x):
        results.append(x)

    def failed_on_success_test_function(x):
        results.append(x)

    results = []
    success_Try = Try(42, True)
    not_success_Try = Try(42, False)
    # WHEN
    success_Try.on_success(successful_on_success_test_function)
    not_success_Try.on_success(successful_on_success_test_function)
    success_Try.on_success(failed_on_success_test_function)
    not_success_Try.on_success(failed_on_success_test_function)
    # THEN
    assert results == [42]


# Generated at 2022-06-24 00:24:35.967228
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-24 00:24:40.365795
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def _on_fail(value):  # pylint: disable=unused-argument
        return False

    def _on_fail_other(value):  # pylint: disable=unused-argument
        return True

    def _no_raise():
        return 1

    def _raise():
        raise ValueError('test')

    assert Try.of(_no_raise).on_fail(_on_fail)
    assert not Try.of(_raise).on_fail(_on_fail_other)


# Generated at 2022-06-24 00:24:48.122613
# Unit test for constructor of class Try
def test_Try():
    """
    Testing constructor of Try class.

    :returns: True when all tests is passed, otherwise False
    :rtype: boolean
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, False) == Try(2, False)


# Generated at 2022-06-24 00:24:51.789364
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1).get_or_else(0) == 1
    assert Try.of(lambda: 1 / 0).get_or_else(0) == 0


# Generated at 2022-06-24 00:24:55.822442
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True).is_success is True
    assert Try(1, False).is_success is False
    assert Try(1, True).value == 1
    assert Try(1, False).value == 1


# Generated at 2022-06-24 00:25:05.890211
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test case for method bind of class Try.

    :rtype: None
    """
    # Test case when both Try are successfully
    assert Try.of(lambda x: x, 1).bind(lambda x: Try.of(lambda y: y, x)) == Try(1, True)
    # Test case when first Try is not successfully
    assert Try.of(lambda x, y: y / x, 0, 1).bind(lambda x: Try.of(lambda y: y, x)) == Try(ZeroDivisionError("division by zero"), False)
    # Test case when second Try is not successfully
    assert Try.of(lambda x: x, 1).bind(lambda x: Try.of(lambda y, z: z / y, 0, x)) == Try(ZeroDivisionError("division by zero"), False)
    # Test case when both

# Generated at 2022-06-24 00:25:07.478661
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2


# Generated at 2022-06-24 00:25:13.490159
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try("str", True) == Try("str", True)
    assert Try("str", False) == Try("str", False)
    assert Try(1, True) != Try("str", True)
    assert Try(1, False) != Try("str", False)
# test_Try___eq__()



# Generated at 2022-06-24 00:25:15.858342
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) != None
    assert Try(1, True) == Try(1, True)


# Generated at 2022-06-24 00:25:18.326417
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda x: x, 5).on_success(lambda x: x) == Try(5, True)


# Generated at 2022-06-24 00:25:25.350459
# Unit test for method map of class Try
def test_Try_map():
    # Test for successfully map
    assert Try.of(int, "5").map(lambda x: x + 3)\
        == Try(8, True)

    # Test for map not successfully
    assert Try.of(int, "x").map(lambda x: x + 3)\
        == Try(ValueError("invalid literal for int() with base 10: 'x'"), False)


# Generated at 2022-06-24 00:25:29.679469
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)

# Generated at 2022-06-24 00:25:33.487797
# Unit test for method __eq__ of class Try
def test_Try___eq__():

    assert Try(1, False) == Try(1, False)
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:25:37.540414
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(2, True).filter(lambda x: x > 0) == Try(2, True)
    assert Try(-2, True).filter(lambda x: x > 0) == Try(-2, False)
    assert Try(2, False).filter(lambda x: x > 0) == Try(2, False)


# Generated at 2022-06-24 00:25:44.821529
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    """
    Unit test for method __str__ of class Try

    :return: True when test is passed, False othercase
    :rtype: Boolean
    """
    try_ = Try(1, True)
    assert str(try_) == 'Try[value=1, is_success=True]'

    try_ = Try(None, False)
    assert str(try_) == 'Try[value=None, is_success=False]'

    fail = Try(None, False)
    assert str(fail) == 'Try[value=None, is_success=False]'
    return True



# Generated at 2022-06-24 00:25:53.366028
# Unit test for constructor of class Try
def test_Try():
    assert Try(3, True) == Try(3, True)
    assert Try(3, False) == Try(3, False)
    assert Try(3, True) != Try(3, False)
    assert Try(3, False) != Try(3, True)
    assert Try(2, True) == Try(2, True)
    assert Try(2, False) == Try(2, False)
    assert Try(2, True) != Try(2, False)
    assert Try('test', False) == Try('test', False)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) == Try(None, True)



# Generated at 2022-06-24 00:26:01.702746
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def get_pos_divisible(dividend, divisor):
        # Check divisor is not zero
        if divisor == 0:
            raise ValueError("Divisor can't be zero")
        # Compute division result
        division_result = dividend / divisor
        # Check division result is positive
        if division_result < 0:
            raise ValueError("Division result can't be negative")
        # Return division result
        return division_result

    # Check with non zero divisor
    assert Try.of(get_pos_divisible, 50, 10).get_or_else(0) == 5.0  # type: ignore

    # Check with zero divisor
    assert Try.of(get_pos_divisible, 50, 0).get_or_else(0) == 0  # type: ignore


# Generated at 2022-06-24 00:26:04.364613
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda: 1).get_or_else(0) == 1
    assert T

# Generated at 2022-06-24 00:26:14.471175
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    """Unit test for method filter of class Try."""
    def filterer(value):
        return value == 'one'

    assert Try.of(lambda: 'one', True).filter(filterer).value == 'one'
    assert not Try.of(lambda: 'two', True).filter(filterer).is_success
    assert Try.of(lambda: 'two', True).filter(filterer).value == 'two'
    assert not Try.of('test_exception_message', False).filter(filterer).is_success
    assert Try.of('test_exception_message', False).filter(filterer).value == 'test_exception_message'


# Generated at 2022-06-24 00:26:23.825882
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    from monad.either import Either

    class Person:
        def __init__(self, name) -> None:
            self.name = name

        def __str__(self) -> str:
            return 'Person[name={}]'.format(self.name)

    def add_one(v: int) -> int:
        return v + 1

    def add_one_if_not_exists(p: Person) -> Person:
        return Person(p.name) if p.name.endswith('1') else Person(p.name + '1')

    def multiply_by_2(v: int) -> int:
        return v * 2


# Generated at 2022-06-24 00:26:28.096405
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_true = Try(1, True)
    assert str(try_true) == 'Try[value=1, is_success=True]'

    try_false = Try("some message", False)
    assert str(try_false) == 'Try[value=some message, is_success=False]'


# Generated at 2022-06-24 00:26:30.706848
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(True, False).get_or_else(False) == False
    assert Try(True, True).get_or_else(False) == True


# Generated at 2022-06-24 00:26:34.543670
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # When monad is successfully
    result = Try(42, True).get_or_else(0)
    assert result == 42

    # When monad is not successfully
    result = Try(None, False).get_or_else(0)
    assert result == 0


# Generated at 2022-06-24 00:26:37.046680
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False) == Try(1, False)


# Generated at 2022-06-24 00:26:43.397403
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = 2
    action_call = False
    success_fn = lambda x: 'action_call'

    def action():
        nonlocal action_call
        action_call = True

    actual = Try(value, True).on_success(success_fn).on_success(action)
    assert actual.value == value
    assert actual.is_success
    assert success_fn(value) == 'action_call'
    assert action_call



# Generated at 2022-06-24 00:26:47.703460
# Unit test for method map of class Try
def test_Try_map():
    def add_1(i):
        return i + 1

    assert Try.of(add_1, 1).map(add_1).get() == 3

    assert Try.of(add_1, 1).map(lambda x: x + 1).get() == 3


# Generated at 2022-06-24 00:26:56.899012
# Unit test for method get of class Try
def test_Try_get():
    """Unit test for class Try method get."""
    assert Try.of(lambda : 1).get() == 1
    assert Try.of(lambda : 1, 2, 3).get() == 1
    assert Try.of(lambda : 'foo').get() == 'foo'
    assert Try.of(lambda a, b: a+b, 1, 2).get() == 3
    assert Try.of(lambda a, b: a+b, 'foo', 'bar').get() == 'foobar'
    assert not Try.of(lambda : 1/0).get()  # pragma: no cover
    assert not Try.of(lambda : foo).get()  # pragma: no cover


# Generated at 2022-06-24 00:27:02.444515
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Check call fail callback function when monad is not successfully
    is_fail = False
    Try.of(lambda: 1 / 0, ).on_fail(lambda _: setattr(test_Try_on_fail, 'is_fail', True))
    assert is_fail is True

    # Check no call fail callback function when monad is successfully
    is_fail = False
    Try.of(lambda: 1, ).on_fail(lambda _: setattr(test_Try_on_fail, 'is_fail', True))
    assert is_fail is False



# Generated at 2022-06-24 00:27:07.317073
# Unit test for method on_success of class Try
def test_Try_on_success():
    def check_value(value):
        assert value == "Have any value"

    Try.of(lambda: "Have any value", )\
        .on_success(check_value)


# Generated at 2022-06-24 00:27:15.891970
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: True == x).is_success
    assert not Try(False, True).filter(lambda x: True == x).is_success
    assert not Try(None, True).filter(lambda x: True == x).is_success
    assert not Try(True, True).filter(lambda x: True == x).is_success
    assert not Try(True, False).filter(lambda x: True == x).is_success
    assert not Try(2, False).filter(lambda x: x > 3).is_success
    assert not Try([1,2,3,4], True).filter(lambda x: len(x) == 5).is_success


# Generated at 2022-06-24 00:27:22.374869
# Unit test for method bind of class Try
def test_Try_bind():
    class TestException(Exception):
        pass

    def success_fn(*args, **kwargs):
        return "return value"

    def fail_fn(*args, **kwargs):
        raise TestException("raise exception")

    def bind_fn(value):
        return Try(value, True)

    assert Try.of(success_fn).bind(bind_fn) == Try("return value", True)
    assert Try.of(fail_fn).bind(bind_fn) == Try(TestException("raise exception"), False)


# Generated at 2022-06-24 00:27:24.945109
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover

    def fail_callback(error):
        assert error == 'test error'

    Try.of(lambda: 1/0, None).on_fail(fail_callback)

# Generated at 2022-06-24 00:27:30.086077
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def divide(num1, num2):
        return num1 / num2

    expected_result = 42
    result = Try.of(divide, 12, 3).get_or_else(expected_result)
    assert result == 4
    result = Try.of(divide, 12, 0).get_or_else(expected_result)
    assert result == expected_result

# Generated at 2022-06-24 00:27:36.460602
# Unit test for method bind of class Try
def test_Try_bind():
    def generate_exception():
        raise Exception('')

    assert Try.of(lambda: 1).bind(lambda n: n) == Try(1, True)
    assert Try.of(lambda: 1).bind(generate_exception) == Try(1, True)
    assert Try.of(generate_exception).bind(lambda n: n) == Try(Exception(''), False)



# Generated at 2022-06-24 00:27:42.092617
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    f = lambda x: Try(x, True)
    g = lambda x: Try(x * 2, True)
    h = lambda x: Try(x - 1, True)
    assert f(10).bind(g).bind(h).get() == 19

    m = lambda x: Try(x, True)
    n = lambda x: Try(x * 2, True)
    h = lambda x: Try(x - 1, False)
    assert m(10).bind(n).bind(h).get() == 20

# Generated at 2022-06-24 00:27:44.916434
# Unit test for constructor of class Try
def test_Try():
    def func():
        raise Exception("message")
    try_ = Try(42, True)
    assert try_ == Try(42, True)
    assert Try.of(func) == Try(Exception("message"), False)



# Generated at 2022-06-24 00:27:54.090503
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    class TestException(Exception):
        def __init__(self, message):
            super(TestException, self).__init__(message)

    def test_success():
        def success_callback(value):
            print(value)

        def fail_callback(value):
            print(value.message)

        try_monad = Try(1, True)
        try_monad.on_success(success_callback).on_fail(fail_callback)

    def test_fail():
        def success_callback(value):
            print(value)

        def fail_callback(value):
            print(value.message)

        try_monad = Try(TestException('Exception'), False)
        try_monad.on_success(success_callback).on_fail(fail_callback)


# Generated at 2022-06-24 00:27:58.607554
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'
    assert str(Try(Exception('error'), False)) == 'Try[value=Exception("error"), is_success=False]'



# Generated at 2022-06-24 00:28:01.442606
# Unit test for method map of class Try
def test_Try_map():
    """
    Test Try class method: map
    """
    assert Try.of(lambda: 10).map(lambda x: x + 1) == Try(11, True)
    assert Try.of(lambda: 10).map(lambda x: x / 0) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0).map(lambda x: x + 1) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:28:09.536235
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception(), False) == Try(Exception(), False)
    assert Try(1, True) != Try(None, True)
    assert Try(1, True) != Try(None, False)
    assert Try(1, True) != Try(None, True)
    assert Try(1, True) != 'a'
    assert Try(1, True) != 1
    assert Try(1, True) != None



# Generated at 2022-06-24 00:28:15.665714
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    from src.utils.exception import AssertionError

    Try\
    .of(float, '42')\
    .on_fail(lambda reason: print(reason))\
    .on_success(lambda value: print(value))

    Try\
    .of(float, 'not_number')\
    .on_fail(lambda reason: print(reason))\
    .on_success(lambda value: print(value))

# Generated at 2022-06-24 00:28:26.741049
# Unit test for method filter of class Try
def test_Try_filter():
    from pymonad import compose
    from pymonad import curry

    is_even = curry(lambda x: x % 2 == 0)
    is_positive = curry(lambda x: x > 0)

    assert (
        Try.of(lambda: 20).filter(is_even).filter(is_positive)\
            == Try(20, True)
    )

    assert (
        Try.of(lambda: 21).filter(is_even).filter(is_positive)\
            == Try(21, False)
    )

    assert (
        Try.of(lambda: -21).filter(is_even).filter(is_positive)\
            == Try(-21, False)
    )


# Generated at 2022-06-24 00:28:34.008469
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:28:39.465672
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Unit test for method bind of class Try.
    """
    def binder(x):
        return Try(x * 2, True)

    assert Try(Try(4, True).bind(binder), True) == Try(8, True)
    assert Try(Try(4, True).bind(lambda x: Try(x / 0, True)), True).map(lambda x: x.value) == Try(ZeroDivisionError, False)


# Generated at 2022-06-24 00:28:50.027901
# Unit test for method filter of class Try
def test_Try_filter():
    is_type_of_2 = lambda x: isinstance(x, int) and x == 2
    is_type_of_str = lambda x: isinstance(x, str)

    assert Try(1, True).filter(is_type_of_2).is_success is False
    assert Try(2, True).filter(is_type_of_2).is_success is True
    assert Try(2, True).filter(is_type_of_str).is_success is False
    assert Try(2, False).filter(is_type_of_2).is_success is False
    assert Try('string', True).filter(is_type_of_str).is_success is True
    assert Try('string', False).filter(is_type_of_str).is_success is False

