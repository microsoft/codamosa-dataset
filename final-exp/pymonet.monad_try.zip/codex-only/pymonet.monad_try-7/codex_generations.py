

# Generated at 2022-06-24 00:18:47.210060
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-24 00:18:56.964155
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try

    """
    assert Try(1, True) == Try(1, True)
    assert Try(0, False) == Try(0, False)
    assert Try(1, False) != Try(1, True)
    assert Try(0, True) != Try(0, False)
    assert Try(1, False) != Try(0, False)
    assert Try(1, True) != Try(0, True)
    assert Try(0, False) != Try(1, False)
    assert Try(0, True) != Try(1, True)
    assert Try(0, False) != None
    assert Try(0, False) != 'test'
    assert Try(1, True) != None
    assert Try(1, True) != 'test'


# Generated at 2022-06-24 00:19:00.714505
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try.of(lambda: 1) == Try.of(lambda: 1)
    assert Try.of(lambda: 1) != Try.of(lambda: 2)
    assert Try.of(lambda: 1) != Try.of(lambda: 2, 1)
    assert Try.of(lambda: 1) != Try.of(lambda: 1, 1)
    assert Try.of(lambda: 1, 1) != Try.of(lambda: 1)


# Generated at 2022-06-24 00:19:05.760898
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(10, True)) == "Try[value=10, is_success=True]"



# Generated at 2022-06-24 00:19:08.059522
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: x+1) == Try(2, True)
    assert Try(1, False).on_success(lambda x: x+1) == Try(1, False)


# Generated at 2022-06-24 00:19:09.164529
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    result = Try(12, True)
    assert result.get() == 12


# Generated at 2022-06-24 00:19:11.712436
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x: x, 'test').get() == 'test'



# Generated at 2022-06-24 00:19:22.248127
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(value):
        return Try(value, True)

    t = Try(5, True)
    assert t.bind(binder) == Try(5, True)

    def binder(value):
        return Try(value, False)

    t = Try(5, True)
    assert t.bind(binder) == Try(5, False)

    def binder(value):
        return Try(value, True)

    t = Try(5, False)
    assert t.bind(binder) == Try(5, False)

    def binder(value):
        return Try(value, False)

    t = Try(5, False)
    assert t.bind(binder) == Try(5, False)

    t = Try(5, True)

# Generated at 2022-06-24 00:19:27.607158
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test for method map of class Try.
    """
    def double(x):
        return 2 * x

    assert Try.of(lambda: 'Text to double', None).map(double) == Try('Text to double', True)
    assert Try.of(lambda: 'Text to double', None).map(double).get() == 'Text to doubleText to double'
    assert Try.of(lambda: 'Text to double', None).map(lambda x: double(double(x))) == Try('Text to double', True)
    assert Try.of(lambda: 'Text to double', None).map(lambda x: double(double(x))).get() == 'Text to doubleText to doubleText to doubleText to double'

# Generated at 2022-06-24 00:19:30.825554
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    ex = Exception('test')
    result = Try(10, True).get_or_else(30)
    assert result == 10

    result = Try(ex, False).get_or_else(30)
    assert result == 30



# Generated at 2022-06-24 00:19:34.878342
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else(43) == 42
    assert Try(42, False).get_or_else(43) == 43


# Generated at 2022-06-24 00:19:43.282132
# Unit test for method bind of class Try
def test_Try_bind():

    def divider(x, y):
        return x / y

    def binder(x):
        return Try.of(divider, x, 2)

    try1 = Try.of(divider, 4, 2)
    try2 = Try.of(divider, 4, 0)

    assert try1.bind(binder).get() == 2
    assert try2.bind(binder).is_success == False

# Generated at 2022-06-24 00:19:46.765457
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:19:52.572197
# Unit test for method map of class Try
def test_Try_map():
    def fn(i):
        return i + 2
    my_try = Try.of(fn, 1)
    assert my_try.is_success
    assert my_try.map(fn) == Try(4, True)
    assert my_try.map(fn).is_success

    def bad_fn():
        raise ZeroDivisionError()
    my_try = Try.of(bad_fn)
    assert not my_try.is_success
    assert my_try.map(fn) == my_try



# Generated at 2022-06-24 00:19:55.621712
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-24 00:20:01.119322
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert 'Try[value=1, is_success=True]' == str(Try(1, True))
    assert 'Try[value=Exception(), is_success=False]' == str(Try(Exception(), False))
    assert 'Try[value=1, is_success=False]' == str(Try(1, False))



# Generated at 2022-06-24 00:20:10.735886
# Unit test for method bind of class Try
def test_Try_bind():
    def test_fn(arg):
        return arg

    value = 'test'

    def binder(arg):
        return Try(arg, True)

    success_try = Try.of(test_fn, value)
    assert success_try.bind(binder) == binder(value)

    fail_try = Try.of(lambda: 1/0)
    assert fail_try.bind(binder) == fail_try

    def binder2(arg):
        if arg:
            return Try(arg, True)
        return Try(arg, False)

    assert success_try.bind(binder2) == binder2(value)
    assert fail_try.bind(binder2) == binder2(fail_try.get())


# Generated at 2022-06-24 00:20:18.040822
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    class TestException(Exception):
        """TestException"""

    def test_value(value):
        """Test function to raise TestException when value is a."""
        if value == 'a':
            raise TestException()

    # Call Try of method with test_value function, value a and arg fail_handler
    # fail_handler always return a
    fail_handler = lambda _: 'a'
    try_instance = Try.of(test_value, 'a', fail_handler)

    assert try_instance.is_success is False
    assert try_instance.value is 'a'

    def test_fail_handler(value):
        """Test fail_handler function to check if value is a."""
        assert value == 'a'

    try_instance.on_fail(test_fail_handler)



# Generated at 2022-06-24 00:20:22.874775
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    result = Try.of(lambda: raise_exception()).on_fail(lambda e: e.args)
    assert result == Try(('Either StopIteration or Return inside generator'), False)



# Generated at 2022-06-24 00:20:30.375202
# Unit test for method map of class Try
def test_Try_map():
    t = Try.of(lambda a: a + 1, 2)
    assert t.map(lambda a: a + 1) == Try(4, True)

    t = Try.of(lambda a: a + 1, None)
    assert t.map(lambda a: a + 1) == Try(None, False)


# Generated at 2022-06-24 00:20:36.709268
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    exec_test = Trampoline()
    exec_test.defer(
        lambda: exec_test.immediate(Try.of(divmod, 1, 0))
        .bind(lambda _: exec_test.immediate(Try.of(divmod, 1, 1)))
        .on_fail(lambda _: exec_test.immediate(123))
        .bind(lambda value: exec_test.immediate(value == 1))
    )

# Generated at 2022-06-24 00:20:38.246902
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(3, True)) == 'Try[value=3, is_success=True]'
    assert str(Try(3, False)) == 'Try[value=3, is_success=False]'


# Generated at 2022-06-24 00:20:43.433133
# Unit test for method map of class Try
def test_Try_map():
    def add_two(x):
        return x + 2
    assert Try.of(lambda: 1, ()).map(add_two) == Try(3, True)
    assert Try.of(lambda: 1, ()).map(lambda _: 1 / 0) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0, ()).map(lambda _: 1) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:20:45.573490
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = 'value'
    try_instance = Try(value, True)

# Generated at 2022-06-24 00:20:47.414801
# Unit test for method get of class Try
def test_Try_get():
    assert 'abcd' == Try('abcd', True).get()
    assert 'abcd' == Try('abcd', False).get()



# Generated at 2022-06-24 00:20:52.709168
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # given
    mock_on_fail = Mock()
    # when
    Success(None).on_fail(mock_on_fail)
    # then
    mock_on_fail.assert_not_called()
    # when
    Fail(None).on_fail(mock_on_fail)
    # then
    mock_on_fail.assert_called_with(None)


# Generated at 2022-06-24 00:20:56.814936
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == "Try[value=1, is_success=True]"
    assert str(Try(1, False)) == "Try[value=1, is_success=False]"
    assert str(Try(Exception(1), True)) == "Try[value=1, is_success=True]"
    assert str(Try(Exception(1), False)) == "Try[value=1, is_success=False]"


# Generated at 2022-06-24 00:20:59.244046
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1, ()).map(lambda x: x + 1).get() == 2


# Generated at 2022-06-24 00:21:10.254060
# Unit test for method bind of class Try
def test_Try_bind():
    def divide(num):
        return Try(num/2, True)

    def multiply(num):
        return Try(num*3, True)

    def is_even(num):
        return num % 2 == 0

    assert Try(10, True).bind(divide).bind(multiply).value == 15
    assert Try(10, True).bind(divide).bind(multiply).is_success == True
    assert Try(10, True).bind(divide).bind(multiply).bind(divide).value == 7.5
    assert Try(10, True).bind(divide).bind(multiply).bind(divide).is_success == True
    assert Try(11, True).bind(divide).bind(multiply).bind(divide).value == 11

# Generated at 2022-06-24 00:21:12.868992
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try('', False)) == 'Try[value=, is_success=False]'


# Generated at 2022-06-24 00:21:20.414392
# Unit test for method map of class Try
def test_Try_map():
    # Test with successful Try with simple value
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    # Test with unsuccessful Try with simple value
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)
    # Test with successful Try with complex value
    assert Try('string', True).map(lambda x: {x.upper(): x}) == Try({'STRING': 'string'}, True)
    # Test with unsuccessful Try with complex value
    assert Try('string', False).map(lambda x: {x.upper(): x}) == Try('string', False)
    # Test with failed try with simple value
    assert Try.of(lambda x: 1 / x, 0).map(lambda x: x + 1) == Try(1, True)
    # Test with failed

# Generated at 2022-06-24 00:21:24.794126
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(2, True) == Try(2, True)
    assert not Try(2, True) == Try(3, True)
    assert not Try(2, True) == Try(2, False)
    assert not Try(2, False) == Try(3, False)
    assert not Try(2, True) == None

# Generated at 2022-06-24 00:21:33.035070
# Unit test for method map of class Try
def test_Try_map():
    from pymonad.operator import (mcompose,
                                  flip,
                                  curry)
    from pymonad.tools import do

    @do(Try)
    def my_function(x):
        y = yield x
        z = yield y + 1
        return z + y
    assert my_function(Try(5, True)) == Try(11, True)
    assert my_function(Try(5, False)) == Try(5, False)

    @do(Try)
    def my_function2(x):
        y = yield x
        z = yield y + 1
        return z
    assert my_function2(Try(5, True)) == Try(6, True)
    assert my_function2(Try(5, False)) == Try(5, False)

    def my_function3(x):
        return

# Generated at 2022-06-24 00:21:43.084291
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    from random import randrange
    from itertools import chain
    from functional.monad.option import Some, None_
    from functional.monad.result import Ok, Err

    # create list of values (for exception we use NoneType)
    values = chain(
        list(range(50)), [float('inf'), float('nan'), None])

    # create list of exceptions (exception we use is None)
    exceptions = chain(
        [TypeError, ValueError, IndexError, None], [FileExistsError])

    # iterate over all try - catch combinations
    for exception in exceptions:
        for value in values:
            # call on_fail method and check if method behaviour is correnct
            is_callable = Try(value, True).on_fail(lambda _: exception).is_success
            is_not_callable = Try

# Generated at 2022-06-24 00:21:46.526521
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def success():
        return 'success'

    def fail():
        raise Exception('fail!')

    # Successfully
    assert Try.of(success).get_or_else(1) is 'success'

    # Fail
    assert Try.of(fail).get_or_else(1) is 1

# Generated at 2022-06-24 00:21:53.198669
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert type(Try(1, True).get()) == int
    assert Try(1.0, True).get() == 1.0
    assert type(Try(1.0, True).get()) == float
    assert Try('test', True).get() == 'test'
    assert type(Try('test', True).get()) == str

    # assert Try(1, False).get() == None
    # assert Try(1.0, False).get() == None
    # assert Try('test', False).get() == None


# Generated at 2022-06-24 00:22:00.905240
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    a = Try(1, True)
    b = Try(1, True)
    c = Try(2, False)
    a_fake = '1'

    assert a == b, 'Try.__eq__ must returns True when 2 try are equals'
    assert not a == c, 'Try.__eq__ must returns False when 2 try are not equals'
    assert not a == a_fake, 'Try.__eq__ must returns False when try is compared to an other type'


# Generated at 2022-06-24 00:22:06.501815
# Unit test for constructor of class Try
def test_Try():
    """
    Test successfuly Try constructor.
    """
    assert Try(1, True) == Try(1, True)



# Generated at 2022-06-24 00:22:13.387193
# Unit test for method bind of class Try
def test_Try_bind():
    def f():
        raise Exception('Test exception')
        return True

    def g(x):
        if x:
            return Try(True, True)
        return Try(False, False)

    assert Try.of(f).bind(g) == Try(Exception('Test exception'), False)
    assert Try.of(lambda: True).bind(g) == Try(True, True)



# Generated at 2022-06-24 00:22:16.702625
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'
    assert str(Try(Exception(7), False)) == 'Try[value=7, is_success=False]'


# Generated at 2022-06-24 00:22:19.856992
# Unit test for method on_success of class Try
def test_Try_on_success():
    def my_mapper(x):
        return x * 2

    mapped_value = Try(44, True).map(my_mapper).get()
    assert mapped_value == 88

# Generated at 2022-06-24 00:22:25.396344
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Test correctly of method on_success when monad is successfully.
    """
    test_value = 'test'

# Generated at 2022-06-24 00:22:32.127518
# Unit test for method bind of class Try
def test_Try_bind():
    def divide_100_by(x):
        if x == 0:
            raise ValueError('Zero division error')
        return 100 / x

    assert Try.of(divide_100_by, 0) == Try(ValueError('Zero division error'), False)
    assert Try.of(divide_100_by, 1) == Try(100, True)

    def divide_by_3(value):
        return Try(value/3, True)

    assert Try.of(divide_100_by, 3).bind(divide_by_3) == Try(10, True)


# Generated at 2022-06-24 00:22:34.292702
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True).is_success
    assert not Try(1, False).is_success


# Generated at 2022-06-24 00:22:36.737268
# Unit test for method bind of class Try
def test_Try_bind():
    result = Try(20, True).bind(lambda x: Try(x * 1.5, True)).get()
    assert result == 30

# Generated at 2022-06-24 00:22:39.174711
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, False) == Try(None, False)
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'



# Generated at 2022-06-24 00:22:46.188962
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def success_callback(value):
        raise Exception("Shouldn't go here")

    def fail_callback(value):
        assert str(value) == 'test_exception'

    try_1 = Try.of(fail_callback) # should raise exception
    try_1.on_fail(success_callback)

    try_2 = Try.of(fail_callback) # should raise exception
    try_2.on_fail(fail_callback)

    try_3 = Try.of(success_callback) # should raise exception
    try_3.on_fail(success_callback)

    try_4 = Try.of(success_callback) # should raise exception

# Generated at 2022-06-24 00:22:51.479241
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def test_ok_fn(a: str) -> None:
        print('OK: {}'.format(a))

    def test_fail_fn(a: str) -> None:
        print('FAIL: {}'.format(a))

    Try.of(lambda: 'ok').on_success(test_ok_fn).on_fail(test_fail_fn)
    Try.of(lambda: 'fail').on_success(test_ok_fn).on_fail(test_fail_fn)


# Generated at 2022-06-24 00:22:56.843005
# Unit test for constructor of class Try
def test_Try():
    assert Try(True, True) == Try(True, True)
    assert Try(True, False) == Try(True, False)
    assert Try(True, True) != Try(True, False)
    assert Try(True, True) != Try(False, True)

    assert Try(42, True) != Try(43, True)
    assert Try(True, True) != Try(False, False)


# Generated at 2022-06-24 00:22:58.073553
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-24 00:23:01.010648
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    ret: Try[int] = Try.of(lambda x: 1/x, 0)

# Generated at 2022-06-24 00:23:03.477690
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:23:08.840863
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try.of(lambda: 5, ()).__eq__(Try.of(lambda: 5, ()))
    assert Try.of(lambda: 5, ()).__eq__(Try.of(lambda: 5, ())) is not False
    assert Try.of(lambda: 5, ()).__eq__(Try.of(lambda: '5', ())) is False
    assert Try.of(lambda: 5, ()).__eq__(Try.of(lambda: 5, ())).is_success
    assert not Try.of(lambda x: x / 0, (1,)).__eq__(Try.of(lambda: 5, ())).is_success



# Generated at 2022-06-24 00:23:13.869214
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: x) == Try(1, True)
    assert Try(1, True).on_fail(lambda x: x) == Try(1, True)
    assert Try(1, False).on_fail(lambda x: x) == Try(1, False)
    assert Try(1, False).on_fail(lambda x: x+1) == Try(2, False)



# Generated at 2022-06-24 00:23:18.878616
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    """
    When try is successfully, return as string: Try[value=<value>, is_success=True]
    When try is not successfully, return as string: Try[value=<value>, is_success=True]
    """
    assert Try('foo', True).__str__() == 'Try[value=foo, is_success=True]'
    assert Try('foo', False).__str__() == 'Try[value=foo, is_success=False]'


# Generated at 2022-06-24 00:23:21.137663
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    sample_value = 5
    assert Try(sample_value, True) == Try(sample_value, True)


# Generated at 2022-06-24 00:23:23.621046
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, False).on_fail(lambda x: 2) == Try(1, False)
    assert Try(1, True).on_fail(lambda x: 2) == Try(1, True)



# Generated at 2022-06-24 00:23:32.935724
# Unit test for constructor of class Try

# Generated at 2022-06-24 00:23:38.696070
# Unit test for method map of class Try
def test_Try_map():
    # Given
    def mapper(value):
        return value + 1

    # When
    success = Try.of(lambda: 1)
    failure = Try.of(lambda: 1/0)

    # Then
    assert success.map(mapper) == Try(2, True)
    assert failure.map(mapper) == Try(ZeroDivisionError, False)



# Generated at 2022-06-24 00:23:41.321198
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else(0) == 42
    assert Try(42, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:23:42.801269
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try("success", True).get_or_else("fail") == "success"



# Generated at 2022-06-24 00:23:44.603392
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(35, True).get() == 35
    assert Try(100, False).get() == 100


# Generated at 2022-06-24 00:23:45.743262
# Unit test for constructor of class Try
def test_Try():
    try_monad = Try(0, True)
    assert try_monad == Try(0, True)


# Generated at 2022-06-24 00:23:50.127999
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(1, False)
    assert Try(2, True) == Try(2, True)
    assert not Try(2, True) == Try(2, False)
    assert Try(1, False) == Try(1, False)
    assert not Try(1, False) == Try(2, False)
    assert Try(2, False) == Try(2, False)
    assert not Try(2, False) == Try(1, False)
    assert not Try(1, True) == Try(1, False)
    assert Try(1, False) == Try(1, True)


# Generated at 2022-06-24 00:23:57.261989
# Unit test for method filter of class Try
def test_Try_filter():
    """
    test_Try_filter function for unit test method filter in Try class.
    """
    try_test = Try(5, True).filter(lambda x: x == 5)
    assert isinstance(try_test, Try)
    assert try_test == Try(5, True)
    try_test = Try(5, True).filter(lambda x: x == 6)
    assert isinstance(try_test, Try)
    assert try_test == Try(5, False)
    try_test = Try(5, False).filter(lambda x: x == 5)
    assert isinstance(try_test, Try)
    assert try_test == Try(5, False)


# Generated at 2022-06-24 00:24:04.217576
# Unit test for constructor of class Try
def test_Try():
    success_monad = Try(1, True)
    fail_monad = Try(None, False)
    assert success_monad == Try(1, True)
    assert fail_monad == Try(None, False)
    assert success_monad != Try(None, True)
    assert fail_monad != Try(1, False)
    assert success_monad != fail_monad
    assert success_monad != 1
    assert fail_monad != 1


# Generated at 2022-06-24 00:24:11.226328
# Unit test for method filter of class Try
def test_Try_filter():
    def empty(value):
        return value.strip() == ""

    assert Try("", True).filter(empty) == Try("", False)
    assert Try("  ", True).filter(empty) == Try("  ", False)
    assert Try(" abc ", True).filter(empty) == Try(" abc ", True)



# Generated at 2022-06-24 00:24:19.984869
# Unit test for method get of class Try
def test_Try_get():
    def get_value() -> int:
        return 3

    try_1 = Try.of(get_value)
    try_2 = Try.of(lambda: 1 / 0)
    try_3 = Try.of(lambda: map(lambda x: x, []))

    assert try_1.get() == 3
    assert try_2.get() == Try(ZeroDivisionError(), False)
    assert try_3.get() == Try(StopIteration(), False)



# Generated at 2022-06-24 00:24:24.858985
# Unit test for constructor of class Try
def test_Try():
    assert Try(12, True) == Try(12, True)
    assert Try(12, True) is not Try(12, True)

    assert Try(12, False) == Try(12, False)
    assert Try(12, False) is not Try(12, False)

    assert Try(12, True) != Try(12, False)


# Generated at 2022-06-24 00:24:31.906573
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Tests for method on_success of class Try.

    :return: None
    :rtype: None
    """
    def process_success(value):
        assert value == 'try'

    def process_fail(value):
        assert True

    Try('try', True).on_success(process_success)\
        .on_fail(process_fail)

    Try(None, False).on_success(process_success)\
        .on_fail(process_fail)

# Generated at 2022-06-24 00:24:33.713737
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:24:41.185290
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False) != Try(2, True)


# Generated at 2022-06-24 00:24:44.071731
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:24:50.364145
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_1 = Try(1, True)
    try_2 = try_1.map(lambda x: x + 1)

# Generated at 2022-06-24 00:24:52.337795
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    idempotent test for method on_success
    """
    assert Try.of(lambda: 1, None).on_success(lambda x: x + 2) == Try.of(lambda: 1, None).on_success(lambda x: x + 2)


# Generated at 2022-06-24 00:24:55.705405
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: x + 1) == Try(1, True)
    assert Try(1, False).on_fail(lambda x: x + 1) == Try(2, False)



# Generated at 2022-06-24 00:24:58.174856
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try('test', True) == Try('test', True)
    assert Try('test', False) == Try('test', False)
    assert Try('test', True) != Try('test', False)



# Generated at 2022-06-24 00:24:59.967923
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x * 2)) == Try(1, True)


# Generated at 2022-06-24 00:25:02.300910
# Unit test for method on_success of class Try
def test_Try_on_success():
    def fn():
        return 2
    def cb(x):
        assert x == 2
    Try.of(fn).on_success(cb)


# Generated at 2022-06-24 00:25:06.407459
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test Try.on_fail function.
    """
    Try.of(lambda: 1 / 0,
           ).on_fail(lambda e: print(e))
    # When division by zero

# Generated at 2022-06-24 00:25:11.513851
# Unit test for constructor of class Try
def test_Try():
    try_1 = Try(1, True)
    try_2 = Try(2, False)

    assert try_1.value == 1
    assert try_1.is_success == True
    assert try_2.value == 2
    assert try_2.is_success == False


# Generated at 2022-06-24 00:25:20.416675
# Unit test for method on_success of class Try
def test_Try_on_success():

    class TestClass:
        is_test_success = None
        def set_test_success(value):
            TestClass.is_test_success = True

    try:
        int(22)
    except Exception as e:
        pass

    test_instance = TestClass()

    assert Try(1, True).on_success(test_instance.set_test_success)
    assert TestClass.is_test_success
    assert not Try(1, False).on_success(test_instance.set_test_success)
    assert not TestClass.is_test_success



# Generated at 2022-06-24 00:25:22.037547
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True)
    assert Try(Exception(), False)


# Generated at 2022-06-24 00:25:32.706104
# Unit test for method map of class Try
def test_Try_map():
    def sum(x, y):
        return x + y

    assert Try.of(sum, 1, 2).map(lambda n: n * 2) == Try(6, True)
    assert Try.of(sum, 1, 2).map(lambda n: n * 2) == Try(6, True)
    assert Try.of(sum, 1, 'a').map(lambda n: n * 2) == Try('a', False)
    assert Try.of(sum, 1, 2).map(lambda n: n * 2) == Try(6, True)
    assert Try.of(sum, 'a', 2).map(lambda n: n * 2) == Try('a', False)

# Generated at 2022-06-24 00:25:36.752148
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_ = Try(1, True)
    assert try_.get_or_else(2) == 1
    try_ = Try(1, False)
    assert try_.get_or_else(2) == 2
    try_ = Try(None, True)
    assert try_.get_or_else(2) == None


# Generated at 2022-06-24 00:25:40.602497
# Unit test for method filter of class Try
def test_Try_filter():

    def filterer(value: int) -> bool:
        return value > 0

    try_ = Try(2, True)

    assert try_.filter(filterer) == Try(2, True)

    try_ = Try(0, True)

    assert try_.filter(filterer) == Try(0, False)



# Generated at 2022-06-24 00:25:43.874010
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    value = 0
    def callback(n):
        nonlocal value
        value = n + 1
    result = Try.of(lambda: 1/0)
    result.on_fail(callback)
    assert result == Try(ZeroDivisionError(), False)
    assert value == 1


# Generated at 2022-06-24 00:25:46.461577
# Unit test for method get of class Try
def test_Try_get():
    """
    Unit test for method get of class Try.
    """
    assert Try.of(lambda: 5).get() == 5
    assert not Try.of(lambda: 5/0).get()


# Generated at 2022-06-24 00:25:50.372296
# Unit test for constructor of class Try
def test_Try():
    success = Try(3, True)
    not_success = Try('error', False)

    assert success.value == 3
    assert not_success.value == 'error'

    assert success.is_success == True
    assert not_success.is_success == False



# Generated at 2022-06-24 00:25:59.936285
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Success(1) == Success(1)
    assert Success(2) == Success(2)
    assert Success(3) == Success(3)
    assert Success(4) == Success(4)
    assert Success(5) == Success(5)

    assert Failure('1') == Failure('1')
    assert Failure('2') == Failure('2')
    assert Failure('3') == Failure('3')
    assert Failure('4') == Failure('4')
    assert Failure('5') == Failure('5')

    assert Success(1) != Failure('1')
    assert Success(1) != Failure('2')
    assert Success(1) != Failure('3')

    assert Failure('1') != Success(1)
    assert Failure('2') != Success(2)
    assert Failure('3') != Success(3)


# Generated at 2022-06-24 00:26:05.888169
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Test for method on_success of class Try
    """

# Generated at 2022-06-24 00:26:08.995509
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        1/0
    except Exception as e:
        assert Try(e, False).on_fail(lambda x: x.args[0]).get() == 'division by zero'

# Generated at 2022-06-24 00:26:16.421113
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover

    assert True == (Try(1,True) == Try(1, True))
    assert False == (Try(1,True) == Try(2, True))
    assert False == (Try(1,True) == Try(1, False))
    assert False == (Try(1,False) == Try(2, False))
    assert False == (Try(1,False) == Try(2, True))
    assert False == (Try(1,True) == Try(None, False))
    assert False == (Try(1,True) == None)
    assert False == (Try(1,True) == True)
    assert False == (Try(1,True) == False)
    assert False == (Try(1,True) == 1)
    assert False == (Try(1,True) == "1")

# Generated at 2022-06-24 00:26:18.502985
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    t = Try("test", True)
    assert t.value == "test"
    assert t.is_success == True


# Generated at 2022-06-24 00:26:22.518300
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    '''
    >>> x = Try.of(lambda x: x, 1)
    >>> x.filter(lambda x: x % 3 == 0).get_or_else(-1)
    -1
    >>> x.filter(lambda x: x == 1).get_or_else(-1)
    1
    >>> x.filter(lambda x: x == 1).get_or_else(-1)
    1
    '''


# Generated at 2022-06-24 00:26:24.578101
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5
    assert Try(5, False).get() == 5


# Generated at 2022-06-24 00:26:26.456110
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-24 00:26:30.030153
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert(str(Try('test', True)) == 'Try[value=test, is_success=True]')
    assert(str(Try('test', False)) == 'Try[value=test, is_success=False]')


# Generated at 2022-06-24 00:26:34.643209
# Unit test for method bind of class Try
def test_Try_bind():
    def some_function():
        return 5

    def other_function(value):
        return Try(value, True)

    assert Try.of(some_function).bind(other_function) == Try(5, True)



# Generated at 2022-06-24 00:26:36.511990
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_monad = Try(42, False)
    try_monad2 = Try(42, False)
    assert try_monad == try_monad2


# Generated at 2022-06-24 00:26:40.800213
# Unit test for method map of class Try
def test_Try_map():
    assert Try("123", True).map(len) == Try(3, True)
    assert Try("123", True).map(lambda x: int(x) // 2) == Try(61, True)
    assert Try("123", True).map(lambda x: int(x) / 0) == Try("division by zero", False)
    assert Try("abc", False).map(len) == Try("abc", False)
    assert Try("a", True).map(lambda x: int(x)) == Try("invalid literal for int() with base 10: 'a'", False)


# Generated at 2022-06-24 00:26:43.122890
# Unit test for method get of class Try
def test_Try_get():
    try_success = Try(3, True)
    assert try_success.get() == 3

    try_fail = Try(2, False)
    assert try_fail.get() == 2


# Generated at 2022-06-24 00:26:44.559821
# Unit test for method get of class Try
def test_Try_get():
    res = Try.of(
            lambda x: x ** 2,
            2
           )
    assert res.get() == 4


# Generated at 2022-06-24 00:26:51.076232
# Unit test for method get of class Try
def test_Try_get():
    """
    >>> test_Try_get()
    True
    """
    def fn(arg):
        return arg

    t1 = Try.of(fn, 1)
    t2 = Try.of(fn, 0 / 0)

    assert t1.get() == 1
    assert t1.filter(lambda x: x < 2).get() == 1
    assert t2.get() == ZeroDivisionError('division by zero')
    assert t2.filter(lambda x: x < 2).get() == ZeroDivisionError('division by zero')

    return True

# Generated at 2022-06-24 00:26:56.241019
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Arrange
    from unittest.mock import MagicMock
    mock_function = MagicMock()

    # Act
    # Assert
    assert Try(4, True).on_fail(mock_function) == Try(4, True)
    mock_function.assert_not_called()

    assert Try(4, False).on_fail(mock_function) == Try(4, False)
    mock_function.assert_called()

# Generated at 2022-06-24 00:26:59.540615
# Unit test for method filter of class Try
def test_Try_filter():
    # When filterer function return True method should return Successfully Try
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    # When filterer function return True method should return Not Successfully Try
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    # When monad is not successfully method should return copy of monad
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)



# Generated at 2022-06-24 00:27:05.965244
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try

    :returns: True when all test are successfully passed
    :rtype: Boolean
    """
    from math import sqrt

    fn_to_bind = lambda value: Try(sqrt(value), True)
    assert Try.of(lambda value: value, 4).filter(lambda value: True).bind(fn_to_bind) == Try(2.0, True)
    assert Try.of(lambda value: value, 4).filter(lambda value: False).bind(fn_to_bind) == Try(4, False)

    fn_to_fail = lambda value: Try(sqrt(value), False)
    assert Try.of(lambda value: value, 4).filter(lambda value: True).bind(fn_to_fail) == Try(4, False)

# Generated at 2022-06-24 00:27:12.497527
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Testing on_success method of Try class.
    """
    def callback_fn(value):
        pass

    try_obj = Try(None, True)
    try_obj.on_success(callback_fn)

    def callback_fn_error(value):
        raise Exception("callback_fn must not call!")

    try_obj = Try(None, False)
    try_obj.on_success(callback_fn_error)



# Generated at 2022-06-24 00:27:15.645907
# Unit test for constructor of class Try
def test_Try():
    assert Try(42, True) == Try(42, True)
    assert Try(42, False) != Try(42, True)
    assert Try(42, True) != Try(13, True)
    assert Try(42, False) != Try(13, False)


# Generated at 2022-06-24 00:27:20.277013
# Unit test for constructor of class Try
def test_Try():
    try_of_2 = Try(2, True)
    try_fail_3 = Try(3, False)
    assert try_of_2 == Try(2, True)
    assert try_of_2 != try_fail_3


# Generated at 2022-06-24 00:27:24.810299
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_ = Try(0, True)
    assert try_.get_or_else(1) == 0
    try_ = Try(0, False)
    assert try_.get_or_else(1) == 1


# Generated at 2022-06-24 00:27:31.684811
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == str(Try(1, True))
    assert str(Try(1, False)) == str(Try(1, False))
    assert str(Try(None, True)) == str(Try(None, True))
    assert str(Try(None, False)) == str(Try(None, False))
    assert str(Try(Exception('ex'), True)) != str(Try(Exception('anothr ex'), False))


# Generated at 2022-06-24 00:27:37.302864
# Unit test for method map of class Try
def test_Try_map():
    identity = lambda x: x
    assert Try(identity, True).map(identity) == Try(identity, True)
    assert Try(identity, False).map(identity) == Try(identity, False)


# Generated at 2022-06-24 00:27:41.983370
# Unit test for constructor of class Try
def test_Try():
    assert Try("test_value", True) == Try("test_value", True)
    assert Try("test_value", False) != Try("test_value", True)
    assert Try("test_value", True) != Try("test_value2", True)
    assert Try("test_value", True) != Try("test_value", False)
    assert Try("test_value", False) != Try("test_value2", False)



# Generated at 2022-06-24 00:27:46.228770
# Unit test for method bind of class Try
def test_Try_bind():
    def f(x):
        if x == 42:
            return Try(42, True)
        return Try(99, False)
    assert Try(42, True).bind(f) == Try(42, True)
    assert Try(43, True).bind(f) == Try(99, False)
    assert Try(42, False).bind(f) == Try(42, False)
    assert Try(43, False).bind(f) == Try(43, False)


# Generated at 2022-06-24 00:27:47.552615
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'


# Generated at 2022-06-24 00:27:52.664412
# Unit test for method filter of class Try
def test_Try_filter():
    # Test successful
    t1 = Try.of(lambda x: x + 1, 1)
    assert t1.filter(lambda x: x > 1) == Try(2, True)
    assert t1.filter(lambda x: x < 1) == Try(2, False)
    # Test not successful
    t2 = Try.of(lambda x: x + 1, 1)
    assert t2.filter(lambda x: x > 3) == Try(2, False)
    assert t2.filter(lambda x: x < 3) == Try(2, False)
test_Try_filter()



# Generated at 2022-06-24 00:27:58.129636
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    assert Try.of(lambda: 10 / 2, None).on_fail(lambda e: print(e)) == Try(5, True)
    assert Try.of(lambda: 10 / 0, None).on_fail(lambda e: print(e)) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:28:02.614282
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def raise_error(_):
        raise Exception('Fail')

    def double(value):
        return 2 * value

    # Successful Try
    assert Try.of(lambda: 2).map(double) == Try(4, True)

    # Not successful Try
    assert Try.of(raise_error).map(double) == Try(Exception('Fail'), False)


# Generated at 2022-06-24 00:28:03.744469
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 1).on_success(lambda x: x + 1).get() == 2



# Generated at 2022-06-24 00:28:15.510600
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try([], True)) == 'Try[value=[], is_success=True]'
    assert str(Try([], False)) == 'Try[value=[], is_success=False]'
    assert str(Try(Try(None, True), True)) == 'Try[value=Try[value=None, is_success=True], is_success=True]'
    assert str(Try(Try(None, True), False))

# Generated at 2022-06-24 00:28:21.817249
# Unit test for method get of class Try
def test_Try_get():             # pragma: no cover
    def identity(x):
        return x

    assert Try.of(identity, 1).get() == 1

    def raise_exception():
        raise Exception('raise_exception')

    assert Try.of(raise_exception).get() is not None
    assert Try.of(raise_exception).get().__class__.__name__ == 'Exception'



# Generated at 2022-06-24 00:28:27.352535
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try
    """
    try:
        value = 'foobar'
        monad = Try(value, True)

        assert(monad == Try(value, True))
        assert(monad != Try((value,), True))
        assert(monad != Try(value, False))
        assert(monad != 'foobar')
    except Exception as e:
        raise e



# Generated at 2022-06-24 00:28:33.245743
# Unit test for constructor of class Try
def test_Try():
    assert Try(42, True) == Try(42, True)
    assert Try(ValueError('oops'), False) == Try(ValueError('oops'), False)
    assert Try(42, True) != Try(42, False)
    assert Try(42, True) != Try(24, True)
    assert Try(42, False) != Try(24, False)
    assert Try(42, True) != 'str'
    assert Try(42, True) != {'key': 42}



# Generated at 2022-06-24 00:28:36.482910
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def test_func(arg1, arg2):
        return arg1 + arg2
    assert Try(test_func(1, 2), True).get_or_else(10) == 3
    assert Try(None, False).get_or_else(10) == 10


# Generated at 2022-06-24 00:28:40.550102
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(10, True) == Try(10, True)
    assert Try(10, False) != Try(10, True)
    assert Try(10, True) != Try(11, True)
    assert Try(10, True) != Try(11, False)


# Generated at 2022-06-24 00:28:47.897542
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False).value == 1
    assert not Try(1, False).is_success
    assert Try(1, True).value == 1
    assert Try(1, True).is_success
