

# Generated at 2022-06-24 00:18:46.120649
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda x: x + 2, 1).get_or_else(2) == 3
    assert Try.of(lambda x: x + 2, 1).get_or_else(0) == 3
    assert Try.of(lambda x: x / 0, 1).get_or_else(2) == 2
    assert Try.of(lambda x: x / 0, 1).get_or_else(0) == 0


# Generated at 2022-06-24 00:18:51.427754
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception('Exception'), False)) == "Try[value=Exception('Exception'), is_success=False]"


# Generated at 2022-06-24 00:18:59.455974
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    _ = "on fail test"
    is_called = False

    def fail_callback(value):
        if value == _:
            nonlocal is_called
            is_called = True

    try_ = Try.of(lambda x: x, "some value")
    try_.on_fail(fail_callback)
    assert is_called == False, "should be False"

    try_ = Try.of(lambda x: x, _)
    try_.on_fail(fail_callback)
    assert is_called == True, "should be True"


# Generated at 2022-06-24 00:19:02.663157
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_positive(number):
        return number > 0

    assert Try.of(lambda x: x, -2).filter(is_positive) == Try(-2, False)
    assert Try.of(lambda x: x, 2).filter(is_positive) == Try(2, True)


# Generated at 2022-06-24 00:19:04.054652
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda : 'Hello').get() == 'Hello'
    assert Try.of(lambda : 1 / 0, 1).get() is not None


# Generated at 2022-06-24 00:19:05.231598
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(Exception(), False).get() == Exception()


# Generated at 2022-06-24 00:19:10.987545
# Unit test for method map of class Try
def test_Try_map():
    try_value = Try.of(lambda: 1)
    try_value1 = Try.of(lambda: 1/0, 1)
    try_value2 = Try.of(lambda a: a * 2, 2)
    try_value3 = Try.of(lambda x, y: x * y, 2, 3)

    assert try_value.map(lambda x: x + 1).value == 2
    assert try_value2.map(lambda x: x + 1).value == 5
    assert try_value3.map(lambda x, y: x + y).value == 5

    assert try_value.map(lambda x: x + 1).is_success == True
    assert try_value1.map(lambda x: x + 1).is_success == False


# Generated at 2022-06-24 00:19:13.321163
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5


# Generated at 2022-06-24 00:19:19.197595
# Unit test for method on_fail of class Try
def test_Try_on_fail():

    def raise_exception():
        """
        Raise AssertionError with message
        """
        raise AssertionError('AssertionError')

    def assert_not_exception(value):
        """
        Assert that value is None

        :params value: value for assertion
        :type value: Any
        """
        assert value is None

    assert Try(1, True).on_fail(assert_not_exception) == Try(1, True)
    assert Try(1, False).on_fail(assert_not_exception) == Try(1, False)
    assert Try(None, False).on_fail(assert_not_exception) == Try(None, False)
    assert Try(raise_exception(), True).on_fail(assert_not_exception) == Try(raise_exception(), True)
   

# Generated at 2022-06-24 00:19:23.605231
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    attr = 'value'
    assert Try(attr, True).__eq__(Try(attr, True)) is True
    assert Try('', False).__eq__('a') is False
    assert Try(attr, True).__eq__(Try(attr, False)) is False


# Generated at 2022-06-24 00:19:27.102621
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # unit test
    try_monad = Try(1, True)
    assert try_monad.get_or_else(None) == 1

    try_monad = Try(None, False)
    assert try_monad.get_or_else(1) == 1



# Generated at 2022-06-24 00:19:32.592597
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert_that(
            Try(10, True),
            equal_to(Try(10, True)),
            'Try should be equals with same values'
    )

    assert_that(
            Try(10, True),
            is_not(equal_to(Try(10, True))),
            'Try should be not equals when is_success args is different'
    )

    assert_that(
            Try(10, True),
            is_not(equal_to(Try(11, True))),
            'Try should be not equals when value args is different'
    )



# Generated at 2022-06-24 00:19:36.922345
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test method on_fail of class Try.
    """
    def exc_handler(exc):
        raise exc

    # Call on_fail with exception
    try:
        Try(1, True).on_fail(exc_handler)
        assert False
    except Exception as e:
        assert e == 1

    # Call on_fail without exception
    try:
        Try(1, False).on_fail(exc_handler)
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-24 00:19:41.526263
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    assert Try(2, True).bind(lambda x: Try(x * 2, True)) == Try(4, True)
    assert Try(2, True).bind(lambda x: Try(x * 2, False)) == Try(4, False)
    assert Try(2, False).bind(lambda x: Try(x * 2, True)) == Try(2, False)
    assert Try(2, False).bind(lambda x: Try(x * 2, False)) == Try(2, False)


# Generated at 2022-06-24 00:19:46.049571
# Unit test for constructor of class Try
def test_Try():
    try_success, try_fail = Try(1, True), Try(Exception(), False)
    assert try_success.value == 1
    assert try_fail.value == Exception()
    assert try_success.is_success
    assert not try_fail.is_success


# Generated at 2022-06-24 00:19:48.478705
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    expected_1 = Try(5, True)
    expected_2 = Try(5, False)
    expected_3 = Try(5, True)

    assert expected_1 == expected_1
    assert expected_1 == expected_3
    assert expected_1 == 5
    assert expected_1 == 5.0

    assert expected_1 != expected_2
    assert expected_1 != 10
    assert expected_1 != 10.0


# Generated at 2022-06-24 00:19:51.278977
# Unit test for method on_success of class Try
def test_Try_on_success():
    t_success = Try.of(lambda: 5, None)
    t_failure = Try.of(lambda: 5/0, None)
    assert t_success.on_success(lambda x: print(x + 5)) == Try(5, True)
    assert t_failure.on_success(lambda x: print(x + 5)) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-24 00:19:52.927797
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:19:58.628281
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(10, True) == Try(10, True)
    assert Try(10, False) == Try(10, False)
    assert Try(10, True) != Try(10, False)
    assert Try(10, False) != Try(10, True)
    assert Try(10, True) != Try('10', True)
    assert Try(10, False) != Try('10', False)



# Generated at 2022-06-24 00:20:05.214026
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test method on_fail on class Try.

    :returns: True when test is successfully passed, othercase raise AssertionError.
    :rtype: Boolean
    """
    assert Try.of(lambda: 1 / 0).on_fail(lambda e: e + 1) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 1).on_fail(lambda e: e + 1) == Try(1, True)
    return True

# Generated at 2022-06-24 00:20:10.422956
# Unit test for method map of class Try
def test_Try_map():
    """
    Test when monad Try is successfully and not successfully.
    """
    def fn(a):
        return a + 1

    def fn_raise(a):
        raise Exception('Test')

    assert Try.of(fn_raise, 2).map(fn) == Try(Exception('Test'), False)
    assert Try.of(fn, 2).map(fn) == Try(3, True)


# Generated at 2022-06-24 00:20:14.554169
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_success = Try("Something", True)
    assert str(try_success) == 'Try[value=Something, is_success=True]'

    try_fail_with_exception = Try(ValueError("Something wrong!"), False)
    assert str(try_fail_with_exception) == 'Try[value=Something wrong!, is_success=False]'


# Generated at 2022-06-24 00:20:19.412194
# Unit test for method on_fail of class Try

# Generated at 2022-06-24 00:20:20.558636
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert 'Try[value=1, is_success=True]' == str(Try(1, True))



# Generated at 2022-06-24 00:20:28.539619
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test method bind of class Try.
    Test monad bind behavior when monad is successfully and not successfully.
    Test when binder function raises exception and not.
    """
    def binder(x):
        return Try(x + 1, True)

    def binder_two(x):
        return Try(x + 2, True)

    def binder_raise(x):
        raise Exception()

    # Test monad bind behavior when monad is successfully and not successfully.
    success = Try(1, True)
    failure = Try(2, False)
    assert success.bind(binder) == Try(2, True)
    assert failure.bind(binder) == Try(2, False)

    # Test when binder function raises exception and not.

# Generated at 2022-06-24 00:20:33.045774
# Unit test for method get of class Try
def test_Try_get():
    assert True == Try(True, True).get()
    assert False == Try(False, True).get()



# Generated at 2022-06-24 00:20:36.534882
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert (Try(1, True) == Try(1, True)) is True
    assert (Try(1, True) == Try(1, False)) is False
    assert (Try(1, True) == Try(2, True)) is False
    assert (Try(1, False) == Try(2, False)) is False



# Generated at 2022-06-24 00:20:40.189757
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    success_monad_1 = Try(1, True)
    success_monad_2 = Try(1, True)
    assert success_monad_1 == success_monad_2

    success_monad_3 = Try(2, True)
    assert not success_monad_1 == success_monad_3

    not_success_monad_1 = Try(1, False)
    assert success_monad_1 != not_success_monad_1

    success_monad_4 = Try('1', True)
    assert not success_monad_1 == success_monad_4



# Generated at 2022-06-24 00:20:43.046403
# Unit test for method map of class Try
def test_Try_map():
    # GIVEN
    try_ = Try("hello", True)
    # WHEN
    actual = try_.map(lambda x: x.upper())
    # THEN
    expected = Try("HELLO", True)
    assert actual == expected


# Generated at 2022-06-24 00:20:45.118212
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(10) == 1
    assert Try(None, False).get_or_else(10) == 10


# Generated at 2022-06-24 00:20:49.934067
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_success_callback(value):
        assert value == 'success'

    def test_fail_callback(value):
        assert type(value) == Exception

    Try.of(lambda: True, None).on_success(test_success_callback).on_fail(test_fail_callback)
    assert Try.of(lambda: False, None).on_success(test_success_callback).on_fail(test_fail_callback) == Try(False, False)

# Generated at 2022-06-24 00:20:55.549641
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda v: v % 5 == 0) == Try(10, True)
    assert Try(10, True).filter(lambda v: v % 4 == 0) == Try(10, False)
    assert Try('x', True).filter(lambda v: len(v) == 1) == Try('x', True)
    assert Try('x', True).filter(lambda v: len(v) == 2) == Try('x', False)

# Generated at 2022-06-24 00:20:56.766514
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(10, True) == Try(10, True)
    assert Try(10, True) != Try(10, False)



# Generated at 2022-06-24 00:21:01.260300
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(10, True) == Try(10, True)
    assert Try(10, False) == Try(10, False)
    assert Try(10, True) != Try('10', True)
    assert Try(10, True) != Try(10, False)
    assert Try('10', True) != Try(10, True)


# Generated at 2022-06-24 00:21:11.040949
# Unit test for method bind of class Try
def test_Try_bind():
    def _test_bind(test_case_name, fn, arguments, expected_result, expected_is_success):
        """
        For given arguments of Try.of call this method
        and compare result with expected_result and expected_is_success.

        :params test_case_name:
        :type test_case_name: String
        :params fn: function to call in Try.of
        :type fn: Function(*args) -> A
        :params arguments:
        :type arguments: List
        :params expected_result:
        :type expected_result: A
        :params expected_is_success:
        :type expected_is_success: Boolean
        :returns: None
        :rtype: None
        """
        try_ = Try.of(fn, *arguments)

# Generated at 2022-06-24 00:21:14.341191
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def some_func():
        return 'foo'

    try_one = Try.of(some_func)
    try_two = Try.of(some_func)

    assert try_one == try_one
    assert try_one == try_two
    assert try_one != Try('bar', True)


# Generated at 2022-06-24 00:21:20.928544
# Unit test for method map of class Try
def test_Try_map():
    result = Try.of(lambda: 1 + 1).map(lambda x: x * 3)
    assert result.is_success
    assert result.value == 6

    result = Try.of(lambda: 1 / 0).map(lambda x: x * 3)
    assert not result.is_success
    assert isinstance(result.value, ZeroDivisionError)


# Generated at 2022-06-24 00:21:23.599809
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    value = 'test_value'
    saved_value = None
    def save_value(x):
        nonlocal saved_value
        saved_value = x
    Try.of(lambda x: x, value).on_success(save_value)
    assert value == saved_value


# Generated at 2022-06-24 00:21:32.048819
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def fn():
        return 'fn'
    try_success = Try.of(fn)
    try_success_2 = Try.of(fn)
    try_fail = Try.of(lambda: 1 / 0)
    try_fail_2 = Try.of(lambda: 1 / 0)
    assert try_success is not try_success_2
    assert try_success == try_success_2
    assert not try_success == try_fail
    assert try_success != try_fail
    assert try_fail is not try_fail_2
    assert try_fail == try_fail_2
test_Try___eq__()


# Generated at 2022-06-24 00:21:36.244738
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(None, True) == Try(None, True)
    assert Try(ValueError(), False) == Try(ValueError(), False)

    assert Try(None, True) != Try(None, False)
    assert Try(ValueError(), False) != Try(ValueError(), True)



# Generated at 2022-06-24 00:21:40.482517
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    t1 = Try(1, True)
    assert t1.get_or_else(0) == 1

    t2 = Try(1, False)
    assert t2.get_or_else(0) == 0

# Generated at 2022-06-24 00:21:44.140034
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 1)\
        .filter(lambda x: x == 1) == Try.of(lambda x: x, 1)
    assert Try.of(lambda x: x, 1)\
        .filter(lambda x: x == 0) == Try.of(lambda x: x, 1)

# Generated at 2022-06-24 00:21:46.534767
# Unit test for method on_fail of class Try

# Generated at 2022-06-24 00:21:49.722536
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try("test-value", True).get_or_else("default-value") == "test-value"
    assert Try("test-value", False).get_or_else("default-value") == "default-value"


# Generated at 2022-06-24 00:21:52.321573
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(2, True) == Try(2, True)
    assert Try(3, False) == Try(3, False)
    assert Try(2, True) != Try(2, False)
    assert Try(2, False) != Try(3, False)
    assert Try(2, True) != Try(3, True)


# Generated at 2022-06-24 00:22:02.936386
# Unit test for constructor of class Try
def test_Try():
    t0 = Try(None, True)
    t1 = Try(None, True)
    t2 = Try(None, False)
    t3 = Try(None, False)

    assert t0 == t1
    assert t1 == t2
    assert t2 == t3

    assert t0 != t2
    assert t1 != t3

    assert str(t0) == 'Try[value=None, is_success=True]'
    assert str(t1) == 'Try[value=None, is_success=True]'
    assert str(t2) == 'Try[value=None, is_success=False]'
    assert str(t3) == 'Try[value=None, is_success=False]'

# Unit tests for static method Try.of

# Generated at 2022-06-24 00:22:09.966660
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(123, True) == Try(123, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(True, True)
    assert Try(1, False) != Try(False, False)


# Generated at 2022-06-24 00:22:11.497643
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda x: x, '1')\
        .map(lambda x: x * 2).get() == '11'
    assert not Try.of(lambda x: x, '1')\
        .map(lambda x: x * 2).is_success


# Generated at 2022-06-24 00:22:16.739544
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = '1'

    # Successful
    result = Try.of(lambda v: v, value).map(lambda v: int(v)).on_success(lambda v: v)
    assert isinstance(result, Try)
    assert result.value == 1
    assert result.is_success

    # Fail
    result = Try.of(lambda v: int(v), value).on_success(lambda v: v)
    assert isinstance(result, Try)
    assert isinstance(result.value, ValueError)
    assert not result.is_success


# Generated at 2022-06-24 00:22:19.006079
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0


# Generated at 2022-06-24 00:22:23.780144
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    >>> str(Try(12, True))
    'Try[value=12, is_success=True]'
    >>> str(Try(12, False))
    'Try[value=12, is_success=False]'
    >>> str(Try('12', True))
    'Try[value=12, is_success=True]'
    >>> str(Try('12', False))
    'Try[value=12, is_success=False]'
    """


# Generated at 2022-06-24 00:22:27.541358
# Unit test for method on_success of class Try
def test_Try_on_success():

    def success_fn(val):
        assert val == 1
        assert isinstance(val, int)

    def fail_fn(val):
        assert False

    assert Try.of(lambda: 1).on_success(success_fn) == Try(1, True)
    assert Try(1, True).on_success(success_fn) == Try(1, True)
    assert Try(1, False).on_fail(fail_fn) == Try(1, False)



# Generated at 2022-06-24 00:22:32.568778
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def fn1(x):
        return x + 2

    def fn2(x):
        return x - 2

    def fail_fn(x):
        return 1/x

    assert Try(1, True).bind(fail_fn) == Try(1, False)
    assert Try(1, True).bind(fn1).bind(fn2) == Try(1, True)
    assert Try(1, False).bind(fn1).bind(fn2) == Try(1, False)

# Generated at 2022-06-24 00:22:39.579927
# Unit test for method filter of class Try
def test_Try_filter():
    # call filter on successfully monad Try
    result = Try(10, True)\
        .filter(lambda x: x > 5)\
        .filter(lambda x: x < 15)\
        .get()
    assert result == 10
    # call filter on not successfully monad Try
    # just copy Try
    result = Try('test', False)\
        .filter(lambda x: x > 5) \
        .is_success
    assert not result
    # call filter on successfully monad Try with filterer return False
    result = Try(10, True) \
        .filter(lambda x: x > 15) \
        .is_success
    assert not result



# Generated at 2022-06-24 00:22:44.397089
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(Exception(), False).get_or_else(0) == 0



# Generated at 2022-06-24 00:22:51.550548
# Unit test for method bind of class Try
def test_Try_bind():
    def f(value):
        if value > 100:
            return Try(value, True)
        return Try(value, False)

    assert Try(200, True).bind(f) == Try(200, True)
    assert Try(200, True).bind(f) != Try(200, False)
    assert Try(200, True).bind(f) != Try(100, True)
    assert Try(100, True).bind(f) == Try(100, False)
    assert Try(100, True).bind(f) != Try(100, True)



# Generated at 2022-06-24 00:22:55.427458
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:22:57.709489
# Unit test for constructor of class Try
def test_Try():
    try_ = Try(1, True)
    assert try_.is_success == True
    assert try_.value == 1

    try_ = Try(1, False)
    assert try_.is_success == False
    assert try_.value == 1


# Generated at 2022-06-24 00:23:04.945587
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:23:11.189289
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    with pytest.raises(Exception) as e:
        def func():
            raise Exception('fail')
        actual = Try.of(func).on_fail(lambda e: print(e))
        expected = Try(Exception('fail'), False)
        assert expected == actual

# Generated at 2022-06-24 00:23:19.821404
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Given
    try_1 = Try(1, True)
    try_2 = Try(1, False)
    try_3 = Try(1, True)
    try_4 = Try(2, True)
    try_5 = Try('s', True)
    try_6 = Try(1, True)
    try_7 = Try(None, False)
    try_8 = Try(None, False)
    try_9 = Try('s', True)
    try_10 = Try(1, False)
    try_11 = Try('s', True)
    try_12 = Try('s', True)
    # When
    actual_1 = try_1 == try_2
    actual_2 = try_1 == try_3
    actual_3 = try_1 == try_4
    actual_4 = try_1

# Generated at 2022-06-24 00:23:28.785119
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 1).on_success(lambda x: x + 1).get() == 2, 'Should increase x on 1'
    assert Try.of(lambda: 1).on_success(lambda x: x + 1).on_success(lambda x: x + 1).get() == 3, 'Should increase x on 2'
    assert Try.of(lambda: 1).on_success(lambda x: None).get() == None, 'Should return None'
    assert Try.of(lambda: 1).on_success(lambda x: 1).get() == 1, 'Should return 1'
    assert Try.of(lambda: 1).on_success(lambda x: None).on_success(lambda x: x + 1).get() == None, 'Should return None'

# Generated at 2022-06-24 00:23:32.106612
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(True, True)) == 'Try[value=True, is_success=True]'
    assert str(Try(Exception("Exception"), False)) == 'Try[value=Exception("Exception"), is_success=False]'


# Generated at 2022-06-24 00:23:36.804178
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(2, True).get_or_else(1) == 2
    assert Try(2, False).get_or_else(1) == 1
    assert Try(False, True).get_or_else(True) is False
    assert Try(False, False).get_or_else(True) is True



# Generated at 2022-06-24 00:23:45.984990
# Unit test for method map of class Try
def test_Try_map():
    """
    Tests for function Try.map(mapper)
    """
    def mul(arg):
        return arg * 2
    def div(arg):
        return Try(arg / 2, True)

    check_try = Try(2, True)
    assert check_try == check_try.map(mul)

    check_try_fail = Try(2, False)
    assert check_try_fail == check_try_fail.map(mul)

    assert Try(4, True) == Try(2, True).map(mul)
    assert Try(2, False) == Try(2, False).map(mul)

    assert Try(1, True) == Try(2, True).map(div)
    assert Try(2, False) == Try(2, False).map(div)


# Generated at 2022-06-24 00:23:52.502534
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def do_on_fail(e: Exception):
        assert e.message == 'error'
        assert e.code == 1

    try:
        1/0
    except Exception as e:
        assert Try(e, False).on_fail(do_on_fail) == Try(e, False)
    print('test_Try_on_fail: PASSED')



# Generated at 2022-06-24 00:23:59.553691
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(Exception('test'), True) != Try(Exception('test'), False)
    assert Try(Exception('test1'), True) != Try(Exception('test2'), True)
    assert Try(Exception('test1'), True) != Try(Exception('test2'), False)


# Generated at 2022-06-24 00:24:07.504244
# Unit test for method map of class Try
def test_Try_map():
    to_string = lambda n: str(n)
    assert Try.of(int, '1234').map(to_string) == Try('1234', True)
    assert Try.of(int, 'not a number').map(to_string) == Try('not a number', False)
    assert Try.of(int, '1234').map(to_string).filter(lambda s: len(s) > 2) == Try('1234', True)
    assert Try.of(int, '1234').map(to_string).filter(lambda s: len(s) < 2) == Try('1234', False)


# Generated at 2022-06-24 00:24:14.113553
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    e1 = KeyError()
    e2 = TypeError()

    assert Try(e1, False) == Try(e1, False)
    assert Try(e1, True) == Try(e1, True)

    assert Try('data', True) == Try('data', True)
    assert Try('data', False) == Try('data', False)

    assert Try(e1, False) != Try(e2, False) and Try(e1, True) != Try(e2, True)

    assert Try(e1, True) != Try(e1, False) and Try(e2, True) != Try(e2, False)
    assert Try('data', True) != Try('data', False) and Try('data', True) != Try('data2', False)


# Generated at 2022-06-24 00:24:20.538321
# Unit test for method filter of class Try
def test_Try_filter():
    """
    This test test filter method of Try class.
    Test when monad is successfully and filterer return True,
    when filterer return False, when monad is not successfully.

    :returns: print test result
    :rtype: None
    """
    a = Try("", True)
    b = Try("", False)
    assert a.filter(lambda x: True) == Try("", True)
    assert a.filter(lambda x: False) == Try("", False)
    assert b.filter(lambda x: True) == Try("", False)
    print("Unit test for method filter of class Try is passed")


# Generated at 2022-06-24 00:24:24.859098
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try('1', False) == Try('1', False)
    assert Try('2', True) != Try('1', True)
    assert Try(3, False) != Try(3, True)


# Generated at 2022-06-24 00:24:32.903396
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try.
    """
    assert Try(1, True) == Try(1, True)
    assert Try(0, False) == Try(0, False)
    assert Try(1, True) != Try(0, False)
    assert Try(1, False) != Try(0, True)
    assert Try(1, True) != Try(0, True)
    assert Try(1, False) != Try(0, False)
    assert Try(1, True) != Try(1, False)



# Generated at 2022-06-24 00:24:35.429627
# Unit test for constructor of class Try
def test_Try():
    assert Try(True, True) == Try(True, True)
    assert Try('bar', False) != Try('bar', True)
    assert Try(1, True) != Try('bar', True)


# Generated at 2022-06-24 00:24:38.124754
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    t1 = Try(1, True)
    t2 = Try(1, True)
    assert t1 == t2

    t3 = Try(2, True)
    assert not t1 == t3

    t4 = Try(1, False)
    assert not t1 == t4



# Generated at 2022-06-24 00:24:42.712450
# Unit test for constructor of class Try
def test_Try():
    value = object()
    assert Try(value, True).value == value
    assert Try(value, True).is_success
    assert Try(value, False).value == value
    assert not Try(value, False).is_success



# Generated at 2022-06-24 00:24:50.850412
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Test __str__ method of class Try

    :returns: empty string when all test passed
    :rtype: str
    """
    def try_with_value_True():
        return 'Try[value=None, is_success=True]'

    def try_with_value_False():
        return 'Try[value=None, is_success=False]'

    def try_with_value_get_number():
        return 'Try[value=1, is_success=True]'

    def try_with_value_get_number_false():
        return 'Try[value=1, is_success=False]'

    def try_with_value_get_list():
        return 'Try[value=[1, 2], is_success=True]'


# Generated at 2022-06-24 00:24:55.141699
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 'A').map(lambda x: x + 'B') == Try('AB', True)

    def ex():
        raise Exception('Some error')
    assert Try.of(ex).map(lambda x: 'C') == Try(Exception('Some error'), False)


# Generated at 2022-06-24 00:25:05.256106
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    from functools import reduce

    first_try = Try.of(lambda: reduce((lambda accumulator, next_value: accumulator + next_value), [2, 3, 5]))
    second_try = Try.of(lambda: reduce((lambda accumulator, next_value: accumulator + next_value), [2, 3, 5, 5]))

    def doubler(number):
        if number is 5:
            raise Exception('Value 5 not allowed')
        return number

    result_try = first_try.bind(lambda number: Try.of(lambda: doubler(number)))

    assert result_try == Try(10, True)

    result_try = second_try.bind(lambda number: Try.of(lambda: doubler(number)))


# Generated at 2022-06-24 00:25:08.873663
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, True) == Try(1, False)



# Generated at 2022-06-24 00:25:13.794367
# Unit test for method bind of class Try
def test_Try_bind():
    def f1(x):
        return Try.of(lambda: x + 1, 18)

    def f2(x):
        return Try.of(lambda: x + 1, 'q')

    assert Try.of(f1, 17).bind(f1) == Try(19, True)
    assert Try.of(f2, 17).bind(f1) == Try('q', False)


# Generated at 2022-06-24 00:25:17.215496
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(int, '42').get() == 42
    assert Try.of(int, '42a').get() == ValueError('invalid literal for int() with base 10: \'42a\'')


# Generated at 2022-06-24 00:25:22.042600
# Unit test for method map of class Try
def test_Try_map():
    """
    Try map test
    """
    value = Try(1, True)\
        .map(lambda x: x + 1)\
        .map(lambda x: 2 * x)\
        .map(lambda x: x / 2)

    assert value == Try(3, True)

    value = Try(1, False)\
        .map(lambda x: x + 1)\
        .map(lambda x: 2 * x)\
        .map(lambda x: x / 2)

    assert value == Try(1, False)



# Generated at 2022-06-24 00:25:27.750822
# Unit test for method __str__ of class Try
def test_Try___str__():
    # Prepare
    expected_value = "Try[value=0, is_success=True]"
    try_0 = Try(0, True)

    # Execute
    actual_value = try_0.__str__()

    # Assert
    assert actual_value, expected_value


# Generated at 2022-06-24 00:25:32.626506
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda a: True) == Try(1, True)
    assert Try(1, False).on_fail(lambda a: True) == Try(1, False)
    assert Try(1, True).on_fail(lambda a: False) == Try(1, True)
    assert Try(1, False).on_fail(lambda a: False) == Try(1, False)


# Generated at 2022-06-24 00:25:35.359399
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    value = 1
    is_success = True
    t1 = Try(value, is_success)
    t2 = Try(value, is_success)
    assert t1 == t2



# Generated at 2022-06-24 00:25:37.497329
# Unit test for method get of class Try
def test_Try_get():
    string_value = "Test string value"
    # Check that method get return expected value
    assert Try.of(lambda: string_value, ).get() == string_value



# Generated at 2022-06-24 00:25:40.715623
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try.
    """
    assert(Try(1, True).get_or_else(0) == 1)
    assert(Try(None, False).get_or_else(1) == 1)


# Generated at 2022-06-24 00:25:44.549667
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test for method map of class Try.
    """
    assert Try.of(lambda x: x + 1, 1).map(lambda x: x * 2) == Try(4, True)
    assert Try.of(lambda x: x + 1, 1).map(lambda x: x / 0) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:25:46.119689
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-24 00:25:48.569588
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(-1) == 1
    assert Try(1, False).get_or_else(-1) == -1



# Generated at 2022-06-24 00:25:58.613606
# Unit test for method on_success of class Try
def test_Try_on_success():
    # pylint: disable=W0612
    # I want to use vars as global variables to test
    vars = []
    def callback(arg):
        vars.append(arg)
    def exception_callback(arg):
        vars.append(arg)
    assert Try(5, True).on_success(callback).get() == 5
    assert vars == [5]
    assert Try(5, False).on_success(callback).get() == 5
    assert vars == [5]
    assert Try(Exception('test'), True).on_success(exception_callback).get() is None
    assert vars == [5]
    assert Try(Exception('test'), False).on_success(exception_callback).get() == 'test'
    assert vars == [5, 'test']


# Generated at 2022-06-24 00:26:02.219987
# Unit test for method bind of class Try
def test_Try_bind():
    def f(x):
        return Try(x + 1, True)

    assert Try.of(Try, 1).bind(f) == Try(2, True)
    assert Try.of(Try, 1).bind(lambda _: Try(2, False)).bind(f) == Try(2, False)



# Generated at 2022-06-24 00:26:07.411898
# Unit test for method __str__ of class Try
def test_Try___str__():
    def fn(num):
        return num

    assert str(Try.of(fn, 1)) == 'Try[value=1, is_success=True]'
    assert str(Try.of(fn, ValueError(1))) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:26:10.841181
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception('test'), False) == Try(Exception('test'), False)
    assert Try(1, True) != Try(2, True)



# Generated at 2022-06-24 00:26:14.691014
# Unit test for constructor of class Try
def test_Try():
    #  type: () -> None
    """
    Test constructor of class Try.
    Monad is successfully without any error.
    """
    result = Try(value="safe value", is_success=True)
    assert result == Try(value="safe value", is_success=True)
    assert result.is_success is True


# Generated at 2022-06-24 00:26:16.844430
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, False) == Try(None, False)
    assert Try("None", False) != Try("None", True)
    assert Try("None", True) != Try("None", False)


# Generated at 2022-06-24 00:26:19.180098
# Unit test for method get of class Try
def test_Try_get():
    monad_value = Try(42, True)
    assert monad_value.get() == 42
    monad_value = Try(None, False)
    assert monad_value.get() is None


# Generated at 2022-06-24 00:26:21.622737
# Unit test for constructor of class Try
def test_Try():
    assert Try(123, True) == Try(123, True)
    assert Try(123, False) == Try(123, False)
    assert Try(123, True) != Try(123, False)
    assert Try(234, False) != Try(123, False)
    assert Try(234, True) != Try(123, False)


# Generated at 2022-06-24 00:26:24.245651
# Unit test for method map of class Try
def test_Try_map():
    def square(x): return x * x
    def double(x): return x * 2
    assert Try.of(square, 2).map(double) == Try(8, True)
    assert Try.of(square, '2').map(double) == Try(2, False)



# Generated at 2022-06-24 00:26:32.761479
# Unit test for method map of class Try
def test_Try_map():
    assert Try('foo', True)\
        .map(lambda x: x.upper())\
        == Try('FOO', True)

    assert Try(42, True)\
        .map(lambda x: x+1)\
        == Try(43, True)

    assert Try(42, True)\
        .map(lambda x: x+1)\
        != Try(43, False)

    assert Try(42, False)\
        .map(lambda x: x+1)\
        == Try(42, False)

    assert Try(42, False)\
        .map(lambda x: x+1)\
        != Try('foo', False)



# Generated at 2022-06-24 00:26:35.670808
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def func(num):
        return num / 0

    def fail(exception):
        raise AssertionError(exception)

    Try.of(func, 10).on_fail(fail)



# Generated at 2022-06-24 00:26:39.277839
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, False)


# Generated at 2022-06-24 00:26:41.455630
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x)).get() == 1
    assert Try(Exception('Hi'), False).on_success(lambda x: print(x)).get() == Exception('Hi')


# Generated at 2022-06-24 00:26:42.791938
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1).bind(lambda value: Try.of(lambda: value + 2)).get() == 3



# Generated at 2022-06-24 00:26:50.154718
# Unit test for constructor of class Try
def test_Try():
    assert(Try(1, True) == Try(1, True))
    assert(Try(1, True) != Try(1, False))
    assert(Try(1, False) != Try(2, False))
    assert(str(Try(1, True)) == 'Try[value=1, is_success=True]')
    assert(Try(1, False).get() == 1)
    assert(Try(1, True).get() == 1)
    assert(Try(1, True).get_or_else(0) == 1)
    assert(Try(1, False).get_or_else(0) == 0)

# Generated at 2022-06-24 00:26:58.999566
# Unit test for method bind of class Try
def test_Try_bind():
    """
    >>> test_Try_bind()
    True
    """
    add_on_5 = lambda v: Try.of(lambda x: x + 5, v)
    add1_on5 = lambda v: Try.of(lambda x: x + 1, v)
    is_even = lambda v: Try.of(lambda x: x % 2 == 0, v)

    # Apply Try.bind(add_on_5).bind(add1_on5).bind(is_even) on successfully Try
    result = Try(13, True)\
        .bind(add_on_5)\
        .bind(add1_on5)\
        .bind(is_even)

    # Check result is Try and result Try is successfully
    if result.is_success and result == Try(False, True):
        print(True)

# Generated at 2022-06-24 00:27:01.287717
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, True) == Try(1, False)



# Generated at 2022-06-24 00:27:05.590528
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try.
    """
    assert Try(1, True) == Try(1, True), 'Should be true'
    assert Try(1, False) != Try(1, True), 'Should be true'
    assert Try(2, False) != Try(1, True), 'Should be true'
    assert Try(1, True) != Try(2, True), 'Should be true'
    assert Try(3, True) != Try(2, True), 'Should be true'


# Generated at 2022-06-24 00:27:10.991007
# Unit test for method bind of class Try
def test_Try_bind():
    def add(value: int) -> int:
        return value + 5

    # Successfully Try
    assert Try(5, True).bind(lambda x: Try(add(x), True)) == Try(10, True)

    # Not successfully Try
    assert Try(5, False).bind(lambda x: Try(add(x), True)) == Try(5, False)



# Generated at 2022-06-24 00:27:17.821852
# Unit test for method bind of class Try
def test_Try_bind():
    def run_test(test_name, params_fn, params_args, expected_result):
        try:
            assert expected_result == Try.of(*params_fn(*params_args)).bind(lambda x: Try(x + 1, True))
            print(test_name + " passed")
        except AssertionError:
            print(test_name + " failed")

    run_test("test_Try_bind_1", lambda x: (x + 1, x), 1, Try(2, True))
    run_test("test_Try_bind_2", lambda x: (x + 1, x), 1, Try(3, True))



# Generated at 2022-06-24 00:27:24.086777
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Method filter must return copy of monad when monad is successfully and filterer returns True,
    othercase return not successfully Try with previous value.
    """
    successful_Try = Try(True, True)
    result = successful_Try.filter(lambda value: True)
    assert result == successful_Try

    result = successful_Try.filter(lambda value: False)

    assert result == Try(True, False)

    result = successful_Try.filter(lambda value: False)

    assert result == Try(True, False)


# Generated at 2022-06-24 00:27:31.948610
# Unit test for method get of class Try
def test_Try_get():
    # Given
    some_value = 'some value'
    some_exception = Exception('some exception')
    t0 = Try(some_value, True)
    t1 = Try(some_value, False)
    t2 = Try(some_exception, False)
    # When
    value0 = t0.get()
    value1 = t1.get()
    value2 = t2.get()
    # Then
    assert value0 == some_value
    assert value1 == some_value
    assert value2 == some_exception



# Generated at 2022-06-24 00:27:35.541294
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(5, True).get_or_else(3) == 5
    assert Try(5, False).get_or_else(3) == 3


# Generated at 2022-06-24 00:27:37.020531
# Unit test for constructor of class Try
def test_Try():
    with pytest.raises(TypeError):  # Test parameters from constructor
        Try(1, 1)



# Generated at 2022-06-24 00:27:40.054877
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 42).on_fail(lambda _: print('Exception!')) == Try(42, True)
    assert Try.of(lambda: int('a')).on_fail(lambda _: print('Exception!')) == Try(ValueError(), False)


# Generated at 2022-06-24 00:27:42.869965
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try("expected_value", True).get_or_else("default_value") == "expected_value"
    assert Try("not_expected_value", False).get_or_else("default_value") == "default_value"



# Generated at 2022-06-24 00:27:47.125311
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 1/0).on_fail(lambda _: print('error')) ==\
           Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(lambda: 1/0).on_fail(lambda _: print('error')).on_fail(lambda _: print('error again')) ==\
           Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-24 00:27:50.873537
# Unit test for method bind of class Try
def test_Try_bind():
    def _test():
        return 1
    assert Try.of(_test).bind(lambda x: Try(x, False)).value == 1
    assert not Try.of(_test).bind(lambda x: Try(x, False)).is_success
    assert Try.of(_test).bind(lambda x: Try(x, True)).value == 1
    assert Try.of(_test).bind(lambda x: Try(x, True)).is_success


# Generated at 2022-06-24 00:27:54.625204
# Unit test for method __str__ of class Try
def test_Try___str__():
    actual = Try(2, True)
    expected = "Try[value=2, is_success=True]"
    assert str(actual) == expected



# Generated at 2022-06-24 00:27:57.185757
# Unit test for method get of class Try
def test_Try_get():
    """ Test case for test_Try_get method """
    value = 'a'
    tryy = Try(value, True)
    assert tryy.get() == value


# Generated at 2022-06-24 00:28:02.437764
# Unit test for method map of class Try
def test_Try_map():
    # set up
    result = Try.of(int, '42')

    # Call method
    mapped = result.map(lambda x: x ** 2)

    # assertion
    assert mapped == Try(1764, True)

    # set up
    result = Try.of(float, '42')

    # Call method
    mapped = result.map(lambda x: x ** 2)

    # assertion
    assert mapped == Try(1764.0, True)



# Generated at 2022-06-24 00:28:04.042703
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:28:07.157000
# Unit test for constructor of class Try
def test_Try():
    try_ = Try(1, True)
    assert(try_.is_success == True)
    assert(try_.value == 1)


# Generated at 2022-06-24 00:28:13.322790
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)

    # Check __str__
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-24 00:28:17.126921
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_success_callback(value):
        assert value == 1
    assert Try.of(lambda: 1, []).on_success(test_success_callback) is not None


# Generated at 2022-06-24 00:28:24.802282
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-24 00:28:29.444457
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Define unit test for method Try.__str__().
    """
    assert str(Try(1, True)) == "Try[value=1, is_success=True]",\
        "Try.__str__() does not work"
    assert str(Try(2, False)) == "Try[value=2, is_success=False]",\
        "Try.__str__() does not work"


# Generated at 2022-06-24 00:28:31.987331
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-24 00:28:35.718033
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def test_method(value, expected):
        try_value = Try.of(lambda x: x, value)
        try_result = Try.of(lambda x: x + '1', expected)
        assert try_result == try_value.map(lambda x: x + '1')

    test_method('1', '11')


# Generated at 2022-06-24 00:28:41.818112
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test case for Try.on_fail method
    """
    assert Try(1, True).on_fail(lambda x: print(x)) == Try(1, True)
    assert Try(1, True).on_fail(lambda x: print(x)).value == 1
    assert Try(1, False).on_fail(lambda x: print(x)).value == 1
