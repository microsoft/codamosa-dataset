

# Generated at 2022-06-24 00:18:47.621683
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(True, True)) == 'Try[value=True, is_success=True]'
    assert str(Try(False, False)) == 'Try[value=False, is_success=False]'


# Generated at 2022-06-24 00:18:55.510751
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    try_one = Try(1, True)
    try_two = Try(2, True)
    try_one_not_successful = Try(1, False)
    try_two_not_successful = Try(1, False)
    assert try_one == try_one
    assert try_one_not_successful == try_two_not_successful
    assert try_one != try_two
    assert try_one_not_successful != try_one
    print('test_Try___eq__')


# Generated at 2022-06-24 00:18:59.121076
# Unit test for method bind of class Try
def test_Try_bind():
    t_fail = Try(1, False)
    t_success = Try(2, True)

    def foo(n):
        return Try(n+1, True)

    assert t_fail.bind(foo) == t_fail
    assert t_success.bind(foo) == foo(2)



# Generated at 2022-06-24 00:19:02.643978
# Unit test for method map of class Try
def test_Try_map():
    t1 = Try.of(lambda x: x * 33, 18)
    assert t1.map(lambda x: x // 2) == Try(594, True)
    t2 = Try.of(lambda x: x * 33, "dsd")
    assert t2.map(lambda x: x // 2) == Try("dsd", False)


# Generated at 2022-06-24 00:19:04.469905
# Unit test for method on_success of class Try
def test_Try_on_success():
    result = Try.of(lambda x: x + x, 10)
    result.on_success(lambda x: print(x))
    assert result == Try(20, True)


# Generated at 2022-06-24 00:19:07.230376
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    obj = Try(123, True)
    assert str(obj) == 'Try[value=123, is_success=True]'

    obj = Try('test', False)
    assert str(obj) == 'Try[value=test, is_success=False]'



# Generated at 2022-06-24 00:19:16.732841
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try('foo', True) == Try('foo', True)
    assert Try('foo', False) == Try('foo', False)
    assert not Try('foo', True) == Try('foo', False)
    assert not Try('foo', False) == Try('foo', True)
    assert not Try('foo', True) == Try('bar', True)
    assert not Try('foo', False) == Try('bar', False)
    assert not Try('foo', True) == Try('bar', False)
    assert not Try('foo', False) == Try('bar', True)


# Generated at 2022-06-24 00:19:20.556240
# Unit test for method bind of class Try
def test_Try_bind():
    def multiply(x):
        return lambda y: y * x

    def add(x):
        return lambda y: y + x

    value = Try.of(add(5), 2) \
        .bind(multiply(2)) \
        .get()

    assert value == 14


# Generated at 2022-06-24 00:19:23.327915
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    t = Try(42, True)
    assert t == Try(42, True)


# Generated at 2022-06-24 00:19:24.683593
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, True) == Try(None, True)



# Generated at 2022-06-24 00:19:27.359181
# Unit test for method get of class Try
def test_Try_get():
    try_value = Try(42, True)
    assert try_value.get() == 42

    try_value = Try('42', False)
    assert try_value.get() == '42'


# Generated at 2022-06-24 00:19:32.725455
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(42, True) == Try(42, True)
    assert Try(42, False) == Try(42, False)
    assert Try(42, True) != Try(42, False)
    assert Try(42, False) != Try(42, True)
    assert Try(42, True) != Try(0, True)
    assert Try(42, False) != Try(0, False)



# Generated at 2022-06-24 00:19:37.173677
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try('a', True).get_or_else('b') == 'a'
    assert Try('a', False).get_or_else('b') == 'b'


# Generated at 2022-06-24 00:19:39.012855
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 'value', 1).get() == 'value'
    assert Try.of(lambda: 1, 1).get() == 1


# Generated at 2022-06-24 00:19:41.955259
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(None, False).on_success(lambda _: 1) == Try(None, False)
    assert Try(None, True).on_success(lambda _: 1) == Try(None, True)


# Generated at 2022-06-24 00:19:45.418997
# Unit test for method __str__ of class Try
def test_Try___str__():
    expected = 'Try[value=True, is_success=True]'
    actual = str(Try(True, True))
    assert expected == actual


# Generated at 2022-06-24 00:19:49.450162
# Unit test for method map of class Try
def test_Try_map():
    """
    Test Try.map method
    """
    assert Try.of(1).map(lambda value: value + 1) == Try(2, True)
    try:
        assert Try.of(raise_exception).map(lambda _: 1) == Try(1, True)
    except AssertionError:
        assert True



# Generated at 2022-06-24 00:19:52.846506
# Unit test for method get of class Try
def test_Try_get():
    assert Try(3, True).get() == 3
    assert Try(3, False).get() == 3


# Generated at 2022-06-24 00:19:53.894985
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert '' == Try(None, True).__str__()


# Generated at 2022-06-24 00:19:57.758395
# Unit test for method map of class Try
def test_Try_map():
    try_fn = Try.of(lambda a, b: a / b, 4, 2)
    assert try_fn.map(lambda x: x * 2).get() == 4
    assert try_fn.map(lambda x: x * 3).get() == 6



# Generated at 2022-06-24 00:20:00.139491
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(1, True).get() == 1
    assert Try(Exception, False).get() == Exception


# Generated at 2022-06-24 00:20:08.065492
# Unit test for method on_success of class Try
def test_Try_on_success():
    # GIVEN
    def create_palindrome(string):
        string += string[::-1]
        return string

    def on_success(palindrome):
        print("My palindrome is {}".format(palindrome))

    def on_fail(exception):
        print("Smth gone wrong: {}".format(exception))

    # WHEN
    result = Try.of(create_palindrome, "qwerty").on_success(on_success).on_fail(on_fail)
    # THEN
    assert result == Try("qwertyytrewq", True)


# Generated at 2022-06-24 00:20:13.738310
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(2, True) == Try(2, True)
    assert Try(3, False) == Try(3, False)
    assert Try(3, False) != Try(3, True)
    assert Try(2, True) != Try(2, False)
    assert Try(2, True) != 2
    assert Try(2, True) != None
    assert Try(None, False) != None
    assert Try(None, False) == Try(None, False)


# Generated at 2022-06-24 00:20:20.972797
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(1, True)
    try_2 = Try(2, True)
    try_3 = Try(3, False)
    try_4 = Try(1, False)
    try_5 = Try(1, True)
    assert try_1 == try_1
    assert try_1 != try_2
    assert try_1 != try_3
    assert try_1 != try_4
    assert try_1 == try_5


# Generated at 2022-06-24 00:20:22.832338
# Unit test for method get of class Try
def test_Try_get():
    try_success = Try(1, True)
    assert try_success.get() == 1

    try_fail = Try(1, False)
    assert try_fail.get() == 1


# Generated at 2022-06-24 00:20:31.103026
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        # type: (str) -> None
        assert isinstance(value, str)
        assert value == 'hello world'

    def fail_callback(value):
        # type: (Exception) -> None
        assert False

    Try('hello world', True).on_success(success_callback).on_fail(fail_callback)
    Try('hello world', False).on_success(success_callback).on_fail(fail_callback)


# Generated at 2022-06-24 00:20:35.443021
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try.
    """
    assert Try('value', True).get_or_else('') == 'value'
    assert Try('', False).get_or_else('value') == 'value'


# Generated at 2022-06-24 00:20:39.701432
# Unit test for method get of class Try
def test_Try_get():
    assert Try(42, True).get() == 42
    assert Try(42, False).get() == 42


# Generated at 2022-06-24 00:20:42.370617
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try('test', False)) == 'Try[value=test, is_success=False]'


# Generated at 2022-06-24 00:20:46.623913
# Unit test for method on_success of class Try
def test_Try_on_success():
    def successful(value):
        assert value == 1
    def fail(value):
        assert False
    Try(1, True).on_success(successful)
    Try(1, False).on_success(fail)


# Generated at 2022-06-24 00:20:51.061880
# Unit test for constructor of class Try
def test_Try():
    assert Try(4, True) == Try(4, True)
    assert Try(4, False) == Try(4, False)
    assert Try(1, True) != Try(0, True)
    assert Try(1, False) != Try(0, False)
    assert Try(1, True) != Try(1, False)
    assert Try(0, False) != Try(1, False)


# Generated at 2022-06-24 00:20:56.400060
# Unit test for constructor of class Try
def test_Try():
    """
    Unit test for constructor of class Try
    """
    value = 5
    assert Try(value, True) == Try(value, True)
    assert Try(value, True) == Try(value, True)


# Generated at 2022-06-24 00:21:00.020146
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-24 00:21:03.906655
# Unit test for method on_success of class Try

# Generated at 2022-06-24 00:21:14.796153
# Unit test for method bind of class Try
def test_Try_bind():
    class A:
        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    try_z = Try.of(lambda: 1)
    assert try_z.is_success

    try_z = Try.of(lambda: 1/0)
    assert not try_z.is_success

    try_z = Try.of(lambda: 1/0).bind(lambda x: Try.of(lambda: 2//x))
    assert not try_z.is_success

    try_z = Try.of(lambda: 1/0).bind(lambda x: Try.of(lambda: 2//x)).bind(lambda x: Try.of(lambda: x+1))
    assert not try_z.is_success

    try_z = Try.of(lambda: 1).bind

# Generated at 2022-06-24 00:21:17.227284
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(1, True).get() == 1


# Generated at 2022-06-24 00:21:20.570275
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(15, True) == Try(15, True)



# Generated at 2022-06-24 00:21:22.625398
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    try_success = Try(1, True)
    assert try_success.value == 1
    assert try_success.is_success

    try_fail = Try(Exception("Exception text"), False)
    assert try_fail.value.args[0] == "Exception text"
    assert not try_fail.is_success



# Generated at 2022-06-24 00:21:24.037391
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(int, "1")\
        .map(lambda x: x+1)\
        .equals(Try.of(int, "1").bind(lambda x: Try(x+1, True)))



# Generated at 2022-06-24 00:21:34.098764
# Unit test for method map of class Try
def test_Try_map():
    # GIVEN
    def div_ten(number: int) -> int:
        return number // 10

    # WHEN
    wrapped_value: Try[int] = Try(10, True) # no exception
    mapped_value: Try[int] = wrapped_value.map(div_ten)

    error_value: Try[int] = Try(10, False) # exception
    mapped_error_value: Try[int] = error_value.map(div_ten)

    # THEN
    assert mapped_value == Try(1, True)
    assert mapped_error_value == Try(10, False)



# Generated at 2022-06-24 00:21:36.376814
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)



# Generated at 2022-06-24 00:21:41.396924
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 2) == Try(3, True)
    assert Try(1, False).map(lambda x: x + 2) == Try(1, False)


# Generated at 2022-06-24 00:21:49.274111
# Unit test for method map of class Try
def test_Try_map():
    def exception_fn():
        raise Exception('value')

    def echo_fn(value):
        return value

    def plus_fn(value):
        return value + 1

    assert Try.of(exception_fn).map(echo_fn) == Try.of(echo_fn)(Exception('value'))
    assert Try.of(echo_fn)('value').map(plus_fn) == Try('value1', True)
    assert Try.of(echo_fn)('value').map(exception_fn) == Try(Exception('value'), False)



# Generated at 2022-06-24 00:21:51.307097
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(int, '42').get() == 42
    assert Try.of(int, 'foo').get() == 'foo'



# Generated at 2022-06-24 00:21:56.241292
# Unit test for method filter of class Try
def test_Try_filter():
    # arrange
    fn = Try.of(int, '1')

    # act
    fn2 = fn.filter(lambda v: v < 1)
    fn3 = fn.filter(lambda v: 1 < v)
    fn4 = Try.of(int, 'a').filter(lambda v: v < 1)
    fn5 = Try.of(int, 'a').filter(lambda v: 1 < v)

    # assert
    assert fn2 == Try(1, False)
    assert fn3 == Try(1, True)
    assert fn4 == Try(ValueError(), False)
    assert fn5 == Try(ValueError(), False)


# Generated at 2022-06-24 00:22:01.631140
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else('n.a.') == 42
    assert isinstance(Try(42, True).get_or_else('n.a.'), int)
    assert Try(None, False).get_or_else('n.a.') == 'n.a.'
    assert isinstance(Try(None, False).get_or_else('n.a.'), str)


# Generated at 2022-06-24 00:22:04.792947
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_true = Try(100500, True)
    try_false = Try(ValueError('test'), False)

    assert str(try_true) == 'Try[value=100500, is_success=True]'
    assert str(try_false) == 'Try[value=test, is_success=False]'


# Generated at 2022-06-24 00:22:13.355089
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Run unit test for method on_fail of class Try.
    """
    import pytest
    exception = Exception('error')
    try_error = Try(exception, False)
    try_error = try_error.on_fail(lambda value: pytest.fail(
        'Fail with {}, expected {}'.format(value, exception)))
    assert isinstance(try_error, Try) and try_error.is_success is False
    try_error = Try(exception, True)
    try_error = try_error.on_fail(lambda value: pytest.fail(
        'Fail with {}, expected {}'.format(value, exception)))
    assert isinstance(try_error, Try) and try_error.is_success is True


# Generated at 2022-06-24 00:22:16.541024
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(2, True) == Try(2, True)
    assert Try(2, False) == Try(2, False)
    assert Try(2, True) != Try(1, True)
    assert Try(2, False) != Try(2, True)
    assert Try(2, True) != Try(1, False)



# Generated at 2022-06-24 00:22:18.281201
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2
    assert Try(2, False).get() == 2


# Generated at 2022-06-24 00:22:22.763680
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x)).is_success
    assert not Try(Exception, False).on_success(lambda x: print(x)).is_success



# Generated at 2022-06-24 00:22:24.639747
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True).get() == 1
    assert Try(Exception('error'), False).get() is not None


# Generated at 2022-06-24 00:22:26.251401
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 'foo', None).get() == 'foo'
    assert not Try.of(lambda: 1 / 0, None).get()



# Generated at 2022-06-24 00:22:30.355004
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 3, 3).get() == 3



# Generated at 2022-06-24 00:22:33.366756
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1 + 1, None).get_or_else("Failed") == 2
    assert Try.of(lambda: 1 / 0, None).get_or_else("Failed") == "Failed"



# Generated at 2022-06-24 00:22:34.694073
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1).get() == 1
    assert Try.of(lambda: 2, 1).get() == 2


# Generated at 2022-06-24 00:22:40.501684
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 2).map(lambda x: x * 2) == Try(4, True)
    assert Try.of(lambda: 2).map(lambda x: x / 0) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-24 00:22:45.647952
# Unit test for constructor of class Try
def test_Try():
    assert Try("value", False) == Try("value", False)
    assert Try("value", False) != Try("value", True)
    assert Try("value", False) != Try("other value", False)


# Generated at 2022-06-24 00:22:49.232419
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(12, True)) == 'Try[value=12, is_success=True]'
    assert str(Try(13, False)) == 'Try[value=13, is_success=False]'


# Generated at 2022-06-24 00:22:51.287746
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-24 00:22:53.554893
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Given
    a = 3
    b = 4
    sum_fn = lambda x, y: x + y

    # When
    sum_result = Try.of(sum_fn, a, b).on_fail(print)
    is_same = sum_result == Try(7, True)

    # Then
    assert is_same

# Generated at 2022-06-24 00:22:56.323957
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1).get_or_else(None) == 1
    assert Try.of(lambda: 1 / 0).get_or_else(None) is None


# Generated at 2022-06-24 00:23:00.685872
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def no_empty(val):
        return len(val) > 0

    assert Try.of(lambda: "123").filter(no_empty) == Try("123", True)
    assert Try.of(lambda: "").filter(no_empty) == Try("", False)
    assert Try.of(lambda: 123).filter(no_empty) == Try(123, True)



# Generated at 2022-06-24 00:23:07.300266
# Unit test for method bind of class Try
def test_Try_bind():
    # Check for number in range 1-100
    def check_number(x):
        if 0 < x < 100:
            return Try.of(lambda: x)
        return Try.of(lambda: Exception('Not in range 1-100'))

    # Increment number by one
    def inc_i(x):
        return Try.of(lambda: x + 1)

    # Check that i is even
    def check_even(x):
        if x % 2 == 0:
            return Try.of(lambda: x)
        return Try.of(lambda: Exception('Not even'))

    # Check that i is odd
    def check_odd(x):
        if x % 2 != 0:
            return Try.of(lambda: x)
        return Try.of(lambda: Exception('Not odd'))

    # Increment three


# Generated at 2022-06-24 00:23:14.430183
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Unit test for method on_fail of class Try.
    """
    def func():
        1 / 0

    def fail_callback(value: Exception):
        assert value is not None
        assert isinstance(value, ZeroDivisionError)

    try_monad = Try.of(func)
    assert try_monad.is_success == False
    on_fail_result = try_monad.on_fail(fail_callback)
    assert try_monad is on_fail_result

if __name__ == '__main__':
    test_Try_on_fail()

# Generated at 2022-06-24 00:23:20.429297
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def foo(i):
        return Try(i+10, True)

    import pytest
    assert Try.of(lambda _: 12, None).bind(foo) == foo(12)
    assert Try.of(lambda j: j, 100).bind(foo) == foo(100)
    assert Try.of(lambda _: 12, None).bind(foo).bind(foo) == foo(12).bind(foo)
    assert Try.of(lambda _: 12, None).bind(foo).bind(foo).bind(foo) == foo(12).bind(foo).bind(foo)
    assert Try.of(lambda _: 12, None).get() == 12
    assert Try.of(lambda _: 12, None).bind(foo).get() == 22

# Generated at 2022-06-24 00:23:24.250533
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    result = 1
    @try_monad(Try)
    def test_function():
        raise Exception()

    @try_monad(Try)
    def test_function2():
        return 1

    test_function().on_fail(lambda x: print(x)).on_success(lambda x: print(x, x))
    assert result == 1

    test_function2().on_fail(lambda x: print(x)).on_success(lambda x: print(x, x))
    assert result == 1


# Generated at 2022-06-24 00:23:26.390531
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(None, False).get_or_else('default') == 'default'
    assert Try(None, True).get_or_else('default') is None



# Generated at 2022-06-24 00:23:27.623979
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-24 00:23:29.788781
# Unit test for method get of class Try
def test_Try_get():
    number = Try.of(int, '1')
    assert number.get() == 1
    assert number.get() != '1'


# Generated at 2022-06-24 00:23:38.264378
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.

    :returns: AssertionError when method filter not work as desired.
    :rtype: AssertionError
    """
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 0).get() == 1
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 0).get() == 1
    assert Try.of(lambda x: x, 1).filter(lambda x: x < 0).get() == 1
    assert Try.of(lambda x: x / 0, 1).filter(lambda x: x == 0).value == 1


# Generated at 2022-06-24 00:23:39.726751
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(42, True) == Try(42, True)



# Generated at 2022-06-24 00:23:46.554030
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def add(a, b):
        return a + b

    def square(a):
        return a ** 2

    try_success: Try[int] = Try(add(2, 3), True)
    assert try_success.map(square) == Try(25, True)

    try_fail: Try[Exception] = Try(Exception('Not successfully'), False)
    assert try_fail.map(square) == Try(Exception('Not successfully'), False)


# Generated at 2022-06-24 00:23:54.811315
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Test for method __str__ of class Try.
    """
    assert str(Try(True, True)) == 'Try[value=True, is_success=True]'
    assert str(Try(False, False)) == 'Try[value=False, is_success=False]'
    assert str(Try('True', True)) == "Try[value=True, is_success=True]"
    assert str(Try('False', False)) == "Try[value=False, is_success=False]"
    assert str(Try(Exception(), False)) == "Try[value=Exception(), is_success=False]"


# Generated at 2022-06-24 00:23:58.813265
# Unit test for method on_success of class Try
def test_Try_on_success():
    # Test with successfully
    assert(Try(2, True).on_success(lambda x: x * 2) == Try(2, True))
    # Test with not successfully
    assert(Try(2, False).on_success(lambda x: x * 2) == Try(2, False))


# Generated at 2022-06-24 00:24:02.529696
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        raise Exception('test')
    except Exception as e:
        monad = Try(e, False)
        result = monad.on_fail(lambda x: print(x))
    assert result == monad


# Generated at 2022-06-24 00:24:06.705331
# Unit test for method get of class Try
def test_Try_get():
    """
    Test method get of class Try.

    :returns: None
    :rtype: None
    """
    assert Try('a', True).get() == 'a'
    assert Try(1, True).get() == 1
    assert Try([1, 2, 3], True).get() == [1, 2, 3]



# Generated at 2022-06-24 00:24:09.516931
# Unit test for method map of class Try
def test_Try_map():
    result = Try(1, True).map(lambda x: x * 2)
    assert result == Try(2, True)
    assert Try(1, False).map(lambda x: x * 2) == Try(1, False)

test_Try_map()


# Generated at 2022-06-24 00:24:12.562031
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(123, True) == Try(123, True)
    assert Try(123, True) != Try(123, False)
    assert Try(123, False) != Try(456, True)
    assert Try(123, False) != Try(456, False)


# Generated at 2022-06-24 00:24:16.783008
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(10, True).get_or_else(11) == 10
    assert Try(10, False).get_or_else(11) == 11

# Generated at 2022-06-24 00:24:22.346422
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(v):
        return v > 0

    assert Try(0, True).filter(filterer).is_success == False
    assert Try(0, True).filter(filterer).value == 0
    assert Try(1, True).filter(filterer).is_success == True
    assert Try(1, True).filter(filterer).value == 1

    assert Try(0, False).filter(filterer).is_success == False
    assert Try(0, False).filter(filterer).value == 0
    assert Try(1, False).filter(filterer).is_success == False
    assert Try(1, False).filter(filterer).value == 1


# Generated at 2022-06-24 00:24:25.756762
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try('1', False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:24:27.112938
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-24 00:24:30.120539
# Unit test for method get of class Try
def test_Try_get():
    try_monad = Try.of(lambda: 1, 1)
    assert try_monad.get() == 1


# Generated at 2022-06-24 00:24:32.729544
# Unit test for method __str__ of class Try
def test_Try___str__():

    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-24 00:24:40.133354
# Unit test for method map of class Try
def test_Try_map():
    # Test for Try.of
    assert Try.of(lambda x: x * x, 2) == Try(4, True)
    assert Try.of(lambda x, y: x * y, 2, 5) == Try(10, True)
    assert Try.of(lambda: 1 / 0) == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(2) == Try(TypeError('of() takes 1 positional argument but 2 were given'), False)
    assert Try.of('') == Try(TypeError('unsupported operand type(s) for /: \'str\' and \'int\''), False)

    # Test for mapping value
    assert Try.of(lambda x: x * x, 5).map(lambda x: x + 2) == Try(27, True)

# Generated at 2022-06-24 00:24:47.826533
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover

    # GIVEN
    is_success = False
    value = 'Value'
    default_value = 'Default value'

    # WHEN
    try_result = Try(value, is_success)

    # THEN
    assert try_result.get_or_else(default_value) == default_value

    # GIVEN
    is_success = True

    # WHEN
    try_result = Try(value, is_success)

    # THEN
    assert try_result.get_or_else(default_value) == value



# Generated at 2022-06-24 00:24:49.915374
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10


# Generated at 2022-06-24 00:24:59.006818
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1, ).get() == 1
    assert Try.of(lambda: [], ).get() == []
    assert Try.of(lambda: {}, ).get() == {}
    assert Try.of(lambda: '', ).get() == ''
    assert Try.of(lambda: tuple(), ).get() == tuple()
    assert Try.of(lambda: float(2), ).get() == 2.0
    assert Try.of(lambda: complex(2, 2), ).get() == 2.0 + 2.0j
    assert Try.of(lambda: {'key': 'value'}, ).get() == {'key': 'value'}

    def test_try():
        raise Exception()
    assert Try.of(test_try, ).get() is None


# Generated at 2022-06-24 00:25:05.296289
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, False) == Try(1, False)
    assert Try(2, True) == Try(2, True)

    assert Try(1, False) != Try(1, True)
    assert Try(2, False) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(2, True) != Try(1, True)



# Generated at 2022-06-24 00:25:09.781852
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x % 2 == 0

    m = Try(2, True)
    assert m == m.filter(filterer)

    m = Try(3, True)
    assert not m == m.filter(filterer)



# Generated at 2022-06-24 00:25:13.021839
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value < 10

    assert(Try(0, True).filter(filterer) == Try(0, True))
    assert(Try(10, True).filter(filterer) == Try(10, False))

# Generated at 2022-06-24 00:25:17.340211
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test get_or_else method.
    """
    val = 'test'
    assert Try.of(lambda: 1).get_or_else(0) == 1
    assert Try.of(lambda: 4/0).get_or_else(val) == val

# Generated at 2022-06-24 00:25:22.095671
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def double(x):
        return x * 2

    assert Try.of(double, 2).map(double) == Try(8, True)
    assert Try.of(double, 'a').map(double) == Try('a', False)
    assert Try.of(double, 2).map(double).map(lambda x: x * 15) == Try(120, True)
    assert Try.of(double, 2).map(double).map(lambda x: x * 'a') == Try(8, True)



# Generated at 2022-06-24 00:25:30.106409
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_function(val):
        if val == 'test value':
            return True
        return False
    assert Try(4, True).on_success(lambda v: test_function(v)).is_success == False, \
        'Try.on_success() unit test, check return value'
    assert Try('test value', True).on_success(lambda v: test_function(v)).is_success == True, \
        'Try.on_success() unit test, check return value'


# Generated at 2022-06-24 00:25:33.570371
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # when monad is successfully return monad value
    assert Try.of(lambda: 1, ()).get_or_else(0) == 1

    # when monad is not successfully return default value
    assert Try.of(lambda: 1/0, ()).get_or_else(0) == 0

# Generated at 2022-06-24 00:25:35.694520
# Unit test for method __str__ of class Try
def test_Try___str__():
        t = Try(1, True)
        assert str(t) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-24 00:25:38.171007
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_: Try[int] = Try.of(int, '123')
    try_.on_success(lambda value: print("on_success: value + 1 =",value+1))
    assert True #if exception is raised, test will failed


# Generated at 2022-06-24 00:25:43.461650
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def plus(x):
        return x + 10

    assert Try.of(int, '1') == Try(1, True)
    assert Try.of(int, 'foo') == Try(ValueError, False)

    assert Try.of(int, '1').map(plus) == Try(11, True)
    assert Try.of(int, 'foo').map(plus) == Try(ValueError, False)



# Generated at 2022-06-24 00:25:47.182685
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(42, True) == Try(42, True)
    assert not Try(42, True) == Try(43, True)
    assert not Try(42, True) == Try(42, False)
    assert not Try(42, False) == Try(43, False)


# Generated at 2022-06-24 00:25:53.732549
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(10, True) == Try(10, True)
    assert Try(10, True) != Try(10, False)
    assert Try(20, True) != Try(10, True)
    assert Try(10, False) != Try(20, False)
    assert Try(10, True) != True
    assert Try(20, False) != []
    assert Try(20, False) != None
    assert Try(10, True) != 10


# Generated at 2022-06-24 00:25:57.048021
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not (Try(1, True) == Try(1, False))
    assert not (Try(1, True) == Try(2, True))


# Generated at 2022-06-24 00:26:00.883034
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Unit test for method on_success of class Try.
    """
    def success_callback(value):
        assert value == 6

    def fail_callback(value):
        raise ValueError('Fail callback should not be called!')

    try_ = Try.of(lambda: 6)
    try_.on_success(success_callback).on_fail(fail_callback)


# Generated at 2022-06-24 00:26:06.347783
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 2 + 3, ()).get_or_else(0) == 5
    assert Try.of(lambda: 1/0, ()).get_or_else(0) == 0
    assert Try.of(lambda: [1, 2, 3][5], ()).get_or_else([]) == []


# Generated at 2022-06-24 00:26:14.761727
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Function tests method filter of class Try.

    :returns: information about test
    :rtype: String
    """
    try_1 = Try(1, True)\
        .filter(lambda x: x > 0)\
        .filter(lambda x: x < 2)
    try_2 = Try(1, True)\
        .filter(lambda x: x > 1)
    try_3 = Try(1, True)\
        .filter(lambda x: x < 0)
    assert try_1 == Try(1, True)
    assert try_2 == Try(1, False)
    assert try_3 == Try(1, False)
    return 'All tests passed...'


# Generated at 2022-06-24 00:26:20.633001
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.

    :returns: None
    :rtype: None
    """

    def even_predicate(x):
        return x % 2 == 0

    def get_some():
        return Try.of(lambda: 2.0)

    assert get_some()\
        .bind(lambda x: Try.of(lambda: x))\
        .filter(even_predicate)\
        == Try(2.0, True)

    assert get_some()\
        .bind(lambda x: Try.of(lambda: x))\
        .filter(lambda x: x > 0)\
        == Try(2.0, True)

    assert get_some()\
        .bind(lambda x: Try.of(lambda: x))\
        .filter(lambda x: x < 0)\
       

# Generated at 2022-06-24 00:26:27.664975
# Unit test for method on_success of class Try
def test_Try_on_success():
    def fn(a):
        return a ** 2

    assert Try.of(fn, 4).on_success(lambda x: print(x)) == Try(16, True) \
        and Try.of(fn, "ab").on_success(lambda x: print(x)) == Try("ab", False) \
        and Try.of(fn, "ab").on_success(lambda x: print(x)).map(lambda x: x ** 2) == Try("ab", False)


if __name__ == "__main__":
    test_Try_on_success()

# Generated at 2022-06-24 00:26:32.229164
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    raise_exception_function = lambda: 1/0
    try_monad = Try.of(raise_exception_function)
    error_message = ''
    try_monad.on_fail(lambda error: setattr(error_message, 'error', error))
    assert error_message == ZeroDivisionError

# Generated at 2022-06-24 00:26:36.193467
# Unit test for method map of class Try
def test_Try_map():
    def square(x):
        return x * x

    try_value = Try(2, True)
    assert try_value.map(square) == Try(4, True)

    try_value = Try(2, False)
    assert try_value.map(square) == Try(2, False)


# Generated at 2022-06-24 00:26:40.699570
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return True if value % 2 == 0 else False

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, True)
    assert Try(3, False).filter(filterer) == Try(3, False)
    assert Try(4, False).filter(filterer) == Try(4, False)


# Generated at 2022-06-24 00:26:42.780917
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-24 00:26:45.594270
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(None, False).get_or_else(1) == 1
    assert Try(2, True).get_or_else(1) == 2


# Generated at 2022-06-24 00:26:51.269218
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    def filterer(x):
        return x >= 3

    # success value is greater 3
    monad = Try(4, True).filter(filterer)
    assert monad.is_success == True
    assert monad.get() == 4

    # fail value is less 3
    monad = Try(2, True).filter(filterer)
    assert monad.is_success == False
    assert monad.get() == 2

# Generated at 2022-06-24 00:26:56.103632
# Unit test for constructor of class Try
def test_Try():
    try_monad_success: Try[int] = Try(10, True)
    try_monad_fail: Try[None] = Try(None, False)
    assert try_monad_success.value == 10
    assert try_monad_success.is_success == True
    assert try_monad_fail.value == None
    assert try_monad_fail.is_success == False


# Generated at 2022-06-24 00:27:03.958926
# Unit test for constructor of class Try
def test_Try():
    """
    Unit test for constructor of class Try.
    """
    monad = Try(2, True)
    assert monad.value == 2
    assert monad.is_success
    assert str(monad) == "Try[value=2, is_success=True]"

    monad = Try(2, False)
    assert monad.value == 2
    assert not monad.is_success
    assert str(monad) == "Try[value=2, is_success=False]"



# Generated at 2022-06-24 00:27:06.062975
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def test_function(value):
        assert value == 4

    Try.of(lambda: 4, ()).on_success(test_function)


# Generated at 2022-06-24 00:27:12.760863
# Unit test for method get of class Try
def test_Try_get():
    """
    Unit test for method get of class Try
    """
    assert 1 == Try.of(int, '1').get()
    assert -1 == Try.of(int, '1').map(lambda x: -x).get()
    assert 1 == Try.of(int, 'abc').get_or_else(-1)
    assert -1 == Try.of(int, 'abc').get_or_else(-1).map(lambda x: -x).get()


# Generated at 2022-06-24 00:27:14.638824
# Unit test for method __str__ of class Try
def test_Try___str__():
    expected_result = 'Try[value=4, is_success=True]'
    assert str(Try(4, True)) == expected_result


# Generated at 2022-06-24 00:27:20.432606
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def a() -> int:
        return 1

    try_ = Try.of(a)
    assert try_ == Try(1, True)
    assert try_ != Try(1, False)
    assert try_ != 1
    assert try_ != None


# Generated at 2022-06-24 00:27:28.981770
# Unit test for method map of class Try
def test_Try_map():
    def add_one(x):
        return x + 1

    assert Try.of(add_one, 1).map(add_one) == Try(3, True)
    assert Try.of(add_one, 1).map(add_one).is_success

    def raise_exception(x):
        raise ValueError()

    assert Try.of(raise_exception, 1).map(add_one) == Try(1, False)
    assert not Try.of(raise_exception, 1).map(add_one).is_success



# Generated at 2022-06-24 00:27:32.482847
# Unit test for method on_success of class Try
def test_Try_on_success():
    result = Try.of(lambda: 1).on_success(lambda a: str(a))
    assert result == Try(1, True), 'not match result of on_success function'
    assert result.value == 1, 'not match result of on_success function'


# Generated at 2022-06-24 00:27:34.648383
# Unit test for method get of class Try
def test_Try_get():
    value = Try(12, True).get()
    assert value == 12

    value = Try(None, False).get()
    assert value is None


# Generated at 2022-06-24 00:27:39.831015
# Unit test for method map of class Try
def test_Try_map():
    """
    Test for Try.map(mapper) method
    """
    # Successfully Try and function that increase value by one
    assert Try.of(lambda: 1, None).map(lambda x: x + 1) == Try(2, True)
    # Not successfully Try, value is Exception and function that increase value by one
    assert Try.of(lambda: None['not_exists'], None)\
        .map(lambda x: x + 1) == Try(KeyError("'not_exists'"), False)

# Generated at 2022-06-24 00:27:46.660866
# Unit test for constructor of class Try
def test_Try():
    assert Try('value', True) == Try('value', True)
    assert Try('value', False) == Try('value', False)
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try('value', True)
    assert Try(None, False) != Try('value', False)
    assert Try('value', True) != Try('value', False)
    assert Try('value', False) != Try('value', True)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)


# Generated at 2022-06-24 00:27:48.850390
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try.of(lambda: 2, ()).get() == 2
    assert Try.of(lambda: 1/0, ()).get() == ZeroDivisionError


# Generated at 2022-06-24 00:28:00.188002
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Check if method bind returns successfully Try
    when argument function don't raise exception.
    Check if method bind returns not successfully Try
    when argument function raises exception.
    """
    def success(name, age):
        return name + ' ' + str(age)

    def raise_exception(name, age):
        raise Exception

    t1 = Try.of(success, 'Name', 1).bind(lambda x: Try(x.split(' '), True))
    assert t1 == Try(['Name', '1'], True)

    t2 = Try.of(raise_exception, 'Name', 1).bind(lambda x: Try(x.split(' '), True))
    assert t2 == Try(Exception(), False)



# Generated at 2022-06-24 00:28:03.699292
# Unit test for method on_success of class Try
def test_Try_on_success():
    # Given
    t = Try(100, False)
    # When
    t.on_success(lambda v: print(v))
    # Then

    assert t == Try(100, False)


# Generated at 2022-06-24 00:28:12.471441
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Try

    bind(Function(A) -> Try[B])
    """
    spy = MagicMock()
    success = Try(42, True)
    not_success = Try(ZeroDivisionError, False)
    func = lambda v: Try(v / 10, True)

    success.bind(spy)
    assert spy.call_count == 1

    success.bind(func).map(spy)
    assert spy.call_count == 2

    not_success.bind(spy)
    assert spy.call_count == 2



# Generated at 2022-06-24 00:28:20.584286
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_callback(value):
        assert value == 'test_value'

    def test_callback_fail(value):
        assert False

    assert Try('test_value', True)\
        .on_success(test_callback)\
        .on_fail(test_callback_fail)\
        == Try('test_value', True)

    assert Try('test_value', False)\
        .on_success(test_callback)\
        .on_fail(test_callback_fail)\
        == Try('test_value', False)


# Generated at 2022-06-24 00:28:27.530806
# Unit test for method bind of class Try
def test_Try_bind():
    # not successful Try
    not_successful_try = Try(1, False)
    # successful Try
    successful_try = Try(1, True)

    def binder(val):
        return Try(val + 1, True)

    def fail_binder(val):
        return Try(val - 1, False)

    # bind always returns not successful Try
    assert not_successful_try.bind(binder) == not_successful_try
    assert not_successful_try.bind(fail_binder) == not_successful_try

    # bind returns successful Try when bind returns successful Try
    assert successful_try.bind(binder) == Try(2, True)
    # bind returns not successful Try when bind returns not successful Try
    assert successful_try.bind(fail_binder) == Try(0, False)


# Generated at 2022-06-24 00:28:33.627621
# Unit test for method filter of class Try
def test_Try_filter():
    try_success = Try.of(lambda a: a, 'a')
    assert try_success.filter(lambda v: True) == try_success

    try_not_success = Try.of(lambda a: a, 'a')
    assert try_not_success.filter(lambda v: False) != try_not_success

    try_not_success_with_exception = Try.of(lambda a: 1 / 0, 0)
    assert try_not_success_with_exception.filter(lambda v: True) != try_not_success_with_exception


# Generated at 2022-06-24 00:28:36.267581
# Unit test for method filter of class Try
def test_Try_filter():

    def is_even(value) -> bool:
        return value % 2 == 0

    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(1, True).filter(is_even) == Try(1, False)



# Generated at 2022-06-24 00:28:40.406477
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_instance = Try(10, True)
    assert str(try_instance) == 'Try[value=10, is_success=True]'



# Generated at 2022-06-24 00:28:49.267278
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    print('Test __eq__ method of class Try:')

    def check_test(expected_result, result, info):
        assert expected_result == result, 'Test {} failed.'.format(info)

    test_Try_1 = Try(0, True)
    test_Try_2 = Try(0, True)
    test_Try_3 = Try(0, False)
    test_Try_4 = Try(1, True)

    check_test(True, test_Try_1 == test_Try_1, 'equal monads')
    check_test(False, test_Try_1 == test_Try_3, 'unequal is_success')
    check_test(False, test_Try_1 == test_Try_4, 'unequal value')

    print('Test __eq__ method of class Try compleate.')

#