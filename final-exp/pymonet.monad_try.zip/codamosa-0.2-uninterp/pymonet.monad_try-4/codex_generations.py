

# Generated at 2022-06-18 01:53:34.586073
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 01:53:40.656505
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:53:47.259705
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    # Test for successfully Try
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    # Test for not successfully Try
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:53:50.765242
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:53:59.235314
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).filter(lambda x: x == 2).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).filter(lambda x: x == 2).filter(lambda x: x == 2).filter(lambda x: x == 2) == Try(1, False)

# Generated at 2022-06-18 01:54:06.083536
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-18 01:54:12.414950
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:54:16.641203
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-18 01:54:22.326178
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:54:29.248312
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:54:38.988570
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:54:44.169605
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:54:47.280533
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 01:54:53.457615
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 01:54:58.295402
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:01.923260
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:07.754971
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-18 01:55:12.120776
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:18.251460
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-18 01:55:24.854021
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:34.567316
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(-1, False).filter(filterer) == Try(-1, False)


# Generated at 2022-06-18 01:55:40.470315
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:47.198054
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:52.779769
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:57.325302
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-18 01:56:00.224773
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:56:04.896655
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-18 01:56:10.740288
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:56:15.821219
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-18 01:56:19.554536
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-18 01:56:34.281517
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 1

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 01:56:39.392113
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:56:44.426434
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).get() == 1
    assert Try.of(lambda: 1).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda: 1).filter(lambda x: x == 2).on_success(lambda x: print(x)) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).on_fail(lambda x: print(x)) == Try(1, False)

# Generated at 2022-06-18 01:56:54.036228
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda: 1).filter(lambda x: x == 1).get_or_else(2) == 1
    assert Try.of(lambda: 1).filter(lambda x: x == 1).get() == 1
    assert Try.of(lambda: 1).filter(lambda x: x == 2).get() == 1
    assert Try.of(lambda: 1).filter(lambda x: x == 1).on_success(lambda x: x + 1).get() == 2

# Generated at 2022-06-18 01:57:00.833374
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:07.033872
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:12.569459
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:17.360529
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:20.676617
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:26.137475
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 01:57:48.372100
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(Exception, False).filter(filterer) == Try(Exception, False)


# Generated at 2022-06-18 01:57:51.559824
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    assert Try(5, True).filter(filterer) == Try(5, False)
    assert Try(6, True).filter(filterer) == Try(6, True)


# Generated at 2022-06-18 01:57:55.906007
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 1

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(2, False).filter(filterer) == Try(2, False)


# Generated at 2022-06-18 01:58:04.294407
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 2).get_or_else(2) != 1


# Generated at 2022-06-18 01:58:09.277790
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:58:18.144787
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x < 0) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x < 0).filter(lambda x: x > 0) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x > 0).filter(lambda x: x < 0) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x < 0).filter(lambda x: x < 0) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x > 0).filter(lambda x: x > 0) == Try(1, True)
   

# Generated at 2022-06-18 01:58:22.721205
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:58:26.846182
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)


# Generated at 2022-06-18 01:58:34.247852
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda: 1).filter(lambda x: x == 1).get_or_else(2) == 1
    assert Try.of(lambda: 1).filter(lambda x: x == 1).get() == 1
    assert Try.of(lambda: 1).filter(lambda x: x == 2).get() == 1
    assert Try.of(lambda: 1).filter(lambda x: x == 1).on_success(lambda x: x + 1).get() == 2

# Generated at 2022-06-18 01:58:40.088360
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:59:30.325868
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:59:33.672958
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:59:38.693634
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:59:44.570067
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:59:48.481840
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x == 1

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(2, False).filter(filterer) == Try(2, False)


# Generated at 2022-06-18 01:59:54.773082
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'test'

    assert Try('test', True).filter(filterer) == Try('test', True)
    assert Try('test', False).filter(filterer) == Try('test', False)
    assert Try('not test', True).filter(filterer) == Try('not test', False)
    assert Try('not test', False).filter(filterer) == Try('not test', False)


# Generated at 2022-06-18 02:00:00.359811
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:00:05.200357
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:00:09.065003
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 1

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(2, True).filter(filterer) == Try(2, False)
    assert Try(1, False).filter(filterer) == Try(1, False)
    assert Try(2, False).filter(filterer) == Try(2, False)


# Generated at 2022-06-18 02:00:12.941943
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 02:01:59.908052
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:02:04.309164
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(3, True).filter(filterer) == Try(3, False)
    assert Try(10, False).filter(filterer) == Try(10, False)
    assert Try(3, False).filter(filterer) == Try(3, False)


# Generated at 2022-06-18 02:02:07.963885
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:02:12.765802
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(10, False).filter(filterer) == Try(10, False)
    assert Try(4, True).filter(filterer) == Try(4, False)
    assert Try(4, False).filter(filterer) == Try(4, False)


# Generated at 2022-06-18 02:02:17.720954
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 02:02:22.614204
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:02:28.063211
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:02:31.642509
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(-1, False).filter(filterer) == Try(-1, False)


# Generated at 2022-06-18 02:02:37.290423
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:02:41.202370
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)
