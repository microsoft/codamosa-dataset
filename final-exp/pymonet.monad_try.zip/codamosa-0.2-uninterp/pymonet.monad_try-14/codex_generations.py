

# Generated at 2022-06-18 01:53:37.193150
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:53:42.073521
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 01:53:46.331491
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 01:53:51.393128
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 10

    assert Try(10, True).filter(filterer) == Try(10, False)
    assert Try(11, True).filter(filterer) == Try(11, True)


# Generated at 2022-06-18 01:53:56.738479
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:54:04.701111
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)



# Generated at 2022-06-18 01:54:11.118174
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'test'

    assert Try('test', True).filter(filterer) == Try('test', True)
    assert Try('test', False).filter(filterer) == Try('test', False)
    assert Try('test1', True).filter(filterer) == Try('test1', False)
    assert Try('test1', False).filter(filterer) == Try('test1', False)



# Generated at 2022-06-18 01:54:16.716264
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 01:54:23.524759
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(0, True).filter(filterer) == Try(0, False)
    assert Try(0, False).filter(filterer) == Try(0, False)
    assert Try(Exception('error'), False).filter(filterer) == Try(Exception('error'), False)


# Generated at 2022-06-18 01:54:31.011765
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 01:54:37.416546
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 2

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(3, True).filter(filterer) == Try(3, True)


# Generated at 2022-06-18 01:54:43.033566
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:54:47.917287
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:54:55.777311
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:07.280081
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda: 1).filter(lambda x: x == 2).get_or_else(lambda: 2)() == 2
    assert Try.of(lambda: 1).filter(lambda x: x == 2).get_or_else(lambda: 3)() == 3
    assert Try.of(lambda: 1).filter(lambda x: x == 1).get_or_else(lambda: 3)() == 1

# Generated at 2022-06-18 01:55:11.451784
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:17.570858
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:24.365342
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x != 1) == Try(1, False)


# Generated at 2022-06-18 01:55:34.224660
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, None).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).get() == 1
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).on_success(lambda x: print(x)) == Try(1, False)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).on_fail(lambda x: print(x)) == Try(1, False)
    assert Try

# Generated at 2022-06-18 01:55:40.241544
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:55:50.807976
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 5

    assert Try(10, True).filter(filterer) == Try(10, True)
    assert Try(5, True).filter(filterer) == Try(5, False)
    assert Try(5, False).filter(filterer) == Try(5, False)
    assert Try(Exception, False).filter(filterer) == Try(Exception, False)


# Generated at 2022-06-18 01:55:54.717669
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 01:56:02.489881
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try.of(lambda: 1, ).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1, ).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1, ).filter(lambda x: x == 2).is_success == False
    assert Try.of(lambda: 1, ).filter(lambda x: x == 1).is_success == True
    assert Try.of(lambda: 1, ).filter(lambda x: x == 1).get() == 1
    assert Try.of(lambda: 1, ).filter(lambda x: x == 2).get() == 1
    assert Try.of(lambda: 1, ).filter(lambda x: x == 2).get_or_else

# Generated at 2022-06-18 01:56:09.155865
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'test'

    assert Try('test', True).filter(filterer) == Try('test', True)
    assert Try('test', False).filter(filterer) == Try('test', False)
    assert Try('test1', True).filter(filterer) == Try('test1', False)
    assert Try('test1', False).filter(filterer) == Try('test1', False)


# Generated at 2022-06-18 01:56:13.473676
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:56:16.887152
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:56:21.260925
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:56:25.296979
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0
    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 01:56:30.370449
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(0, True).filter(filterer) == Try(0, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 01:56:35.760082
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 01:56:51.459921
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:56:56.312734
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:03.450785
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:09.459232
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:14.885157
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:19.713238
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:29.072591
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 2).get() == 1
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 2).on_success(lambda x: print(x)) == Try(1, False)
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 2).on_fail(lambda x: print(x)) == Try(1, False)
    assert Try

# Generated at 2022-06-18 01:57:34.090329
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:40.802035
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:57:48.557599
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, None).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).get() == 1
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda: 1, None).filter(lambda x: x == 1).get_or_else(2) == 1
    assert Try.of(lambda: 1, None).filter(lambda x: x == 1).get_or_else(2) == 1

# Generated at 2022-06-18 01:58:12.762955
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:58:16.438984
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(0, True).filter(filterer) == Try(0, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 01:58:20.758808
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:58:26.264450
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:58:29.609726
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:58:31.861794
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-18 01:58:35.306654
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)



# Generated at 2022-06-18 01:58:41.840212
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:58:46.104078
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 01:58:51.526452
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 01:59:36.860923
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 01:59:41.341186
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:59:44.969922
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 10

    assert Try(10, True).filter(filterer) == Try(10, False)
    assert Try(11, True).filter(filterer) == Try(11, True)


# Generated at 2022-06-18 01:59:49.405233
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 01:59:55.536983
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 01:59:59.976798
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 02:00:04.844180
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:00:08.774635
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:00:13.408281
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:00:17.683723
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    def filterer(value):
        return value > 0

    # When
    try_1 = Try(1, True)
    try_2 = Try(-1, True)
    try_3 = Try(1, False)
    try_4 = Try(-1, False)

    # Then
    assert try_1.filter(filterer) == Try(1, True)
    assert try_2.filter(filterer) == Try(-1, False)
    assert try_3.filter(filterer) == Try(1, False)
    assert try_4.filter(filterer) == Try(-1, False)

# Generated at 2022-06-18 02:02:12.615333
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:02:21.410950
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, None).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).get() == 1
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).on_fail(lambda x: print(x)) == Try(1, False)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).on_success(lambda x: print(x)) == Try(1, False)
    assert Try

# Generated at 2022-06-18 02:02:30.618323
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, None).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).get() == 1
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).on_success(lambda x: print(x)).get() == 1
    assert Try.of(lambda: 1, None).filter(lambda x: x == 2).on_fail(lambda x: print(x)).get() == 1

# Generated at 2022-06-18 02:02:35.997427
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:02:40.409866
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 02:02:48.387611
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.
    """
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(-1, False).filter(filterer) == Try(-1, False)


# Generated at 2022-06-18 02:02:51.177525
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-18 02:02:57.049654
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-18 02:03:00.892488
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)
    assert Try(1, False).filter(filterer) == Try(1, False)


# Generated at 2022-06-18 02:03:05.691164
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)
