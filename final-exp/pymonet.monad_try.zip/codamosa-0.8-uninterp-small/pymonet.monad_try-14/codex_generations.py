

# Generated at 2022-06-25 23:53:08.166440
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)

    def filter_0(a0):
        return a0 == -3526

    try_1 = try_0.filter(filter_0)


# Generated at 2022-06-25 23:53:13.051840
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)

    def filterer(x_0):
        if x_0 > 0:
            return True
        return False

    try_1 = try_0.filter(filterer)
    assert(try_1.is_success == False)
    assert(try_1.value == int_0)


# Generated at 2022-06-25 23:53:23.391514
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -6584
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    def method_0(x):
        return x > 0
    try_1 = try_0.filter(method_0)
    assert not try_1.is_success
    assert try_1.value == int_0
    int_1 = -56438
    bool_1 = True
    try_2 = Try(int_1, bool_1)
    try_3 = try_2.filter(method_0)
    assert not try_3.is_success
    assert try_3.value == int_1


# Generated at 2022-06-25 23:53:27.238220
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(abs, -5).filter(lambda i: i > 10).is_success == False
    assert Try.of(abs, -5).filter(lambda i: i > -6).is_success == True


# Generated at 2022-06-25 23:53:35.371509
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    bool_1 = False
    func_0 = lambda x : (x//1) > 0
    func_1 = lambda x : (x//1) < 0
    int_0 = 9223372036854775807
    int_1 = -9223372036854775807
    try_0 = Try(int_0, bool_0)
    try_1 = Try(int_0, bool_0)
    try_2 = Try(int_1, bool_0)
    try_3 = Try(int_1, bool_0)
    try_4 = try_0.filter(func_0)
    try_5 = try_1.filter(func_1)
    try_6 = try_2.filter(func_0)
    try_7 = try_3.filter

# Generated at 2022-06-25 23:53:44.161025
# Unit test for method filter of class Try
def test_Try_filter():
    def add_1(x):
        return x + 1

    int_0 = -3526
    bool_0 = True
    int_1 = 5
    bool_1 = True
    try_0 = Try(int_0, bool_0)
    try_1 = Try(int_1, bool_1)

    assert try_0.filter(lambda x: x > int_0) == Try(int_0, False)
    assert try_1.filter(lambda x: x > int_0) == Try(int_1, True)


# Generated at 2022-06-25 23:53:46.061988
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 54
    bool_0 = True
    try_0 = Try(int_0, bool_0)

# Generated at 2022-06-25 23:53:54.286534
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(12, True).filter(lambda x: True) == Try(12, True)
    assert Try(12, True).filter(lambda x: False) == Try(12, False)
    assert Try(0, True).filter(lambda x: True) == Try(0, True)
    assert Try(1, True).filter(lambda x: False) == Try(1, False)
    assert Try(0, True).filter(lambda x: False) == Try(0, False)
    assert Try(0, False).filter(lambda x: False) == Try(0, False)
    assert Try(3, True).filter(lambda x: True) == Try(3, True)

# Generated at 2022-06-25 23:54:03.085836
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer_0(val_0):
        return val_0 == val_0
    def filterer_1(val_0):
        return re.findall(r"[#@!$%^&*].{0,}", repr(val_0)).count(val_0[0]) == 0
    int_0 = -16658
    bool_0 = False
    try_0 = Try(int_0, bool_0).filter(filterer_0)
    try_1 = Try(int_0, bool_0).filter(filterer_1)
    assert try_0.value == int_0 and try_0.is_success == False
    assert try_1.value == int_0 and try_1.is_success == False


# Generated at 2022-06-25 23:54:13.837304
# Unit test for method filter of class Try
def test_Try_filter():
    # Initialization of needed values
    int_0 = -3526
    bool_0 = True
    not_bool_0 = False
    try_0 = Try(int_0, bool_0)
    try_1 = Try(int_0, not_bool_0)
    # Call of filter with filterer that returns True
    try_2 = try_0.filter(lambda x: x > 0)
    # Assertion that try_2 contains int_0 and is_success == True
    assert try_2 == Try(int_0, not_bool_0)
    # Call of filter with filterer that returns True
    try_3 = try_1.filter(lambda x: x > 0)
    # Assertion that try_2 contains int_0 and is_success == True

# Generated at 2022-06-25 23:54:20.385839
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 0
    try_0 = Try(int_0, True)
    try_1 = Try(int_0, True)

# Generated at 2022-06-25 23:54:33.885179
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    bool_1 = True
    if bool_0:
        if int_0 >= 0:
            bool_1 = True
        else:
            bool_1 = False
    else:
        bool_1 = False
    bool_1 = bool_1
    bool_2 = bool_1
    if bool_0:
        bool_2 = bool_1
    else:
        bool_2 = False
    bool_2 = bool_2
    bool_3 = True
    if bool_0:
        if bool_2:
            bool_3 = True
        else:
            bool_3 = False
    else:
        bool_3 = False
    bool_3 = bool_3
    bool

# Generated at 2022-06-25 23:54:45.553631
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)

    int_1 = -3526
    bool_1 = True
    try_1 = Try(int_1, bool_1)
    int_2 = -3526
    bool_2 = True
    try_2 = Try(int_2, bool_2)
    int_3 = -3526
    bool_3 = True
    try_3 = Try(int_3, bool_3)
    int_4 = -3526
    bool_4 = True
    try_4 = Try(int_4, bool_4)
    int_5 = -3526
    bool_5 = True
    try_5 = Try(int_5, bool_5)

    # Test arguments
    fil

# Generated at 2022-06-25 23:54:53.243781
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(int, "43")
    try_0 = try_0.filter(lambda value: value < 10)
    try_0 = try_0.filter(lambda value: value < 10)
    assert(try_0 == Try(43, False))


# Generated at 2022-06-25 23:55:01.842176
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    int_1 = try_0.filter(lambda x: x > int_0)
    assert int_1.is_success == True
    int_2 = try_0.filter(lambda x: x < int_0)
    assert int_2.is_success == False
    int_3 = try_0.filter(lambda x: x == -3526)
    assert int_3.is_success == True


# Generated at 2022-06-25 23:55:09.608646
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 8
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    try_0 = try_0.filter(lambda x: False)
    assert isinstance(try_0, Try)
    assert isinstance(try_0.value, int)
    assert not try_0.is_success
    assert try_0 == Try(int_0, False)



# Generated at 2022-06-25 23:55:20.321733
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)

    print("*************************")
    print("test_Try_filter START")
    print("*************************")

    str_0 = "Try[value=-3526, is_success=True]"
    assert(str_0 == str(try_0))
    test_filter_0 = lambda arg_0: arg_0 < int_0
    try_1 = try_0.filter(test_filter_0)
    str_1 = "Try[value=-3526, is_success=False]"
    assert(str_1 == str(try_1))

    test_filter_1 = lambda arg_0: arg_0 > int_0

# Generated at 2022-06-25 23:55:32.716493
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    int_1 = -1780
    bool_1 = True
    try_1 = Try(int_1, bool_1)
    bool_2 = False
    try_2 = Try(int_1, bool_2)
    int_3 = -1780
    bool_3 = False
    try_3 = Try(int_3, bool_3)
    int_4 = -1788
    bool_4 = False
    try_4 = Try(int_4, bool_4)
    int_5 = -2409
    bool_5 = False
    try_5 = Try(int_5, bool_5)
    int_6 = -2409
    bool_6 = True


# Generated at 2022-06-25 23:55:35.061391
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    expected_value = True
    def filterer(value):
        return value < 1000000
    assert try_0.filter(filterer).is_success == expected_value, 'test_Try_filter fails'


# Generated at 2022-06-25 23:55:37.375729
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    def filter_0(a_0):
        return a_0 < 0
    try_1 = try_0.filter(filter_0)


# Generated at 2022-06-25 23:55:45.996695
# Unit test for method filter of class Try
def test_Try_filter():
    test_fn_0 = lambda x: x > 3 and x < 10
    try_0 = Try.of(lambda: 3)
    try_1 = try_0.filter(test_fn_0)
    try_2 = Try(3, False)
    
    print("Try.filter for test_Try_filter passed: " + str(try_2 == try_1))


# Generated at 2022-06-25 23:55:54.349422
# Unit test for method filter of class Try
def test_Try_filter():
    def add_3(num):
        return num + 3

    def is_even(value):
        return value % 2 == 0

    assert Try(2, True).filter(is_even).get() == 2
    assert Try(2, True).filter(is_even).is_success
    assert Try(3, True).filter(is_even).is_success == False
    assert Try(5, False).filter(is_even).get() == 5
    assert Try(5, False).filter(is_even).is_success == False



# Generated at 2022-06-25 23:56:00.307192
# Unit test for method filter of class Try
def test_Try_filter():
    """
    This test checks the correctness of the filter method in the Try class.
    """
    assert Try.of(lambda: 1).filter(lambda x: x) == Try(1, True)
    assert Try.of(lambda: 0).filter(lambda x: x) == Try(0, False)
    assert Try.of(lambda: 1).filter(lambda x: True) == Try(1, True)
    assert Try.of(lambda: 0).filter(lambda x: True) == Try(0, True)


# Generated at 2022-06-25 23:56:06.684680
# Unit test for method filter of class Try
def test_Try_filter():
    print('\n---------------Unit test for method filter of class Try---------------\n')
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    def filterer (int_1) :
        return int_1 >= 0
    try_1 = try_0.filter(filterer)
    print(try_1)
    assert try_1.value == int_0
    assert not try_1.is_success
    int_2 = -23
    try_2 = Try(int_2, bool_0)
    try_3 = try_2.filter(filterer)
    print(try_3)
    assert try_3.value == int_2
    assert not try_3.is_success
    int_3 = 45
    try_

# Generated at 2022-06-25 23:56:18.069109
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 23
    bool_0 = True
    try_0 = Try(int_0, bool_0)


    int_1 = 23
    bool_1 = False
    try_1 = Try(int_1, bool_1)


    int_2 = 3
    bool_2 = False
    try_2 = Try(int_2, bool_2)


    int_3 = 489
    bool_3 = True
    try_3 = Try(int_3, bool_3)


    bool_4 = True
    try_4 = Try(None, bool_4)


    bool_5 = False
    try_5 = Try(None, bool_5)


    bool_6 = False
    try_6 = Try(None, bool_6)


    bool_7 = True
   

# Generated at 2022-06-25 23:56:26.070971
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -3526
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    def predicate_0(arg_0):
        return arg_0 < 0
    try_1 = try_0.filter(predicate_0)
    assert try_1.value == int_0
    assert try_1.is_success
    int_1 = 0
    bool_1 = False
    try_2 = Try(int_1, bool_1)
    int_2 = 31
    bool_2 = True
    try_3 = Try(int_2, bool_2)
    try_4 = try_2.filter(predicate_0)
    assert try_4.value == int_1
    assert not try_4.is_success

# Generated at 2022-06-25 23:56:33.222604
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer_0(x):
        return x > 10

    int_0 = 0
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    try_1 = try_0.filter(filterer_0)

    assert not try_1.is_success

    int_1 = 15
    bool_1 = True
    try_2 = Try(int_1, bool_1)
    try_3 = try_2.filter(filterer_0)

    assert try_3.is_success



# Generated at 2022-06-25 23:56:44.445983
# Unit test for method filter of class Try
def test_Try_filter():
    assert_0 = Try(True, True)
    assert_1 = Try(1, True)
    assert_2 = Try(2, True)
    assert_3 = Try(3, True)
    assert_4 = Try(4, True)
    assert_5 = Try(5, True)
    assert_6 = Try(6, True)
    assert_7 = Try(7, True)
    assert_8 = Try(8, True)
    assert_9 = Try(9, True)
    assert_10 = Try(10, True)

    test_filter_0 = lambda x: x % 2 == 0
    assert assert_0.filter(test_filter_0).value == True
    assert assert_1.filter(test_filter_0).value == 1
    assert assert_2.filter(test_filter_0).value

# Generated at 2022-06-25 23:56:49.096731
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -6574
    bool_0 = True
    Try_0 = Try(int_0, bool_0)
    def filterer(x):
        return True
    Try_1 = Try_0.filter(filterer)
    int_1 = 1256
    Try_2 = Try(int_1, True)
    assert Try_1 == Try_2


# Generated at 2022-06-25 23:56:54.471946
# Unit test for method filter of class Try
def test_Try_filter():
    # Case 0
    try_0 = Try(0, True)
    lambda_0 = lambda fn_0: fn_0 > 5
    expected_0 = Try(0, False)
    result_0 = try_0.filter(lambda_0)

    assert expected_0 == result_0

    # Case 1
    try_1 = Try(6, True)
    lambda_1 = lambda fn_0: fn_0 > 5
    expected_1 = Try(6, True)
    result_1 = try_1.filter(lambda_1)

    assert expected_1 == result_1

    # Case 2
    try_2 = Try(0, False)
    lambda_2 = lambda fn_0: fn_0 > 5
    expected_2 = Try(0, False)

# Generated at 2022-06-25 23:57:09.250231
# Unit test for method filter of class Try
def test_Try_filter():
    """Unit test for method filter of class Try."""
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    try_0_new = try_0.filter(lambda x: x)
    assert try_0_new.is_success == True
    assert try_0_new.value == True

    try_0_new = try_0.filter(lambda x: not x)
    assert try_0_new.is_success == False
    assert try_0_new.value == True

    # Error
    try_0_new = try_0.filter(lambda x: 'a')



# Generated at 2022-06-25 23:57:13.388219
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(False, False)
    assert try_0.filter(lambda value: value) == Try(False, False)
    try_1 = Try(True, True)
    assert try_1.filter(lambda value: value) == Try(True, True)


# Generated at 2022-06-25 23:57:19.222342
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.filter(lambda value: True) == Try(bool_0, bool_0)

    bool_1 = False
    try_1 = Try(bool_1, bool_0)
    assert try_1.filter(lambda value: False) == Try(bool_1, False)

    assert try_0.filter(lambda value: False) == Try(bool_0, False)


# Generated at 2022-06-25 23:57:24.018179
# Unit test for method filter of class Try
def test_Try_filter():
    success_try = Try(5, True)
    assert success_try.filter(lambda v: v % 2 == 0) == Try(5, False)
    assert success_try.filter(lambda v: v % 3 == 0) == Try(5, True)
    fail_try = Try('error', False)
    assert fail_try.filter(lambda v: True) == fail_try


# Generated at 2022-06-25 23:57:34.588716
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filterer(arg):
        return arg == 'test'

    valid_test_value = 'test'
    invalid_test_value = 'invalid_test'

    try_0 = Try(valid_test_value, True)
    try_1 = Try(invalid_test_value, True)

    try_0_filtered = try_0.filter(test_filterer)
    try_1_filtered = try_1.filter(test_filterer)

    bool_0 = try_0_filtered.is_success
    bool_1 = try_1_filtered.is_success

    bool_0_expected = True
    bool_1_expected = False

    assert bool_0 == bool_0_expected
    assert bool_1 == bool_1_expected


# Generated at 2022-06-25 23:57:42.335261
# Unit test for method filter of class Try
def test_Try_filter():
    # When Try is not successfully, the method filter should return
    # Try with the same is_success value.
    try_0 = Try(None, False)
    try_1 = try_0.filter(lambda x: x)
    assert not try_1.is_success

    # When Try is successfully and condition is True, the method filter should return
    # Try with the same is_success value.
    try_2 = Try(None, True).filter(lambda x: x)
    assert try_2.is_success

    # When Try is successfully and condition is False, the method filter should return
    # Try with is_success False.
    try_3 = Try(None, True).filter(lambda x: not x)
    assert not try_3.is_success



# Generated at 2022-06-25 23:57:46.703003
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(10, True)
    try_1 = try_0.filter(lambda value: value > 5)
    try_2 = try_0.filter(lambda value: value > 15)

    assert try_1 == Try(10, True)
    assert try_2 == Try(10, False)



# Generated at 2022-06-25 23:57:56.900361
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    fn_0 = lambda x: True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(fn_0)
    assert_is_not(try_0, try_1)
    assert_is_not(try_0.value, try_1.value)
    assert_is_not(try_0.is_success, try_1.is_success)
    bool_0 = True
    fn_0 = lambda x: True
    try_0 = Try(bool_0, not bool_0)
    try_1 = try_0.filter(fn_0)
    assert_is_not(try_0, try_1)
    assert_is_not(try_0.value, try_1.value)
    assert_is

# Generated at 2022-06-25 23:58:04.636930
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    # Case 1
    # Case input
    int_1_input = int_1
    int_2_input = int_2
    # Case expected output
    int_1_try_expected = Try(int_1, True)
    int_2_try_expected = Try(int_2, True)
    # Case output
    int_1_try_output = Try.of(int, int_1_input).filter(lambda x: x == int_1)
    int_2_try_output = Try.of(int, int_2_input).filter(lambda x: x == int_2)
    # Assert output is expected
    assert int_1_try_output == int_1_try_expected
    assert int_2_try

# Generated at 2022-06-25 23:58:16.317717
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    bool_1 = False

    try_0 = Try(bool_1, bool_0)
    assert try_0.filter(lambda b: bool_1).is_success == bool_0
    assert try_0.filter(lambda b: bool_1).value == bool_1

    try_1 = Try(bool_0, bool_0)
    assert try_1.filter(lambda b: bool_1).is_success == bool_0
    assert try_1.filter(lambda b: bool_1).value == bool_0

    try_0_1 = Try(bool_1, bool_1)
    assert try_0_1.filter(lambda b: bool_0).is_success == bool_1
    assert try_0_1.filter(lambda b: bool_0).value == bool_1

# Generated at 2022-06-25 23:58:25.736831
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_0 = Try(False, True)
    assert str(try_0) == 'Try[value=False, is_success=True]'

    try_1 = Try('string one', False)
    assert str(try_1) == 'Try[value=string one, is_success=False]'

    try_2 = Try(1, True)
    assert str(try_2) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-25 23:58:26.545850
# Unit test for constructor of class Try
def test_Try():
    test_case_0()

# Generated at 2022-06-25 23:58:30.669358
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert str(try_0) == 'Try[value=True, is_success=True]'



# Generated at 2022-06-25 23:58:36.694870
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0).on_fail(lambda o: assert_false(bool_0))
    bool_0 = False
    assert_equal(Try(bool_0, bool_0).on_fail(lambda o: assert_false(bool_0)).value, bool_0)


# Generated at 2022-06-25 23:58:40.136047
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(value):
        return Try(value, True)

    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    result = try_0.bind(binder)
    assert result.value == bool_0
    assert result.is_success == bool_0



# Generated at 2022-06-25 23:58:41.591330
# Unit test for method get of class Try
def test_Try_get():
    assert Try(True, True).get()
    assert Try(None, True).get() is None



# Generated at 2022-06-25 23:58:45.971538
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(5, True).bind(lambda x: Try(x * 2, True)) == Try(10, True)
    assert Try(3, True).bind(lambda x: Try(x, False)) == Try(3, False)
    assert Try(0, True).bind(lambda x: Try(x * 2, x % 2 == 0)) == Try(0, False)



# Generated at 2022-06-25 23:58:46.771441
# Unit test for constructor of class Try
def test_Try():
    test_case_0()



# Generated at 2022-06-25 23:58:50.832704
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def testFunction(e):
        assert isinstance(e, Exception)

    assert Try(None, False).on_fail(testFunction) == Try(None, False)
    assert Try(None, True).on_fail(testFunction) == Try(None, True)


# Generated at 2022-06-25 23:58:55.090486
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    list_0 = [bool_0, try_0.is_success]
    list_1 = []
    try_0.on_fail(list_1.append)


# Generated at 2022-06-25 23:59:06.621087
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    t_0 = try_0.get_or_else(True)

    if t_0 != True:
        raise Exception('Fail test_Try_get_or_else')


# Generated at 2022-06-25 23:59:09.464734
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try_0 = Try(ValueError('Error'), False)
    try_1 = try_0.on_fail(lambda value: print(value))
    assert ValueError.__name__ == type(try_1.value).__name__

# Generated at 2022-06-25 23:59:16.409146
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    bool_1 = False
    try_1 = Try(bool_1, bool_1)

    desired_value_0 = bool_0
    desired_value_1 = bool_1

    flag_0 = False
    flag_1 = False

    def action_0(value):
        nonlocal flag_0
        flag_0 = True
        return Try(value, desired_value_0)

    def action_1(value):
        nonlocal flag_1
        flag_1 = True
        return Try(value, desired_value_1)

    res_0 = try_0.on_success(action_0)
    res_1 = try_1.on_success(action_1)

    return desired_value_0 == flag

# Generated at 2022-06-25 23:59:18.089693
# Unit test for method filter of class Try
def test_Try_filter():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 23:59:25.548516
# Unit test for method map of class Try
def test_Try_map():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.map(lambda x: x)

    bool_1 = False
    try_2 = try_0.map(lambda x: bool_1)

    try_3 = try_0.map(lambda x: x)
    try_4 = Try(bool_0, bool_0)

    try_5 = try_0.map(lambda x: bool_0)
    try_6 = Try(bool_0, bool_0)

    assert try_1 == try_4
    assert try_2 != try_5
    assert try_3 == try_6



# Generated at 2022-06-25 23:59:36.064045
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    bool_1 = False

    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_1)
    try_2 = Try(bool_1, bool_0)
    try_3 = Try(bool_1, bool_1)

    assert try_0 == try_0
    assert try_1 == try_1
    assert try_2 == try_2
    assert try_3 == try_3

    assert try_0 == Try(bool_0, bool_0)
    assert try_1 == Try(bool_0, bool_1)
    assert try_2 == Try(bool_1, bool_0)
    assert try_3 == Try(bool_1, bool_1)

    assert try_0 != try_1

# Generated at 2022-06-25 23:59:38.409059
# Unit test for method __str__ of class Try
def test_Try___str__():
    test_value = 5
    try_0 = Try(test_value, True)
    #assert try_0 == "Try[value=5, is_success=True]"
    assert try_0.__str__() == "Try[value=5, is_success=True]"


# Generated at 2022-06-25 23:59:47.149942
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try_0_0 = Try([1], True)
    try_0_1 = Try([], True)
    try_0_2 = Try(1, True)
    def func_0_0(val_0_0):
        val_0_1 = (val_0_0 == [])
        assert val_0_1, "test_Try_on_fail_test_0"
        return Try(val_0_1, val_0_1)
    try_0_0.bind(func_0_0)

    def func_0_1(val_0_2):
        val_0_3 = (val_0_2 == True)
        assert val_0_3, "test_Try_on_fail_test_1"
        return Try(val_0_3, val_0_3)


# Generated at 2022-06-25 23:59:48.876410
# Unit test for constructor of class Try
def test_Try():
    print("TEST Try")
    print("TEST Try constructor")
    assert isinstance(Try(1, True), Try)
    print("PASSED\t Try constructor")
    print('\n')



# Generated at 2022-06-25 23:59:55.111492
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Call Try.get_or_else method with no successfully Try and return value from
    get_or_else method.
    """
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, not bool_0)
    value_0 = try_0.get_or_else(1)
    value_1 = try_1.get_or_else(0)
    assert value_0 and not value_1



# Generated at 2022-06-26 00:00:17.843307
# Unit test for method map of class Try
def test_Try_map():
    # Test case 0
    def identity(a):
        return a

    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.map(identity)
    assert try_1 == Try(bool_0, bool_0)

    # Test case 1
    try_0 = Try(bool_0, not bool_0)
    try_1 = try_0.map(identity)
    assert try_1 == Try(bool_0, not bool_0)

    # Test case 2
    def is_int(a):
        return type(a) is int

    var_0 = 0
    try_0 = Try(var_0, not bool_0)
    try_1 = try_0.map(is_int)
    assert try_1 == Try

# Generated at 2022-06-26 00:00:25.499400
# Unit test for method map of class Try
def test_Try_map():
    # Test call with successfully Try value
    try_1 = Try(10, True)
    try_2 = try_1.map(lambda value: value + 1)
    assert try_2.value == 11 and try_2.is_success
    # Test call with not successfully Try value
    try_3 = Try(10, False)
    try_4 = try_3.map(lambda value: value + 1)
    assert try_4.value == 10 and not try_4.is_success


# Generated at 2022-06-26 00:00:28.809084
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert Try.of(lambda: bool_0 or bool_0, None) == Try(bool_0 or bool_0, bool_0 or bool_0)
    assert Try.of(lambda: bool_0 or bool_0, None).filter(bool_0 or bool_0) == Try(bool_0 or bool_0, bool_0 or bool_0)
    assert Try.of(lambda: bool_0 or bool_0, None).filter(bool_0 or bool_0) == Try(bool_0 or bool_0, bool_0 or bool_0)


# Generated at 2022-06-26 00:00:30.423229
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(None, False) == Try(None, False)


# Generated at 2022-06-26 00:00:34.040596
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    assert try_0.__eq__(try_1)



# Generated at 2022-06-26 00:00:42.349222
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Test case True
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0)
    if not (try_0 == try_1):
        raise Exception()
    # Test case False
    try_0 = Try(bool_0, not bool_0)
    try_1 = Try(bool_0, bool_0)
    if try_0 == try_1:
        raise Exception()
    # Test case False
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0)
    if try_0 == try_1:
        raise Exception()
    # Test case True
    bool_0 = False

# Generated at 2022-06-26 00:00:48.851969
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Method path to test:
        - bind
    """
    # true path
    bool_0 = True
    try_0 = Try(bool_0, bool_0).bind(lambda x: Try(x, True))
    assert try_0 == Try(bool_0, bool_0)

    # false path
    bool_0 = False
    try_0 = Try(bool_0, bool_0).bind(lambda x: Try(x, True))
    assert try_0 == Try(bool_0, bool_0)


# Generated at 2022-06-26 00:00:55.468939
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.filter(lambda x: x) == Try(bool_0, bool_0)
    assert try_0.filter(lambda x: not x) == Try(bool_0, False)
    bool_1 = False
    try_1 = Try(bool_1, bool_1)
    assert try_1.filter(lambda x: x) == Try(bool_1, False)
    assert try_1.filter(lambda x: not x) == Try(bool_1, False)


# Generated at 2022-06-26 00:01:01.209822
# Unit test for constructor of class Try
def test_Try():
    assert Try(2, True) == Try(2, True)
    assert Try(2, False) == Try(2, False)
    assert Try(2, True) != Try(2, False)
    assert Try(2, False) != Try(2, True)
    assert 2 == Try(2, True).get()
    assert None == Try(None, False).get()
    assert 2 == Try(None, False).get_or_else(2)
    assert None == Try(None, True).get_or_else(None)


# Generated at 2022-06-26 00:01:05.441963
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

# Generated at 2022-06-26 00:01:22.094399
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert(try_0 == try_0)


# Generated at 2022-06-26 00:01:31.065941
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    bool_1 = False
    bool_2 = bool_0
    str_0 = 'znoqx'
    str_1 = 'akgqj'
    str_2 = str_0
    def func_0():
        return bool_1
    def func_1():
        return bool_0
    def func_2():
        return str_1
    def func_3():
        return str_0
    def func_4():
        return str_0
    def func_5():
        return bool_0
    def func_6():
        return str_0
    def func_7():
        return str_0
    def func_8():
        return bool_0

    bool_3 = func_1()
    bool_4 = func_0()
    bool_5 = bool

# Generated at 2022-06-26 00:01:40.076600
# Unit test for method on_success of class Try
def test_Try_on_success():
    # Test case when Try is successfully

    # Setup
    def test_on_success_callback(value: bool) -> None:
        if not value:
            raise Exception("Something goes wrong")
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    # Test
    try_0.on_success(test_on_success_callback)

    # Assert
    assert True

    # Test case when Try is not successfully

    # Setup
    def test_on_success_callback(value: bool) -> None:
        if not value:
            raise Exception("Something goes wrong")
    bool_0 = False
    try_0 = Try(bool_0, not bool_0)

    # Test
    try_0.on_success(test_on_success_callback)

    # Assert
   

# Generated at 2022-06-26 00:01:48.889307
# Unit test for method map of class Try
def test_Try_map():
    try_0 = Try.of(None, None)

    try_1 = Try.of(int, '1')
    try_2 = Try.of(int, '1')
    assert try_1 == try_2

    try_3 = Try.of(int, 'a')
    try_4 = Try.of(int, 'a')
    assert try_4 == try_3

    try_5 = Try.of(int, '10')
    try_6 = try_5.map(lambda x: x * x)
    print(try_6)
    assert try_6 == Try(100, True)

    try_7 = try_5.map(str)
    print(try_7)
    assert try_7 == Try('10', True)



# Generated at 2022-06-26 00:01:53.469908
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = True
    bool_1 = False

    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_1)

    assert try_0.get_or_else(bool_1) == bool_0
    assert try_1.get_or_else(bool_0) == bool_0


# Generated at 2022-06-26 00:01:58.502415
# Unit test for method map of class Try
def test_Try_map():
    a = 10
    fn_0 = lambda x: x + 1
    try_1 = Try.of(lambda: a)
    try_2 = try_1.map(fn_0)
    try_3 = try_1.map(lambda x: x + 1)

    assert try_1 == Try(a, True)
    assert try_2 == Try(11, True)
    assert try_3 == Try(11, True)



# Generated at 2022-06-26 00:02:03.550215
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    def binder(value):
        try_1 = Try(value, value)
    try_2 = try_0.bind(binder)

test_Try_bind()


# Generated at 2022-06-26 00:02:11.593194
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.value == bool_0
    assert try_0.is_success == bool_0
    assert try_0 == Try(bool_0, bool_0)

    bool_1 = False
    try_1 = Try(bool_1, bool_0)
    assert try_1.value == bool_1
    assert try_1.is_success == bool_0
    assert try_1 == Try(bool_1, bool_0)

    bool_2 = False
    try_2 = Try(bool_2, bool_1)
    assert try_2.value == bool_2
    assert try_2.is_success == bool_1
    assert try_2 == Try(bool_2, bool_1)



# Generated at 2022-06-26 00:02:15.089013
# Unit test for method get of class Try
def test_Try_get():
    # in this test we used assert method to check that when try succeed
    # then it's value is the same as putted into try earlier
    # and that when try failed it's value is the same as putted into try earlier
    assert Try(True, True).get() == True
    assert Try(False, False).get() == False


# Generated at 2022-06-26 00:02:16.633097
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(5, True).get_or_else(7) == 5
    assert Try(5, False).get_or_else(7) == 7



# Generated at 2022-06-26 00:02:50.384723
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10


# Generated at 2022-06-26 00:02:58.161522
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Unit test for method on_fail of class Try
    """
    bool_0 = True
    bool_1 = True
    try_0 = Try(bool_0, bool_0)

# Generated at 2022-06-26 00:03:03.009732
# Unit test for method map of class Try
def test_Try_map():
    assert Try(-1, False).map(lambda x: x + 1) == Try(-1, False)
    assert Try(0, False).map(lambda x: x + 1) == Try(0, False)
    assert Try(100, True).map(lambda x: f"{x}") == Try("100", True)
    assert Try(100, True).map(lambda x: x) == Try(100, True)
    assert Try(100, True).map(lambda x: x).map(lambda x: x + 1) == Try(101, True)
