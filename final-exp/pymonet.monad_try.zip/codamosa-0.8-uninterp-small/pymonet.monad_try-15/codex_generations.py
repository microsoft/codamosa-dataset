

# Generated at 2022-06-25 23:53:05.922395
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1403.727917
    bool_0 = True
    try_0 = Try(float_0, bool_0)
    try_1 = try_0.filter(None)



# Generated at 2022-06-25 23:53:14.949298
# Unit test for method filter of class Try
def test_Try_filter():
    test_1_filterer = lambda x: x / 7 > 100
    test_2_filterer = lambda x: x < 0
    test_3_filterer = lambda x: x * 2 < 0
    test_4_filterer = lambda x: x * x < 0
    test_5_filterer = lambda x: len(x) > 0
    test_6_filterer = lambda x: len(x) > len(x.strip())
    test_7_filterer = lambda x: len(x.split()) > 1
    test_8_filterer = lambda x: len(x) < len(x.replace(" ", ""))
    test_9_filterer = lambda x: x[0] != x[0].upper()

# Generated at 2022-06-25 23:53:27.454327
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1972.108
    bool_0 = False
    try_0 = Try(float_0, bool_0)

    int_0 = 5
    int_1 = 6
    int_2 = 8
    def function_0(int_0):
        return int_0 != 7
    try_1 = try_0.filter(function_0)
    try_2 = try_1.filter(function_0)
    try_3 = try_2.filter(function_0)
    try_4 = try_3.filter(function_0)
    try_5 = try_4.filter(function_0)
    try_6 = try_5.filter(function_0)
    try_7 = try_6.filter(function_0)
    try_8 = try_7.filter(function_0)

# Generated at 2022-06-25 23:53:35.541170
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1972.108
    bool_0 = False
    try_0 = Try(float_0, bool_0)

    float_1 = float(2264)
    bool_1 = True
    try_1 = Try(float_1, bool_1)

    float_2 = float(-140)
    bool_2 = True
    try_2 = Try(float_2, bool_2)

    def less(a):
        return a < 3500

    def negative(a):
        return a < 0

    try_0_2 = try_0.filter(less)
    try_1_2 = try_1.filter(negative)
    try_2_1 = try_2.filter(less)

    assert try_0_2.value == float_0
    assert try_0_2.is_success

# Generated at 2022-06-25 23:53:40.937521
# Unit test for method filter of class Try
def test_Try_filter():
    try_1 = Try(float(), False)
    assert isinstance(try_1.filter(float), Try)
    assert try_1.is_success == False
    #
    float_2 = float()
    bool_2 = float_2 == float()
    try_2 = Try(float_2, bool_2)
    try_3 = try_2.filter(float)
    try_3_is_success = try_3.is_success
    try_3_value = try_3.value
    bool_3 = try_3_is_success == bool_2
    bool_4 = try_3_value == float_2
    bool_5 = bool_3 and bool_4
    assert bool_5


# Generated at 2022-06-25 23:53:51.385403
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 372.2922077518914
    bool_0 = True
    try_0 = Try(float_0, bool_0)
    float_1 = 569.0807917479804
    bool_1 = False
    try_1 = Try(float_1, bool_1)
    bool_4 = False
    str_4 = "Try[value={}, is_success={}]"
    try_5 = Try(bool_4, bool_0)
    try_6 = Try(bool_4, bool_1)
    float_2 = -564.0788261251285
    bool_2 = True
    try_2 = Try(float_2, bool_2)
    float_3 = -561.7460424011922
    bool_3 = False

# Generated at 2022-06-25 23:54:00.138007
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1972.108
    try_0 = Try(float_0, False)
    assert try_0 == Try.of(lambda: float_0, float_0).filter(lambda val: True)
    assert try_0 == Try.of(lambda: float_0, float_0).filter(lambda val: False)
    assert True == Try.of(lambda: float_0, float_0).filter(lambda val: True).is_success
    assert False == Try.of(lambda: float_0, float_0).filter(lambda val: False).is_success



# Generated at 2022-06-25 23:54:03.222268
# Unit test for method filter of class Try
def test_Try_filter():
    __test_Try_filter_0()
    __test_Try_filter_1()

# func test for method filter of class Try

# Generated at 2022-06-25 23:54:13.923581
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1972.108
    bool_0 = False
    try_0 = Try(float_0, bool_0)
    float_1 = 1972.108
    bool_1 = True
    try_1 = Try(float_1, bool_1)
    float_2 = 3587.697
    bool_2 = True
    try_2 = Try(float_2, bool_2)
    bool_3 = False
    try_3 = Try(bool_3, bool_3)
    bool_4 = True
    try_4 = Try(bool_4, bool_4)
    bool_5 = True
    try_5 = Try(bool_5, bool_5)
    bool_6 = True
    try_6 = Try(bool_6, bool_6)

# Generated at 2022-06-25 23:54:26.254560
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1972.108
    bool_0 = False
    try_0 = Try(float_0, bool_0)
    assert try_0.filter(lambda f_0: f_0 == 1972.108) == Try(float_0, bool_0)
    float_0 = -2983.939
    bool_0 = False
    try_0 = Try(float_0, bool_0)
    assert try_0.filter(lambda f_0: f_0 == -2983.939) == Try(float_0, bool_0)
    float_0 = -3533.767
    bool_0 = False
    try_0 = Try(float_0, bool_0)

# Generated at 2022-06-25 23:54:39.084424
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1.268
    bool_0 = True
    try_0 = Try(float_0, bool_0)
    try_1 = try_0.filter(lambda x: x > 0.5)

    assert(try_0 != try_1)
    assert(try_1.value == float_0)
    assert(try_1.is_success)

    try_2 = try_1.filter(lambda x: x > 2.0)

    assert(try_2 != try_1)
    assert(try_2.value == float_0)
    assert(not try_2.is_success)

    int_0 = -100
    bool_1 = True
    try_3 = Try(int_0, bool_1)


# Generated at 2022-06-25 23:54:43.412120
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1972.108
    bool_0 = False
    try_0 = Try(float_0, bool_0)
    assert try_0.filter(lambda x:x<1000) == Try(float_0, bool_0)


# Generated at 2022-06-25 23:54:52.335304
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1972.108
    bool_0 = True
    try_0 = Try(float_0, bool_0)
    def filterer_0(arg_0):
        return arg_0 < 1972
    try_1 = try_0.filter(filterer_0)
    assert not try_1.is_success
    assert try_1.value == float_0

    float_1 = -1671.0
    bool_1 = True
    try_2 = Try(float_1, bool_1)
    def filterer_1(arg_1):
        return arg_1 < 1972
    try_3 = try_2.filter(filterer_1)
    assert try_3.is_success
    assert try_3.value == float_1


# Generated at 2022-06-25 23:55:03.726804
# Unit test for method filter of class Try
def test_Try_filter():
    def test_case_1():
        def fn_0():
            str_0 = "wh"
            int_0 = int(str_0)
            return int_0 * int_0

        def fn_1(value):
            return value % 2 == 0

        Try_0 = Try.of(fn_0)
        Try_1 = Try_0.filter(fn_1)
        bool_1 = Try_1.is_success
        bool_0 = bool_1

    def test_case_2():
        def fn_4():
            str_0 = "wh"
            int_0 = int(str_0)
            return int_0 * int_0

        def fn_5(value):
            return value % 2 == 0

        Try_2 = Try.of(fn_4)

# Generated at 2022-06-25 23:55:11.673456
# Unit test for method filter of class Try
def test_Try_filter():
    # Assert for for successful Monad
    assert Try(4, True).filter(lambda x: isinstance(x, int)) == Try(4, True)
    # Assert for not successful Monad
    assert Try(4, False).filter(lambda x: isinstance(x, int)) == Try(4, False)
    # Assert for successful Monad and filterer return False
    assert Try(4, True).filter(lambda x: isinstance(x, str)) == Try(4, False)


# Generated at 2022-06-25 23:55:17.734333
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = "value"
    bool_0 = False
    try_0 = Try.of(lambda x: x, str_0)
    try_1 = try_0.filter(lambda x: x.startswith("v"))
    try_2 = try_1.filter(lambda x: x.endswith("e"))
    bool_1 = try_2.is_success
    str_1 = try_2.get()



# Generated at 2022-06-25 23:55:30.215397
# Unit test for method filter of class Try
def test_Try_filter():
    # Unit test for method filter of class Try with lambda function.
    float_0 = 1972.108
    bool_0 = True
    try_0 = Try(float_0, bool_0).filter(lambda x: x > 1972.0)
    bool_1 = try_0.is_success
    assert bool_1 == True
    float_1 = try_0.get()
    assert float_1 == 1972.108
    # Unit test for method filter of class Try with lambda function.
    float_0 = 1972.108
    bool_0 = True
    try_0 = Try(float_0, bool_0).filter(lambda x: x < 1972.0)
    bool_1 = try_0.is_success
    assert bool_1 == False
    float_1 = try_0.get()
    assert float_1 == 1972

# Generated at 2022-06-25 23:55:37.224617
# Unit test for method filter of class Try
def test_Try_filter():
    float_0 = 1972.108
    bool_0 = False
    try_0 = Try(float_0, bool_0)
    def pred_fn(arg_0):
        return arg_0 > 1972.108

    ret_2 = try_0.filter(pred_fn)
    assert (ret_2.is_success == False)

    string_0 = "owo"
    bool_2 = True
    try_1 = Try(string_0, bool_2)

    ret_0 = try_1.filter(pred_fn)
    assert (ret_0.is_success == True)


# Generated at 2022-06-25 23:55:39.481095
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value % 2 == 0

    @property
    def monad():
        return Try(1, True)

    assert monad.filter(filterer) == Try(1, False)



# Generated at 2022-06-25 23:55:51.235271
# Unit test for method filter of class Try
def test_Try_filter():
    # in 1: test with not successfully monad
    # in   1.1: try_0.filter(lambda x: True)
    # in   1.2: try_0.filter(lambda x: False)

    # in 2: test with successfully monad
    # in   2.1: try_1.filter(lambda x: True)
    # in   2.2: try_1.filter(lambda x: False)

    # in 1: test with not successfully monad
    # in   1.1: try_0.filter(lambda x: True)
    float_0 = 1972.108
    bool_0 = False
    try_0 = Try(float_0, bool_0)
    try_0.filter(lambda x: True)

    # in   1.2: try_0.filter(lambda x: False)

# Generated at 2022-06-25 23:56:00.873621
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    try_0 = Try.of(int, '100')
    try_1 = Try.of(int, '-100')

    try_0_filtered = try_0.filter(filterer)
    try_1_filtered = try_1.filter(filterer)

    return try_0_filtered.is_success == True and try_1_filtered.is_success == False


# Generated at 2022-06-25 23:56:06.970033
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_even(val):
        return val % 2 == 0

    def is_negative(val):
        return val < 0

    cases = [
        dict(
            args=dict(
                filterer=is_even,
            ),
            expected=Try(1, False),
        ),
        dict(
            args=dict(
                filterer=is_negative,
            ),
            expected=Try(1, False),
        ),
        dict(
            args=dict(
                filterer=is_even,
            ),
            expected=Try(2, True),
        ),
        dict(
            args=dict(
                filterer=is_negative,
            ),
            expected=Try(-1, True),
        ),
    ]


# Generated at 2022-06-25 23:56:18.489129
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try
    """
    # Test for when filterer returns true
    def filterer_true():
        a = Try(5, True)
        res = a.filter(lambda _: True)
        assert res == Try(5, True)
    
    filterer_true()
    
    # Test for when filterer returns false
    def filterer_false():
        a = Try(5, True)
        res = a.filter(lambda _: False)
        assert res == Try(5, False)
    
    filterer_false()
    
    # Test for when filterer returns false and Try is not successfully
    def filterer_NotSuccessfully():
        a = Try(5, False)
        res = a.filter(lambda _: False)

# Generated at 2022-06-25 23:56:24.840382
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)

    bool_1 = True
    try_1 = Try(bool_1, bool_1)

    assert try_1.filter(lambda v: True).is_success
    assert not try_1.filter(lambda v: False).is_success
    assert try_0.filter(lambda v: True).is_success == try_0.is_success
    assert try_0.filter(lambda v: False).is_success == try_0.is_success



# Generated at 2022-06-25 23:56:29.330907
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.filter(lambda x: True) == try_0
    bool_1 = False
    try_1 = Try(bool_1, bool_0)
    assert try_1.filter(lambda x: True) != try_1


# Generated at 2022-06-25 23:56:34.285612
# Unit test for method filter of class Try
def test_Try_filter():
    """Test Try filter method"""
    def test_filter(value, expected):
        """Test Try filter method"""
        try_ = Try(value, True)
        try_filtered = try_.filter(lambda x: x)
        assert try_filtered.is_success == expected
        assert try_filtered.value == value
    test_filter(False, False)
    test_filter(True, True)


# Generated at 2022-06-25 23:56:40.964552
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_1 = not bool_0
    assert try_0.filter(lambda var_0: var_0 == True) == Try(bool_0, bool_0)
    assert try_0.filter(lambda var_0: var_0 == False) == Try(bool_0, not bool_0)


# Generated at 2022-06-25 23:56:49.941230
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0_success = True
    bool_0 = True

    bool_1_success = True
    bool_1 = False

    bool_2_success = False
    bool_2 = True

    bool_3_success = False
    bool_3 = False

    bool_0_try = Try(bool_0, bool_0_success)
    bool_1_try = Try(bool_1, bool_1_success)
    bool_2_try = Try(bool_2, bool_2_success)
    bool_3_try = Try(bool_3, bool_3_success)

    filter_bool_0 = bool_0_try.filter(lambda value: value == bool_0)
    filter_bool_1 = bool_1_try.filter(lambda value: value == bool_0)
    filter_bool_

# Generated at 2022-06-25 23:57:02.081373
# Unit test for method filter of class Try
def test_Try_filter():
    # Positive test
    print('Positive test for method filter of class Try')
    bool_0 = True
    try_0 = Try(True, True)
    print('Try({}, {})'.format(bool_0, bool_0))
    try_0 = try_0.filter(lambda x: x == bool_0)
    print('Try({}, {})'.format(bool_0, bool_0))
    assert try_0 == Try(bool_0, bool_0)
    print('Passed')
    # Negative test
    print('Negative test for method filter of class Try')
    bool_0 = False
    try_0 = Try(True, True)
    print('Try({}, {})'.format(True, True))
    try_0 = try_0.filter(lambda x: x == bool_0)
   

# Generated at 2022-06-25 23:57:13.600586
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = 1
    try_0 = Try(bool_0, 1)
    try_0.filter(lambda bool_1: bool(bool_1))

    bool_0 = 'True'
    try_0 = Try(bool_0, 'True')
    bool_1 = try_0.filter(lambda bool_2: bool(bool_2)).get()

    bool_0 = 0
    try_0 = Try(bool_0, 0)
    bool_1 = try_0.filter(lambda bool_2: bool(bool_2)).get()

    bool_0 = None
    try_0 = Try(bool_0, None)
    bool_1 = try_0.filter(lambda bool_2: bool(bool_2)).get()


# Generated at 2022-06-25 23:57:22.656905
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: True).get() == 1
    assert Try(1, True).filter(lambda x: False).get() != 1
    assert Try(1, False).filter(lambda x: False).get() != 1
    assert Try(1, False).filter(lambda x: True).get() != 1
test_Try_filter.__doc__ = '''Test for method filter of class Try'''



# Generated at 2022-06-25 23:57:25.682956
# Unit test for method get of class Try
def test_Try_get():
    success_instance = Try(10, True)
    assert success_instance.get() == 10
    fail_instance = Try(Exception('Test'), False)
    assert fail_instance.get() == Exception('Test')


# Generated at 2022-06-25 23:57:36.283151
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '\n    Test for method filter of class Try\n    '
    s_0 = 'test_Try_filter'
    s_1 = 'Test for method filter of class Try'
    fn_0 = lambda el_0: el_0 == 3
    fn_1 = lambda: 3
    fn_2 = lambda el_0: el_0 == 1
    fn_3 = lambda: 1
    s_2 = Try(fn_1(), True)
    s_3 = s_2.filter(fn_0)

    def fn_4():
        s_3.filter(fn_2)
        s_0
        return s_1
    s_4 = Try(fn_4, None)
    s_5 = s_4.get_or_else(str_0)
    s_6 = Try

# Generated at 2022-06-25 23:57:43.677700
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    str_0 = '\n    Test for method on_fail of class Try\n    '
    def _case_0_default_arguments():
        str_0 = '\n        Case of default arguments\n        '
        cases = [
            Try(5, False),
            Try(5, True)
        ]
        results = [
            'value=5',
            ''
        ]
        for result, case in zip(results, cases):
            str_1 = '\n            case: {}\n            '.format(case)
            str_2 = '\n            result: {}\n            '.format(result)
            assert_1 = case.on_fail(lambda x: print('value={}'.format(x))).get_or_else(result) == result

# Generated at 2022-06-25 23:57:46.618239
# Unit test for method get of class Try
def test_Try_get():
    my_try = Try.of(lambda: 2, 10, 2)
    assert my_try.get() == 2, 'Try get method error'


# Generated at 2022-06-25 23:57:54.797398
# Unit test for constructor of class Try
def test_Try():
    str_0 = 'Test for constructor of class Try'
    str_1 = 'Test for constructor of class Try - throw exception'
    try:
        assert Try(0, True) == Try(0, True)
        assert Try(1, False) == Try(1, False)
        print(str_0)
    except Exception as e:
        print(str_0)
        print(e)
    try:
        assert Try(0, True) != Try(1, False)
        print(str_0)
    except Exception as e:
        print(str_0)
        print(e)


# Generated at 2022-06-25 23:58:03.170405
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    str_0 = '\n    Test for method on_fail of class Try\n    '
    try_0 = Try.of(lambda: 0 / 1)

# Generated at 2022-06-25 23:58:13.973745
# Unit test for method bind of class Try
def test_Try_bind():
    str_0 = '\n    Unit test for method bind of class Try\n    '
    str_1 = '\n        Test for successful values\n        '
    print(str_0)
    print(str_1)

    def sum_of_two_and_three(a):
        return Try(a + 2, True)

    def sum_of_three_and_three(a):
        return Try(a + 3, True)

    def raise_exception(a):
        raise Exception()

    assert Try(5, True).bind(sum_of_two_and_three).get() == 7, 'Method bind - test_0 failed'

# Generated at 2022-06-25 23:58:24.169793
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    str_0 = '\n    Test for method get_or_else of class Try\n    '
    Try_0 = Try.of(int, '5')
    Try_1 = Try_0.map(lambda x: x + 10)
    Try_2 = Try_1.map(lambda x: x / 5)
    def func_0(val):
        return val + 5
    Try_3 = Try_2.map(func_0)
    Try_4 = Try_3.map(lambda x: x * 2)
    Try_5 = Try_4.filter(lambda x: x % 2 == 0)
    Try_6 = Try_5.filter(lambda x: x % 4 == 0)
    Try_7 = Try_6.filter(lambda x: x % 4 == 0)
    Try_8 = Try_7

# Generated at 2022-06-25 23:58:33.011811
# Unit test for method on_success of class Try
def test_Try_on_success():
    str_0 = '\n    Unit test for method on_success of class Try\n    '
    l_0 = [1]
    def on_success_0(val):
        l_0[0] += val

    Try.of(int, '1').on_success(on_success_0).on_fail(lambda e: 1/0)
    assert l_0[0] == 2
    Try(Exception, False).on_success(lambda e: 1/0).on_fail(lambda e: 1)
    assert l_0[0] == 2
    str_1 = '\n    Unit test for method on_success of class Try passed successfully\n    '


# Generated at 2022-06-25 23:58:41.432059
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    str_0 = '\n    Test for method get_or_else of class Try\n    '
    assert Try.of(lambda: 1).get_or_else(0) == 1, str_0 + ': step 1'
    assert Try.of(lambda: 0 / 0).get_or_else(1) == 1, str_0 + ': step 2'


# Generated at 2022-06-25 23:58:49.080748
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    str_0 = '\n    Test for method on_fail of class Try\n    '

    # Case 0
    # Test with successful monad
    t0 = 'Test with successful monad'

    def f0():
        assert 'Exception: Error' == Try.of(int, '1').on_fail(lambda e: str(e)).get()
        assert 1 == Try.of(int, '1').on_fail(lambda e: str(e)).get()
    f0()

    # Case 1
    # Test with not successful monad
    t1 = 'Test with not successful monad'

    def f1():
        assert 'Error' == Try.of(int, 'a').on_fail(lambda e: str(e)).get()
    f1()

# Main

# Generated at 2022-06-25 23:59:00.773844
# Unit test for constructor of class Try
def test_Try():
    def test_case_0():
        str_0 = '\n    Test for constructor of class Try\n    '

        try_0 = Try(10, True)
        assert_equal(try_0.value, 10)
        assert_equal(try_0.is_success, True)

        print(str_0 + ' - Done')

    def test_of():
        str_0 = '\n    Test for method of of class Try\n    '

        try_0 = Try.of(lambda x: x, 5)
        assert_equal(try_0.value, 5)
        assert_equal(try_0.is_success, True)

        try_1 = Try.of(lambda x, y: x/y, 5, 2)
        assert_equal(try_1.value, 2.5)

# Generated at 2022-06-25 23:59:07.238294
# Unit test for method get of class Try
def test_Try_get():
    # muestra cuando un elemento es success

    # se verifica lo mostrado en el caso
    try_true = Try.of(lambda: 1, '')
    assert try_true.is_success == True

    # muestra cuando un elemento es success
    # se verifica lo mostrado en el caso
    try_false = Try.of(lambda: None, 0)
    assert try_false.is_success == False



# Generated at 2022-06-25 23:59:12.592516
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    str_0 = '\n    Test for method on_fail of class Try\n    '
    Try_0 = Try.of(lambda arg_1: arg_1, 1)
    Try_0.on_fail(lambda arg_1: None)
    Try_0 = Try.of(lambda arg_1: 0 / 0, 1)
    Try_0.on_fail(lambda arg_1: None)
    str_1 = '\n    Test for method bind of class Try\n    '


# Generated at 2022-06-25 23:59:17.194422
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_case_0():
        # when
        def success_callback(result):
            global success_callback_called
            success_callback_called = True
        # then
        global success_callback_called
        success_callback_called = False
        # and
        value = 1
        # when
        try_ = Try(value, True)
        # and
        try_.on_success(success_callback)
        # then
        assert success_callback_called is True
        # and
        assert try_.value == value
        assert try_.is_success is True
    test_case_0()
    return True


# Generated at 2022-06-25 23:59:18.882320
# Unit test for method bind of class Try
def test_Try_bind():
    str_0 = '\n    Unit test for method bind of class Try\n    '


# Generated at 2022-06-25 23:59:27.193822
# Unit test for method __str__ of class Try
def test_Try___str__():
    str_0 = 'Try[value=None, is_success=False]'
    str_1 = 'Try[value=None, is_success=True]'
    str_2 = 'Try[value=None, is_success=None]'
    str_3 = 'Try[value=[], is_success=False]'
    str_4 = 'Try[value=[], is_success=True]'
    str_5 = 'Try[value=[], is_success=None]'
    str_6 = 'Try[value=False, is_success=False]'
    str_7 = 'Try[value=False, is_success=True]'
    str_8 = 'Try[value=False, is_success=None]'
    str_9 = 'Try[value=True, is_success=False]'

# Generated at 2022-06-25 23:59:35.114385
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    str_0 = '\n    Unit test for method get_or_else of class Try\n    '

    def fn_0(x):
        return x + 1

    class A:
        pass

    a_0 = A()
    a_1 = A()

    assert 1 == a_0.get_or_else(1)
    assert 1 == A.get_or_else(Try(None, False), 1)
    assert 1 == A.get_or_else(Try(a_0, False), 1)



# Generated at 2022-06-25 23:59:38.340325
# Unit test for method get of class Try
def test_Try_get():
    str_0 = '\n    Unit test for method get of class Try\n    '
    str_1 = '\n        Test for successfully monad\n        '
    str_2 = '\n        Test for not successfully monad\n        '



# Generated at 2022-06-25 23:59:46.466023
# Unit test for method on_success of class Try
def test_Try_on_success():
    str_0 = Try.of(int, '10')

    assert str_0.on_success(lambda x: print(x)) == str_0
    str_1 = Try.of(int, 'a')
    assert str_1.on_success(lambda x: print(x)) == str_1


# Generated at 2022-06-25 23:59:54.307614
# Unit test for method on_success of class Try
def test_Try_on_success():

    str_0 = '\n    Test for method on_success of class Try\n    '
    print(str_0)

    def test_case_0():
        str_0 = str_0 + '\n    - test case 0\n    '
        value = [1, 2, 3, 4, 5]
        try_value = Try.of(lambda: value + [6], value)
        try_value.on_success(lambda _: print(str_0 + 'on_success: used with success'))
        try_value.on_fail(lambda _: print(str_0 + 'on_success: used with fail'))

# Generated at 2022-06-25 23:59:55.895407
# Unit test for method bind of class Try
def test_Try_bind():
    str_0 = '\n    Test for method bind of class Try\n    '



# Generated at 2022-06-26 00:00:05.344992
# Unit test for method get of class Try
def test_Try_get():
    # Test for method get of class Try
    def test_case_0():
        str_0 = '\n        Test for method get of class Try\n        '
        print(str_0)

        def in_try_0(value):
            def in_try_1(value_0):
                return value_0

            return Try.of(in_try_1, value)

        def in_try_2(value):
            return value

        def in_try_3(value):
            return value

        assert in_try_0(2).get() == in_try_0(2).get()
        assert in_try_0(1).map(in_try_3).get() == in_try_0(1).map(in_try_3).get()

# Generated at 2022-06-26 00:00:10.354304
# Unit test for method __str__ of class Try
def test_Try___str__():
    print('\n\n\n>>> Unit test for method __str__ of class Try:')

    obj_0 = Try(12, True)
    print(obj_0)

    obj_1 = Try(None, False)
    print(obj_1)



# Generated at 2022-06-26 00:00:12.974001
# Unit test for method map of class Try
def test_Try_map():
    def double(x):
        return x * 2

    res = Try.of(int, '2').map(double)
    assert res == Try(4, True)


# Generated at 2022-06-26 00:00:18.615666
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try:
        str_0 = '\n    Test for method __eq__ of class Try\n    '

        assert Try(10, True) == Try(10, True)
        assert Try(10, False) == Try(10, False)
        assert not Try(10, True) == Try(10, False)
        assert not Try(10, False) == Try(10, True)
        assert Try(10, True) == Try(10, True)

        return '{} test passed'.format(str_0)
    except AssertionError as e:
        return '{} test not passed\n{}'.format(str_0, e)


# Generated at 2022-06-26 00:00:27.020915
# Unit test for method map of class Try
def test_Try_map():
    str_0 = '\n    Test for method map of class Try\n    '
    def fun_1(value):
        return value + 1

    try_0 = Try(0, False)
    try_1 = Try(1, True)

    assert str_0 + 'When try is not successfully, method map do nothing',\
        Try(0, False) == try_0.map(fun_1)

    assert str_0 + 'When try is successfully, method map do function on try value',\
        Try(2, True) == try_1.map(fun_1)


# Generated at 2022-06-26 00:00:36.074603
# Unit test for method bind of class Try
def test_Try_bind():
    str_0 = '\n    Test for method bind of class Try\n    '
    def filter_0(value):
        return True if value == 'Hello World!' else False
    def filter_1(value):
        return True if value == 'Hello, World!' else False

    # Test when value is filtered
    assert Try.of(lambda: 'Hello World!').bind(
        lambda x: Try(x, filter_0(x))).get() == 'Hello World!'

    # Test when value is not filtered
    assert Try.of(lambda: 'Hello, World!').bind(
        lambda x: Try(x, filter_1(x))).get_or_else('Hello World!') == 'Hello World!'


# Generated at 2022-06-26 00:00:43.196221
# Unit test for method get of class Try
def test_Try_get():
    str_0 = '\n    Test for method get of class Try\n    '
    def test_case_0():
        str_0 = '\n        Test case #0\n        '
        success_value = 1
        success_try = Try(success_value, True)
        assert success_value == success_try.get()
        print(str_0 + 'SUCCESS')
    test_case_0()

    def test_case_1():
        str_0 = '\n        Test case #1\n        '
        success_value = 1
        success_try = Try(success_value, False)
        assert success_value == success_try.get()
        print(str_0 + 'SUCCESS')
    test_case_1()
    print(str_0 + 'SUCCESS')



# Generated at 2022-06-26 00:00:50.461920
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(int, '4').get_or_else(1) == 4
    assert Try.of(int, 'four').get_or_else(1) == 1


# Generated at 2022-06-26 00:00:58.925213
# Unit test for method get of class Try
def test_Try_get():
    def test_case_1():
        str_0 = '\n    Test for method get of class Try\n    '
        t_0 = Try.of(str, 'str')
        success_0 = t_0.get() == 'str'
        t_1 = Try.of(int, 'str')
        success_1 = False == t_1.is_success
        return [success_0, success_1]
    def test_case_2():
        str_0 = '\n    Test for method get of class Try\n    '
        t_0 = Try.of(str, 'str')
        success_0 = t_0.get() == 'str'
        t_1 = Try.of(int, 'str')
        success_1 = False == t_1.is_success

# Generated at 2022-06-26 00:01:07.277703
# Unit test for method get of class Try
def test_Try_get():
    def test_case_0():
        str_0 = '\n    Unit test for method get of class Try\n    '
        def case_0():
            str_0 = '\n        Case 0\n        '

            def test_0():
                expected = 1
                result = Try(1, True).get()
                assert result == expected, ' {0} must be {1} \n actual = {2}'.format('result', expected, result)
            test_0()

            def test_1():
                expected = 0
                result = Try(0, False).get()
                assert result == expected, ' {0} must be {1} \n actual = {2}'.format('result', expected, result)
            test_1()

            print(str_0)
        case_0()

    test_case_0()

# Generated at 2022-06-26 00:01:11.530512
# Unit test for method bind of class Try
def test_Try_bind():
    # Add test code here
    str_0 = '\n    Test for method bind of class Try\n    '


# Generated at 2022-06-26 00:01:17.102872
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    str_0 = "\n    Tests for method get_or_else of class Try\n    "
    assert Try.of(lambda : 2 / 3, None).get_or_else(0.0) == \
        2 / 3, \
        "    Unit test failed\n    " + \
        str_0
    assert Try.of(lambda : 2 / 0, None).get_or_else(0.0) == \
        0.0, \
        "    Unit test failed\n    " + \
        str_0
    print("    Unit test passed\n    " + str_0)


# Generated at 2022-06-26 00:01:26.760323
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def assert_test(test_name, result, expected):
        assert result == expected, f'Test "{test_name}" failed. Expected: {expected}, result: {result}'

    str_0 = '\n    Test for method on_fail of class Try\n    '

    # Case 0
    test_name = 'Case 0'

    expected = False
    result = False

    assert_test(test_name, result, expected)

    # Case 1
    def fail_callback(value):
        nonlocal expected, result
        expected = True
        result = True

    test_name = 'Case 1'

    expected = True
    result = False
    t = Try.of(lambda: 1 / 0)
    _ = t.on_fail(fail_callback)

    assert_test(test_name, result, expected)



# Generated at 2022-06-26 00:01:32.531718
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '\n    Test for method filter of class Try\n    '
    val = 10
    try_0 = Try(val, True).filter(lambda x: x > 5)
    try_1 = Try(val, True).filter(lambda x: x > 15)
    try_2 = Try(val, False).filter(lambda x: x > 15)
    assert try_0 == Try(val, True)
    assert try_1 == Try(val, False)
    assert try_2 == Try(val, False)

# Generated at 2022-06-26 00:01:41.490377
# Unit test for method bind of class Try
def test_Try_bind():
    some_value = 0
    def __throwing_fn_0():
        raise Exception('Exception 0')

    def __mapper_0(value):
        return value + 1

    def __binder_0(value):
        return Try(value + 1, True)

    def __success_callback_0(value):
        nonlocal some_value
        some_value = value

    def __fail_callback_0(value):
        nonlocal some_value
        some_value = value

    def __filterer_0(value):
        return value > 11


# Generated at 2022-06-26 00:01:50.784776
# Unit test for method on_success of class Try
def test_Try_on_success():
    str_0 = '\n    Test for method on_success of class Try\n    '

    def test_on_success(value):
        assert value is None

    def test_on_fail(value):
        assert False

    @Try.of
    def test_method(str1):
        assert str1 == str_0
        return

    assert test_method.is_success
    assert test_method.value is None

    test_method.on_success(test_on_success).on_fail(test_on_fail)

    @Try.of
    def test_exception_method(str1):
        assert str1 == str_0
        raise Exception('')

    assert not test_exception_method.is_success
    assert test_exception_method.value is not None

    test_exception_method

# Generated at 2022-06-26 00:01:57.436054
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '\n    Test for method filter of class Try\n    '

    def Filterer(value):
        return value > 'a'

    result = Try(2, True).filter(Filterer)
    success_value = result.get()
    success_is_success = result.is_success

    assert success_value == 2, f'Success value was {success_value}. {str_0}'
    assert success_is_success == True, f'Success is_success was {success_is_success}. {str_0}'


# Generated at 2022-06-26 00:02:04.501065
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(True, True)) == 'Try[value=True, is_success=True]'
    assert str(Try(False, False)) == 'Try[value=False, is_success=False]'


# Generated at 2022-06-26 00:02:06.164177
# Unit test for constructor of class Try
def test_Try():
    test_case_0()
    print("test for constructor of class Try is passed")



# Generated at 2022-06-26 00:02:10.791972
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    bool_1 = False

    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0)
    assert try_0 == try_1

    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_1)
    assert not try_0 == try_1

    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_0)
    assert not try_0 == try_1


# Generated at 2022-06-26 00:02:14.326974
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    bool_1 = False

    try_0 = Try(bool_0, bool_0)
    try_1 = Try(True, True)
    try_2 = Try(False, True)

    assert(try_0 == try_1)
    assert(try_0 != try_2)



# Generated at 2022-06-26 00:02:16.460203
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    value = try_0.__str__()
    assert value == 'Try[value=True, is_success=True]'



# Generated at 2022-06-26 00:02:19.641068
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(val):
        raise Exception(val)

    with raises(Exception):
        Try(1, False).on_fail(fail_callback)

    Try(1, True).on_fail(fail_callback)


# Generated at 2022-06-26 00:02:21.553986
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try(True, True)
    try_2 = Try(True, True)
    assert try_0 == try_2

# Generated at 2022-06-26 00:02:24.163632
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert str(try_0) == 'Try[value=True, is_success=True]'



# Generated at 2022-06-26 00:02:29.585523
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 'a', None) == Try('a', True)
    assert Try.of(lambda: 1 / 0, None) == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(lambda: 'a', None).bind(lambda el: Try('b', True)) == Try('b', True)
    assert Try.of(lambda: 'a', None).bind(lambda el: Try(1 / 0, True)) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-26 00:02:34.030278
# Unit test for method map of class Try
def test_Try_map():
    value_0 = True  # type: bool
    try_0 = Try(value_0, True)  # type: Try[bool]
    try_1 = try_0.map(lambda x: not x)  # type: Try[bool]
    assert try_1.get() is False


# Generated at 2022-06-26 00:02:52.379154
# Unit test for method map of class Try
def test_Try_map():
    fn_0 = lambda x: x * 2
    try_0 = Try(1, True)
    try_1 = Try(2, True)
    assert try_0.map(fn_0) == Try(2, True)
    assert try_1.map(fn_0) == Try(4, True)


# Generated at 2022-06-26 00:02:55.813249
# Unit test for method get of class Try
def test_Try_get():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.get() == bool_0
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.get() == bool_0


# Generated at 2022-06-26 00:03:01.379818
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(True, True).on_success(lambda _: None) == Try(True, True)
    assert Try(True, False).on_success(lambda _: None) == Try(True, False)

    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_0.on_success(lambda _: print('Successful'))
    try_0.on_fail(lambda _: print('Not successful'))
# # Unit test for method on_fail of class Try