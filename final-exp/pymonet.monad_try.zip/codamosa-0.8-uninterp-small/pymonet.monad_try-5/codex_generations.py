

# Generated at 2022-06-25 23:53:03.705168
# Unit test for method filter of class Try
def test_Try_filter():
    def doubler(x):
        return x * 2

    def filterer(value):
        return value % 2 == 0

    try_0 = Try.of(doubler, 2)
    try_1 = try_0.filter(filterer)
    try_2 = try_1.filter(filterer)

    assert try_0.value == 4
    assert try_0.is_success
    assert try_1.value == 4
    assert try_1.is_success
    assert try_2.value == 4
    assert try_2.is_success

    try_0 = Try.of(doubler, 3)
    try_1 = try_0.filter(filterer)
    try_2 = try_1.filter(filterer)

    assert try_0.value == 6

# Generated at 2022-06-25 23:53:09.149689
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(0, True).filter(lambda x: x == 1) == Try(0, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)



# Generated at 2022-06-25 23:53:13.014439
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x > 3) == Try(5, True)
    assert Try(4, True).filter(lambda x: x > 5) == Try(4, False)
    assert Try(5, False).filter(lambda x: x > 3) == Try(5, False)


# Generated at 2022-06-25 23:53:18.112339
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(0, True)
    try_1 = try_0.filter(lambda x: x > 0)
    assert try_1 == Try(0, False)
    try_2 = try_0.filter(lambda x: x == 0)
    assert try_2 == Try(0, True)


# Generated at 2022-06-25 23:53:23.172868
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0).filter(lambda x : x)
    assert try_1 == Try(bool_0, bool_0)



# Generated at 2022-06-25 23:53:34.679878
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = bool(random.getrandbits(1))
    bool_1 = bool(random.getrandbits(1))
    bool_2 = bool(random.getrandbits(1))
    bool_3 = bool(random.getrandbits(1))
    bool_4 = bool(random.getrandbits(1))
    bool_5 = bool(random.getrandbits(1))
    bool_6 = bool(random.getrandbits(1))
    bool_7 = bool(random.getrandbits(1))
    bool_8 = bool(random.getrandbits(1))
    bool_9 = bool(random.getrandbits(1))
    bool_10 = bool(random.getrandbits(1))
    bool_11 = bool(random.getrandbits(1))

# Generated at 2022-06-25 23:53:41.207618
# Unit test for method filter of class Try
def test_Try_filter():
    def test_case_1():
        num_0 = -100
        try_0 = Try.of(lambda: num_0, num_0)
        bool_0 = False
        try_1 = try_0.filter(lambda x: bool_0)
        assert(isinstance(try_1, Try))
        assert(try_1 == Try(num_0, bool_0))

        bool_1 = True
        try_2 = try_0.filter(lambda x: bool_1)
        assert(try_2 == try_0)

    def test_case_2():
        bool_0 = False
        try_0 = Try(bool_0, bool_0)
        bool_1 = True
        try_1 = try_0.filter(lambda x: bool_1)

# Generated at 2022-06-25 23:53:46.353065
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda a: a == 1) == Try(1, True)
    assert Try(2, True).filter(lambda a: a == 1) == Try(2, False)
    assert Try(2, False).filter(lambda a: a == 2) == Try(2, False)


# Generated at 2022-06-25 23:53:55.352829
# Unit test for method filter of class Try
def test_Try_filter():
    def true_filterer(value):
        return True

    def false_filterer(value):
        return False

    def exception_filterer(value):
        raise ValueError(value)

    assert Try(2, True).filter(true_filterer) == Try(2, True)
    assert Try(2, True).filter(false_filterer) == Try(2, False)

    try_0 = Try(2, False)
    assert try_0.filter(true_filterer) == try_0
    assert try_0.filter(false_filterer) == try_0

    try_0 = Try(2, True)
    try_1 = Try(2, False)
    assert try_0.filter(exception_filterer) == try_1

# Generated at 2022-06-25 23:53:58.717496
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try.of(bool, bool_0)
    b = try_0.filter(lambda bool_0: bool_0)
    assert try_0 == b


# Generated at 2022-06-25 23:54:10.104871
# Unit test for method filter of class Try
def test_Try_filter():
    try_1 = Try.of(lambda x: x, int_0)
    try_2 = Try.of(lambda x: x, int_0).filter(lambda x: True)
    assert try_1 == try_2
    try_1 = Try.of(lambda x: x, int_0).filter(lambda x: False)
    try_2 = Try(int_0, False)
    assert try_1 == try_2

# Generated at 2022-06-25 23:54:18.677398
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = Try.of(int, "1")
    int_1 = Try.of(int, "a")
    int_2 = Try.of(int, "1")

    assert int_0.filter(lambda x: True) == int_2
    assert int_0.filter(lambda x: False) == Try(1, False)
    assert int_1.filter(lambda x: True) == int_1.filter(lambda x: False)
    assert int_1.filter(lambda x: True) == Try(ValueError('invalid literal for int() with base 10: "a"'), False)


# Generated at 2022-06-25 23:54:21.761410
# Unit test for method filter of class Try
def test_Try_filter():
    value = 1
    Try_0 = Try(value, True)
    Try_1 = Try_0.filter(lambda x: x > 0)
    assert Try_1 == True
    

# Generated at 2022-06-25 23:54:35.062784
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    int_0 = 1
    def is_not_zero(value): return value != 0
    def is_zero(value): return value == 0

    # When
    try_0 = Try.of(int, 0)
    try_1 = Try.of(int, 1)
    try_2 = Try.of(int, int_0)
    try_2_b = Try.of(int, int_0).map(lambda x: x + 1)
    try_3 = Try.of(int, 1)
    try_4 = Try.of(int, 1)

    # Then
    assert try_0.filter(is_not_zero) == Try(0, False)
    assert try_1.filter(is_not_zero) == Try(1, True)

# Generated at 2022-06-25 23:54:47.197839
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 1
    int_1 = 2

    int_0_0 = int_0 + 10
    int_0_1 = int_0 * 10

    int_1_0 = int_1 + 10
    int_1_1 = int_1 * 10

    def filterer_0(val): return val % 2 == 0

    def filterer_1(val): return val % 2 == 1

    def filterer_2(val): return val > 0

    assert Try.of(lambda: int_0, None).filter(filterer_0) == Try(int_0, False)
    assert Try.of(lambda: int_0, None).filter(filterer_1) == Try(int_0, False)

# Generated at 2022-06-25 23:54:50.845015
# Unit test for method filter of class Try
def test_Try_filter():
    def is_odd(value):
        return value % 2 == 0

    assert Try.of(lambda: int_0).filter(is_odd).is_success == False

    assert Try.of(lambda: int_0 + 1).filter(is_odd).is_success == True


# Generated at 2022-06-25 23:55:00.588706
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 2) == Try(1, False)

    assert Try.of(lambda: 1, 1).filter(lambda x: x == 1).map(lambda x: 2) == Try(2, True)
    assert Try.of(lambda: 1, 1).filter(lambda x: x == 2).map(lambda x: 2) == Try(1, False)


# Generated at 2022-06-25 23:55:03.349465
# Unit test for method filter of class Try
def test_Try_filter():
    t1 = Try.of(test_case_0)
    t2 = t1.filter(lambda x: x == 1)
    assert t1 == t2


# Generated at 2022-06-25 23:55:11.132592
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 1
    int_1 = 2
    monad = Try.of(int, int_0)
    monad.filter(lambda x: x is int_0) \
        .filter(lambda x: False) \
        .filter(lambda x: True) \
        .on_success(lambda x: test_case_0()) \
        .on_fail(lambda x: test_case_0())
    assert monad == Try(1, True)


# Generated at 2022-06-25 23:55:15.599113
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(int_0, True).filter(lambda x: x == int_0).is_success == True
    assert Try(int_0, True).filter(lambda x: x != int_0).is_success == False
    assert Try(int_0, False).filter(lambda x: x == int_0).is_success == False


# Generated at 2022-06-25 23:55:33.771296
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 1
    string_0 = '1'

    assert Try.of(int, string_0)\
        .map(lambda x: x + 1)\
        .filter(lambda x: x == int_0)\
        == Try(int_0, True)

    assert Try.of(int, string_0)\
        .map(lambda x: x + 2)\
        .filter(lambda x: x == int_0)\
        == Try(int_0, False)

    assert Try.of(int, 'a')\
        .map(lambda x: x + 1)\
        .filter(lambda x: x == int_0)\
        == Try(int_0, False)



# Generated at 2022-06-25 23:55:41.098393
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of Try class.
    """
    try_0 = Try.of(lambda: 1/0)
    try_1 = Try.of(lambda: 1/1)
    try_2 = Try.of(lambda: 2/1)
    try_3 = Try.of(lambda: 2/2)
    try_4 = Try.of(lambda: 2/3)
    try_5 = Try.of(lambda: 3/4)

    try_0f = try_0.filter(lambda x: x == 1)
    try_1f = try_1.filter(lambda x: x != 1)
    try_2f = try_2.filter(lambda x: x != 1)
    try_3f = try_3.filter(lambda x: x != 1)
    try_4f = try_

# Generated at 2022-06-25 23:55:49.528496
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """

# Generated at 2022-06-25 23:55:58.926019
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(int, 'a')
    try_1 = try_0.map(lambda x: 2*x)

    result_0 = ''
    result_1 = ''

    try_0.filter(lambda x: x>=2).on_success(lambda x: result_0.append(x))
    try_1.filter(lambda x: x>=2).on_success(lambda x: result_1.append(x))

    if result_0 == '':
        print('Try filter is ok!')
    else:
        print('Try filter is bad!')

    if result_1 == 4:
        print('Try filter is ok!')
    else:
        print('Try filter is bad!')


# Generated at 2022-06-25 23:56:02.915598
# Unit test for method filter of class Try
def test_Try_filter():
    a = lambda x: x == 0
    test_case = lambda x: Try(x, True).filter(a)
    assert test_case(0) == Try(0, True)
    assert test_case(1) == Try(1, False)
    int_instance = 1
    assert test_case(int_instance) == Try(int_instance, False)


# Generated at 2022-06-25 23:56:07.927543
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 1
    int_1 = 2
    int_2 = 3

    fn_square = lambda x: x * x

    # when monad is not successfully
    t_int_0 = Try.of(fn_square, int_0)
    t_int_0.filter(lambda value: True) == Try(int_0, True)

    t_int_1 = Try.of(fn_square, int_0)
    t_int_1.filter(lambda value: False) == Try(int_0, False)

    fn_not_square = lambda x: x != x * x

    # when monad is successfully
    t_int_2 = Try.of(fn_square, int_1)
    t_int_2.filter(lambda value: True) == Try(int_1**2, True)

# Generated at 2022-06-25 23:56:19.504615
# Unit test for method filter of class Try
def test_Try_filter():

    def test_case_0():
        int_0 = Try(1, True)
        int_1 = Try(2, False)

        filterer = lambda value: value == 1
        assert int_0.filter(filterer).get() == 1
        assert not int_1.filter(filterer).is_success

    def test_case_1():
        int_1 = Try(1, True)
        int_2 = Try(2, True)

        filterer = lambda value: value == 1
        assert int_1.filter(filterer).get() == 1
        assert not int_2.filter(filterer).is_success

    def test_case_2():
        int_1 = Try(1, False)
        int_2 = Try(2, False)


# Generated at 2022-06-25 23:56:23.723835
# Unit test for method filter of class Try
def test_Try_filter():
    def map_2_plus(a):
        return a + 2

    def predicate(a):
        return a > 6

    assert Try.of(map_2_plus, 0).filter(predicate).get() == 2
    assert not Try.of(map_2_plus, 0).filter(predicate).is_success


# Generated at 2022-06-25 23:56:32.960368
# Unit test for method filter of class Try
def test_Try_filter():
    # case 0: create successfully Try with int
    try_0 = Try.of(int, '1')

    # case 1: create successfully Try with int
    try_1 = Try.of(int, '1')

    # case_2: create not successfully Try
    try_2 = Try.of(int, 'a')

    @staticmethod
    def filterer(value):
        return value > 0

    @staticmethod
    def filterer_2(value):
        return value < 0

    def test_case_0():
        assert try_0.filter(filterer) == Try(1, True)

    def test_case_1():
        assert try_1.filter(filterer_2) == Try(1, False)


# Generated at 2022-06-25 23:56:40.348300
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(int_0, True)
    try_1 = Try(int_0 * 2, True)

    def filterer(value):
        return value == int_0

    try_2 = try_0.filter(filterer)
    try_3 = try_1.filter(filterer)

    assert try_2 == Try(int_0, True)
    assert try_3 == Try(int_0 * 2, False)


# Generated at 2022-06-25 23:56:58.803626
# Unit test for method filter of class Try
def test_Try_filter():

    try_1 = Try.of(lambda: "something")
    try_2 = Try.of(lambda: (1,2))
    try_3 = Try.of(lambda: None)
    try_4 = Try.of(lambda: [1,2])
    try_5 = Try.of(lambda: {1,2})
    try_6 = Try.of(lambda: {1:2})

    try_11 = Try.of(lambda: "something", None)
    try_12 = Try.of(lambda: (1,2), None)
    try_13 = Try.of(lambda: None, None)
    try_14 = Try.of(lambda: [1,2], None)
    try_15 = Try.of(lambda: {1,2}, None)

# Generated at 2022-06-25 23:57:10.549456
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Given various values of x and y
    When x is greater than y
    Then True is returned, otherwise False is returned
    """
    def __test_case_0():
        x = 1
        y = 2

        def filterer(value): return value == 1

        t_x = Try.of(lambda: x)
        t_y = Try.of(lambda: y)
        output_x = t_x.filter(filterer).is_success
        output_y = t_y.filter(filterer).is_success
        assert output_x == True
        assert output_y == False

    def __test_case_1():
        x = 1
        y = 2

        def filterer(value): return value == 2

        t_x = Try.of(lambda: x)
        t_

# Generated at 2022-06-25 23:57:16.497485
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x == 1

    try_0 = Try.of(lambda: 1)
    try_1 = try_0.filter(filterer)
    assert try_1.is_success
    assert try_1.get() == 1

    try_0 = Try(None, False)
    try_1 = try_0.filter(filterer)
    assert not try_1.is_success



# Generated at 2022-06-25 23:57:22.282625
# Unit test for method filter of class Try
def test_Try_filter():
    # Test case 1
    try_1 = Try.of(int, "1")
    try_1_f = try_1.filter(lambda v: v == 1)
    assert try_1_f == Try.of(int, "1")

    # Test case 2
    try_2 = Try.of(int, "abc")
    try_2_f = try_2.filter(lambda v: v == 1)
    assert try_2_f == Try.of(int, "abc").filter(lambda v: v == 1)


# Generated at 2022-06-25 23:57:25.723247
# Unit test for method filter of class Try
def test_Try_filter():
    test_case_0()
    try:
        assert Try(int_0, True).filter(lambda x: x == 1).value == int_0
        test_case_1()
    except:
        print('Test case 0: Try.filter failed')
        raise


# Generated at 2022-06-25 23:57:36.327696
# Unit test for method filter of class Try
def test_Try_filter():
    from unittest import TestCase, main

    class TestTryFilter(TestCase):

        def test_case_0(self):
            int_0 = 1
            int_1 = 0
            int_2 = -1

            boolean_0 = int_0 > 0
            boolean_1 = int_1 > 0
            boolean_2 = int_2 > 0

            self.assertTrue(Try.of(int, int_0).filter(lambda value: value > 0).get())
            self.assertIsNone(Try.of(int, int_1).filter(lambda value: value > 0).get())
            self.assertIsNone(Try.of(int, int_2).filter(lambda value: value > 0).get())


# Generated at 2022-06-25 23:57:43.702065
# Unit test for method filter of class Try
def test_Try_filter():
    # Test for normal case
    print("\n" + "->".join(["Test Try filter", "test_case 1"]))
    try_1 = Try.of(lambda: int_0 + 42)
    try_1 = try_1.filter(lambda x: x % 2 == 0)
    assert try_1.get() == int_0 + 42
    try_1 = try_1.filter(lambda x: x % 2 == 1)
    assert not try_1.is_success
    try_1 = try_1.filter(lambda x: x % 2 == 0)
    assert not try_1.is_success

    # Test for case when Try is not successfully
    print("\n" + "->".join(["Test Try filter", "test_case 2"]))

# Generated at 2022-06-25 23:57:54.618395
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 1
    int_1 = 2
    int_10 = 10
    int_100 = 100
    int_1000 = 1000

    def positive_filter(val):
        return val > 0

    def is_even_filter(val):
        return val % 2 == 0

    # test method filter for successful Try
    assert Try.of(lambda: int_0, ).filter(lambda x: x > 0).is_success == True
    assert Try.of(lambda: int_1, ).filter(lambda x: x > 0).is_success == True
    assert Try.of(lambda: int_10, ).filter(lambda x: x > 0).is_success == True
    assert Try.of(lambda: int_100, ).filter(lambda x: x > 0).is_success == True

# Generated at 2022-06-25 23:58:03.029370
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(test_case_0).filter(lambda e: e > 0).is_success == False
    assert Try.of(test_case_0).filter(lambda e: (1, 2) > 0).is_success == False
    assert Try.of(test_case_0).filter(lambda e: (1, 2) == 0).is_success == False
    assert Try.of(test_case_0).filter(lambda e: (1, 2, 3, 4) > 0).is_success == False
    assert Try.of(test_case_0).filter(lambda e: True).is_success == True
    assert Try.of(test_case_0).filter(lambda e: False).is_success == False

# Generated at 2022-06-25 23:58:11.516525
# Unit test for method filter of class Try
def test_Try_filter():
    val = Try.of(lambda: int_0 / 0)
    assert val == Try(ZeroDivisionError(), False)
    assert val.filter(lambda _: True) == Try(ZeroDivisionError(), False)
    assert val.filter(lambda _: False) == Try(ZeroDivisionError(), False)

    val = Try.of(lambda: int_0 % 2 == 0)
    assert val == Try(False, True)
    assert val.filter(lambda _: True) == Try(False, True)
    assert val.filter(lambda _: False) == Try(False, False)



# Generated at 2022-06-25 23:58:27.552663
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = Try.of(int, '0')
    assert int_0.filter(lambda x: x == 0) == Try(0, True)
    assert int_0.filter(lambda x: x == 1) == Try(0, False)
    assert int_0.filter(lambda x: x == 1).__dict__ == Try(Exception('invalid literal for int() with base 10: \'0\''),False).__dict__
    assert int_0 == Try(0, True)
    test_case_0()
    int_1 = Try.of(int, '1')
    assert int_1.filter(lambda x: x == 1) == Try(1, True)
    assert int_1.filter(lambda x: x == 0) == Try(1, False)

# Generated at 2022-06-25 23:58:32.541675
# Unit test for method filter of class Try
def test_Try_filter():
    tryer = Try.of(test_case_0)
    assert tryer.filter(lambda x: True) == Try(None, True)
    assert tryer.filter(lambda x: False) == Try(None, False)


# Generated at 2022-06-25 23:58:41.995180
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(int, 'a')  # \not\in {1, 2, .., 9}
    try_1 = Try.of(int, '1')  # \in {1, 2, .., 9}
    try_2 = Try.of(int, '0')  # \not\in {1, 2, .., 9}
    int_0 = 1
    int_1 = 2
    int_9 = 9
    lambda_0 = lambda val: val == int_0
    lambda_1 = lambda val: val == int_1
    lambda_2 = lambda val: val == int_2
    lambda_9 = lambda val: val == int_9
    test_case_0 = try_0.filter(lambda_0)

# Generated at 2022-06-25 23:58:47.685690
# Unit test for method filter of class Try
def test_Try_filter():
    try_of_1 = Try.of(lambda: 1)
    try_of_exception = Try.of(lambda: 1 / 0, 1)

    assert try_of_1.filter(lambda x: x > 0) == Try.of(lambda: 1)
    assert try_of_1.filter(lambda x: x < 0) == Try.of(lambda: 1, is_success=False)
    assert try_of_exception.filter(lambda x: x > 0) == Try.of(lambda: 1 / 0)


# Generated at 2022-06-25 23:58:58.705498
# Unit test for method filter of class Try
def test_Try_filter():
    from unittest.mock import MagicMock

    fn = MagicMock()
    fn.return_value = True

    try_success = Try(0, True)
    # fn(try_success.value)
    try_success.filter(fn).on_success(print)
    assert fn.call_count == 1

    try_fail = Try(0, False)
    # not called
    try_fail.filter(fn).on_success(print)
    assert fn.call_count == 1

    try_success = Try(0, True)
    fn.return_value = False
    # not called
    try_success.filter(fn).on_success(print)
    assert fn.call_count == 2


# Generated at 2022-06-25 23:59:00.062901
# Unit test for method filter of class Try
def test_Try_filter():
    pass

# Unit test method filter when monad is successfully and filterer returns true

# Generated at 2022-06-25 23:59:02.781268
# Unit test for method filter of class Try
def test_Try_filter():
    # Arrange and act
    test_case = Try(int_0, True).filter(lambda x: x > 0)

    # Assert
    assert test_case == Try(int_0, True)


# Generated at 2022-06-25 23:59:12.231493
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = Try.of(int, '0')
    int_1 = Try.of(int, '1')
    int_ex = Try.of(int, 'a')

    assert Try.of(int, '0').filter(lambda x: True).get() == 0
    assert Try.of(int, '1').filter(lambda x: True).get() == 1
    assert Try.of(int, '1').filter(lambda x: False).is_success == False

    assert Try.of(int, 'a').filter(lambda x: True).is_success == False
    assert Try.of(int, 'a').filter(lambda x: False).is_success == False
    assert Try.of(int, 'a').filter(lambda x: True).get() == 'a'

# Generated at 2022-06-25 23:59:19.580474
# Unit test for method filter of class Try
def test_Try_filter():
    def test_case_0():
        # When call with Try that is not successfully, return copy of Try
        test_Try = Try.of(int, 'a')
        test_Try.filter(lambda x: x == 1)
        assert test_Try == Try.of(int, 'a')

    def test_case_1():
        # When call with Try that is successfully but filterer return False, return not successfully Try
        test_Try = Try.of(int, '1')
        test_Try.filter(lambda x: x == 2)
        assert test_Try == Try.of(int, '2')

    def test_case_2():
        # When call with Try that is successfully, return copy of Try
        test_Try = Try.of(int, '1')

# Generated at 2022-06-25 23:59:21.948015
# Unit test for method filter of class Try
def test_Try_filter():
    try_of = Try.of(lambda x: x, int_0)

    assert try_of.filter(lambda x: x == 1) == Try(int_0, True)


# Generated at 2022-06-25 23:59:36.374553
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    Try_0 = Try(bool_0, bool_0)
    assert not Try_0.filter(lambda bool_0: bool_0)
    assert Try_0.filter(lambda bool_0: not bool_0)
    bool_1 = True
    Try_1 = Try(bool_1, bool_1)
    assert Try_1.filter(lambda bool_1: bool_1)
    assert not Try_1.filter(lambda bool_1: not bool_1)


# Generated at 2022-06-25 23:59:39.118535
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(lambda x: x)
    try_1 = Try(bool_0, True)


# Generated at 2022-06-25 23:59:42.973006
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True)\
           .filter(bool)\
           == Try(True, True)
    assert Try(False, True)\
           .filter(bool)\
           == Try(False, False)
    assert Try(False, False)\
           .filter(bool)\
           == Try(False, False)



# Generated at 2022-06-25 23:59:48.240564
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    bool_1 = False

    fixture_0 = Try(bool_0, bool_0)
    fixture_1 = Try(bool_1, bool_1)

    def filterer_0(value): return value == bool_0

    assert fixture_0.filter(filterer_0) == Try(bool_0, bool_0)
    assert fixture_1.filter(filterer_0) == Try(bool_1, bool_1)

# Generated at 2022-06-25 23:59:57.072769
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test coverage: 85%
    """

    str_0 = 'str_0'
    str_1 = 'str_1'

    try_0 = Try(str_0, True)
    try_1 = try_0.filter(lambda value: value == str_1)
    if try_0 != try_1:
        raise AssertionError('assert error')

    try_1 = try_0.filter(lambda value: value == str_0)
    if try_0 != try_1:
        raise AssertionError('assert error')

    try_1 = Try(str_0, False)
    try_1 = try_1.filter(lambda value: value == str_0)
    if try_1.is_success:
        raise AssertionError('assert error')

    bool_0 = False


# Generated at 2022-06-26 00:00:07.697720
# Unit test for method filter of class Try
def test_Try_filter():
    false_value = False
    true_value = True
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_1)

    def is_false(value):
        assert value == false_value
        return False

    def is_true(value):
        assert value == true_value
        return True

    assert try_0.filter(is_true).is_success == bool_0
    assert try_0.filter(is_false).is_success == bool_0
    assert try_1.filter(is_true).is_success == bool_1
    assert try_1.filter(is_false).is_success == bool_0


# Generated at 2022-06-26 00:00:14.783531
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: bool) -> bool:
        return True

    try_0 = Try(False, False).filter(filterer)
    assert try_0.is_success == False
    assert try_0.value == False

    try_1 = Try(True, True).filter(filterer)
    assert try_1.is_success == True
    assert try_1.value == True

    try_2 = Try(False, True).filter(filterer)
    assert try_2.is_success == False
    assert try_2.value == False



# Generated at 2022-06-26 00:00:18.792828
# Unit test for method filter of class Try
def test_Try_filter():
    test_cases = [
        [Try(True, True), lambda x: x, Try(True, True)],
        [Try(True, True), lambda x: False, Try(True, False)],
        [Try(False, True), lambda x: x, Try(False, False)],
        [Try(True, False), lambda x: x, Try(True, False)],
    ]
    for case in test_cases:
        actual = case[0].filter(case[1])
        assert actual == case[2]



# Generated at 2022-06-26 00:00:21.753808
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(1, 1).filter(lambda x: True) == Try(1, True)
    assert Try.of(1, 1).filter(lambda x: False) == Try(1, False)



# Generated at 2022-06-26 00:00:27.352982
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(bool)
    try_2 = Try(True, True)
    try_3 = try_2.filter(bool)
    assert try_1.value == try_0.value and try_3.value == try_2.value



# Generated at 2022-06-26 00:00:36.627758
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert_that(str(Try(5, True)), equal_to('Try[value=5, is_success=True]'))
    assert_that(str(Try(False, False)), equal_to('Try[value=False, is_success=False]'))


# Generated at 2022-06-26 00:00:37.370919
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(False, False).get() == False


# Generated at 2022-06-26 00:00:43.898089
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(True, bool_1)
    assert try_0.get_or_else(None) is None
    assert try_1.get_or_else(None) is bool_1
    assert try_0.get_or_else(1) == 1
    assert try_1.get_or_else(1) is bool_1
    assert try_0.get_or_else(1.5) == 1.5
    assert try_1.get_or_else(1.5) is bool_1
    assert try_0.get_or_else('a') == 'a'
    assert try_1.get_or_else('a') is bool_1
    list_

# Generated at 2022-06-26 00:00:48.774152
# Unit test for method on_success of class Try
def test_Try_on_success():
    text = 'sample text'
    print_ = lambda t: print(t)
    assert Try(text, True).on_success(print_).get() == text
    assert Try(Exception('error'), False).on_success(print_).get() == Exception('error')
    assert Try(Exception('error'), False).on_success(print_).is_success == False


# Generated at 2022-06-26 00:00:57.266597
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, bool_1)
    try_0_copy = try_0.copy()

    assert try_0.filter(lambda value: value) == Try(bool_0, bool_0)
    assert try_0 == try_0_copy
    assert try_0_copy == try_0
    assert try_0 == try_0_copy

    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_0_copy = try_0.copy()

    assert try_0.filter(lambda value: value) == Try(bool_0, bool_0)
    assert try_0 == try_0_copy
    assert try_0_copy == try_0
    assert try_0 == try_

# Generated at 2022-06-26 00:01:01.840561
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert str(try_0) == 'Try[value=False, is_success=False]'

    bool_1 = True
    try_1 = Try(bool_0, bool_1)
    assert str(try_1) == 'Try[value=False, is_success=True]'



# Generated at 2022-06-26 00:01:12.418762
# Unit test for constructor of class Try
def test_Try():
    # Case 0: Successfully Try with value = False, is_success = False
    bool_0 = False
    try_0 = Try.of(lambda: bool_0, None)

    # Case 1: Successfully Try with value = 1, is_success = True
    try_1 = Try.of(lambda: 1, None)

    # Case 2: Successfully Try with value = 2, is_success = True
    try_2 = Try.of(lambda: 2, None)

    # Case 3: Successfully Try with value = -5, is_success = True
    try_3 = Try.of(lambda: -5, None)

    # Case 4: Successfully Try with value = 'abc', is_success = True
    try_4 = Try.of(lambda: 'abc', None)

    # Case 5: Try with Exception value and is

# Generated at 2022-06-26 00:01:16.352887
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    success_value = 10
    success_try = Try(success_value, True)
    assert success_try.get_or_else(False) == success_value
    fail_value = False
    fail_try = Try(fail_value, fail_value)
    assert fail_try.get_or_else(True) == True

test_Try_get_or_else()


# Generated at 2022-06-26 00:01:19.988337
# Unit test for method get of class Try
def test_Try_get():
    res_0 = Try(1, True).get()
    assert res_0 == 1
    res_1 = Try(2, False).get()
    assert res_1 == 2


# Generated at 2022-06-26 00:01:22.340721
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    fail_callback = lambda res: print(res)
    try_0.on_fail(fail_callback)


# Generated at 2022-06-26 00:01:39.010520
# Unit test for constructor of class Try
def test_Try():
    try_0 = Try(False, False)
    assert try_0.value is False
    assert try_0.is_success is False

    try_1 = Try(True, True)
    assert try_1.value is True
    assert try_1.is_success is True

    try_3 = Try(0, False)
    assert try_3.value is 0
    assert try_3.is_success is False

    try_4 = Try(0, True)
    assert try_4.value is 0
    assert try_4.is_success is True



# Generated at 2022-06-26 00:01:42.540313
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try(1, True)
    try_1 = Try(1, True)
    assert try_0 == try_1
    try_0 = Try(1, False)
    try_1 = Try(1, False)
    assert try_0 == try_1


# Generated at 2022-06-26 00:01:43.455939
# Unit test for constructor of class Try
def test_Try():
    test_case_0()

# Generated at 2022-06-26 00:01:46.210349
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(True, True).get_or_else(False) == True
    assert Try(False, False).get_or_else(True) == True


# Generated at 2022-06-26 00:01:47.065544
# Unit test for constructor of class Try
def test_Try():
    test_case_0()


# Generated at 2022-06-26 00:01:51.557075
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_1 = False
    bool_0 = True

    try_1 = Try(bool_1, bool_1)
    assert try_1.get_or_else(bool_1) == bool_1

    try_0 = Try(bool_0, bool_0)
    assert try_0.get_or_else(bool_0) == bool_0


# Generated at 2022-06-26 00:01:55.528719
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    for value in [True, False]:
        for default_value in [True, False]:
            assert Try(value, value).get_or_else(default_value) == value
            assert Try(value, not value).get_or_else(default_value) == default_value



# Generated at 2022-06-26 00:02:05.609582
# Unit test for method map of class Try
def test_Try_map():
    # Case 0: Successfully case
    bool_0 = False
    try_0 = Try(bool_0, True)
    bool_1 = not bool_0
    try_1 = try_0.map(lambda x: not x)
    bool_2 = try_1.get()
    bool_3 = try_1.is_success

    # Case 1: Not successfully case
    bool_0 = False
    try_0 = Try(bool_0, False)
    bool_1 = try_0.get()
    bool_2 = try_0.is_success
    try_1 = try_0.map(lambda x: not x)
    bool_3 = try_1.get()
    bool_4 = try_1.is_success


# Generated at 2022-06-26 00:02:08.994360
# Unit test for method on_success of class Try
def test_Try_on_success():
    v_0 = 'test'
    v_1 = 'test1'
    try_0 = Try(v_0, True)
    try_1 = Try(v_1, False)
    fn_0 = lambda v: v
    assert try_0.on_success(fn_0) == Try(v_0, True)
    assert try_1.on_success(fn_0) == Try(v_1, False)


# Generated at 2022-06-26 00:02:13.696108
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = True
    bool_1 = False
    try_0 = Try(bool_0, bool_0)
    value = try_0.get_or_else('other value')
    assert value == bool_0
    try_1 = Try(bool_1, bool_1)
    value = try_1.get_or_else('other value')
    assert value == 'other value'
# tester for unit test of method get_or_else of class Try

# Generated at 2022-06-26 00:02:38.272290
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_0 = Try(1, True)
    assert try_0.get_or_else(0) == 1

    try_1 = Try(1, False)
    assert try_1.get_or_else(0) == 0


# Generated at 2022-06-26 00:02:40.465073
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(10, True).get_or_else(0) == 10
    assert Try(0, False).get_or_else(10) == 10


# Generated at 2022-06-26 00:02:50.597635
# Unit test for method get of class Try
def test_Try_get():

    # Case for success Try with bool value
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.get() == bool_0

    # Case for not success Try with bool value
    bool_0 = True
    try_0 = Try(bool_0, not bool_0)
    assert try_0.get() == bool_0

    # Case for success Try with number type value
    int_0 = 0
    try_0 = Try(int_0, True)
    assert try_0.get() == int_0

    # Case for not success Try with number type value
    int_0 = 0
    try_0 = Try(int_0, False)
    assert try_0.get() == int_0

    # Case for success Try with string value
    str_0

# Generated at 2022-06-26 00:02:57.384553
# Unit test for constructor of class Try
def test_Try():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    def test_0():
        assert try_0.value == False, "value of try_0 is not False"
    def test_1():
        assert try_0.is_success == False, "is_success of try_0 is not False"
    def test_2():
        assert try_0 == Try(bool_0, bool_0), "try_0 is not equal to Try(bool_0, bool_0)"
    test_0()
    test_1()
    test_2()

# Unit tests for eq function.