

# Generated at 2022-06-25 23:53:11.222511
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    int_0 = 0
    int_1 = 1

    def _filter(value):
        raise AssertionError
    try_1 = try_0.filter(_filter)
    assert try_0 == try_1
    assert not try_1.is_success

    def _filter(value):
        return True
    try_1 = try_0.filter(_filter)
    assert try_0 == try_1
    assert not try_1.is_success

    bytes_0 = b'\xf0'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    def _filter(value):
        return False
    try_1 = try_0.filter

# Generated at 2022-06-25 23:53:13.911948
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 0,).filter(lambda x: x == 0,) == Try(0, True)
    assert Try.of(lambda: 0,).filter(lambda x: x == 1,) == Try(0, False)


# Generated at 2022-06-25 23:53:20.330882
# Unit test for method filter of class Try
def test_Try_filter():
    list_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    def filterer(num):
        return num == 5
    try_0 = Try.of(lambda : list_0)
    try_0 = try_0.filter(filterer)

    assert try_0.is_success == True
    assert try_0.value == list_0


# Generated at 2022-06-25 23:53:23.391004
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    bytes_0 = b''
    try_0 = Try(bytes_0, bool_0)
    assert callable(Try.filter)



# Generated at 2022-06-25 23:53:34.679243
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    bytes_1 = b'\x01'
    bool_1 = True
    try_1 = Try(bytes_1, bool_1)
    list_0 = []
    float_0 = float(1.0)
    float_1 = float(0.0)
    bool_2 = False
    bool_3 = True
    try_2 = Try.of(list_0.append, float_0)
    try_3 = Try.of(list_0.append, float_1)
    try_4 = try_1.filter(lambda kek_0: bool_1)
    try_5 = try_0.filter(lambda kek_1: bool_2)
    try_6

# Generated at 2022-06-25 23:53:46.500264
# Unit test for method filter of class Try

# Generated at 2022-06-25 23:53:50.540353
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1).filter(lambda x: x == 1) == Try(1, True)



# Generated at 2022-06-25 23:54:02.192778
# Unit test for method filter of class Try

# Generated at 2022-06-25 23:54:09.171340
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True)\
        .filter(lambda x: True)\
        .get() == 1

    assert isinstance(
        Try(1, True)\
            .filter(lambda x: False)\
            .get(), Exception)

    assert isinstance(
        Try(1, False)\
            .filter(lambda x: False)\
            .get(), Exception)



# Generated at 2022-06-25 23:54:14.705043
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(0, True).filter(lambda x: x > 0) == Try(0, False)
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, False).filter(lambda x: x > 0) == Try(1, False)

# Generated at 2022-06-25 23:54:30.842675
# Unit test for method filter of class Try
def test_Try_filter():
    def test_case_0():
        bytes_0 = b'\x7f'
        bool_0 = True
        try_0 = Try(bytes_0, bool_0)
        str_0 = '7f'
        str_1 = '{!r}'.format(bytes_0)
        def filterer(arg_0):
            bool_1 = bool(arg_0)
            return bool_1
        try_1 = try_0.filter(filterer)
        try_2 = Try(str_0, bool_0)
        try_3 = Try(str_1, bool_0)
        try_4 = Try(bytes_0, bool_0)
        try_5 = try_4.filter(filterer)
        assert try_5 == try_0

# Generated at 2022-06-25 23:54:39.082644
# Unit test for method filter of class Try
def test_Try_filter():
    func_0 = lambda arg_0: True
    bytes_0 = b'\x00'
    bool_0 = False
    bytes_1 = b'\x00'
    bool_1 = True
    bytes_2 = b'\x01'
    bool_2 = True
    try_0 = Try.of(lambda : bytes_0,  *())
    try_1 = try_0.filter(func_0)
    try_2 = Try(bytes_1, bool_1)
    try_3 = Try(bytes_2, bool_2)
    try_4 = try_3.filter(func_0)

# Generated at 2022-06-25 23:54:44.137317
# Unit test for method filter of class Try
def test_Try_filter():
    # Call the method filter with correct parameters
    try0 = Try(0, True)
    try1 = try0.filter(lambda x: x == 0)
    assert try1 == Try(0, True)
    try2 = try0.filter(lambda x: x == 1)
    assert try2 == Try(0, False)



# Generated at 2022-06-25 23:54:52.541189
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer_Test_Try_filter(value):
        return value == True
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(filterer_Test_Try_filter)
    assert try_0 == try_1
    bool_1 = True
    try_2 = Try(bool_0, bool_1)
    try_3 = try_2.filter(filterer_Test_Try_filter)
    assert try_2 == try_3
    try_4 = Try(bool_1, bool_1)
    try_5 = try_4.filter(filterer_Test_Try_filter)
    assert try_4 == try_5

# Test for method Try.of

# Generated at 2022-06-25 23:55:03.169454
# Unit test for method filter of class Try
def test_Try_filter():
    def func_try_filter_0():
        """
        Test with filterer returns True
        """
        def filterer(value=None):
            return value

        bytes_0 = b''
        bool_0 = True
        return Try(bytes_0, bool_0).filter(filterer)

    def func_try_filter_1():
        """
        Test with filterer returns False
        """
        def filterer(value=None):
            return value

        bytes_0 = b''
        bool_0 = False
        return Try(bytes_0, bool_0).filter(filterer)

    try_0 = func_try_filter_0()
    try_1 = func_try_filter_1()



# Generated at 2022-06-25 23:55:10.092554
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b'\xff'
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    bool_1 = try_0.filter(bool)
    assert bool_1
    bool_2 = try_0.is_success
    assert bool_2
    int_0 = len(byte_arr_0)
    assert int_0 == 9

# Generated at 2022-06-25 23:55:17.888603
# Unit test for method filter of class Try
def test_Try_filter():
    def func_0(arg_0):
        return arg_0 > 10
    def func_1(arg_0):
        return arg_0 > 10
    def func_2(arg_0):
        return arg_0 > 10
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    try_1 = try_0.filter(func_0)
    try_2 = try_0.filter(func_1)
    try_3 = try_0.filter(func_2)


# Generated at 2022-06-25 23:55:30.427438
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b'^\xfe\x0c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    def fn(val):
        return val == b''
    value_0 = fn(bytes_0)
    list_1 = [bool_0]
    def fn(val):
        return val in list_1
    bool_1 = fn(value_0)
    value_1 = try_0.get()
    bool_2 = True

# Generated at 2022-06-25 23:55:39.006235
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)


# Generated at 2022-06-25 23:55:51.204583
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(b'\x00\x00\x00\x00', True)
    try_1 = try_0.bind(lambda x: Try.of(bytes.fromhex, 'FF' * 3))
    assert try_1 == Try(b'\xff\xff\xff', True)
    assert isinstance(try_0, Try)
    assert isinstance(try_1, Try)
    assert isinstance(try_0.value, bytes)
    assert isinstance(try_1.value, bytes)
    assert try_0.is_success == True
    assert try_1.is_success == True
    bool_0 = False
    try_2 = try_1.filter(lambda x: bool_0)
    assert try_2.is_success == False
    try_3 = try_2.filter

# Generated at 2022-06-25 23:55:57.817104
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(12, True).filter(lambda x: x > 10) == Try(12, True)
    assert Try(12, True).filter(lambda x: x == 10) == Try(12, False)
    assert Try(12, False).filter(lambda x: x == 10) == Try(12, False)


# Generated at 2022-06-25 23:56:05.322548
# Unit test for method filter of class Try
def test_Try_filter():
    def fn_0(arg_0):
        return arg_0.get_or_else(b'1') == b'1'

    def fn_1(arg_0):
        return arg_0.get_or_else(b'1') != b'1'

    def fn_2(arg_0):
        return arg_0.get_or_else(b'1') == b''

    def fn_3(arg_0):
        return arg_0.get_or_else(b'1') != b''

    def fn_4(arg_0):
        return arg_0.get_or_else(b'1') == b'0'

    def fn_5(arg_0):
        return arg_0.get_or_else(b'1') != b'0'


# Generated at 2022-06-25 23:56:15.055172
# Unit test for method filter of class Try
def test_Try_filter():
    list_0 = []
    bytes_0 = b''
    try_0 = Try(bytes_0, True)
    try_1 = Try(list_0, True)
    try_2 = Try(list_0, False)
    try_0 = try_0.filter(lambda bytes: len(bytes) == 0)
    assert not try_0.is_success
    try_1 = try_1.filter(lambda list: len(list) > 0)
    assert not try_1.is_success
    try_2 = try_2.filter(lambda list: len(list) > 0)
    assert not try_2.is_success


# Generated at 2022-06-25 23:56:24.564105
# Unit test for method filter of class Try
def test_Try_filter():
    bool_true = True
    bool_false = False
    bytes_0 = b''
    # symbol_0 = Symbol(bytes_0)
    # symbol_0_copy = Symbol(bytes_0)
    # preimage_0 = Preimage(bytes_0)
    # preimage_0_copy = Preimage(bytes_0)
    # address_0 = Address(bytes_0)
    # address_0_copy = Address(bytes_0)
    # address_0_1 = Address(bytes_0)
    # address_0_1_copy = Address(bytes_0)
    # sig_0 = Sig(bytes_0)
    # sig_0_copy = Sig(bytes_0)
    # public_key_0 = PublicKey(bytes_0)
    # public_key_0_copy = PublicKey(

# Generated at 2022-06-25 23:56:34.110703
# Unit test for method filter of class Try
def test_Try_filter():
    # Case 0
    try_0 = Try(b'', False)
    bool_0 = try_0.filter(lambda x: True)
    assert bool_0 == Try(b'', False)

    # Case 1
    try_1 = Try(b'', True)
    bool_1 = try_1.filter(lambda x: False)
    assert bool_1 == Try(b'', False)

    # Case 2
    try_2 = Try(b'', True)
    bool_2 = try_2.filter(lambda x: True)
    assert bool_2 == Try(b'', True)

    # Case 3
    try_3 = Try(b'', False)
    bool_3 = try_3.filter(lambda x: False)
    assert bool_3 == Try(b'', False)

    # Case

# Generated at 2022-06-25 23:56:38.874264
# Unit test for method filter of class Try
def test_Try_filter():
    string_0 = "T"
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    return try_0.filter(string_0)


# Generated at 2022-06-25 23:56:48.268459
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0_0 = True
    bytes_0_0 = b'\x00'
    try_0_0 = Try(bytes_0_0, bool_0_0)
    def filterer_00(arg_0_00):
        return True
    try_0_0.filter(filterer_00)
    bool_0_1 = False
    bytes_0_1 = b'\x00'
    try_0_1 = Try(bytes_0_1, bool_0_1)
    bool_0_0 = True
    bytes_0_0 = b'\x00'
    try_0_0 = Try(bytes_0_0, bool_0_0)
    def filterer_01(arg_0_01):
        return False

# Generated at 2022-06-25 23:56:51.515172
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    bytes_0 = b'\xc2\x8f\x87'
    def filterer(argument_0):
        return True
    try_0 = Try(bytes_0, bool_0)
    assert try_0.filter(filterer) == Try(bytes_0, True)


# Generated at 2022-06-25 23:56:55.693381
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    def func_lambda_0(arg0):
        return arg0
    bytes_1 = b'\x9d\xe9\xae\xc2\x88\xc4\x90'
    str_0 = '\x9d\xe9\xae\xc2\x88\xc4\x90'
    if (hash(str_0) == hash(bytes_1)):
        assert bytes_1 == bytes_0
    def func_lambda_1(arg0):
        return arg0 == bytes_0
    assert try_0.filter(func_lambda_1) == try_0
    bool_1 = True
    try_1 = Try(bytes_0, bool_1)

# Generated at 2022-06-25 23:57:07.086497
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b'\x00\x00'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    bytes_1 = b'\x00\x00'
    bool_1 = False
    try_1 = Try(bytes_1, bool_1)
    bytes_2 = b'\x00\x00'
    bool_2 = True
    try_2 = Try(bytes_2, bool_2)
    bytes_3 = b'\x00\x00'
    bool_3 = False
    try_3 = Try(bytes_3, bool_3)

    def filterer(arg_0):
        return True if True else False

    try_4 = try_0.filter(filterer)

# Generated at 2022-06-25 23:57:19.011808
# Unit test for method filter of class Try

# Generated at 2022-06-25 23:57:24.490154
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '2').filter(lambda x: x > 1) == Try(2, True)
    assert Try.of(int, '0').filter(lambda x: x > 1) == Try(0, False)
    assert Try.of(int, '2').filter(lambda x: x > 5) == Try(2, False)
    assert Try.of(int, 'abc').filter(lambda x: x > 1) == Try('abc', False)


# Generated at 2022-06-25 23:57:29.213419
# Unit test for method filter of class Try
def test_Try_filter():
    string_0 = 'test_string'
    try_0 = Try.of(lambda: string_0)
    assert try_0.filter(lambda value: True).get() == string_0
    assert try_0.filter(lambda value: False).get_or_else('') == ''


# Generated at 2022-06-25 23:57:38.577771
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_1 = b'Hello'
    bool_1 = True
    try_1 = Try(bytes_1, bool_1)
    assert try_1.filter(lambda x: len(x) > 4) == try_1
    assert try_1.filter(lambda x: len(x) < 4) == Try(bytes_1, False)
    bytes_2 = b'World'
    bool_2 = True
    try_2 = Try(bytes_2, bool_2)
    assert Try(bytes_2, False).filter(lambda x: len(x) > 4) == Try(bytes_2, False)
    assert try_2.filter(lambda x: len(x) < 4) == Try(bytes_2, False)
    assert try_2.filter(lambda x: len(x) > 4) == try_2

# Generated at 2022-06-25 23:57:45.028732
# Unit test for method filter of class Try
def test_Try_filter():
    # Initialization of input data
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)

    # Function call
    # Condition where 'if' statement is True
    try_ret_0 = Try.of(hex, bytes_0)
    try_ret_1 = Try.of(lambda x: x.upper(), bytes_0)
    try_ret_2 = try_ret_1.filter(lambda x: len(x) == 120)
    int_0 = len(try_ret_2.get())

    # Condition where 'if' statement is False
   

# Generated at 2022-06-25 23:57:55.323753
# Unit test for method filter of class Try
def test_Try_filter():
    # positive test case
    obj_0 = Try(0, True)
    filterer_0 = lambda x: type(x) == int
    Try_obj_0 = obj_0.filter(filterer_0)
    print(isinstance(Try_obj_0, Try) and Try_obj_0.get() == 0 and Try_obj_0.is_success)

    # negative test case
    obj_1 = Try(b'', False)
    filterer_1 = lambda x: type(x) == int
    Try_obj_1 = obj_1.filter(filterer_1)
    print(isinstance(Try_obj_1, Try) and Try_obj_1.get() == b'' and not Try_obj_1.is_success)



# Generated at 2022-06-25 23:58:03.582803
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    bytes_1 = b''
    try_1 = try_0.filter(lambda _: bool_0)
    assert try_0 is not try_1
    assert try_1.is_success == bool_0
    assert try_1.value == bytes_1
    bytes_2 = b'\x00\x81\x00\x01\x02\x03\x04\x05'
    bool_1 = True
    try_2 = Try(bytes_2, bool_1)
    bytes_3 = b'%\x01\x9f\xf3l\xc0\xbd\xbd\xb4\x1d'

# Generated at 2022-06-25 23:58:12.323807
# Unit test for method filter of class Try
def test_Try_filter():
    gte = lambda x: x >= 2
    lte = lambda x: x <= 2
    ts = Try.of(lambda x: x, 1)
    tf = Try.of(lambda x: x, 1).filter(gte)
    tt = Try.of(lambda x: x, 2).filter(gte)
    ttt = Try.of(lambda x: x, 2).filter(lte)

    assert ts == Try(1, True)
    assert tf == Try(1, False)
    assert tt == Try(2, True)
    assert ttt == Try(2, True)


# Generated at 2022-06-25 23:58:22.600892
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    def filterer_0(value): return True
    try_1 = try_0.filter(filterer_0)
    assert try_1.is_success == False
    assert try_1.value == bytes_0
    bytes_1 = b'\x16\x02\xfd\xe8\x8a\xa6\r\xc9FZ\x04\x8c\x89\xec\xaf\x98\x8a\x87\xc9'
    bool_1 = True
    try_2 = Try(bytes_1, bool_1)
    def filterer_1(value): return True

# Generated at 2022-06-25 23:58:32.019018
# Unit test for method filter of class Try
def test_Try_filter():
    print('Unit test for method filter of class Try')
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    try_1 = Try(bytes_0, bool_0)
    try_2 = Try(bytes_0, bool_0)
    try_3 = Try(bytes_0, bool_0)
    try_4 = Try(bytes_0, bool_0)
    try_5 = Try(bytes_0, bool_0)
    try_6 = Try(bytes_0, bool_0)
    try_7 = Try(bytes_0, bool_0)
    try_8 = Try(bytes_0, bool_0)
    try_9 = Try(bytes_0, bool_0)

# Generated at 2022-06-25 23:58:40.729202
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    def filterer_0(val):
        return val == bytes_0
    try_1 = try_0.filter(filterer_0)
    try_2 = try_0.filter(filterer_0)
    assert try_1 == try_2


# Generated at 2022-06-25 23:58:48.632477
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    bytes_0 = b''
    try_0 = Try(bytes_0, bool_0)
    try_1 = try_0.filter(lambda arg_0: arg_0 == bytes_0)
    assert type(try_1) == Try
    assert try_1.is_success == bool_0
    assert try_1.value == bytes_0

# Generated at 2022-06-25 23:58:52.235242
# Unit test for method filter of class Try
def test_Try_filter():
    f = lambda x: len(x) >= 4
    monad = Try(b'test', True).filter(f)

    b = monad.is_success and f(monad.get())

    assert b



# Generated at 2022-06-25 23:59:03.111782
# Unit test for method filter of class Try
def test_Try_filter():
    def test_case_0():
        def func_1(arg_0: bytes):
            int_0 = 0
            return arg_0[int_0]

        bytes_0 = b''
        bool_0 = True
        try_0 = Try(bytes_0, bool_0)
        try_1 = try_0.filter(func_1)
        bool_1 = False
        assert try_1.is_success == bool_1
        try_2 = Try(bytes_0, bool_1)
        try_3 = try_2.filter(func_1)
        assert try_3.is_success == bool_1

    def test_case_1():
        def func_1(arg_0: bytes):
            int_0 = 0
            int_1 = 5

# Generated at 2022-06-25 23:59:08.121100
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda v: v > 0) == Try(10, True)
    assert Try(10, True).filter(lambda v: v < 0) == Try(10, False)
    assert Try(10, False).filter(lambda v: v > 0) == Try(10, False)


# Generated at 2022-06-25 23:59:15.623230
# Unit test for method filter of class Try
def test_Try_filter():
    from nose.tools import assert_equal
    from nose.tools import assert_true
    from nose.tools import assert_false
    from nose.tools import assert_is_instance
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    def anonymous_fun_0(fn_0: bytes, fn_1: bytes) -> bool:
        def anonymous_fun_1(fn_0: bytes, fn_1: bytes) -> bool:
            return bytes_0 == fn_1
        return anonymous_fun_1(fn_0, fn_1)
    try_1 = try_0.filter(anonymous_fun_0)
    assert_is_instance(try_1, Try)
    assert_true(try_1.is_success)
    assert_equal

# Generated at 2022-06-25 23:59:20.449106
# Unit test for method filter of class Try
def test_Try_filter():
    args_0 = (1, 7)
    bytes_0 = b'test'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    try_1 = try_0.filter(lambda x: len(x) < args_0[0] or len(x) > args_0[1])
    bool_1 = try_1.is_success
    assert bool_1 == False


# Generated at 2022-06-25 23:59:24.439414
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try('qwerty', True).filter(lambda x: len(x) > 0) == Try('qwerty', True)
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)


# Generated at 2022-06-25 23:59:32.476149
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b'test'
    try_0 = Try(bytes_0, True)
    try_1 = try_0.filter(lambda x: True)
    assert try_1.value == bytes_0
    assert try_1.is_success
    try_2 = try_0.filter(lambda x: False)
    assert try_2.value == bytes_0
    assert not try_2.is_success
    try_3 = try_0.filter(lambda x: True)
    assert try_3.is_success
    assert try_3 == try_0


# Generated at 2022-06-25 23:59:41.115879
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    int_0 = 0
    int_1 = 1
    bool_0 = True
    bool_1 = False
    try_0 = Try(int_0, bool_0)
    try_1 = Try(int_0, bool_0)
    try_2 = Try(int_0, bool_0)
    try_3 = Try(bytes_0, bool_0)
    try_4 = Try(int_1, bool_0)
    try_5 = Try(int_0, bool_1)
    try_6 = Try(int_0, bool_1)
    try_7 = Try(int_1, bool_1)
    try_7

# Generated at 2022-06-25 23:59:54.563468
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    def str_filterer(arg_0: bytes) -> bool:
        return len(arg_0) > 1
    try_0 = try_0.filter(str_filterer)
    assert isinstance(try_0, Try)


# Generated at 2022-06-26 00:00:03.820773
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    str_0 = ""
    def func_0():
        None
        return str_0
    def func_1(arg_0):
        try_0 = Try(func_0(), bool_0)
        try_0 = try_0.filter(lambda arg_0: arg_0 == str_0)
        return try_0
    def func_2(arg_0):
        bool_1 = False
        try_0 = Try(arg_0, bool_1)
        try_0 = try_0.filter(lambda arg_0: arg_0 == str_0)
        return try_0
    func_1(str_0)
    func_2(str_0)
    func_2(str_0)
    func_2(str_0)


# Generated at 2022-06-26 00:00:07.746220
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return True

    try_0 = Try(bytes, True)
    try_1 = try_0.filter(filterer)


# Generated at 2022-06-26 00:00:14.826538
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    bool_1 = True
    try_1 = try_0.filter(lambda arg_0: arg_0)
    bool_2 = True
    assert try_1.is_success == bool_2
    bytes_1 = b''
    bool_2 = False
    try_2 = try_0.filter(lambda arg_0: arg_0)
    bool_3 = False
    assert try_2.is_success == bool_3


# Generated at 2022-06-26 00:00:27.353006
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    def f_0(arg_0):
        return (arg_0 == bytes_0)
    bool_1 = f_0(bytes_0)
    assert bool_1
    bool_2 = bool_0
    assert bool_2
    bool_1 = bool_2 and bool_1
    assert bool_1
    bool_1 = bool_1 and bool_1
    assert bool_1
    try_1 = try_0.filter(f_0)
    def f_1(arg_0):
        return (arg_0 == bytes_0)

    assert f_1(try_0.get())
    assert try_0.get() == try_1.get()
    assert try_

# Generated at 2022-06-26 00:00:37.379701
# Unit test for method filter of class Try
def test_Try_filter():
    # get test input
    bytes_0 = b'\x6b\x6d\x69\x64\x61\x67\x6b'
    bytes_1 = b'\x69\x6f\x64\x6f\x6b\x69\x6f'
    bytes_2 = b'\x6d\x69\x64\x61\x67\x6b\x6f'
    bytes_3 = b'\x6e\x6e\x6f\x70\x6f\x6e\x6f'
    bytes_4 = b'\x69\x6f\x67\x6f\x70\x6f\x61'

# Generated at 2022-06-26 00:00:41.729901
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b'0123456789'
    try_0 = Try(bytes_0, True)

    def filterer_0(arg_0):
        return True

    def filterer_1(arg_0):
        return False
    try_1 = try_0.filter(filterer_0)
    try_2 = try_0.filter(filterer_1)
    assert isinstance(try_1, Try) and try_1.value == bytes_0 and try_1.is_success
    assert isinstance(try_2, Try) and try_2.value == bytes_0 and try_2.is_success == False


# Generated at 2022-06-26 00:00:49.488156
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Given
    - monad with value 'Hello', is_success=True
    When
    - filter monad value with function lambda v: len(v) > 5
    Then
    - return monad with previous value
    """
    str_0 = "Hello"
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(lambda v: len(v) > 5)
    bool_1 = try_1.is_success
    assert bool_1 == True
    str_1 = try_1.value
    assert str_1 == "Hello"


# Generated at 2022-06-26 00:00:54.300949
# Unit test for method filter of class Try
def test_Try_filter():
    byte_0 = b'\x01'
    byte_1 = b'\x02'
    bytes_0 = (byte_0, byte_1)
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    def filterer_0(fn_0):
        return len(fn_0) >= 1
    try_1 = try_0.filter(filterer_0)


# Generated at 2022-06-26 00:01:02.829309
# Unit test for method filter of class Try
def test_Try_filter():
    def func_0(arg_0):
        return arg_0 < 10
    def func_1(arg_0):
        return arg_0 > 10
    def func_2(arg_0):
        return arg_0 == 10
    def func_3(arg_0):
        return arg_0 != 10
    try_0 = Try.of(int, '23')
    assert (try_0.filter(func_0).is_success == False)
    assert (try_0.filter(func_1).is_success == True)
    assert (try_0.filter(func_2).is_success == True)
    assert (try_0.filter(func_3).is_success == True)
    try_1 = Try.of(int, '10')

# Generated at 2022-06-26 00:01:18.072081
# Unit test for method __eq__ of class Try

# Generated at 2022-06-26 00:01:20.947282
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_0.on_fail(print)


# Generated at 2022-06-26 00:01:25.701221
# Unit test for method bind of class Try
def test_Try_bind():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    bytes_1 = b''
    bool_1 = False
    try_1 = Try(bytes_1, bool_1)
    list_0 = []
    try_0.bind(list_0.append)


# Generated at 2022-06-26 00:01:31.286383
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bytes_0 = b'data'
    bytes_1 = b'bytes'
    bool_0 = True
    bool_1 = False
    try_0 = Try(bytes_0, bool_0)
    value_0 = try_0.get_or_else(bytes_1)
    assert value_0 == bytes_0
    try_1 = Try(bytes_0, bool_1)
    value_1 = try_1.get_or_else(bytes_1)
    assert value_1 == bytes_1


# Generated at 2022-06-26 00:01:34.443421
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)

    def my_func():
        assert not try_0.is_success

    try_0.on_fail(my_func)


# Generated at 2022-06-26 00:01:37.189390
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try(b'', True)
    try_1 = Try(b'', True)

    result = (try_0 == try_1)
    assert result


# Generated at 2022-06-26 00:01:43.735419
# Unit test for constructor of class Try
def test_Try():
    """
    Test constructor of class Try.
    """
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)



# Generated at 2022-06-26 00:01:47.464393
# Unit test for constructor of class Try
def test_Try():
    assert Try(b'', True) == Try(b'', True)
    assert Try(b'', True).__class__ == Try
    assert Try(b'', True).value == b''
    assert Try(b'', True).is_success == True


# Generated at 2022-06-26 00:01:55.064858
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'
    assert str(Try(b'', True)) == "Try[value=b'', is_success=True]"
    assert str(Try(b'', False)) == "Try[value=b'', is_success=False]"


# Generated at 2022-06-26 00:02:05.491186
# Unit test for constructor of class Try
def test_Try():
    get_0 = Try(1, True)
    assert get_0.value == 1
    assert get_0.is_success == True
    get_1 = Try(1, False)
    assert get_1.value == 1
    assert get_1.is_success == False
    get_2 = Try(2, True)
    assert get_2.value == 2
    assert get_2.is_success == True
    get_3 = Try(2, False)
    assert get_3.value == 2
    assert get_3.is_success == False
    get_4 = Try(3, True)
    assert get_4.value == 3
    assert get_4.is_success == True
    get_5 = Try(3, False)
    assert get_5.value == 3

# Generated at 2022-06-26 00:02:24.279018
# Unit test for method __str__ of class Try
def test_Try___str__():
    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    print(str(try_0), end='')
    bytes_1 = b''
    bool_1 = True
    try_1 = Try(bytes_1, bool_1)
    print(str(try_1), end='')


# Generated at 2022-06-26 00:02:26.236183
# Unit test for method __str__ of class Try
def test_Try___str__():
    expected = 'Try[value=1, is_success=True]'
    actual = Try(1, True)
    assert str(actual) == expected


# Generated at 2022-06-26 00:02:33.849856
# Unit test for method filter of class Try
def test_Try_filter():
    result_try = Try('test', True).filter(lambda string: len(string) == 4)
    assert result_try.is_success == True
    assert result_try.value == 'test'
    result_try = Try('test_1', True).filter(lambda string: len(string) == 4)
    assert result_try.is_success == False
    assert result_try.value == 'test_1'
    result_try = Try('test', False).filter(lambda string: len(string) == 4)
    assert result_try.is_success == False
    assert result_try.value == 'test'


# Generated at 2022-06-26 00:02:37.699093
# Unit test for method map of class Try
def test_Try_map():
    def f(x):
        return x

    def test(x):
        return x + 4

    assert(Try.of(f, 4).map(test).value == 8), "Test map of Try.of(f, 4) failed"


# Generated at 2022-06-26 00:02:42.344084
# Unit test for method bind of class Try
def test_Try_bind():
    def fun_0(x):
        return Try(x, True)

    def fun_1(x):
        return Try(x, True)

    def fun_2(x):
        return Try(x, True)

    def fun_3(x):
        return Try(x, True)

    def fun_4(x):
        return Try(x, True)




# Generated at 2022-06-26 00:02:46.945986
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda val: 2) == Try(2, True)
    assert Try(1, False).map(lambda val: 2) == Try(1, False)



# Generated at 2022-06-26 00:02:52.843104
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    def filterer(value):
        return True
    try_1 = try_0.filter(filterer)
    assert try_1 == Try(b'', True)
    def filterer(value):
        return False
    try_2 = try_0.filter(filterer)
    assert try_2 == Try(b'', False)

# Generated at 2022-06-26 00:02:54.271698
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert "Try[value=b'', is_success=False]" == str(test_case_0())


# Generated at 2022-06-26 00:02:58.198467
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = False
    try_0 = Try((lambda str_0: str_0.decode('cp866')), bool_0).on_success((lambda str_0: str_0.join('')))
    assert not try_0.is_success
    assert try_0.value != None
