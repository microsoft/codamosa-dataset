

# Generated at 2022-06-25 23:53:09.402427
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(None, False)
    try_1 = try_0.filter(lambda value: False)
    try_2 = try_0.filter(lambda value: True)

    try_3 = Try(None, True)
    try_4 = try_3.filter(lambda value: False)
    try_5 = try_3.filter(lambda value: True)



# Generated at 2022-06-25 23:53:16.554550
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    bool_1 = True
    bool_2 = False
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    set_1 = {bool_1, bool_1, bool_1, bool_1}
    set_2 = {bool_2, bool_2, bool_2, bool_2}
    list_0 = [set_0, set_0, set_0, set_0]
    list_1 = [set_1, set_1, set_1, set_1]
    list_2 = [set_2, set_2, set_2, set_2]
    try_0 = Try(list_0, bool_1)
    try_1 = Try(list_1, bool_1)

# Generated at 2022-06-25 23:53:26.923682
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    list_0 = [set_0, set_0, set_0, set_0]
    try_0 = Try(list_0, bool_0)
    def func_0(arg_1):
        return (arg_1 == list_0)
    # not covered branch
    try_0.filter(func_0)
    # not covered branch
    Try(list_0, False).filter(func_1)
    # not covered branch
    Try(list_0, True).filter(func_2)
    assert (False)


# Generated at 2022-06-25 23:53:36.568360
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter of Try
    """

# Generated at 2022-06-25 23:53:49.361199
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    list_0 = [set_0, set_0, set_0, set_0]
    try_0 = Try(list_0, bool_0)
    # Test 1
    try_1 = try_0.filter(lambda x: bool(x))
    assert try_1 == Try([{True, True, True, True},
                         {True, True, True, True},
                         {True, True, True, True},
                         {True, True, True, True}],
                        True)
    # Test 2
    try_2 = try_0.filter(lambda x: not bool(x))

# Generated at 2022-06-25 23:54:01.564654
# Unit test for method filter of class Try
def test_Try_filter():
    # Create new Try
    try_0 = Try(None, True)
    # Set filterer function
    def func_0(arg_0):
        return arg_0 is None
    # Run filter
    try_0.filter(func_0)
    # Assertion
    try:
        assert(True is try_0.is_success)
    except AssertionError as e:
        print("Try_filter.py, line 101: assertion failure")
    # Change filterer function to return False
    def func_1(arg_1):
        return arg_1 is not None
    # Run filter
    try_0.filter(func_1)
    # Assertion

# Generated at 2022-06-25 23:54:13.110600
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    int_1 = 2
    int_2 = 10
    int_3 = 10
    int_4 = 3
    int_5 = 8
    int_6 = 7
    int_7 = 3
    int_8 = 3
    int_9 = 0
    int_10 = 2
    int_11 = 2
    pred_0 = Predicate(lambda int_3, int_4, int_5, int_6, int_7, int_8, int_9: int_9 == int_5 + int_5 - int_5)
    pred_1 = Predicate(lambda int_4, int_5, int_6, int_7, int_8, int_9, int_10: int_10 != int_6 * int_6 - int_6 + int_6)
    pred_

# Generated at 2022-06-25 23:54:20.007525
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    list_0 = [set_0, set_0, set_0, set_0]
    try_0 = Try(list_0, bool_0)
    try_1 = Try(list_0, bool_0)
    try_1.filter(lambda x: len(x) == 4 and type(x) == list and type(x[0]) == set and type(x[0][0]) == bool)


# Generated at 2022-06-25 23:54:33.505635
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    num_0 = 0
    char_0 = '\x00'
    str_0 = '\x00\x00 \x00\x00'
    map_0 = {str_0: char_0, str_0: num_0}
    list_0 = [char_0, map_0, num_0, str_0, num_0]
    def filterer_0(value):
        return value == map_0
    def filterer_1(value):
        return value == str_0
    def filterer_2(value):
        return value == num_0
    try_0 = Try(list_0, True)
    try_1 = try_0.filter(filterer_0)

# Generated at 2022-06-25 23:54:45.193843
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    dict_0 = {}
    str_0 = "1"
    str_1 = "1"
    str_2 = "2"
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    try_0 = Try(int_1, True)
    try_1 = try_0.filter(lambda x: x == int_3)
    assert try_0 == try_1

    def func_0(x):
        return x == int_1
    try_1 = try_0.filter(func_0)
    assert try_0 == try_1

    try_0 = Try(str_0, True)
    try_1 = try_0.filter(lambda x: x != str_1)


# Generated at 2022-06-25 23:54:52.002044
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    print('\n    Test on_fail of Try\n    ')
    try_0 = Try.of(int, '10')
    try_1 = Try.of(int, 'a')
    try_0.on_fail(lambda value: print(value))
    try_1.on_fail(lambda value: print(value))
    assert (try_0.is_success and not try_1.is_success)


# Generated at 2022-06-25 23:55:01.450811
# Unit test for constructor of class Try
def test_Try():
    assert Try('', True) == Try('', True)
    assert Try('', False) == Try('', False)
    assert Try('', True) != Try('', False)
    assert Try('', False) != Try('', True)
    assert Try('a', True) != Try('', True)
    assert Try('a', True) != Try('', False)
    assert Try('a', False) != Try('', True)
    assert Try('a', False) != Try('', False)
    try:
        assert Try('a', True) != Try('', True)
        assert False
    except:
        assert True


# Generated at 2022-06-25 23:55:12.470698
# Unit test for method map of class Try
def test_Try_map():
    str_0 = '\n    Test map of Try\n    '

    def print_success_map(value):
        print(str_0 + 'Success map with value = ' + value)
    def print_fail_map(value):
        print(str_0 + 'Fail map with value = ' + value)

    def get_square(num):
        return num * num

    def get_square_div(num):
        return Try(get_square(num), True)

    success_val_0 = Try(21, True)
    success_val_1 = Try(1024, True)
    fail_val_0 = Try(Exception, False)

    success_val_0\
        .map(get_square)\
        .on_success(print_success_map)\
        .on_fail(print_fail_map)

# Generated at 2022-06-25 23:55:17.840695
# Unit test for constructor of class Try
def test_Try():
    assert True, 'Assert True'
    str0 = 'Test Try constructor'
    try0 = Try(0, True)
    assert isinstance(try0, Try), 'Wrong type of instance'
    assert try0.value == 0, 'Error in value initialization'
    assert try0.is_success == True, 'Error in success initialization'


# Generated at 2022-06-25 23:55:30.372645
# Unit test for method bind of class Try
def test_Try_bind():
    str_0 = 'Test bind of Try'
    def on_success(value):  # type: (int) -> Try
        return Try(value + 1, True)
    def on_fail(value):  # type: (Exception) -> Try
        return Try(value, False)

    assert Try.of(lambda x: x + 1, 2).bind(on_success) == Try(3, True)
    assert Try.of(lambda x: x + 1, 2).bind(on_success).bind(on_success) == Try(4, True)
    assert Try.of(lambda x: x / 0, 2).bind(on_fail) == Try(ZeroDivisionError(), False)

# Generated at 2022-06-25 23:55:36.109248
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def test_case_0():
        str_0 = '\n    Test get_or_else of Try\n    '
        expected_0 = 'Hello'
        actual_0 = Try.of(str.strip, str_0).get_or_else('default')
        assert actual_0 == expected_0, '\nExpected: {}\n  Actual: {}'.format(expected_0, actual_0)
    
    test_case_0()



# Generated at 2022-06-25 23:55:41.526274
# Unit test for method on_success of class Try
def test_Try_on_success():
    str_0 = '\n    Test on_success of Try\n    '
    str_1 = '    Test on_success with successful monad\n    '
    str_2 = '    Test on_success with unsuccessful monad\n    '
    value_0 = 0
    value_1 = 1
    result_0 = Try(value_0, True)\
        .map(lambda e: e + 1)\
        .on_success(lambda e: value_1 == e)
    assert result_0
    result_1 = Try(value_0, False)\
        .map(lambda e: e + 1)\
        .on_success(lambda e: value_1 == e)
    assert not result_1


# Generated at 2022-06-25 23:55:52.717315
# Unit test for method get of class Try
def test_Try_get():
    str_0 = '\n    Test get of Try\n    '

    assert Try.of(lambda x: x*x, 5).get() == 25
    assert Try.of(lambda x: x*x, 6).get() == 36
    assert Try.of(lambda x: x*x, 7).get() == 49
    assert Try.of(lambda x: x*x, 8).get() == 64
    assert Try.of(lambda x: x*x, 9).get() == 81
    assert Try.of(lambda x: x*x, 10).get() == 100
    assert Try.of(lambda x: x*x, 11).get() == 121
    assert Try.of(lambda x: x*x, 12).get() == 144
    assert Try.of(lambda x: x*x, 13).get() == 169
   

# Generated at 2022-06-25 23:56:02.291688
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    str_0 = '\n    Test on_fail of Try\n    '

    assert True == isinstance(
        Try.of(lambda : 1).on_fail(lambda x: None),
        Try
    ), 'Test fail result type'

    assert 1 == Try.of(lambda : 1).on_fail(lambda x: None).get(), 'Test fail with scalar value'

    assert [1, 2] == Try.of(lambda : [1, 2]).on_fail(lambda x: None).get(), 'Test fail with array'

    assert 'hello' == Try.of(lambda : 'hello').on_fail(lambda x: None).get(), 'Test fail with string'

    assert True == Try.of(lambda : True).on_fail(lambda x: None).get(), 'Test fail with boolean'


# Generated at 2022-06-25 23:56:13.272107
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '\n    Test filter of Try\n    '
    print(str_0)

    def filter_is_even(value: int) -> bool:
        return value % 2 == 0

    try_actual = Try.of(int, '0').filter(filter_is_even)
    try_expected = Try(0, True)
    assert(try_actual == try_expected)

    try_actual = Try.of(int, '1').filter(filter_is_even)
    try_expected = Try(1, False)
    assert(try_actual == try_expected)

    try_actual = Try.of(int, '1').filter(filter_is_even)
    try_expected = Try(1, False)
    assert(try_actual == try_expected)

    try_actual = Try.of

# Generated at 2022-06-25 23:56:23.999354
# Unit test for method get of class Try
def test_Try_get():
    str_0 = '\n    Test get of Try\n    '
    
    # Case 0
    try:
        test_case_0()
    except:
        try_0 = Try.of(test_case_0)
        try_1 = try_0.get()
        assert_0 = try_0
        assert_1 = try_1
        print('{}Case 0{}'.format(str_0, assert_0))
        print('{}Case 0{}'.format(str_0, assert_1))


# Generated at 2022-06-25 23:56:33.308250
# Unit test for constructor of class Try
def test_Try():
    """
    :return: List[Test]
    """
    test_cases = []

    # test case -- Try.__init__
    str_0 = '\n    Test constructor of Try\n    '
    def t0():
        try_ = Try(10, True)
        assert try_.value == 10
        assert try_.is_success == True
        assert try_.__str__() == 'Try[value=10, is_success=True]'
        assert try_.__eq__(try_) == True
    test_cases.append(Test(str_0, t0))

    # test case -- Try.of
    str_1 = '\n    Test of of Try\n    '
    def t1():
        def f(x):
            return x + 10
        try_ = Try.of(f, 10)


# Generated at 2022-06-25 23:56:35.973819
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-25 23:56:41.333815
# Unit test for method on_success of class Try
def test_Try_on_success():
    t = Try(1, True)
    mock = Mock()
    called = False

# Generated at 2022-06-25 23:56:50.217994
# Unit test for method filter of class Try
def test_Try_filter():
    # test case 0
    str_0 = '\n    Test filter of Try\n    '
    int_0 = 23
    int_1 = 42
    int_2 = 33
    int_3 = 94
    int_4 = 1
    int_5 = 0
    int_6 = -334
    int_7 = 23
    try_0 = Try(int_0, False)
    try_1 = Try(int_1, True)
    try_2 = Try(int_2, True)
    try_3 = Try(int_3, True)
    try_4 = Try(int_4, True)
    try_5 = Try(int_5, True)
    try_6 = Try(int_6, True)
    try_7 = Try(int_7, True)

# Generated at 2022-06-25 23:56:56.470303
# Unit test for constructor of class Try
def test_Try():
    print('\n    Test constructor of Try\n    ')
    try_0 = Try(1, True)
    assert try_0.value == 1
    assert try_0.is_success == True
    assert str(try_0) == 'Try[value=1, is_success=True]'
    print('Test constructor OK')


# Generated at 2022-06-25 23:57:00.166631
# Unit test for method map of class Try
def test_Try_map():
    def add(x):
        return x + 1

    assert Try(2, True).map(add) == Try(3, True)
    assert Try('2', True).map(add) == Try('2', True)



# Generated at 2022-06-25 23:57:03.808262
# Unit test for method get of class Try
def test_Try_get():
    # Test case: initialized with None, not successfully and with custom value, successfully
    assert isinstance(Try(None, False).get(), type(None))
    assert isinstance(Try('any', True).get(), str)


# Generated at 2022-06-25 23:57:13.162362
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try:
        t_0 = Try(10, True)
        t_1 = Try(10, True)
        assert t_0 == t_1
        print('Try.__eq__')
        print('\tTrue case: Passed')
    except:
        print('Try.__eq__')
        print('\tTrue case: Failed')
    try:
        t_0 = Try(10, True)
        t_1 = Try(10, False)
        assert t_0 != t_1
        print('\tFalse case: Passed')
    except:
        print('\tFalse case: Failed')
# -----------------

# Generated at 2022-06-25 23:57:21.079821
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_case_0():
        str_0 = '\n        Test on_fail of Try control\n        '
    # Test on_fail with bin(True).
    def test_case_1():
        str_0 = '\n            Test on_fail of successful Try\n            '
        test_case_0()
        test_case_1()
        def test_case_2(x):
            str_0 = '\n                Test of function which raise exception\n                '
            def test_case_3(x):
                str_0 = '\n                    Test of callback\n                    '
                test_case_0()
                test_case_1()
                test_case_2(x)
                test_case_3(x)
                test_case_4(x)

# Generated at 2022-06-25 23:57:29.644374
# Unit test for method get of class Try
def test_Try_get():
    assert(Try.of(int, '123').get() == 123)
    assert(Try.of(int, 'foo').get_or_else(0) == 0)
    assert(Try.of(int, 'foo').get() is None)


# Generated at 2022-06-25 23:57:33.995534
# Unit test for method filter of class Try
def test_Try_filter():
    try:
        assert_equal(True, True, '\n    Can not assert equal\n    ')
    except AssertionError as e:
        print(e)

    def test_case_0():
        str_0 = '\n        Test filter of Try\n        '


# Generated at 2022-06-25 23:57:40.400593
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    str_0 = '\n    Test on_fail of Try\n    '

    def test_func(a): # подсмотрел в интернете как замыкания работают в python
        return a * a

    test_var = Try.of(test_func, 2)
    assert (test_var == Try(4, True))
    test_var.on_fail(lambda: print('test failed'))
    print('test passed')


# Generated at 2022-06-25 23:57:46.145497
# Unit test for method bind of class Try
def test_Try_bind():
    str_0 = '\n    Test bind of Try\n    '

    def g(x):
        # type: (int) -> Try[str]
        return Try.of(str, x)

    def f(x):
        # type: (int) -> Try[int]
        return Try.of(lambda: x / 0)

    str_1 = '\n        '
    print(str_0, str_1)
    assert Try(1, True).bind(f).bind(g) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-25 23:57:50.668368
# Unit test for method map of class Try
def test_Try_map():
    str_1 = ' Test map of Try'

    def to_uppercase(s):
        return s.upper()

    assert Try.of(lambda: 'AaA').map(to_uppercase) == Try('AAA', True)


# Generated at 2022-06-25 23:57:59.686939
# Unit test for method map of class Try
def test_Try_map():
    """
    Case: Successfully Try
    """
    str_0 = '\n    Test map of Try\n    '
    int_0 = Try(1232, True)
    int_1 = int_0.map(lambda x: x * 2).get()
    assert int_1 == 2464
    int_2 = int_0.map(lambda x: Try(x * 2, True)).map(lambda x: x.get()).get()
    assert int_2 == 2464
    int_3 = int_0.map(lambda x: Try(x * 2, True)).map(lambda x: x.map(lambda y: y * 10).get()).get()
    assert int_3 == 24640

# Generated at 2022-06-25 23:58:06.109034
# Unit test for method on_success of class Try
def test_Try_on_success():
    str_0 = '\n    Test filter of Try\n    '
    def str_1(arg_0):
        str_0 = '\n            executed success callback\n        '
        print(str_0)
    def str_2(arg_0):
        str_0 = '\n            executed fail callback\n        '
        print(str_0)
    Try(1, True).on_success(str_1).on_fail(str_2)
    Try(1, False).on_success(str_1).on_fail(str_2)
    ###############################
    str_0 = '\n    Test map of Try\n    '
    def str_3(arg_0):
        str_0 = '\n            executed success callback\n        '
        print(str_0)


# Generated at 2022-06-25 23:58:14.312470
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    str_0 = '\n    Unit test for method get_or_else of class Try\n    '
    try_0 = Try(42, True)
    try_1 = try_0.get_or_else('43')
    try_2 = Try(42, True).get_or_else('43')
    try_3 = Try(42, False).get_or_else('43')
    assert try_1 == 42
    assert try_2 == 42
    assert try_3 == '43'


# Generated at 2022-06-25 23:58:24.477771
# Unit test for method map of class Try
def test_Try_map():
    str_0 = '\n    Test map of Try\n    '
    str_1 = Try.of(str, str_0).map(lambda s: s[4:]).get()  # Test start index
    assert str_0[4:] == str_1
    str_1 = Try.of(str, str_0).map(lambda s: s[4:-4]).get()  # Test start index and end index
    assert str_0[4:-4] == str_1
    str_1 = Try.of(str, str_0).map(lambda s: s.replace('\n', '@')).get()  # Test replace
    assert str_0.replace('\n', '@') == str_1
    str_1 = Try.of(str, str_0).map(lambda s: s.strip()).get

# Generated at 2022-06-25 23:58:35.470026
# Unit test for method on_success of class Try
def test_Try_on_success():
    str_1 = '\n    Test on_success of Try\n    '
    print(str_0)

    def print_hello():
        print('Hello')

    success_try: Try[int] = Try.of(lambda: 1, 0)
    fail_try: Try[Exception] = Try.of(lambda: 1/0, 0)

    success_try\
        .on_success(lambda v: print(str_1, 'Success value: ', v))\
        .on_fail(lambda e: print(str_1, 'Fail value: ', e))\
        .on_success(lambda _: print_hello())


# Generated at 2022-06-25 23:58:46.946498
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    str_0 = '\n    Test get_or_else of Try\n    '
    try_monad = Try.of(int, '2')
    get_or_else_result = try_monad.get_or_else(0)
    assert get_or_else_result == 2, str_0 + 'get_or_else is not work'
    try_monad_1 = Try.of(int, 'q')
    get_or_else_result_1 = try_monad_1.get_or_else(0)
    assert get_or_else_result_1 == 0, str_0 + 'get_or_else is not work'



# Generated at 2022-06-25 23:58:55.460238
# Unit test for method get of class Try
def test_Try_get():
    str_0 = '\n    Test get of Try\n    '
    print(str_0, end='')

    def the_test():
        return 42

    try_0 = Try.of(the_test)
    assert try_0.get() == 42
    assert try_0.get_or_else(None) == 42

    try_error = Try.of(the_test, 0)
    assert isinstance(try_error.get(), TypeError)
    assert try_error.get_or_else('Error') == 'Error'

    print('    test passed!!!')



# Generated at 2022-06-25 23:59:01.681244
# Unit test for method __str__ of class Try
def test_Try___str__():
    print("\n    Test __str__ of Try")
    try_0 = Try(10, True)
    try_1 = Try('Error', False)
    print(try_0)
    print(try_1)

    assert str(try_0) == 'Try[value=10, is_success=True]'
    assert str(try_1) == 'Try[value=Error, is_success=False]'


# Generated at 2022-06-25 23:59:11.352262
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    test_case_0()
    str_0 = Try('Try[value=1, is_success=True]', True)
    str_1 = Try(1, True)
    str_2 = Try(1, False)
    str_3 = Try('Try[value=1, is_success=True]', False)
    str_4 = Try(1, True)
    str_5 = Try('Try[value=2, is_success=True]', True)
    str_6 = Try(2, True)
    str_7 = Try(2, False)
    str_8 = Try('Try[value=2, is_success=True]', False)
    str_9 = Try(2, True)
    str_10 = Try('Try[value=1, is_success=False]', False)
    str_11

# Generated at 2022-06-25 23:59:13.161390
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try('0', True).filter(lambda x: x == '0') == Try('0', True)
    assert Try('1', True).filter(lambda x: x == '0') == Try('1', False)


# Generated at 2022-06-25 23:59:20.870095
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_case_0():
        str_0 = '\n    Test on_fail of Try\n    '
        print(str_0)
        str_1 = '    Given: when Try is not successfully.\n    '
        print(str_1)
        str_2 = '    When: call on_fail method.\n    '
        print(str_2)
        str_3 = '    Then: call fail_callback with failure value.\n    '
        print(str_3)
        is_call = False

        def callback(value):
            nonlocal is_call
            is_call = True

        try_0 = Try(None, False)
        try_0.on_fail(callback)
        assert is_call

    test_case_0()


# Generated at 2022-06-25 23:59:25.779252
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def assert_equal(result, expected):
        if not result == expected:
            raise Exception(
                'Assertion error: \nexpected: {} \ngot: {}'.format(expected, result))

    assert_equal(Try.of(1, int, '1').get_or_else(0), 1)
    assert_equal(Try.of(int, 'abc').get_or_else(0), 0)


# Generated at 2022-06-25 23:59:31.502708
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    str_0 = '\n    Test get_or_else of Try\n    '
    print(str_0)
    assert Try(1, True).get_or_else('error') == 1
    assert Try('error', False).get_or_else('error') == 'error'
    print(str_0 + 'Success!\n')
    
    

# Generated at 2022-06-25 23:59:33.998353
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert(Try(0, True).get_or_else(1) == 0)
    assert(Try(0, False).get_or_else(1) == 1)

# Generated at 2022-06-25 23:59:36.374873
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(2, False).value == 2
    assert Try(2, False).is_success == False


# Generated at 2022-06-25 23:59:50.673950
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(value):
        nonlocal str_0
        str_0 += 'fail_callback called with value={}\n    '.format(value)

    nonlocal str_0
    str_0 = '\n    Test on_fail of Try\n    '
    Try.of(lambda x: 1 / 0, 1).on_fail(fail_callback)
    assert str_0 == '\n    Test on_fail of Try\n    fail_callback called with value=division by zero\n    ', 'unit test failed'
    str_0 = '\n    Test on_fail of Try\n    '
    Try.of(lambda x: 1, 1).on_fail(fail_callback)
    assert str_0 == '\n    Test on_fail of Try\n    ', 'unit test failed'


# Generated at 2022-06-25 23:59:58.740324
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    str_0 = '\n    Test method get_or_else of Try\n    '

    try:
        assert Try.of(int, '1').get_or_else(2) == 1
        print('{}test 0 passed'.format(str_0))
    except AssertionError:
        print('{}test 0 failed'.format(str_0))

    try:
        assert Try.of(int, 'a').get_or_else(2) == 2
        print('{}test 1 passed'.format(str_0))
    except AssertionError:
        print('{}test 1 failed'.format(str_0))



# Generated at 2022-06-26 00:00:01.835573
# Unit test for method __str__ of class Try
def test_Try___str__():
    str_0 = '\n    Test __str__ of Try\n    '
    try:
        assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    except:
        print(str_0 + 'FAILED')


# Generated at 2022-06-26 00:00:13.714792
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    str_0 = '\n    Test on_fail of Try\n    '
    def fail_callback(err):
        assert type(err) == AssertionError

    Try.of(lambda: 3 + 3).on_fail(fail_callback)
    Try.of(lambda: 3 + 3).on_fail(fail_callback)
    Try.of(lambda: 3 + 3).filter(lambda x: x > 5).on_fail(fail_callback)
    Try.of(lambda: 3 + 3).filter(lambda x: x < 5).on_fail(fail_callback)

    Try.of(lambda: 3 + 3).map(lambda x: x + 1).on_fail(fail_callback)
    Try.of(lambda: 3 + 3).map(lambda x: x + 1).filter(lambda x: x > 5).on_

# Generated at 2022-06-26 00:00:25.583186
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_0 = Try.of(lambda : 1)
    assert str(try_0) == 'Try[value=1, is_success=True]'

    try_1 = Try.of(lambda : 1, 1)
    assert str(try_1) == 'Try[value=1, is_success=True]'

    try_2 = Try.of(lambda : 1, 1, 2)
    assert str(try_2) == 'Try[value=1, is_success=True]'

    try_3 = Try.of(lambda : 1, 1, 2, 3)
    assert str(try_3) == 'Try[value=1, is_success=True]'

    try_4 = Try.of(lambda : 'abc')
    assert str(try_4) == "Try[value='abc', is_success=True]"

   

# Generated at 2022-06-26 00:00:35.780293
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x % 2 == 1) == Try(5, True), "Try filter test case-0 failed"
    assert Try(4, True).filter(lambda x: x % 2 == 1) == Try(4, False), "Try filter test case-1 failed"
    assert Try(5, False).filter(lambda x: x % 2 == 1) == Try(5, False), "Try filter test case-2 failed"
    assert Try(4, False).filter(lambda x: x % 2 == 1) == Try(4, False), "Try filter test case-3 failed"
    assert Try(NotImplementedError(), True).filter(lambda x: x % 2 == 1) == Try(NotImplementedError(), False),\
        "Try filter test case-4 failed"

# Generated at 2022-06-26 00:00:42.988399
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    str_0 = '\n    Test __eq__ of Try\n    '
    t_0 = Try(3, True)
    t_1 = Try(3, True)
    t_2 = Try(3, False)
    t_3 = Try(5, True)

# Generated at 2022-06-26 00:00:52.046050
# Unit test for constructor of class Try
def test_Try():
    str_0 = '\n    Test constructor of Try\n    '
    print(str_0)

    try:
        try_0 = Try(10, True)
        print('Successfully Try monad with value 10: ', try_0)
    except Exception as e:
        print(e)

    try:
        try_1 = Try(10, False)
        print('Not successfully Try monad with value 10: ', try_1)
    except Exception as e:
        print(e)

    try:
        try_2 = Try('Hello', True)
        print('Successfully Try monad with value Hello: ', try_2)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 00:00:56.188568
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, True).get_or_else(2) != 2

    assert Try(1, False).get_or_else(2) == 2
    assert Try(1, False).get_or_else(2) != 1


# Generated at 2022-06-26 00:01:04.764909
# Unit test for method on_success of class Try
def test_Try_on_success():
    str_0 = '\n    Test on_success of Try\n    '

    assert len(str_0) == 33, 'AssertionError: {} len is not 33'.format(str_0)


# Generated at 2022-06-26 00:01:29.869766
# Unit test for method on_success of class Try
def test_Try_on_success():
    str_0 = '\n    Unit test for method on_success of class Try\n    '

    def on_success(value):
        print('Try: {}'.format(value))

    def on_success_with_exception(value):
        raise Exception('Try must not be executed')

    Try(1, True)\
    .on_success(on_success)\
    .on_success(on_success_with_exception)

    Try(1, False)\
    .on_success(on_success_with_exception)


# Generated at 2022-06-26 00:01:34.222926
# Unit test for method get of class Try
def test_Try_get():
    with subTest(msg='Expect return None, because Try object is not successfully.'):
        try_monad = Try(None, False)
        assert try_monad.get() is None

    with subTest(msg='Expect return None, because Try object is successfully.'):
        try_monad = Try(10, True)
        assert try_monad.get() is not None


# Generated at 2022-06-26 00:01:36.168767
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: None).on_fail(lambda e: None) == Try(None, False)



# Generated at 2022-06-26 00:01:42.787483
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    str_0 = '\n    Test get_or_else of Try\n    '
    test_target_0 = Try.of(int, '1')
    print((str_0 + (('Current value: ' + str(test_target_0.get_or_else(None))) + '\n    ')))
    test_target_0 = Try.of(lambda: 1 / 0)
    print((str_0 + (('Current value: ' + str(test_target_0.get_or_else(None))) + '\n    ')))


# Generated at 2022-06-26 00:01:46.251154
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    str_0 = '\n    Test __eq__ of Try\n    '
    # Assertions
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)


# Generated at 2022-06-26 00:01:55.488048
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '\n    Test filter of Try\n    '

    from functools import partial

    def filterer(num):
        return num % 2 == 0

    def filterer_false(num):
        return num % 2 == 1

    def should_be_true(v):
        if v != 'test':
            raise ValueError('v != test')

    def should_be_none(v):
        if v is not None:
            raise ValueError('v is not None')

    def should_be_false(v):
        if isinstance(v, ValueError):
            raise ValueError('v is not ValueError')

    def should_be_error(v):
        if not isinstance(v, ValueError):
            raise ValueError('v is not ValueError')


# Generated at 2022-06-26 00:01:57.635283
# Unit test for method get of class Try
def test_Try_get():
    from nose.tools import assert_equal
    value = 1
    t = Try(value, True)

    assert_equal(t.get(), value)


# Generated at 2022-06-26 00:02:07.879867
# Unit test for method map of class Try
def test_Try_map():
    str_0 = '\n    Test map of Try\n    '
    assert str_0 == '\n    Test map of Try\n    '
    assert Try.of(lambda a : a + 10, 10).map(lambda b : b * 2).get() == 30
    assert Try.of(lambda a : a + 10, 10).map(lambda b : b * 2).on_success(lambda c : print(c)).get() == 30
    assert Try.of(lambda a : a + 10, 10).map(lambda b : b * 2).on_fail(lambda c : print(c)).get() == 30
    assert Try.of(lambda a : a, [10, 20, 30]).map(lambda x : [i * 2 for i in x]).get() == [20, 40, 60]

# Generated at 2022-06-26 00:02:10.525334
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'
test_case_0()


# Generated at 2022-06-26 00:02:16.304514
# Unit test for method __str__ of class Try
def test_Try___str__():
    str_0 = '\n    Test __str__ of Try\n    '
    try_0 = Try(12, True)
    try_1 = Try(12, False)
    assert str(try_0) == 'Try[value=12, is_success=True]', \
        '{0}Error: method __str__ of Try not work correctly'.format(str_0)
    assert str(try_1) == 'Try[value=12, is_success=False]', \
        '{0}Error: method __str__ of Try not work correctly'.format(str_0)


# Generated at 2022-06-26 00:02:59.208539
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: lambda: 'test')().get_or_else('Not test') == 'test'
    assert Try.of(lambda: 1 / 0)().get_or_else('Not test') == 'Not test'
    assert Try.of(lambda: 1 / 0)() == Try(ZeroDivisionError(), False)
