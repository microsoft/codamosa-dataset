

# Generated at 2022-06-25 23:53:13.014955
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    str_0 = "uV7Z71A3T}#_+sq"
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    dict_1 = {}
    str_1 = "I7bQlkN?tK!"
    bool_1 = True
    try_1 = Try(str_1, bool_1)
    assert try_0.filter(lambda value: 1 == 0) == try_1
    dict_2 = {}
    str_2 = "U|\6U%Q6"
    bool_2 = False
    try_2 = Try(str_2, bool_2)
    dict_3 = {}
    str_3 = "uV7Z71A3T}#_+sq"
    bool_3 = True

# Generated at 2022-06-25 23:53:20.576825
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 11
    int_1 = int_0
    int_2 = int_1
    str_0 = "%P?~H/+FnjCg_y3i,NF"
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(lambda x: bool(int_2))
    bool_1 = False if (try_1.value) else False



# Generated at 2022-06-25 23:53:25.274010
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    str_0 = "2@r'o=VE]uuR'yG !5 N"
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    assert try_0.filter(lambda x: True) == Try(str_0, True)


# Generated at 2022-06-25 23:53:30.590104
# Unit test for method filter of class Try
def test_Try_filter():
    print("case 0")
    dict_0 = {}
    str_0 = "2@r'o=VE]uuR'yG !5 N"
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    def func_1(x):
        return (5 > x.__len__())
    try_1 = try_0.filter(func_1)
    assert try_1.value == str_0
    assert try_0.is_success == True
    assert try_0.value == str_0


# Generated at 2022-06-25 23:53:36.329502
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    str_0 = "2@r'o=VE]uuR'yG !5 N"
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    def func_0(arg_0):
        if arg_0 == '2@r\'o=VE]uuR\'yG !5 N':
            return True
        else:
            return False

    assert(try_0.filter(func_0)) == Try("2@r'o=VE]uuR'yG !5 N", True)



# Generated at 2022-06-25 23:53:46.464409
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    str_0 = "2@r'o=VE]uuR'yG !5 N"
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    def lambda_0(arg_0):
        return len(arg_0) == 27
    try_1 = try_0.filter(lambda_0)
    bool_1 = try_1.is_success
    bool_2 = bool_1
    assert bool_2
    try_2 = Try.of(str_0 , dict_0)
    def lambda_1(arg_0):
        return len(arg_0) == 19
    try_3 = try_2.filter(lambda_1)
    bool_3 = try_3.is_success
    bool_4 = not bool_3


# Generated at 2022-06-25 23:53:53.970958
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    dict_0 = {}
    str_0 = "2@r'o=VE]uuR'yG !5 N"
    str_1 = "2@r'o=VE]uuR'yG !5 N"
    bool_0 = True

    # When
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(lambda value: value == str_1)
    bool_1 = try_1.get() == str_1

    # Then
    assert not bool_1


# Generated at 2022-06-25 23:53:58.540902
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    str_0 = "2@r'o=VE]uuR'yG !5 N"
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(lambda v_0: True)


# Generated at 2022-06-25 23:54:05.229108
# Unit test for method filter of class Try
def test_Try_filter():
    # Tested with class Try
    str_0 = "2@r'o=VE]uuR'yG !5 N"
    try_0 = Try(str_0, True)

    #a = lambda a: a == str_0
    #try_1 = try_0.filter(a)
    #print(try_1)

    a = lambda a: a == str_0
    try_2 = Try(str_0, False).filter(a)
    print(try_2)
    a = lambda a: a == str_0
    try_3 = Try(str_0, True).filter(a)
    print(try_3)

    a = lambda a: a == "M"
    try_4 = Try(str_0, True).filter(a)
    print(try_4)





# Generated at 2022-06-25 23:54:10.747257
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    str_0 = "2@r'o=VE]uuR'yG !5 N"
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    assert str_0 == try_0.filter(lambda t: True).get()


# Generated at 2022-06-25 23:54:17.938885
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)

    def mapper(x):
        return x

    def filterer(x):
        if x == 'case 0':
            return True
        return False

    try_1 = try_0.filter(filterer)

    assert try_1 == Try('case 0', True)

# Generated at 2022-06-25 23:54:31.774457
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    str_0 = 'case 0'
    str_1 = 'case 1'
    str_2 = 'case 2'
    str_3 = 'case 3'
    str_4 = 'case 4'

    try_0 = Try(str_0, bool_0)
    try_1 = Try(str_1, bool_0)
    try_2 = Try(str_2, bool_0)
    try_3 = Try(str_3, bool_0)
    try_4 = Try(str_4, bool_0)

    def filterer_0(value):
        return value == str_2

    try_0 = try_0.filter(filterer_0)
    try_1 = try_1.filter(filterer_0)
    try_2 = try_

# Generated at 2022-06-25 23:54:36.864165
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: str) -> bool:
        return value == 'str'

    str_0 = 'str'
    str_1 = 'str_1'
    try_0 = Try(str_0, True)
    try_1 = Try(str_1, True)
    try_2 = try_0.filter(filterer)
    try_3 = try_1.filter(filterer)


# Generated at 2022-06-25 23:54:46.305219
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    assert(try_0.filter(lambda x: x == 'case 0') == Try(str_0, True))
    assert(try_0.filter(lambda x: x == 'case 1') == Try(str_0, False))

    str_1 = 'case 1'
    bool_1 = False
    try_1 = Try(str_1, bool_1)
    assert(try_1.filter(lambda x: x == 'case 0') == Try(str_1, False))



# Generated at 2022-06-25 23:54:53.458349
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    assert isinstance(try_0, Try),\
        'isinstance(try_0, Try)'
    assert try_0 == Try(str_0, bool_0),\
        'try_0 == Try(str_0, bool_0)'
    assert try_0.get() == str_0,\
        'try_0.get() == str_0'
    assert try_0.is_success == bool_0,\
        'try_0.is_success == bool_0'

    str_1 = 'case 1'
    bool_1 = False
    try_1 = try_0.filter(lambda x: x == str_0)

# Generated at 2022-06-25 23:55:04.672807
# Unit test for method filter of class Try
def test_Try_filter():
    """Test filter method of Try object.

    Tests correct filter method behavior.

    :returns: True when test passes else False
    :rtype: boolean
    """
    try_0 = Try(1, False)
    try_filter_0 = try_0.filter(lambda x: True)
    try_filter_1 = try_0.filter(lambda x: False)
    try_1 = Try(2, True)
    try_filter_2 = try_1.filter(lambda x: True)
    try_filter_3 = try_1.filter(lambda x: False)

# Generated at 2022-06-25 23:55:13.049133
# Unit test for method filter of class Try
def test_Try_filter():
    def t_0(str_0):
        return str_0 is not None

    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(t_0)

    def t_1(str_0):
        return str_0 is None

    try_2 = try_0.filter(t_1)
    try_3 = Try(None, True).filter(t_0)
    try_4 = Try(None, False).filter(t_0)



# Generated at 2022-06-25 23:55:23.858688
# Unit test for method filter of class Try
def test_Try_filter():
    # Case 0
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_0_mapper = lambda value: value == 'case 0'
    try_0_mapper_value = try_0_mapper(str_0)
    try_0_filtered = try_0.filter(try_0_mapper)
    assert try_0_filtered == Try(str_0, True)

    # Case 1
    str_1 = 'case 1'
    bool_1 = False
    try_1 = Try(str_1, bool_1)
    try_1_mapper = lambda value: value == 'case 1'
    try_1_mapper_value = try_1_mapper(str_1)
    try_

# Generated at 2022-06-25 23:55:31.696344
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x == 'true'

    try_0 = Try('true', True)
    try_1 = try_0.filter(filterer)

    assert try_1 == Try('true', True)

    try_0 = Try('false', True)
    try_1 = try_0.filter(filterer)

    assert try_1 == Try('false', False)


# Generated at 2022-06-25 23:55:38.276820
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == str_0

    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)

    try_1 = try_0.filter(filterer)
    assert try_1.value == str_0
    assert try_1.is_success == True

    str_1 = 'case 1'
    try_2 = try_0.filter(lambda x: x == str_1)
    assert try_2.value == str_0
    assert try_2.is_success == False

# Generated at 2022-06-25 23:55:51.520242
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_1 = Try(str_0, False)
    @assert_equal
    def _():
        return try_0.filter(lambda a: a == str_0)
    @assert_equal
    def _():
        return Try('case 1', False)
    @assert_equal
    def _():
        return try_1.filter(lambda a: a == str_0)
    @assert_equal
    def _():
        return Try(str_0, False)
    return 0

# Generated at 2022-06-25 23:55:55.313960
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 0, ).filter(lambda x: x == 0).is_success == True
    assert Try.of(lambda: 0, ).filter(lambda x: x == 1).is_success == False


# Generated at 2022-06-25 23:56:03.845806
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    bool_1 = False
    try_1 = Try(str_0, bool_1)

    str_1 = 'case 1'
    bool_2 = False
    try_2 = Try(str_1, bool_2)
    str_2 = 'case 2'
    bool_3 = True
    try_3 = Try(str_2, bool_3)

    # case 1
    assert try_0.filter(lambda x: x == str_0) == try_3

    # case 2
    assert try_0.filter(lambda x: x == str_1) == try_1

    # case 3

# Generated at 2022-06-25 23:56:08.842368
# Unit test for method filter of class Try
def test_Try_filter():
    bool_1 = False
    str_1 = 'case 1'
    try_1 = Try(str_1, bool_1)
    function_1 = lambda x: len(x) > 3
    try_2 = try_1.filter(function_1)
    bool_2 = False
    assert try_2.is_success == bool_2


# Generated at 2022-06-25 23:56:16.675877
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(val):
        return val == 'case 1'
    try_0 = Try('case 0', False)
    try_1 = Try('case 1', True)
    try_2 = Try('case 2', True)
    assert try_0.filter(filterer) == Try('case 0', False)
    assert try_1.filter(filterer) == Try('case 1', True)
    assert try_2.filter(filterer) == Try('case 2', False)

# Generated at 2022-06-25 23:56:24.363132
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'Exception'
    bool_0 = False
    try_0 = Try(str_0, bool_0)

    str_1 = 'Hello is not Exception'
    bool_1 = True
    try_1 = Try(str_1, bool_1)

    def filterer(value: str) -> bool:
        if value == 'Hello is not Exception':
            return True
        return False

    assert try_0.filter(filterer) == Try(str_0, bool_0)
    assert try_1.filter(filterer) == Try(str_1, bool_1)



# Generated at 2022-06-25 23:56:33.812803
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(lambda str_: 'e' in str_)
    assert try_0 == try_1

    str_1 = 'case 1'
    bool_1 = False
    try_2 = Try(str_1, bool_1)
    try_3 = try_2.filter(lambda str_: 'e' in str_)
    assert try_2 == try_3

    str_2 = 'case 2'
    bool_2 = True
    try_4 = Try(str_2, bool_2)
    try_5 = try_4.filter(lambda str_: 'e' not in str_)
    assert try_2 == try_5


# Generated at 2022-06-25 23:56:45.012646
# Unit test for method filter of class Try
def test_Try_filter():
    def get_bool_0(x): return True
    def get_bool_1(x): return False

    try_0 = Try(True, True)
    try_1 = Try(True, False)
    try_2 = Try(False, True)
    try_3 = Try(False, False)

    try_0_ = Try(True, True)
    try_1_ = Try(True, False)
    try_2_ = Try(False, False)
    try_3_ = Try(False, False)

    assert(try_0.filter(get_bool_0()) == try_0_)
    assert(try_1.filter(get_bool_0()) == try_1_)
    assert(try_2.filter(get_bool_0()) == try_2_)

# Generated at 2022-06-25 23:56:47.793268
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    def mult_4(a):
        return a * 4
    try_1 = Try.of(mult_4, str_0)
    assert (try_1 == Try(str_0 * 4, True))
    assert (try_0.filter(filter_def) == try_0)
    assert (try_1.filter(filter_def) == Try(str_0 * 4, False))


# Generated at 2022-06-25 23:56:54.320363
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'fail'

    assert Try('success', True).filter(filterer) == Try('success', True)
    assert Try('fail', True).filter(filterer) == Try('fail', True)
    assert Try('success', False).filter(filterer) == Try('success', False)
    assert Try('fail', False).filter(filterer) == Try('fail', False)


# Generated at 2022-06-25 23:57:10.141856
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try('case 0', True).filter(lambda x: False) == Try('case 0', False)
    assert Try('case 1', True).filter(lambda x: True) == Try('case 1', True)
    assert Try('case 2', False).filter(lambda x: False) == Try('case 2', False)
    assert Try(1, True).filter(lambda x: x < 0) == Try(1, False)
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(1, False).filter(lambda x: x < 0) == Try(1, False)

# Generated at 2022-06-25 23:57:19.670860
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(
        lambda value: value == 'case 0'
    )
    assert try_0 == try_1
    try_2 = try_1.filter(
        lambda value: value == 'non case 0'
    )
    assert not try_2.is_success
    assert try_2.get() == try_0.get()
    str_1 = 'case 1'
    try_1 = Try(str_1, False)
    try_2 = try_1.filter(
        lambda value: value == 'non case 1'
    )
    assert not try_2.is_success
    assert try_2.get() == try_1.get

# Generated at 2022-06-25 23:57:29.687901
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 10
    int_1 = 10
    try_0 = Try(int_0, True)
    try_1 = Try(int_0, True)
    try_2 = Try(int_0, False)
    try_3 = Try(int_1, True)
    try_4 = Try(int_1, False)
    try_5 = Try(int_1, False)
    assert try_0.filter(lambda val: val == int_0) == try_1
    assert try_0.filter(lambda val: val == int_1) == try_2
    assert try_0.filter(lambda val: val != int_0) == try_3
    assert try_0.filter(lambda val: val != int_1) == try_4

# Generated at 2022-06-25 23:57:39.007933
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_0(_):
        return False
    str_0 = 'case 0'
    bool_0 = False
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(filter_0)
    try_2 = Try(str_0, bool_0)
    assert try_1 == try_2
    
    def filter_1(_):
        return True
    str_1 = 'case 1'
    bool_1 = True
    try_3 = Try(str_1, bool_1)
    try_4 = try_3.filter(filter_1)
    try_5 = Try(str_1, bool_1)
    assert try_4 == try_5
    
    def filter_2(_):
        return False
    str_2 = 'case 2'

# Generated at 2022-06-25 23:57:45.240122
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)

    str_1 = 'case 1'
    bool_1 = False
    try_1 = Try(str_1, bool_1)

    str_2 = 'case 2'
    bool_2 = True
    try_2 = Try(str_2, bool_2)

    str_3 = 'case 3'
    bool_3 = False
    try_3 = Try(str_3, bool_3)

    str_4 = 'case 4'
    bool_4 = False
    try_4 = Try(str_4, bool_4)

    str_5 = 'case 5'
    bool_5 = True
    try_5 = Try(str_5, bool_5)

   

# Generated at 2022-06-25 23:57:49.769006
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    bool_1 = bool_0 == bool_0
    try_1 = try_0.filter(lambda x: True)
    assert try_1 == Try(str_0, bool_1)


# Generated at 2022-06-25 23:57:59.439235
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'case 0'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_0_filtered_0 = try_0.filter(lambda success: success == str_0)
    assert(try_0_filtered_0 == Try(str_0, True))
    try_0_filtered_1 = try_0.filter(lambda success: success == str_0 + ' == ' + str_0)
    assert(try_0_filtered_1 == Try(str_0, False))
    str_1 = 'case 1'
    try_1 = Try(str_1, False)
    try_1_filtered_0 = try_1.filter(lambda success: success == str_1)

# Generated at 2022-06-25 23:58:05.980118
# Unit test for method filter of class Try
def test_Try_filter():
    x = 0

    def success_callback(value: int) -> None:
        assert value == x
        print(value)

    def fail_callback(value: int) -> None:
        assert value == x
        assert isinstance(value, Exception)
        print(value)

    @decorators.TestCase
    @decorators.with_args(x, success_callback, fail_callback)
    def run_test(x: int, success_callback: Callable[[int], None], fail_callback: Callable[[int], None]) -> None:
        def filterer(value: int) -> bool:
            return value > 0

        def binder(value: int) -> Try[int]:
            return Try(value, True)

        Try.of(lambda: 1).filter(filterer).bind(binder).on_

# Generated at 2022-06-25 23:58:14.267345
# Unit test for method filter of class Try
def test_Try_filter():
    # Init test case
    test_case = Try(2, True).filter(lambda x: 2 < 5)

    # Successfully case
    assert test_case.is_success
    # Value Assert
    assert test_case.get() == 2

    # Not successfully case
    test_case = Try(2, True).filter(lambda x: 2 > 5)
    assert not test_case.is_success
    # Value Assert
    assert test_case.get() == 2



# Generated at 2022-06-25 23:58:24.435262
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'Success'
    str_1 = 'Successful'
    str_2 = 'Successfully'
    str_3 = 'Successfulness'
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = 4
    func_0 = (lambda x: x in [str_0, str_1, str_2, str_3])
    func_1 = (lambda x: x in [str_0, str_1, str_2, str_3])
    func_2 = (lambda x: x in [int_0, int_1, int_2, int_3])
    func_3 = (lambda x: x in [int_0, int_1, int_2, int_3])

# Generated at 2022-06-25 23:58:40.890810
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda: Try.of(lambda: int('x'))).filter(lambda t: t.is_success == True)
    assert result == Try(Try(Exception('invalid literal for int() with base 10: \'x\''), False), True)
    try:
        result = Try.of(lambda: Try.of(lambda: int('x'))).filter(lambda t: t.get() == 10)
    except Exception as e:
        result = e
    assert result == Try(Try(Exception('invalid literal for int() with base 10: \'x\''), False), True)
    try:
        result = Try.of(lambda: Try.of(lambda: int('x'))).filter(lambda t: t.get() == 10).get()
    except Exception as e:
        result = e

# Generated at 2022-06-25 23:58:46.525137
# Unit test for method filter of class Try
def test_Try_filter():
    value_0 = Try.of(int, '0')
    value_1 = Try.of(int, '1')

    assert value_0.filter(lambda x: x == 0) == Try(0, True)
    assert value_0.filter(lambda x: x == 1) == Try(0, False)
    assert value_1.filter(lambda x: x == 0) == Try(1, False)
    assert value_1.filter(lambda x: x == 1) == Try(1, True)


# Generated at 2022-06-25 23:58:51.706592
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '123').filter(lambda x: x > 1) == Try(123, True)
    assert Try.of(int, 'one').filter(lambda x: x > 1) == Try('one', False)
    #assert Try.of(int_0).filter(lambda x: x > 1) == Try(None, False)


# Generated at 2022-06-25 23:58:59.068950
# Unit test for method filter of class Try
def test_Try_filter():
    t_0 = Try(int_0, True).filter(lambda n: n < 5)
    t_1 = Try(int_0, True).filter(lambda n: n >= 5)
    t_2 = Try(int_0, False).filter(lambda n: n < 5)

    assert t_0 == Try(int_0, True)
    assert t_1 == Try(int_0, False)
    assert t_2 == Try(int_0, False)


# Generated at 2022-06-25 23:59:06.945246
# Unit test for method filter of class Try

# Generated at 2022-06-25 23:59:14.865181
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 0
    assert Try.of(int_0)  == Try(0, True)
    assert Try.of(test_case_0, int_0) == Try(ZeroDivisionError, False)
    assert Try.of(lambda x: x, int_0).map(lambda x: x + 10).get() == 10
    assert Try.of(test_case_0, int_0).map(lambda x: x + 10)  == Try(ZeroDivisionError, False)
    assert Try.of(int_0).filter(lambda x: x > 1) == Try(0, False)
    assert Try.of(int_0).filter(lambda x: x == 0) == Try(0, True)

if __name__ == '__main__':  # pragma: no cover
    test_Try_filter()

# Generated at 2022-06-25 23:59:23.063018
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 0
    int_2 = 2
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''

    # call function with value 0 and returns output in Try class
    # when function don't raise Exception
    try_0 = Try.of(divmod, int_2, int_0)
    # call function with value 1 and returns output in Try class
    # when function don't raise Exception
    try_1 = Try.of(divmod, int_2, 1)
    # call function with value 2 and returns output in Try class
    # when function don't raise Exception
    try_2 = Try.of(divmod, int_2, 2)

    # value == 0

# Generated at 2022-06-25 23:59:27.913895
# Unit test for method filter of class Try
def test_Try_filter():
    def add_1_try(num: int) -> Try[int]:
        return Try.of(lambda x: x + 1, num)

    def even(number: int) -> bool:
        return number % 2 == 0

    assert add_1_try(5).filter(even) == Try(6, False), 'filter value'
    assert add_1_try(4).filter(even) == Try(5, True), 'filter value'


# Generated at 2022-06-25 23:59:38.520104
# Unit test for method filter of class Try
def test_Try_filter():
    result_0 = Try.of(int, '123')
    assert result_0.filter(lambda val: val == 123) == Try(123, True)
    assert result_0.filter(lambda val: val != 123) == Try(123, False)

    try:
        result_1 = Try.of(int, '123').filter(lambda val: val / 0)
    except Exception as e:
        result_1 = Try(e, False)

    assert result_1 == Try(ZeroDivisionError('division by zero'), False)

    try:
        result_2 = Try.of(test_case_0)
    except Exception as e:
        result_2 = Try(e, False)

    assert result_2 == Try(ZeroDivisionError('division by zero'), False)

# Generated at 2022-06-25 23:59:47.295181
# Unit test for method filter of class Try
def test_Try_filter():
    try:
        int_0 = 0
        int_1 = 1
        try_int_0 = Try.of(lambda: int_0, ())
        assert(try_int_0.filter(lambda x: x != 0) == Try(0, False))
        assert(try_int_0.filter(lambda x: x == 0) == try_int_0)
        try_int_1 = Try.of(lambda: int_1, ())
        assert(try_int_1.filter(lambda x: x != 0) == try_int_1)
    except Exception as e:
        # Fail when e is not ZeroDivisionError
        assert(isinstance(e, ZeroDivisionError))
        int_1 = 1
        try_int_1 = Try.of(lambda: int_1, ())

# Generated at 2022-06-26 00:00:10.749450
# Unit test for method filter of class Try
def test_Try_filter():
    """
    AssertionError: assert False is True.

    AssertionError: assert False is True.

    AssertionError: assert False is True.
    """

    int_0 = 0
    int_1 = 1

    # not successfully
    # filter raises ValueError
    assert Try.of(int_0).filter(int_1) == Try(ValueError('int() argument must be a string, a bytes-like object or a number, not \'int\''), False)

    # not successfully
    # filter raises ValueError
    assert Try.of(int_1).filter(int_0) == Try(ValueError('int() argument must be a string, a bytes-like object or a number, not \'int\''), False)

    # not successfully
    # filter raises ValueError

# Generated at 2022-06-26 00:00:18.293197
# Unit test for method filter of class Try
def test_Try_filter():
    def is_less(val):  # function to check is value less then 0
        return val < 0

    def is_greater(val):  # function to check is value greater then 0
        return val > 0

    assert Try.of(lambda val: val, -1).filter(is_greater) == Try(Exception(ValueError), False)
    assert Try.of(lambda val: val, -1).filter(is_less) == Try(-1, True)
    assert Try.of(lambda val: val, 1).filter(is_greater) == Try(1, True)
    assert Try.of(lambda val: val, 1).filter(is_less) == Try(Exception(ValueError), False)

# Generated at 2022-06-26 00:00:26.731277
# Unit test for method filter of class Try
def test_Try_filter():
    def is_positive_int(value):
        return isinstance(value, int) and value > 0

    assert Try.of(test_case_0).filter(is_positive_int) == Try('int' > '0', False)
    assert Try.of(test_case_0).filter(is_positive_int).filter(is_positive_int) == Try('int' > '0', False)
    assert Try.of(test_case_0).filter(is_positive_int).filter(is_positive_int).filter(is_positive_int) == Try('int' > '0', False)



# Generated at 2022-06-26 00:00:30.694801
# Unit test for method filter of class Try
def test_Try_filter():
    """
    For Try[B] monad filter method take function with A -> B signature,
    call this function with monad value when monad is successfully, and build new Try monad.
    When Try[A] is not successfully, Try[B] is not successfully too.
    """
    # Successfully filtered Try monad
    int_0 = Try(0, True)\
        .filter(lambda n: n == 0)\
        .get()
    assert int_0 == 0, "Test filter method for successfully Try monad failed."

    # Not successfully filtered Try monad, because of the previous Try
    # is not successfully
    is_fail = Try(0, False)\
        .filter(lambda n: n == 0)\
        .is_success
    assert is_fail is False, "Test filter method for not successfully Try monad failed."


# Generated at 2022-06-26 00:00:40.034607
# Unit test for method filter of class Try
def test_Try_filter():
    """
    When we call filter of Try monad
    - and Try monad is successfully
    - and filter returns True:
        - We expect that returned monad will have value of first monad
        - We expect that returned monad will be successfully
    - and filter returns False:
        - We expect that returned monad will have value of first monad
        - We expect that returned monad will not be successfully
    - and Try monad is not successfully
        - We expect that returned monad will have value of first monad
        - We expect that returned monad will not be successfully
    :return:
    """
    # when Try monad is successfully and filter returns False
    # We expect that returned monad will have value of first monad
    # We expect that returned monad will not be successfully
    m = Try.of(lambda: 4)

# Generated at 2022-06-26 00:00:45.130868
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(test_case_0).filter(lambda x: True) == Try.of(test_case_0).bind(lambda x: Try(x, True))
    assert Try.of(test_case_0).filter(lambda x: True).get() == test_case_0
    assert Try.of(test_case_0).filter(lambda x: False).get() is None


# Generated at 2022-06-26 00:00:47.069081
# Unit test for method filter of class Try
def test_Try_filter():
    fn = lambda x: x / 1
    Try.of(fn, int_0)


# Generated at 2022-06-26 00:00:56.020853
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 0
    int_1 = 1
    # This case is success
    assert Try.of(test_case_0).filter(lambda x: True) == Try(None, True)
    # This case is not success
    assert Try.of(test_case_0) \
        .filter(lambda x: False) == Try(None, False)
    # This case is not success and value is 0
    assert Try.of(lambda: 1 / int_0) \
        .filter(lambda x: True) \
        == Try(zero_division, False)
    # This case is not success and value is 0
    assert Try.of(lambda: 1 / int_0) \
        .filter(lambda x: False) \
        == Try(zero_division, False)



# Generated at 2022-06-26 00:01:04.612524
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 0

    def filterer_return_true(value):
        return True

    def filterer_return_false(value):
        return False

    try_success = Try.of(lambda: int_0)
    try_fail = Try.of(test_case_0)

    try_success_filtered_true = try_success.filter(filterer_return_true)
    assert try_success_filtered_true.value == int_0
    assert try_success_filtered_true.is_success

    try_success_filtered_false = try_success.filter(filterer_return_false)
    assert try_success_filtered_false.value == int_0
    assert not try_success_filtered_false.is_success

    try_fail_filtered = try_fail

# Generated at 2022-06-26 00:01:13.821721
# Unit test for method filter of class Try
def test_Try_filter():
    # when and then
    int_0 = 0
    m_int_0 = Try.of(int, int_0)
    m_int_0_res = m_int_0.filter(lambda value: value == 0)
    assert(m_int_0 == m_int_0_res)

    # when and then not
    m_int_1 = Try.of(int, "1")
    m_int_1_res = m_int_1.filter(lambda value: value == 0)
    assert(not m_int_1 == m_int_1_res)
    assert(m_int_1_res.is_success == False)


# Generated at 2022-06-26 00:01:40.413465
# Unit test for method filter of class Try
def test_Try_filter():
    m_0 = Try.of(lambda x: x + 10, int_0)
    m_1 = m_0.filter(lambda x: x < 0)
    assert m_1 is m_0

    m_2 = m_0.filter(lambda x: x > 0)
    assert m_2 is m_0

    m_3 = m_0.filter(lambda x: True)
    assert m_3 is m_0


# Generated at 2022-06-26 00:01:46.824935
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(('{}', 4, 4, 3), True).filter(lambda x: len(x) == 4).get_or_else(None) == ('{}', 4, 4, 3)
    assert Try(('{}', 4, 4, 3), True).filter(lambda x: len(x) == 3).get_or_else(None) == None
    assert Try(('{}', 4, 4, 3), False).filter(lambda x: len(x) == 3).get_or_else(None) == None


# Generated at 2022-06-26 00:01:49.424523
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: int_0).filter(lambda _: True) == Try(int_0, True)
test_Try_filter.test = 'test_case_0'


# Generated at 2022-06-26 00:01:54.902380
# Unit test for method filter of class Try
def test_Try_filter():
    case_0 = Try(2, True).filter(lambda x: x % 2 == 0)
    assert case_0.is_success == True
    case_1 = Try(2, True).filter(lambda x: x % 2 == 1)
    assert case_1.is_success == False
    case_2 = Try(2, False).filter(lambda x: x % 2 == 1)
    assert case_2.is_success == False

# Generated at 2022-06-26 00:02:04.997349
# Unit test for method filter of class Try
def test_Try_filter():
    # try-catch example
    try:
        int_0 = 0
        result = int_0 / int_0
    except ZeroDivisionError:
        result = 'div by zero'
    assert result == 'div by zero'

    # try example with Try object
    int_0 = 0
    result = Try.of(lambda: int_0 / int_0).filter(lambda _: _ != 2)
    assert not result.is_success
    assert result.get() == 'div by zero'

    # try example don't raised exception on filter
    int_0 = 1
    result = Try.of(lambda: int_0 / int_0).filter(lambda _: _ != 2)
    assert result.is_success
    assert result.get() == 1


# Generated at 2022-06-26 00:02:09.500179
# Unit test for method filter of class Try
def test_Try_filter():
    # Try[value=0, is_success=False]
    t = Try.of(int_0, '0')

    # Try[value=0, is_success=False]
    assert t.filter(lambda x: x == 0) == Try(0, False)

    # Try[value=0, is_success=True]
    assert t.filter(lambda x: x == 1) == Try(0, True)


# Generated at 2022-06-26 00:02:11.793092
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(test_case_0)
    try_1 = try_0.filter(lambda x: int_0 == 0)
    assert try_1 == Try(None, True)

# Generated at 2022-06-26 00:02:17.478647
# Unit test for method filter of class Try
def test_Try_filter():
    from random import random
    from math import ceil
    from utils import random_int
    from assertpy import assert_that

    def int_random_gt_0(value):
        return value > 0

    for _ in range(100):
        int_random = random_int()
        int_random_filtered = Try\
            .of(int, ceil(int_random * random()))\
            .filter(int_random_gt_0)\
            .get()

        assert_that(int_random_filtered in range(1, int_random), int_random_filtered)


# Generated at 2022-06-26 00:02:20.144282
# Unit test for method filter of class Try
def test_Try_filter():
    test_case_0()
    test_Try_filter_0()
    test_Try_filter_1()

# Test case for method filter of class Try

# Generated at 2022-06-26 00:02:23.544411
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filterer(value):
        return value == 0

    value = Try.of(test_case_0)
    result = value.filter(test_filterer)
    expected = Try(0, True)
    assert result == expected

test_Try_filter()

# Generated at 2022-06-26 00:02:52.454906
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(test_case_0).filter(lambda x: x > 10) == Try(0, False)
    assert Try.of(lambda: ''.join(list(map(str, list(range(0))))[:10])).filter(lambda x: len(x) > 100) == Try(0, False)



# Generated at 2022-06-26 00:02:59.009216
# Unit test for method filter of class Try
def test_Try_filter():
    success = Try.of(lambda: 1).filter(lambda a: True)
    fail = Try.of(lambda: 1).filter(lambda a: False)
    assert(success.is_success == True)
    assert(success.value == 1)
    assert(fail.is_success == False)
    assert(fail.value == None)

    exception = Try.of(lambda: 1//0).filter(lambda a: True)
    exception_value = exception.value
    assert(exception.is_success == False)
    assert(type(exception_value) == ZeroDivisionError)
