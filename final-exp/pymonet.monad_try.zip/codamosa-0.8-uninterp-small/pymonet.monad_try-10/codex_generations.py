

# Generated at 2022-06-25 23:53:12.343805
# Unit test for method filter of class Try
def test_Try_filter():
    assert (
        Try.of(lambda x: x + x, 2)\
        .filter(lambda x: x % 2 == 0)\
        .get() == 4
    )
    assert Try.of(lambda x: x + x, 3).filter(lambda x: x % 2 == 0).get_or_else(0) == 0
    assert (
        Try.of(lambda x: x + x, 4)\
        .filter(lambda x: x % 2 == 0)\
        .on_success(lambda x: print('yes'))\
        .on_fail(lambda x: print('no'))\
        .get_or_else(1) == 8
    )

# Generated at 2022-06-25 23:53:24.697344
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    func_0 = lambda arg_0: arg_0
    func_1 = lambda arg_0: arg_0
    func_2 = lambda arg_0: arg_0
    dict_0 = {0: 0, 1: 1, 2: 2}
    dict_1 = {0: 0, 1: 1, 2: 2}
    dict_2 = {0: 0, 1: 1, 2: 2}
    try_1 = try_0.filter(func_0)
    try_2 = try_0.filter(func_1)
    try_3 = try_0.filter(func_2)
    try_4 = try_1.filter(func_0)

# Generated at 2022-06-25 23:53:34.679634
# Unit test for method filter of class Try
def test_Try_filter():
  def test_default():
    def f_0():
      return None
    def f_1():
      return False
    def f_2(x: float, y: float):
      return x*x + y*y
    def f_3():
      return False
    def f_4():
      return None
    def f_5():
      return False
    def f_6():
      return True
    def f_7():
      return bytes([91, 92, 93, 94, 95, 96, 97, 98, 99, 100])
    def f_8():
      return bytes([0])
    def f_9():
      return bytes([1])
    def f_10():
      return False
    def f_11():
      return bytes([1])
    def f_12():
      return False

# Generated at 2022-06-25 23:53:39.768409
# Unit test for method filter of class Try
def test_Try_filter():
    bytes_0 = b'\x0c'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    try_1 = Try.of(test_Try_filter)
    try_2 = try_0.filter(test_Try_filter)
    try_3 = try_1.filter(test_Try_filter)
    assert try_0 == try_2
    assert try_1 != try_3


# Generated at 2022-06-25 23:53:46.903194
# Unit test for method filter of class Try
def test_Try_filter():
    """
    >>> test_Try_filter()
    True
    """
    def _filterer(value):
        return value

    bytes_0 = b'\x0c\xcd\xfa\x0e\xf0\xb3\xe8\x07\x11'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    try_0 = try_0.filter(_filterer)
    return try_0.get() == bytes_0


# Generated at 2022-06-25 23:53:55.678217
# Unit test for method filter of class Try
def test_Try_filter():
    def test_method_filter_0():
        # bytes_0 = b""
        # bool_0 = True
        # try_0 = Try(bytes_0, bool_0)
        bytes_0 = b''
        bool_0 = True
        try_0 = Try(bytes_0, bool_0)
        bytes_1 = b'\x82\xb8\x8e\xe7\xb9\xe4'
        def func_0(obj_0):
            return len(obj_0) > 0
        try_1 = try_0.filter(func_0)
        assert isinstance(try_1, Try)
        assert try_1.is_success is False
        assert hasattr(try_1, 'value')
        assert try_1.value == bytes_0

# Generated at 2022-06-25 23:54:04.096471
# Unit test for method filter of class Try

# Generated at 2022-06-25 23:54:10.789798
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return True

    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    try_0_filter = try_0.filter(filterer)

    assert(try_0_filter.value == bytes_0)
    assert(try_0_filter.is_success == bool_0)



# Generated at 2022-06-25 23:54:21.808128
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(bytes(), True).filter(
        lambda bytes_input: False) == Try(bytes(), False)
    assert Try(bytes(), True).filter(
        lambda bytes_input: True) == Try(bytes(), True)
    assert Try(bytes.fromhex("41"), True).filter(
        lambda bytes_input: str(bytes_input) == "A") == Try(bytes.fromhex("41"), True)
    assert Try(bytes.fromhex("41"), True).filter(
        lambda bytes_input: str(bytes_input) == "B") == Try(bytes.fromhex("41"), False)
    assert Try(False, True).filter(
        lambda bytes_input: False) == Try(False, True)
    assert Try(False, True).filter(
        lambda bytes_input: True) == Try(False, True)
   

# Generated at 2022-06-25 23:54:31.327845
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try("Hi!", True).filter(lambda string: "Hi" not in string) == Try("Hi!", False)
    assert Try("Hi!", True).filter(lambda string: "Hi" in string) == Try("Hi!", True)
    assert Try("Hi!", False).filter(lambda string: "Hi" in string) == Try("Hi!", False)
    assert Try("Hi!", False).filter(lambda string: "Hi" not in string) == Try("Hi!", False)


# Generated at 2022-06-25 23:54:40.346339
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    try_0.on_fail(lambda x: str(x))

    bytes_0 = b''
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    try_0.on_fail(lambda x: str(x))


# Generated at 2022-06-25 23:54:49.602506
# Unit test for method map of class Try
def test_Try_map():
    # Test with None value
    try_0 = Try(None, False)
    mapper_0 = lambda x: x**2

    # Test with success result
    try_0 = Try(2, True)
    mapper_0 = lambda x: x**2
    try_1 = Try(4, True)
    assert try_0.map(mapper_0) == try_1

    # Test with fail result
    try_0 = Try(2, False)
    mapper_0 = lambda x: x**2
    try_1 = Try(2, False)
    assert try_0.map(mapper_0) == try_1



# Generated at 2022-06-25 23:55:01.287093
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Given
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_0 = True
    bool_1 = True
    try_0 = Try(bytes_0, bool_0)
    try_1 = Try(bytes_0, bool_0)
    try_2 = Try(bytes_1, bool_0)
    try_3 = Try(bytes_0, bool_1)
    try_4 = Try(bytes_1, bool_1)
    # When
    result_0 = try_0 == try_1

# Generated at 2022-06-25 23:55:12.381797
# Unit test for method bind of class Try
def test_Try_bind():
    b'bytes_0'
    bool_0 = True
    try_0 = Try.of(b'bytes_0', bool_0)
    assert(try_0.is_success == True)
    assert(try_0.value == b'bytes_0')

    str_0 = ('str_0')
    bool_0 = True
    try_0 = Try.of(str_0, bool_0)
    assert(try_0.is_success == True)
    assert(try_0.value == 'str_0')

    class_0 = __class__
    try_0 = Try.of(class_0, class_0)
    assert(try_0.is_success == True)
    assert(try_0.value == __class__)

    function_0 = type

# Generated at 2022-06-25 23:55:19.055674
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = False
    def func_0(param_0: str) -> bool:
        nonlocal bool_0
        bool_0 = True
        return bool_0
    bool_1 = True
    str_0 = '>nx'
    try_0 = Try(str_0, bool_0)
    try_0 = try_0.on_success(func_0)
    bool_2 = bool_0
    assert bool_2



# Generated at 2022-06-25 23:55:31.460731
# Unit test for method get of class Try
def test_Try_get():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    assert try_0 == Try(bytes_0, bool_0)
    assert try_0.get() == bytes_0
    bool_0 = False
    try_0 = Try(None, bool_0)
    assert try_0 == Try(None, bool_0)
    assert try_0.get() is None
    bool_0 = False
    try_0 = Try(1.36, bool_0)
    assert try_0 == Try(1.36, bool_0)
    assert try_0.get() == 1.36
    bool_0 = False
    try_0 = Try(1.36, bool_0)

# Generated at 2022-06-25 23:55:39.618541
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    def func_0():
        s = ''
        for i in range(1, 1 + randint(1, 10)):
            s = s + str(i)
        return s
    func_1 = func_0()
    bytes_0 = b''
    bool_0 = True
    try_1 = Try(bytes_0, bool_0)

    def mock_fail_callback(e):
        ex_msg = 'Exception message must be equals error'
        assert e.args[0] == ex_msg
    try_0.on_fail(mock_fail_callback)

    def mock_fail_callback(e):
        ex_msg = 'Exception message must be equals error'

# Generated at 2022-06-25 23:55:43.460830
# Unit test for method __str__ of class Try
def test_Try___str__():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)

    assert str(try_0) == 'Try[value=b\'\', is_success=True]'


# Generated at 2022-06-25 23:55:55.052188
# Unit test for method bind of class Try
def test_Try_bind():
    import io
    import pickle

    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    bool_1 = isinstance(try_0.bind(lambda : None), Try)


# Generated at 2022-06-25 23:55:56.902172
# Unit test for method get of class Try
def test_Try_get():
    try_0 = Try(0, True)
    assert try_0.get() == 0



# Generated at 2022-06-25 23:56:03.488586
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    try_0.on_fail(print)
    assert(True)


# Generated at 2022-06-25 23:56:04.913215
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(None, True) == Try(None, True)


# Generated at 2022-06-25 23:56:16.235977
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    bytes_1 = bytes_0
    bool_1 = bool_0
    try_1 = Try(bytes_1, bool_1)

    long_0 = long()
    long_1 = long()
    long_2 = long()
    long_3 = long()
    long_4 = long()
    long_5 = long()
    long_6 = long()

    assert try_0.get_or_else(long_0) == long_0
    assert try_1.get_or_else(long_1) == long_1
    assert try_0.get_or_else(long_2) == long_2

# Generated at 2022-06-25 23:56:20.199526
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    assert Try(b'', bool_0).__eq__(Try(b'', True)) == True
    bool_0 = False
    assert Try(b'', bool_0).__eq__(Try(b'', True)) == False


# Generated at 2022-06-25 23:56:26.115333
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def success_callback_0(value):
        print('Successfully callback')

    def fail_callback_0(value):
        print('Fail callback')

    def success_callback_1(value):
        print('Successfully callback')

    def fail_callback_1(value):
        print('Fail callback')

    value_0 = Try(0, True)
    value_1 = Try(0, False)
    value_0.on_success(success_callback_0).on_fail(fail_callback_0)
    value_1.on_success(success_callback_1).on_fail(fail_callback_1)


# Generated at 2022-06-25 23:56:35.765708
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    print('Unit test for method on_fail of class Try:')

    def get_value(String):
        return String

    def on_fail_callback(e):
        return e

    temp_string_0: str = str('')
    bool_0: bool = False
    try_0 = Try(temp_string_0, bool_0)
    try_0 = try_0.on_fail(on_fail_callback)
    temp_string_1: str = str('sadfs')
    bool_1: bool = True
    try_1 = Try(temp_string_1, bool_1)
    try_1 = try_1.on_fail(on_fail_callback)
    temp_string_2: str = str('dsfsdf')
    bool_2: bool = False
    try_2 = Try

# Generated at 2022-06-25 23:56:38.422948
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    pass


# Generated at 2022-06-25 23:56:39.394356
# Unit test for constructor of class Try
def test_Try():
    test_case_0()



# Generated at 2022-06-25 23:56:44.958685
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bytes_0 = b'beep boop'
    bytes_1 = b'beep boop'
    bool_0 = False
    try_0 = Try(bytes_0, bool_0)
    assert try_0.get_or_else(bytes_1) == bytes_1
    try_0 = Try(bytes_0, True)
    assert try_0.get_or_else(bytes_1) == bytes_0


# Generated at 2022-06-25 23:56:52.480218
# Unit test for method bind of class Try
def test_Try_bind():
    def function_0(arg_1=None):
        return arg_1
    def function_1(arg_1):
        return Try(arg_1, True)
    def function_2(arg_1):
        return Try(arg_1, False)
    try_0 = Try(True, True)
    try_0.bind(function_1).bind(function_2)
    try_0.bind(function_2).bind(function_2)
    try_0.bind(function_2).bind(function_1)
    try_0.bind(function_1).bind(function_1)
    try_0.bind(function_1).bind(function_0)
    try_0.bind(function_1).bind(function_1).bind(function_1)

# Generated at 2022-06-25 23:57:08.058004
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    str_0 = "C"
    bool_1 = False
    try_0 = Try(str_0, bool_1)
    try_1 = Try(str_0, bool_1)
    assert (try_0 == try_1)
    assert (try_0.get_or_else(str_0) == str_0)
    assert (try_1.get_or_else(str_0) == str_0)


# Generated at 2022-06-25 23:57:13.995234
# Unit test for constructor of class Try
def test_Try():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    assert try_0.value == bytes_0
    assert try_0.is_success == bool_0
    assert type(try_0) == Try
    assert isinstance(try_0, Try)
    assert not isinstance(try_0, int)


# Generated at 2022-06-25 23:57:16.407789
# Unit test for method bind of class Try
def test_Try_bind():
    def add_x(x):
        return Try(x + 1, True)

    assert Try(1, True).bind(add_x) == Try(2, True)
    assert Try(1, False).bind(add_x) == Try(1, False)


# Generated at 2022-06-25 23:57:21.821770
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    print('test_Try_on_fail()')
    bytes_0 = b'bytes_0'
    str_0 = 'str_0'
    try_0 = Try(bytes_0, True)
    try_1 = Try(str_0, False)
    def test_success(value):
        print('Success!: {}'.format(value))
    def test_fail(value):
        print('Fail!: {}'.format(value))
    try_0.on_fail(test_success)
    try_0.on_success(test_fail)
    try_1.on_fail(test_fail)
    try_1.on_success(test_success)


# Generated at 2022-06-25 23:57:25.107770
# Unit test for method __str__ of class Try
def test_Try___str__():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    str_0 = try_0.__str__()
    assert(isinstance(str_0, str))


# Generated at 2022-06-25 23:57:35.699419
# Unit test for method map of class Try
def test_Try_map():
    @Try.of
    def func(a, b, c):
        return 10
    @Try.of
    def func_0(a, b, c, d):
        return 10

    @Try.of
    def call_func():
        return func(1, 2, 3)

    @Try.of
    def call_func_0():
        return func(1, 2, 3).map(lambda x: x)

    @Try.of
    def call_func_1():
        return func(1, 2, 3).map(lambda x: x.bit_length())

    @Try.of
    def call_func_2():
        return func_0(1, 2, 3)


# Generated at 2022-06-25 23:57:38.538399
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    str = try_0.get_or_else(1.0)
    assert str == bytes_0


# Generated at 2022-06-25 23:57:45.006981
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    bytes_1 = b'\x00\x01\x02\x03\x04\x05'
    bool_1 = False
    try_1 = Try(bytes_1, bool_1)
    int_0 = 42
    str_0 = 'woof'
    bytes_2 = b'\x00\x01\x04\x05\x06\x07\x08\t\n\x0c\r\x0e\x0f\x10\x11\x12\x13'
    bool_2 = False
    try_2 = Try(bytes_2, bool_2)

# Generated at 2022-06-25 23:57:55.322852
# Unit test for method map of class Try
def test_Try_map():
    def fn_0(x):
        assert x == 0
        return Try(0, True)
    def fn_1(x):
        assert x == 0
        return Try(0, False)
    def fn_2(x):
        return x + 2

    try_0 = Try(0, True)
    try_1 = try_0.map(fn_2)
    assert try_0.is_success == True
    assert try_1.value == 2
    assert try_1.is_success == True
    assert try_0.value == 0

    try_1 = Try(1, True)
    try_2 = try_1.map(fn_2)
    assert try_1.is_success == True
    assert try_2.value == 3
    assert try_2.is_success == True

# Generated at 2022-06-25 23:57:58.662800
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 0, 1).bind(lambda x: x + 1) == Try(1, True)
    assert Try.of(lambda: 0 / 0, 1).bind(lambda x: x + 1) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-25 23:58:19.358994
# Unit test for method map of class Try
def test_Try_map():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    def function_0(param_0):
        return param_0
    try_1 = try_0.map(function_0, )


# Generated at 2022-06-25 23:58:24.558310
# Unit test for method bind of class Try
def test_Try_bind():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    bytes_1 = b''
    try_1 = Try(bytes_1, bool_0)
    try_2 = try_0.bind(lambda _: try_1)
    assert try_2.value == bytes_1
    assert try_2.is_success


# Generated at 2022-06-25 23:58:31.053952
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert \
    Try(1, True)\
        .on_success(lambda x: print('success:', x))\
        .on_fail(lambda x: print('fail:', x))\
        .is_success == True
    assert \
    Try(1, False)\
        .on_success(lambda x: print('success:', x))\
        .on_fail(lambda x: print('fail:', x))\
        .is_success == False


# Generated at 2022-06-25 23:58:40.892002
# Unit test for method filter of class Try
def test_Try_filter():
    # Object case
    class MyObject:
        def __init__(self, value) -> None:
            self.value = value

    my_object = MyObject(1)
    try_0 = Try.of(lambda x: x, my_object)
    try_1 = try_0.filter(lambda x: x.value > 0)
    assert try_1 == Try(my_object, True)
    try_2 = try_0.filter(lambda x: x.value > 1)
    assert try_2 == Try(my_object, False)

    # Int case
    try_3 = Try(1, True)
    try_4 = try_3.filter(lambda x: x > 0)
    assert try_4 == Try(1, True)

# Generated at 2022-06-25 23:58:48.760646
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(None) == 'Try[value=None, is_success=True]'
    assert str(1) == 'Try[value=1, is_success=True]'
    assert str('') == 'Try[value=, is_success=True]'
    assert str(1.0) == 'Try[value=1.0, is_success=True]'
    assert str(()) == 'Try[value=(), is_success=True]'
    assert str([]) == 'Try[value=[], is_success=True]'
    assert str(dict()) == 'Try[value={}, is_success=True]'
    assert str(Exception()) == 'Try[value=Exception(), is_success=False]'
    assert str(True) == 'Try[value=True, is_success=True]'

# Generated at 2022-06-25 23:58:58.706040
# Unit test for method get of class Try
def test_Try_get():
    bytes_0 = b'\x00\x00'
    bytes_1 = b''
    bool_0 = True
    bool_1 = False
    try_0 = Try(bytes_0, bool_0)
    try_1 = Try(bytes_1, bool_0)
    try_2 = Try(bytes_0, bool_1)
    try_3 = Try(bytes_1, bool_1)
    assert try_0.get() == bytes_0
    assert try_1.get() == bytes_1
    assert try_2.get() == bytes_0
    assert try_3.get() == bytes_1


# Generated at 2022-06-25 23:59:05.324817
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fn_0(arg_0) -> bool:
        return True is arg_0

    def fn_1(arg_0) -> bool:
        return False is arg_0

    # fn_0 - this method will be call in success case
    # fn_1 - this method will be call in not success case
    _ = Try.of(fn_0, True).on_fail(fn_1)
    _ = Try.of(fn_1, True).on_fail(fn_1)

# Generated at 2022-06-25 23:59:13.526787
# Unit test for method bind of class Try
def test_Try_bind():
    method_names = [
        'test_case_0',
        'test_case_1',
        'test_case_2',
        'test_case_3'
    ]

    def test_case_0():
        def fn_p_b_0(b_1):
            bytes_0 = b_1
            bool_0 = True
            try_0 = Try(bytes_0, bool_0)
            return try_0
        bytes_0 = b''
        bool_0 = True
        try_0 = Try(bytes_0, bool_0)
        return_value_0 = try_0.bind(fn_p_b_0)
        assert isinstance(return_value_0, Try)


# Generated at 2022-06-25 23:59:20.755533
# Unit test for constructor of class Try
def test_Try():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    bool_1 = isinstance(try_0, Try)
    bool_var_0 = True
    bool_var_1 = True

    assert bool_1 == bool_var_0, 'AssertionError: {} != {}'.format(bool_1, bool_var_0)
    assert try_0.value == bytes_0, 'AssertionError: {} != {}'.format(try_0.value, bytes_0)
    assert try_0.is_success == bool_var_1, 'AssertionError: {} != {}'.format(try_0.is_success, bool_var_1)


# Generated at 2022-06-25 23:59:30.756040
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bytes_0 = b''
    bytes_1 = b'\x18\x9a\xce\xda\x0b\xc6\x8d'
    bytes_2 = b'\xaf\x8b\xe3\xdd'
    int_0 = 0
    bool_0 = True
    bool_1 = False
    try_0 = Try(bytes_0, bool_0)
    assert try_0 == try_0
    assert not (try_0 != try_0)
    try_1 = Try(bytes_1, bool_0)
    assert not (try_0 == try_1)
    try_2 = Try(bytes_2, bool_0)
    assert not (try_1 == try_2)
    try_3 = Try(bytes_1, bool_1)

# Generated at 2022-06-26 00:00:12.759605
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    bytes_1 = b''
    bool_1 = False
    try_1 = Try(bytes_1, bool_1)
    assert (try_0 == try_0)
    assert (not (try_0 == try_1))
    assert (not (try_1 == try_0))
    assert (try_1 == try_1)


# Generated at 2022-06-26 00:00:16.413089
# Unit test for method map of class Try
def test_Try_map():
    # case 0:
    bytes_0 = b''
    def fn_0(a: bytes) -> int:
        return int.from_bytes(a, 'big')
    try_0 = Try(bytes_0, True)
    try_0 = try_0.map(fn_0)
    assert try_0.value == 0


# Generated at 2022-06-26 00:00:25.362645
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(load_config, 'file_0.py')
    bools = [True, True, True, True, True, True]

    def filterer(arg_0):
        bools.pop()
        return True

    try_1 = try_0.filter(filterer)
    try_2 = Try.of(load_config, 'file_1.py')

    assert try_0.value == try_1.value
    assert bools == []


# Generated at 2022-06-26 00:00:28.354560
# Unit test for method get of class Try
def test_Try_get():
    bytes_0 = b'\x00\x00'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    assert try_0.get() == bytes_0


# Generated at 2022-06-26 00:00:38.337316
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    print('test_Try___eq__')
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    bytes_0 = b''
    bool_1 = True
    try_1 = Try(bytes_0, bool_1)
    bool_2 = try_0 == try_1
    assert bool_2 == True
    bytes_1 = b'\u0000'
    bool_1 = True
    try_1 = Try(bytes_1, bool_1)
    bool_2 = try_0 == try_1
    assert bool_2 == False
    bytes_1 = b''
    bool_1 = False
    try_1 = Try(bytes_1, bool_1)
    bool_2 = try_0 == try_1
    assert bool_2

# Generated at 2022-06-26 00:00:44.424373
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = True
    bytes_0 = b''
    try_0 = Try(bytes_0, bool_0)
    try_0.on_fail(FuncUtil.println)
    bool_0 = False
    bytes_0 = b''
    try_0 = Try(bytes_0, bool_0)
    try_0.on_fail(FuncUtil.println)
    bool_0 = True
    bytes_0 = b''
    try_0 = Try(bytes_0, bool_0)
    try_0.on_fail(FuncUtil.println)
    bool_0 = False
    bytes_0 = b'e'
    try_0 = Try(bytes_0, bool_0)
    try_0.on_fail(FuncUtil.println)

# Generated at 2022-06-26 00:00:53.476372
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)

# Generated at 2022-06-26 00:00:58.999498
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bytes_0 = b'1'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)

    bytes_1 = b'1'
    bool_1 = True
    try_1 = Try(bytes_1, bool_1)

    bytes_2 = b'2'
    bool_2 = False
    try_2 = Try(bytes_2, bool_2)

    assert try_0 == try_1
    assert not (try_0 == try_2)



# Generated at 2022-06-26 00:01:07.332602
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    str_0 = 'foo!bar'
    func_0 = lambda arg: arg + 'foo'
    try_1 = (lambda arg: Try.of(func_0, arg + 'bar'))(str_0)
    try_2 = try_1.on_fail(None)
    try_2.get()
    try_3 = Try(str_0, bool_0)
    try_4 = try_3.on_fail(lambda arg: print(arg + 'foo'))
    try_4.get()
    float_0 = float()
    try_5 = Try(float_0, bool_0)
    try_6 = try_5.on_fail(None)
   

# Generated at 2022-06-26 00:01:17.263387
# Unit test for method on_success of class Try
def test_Try_on_success():
    def call(string):
        string = string + '!'

    bytes_0 = b'\x0e\x14\x1c"&*\xe9\x01\x1d\xa8\x05\xc0\xaa\x14\x1b\xe7\x9b\xdf\xe6\x8c\xc7\xc3\x83\x89\x8d\xb1m\x81\x0c\x8a\xc7\xc1\x0c\xca'
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)

# Generated at 2022-06-26 00:02:34.869085
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True) == Try(True, True) == Try(1, 1)
    assert Try(1, 1) == Try(1, True) == Try(None, None)
    assert Try(1, 0) != Try(None, 1) != Try(1, None) != Try(1, True)
    assert Try(0, 1) != Try(True, True) != Try(True, 0) != Try(0, 0)


# Generated at 2022-06-26 00:02:46.053764
# Unit test for method get of class Try
def test_Try_get():
    bytes_0 = b''
    bool_0 = True
    try_0 = Try(bytes_0, bool_0)
    result_0 = try_0.get()
    assert result_0 == bytes_0
    assert result_0 is bytes_0
    bool_1 = False
    try_1 = Try(bytes_0, bool_1)
    result_1 = try_1.get()
    assert result_1 == bytes_0
    assert result_1 is bytes_0
    int_0 = -1
    bool_2 = True
    try_2 = Try(int_0, bool_2)
    result_2 = try_2.get()
    assert result_2 == int_0
    assert result_2 is int_0
    float_0 = -1.0
    bool_3 = False
   

# Generated at 2022-06-26 00:02:49.001285
# Unit test for constructor of class Try
def test_Try():
    try:
        test_case_0()
    except Exception as e:
        assert False, 'test_case_0() raised Exception'
    else:
        assert True, 'test_case_0() did not raise Exception'


# Generated at 2022-06-26 00:02:58.301448
# Unit test for method bind of class Try
def test_Try_bind():
    # Given
    bytes_0 = b'com.telegram.messages'
    bytes_1 = b'com.whatsapp.messages'
    bytes_2 = b'com.telegram.messages'
    def function_0(arg_0):
        try:
            arg_0.index(bytes_2)
            _ = arg_0.index(bytes_2)
            return Try(None, True)
        except ValueError:
            return Try(None, False)

    # When
    try_0 = Try(bytes_1, True)
    try_1 = Try(bytes_0, True)
    try_2 = try_0.bind(function_0)
    try_3 = try_1.bind(function_0)

    # Then
    assert not try_2.is_success