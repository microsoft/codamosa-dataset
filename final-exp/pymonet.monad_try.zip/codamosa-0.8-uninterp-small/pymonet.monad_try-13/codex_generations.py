

# Generated at 2022-06-25 23:53:09.277462
# Unit test for method filter of class Try
def test_Try_filter():
    """
        Test Try class filter method.
    """
    # prepare data
    value_0 = 3
    success_0 = True
    try_0 = Try(value_0, success_0)

    # check
    assert try_0.filter(lambda x: x > 5) == Try(value_0, False)
    assert try_0.filter(lambda x: x > 2) == Try(value_0, True)


# Generated at 2022-06-25 23:53:12.505290
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: x).is_success
    assert Try(True, True).filter(lambda x: not x).is_success == False
    assert Try(True, False).filter(lambda x: x).is_success == False



# Generated at 2022-06-25 23:53:17.694597
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(lambda x: x)
    try_2 = try_0.filter(lambda x: False)
    assert try_1 == Try(bool_0, True)
    assert try_2 == Try(bool_0, False)
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(lambda x: x)
    try_2 = try_0.filter(lambda x: False)
    assert try_1 == Try(bool_0, False)
    assert try_2 == Try(bool_0, False)



# Generated at 2022-06-25 23:53:28.874745
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(10, True)
    filterer_0 = lambda x: x % 2 == 0
    try_1 = try_0.filter(filterer_0)
    assert try_1.is_success == True
    assert try_1.value == 10
    try_0 = Try(10, True)
    try_1 = try_0.filter(lambda x: x % 2 != 0)
    assert try_1.is_success == False
    assert try_1.value == 10
    try_0 = Try(10, False)
    try_1 = try_0.filter(lambda x: x % 2 != 0)
    assert try_1.is_success == False
    assert try_1.value == 10


# Generated at 2022-06-25 23:53:35.199885
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda v: v).get()
    assert not Try(True, True).filter(lambda v: not v).is_success
    assert Try(False, False).filter(lambda v: v).is_success


# Generated at 2022-06-25 23:53:44.218869
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try.of(bool, bool_0)
    try_1 = try_0.filter(lambda v: True)
    try_2 = try_0.filter(lambda v: False)
    bool_1 = bool(bool_0)
    bool_2 = bool(bool_0)
    bool_3 = bool_1 == bool_2
    assert (bool_1 == try_1.value)
    assert (bool_2 == try_2.value)
    assert (bool_3 == try_1.is_success)

# Generated at 2022-06-25 23:53:53.100014
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_0_filter_0 = try_0.filter(lambda x: True)
    assert try_0_filter_0 == Try(True, True)
    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    try_1_filter_0 = try_1.filter(lambda x: False)
    assert try_1_filter_0 == Try(True, False)
    bool_2 = False
    try_2 = Try(bool_2, bool_2)
    try_2_filter_0 = try_2.filter(lambda x: False)
    assert try_2_filter_0 == Try(False, False)
    bool_3 = False

# Generated at 2022-06-25 23:53:59.073672
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test Try::filter() method
    """
    NOT_SUCCESS_MESSAGE = 'method filter of Try class should return Try without value. Expected {} but got {}'
    SUCCESS_MESSAGE = 'method filter of Try class should return Try with value. Expected {} but got {}'

    def filterer_0(x: int) -> bool:
        return x > 1

    value_0 = 3
    try_0 = Try(value_0, True)
    result_0 = try_0.filter(filterer_0)
    assert_true(result_0.is_success, SUCCESS_MESSAGE.format(value_0, result_0.get()))

# Generated at 2022-06-25 23:54:04.241277
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_monad(value):
        return value > 0

    def filter_monad2(value):
        return value > 5

    check_filter_0 = Try(10, True).filter(filter_monad).get() == 10
    check_filter_1 = Try(-1, True).filter(filter_monad).is_success is False
    check_filter_2 = Try(-1, True).filter(filter_monad2).is_success is False

    return check_filter_0 and check_filter_1 and check_filter_2



# Generated at 2022-06-25 23:54:14.313586
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 0
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_0_filter = try_0.filter(filterer)
    assert try_0_filter != None
    assert try_0_filter.value == bool_0
    assert try_0_filter.is_success == bool_0
    int_0 = 1
    try_1 = Try(int_0, True)
    try_1_filter = try_1.filter(filterer)
    assert try_1_filter != None
    assert try_1_filter.value == int_0
    assert try_1_filter.is_success == True
    def filterer(x):
        return x == 0
    int_0 = 0
    try_0

# Generated at 2022-06-25 23:54:25.515546
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    bool_2 = False
    try_2 = Try(bool_1, bool_2)
    assert try_0 == try_0
    assert not try_0 == try_1
    assert not try_0 == try_2
    assert not try_0 == 3
    assert not try_0 == None


# Generated at 2022-06-25 23:54:32.485873
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert_equal(
        True,
        Try.of(lambda: True, None)\
            .on_success(lambda x: assert_equal(x, True))\
            .is_success
    )

    assert_equal(
        False,
        Try.of(lambda: True, None)\
            .on_success(lambda x: assert_equal(x, False))\
            .is_success
    )



# Generated at 2022-06-25 23:54:41.113013
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = False
    try_0 = Try(bool_0, not bool_0)

# Generated at 2022-06-25 23:54:51.428939
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    impure_count = 0
    success_test_callback = lambda x: None

# Generated at 2022-06-25 23:54:52.902380
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Test 0
    test_Try___eq___0()



# Generated at 2022-06-25 23:54:56.426990
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    str_0 = str(try_0)
    assert str_0 == 'Try[value=False, is_success=False]'


# Generated at 2022-06-25 23:55:09.733572
# Unit test for method bind of class Try
def test_Try_bind():
    def assert_bind(test_input, expected_output_value, expected_output_success, bind_fn):
        test_try = Try(test_input, True)
        result_bind = test_try.bind(bind_fn)
        assert result_bind.value == expected_output_value, "in test_Try_bind: expected value - {}, found value - {}"\
            .format(result_bind.value, expected_output_value)
        assert result_bind.is_success == expected_output_success, "in test_Try_bind: expected success - {},"\
            "found success - {}".format(result_bind.is_success, expected_output_success)

    def bind_fn_0(input_value):
        return Try(input_value, False)


# Generated at 2022-06-25 23:55:15.503259
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try_0 = Try(True, True)
    func_0 = lambda e : print(e)
    try_0.on_fail(func_0) # when success_call_back not call

    try_1 = Try(True, False)
    def func_1(e):
        assert e == True
    try_1.on_fail(func_1) # when success_call_back is call and assert True is present in function


# Generated at 2022-06-25 23:55:19.826091
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(lambda: 1, None)) == 'Try[value=1, is_success=True]'
    assert str(Try.of(lambda: 1 / 0, None)) == 'Try[value=division by zero, is_success=False]'


# Generated at 2022-06-25 23:55:22.952102
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.value == bool_0
    assert try_0.is_success == bool_0


# Generated at 2022-06-25 23:55:34.263767
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = True
    bool_1 = False
    bool_2 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_1)
    try_2 = Try(bool_2, bool_2)
    try_0.get_or_else(bool_1)
    try_1.get_or_else(bool_2)
    try_2.get_or_else(bool_0)
    try_1.get_or_else(bool_0)


# Generated at 2022-06-25 23:55:39.840495
# Unit test for method map of class Try
def test_Try_map():
    def mapper(value):
        return not value

    try_0 = Try(False, True)
    try_1 = try_0.map(mapper)
    try_2 = try_1.map(mapper)
    assert_equals(try_2.value, False)
    assert_equals(try_2.is_success, True)

    try_3 = Try(False, False)
    try_4 = try_3.map(mapper)
    assert_equals(try_4.value, False)
    assert_equals(try_4.is_success, False)



# Generated at 2022-06-25 23:55:42.667308
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-25 23:55:51.111378
# Unit test for method map of class Try
def test_Try_map():
    # Given
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, not bool_0)
    mapper = lambda value: not value

    # When
    try_0_mapped = try_0.map(mapper)
    try_1_mapped = try_1.map(mapper)

    # Then
    assert try_0_mapped == try_0
    assert try_1_mapped != try_1
    assert try_1_mapped.value == True


# Generated at 2022-06-25 23:55:55.313999
# Unit test for method map of class Try
def test_Try_map():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    def not_bool(value):
        return not value

    try_1 = try_0.map(not_bool)

    assert try_1 == Try(False, True)


# Generated at 2022-06-25 23:56:02.404455
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = True
    def f_0(b):
        return bool_0 and b
    def f_1(b):
        bool_0 = False
        return bool_0 and b
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(f_1, f_0(bool_0))
    bool_1 = not bool_0
    try_2 = try_1.on_fail(f_0)
    bool_2 = bool_0 and bool_1
    assert_equal(bool_2, bool_0, 'assert_equal failed on line 48')


# Generated at 2022-06-25 23:56:10.606980
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    map_callback_0 = (lambda e: e)
    try_1 = try_0.on_fail(map_callback_0)
    bool_1 = try_1.is_success
    bool_2 = try_0.is_success
    assert (bool_0 == bool_1)
    assert (bool_2 == bool_1)
    bool_0 = False
    bool_1 = bool_1 == bool_0
    assert (bool_0 == bool_1)


# Generated at 2022-06-25 23:56:14.110123
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_0 = Try.of(lambda x: x + 2, 2)
    try_0.on_success(
        lambda value: print("Value {} is successfully".format(value)))


# Generated at 2022-06-25 23:56:22.416030
# Unit test for method filter of class Try
def test_Try_filter():
    # Test case 0
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(lambda bool_: True)
    assert not try_0.is_success
    assert try_1.is_success
    assert bool_0 == try_1.get()

    # Test case 1
    bool_1 = True
    try_2 = Try(bool_1, bool_1)
    try_3 = try_2.filter(lambda bool_: not bool_)
    assert not try_3.is_success
    assert bool_1 == try_3.get()

# Generated at 2022-06-25 23:56:28.268719
# Unit test for constructor of class Try
def test_Try():
    # Initialize some arguments
    foo = "foo"
    bool_false = False
    bool_true = True
    try_false = Try(foo, bool_false)
    try_true = Try(foo, bool_true)
    # Test for initial values
    assert try_false.value == foo
    assert try_false.is_success == bool_false
    assert try_true.value == foo
    assert try_true.is_success == bool_true


# Generated at 2022-06-25 23:56:39.825948
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test that method get_or_else returns default value when Try is not successfully
    and or returns Try's value when Try is successfully.
    """
    default_value = 'default'
    value = 'value'
    try_0 = Try(value, True)
    try_1 = Try(value, False)
    assert try_0.get_or_else(default_value) == value
    assert try_1.get_or_else(default_value) == default_value


# Generated at 2022-06-25 23:56:44.623821
# Unit test for method bind of class Try
def test_Try_bind():
    try_0 = Try.of(lambda: True)
    assert try_0.bind(lambda v: Try(v, True)) == Try(True, True)
    assert try_0.bind(lambda v: Try(v, False)) == Try(True, True)
    assert try_0.bind(lambda v: Try(True, False)) == Try(True, True)


# Generated at 2022-06-25 23:56:50.115954
# Unit test for constructor of class Try
def test_Try():
    try_0 = Try(False, False)
    assert isinstance(try_0, Try)
    assert try_0.get() == False
    assert try_0.is_success == False
    assert try_0.get_or_else('else') == 'else'
    assert try_0 == Try(False, False)
    assert try_0 != Try(False, True)
    assert try_0 != Try(True, False)
    assert try_0 != Try(True, True)


# Generated at 2022-06-25 23:56:56.319011
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)

    def test_case_1():
        bool_0 = False
        try_0 = Try(bool_0, bool_0)
        try_0.bind(test_case_1)

    test_case_1()



# Generated at 2022-06-25 23:57:00.006204
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert str(try_0) == 'Try[value={}, is_success={}]'.format(bool_0, bool_0)



# Generated at 2022-06-25 23:57:03.211732
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    def success_callback(value):
        return value
    try_0.on_success(success_callback)


# Generated at 2022-06-25 23:57:09.943165
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try('value', True)
    try_1 = Try('value', True)
    assert try_0 == try_1

    try_1 = Try(1, True)
    try_1 = Try(2, True)
    assert not try_0 == try_1

    try_0 = Try('value', False)
    try_1 = Try('value', True)
    assert not try_0 == try_1


# Generated at 2022-06-25 23:57:19.535742
# Unit test for method bind of class Try
def test_Try_bind():
    def test_case_0():
        bool_0 = False
        try_0 = Try(bool_0, bool_0)
        assert try_0.bind(lambda x: Try(not x, not x)).get() == bool_0

    def test_case_1():
        value_0 = "value_0"
        try_0 = Try(value_0, True)
        assert try_0.bind(lambda x: Try(x[::-1], x[::-1])) == Try(value_0[::-1], value_0[::-1])

    def test_case_2():
        try_0 = Try(Exception("Exception"), False)
        assert try_0.bind(lambda x: Try(bool(x), bool(x))) == try_0

    def test_case_3():
        try_

# Generated at 2022-06-25 23:57:22.997431
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    _try = Try(1, True)
    assert _try == Try(1, True)
    assert _try != Try(2, True)
    assert _try != Try(1, False)
    assert _try != Try(2, False)


# Generated at 2022-06-25 23:57:33.062737
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    from pytest import approx
    from dataclasses import dataclass

    @dataclass
    class User:
        age: int
        name: str

    user = User(10, 'John')

    def map_user_age(user, mapper):
        return user.map(lambda u: u.age * mapper)

    def get_user_name(user):
        return user.map(lambda u: u.name)

    def get_user_age(user):
        return user.map(lambda u: u.age)

    def parse_user(user_string):
        return Try.of(lambda: json.loads(user_string), user_string)

    def parse_user_age(user_string):
        return parse_user(user_string).map(lambda u: u['age'])


# Generated at 2022-06-25 23:57:41.876706
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(None, False).get_or_else(True) is True
    assert Try(None, True).get_or_else(True) is None


# Generated at 2022-06-25 23:57:47.232238
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_0 = Try(True, True)
    assert try_0.on_success(lambda x: print('Success')).is_success == True
    assert try_0.on_success(lambda x: print('Fail')).is_success == True
    assert try_0.on_success(lambda x: print('Success')).get() == True
    assert try_0.on_success(lambda x: print('Fail')).get() == True


# Generated at 2022-06-25 23:57:52.124229
# Unit test for method __str__ of class Try
def test_Try___str__():
    #  A test for method __str__ of class Try
    # Create an instance of Try
    try_0 = Try(False, False)

    # Check that method __str__ returns expected value
    assert(str(try_0) == 'Try[value=False, is_success=False]')


# Generated at 2022-06-25 23:57:54.927088
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(5, True)\
        .bind(lambda x: Try(x + 10, True))\
        .bind(lambda x: Try(x * 3, True)) == Try(45, True)



# Generated at 2022-06-25 23:57:57.855578
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try(False, False)
    try_1 = Try(False, False)
    try_2 = Try(False, True)
    assert try_0 == try_1
    assert try_0 != try_2


# Generated at 2022-06-25 23:58:05.186808
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # check state of equality
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0 == try_0, "Two objects are exactly the same!"
    assert try_0 != 5, "5 and 2 are different kinds of objects!"
    try_1 = Try(bool_0, bool_0)
    try_2 = Try(bool_0, bool_1)
    try_3 = Try(bool_1, bool_0)
    try_4 = Try(bool_1, bool_1)
    try_5 = Try(bool_1, bool_1)
    assert try_1 == try_1, "Two objects are exactly the same!"
    assert try_2 == try_2, "Two objects are exactly the same!"

# Generated at 2022-06-25 23:58:08.565059
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0)
    try_0 == try_1


# Generated at 2022-06-25 23:58:19.939761
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try(5, True).get() == 5
    assert Try(5, False).get() == 5
    assert Try(None, True).get() is None
    assert Try(None, False).get() is None
    assert Try("", True).get() == ""
    assert Try("", False).get() == ""
    assert Try("", True).get() == ""
    assert Try("", False).get() == ""
    assert Try(False, True).get() == False
    assert Try(False, False).get() == False
    assert Try(True, True).get() == True
    assert Try(True, False).get() == True
    assert Try(1.0, True).get() == 1.0

# Generated at 2022-06-25 23:58:21.427107
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_0 = Try(0, True)
    try_0.get_or_else(1) == 0
    try_1 = Try(1, False)
    try_1.get_or_else(0) == 0


# Generated at 2022-06-25 23:58:22.729418
# Unit test for constructor of class Try
def test_Try():
    try_0 = Try(True, True)
    assert try_0 is not None


# Generated at 2022-06-25 23:58:39.860008
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    bool_1 = try_0.get_or_else(True)
    assert bool_1 is True



# Generated at 2022-06-25 23:58:46.704580
# Unit test for method bind of class Try
def test_Try_bind():
    add_one = lambda x: x + 1
    succ = Try.of(add_one, 0)
    fail = Try.of(add_one, 'a')
    try_0 = succ.bind(lambda x: Try.of(add_one, x))
    try_1 = fail.bind(lambda x: Try.of(add_one, x))
    assert try_0.is_success == True
    assert try_1.is_success == False
    assert try_0.value == 1
    assert try_1.value == "unsupported operand type(s) for +: 'int' and 'str'"


# Generated at 2022-06-25 23:58:51.114129
# Unit test for method get of class Try
def test_Try_get():
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_1)
    assert try_0.get() is bool_0
    assert try_1.get() is bool_1


# Generated at 2022-06-25 23:59:02.097293
# Unit test for method get of class Try
def test_Try_get():
    def test_0():
        assert Try(True, True).get()

    def test_1():
        assert not Try(True, False).get()

    def test_2():
        assert Try(1, True).get() == 1

    def test_3():
        assert Try(1, False).get() == 1

    def test_4():
        assert Try("value", True).get() == "value"

    def test_5():
        assert Try("value", False).get() == "value"

    def test_6():
        assert Try((1, True), True).get() == (1, True)

    def test_7():
        assert Try((1, True), False).get() == (1, True)

    test_0()
    test_1()
    test_2()
    test_3()
    test

# Generated at 2022-06-25 23:59:05.528360
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0 == Try(bool_0, bool_0)


# Generated at 2022-06-25 23:59:08.730091
# Unit test for method get of class Try
def test_Try_get():
    assert Try(True, True).get() == True
    assert Try(False, False).get() == False
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.get() == bool_0


# Generated at 2022-06-25 23:59:11.195771
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(12, True)) == 'Try[value=12, is_success=True]'
    assert str(Try(Exception(), False)) == 'Try[value=Exception(), is_success=False]'


# Generated at 2022-06-25 23:59:15.304594
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Case 0.1
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, bool_0)

# Generated at 2022-06-25 23:59:19.492681
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # GIVEN
    a_try = Try(1, True)

    # WHEN
    actually = a_try.get_or_else(5)

    # THEN
    assert actually == 1

    # WHEN
    a_try = Try(None, False)

    # THEN
    assert a_try.get_or_else(5) == 5


# Generated at 2022-06-25 23:59:24.087966
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert(str(try_0) == 'Try[value=False, is_success=False]')

    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    assert(str(try_1) == 'Try[value=True, is_success=True]')


# Generated at 2022-06-25 23:59:56.756835
# Unit test for method on_fail of class Try

# Generated at 2022-06-26 00:00:00.352895
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try.of(lambda: Try(1, True))
    try_0 = try_0.bind(lambda value: try_1)
    assert try_1 == try_0



# Generated at 2022-06-26 00:00:11.971257
# Unit test for constructor of class Try
def test_Try():
    print('test_Try')
    bool_0: bool = False
    bool_1: bool = True
    str_0: str = 'this is string'
    str_1: str = 'this is string'
    str_2: str = 'another string'
    num_0: int = 0
    num_1: int = 1
    bool_fn: Callable = lambda bool: bool
    str_fn: Callable = lambda str: str
    num_fn: Callable = lambda num: num
    bool_mapper: Callable = lambda bool: bool
    str_mapper: Callable = lambda str: str
    num_mapper: Callable = lambda num: num
    bool_binder: Callable = lambda bool: Try(bool, bool)

# Generated at 2022-06-26 00:00:13.539255
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'



# Generated at 2022-06-26 00:00:19.729185
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_1 = try_0.get_or_else(None)
    assert bool_1
    bool_2 = False
    try_1 = Try(bool_2, bool_2)
    bool_3 = try_1.get_or_else(True)
    assert bool_3


# Generated at 2022-06-26 00:00:26.278893
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_1 = Try(True, True)  # True
    bool_0 = Try(False, True)  # False
    print(bool_1.get_or_else(False))  # True
    print(bool_0.get_or_else(True))  # False
    bool_0 = Try(True, False)
    print(bool_0.get_or_else(True))  # True


# Generated at 2022-06-26 00:00:28.762370
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert str(try_0) == 'Try[value=True, is_success=True]'


# Generated at 2022-06-26 00:00:38.713915
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = False
    class_type_0 = Try(bool_0, bool_0)
    class_type_1 = Try(bool_0, bool_0)
    assert class_type_0 == class_type_1

    bool_1 = False
    class_type_2 = Try(bool_1, bool_1)
    class_type_3 = Try(bool_1, bool_1)
    assert class_type_2 == class_type_3

    bool_0 = False
    bool_1 = False
    class_type_4 = Try(bool_0, bool_0)
    class_type_5 = Try(bool_1, bool_1)
    assert class_type_4 != class_type_5

    bool_0 = False
    bool_1 = False

# Generated at 2022-06-26 00:00:44.465477
# Unit test for method map of class Try
def test_Try_map():
    bool_0 = False
    def fn_0():
        return True
    def mapper_0(param_0):
        return param_0
    def mapper_1(param_0):
        return param_0
    try_0 = Try(fn_0(), bool_0)
    try_1 = try_0.map(mapper_0)
    assert isinstance(try_1, Try)
    assert try_1.value == bool_0
    assert try_1.is_success == bool_0
    try_2 = try_1.map(mapper_1)
    assert isinstance(try_2, Try)
    assert try_2.value == bool_0
    assert try_2.is_success == bool_0


# Generated at 2022-06-26 00:00:53.521344
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = True
    bool_1 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_0)
    try_2 = Try(bool_1, bool_1)
    try_3 = Try(bool_0, bool_1)

    assert try_0.bind(lambda x: Try(x, x)) == try_0
    assert try_1.bind(lambda x: Try(x, x)) == try_1
    assert try_2.bind(lambda x: Try(x, x)) == try_2
    assert try_3.bind(lambda x: Try(x, x)) == try_3

    def func_0():
        raise ValueError('Test')
    def func_1(value):
        return Try(value, True)


# Generated at 2022-06-26 00:02:02.690445
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = False
    bool_1 = True

    # Try[False, False]
    try_0 = Try(bool_0, bool_0)
    def f_0(arg_0):
        return Try(arg_0, True)
    assert try_0.bind(f_0) == Try(bool_0, bool_0)

    # Try[True, True]
    try_1 = Try(bool_1, bool_1)
    assert try_1.bind(f_0) == Try(bool_1, bool_1)


# Generated at 2022-06-26 00:02:09.464436
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer (value):
        return not value

    test_cases = [
        {'name': 'case 0', 'filterer': filterer, 'value': True},
        {'name': 'case 1', 'filterer': filterer, 'value': False}
    ]

    for case in test_cases:
        with pytest.raises(AssertionError):
            try_0: Try[bool] = Try(case['value'], True)
            try_1: Try[bool] = try_0.filter(case['filterer'])
            assert case['value'] == try_1.value


# Generated at 2022-06-26 00:02:12.992557
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == "Try[value=1, is_success=True]"
    assert str(Try(1, False)) == "Try[value=1, is_success=False]"
    assert str(Try(None, False)) == "Try[value=None, is_success=False]"


# Generated at 2022-06-26 00:02:15.263604
# Unit test for method get of class Try
def test_Try_get():
    expected_value = 1
    try_0 = Try(expected_value, True)
    actual_value = try_0.get()

    assert expected_value == actual_value


# Generated at 2022-06-26 00:02:17.244865
# Unit test for method on_success of class Try
def test_Try_on_success():
    test_value = 'test_value'
    success_callback = lambda x: print('value is {0}'.format(x))
    try_0 = Try(test_value, True)
    try_1 = try_0.on_success(success_callback)


# Generated at 2022-06-26 00:02:21.213788
# Unit test for method map of class Try
def test_Try_map():
    # Test for successfully monad
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)

    # Test for not successfully monad
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)



# Generated at 2022-06-26 00:02:25.087811
# Unit test for method filter of class Try
def test_Try_filter():
    def assert_filter(bool_0, bool_1):
        try_0 = Try(bool_0, bool_0)
        assert try_0.filter(lambda v: v) == Try(bool_0, bool_1)

    assert_filter(True, True)
    assert_filter(False, False)


# Generated at 2022-06-26 00:02:32.012796
# Unit test for method on_success of class Try
def test_Try_on_success():
    l = list()

    def success_callback(a):
        l.append(a)

    def fail_callback(a):
        l.append(a)

    try_0 = Try.of(lambda: True)
    try_1 = Try.of(lambda: True)
    try_2 = Try.of(lambda: True)
    try_3 = Try.of(lambda: True)

    try_0.on_success(success_callback)
    try_1.on_fail(fail_callback)
    try_2.on_success(success_callback)
    try_3.on_fail(fail_callback)

    assert l == [True, True]



# Generated at 2022-06-26 00:02:39.786132
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda a: a % 2 == 0) == Try(5, False)
    assert Try(4, True).filter(lambda a: a % 2 == 0) == Try(4, True)
    assert Try(5, False).filter(lambda a: a % 2 == 0) == Try(5, False)
    assert Try(Exception(), False).filter(lambda a: a % 2 == 0) == Try(Exception(), False)


# Generated at 2022-06-26 00:02:42.224521
# Unit test for method get of class Try
def test_Try_get():
    x = Try(20, True)
    y = Try(None, False)
    assert(x.get() == 20)
    assert(y.get() == None)

