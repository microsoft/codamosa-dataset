

# Generated at 2022-06-25 23:53:05.016418
# Unit test for method filter of class Try
def test_Try_filter():
    success_0 = Try('Success', True)
    result_0 = success_0.filter(lambda arg_0: arg_0 == 'Success')

    failure_0 = Try('Failure', False)
    result_1 = failure_0.filter(lambda arg_0: arg_0 == 'Failure')

    b_0 = True
    b_1 = True
    assert result_0 == Try('Success', b_0)
    assert result_1 == Try('Failure', b_1)


# Generated at 2022-06-25 23:53:14.082265
# Unit test for method filter of class Try
def test_Try_filter():
    def test_return_copy_of_monad():
        bool_0 = True
        try_0 = Try(bool_0, bool_0).filter(lambda bool_value: bool_value)
        # bool-0 ? bool-0
        assert try_0.value == bool_0

    def test_return_not_success_copy_of_monad():
        bool_0 = False
        try_0 = Try(bool_0, not bool_0).filter(lambda bool_value: bool_value)
        # bool-0 ? bool-0
        assert try_0.value == bool_0

    test_return_copy_of_monad()
    test_return_not_success_copy_of_monad()


# Generated at 2022-06-25 23:53:25.083210
# Unit test for method filter of class Try
def test_Try_filter():
    a = Try("4", True)
    b = Try("4", True)
    c = Try("a", True)
    d = Try("4", False)
    e = Try("a", True).filter(lambda str_: str_.isdigit())
    f = Try("4", True).filter(lambda str_: str_.isdigit())
    g = Try("a", True).filter(lambda str_: str_.isalpha())
    h = Try("a", False).filter(lambda str_: str_.isalpha())
    assert e == Try("a", False)
    assert f == Try("4", True)
    assert g == Try("a", True)
    assert h == Try("a", False)
    print("Test method filter of class Try passed")


# Generated at 2022-06-25 23:53:29.123060
# Unit test for method filter of class Try
def test_Try_filter():
    def apply(x: int)-> bool:
        return x > 5

    try_0 = Try(1, True)
    try_1 = try_0.filter(apply)

    result = isinstance(try_0, Try) and isinstance(
        try_1, Try) and try_0.is_success and not(try_1.is_success) and try_0.value == 1 and try_1.value == 1
    assert result


# Generated at 2022-06-25 23:53:36.548513
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    bool_2 = False
    try_0 = Try(1, bool_0)
    try_1 = try_0.filter(lambda x: x != 1)
    try_2 = try_1.filter(lambda x: bool_2)
    try_3 = Try(1, bool_2).filter(lambda x: bool_0)
    assert try_0.value == try_1.value
    assert try_1.value == try_2.value
    assert try_0.value != try_2.value
    assert try_2.value == try_3.value


# Generated at 2022-06-25 23:53:43.516775
# Unit test for method filter of class Try
def test_Try_filter():
    test_0 = Try(True, True)
    assert test_0.filter(lambda val: val == True) == test_0,\
        'Filter must return current Try if filterer returns True'
    assert test_0.filter(lambda val: val == False) == Try(True, False)\
        and not test_0.filter(lambda val: val == False).is_success,\
        'Filter must returns not successfully Try if filterer returns False'


# Generated at 2022-06-25 23:53:50.066694
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(lambda b: True)

    bool_1 = True
    try_2 = Try(bool_1, bool_1).filter(lambda b: True)
    try_3 = Try(bool_1, bool_1).filter(lambda b: False)


# Generated at 2022-06-25 23:54:01.827955
# Unit test for method filter of class Try
def test_Try_filter():
    fn_1 = lambda x: x
    try_1 = Try.of(fn_1)
    try_1_1 = try_1.filter(lambda x: True)
    bool_0 = try_1_1.is_success
    val_0 = try_1_1.value
    bool_1 = False
    try_1_2 = try_1.filter(lambda x: False)
    bool_2 = try_1_2.is_success
    val_1 = try_1_2.value
    try_2 = Try(Exception(), False)
    try_2_1 = try_2.filter(lambda x: True)
    bool_3 = try_2_1.is_success
    val_2 = try_2_1.value


# Generated at 2022-06-25 23:54:12.409817
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 5

    def fail_filterer(x):
        return x < 5

    def get_10():
        return 10

    def get_0():
        return 0

    try_0 = Try.of(get_10)
    try_1 = Try.of(get_0)
    filtered_try_0 = try_0.filter(filterer)
    filtered_try_1 = try_1.filter(filterer)
    fail_filtered_try_0 = try_0.filter(fail_filterer)
    fail_filtered_try_1 = try_1.filter(fail_filterer)



# Generated at 2022-06-25 23:54:22.912314
# Unit test for method filter of class Try
def test_Try_filter():
    test_input_1 = True
    test_input_2 = False
    test_input_3 = True
    test_input_4 = False
    test_input_5 = True
    test_input_6 = False
    test_input_7 = True
    test_input_8 = False
    test_input_9 = True
    test_input_10 = False

    _int_0 = Try(test_input_1, test_input_1).filter(lambda x: x)
    print("- Filter test _int_0: " + str(_int_0.__str__()))
    assert (_int_0.__eq__(Try((True), True)))
    test_input_1 = True
    test_input_2 = False

# Generated at 2022-06-25 23:54:26.425953
# Unit test for method __str__ of class Try
def test_Try___str__():
    # TODO write test
    pass


# Generated at 2022-06-25 23:54:31.662948
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try.of(int, '42') == Try.of(int, '42')
    assert Try.of(int, '42') != Try.of(int, '43')
    assert not Try.of(int, '42') == Try.of(int, '43')


# Generated at 2022-06-25 23:54:35.230561
# Unit test for method map of class Try
def test_Try_map():
    try_0 = Try.of(lambda : var_0(bool_0),)
    try_1 = try_0.map(lambda bool_value: bool_value)
    assert isinstance(try_1, Try)
    assert try_1.value == False



# Generated at 2022-06-25 23:54:40.514876
# Unit test for constructor of class Try
def test_Try():
    # Setup
    bool_0 = False
    # Assert
    assert Try.of(int, '10') == Try(10, True)
    assert Try.of(int, 'a') == Try(ValueError("invalid literal for int() with base 10: 'a'"), False)


# Generated at 2022-06-25 23:54:44.091355
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('value', True)) == 'Try[value=value, is_success=True]'
    assert str(Try(5, False)) == 'Try[value=5, is_success=False]'


# Generated at 2022-06-25 23:54:49.951496
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try(None, False)
    assertTrue(Try(None, False) == try_0)
    assertTrue(not Try(None, True) == try_0)
    assertTrue(not Try(None, False) == Try(None, True))
    try_1 = Try(None, True)
    assertTrue(not try_0 == try_1)
    assertTrue(try_1 == try_1)


# Generated at 2022-06-25 23:54:51.044999
# Unit test for method __str__ of class Try
def test_Try___str__():
    pass



# Generated at 2022-06-25 23:55:02.596028
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # variables with example values,
    # you can change values and add new variables with different values
    # to check if everything is ok
    bool_0 = False
    str_0 = 'abc'
    int_0 = 1
    float_0 = 0.1
    list_0 = [bool_0, str_0, int_0, float_0]
    # run test
    try_0 = Try(list_0, True)
    try_1 = Try(list_0, True)
    try_2 = Try(list_0, False)
    try_3 = Try(list_0, False)
    assert try_0 == try_1
    assert not (try_0 == try_2)
    assert try_2 == try_3
    # if test was failed
    # AssertionError will be raised
    #

# Generated at 2022-06-25 23:55:12.675801
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = False
    var_0 = lambda bool_value: bool_value
    var_1 = Try.of(lambda: 2 + 2)
    var_2 = var_1.bind(lambda int_value: Try(int_value, var_0(int_value == 4)))
    if var_0(var_2.is_success) and var_0(var_2.value == 4):
        var_3 = var_1.bind(lambda int_value: Try(int_value, var_0(int_value != 4)))
        if var_0(not var_3.is_success) and var_0(var_3.value == 4):
            bool_0 = True
    return bool_0


# Generated at 2022-06-25 23:55:19.703966
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Test case False
    bool_0 = False
    var_0 = lambda bool_value: bool_value
    try_0 = Try(var_0(bool_0), True)
    assert try_0.get_or_else(2) is True
    # Test case True
    var_1 = lambda bool_value: bool_value
    try_1 = Try(var_1(bool_0), False)
    assert try_1.get_or_else(2) is 2



# Generated at 2022-06-25 23:55:31.604502
# Unit test for method bind of class Try
def test_Try_bind():

    def f(x):
        return Try(x, True)

    def g(y):
        return Try(y, False)

    def get_value(x):
        return Try(x.value, True)
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.bind(f)
    try_2 = try_1.bind(g)
    try_3 = try_2.bind(get_value)
    value_3 = try_3.value
    assert value_3 == bool_0


# Generated at 2022-06-25 23:55:35.230597
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_0 = try_0.filter(lambda x: bool_0)
    assert try_0 == Try(bool_0, bool_0)


# Generated at 2022-06-25 23:55:39.654272
# Unit test for constructor of class Try
def test_Try():
    try_1 = Try(True, True)
    assert try_1.value == True and try_1.is_success == True
    try_2 = Try('a', False)
    assert try_2.value == 'a' and try_2.is_success == False
    bool_0 = True
    try_3 = Try(bool_0, bool_0)
    assert try_3.value == True and try_3.is_success == True


# Generated at 2022-06-25 23:55:48.430378
# Unit test for method get of class Try
def test_Try_get():
    # test case
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    result = try_0.get()
    expected = bool_0
    # check test case
    assert result is expected, "error on test_Try_get"
    # test case
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    result = try_0.get()
    expected = bool_0
    # check test case
    assert result is expected, "error on test_Try_get"


# Generated at 2022-06-25 23:55:52.156793
# Unit test for method get of class Try
def test_Try_get():
    def get_0(a):
        return Try(a, True).get()

    def get_1(a):
        return Try(a, False).get()

    assert get_0(True)
    assert not get_1(True)


# Generated at 2022-06-25 23:55:55.621758
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.value is True
    assert try_0.is_success is True


# Generated at 2022-06-25 23:55:58.509935
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 3/2).get_or_else(0) == 1.5
    assert Try.of(lambda: 3/0).get_or_else(0) == 0


# Generated at 2022-06-25 23:56:01.643062
# Unit test for constructor of class Try
def test_Try():
    assert Try(True, True) == Try(True, True)
    assert Try(True, False) != Try(False, False)
    assert Try(True, True) != Try(True, False)
    assert Try(False, True) != Try(False, False)


# Generated at 2022-06-25 23:56:05.058015
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try:
        str_0 = try_0.__str__()
    except Exception as e:
        print("Exception: {}".format(e))
    else:
        assert str_0 == 'Try[value=True, is_success=True]'



# Generated at 2022-06-25 23:56:10.997259
# Unit test for method map of class Try
def test_Try_map():
    """
    Map is a method of class Try
    """
    # Given
    try_0 = Try(3, True)
    def fn_0(x): return x * 2
    # When
    try_1 = try_0.map(fn_0)
    # Then
    bool_0 = 6
    bool_1 = try_1.value == bool_0
    assert bool_1



# Generated at 2022-06-25 23:56:20.346141
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = True
    str_0 = 'F'
    str_1 = 'T'
    def lambda_0():
        return str_0
    def lambda_1():
        return str_1
    try_0 = Try.of(lambda_0)
    try_1 = Try.of(lambda_1)
    try_2 = try_0.bind(lambda x: try_1)


# Generated at 2022-06-25 23:56:21.358359
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        pass

    Try(True, True).on_success(success_callback)



# Generated at 2022-06-25 23:56:24.006154
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_1 = Try(1, True)
    assert try_1.get_or_else(0) == 1

    try_2 = Try(1, False)
    assert try_2.get_or_else(0) == 0


# Generated at 2022-06-25 23:56:30.084820
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    test_cases = [
        {'value': True, 'is_success': True, 'default_value': False, 'expected': True},
        {'value': True, 'is_success': False, 'default_value': False, 'expected': False},
    ]

    for case in test_cases:
        try_ = Try(case['value'], case['is_success'])
        result = try_.get_or_else(case['default_value'])
        assert case['expected'] == result



# Generated at 2022-06-25 23:56:34.273580
# Unit test for method get of class Try
def test_Try_get():
    assert Try(3, True).get() == 3
    assert Try(3, False).get() == 3
    assert Try(3, True).get() == 3
    assert Try(3, True).get() != False
    assert Try(4, False).get() == 4
    assert Try(4, True).get() == 4


# Generated at 2022-06-25 23:56:45.593260
# Unit test for method bind of class Try
def test_Try_bind():
    def check_success(e):
        try:
            True
        except Exception as e:
            return False
        return True

    def check_fail(e):
        try:
            raise Exception('error!')
        except Exception as e:
            return True
        return False

    success_full = lambda x: Try(x, True)
    success_empty = lambda x: Try(None, True)

    fail_full = lambda x: Try(x, False)
    fail_empty = lambda x: Try(None, False)


# Generated at 2022-06-25 23:56:46.743769
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    str_0 = try_0.__str__()


# Generated at 2022-06-25 23:56:49.132909
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.is_success == bool_0
    assert try_0.value == bool_0

# Generated at 2022-06-25 23:57:00.799974
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(True, True) == Try(True, True)
    assert Try(False, False) == Try(False, False)
    assert Try(False, True) == Try(False, True)
    assert Try(5, True) == Try(5, True)
    assert Try(5.5, True) == Try(5.5, True)
    assert Try("", True) == Try("", True)
    assert Try([], True) == Try([], True)
    assert Try(None, True) == Try(None, True)
    assert Try((1,2), True) == Try((1,2), True)
    assert Try(Exception(), False) == Try(Exception(), False)
    assert Try([], True) != Try([5], True)



# Generated at 2022-06-25 23:57:04.901255
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(True, True) == Try(True, True)
    assert Try(True, False) == Try(True, False)

    assert Try(True, True) != Try(True, False)
    assert Try(True, False) != Try(True, True)


# Generated at 2022-06-25 23:57:14.520686
# Unit test for method bind of class Try
def test_Try_bind():
    assert bind_test_0()
    assert bind_test_1()
    assert bind_test_2()


# Generated at 2022-06-25 23:57:21.674435
# Unit test for method bind of class Try
def test_Try_bind():
    def mapper(value):
        return value

    def binder(value):
        return Try(value + 1, value % 2 == 0)

    def filterer(value):
        return value % 2 == 0

    def success_callback(value):
        print(value)

    def fail_callback(value):
        raise Exception

    try_0 = Try.of(lambda: 1)

    try_1 = try_0.map(mapper)
    try_1_str = str(try_1)

    try_2 = try_0.bind(binder)
    try_2_str = str(try_2)

    try_3 = try_2.filter(filterer)
    try_3_str = str(try_3)

    try_4 = try_0.on_success(success_callback)

# Generated at 2022-06-25 23:57:25.643612
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    check_0 = Try.of(int, "1")

# Generated at 2022-06-25 23:57:29.384997
# Unit test for method get of class Try
def test_Try_get():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_1 = try_0.get()
    assert bool_1 == bool_0


# Generated at 2022-06-25 23:57:34.083780
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_0 = Try(True, True)
    try_1 = Try(True, False)
    string_0 = str(try_0)
    string_1 = str(try_1)
    assert string_0 == Try(True, True).__str__()
    assert string_1 == Try(True, False).__str__()


# Generated at 2022-06-25 23:57:42.234772
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0
    assert try_0.value
    assert try_0.is_success
    str_0 = try_0.__str__()
    assert str_0 == "Try[value=True, is_success=True]"
    bool_0 = True
    try_1 = Try(bool_0, not bool_0)
    assert try_1
    assert not try_1.value
    assert not try_1.is_success
    str_0 = try_1.__str__()
    assert str_0 == "Try[value=False, is_success=False]"
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0
    assert try_0

# Generated at 2022-06-25 23:57:44.150492
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert True == Try(1, True).get_or_else(0)
    assert 0 == Try(1, False).get_or_else(0)


# Generated at 2022-06-25 23:57:51.124367
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Test case 0
    try_0 = Try(1, True)
    try_1 = Try(None, False)

    assert try_0.get_or_else(None) == 1
    assert try_1.get_or_else('hello') == 'hello'

    try_1 = Try(None, False)
    assert try_1.get_or_else(2.0) == 2.0


# Generated at 2022-06-25 23:57:53.108821
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_0 = Try(False, False)
    bool_0 = try_0.get_or_else(True)



# Generated at 2022-06-25 23:57:59.647360
# Unit test for method on_success of class Try
def test_Try_on_success():
    # Creating test class
    class Test:
        def __init__(self):
            self.x = 0
        def increment(self):
            self.x += 1
    test = Test()

    Try(0, True).on_success(lambda x: test.increment())
    assert test.x == 1
    Try(None, False).on_success(lambda x: test.increment())
    assert test.x == 1
    Try(0, False).on_success(lambda x: test.increment())
    assert test.x == 1


# Generated at 2022-06-25 23:58:16.559906
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert test_case_0()



# Generated at 2022-06-25 23:58:21.556887
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    assert try_0.value is True
    assert try_0.is_success is True

    bool_1 = False
    try_1 = Try(bool_1, bool_1)

    assert try_1.value is False
    assert try_1.is_success is False


# Generated at 2022-06-25 23:58:30.518834
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    bool_1 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_1)
    bool_2 = try_0 == try_1
    bool_3 = try_1 == try_1
    bool_4 = try_0 == try_0
    bool_5 = True and bool_2
    bool_6 = True and bool_3
    bool_7 = True and bool_4
    bool_8 = bool_5
    str_0 = try_0.__str__()
    str_1 = try_1.__str__()
    str_2 = Try(str_0, bool_0).__str__()
    str_3 = Try(str_1, bool_1).__str__()
    str_4

# Generated at 2022-06-25 23:58:40.453188
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    bool_2 = False
    try_2 = Try(bool_2, bool_2)
    bool_3 = True
    try_3 = Try(bool_3, bool_3)
    bool_4 = True
    try_4 = Try(bool_4, bool_4)
    bool_5 = True
    try_5 = Try(bool_5, bool_5)
    bool_6 = True
    try_6 = Try(bool_6, bool_6)
    bool_7 = True
    try_7 = Try(bool_7, bool_7)
    assert(try_0 == try_1)

# Generated at 2022-06-25 23:58:48.436643
# Unit test for method filter of class Try
def test_Try_filter():
    # Unit test for method filter of class Try
    def test_filter_0():
        # Constructor is success full
        int_0 = Try.of(lambda: int('1123'), '1123').get()
        bool_0 = Try.of(lambda: int('1123') == 1123, '1123').filter(lambda x: x == int('1123')).is_success
        assert bool_0
    test_filter_0()

    def test_filter_1():
        # Constructor is success full
        int_0 = Try.of(lambda: int('1123'), '1123').get()
        bool_0 = Try.of(lambda: int('1123') == 1123, '1123').filter(lambda x: x == int('1123')).is_success
        assert bool_0
    test_filter_1

# Generated at 2022-06-25 23:58:54.756410
# Unit test for method map of class Try
def test_Try_map():
    def f(n):
        return Try(n * 2, True)

    t1 = Try(1, True)
    t2 = t1.map(f)
    assert t1 == Try(1, True)
    assert t2 == Try(2, True)

    t1 = Try(1, False)
    t2 = t1.map(f)
    assert t1 == t2



# Generated at 2022-06-25 23:59:02.950298
# Unit test for method map of class Try
def test_Try_map():
    try_0 = Try(True, True)
    try_1 = try_0.map(lambda value: not value)
    try_2 = try_0.map(lambda value: value)
    try_3 = Try(False, False)
    try_4 = try_3.map(lambda value: not value)
    try_5 = try_3.map(lambda value: value)
    try_6 = Try(False, True)
    try_7 = try_6.map(lambda value: not value)
    try_8 = try_6.map(lambda value: value)


# Generated at 2022-06-25 23:59:08.893718
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)
    assert Try(1, True).__str__() == 'Try[value=1, is_success=True]'
    assert Try(1, False).__str__() == 'Try[value=1, is_success=False]'


# Generated at 2022-06-25 23:59:14.819594
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try_0 = Try(True, True)
    def fn_0(arg_0):
        return Try(arg_0, True)
    def fn_1(arg_0):
        return Try(arg_0, False)
    def fn_2(arg_0):
        return Try(arg_0, False)
    try_1 = Try(False, False)
    try_2 = try_0.on_fail(fn_0)
    try_3 = try_1.on_fail(fn_1)
    try_4 = try_2.on_fail(fn_2)


# Generated at 2022-06-25 23:59:19.213549
# Unit test for method on_success of class Try
def test_Try_on_success():
    def is_true(x):
        assert x == True
    def is_false(x):
        assert x == False
    is_true(Try(True, True).on_success(is_true).get())
    is_false(Try(False, True).on_success(is_true).get())
    is_false(Try(True, False).on_success(is_true).get())


# Generated at 2022-06-25 23:59:58.533767
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try.of(lambda x: x, bool_0)
    bool_1 = None
    try_2 = Try.of(lambda x: x, bool_1)
    try_3 = Try.of(lambda: bool_1)
    try_4 = Try.of(lambda x: x)
    bool_2 = False
    try_5 = Try(bool_1, bool_2)
    str_0 = try_0.__str__()
    test_case_0()



# Generated at 2022-06-26 00:00:08.084468
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_0 = Try(None, True)
    _val_0 = try_0.get_or_else(None)
    assert _val_0 == None
    try_0 = Try(None, False)
    _val_0 = try_0.get_or_else(True)
    assert _val_0 == True
    try_0 = Try(None, False)
    _val_0 = try_0.get_or_else(False)
    assert _val_0 == False
    try_0 = Try(None, True)
    _val_0 = try_0.get_or_else(False)
    assert _val_0 == None


# Generated at 2022-06-26 00:00:09.907457
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(bool_0, bool_0) == Try(bool_0, bool_0)


# Generated at 2022-06-26 00:00:17.970709
# Unit test for method filter of class Try
def test_Try_filter():
    # Prepare values to use
    try_0_value = 1
    try_1_value = '1'
    try_2_value = None
    try_3_value = ''
    try_4_value = 'hello'

    try_0 = Try(try_0_value, True) # try_0 is successfully Try[int] with value 1
    try_1 = Try(try_1_value, True) # try_1 is successfully Try[str] with value 1
    try_2 = Try(try_2_value, False) # try_2 is not successfully Try[None] with value None
    try_3 = Try(try_3_value, True) # try_3 is successfully Try[str] with value ''
    try_4 = Try(try_4_value, True) # try_4 is successfully Try[str] with

# Generated at 2022-06-26 00:00:21.945769
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    str_0 = try_0.__str__()
    assert repr(str_0) == repr("Try[value=True, is_success=True]")



# Generated at 2022-06-26 00:00:24.936050
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try(True, True)
    try_1 = Try(True, True)
    assert try_0 == try_1


# Generated at 2022-06-26 00:00:27.632316
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.bind(None)

    assert (isinstance(try_1, Try))


# Generated at 2022-06-26 00:00:37.651225
# Unit test for method filter of class Try
def test_Try_filter():
    # 1. True -> True
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(lambda x: True)
    assert try_1.is_success
    assert try_1.value == bool_0
    # 2. True -> False
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(lambda x: False)
    assert not try_1.is_success
    assert try_1.value == bool_0
    # 3. False -> None
    bool_0 = True
    try_0 = Try(bool_0, False)
    try_1 = try_0.filter(lambda x: True)
    assert not try_1.is_success
   

# Generated at 2022-06-26 00:00:42.292595
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer_0(value_0):
        return True

    def filterer_1(value_1):
        return False

    int_0 = 0
    try_0 = Try.of(int, int_0)
    try_1 = try_0.filter(filterer_0)
    bool_0 = try_1.is_success
    try_2 = try_0.filter(filterer_1)
    bool_1 = try_2.is_success



# Generated at 2022-06-26 00:00:51.392281
# Unit test for method on_success of class Try
def test_Try_on_success():
    boolean_arg_0 = True
    boolean_arg_1 = False

    def test_0(boolean_arg_0):
        string_arg_0 = 'test'
        string_arg_1 = '0'
        string_arg_2 = 'test_0'
        boolean_arg_2 = True
        integer_arg_0 = 0
        string_arg_3 = 'ten'
        integer_arg_1 = 10
        string_arg_4 = '0'
        boolean_arg_3 = False
        boolean_arg_4 = True

        try_0 = Try(boolean_arg_0, boolean_arg_0)
        _ = try_0.is_success
        try_1 = try_0.bind(lambda string_arg_0: Try(boolean_arg_2, boolean_arg_2))

# Generated at 2022-06-26 00:02:02.883160
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    assert(try_0 == try_1)
    bool_1 = False
    try_1 = Try(bool_1, bool_1)
    assert(not try_0 == try_1)


# Generated at 2022-06-26 00:02:11.072432
# Unit test for method filter of class Try
def test_Try_filter():
    def _bool_(x):
        return True
    a = True
    _try_ = Try(a, _bool_(a))
    _bool_0_ = _try_.filter(_bool_)
    _bool_0_ = not _bool_0_
    assert _bool_0_
    def _bool_1_(x):
        return False
    a = True
    _try_1_ = Try(a, _bool_(a))
    _bool_0_ = _try_1_.filter(_bool_1_)
    _bool_0_ = not _bool_0_
    assert _bool_0_
    def _bool_2_(x):
        return True
    a = False
    _try_2_ = Try(a, _bool_(a))

# Generated at 2022-06-26 00:02:13.733123
# Unit test for method bind of class Try
def test_Try_bind():
    try_0 = Try.of(lambda : 1 + 1)
    try_1 = try_0.bind(lambda val_0: Try.of(lambda : val_0 + 2))
    int_0 = try_1.get()


# Generated at 2022-06-26 00:02:18.552991
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # If: given boolean value
    # When: call on_fail from Try
    # Then: if value is False raise Exception, othercase return Try
    @test
    def test_0():
        assert_that(Try("test_0", False).on_fail(lambda x: None) == Try("test_0", False))

    @test
    def test_1():
        assert_that(Try("test_1", True).on_fail(lambda x: None) == Try("test_1", True))


# Generated at 2022-06-26 00:02:27.124447
# Unit test for method map of class Try
def test_Try_map():
    try_0 = Try.of(lambda: True, [])
    try_1 = Try.of(lambda: False, [])
    try_2 = Try.of(lambda: False, [])

    if try_0 == Try(True, True) and try_1 == Try(False, True):
        pass
    else:
        raise Exception("Unit test for method map in class Try failed for successful and not successful Try")

    try_0 = try_0.map(lambda x: not x)
    try_1 = try_1.map(lambda x: not x)

    if try_0 == Try(False, True) and try_1 == Try(False, True):
        pass
    else:
        raise Exception("Unit test for method map in class Try failed for successful and not successful Try")



# Generated at 2022-06-26 00:02:29.662505
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.value == bool_0
    assert try_0.is_success == bool_0


# Generated at 2022-06-26 00:02:33.812064
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def raise_exception():
        raise Exception()

    def on_fail(value):
        print(value)

    not_successfully_try = Try.of(lambda: raise_exception())
    not_successfully_try.on_fail(on_fail)


# Generated at 2022-06-26 00:02:40.540387
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_1 = False
    try_1 = Try(bool_1, not bool_1)
    bool_2 = False
    def f0(a0):
        bool_1 = True
        if bool_1:
            bool_2 = True
            None
        else:
            bool_2 = False
            None
        return bool_2
    bool_3 = try_1.on_fail(f0).is_success
    bool_4 = bool_2
    assert(bool_3 and bool_4)


# Generated at 2022-06-26 00:02:50.648795
# Unit test for method on_success of class Try
def test_Try_on_success():
    def assert_equals(first, second):
        assert first == second

    def assert_not_equals(first, second):
        assert first != second

    def num_to_str(num):
        return str(num)

    def str_to_int(string):
        return int(string)

    assert_equals(Try.of(num_to_str, 10).on_success(lambda value: assert_equals(value, '10')).get(), '10')
    assert_equals(Try.of(str_to_int, '10').on_success(lambda value: assert_equals(value, 10)).get(), 10)

# Generated at 2022-06-26 00:02:52.849397
# Unit test for method get of class Try
def test_Try_get():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_1 = try_0.get()

