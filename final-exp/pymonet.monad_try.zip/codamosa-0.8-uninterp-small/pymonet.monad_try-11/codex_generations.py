

# Generated at 2022-06-25 23:53:03.312884
# Unit test for method filter of class Try
def test_Try_filter():
    pass

# Generated at 2022-06-25 23:53:13.419176
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    tuple_1 = (1, 2, 3)
    bool_1 = False
    try_1 = Try(tuple_1, bool_1)
    tuple_2 = (1, 2, 3)
    bool_2 = True
    try_2 = Try(tuple_2, bool_2)
    bool_3 = True
    try_3 = Try(tuple_0, bool_3)
    bool_4 = False
    try_4 = Try(tuple_1, bool_4)
    bool_5 = True
    try_5 = Try(tuple_0, bool_5)
    bool_6 = True

# Generated at 2022-06-25 23:53:21.057645
# Unit test for method filter of class Try
def test_Try_filter():
    fn = lambda x: x * x
    fn_1 = lambda x: x * x * x
    fn_ex = lambda x: 1 / x

    try_0 = Try.of(fn, 2)

    try_1 = Try.of(fn_ex, 0).filter(lambda x: x > 0)

    try_2 = try_0.filter(lambda x: x > 0)

    assert try_0 == try_2
    assert try_1.get_or_else(-1) == -1



# Generated at 2022-06-25 23:53:28.977358
# Unit test for method filter of class Try
def test_Try_filter():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    func_0 = lambda arg_0: arg_0
    str_0 = func_0(bool_0)
    func_1 = lambda arg_0: arg_0
    bool_1 = func_1(str_0)
    try_1 = try_0.filter(func_1)
    assert(try_1.is_success and try_1.value == tuple_0)


# Generated at 2022-06-25 23:53:36.219790
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    tuple_1 = tuple_0
    bool_1 = bool_0
    try_1 = Try(tuple_1, bool_1)
    assert try_0 == try_1


# Generated at 2022-06-25 23:53:49.360825
# Unit test for method filter of class Try
def test_Try_filter():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    str_0 = 'abc'
    int_0 = 123
    int_1 = 789
    str_1 = "def"
    list_0 = [str_0, int_0, int_1, str_1]
    func_0 = lambda str_2, int_2, int_3, str_3: str_2 + str(int_2) + str(int_3) + str_3
    try_1 = try_0.map(func_0)
    try_2 = try_1.filter(lambda arg_0: arg_0 not in list_0)
    assert try_2.is_success is False

# Generated at 2022-06-25 23:54:01.565714
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = ()
    tuple_1 = ()
    bool_0 = True
    bool_1 = False
    try_0 = Try(tuple_0, bool_0)
    try_1 = Try(tuple_0, bool_0)
    try_2 = Try(tuple_1, bool_0)
    try_3 = Try(tuple_0, bool_1)
    try_4 = Try(tuple_1, bool_1)

    assert try_0.__eq__(try_0) == True
    assert try_0.__eq__(try_1) == True
    assert try_0.__eq__(try_2) == False
    assert try_0.__eq__(try_3) == False
    assert try_0.__eq__(try_4) == False
   

# Generated at 2022-06-25 23:54:10.524039
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try.of(int, '32')
    try_1 = Try.of(int, '32')
    try_2 = Try.of(int, 'a33')
    try_3 = Try(32, True)
    try_4 = Try(32, True)
    assert(try_0 == try_1)
    assert(try_0 != try_2)
    assert(try_0 != try_3)
    assert(try_3 == try_4)
    assert(try_1 != try_3)


# Generated at 2022-06-25 23:54:15.004056
# Unit test for method filter of class Try
def test_Try_filter():
    def function_0(param_0):
        const_0 = 'a'
        try_0 = Try(const_0, True)
        return try_0.filter(lambda param_0: True)
    assert function_0(True) == Try('a', True)



# Generated at 2022-06-25 23:54:27.716034
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = ()
    tuple_1 = ()
    bool_0 = True
    bool_1 = True
    try_0 = Try(tuple_0, bool_0)
    try_1 = Try(tuple_0, bool_1)
    try_2 = Try(tuple_1, bool_0)
    try_3 = Try(tuple_1, bool_1)
    try_4 = Try(tuple_0, bool_0)
    try_5 = Try(tuple_0, bool_0)
    tuple_2 = (try_0, try_1, try_2, try_3, try_4, try_5)
    tuple_3 = (True, True, True, True, True, True)
    # Assert expressions
    assert (try_0 == try_0)
   

# Generated at 2022-06-25 23:54:31.393533
# Unit test for method get of class Try
def test_Try_get():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    value = try_0.get()
    assert tuple_0 == value


# Generated at 2022-06-25 23:54:36.348825
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # test with not successful monad
    input_value_0 = object()
    try_0 = Try(input_value_0, False)

# Generated at 2022-06-25 23:54:48.026755
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    number_0 = int()
    number_1 = int()

    tuple_0 = (number_1, number_1)
    boolean_0 = True
    try_0 = Try(tuple_0, boolean_0)
    tuple_1 = try_0.get_or_else(tuple_0)
    assert tuple_0[0] is tuple_1[0]
    assert tuple_0[1] is tuple_1[1]

    tuple_0 = (number_1, number_1)
    boolean_0 = False
    try_0 = Try(tuple_0, boolean_0)
    tuple_1 = try_0.get_or_else(tuple_0)
    assert tuple_0[0] is tuple_1[0]
    assert tuple_0[1] is tuple_1[1]

# Generated at 2022-06-25 23:54:52.779982
# Unit test for method on_success of class Try
def test_Try_on_success():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)

    list_0 = [0, 1, 2, 3, 4]
    def f(x):
        list_0.append(x)

    tuple_1 = (0,)
    bool_1 = True
    try_1 = Try(tuple_1, bool_1).on_success(f)
    assert list_0 == [0, 1, 2, 3, 4]



# Generated at 2022-06-25 23:55:02.644656
# Unit test for method bind of class Try
def test_Try_bind():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)

    def fn_0(tuple_0):
        tuple_1 = (tuple_0)
        bool_1 = True
        return Try(tuple_1, bool_1)
    try_1 = try_0.bind(fn_0)
    value_0 = try_1.get()
    value_1 = try_1.is_success
    value_2 = try_0.bind(fn_0)

    assert value_0 == ()
    assert value_1 == True
    assert value_2 == try_1


# Generated at 2022-06-25 23:55:10.888192
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = (14, 'further', [0])
    tuple_1 = (14, 'further', [0])
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    try_1 = Try(tuple_1, bool_0)
    try_2 = None
    assert try_1 == try_1
    assert not try_2 == try_0
    assert try_1 == try_0
    assert not try_0 == try_2


# Generated at 2022-06-25 23:55:21.573779
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    tuple_1 = (())
    bool_1 = True
    try_1 = Try(tuple_1, bool_1)
    tuple_2 = (1, 2, 3)
    bool_2 = True
    try_2 = Try(tuple_2, bool_2)
    tuple_3 = (1, 2, 3)
    bool_3 = False
    try_3 = Try(tuple_3, bool_3)
    val_0 = try_0.get_or_else(tuple_1)
    val_1 = try_2.get_or_else(try_0)
    val_2 = try_3.get_or_else(tuple_0)


# Generated at 2022-06-25 23:55:25.754848
# Unit test for method __str__ of class Try
def test_Try___str__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    str_0 = str(try_0)
    str_1 = 'Try[value=(), is_success=True]'
    assert str_0 == str_1


# Generated at 2022-06-25 23:55:33.140925
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    list_0 = list()
    def my_function_0():
        list_0.append(2)

    tuple_0 = (1, 2, 3)
    try_0 = Try(tuple_0, False)
    try_0.on_fail(my_function_0)
    assert len(list_0) == 1
    assert list_0[0] == 2


# Generated at 2022-06-25 23:55:36.382759
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_0 = Try("abc", True)
    assert (try_0.get_or_else("def") == "abc")
    try_1 = Try("abc", False)
    assert (try_1.get_or_else("def") == "def")



# Generated at 2022-06-25 23:55:51.278895
# Unit test for method on_success of class Try
def test_Try_on_success():
    from unittest import TestCase
    from types import MethodType, FunctionType

    class TestTry(TestCase):
        def __init__(self, *args, **kwargs):
            self.called = False
            self.value = None
            super(TestTry, self).__init__(*args, **kwargs)

        def test_on_success(self):
            def success_callback(value):
                self.called = True
                self.value = value

            try_0 = Try(0, bool_0)
            try_0.on_success(success_callback)

            self.assertTrue(self.called, 'on_success must call success_callback with value when try is successfully')
            self.assertEqual(self.value, try_0.value, 'on_success must call success_callback with value when try is successfully')

# Generated at 2022-06-25 23:55:55.833469
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    int_0 = try_0.get_or_else(1)
    assert(isinstance(int_0, int))
    assert(int_0 == 1)


# Generated at 2022-06-25 23:56:04.175767
# Unit test for method filter of class Try
def test_Try_filter():
    # Test 0
    def test_0():
        def test_fn_0(value):
            return True
        tuple_0 = ()
        bool_0 = True
        try_0 = Try(tuple_0, bool_0)
        try_1 = try_0.filter(test_fn_0)
        assert try_0 == try_1
        tuple_1 = (1,)
        bool_1 = False
        try_2 = Try(tuple_1, bool_1)
        try_3 = try_2.filter(test_fn_0)
        assert try_3 != try_2
        assert try_3.is_success == False

    def test_1():
        def test_fn_0(value):
            return False
        tuple_0 = ()
        bool_0 = True
        try_0

# Generated at 2022-06-25 23:56:15.649317
# Unit test for method map of class Try
def test_Try_map():
    def assert_map(
        function_0,
        function_1,
        function_arg_a_0,
        function_arg_a_1,
        function_arg_b_0,
        function_arg_b_1,
        function_exception_0,
        function_exception_1,
        expected_is_success,
        expected_value,
        expected_type,
        expected_str,
    ):
        bool_0 = True
        try_0 = Try(
            function_0,
            bool_0,
        )
        try_1 = try_0.map(
            function_1,
        )
        assert try_0.is_success == bool_0
        assert try_1.is_success == expected_is_success
        assert try_1.value == expected_value


# Generated at 2022-06-25 23:56:20.781865
# Unit test for method bind of class Try
def test_Try_bind():

    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    def fn_0(arg_0):
        tuple_0 = ()
        bool_0 = True
        return Try(tuple_0, bool_0)
    try_0 = try_0.bind(fn_0)


# Generated at 2022-06-25 23:56:26.838581
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = ()
    tuple_1 = (1, 2)
    tuple_2 = (1, 2)
    bool_0 = True
    bool_1 = True
    try_0 = Try(tuple_0, bool_0)
    try_1 = Try(tuple_1, bool_0)
    try_2 = Try(tuple_1, bool_1)
    try_3 = Try(tuple_2, bool_0)
    assert (try_0 == try_0)
    assert not (try_0 == try_1)
    assert not (try_1 == try_0)
    assert (try_1 == try_2)
    assert not (try_1 == try_3)



# Generated at 2022-06-25 23:56:33.771315
# Unit test for method on_success of class Try
def test_Try_on_success():
    def fn0(*args):
        return tuple(args)
    tuple_0 = ()
    bool_0 = True
    try_0 = Try.of(fn0, tuple_0, bool_0)
    str_0 = "SUCCESS"
    def fn1(value1):
        print(str_0)
    def fn2(value2):
        print(str_0)
    assert try_0.on_success(fn1).value == try_0.value
    assert try_0.on_success(fn2).value == try_0.value


# Generated at 2022-06-25 23:56:40.391621
# Unit test for method __str__ of class Try
def test_Try___str__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    try_str_0 = str(try_0)
    assert try_str_0 == 'Try[value=(), is_success=True]', 'Expected "Try[value=(), is_success=True]", but got: {}'.format(try_str_0)


# Generated at 2022-06-25 23:56:42.902519
# Unit test for constructor of class Try
def test_Try():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    assert try_0 is not None



# Generated at 2022-06-25 23:56:51.297560
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)

    tuple_1 = ()
    bool_1 = True
    try_1 = Try(tuple_1, bool_1)

    tuple_2 = ()
    bool_2 = False
    try_2 = Try(tuple_2, bool_2)

    tuple_3 = ()
    bool_3 = False
    try_3 = Try(tuple_3, bool_3)

    tuple_4 = ()
    bool_4 = True
    try_4 = Try(tuple_4, bool_4)

    if not (try_0 == try_0):
        raise RuntimeError('Expected True, got {0:s}'.format(str(try_0 == try_0)))


# Generated at 2022-06-25 23:57:09.944285
# Unit test for method bind of class Try
def test_Try_bind():
    tuple_0 = ()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    def func_0(arg_0, bool_0):
        dict_0[arg_0] = bool_0
    def func_1():
        dict_1['key_0'] = 0
    def func_2():
        dict_2['key_0'] = None
        dict_2['key_1'] = False
    def func_3(arg_0, arg_1):
        dict

# Generated at 2022-06-25 23:57:15.234550
# Unit test for method __str__ of class Try
def test_Try___str__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    str_0 = repr(try_0)
    str_1 = 'Try[value=(), is_success=True]'
    assert str_0 == str_1, 'Expected different value of variable str_0'


# Generated at 2022-06-25 23:57:21.765171
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_case_0():
        tuple_0 = ()
        bool_0 = True
        def func_0(arg_0, arg_1):
            print(arg_0)
            print(arg_1)
        try_0 = Try(tuple_0, bool_0)
        try_1 = try_0.on_fail(func_0)

    def test_case_1():
        list_0 = [1, 2, 3]
        bool_0 = False
        def func_0(arg_0, arg_1):
            print(arg_0)
            print(arg_1)
        try_0 = Try(list_0, bool_0)
        try_1 = try_0.on_fail(func_0)



# Generated at 2022-06-25 23:57:31.782259
# Unit test for method filter of class Try
def test_Try_filter():
    tuple_0 = ()
    tuple_1 = (1, 2, 3)
    bool_0 = True
    bool_1 = False
    bool_2 = bool_1
    try_0 = Try(tuple_0, bool_0)
    try_1 = Try(tuple_1, bool_1)
    try_2 = Try(tuple_1, bool_2)
    assert (try_0.filter(lambda x: False)
            == Try(tuple_0, bool_0))
    assert (try_1.filter(lambda x: True)
            == Try(tuple_1, bool_1))
    assert (try_2.filter(lambda x: True)
            == Try(tuple_1, bool_1))


# Generated at 2022-06-25 23:57:36.365725
# Unit test for method __str__ of class Try
def test_Try___str__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    try_1 = Try.of(lambda x: tuple_0, tuple_0)
    str_0 = str(try_0)
    str_1 = str(try_1)



# Generated at 2022-06-25 23:57:38.257335
# Unit test for constructor of class Try
def test_Try():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)


# Generated at 2022-06-25 23:57:44.843204
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    try_1 = Try(tuple_0, False)
    try_2 = Try(try_0, bool_0)
    try_3 = Try(tuple_0, bool_0)
    try_4 = Try(tuple_0, False)
    assert try_0 == try_3
    assert not try_0 == try_1
    assert not try_0 == try_2
    assert try_1 == try_4
    assert not try_1 == try_0
    assert not try_1 == try_2
    assert try_2 == try_2
    assert not try_2 == try_0
    assert not try_2 == try_1


# Generated at 2022-06-25 23:57:47.700539
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_0 = Try(123, True)
    try_0.on_success(lambda value: print(value))
    try_0.on_success(lambda value: True)



# Generated at 2022-06-25 23:57:57.856998
# Unit test for method on_success of class Try
def test_Try_on_success():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    def method_0(arg_0, arg_1):
        for i in range(4, 0, -1):
            if (i > 0):
                try_0 = Try(tuple_0, bool_0)
            if (i <= (arg_0 + arg_1)):
                try_0 = Try(tuple_0, bool_0)
                try_0.on_success(method_0)
            if (i >= (arg_1 * arg_0)):
                try_0 = Try(tuple_0, bool_0)
                try_0.on_success(method_0)
        return try_0
    method_0(1, 1)
    method_0

# Generated at 2022-06-25 23:58:02.326868
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = False
    tuple_0 = ()
    try_0 = Try(tuple_0, bool_0)
    str_0 = 'Try[value={}, is_success={}]'.format(tuple_0, bool_0)
    if not str_0 == str(try_0):
        raise RuntimeError('str(try_0) != str_0')


# Generated at 2022-06-25 23:58:18.488067
# Unit test for method get of class Try
def test_Try_get():
    try_0 = Try(())
    with pytest.raises(AttributeError):
        getattr(try_0, "get")


# Generated at 2022-06-25 23:58:22.266324
# Unit test for method get of class Try
def test_Try_get():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    tuple_1 = try_0.get()
    bool_1 = (tuple_1 == tuple_0)
    bool_2 = bool_1


# Generated at 2022-06-25 23:58:27.844582
# Unit test for method map of class Try
def test_Try_map():
    tuple_0 = ()
    bool_0 = True
    tuple_1 = (0,)
    try_0 = Try(tuple_0, bool_0)
    try_1 = Try.of(lambda *args: args, tuple_1)
    int_0 = 0
    def func_0(arg_0):
        return arg_0
    try_2 = try_0.map(func_0)
    try_3 = try_1.map(func_0)
    assert try_2 == try_0
    assert try_3 == try_1


# Generated at 2022-06-25 23:58:35.383572
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test for on_fail method.
    """
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    fn_0 = lambda arg_0: arg_0
    def fn_1(arg_0):
        fn_0(arg_0)
    try_0.on_fail(fn_0)
    

# Generated at 2022-06-25 23:58:41.352782
# Unit test for method bind of class Try
def test_Try_bind():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    bool_1 = bool_0
    def func_0(arg_0):
        bool_1 = bool_0
        return Try(arg_0, bool_1)
    try_1 = try_0.bind(func_0)
    bool_2 = (not bool_1)
    bool_3 = try_1.is_success
    bool_4 = (bool_2 == bool_3)


# Generated at 2022-06-25 23:58:43.806124
# Unit test for method bind of class Try
def test_Try_bind():
    def function_0(arg_0):
        return Try(1, True)
    try_0 = Try.of(function_0, 1).bind(function_0)


# Generated at 2022-06-25 23:58:45.933845
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    tuple_0 = ()
    try_0 = Try(tuple_0, False)
    int_0 = try_0.get_or_else(0)


# Generated at 2022-06-25 23:58:51.097286
# Unit test for method on_success of class Try
def test_Try_on_success():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)

    # Try is successfully
    def fn_0_try_on_success():
        def fn_0(arg_0):
            fn_0.call_count += 1

        fn_0.call_count = 0

        try_0.on_success(fn_0)

        actual = fn_0.call_count
        expected = 1

        assert actual == expected, 'fn_0_try_on_success: Expected result is {}, actual result is {}'.format(expected, actual)

    fn_0_try_on_success()

    # Try is not successfully
    def fn_1_try_on_success():
        def fn_0(arg_0):
            fn_0.call_count

# Generated at 2022-06-25 23:59:02.098901
# Unit test for method get of class Try
def test_Try_get():
    def f_0() -> Try:
        pass
    def f_1() -> Try:
        return Try((), True)
    def f_2() -> Try:
        return Try((), False)
    def f_3() -> Try:
        return Try((0,), True)
    def f_4() -> Try:
        return Try((0,), False)
    def f_5() -> Try:
        return Try(Try((), True), True)
    def f_6() -> Try:
        return Try(Try((), True), False)
    def f_7() -> Try:
        return Try(Try((), False), True)
    def f_8() -> Try:
        return Try(Try((), False), False)

# Generated at 2022-06-25 23:59:11.736486
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-25 23:59:42.278440
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_0 = Try(tuple(), True)
    assert try_0.on_success(lambda _: None) == Try(tuple(), True)

# Generated at 2022-06-25 23:59:47.074700
# Unit test for method get of class Try
def test_Try_get():
    # Case 0
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    assert try_0.get() == tuple_0
    # Case 1
    tuple_1 = ()
    bool_1 = False
    try_1 = Try(tuple_1, bool_1)
    assert try_1.get() == tuple_1


# Generated at 2022-06-25 23:59:49.166970
# Unit test for method get of class Try
def test_Try_get():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    assert tuple_0 == try_0.get()


# Generated at 2022-06-25 23:59:52.418069
# Unit test for method filter of class Try
def test_Try_filter():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    def f():
        pass
    assert try_0.filter(f) == Try(tuple_0, bool_0)


# Generated at 2022-06-25 23:59:56.627577
# Unit test for method __str__ of class Try
def test_Try___str__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    str_0 = try_0.__str__()
    str_1 = 'Try[value=(), is_success=True]'
    assert str_0 == str_1


# Generated at 2022-06-26 00:00:07.549255
# Unit test for method __eq__ of class Try
def test_Try___eq__():

    value_0 = "abcd"
    try_0 = Try(value_0, True)
    try_1 = Try(value_0, False)
    value_1 = "abcd"
    value_2 = "abce"
    try_2 = Try(value_1, True)
    try_3 = Try(value_1, False)
    try_4 = Try(value_2, True)
    try_5 = Try(value_2, False)

    assert (try_0 == try_0), "test_Try___eq__: " + "test_case_0 failed"
    assert (try_1 == try_1), "test_Try___eq__: " + "test_case_1 failed"

# Generated at 2022-06-26 00:00:10.501403
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    exp = 'abc'
    Try('abc', True).get_or_else('efg') == exp
    assert Try('abc', True).get_or_else('efg') == exp


# Generated at 2022-06-26 00:00:15.708869
# Unit test for method get of class Try
def test_Try_get():
    """
    :Test-Id: G007T001
    :Description: Unit test for get function of Try class
    :Expected: return value is equal to the value in Try class
    :Requirement:
    """
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    result_0 = try_0.get()
    assert result_0 == tuple_0


# Generated at 2022-06-26 00:00:21.262922
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    tuple_1 = ()
    try_0.get_or_else(tuple_1)


# Generated at 2022-06-26 00:00:27.554223
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x != 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)
    assert Try(1, False).filter(lambda x: x != 1) == Try(1, False)


# Generated at 2022-06-26 00:01:32.419965
# Unit test for method get of class Try
def test_Try_get():
    def fn_0():
        return ()

    tuple_0 = ()
    bool_0 = True

    try_0 = Try(tuple_0, bool_0)
    try_1 = Try.of(fn_0)

    obj_0 = try_0.get()
    obj_1 = try_1.get()

    assert obj_0 == tuple_0
    assert obj_1 == tuple_0


# Generated at 2022-06-26 00:01:36.619209
# Unit test for constructor of class Try
def test_Try():
    assert Try((), True) == Try((), True)
    assert Try((), True) != Try((), False)
    assert Try((), True) != Try((1, 2, 3), True)
    assert Try((), True) != Try((1, 2, 3), False)
    assert Try((), False) != Try((1, 2, 3), False)


# Generated at 2022-06-26 00:01:40.877488
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    try_0.on_fail(lambda e: e)
    try_1 = Try(tuple_0, bool_0)
    try_1.on_fail(lambda e: e)


# Generated at 2022-06-26 00:01:49.009375
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = ()
    tuple_1 = ()
    bool_0 = True
    bool_1 = True
    try_0 = Try(tuple_0, bool_0)
    try_1 = Try(tuple_0, bool_0)
    try_2 = Try(tuple_0, bool_1)
    try_3 = Try(tuple_1, bool_0)
    try_4 = Try(tuple_1, bool_1)
    assert try_0 == try_0
    assert not try_0 == try_1
    assert not try_0 == try_2
    assert not try_0 == try_3
    assert not try_0 == try_4


# Generated at 2022-06-26 00:01:53.586387
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def func_0(inner_0: Try) -> Try:
        inner_0.on_fail(lambda i_0: i_0)
        return inner_0

    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)

    variable_0 = func_0(try_0)



# Generated at 2022-06-26 00:01:56.713007
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(False, False).get() is False
    assert Try(None, True).get() is None
    assert Try(None, False).get() is None


# Generated at 2022-06-26 00:02:07.056066
# Unit test for method on_success of class Try
def test_Try_on_success():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)

    def func_0(arg_0, arg_1):
        print(arg_0)
        print(arg_1)

    list_0 = [
        tuple([Try(bool_0, bool_0)]),
        tuple([try_0])
        ]
    list_1 = [
        tuple([bool_0]),
        tuple([])
        ]
    list_2 = [
        tuple_0,
        tuple_0
        ]


# Generated at 2022-06-26 00:02:09.740584
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tuple_0 = ()
    bool_0 = True
    try_0 = Try(tuple_0, bool_0)
    tuple_1 = ()
    bool_1 = True
    try_1 = Try(tuple_1, bool_1)
    assert try_0 == try_1



# Generated at 2022-06-26 00:02:12.952509
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_0 = Try(tuple(), True)
    tuple_0 = try_0.get_or_else((tuple(),))
    try_0 = Try(tuple(), False)
    tuple_1 = try_0.get_or_else((tuple(), (tuple(),)))


# Generated at 2022-06-26 00:02:21.211952
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_case_0():
        tuple_0 = (1,)
        bool_0 = True
        try_0 = Try(tuple_0, bool_0)
        bool_1 = True
        bool_2 = True
        bool_3 = True
        try_1 = try_0.on_success(lambda x: bool_1 if x == len(x) else bool_2)
        try_2 = try_1.on_success(lambda x_1: bool_3 if x_1 else None)
        assert (try_2.value == bool_3)
        assert (try_2.is_success)

    def test_case_1():
        tuple_0 = ()
        bool_0 = True
        try_0 = Try(tuple_0, bool_0)
        bool_1 = True
        bool