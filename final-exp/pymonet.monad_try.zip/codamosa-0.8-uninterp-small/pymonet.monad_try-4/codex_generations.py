

# Generated at 2022-06-25 23:53:12.976996
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Expectation:
        Try(False, True).filter(lambda value: True) == Try(False, True)
        Try(False, False).filter(lambda value: True) == Try(False, False)
        Try(True, False).filter(lambda value: False) == Try(True, False)
        Try(True, True).filter(lambda value: False) == Try(True, False)
    """
    assert Try(False, True).filter(lambda value: True) == Try(False, True)
    assert Try(False, False).filter(lambda value: True) == Try(False, False)
    assert Try(True, False).filter(lambda value: False) == Try(True, False)
    assert Try(True, True).filter(lambda value: False) == Try(True, False)


# Generated at 2022-06-25 23:53:17.762373
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    def filterer_0(value):
        return not bool_0
    try_1 = try_0.filter(filterer_0)
    assert try_1.is_success == bool_0


# Generated at 2022-06-25 23:53:22.072481
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(lambda value: not bool_0)

    assert try_0 == try_1



# Generated at 2022-06-25 23:53:29.494208
# Unit test for method filter of class Try
def test_Try_filter():
    test1 = Try(1, True).filter(lambda value: value == 1).is_success
    assert test1 == True, 'failure in test1'

    test2 = Try(2, True).filter(lambda value: value == 1).is_success
    assert test2 == False, 'failure in test2'

    test3 = Try(Exception('error'), False).filter(lambda value: value == 1).is_success
    assert test3 == False, 'failure in test3'



# Generated at 2022-06-25 23:53:39.479391
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_method(value):
        return isinstance(value, str)
    true_value = True
    false_value = False
    filter_str = 'string'
    not_filter_str = 10
    try_str_filter = Try(filter_str, true_value)
    try_str_not_filter = Try(not_filter_str, true_value)
    try_not_success = Try(not_filter_str, false_value)
    assert try_str_filter.filter(filter_method) == Try(filter_str, true_value)
    assert try_str_not_filter.filter(filter_method) == Try(not_filter_str, false_value)
    assert try_not_success.filter(filter_method) == Try(not_filter_str, false_value)

# Unit test

# Generated at 2022-06-25 23:53:47.294752
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully case
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    def filterer(value):
        return value
    try_1 = try_0.filter(filterer)
    assert try_1 == Try(bool_0, bool_0)
    # Not successfully case
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(filterer)
    assert try_1 == Try(bool_0, False)



# Generated at 2022-06-25 23:53:53.141730
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0 == try_0.filter(lambda x: x), ''
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert Try(bool_0, bool_0) == try_0.filter(lambda x: x), ''


# Generated at 2022-06-25 23:54:02.329660
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter for class Try
    """
    assert Try.of(int, "0").value == 0
    assert Try.of(int, "0").map(lambda x: x ** 2).value == 0
    assert Try.of(int, "0x11").value == 17
    assert Try.of(int, "0x11").map(lambda x: x ** 2).value == 289
    assert Try.of(int, "11").value == 11
    assert Try.of(int, "11").map(lambda x: x ** 2).value == 121
    assert Try.of(int, "0xFF").value == 255
    assert Try.of(int, "0xFF").map(lambda x: x ** 2).value == 65025



# Generated at 2022-06-25 23:54:13.571186
# Unit test for method filter of class Try
def test_Try_filter():
    # Test 1
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_0_result = try_0.filter(lambda value: value == bool_0)
    assert try_0_result == Try(bool_0, not bool_0)
    # Test 2
    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    try_1_result = try_1.filter(lambda value: value == bool_1)
    assert try_1_result == Try(bool_1, bool_1)
    # Test 3
    bool_2 = True
    try_2 = Try(bool_2, not bool_2)
    try_2_result = try_2.filter(lambda value: value)

# Generated at 2022-06-25 23:54:25.827808
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(lambda: bool(0), bool)
    bool_0 = bool(0)
    try_1 = try_0.filter(lambda value: value == bool_0)
    try_2 = Try.of(lambda: bool(1), bool)
    bool_1 = bool(1)
    try_3 = try_2.filter(lambda value: value == bool_1)
    assert try_1.value == bool_0, "Can't assert value for 'try_1' and 'bool_0'"
    assert try_1.is_success == False, "Can't assert value for 'try_1' and 'False'"
    assert try_3.value == bool_1, "Can't assert value for 'try_3' and 'bool_1'"

# Generated at 2022-06-25 23:54:37.636633
# Unit test for method filter of class Try
def test_Try_filter():
    # test when is_success is False
    try_1 = Try('asds', False)
    try_2 = try_1.filter(lambda value: False)
    assert isinstance(try_2, Try)
    assert try_1 == try_2
    try_3 = try_1.filter(lambda value: True)
    assert isinstance(try_3, Try)
    assert try_1 == try_3

    # test when is_success is True
    try_4 = Try('asds', True)
    try_5 = try_4.filter(lambda value: False)
    assert isinstance(try_5, Try)
    assert try_5.value == try_4.value
    assert not try_5.is_success

    try_6 = try_4.filter(lambda value: True)
    assert isinstance

# Generated at 2022-06-25 23:54:48.431468
# Unit test for method filter of class Try
def test_Try_filter():
    # Test case 0
    try_0 = Try(True, True)
    try_1 = try_0.filter(lambda arg0: arg0 == True)
    assert try_0 == try_1, 'expected Try[value=True, is_success=True]'

    # Test case 1
    try_2 = Try(True, True)
    try_3 = try_2.filter(lambda arg0: arg0 == False)
    assert try_2 != try_3, 'expected Try[value=True, is_success=False]'

    # Test case 2
    try_4 = Try(False, False)
    try_5 = try_4.filter(lambda arg0: arg0 == True)
    assert try_4 == try_5, 'expected Try[value=False, is_success=False]'

    # Test case 3
   

# Generated at 2022-06-25 23:55:00.365517
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Assert equality of objects
    """

    # Case 0:
    # monad is not successfully
    try_0 = Try(False, False)
    assert try_0.filter(lambda v: True) == Try(False, False)

    # Case 1:
    # monad is successfully, filterer returns False,
    # result should be not successfully with previous value.
    try_1 = Try(True, True)
    assert try_1.filter(lambda v: False) == Try(True, False)

    # Case 2:
    # monad is successfully, filterer returns True,
    # result should be successfully with previous value.
    try_2 = Try(True, True)
    assert try_2.filter(lambda v: True) == Try(True, True)

    # Case 3:
    # monad

# Generated at 2022-06-25 23:55:04.624966
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: bool) -> bool:
        return True

    # Create test case
    bool_0 = False
    try_0 = Try(bool_0, bool_0).filter(filterer)

    # Check test case
    assert try_0 == Try(bool_0, False)



# Generated at 2022-06-25 23:55:14.173859
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    def filterer_0(value):
        return True
    try_0 = Try(bool_0, bool_0)

    assert try_0.filter(filterer_0).is_success == bool_0
    assert try_0.filter(filterer_0).value == bool_0

    bool_1 = False
    try_1 = Try(bool_0, bool_1)

    assert try_1.filter(filterer_0).is_success == bool_1
    assert try_1.filter(filterer_0).value == bool_0

    def filterer_1(value):
        return False
    try_2 = Try(bool_0, bool_0)

    assert try_2.filter(filterer_1).is_success == bool_1
   

# Generated at 2022-06-25 23:55:24.987589
# Unit test for method filter of class Try
def test_Try_filter():
    fn = lambda a: a

    try_0 = Try.of(fn, 5)
    assert try_0.filter(lambda a: a == 5) == Try(5, True)

    try_1 = Try.of(fn, 'string')
    assert try_1.filter(lambda a: 'r' in a) == Try('string', True)

    try_2 = Try.of(fn, None)
    assert try_2.filter(lambda a: None) == Try(None, False)

    try_3 = Try.of(fn, [])
    assert try_3.filter(lambda a: a == []) == Try([], True)

    try_4 = Try.of(fn, [1, 2, 3])

# Generated at 2022-06-25 23:55:34.676021
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.filter(lambda x: x == True) == Try(bool_0, False)
    assert try_0.filter(lambda x: x == False) == Try(bool_0, False)

    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.filter(lambda x: x == True) == Try(bool_0, True)
    assert try_0.filter(lambda x: x == False) == Try(bool_0, False)


# Generated at 2022-06-25 23:55:41.174699
# Unit test for method filter of class Try
def test_Try_filter():
    default_value = 'default_value'
    addr = '127.0.0.1'

    assert Try.of(lambda: 222).filter(lambda v: v == 222).get() == 222
    assert Try.of(lambda: 222).filter(lambda v: v == 333).get_or_else(default_value) == default_value
    assert Try.of(lambda: 222).filter(lambda v: v == 222).get_or_else(default_value) == 222

    assert Try.of(lambda: 444).bind(lambda v: Try(v, False)).filter(lambda v: v == 444).get() == 444
    assert Try.of(lambda: 444).bind(lambda v: Try(v, False)).filter(lambda v: v == 555).get_or_else(default_value) == default_value
    assert Try.of

# Generated at 2022-06-25 23:55:51.011146
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer_0(value):
        return bool(value)

    def filterer_1(value):
        return bool(value)

    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_0 = try_0.filter(filterer_0)
    bool_1 = bool_0
    try_1 = try_0
    assert bool_1 == try_1.is_success

    bool_1 = False
    try_0 = try_0.filter(filterer_1)
    try_1 = try_0
    assert bool_1 == try_1.is_success



# Generated at 2022-06-25 23:55:55.223084
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    filter_0 = lambda x: True  # TODO: Can this line be simplified?
    assert try_0.filter(filter_0) == Try(bool_0, False)


# Generated at 2022-06-25 23:56:05.894809
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    cases = [
        {
            'value': 1,
            'is_success': True,
            'expect_value': 1,
            'expect_is_success': True,
        },
        {
            'value': 1,
            'is_success': False,
            'expect_value': 1,
            'expect_is_success': False,
        },
    ]
    for case in cases:
        try_m = Try(case['value'], case['is_success'])
        arg_0 = lambda e: e

        try_0 = try_m.on_fail(arg_0)

        try_0_value = try_0.get()
        assert try_0_value == case['expect_value']
        try_0_is_success = try_0.is_success
       

# Generated at 2022-06-25 23:56:13.052972
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_0 = Try(True, True)
    try_0_value = try_0.get_or_else(False)
    try_0_expected = True
    assert try_0_value == try_0_expected

    try_1 = Try(False, False)
    try_1_value = try_1.get_or_else(True)
    try_1_expected = True
    assert try_1_value == try_1_expected


# Generated at 2022-06-25 23:56:22.236682
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Testing method get_or_else of class Try.

    """
    val = 'qwerty'
    def_val = 'zxcvbn'
    try_0 = Try(val, True)
    try_1 = Try(val, False)
    try_2 = Try(None, True)
    try_3 = Try(None, False)
    assert try_0.get_or_else(def_val) == val
    assert try_1.get_or_else(def_val) == def_val
    assert try_2.get_or_else(def_val) == def_val
    assert try_3.get_or_else(def_val) == def_val


# Generated at 2022-06-25 23:56:31.761933
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_1 = Try(bool_0, bool_0)
    try_0 = Try(try_1, bool_0)
    try_0_0 = Try.of(lambda: 0, )
    bool_0_0 = True
    bool_1_1 = False
    bool_1_0 = bool_0_0
    try_2 = try_0_0.filter(lambda a: bool_1_1)
    try_0_0 = try_0_0.filter(lambda a: bool_1_0)
    try_2_0 = try_2.map(lambda a: try_0.filter(lambda a: bool_1_1))

# Generated at 2022-06-25 23:56:42.611120
# Unit test for method filter of class Try
def test_Try_filter():
    value: str = 'success'
    # Predicate function will return True for str
    def filterer(value) -> bool:
        return isinstance(value, str)

    try_0 = Try(value, True)
    assert try_0.filter(filterer) == Try(value, True)
    assert try_0.filter(filterer) != Try(value, False)

    # Predicate function will return True for int
    def filterer(value) -> bool:
        return isinstance(value, int)

    try_0 = Try(value, True)
    assert try_0.filter(filterer) != Try(value, True)
    assert try_0.filter(filterer) == Try(value, False)


# Generated at 2022-06-25 23:56:47.964383
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_0.on_fail(lambda x: print('Fail message: ' + str(x)))
    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    try_1.on_fail(lambda x: print('Fail message: ' + str(x)))

test_Try_on_fail()

# Generated at 2022-06-25 23:56:51.316234
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(None, False).on_success(lambda _: False) == Try(None, False)\
        .on_success(lambda _: True) == Try(42, True).on_success(lambda _: True) == Try(42, True)



# Generated at 2022-06-25 23:57:03.267067
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_0 = False
    try_1 = Try(bool_0, bool_0)
    int_0 = 5
    int_1 = int_0 + 1
    bool_0 = int_0 == int_1
    try_2 = Try(bool_0, bool_0)
    try_2.on_success(lambda v: v == True).on_fail(lambda v: v == True)
    int_0 = 5
    int_1 = int_0 + 1
    bool_0 = int_0 == int_1
    try_3 = Try(bool_0, bool_0)
    try_0.on_success(lambda v: v == False)
    int_0 = 5
    int_1 = int_

# Generated at 2022-06-25 23:57:06.045426
# Unit test for constructor of class Try
def test_Try():
    assert Try(True, True) == Try(True, True)
    assert Try(True, True) != Try(False, False)



# Generated at 2022-06-25 23:57:09.782246
# Unit test for method map of class Try
def test_Try_map():
    try_0 = Try(1, True)
    try_1 = try_0.map(lambda a: a + 1)
    try_2 = Try(2, True)

    assert try_1 == try_2


# Generated at 2022-06-25 23:57:17.913272
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert str(try_0) == 'Try[value=False, is_success=False]'

    int_0 = 100
    try_1 = Try(int_0, True)
    assert str(try_1) == 'Try[value=100, is_success=True]'



# Generated at 2022-06-25 23:57:21.514882
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x + 1, 2)\
        .filter(lambda n: n > 0)\
        .get() == 3

    assert Try.of(lambda x: x + 1, 2)\
        .filter(lambda n: n < 0)\
        .get_or_else(0) == 0


# Generated at 2022-06-25 23:57:27.868409
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_on_fail_case_0(test_value):
        assert test_value == False

    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_0.on_fail(test_on_fail_case_0)
    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    try_1.on_fail(test_on_fail_case_0)



# Generated at 2022-06-25 23:57:31.267872
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda x: x + 1, 1).get_or_else(0) == 2
    assert Try.of(lambda x: x + 1, "1").get_or_else(0) == 0

# Generated at 2022-06-25 23:57:40.437985
# Unit test for method on_success of class Try
def test_Try_on_success():
    val_0 = 'str_0'
    bool_0 = False
    bool_1 = bool(val_0)
    try_0 = Try(val_0, bool_1)
    try_1 = try_0.on_success(lambda val: val.upper())
    val_1 = val_0.upper()
    bool_2 = bool_1
    assert val_1 == try_1.value
    assert bool_2 == try_1.is_success

    val_2 = val_1
    bool_3 = bool_0
    try_3 = Try(val_2, bool_3)
    try_4 = try_3.on_success(lambda val: val.upper())
    val_3 = val_2
    bool_4 = bool_3
    assert val_3 == try_4.value


# Generated at 2022-06-25 23:57:41.876916
# Unit test for constructor of class Try
def test_Try():
    assert isinstance(Try(2, True), Try)
    assert isinstance(Try('a', False), Try)


# Generated at 2022-06-25 23:57:46.878611
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = True
    def bool_bind(val):
        bool_0 = not val
        return Try(bool_0, bool_0)
    try_0 = Try(True, True).bind(bool_bind)
    bool_0 = not bool_0
    assert try_0.value == bool_0
    assert try_0.is_success == bool_0


# Generated at 2022-06-25 23:57:49.618613
# Unit test for method get of class Try
def test_Try_get():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)

    assert(try_0.get() == bool_0)


# Generated at 2022-06-25 23:57:53.779499
# Unit test for method on_success of class Try
def test_Try_on_success():
    def assertion(value: bool) -> None:
        assert value
    try_0 = Try(True, True)
    try_1 = Try(False, True)
    try_0.on_success(assertion)
    try_1.on_success(assertion)


# Generated at 2022-06-25 23:57:54.798522
# Unit test for constructor of class Try
def test_Try():
    test_case_0()

# Generated at 2022-06-25 23:58:10.292718
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try.of(lambda: True)
    assert try_0 == try_0, 'Test 0'

    bool_0 = True
    try_1 = Try(bool_0, bool_0)
    assert try_0 == try_1, 'Test 1'

    bool_0 = True
    try_2 = Try(bool_0, bool_0)
    assert not (try_2 != try_1), 'Test 2'

    bool_0 = False
    try_3 = Try(bool_0, bool_0)
    bool_0 = False
    try_4 = Try(bool_0, bool_0)
    assert try_3 == try_4, 'Test 3'


# Generated at 2022-06-25 23:58:12.890707
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_0.get_or_else(False)


# Generated at 2022-06-25 23:58:17.679856
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success(obj):
        assert obj
    def fail(obj):
        assert not obj

    Try(True, True).on_success(success)
    Try(False, True).on_fail(fail)
    Try(True, False).on_success(success)
    Try(False, False).on_fail(fail)


# Generated at 2022-06-25 23:58:24.449592
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    success_value = 5
    success_try = Try(success_value, True)
    assert success_try.on_fail(lambda e: None) == success_try
    assert success_try.on_fail(lambda e: print('not success')) == success_try

    error_value = 5
    error_try = Try(error_value, False)
    assert error_try.on_fail(lambda e: None) == error_try
    assert error_try.on_fail(lambda e: print('not success')) == error_try



# Generated at 2022-06-25 23:58:35.426938
# Unit test for method filter of class Try
def test_Try_filter():
    try_int_1 = Try(1, True)

    try_int_1.filter(lambda x: x % 2 == 0).get_or_else(False)
    assert (try_int_1.filter(lambda x: x % 2 == 0).get_or_else(False) == False)

    try_int_1.filter(lambda x: x % 2 == 1).get_or_else(False)
    assert (try_int_1.filter(lambda x: x % 2 == 1).get_or_else(False) == 1)

    try_exception_0 = Try(Exception(), False)
    try_exception_0.filter(lambda x: True).get_or_else(False)
    assert (try_exception_0.filter(lambda x: True).get_or_else(False) == False)

# Generated at 2022-06-25 23:58:41.746501
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    mock_value_0 = Mock()
    mock_callback_0 = Mock()
    mock_try_0 = Mock()

    try_0 = Try(mock_value_0, False)
    try_0.on_fail(mock_callback_0)
    mock_callback_0.assert_called_once_with(mock_value_0)

    try_1 = Try(mock_value_0, True)
    try_1.on_fail(mock_callback_0)
    mock_callback_0.assert_not_called()


# Generated at 2022-06-25 23:58:46.126041
# Unit test for method __str__ of class Try
def test_Try___str__():
    boolean_0 = True
    try_0 = Try(boolean_0, boolean_0)
    try_0_str = "Try[value={}, is_success={}]".format(boolean_0, boolean_0)
    try_0_str_1 = try_0.__str__()
    assert try_0_str == try_0_str_1


# Generated at 2022-06-25 23:58:51.554799
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, False) == Try(1, False)
    assert Try(2, True) == Try(2, True)
    assert Try(False, True) == Try(False, True)
    assert Try(1, False) != Try(1, True)
    assert Try(2, True) != Try(3, True)
    assert Try(False, True) != Try(False, False)


# Generated at 2022-06-25 23:58:53.910925
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(int, '1').get() == 1
    assert Try.of(int, 'a').get() == 'a'


# Generated at 2022-06-25 23:59:05.488066
# Unit test for method filter of class Try
def test_Try_filter():
    def true():
        return True

    def false():
        return False

    result_true_true = Try(True, True).filter(true)
    assert result_true_true == Try(True, True), 'Expect {} but got {}'.format(Try(True, True), result_true_true)

    result_true_false = Try(True, True).filter(false)
    assert result_true_false == Try(True, False), 'Expect {} but got {}'.format(Try(True, False), result_true_false)

    result_false_true = Try(False, False).filter(true)
    assert result_false_true == Try(False, False), 'Expect {} but got {}'.format(Try(False, False), result_false_true)


# Generated at 2022-06-25 23:59:13.888935
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_0 = Try(True, True)
    func_0 = lambda value: print(value)
    try_0.on_success(func_0)


# Generated at 2022-06-25 23:59:21.904601
# Unit test for method map of class Try
def test_Try_map():
    class Error(Exception):
        pass

    def some_func_0(*args):
        return args[0] * args[1]

    def some_func_1(*args):
        return Try(some_func_0(*args), True)

    def some_func_2(*args):
        return Try(some_func_0(*args), False)

    def some_func_3(*args):
        if len(args) != 2:
            raise Error('wrong args length')

        if not isinstance(args[0], int):
            raise Error('wrong type of first arg')

        if not isinstance(args[1], int):
            raise Error('wrong type of second arg')

        return Try(some_func_0(*args), True)


# Generated at 2022-06-25 23:59:24.942131
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: None).on_success(lambda x: x) == Try.of(lambda: None)
    assert Try.of(lambda: 1).on_success(lambda x: x) == Try.of(lambda: 1)


# Generated at 2022-06-25 23:59:26.061604
# Unit test for method get of class Try
def test_Try_get():
    assert Try(True, True).get() == True

# Generated at 2022-06-25 23:59:32.952524
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():

    def exception_case():
        raise Exception('test_case_0')

    try_0 = Try.of(bool, True)
    assert try_0.get_or_else(False) == True

    try_1 = Try.of(bool, 0)
    assert try_1.get_or_else(True) == False

    try_2 = Try.of(exception_case)
    assert try_2.get_or_else('Exception') == 'Exception'



# Generated at 2022-06-25 23:59:36.463733
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-25 23:59:38.554948
# Unit test for method get of class Try
def test_Try_get():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.get() == bool_0


# Generated at 2022-06-25 23:59:42.438119
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 5) == Try(10, True)
    assert Try(5, True).filter(lambda x: x > 5) == Try(5, False)
    assert Try(Exception('Error'), False).filter(lambda x: x > 5) == Try(Exception('Error'), False)


# Generated at 2022-06-25 23:59:50.350299
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    bool_1 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_1)
    try_2 = Try(bool_0, bool_1)
    try_3 = Try(bool_1, bool_0)

    assert try_0.value == bool_0
    assert try_0.is_success == bool_0
    assert try_1.value == bool_1
    assert try_1.is_success == bool_1
    assert try_2.value == bool_0
    assert try_2.is_success == bool_1
    assert try_3.value == bool_1
    assert try_3.is_success == bool_0
    assert try_0 == try_3

# Generated at 2022-06-25 23:59:52.592725
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.get_or_else(True) == True


# Generated at 2022-06-26 00:00:11.405941
# Unit test for method filter of class Try
def test_Try_filter():
    from nose.tools import assert_equal
    from lmh_utils.try_.try_ import Try
    from .test_case import test_case_0, test_case_1, test_case_2, test_case_3, test_case_4

    # Calling the Try.filter method with the case of True
    assert_equal(
        True,
        isinstance(
            test_case_0(),
            Try
        )
    )

    # Calling the Try.filter method with the case of True
    assert_equal(
        True,
        isinstance(
            test_case_1(),
            Try
        )
    )

    # Calling the Try.filter method with the case of True
    assert_equal(
        True,
        isinstance(
            test_case_2(),
            Try
        )
    )

# Generated at 2022-06-26 00:00:15.467975
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert not Try.of(lambda: True).on_fail(lambda x: True).is_success
    assert not Try.of(lambda: raise_exception()).on_fail(lambda x: True).is_success
    assert Try.of(lambda: True).on_fail(lambda x: False).is_success


# Generated at 2022-06-26 00:00:19.241213
# Unit test for method get of class Try
def test_Try_get():
    assert Try(123, True).get() == 123


# Generated at 2022-06-26 00:00:26.181424
# Unit test for constructor of class Try
def test_Try():

    bool_0 = True
    bool_1 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_1)

    assert try_0.is_success == bool_0
    assert try_0.value == bool_0
    assert try_1.is_success == bool_1
    assert try_1.value == bool_1
    assert try_0 != try_1


# Generated at 2022-06-26 00:00:32.480212
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_1 = True
    try_1 = Try(bool_1, bool_1)

    def success_callback(value):
        value = not value

    def fail_callback(value):
        value = not value

    try_1.on_success(success_callback)
    assert try_1.get() is True

    try_1.is_success = False
    assert try_1.get() is True
    try_1.on_fail(fail_callback)
    assert try_1.get() is False


# Generated at 2022-06-26 00:00:36.450904
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Simple test with Try(True, True).

    :return: None
    """
    boolean_1 = True
    try_1 = Try(boolean_1, True).filter(lambda x: True)


# Generated at 2022-06-26 00:00:37.930055
# Unit test for method get of class Try
def test_Try_get():
    assert Try(3, True).get() == 3
    assert Try(None, False).get() is None


# Generated at 2022-06-26 00:00:44.053489
# Unit test for method filter of class Try
def test_Try_filter():
    # noinspection PyTypeChecker
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 0) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)

    assert Try({'a': 1}, True).filter(lambda x: 'a' in x) == Try({'a': 1}, True)
    assert Try({'a': 1}, True).filter(lambda x: 'b' in x) == Try({'a': 1}, False)
    assert Try({'a': 1}, False).filter(lambda x: 'b' in x) == Try({'a': 1}, False)


# Generated at 2022-06-26 00:00:47.349598
# Unit test for constructor of class Try
def test_Try():
    # False, False
    test_case_0()
    # False, True
    test_case_1()
    # True, False
    test_case_2()
    # True, True
    test_case_3()

# Generated at 2022-06-26 00:00:50.104550
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    monad_0 = Try(1, True)
    monad_1 = monad_0.on_fail(lambda x: x)
    assert monad_0 == monad_1


# Generated at 2022-06-26 00:01:15.429894
# Unit test for method bind of class Try
def test_Try_bind():
    def test_case_0():
        bool_0 = False
        try_0 = Try(bool_0, bool_0)
        assert isinstance(try_0, Try)
        def binder_0(arg_0):
            assert arg_0 == bool_0
            return Try(bool_0, not bool_0)
        try_0_binder_0 = try_0.bind(binder_0)
        assert isinstance(try_0_binder_0, Try)
        assert try_0_binder_0 == Try(bool_0, not bool_0)

        bool_1 = True
        try_1 = Try(bool_1, bool_1)
        assert isinstance(try_1, Try)
        def binder_1(arg_1):
            assert arg_1 == bool_1


# Generated at 2022-06-26 00:01:17.903260
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_0 = Try(True, True)
    assert 'Try[value=True, is_success=True]' == str(try_0)


# Generated at 2022-06-26 00:01:27.460715
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(v):
        return v

    bool_0 = True
    try_0 = Try(bool_0, bool_0).filter(filterer)
    bool_1 = True
    bool_2 = try_0.is_success
    bool_3 = try_0.value
    bool_4 = bool_1 == bool_2 and bool_2 == bool_3

    bool_0 = False
    try_0 = Try(bool_0, bool_0).filter(filterer)
    bool_1 = False
    bool_2 = try_0.is_success
    bool_3 = try_0.value
    bool_5 = bool_1 == bool_2 and bool_2 == bool_3

    bool_0 = True

# Generated at 2022-06-26 00:01:29.722223
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(None, False).get_or_else(0) == 0


# Generated at 2022-06-26 00:01:35.783044
# Unit test for method map of class Try
def test_Try_map():
    assert(Try(1, True).map(lambda s: s + 1) == Try(2, True))
    assert(Try(1, False).map(lambda s: s + 1) == Try(1, False))

    with pytest.raises(TypeError, message="unsupported operand type(s) for +: 'int' and 'str'"):
        assert(Try(1, True).map(lambda s: s + '1'))

    assert(Try(1, False).map(lambda s: s + '1') == Try(1, False))



# Generated at 2022-06-26 00:01:45.289737
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = False
    bool_1 = True
    str_0 = "test"
    int_0 = 0
    int_1 = 1
    obj_0 = {
        "attr_0": 0,
        "attr_1": 1
    }
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_1)
    try_2 = Try(str_0, bool_0)
    try_3 = Try(str_0, bool_1)
    try_4 = Try(int_0, bool_0)
    try_5 = Try(int_1, bool_1)
    try_6 = Try(obj_0, bool_0)
    try_7 = Try(obj_0, bool_1)

    global_value = 0



# Generated at 2022-06-26 00:01:46.824061
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert(str(Try(1, True)) == 'Try[value=1, is_success=True]')



# Generated at 2022-06-26 00:01:55.064836
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    error_message = 'error message'
    error_message_2 = 'error message 2'
    is_success = False

    try_0 = Try(error_message, is_success)
    fail_callback = lambda x: print(x)

    try_0.on_fail(fail_callback)

    try_1 = Try(error_message, not is_success)
    try_1.on_fail(fail_callback)

    try_2 = Try(error_message_2, is_success)
    try_2.on_fail(fail_callback)

    try_3 = Try(error_message_2, not is_success)
    try_3.on_fail(fail_callback)



# Generated at 2022-06-26 00:01:57.554870
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    expected = Try(True, True)

    # When
    actual = Try.of(bool, 1).filter(lambda x: x)

    # Then
    actual == expected


# Generated at 2022-06-26 00:02:03.550704
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try\
        .of(lambda: 10)\
        .bind(lambda a: Try.of(lambda: a % 2)) == Try(0, True)

    assert Try\
        .of(divmod, 10, 0)\
        .bind(lambda a: Try.of(lambda: a[0] % a[1])) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-26 00:02:38.556153
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    on_fail method return self when monad is successfully.
    """
    bool_0 = True
    value_0 = 'Successfully'
    try_0 = Try(value_0, bool_0)
    try_1 = try_0.on_fail(lambda e: e.lower())
    assert try_0 == try_1


# Generated at 2022-06-26 00:02:42.031395
# Unit test for method map of class Try
def test_Try_map():
    try_0 = Try(True, True)
    try_1 = try_0.map(lambda x: x)
    assert try_1.value == True
    assert try_1.is_success == True
    assert try_0 == try_1


# Generated at 2022-06-26 00:02:45.829043
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try(5, True)
    try_1 = Try(5, True)

    assert try_0 == try_1


# Generated at 2022-06-26 00:02:49.112737
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = False
    try_0: Try[bool] = Try(bool_0, bool_0)
    try_1: Try[bool] = try_0.on_fail(lambda value: print(value))
    assert(try_1 == try_0)


# Generated at 2022-06-26 00:02:52.229963
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, True).filter(lambda x: True).get() is True
    assert Try.of(lambda x: x, True).filter(lambda x: False).get() is False



# Generated at 2022-06-26 00:02:58.268246
# Unit test for method on_success of class Try
def test_Try_on_success():
    test_case_0()
    try_1 = Try(1, True)
    try_1.on_success(lambda x: print("True"))

    try_2 = Try(0, False)
    try_2.on_success(lambda x: print("False"))

    try_3 = Try(0, True)
    try_3.on_success(lambda x: print("False"))

    assert try_1.get() == 1
    assert try_2.get() == 0
    assert try_3.get() == 0



# Generated at 2022-06-26 00:03:03.835434
# Unit test for method filter of class Try
def test_Try_filter():
    def test_0():
        def filterer(value):
            return value > 42
        try_0 = Try(42, True)
        try_1 = try_0.filter(filterer)
        assert try_1.is_success
        assert not Try(42, False).filter(filterer).is_success
    def test_1():
        def filterer(value):
            return value > 42
        try_0 = Try(43, True)
        try_1 = try_0.filter(filterer)
        assert not try_1.is_success
        assert not Try(43, False).filter(filterer).is_success
    test_0()
    test_1()
