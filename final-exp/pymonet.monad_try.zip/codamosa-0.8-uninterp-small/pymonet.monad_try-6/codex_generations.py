

# Generated at 2022-06-25 23:53:12.627038
# Unit test for method filter of class Try
def test_Try_filter():
    # Test case 1
    int_0 = 3
    bool_0 = True
    try_0 = Try(int_0, bool_0)

    try_1 = try_0.filter(lambda x: x % 2 == 0)

    assert try_1 != try_0
    assert try_1.is_success == False
    assert try_1.value == int_0

    # Test case 2
    int_1 = 2
    bool_1 = True
    try_2 = Try(int_1, bool_1)

    try_3 = try_2.filter(lambda x: x % 2 == 0)

    assert try_3 != try_2
    assert try_3.is_success == True
    assert try_3.value == int_1



# Generated at 2022-06-25 23:53:20.142903
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 7
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    filterer = lambda x: x == 5
    try_1 = try_0.filter(filterer)
    assert try_0 != try_1
    assert try_0.is_success and not try_1.is_success
    assert try_0.value == try_1.value


# Generated at 2022-06-25 23:53:30.958467
# Unit test for method filter of class Try
def test_Try_filter():
    test_0_0 = lambda n: n > 0
    test_0_1 = Try.of(lambda: 1)
    assert test_0_1.filter(test_0_0) == Try(1, True)
    test_0_2 = Try.of(lambda: -1)
    assert test_0_2.filter(test_0_0) == Try(-1, False)
    test_0_3 = Try.of(lambda: 'a')
    assert test_0_3.filter(test_0_0) == Try('a', False)
    test_1_0 = lambda n: n < 0
    test_1_1 = Try.of(lambda: 1)
    assert test_1_1.filter(test_1_0) == Try(1, False)

# Generated at 2022-06-25 23:53:37.719805
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 1
    int_1 = 3
    int_2 = 0
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    lambda_0 = lambda x: x > int_1
    try_0.filter(lambda_0)
    int_3 = 3
    bool_1 = True
    try_1 = Try(int_3, bool_1)
    lambda_1 = lambda x: x == int_1
    try_1.filter(lambda_1)
    int_4 = 3
    bool_2 = True
    try_2 = Try(int_4, bool_2)
    lambda_2 = lambda x: x < int_1
    try_2.filter(lambda_2)
    int_5 = 3
    bool_3 = True
    try_

# Generated at 2022-06-25 23:53:44.273060
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.

    :returns: assertion result
    :rtype: Boolean
    """
    def filterer(value):
        return value == 0

    assert Try(0, True).filter(filterer) == Try(0, True)
    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(0, False).filter(filterer) == Try(0, False)
    assert Try(1, False).filter(filterer) == Try(1, False)
    return True



# Generated at 2022-06-25 23:53:54.071872
# Unit test for method filter of class Try
def test_Try_filter():
    int_1 = 1300
    bool_1 = True
    try_1 = Try(int_1, bool_1)
    try_1_filterer_0 = lambda number: len(str(number)) == 4
    bool_2 = False
    try_2 = Try(int_1, bool_2)
    try_2_filterer_0 = lambda number: len(str(number)) == 4
    assert try_1.filter(try_1_filterer_0) == try_2.filter(try_2_filterer_0)
    assert try_1.filter(try_1_filterer_0).get() == int_1
    assert try_1.filter(try_1_filterer_0).get_or_else(1) == int_1

# Generated at 2022-06-25 23:54:03.202498
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    assert_equal(try_0, try_0.filter(lambda v: True))

    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    assert_equal(Try(int_0, False), try_0.filter(lambda v: False))

    int_0 = -13
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    assert_equal(None, try_0.filter(lambda v: True))

    int_0 = -13
    bool_0 = True
    try_0 = Try(int_0, bool_0)

# Generated at 2022-06-25 23:54:13.411003
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 13
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    try_1 = try_0.filter(lambda n: n > 0)
    assert try_0.value == 13
    assert try_0.is_success
    assert try_1.value == 13
    assert try_1.is_success
    assert not (try_0 is try_1)
    assert try_0 == try_1
    try_2 = try_0.filter(lambda n: n % 2)
    assert try_2.value == 13
    assert try_2.is_success
    assert not (try_0 is try_2)
    assert try_0 == try_2



# Generated at 2022-06-25 23:54:16.633067
# Unit test for method filter of class Try
def test_Try_filter():
    """Test filter method of class Try"""

    assert Try(0, True).filter(lambda x: x % 2 == 0) == Try(0, True)
    assert Try(1, True).filter(lambda x: x % 2 == 0) == Try(1, False)


# Generated at 2022-06-25 23:54:27.276700
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(42, True).filter(lambda x: x > 0) == Try(42, True)
    assert Try(42, True).filter(lambda x: x < 0) == Try(42, False)
    assert Try(42, False).filter(lambda x: x > 0) == Try(42, False)
    try_0 = Try(42, True).filter(lambda x: x > 100)
    assert try_0 == Try(42, False)
    try_0 = Try(42, True).filter(lambda x: x > 100)
    assert try_0 != Try(42, True)


# Generated at 2022-06-25 23:54:35.999292
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    def lambda_0(x):
        return x > 5
    try_1 = Try(int_0, False)
    try_2 = try_0.filter(lambda_0)
    assert try_2 == try_0
    try_3 = try_1.filter(lambda_0)
    assert try_3 == try_1


# Generated at 2022-06-25 23:54:39.322563
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda: int('abc')).filter(lambda x: x < 10)
    assert not result.is_success


# Generated at 2022-06-25 23:54:45.466115
# Unit test for method filter of class Try
def test_Try_filter():
    """
    => filter : Function(A) -> Boolean
    """
    int_0 = -13
    bool_0 = False
    def filter_0(arg_0):
        return arg_0 < 0
    try_0 = Try(int_0, bool_0)
    try_1 = try_0.filter(filter_0)
    assert try_1 == Try(int_0, bool_0)


# Generated at 2022-06-25 23:54:56.900106
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)

    int_1 = 1
    bool_1 = True
    try_1 = Try(int_1, bool_1)

    int_2 = 42
    bool_2 = True
    try_2 = Try(int_2, bool_2)

    bool_3 = bool_1
    filter_0 = lambda x: bool_3
    filter_1 = filter_0

    # Case 0
    assert isinstance(try_0.filter(filter_1), Try)


# Generated at 2022-06-25 23:55:08.256306
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(10, True)
    try_1 = try_0.filter(lambda x: x > 0)
    assert try_1.is_success == True
    assert try_1.value == 10

    try_1 = try_0.filter(lambda x: x < 0)
    assert try_1.is_success == False
    assert try_1.value == 10

    try_0 = Try(10, False)
    try_1 = try_0.filter(lambda x: x > 0)
    assert try_1.is_success == False
    assert try_1.value == 10


# Generated at 2022-06-25 23:55:15.993858
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filter():
        def filterer(int_0):
            bool_0 = False
            if int_0 > 0:
                bool_0 = True
            return bool_0

        int_0 = -13
        bool_0 = False
        try_0 = Try(int_0, bool_0)
        try_1 = try_0.filter(filterer)
        bool_1 = False
        try_2 = Try(int_0, bool_1)
        assert try_1 == try_2

    test_filter()


# Generated at 2022-06-25 23:55:22.856027
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 13
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    try_1 = try_0.filter(lambda x : x == int_0)
    assert (not try_1.is_success) and try_1.value == int_0
    try_2 = try_0.filter(lambda x : x > 10)
    assert try_2.is_success and try_2.value == int_0


# Generated at 2022-06-25 23:55:30.320311
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    def filterer(x):
        return (not (x < 0))
    try_1 = try_0.filter(filterer)

    if (try_1.is_success == False):
        assert True
    else:
        assert False


# Generated at 2022-06-25 23:55:38.948715
# Unit test for method filter of class Try
def test_Try_filter():
    # Test: case with error in mapper function.
    # In this case method return not successfully with previous value.
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)

    def filterer(x: int) -> bool:
        return x > 0

    try_1 = try_0.filter(filterer)

    assert try_1 == Try(int_0, False)

    # Test: case with successful mapper function.
    # In this case method return not successfully with previous value.
    int_0 = 13
    bool_0 = True
    try_0 = Try(int_0, bool_0)

    def filterer(x: int) -> bool:
        return x > 0


# Generated at 2022-06-25 23:55:51.155430
# Unit test for method filter of class Try
def test_Try_filter():
    # Test if filter applied on successful monad returns copy of monad
    def filterer_1(mapper_arg):
        return True

    def filterer_2(mapper_arg):
        return False

    def mapper(mapper_arg):
        return mapper_arg

    def binder(binder_arg):
        return Try(binder_arg, bool_0)

    int_0 = 0
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    try_1 = try_0.bind(binder).map(mapper)

    assert try_1.filter(filterer_1) == try_0,\
        'filter applied on successful monad returns copy of monad'

    # Test if filter applied on unsuccessful monad returns copy of monad

# Generated at 2022-06-25 23:55:56.433282
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 10
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    assert try_0.filter(lambda x: x > 5) == try_0


# Generated at 2022-06-25 23:56:00.387884
# Unit test for method filter of class Try
def test_Try_filter():
    string_0 = "foo"
    int_0 = 0
    bool_0 = False
    try_0 = Try(string_0, bool_0)

    try_1 = try_0.filter(lambda ref_0: len(ref_0) < 10)

    assert try_1.get() == string_0


# Generated at 2022-06-25 23:56:04.997751
# Unit test for method filter of class Try
def test_Try_filter():
    value_0 = -1
    is_success_0 = True
    try_0 = Try(value_0, is_success_0)
    value_1 = 2
    is_success_1 = True
    try_1 = Try(value_1, is_success_1)
    bool_1 = True
    def filterer(value):
        return bool_1
    try_2 = try_0.filter(filterer)

# Generated at 2022-06-25 23:56:16.333387
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    cond_bool_0 = lambda a: True
    try_0.filter(cond_bool_0)
    int_1 = 100
    bool_1 = True
    try_1 = Try(int_1, bool_1)
    try_1.filter(cond_bool_0)
    int_2 = 0
    bool_2 = True
    try_2 = Try(int_2, bool_2)
    try_2.filter(cond_bool_1)
    int_3 = 0
    bool_3 = True
    try_3 = Try(int_3, bool_3)
    try_3.filter(cond_bool_1)
    int_4 = 1
    bool_

# Generated at 2022-06-25 23:56:23.234805
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    int_1 = 99
    bool_0 = False
    bool_1 = True
    try_0 = Try(int_0, bool_0)
    try_1 = Try(int_1, bool_1)
    try_0 = try_0.filter(lambda x: x > 0)
    try_1 = try_1.filter(lambda x: x > 0)
    assert try_0.is_success == False
    assert try_1.is_success == True


# Generated at 2022-06-25 23:56:29.662495
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)

    success_result = isinstance(try_0, Try)
    assert success_result

    success_result = try_0.filter(lambda x: x <= 0) == Try(int_0, bool_0)
    assert success_result

    success_result = try_0.filter(lambda x: x > 0) == Try(int_0, False)
    assert success_result



# Generated at 2022-06-25 23:56:35.933465
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 13
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    int_1 = int_0 * 2
    try_1 = try_0.filter(lambda i: i == int_1)
    assert not try_1.is_success

    int_2 = int_0
    try_2 = try_0.filter(lambda i: i == int_2)
    assert try_2.is_success
    assert try_0 == try_2


# Generated at 2022-06-25 23:56:47.301135
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    bool_1 = try_0.filter(lambda v: True)
    int_1 = try_0.filter(lambda v: True).get()
    bool_2 = try_0.filter(lambda v: v == -13).get()
    bool_3 = try_0.filter(lambda v: v != -13).is_success
    int_2 = try_0.filter(lambda v: False).get()
    bool_4 = try_0.filter(lambda v: False).is_success
    int_3 = Try.of(lambda: int_0, int_0).filter(lambda v: v == -13).get()

# Generated at 2022-06-25 23:56:52.411592
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)

    def filterer(x):
        return x == int_0

    try_1 = try_0.filter(filterer)

    assert try_1.is_success == False and try_1.get() == int_0


# Generated at 2022-06-25 23:57:00.119271
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test case using filter method of Try control.
    """
    int_0 = 6
    bool_0 = True
    # try_0: Try[int] = Try(int_0, bool_0)
    # for me this test case always returns False
    try_0 = Try(int_0, bool_0).filter(lambda value: value > 5)
    if try_0.is_success:
        print("Value greater than 5")
    else:
        print("Value is less or equal to 5")

test_Try_filter()

# Generated at 2022-06-25 23:57:13.853422
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    int_1 = 100
    int_2 = int_0

    try_0 = Try(int_0, True)
    try_1 = Try(int_1, True)
    try_2 = Try(int_2, True)
    try_list_0 = [try_0, try_1, try_2]
    try_val_0 = [try_0.get(), try_1.get(), try_2.get()]
    fn_0 = lambda try_val: try_val > 0
    fn_1 = lambda try_val: try_val == 0

    for monad in try_list_0:
        assert monad.filter(fn_0).get() > 0

    for monad in try_list_0:
        assert monad.filter(fn_1).get

# Generated at 2022-06-25 23:57:18.404902
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    def function_0(s0):
        return (s0 < 0)
    v0 = try_0.filter(function_0)
    v1 = Try(int_0, bool_0)

    assert v0 == v1


# Generated at 2022-06-25 23:57:23.045670
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    def filter_0(value):
        return value > 0

    def filterer_0():
        return filter_0
    int_0 = 9
    bool_1 = True
    def filter_1(value):
        return value > 0
    try_0 = Try(int_0, bool_1)
    try_0.filter(filter_1)


# Generated at 2022-06-25 23:57:33.119757
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    try_1 = try_0.filter(lambda x: x > 0)
    bool_1 = try_1.is_success
    print(bool_1)
    int_1 = 1
    bool_2 = bool_1 == bool_0
    print(bool_2)
    try_2 = try_0.filter(lambda x: x < 0)
    bool_3 = try_2.is_success
    print(bool_3)
    int_2 = 1
    bool_4 = bool_3 == bool_0
    print(bool_4)
    int_3 = 0
    bool_5 = bool_4 == bool_0
    print(bool_5)
    try_3

# Generated at 2022-06-25 23:57:41.771820
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer_0(val):
        return True

    def filterer_1(val):
        return False

    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    try_1 = Try(int_0, bool_0)
    try_2 = Try(-13, True)
    try_3 = Try(-13, True)
    try_0.filter(filterer_0)
    print(try_0)
    try_1.filter(filterer_1)
    print(try_1)
    try_2.filter(filterer_0)
    print(try_2)
    try_3.filter(filterer_1)
    print(try_3)

# Unit

# Generated at 2022-06-25 23:57:52.082962
# Unit test for method filter of class Try
def test_Try_filter():
    test_0_1 = Try(0, True).filter(lambda x: x % 2 == 0)
    test_0_2 = Try(1, True).filter(lambda x: x % 2 == 0)
    test_0_3 = Try(0, False).filter(lambda x: x % 2 == 0)
    assert test_0_1 == Try(0, True)
    assert test_0_2 == Try(1, False)
    assert test_0_3 == Try(0, False)

    test_1_1 = Try(True, True).filter(lambda x: x)
    test_1_2 = Try(False, True).filter(lambda x: x)
    test_1_3 = Try(True, False).filter(lambda x: x)
    assert test_1_1 == Try(True, True)
   

# Generated at 2022-06-25 23:57:57.239983
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(0, True).filter(lambda x: x > 0) == Try(0, False)
    assert Try(0, True).filter(lambda x: x == 0) == Try(0, True)
    assert Try(0, False).filter(lambda x: x > 0) == Try(0, False)
    assert Try(0, False).filter(lambda x: x == 0) == Try(0, False)



# Generated at 2022-06-25 23:58:02.363621
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 123
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    def method_0(int_0, int_1):
        return int_0 > int_1
    int_1 = 100
    bool_1 = try_0.filter(method_0, int_1)
    assert bool_1.get() == bool_0 and bool_1.is_success == bool_0


# Generated at 2022-06-25 23:58:07.431624
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        if value < 0:
            return True
        return False

    try_0 = Try(int(-1), bool(True))
    try_1 = Try(int(1), bool(True))
    try_2 = Try(int(0), bool(True))
    try_3 = Try(int(-1), bool(False))
    try_4 = Try(int(1), bool(False))
    try_5 = Try(int(0), bool(False))

    try_6 = try_0.filter(filterer)
    assert try_6.get() == -1
    assert try_6.is_success == True

    try_7 = try_1.filter(filterer)
    assert try_7.get() == 1
    assert try_7.is_success == False



# Generated at 2022-06-25 23:58:18.930467
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    try_1 = Try.filter(try_0, lambda x: x > 0)
    if (not Try.get(try_1)):
        raise ValueError('try_1 failed')
    if (Try.is_success(try_1)):
        raise ValueError('try_1 failed')
    int_1 = 18
    bool_1 = True
    try_2 = Try(int_1, bool_1)
    try_3 = Try.filter(try_2, lambda x: x > 0)
    if (not Try.get(try_3)):
        raise ValueError('try_3 failed')
    if (not Try.is_success(try_3)):
        raise ValueError

# Generated at 2022-06-25 23:58:24.928296
# Unit test for method filter of class Try
def test_Try_filter():
    """ function : test_Try_filter """
    int_0 = -13
    bool_0 = True
    try_0 = Try(int_0, bool_0)

    bool_1 = True
    bool_2 = True
    if not (try_0.filter(lambda int_1: bool_1) == Try(int_0, bool_2)):
        raise RuntimeError('Assertion failed')



# Generated at 2022-06-25 23:58:31.200304
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try
    """
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    def f_0(arg_0):
        assert arg_0 == int_0
        return bool_0
    try_1 = try_0.filter(f_0)
    assert try_1 == Try(int_0, bool_0)


# Generated at 2022-06-25 23:58:39.105400
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)

    is_negative = lambda v: v < 0
    try_filter_0 = try_0.filter(is_negative)
    assert try_filter_0 == Try(-13, True)

    int_1 = 13
    bool_1 = True
    try_1 = Try(int_1, bool_1)
    try_filter_1 = try_1.filter(is_negative)
    assert try_filter_1 == Try(13, False)


# Generated at 2022-06-25 23:58:46.608670
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 0

    int_0 = 0
    bool_0 = True
    try_1 = Try(int_0, bool_0)
    try_2 = try_1.filter(filterer)
    assert not try_2.is_success
    assert try_2.get() == 0
    assert try_1 == try_2

    int_0 = 3
    try_3 = Try(int_0, bool_0)
    try_4 = try_3.filter(filterer)
    assert try_4.is_success
    assert try_4 == try_3
    assert try_4.get() == 3


# Generated at 2022-06-25 23:58:54.401941
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(lambda x: x ** 3, 3)
    assert try_0.is_success
    try_1 = try_0.filter(lambda x: x == 27)
    try_2 = try_0.filter(lambda x: x == 0)
    assert isinstance(try_1, Try)
    assert isinstance(try_2, Try)
    assert try_1.is_success
    assert not try_2.is_success
    assert try_1.value == 27
    assert try_2.value == 27


# Generated at 2022-06-25 23:59:05.877862
# Unit test for method filter of class Try
def test_Try_filter():
    def test_case_0():
        int_0 = 5
        bool_0 = True
        try_0 = Try(int_0, bool_0)

        def filterer_0(a):
            return a > 0

        try_1 = try_0.filter(filterer_0)

        assert try_0.value == int_0
        assert try_0.is_success and try_1.is_success
        assert try_1.value == int_0

    def test_case_1():
        int_0 = -13
        bool_0 = False
        try_0 = Try(int_0, bool_0)

        def filterer_0(a):
            return a > 0

        try_1 = try_0.filter(filterer_0)


# Generated at 2022-06-25 23:59:09.723914
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 12
    bool_0 = True

    def f(x: int):
        return x < 0

    try_0 = Try(int_0, bool_0)
    try_1 = try_0.filter(f)

    try_2 = Try(int_0, False)

    assert try_1 == try_2

# Generated at 2022-06-25 23:59:16.017952
# Unit test for method filter of class Try
def test_Try_filter():

    def func_0(int_0):
        if int_0 > 0:
            return True
        return False

    int_0 = 13
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    try_1 = try_0.filter(func_0)
    assert try_1.is_success is True
    assert try_1.value == int_0

    int_1 = -13
    bool_1 = True
    try_2 = Try(int_1, bool_1)
    try_3 = try_2.filter(func_0)
    assert try_3.is_success is False
    assert try_3.value == int_1



# Generated at 2022-06-25 23:59:24.669698
# Unit test for method filter of class Try
def test_Try_filter():
    from unittest import TestCase, main

    class TryFilterTest(TestCase):
        def test_filter_0(self):
            int_0 = 0
            bool_0 = False
            try_0 = Try(int_0, bool_0)
            bool_1 = True
            try_1 = Try(int_0, bool_1)

            def filterer(value):
                return True

            self.assertTrue(try_0.filter(filterer).is_success)
            self.assertTrue(try_1.filter(filterer).is_success)

        def test_filter_1(self):
            int_0 = 0
            bool_0 = False
            try_0 = Try(int_0, bool_0)
            bool_1 = True

# Generated at 2022-06-25 23:59:30.896737
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x == 5) == Try(5, True)
    assert Try(5, True).filter(lambda x: x == 0) == Try(5, False)
    assert Try(5, False).filter(lambda x: x == 5) == Try(5, False)
    assert Try(ValueError(""), True).filter(lambda x: x == 5) == Try(ValueError(""), False)


# Generated at 2022-06-25 23:59:38.193865
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 0
    int_1 = int_0 + 1
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    try_1 = Try(int_1, bool_0)
    filterer = lambda int_0: int_0 == int_1
    try_0 = try_0.filter(filterer)
    assert try_1 == try_0



# Generated at 2022-06-25 23:59:46.924294
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    str_0 = 'Any string'
    bool_1 = True
    try_1 = Try(str_0, bool_1)
    bool_2 = True
    try_2 = Try(int_0, bool_2)
    str_1 = 'This is wrong'
    bool_3 = False
    try_3 = Try(str_1, bool_3)
    try_4 = try_0.filter(lambda x: x > 0)
    try_5 = try_1.filter(lambda x: x == 'Any string')
    try_6 = try_2.filter(lambda x: x > 0)
    try_7 = try_3.filter(lambda x: x > 0)


# Generated at 2022-06-25 23:59:52.296287
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    try_0 = Try(-1, True)
    try_1 = try_0.filter(lambda x: x > 0)
    try_2 = try_0.filter(lambda x: x < 0)
    try_3 = try_0.filter(lambda x: x == 0)

    assert isinstance(try_0, Try)
    assert try_0 == Try(-1, True)
    assert try_1 == Try(-1, False)
    assert try_2 == Try(-1, True)
    assert try_3 == Try(-1, False)



# Generated at 2022-06-26 00:00:01.609804
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 3
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    int_1 = 4
    bool_1 = False
    try_1 = Try(int_1, bool_1)
    int_2 = -2
    bool_2 = True
    try_2 = Try(int_2, bool_2)
    int_3 = -3
    bool_3 = False
    try_3 = Try(int_3, bool_3)
    #
    int_4 = -2
    bool_4 = False
    try_4 = Try(int_4, bool_4)
    int_5 = 4
    bool_5 = True
    try_5 = Try(int_5, bool_5)
    int_6 = 5
    bool_6 = False

# Generated at 2022-06-26 00:00:08.323253
# Unit test for method filter of class Try
def test_Try_filter():
    def is_zero(x):
        return x == 0

    assert Try(0, True).filter(is_zero) == Try(0, True)
    assert Try(1, True).filter(is_zero) == Try(1, False)
    assert Try(Exception('error'), False).filter(is_zero) == Try(Exception('error'), False)


# Generated at 2022-06-26 00:00:17.062435
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    int_0 = 2
    int_1 = -5
    try_0 = Try(int_0, bool_0)
    try_1 = Try(int_1, bool_0)
    try_2 = try_1.filter(lambda x: x > 0)
    try_3 = try_1.filter(lambda x: x < 0)
    try_4 = try_0.filter(lambda x: x > 0)
    assert(try_0.is_success == bool_0)
    assert(try_1.is_success == bool_0)
    assert(try_2.is_success == bool_0)
    assert(try_3.is_success == bool_0)
    assert(try_4.is_success == bool_0)

# Generated at 2022-06-26 00:00:28.486816
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = 0
    bool_0 = False
    try_0 = Try(int_0, bool_0)

    int_1 = -1
    bool_1 = False
    try_1 = Try(int_1, bool_1)

    int_2 = 2
    bool_2 = True
    try_2 = Try(int_2, bool_2)

    int_3 = 13
    bool_3 = True
    try_3 = Try(int_3, bool_3)

    filterer_0 = lambda n: n > 0
    filterer_1 = lambda n: n < 0
    filterer_2 = lambda n: n == 0

    assert try_0.filter(filterer_0).is_success == False
    assert try_0.filter(filterer_1).is_

# Generated at 2022-06-26 00:00:34.885153
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    def func_0(obj_0):
        obj_0 = obj_0 * 2
        bool_1 = obj_0 < 0
        return bool_1
    try_1 = try_0.filter(func_0)
    int_1 = try_1.get()
    assert int_0 == int_1


# Generated at 2022-06-26 00:00:47.104117
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -17
    int_1 = 17
    bool_0 = False
    def add(x, y):
        return x + y
    try_0 = Try.of(add, int_0, int_1)
    try_1 = try_0.filter(lambda x : x >= 18)
    assert not (try_1.value == None or try_1.is_success == None)
    assert try_1.value == add(int_0, int_1)
    assert try_1.is_success == bool_0


# Generated at 2022-06-26 00:00:54.174994
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    fn_0 = lambda x: True if x < -5 else False
    try_1 = try_0.filter(fn_0)
    assert try_1.value == int_0
    assert try_1.is_success == False
    int_1 = -12
    try_2 = Try(int_1, bool_0)
    try_3 = try_2.filter(fn_0)
    assert try_3.value == int_1
    assert try_3.is_success == True


# Generated at 2022-06-26 00:00:59.309491
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    result = try_0.filter(lambda x: x >= 0)
    assert result == Try(-13, False)


# Generated at 2022-06-26 00:01:03.195800
# Unit test for method filter of class Try
def test_Try_filter():
    # Arrange
    int_0 = -13
    bool_0 = False
    def filterer_0(value):
        return value < 0
    try_0 = Try(int_0, bool_0)
    # Act
    try_0.filter(filterer_0)
    # Assert


# Generated at 2022-06-26 00:01:05.860985
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)


# Generated at 2022-06-26 00:01:11.479725
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 0
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    try_1 = try_0.filter(filterer)
    assert try_0 == try_1



# Generated at 2022-06-26 00:01:23.191122
# Unit test for method filter of class Try

# Generated at 2022-06-26 00:01:30.944707
# Unit test for method filter of class Try
def test_Try_filter():
    # Apply on not successfully Try
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    try_0 = try_0.filter(lambda x: x > 0)
    assert not try_0.is_success and try_0.value == int_0

    # Apply on successfully Try
    int_1 = 13
    bool_1 = True
    try_1 = Try(int_1, bool_1)
    try_1 = try_1.filter(lambda x: x > 0)
    assert try_1.is_success and try_1.value == int_1


# Generated at 2022-06-26 00:01:36.169051
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    assert try_0.filter(lambda x: False) == Try(int_0, False)
    int_1 = 0
    bool_1 = True
    try_1 = Try(int_1, bool_1)
    assert try_1.filter(lambda x: True) == Try(int_1, True)


# Generated at 2022-06-26 00:01:45.715211
# Unit test for method filter of class Try
def test_Try_filter():
    # 1 cross-test + 3 positive-tests + 3 negative-tests = 7 tests
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    int_1 = None
    bool_1 = True
    try_1 = Try(int_1, bool_1)
    int_2 = 78
    bool_2 = True
    try_2 = Try(int_2, bool_2)
    def filterer_0(value):
        return value > 0
    bool_3 = try_0.filter(filterer_0) == Try(int_0, False)
    bool_4 = try_1.filter(filterer_0) == Try(int_1, False)
    bool_5 = try_2.filter(filterer_0)

# Generated at 2022-06-26 00:01:54.943090
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Asserts:
        1. filter function of class Try create new Try monad from existing monad Try.
        2. filter function of class Try return same monad when monad is not successfully.
    """
    # arrange
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)
    # act
    try_1 = try_0.filter(lambda x: x > 0)
    try_2 = try_1.filter(lambda x: x > 0)
    # assert
    assert try_2 != try_0 == try_1
    assert try_1.is_success == False
    assert try_1.get() == -13
    assert try_2.is_success == False
    assert try_2.get() == -13

# Unit test

# Generated at 2022-06-26 00:02:05.409991
# Unit test for method filter of class Try
def test_Try_filter():
    int_0 = -13
    bool_0 = False
    try_0 = Try(int_0, bool_0)

    int_1 = 13
    bool_1 = True
    try_1 = Try(int_1, bool_1)

    int_2 = -13
    bool_2 = True
    try_2 = Try(int_2, bool_2)

    def is_positive(x):
        if x > 0:
            return True
        else:
            return False

    def is_negative(x):
        if x < 0:
            return True
        else:
            return False

    def is_zero(x):
        if x == 0:
            return True
        else:
            return False

    try_0_filtered_0 = try_0.filter(is_positive)

# Generated at 2022-06-26 00:02:12.629147
# Unit test for method filter of class Try
def test_Try_filter():
    bool_1 = True
    bool_2 = False
    try_1 = Try(bool_1, bool_1)
    try_2 = Try(bool_2, bool_1)
    try_3 = Try(bool_1, bool_2)
    try_4 = Try(bool_2, bool_2)
    try_5 = Try(bool_1, bool_1)

    def test_1(value):
        assert value == bool_1
        return True

    def test_2(value):
        assert value == bool_1
        return False

    assert try_1.filter(test_1) == Try(bool_1, bool_1)
    assert try_1.filter(test_2) == Try(bool_1, bool_2)

# Generated at 2022-06-26 00:02:20.868077
# Unit test for method filter of class Try
def test_Try_filter():
    # test_case_0
    def test_case_0():
        bool_0 = True
        try_0 = Try(bool_0, bool_0)
        try_1 = try_0.filter(lambda x: x)
        try_2 = Try(bool_0, bool_0)
        assert try_1 == try_2
    test_case_0()

    # test_case_1
    def test_case_1():
        bool_0 = False
        try_0 = Try(bool_0, bool_0)
        try_1 = try_0.filter(lambda x: x)
        try_2 = Try(bool_0, False)
        assert try_1 == try_2
    test_case_1()

    # test_case_2
    def test_case_2():
        bool

# Generated at 2022-06-26 00:02:29.027492
# Unit test for method filter of class Try
def test_Try_filter():

    def filterer(x):
        return x

    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    filter_0 = filterer(bool_0)
    if filter_0:
        x = try_0.filter(filterer)
        x = x.get()
        assert isinstance(x, bool)

    def filterer(x):
        return x

    bool_1 = True
    try_1 = Try(bool_1, not bool_1)

    filter_1 = filterer(bool_1)
    if not filter_1:
        x = try_1.filter(filterer)
        x = x.get()
        assert isinstance(x, bool)

    def filterer(x):
        return x

    bool_2 = True

# Generated at 2022-06-26 00:02:35.088175
# Unit test for method filter of class Try
def test_Try_filter():
   assert Try.of(lambda: 5).filter(lambda x: x == 5).is_success, "Boolean {} is not success".format(
       Try.of(lambda: 5).filter(lambda x: x == 5).is_success)
   assert not (Try.of(lambda: 5).filter(lambda x: x != 5).is_success), "Boolean {} is not success".format(
       Try.of(lambda: 5).filter(lambda x: x != 5).is_success)


# Generated at 2022-06-26 00:02:39.263723
# Unit test for method filter of class Try
def test_Try_filter():
    def err_str(str_):
        raise Exception('err')

    assert Try.of(err_str, 'str') == Try(Exception('err'), False)
    assert Try.of(err_str, 'str')\
        .filter(lambda x: type(x) == Exception)\
        == Try(Exception('err'), True)

# Generated at 2022-06-26 00:02:49.813680
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(lambda: 5)
    assert try_0.filter(lambda value: value < 6) == Try(5, True)
    assert try_0.filter(lambda value: value >= 6) == Try(5, False)

    exception_0 = Exception('exception_0')
    try_1 = Try(exception_0, False)
    assert try_1.filter(lambda value: isinstance(value, Exception)) == try_1

    try_0 = Try.of(lambda: 5)
    assert try_0.filter(lambda value: value < 6).filter(lambda value: value > 4) == Try(5, True)

    exception_0 = Exception('exception_0')
    try_1 = Try(exception_0, False)

# Generated at 2022-06-26 00:02:54.608815
# Unit test for method filter of class Try
def test_Try_filter():
    try_1 = Try(True, True)
    try_2 = try_1.filter(lambda value: value)

    try_3 = try_1.filter(lambda value: not value)
    try_4 = Try(False, False)

    assert try_2 == try_1, 'test_Try_filter_1'
    assert try_3 == try_4, 'test_Try_filter_2'


# Generated at 2022-06-26 00:02:58.742471
# Unit test for method filter of class Try
def test_Try_filter():
    test_bool = True
    test_Try = Try(test_bool, test_bool)
    assert test_Try.filter(lambda value: test_bool == value) == Try(test_bool, True)
    assert test_Try.filter(lambda value: test_bool != value) == Try(test_bool, False)
