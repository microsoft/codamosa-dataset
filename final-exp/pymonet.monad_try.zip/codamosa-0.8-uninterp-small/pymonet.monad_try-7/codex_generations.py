

# Generated at 2022-06-25 23:53:11.971909
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)

    bool_1 = True
    try_1 = Try(bool_1, bool_1)

    assert try_0.filter(lambda _: bool_0) == Try(bool_0, bool_1)
    assert try_0.filter(lambda _: bool_1) == Try(bool_0, bool_0)
    assert try_1.filter(lambda _: bool_0) == Try(bool_1, bool_0)
    assert try_1.filter(lambda _: bool_1) == Try(bool_1, bool_1)


test_case_0()
test_Try_filter()

# Generated at 2022-06-25 23:53:24.617622
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(bool, 0).filter(lambda x: x) == False,\
        'For value 0 and lambda x -> True, Try.of(bool, 0).filter(lambda x -> x) must not return successfully instance of Try.'
    assert Try.of(bool, 1).filter(lambda x: x) == True,\
        'For value 1 and lambda x -> True, Try.of(bool, 1).filter(lambda x -> x) must return successfully instance of Try.'
    assert Try.of(bool, 0).filter(lambda x: not x) == Try(False, False),\
        'For value 0 and lambda x -> not x, Try.of(bool, 0).filter(lambda x -> x) must return not successfully instance of Try.'

# Generated at 2022-06-25 23:53:32.983042
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_1)

    def filterer_0(value):
        return True

    def filterer_1(value):
        return False

    assert try_0.filter(filterer_0) == Try(bool_0, bool_0)
    assert try_0.filter(filterer_1) == Try(bool_0, bool_0)
    assert try_1.filter(filterer_0) == Try(bool_0, bool_1)
    assert try_1.filter(filterer_1) == Try(bool_0, bool_0)



# Generated at 2022-06-25 23:53:36.219525
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(2, True).filter(lambda x: x == 1) == Try(2, False)
    assert Try('error', False).filter(lambda x: x == 1) == Try('error', False)


# Generated at 2022-06-25 23:53:42.902376
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    try_0 = Try(bool_0, True)
    try_1 = try_0.filter(lambda x : x)
    bool_1 = True
    assert bool_1 == try_1.is_success
    bool_2 = False
    try_2 = try_0.filter(lambda x : not x)
    assert bool_2 == try_2.is_success


# Generated at 2022-06-25 23:53:50.694795
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(True, True)
    def filterer0(value):
        return value

    try_1 = Try(True, True)
    def filterer1(value):
        return not value

    assert try_0.filter(filterer0) == try_0
    assert try_0.filter(filterer1) != try_0
    assert try_1.filter(filterer0) != try_1
    assert try_1.filter(filterer1) != try_1


# Generated at 2022-06-25 23:53:56.979678
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.filter(lambda x: x) == try_0, 'Test failed'
    assert try_0.filter(lambda x: not x) != try_0, 'Test failed'


# Generated at 2022-06-25 23:53:59.933719
# Unit test for method filter of class Try
def test_Try_filter():
    def tester(value):
        return True

    expect = Try(True, True)
    result = Try(True, True).filter(tester)
    assert result == expect


# Generated at 2022-06-25 23:54:12.295432
# Unit test for method filter of class Try
def test_Try_filter():
    # test case 1
    assert Try.of(lambda b: b, False).filter(lambda v: v).is_success is False
    # test case 2
    assert Try.of(lambda b: b, False).filter(lambda v: not v).is_success is False
    assert Try.of(lambda b: b, False).filter(lambda v: not v).get() is False
    # test case 3
    assert Try.of(lambda b: b, True).filter(lambda v: not v).is_success is False
    assert Try.of(lambda b: b, True).filter(lambda v: not v).get() is True
    # test case 4
    assert Try.of(lambda b: b, True).filter(lambda v: v).is_success is True

# Generated at 2022-06-25 23:54:16.265184
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = 1
    try_0 = Try(bool_0, True)
    def func_0(arg_0):
        return arg_0
    try_1 = try_0.filter(func_0)
    assert try_1.is_success == bool_0


# Generated at 2022-06-25 23:54:21.609861
# Unit test for method __str__ of class Try
def test_Try___str__():
    class Test:
        def __eq__(self, other):
            return True

    test_0 = Test()
    try_0 = Try(test_0, True)
    assert str(try_0) == 'Try[value=<__main__.Test object at 0x000001E79F74C908>, is_success=True]'

    test_1 = Test()
    try_1 = Try(test_1, False)
    assert str(try_1) == 'Try[value=<__main__.Test object at 0x000001E79F74C908>, is_success=False]'

    test_2 = Test()
    try_2 = Try(test_2, True)

# Generated at 2022-06-25 23:54:26.890399
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    try_0 = Try(False, True)
    try_1 = try_0.on_success(lambda x: print(x))

    assert try_0 == try_1

# Generated at 2022-06-25 23:54:31.663176
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.__str__() == 'Try[value=False, is_success=False]', 'Failed assert for __str__ method of class Try'


# Generated at 2022-06-25 23:54:36.231830
# Unit test for constructor of class Try
def test_Try():
    T = Try.of(lambda: 10)
    assert T.is_success, 'Success'
    assert T.value == 10, 'Success'
    T = Try.of(lambda: 10/0)
    assert T.is_success == False, 'not Success'
    assert isinstance(T.value, ZeroDivisionError), 'not Success'



# Generated at 2022-06-25 23:54:40.431582
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert(str(Try(0, True)) == 'Try[value=0, is_success=True]')
    assert(str(Try(0, False)) == 'Try[value=0, is_success=False]')


# Generated at 2022-06-25 23:54:44.380910
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_1 = try_0.filter(lambda b: bool_0)

    try_1 = Try(bool_0, bool_0)


# Generated at 2022-06-25 23:54:51.055614
# Unit test for method on_success of class Try
def test_Try_on_success():
    def binder(a):
        return Try(a, True)

# Generated at 2022-06-25 23:55:02.644617
# Unit test for method map of class Try
def test_Try_map():
    """
    Test case for method map of class Try
    """
    assertion_0 = True
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    
    def add_one(value):
        return int(value) + 1
    
    def find_list_len(list_):
        return len(list_)
    
    try_1 = try_0.map(add_one)
    try_2 = Try(add_one(bool_0), bool_0)
    assert try_1 == try_2 == Try(int(bool_0) + 1, bool_0), 'Test case of test_Try_map failed!'
    
    
    bool_0 = True
    list_0 = ['1', '2', '3']

# Generated at 2022-06-25 23:55:13.159904
# Unit test for method map of class Try
def test_Try_map():
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_1)
    def mapper_0(bool_arg_0):
        bool_0 = True
        bool_1 = False
        if bool_arg_0:
            return bool_0
        return bool_1
    try_randoop_0 = Try(mapper_0, mapper_0)
    def mapper_1(bool_arg_0):
        bool_0 = True
        bool_1 = False
        if bool_arg_0:
            return bool_0
        return bool_1
    map_of_try_0 = try_0.map(mapper_1)

# Generated at 2022-06-25 23:55:23.999437
# Unit test for method bind of class Try
def test_Try_bind():
    from typing import cast

    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = cast(Try[bool], try_0.bind(lambda bool_0: Try(bool_0, bool_0)))

    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_2 = cast(Try[bool], try_0.bind(lambda bool_0: Try(bool_0, bool_0)))

    bool_0 = True
    bool_1 = bool_0
    try_0 = Try(bool_0, bool_0)
    try_3 = Try(bool_0, bool_0)
    try_4 = cast(Try[bool], try_3.bind(lambda bool_0: try_0))

    bool_0 = False

# Generated at 2022-06-25 23:55:36.534259
# Unit test for method bind of class Try
def test_Try_bind():
    """
    bind method applied function on monad value.
    When monad is successfully returns function result value.
    Othercase returns copy of monad.
    """

    def boolean_to_success_monad(flag):
        return Try(flag, True) if flag else Try(flag, False)

    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.bind(boolean_to_success_monad) == Try(bool_0, bool_0)

    bool_1 = False
    try_1 = Try(bool_1, bool_1)
    assert try_1.bind(boolean_to_success_monad) == Try(bool_1, bool_1)



# Generated at 2022-06-25 23:55:37.843836
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda i: Try(i + 1, True)) == Try(2, True)


# Generated at 2022-06-25 23:55:48.540345
# Unit test for method bind of class Try
def test_Try_bind():
    # create successfully Try
    try_0 = Try(True, True)
    # simple check copy
    assert try_0.bind(lambda x: Try(x, True)) == Try(True, True)
    assert try_0.bind(lambda x: Try(x, False)) == Try(True, True)

    # create not successfully Try
    try_0 = Try(True, False)
    # simple check copy
    assert try_0.bind(lambda x: Try(x, True)) == Try(True, False)
    assert try_0.bind(lambda x: Try(x, False)) == Try(True, False)


# Generated at 2022-06-25 23:55:58.844376
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0).map(lambda _: bool_0)
    try_2 = Try(bool_0, bool_0).map(lambda _: bool_0).map(lambda _: bool_0)
    try_3 = Try(bool_0, bool_0).map(lambda _: bool_0).map(lambda _: bool_0).map(lambda _: bool_0)
    bool_1 = bool_0.__class__(bool_0)
    try_4 = Try(bool_0, bool_0).map(lambda _: bool_0).map(lambda _: bool_0).map(lambda _: bool_0).map(lambda _: bool_0)

# Unit test

# Generated at 2022-06-25 23:56:01.643046
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.bind(lambda value: Try(value, bool_0)) == Try(bool_0, bool_0)



# Generated at 2022-06-25 23:56:03.912667
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    result_0 = try_0.get_or_else(True)
    assert result_0 == True



# Generated at 2022-06-25 23:56:15.355117
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    bool_1 = True
    try_1 = Try(bool_0, bool_1)
    bool_2 = True
    try_2 = Try(bool_0, bool_2)
    bool_3 = False
    try_3 = Try(bool_0, bool_3)
    bool_4 = True
    try_4 = Try(bool_0, bool_4)
    bool_5 = False
    try_5 = Try(bool_0, bool_5)
    assert try_0 == try_0
    assert try_1 == try_1
    assert try_2 == try_2
    assert try_3 == try_3
    assert not try_0 == try_1
    assert not try_1 == try_2

# Generated at 2022-06-25 23:56:24.706397
# Unit test for method filter of class Try
def test_Try_filter():
    def inc(x: int) -> int:
        return x + 1

    def is_even(x: int) -> bool:
        return x % 2 == 0

    def filterer(x: int) -> bool:
        return True

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(0, False).filter(filterer) == Try(0, False)

    assert Try(1, True).filter(is_even) == Try(1, False)
    assert Try(2, True).filter(is_even) == Try(2, True)

    assert Try(1, False).filter(is_even) == Try(1, False)

    assert Try(1, True).map(inc).filter(is_even) == Try(2, False)


# Generated at 2022-06-25 23:56:34.285609
# Unit test for method bind of class Try
def test_Try_bind():
    fn = lambda x: x
    assert Try(fn(1), True).bind(lambda x: Try(fn(x), True)) == Try(fn(fn(1)), True)
    assert Try(fn(1), True).bind(lambda x: Try(fn(x), True)).bind(lambda x: Try(fn(x), True)) == Try(fn(fn(fn(1))), True)
    assert Try(fn(1), True).bind(lambda x: Try(fn(x), True)).bind(lambda x: Try(fn(x), True)).bind(lambda x: Try(fn(x), False)) == Try(fn(fn(fn(1))), False)

# Generated at 2022-06-25 23:56:37.868295
# Unit test for constructor of class Try
def test_Try():
    """
    >>> import sys
    >>> sys.version_info[0] == 3 and sys.version_info[1] >= 6
    True
    """
    assert True



# Generated at 2022-06-25 23:56:42.659105
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-25 23:56:49.208654
# Unit test for method bind of class Try
def test_Try_bind():
    # Create Try monad
    try_0: Try = Try(100, True)

    # Try monad is successfully
    try_1: Try = try_0.bind(lambda a: Try(a + 10, True))
    assert try_1.is_success == True
    assert try_1.value == 110

    # Try monad is unsuccessfully
    try_2: Try = try_0.bind(lambda a: Try(a + 10, False))
    assert try_2.is_success == False
    assert try_2.value == 110



# Generated at 2022-06-25 23:56:50.589888
# Unit test for method get of class Try
def test_Try_get():
    assert Try(42, True).get() == 42


# Generated at 2022-06-25 23:56:54.769915
# Unit test for method get of class Try
def test_Try_get():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.get() == bool_0


# Generated at 2022-06-25 23:56:56.269823
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(0, True) == Try(0, True)



# Generated at 2022-06-25 23:57:02.506358
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """Test case for on_fail method of class Try"""
    bool_1 = True
    try_1 = Try.of(lambda: bool_1, 1)
    bool_2 = False
    try_2 = Try.of(lambda: bool_2, 1)
    assert try_1.on_fail(lambda val: None) == try_1
    assert try_2.on_fail(lambda val: None) == try_2


# Generated at 2022-06-25 23:57:13.995552
# Unit test for method filter of class Try
def test_Try_filter():
    # Test of True, Success
    t1 = Try(True, True)
    t2 = t1.filter(lambda v: v)
    assert t1 is not t2
    assert t2 == Try(True, True)

    # Test of True, Not Success
    t1 = Try(True, False)
    t2 = t1.filter(lambda v: v)
    assert t1 is not t2
    assert t2 == Try(True, False)

    # Test of False, Success
    t1 = Try(True, True)
    t2 = t1.filter(lambda v: not v)
    assert t1 is not t2
    assert t2 == Try(True, False)

    # Test of False, Not Success
    t1 = Try(False, False)

# Generated at 2022-06-25 23:57:16.173716
# Unit test for method on_success of class Try

# Generated at 2022-06-25 23:57:24.659113
# Unit test for method get of class Try
def test_Try_get():
    try_0 = Try.of(lambda: False, None)
    try_1 = Try.of(lambda: True, None)
    try_2 = Try.of(lambda: 1, None)
    try_3 = Try.of(lambda: -1, None)
    try_4 = Try.of(lambda: 0, None)
    try_5 = Try.of(lambda: 0.0, None)
    try_6 = Try.of(lambda: '', None)
    try_7 = Try.of(lambda: 'False', None)
    try_8 = Try.of(lambda: 'True', None)
    try_9 = Try.of(lambda: '1', None)
    try_10 = Try.of(lambda: '-1', None)

# Generated at 2022-06-25 23:57:34.546251
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def assert_on_fail(e, expected_value):
        bool_value = False
        try_ = Try(e, bool_value)
        actual_value = try_.on_fail(lambda x: x)
        assert expected_value == actual_value

    assert_on_fail(Exception('Exception message.'), Try(Exception('Exception message.'), False))
    assert_on_fail(Exception(''), Try(Exception(''), False))
    assert_on_fail(Exception('Exception message.'), Try(Exception('Exception message.'), False))
    assert_on_fail(Exception('Exception message.'), Try(Exception('Exception message.'), False))
    assert_on_fail(Exception('Exception message.'), Try(Exception('Exception message.'), False))


# Generated at 2022-06-25 23:57:46.922023
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    t_bool_0 = True
    t_bool_1 = False
    t_string_0 = "Monad Try"
    t_Try_0 = Try(t_string_0, t_bool_1)

    assert t_Try_0 == Try(t_string_0, t_bool_1)
    assert t_Try_0 != Try(t_string_0, t_bool_0)
    assert t_Try_0 != Try("Try Monad", t_bool_1)


# Generated at 2022-06-25 23:57:52.167362
# Unit test for method get of class Try
def test_Try_get():
    bool_0 = False
    try_0 = Try(bool_0, False)
    if try_0.get() != bool_0:
        raise AssertionError()
    try_0 = Try(bool_0, True)
    if try_0.get() != bool_0:
        raise AssertionError()


# Generated at 2022-06-25 23:58:00.092400
# Unit test for constructor of class Try
def test_Try():
    assert Try(True, True) == Try.of(lambda: True)
    assert Try(True, True) == Try(True, True)
    assert Try(True, True).is_success == True
    assert Try(True, True).value == True
    assert Try(True, False).is_success == False
    assert Try(True, False).value == True
    assert Try(0, True).is_success == True
    assert Try(0, True).value == 0
    assert Try("", True).is_success == True
    assert Try("", True).value == ""
    assert Try('a', True).is_success == True
    assert Try('a', True).value == 'a'



# Generated at 2022-06-25 23:58:06.313452
# Unit test for constructor of class Try
def test_Try():
    # Successfully Try
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(True, True)
    assert try_0 == try_1
    # Not successful Try
    bool_1 = False
    try_2 = Try(bool_1, bool_1)
    try_3 = Try(False, False)
    assert try_2 == try_3
    # Exception raise in constructor
    try:
        Try('str', True)
        assert False
    except TypeError:
        pass
    except:
        assert False
    try:
        Try('str', False)
        assert False
    except TypeError:
        pass
    except:
        assert False
    # Illegal arguments

# Generated at 2022-06-25 23:58:11.278950
# Unit test for constructor of class Try
def test_Try():
    assert Try(12321, True).value == 12321
    assert Try(12321, True).is_success == True
    assert Try(12321, False).value == 12321
    assert Try(12321, False).is_success == False



# Generated at 2022-06-25 23:58:16.028923
# Unit test for method bind of class Try
def test_Try_bind():
    def inc_0(a: int) -> int:
        return a + 1


    def inc_1(a: int):
        return Try(a + 1, True)


    try_0 = Try(1, True)
    assert Try(2, True) == try_0.bind(inc_1)



# Generated at 2022-06-25 23:58:25.524207
# Unit test for method filter of class Try
def test_Try_filter():
    # Case 0: Successful Try
    try_0 = Try.of(lambda x: x, True)
    assert try_0.filter(lambda x: x) is not None, 'Case 0 failed'

    # Case 1: Not successful Try
    try_1 = Try.of(lambda x: x, False)
    assert try_1.filter(lambda x: x) is not None, 'Case 1 failed'

    # Case 2: Successful Try and filter is False function
    try_2 = Try.of(lambda x: x, True)
    assert try_2.filter(lambda x: False) is not None, 'Case 2 failed'

    # Case 3: Not successful Try and filter is True function
    try_3 = Try.of(lambda x: x, True)
    assert try_3.filter(lambda x: True) is not None

# Generated at 2022-06-25 23:58:32.182478
# Unit test for method map of class Try
def test_Try_map():
    """
    Test case for method map of class Try
    :param result_0:
    :return:
    """
    # Initialization
    result_0 = False
    try_0 = Try(result_0, result_0)
    try_1 = try_0.map(lambda x: x)

    assert result_0 == try_1.value
    assert result_0 == try_1.is_success


# Generated at 2022-06-25 23:58:33.530409
# Unit test for method get of class Try
def test_Try_get():
    assert Try(True, True).get() == True


# Generated at 2022-06-25 23:58:38.796002
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: bool) -> bool:
        return value
    assert Try(True, True).filter(filterer) == Try(True, True)
    assert Try(False, True).filter(filterer) == Try(False, False)
    assert Try(False, False).filter(filterer) == Try(False, False)


# Generated at 2022-06-25 23:58:55.510043
# Unit test for constructor of class Try
def test_Try():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.value is bool_0
    assert try_0.is_success is bool_0


# Generated at 2022-06-25 23:59:00.691692
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(True, True).get_or_else(False) == True, \
        'Try.get_or_else() do not return correct value.'
    assert Try(False, False).get_or_else(True) == True, \
        'Try.get_or_else() do not return correct value.'


# Generated at 2022-06-25 23:59:05.141608
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = False
    try_0 = Try(bool_0, True)
    try_0.on_success(lambda value: print(value))
    try_0.on_fail(lambda value: print(value))
    return (try_0.get())


# Generated at 2022-06-25 23:59:10.324454
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_0 = Try.of(lambda: 1)
    try_1 = Try(1, True)
    assert (try_1 == try_1)
    try_2 = Try(2, True)
    assert (try_2 == try_2)
    assert (try_0 == try_1)
    assert (try_0 != try_2)
    try_3 = Try(2, False)
    assert (try_2 == try_3)


# Generated at 2022-06-25 23:59:16.847232
# Unit test for method map of class Try
def test_Try_map():
    # Try[False] | map
    monad_0 = Try(False, False)
    monad_1 = monad_0.map(lambda x: not x)
    monad_2 = monad_1.map(bool)
    assert monad_0.value == False
    assert monad_0.is_success == False
    assert monad_1.value == True
    assert monad_1.is_success == False
    assert monad_2.value == True
    assert monad_2.is_success == False

    # Try[0] | map
    monad_0 = Try(0, True)
    monad_1 = monad_0.map(lambda x: x + 1)
    monad_2 = monad_1.map(bool)
    assert monad_0.value == 0

# Generated at 2022-06-25 23:59:25.476771
# Unit test for method __eq__ of class Try
def test_Try___eq__():

    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = try_0
    bool_0 = (try_0 == try_1)
    # bool_0 = True
    assert bool_0

    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    bool_2 = False
    try_1 = Try(bool_2, bool_2)
    bool_0 = (try_0 == try_1)
    # bool_0 = True
    assert bool_0

    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_0 = False
    try_1 = Try(bool_0, bool_0)
    bool_0 = (try_0 == try_1)
    #

# Generated at 2022-06-25 23:59:33.811299
# Unit test for method map of class Try
def test_Try_map():
    """
    If successfully monad return mapped monad else return copy of self
    """
    a = Try(10, True)
    assert a.map(lambda x: x+1) == Try(11, True)

    a = Try(10, False)
    assert a.map(lambda x: x+1) == Try(10, False)

    a = Try(10, False)
    assert a.map(lambda x: x+1).value == 10

    a = Try(10, False)
    assert a.map(lambda x: x+1).is_success == False


# Generated at 2022-06-25 23:59:39.733729
# Unit test for constructor of class Try
def test_Try():
    bool_0 = False
    try_0 = Try.of(lambda: True)

    assert try_0.is_success == True
    assert try_0.value == True

    try_1 = Try.of(lambda: int('a'))
    assert try_1.is_success == False
    assert isinstance(try_1.value, ValueError)

    try_2 = Try.of(lambda: int('12'))
    assert try_2.is_success == True
    assert try_2.value == int('12')



# Generated at 2022-06-25 23:59:45.365696
# Unit test for method on_success of class Try
def test_Try_on_success():
    # success
    def success_callback(v: int) -> None:
        assert v == 1

    assert Try.of(lambda: 1).on_success(success_callback) == Try(1, True)

    # fail
    def fail_callback(v: Exception) -> None:
        assert isinstance(v, Exception)

    assert Try.of(lambda: 1 / 0).on_fail(fail_callback) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-25 23:59:48.819489
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.get() == bool_0

    bool_1 = True
    try_1 = try_0.filter(lambda a: bool_1)
    assert try_1.get() == bool_1

    try_2 = try_0.filter(lambda a: False)
    assert try_2.get() == bool_0
    assert try_2.is_success == False



# Generated at 2022-06-26 00:00:20.872177
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    str_0 = str(try_0)
    print(str_0)


# Generated at 2022-06-26 00:00:25.753658
# Unit test for method map of class Try
def test_Try_map():
    try_0 = Try(2, True)
    assert try_0.map(lambda x: x ** 2) == Try(4, True)

    try_1 = Try(ZeroDivisionError, False)
    assert try_1.map(lambda x: x ** 2) == try_1



# Generated at 2022-06-26 00:00:35.862786
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def test_0_expected_value():
        bool_0 = False
        try_0 = Try(bool_0, bool_0)
        try_1 = Try(bool_0, not bool_0)
        return try_0 == try_1

    def test_1_expected_value():
        bool_0 = False
        try_0 = Try(bool_0, not bool_0)
        try_1 = Try(bool_0, bool_0)
        return not (try_0 == try_1)

    def test_2_expected_value():
        bool_0 = False
        try_0 = Try(bool_0, bool_0)
        try_1 = Try(bool_0, bool_0)
        return try_0 == try_1

    def test_3_expected_value():
        bool_

# Generated at 2022-06-26 00:00:40.662627
# Unit test for constructor of class Try
def test_Try():
    assert Try(2, False) == Try(2, False)

    assert Try(2, True) != Try(2, False)
    assert Try(2, True) != Try(3, True)
    assert Try(3, False) != Try(2, False)

    assert str(Try(True, True)) == 'Try[value=True, is_success=True]'
    assert str(Try(False, False)) == 'Try[value=False, is_success=False]'



# Generated at 2022-06-26 00:00:50.261670
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value: bool) -> bool:
        """
        Return True when value is True
        """
        return value
    bool_0 = True
    try_0 = Try(bool_0, True)
    filter_result = try_0.filter(filterer)
    filter_expect = Try(bool_0, True)
    assert filter_result is not None
    assert filter_result == filter_expect
    #
    bool_1 = False
    try_1 = Try(bool_1, True)
    filter_result = try_1.filter(filterer)
    filter_expect = Try(bool_1, False)
    assert filter_result is not None
    assert filter_result == filter_expect
    #
    try_2 = Try(True, False)

# Generated at 2022-06-26 00:00:52.644010
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)

# Generated at 2022-06-26 00:00:57.980103
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = False
    try_0 = Try(bool_0, False)
    def mock_fail_callback(value):
        return value

    # @returns: self
    # @rtype: Try[A]
    try_0_copy = try_0.on_fail(mock_fail_callback)

    assert try_0_copy.get() == bool_0
    assert try_0_copy.is_success == False


# Generated at 2022-06-26 00:01:06.412288
# Unit test for method map of class Try
def test_Try_map():
    # Successfully state
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(not bool_0, not bool_0)
    # Not successfully state
    error_0 = Exception('error')
    try_2 = Try(error_0, not bool_0)
    try_3 = Try(not error_0, bool_0)

    # Successfully state and with successfully monad
    mapper_0 = lambda value: value
    try_4 = try_0.map(mapper_0)
    try_5 = try_1.map(mapper_0)

    # Successfully state and with not successfully monad
    mapper_1 = lambda value: value
    try_6 = try_2.map(mapper_1)

# Generated at 2022-06-26 00:01:16.525835
# Unit test for method filter of class Try
def test_Try_filter():
    """Basic usage of the filter method from Try control."""

    def filter_0(value):
        print('filter_0 is called')
        return value

    def filter_1(value):
        print('filter_1 is called')
        return False

    def filter_2(value):
        print('filter_2 is called')
        return True

    def run_tests():
        test_0 = Try(True, False)
        print('test_0.filter(filter_0)')
        test_0.filter(filter_0)

        test_1 = Try(True, False)
        print('test_1.filter(filter_1)')
        test_1.filter(filter_1)

        test_2 = Try(True, False)
        print('test_2.filter(filter_2)')
        test_2

# Generated at 2022-06-26 00:01:26.503472
# Unit test for method filter of class Try
def test_Try_filter():
    tests = {}

    tests[1] = {
        'input': {
            'filterer': lambda x: x % 2 == 0,
            'default_value': 100
        },
        'output': {
            'condition': lambda x: x % 2 == 0,
            'success_expected': True,
            'value_expected': lambda x: x,
            'test_values': [
                (2, 2),
                (3, 100)
            ]
        }
    }


# Generated at 2022-06-26 00:02:29.814448
# Unit test for constructor of class Try
def test_Try():
    # Unit test for constructor of class Try
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.value == bool_0
    assert try_0.is_success == bool_0
    try_1 = Try(bool_1, bool_1)
    assert try_1.value == bool_1
    assert try_1.is_success == bool_1
    # Unit test for of method
    def bool_0_function():
        bool_0 = False
        return bool_0
    def bool_1_function():
        bool_1 = True
        return bool_1
    try_0 = Try.of(bool_0_function)
    assert try_0.value == bool_0
    assert try_0.is_success == bool

# Generated at 2022-06-26 00:02:33.187392
# Unit test for constructor of class Try
def test_Try():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert try_0.value == bool_0
    assert try_0.is_success == bool_0



# Generated at 2022-06-26 00:02:45.181743
# Unit test for constructor of class Try
def test_Try():
    assert Try(False, False) == Try(False, False)
    assert Try(False, True) == Try(False, True)
    assert Try(True, False) == Try(True, False)
    assert Try(True, True) == Try(True, True)

    assert Try(False, False) != Try(False, True)
    assert Try(False, True) != Try(False, False)

    assert Try(True, False) != Try(False, True)
    assert Try(False, True) != Try(True, False)
    assert Try(True, True) != Try(False, True)
    assert Try(False, True) != Try(True, True)

    assert Try(False, True) != True
    assert Try(False, False) != True
    assert Try(True, False) != True

# Generated at 2022-06-26 00:02:49.187805
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)
    assert not try_0.on_fail(lambda: bool_0)

    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    assert try_1.on_fail(lambda: bool_0)


# Generated at 2022-06-26 00:02:54.417762
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = False
    bool_1 = bool(0)
    callback_0 = test_case_0
    callback_1 = test_case_0
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_1)
    try_0.on_success(callback_0)
    try_1.on_success(callback_1)


# Generated at 2022-06-26 00:02:57.348734
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)

    assert str(try_0) == 'Try[value=False, is_success=False]'
    print('test_Try___str__ successful')



# Generated at 2022-06-26 00:03:01.996552
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # success Try
    try_0 = Try.of(lambda x: x, True)
    bool_0 = True
    try_1 = try_0.filter(lambda value: bool_0)
    print(try_1)

    # not success Try
    bool_1 = False
    try_2 = try_0.filter(lambda value: bool_1)
    print(try_2)

