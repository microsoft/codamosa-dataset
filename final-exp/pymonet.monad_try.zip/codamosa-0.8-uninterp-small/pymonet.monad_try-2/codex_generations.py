

# Generated at 2022-06-25 23:53:12.938952
# Unit test for method filter of class Try
def test_Try_filter():
    def filter_0(a):
        return a == 10
    def filter_1(a):
        return a != 10
    def filter_2(a):
        return a == 20
    def filter_3(a):
        return a == 10
    def filter_4(a):
        return a != 10
    def filter_5(a):
        return a == 20
    num_0 = 10
    str_0 = '5D2A|'
    str_1 = '9^$('
    str_2 = '0i'
    bool_0 = True
    bool_1 = False
    try_0 = Try(num_0, bool_0)
    try_1 = Try(str_0, bool_0)
    try_2 = Try(str_1, bool_1)
    try_3 = Try

# Generated at 2022-06-25 23:53:18.150617
# Unit test for method filter of class Try
def test_Try_filter():
    def mul(a, b):
        return a * b
    def increment(a):
        return a + 1

    result = Try.of(mul, 2, 3)
    assert result == Try(6, True)

    result = result.map(increment)
    assert result == Try(7, True)

    result = Try.of(lambda: 'a' + 1)
    assert result == Try(TypeError("Can't convert 'int' object to str implicitly"), False)

    result = result.map(increment)
    assert result == Try(TypeError("Can't convert 'int' object to str implicitly"), False)

    result = result.bind(lambda v: Try(v, False)).on_fail(lambda e: print(e))
    assert result == Try(TypeError("Can't convert 'int' object to str implicitly"), False)

# Generated at 2022-06-25 23:53:29.949233
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '=X-;6V'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    str_1 = 'Z'

    def func_0(arg_0):
        assert arg_0 == str_0
        return bool_0

    try_1 = try_0.filter(func_0)
    assert try_1.value == str_0
    assert try_1.is_success == bool_0

    def func_1(arg_0):
        assert arg_0 == str_1
        return not bool_0

    try_2 = Try(str_1, bool_0).filter(func_1)
    assert try_2.value == str_1

# Generated at 2022-06-25 23:53:37.680962
# Unit test for method filter of class Try
def test_Try_filter():
    def test_0():
        str_0 = '=X-;6V'
        bool_0 = True
        try_0 = Try(str_0, bool_0)
        def pred_0(arg_0):
            return True

        pred_0 = pred_0
        try_1 = try_0.filter(pred_0)
        try_2 = Try(str_0, bool_0)
        assert try_1 == try_2
    def test_1():
        str_0 = '=X-;6V'
        bool_0 = True
        try_0 = Try(str_0, bool_0)
        def pred_0(arg_0):
            return True

        pred_0 = pred_0
        try_1 = try_0.filter(pred_0)

# Generated at 2022-06-25 23:53:44.265325
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '=X-;6V'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    str_1 = try_0.filter(lambda x: x == '=X-;6V')
    str_2 = '=X-;6V'
    bool_1 = True
    try_1 = Try(str_2, bool_1)
    assert str_1 == try_1


# Generated at 2022-06-25 23:53:54.040475
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '=X-;6V'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    str_1 = 'l'
    bool_1 = True
    try_1 = Try(str_1, bool_1)
    str_2 = 'h'
    bool_2 = False
    try_2 = Try(str_2, bool_2)

    def lambda_1(x_0):
        return x_0 == 'l'

    if not lambda_1(try_1.get()):
        raise Exception(
            'Test try_1 fail: expected lambda_1(try_1.get()), got ' +
            str(lambda_1(try_1.get()))
        )


# Generated at 2022-06-25 23:54:03.173580
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '=X-;6V'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    str_1 = 'bZ5w5'
    bool_1 = False
    try_1 = Try(str_1, bool_1)
    str_2 = 'GQTT`'
    bool_2 = True
    try_2 = Try(str_2, bool_2)
    def func_0(arg_0):
        if arg_0 == 'bZ5w5':
            return True
        return False
    try_2 = try_1.filter(func_0)
    assert try_2 == Try(str_1, False)
    try_2 = try_0.filter(func_0)

# Generated at 2022-06-25 23:54:13.895448
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '=X-;6V'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    def filterer_0(arg0):
        return arg0 > '='
    Try(filterer_0(str_0), True)
    Try(filterer_0(str_0), (filterer_0(str_0) is not False))
    filterer_1 = filterer_0
    Try(filterer_1(str_0), True)
    Try(filterer_1(str_0), (filterer_1(str_0) is not False))
    Try(filterer_1(str_0), (filterer_1(str_0) is not False))

# Generated at 2022-06-25 23:54:26.193494
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(lambda x: 3, 3)
    try_1 = try_0.filter(lambda x: x % 2 == 0)
    try_2 = try_1.filter(lambda x: x % 2 == 0)
    #Test 2: Try with same state after filter
    assert(try_0 == Try(try_0.get(), try_0.is_success))
    #Test 3: not successed Try after filter
    assert(try_1 == Try(3, False))
    #Test 4: not successed Try after filter
    assert(try_2 == Try(3, False))
    #Test 5: state succes of Try is not changed
    assert(try_0.is_success)
    #Test 6: state succes of Try is changed
    assert(not try_1.is_success)


# Generated at 2022-06-25 23:54:31.857684
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: x == True) == Try(True, True)
    assert Try(False, True).filter(lambda x: x != False) == Try(False, False)
    assert Try(None, True).filter(lambda x: x == None) == Try(None, True)


# Generated at 2022-06-25 23:54:41.153214
# Unit test for method filter of class Try
def test_Try_filter():
    result_0 = Try.of(int, '0')
    def func_0(val_0):
        return val_0 > 0
    def func_1(val_0):
        return val_0 < 0
    result_1 = result_0.filter(func_0)
    result_2 = result_0.filter(func_1)
    assert result_1 == result_0
    assert result_2 != result_0


# Generated at 2022-06-25 23:54:49.145572
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return True
    
    str_0 = '=X-;6V'
    str_1 = '=X-;6V'
    bool_0 = True
    bool_1 = True
    int_0 = 3
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(filterer)
    assert try_1.value == str_1
    assert try_1.is_success == bool_1
    assert len(try_1) == int_0


# Generated at 2022-06-25 23:55:00.808385
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'no error'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    str_1 = 'error'
    bool_1 = False
    try_1 = Try(str_1, bool_1)

    assert True == (True and True)
    assert False == (True and False)
    assert False == (False and True)
    assert False == (False and False)

    str_2 = 'no error'
    bool_2 = False
    try_2 = try_0.filter(lambda x: True)
    assert try_0 == try_2
    str_3 = 'error'
    bool_3 = False
    try_3 = try_1.filter(lambda x: True)
    assert try_1 == try_3


# Generated at 2022-06-25 23:55:08.317774
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '=X-;6V'
    bool_0 = True
    try_0 = Try(str_0, bool_0)

    assert not Try(str_0, bool_0).filter(lambda x: x == 'o') == try_0
    assert Try(str_0, bool_0).filter(lambda x: x == str_0) == try_0


# Generated at 2022-06-25 23:55:19.312743
# Unit test for method filter of class Try
def test_Try_filter():
    def test_Try_filter_0():
        test_Try_filter_0_expected_value = Try('P(@', True)
        test_Try_filter_0_observed_value = Try.of(lambda: 'P(@').filter(lambda x: True if x == 'P(@' else False)
        assert test_Try_filter_0_observed_value == test_Try_filter_0_expected_value

    def test_Try_filter_1():
        test_Try_filter_1_expected_value = Try('6j>U!X', False)
        test_Try_filter_1_observed_value = Try.of(lambda: '6j>U!X').filter(lambda x: True if x == '6j>U!X' else False)
        assert test_Try_filter_1_ob

# Generated at 2022-06-25 23:55:31.748476
# Unit test for method filter of class Try
def test_Try_filter():
    def lambda_0():
        return True

    def lambda_1():
        return False

    def lambda_2(arg_0):
        return True

    str_0 = '=X-;6V'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    try_1 = try_0.filter(lambda_0)
    try_2 = try_0.filter(lambda_1)
    assert try_1.value == str_0
    assert try_1.is_success
    assert try_2.value == str_0
    assert try_2.is_success == False
    int_0 = 0
    bool_0 = True
    try_3 = Try(int_0, bool_0)
    try_4 = try_3.filter(lambda_2)
   

# Generated at 2022-06-25 23:55:36.868417
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '--0[6c|p$'
    bool_0 = True
    try_0 = Try(str_0, bool_0)
    def filterer_0(param_0): return True
    bool_0 = False
    try_1 = try_0.filter(filterer_0)
    assert try_1.get() == str_0
    assert try_1.is_success == bool_0

# Generated at 2022-06-25 23:55:46.045507
# Unit test for method filter of class Try
def test_Try_filter():
    # Setup
    str_0 = '~HG<f'
    bool_0 = True
    try_0 = Try(str_0, bool_0)

    def filterer_0(arg_0):
        return arg_0 == '~HG<f'

    # Invoke method
    try_1 = try_0.filter(filterer_0)

    # Check result
    assert isinstance(try_1, Try)
    assert try_1.get() is not None
    assert try_1.value == '~HG<f'
    assert try_1.is_success is True
    # Teardown



# Generated at 2022-06-25 23:55:55.052471
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'f1M}n'
    bool_0 = False
    try_0 = Try(str_0, bool_0)
    def filterer_0(x):
        return len(x) == 5
    if filterer_0(str_0) == True:
        print("try_0.value: ", try_0.value)
    bool_1 = True
    try_1 = Try(str_0, bool_1)
    if filterer_0(str_0) == True:
        print("try_1.value: ", try_1.value)


# Generated at 2022-06-25 23:56:03.634328
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = "5=+;M"
    bool_0 = False
    try_0 = Try(str_0, bool_0)
    def fn_0(arg_0):
        return True if arg_0 == str_0 else False
    try_1 = try_0.filter(fn_0)
    assert try_1.value == str_0
    assert try_1.is_success == bool_0
    str_1 = "C2%"
    bool_1 = False
    try_2 = Try(str_1, bool_1)
    def fn_1(arg_0):
        return True if arg_0 == str_0 else False
    try_3 = try_2.filter(fn_1)
    assert try_3.value == str_1

# Generated at 2022-06-25 23:56:17.625421
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(str_0).filter(lambda x: str_0) == Try('0', True)
    assert Try.of(str_0).filter(lambda x: str_1) == Try('0', False)
    assert Try.of(int, str_0).filter(lambda x: x) == Try(0, True)
    assert Try.of(int, str_0).filter(lambda x: x + 1) == Try(0, True)
    assert Try.of(int, str_1).filter(lambda x: x) == Try('1', False)
    assert Try.of(int, str_0).filter(lambda x: x / 0) == Try(0, False)
    assert Try.of(int, str_1).filter(lambda x: x / 0) == Try('1', False)

# Generated at 2022-06-25 23:56:25.908266
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '1').filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(int, '1').filter(lambda x: x == 0) == Try(0, False)
    assert Try.of(int, 'str').filter(lambda x: x == 1) == Try(ValueError("invalid literal for int() with base 10: 'str'"), False)
    assert Try.of(lambda a: a, None).filter(lambda x: x == 0) == Try(None, False)
    assert Try.of(lambda a: a, None).filter(lambda x: x == None) == Try(None, True)
    assert Try.of(test_case_0).filter(lambda x: True) == Try(test_case_0, True)


# Generated at 2022-06-25 23:56:32.224554
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda a: 0, 'Not exception')\
        .filter(lambda x: x == 0)\
        == Try(0, True)

    assert Try.of(lambda a: int(a), str_0)\
        .filter(lambda x: x == 0)\
        == Try(0, True)

    assert Try.of(lambda a: int(a), str_0)\
        .filter(lambda x: x == 1)\
        == Try(0, False)


# Generated at 2022-06-25 23:56:35.724570
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(str_0, True).filter(lambda e: e == str_0) == Try(str_0, True)
    assert Try(str_0, True).filter(lambda e: e == '1') == Try(str_0, False)


# Generated at 2022-06-25 23:56:47.094570
# Unit test for method filter of class Try
def test_Try_filter():
    try_0_true: Try = Try(str_0, True)
    try_0_false: Try = Try(str_0, False)
    try_1_true: Try = Try(1, True)
    try_1_false: Try = Try(1, False)

    try_0_true = try_0_true.filter(lambda x: x == str_0)
    assert try_0_true == Try(str_0, True)

    try_0_false = try_0_false.filter(lambda x: x == str_0)
    assert try_0_false == Try(str_0, False)

    try_1_true = try_1_true.filter(lambda x: x == str_0)
    assert try_1_true == Try(str_0, False)

    try_1_

# Generated at 2022-06-25 23:56:52.619364
# Unit test for method filter of class Try
def test_Try_filter():
    case0 = Try.of(int, str_0)
    case0_filter = case0.filter(lambda v: True)
    assert case0_filter == Try(0, True)
    case1_filter = case0.filter(lambda v: False)
    assert case1_filter == Try(0, False)

    case1 = Try.of(int, str_1)
    case1_filter = case1.filter(lambda v: True)
    assert case1_filter == Try(1, True)
    case2_filter = case1.filter(lambda v: False)
    assert case2_filter == Try(1, False)


# Generated at 2022-06-25 23:56:57.921044
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, str_0).filter(lambda i: i == 0) == Try(0, True)
    assert Try.of(int, str_0).filter(lambda i: i == 1) == Try(0, False)
    assert Try.of(int, str_0).filter(lambda i: i == 2) == Try(0, False)


# Generated at 2022-06-25 23:57:09.631471
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(str, 0).map(lambda s: s + 's').filter(lambda s: s == '0s') == Try.of(str, 0).map(lambda s: s + 's')
    assert Try.of(str, 0).map(lambda s: s + 's').filter(lambda s: s == '1s') != Try.of(str, 0).map(lambda s: s + 's')
    assert Try.of(str, 0).map(lambda s: s + 's').filter(lambda s: s == '0s').get() == '0s'
    assert Try.of(str, 0).map(lambda s: s + 's').filter(lambda s: s == '1s').get() == 0

# Generated at 2022-06-25 23:57:14.522187
# Unit test for method filter of class Try
def test_Try_filter():
    success_result = Try.of(int, str_0)
    assert success_result\
        .filter(lambda x: x == 0) == Try(0, True)

    fail_result = Try.of(int, str_0)
    assert fail_result\
        .filter(lambda x: x == 1) == Try(0, False)



# Generated at 2022-06-25 23:57:17.437751
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(test_case_0, 0)\
        .filter(lambda n: n == 0)\
        .is_success

    assert not Try.of(test_case_0, 0)\
        .filter(lambda n: n != 0)\
        .is_success


# Generated at 2022-06-25 23:57:28.436131
# Unit test for method filter of class Try
def test_Try_filter():
    cls = Try.of(test_case_0)
    assert cls.filter(lambda a: a == '0').get_or_else('1') == '0'
    assert cls.filter(lambda a: a == '1').get_or_else('0') == '0'
    #assert cls.filter(lambda a: a == '1') == Try(test_case_0, False)


# Generated at 2022-06-25 23:57:32.132920
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(test_case_0).filter(lambda _: True).get_or_else('1') == '0'
    assert Try.of(test_case_0).filter(lambda _: False).get_or_else('1') == '1'

# Generated at 2022-06-25 23:57:35.016137
# Unit test for method filter of class Try
def test_Try_filter():
    try_int = Try.of(lambda: int(str_0))
    assert try_int.filter(lambda x: x == 0) == Try(0, True)



# Generated at 2022-06-25 23:57:42.861604
# Unit test for method filter of class Try
def test_Try_filter():

    compare = lambda x, y: x == y

    true_condition = lambda x: True

    false_condition = lambda x: False

    def int_parsing(x: str) -> int:
        return int(x)

    def division(x: int, y: int) -> float:
        return x / y

    def assertion(not_success_f, success_f):
        assert success_f(Try(5, True)).is_success == True
        assert not_success_f(Try(5, True)).is_success == False
        assert success_f(Try(5, False)).is_success == False
        assert not_success_f(Try(5, False)).is_success == False

    assertion(lambda x: x.filter(false_condition), lambda x: x.filter(true_condition))

    # Case 0


# Generated at 2022-06-25 23:57:47.010479
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Case 0:
    >>> Try.of(int, str_0).filter(lambda x: x > 1)
    False

    Case 1:
    >>> Try.of(int, str_0).filter(lambda x: x > -1)
    True

    """
    pass


# Generated at 2022-06-25 23:57:57.199548
# Unit test for method filter of class Try
def test_Try_filter():
    # Test case 0
    try:
        print('Test case 0')
        assert Try.of(int, str_0).filter(lambda x: x > 0) == Try(str_0, False)
        print('Success test case 0')
    except AssertionError:
        print('Fail test case 0')

    # Test case 1
    try:
        print('Test case 1')
        assert Try.of(int, '-1').filter(lambda x: x > 0) == Try('-1', False)
        print('Success test case 1')
    except AssertionError:
        print('Fail test case 1')

    # Test case 2

# Generated at 2022-06-25 23:58:03.732412
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Check that the filter method return successful Try with the same value when filterer returns True.
    """
    def filterer(x):
        return x == '0'

    str_0 = '0'
    my_try = Try.of(lambda: str_0)
    my_try_filtered = my_try.filter(filterer)
    assert isinstance(my_try_filtered, Try)
    assert my_try_filtered.is_success
    assert my_try_filtered.value == str_0
    assert my_try_filtered == Try(str_0, True)


# Generated at 2022-06-25 23:58:08.001460
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    str_0 = '0'
    str_1 = '1'

    # When
    result = Try(str_0, True).filter(lambda x: x == str_0)

    # Then
    assert result == Try(str_0, True)
    assert result != Try(str_0, False)


# Generated at 2022-06-25 23:58:14.266100
# Unit test for method filter of class Try
def test_Try_filter():
    try_str_0 = Try.of(lambda: str_0)
    assert(try_str_0 == Try('0', True))
    assert(try_str_0.filter(lambda x: x=='0') == Try('0', True))
    assert(try_str_0.filter(lambda x: x=='1') == Try('0', False))


# Generated at 2022-06-25 23:58:24.436408
# Unit test for method filter of class Try
def test_Try_filter():
    # try with successful value
    try_0 = Try.of(int, str_0)
    # filter successful value by successful predicate
    try_0_filtered = try_0.filter(lambda x: x == 0)
    # check that both values are in successful values
    assert try_0.is_success
    assert try_0.value == 0
    assert try_0_filtered.is_success
    assert try_0_filtered.value == 0
    # filter successful value by not successful predicate
    try_0_filtered = try_0.filter(lambda x: x > 0)
    # check that first value is in successful values
    # and second value is in not successful values
    assert try_0.is_success
    assert try_0.value == 0
    assert not try_0_filtered.is_success


# Generated at 2022-06-25 23:58:40.136371
# Unit test for method filter of class Try
def test_Try_filter():
    try_1 = Try.of(int, str_0)
    try_2 = Try.of(int, 'a')
    try_3 = Try.of(int, 0)
    # try_1.filter(lambda x: x == 0)
    assert try_1 == Try(0, True)
    assert try_2 == Try(ValueError("invalid literal for int() with base 10: 'a'"), False)
    assert try_3 == Try(0, True)
    assert try_2.filter(lambda x: x == 0) == Try(ValueError("invalid literal for int() with base 10: 'a'"), False)
    assert try_1.filter(lambda x: x == 0) == Try(0, True)
    assert try_3.filter(lambda x: x == 0) == Try(0, True)


# Generated at 2022-06-25 23:58:47.487120
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, '0').filter(lambda x: x > 0) == Try(0, True)
    assert Try.of(int, '0').filter(lambda x: x < 0) == Try(0, False)
    assert Try.of(int, '0').filter(lambda x: x == 0) == Try(0, True)
    assert Try.of(int, '0').filter(lambda x: x > 7) == Try(0, False)
    assert Try.of(int, '0').filter(lambda x: x < 7) == Try(0, True)
    assert Try.of(int, '0').filter(lambda x: x == 7) == Try(0, False)



# Generated at 2022-06-25 23:58:52.556186
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(lambda: int(str_0))
    try_1 = try_0.filter(lambda x: x > 1)
    assert try_1 == Try(0, False)
    try_2 = try_0.filter(lambda x: x <= 1)
    assert try_2 == Try(0, True)



# Generated at 2022-06-25 23:58:55.090567
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, str_0).filter(lambda x: x == 0)\
        == Try(0, True)


# Generated at 2022-06-25 23:59:06.290744
# Unit test for method filter of class Try
def test_Try_filter():
    # Test case 0
    try_0 = Try.of(int, '0')
    try_0_filterer = lambda value: value == 0
    try_0_filtered = try_0.filter(try_0_filterer)
    assert try_0_filtered == Try(0, True)

    # Test case 1
    try_1 = Try.of(int, '1')
    try_1_filterer = lambda value: value == 0
    try_1_filtered = try_1.filter(try_1_filterer)
    assert try_1_filtered == Try(try_1.value, False)

    # Test case 2
    try_2 = Try.of(int, 'abc')
    try_2_filterer = lambda value: value == 0
    try_2_fil

# Generated at 2022-06-25 23:59:14.321927
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: str_0).filter(lambda x: not x.isdigit()) == Try('0', True)
    assert Try.of(lambda: str_0).filter(lambda x: x.isdigit()) == Try('0', False)
    assert Try.of(lambda: 2).filter(lambda x: x > 0) == Try(2, True)
    assert Try.of(lambda: 2).filter(lambda x: x < 0) == Try(2, False)
    assert Try.of(lambda: False).filter(lambda x: x) == Try(False, False)
    assert Try.of(lambda: False).filter(lambda x: not x) == Try(False, True)
    assert Try.of(lambda: True).filter(lambda x: not x) == Try(True, False)
    assert Try.of

# Generated at 2022-06-25 23:59:16.875019
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, str_0).filter(lambda x: x == 0) == Try(0, True)
    assert Try.of(int, str_0).filter(lambda x: x != 0) == Try(0, False)

# Generated at 2022-06-25 23:59:24.555815
# Unit test for method filter of class Try
def test_Try_filter():

    # when monad is successfully and filterer return true
    assert Try.of(lambda: str_0).filter(lambda x: x != '') == Try(str_0, True)
    # when monad is successfully and filterer return false
    assert Try.of(lambda: str_0).filter(lambda x: x == '') == Try(str_0, False)
    # when monad is not successfully
    assert Try.of(lambda: 1/0).filter(lambda x: x != '') == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1/0).filter(lambda x: x == '') == Try(ZeroDivisionError(), False)


# Generated at 2022-06-25 23:59:33.004169
# Unit test for method filter of class Try
def test_Try_filter():
    try_int_0 = Try.of(lambda x: int, str_0)

    # When monad is not successfully,
    # filterer function should not be called

# Generated at 2022-06-25 23:59:39.386773
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(int, '0')
    try_not_0 = Try.of(int, '1')

    assert (try_0.filter(lambda x: x == 0) == Try(0, True))
    assert (try_0.filter(lambda x: x == 1) == Try(0, False))
    assert (try_not_0.filter(lambda x: x == 0) == Try(1, False))
    assert (try_not_0.filter(lambda x: x == 1) == Try(1, True))


# Generated at 2022-06-25 23:59:54.561594
# Unit test for method filter of class Try
def test_Try_filter():
    # Filter successfully
    assert Try.of(lambda: int(str_0), str_0).filter(lambda x: x == 0).is_success
    # Filter not successfully
    assert not Try.of(lambda: int(str_0), str_0).filter(lambda x: x != 0).is_success



# Generated at 2022-06-26 00:00:03.820698
# Unit test for method filter of class Try
def test_Try_filter():
    # Case successfully Try, filterer returns True.
    # When filterer returns True method should return successfully Try with previous value.
    ut_case_1 = Try(0, True).filter(lambda x: x == 0)
    str_ut_case_1 = 'Try[value=0, is_success=True]'
    assert str(ut_case_1) == str_ut_case_1

    # Case successfully Try, filterer returns False.
    # When filterer returns False method should return not successfully Try with previous value.
    ut_case_2 = Try(0, True).filter(lambda x: x != 0)
    str_ut_case_2 = 'Try[value=0, is_success=False]'
    assert str(ut_case_2) == str_ut_case_2

    # Case not successfully Try

# Generated at 2022-06-26 00:00:13.257759
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(test_case_0).map(lambda obj: str(obj)).filter(lambda value: value == '0') == Try('0', True)
    assert Try.of(test_case_0).map(lambda obj: str(obj)).filter(lambda value: value != '0') == Try('0', False)
    assert Try.of(test_case_0).map(lambda obj: str(obj)).filter(lambda value: False) == Try('0', False)
    assert Try.of(test_case_0).map(lambda obj: str(obj)).filter(lambda value: True) == Try('0', True)



# Generated at 2022-06-26 00:00:19.923825
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return True

    assert Try(None, True).filter(filterer) == Try(None, True)

    def filterer(value):
        return True

    assert Try(None, False).filter(filterer) == Try(None, False)

    def filterer(value):
        return False

    assert Try(None, True).filter(filterer) == Try(None, False)


# Unittest for method map of class Try

# Generated at 2022-06-26 00:00:21.754491
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(test_case_0) == Try(None, True)


# Generated at 2022-06-26 00:00:30.726398
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '0'
    val = Try.of(str_0.isdigit)
    val_f = val.filter(lambda x: x)
    val = Try.of(str_0.isdigit, str_0)
    val_f = val.filter(lambda x: x)

    assert val == val_f
    assert val_f.is_success

    str_a = 'a'
    val = Try.of(str_a.isdigit, str_a)
    val_f = val.filter(lambda x: x)

    assert val != val_f
    assert not val_f.is_success



# Generated at 2022-06-26 00:00:37.379506
# Unit test for method filter of class Try
def test_Try_filter():
    number = Try(3, True)

    def is_even(value):
        return value % 2 == 0

    unsuccess_Try = number.filter(is_even)
    success_Try = number.filter(lambda x: x % 3 == 0)

    assert unsuccess_Try.get() == number.get()
    assert unsuccess_Try.is_success == False

    assert success_Try.get() == number.get()
    assert success_Try.is_success == True



# Generated at 2022-06-26 00:00:38.717914
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(Try.get_or_else, test_case_0, '0').bind(lambda x: Try.of(int, x)).filter(lambda x: x == 0) == Try(0, True)


# Generated at 2022-06-26 00:00:42.506746
# Unit test for method filter of class Try
def test_Try_filter():
    # When monad is successfully
    assert Try.of(int, str_0).map(lambda x: x * 2)\
        .filter(lambda x: x == 0)\
        .get_or_else(-1) == 0
    # When monad is not successfully
    assert Try.of(int, str_0[1:]).map(lambda x: x * 2)\
        .filter(lambda x: x == 0)\
        .get_or_else(-1) == -1


# Generated at 2022-06-26 00:00:46.170037
# Unit test for method filter of class Try
def test_Try_filter():
    def is_num(s: str):
        return s.isnumeric()

    str_0 = Try.of(lambda i: int(i), '0')
    str_0 = str_0.filter(is_num)

    assert str_0 == Try(0, True)



# Generated at 2022-06-26 00:01:07.783695
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(test_case_0).filter(lambda x: isinstance(x, str)) == Try('0', True)
    assert Try.of(test_case_0).filter(lambda x: not isinstance(x, str)) == Try('0', False)


# Generated at 2022-06-26 00:01:13.307723
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, str_0).filter(lambda i: i == 0) == Try(0, True)
    assert Try.of(int, str_0).filter(lambda i: i != 0) == Try(0, False)


# Generated at 2022-06-26 00:01:18.943570
# Unit test for method filter of class Try
def test_Try_filter():
    def str_to_int(str_val):
        return int(str_val)

    def int_is_even(int_val):
        return int_val % 2 == 0

    def str_to_int_is_even(str_val):
        str_to_int_result = str_to_int(str_val)
        return int_is_even(str_to_int_result)

    try_0 = Try.of(str_to_int, '0')

    assert(try_0.filter(int_is_even) == Try(0, True))
    assert(try_0.filter(str_to_int_is_even) == Try(0, True))

    try_1 = Try.of(str_to_int, '1')


# Generated at 2022-06-26 00:01:24.238933
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: int(str_0), str_0).filter(lambda a: a == 0).get() == 0
    assert Try.of(lambda: int(str_0), str_0).filter(lambda a: a == 1).is_success == False
    assert Try.of(lambda: int(str_0), str_0).filter(lambda a: a == 1).get() == 0

# Generated at 2022-06-26 00:01:32.686187
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(int, str_0)
    try_0 = try_0.filter(lambda x: x > 0)
    assert try_0 == Try(0, False)

    try_1 = Try.of(int, str_0)
    try_1 = try_1.map(lambda x: x + 1)
    assert try_1 == Try(1, True)

    try_2 = try_1.filter(lambda x: x > 0)
    assert try_2 == Try(1, True)

    try_3 = try_1.bind(lambda x: Try.of(int, str(x+1)))
    assert try_3 == Try(2, True)

    try_4 = try_3.filter(lambda x: x > 0)
    assert try_4 == Try(2, True)

# Generated at 2022-06-26 00:01:41.619036
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = '0'
    str_1 = '1'
    str_2 = '2'
    str_3 = '3'
    str_4 = '4'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3

    def int_from_str(str_):
        if str_.isdigit():
            return int(str_)
        raise ValueError('string is not digit')

    # Try[2]
    try_int_2 = Try.of(int_from_str, str_2)
    # Try[1]
    try_int_1 = Try.of(int_from_str, str_1)

    # Try[False]
    try_false = Try.of(int_from_str, str_3)
   

# Generated at 2022-06-26 00:01:49.851200
# Unit test for method filter of class Try
def test_Try_filter():
    def argument_function_1(arg):
        return int(arg)

    success_Try = Try.of(argument_function_1, '1')
    success_Try_filter = success_Try.filter(lambda x: x == 1)

    assert success_Try_filter == Try(1, True) and success_Try_filter is not success_Try

    def argument_function_0(arg):
        return int(arg)

    success_Try = Try.of(argument_function_0, '0')
    success_Try_filter = success_Try.filter(lambda x: x != 0)

    assert success_Try_filter == Try(0, False) and success_Try_filter is not success_Try


# Generated at 2022-06-26 00:01:55.650479
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: '0').filter(lambda x: x == '0') == Try('0', True)
    assert Try.of(lambda: 0).filter(lambda x: x == 0) == Try(0, True)
    assert Try.of(lambda: True).filter(lambda x: x is True) == Try(True, True)
    assert Try.of(lambda: 1/0).filter(lambda x: x is 0) == Try(1/0, False)


# Generated at 2022-06-26 00:02:06.046229
# Unit test for method filter of class Try
def test_Try_filter():
    # Test 0
    # Test input:
    #   str_0 = '0'
    # Test output:
    #   Try[value='0', is_success=False]
    # Test comment:
    #   when empty string passed to parseInt function this function return '0'.
    #   Filtered value is at least 4 characters long.
    #   so that filterer function returns False, not successfully Try is expected
    str_0 = '0'
    try_0 = Try.of(parseInt, str_0).filter(lambda x: len(x) >= 4)
    assert try_0 == Try(str_0, False)

    # Test 1
    # Test input:
    #   str_0 = '0'
    # Test output:
    #   Try[value='0', is_success=True]
    #

# Generated at 2022-06-26 00:02:10.161085
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value

    # Test 0
    try_0 = Try(None, True)
    assert try_0.filter(filterer) == Try(None, False)

    # Test 1
    try_1 = Try([1, 2, 3], True)
    assert try_1.filter(filterer) == Try([1, 2, 3], True)



# Generated at 2022-06-26 00:02:59.365698
# Unit test for method filter of class Try
def test_Try_filter():
    """
        Try.filter(filterer: Function(T) -> Boolean) -> Try[T | U]
        when monad is successfully call filterer with monad value.
        When filterer returns True method returns copy of monad, othercase
        not successfully Try with previous value.

        :params filterer: function to apply on monad value
        :type filterer: Function(A) -> Boolean
        :returns: Try with previous value
        :rtype: Try[A]
    """
    def filter_0(value):
        return value == 0
    def filter_1(value):
        return value == 1

    try_0 = Try.of(int, '0')
    try_1 = Try.of(int, '1')
    try_fail = Try.of(int, 'a')
    try_