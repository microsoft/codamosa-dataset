

# Generated at 2022-06-25 23:53:07.511963
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(False, True)
    try_2 = try_0.map(lambda value: value)
    assert(try_0 == try_1) == False
    assert(try_0 == try_2) == True


# Generated at 2022-06-25 23:53:10.797818
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    bool_00 = True
    try_00 = try_0.filter(lambda a: bool_00)

    assert try_00 == try_00


# Generated at 2022-06-25 23:53:13.574179
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool(1), bool_0)
    assert try_0.__eq__(try_1) == False


# Generated at 2022-06-25 23:53:17.184087
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try("a", True).filter(lambda x: x == 'a') == Try("a", True)
    assert Try("b", True).filter(lambda x: x == 'a') == Try("b", False)



# Generated at 2022-06-25 23:53:21.006333
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: True).filter(lambda x: x) == Try(True, True)
    assert Try.of(lambda: False).filter(lambda x: x) == Try(False, False)



# Generated at 2022-06-25 23:53:26.575395
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    bool_1 = True
    try_1 = Try(bool_0, bool_1)
    test_value = try_0.__eq__(try_1)
    assert type(test_value) is bool


# Generated at 2022-06-25 23:53:35.064663
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0)
    try_2 = Try(bool_0, bool_0)
    assert try_0 == try_0
    assert try_0 == try_1
    assert try_1 == try_0
    assert try_0 == try_2
    assert try_2 == try_0
    assert not (try_0 != try_0)
    assert not (try_0 != try_1)
    assert not (try_1 != try_0)
    assert not (try_0 != try_2)
    assert not (try_2 != try_0)
    bool_1 = False
    try_3 = Try(bool_1, bool_1)

# Generated at 2022-06-25 23:53:47.614126
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(bool) == Try(True, True)
    assert Try('True', True).filter(lambda x: x == 'True') == Try('True', True)
    assert Try('1', True).filter(lambda x: x == 'True') == Try('1', False)
    assert Try('True', False).filter(lambda x: x == 'True') == Try('True', False)
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == '1') == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)


# Generated at 2022-06-25 23:53:52.848359
# Unit test for method filter of class Try
def test_Try_filter():
    bool_1 = True
    bool_0 = False
    try_1 = Try(bool_1, bool_1)
    try_0 = Try(bool_0, bool_0)

    assert None == try_1.filter(lambda x: x == bool_1)
    assert None == try_0.filter(lambda x: x == bool_1)



# Generated at 2022-06-25 23:54:01.409083
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(lambda x: 1 / 0, None)
    try_0 = try_0.filter(lambda x: x < 3)
    assert(try_0 == Try(ZeroDivisionError, False))
    try_0 = Try(3, True)
    try_0 = try_0.filter(lambda x: x < 3)
    assert(try_0 == Try(3, False))
    try_1 = Try.of(lambda x: x + 1, 2)
    try_1 = try_1.filter(lambda x: x < 3)
    assert(try_1 == Try(2, True))


# Generated at 2022-06-25 23:54:09.171390
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False

    def filterer(value):
        return value

    try_0 = Try(bool_0, bool_0)
    try_1 = try_0.filter(filterer)



# Generated at 2022-06-25 23:54:10.791416
# Unit test for method filter of class Try
def test_Try_filter():
    pass


# Generated at 2022-06-25 23:54:18.519785
# Unit test for method filter of class Try
def test_Try_filter():
    assert \
    Try.of(int, '1')\
        .filter(lambda n: n > 0)\
        == Try(1, True)
    assert \
    Try.of(int, '-1')\
        .filter(lambda n: n > 0)\
        == Try(-1, False)
    assert \
    Try.of(int, 'a')\
        .filter(lambda n: n > 0)\
        == Try(ValueError("invalid literal for int() with base 10: 'a'"), False)



# Generated at 2022-06-25 23:54:31.716607
# Unit test for method filter of class Try
def test_Try_filter():
    # First test case
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    test_case_0 = try_0.filter(lambda x: True)
    assert test_case_0.is_success == True
    # Second test case
    bool_1 = True
    try_1 = Try(bool_1, not bool_1)
    test_case_1 = try_1.filter(lambda x: True)
    assert test_case_1.is_success == False
    # Third test case
    bool_2 = True
    try_2 = Try(bool_2, bool_2)
    test_case_2 = try_2.filter(lambda x: False)
    assert test_case_2.is_success == False

# Generated at 2022-06-25 23:54:35.312697
# Unit test for method filter of class Try
def test_Try_filter():
    source = [1, 2, 3, 4]
    result = Try\
            .of(lambda: source[2])\
            .map(lambda a: a + 2)\
            .filter(lambda a: a > 2)\
            .get()
    assert result is 5



# Generated at 2022-06-25 23:54:40.941924
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(val):
        return val > 2
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    try_1 = try_0.filter(filterer)
    bool_1 = try_1.is_success
    print(bool_1)


# Generated at 2022-06-25 23:54:51.296930
# Unit test for method filter of class Try
def test_Try_filter():
    # Test for successfully Try monad with value == True
    try_0 = Try(True, True)
    # filterer should return true for successfully Try monad with value == True
    filterer_0 = lambda value: value
    # returns Try(True, True) due to successfully Try monad with value == True and filterer function returns True
    try_1 = try_0.filter(filterer_0)
    # returns Try(False, False) due to successfully Try monad with value == True and filterer function returns False
    filterer_1 = lambda value: not value
    try_2 = try_0.filter(filterer_1)

    # Test for successfully Try monad with value == False
    try_3 = Try(False, True)
    # returns Try(False, True) due to successfully Try monad with

# Generated at 2022-06-25 23:54:56.173559
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(3.14, True).filter(lambda x: True) == Try(3.14, True)
    assert Try(3.14, True).filter(lambda x: False) == Try(3.14, False)
    assert Try(3.14, False).filter(lambda x: True) == Try(3.14, False)



# Generated at 2022-06-25 23:55:04.167461
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = False
    bool_1 = True
    try_0 = Try(bool_0, True)
    try_filtered = try_0.filter(lambda x: x)

    assert try_filtered.is_success == False
    assert try_filtered.value == bool_0

    try_1 = Try(bool_1, True)
    try_filtered = try_1.filter(lambda x: x)

    assert try_filtered.is_success == True
    assert try_filtered.value == bool_1


# Generated at 2022-06-25 23:55:10.632050
# Unit test for method filter of class Try
def test_Try_filter():
    bool_1 = True
    try_1 = Try(bool_1, bool_1)

    def filterer(value):
        return value

    bool_2 = filterer(bool_1)
    try_2 = try_1.filter(filterer)
    assert bool_2 == try_2.get()



# Generated at 2022-06-25 23:55:15.799955
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert str(try_0) == 'Try[value=True, is_success=True]'


# Generated at 2022-06-25 23:55:19.263528
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-25 23:55:22.903204
# Unit test for method get of class Try
def test_Try_get():
    assert Try(True, True).get() == True
    assert Try(True, False).get() == True
    assert Try('a', True).get() == 'a'
    assert Try('a', False).get() == 'a'


# Generated at 2022-06-25 23:55:25.519362
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(None, False).get_or_else(1) == 1


# Generated at 2022-06-25 23:55:36.495927
# Unit test for method map of class Try
def test_Try_map():
    """
    Try.map test.
    """
    class String:
        def __init__(self, value) -> None:  # pragma: no cover
            self.value = value

        def to_upper(self):
            return self.value.upper()

    string_0 = String('aaa')
    string_1 = String('bbb')

    try_0 = Try(string_0, True)
    try_1 = Try(string_1, False)

    assert try_0.map(lambda x: x.to_upper()) == Try(string_0.to_upper(), True)
    assert try_1.map(lambda x: x.to_upper()) == Try(string_1.to_upper(), False)


# Generated at 2022-06-25 23:55:38.947873
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try('foo', True).get() == 'foo'
    assert Try(True, True).get()
    assert Try(None, True).get() is None



# Generated at 2022-06-25 23:55:43.354893
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_0 = Try(True, True)
    assert try_0.get_or_else(False)
    try_0 = Try(True, False)
    assert not try_0.get_or_else(False)


# Generated at 2022-06-25 23:55:52.763364
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    assert try_0.is_success == bool_0, 'Try value should be same as provided to constructor'
    assert try_0.value == bool_0, 'Try is_success flag should be same as provided to constructor'

    bool_0 = False
    try_0 = Try(bool_0, bool_0)

    assert try_0.is_success == bool_0, 'Try value should be same as provided to constructor'
    assert try_0.value == bool_0, 'Try is_success flag should be same as provided to constructor'

# Try of function

# Generated at 2022-06-25 23:55:59.431695
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    counter = 0
    def check_something(x):
        nonlocal counter
        if x == 5:
            counter += 1
            return Try(True, True)
        return Try(False, False)

    check_something(5).bind(lambda x: Try(5, True)).filter(lambda x: x == 5).on_fail(
        lambda x: print('ERROR {}'.format(x))).on_success(lambda x: print('SUCCESS {}'.format(x)))
    assert counter == 1



# Generated at 2022-06-25 23:56:00.955384
# Unit test for method get of class Try
def test_Try_get():
    assert_method(Try, 'get', 2, Try(2, True))


# Generated at 2022-06-25 23:56:11.621881
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0)

    try_2 = Try(bool_0, not bool_0)
    try_3 = Try(not bool_0, not bool_0)

    try_4 = Try(bool_0, not bool_0)
    try_5 = Try(not bool_0, bool_0)


# Generated at 2022-06-25 23:56:17.268062
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(value):
        return Try(not value, True)

    try_0 = Try(True, True)
    try_1 = try_0.bind(binder)
    if try_0.value == True and try_0 == binder(try_0.value):
        pass
    else:
        raise Exception("Test Try_bind error")


# Generated at 2022-06-25 23:56:25.713324
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    def fn_0(value):
        return not value
    def fn_1(value):
        return not value
    try_1 = try_0.on_success(fn_0)
    assert try_1.value == bool_0
    assert try_1 is not try_0
    assert try_1.is_success is not try_0.is_success
    try_2 = try_0.on_success(fn_1)
    assert try_2 is try_1
    assert try_2 == try_1
    bool_1 = False
    try_3 = Try(bool_1, bool_1)
    def fn_2(value):
        return not value

# Generated at 2022-06-25 23:56:32.833731
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = False
    exception_0 = Exception()
    try_0 = Try(True, bool_0)
    # State check before method call
    assert try_0.value is True
    assert try_0.is_success is bool_0
    # Method call
    str_0 = try_0.__str__()
    # State check after method call
    assert try_0.value is True
    assert try_0.is_success is bool_0
    assert str_0 == 'Try[value=True, is_success=False]'



# Generated at 2022-06-25 23:56:36.202172
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.is_success == bool_0
    assert try_0.value == bool_0

# Function returns True when succeed with Try[Boolean]

# Generated at 2022-06-25 23:56:43.811587
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    value_0 = True
    value_1 = False
    try_0 = Try(value_0, value_0)
    try_1 = Try(value_1, value_1)
    try_2 = Try(value_0, value_0)
    try:
        assert(try_0 == try_2)
        assert(try_0 != try_1)
    except AssertionError as e:  # pragma: no cover
        print(e)



# Generated at 2022-06-25 23:56:48.311232
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, not bool_0)
    assert str(try_0) == "Try[value=True, is_success=True]"
    assert str(try_1) == "Try[value=True, is_success=False]"



# Generated at 2022-06-25 23:56:56.871258
# Unit test for method map of class Try
def test_Try_map():
    bool_0 = False
    try_0 = Try(bool_0, bool_0)

    try_1 = try_0.map(lambda e: e)

    bool_1 = bool_0 == try_1.get() == try_0.get() == bool_0
    assert bool_1

    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    bool_1 = bool_0 == try_0.map(lambda e: e).get() == try_0.get() == bool_0
    assert bool_1



# Generated at 2022-06-25 23:57:04.084724
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    success_callback = lambda x: print(x)
    fail_callback = lambda x: print(x.__class__.__name__)

    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.on_fail(fail_callback) == try_0

    try_1 = Try(Exception(), False)
    assert try_1.on_fail(fail_callback) == try_1

    try_1.on_fail(fail_callback)


# Generated at 2022-06-25 23:57:11.149521
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(5, True)
    try_1 = try_0.filter(lambda arg_0: arg_0 > 0)
    assert isinstance(try_1, Try)
    try_2 = try_0.filter(lambda arg_0: arg_0 < 0)
    assert isinstance(try_2, Try)
    assert try_1.value == try_0.value
    assert not try_2.is_success


# Generated at 2022-06-25 23:57:21.018177
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    def callback_0(arg_0): pass
    try_0.on_fail(callback_0)


# Generated at 2022-06-25 23:57:23.935769
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert str(try_0) == 'Try[value=True, is_success=True]'


# Generated at 2022-06-25 23:57:30.032268
# Unit test for method map of class Try
def test_Try_map():
    bool_0 = True
    bool_1 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_0)
    assert try_0.map(lambda x: x is True) == Try(bool_0, bool_0)
    assert try_1.map(lambda x: x is True) == Try(bool_1, bool_0)


# Generated at 2022-06-25 23:57:39.339747
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filter_when_True(value):
        def test_filter_when_True(value):
            bool_0 = bool()
            bool_0 = True
            try_0 = Try(bool_0, bool_0)
            try_1 = try_0.filter(value)
            str_0 = str()
            str_0 = str(try_1)
            assert str_0 == "Try[value=True, is_success=True]"
        value(test_filter_when_True)
    test_filter_when_True(test_filter_when_True)

    def test_filter_when_False(value):
        def test_filter_when_False(value):
            bool_0 = bool()
            bool_0 = True
            try_0 = Try(bool_0, False)
            try_

# Generated at 2022-06-25 23:57:40.892568
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(233, False).on_fail(print) == Try(233, False)
    assert Try("spam", True).on_fail(print) == Try("spam", True)



# Generated at 2022-06-25 23:57:45.925687
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda v: Try(v, True)) == Try(1, True)
    assert Try(1, True).bind(lambda v: Try(2, False)) == Try(2, False)
    assert Try(1, False).bind(lambda v: Try(v, True)) == Try(1, False)
    assert Try(1, False).bind(lambda v: Try(2, False)) == Try(2, False)


# Generated at 2022-06-25 23:57:47.870527
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(int(10), True).on_fail(lambda e: print(e)) == Try(10, True)



# Generated at 2022-06-25 23:57:52.084849
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(True, True).on_success(lambda value: print(value)) == Try(True, True)
    assert Try(True, False).on_success(lambda value: print(value)) == Try(True, False)


# Generated at 2022-06-25 23:58:00.969204
# Unit test for method on_success of class Try
def test_Try_on_success():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    class Mock_success_callback:
        def __init__(self, expected_value):
            self.expected_value = expected_value
            self.actual_value = None

        def __call__(self, argument):
            self.actual_value = argument

        def is_equals_to(self, other_value):
            return self.actual_value == other_value

    mock_success_callback = Mock_success_callback(bool_0)
    try_0.on_success(mock_success_callback)

    assert mock_success_callback.is_equals_to(bool_0)

    bool_1 = False
    try_1 = Try(bool_1, bool_1)
    mock_success_callback = Mock

# Generated at 2022-06-25 23:58:06.989990
# Unit test for method filter of class Try
def test_Try_filter():
    # when filterer function return True
    try_0 = Try(0, False).filter(lambda x: x == 0)
    try_1 = Try(False, False).filter(lambda x: not x)
    assert not try_0.is_success
    assert not try_1.is_success
    # when filterer function return False
    try_2 = Try(0, True).filter(lambda x: x == 0)
    try_3 = Try(False, True).filter(lambda x: not x)
    assert try_2.is_success
    assert try_3.is_success


# Generated at 2022-06-25 23:58:25.793733
# Unit test for method on_success of class Try
def test_Try_on_success():
   bool_0 = True
   try_0 = Try(bool_0, bool_0)
   bool_1 = (not bool_0)
   bool_result = bool_0
   try_0.on_success(None)
   bool_result = (bool_result and try_0.is_success)
   bool_result = (bool_result and try_0.value)
   assert(bool_result)


# Generated at 2022-06-25 23:58:32.962765
# Unit test for method __str__ of class Try
def test_Try___str__():
    bool_1 = True
    try_1 = Try(bool_1, bool_1)
    assert str(try_1) == "Try[value={}, is_success={}]".format(bool_1, bool_1)

    bool_2 = False
    try_2 = Try(bool_2, bool_2)
    assert str(try_2) == "Try[value={}, is_success={}]".format(bool_2, bool_2)



# Generated at 2022-06-25 23:58:35.649319
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert(str(Try(True, True)) == "Try[value=True, is_success=True]")


# Generated at 2022-06-25 23:58:40.012429
# Unit test for method on_success of class Try
def test_Try_on_success():

    # generate function to apply on monad value
    def success_callback(bool_0):
        assert bool_0
    # generate monad Try
    def fn_0(*args):
        return True
    try_0 = Try.of(fn_0)
    # call on_success method with success_callback function
    try_0.on_success(success_callback)

# Generated at 2022-06-25 23:58:44.378946
# Unit test for method get of class Try
def test_Try_get():
    assert Try(True, True).get() == True
    assert Try('Hi', True).get() == 'Hi'
    assert Try(10, True).get() == 10
    assert Try({'hi': 'hi'}, True).get() == {'hi': 'hi'}
    assert Try(('hi', 3), True).get() == ('hi', 3)


# Generated at 2022-06-25 23:58:47.286147
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # 1. test case
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    bool_1 = True
    try_1 = Try(bool_1, bool_1)

    assert try_0 == try_1


# Generated at 2022-06-25 23:58:48.518168
# Unit test for constructor of class Try
def test_Try():
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-25 23:59:00.354102
# Unit test for method map of class Try
def test_Try_map():
    # Try -> Option
    value = Try.of(identity, 1)
    value_1 = value.map(int)
    assert value_1 == Try(1, True)

    # Value not None
    value = Try.of(identity, "1")
    value_1 = value.map(identity)
    assert value_1 == Try("1", True)
    value_2 = value.map((lambda n: n*2))
    assert value_2 == Try("11", True)

    # Value None
    try_0 = Try(None, False)
    try_1 = try_0.map(identity)
    assert try_1 == Try(None, False)
    try_2 = try_0.map((lambda n: n*2))
    assert try_2 == Try(None, False)


#

# Generated at 2022-06-25 23:59:05.499766
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = False
    assert Try.of(int, '101').bind(lambda x: Try(x, bool_0) == Try(101, bool_0))
    assert Try.of(int, 'a').bind(lambda x: Try(x, bool_0) == Try('a', not bool_0))


# Generated at 2022-06-25 23:59:08.366064
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert(Try(True, True) == Try(True, True))
    assert(not Try(False, False) == Try(False, True))
    assert(not Try(True, False) == Try(False, False))


# Generated at 2022-06-25 23:59:41.229030
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0 == Try(bool_0, True)



# Generated at 2022-06-25 23:59:49.632445
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    # Test returns Try with value of binder function when inside Try is successful
    def binder_0(arg_0):
        return arg_0
    try_1 = try_0.bind(binder_0)
    assert isinstance(try_1, Try) and try_1.get() == bool_0
    # Test returns try_0 when is not successful
    def binder_1(arg_0):
        return arg_0
    try_2 = try_1.bind(binder_1)
    assert isinstance(try_2, Try) and try_2.get() == bool_0
    # Test returns Try with value of binder function when inside Try is successful
    def binder_2(arg_0):
        return

# Generated at 2022-06-25 23:59:59.271827
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    result = Try(True, True) == Try(True, True)
    assert result
    result = Try(1, True) == Try(1, True)
    assert result
    result = Try('4', True) == Try('4', True)
    assert result
    result = Try(True, True) == Try(True, False)
    assert not result
    result = Try('4', True) == Try('4', False)
    assert not result
    result = Try(1, True) == Try(1, False)
    assert not result
    result = Try(1, False) == Try(1, False)
    assert result
    result = Try(True, False) == Try(True, False)
    assert result
    result = Try('4', False) == Try('4', False)
    assert result

# Generated at 2022-06-26 00:00:00.143097
# Unit test for method get of class Try
def test_Try_get():
    test_case_0()


# Generated at 2022-06-26 00:00:04.613375
# Unit test for method get of class Try
def test_Try_get():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.get() is bool_0

    bool_1 = False
    try_1 = Try(bool_1, bool_1)
    assert try_1.get() is bool_1



# Generated at 2022-06-26 00:00:10.403630
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    bool_0 = True
    bool_1 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_0, bool_0)
    try_2 = Try(bool_1, bool_0)
    assert try_0 == try_1
    assert not try_0 == try_2


# Generated at 2022-06-26 00:00:15.120216
# Unit test for method filter of class Try
def test_Try_filter():
    true_bool = True
    false_bool = False
    try_true = Try(true_bool, true_bool)
    try_false = Try(false_bool, false_bool)

    def filterer_true(_):
        return True

    def filterer_false(_):
        return False

    assert try_true.filter(filterer_true) == Try(true_bool, true_bool)
    assert try_true.filter(filterer_false) == Try(true_bool, false_bool)
    assert try_false.filter(filterer_true) == Try(false_bool, false_bool)
    assert try_false.filter(filterer_false) == Try(false_bool, false_bool)



# Generated at 2022-06-26 00:00:17.535521
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda x: x, 2).on_success(lambda x: x + 2) == Try(4, True)
    assert Try.of(lambda x: x, Exception()).on_success(lambda x: x + 2) == Try(Exception(), False)


# Generated at 2022-06-26 00:00:28.513670
# Unit test for method map of class Try
def test_Try_map():
    assert Try(2, True).map(lambda x: x + 1) == Try(3, True)
    assert Try(None, True).map(lambda x: x + 1) == Try(None, True)
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, True).map(lambda x: x * 2) == Try(2, True)
    assert Try(1, True).map(lambda x: x / 2) == Try(0.5, True)
    assert Try(1, True).map(lambda x: False) == Try(False, True)
    assert Try(1, True).map(lambda x: True) == Try(True, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)
   

# Generated at 2022-06-26 00:00:34.210949
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = True
    bool_1 = False
    value_0 = 0
    try_0 = Try(value_0, bool_0)
    try_1 = Try(value_0, bool_1)
    value_1 = 1

    assert try_0.get_or_else(value_1) == value_0
    assert try_1.get_or_else(value_1) == value_1


# Generated at 2022-06-26 00:01:43.816509
# Unit test for method filter of class Try
def test_Try_filter():

    def check(leaf):
        return leaf
    def nocheck(leaf):
        return False

    # check(Try(100, True).filter(check).is_success)
    # check(not Try(100, True).filter(nocheck).is_success)
    # check(not Try(100, False).filter(check).is_success)
    # check(not Try(100, False).filter(nocheck).is_success)
    pass



# Generated at 2022-06-26 00:01:49.312864
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    bool_0 = True
    expected = bool_0
    try_0 = Try(bool_0, bool_0)
    try:
        result = try_0.on_fail(lambda bool_1: bool_1)
        is_success = result.is_success
        assert is_success == expected
    except Exception as e:
        log.info(e)
        log.info("test_Try_on_fail failed.")


# Generated at 2022-06-26 00:01:53.224333
# Unit test for method bind of class Try
def test_Try_bind():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)

    def binder(value):
        return Try(not value, not value)

    try_1 = try_0.bind(binder)
    assert not try_0.value
    assert not try_1.value


# Generated at 2022-06-26 00:01:57.634591
# Unit test for constructor of class Try
def test_Try():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert try_0.value == True
    assert try_0.is_success == True
    bool_1 = False
    try_1 = Try(bool_0, bool_1)
    assert try_1.value == True
    assert try_1.is_success == False


# Generated at 2022-06-26 00:02:01.766964
# Unit test for constructor of class Try
def test_Try():
    bool_1 = False
    try_1 = Try(bool_1, bool_1)

    assert isinstance(try_1, Try)
    assert try_1.is_success == bool_1



# Generated at 2022-06-26 00:02:03.017557
# Unit test for method __str__ of class Try
def test_Try___str__():
    # Test case 0
    try_0 = Try(2, True)
    str_0 = try_0.__str__()
    assert str_0 == 'Try[value=2, is_success=True]'


# Generated at 2022-06-26 00:02:06.700727
# Unit test for method map of class Try
def test_Try_map():
    test_case_0()
    bool_0 = True
    bool_1 = False
    try_0 = Try(bool_0, bool_0)
    try_1 = Try(bool_1, bool_1)
    try_2 = Try(bool_0, bool_0)
    try_3 = Try(bool_1, bool_1)
    try_4 = Try(bool_0, bool_0)
    try_5 = Try(bool_1, bool_1)
    try_6 = Try(bool_0, bool_0)
    try_7 = Try(bool_1, bool_1)
    try_8 = Try(bool_0, bool_0)
    try_9 = Try(bool_1, bool_1)
    try_10 = Try(bool_0, bool_0)
   

# Generated at 2022-06-26 00:02:12.237411
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    bool_0 = True
    try_0 = Try(bool_0, bool_0)
    assert bool_0 == try_0.get_or_else(False)

    bool_1 = False
    try_1 = Try(bool_1, bool_1)
    assert not bool_1 == try_1.get_or_else(True)

    bool_2 = True
    try_2 = Try(bool_2, not bool_2)
    assert bool_2 == try_2.get_or_else(False)

    bool_3 = False
    try_3 = Try(bool_3, not bool_3)
    assert bool_3 == try_3.get_or_else(True)

    bool_4 = True
    try_4 = Try(bool_4, bool_4)
    assert not bool_

# Generated at 2022-06-26 00:02:16.472395
# Unit test for method bind of class Try
def test_Try_bind():
    bool_1 = True
    try_1 = Try(bool_1, bool_1)

    assert try_1.bind(lambda x: Try(not x, not x)) == Try(False, False)

    bool_2 = False
    try_2 = Try(bool_2, not bool_2)

    assert try_2.bind(lambda x: Try(not x, not x)) == Try(False, True)


# Generated at 2022-06-26 00:02:20.711824
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    value = 1
    is_success = True
    assert Try(value, is_success) == Try(value, is_success)
    assert Try(value, is_success) != Try(value + 1, is_success)
    assert Try(value, is_success) != Try(value, is_success + 1)
