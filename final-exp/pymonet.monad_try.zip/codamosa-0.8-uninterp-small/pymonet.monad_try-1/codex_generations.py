

# Generated at 2022-06-25 23:52:58.374652
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(lambda: 1)
    try_0 = try_0.filter(lambda val_0: val_0 == 1)
    assert try_0.is_success


# Generated at 2022-06-25 23:53:03.976812
# Unit test for method filter of class Try
def test_Try_filter():
    original_dict_0 = {}
    new_dict_0 = {}
    bool_0 = True
    try_0 = Try(original_dict_0, bool_0)

    def filterer_0(self_0, arg_0):
        return True

    if filterer_0(try_0, filterer_0):
        try_0 = Try(new_dict_0, False)


# Generated at 2022-06-25 23:53:13.634763
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    dict_1 = dict_0
    dict_0_value = False
    bool_0 = True
    val_0 = Try.of(dict_0.__contains__, "key")
    val_1 = type(val_0)
    val_2 = type(val_1)
    val_3 = val_2.__getattribute__(val_0, "value")
    ret_0 = val_3
    ret_1 = val_2.__getattribute__(val_0, "is_success")
    bool_1 = bool_0 == ret_1
    ret_2 = val_2.__getattribute__(val_1, "value")
    bool_2 = bool_1 == ret_2



# Generated at 2022-06-25 23:53:24.969278
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    def function_0(argument_0):
        if argument_0:
            return bool
        return bool_0

    assert Try.of(function_0, try_0).filter(lambda v: v is True) == (Try(bool, True))
    assert Try.of(function_0, Try(try_0, bool_0)).filter(lambda v: v is True) == (Try(bool, True))
    assert Try.of(function_0, bool_0).filter(lambda v: v is True) == (Try(bool, True))
    assert Try.of(function_0, bool).filter(lambda v: v is True) != (Try(bool, True))



# Generated at 2022-06-25 23:53:30.848406
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)

    def func_0(arg_0):
        dict_0[arg_0] = arg_0

    try_0.filter(lambda arg_0: arg_0 == 1)
    assert not try_0.is_success
    try_0.filter(lambda arg_0: arg_0 == 0)
    assert try_0.is_success
    try_0.filter(lambda arg_0: arg_0 == 1)
    assert not try_0.is_success



# Generated at 2022-06-25 23:53:37.506050
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)

    dict_1 = {}
    bool_1 = True
    try_1 = Try(dict_1, bool_1)

    dict_2 = {}
    bool_2 = False
    try_2 = Try(dict_2, bool_2)

    dict_3 = {}
    bool_3 = False
    try_3 = Try(dict_3, bool_3)

    assert(try_0.filter({}.__contains__) == try_1)
    assert(try_0.filter({}.__contains__) != try_2)
    assert(try_0.filter({}.__contains__) != try_3)


# Generated at 2022-06-25 23:53:42.740131
# Unit test for method filter of class Try
def test_Try_filter():

    # Setup
    def filterer_0(value):
        return value == 1
    Try_0 = Try.of(int, '1')
    Try_0 = Try.of(int, '1').filter(filterer_0)

    # Assertion
    assert Try_0 == Try(1, True)



# Generated at 2022-06-25 23:53:52.392029
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value

    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    try_1 = try_0.filter(filterer)
    assert(try_1.value == try_0.value)
    assert(try_1.is_success == try_0.is_success)
    bool_0 = False
    try_0 = Try(dict_0, bool_0)
    try_1 = try_0.filter(filterer)
    assert(try_1.value == try_0.value)
    assert(try_1.is_success == try_0.is_success)
    bool_0 = True
    try_0 = Try(dict_0, bool_0)

# Generated at 2022-06-25 23:53:59.083694
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: True) == Try(True, True)
    assert Try(False, True).filter(lambda x: True) == Try(False, False)
    assert Try(True, False).filter(lambda x: True) == Try(True, False)
    assert Try(False, False).filter(lambda x: True) == Try(False, False)


# Generated at 2022-06-25 23:54:05.472735
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 0

    def success_callback(value):
        pass

    def fail_callback(value):
        pass

    try_0 = Try['Try'](0, True)
    try_1 = try_0.filter(filterer)
    value_1 = try_1.get()
    is_success_1 = try_1.is_success

    try_2 = Try['Try'](0, False)
    try_3 = try_2.filter(filterer)
    value_2 = try_3.get()
    is_success_2 = try_3.is_success

    assert value_1 == 0
    assert is_success_1
    assert value_2 == 0
    assert not is_success_2


# Generated at 2022-06-25 23:54:15.341731
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try(1, True)
    value_0 = try_0.filter(lambda x: x > 0)
    value_1 = Try(1, False).filter(lambda x: x > 0)
    assert value_0 == Try(1, True), "Try filter result error"
    assert value_1 == Try(1, False), "Try filter result error"


# Generated at 2022-06-25 23:54:21.029424
# Unit test for method filter of class Try
def test_Try_filter():
    str_0 = 'Test, successful'
    str_1 = 'Test string'
    def filterer(str_0):
        return True
    def filterer_0(str_1):
        return False
    Try.of(str, str_0).filter(filterer)
    Try.of(str, str_0).filter(filterer_0)


# Generated at 2022-06-25 23:54:31.675155
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(dict(), True).filter(lambda x: len(x) == 0) == Try(dict(), True)

    assert Try(dict(), True).filter(lambda x: len(x) > 0) == Try(dict(), False)

    assert Try(dict(), False).filter(lambda x: len(x) == 0) == Try(dict(), False)

    assert Try(dict(), False).filter(lambda x: len(x) > 0) == Try(dict(), False)

try_0 = Try.of(lambda x, y: x + y, 1, 2)


# Generated at 2022-06-25 23:54:39.330210
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(lambda: {})
    assert try_0.filter(lambda x: True) == Try({}, True)
    try_0 = Try.of(lambda: {})
    try_1 = try_0.filter(lambda x: False)
    assert try_1 == Try({}, False)
    try_0 = Try.of(lambda: TypeError("Wrong type"), "")
    try_1 = try_0.filter(lambda x: True)
    assert try_1 == Try("Wrong type", False)
    try_0 = Try.of(lambda: TypeError("Wrong type"), "")
    try_1 = try_0.filter(lambda x: False)
    assert try_1 == Try("Wrong type", False)


# Generated at 2022-06-25 23:54:49.988619
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {'a': 0, 'c': 2, 'b': 1}
    list_0 = [0, 1, 2, 3]

    def function_0(arg_0):
        assert arg_0 == dict_0
        return True
    try_0 = Try.of(lambda : dict_0)
    try_1 = try_0.filter(function_0)

    assert try_1.value == dict_0

    def function_1(arg_0):
        assert arg_0 == dict_0
        return False
    try_2 = try_0.filter(function_1)

    assert not try_2.is_success

    def function_2(arg_0):

        if 1 in arg_0:
            return True
        return False

# Generated at 2022-06-25 23:54:51.531750
# Unit test for method filter of class Try
def test_Try_filter():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 23:54:59.226482
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    dict_0.update({'key_0': 0.0})
    dict_0.update({'key_1': 1.0})
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    def func_0(arg_0):
        return arg_0['key_0'] == 0.0
    try_1 = try_0.filter(func_0)
    bool_1 = True
    bool_2 = try_1.is_success == bool_1


# Generated at 2022-06-25 23:55:04.979679
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    try_0 = Try(dict_0, True)
    dict_result = {}

    def function_1(arg_1):
        dict_result.update(arg_1)
        return True

    try_0.filter(function_1)
    assert dict_0 == dict_result
    assert try_0 == Try(dict_result, True)



# Generated at 2022-06-25 23:55:14.329239
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {'key_0': 0, 'key_1': 1, 'key_2': 2, 'key_3': 3, 'key_4': 4, 'key_5': 5, 'key_6': 6, 'key_7': 7, 'key_8': 8, 'key_9': 9}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    # Filter when value of key_0 is 0.
    bool_1 = bool_0
    try_1 = try_0.filter(lambda i: i['key_0'] == 0)
    # Assertions
    assert try_1.is_success is bool_1
    assert try_1.get()['key_0'] == 0
    assert try_1.get()['key_1'] == 1
   

# Generated at 2022-06-25 23:55:21.623033
# Unit test for method filter of class Try
def test_Try_filter():

    def fn_0(arg_0=None):
        arg_0['a']
        return None

    Try(None, False).filter(fn_0)
    Try(dict(), True).filter(fn_0)
    Try({'key': 'value'}, True).filter(fn_0)
    Try({'a': 'value'}, True).filter(fn_0)
    Try({'key': 'value', 'a': 'value'}, True).filter(fn_0)


# Generated at 2022-06-25 23:55:35.681899
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)

    dict_1 = {}
    bool_1 = True
    try_1 = Try(dict_1, bool_1)

    dict_2 = {}
    bool_2 = True
    try_2 = Try(dict_2, bool_2)

    dict_3 = {}
    bool_3 = True
    try_3 = Try(dict_3, bool_3)

    dict_4 = {}
    bool_4 = True
    try_4 = Try(dict_4, bool_4)

    dict_5 = {}
    bool_5 = True
    try_5 = Try(dict_5, bool_5)

    dict_6 = {}
    bool_6 = True

# Generated at 2022-06-25 23:55:45.948817
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(dict)
    try_1 = try_0.filter(lambda value: True)
    assert try_1.is_success
    assert try_1.value == {}
    try_2 = try_0.filter(lambda value: None)
    assert not try_2.is_success
    assert try_2.value == {}
    try_3 = Try(None, True)
    try_4 = try_3.filter(lambda value: True)
    assert not try_4.is_success
    assert try_4.value is None
    try_5 = Try(None, False)
    try_6 = try_5.filter(lambda value: True)
    assert not try_6.is_success
    assert try_6.value is None


# Generated at 2022-06-25 23:55:52.763076
# Unit test for method filter of class Try
def test_Try_filter():
    dict0 = {"a":5, "b":10}
    def filterer0(arg0):
        return arg0["a"] > 3
    def filterer1(arg0):
        return arg0["a"] > 4
    try0 = Try(dict0, True)
    assert try0.filter(filterer0) == Try(dict0, True)
    assert try0.filter(filterer1) != Try(dict0, True)


# Generated at 2022-06-25 23:55:58.101324
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True

    try_0 = Try(dict_0, bool_0)
    func_0 = lambda x : x.get("int_0") == 10
    try_1 = try_0.filter(func_0)

    assert(try_1.value == dict_0 and try_1.is_success == False)


# Generated at 2022-06-25 23:55:59.978897
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)


# Generated at 2022-06-25 23:56:03.810636
# Unit test for method filter of class Try
def test_Try_filter():
    def fn(x):
        return True
    try_0 = Try.of(lambda: 0, ())
    try_1 = Try.of(lambda x: x, (1, ))
    try_2 = Try.of(lambda x: x, (2, ))
    try_1 = try_1.filter(fn)
    assert try_1 == try_2

# Generated at 2022-06-25 23:56:10.655713
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    bool_1 = bool_0
    str_0 = str_0 = try_0.filter(lambda bool_0: bool_0)
    assert (str_0 == bool_1)
    list_0 = list_0 = try_0.filter(lambda str_0: str_0)
    assert (list_0 == bool_1)
    

# Generated at 2022-06-25 23:56:20.002732
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    function_0 = functools.partial(filter_0, try_0)
    try_1 = Try.of(function_0, dict_0)
    try_1.filter(function_0)
    string_0 = try_1.get()
    bool_1 = try_1.is_success
    dict_1 = try_0.get()
    bool_2 = try_0.is_success
    print('test_Try_filter=', string_0, bool_1, dict_1, bool_2, sep='')


# Generated at 2022-06-25 23:56:26.975983
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    def func_0(arg_0):
        return arg_0
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_7[0] = dict_0
    dict_5[1] = dict_6
    dict_5[0] = dict_7
    dict_4[0] = dict_5
    dict_3[1] = dict_4
    dict_2[1] = dict_3
    dict_3[0] = dict_2
    dict_1[1] = dict_0
    dict_1[0]

# Generated at 2022-06-25 23:56:36.292757
# Unit test for method filter of class Try
def test_Try_filter():
    def test_0():
        dict_0 = {}
        bool_0 = True
        try_0 = Try(dict_0, bool_0)
        try_0.filter(lambda value: True)

    def test_1():
        dict_0 = {}
        bool_0 = True
        try_0 = Try(dict_0, bool_0).filter(lambda value: True)
        assert len(try_0.value) == 0

    def test_2():
        dict_0 = {}
        bool_0 = False
        try_0 = Try(dict_0, bool_0)
        try_0.filter(lambda value: True)

    def test_3():
        dict_0 = {}
        bool_0 = False

# Generated at 2022-06-25 23:56:47.175222
# Unit test for method filter of class Try
def test_Try_filter():
    def try_filter():
        dict_0 = {'test': 'test'}
        bool_0 = True
        try_0 = Try(dict_0, bool_0)

        def filterer(x):
            return True if (x['test'] == 'test') else False

        # Try with previous value
        try_1 = try_0.filter(filterer)

        # Try with previous value
        try_2 = Try(dict_0, True)

        assert try_1 == try_2
    try_filter()


# Generated at 2022-06-25 23:56:57.639857
# Unit test for method filter of class Try
def test_Try_filter():

    def should_return_true_for_True(value):
        return True

    def should_return_false_for_false(value):
        return False

    class Success:
        pass
    success = Success()

    class Failure:
        pass
    failure = Failure()

    try_success = Try(success, True)
    try_failure = Try(failure, False)

    successful_try_success = try_success.filter(should_return_true_for_True)
    not_successful_try_success = try_success.filter(should_return_false_for_false)
    successful_try_failure = try_failure.filter(should_return_true_for_True)
    not_successful_try_failure = try_failure.filter(should_return_false_for_false)

    assert successful

# Generated at 2022-06-25 23:57:09.306403
# Unit test for method filter of class Try
def test_Try_filter():
    # Test (1)
    dict_0 = {'a': '1'}
    bool_0 = False
    try_0 = Try(dict_0, bool_0)
    try_1 = try_0.filter(None)
    assert not try_1.is_success
    assert try_1.value == dict_0
    # Test (2)
    try_0 = Try({}, True)
    try_1 = try_0.filter({}.get)
    assert not try_1.is_success
    assert try_1.value == {}
    # Test (3)
    try_0 = Try({'a': '1'}, True)
    try_1 = try_0.filter({'a': '1'}.get)
    assert try_1.is_success

# Generated at 2022-06-25 23:57:17.536853
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try.of(lambda:dict_0, None)
    assert try_0.get() == dict_0
    assert not try_0.is_success
    try_0 = Try(dict_0, bool_0)
    assert try_0.get() == dict_0
    assert try_0.is_success
    assert try_0.filter(lambda value:True) == try_0
    assert try_0.filter(lambda value:False) != try_0
    assert not try_0.filter(lambda value:False).is_success



# Generated at 2022-06-25 23:57:26.090491
# Unit test for method filter of class Try
def test_Try_filter():
    # setup
    def filterer_0(value):
        return True

    # setup
    def filterer_1(value):
        return False

    # setup
    def filterer_2(value):
        return True

    # setup
    def filterer_3(value):
        return False

    # setup
    def filterer_4(value):
        return True

    # setup
    def filterer_5(value):
        return False

    # setup
    def filterer_6(value):
        return True

    # setup
    def filterer_7(value):
        return False

    # setup
    def filterer_8(value):
        return True

    # setup
    def filterer_9(value):
        return False

    # setup

# Generated at 2022-06-25 23:57:36.700067
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    dict_1 = {'k': 0, 'v': 1}
    bool_1 = True
    bool_0 = False
    try_0 = Try(dict_1, bool_1)
    try_1 = Try(dict_1, bool_0)
    try_2 = Try(dict_1, bool_1)
    try_3 = Try(dict_0, bool_1)
    try_4 = Try(dict_0, bool_1)
    if dict_1 != dict_0:
        try_5 = try_1.filter(lambda x: x == dict_1)

# Generated at 2022-06-25 23:57:40.700210
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try.of(Try, dict_0, bool_0)
    dict_1 = {}
    bool_1 = True
    try_1 = Try.of(Try, dict_1, bool_1)
    assert(try_0.filter(lambda cond: True) == try_1)

# Generated at 2022-06-25 23:57:47.357837
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(dict_0):
        return len(dict_0) > 0

    dict_0 = {1: 1}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    try_1 = try_0.filter(filterer)

    assert try_1.is_success == True

    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    try_1 = try_0.filter(filterer)

    assert try_1.is_success == False



# Generated at 2022-06-25 23:57:57.526998
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    def func_0(arg_0):
        arg_0['key_0'] = {}
        arg_0['key_0']['key_1'] = {}
        arg_0['key_0']['key_1']['key_2'] = {}
        arg_0['key_0']['key_1']['key_2']['key_3'] = {}
        arg_0['key_0']['key_1']['key_2']['key_3']['key_4'] = {}

# Generated at 2022-06-25 23:58:02.327604
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Try given dictionary has more than 0 items
    """
    dict_0 = {}
    bool_1 = True
    try_0 = Try(dict_0, bool_1)
    def f(dict_0):
        return len(dict_0) > 0
    try_0 = try_0.filter(f)
    assert not try_0.is_success
    assert try_0.value == {}


# Generated at 2022-06-25 23:58:15.979258
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {'name': 'Martin'}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    def func_0(arg_0):
        return arg_0['name'] == 'Martin'
    try_1 = try_0.filter(func_0)
    assert(try_1.is_success == True)


# Generated at 2022-06-25 23:58:25.501863
# Unit test for method filter of class Try
def test_Try_filter():
    def assert_filters_eqs_and_succs(args_0, args_1, args_4):
        e = None
        bool_0 = False

# Generated at 2022-06-25 23:58:36.996169
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = True
    bool_1 = False
    def func_0(arg_0):
        if arg_0 == 0:
            return bool_0
        return bool_1
    list_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    list_1 = [0, 1, 2, 3, 4, 5, 6, 0, 8, 9]
    def func_1(arg_0):
        if arg_0 in (1, 2, 3, 4, 5):
            return bool_0
        return bool_1
    bool_2 = True
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict

# Generated at 2022-06-25 23:58:45.546783
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    dict_1 = {}
    dict_1['exception'] = ValueError()
    dict_1['value'] = 'try_1'
    bool_1 = True
    try_1 = Try(dict_1, bool_1)
    dict_2 = {}
    dict_2['exception'] = ValueError()
    dict_2['value'] = 'try_2'
    bool_2 = True
    try_2 = Try(dict_2, bool_2)
    dict_3 = {}
    dict_3['exception'] = ValueError()
    dict_3['value'] = 'try_3'
    bool_3 = True

# Generated at 2022-06-25 23:58:55.876968
# Unit test for method filter of class Try
def test_Try_filter():
    bool_0 = bool()
    bool_1 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_2 = bool()
    bool_3 = bool()
    dict_0 = {}
    dict_1 = {"key" : 0}
    dict_2 = {"key" : 0}
    dict_3 = {"key" : 0, "key1" : 1}
    dict_4 = {"key" : 0, "key1" : 1}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {"key1" : 1}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {"key" : 0}
    dict_14 = {}
   

# Generated at 2022-06-25 23:59:00.990342
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    try_0 = Try(dict_0, True)
    """
    try_0.filter(bool)
    """
    """
    try_0.filter(lambda x: True)
    """
    try_0.filter(bool)
    try_0.filter(lambda x: True)


# Generated at 2022-06-25 23:59:07.104854
# Unit test for method filter of class Try
def test_Try_filter():
    def get_dict(value):
        return {
            'key': value
        }

    dict_0 = get_dict('value')

    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    assert try_0.filter(lambda value: value['key'] == 'value') == try_0
    assert try_0.filter(lambda value: value['key'] == 'value2') != try_0


# Generated at 2022-06-25 23:59:09.621392
# Unit test for method filter of class Try
def test_Try_filter():
    try_0 = Try.of(dict, "0")
    try_1 = try_0.filter(lambda data: True)
    try_2 = try_0.filter(lambda data: False)


# Generated at 2022-06-25 23:59:14.082657
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    def filterer_0(a):
        return len(a) > 0
    dict_1 = {}
    bool_1 = False
    try_1 = Try(dict_1, bool_1)
    assert(try_0.filter(filterer_0) == try_1)


# Generated at 2022-06-25 23:59:19.374985
# Unit test for method filter of class Try
def test_Try_filter():
    # Setup
    dict_0 = {}
    bool_0 = True
    try_0 = Try.of(dict, dict_0, bool_0)
    bool_1 = True
    filterer = lambda func: bool_1
    # Exercise & Verify
    assert try_0.filter(filterer).filter(filterer).filter(filterer) == Try.of(dict, dict_0, bool_0).filter(filterer).filter(filterer)


# Generated at 2022-06-25 23:59:39.883030
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {'a': 'a', 'b': 'b'}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    assert try_0.filter(lambda x: x.get('a') == 'a') == Try({'a': 'a', 'b': 'b'}, True)


# Generated at 2022-06-25 23:59:46.786497
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(param0):
        return param0 == 3
    dict_0 = {"value0": 2}
    callback_0 = function_0
    try_0 = Try(dict_0, bool_0)
    try_1 = try_0.filter(filterer)
    try_2 = staticmethod(filterer)
    bool_1 = try_1.is_success
    bool_2 = try_2.is_success
    return (dict_0, callback_0, try_0, try_1, try_2, bool_0, bool_1, bool_2)


# Generated at 2022-06-25 23:59:54.767952
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {'a': 1, 'b': '2'}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    try_1 = try_0.filter(lambda dict_: dict_.get('a'))
    try_2 = try_0.filter(lambda dict_: dict_.get('a', 0))
    try_3 = try_0.filter(lambda dict_: dict_.get('a', False))
    try_4 = Try(dict_1, not bool_0)
    try_5 = try_4.filter(lambda dict_: dict_.get('a', False))
    try_6 = try_4.filter(lambda dict_: dict_.get('a', 0))
    try_7 = try_

# Generated at 2022-06-26 00:00:00.065519
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = { 'key' : True }
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    bool_1 = False
    bool_2 = filterer_0(try_0.get())
    try_1 = try_0.filter(filterer_0)
    bool_3 = False
    assert bool_2 == bool_3
    assert try_1 == Try(dict_0, bool_1)


# Generated at 2022-06-26 00:00:03.905579
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    def func_0(arg_0):
        return False
    try_1 = try_0.filter(func_0)



# Generated at 2022-06-26 00:00:08.936859
# Unit test for method filter of class Try
def test_Try_filter():
    # Arrange
    bool_0 = True
    try_0 = Try(10, bool_0)
    # Act
    try_1 = try_0.filter(lambda x: True)
    # Assert
    assert try_1.is_success == bool_0


# Generated at 2022-06-26 00:00:17.385796
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    bool_0 = True

    def filterer(arg):
        return bool_0

    try_0.filter(filterer)

    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    bool_1 = False

    def filterer(arg):
        return bool_1

    try_0.filter(filterer)

    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    bool_0 = True

    def filterer(arg):
        return bool_0

    try_1 = try_0.filter(filterer)

# Unit

# Generated at 2022-06-26 00:00:28.514468
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x > 10) == Try(10, False)
    assert Try(10, True).filter(lambda x: x <= 10) == Try(10, True)
    assert Try('python', True).filter(lambda x: x != 'python') == Try('python', False)
    assert Try('python', True).filter(lambda x: x == 'python') == Try('python', True)
    assert Try('try', True).filter(lambda x: x != 'try') == Try('try', False)
    assert Try([], True).filter(lambda x: len(x) == 0) == Try([], True)
    assert Try([], True).filter(lambda x: len(x) > 0) == Try([], False)
    assert Try(None, True).filter(lambda x: x is None) == Try

# Generated at 2022-06-26 00:00:38.482993
# Unit test for method filter of class Try
def test_Try_filter():
    def f1():
        return 1
    def f2(a):
        if a % 2 == 0:
            return True
        return False

    t1 = Try.of(f1)
    t2 = t1.filter(f2)
    assert t2.value == 1
    assert t2.is_success

    t1 = Try.of(f1)
    t2 = t1.filter(lambda x: False)
    assert t2.value == 1
    assert not t2.is_success

    def f3():
        raise Exception('f3 error')
    t1 = Try.of(f3)
    t2 = t1.filter(lambda x: False)
    assert t2.value == Exception('f3 error')
    assert not t2.is_success


# Generated at 2022-06-26 00:00:42.882835
# Unit test for method filter of class Try
def test_Try_filter():
    def fn_0(x_0):
        return x_0 > 0
    int_0 = 1
    bool_0 = True
    try_0 = Try(int_0, bool_0)
    try_1 = try_0.filter(fn_0)
    bool_0 = True
    bool_1 = True
    assert(try_0.value == try_1.value and try_0.is_success == try_1.is_success)
    return None


# Generated at 2022-06-26 00:01:21.769967
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    try_1 = try_0.filter(lambda x: bool_0)
    assert(try_0.is_success == bool_0)
    assert(try_1.is_success == bool_0)


# Generated at 2022-06-26 00:01:30.691463
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    def func0(p0):
        return p0
    def func1(p0, p1):
        return p0
    def func2(p0):
        return not p0
    def func3(p0, p1):
        return p0
    def func4(p0):
        return p0
    def func5():
        return 1
    try_1 = try_0.bind(func0)
    try_2 = try_1.filter(func1)
    try_3 = try_2.map(func2)
    try_3.filter(func3)
    try_3.map(func4)
    try_3.get()


# Generated at 2022-06-26 00:01:38.926307
# Unit test for method filter of class Try
def test_Try_filter():
    successfull_Try = Try.of(lambda value: 5, 6)
    assert successfull_Try.filter(lambda value: value == 1) == Try(5, False)
    assert successfull_Try.filter(lambda value: value == 5) == successfull_Try
    assert successfull_Try.filter(lambda value: value != 5) == Try(5, False)

    unsuccessfull_Try = Try(5, False)
    assert unsuccessfull_Try.filter(lambda value: value == 1) == unsuccessfull_Try
    assert unsuccessfull_Try.filter(lambda value: value == 5) == unsuccessfull_Try
    assert unsuccessfull_Try.filter(lambda value: value != 5) == unsuccessfull_Try



# Generated at 2022-06-26 00:01:47.984490
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    dict_1 = {}
    dict_1['val'] = 2
    bool_1 = False
    try_1 = Try(dict_1, bool_1)
    dict_2 = {}
    dict_2['val'] = 2
    bool_2 = True
    try_2 = Try(dict_2, bool_2)
    dict_3 = {}
    dict_3['val'] = 3
    bool_3 = True
    try_3 = Try(dict_3, bool_3)
    dict_4 = {}
    dict_4['val'] = 4
    bool_4 = True
    try_4 = Try(dict_4, bool_4)
    dict_5 = {}
    dict

# Generated at 2022-06-26 00:01:54.944616
# Unit test for method filter of class Try
def test_Try_filter():
    def function_filterer(value):
        return True

    def function_filterer_0(value):
        return False

    obj_tuple_0 = Try(1, True)
    function_filterer_0(obj_tuple_0.get())
    value_0 = obj_tuple_0.filter(function_filterer)
    value_1 = obj_tuple_0.filter(function_filterer_0)
    value_0.is_success
    value_1.is_success
    value_1.get()


# Generated at 2022-06-26 00:02:01.625341
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    bool_1 = True
    bool_2 = bool_0
    bool_1 = (not bool_0)
    bool_2 = not bool_1
    def function_3(arg_0):
        return Try(arg_0, not bool_0)

    assert try_0.filter(function_3).get() == {}


# Generated at 2022-06-26 00:02:06.828439
# Unit test for method filter of class Try
def test_Try_filter():
    dict_0 = {}
    bool_0 = True
    try_0 = Try(dict_0, bool_0)
    bool_1 = try_0.filter(lambda x: True) == Try(dict_0, True)
    bool_2 = try_0.filter(lambda x: False) == Try(dict_0, False)
    bool_3 = bool_1 and bool_2
    bool_3


# Generated at 2022-06-26 00:02:12.311345
# Unit test for method filter of class Try
def test_Try_filter():
    def success_filterer(val):
        return True
    def fail_filterer(val):
        return False
    # test 1
    try_0 = Try(0, True)
    try_1 = try_0.filter(success_filterer)
    if not try_1 == try_0:
        raise ValueError()
    # test 2
    try_0 = Try(0, False)
    try_1 = try_0.filter(success_filterer)
    try_2 = Try(0, False)
    if not try_1 == try_2:
        raise ValueError()
    # test 3
    try_0 = Try(0, True)
    try_1 = try_0.filter(fail_filterer)
    try_2 = Try(0, False)

# Generated at 2022-06-26 00:02:16.002314
# Unit test for method filter of class Try
def test_Try_filter():
    try_var0 = Try.of(lambda : {}, ())
    try_var1 = try_var0.filter(lambda arg0: isinstance(arg0, dict))
    assert (try_var1 == Try({}, True)), 'Assertion failed while testing filter on Try[A]. Reason: ' + 'Expected "{}", found "{}"'.format(True, False)


# Generated at 2022-06-26 00:02:24.726817
# Unit test for method filter of class Try
def test_Try_filter():
    # Test block
    try_0 = Try.of(lambda x: x, "")
    try_1 = try_0.filter(str.isalpha)

    assert isinstance(try_1, Try)
    assert isinstance(try_0, Try)
    assert try_0 is not try_1
    assert try_1.is_success is False
    assert try_0.is_success is True
    assert try_0.value == ""
    assert try_1.value == ""

    # Test block
    try_0 = Try.of(lambda x: x, "")
    try_1 = try_0.filter(str.isalpha)

    assert isinstance(try_1, Try)
    assert isinstance(try_0, Try)
    assert try_0 is not try_1