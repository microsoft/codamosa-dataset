

# Generated at 2022-06-21 19:20:46.306941
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1).get_or_else(100) == 1
    assert Try.of(lambda: 1 / 0).get_or_else(100) == 100



# Generated at 2022-06-21 19:20:49.107929
# Unit test for method get of class Try
def test_Try_get():
    """
    Test for method get of class Try
    """
    assert Try(5, True).get() == 5
    assert Try(5, False).get() == 5
    assert Try(5, True).get() == Try(5, False).get()


# Generated at 2022-06-21 19:21:00.454392
# Unit test for method bind of class Try
def test_Try_bind():
    def add_n(n):
        return lambda x: Try(x + n, True)

    def to_even(x):
        return Try(x % 2 == 0, True)

    # Case 1:
    #   - Try[value=0, is_success=True].bind(add_n(1)).bind(to_even).get()
    #   - Try(0, True).bind(add_1).bind(to_even).get()
    #   - Try(0 + 1, True).bind(to_even).get()
    #   - Try(1, True).bind(to_even).get()
    #   - Try(1 % 2 == 0, True)
    #   - Try(False, True)
    assert Try(0, True).bind(add_n(1)).bind(to_even).get()

# Generated at 2022-06-21 19:21:07.596640
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # When Try is not successfully
    failure = Try(1, False).on_fail(lambda v: print('failure: ' + str(v)))

    assert failure.value == 1
    assert failure.is_success == False

    # When Try is successfully
    success = Try(1, True).on_fail(lambda v: print('failure: ' + str(v)))

    assert success.value == 1
    assert success.is_success == True

    print('test_Try_on_fail: ok')



# Generated at 2022-06-21 19:21:18.162971
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    """
    Test for Try bind method.

    Tests for Try::bind method is similar to tests for Try::of method
    and can be found in tests for of method.
    When we have Try monad and we need to apply on value some function who returns another Try monad,
    we can use bind method. Bind method returns Try who returns function applied on monad value.
    """

    # ================================
    # When function don't raise exception
    # ================================

    # When function returns successfully
    def sqrt(value):  # pragma: no cover
        return Try(value ** 0.5, True)

    assert Try.of(lambda value: value ** 2, 4)\
        .bind(sqrt) == Try(2, True)

    # When function returns not successfully

# Generated at 2022-06-21 19:21:20.556781
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(3, True)) == 'Try[value=3, is_success=True]'
    assert str(Try(3, False)) == 'Try[value=3, is_success=False]'


# Generated at 2022-06-21 19:21:25.692278
# Unit test for method get of class Try
def test_Try_get():
    """
    Unit test for method get of class Try.

    :returns: True when test executed successfully, False when not.
    :rtype: Boolean
    """
    try:
        assert Try('test', True).get() == 'test'
        assert Try('test', False).get() == 'test'
    except AssertionError:
        return False
    return True


# Generated at 2022-06-21 19:21:31.838561
# Unit test for method get of class Try
def test_Try_get():
    def fn():
        return 42
    assert Try.of(fn).get() == 42
    assert Try.of(fn).is_success
    def fn_exception():
        raise ValueError('mock')
    assert not Try.of(fn_exception).is_success
    assert Try.of(fn_exception).get().args[0] == 'mock'


# Generated at 2022-06-21 19:21:37.194950
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda a: a == 1) == Try(True, False)
    assert Try(True, True).filter(lambda a: a == True) == Try(True, True)
    assert Try(True, False).filter(lambda a: a == 1) == Try(True, False)


# Generated at 2022-06-21 19:21:39.358128
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(x):
        return Try(x, True)
    assert Try.of(lambda: 1, 0).bind(binder) == Try(1, True)


# Generated at 2022-06-21 19:21:44.622223
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)



# Generated at 2022-06-21 19:21:48.571037
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try('test', True) == Try('test', True)
    assert Try('test', False) == Try('test', False)


# Generated at 2022-06-21 19:21:51.308427
# Unit test for method __str__ of class Try
def test_Try___str__():
    a = Try(1, True)
    assert str(a) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-21 19:21:55.629213
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    t = Try(5, True)
    assert str(t) == 'Try[value=5, is_success=True]'
    t = Try(Exception(), False)
    assert str(t) == 'Try[value=Exception(), is_success=False]'


# Generated at 2022-06-21 19:22:03.961237
# Unit test for method map of class Try
def test_Try_map():
    def concatenate(s):
        return s + '_map'

    x = Try.of(lambda : 10).map(lambda x: x + 1)
    y = Try.of(lambda : 'x').map(concatenate)
    z = Try.of(lambda : 'x').map(lambda s: s + '_map')
    assert x == Try(11, True)
    assert y == Try('x_map', True)
    assert z == Try('x_map', True)
    assert Try.of(lambda : 10).map(concatenate) == Try(10, False)



# Generated at 2022-06-21 19:22:12.262951
# Unit test for method map of class Try
def test_Try_map():
    def to_upper(string):
        return string.upper()

    assert Try.of(to_upper, 'abc').map(to_upper) == Try(to_upper('abc'), True)
    assert Try.of(to_upper, 'abc').map(to_upper) != Try(to_upper('cba'), True)

    assert Try.of(int, 'a').map(to_upper) == Try('a', False)


# Generated at 2022-06-21 19:22:15.846802
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-21 19:22:23.590687
# Unit test for constructor of class Try
def test_Try():

    # Constructor should return successfully Try when no exception raise.
    #
    @Try.of
    def func():
        return 1

    assert (func.__eq__(Try(1, True)))

    # Constructor should return not successfully Try when exception raise.
    #
    @Try.of
    def func():
        raise Exception("error")

    assert (func.__eq__(Try("error", False)))



# Generated at 2022-06-21 19:22:24.721074
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'


# Generated at 2022-06-21 19:22:31.815127
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def run_test():
        def throw_exception(x):
            raise ValueError("Test exception")

        def return_value(x):
            return x + 1

        print("Try.bind test")
        try_one = Try.of(throw_exception, 2).bind(return_value)
        try_two = Try.of(return_value, 2).bind(throw_exception)
        assert try_one != try_two
        print("try_one: {}".format(try_one))
        print("try_two: {}".format(try_two))
        assert str(try_one) == "Try[value=Test exception, is_success=False]"
        assert str(try_two) == "Try[value=3, is_success=True]"

# Generated at 2022-06-21 19:22:41.438843
# Unit test for method bind of class Try
def test_Try_bind():
    def success_binder(value):
        return Try("Success {}".format(value), True)

    def fail_binder(value):
        return Try("Fail {}".format(value), False)

    assert Try("my value", True).bind(success_binder) == Try("Success my value", True)
    assert Try("my value", False).bind(success_binder) == Try("my value", False)
    assert Try("my value", True).bind(fail_binder) == Try("my value", False)
    assert Try("my value", False).bind(fail_binder) == Try("my value", False)


# Generated at 2022-06-21 19:22:48.072853
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value < 5

    try1 = Try(10, True)
    try2 = Try(2, True)
    assert try1.filter(filterer) == Try(10, False)
    assert try2.filter(filterer) == Try(2, True)

    assert Try(None, False).filter(filterer) == Try(None, False)



# Generated at 2022-06-21 19:22:50.020066
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-21 19:22:53.001618
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'


# Generated at 2022-06-21 19:22:56.560946
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda _: print('Call success')) == Try(1, True)
    assert Try(None, False).on_success(lambda _: print('Call success')) == Try(None, False)


# Generated at 2022-06-21 19:22:58.556543
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try('a', True).get_or_else('b') == 'a'
    assert Try('a', False).get_or_else('b') == 'b'


# Generated at 2022-06-21 19:23:04.803077
# Unit test for method bind of class Try
def test_Try_bind():
    class CustomException(Exception):
        pass

    def divide(x, y):
        return x / y

    def multiply(x, y):
        return Try(x * y, True)

    assert Try.of(divide, 1, 2) == Try(divide(1, 2), True)
    assert Try.of(divide, 1, 0) == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(divide, 1, 0).bind(lambda value: Try(5, True)) == Try(ZeroDivisionError('division by zero'), False)
    assert Try.of(divide, 1, 2).bind(lambda value: Try(5, True)).bind(lambda value: Try(value + 6, True))\
                               == Try(11, True)

# Generated at 2022-06-21 19:23:08.971615
# Unit test for method filter of class Try
def test_Try_filter():
    # Given
    expected = Try('spam', True)
    value = 'spam'

    # When
    actual = Try.of(lambda: 'spam').filter(lambda x: x == 'spam')

    assert actual == expected

# Generated at 2022-06-21 19:23:12.283327
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Function to test Try.filter() method.
    """
    assert Try.of(int, '1').map(lambda value: value + 1).filter(lambda value: value > 1).value == 2

# Generated at 2022-06-21 19:23:20.308851
# Unit test for constructor of class Try
def test_Try():
    # Successfully Try with value 42
    try_1 = Try(42, True)

    # Not successfully Try with Exception object.
    try_2 = Try(Exception('Some exception'), False)

    # Successfully Try with value None
    try_3 = Try(None, True)

    # Not successfully Try with None value.
    try_4 = Try(None, False)

    # Not successfully try with empty value.
    try_5 = Try('', False)

    # Successfully Try with empty value.
    try_6 = Try('', True)

    # Try with value 1
    try_7 = Try(1, True)

    # Try with value 0
    try_8 = Try(0, True)

    assert try_1.value == 42
    assert try_2.value.args[0] == 'Some exception'

# Generated at 2022-06-21 19:23:28.629637
# Unit test for method on_success of class Try
def test_Try_on_success():
    def foo(x):  # pylint: disable=unused-variable
        return x
    assert Try(5, True).on_success(foo).get() == 5
    assert Try(5, False).on_success(foo).get() == 5


# Generated at 2022-06-21 19:23:31.895904
# Unit test for method filter of class Try
def test_Try_filter():
    m = Try.of(lambda: 3/2)
    n = m.filter(lambda x: x == 1.5)

    assert n == Try(1.5, True)


# Generated at 2022-06-21 19:23:41.359596
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try
    """

    def _is_divisible_by_two(value):
        """
        :params value: value
        :type: Any
        :returns: is value divisible by 2
        :rtype: Boolean
        """
        return value % 2 == 0

    assert Try.of(MultiplyOperation.divide, 10, 2).filter(_is_divisible_by_two) == Try(5, True)
    assert Try.of(MultiplyOperation.divide, 10, 2).filter(lambda value: value % 3 == 0) == Try(5, False)



# Generated at 2022-06-21 19:23:46.246770
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, True).map(lambda x: x / 0) == Try(ZeroDivisionError("division by zero"), False)
    assert Try(ZeroDivisionError("division by zero"), False).map(lambda x: x + 1) == Try(ZeroDivisionError("division by zero"), False)


# Generated at 2022-06-21 19:23:52.975204
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_on_success_success():
        def _success_callback(value):
            assert value == 1
        Try.of(lambda: 1, None).on_success(_success_callback)

    def test_on_fail_not_success():
        def _success_callback(value):
            assert False
        Try.of(lambda: 1/0, None).on_success(_success_callback)

    test_on_fail_not_success()
    test_on_success_success()


# Generated at 2022-06-21 19:23:58.767837
# Unit test for method get of class Try
def test_Try_get():
    try_ = Try(value = None, is_success = True)
    assert try_.get() is None
    try_ = Try(value = 1, is_success = True)
    assert try_.get() == 1
    try_ = Try(value = 1, is_success = False)
    assert try_.get() == 1


# Generated at 2022-06-21 19:24:06.273875
# Unit test for method get of class Try
def test_Try_get():
    # Given
    actual_successful_try = Try(1, True)
    expected_successful_try = 1

    actual_unsuccessful_try = Try(1, False)
    expected_unsuccessful_try = 1

    # When
    actual_successful_result = actual_successful_try.get()
    actual_unsuccessful_result = actual_unsuccessful_try.get()

    # Then
    assert expected_successful_try == actual_successful_result
    assert expected_unsuccessful_try == actual_unsuccessful_result



# Generated at 2022-06-21 19:24:09.882807
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(1, True).get() == 1
    assert Try(ValueError('test'), False).get() == ValueError('test')


# Generated at 2022-06-21 19:24:13.772109
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    """
    Test case for method get_or_else of class Try.
    """
    assert Try(10, True).get_or_else(-1) == 10
    assert Try(-1, False).get_or_else(-1) == -1

# Generated at 2022-06-21 19:24:22.221848
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(name):
        return name == 'user'
    assert Try.of(lambda x: x * 2, 3).map(lambda x: x + 1).filter(filterer).get_or_else(None) is None
    assert Try.of(lambda x: x * 2, 3).map(lambda x: x + 1).filter(lambda x: True).get_or_else(None) == 8
    assert Try.of(lambda: 4 / 0, None).filter(lambda _: True).get_or_else(None) is None

# Generated at 2022-06-21 19:24:34.501815
# Unit test for method map of class Try
def test_Try_map():
    def add(a, b):
        return a + b

    def div(a, b):
        return a / b

    def double(x):
        return x * 2

    assert Try.of(add, 1, 2).map(double) == Try(6, True)
    assert Try.of(div, 1, 0).map(double) == Try(0, False)



# Generated at 2022-06-21 19:24:36.968292
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Call Try.bind with not successfully result.
    """
    result = Try.of(int, 'test').bind(lambda x: Try(x + 10, True))
    assert result == Try(None, False)

# Generated at 2022-06-21 19:24:39.424177
# Unit test for method get of class Try
def test_Try_get():
    assert_that(Try.of(lambda: 1, ()).get(), equal_to(1))
    assert_that(Try.of(lambda: 1/0).get(), is_not(1))


# Generated at 2022-06-21 19:24:45.383444
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1).map(lambda x: x * 2) == Try(2, True)
    assert Try.of(lambda: 1).map(lambda x: x * 2).map(lambda x: x * 2) == Try(4, True)
    assert Try.of(lambda: 1).map(lambda x: x * 2).map(lambda x: x * 2).map(lambda x: x * 2) == Try(8, True)
    assert Try.of(lambda: raise_exception).map(lambda x: x * 2) == Try(Exception, False)
    assert Try.of(lambda: 1).map(lambda x: x * 2).map(lambda x: x * 2).map(lambda x: raise_exception) == Try(Exception, False)


# Generated at 2022-06-21 19:24:50.018308
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try('2', False) != Try(2, False)
    assert Try(2, True) != Try(2, False)


# Generated at 2022-06-21 19:24:56.727071
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: x % 2 == 0)\
        == Try(10, False)
    assert Try(10, True).filter(lambda x: x % 2 == 1)\
        == Try(10, True)
    assert Try(10, False).filter(lambda x: x % 2 == 0)\
        == Try(10, False)
    assert Try(10, False).filter(lambda x: x % 2 == 1)\
        == Try(10, False)



# Generated at 2022-06-21 19:25:01.702279
# Unit test for constructor of class Try
def test_Try():
    safe_function = lambda x, y: x // y

    try_result = Try.of(safe_function, 10, 2)
    try_result_fail = Try.of(safe_function, 10, 0)

    assert try_result == Try(5, True)
    assert type(try_result_fail.value) == ZeroDivisionError
    assert try_result_fail == Try(ZeroDivisionError, False)


# Generated at 2022-06-21 19:25:09.291073
# Unit test for method bind of class Try
def test_Try_bind():
    def fn():
        raise Exception

    def binder(v):
        return Try.of(lambda: v)

    def fn2(a, b):
        return a

    assert Try(1, True).bind(binder) == Try(1, True)
    assert Try.of(fn).bind(binder) == Try(None, False)
    assert Try.of(fn2, 1, 2).bind(binder) == Try(1, True)



# Generated at 2022-06-21 19:25:13.561527
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    @require_args(['a'])
    def f(a):
        return a

    t1 = Try.of(f, 1)
    t2 = Try.of(f, 2)

    assert t1 != t2
    assert t1 != t1.map(lambda x: x * 2)



# Generated at 2022-06-21 19:25:15.950970
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]',\
        'Method __str__ of class Try works incorrectly.'


# Generated at 2022-06-21 19:25:39.146865
# Unit test for method map of class Try
def test_Try_map():
    try_obj = Try(True, True)
    def mapper(x):
        return x

    assert try_obj.map(mapper) == Try(True, True) # when monad is success
    try_obj = Try(Exception('x'), False)
    assert try_obj.map(mapper) == Try(Exception('x'), False) # when monad is failure


# Generated at 2022-06-21 19:25:45.698498
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(x):
        return x % 2 == 0

    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(3, True).filter(is_even) == Try(3, False)
    assert Try(Exception('foo'), False).filter(is_even) == Try(Exception('foo'), False)
    print('test_Try_filter function is ok')


# Generated at 2022-06-21 19:25:48.829687
# Unit test for method __str__ of class Try
def test_Try___str__():
    # Arrange
    sut = Try(1, True)

    # Act
    result = str(sut)

    # Assert
    assert result == 'Try[value=1, is_success=True]'


# Generated at 2022-06-21 19:25:50.545126
# Unit test for method get of class Try
def test_Try_get():
    value = Try(5, True).get()
    assert value == 5
    assert type(value) is int


# Generated at 2022-06-21 19:25:59.415979
# Unit test for method bind of class Try
def test_Try_bind():
    """
    In method bind of class Try we need to test:
    * Call of binder function with monad value when successfully
    * Return result of binder function
    * Return copy of monad when not successfully
    """
    def binder_mock_success(x):
        return Try(x + 10, True)

    def binder_mock_fail(x):
        return Try(x + 10, False)

    assert_that(Try(5, True).bind(binder_mock_success), equal_to(Try(15, True)))
    assert_that(Try(5, False).bind(binder_mock_success), equal_to(Try(5, False)))

    assert_that(Try(5, True).bind(binder_mock_fail), equal_to(Try(15, False)))

# Generated at 2022-06-21 19:26:03.199669
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception(), False)) == 'Try[value=Exception(), is_success=False]'



# Generated at 2022-06-21 19:26:13.524872
# Unit test for constructor of class Try
def test_Try():
    """
    Do unit test for constructor of class Try
    """
    assert Try(5, True) == Try(5, True)
    assert Try(5, False) == Try(5, False)
    assert not Try(5, False) == Try(5, True)
    assert not Try(5, True) == Try(4, True)
    assert not Try(4, False) == Try(5, True)
    assert Try(Exception, False).value.__class__ == Exception



# Generated at 2022-06-21 19:26:18.235258
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def raise_exception():
        raise Exception('Failed')

    def assert_callback(exception_message):
        assert str(exception_message) == 'Failed'

    try_either = Try.of(raise_exception)

    try_either.on_fail(assert_callback)



# Generated at 2022-06-21 19:26:20.484849
# Unit test for method get of class Try
def test_Try_get():
    @Try.of
    def try_get_test():
        return 1

    assert try_get_test.get() == 1


# Generated at 2022-06-21 19:26:24.661485
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    assert(
        Try(1, True).on_fail(lambda e: e.join(['foo'])) ==
        Try(1, True)
    )
    assert(
        Try(Exception('bar'), False).on_fail(lambda e: e.args[0] + 'foo') ==
        Try(Exception('bar'), False)
    )


# Generated at 2022-06-21 19:27:01.995583
# Unit test for constructor of class Try
def test_Try():
    try_ = Try(1, True)
    assert_equals(try_.value, 1)
    assert_equals(try_.is_success, True)


# Generated at 2022-06-21 19:27:03.568773
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_0 = Try(1, True)
    assert try_0.get_or_else(2) == 1
    try_1 = Try(1, False)
    assert try_1.get_or_else(2) == 2


# Generated at 2022-06-21 19:27:05.798318
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try('value', True).on_success(lambda value: print(value)) == Try('value', True)



# Generated at 2022-06-21 19:27:10.119535
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try(Exception(), False)) == 'Try[value=Exception(), is_success=False]'


# Generated at 2022-06-21 19:27:13.290945
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # When: calling on_fail method
    fn = lambda x: None
    t = Try.of(lambda: 1/0, ()).on_fail(fn)
    # Then: should to be equal
    assert t == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:27:21.958376
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(3, True).on_success(lambda x: print(x)) == Try(3, True)\
        , 'on_success() for successfully Try should return copy of origin'

    assert Try(3, False).on_success(lambda x: print(x)) == Try(3, False)\
        , 'on_success() for not successfully Try should return copy of origin'

    assert Try(1, True).on_success(lambda x: x == 1) == Try(1, True)\
        , 'on_success() should return copy of origin'

    assert Try(1, True).on_success(lambda x: x == 2) == Try(1, True)\
        , 'on_success() should return copy of origin'



# Generated at 2022-06-21 19:27:26.698609
# Unit test for method map of class Try
def test_Try_map():
    """
    Try:
    """
    assert Try(2, True).map(lambda x: x * x) == Try(4, True)
    assert Try(2, False).map(lambda x: x * x) == Try(2, False)



# Generated at 2022-06-21 19:27:29.422572
# Unit test for method __str__ of class Try
def test_Try___str__():
    v = 'test'
    t = Try(v, True)
    assert str(t) == 'Try[value={}, is_success={}]'.format(v, True)



# Generated at 2022-06-21 19:27:32.935117
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)


# Generated at 2022-06-21 19:27:36.321194
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    print('--test_Try_on_fail--')
    cnt = 0
    def counter(e):
        nonlocal cnt
        cnt += 1

    exception = Exception('test exception')
    Try.of(lambda: 1).on_fail(counter)
    Try(exception, False).on_fail(counter)
    assert cnt == 1
    print('passed')


# Generated at 2022-06-21 19:28:56.981243
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    assert(Try.of(lambda: 0, None).map(lambda: 1) == Try(1, True))
    assert(Try.of(lambda: 0, None).map(lambda x: x / 0) == Try(ZeroDivisionError(), False))
    assert(Try.of(lambda: 0 / 0, None).map(lambda: 1) == Try(ZeroDivisionError(), False))


# Generated at 2022-06-21 19:29:02.520966
# Unit test for method bind of class Try
def test_Try_bind():
    def is_even(x):
        return x % 2 == 0

    def increment(x):
        return x + 1

    assert Try(2, True)\
        .bind(lambda x: Try(is_even(x), True))\
        .bind(lambda x: Try(x, True)).value is True
    assert Try(2, True)\
        .bind(lambda x: Try(is_even(x), True))\
        .bind(lambda x: Try(increment(x), True)).value is 1



# Generated at 2022-06-21 19:29:12.881158
# Unit test for method bind of class Try
def test_Try_bind():
    def get_value_or_exception_try(value):
        return Try(value, True)

    def get_value_or_exception(value):
        return value

    assert Try(1, True).bind(get_value_or_exception_try) == Try(1, True)
    assert Try(1, False).bind(get_value_or_exception_try) == Try(1, False)

    assert Try.of(get_value_or_exception, 1).bind(get_value_or_exception_try) == Try(1, True)
    assert Try.of(get_value_or_exception, Exception()).bind(get_value_or_exception_try) == Try(Exception(), False)


# Generated at 2022-06-21 19:29:15.107320
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 1, None) == Try(1, True)



# Generated at 2022-06-21 19:29:17.032799
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(2, False) == Try(2, False)


# Generated at 2022-06-21 19:29:21.199233
# Unit test for method map of class Try
def test_Try_map():
    def inc(value):
        return value+1

    def div(divisor):
        def fn(dividend):
            return dividend/divisor
        return fn

    assert Try.of(div(2), 4).map(inc) == Try(3, True)
    assert Try.of(div(0), 4).map(inc) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:29:32.210575
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(\
        lambda x: print('Value is {}'.format(x)))\
        .on_fail(lambda x: print('int'))\
        .on_fail(lambda x: print('Value is {}'.format(x)))\
        .on_fail(lambda x: print('int'))\
        == Try(1, True)\
        == Try(1, True)\
        == Try(1, True)

# Generated at 2022-06-21 19:29:35.956803
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception(), False) == Try(Exception(), False)


# Generated at 2022-06-21 19:29:39.751332
# Unit test for constructor of class Try
def test_Try():
    class A: pass
    class B: pass

    assert Try(A(), True) == Try(A(), True)
    assert Try(A(), False) == Try(A(), False)
    assert Try(A(), True) != Try(B(), False)


# Generated at 2022-06-21 19:29:51.587615
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 10).map(lambda x: x * 2) == Try(20, True)
    assert Try.of(lambda x: x, 10).map(lambda x: x * 2) == Try(20, True)
    assert Try.of(lambda x, y: x + y, 10, 20).map(lambda x: x * 2) == Try(60, True)
    
    exception = None
    
    try:
        1 / 0
    except Exception as e:
        exception = e
    
    assert Try.of(lambda: 1 / 0).map(lambda x: x * 2) == Try(exception, False)
    assert Try.of(lambda x: 1 / x, 0).map(lambda x: x * 2) == Try(ZeroDivisionError(), False)