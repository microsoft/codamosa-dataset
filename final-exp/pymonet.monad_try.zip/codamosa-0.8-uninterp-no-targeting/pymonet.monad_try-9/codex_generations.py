

# Generated at 2022-06-21 19:20:53.359329
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    try:
        raise Exception('error')
    except Exception as e:
        assert Try(e, False) == Try(e, False)


# Generated at 2022-06-21 19:20:56.429338
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(1, True)
    assert 'Try[value={}, is_success={}]'.format(1, True) == str(try_)


# Generated at 2022-06-21 19:20:59.097844
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'


# Generated at 2022-06-21 19:21:03.971056
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]', "error in __str__ Try representation"
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]', "error in __str__ Try representation"



# Generated at 2022-06-21 19:21:05.052696
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-21 19:21:14.810090
# Unit test for method bind of class Try
def test_Try_bind():
    try_1 = Try(lambda a: a, True)
    try_2 = Try(lambda a: a + 2, True)
    try_3 = Try(lambda a, b: a + b, True)
    try_4 = Try(1, True)
    try_5 = Try(3, True)
    try_6 = Try(5, True)

    assert try_1.bind(lambda x: Try(x(try_2.value), True)).bind(lambda x: Try(x(try_4.value), True))\
        == Try(lambda a: a(lambda a: a + 2), True).bind(lambda x: Try(x(1), True))
    assert try_3.bind(lambda x: Try(x(try_4.value, try_5.value), True)).get() == 1 + 3

# Generated at 2022-06-21 19:21:16.918909
# Unit test for constructor of class Try
def test_Try():
    value = 'value'
    is_success = True
    actual = Try(value, is_success)
    expected = Try(value, is_success)
    assert actual == expected



# Generated at 2022-06-21 19:21:20.883680
# Unit test for method map of class Try
def test_Try_map():
    """
    Test method map of class Try

    :return: None
    """
    def increment(x) -> int:
        return x + 1

    assert Try.of(lambda: 1).map(increment) == Try(2, True)
    assert Try.of(lambda: 1).map(increment).map(increment) == Try(3, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 1).map(increment) == Try(2, True)
    assert Try.of(lambda: 1).filter(lambda x: x == 2).map(increment) == Try(1, False)


# Generated at 2022-06-21 19:21:25.828433
# Unit test for method on_fail of class Try
def test_Try_on_fail():

    def throw_exception():
        raise ValueError('Some Exception')

    def fail_callback(value):
        assert isinstance(value, ValueError)
        assert value.args[0] == 'Some Exception'

    Try.of(throw_exception).on_fail(fail_callback)
    Success(5).bind(throw_exception).on_fail(fail_callback)
    Failure(5).bind(throw_exception).on_fail(fail_callback)

# Generated at 2022-06-21 19:21:29.862999
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert 'Try[value=value, is_success=True]' == str(Try('value', True))
    assert 'Try[value=value, is_success=False]' == str(Try('value', False))


# Generated at 2022-06-21 19:21:38.152692
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x+1) == Try(2, True)
    assert Try(1, False).map(lambda x: x+1) == Try(1, False)
    assert Try(1, True).map(lambda x: None) == Try(None, True)
    assert Try(1, False).map(lambda x: None) == Try(1, False)


# Generated at 2022-06-21 19:21:40.901957
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1 + 2, None).get() == 3


# Generated at 2022-06-21 19:21:52.834509
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_mock(value):
        return value

    assert Try.of(
        lambda x: x, 2).on_success(success_mock) ==\
        Try.of(lambda x: x, 2)
    assert Try.of(
        lambda x: x, 2).on_success(success_mock).get() == 2
    assert Try.of(
        lambda x: x, 2).on_success(lambda x: x) ==\
        Try.of(lambda x: x, 2)
    assert Try.of(
        lambda x: x, 2).on_success(lambda x: x).get() == 2

    def fail_mock(value):
        raise Exception

    assert Try.of(
        lambda x: x, 2).on_success(fail_mock).get() == 2

# Generated at 2022-06-21 19:21:56.105417
# Unit test for method __str__ of class Try
def test_Try___str__():
    value = 'test'
    monad = Try(value, True)
    assert str(monad) == 'Try[value={}, is_success={}]'.format(value, True)

# Generated at 2022-06-21 19:21:57.665364
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10


# Generated at 2022-06-21 19:22:05.094817
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try('error', False) == Try('error', False)
    assert Try(1, False) != Try(1, True)
    assert Try(None, False) != Try(None, True)
    assert Try('error1', False) != Try('error2', False)
    assert Try(None, True) != Try(None, False)


# Generated at 2022-06-21 19:22:17.765191
# Unit test for method bind of class Try
def test_Try_bind():
    string = "123"
    try_bind = Try(string, True)
    new_try = try_bind.bind(lambda x: Try(x.split(' '), True))
    assert new_try == Try(['123'], True)

    def test_function(string):
        return string.split(' ')

    new_try = try_bind.bind(lambda x: Try.of(test_function, x))
    assert new_try == Try(['123'], True)

    try_bind = Try(string, False)
    new_try = try_bind.bind(lambda x: Try(x.split(' '), True))
    assert new_try == Try(string, False)

    new_try = try_bind.bind(lambda x: Try.of(test_function, x))
    assert new_try == Try

# Generated at 2022-06-21 19:22:20.589661
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2

# Generated at 2022-06-21 19:22:26.605572
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try\
        .of(lambda: 1)\
        .filter(lambda value: value == 1) == Try(1, True)
    assert Try\
        .of(lambda: 1)\
        .filter(lambda value: value == 2) == Try(2, False)
    assert Try\
        .of(lambda: 1 / 0)\
        .filter(lambda value: value == 2) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:22:29.763151
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(5, True) == Try(5, True)
    assert Try(5, True) != Try(10, True)

    assert Try(5, True) != Try(5, False)
    assert Try(5, False) != Try(10, False)



# Generated at 2022-06-21 19:22:38.367907
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(2, True).get_or_else(4) == 2
    assert Try(2, False).get_or_else(4) == 4
    assert Try(None, True).get_or_else(4) == None


# Generated at 2022-06-21 19:22:41.902150
# Unit test for constructor of class Try
def test_Try():
    assert Try(2, True) == Try(2, True)
    assert Try(2, True) != Try(3, True)
    assert Try(2, True) != Try(2, False)
    assert Try(2, True) != Try(3, False)
    assert Try(2, False) != Try(3, True)



# Generated at 2022-06-21 19:22:53.260551
# Unit test for method map of class Try
def test_Try_map():
    try_map = Try.of(lambda x: x ** 2, 2)
    assert try_map.is_success is True
    assert try_map.value == 4

    try_map = Try.of(lambda x: x ** 2, '2')
    assert try_map.is_success is False
    assert isinstance(try_map.value, TypeError)

    try_map = Try.of(lambda x: x ** 2, 2)
    try_map = try_map.map(lambda x: '{}'.format(x))
    assert try_map.is_success is True
    assert try_map.value == '4'

    try_map = Try.of(lambda x: x ** 2, '2')
    try_map = try_map.map(lambda x: '{}'.format(x))

# Generated at 2022-06-21 19:22:54.886821
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1



# Generated at 2022-06-21 19:22:57.853627
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(_):
        return Try(10, True)
    assert binder(Try(5, True)) == Try(10, True)
    assert binder(Try(5, False)) == Try(5, False)


# Generated at 2022-06-21 19:23:00.918581
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) != Try(2, True)


# Generated at 2022-06-21 19:23:06.777154
# Unit test for method map of class Try
def test_Try_map():
    def sum(a, b):
        return a + b

    def add_one(a):
        return a + 1

    assert Try.of(sum, 1, 2).map(add_one) == Try(4, True)
    assert Try.of(sum, 1, 'test').map(add_one) == Try('test', False)


# Generated at 2022-06-21 19:23:13.396011
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    The on_success method of Try class must call success_callback
    with monad value when monad is successfully, otherwise do nothing.

    :returns: True when is no Exceptions, othercase False
    :rtype: Boolean
    """
    def f(_):
        raise Exception('Catch')

    def g(x):
        assert x == 'a'

    return Try.of(f, 'a').on_success(g).is_success



# Generated at 2022-06-21 19:23:19.473222
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    value_success = "Foo"
    value_fail = "Bar"

    try_success = Try(value_success, True)
    try_fail = Try(value_fail, False)

    assert value_success == try_success.get_or_else(value_fail)
    assert try_success.get_or_else(value_success) == try_success.value
    assert value_fail == try_fail.get_or_else(value_fail)
    assert value_success == try_fail.get_or_else(value_success)

# Generated at 2022-06-21 19:23:31.672691
# Unit test for method map of class Try
def test_Try_map():
    try_success = Try(42, True)
    try_fail = Try(ValueError('not even'), False)

    # Successful cases
    assert try_success.map(lambda x: x + 1) == Try(43, True)
    assert try_success.map(lambda x: x ** 2) == Try(1764, True)
    assert try_success.map(lambda _: 42) == Try(42, True)

    # Failure cases
    assert try_fail.map(lambda _: None) == Try(ValueError('not even'), False)
    assert try_fail.map(lambda x: x.message) == Try(ValueError('not even'), False)
    assert try_fail.map(lambda x: x.args[0]) == Try(ValueError('not even'), False)

# Generated at 2022-06-21 19:23:43.174699
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda x: x, 1).on_success(lambda x: print(x+1)) == Try(1, True)



# Generated at 2022-06-21 19:23:50.399707
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Create Try successfully
    user = Try.of(lambda: User('vasya', 'vasya@mail.com'))
    assert user.get_or_else(None) == User('vasya', 'vasya@mail.com')

    # Create Try not successfully
    assert Try.of(lambda: User()).get_or_else(User('vasya', 'vasya@mail.com')) == User('vasya', 'vasya@mail.com')


# Generated at 2022-06-21 19:23:53.116493
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2
    assert Try('2', True).get() == '2'
    assert Try(True, True).get() is True
    assert Try(None, True).get() is None



# Generated at 2022-06-21 19:24:02.541771
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda : "123").filter(lambda x: len(x) < 5)
    assert result == Try("123", True)
    result = Try.of(lambda : "123").filter(lambda x: len(x) > 5)
    assert result == Try("123", False)
    result = Try.of(lambda : "123").filter(lambda x: len(x) > 5)
    assert result == Try("123", False)
    result = Try.of(lambda : "123").filter(lambda x: len(x) < 2)
    assert result == Try("123", False)


# Generated at 2022-06-21 19:24:05.640180
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try('a', True)) == "Try[value='a', is_success=True]"
    assert str(Try('a', False)) == "Try[value='a', is_success=False]"


# Generated at 2022-06-21 19:24:12.599147
# Unit test for method filter of class Try
def test_Try_filter():
    # GIVEN
    try_monad = Try(1, True)

    # WHEN
    try_monad_filtered = try_monad.filter(lambda x: True)

    # THEN
    assert try_monad_filtered == Try(1, True)

    # WHEN
    try_monad_filtered = try_monad.filter(lambda x: False)

    # THEN
    assert try_monad_filtered == Try(1, False)



# Generated at 2022-06-21 19:24:19.272525
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def fail_callback(value):
        print('Fail callback with value =', value)

    def raise_error():
        raise Exception('Exception')

    def raise_error_with_msg(msg='message'):
        raise Exception(msg)

    assert Try.of(lambda: 1).on_fail(fail_callback).get() == 1
    assert Try.of(lambda: 1).on_fail(fail_callback).on_fail(fail_callback).get() == 1
    assert Try.of(raise_error).on_fail(fail_callback).get() == 'Exception'
    assert Try.of(raise_error_with_msg).on_fail(fail_callback).get() == 'message'



# Generated at 2022-06-21 19:24:22.737814
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'


# Generated at 2022-06-21 19:24:30.020798
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Arrange
    try_true = Try(9, True)
    try_false = Try(9, False)
    try_false_not_equals = Try('test', False)

    # Assert
    assert try_false != try_false_not_equals
    assert try_false_not_equals != try_false
    assert try_true != try_false
    assert try_false != try_true
    assert try_true == Try(9, True)
    assert try_false == Try(9, False)


# Generated at 2022-06-21 19:24:34.953616
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    """
    Test __eq__ method of class Try.
    """
    try_success = Try(10, True)
    try_fail = Try(Exception('error'), False)
    assert(try_success == Try(10, True))
    assert(try_fail == Try(Exception('error'), False))
    assert(try_success != Try(10, False))
    assert(try_fail != Try(Exception('another error'), False))


# Generated at 2022-06-21 19:24:56.730665
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1).bind(lambda x: Try.of(lambda: x+2)) == Try(3, True)
    assert Try.of(lambda: 1).bind(lambda x: Try.of(lambda: 1/0)) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-21 19:24:58.968800
# Unit test for method on_fail of class Try

# Generated at 2022-06-21 19:25:02.572935
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    success1 = Try.of(int, '1')
    success2 = Try.of(int, '1')
    fail1 = Try.of(int, 'a')
    fail2 = Try.of(int, 'a')
    assert success1 == success2
    assert fail1 == fail2
    assert success1 != fail1


# Generated at 2022-06-21 19:25:05.612952
# Unit test for method on_success of class Try
def test_Try_on_success():
    def on_success(value):
        assert isinstance(value, int)
        assert value == 42

    assert Try(42, True).on_success(on_success) == Try(42, True)



# Generated at 2022-06-21 19:25:14.236162
# Unit test for constructor of class Try
def test_Try():
    # Test for successfully Try
    assert Try(5, True) == Try(5, True)
    assert Try(5, True) != Try(6, True)
    assert Try(5, True) != Try(6, False)
    assert Try(5, True) != Try(5, False)
    # Test for not successfully Try
    assert Try(5, False) == Try(5, False)
    assert Try(5, False) != Try(6, True)
    assert Try(5, False) != Try(6, False)
    assert Try(5, False) != Try(5, True)



# Generated at 2022-06-21 19:25:18.766102
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda v: v >= 10) == Try(10, True)
    assert Try(5, True).filter(lambda v: v >= 10) == Try(5, False)
    assert Try(10, False).filter(lambda v: v >= 10) == Try(10, False)


# Generated at 2022-06-21 19:25:29.182762
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test method bind of class Try.
    """
    def test_function(a):
        return 5 / a

    assert Try.of(test_function, 2).bind(lambda a: Try(a, True)) == Success(2.5)

    assert Try.of(test_function, 'a').bind(lambda a: Try(a, True)) == Failure(TypeError)

    def test_function_bind(a):
        return Try.of(test_function, a)

    assert Try.of(test_function, 3).bind(test_function_bind).bind(test_function_bind) \
        == Success(0.8333333333333334)

    assert Try.of(test_function, 0).bind(test_function_bind).bind(test_function_bind) \
        == Failure(ZeroDivisionError)



# Generated at 2022-06-21 19:25:38.952428
# Unit test for method bind of class Try
def test_Try_bind():
    @try_safe
    def foo(x, y):
        return x / y

    @try_safe
    def bar(z):
        return z + 1

    t = Try.of(foo, 1, 0)

    assert t.is_success is False

    t2 = t.bind(bar)
    assert t2.is_success is False
    assert t2.get() == t.get()

    t3 = Try.of(foo, 1, 1).bind(bar)
    assert t3.is_success is True
    assert t3.get() == bar(foo(1, 1))



# Generated at 2022-06-21 19:25:47.481789
# Unit test for method filter of class Try
def test_Try_filter():
    # Successfully with filter returns self
    assert Try.of(lambda x: 3).filter(lambda x: True) == Try.of(lambda x: 3)

    # Successfully with filter returns self
    assert Try.of(lambda x: 3).filter(lambda x: x == 3) == Try.of(lambda x: 3)

    # Successfully with filter returns self
    assert Try.of(lambda x: 3).filter(lambda x: x == 4) == Try(4, False)

    # Not successfully with filter return not successfully try
    assert Try(4, False).filter(lambda x: x == 3) == Try(4, False)

# Generated at 2022-06-21 19:25:48.718081
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1



# Generated at 2022-06-21 19:26:22.099788
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(4, True) == Try(4, True)



# Generated at 2022-06-21 19:26:27.176308
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Unit test for method __str__ of class Try
    """
    # Example when monad is successfully
    first_value = Try(10, True)
    assert first_value.__str__() == 'Try[value={}, is_success={}]'.format(10, True)

    # Example when monad is not successfully
    second_value = Try('string', False)
    assert second_value.__str__() == 'Try[value={}, is_success={}]'.format(
        'string', False)

# Generated at 2022-06-21 19:26:32.234809
# Unit test for method on_success of class Try
def test_Try_on_success():
    def write(x: int) -> None:
        print(x)

    val = 12
    assert Try.of(lambda: val).on_success(write) == Try(val, True)
    assert Try.of(lambda: 1/0).on_success(write) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:26:35.674345
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    expected_result = Try(True, True)
    result = Try(True, True)
    assert expected_result == result
    assert expected_result == expected_result


# Generated at 2022-06-21 19:26:44.497998
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_success = Try(lambda: 1 / 1, True)
    try_success_on_success = try_success.on_success(lambda v: print(v))
    assert try_success == try_success_on_success
    assert try_success.value == try_success_on_success.value
    assert try_success.is_success == try_success_on_success.is_success
    try_fail = Try(lambda: 1 / 0, False)
    try_fail_on_success = try_fail.on_success(lambda v: print(v))
    assert try_fail == try_fail_on_success
    assert try_fail.value == try_fail_on_success.value
    assert try_fail.is_success == try_fail_on_success.is_success


# Generated at 2022-06-21 19:26:52.917641
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    def f(a: int, b: int) -> int:
        return a + b

    # Test for success
    try_ = Try.of(f, 1, 2)
    assert try_.get_or_else(0) == 3
    assert try_ == Try(3, True)

    # Test for fail
    try_ = Try.of(f, 1, 'abc')
    assert try_.get_or_else(0) == 0
    assert try_.is_success is False



# Generated at 2022-06-21 19:27:01.995745
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # create value for Try
    value = 'value'

    # create new Try
    try_monad = Try(value, True)

    # when call filter method with filterer function,
    # this function will return True,
    # we will get Try with previous value
    assert try_monad.filter(lambda x: True) == Try(value, True)

    # when call filter method with filterer function,
    # this function will return False,
    # we will get Try with previous value which is not successfully
    assert try_monad.filter(lambda x: False) == Try(value, False)


# Generated at 2022-06-21 19:27:06.220646
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(10, True).on_fail(lambda x: print('value: {}'.format(x))).get() == 10
    assert Try(10, False).on_fail(lambda x: print('value: {}'.format(x))).get() == 10

test_Try_on_fail()


# Generated at 2022-06-21 19:27:08.535635
# Unit test for constructor of class Try
def test_Try():
    res = Try(42, True)
    assert res.value == 42
    assert res.is_success == True


# Generated at 2022-06-21 19:27:11.126666
# Unit test for method map of class Try
def test_Try_map():
    assert Try(5, True).map(lambda x: x * 2) == Try(10, True)
    assert Try(5, False).map(lambda x: x * 2) == Try(5, False)


# Generated at 2022-06-21 19:28:29.013209
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda n: n < 10) == Try(5, True)
    assert Try(10, True).filter(lambda n: n < 10) == Try(10, False)
    assert Try(5, False).filter(lambda n: n < 10) == Try(5, False)


# Generated at 2022-06-21 19:28:33.706104
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def success_callback(value):
        print('On success: {0}'.format(value))

    assert Try(2, True).on_success(success_callback) == Try(2, True)

    assert Try(2, False).on_success(success_callback) == Try(2, False)



# Generated at 2022-06-21 19:28:39.992677
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1337, True)) == 'Try[value=1337, is_success=True]'
    assert str(Try('1337', True)) == 'Try[value=1337, is_success=True]'
    assert str(Try([1337], True)) == 'Try[value=[1337], is_success=True]'
    assert str(Try(1337, False)) == 'Try[value=1337, is_success=False]'
    assert str(Try('1337', False)) == 'Try[value=1337, is_success=False]'
    assert str(Try([1337], False)) == 'Try[value=[1337], is_success=False]'



# Generated at 2022-06-21 19:28:48.227706
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_success_function(value):
        return value

    def test_fail_function(value):
        assert True is False

    assert isinstance(Try.of(test_success_function, 1).on_success(test_success_function), Try)
    assert isinstance(Try.of(test_success_function, 1).on_success(test_fail_function), Try)
    assert isinstance(Try.of(test_fail_function, 1).on_success(test_success_function), Try)
    assert isinstance(Try.of(test_fail_function, 1).on_success(test_fail_function), Try)


# Generated at 2022-06-21 19:28:52.511705
# Unit test for method get of class Try
def test_Try_get():
    try_success = Try(10, True)
    try_failure = Try(None, False)

    assert try_success.get() == 10
    assert try_failure.get() is None


# Generated at 2022-06-21 19:28:55.336473
# Unit test for method __str__ of class Try
def test_Try___str__():
    test_Try = Try(10, True)
    assert str(test_Try) == 'Try[value=10, is_success=True]'



# Generated at 2022-06-21 19:29:02.841747
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def assert_on_fail(expected, actual):
        e_type = type(expected)
        a_type = type(actual)
        assert e_type == a_type
        assert e_type == type(Exception()), 'Type of exception should be same of Exception!'
        assert expected.args == actual.args

    def on_fail_callback(value):
        return value

    exception_message = 'exception'

    assert_on_fail(
        on_fail_callback(
            Try(Exception(exception_message), is_success=False
            ).on_fail(on_fail_callback
            ).get()
        ).args[0],
        exception_message
    )



# Generated at 2022-06-21 19:29:06.472484
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(2, False) == Try(2, False)
    assert Try(1, True) != Try(True, False)

# Generated at 2022-06-21 19:29:13.465929
# Unit test for method bind of class Try
def test_Try_bind():
    def test_fn(param):
        if param:
            return Try('success', True)
        return Try('fail', False)
    assert Try('success', True) == Try(1, True).bind(test_fn)
    assert Try('fail', False) == Try(0, True).bind(test_fn)
    assert Try('a', True) == Try('a', True).bind(test_fn)
    assert Try('fail', False) == Try('a', False).bind(test_fn)
    

# Generated at 2022-06-21 19:29:15.333452
# Unit test for constructor of class Try
def test_Try():
    assert not Try(None, True) == None
    # assert Try(None, True) == Try(None, True)



# Generated at 2022-06-21 19:30:35.008770
# Unit test for constructor of class Try
def test_Try():
    try_class = Try(42, True)
    assert try_class.value == 42
    assert try_class.is_success == True
    try_class = Try(42, False)
    assert try_class.value == 42
    assert try_class.is_success == False


# Generated at 2022-06-21 19:30:38.349035
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(10, True).get() == 10
    assert Try(10, False).get() == 10


# Generated at 2022-06-21 19:30:46.350616
# Unit test for method on_success of class Try
def test_Try_on_success():
    num = 1
    is_first_callback_call = False
    is_second_callback_call = False

    first_success_callback = lambda value: is_first_callback_call.__setitem__(0, value == num)
    second_success_callback = lambda value: is_second_callback_call.__setitem__(0, value == num)

    Try(num, True).on_success(first_success_callback)
    Try(num, True).on_success(first_success_callback).on_success(second_success_callback)

    assert is_first_callback_call == True
    assert is_second_callback_call == True
