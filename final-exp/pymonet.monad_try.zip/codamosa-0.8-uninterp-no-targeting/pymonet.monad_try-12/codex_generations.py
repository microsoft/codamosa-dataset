

# Generated at 2022-06-21 19:20:51.126044
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(None, True) == Try(None, True)


# Generated at 2022-06-21 19:21:01.372044
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test Try filter method.
    """

    def filterer(value):
        return True

    def incorrect_filterer(value):
        return False

    def filterer_with_exception(value):
        raise Exception('error')

    def filterer_with_value_exception(value):
        raise ValueError('error')

    # when monad is not successfully
    success_value = 1
    try_instance = Try(success_value, True)
    try_instance_filtered = try_instance.filter(filterer)
    assert try_instance == try_instance_filtered

    try_instance = Try(success_value, False)
    try_instance_filtered = try_instance.filter(filterer)
    assert try_instance == try_instance_filtered

    # when filt

# Generated at 2022-06-21 19:21:06.618070
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Given
    input_value = Try(None, False)
    side_effect_var = None
    on_fail_callback = lambda value: side_effect_var.append(value)

    # When
    input_value.on_fail(on_fail_callback)

    # Then
    assert side_effect_var == None


# Generated at 2022-06-21 19:21:07.497134
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1



# Generated at 2022-06-21 19:21:10.868715
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(1, True)   # type: Try[int]

    assert str(try_) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-21 19:21:21.884121
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: None).filter(lambda x: True) ==\
        Try(None, True)
    assert Try.of(lambda: None).filter(lambda x: False) ==\
        Try(None, False)
    assert Try.of(lambda: None, 1, 2, 3).filter(lambda x: True) ==\
        Try(None, True)
    assert Try.of(lambda: None, 1, 2, 3).filter(lambda x: False) ==\
        Try(None, False)
    assert Try.of(lambda: None).filter(lambda x: True).get_or_else('?') ==\
        None
    assert Try.of(lambda: None).filter(lambda x: False).get_or_else('?') ==\
        '?'

# Generated at 2022-06-21 19:21:27.990517
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    print('--- test_Try_on_success ---')

    # Should print nothing
    Try(5, False).on_success(lambda x: print(x))

    # Should print '5'
    Try(5, True).on_success(lambda x: print(x))


# Generated at 2022-06-21 19:21:35.383526
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    # Given
    global a
    a = 0
    b = 10
    c = 10
    # When
    global res
    res = Try.of(lambda: a + b).on_success(lambda x: c + x)  # res = Try(20, True)
    # Then
    assert res.value == 20
    assert res.is_success


# Generated at 2022-06-21 19:21:38.878993
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(ValueError('some error'), False)) == "Try[value=ValueError('some error',), is_success=False]"


# Generated at 2022-06-21 19:21:40.797201
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-21 19:21:47.684628
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(2, True) == Try(2, True)
    assert Try(2, False) != Try(2, True)
    assert Try(2, True) != Try(None, True)
    assert Try(2, False) != Try(None, False)



# Generated at 2022-06-21 19:21:50.981880
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception('test'), False) == Try(Exception('test'), False)



# Generated at 2022-06-21 19:21:55.764566
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filter(value):
        return value == 'a'

    def bad_filter(value):
        return False

    assert Try.of(lambda: 'a', False).filter(filter) == Try('a', True)

    assert Try.of(lambda: 'a', False).filter(bad_filter) == Try('a', False)
    assert Try.of(lambda: 'a', False).filter(bad_filter) is not Try.of(lambda: 'a', False)

    assert Try.of(lambda: 'a', False).filter(bad_filter).filter(filter) == Try('a', True)



# Generated at 2022-06-21 19:22:00.913809
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: [1] + [2]).map(lambda x: x[1] + x[0]) == Try(3, True)
    assert Try.of(lambda: [1] + [2]).map(lambda x: x[0] + x[1]) == Try(2, True)
    assert Try.of(div, 3, 0).map(lambda x: x + 1) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0).map(lambda x: x + 1) == Try(ZeroDivisionError(), False)
    assert Try.of(div, 2, 0).map(lambda x: x + 1) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:22:07.684454
# Unit test for method filter of class Try
def test_Try_filter():
    try_success = Try(5, True)
    try_not_success = Try(5, False)

    def filterer(value):
        return value == 5

    assert try_success.filter(filterer) == Try(5, True)
    assert try_not_success.filter(filterer) == Try(5, False)

# Generated at 2022-06-21 19:22:15.105985
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(10, True).filter(lambda x: True) == Try(10, True)
    assert Try(10, True).filter(lambda x: False) == Try(10, False)
    assert Try(10, False).filter(lambda x: True) == Try(10, False)
    assert Try(10, False).filter(lambda x: False) == Try(10, False)


# Generated at 2022-06-21 19:22:23.249866
# Unit test for method map of class Try
def test_Try_map():
    tr = Try.of(lambda: 1).map(lambda x: x + 1)
    assert tr == Try(2, True)
    tr = Try.of(lambda: 1).map(lambda x: x + 1).map(lambda x: x ** 2)
    assert tr == Try(4, True)
    tr = Try.of(lambda: 1 / 0).map(lambda x: x + 1)
    assert tr == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:22:25.751051
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2



# Generated at 2022-06-21 19:22:30.158153
# Unit test for method filter of class Try
def test_Try_filter():
    a = Try(1, True)
    b = Try(2, True)
    c = Try(3, True)
    aa = a.filter(lambda x: x**2 == 1)
    bb = b.filter(lambda x: x**2 == 1)
    cc = c.filter(lambda x: x**2 == 1)
    assert aa == b
    assert bb == a
    assert cc == c



# Generated at 2022-06-21 19:22:37.738905
# Unit test for method on_success of class Try
def test_Try_on_success():
    # GIVEN
    # WHEN
    result = Try.of(lambda: 1+1).on_success(lambda x: x)
    # THEN
    assert result.value == 2
    assert result.is_success
    # GIVEN
    # WHEN
    result = Try.of(lambda: 1/0).on_success(lambda x: x)
    # THEN
    assert not result.is_success


# Generated at 2022-06-21 19:22:46.467381
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(lambda: 3, 3)) == 'Try[value=3, is_success=True]'
    assert str(Try.of(lambda: raise_exception(), 3)) == 'Try[value=asd, is_success=False]'



# Generated at 2022-06-21 19:22:48.786736
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else(7) == 42
    assert Try(None, False).get_or_else(7) == 7


# Generated at 2022-06-21 19:22:51.152377
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception, False) == Try(Exception, False)


# Generated at 2022-06-21 19:22:56.216227
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(x):
        raise Exception('{}'.format(x))
    exception = Exception('test')
    test_func = lambda: None
    test = Try.of(test_func)
    exception = Try.of(test_func, exception)
    test = test.on_fail(fail_callback)
    exception = exception.on_fail(fail_callback)
    assert exception.is_success is True
    assert test.is_success is True



# Generated at 2022-06-21 19:23:00.119919
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def foo(a, b):
        return a + b

    assert Try.of(foo, 10, 12) == Try.of(foo, 10, 12)
    assert Try.of(foo, 10, 12) != Try.of(foo, 11, 12)
    assert Try.of(foo, 10, 12) != Try(10, True)


# Generated at 2022-06-21 19:23:03.973756
# Unit test for method __str__ of class Try
def test_Try___str__(): # pragma: no cover
    assert str(Try(10, True)) == "Try[value=10, is_success=True]"
    assert str(Try(10, False)) == "Try[value=10, is_success=False]"


# Generated at 2022-06-21 19:23:15.635984
# Unit test for method bind of class Try
def test_Try_bind():

    def div(a, b):
        return a / b

    # You can never do that in imperative language.
    # You must use try-catch block in every function call.
    # Here you can use simple bind and focus on program logic.

    def ten_div_b(b):
        return Try.of(div, 10, b)

    def bind_safe_div():
        t = Try.of(div, 10, 2).bind(ten_div_b)
        div_1 = t.bind(ten_div_b).get()
        div_2 = t.bind(ten_div_b).bind(ten_div_b).get()
        div_3 = t.bind(ten_div_b).bind(ten_div_b).bind(ten_div_b).get()
        return div_1 == 2.5

# Generated at 2022-06-21 19:23:19.429535
# Unit test for constructor of class Try
def test_Try():
    fn = lambda: str("try_test")
    monad = Try(fn(), True)
    assert monad.get() == fn()
    assert monad.is_success


# Generated at 2022-06-21 19:23:31.629900
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x > 0) == Try(1, True)
    assert Try(2, True).filter(lambda x: x % 2 == 0) == Try(2, True)
    assert Try(-2, True).filter(lambda x: x % 2 == 0) == Try(-2, False)
    assert Try(-2, True).filter(lambda x: x > 0) == Try(-2, False)
    assert Try(2, True).filter(lambda x: x > 0) == Try(2, True)

    # Unit test for cases when monad is not successfully
    assert Try(None, False).filter(lambda x: x == 0) == Try(None, False)
    assert Try(ValueError('error'), False).filter(lambda x: x == 0) == Try(ValueError('error'), False)



# Generated at 2022-06-21 19:23:33.191830
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) is not None


# Generated at 2022-06-21 19:23:40.632432
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, False)



# Generated at 2022-06-21 19:23:45.467432
# Unit test for method on_success of class Try
def test_Try_on_success():
    incr = lambda x: x + 1
    assert(Try(10, True).on_success(incr) == Try(10, True))
    assert(Try(10, False).on_success(incr) == Try(10, False))


# Generated at 2022-06-21 19:23:51.834007
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Run test on method on_fail of class Try
    """
    try:
        raise Exception('test exception')
    except Exception as e:
        exception = e

    # test on success
    assert Try(3, True).on_fail(lambda _: 1/0) == Try(3, True)

    # test on fail

# Generated at 2022-06-21 19:24:04.818240
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def successfully_fn(val):
        return Try(val, True)

    def unsuccessfully_fn(val):
        return Try(val, False)


# Generated at 2022-06-21 19:24:13.080564
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # method on_fail
    def on_fail(self, fail_callback):
        if not self.is_success:
            fail_callback(self.value)
        return self

    # function for test
    def func_to_test(a, b):
        return a*b
    # initial preparations
    maybe = Try.of(1, 2)
    success = Try.of(func_to_test, 3, 2)
    is_failure = False
    # test
    assert type(maybe) == Try
    assert success.on_fail(lambda err: is_failure == True) == success

# Generated at 2022-06-21 19:24:18.979454
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 10

    assert Try.of(lambda: 5).filter(filterer) == Try(5, False)
    assert Try.of(lambda: 15).filter(filterer) == Try(15, True)
    assert Try.of(lambda: 15, 1, 2).filter(filterer) == Try(15, True)


# Generated at 2022-06-21 19:24:30.143139
# Unit test for method filter of class Try
def test_Try_filter():
    def divide_by_zero(x):
        return x / 0

    def even(x):
        return x % 2 == 0

    def odd(x):
        return x % 2 != 0

    try_success = Try(4, True)
    try_fail = Try(4, False)
    try_fail_odd = try_fail.filter(odd)
    try_fail_even = try_fail.filter(even)
    try_success_odd = try_success.filter(odd)
    try_success_even = try_success.filter(even)
    try_fail_divide_by_zero = Try.of(divide_by_zero, 4)
    try_fail_divide_by_zero_even = try_fail_divide_by_zero.filter(even)
    try_fail_divide_

# Generated at 2022-06-21 19:24:33.236660
# Unit test for method on_success of class Try
def test_Try_on_success():
    def on_success(value):
        return value + 1

    assert Try(1, True).on_success(on_success) == Try(1, True)
    assert Try(2, True).on_success(on_success) == Try(3, True)



# Generated at 2022-06-21 19:24:34.718189
# Unit test for method get of class Try
def test_Try_get():
    value = 5
    try_monad = Try(value, True)
    assert try_monad.get() == value


# Generated at 2022-06-21 19:24:36.179386
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    assert Try(20, False).get() == 20


# Generated at 2022-06-21 19:24:52.018063
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    class ExampleException(Exception):
        pass

    def call(a):
        raise Exception(a)

    t = Try.of(call, 1)
    trigger = False

    def callback(a):
        nonlocal trigger
        trigger = True

    t.on_fail(callback)
    assert trigger

    t = Try.of(call, 2)

    def callback_with_exception(a):
        raise ExampleException()

    with pytest.raises(ExampleException):
        t.on_fail(callback_with_exception)



# Generated at 2022-06-21 19:24:56.867306
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def exception():
        raise Exception('test')

    def fail(value):
        assert isinstance(value, Exception)

    assert Try(1, True).on_fail(fail) == Try(1, True)
    assert Try(exception(), False).on_fail(fail) == Try(exception(), False)


# Generated at 2022-06-21 19:25:01.207580
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    expect(Try(5, True)).to_be(Try(5, True))
    expect(Try(5, False)).to_be(Try(5, False))
    expect(Try(5, True)).not_to_be(None)
    expect(Try(5, False)).not_to_be(None)


# Generated at 2022-06-21 19:25:12.908964
# Unit test for method filter of class Try
def test_Try_filter():
    # Test for successful monad
    actual_1 = Try(1, True).filter(lambda x: True)
    assert actual_1 == Try(1, True), 'actual: {}'.format(actual_1)

    actual_2 = Try(1, True).filter(lambda x: False)
    assert actual_2 == Try(1, False), 'actual: {}'.format(actual_2)

    # Test for not successful monad
    actual_3 = Try(Exception(), False).filter(lambda x: True)
    assert actual_3 == Try(Exception(), False), 'actual: {}'.format(actual_3)

    actual_4 = Try(Exception(), False).filter(lambda x: False)
    assert actual_4 == Try(Exception(), False), 'actual: {}'.format(actual_4)

# Generated at 2022-06-21 19:25:16.952333
# Unit test for method get of class Try
def test_Try_get():
    print("\nTest Try.get()")
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try('x', True).get() == 'x'
    assert Try('x', False).get() == 'x'
    print('Passed')


# Generated at 2022-06-21 19:25:22.700564
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fn():
        raise Exception()

    assert Try(None, False).on_fail(fn).is_success is not True
    assert Try(None, False).on_fail(fn).value is None
    assert Try(None, True).on_fail(fn).is_success is True
    assert Try(None, True).on_fail(fn).value is None


# Generated at 2022-06-21 19:25:25.950296
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: x) == Try(1, True)
    assert Try(1, False).on_success(lambda x: x) == Try(1, False)


# Generated at 2022-06-21 19:25:31.868675
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def div(x, y):
        return x / y

    def take_dictionary(dict):
        return Try.of(div, dict['left'], dict['right'])

    assert Try.of(take_dictionary, {'left': 4, 'right': 2}) == Try(2, True)
    assert Try.of(take_dictionary, {'left': 4, 'right': 0}) == Try(0, False)
    assert Try.of(div, 4, 0) == Try(0, False)


# Generated at 2022-06-21 19:25:40.286814
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, True)



# Generated at 2022-06-21 19:25:45.687263
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    success = Try.of(lambda x: x, 1)
    assert str(success) == 'Try[value=1, is_success=True]'
    fail = Try.of(lambda x: 1/0, 1)
    assert str(fail) == 'Try[value=ZeroDivisionError("division by zero",), is_success=False]'



# Generated at 2022-06-21 19:26:04.628230
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    value_1 = 1
    value_2 = '1'
    assert Try(value_1, True) == Try(value_1, True)
    assert Try(value_1, True) != Try(value_2, True)
    assert Try(value_1, True) != Try(value_1, False)



# Generated at 2022-06-21 19:26:15.600475
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    exception: Exception = Exception('test_Try_on_fail')
    try_value: Try[str] = Try('test string', True)
    try_exception: Try[Exception] = Try(exception, False)
    try_exception_copy: Try[Exception] = Try(exception, False)
    on_fail_callback: Callable[[Exception], None] = lambda _: None

    assert try_value.on_fail(on_fail_callback) == try_value
    assert try_exception.on_fail(on_fail_callback) == try_exception_copy


# Generated at 2022-06-21 19:26:18.225850
# Unit test for method map of class Try
def test_Try_map():
    result = Try.of(lambda x: x**2, 2)
    assert result.map(lambda x: x + 1) == Try(5, True)

    assert Try(ValueError(""), False).map(lambda x: x + 1) == Try(ValueError(""), False)


# Generated at 2022-06-21 19:26:23.280600
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_success(value):
        pass

    def test_fail(value):
        pass

    def value_must_equal(value):
        assert value == 10

    Try(10, True).on_success(test_success)
    Try(10, True).on_success(value_must_equal)
    Try(10, False).on_success(test_fail)



# Generated at 2022-06-21 19:26:30.453651
# Unit test for method filter of class Try
def test_Try_filter():
    def seq(n):
        i = 0
        while i < n:
            yield i
            i += 1

    def test():
        arr = [
            Try.of(lambda: 5).filter(lambda v: v > 3),
            Try.of(lambda: 7).filter(lambda v: v > 10),
            Try.of(lambda: 1 / 0).filter(lambda v: v > 10),
            Try.of(lambda: 'test').filter(lambda v: v == 'test'),
            Try.of(lambda: 't').filter(lambda v: len(v) > 1),
        ]
        assert arr[0] == Try(5, True)
        assert arr[1] == Try(7, False)
        assert arr[2] == Try(ZeroDivisionError(), False)

# Generated at 2022-06-21 19:26:39.143497
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    def foo(x):
        return x + 1
    try_one = Try.of(foo, 1)
    assert str(try_one) == 'Try[value=2, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'


# Generated at 2022-06-21 19:26:45.070199
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('Success', True)) == 'Try[value=Success, is_success=True]'
    assert str(Try('Success', False)) == 'Try[value=Success, is_success=False]'

# Generated at 2022-06-21 19:26:48.166893
# Unit test for constructor of class Try
def test_Try():
    try_1 = Try('value', True)
    try_2 = Try('value', True)

    assert try_1 == try_2


# Generated at 2022-06-21 19:26:52.816271
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, True) != Try(42, True)



# Generated at 2022-06-21 19:27:01.114991
# Unit test for method map of class Try
def test_Try_map():
    from functools import partial

    fn_to_pass_to_Try = partial(int, base=2)

    result = Try.of(fn_to_pass_to_Try, '1000')

    assert result.map(lambda x: x*10) == Try(80, True)

    result = Try.of(fn_to_pass_to_Try, '2')

    assert result.map(lambda x: x*10) == Try(2, True)

    assert False == result.is_success == result.map(lambda x: x*10).is_success



# Generated at 2022-06-21 19:27:38.608761
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != True
    assert Try(1, True) != object()
    assert Try(1, True) != None
    assert Try(1, True) != 1
    assert Try(1, True) != 'Try[value={}, is_success={}]'.format(1, True)


# Generated at 2022-06-21 19:27:41.310450
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda : 1, list()).get() == 1
    assert Try.of(int, None).get() is None


# Generated at 2022-06-21 19:27:44.775030
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)


# Generated at 2022-06-21 19:27:49.949358
# Unit test for constructor of class Try
def test_Try():
    """
    Test Try constructor.
    """
    success = Try(10, True)
    fail = Try('exception', False)
    assert success.value == 10
    assert success.is_success == True
    assert fail.value == 'exception'
    assert fail.is_success == False



# Generated at 2022-06-21 19:27:53.579858
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, False) != Try(None, True)


# Generated at 2022-06-21 19:28:01.895208
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test method on_fail of class Try.
    """
    value = None

    def fail_callback(e: Exception):
        nonlocal value
        value = e

    Try.of(lambda: 1 / 0).on_fail(fail_callback)
    assert value.__class__ is ZeroDivisionError
    value = None
    Try.of(lambda: 1 / 1).on_fail(fail_callback)
    assert value is None



# Generated at 2022-06-21 19:28:03.307449
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert(Try(42, True).get() == 42)
    assert(Try(None, False).get() == None)


# Generated at 2022-06-21 19:28:09.263664
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 1).map(lambda a: a + 1) == Try(2, True)  # Test successful value
    assert Try.of(lambda: 1 / 0).map(lambda a: a + 1) == Try(1 / 0, False)  # Test not successful value


# Generated at 2022-06-21 19:28:15.123019
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    try:
        assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
        assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    except AssertionError:
        raise AssertionError('Error test __str__ of class Try')


# Generated at 2022-06-21 19:28:18.070308
# Unit test for method get of class Try
def test_Try_get():
    failed_try = Try(13, False)
    assert failed_try.get() == 13
    succeeded_try = Try(13, True)
    assert succeeded_try.get() == 13


# Generated at 2022-06-21 19:29:36.807434
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Create new successfully monad and assign on_success method with lambda
    which set value to 1. Then compare new monad with monad Try(1, True).

    :returns: True when works correctly.
    :rtype: Boolean
    """
    a = Try(0, True).on_success(lambda x: x + 1)
    # Compare a: Try(1, True) and b: Try(1, True)
    b = Try(1, True)
    return a == b


# Generated at 2022-06-21 19:29:42.638971
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True)\
        .bind(lambda x: Try(x + 1, True))\
        .bind(lambda x: Try(x + 1, True)) == Try(3, True)

    assert Try(lambda x: x + 1, True)\
        .bind(lambda f: Try(f(2), True))\
        .bind(lambda x: Try(x + 1, True)) == Try(4, True)



# Generated at 2022-06-21 19:29:44.860637
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)

    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-21 19:29:47.737413
# Unit test for method get of class Try
def test_Try_get():
    t = Try(42, True)
    assert t.get() == 42

    t = Try(42, False)
    assert t.get() == 42


# Generated at 2022-06-21 19:29:54.813058
# Unit test for constructor of class Try
def test_Try():
    # Test for successful Try
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) != Try(None, True)
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    # Test for not successful Try
    assert Try('Test', False) == Try('Test', False)
    assert Try('Test', False) != Try('Another test', False)
    assert str(Try('Test', False)) == 'Try[value=Test, is_success=False]'


# Generated at 2022-06-21 19:30:02.545594
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def check_true():
        assert Try(1, True) == Try(1, True)

    def check_false_value():
        assert Try(1, True) != Try(2, True)

    def check_false_success():
        assert Try(1, True) != Try(1, False)

    def check_false_Try():
        assert Try(1, True) != 1

    check_true()
    check_false_value()
    check_false_success()
    check_false_Try()


# Generated at 2022-06-21 19:30:05.894158
# Unit test for method map of class Try
def test_Try_map():
    try_instance = Try.of(lambda: 1, None).map(lambda a: a + 1)
    expected = Try(2, True)

    assert try_instance == expected


# Generated at 2022-06-21 19:30:07.351248
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    assert Try(10, False).get() == 10


# Generated at 2022-06-21 19:30:13.902892
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Checks when monad is successfully return monad value
    Other case return default_value.

    :returns: None
    :rtype: None
    """
    def unit_test():
        assert Try(10, True).get_or_else(20) == 10
        assert Try(None, False).get_or_else(20) == 20
        assert Try('val', True).get_or_else('def') == 'val'
        assert Try(None, False).get_or_else('defa') == 'defa'

    unit_test()


# Generated at 2022-06-21 19:30:19.143007
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True).value == 1
    assert Try(Exception('Nupp'), False).value.__str__() == 'Nupp'
    assert Try(1, True).is_success is True
    assert Try(Exception('Nupp'), False).is_success is False
