

# Generated at 2022-06-21 19:20:56.204600
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: "a").filter(lambda x: x == "a")\
        == Try.of(lambda: "a")
    assert Try.of(lambda: "a").filter(lambda x: x == "b")\
        == Try.of(lambda: "b", False)

# Generated at 2022-06-21 19:21:02.080176
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """

    # filter on successful value

    try_successful_filter_result = Try.of(lambda: 5, ())\
        .filter(lambda v: v > 10)\
        .get_or_else(0)

    assert try_successful_filter_result == 0

    # filter on failure value

    try_failure_filter_result = Try.of(lambda: 1/0, ())\
        .filter(lambda v: True)\
        .get_or_else(0)

    assert try_failure_filter_result == 0

# Generated at 2022-06-21 19:21:03.922567
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1, ()).get_or_else('default') == 1
    assert Try.of(lambda: 1 / 0, ()).get_or_else('default') == 'default'


# Generated at 2022-06-21 19:21:06.236109
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try("a", False).get() == "a"


# Generated at 2022-06-21 19:21:09.960904
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != 1

test_Try___eq__()


# Generated at 2022-06-21 19:21:14.007447
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(5, True) == Try(5, True)
    assert Try(5, False) != Try(5, True)
    assert Try(5, True) != Try(6, True)
    assert Try(5, True) != Try(5, False)


# Generated at 2022-06-21 19:21:18.617307
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda x: Try(2, True)) == Try(2, True)
    assert Try(1, False).bind(lambda x: Try(2, True)) == Try(1, False)
    assert Try(1, True).bind(lambda x: Try(2, False)) == Try(2, False)
    assert Try(1, False).bind(lambda x: Try(2, False)) == Try(1, False)


# Generated at 2022-06-21 19:21:24.218915
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try.

    :return:
    """
    value = '1'
    mock_filterer = Mock(side_effect=[True, False])

    # when monad is successful and filterer returns True
    assert Try.of(lambda: value, value).filter(mock_filterer) == Try('1', True)

    # when monad is successful and filterer returns False
    assert Try.of(lambda: value, value).filter(mock_filterer) == Try('1', False)

    # when monad is not successful
    assert Try(value, False).filter(mock_filterer) == Try(value, False)

    # check order of filterer calls
    assert mock_filterer.call_count == 3
    assert mock_filterer.call

# Generated at 2022-06-21 19:21:28.312759
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try('Try', True).get() == 'Try'
    assert Try('Try', False).get() == 'Try'



# Generated at 2022-06-21 19:21:33.425450
# Unit test for constructor of class Try
def test_Try():
    assert Try('kappa', True) == Try('kappa', True)
    assert Try('kappa', False) == Try('kappa', False)
    not_equal_try = Try('kappa', False)
    assert not_equal_try != Try('kappa', True)
    assert Try('kappa', True) != not_equal_try


# Generated at 2022-06-21 19:21:45.800273
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-21 19:21:48.422041
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)



# Generated at 2022-06-21 19:22:00.270071
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    from assertionlib import assertion


    def test_value(_value):
        return _value == 1

    def test_value_2(_value):
        return Try(_value + 1, True)

    assertion.eq(Try(1, True).bind(test_value).value, True)
    assertion.eq(Try(1, True).bind(test_value_2).value, 2)
    assertion.eq(Try(1, True).bind(test_value).is_success, True)
    assertion.eq(Try(1, True).bind(test_value_2).is_success, True)

    assertion.eq(Try(1, False).bind(test_value).value, 1)
    assertion.eq(Try(1, False).bind(test_value_2).value, 1)
    assertion.eq

# Generated at 2022-06-21 19:22:03.471060
# Unit test for method on_success of class Try

# Generated at 2022-06-21 19:22:12.827953
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_success = Try(lambda x: x, True)
    try_not_success = Try(ValueError('some error'), False)
    mock_success_callback = Mock()

    try_success.on_success(mock_success_callback)
    mock_success_callback.assert_called_once_with(try_success.value)

    try_not_success.on_success(mock_success_callback)
    mock_success_callback.assert_called_once()



# Generated at 2022-06-21 19:22:17.880112
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_mock(fail_mock):
        return "success" if fail_mock else None
    try_success = Try.of(test_mock, False)

    assert try_success.get() == "success"

    try_fail = Try.of(test_mock, True)

    assert try_fail.get() is None

# Generated at 2022-06-21 19:22:24.250866
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    assert Try(None, False) == Try(None, False).map(lambda a: a)
    assert Try(12, True) == Try(12, True).map(lambda a: a)
    assert Try(24, True) == Try(12, True).map(lambda a: a * 2)


# Generated at 2022-06-21 19:22:28.206519
# Unit test for constructor of class Try
def test_Try():
    """
    Constructor test
    """
    assert Try(5, True) == Try(5, True)
    assert Try(5, True) != Try(5, False)
    assert Try(5, False) != Try(4, True)
    assert Try(4, False) != Try(4, True)


# Generated at 2022-06-21 19:22:36.099844
# Unit test for constructor of class Try
def test_Try():
    assert Try(10, True) == Try(10, True)
    assert Try(10, True) != Try(10, False)
    assert Try('10', True) == Try('10', True)
    assert Try('10', False) != Try('10', True)
    assert Try(Exception(), True) == Try(Exception(), True)
    assert Try(Exception(), False) != Try(Exception(), False)
    assert Try(Exception(), True) != Try(Exception(), False)


# Generated at 2022-06-21 19:22:40.898028
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, False)
    assert Try('a', True) != Try(1, True)
    assert Try('a', True) == Try('a', True)


# Generated at 2022-06-21 19:22:50.853356
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test for method on_fail of class Try
    """
    suc = Try(27, True)
    suc.on_fail(lambda x: print(x))
    assert suc

    fail = Try('test', False)
    fail.on_fail(lambda x: print(x))
    assert fail


# Generated at 2022-06-21 19:22:59.240298
# Unit test for method bind of class Try
def test_Try_bind():

    # given
    def func_with_exception(x):
        raise Exception(x)

    expect_not_successfully_Try_with_exception = Try(Exception('exception'), False)
    expect_successfully_Try_with_mapped_value = Try('value', True)

    # when
    successfully_Try = Try('Test', True)
    not_successfully_Try = Try(Exception('exception'), False)

    # then
    assert successfully_Try.bind(lambda x: Try(x, True)) == successfully_Try
    assert not_successfully_Try.bind(lambda x: Try(x, True)) == not_successfully_Try

    l = not_successfully_Try.map(lambda x: x)

    assert successfully_Try.bind(lambda x: Try('value', True)) == expect_successfully_Try_with_mapped_

# Generated at 2022-06-21 19:23:05.339798
# Unit test for method map of class Try
def test_Try_map():
    tr = Try.of(int, '23')
    assert tr.map(lambda x: x + 5) == Try(28, True)
    assert tr.map(lambda x: x + '5') == Try('235', True)
    assert tr.map(lambda x: x / 0) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:23:10.913046
# Unit test for method map of class Try
def test_Try_map():
    # when monad is successfully
    assert Try.of(lambda: 1,  None)\
        .map(lambda value: value + 1)\
        .get() == 2

    # when monad is not successfully
    assert Try.of(lambda: 1 / 0,  None)\
        .map(lambda value: value + 1)\
        .is_success == False



# Generated at 2022-06-21 19:23:19.078842
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 5, ()).map(lambda x: x ** 2).get() == 25
    assert (
        Try.of(lambda: 5, ()).map(lambda x: x ** 2)
        == Try(25, True)
    )
    assert not Try.of(lambda: 5, ()).map(lambda x: x ** 2).get().is_success
    assert Try.of(lambda: ValueError('asd'), ()).map(lambda x: x ** 2).get() == ValueError('asd')
    assert (
        Try.of(lambda: ValueError('asd'), ())
        == Try(ValueError('asd'), False)
    )


# Generated at 2022-06-21 19:23:20.915115
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1



# Generated at 2022-06-21 19:23:27.994975
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    is_success_value = 'is_success'
    not_success_value = 'not_is_success'
    assert Try(is_success_value, True) == Try(is_success_value, True)
    assert Try(is_success_value, False) != Try(is_success_value, True)
    assert Try(not_success_value, True) != Try(not_success_value, False)



# Generated at 2022-06-21 19:23:32.268893
# Unit test for method filter of class Try
def test_Try_filter():
    def is_number(value):
        return not isinstance(value, str)

    assert Try(2, True).filter(is_number) == Try(2, True)
    assert Try('2', True).filter(is_number) == Try('2', False)

# Generated at 2022-06-21 19:23:37.837149
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test for method bind of class Try.
    """
    f = lambda x: x ** 2
    m = lambda x: Try.of(f, x)
    test = lambda x: x == 200
    assert Try.of(f, 100).bind(m).bind(m).filter(test).is_success



# Generated at 2022-06-21 19:23:44.595983
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Create function to convert string to int and apply it on Try[String].
    """
    def to_int(x: str) -> Try[int]:
        return Try.of(int, x)

    assert Try.of(lambda: '1').bind(to_int) == Try(1, True)
    assert Try.of(lambda: 'q').bind(to_int) == Try(ValueError(), False)


# Generated at 2022-06-21 19:23:56.773629
# Unit test for method on_success of class Try
def test_Try_on_success():
    t = Try('yay', True)
    def success_callback(value):
        assert value == 'yay'
    t.on_success(success_callback)



# Generated at 2022-06-21 19:23:59.819883
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else(0) == 42
    assert Try(None, False).get_or_else(0) == 0


# Generated at 2022-06-21 19:24:01.768044
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1).get_or_else(2) == 1
    assert Try.of(lambda: 1/0).get_or_else(2) == 2



# Generated at 2022-06-21 19:24:03.306389
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10



# Generated at 2022-06-21 19:24:06.448741
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x)) == Try(1, True)
    assert Try(Exception(), False).on_success(lambda x: print(x)) == Try(Exception(), False)



# Generated at 2022-06-21 19:24:17.011222
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test for Try.bind() method.

    """

    def divide(a, b):
        """
        Divide arguments a and b.

        :params a,b: divide arguments
        :type a,b: float
        :returns: result of divide a and b
        :rtype: float
        """
        return a/b

    def bind_divide(a: Try):
        """
        Bind identity to divide function.

        :params a: Try with value.
        :type a: Try[float]
        :returns: result of divide a and 2
        :rtype: Try[float]
        """
        return a.bind(lambda a: Try.of(divide, a, 2))

    # bind_divide(Try.successful('some value'))
    # bind_divide(Try.failure

# Generated at 2022-06-21 19:24:19.506411
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(Exception('Exception test'), False).on_fail(lambda e: print('Test')) == Try(Exception('Exception test'), False)



# Generated at 2022-06-21 19:24:24.211582
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1, ()) == Try(1, True)
    assert Try.of(lambda: 1, ()).get() == 1
    assert Try.of(lambda: 1/0, ()) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1/0, ()).get() is ZeroDivisionError



# Generated at 2022-06-21 19:24:31.028142
# Unit test for method on_success of class Try
def test_Try_on_success():
    def get_dic():
        return {'a': 'b'}

    def print_key_value(dic):
        for k, v in dic.items():
            print(k, v)

    try_get_dic = Try.of(get_dic)
    try_get_dic.on_success(print_key_value).on_fail(print)


# Generated at 2022-06-21 19:24:35.275485
# Unit test for method on_success of class Try
def test_Try_on_success():
    try:
        raise Exception()
    except Exception as e:
        try_monad = Try.of(print, 'Testing. ').map(lambda x: x + 'Method on_success of class Try').on_success \
            (lambda x: print(x)).on_success(lambda x: print(x + ' test successful.'))
        assert try_monad == Try(e, False)



# Generated at 2022-06-21 19:24:46.413815
# Unit test for method map of class Try
def test_Try_map():
    """
    Test for method map of class Try.
    """

# Generated at 2022-06-21 19:24:51.296459
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Successful Try
    assert Try(1, True) == Try(1, True)

    # Not successful Try
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-21 19:24:53.950473
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-21 19:24:57.919017
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    from hamcrest import assert_that, equal_to
    assert_that(Try.of(int, 'a').on_fail(lambda e: print(e)), equal_to(Try(ValueError("invalid literal for int() with base 10: 'a'"), False)))


# Generated at 2022-06-21 19:25:01.985406
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # create not successfully Try
    value = ValueError('test_Try_on_fail')
    monad = Try(value, False)

    # create handler for raise exception
    def handler(exp):
        assert exp == value
    with pytest.raises(AssertionError):
        # without handler
        monad.on_fail(handler)



# Generated at 2022-06-21 19:25:04.597835
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try('Error', False) == Try('Error', False)


# Generated at 2022-06-21 19:25:08.553914
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try:
        Try.of(calculate_div, 5, 0).get_or_else(0)
        assert False, "Error in method get_or_else of class Try"
    except ZeroDivisionError:
        assert True


# Generated at 2022-06-21 19:25:11.558076
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, False).get_or_else(2) == 2
    assert Try(1, True).get_or_else(2) == 1


# Generated at 2022-06-21 19:25:12.891930
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try('foo', True) == Try('foo', True)



# Generated at 2022-06-21 19:25:16.390060
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try:
        assert Try('', False).get_or_else('default') == 'default'
        assert Try('ok', True).get_or_else('default') == 'ok'
    except AssertionError:
        print('Test failed')
    else:
        print('Test success')


# Generated at 2022-06-21 19:25:31.423700
# Unit test for method bind of class Try
def test_Try_bind():
    first = Try.of(int, '123')
    second = first.bind(lambda v: Try.of(int, v / 2))
    third = second.bind(lambda v: Try.of(int, v - 2))
    assert first == Try(123, True)
    assert second == Try(61.5, True)
    assert third == Try(59.5, True)
    assert Try.of(int, 'I am string').bind(lambda v: Try.of(int, v / 2)) == Try('I am string', False)


# Generated at 2022-06-21 19:25:41.076563
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    """
    Test method map of Try monad.
    """
    def safe_func(a):
        return a + 2

    # When using Try, there is no need to use try-catch blocks.
    t = Try.of(safe_func, 2)

    # t is Try[4]
    assert t == Try(4, True)

    # t is Try[6]
    t = t.map(lambda a: a*2)
    assert t == Try(6, True)



# Generated at 2022-06-21 19:25:45.729175
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_try(e):
        assert e == 'error'

    Try(ValueError(), False).on_fail(test_try)
    Try(ValueError(), False).on_fail(test_try)
    Try(ValueError(), False).on_fail(test_try)



# Generated at 2022-06-21 19:25:49.774417
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def fail_callback_function(e):
        assert type(e) == ZeroDivisionError
        assert e.args[0] == 'division by zero'

    Try.of(b'/', 0).on_fail(fail_callback_function) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-21 19:25:52.721558
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert 'Try[value=3, is_success=True]' == str(Try(3, True))
    assert 'Try[value=4, is_success=False]' == str(Try(4, False))


# Generated at 2022-06-21 19:25:57.873833
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_1 = Try.of(lambda: 2, None)

    assert try_1 == Try(2, True)

    try_1.on_success(lambda s: print("Success value: " + str(s)))

    try_2 = Try.of(lambda: None, None)

    assert try_2 == Try(None, True)

    try_2.on_success(lambda s: print("Success value: " + str(s)))



# Generated at 2022-06-21 19:26:03.290007
# Unit test for method on_success of class Try
def test_Try_on_success():
    case_1 = Try.of(lambda: 'result 1', None)

# Generated at 2022-06-21 19:26:10.097630
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    # Given
    def binder(*args) -> Try:
        return Try(args, True)

    # When
    result = Try.of(lambda x: x + 1, 2).bind(binder)

    # Then
    assert result == Try((3,), True)


# Generated at 2022-06-21 19:26:15.227405
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    assert Try(1, True).on_fail(lambda _: print('fail')) == Try(1, True)
    assert Try(1, False).on_fail(lambda _: print('fail')) == Try(1, False)


# Generated at 2022-06-21 19:26:18.437328
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    try_one = Try(1, True)
    assert str(try_one) == 'Try[value=1, is_success=True]'

    try_two = Try(2, False)
    assert str(try_two) == 'Try[value=2, is_success=False]'


# Generated at 2022-06-21 19:26:41.076683
# Unit test for method filter of class Try
def test_Try_filter():
    assert(Try.of(lambda : 10).filter(lambda x: x > 5) == Try(10, True))
    assert(Try.of(lambda : 10).filter(lambda x: x > 15) == Try(10, False))
    assert(Try.of(lambda : 10).filter(lambda x: x > 15).get_or_else(0) == 0)



# Generated at 2022-06-21 19:26:46.597229
# Unit test for method __str__ of class Try
def test_Try___str__(): # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'


# Generated at 2022-06-21 19:26:51.325770
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, False) == Try(1, True)
    assert not Try(1, False) == Try(2, False)



# Generated at 2022-06-21 19:26:59.350956
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    plus_one = lambda num: num + 1

    result = Try.of(plus_one, 10)
    assert result == Try(11, True)

    result = Try.of(plus_one, 'foo')
    assert result == Try('foo', False)

    result = Try.of(plus_one, 10).on_fail(lambda e: print('fail'))
    assert result == Try(11, True)

    result = Try.of(plus_one, 'foo').on_fail(lambda e: print('fail'))
    assert result == Try('foo', False)

# Generated at 2022-06-21 19:27:07.496562
# Unit test for method map of class Try
def test_Try_map():
    def add_one(number):
        return number + 1

    assert Try.of(add_one, 2) == Try.of(add_one, 2).map(add_one)

    def add_one_and_raise(number):
        raise Exception('error')

    try:
        assert Try.of(add_one_and_raise, 2) == Try.of(add_one_and_raise, 2).map(add_one)
        assert False
    except Exception as e:
        assert type(e) == type(Try.of(add_one_and_raise, 2).value)


# Generated at 2022-06-21 19:27:09.836239
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    assert Try(1, True).bind(lambda v: Try(v + 1, True)) == Try(2, True)


# Generated at 2022-06-21 19:27:14.702296
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    """
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'\
        and str(Try(1, False)) == 'Try[value=1, is_success=False]'\
        and str(Try('1', True)) == 'Try[value=1, is_success=True]'\
        and str(Try('1', False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:27:17.323670
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(2, True) != Try(1, True)
    assert Try(2, False) != Try(2, True)
    assert Try(1, False) != 2
    assert Try(1, False) != 'foo'


# Generated at 2022-06-21 19:27:22.341624
# Unit test for method filter of class Try
def test_Try_filter():
    assert (Try.of(lambda x: x, 1).filter(lambda x: x == 1) == Try(1, True))
    assert (Try.of(lambda x: x, 2).filter(lambda x: x == 1) == Try(2, False))
    assert (Try.of(lambda x: x / 2, 1).filter(lambda x: x == 0.5) == Try(0.5, True))
    assert (Try.of(lambda x: x / 2, 1).filter(lambda x: x == 0.4) == Try(0.5, False))



# Generated at 2022-06-21 19:27:30.685809
# Unit test for method bind of class Try
def test_Try_bind():
    def f(x: int) -> Try[int]:
        if x == 0:
            return Try(0, False)
        return Try(10/x, True)

    assert Try.of(f, 0).bind(f) == Try(0, False)
    assert Try.of(f, 1).bind(f) == Try(10, True)
    assert Try.of(f, -1).bind(f) == Try(-10, True)
    assert Try.of(f, -1).bind(f).bind(f) == Try(-10, True)


# Generated at 2022-06-21 19:28:05.055079
# Unit test for method on_success of class Try
def test_Try_on_success():
    result = Try.of(lambda x:x, 3).on_success(lambda x: print('Success: ', x))
    assert result.is_success and result.value == 3


# Generated at 2022-06-21 19:28:16.270015
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_ = Try.of(lambda: 1 / 0) \
        .on_fail(lambda err: print(err)) \
        .map(lambda v: v + 1) \
        .on_success(lambda v: print(v))

    assert try_.get_or_else(-1) == -1 \
        and try_.is_success is False \
        and try_.value is not None \
        and isinstance(try_.value, ZeroDivisionError)

    try_ = Try.of(lambda: 1) \
        .on_fail(lambda err: print(err)) \
        .map(lambda v: v + 1) \
        .on_success(lambda v: print(v))

    assert try_.get_or_else(-1) == 2 \
        and try_.is_success is True \
        and try_.value

# Generated at 2022-06-21 19:28:20.829932
# Unit test for method on_success of class Try
def test_Try_on_success():
    result = Try(10, True).on_success(lambda x: x * x)
    expected = Try(10, True)
    assert result == expected

    result = Try(10, False).on_success(lambda x: x * x)
    expected = Try(10, False)
    assert result == expected


# Generated at 2022-06-21 19:28:32.347977
# Unit test for method map of class Try
def test_Try_map():
    def square(n):
        return n ** 2
    def sum_(n):
        return n + 1
    t = Try(42, True)
    t.map(square) == Try(42 ** 2, True)
    t.map(sum_) == Try(43, True)
    t.bind(lambda n: Try(n ** 2, True)) == Try(42 ** 2, True)
    t.bind(lambda n: Try(n + 1, True)) == Try(43, True)
    assert t.map(square).bind(sum_) == Try(square(42) + 1, True)
    assert t.map(sum_).bind(square) == Try(sum_(42) ** 2, True)
    assert t.filter(lambda n: n % 2 == 0) == Try(42, True)
    assert t.filter

# Generated at 2022-06-21 19:28:35.774803
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(abs, -1).filter(lambda x: x > 0) == Try(1, True)
    assert Try.of(abs, -1).filter(lambda x: x > 1) == Try(1, False)

# Generated at 2022-06-21 19:28:37.878295
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-21 19:28:44.167097
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try.

    :returns: True if unit test is successfully.
    :rtype: Boolean
    """
    try_value = Try(1, True)
    assert try_value.get_or_else(5) == 1
    try_value = Try(1, False)
    assert try_value.get_or_else(5) == 5

# Generated at 2022-06-21 19:28:55.705804
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        raise Exception('Fail')
    except Exception as exception:
        Try.of(lambda: None) \
            .on_fail(lambda error: print(error.__str__())) \
            .on_fail(lambda error: print(error.__str__())) \
            .on_fail(lambda error: print(error.__str__())) \
            .on_fail(lambda error: print(error.__str__()))
        Try.of(lambda: None) \
            .on_fail(lambda error: print(error.__str__())) \
            .on_fail(lambda error: print(error.__str__())) \
            .on_fail(lambda error: print(error.__str__())) \
            .on_fail(lambda error: print(error.__str__()))
       

# Generated at 2022-06-21 19:28:58.453556
# Unit test for method get of class Try
def test_Try_get():
    eq_(Try('2', True).get(), '2')
    eq_(Try('3', False).get(), '3')


# Generated at 2022-06-21 19:29:01.270169
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(42, True)) == 'Try[value=42, is_success=True]'
    assert str(Try(42, False)) == 'Try[value=42, is_success=False]'



# Generated at 2022-06-21 19:30:07.164601
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    try:
        raise Exception('Test exception')
    except Exception as e:
        assert e == Try(e, False).on_fail(lambda _: None).value


# Generated at 2022-06-21 19:30:13.494192
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1).bind(lambda x: Try(x + 1, True)) == Try(2, True)
    assert Try.of(lambda: None).bind(lambda x: Try(x + 1, True)) == Try(None, False)
    assert Try.of(lambda: 1).bind(lambda x: Try(1 / x, True)) == Try(1, True)
    assert Try.of(lambda: 1 / 0).bind(lambda x: Try(x + 1, True)) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-21 19:30:24.788238
# Unit test for method bind of class Try
def test_Try_bind():
    def fail(e):
        print(e)
        return Try("some_error", False)

    def success(value):
        print(value)
        return Try("some_value", True)

    # Try(exception, False).bind(fail) => Try("some_error", False)
    assert Try("some_error", False).bind(fail) == Try("some_error", False)

    # Try("some_value", True).bind(fail) => Try("some_value", True)
    assert Try("some_value", True).bind(success) == Try("some_value", True)

    # Try("some_value", True).bind(fail) => Try("some_error", False)
    assert Try("some_value", True).bind(fail) == Try("some_error", False)



# Generated at 2022-06-21 19:30:34.534565
# Unit test for method on_success of class Try
def test_Try_on_success():
    def print_success(value):
        print('Success value:\t' + str(value))

    def print_fail(value):
        print('Fail value:\t' + str(value))

    def test_success(test_value):
        return Try(test_value, True)

    def test_fail(test_value):
        return Try(test_value, False)

    print('Test Try on_success()')

    test_success(10).on_success(print_success)
    test_fail(20).on_success(print_success)
    print('\n')

    test_success(30).on_fail(print_fail)
    test_fail(40).on_fail(print_fail)
    print('\n')



# Generated at 2022-06-21 19:30:44.059181
# Unit test for constructor of class Try
def test_Try(): # pragma: no cover
    success_Try = Try(1, True)
    assert success_Try == Try(1, True)
    assert success_Try.is_success
    assert success_Try.get() == 1

    fail_Try = Try(1, False)
    assert fail_Try == Try(1, False)
    assert not fail_Try.is_success
    assert fail_Try.get() == 1

    assert Try.of(lambda: 1, None) == Try(1, True)
    assert Try.of(lambda x: x + 1, 1) == Try(2, True)


# Generated at 2022-06-21 19:30:47.589536
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(2, True) == Try(2, True)
    assert Try(2, False) == Try(2, False)
    assert Try(False, True) != Try(2, True)
    assert Try(2, True) != Try(2, False)
    assert Try(2, False) != Try(3, False)
    assert Try(3, True) != Try(2, True)


# Generated at 2022-06-21 19:30:53.342702
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda val: val > 0) == Try(1, True)
    assert Try(1, True).filter(lambda val: val < 0) == Try(1, False)
    assert Try(1, False).filter(lambda val: val > 0) == Try(1, False)

