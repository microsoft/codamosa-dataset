

# Generated at 2022-06-21 19:20:51.510708
# Unit test for method get of class Try
def test_Try_get():
    assert Try(100, True).get() == 100
    assert Try(100, False).get() == 100


# Generated at 2022-06-21 19:20:57.477831
# Unit test for method map of class Try
def test_Try_map():
    result = Try.of(lambda x: 1 / x, 2).map(lambda value_: value_ * 3)
    assert(result == Try(1.5, True))
    result = Try.of(lambda x: 1 / x, 0).map(lambda value_: value_ * 3)
    assert(result == Try(ZeroDivisionError('division by zero'), False))


# Generated at 2022-06-21 19:20:59.956664
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2


# Generated at 2022-06-21 19:21:03.486794
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 5, ()).get_or_else(10) == 5
    assert Try.of(lambda: raise_exception(), ()).get_or_else(10) == 10



# Generated at 2022-06-21 19:21:05.440646
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-21 19:21:08.766205
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(None, False).bind(lambda value: Try(value, True)) == Try(None, False)
    assert Try(None, True).bind(lambda value: Try(value, False)) == Try(None, False)
    assert Try(None, True).bind(lambda value: Try(value, True)) == Try(None, True)
    assert Try(4, True).bind(lambda value: Try(value, False)) == Try(4, False)



# Generated at 2022-06-21 19:21:09.881792
# Unit test for method get of class Try
def test_Try_get():
    result = Try(0, True).get()
    assert result == 0


# Generated at 2022-06-21 19:21:14.523402
# Unit test for method filter of class Try
def test_Try_filter():
    try_test = Try(3, True).filter(lambda x: (x % 2) == 0)
    try_test_other = Try(3, False).filter(lambda x: (x % 2) == 0)

    assert try_test == Try(3, False)
    assert try_test_other == Try(3, False)

# Generated at 2022-06-21 19:21:17.337309
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    assert Try(10, False).get() == 10
    assert Try('example', True).get() == 'example'
    assert Try('example', False).get() == 'example'


# Generated at 2022-06-21 19:21:19.474708
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(True, True)) == 'Try[value=True, is_success=True]'
    assert str(Try('message', False)) == 'Try[value=message, is_success=False]'


# Generated at 2022-06-21 19:21:25.998502
# Unit test for constructor of class Try
def test_Try():
    a = Try(1, True)
    b = Try(Exception('Exception message'), False)
    assert a == Try(1, True)
    assert b == Try(Exception('Exception message'), False)
    assert str(a) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-21 19:21:29.912644
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(None, False).map(lambda x: x + 1) == Try(None, False)


# Generated at 2022-06-21 19:21:36.325367
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda x: Try(x + 1, True)) == Try(2, True)
    assert Try(1, True).bind(lambda x: Try(x / 0, True)) == Try(ZeroDivisionError('division by zero'), False)
    assert Try(1, False).bind(lambda x: Try(x + 1, True)) == Try(1, False)


# Generated at 2022-06-21 19:21:38.603100
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 2, None).get() == 2
    assert Try.of(lambda: 2/0, None).get() == 0


# Generated at 2022-06-21 19:21:46.810520
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(2, True) != Try(1, True)
    assert Try('1', True) != Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(2, False) != Try(1, False)
    assert Try('1', False) != Try(1, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-21 19:21:48.200279
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1).get() == 1



# Generated at 2022-06-21 19:21:51.077958
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('hello_world', True)) == 'Try[value=hello_world, is_success=True]'


# Generated at 2022-06-21 19:21:54.592540
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('value', True)) == 'Try[value=value, is_success=True]'\
        and str(Try(None, False)) == 'Try[value=None, is_success=False]'


# Generated at 2022-06-21 19:21:57.765444
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(None, True).on_fail(lambda _: None) == Try(None, True)
    assert Try(None, False).on_fail(lambda _: None) == Try(None, False)



# Generated at 2022-06-21 19:22:08.536362
# Unit test for method bind of class Try
def test_Try_bind():
    def try_divide(dividend, divisor):
        return Try.of(division, dividend, divisor)

    def division(dividend, divisor):
        if divisor == 0:
            raise ZeroDivisionError('Division by zero!')
        return dividend / divisor

    assert Try.of(division, 1, 2) == Try(0.5, True)
    assert Try.of(division, 1, 0) == Try(ZeroDivisionError('Division by zero!'), False)

    assert try_divide(1, 2) == Try(0.5, True)
    assert try_divide(1, 0) == Try(ZeroDivisionError('Division by zero!'), False)



# Generated at 2022-06-21 19:22:12.547535
# Unit test for method on_success of class Try
def test_Try_on_success():
    def assert_on_success():
        assert True
    Try(1, True).on_success(assert_on_success)

# Generated at 2022-06-21 19:22:17.317209
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda x: x, 1).get_or_else(1) == 1
    assert Try.of(lambda x: x, 1).get_or_else(2) == 1
    assert Try.of(lambda x: 1/0, 1).get_or_else(1) == 1

# Generated at 2022-06-21 19:22:28.644285
# Unit test for method filter of class Try
def test_Try_filter():
    def add_one(value):
        return value + 1

    def add_one_and_return_result_as_Try(value):
        return Try(add_one(value), True)

    def greater_than_one(value):
        return value > 1

    assert Try(0, True).filter(greater_than_one) == Try(0, False)
    assert Try(1, True).filter(greater_than_one) == Try(1, False)
    assert Try(2, True).filter(greater_than_one) == Try(2, True)
    assert Try(0, False).filter(greater_than_one) == Try(0, False)

    assert Try(0, True).bind(add_one_and_return_result_as_Try).filter(greater_than_one) == Try

# Generated at 2022-06-21 19:22:33.521297
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try("success value", True)) == "Try[value=success value, is_success=True]"
    assert str(Try("failure", False)) == "Try[value=failure, is_success=False]"


# Generated at 2022-06-21 19:22:38.680588
# Unit test for constructor of class Try
def test_Try():
    """
    Test case:

    call constructor with different value and state of success.
    """
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)



# Generated at 2022-06-21 19:22:43.557813
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(5, True).get_or_else(6) == 5
    assert Try(5, False).get_or_else(6) == 6


# Generated at 2022-06-21 19:22:48.174417
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    @Try.of
    def safe_div(a, b):
        return a / b

    result = Try\
        .of(safe_div, 10, 2)\
        .on_fail(lambda e: None)

    assert result == Try(5, True)



# Generated at 2022-06-21 19:22:52.136831
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False) == Try(1, False)


# Generated at 2022-06-21 19:23:00.127111
# Unit test for constructor of class Try
def test_Try():
    exceptions = Exception()

    # pass
    assert Try(0, True) == Try(0, True)
    assert Try(1, False) == Try(1, False)
    assert Try(True, True) == Try(True, True)
    assert Try('exceptions', False) == Try('exceptions', False)
    assert Try([0, 1, 2], True) == Try([0, 1, 2], True)
    assert Try(exceptions, False) == Try(exceptions, False)

    # fail
    assert Try(0, True) != Try(True, True)
    assert Try(0, True) != Try(0, False)
    assert Try('s', False) != Try('', False)
    assert Try(0, True) != Try(1, True)
    assert Try([0, 1, 2], True) != Try

# Generated at 2022-06-21 19:23:04.361316
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(ex):
        print('The connection is closed\n', ex)

    Try.of(lambda: 5 / 0, ()).on_fail(fail_callback)
    Try.of(lambda: 5, ()).on_fail(fail_callback)


# Generated at 2022-06-21 19:23:12.022151
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(True, True).filter(lambda x: x) == Try(True, True)
    assert Try(False, True).filter(lambda x: x) == Try(False, False)
    assert Try(True, False).filter(lambda x: x) == Try(True, False)


# Generated at 2022-06-21 19:23:15.365784
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(v):
        assert v == 10
        return True

    ret = Try.of(lambda: None).on_fail(fail_callback)
    assert ret == Try(None, False)


# Generated at 2022-06-21 19:23:18.156831
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x):
        return x > 0

    assert Try(1, True).filter(filterer) == Try(1, True)
    assert Try(-1, True).filter(filterer) == Try(-1, False)

# Generated at 2022-06-21 19:23:27.674398
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def success_case(value):
        print('success case with value: {}'.format(value))
        return Try('{}_success'.format(value), True)

    def fail_case(value):
        print('fail case with value: {}'.format(value))
        return Try('{}_fail'.format(value), False)

    Try.of(success_case, 'test').bind(success_case).bind(success_case).bind(fail_case)

if __name__ == '__main__':  # pragma: no cover
    test_Try_bind()

# Generated at 2022-06-21 19:23:34.212269
# Unit test for method bind of class Try
def test_Try_bind():
    def add_one(num):
        return Try(num + 1, True)
    try_success = Try(1, True)
    try_failure = Try(1, False)

    assert(try_success.bind(add_one) == Try(2, True))
    assert(try_success.bind(lambda x: Try(None, False)) == Try(None, False))
    assert(try_failure.bind(add_one) == Try(1, False))



# Generated at 2022-06-21 19:23:38.822722
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2
    assert Try(Exception(), False).get_or_else(2) == 2


# Generated at 2022-06-21 19:23:46.940737
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 1, None).on_success(lambda value: value + 1)\
                         .get() == 2
    assert Try.of(lambda: 1, None).on_success(lambda value: value + 1)\
                         .is_success
    assert not Try.of(lambda: 1/0, None).on_success(lambda value: value + 1)\
                         .is_success
    assert Try.of(lambda: 1, None).on_success(lambda value: value + 1)\
                         .value == 2


# Generated at 2022-06-21 19:23:50.728558
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    exception = Exception('Test exception')

# Generated at 2022-06-21 19:24:04.017642
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test on_fail method of Try.
    """
    from random import choice, choices
    from random import random
    from random import randrange
    from operator import add, truediv, floordiv, mul, sub

    def monad_value_even(value):
        return value % 2 == 0

    def monad_value_odd(value):
        return value % 2 == 1

    def simple_callback(value):
        return value

    def as_number(value):
        return int(value)

    def as_string(value):
        return str(value)

    def operation(op, arg1, arg2):
        if op == add:
            return arg1 + arg2
        if op == truediv:
            return arg1 / arg2

# Generated at 2022-06-21 19:24:07.727502
# Unit test for constructor of class Try
def test_Try():
    assert Try(2, True) == Try(2, True)
    assert Try(2, True) != Try(3, True)
    assert Try(2, True) != Try(2, False)
    assert Try(2, True) != Try(3, False)


# Generated at 2022-06-21 19:24:14.886903
# Unit test for method get of class Try
def test_Try_get():
    value = 0
    value_try = Try(value, True)
    assert value_try.get() == value, 'Failed get method test.'


if __name__ == '__main__':  # pragma: no cover
    test_Try_get()

# Generated at 2022-06-21 19:24:18.435409
# Unit test for method on_success of class Try
def test_Try_on_success():
    def action(value):
        return value

    assert Try(1, True).on_success(action) == Try(1, True)
    assert Try(1, False).on_success(action) == Try(1, False)



# Generated at 2022-06-21 19:24:22.867703
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1 + 1).get_or_else(0) == 2
    assert Try.of(lambda: 1 + '1').get_or_else(0) == 0
    assert Try.of(lambda: 1 / 0).get_or_else(0) == 0

# Generated at 2022-06-21 19:24:27.789596
# Unit test for method __str__ of class Try
def test_Try___str__():
    success = Try(value=1, is_success=True)
    assert str(success) == 'Try[value=1, is_success=True]'
    not_success = Try(value='error', is_success=False)
    assert str(not_success) == 'Try[value=error, is_success=False]'



# Generated at 2022-06-21 19:24:33.345820
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    t_success = Try.of(lambda: 1)
    t_fail = Try.of(lambda: 1 / 0)
    assert t_success.get_or_else(0) == 1, 'Unit test for method get_or_else of class Try: Incorrect.'
    assert t_fail.get_or_else(0) == 0, 'Unit test for method get_or_else of class Try: Incorrect.'
    print('Unit test for method get_or_else of class Try: OK')


# Generated at 2022-06-21 19:24:39.447136
# Unit test for method map of class Try
def test_Try_map():
    def fn_from_int_to_string(value: int) -> str:
        return str(value)

    try_value = Try(42, True)
    assert Try(fn_from_int_to_string(42), True) == try_value.map(fn_from_int_to_string)

    try_none_value = Try(None, False)
    assert try_none_value == try_none_value.map(fn_from_int_to_string)


# Generated at 2022-06-21 19:24:44.885644
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try(2, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-21 19:24:53.345764
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for Try.filter() method.
    """
    t1 = Try.of(lambda: 1)
    assert t1.filter(lambda z: z == 1) == Try(1, True)

    t2 = Try.of(lambda: 1)
    assert t2.filter(lambda z: z != 1) == Try(1, False)

    t3 = Try.of(lambda: 1)
    assert t3.filter(lambda z: z != 1).map(lambda x: x + 1) == Try(1, False)

# Generated at 2022-06-21 19:24:58.233111
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def success():
        return True

    def fail():
        return False

    def on_success_callback(value):
        return value + 1

    assert Try.of(success).on_success(on_success_callback).get() == True
    assert Try.of(fail).on_success(on_success_callback).get() == False



# Generated at 2022-06-21 19:25:05.323216
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.
    """

    # Positive test, monad is successfully
    def test_filter_positive():
        """
        Positive test, monad is successfully.
        """

        def filterer(value):
            return value > 2

        try_1 = Try.of(lambda: 10)

        assert try_1.filter(filterer) == Try(10, True)

    # Negative test, monad is successfully
    def test_filter_negative():
        """
        Negative test, monad is successfully.
        """

        def filterer(value):
            return value > 2

        try_1 = Try.of(lambda: 1)

        assert try_1.filter(filterer) == Try(1, False)

    # Negative test, monad is not successfully

# Generated at 2022-06-21 19:25:20.631339
# Unit test for method get of class Try
def test_Try_get():
    def pow(x, y):
        return x ** y

    assert Try.of(pow, 2, 3).get() == 8
    assert Try.of(pow, 2, -1).get() == 0.5
    assert Try.of(pow, 'a', 2).get() == '**'
    assert Try.of(pow, 2, '').get() is None
    assert Try.of(pow, 2).get() == 4
    assert Try.of(pow, 2, 3, 4).get() is None
    assert Try.of(pow).get() is None



# Generated at 2022-06-21 19:25:26.810642
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try.
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-21 19:25:33.597104
# Unit test for constructor of class Try
def test_Try():
    def raise_exception(number):  # pragma: no cover
        raise ValueError('Bad number')
    assert Try(1, True) == Try(1, True)
    assert Try('a', True) == Try('a', True)
    assert Try('a', False) == Try('a', False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try.of(lambda x: x, 1) == Try(1, True)
    assert Try.of(lambda x: x, 1) != Try(2, True)
    assert Try.of(lambda x: x, 1) != Try(1, False)
    assert Try.of(raise_exception, 1) == Try(1, False)


# Generated at 2022-06-21 19:25:36.521813
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try('c', False) == Try('c', False)



# Generated at 2022-06-21 19:25:42.515288
# Unit test for method bind of class Try
def test_Try_bind():
    """ bind method """
    some_value = 'try'

    result = Try.of(lambda x: x, some_value)\
        .bind(lambda x: Try.of(lambda y: y, x))\
        .bind(lambda x: Try.of(lambda y: y, x))

    assert result.is_success == True
    assert result.get() == some_value

    on_fail_value = 'on_fail'
    result = Try.of(lambda x: x + x, some_value)\
        .bind(lambda x: Try(on_fail_value, False))

    assert result.is_success == False
    assert result.get() == on_fail_value


# Generated at 2022-06-21 19:25:45.789724
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0


# Generated at 2022-06-21 19:25:50.153807
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1, *[]).bind(lambda i: Try(i + 1, True)) == Try(2, True)
    assert Try.of(lambda: 1, *[]).bind(lambda i: Try.of(lambda: 1 / 0, *[])) == \
        Try.of(lambda: 1 / 0, *[])


# Generated at 2022-06-21 19:25:51.898977
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    assert Try(10, False).get() == 10



# Generated at 2022-06-21 19:25:54.538890
# Unit test for method __str__ of class Try
def test_Try___str__():
    success = Try(10, True)
    failure = Try(ValueError('error'), False)

    assert str(success) == 'Try[value=10, is_success=True]'
    assert str(failure) == ("Try[value=ValueError('error',), "
                            "is_success=False]")


# Generated at 2022-06-21 19:25:59.848849
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # given:
    try_one = Try(divmod, 10, 0)
    try_two = Try(divmod, 10, 2)
    # when:
    result_one = try_one.get_or_else(divmod(10, 2))
    result_two = try_two.get_or_else(divmod(10, 2))
    # then:
    assert result_one == (5, 0)
    assert result_two == (5, 0)



# Generated at 2022-06-21 19:26:21.218407
# Unit test for method map of class Try
def test_Try_map():
    # Given
    def add(x, y):
        return x + y

    fx = lambda x: x ** 2

    t1 = Try.of(add, 2, 5)
    t2 = Try.of(add, 2, '2')

    # When
    r1 = t1.map(fx)
    r2 = t2.map(fx)

    # Then
    assert r1 == Try(49, True)
    assert r2 == Try(4, False)



# Generated at 2022-06-21 19:26:23.825783
# Unit test for constructor of class Try
def test_Try():
    """
    Unit test for constructor of class Try
    """
    # given
    try_instance = Try(100, True)

    # when
    actual = try_instance

    # then
    assert actual == Try(100, True)



# Generated at 2022-06-21 19:26:29.924140
# Unit test for method bind of class Try
def test_Try_bind():

    def throwing_func(arg):
        if (arg == 0):
            raise ValueError('Zero value')
        return arg

    def map_func(arg):
        return arg ** 2

    # successfully
    value = 3
    expected_value = 9

    assert Try.of(throwing_func, value)\
        .bind(lambda x: Try(x ** 2, True)) == Try(expected_value, True)

    # not successfully
    value = 0
    expected_value = ValueError('Zero value')

    assert Try.of(throwing_func, value)\
        .bind(lambda x: Try(x ** 2, True)) == Try(expected_value, False)



# Generated at 2022-06-21 19:26:41.407285
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def test_success_callback(value):
        print(value)

    def test_fail_callback(value):
        print(value)

    def test_mapper(value):
        return value + 1

    def test_filterer(value):
        return value == 2

    try_without_exception = Try.of(lambda: 1, ())
    try_without_exception\
        .map(test_mapper)\
        .filter(test_filterer)\
        .on_success(test_success_callback)\
        .on_fail(test_fail_callback)

    assert try_without_exception.get() == 2

    try_with_exception = Try.of(lambda: 1/0, ())

# Generated at 2022-06-21 19:26:46.597229
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'
    assert str(Try('foo', True)) == 'Try[value=foo, is_success=True]'


# Generated at 2022-06-21 19:26:52.960641
# Unit test for method bind of class Try
def test_Try_bind():
    value = 'Try'
    try_value = Try(value, True)
    def test_fn(value):
        return Try(value, True)
    assert try_value.bind(test_fn) == Try(value, True)

    fn = lambda x: int(x)
    try_value = Try.of(fn, value)
    assert try_value.bind(test_fn) == Try(value, False)



# Generated at 2022-06-21 19:26:56.506491
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda x: x, 1).get_or_else('default') == 1
    assert Try.of(lambda x: x/0, 1).get_or_else('default') == 'default'


# Generated at 2022-06-21 19:27:00.171905
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    a = Try(5, True)
    b = Try(5, True)
    assert a == b


a = Try(5, True)
b = Try(5, False)


# Generated at 2022-06-21 19:27:05.698472
# Unit test for method bind of class Try
def test_Try_bind():
    # Test Successful
    assert Try.of(lambda: 3*2, None).bind(lambda x: Try.of(lambda: x*x, None)) == Try(36, True)
    # Test Fails
    assert Try.of(lambda: 3/0, None).bind(lambda x: Try.of(lambda: x*x, None)) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:27:10.045210
# Unit test for method on_success of class Try
def test_Try_on_success():
    # Given
    value = [1, 2, 3]
    side_effect = []
    # When
    try_value = Try.of(lambda: value)
    try_value.on_success(lambda v: side_effect.append(v))
    # Then
    assert side_effect == [value]


# Generated at 2022-06-21 19:27:32.465434
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(None, True).on_fail(lambda _: "fail") == Try(None, True)
    assert Try(None, False).on_fail(lambda _: "fail") == Try(None, False)
    assert Try(None, False).on_fail(lambda _: "fail").value == "fail"
    assert Try(None, True).on_fail(lambda _: "fail").value == None



# Generated at 2022-06-21 19:27:43.849869
# Unit test for method map of class Try
def test_Try_map():
    """
    Take function and applied this function with monad value and returns new monad with mapped value.

    :params mapper: function to apply on monad value
    :type mapper: Function(A) -> B
    :returns: for successfully new Try with mapped value, othercase copy of self
    :rtype: Try[B]
    """
    # given
    x = 3
    y = 2
    sum_function = sum
    function_with_exception = lambda x, y: x / y

    # when
    sum_try = Try.of(sum_function, x, y)
    other = Try.of(function_with_exception, x, y).map(sum_function)

    # then
    assert sum_try.get() == 5
    assert sum_try.is_success
    assert other.get()

# Generated at 2022-06-21 19:27:45.931057
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try_function = lambda: 1/0
    result = Try.of(try_function).on_fail(lambda x: print(x))
    assert result == Try(ZeroDivisionError(), False)



# Generated at 2022-06-21 19:27:48.097418
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    assert Try(ValueError('test'), False).get() == ValueError('test')


# Generated at 2022-06-21 19:27:53.469302
# Unit test for constructor of class Try
def test_Try():
    value = 93
    assert Try(value, True) == Try(value, True)
    assert Try.of(lambda: 10) == Try(10, True)
    assert Try(90, False) == Try(90, False)
    assert Try.of(lambda x: 1 / x, 0) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:27:56.751936
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    Try.of(lambda x: 1 / 0, 1)\
        .on_fail(lambda x: print('fail'))



# Generated at 2022-06-21 19:28:00.195414
# Unit test for method on_success of class Try
def test_Try_on_success():
    monad = Try.of(lambda: 1)

    assert monad.on_success(lambda x: x + 2) == Try(1, True)



# Generated at 2022-06-21 19:28:06.616879
# Unit test for method map of class Try
def test_Try_map():
    def f(x):
        return x ** 2

    # when given successful Try
    assert Try(10, True).map(f) == Try(100, True)
    assert Try(10, True).map(f).get() == 100

    # when given unsuccessful Try
    assert Try(10, False).map(f) == Try(10, False)
    assert Try(10, False).map(f).get() == 10

test_Try_map()


# Generated at 2022-06-21 19:28:09.093527
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test for method map of class Try
    """
    def binder(val):
        return Try(val.capitalize(), True)
    fn = lambda name: name.strip()
    name = '    vasia    '
    try_ = Try.of(fn, name)
    assert try_.map(lambda name: name.capitalize()) == Try.of(fn, name).bind(binder)



# Generated at 2022-06-21 19:28:16.485077
# Unit test for method bind of class Try
def test_Try_bind():
    def create_try(value) -> Try:
        return Try(value, True)

    def div_by_zero(x):
        return x / 0

    def add(x, y):
        return x + y

    assert create_try(1).bind(lambda x: Try(div_by_zero(x), True)) == Try(ZeroDivisionError(), False)
    assert create_try(1).bind(lambda x: create_try(add(x, 1))) == create_try(2)

# Generated at 2022-06-21 19:28:55.919094
# Unit test for method on_success of class Try
def test_Try_on_success():
    def on_success(x):
        assert x == 2

    def on_fail(e):
        assert False

    assert Try(1, True).on_success(on_success).is_success
    assert Try(1, True).on_success(on_fail).is_success
    assert not Try(1, False).on_success(on_fail).is_success



# Generated at 2022-06-21 19:28:58.651141
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x)) == Try(1, True)


# Generated at 2022-06-21 19:29:03.006151
# Unit test for method map of class Try
def test_Try_map():
    assert Try(2, True).map(lambda x: x * 2) == Try(4, True)
    assert Try(2, True).map(lambda x: x * 2) != Try(4, False)
    assert Try(None, True).map(lambda x: 'Apples' if x is None else x) == Try('Apples', True)
    assert Try(Exception, False).map(lambda x: 'Apples' if x is None else x) == Try(Exception, False)



# Generated at 2022-06-21 19:29:09.477072
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(value):
        return value % 2 == 0
    try_1 = Try.of(lambda: 2, None)
    try_2 = Try.of(lambda: 3, None)
    assert try_1.filter(filterer) == Try(2, True)
    assert try_2.filter(filterer) == Try(3, False)


# Generated at 2022-06-21 19:29:14.644565
# Unit test for method map of class Try
def test_Try_map():
    assert Try(17, True).map(lambda x: x + 10) == Try(27, True)
    assert Try(17, False).map(lambda x: x + 10) == Try(17, False)
    assert Try(True, True).map(lambda x: not x) == Try(False, True)
    assert Try(True, False).map(lambda x: not x) == Try(True, False)



# Generated at 2022-06-21 19:29:15.919238
# Unit test for method get of class Try
def test_Try_get():
    value = 1
    assert Try.of(lambda: value, ).get() == value

# Generated at 2022-06-21 19:29:17.040254
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(7, True) == Try(7, True)



# Generated at 2022-06-21 19:29:23.291801
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(divmod, 2, 0).filter(lambda _: True) == Try(0, False)
    assert Try.of(divmod, 2, 1).filter(lambda _: True) == Try(divmod(2, 1), True)
    assert Try.of(divmod, 2, 1).filter(lambda _: False) == Try(divmod(2, 1), False)
    assert Try.of(divmod, 2, 1).filter(lambda _: _[1] == 1) == Try(divmod(2, 1), True)
    assert Try.of(divmod, 2, 1).filter(lambda _: _[1] == 0) == Try(divmod(2, 1), False)


# Generated at 2022-06-21 19:29:26.584208
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:29:30.066072
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    @check try-catch
    >>> try_monad = Try(5, True)
    >>> str(try_monad)
    'Try[value=5, is_success=True]'
    """


# Generated at 2022-06-21 19:30:06.943878
# Unit test for constructor of class Try
def test_Try():
    t1 = Try(1, True)
    t2 = Try(None, False)

    assert t1 == t1
    assert t1 != t2


# Generated at 2022-06-21 19:30:14.022867
# Unit test for method map of class Try
def test_Try_map():
    # create successfully Try
    value = 'value'
    try_a = Try(value, True)
    # create not successfully Try
    try_b = Try(value, False)
    # create function for testing
    def mapper(x):
        return x * 2
    # call map method
    value_a = try_a.map(mapper)
    value_b = try_b.map(mapper)
    # check result
    assert value_a.get() == value * 2
    assert value_a.is_success
    assert value_b.get() == value
    assert not value_b.is_success


# Generated at 2022-06-21 19:30:17.488585
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 10).on_success(lambda x: print(x)) == Try(10, True)



# Generated at 2022-06-21 19:30:22.194572
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def test_true():
        assert True

    def test_false():
        assert False

    assert Try.of(lambda: [1, 2]).on_success(test_true).is_success

    assert not Try.of(lambda: [1, 2]).on_success(test_false).is_success



# Generated at 2022-06-21 19:30:23.523893
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5


# Generated at 2022-06-21 19:30:25.942450
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def test_f():
        x = 1/0
    p = Try.of(test_f)
    assert p.get_or_else('2') == '2'


# Generated at 2022-06-21 19:30:34.534783
# Unit test for method on_success of class Try
def test_Try_on_success():
    def mock_function(value):
        mock_function.data.append(value)

    def test_on_success(value):
        mock_function.data = []
        Try(value, True).on_success(mock_function)
        assert mock_function.data == [value]
        mock_function.data = []
        Try(value, False).on_success(mock_function)
        assert mock_function.data == []

    test_on_success(100)
    test_on_success('100')
    test_on_success(True)
    test_on_success(Try(100, False))


# Generated at 2022-06-21 19:30:39.599748
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda x: x + 1, 1).get_or_else(0) == 2
    assert Try.of(lambda x: 1 / 0, 1).get_or_else(0) == 0


# Generated at 2022-06-21 19:30:45.432709
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'


# Generated at 2022-06-21 19:30:53.293322
# Unit test for method filter of class Try
def test_Try_filter():
    def is_valid(value):
        return value % 2 == 0

    assert Try(2, True).filter(is_valid) == Try(2, True)
    assert Try(3, True).filter(is_valid) == Try(3, False)
    assert Try(3, False).filter(is_valid) == Try(3, False)

