

# Generated at 2022-06-21 19:20:55.806856
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try(1, True).__str__() == 'Try[value=1, is_success=True]'
    assert Try(1, False).__str__() == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:20:59.253684
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2



# Generated at 2022-06-21 19:21:09.807432
# Unit test for constructor of class Try
def test_Try():
    try_success = Try('10', True)
    assert try_success.is_success == True
    assert try_success.get() == '10'
    assert try_success.get_or_else(None) == '10'

    try_not_success = Try('10', False)
    assert try_not_success.is_success == False
    assert try_not_success.get() == '10'
    assert try_not_success.get_or_else(None) == None

    try_not_success_with_default_value = Try('10', False)
    assert try_not_success_with_default_value.is_success == False
    assert try_not_success_with_default_value.get() == '10'

# Generated at 2022-06-21 19:21:10.868013
# Unit test for constructor of class Try
def test_Try():
    pass


# Generated at 2022-06-21 19:21:17.088009
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 1).on_success(lambda x: x + 1) == Try(1, True), 'failure in on_success Try'
    assert Try.of(lambda: 1 / 0).on_success(lambda x: x + 1) == Try(ZeroDivisionError(), False),\
        'failure in on_success Try'



# Generated at 2022-06-21 19:21:22.826883
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    def get_hello():
        return 'Hello'
    t = Try.of(get_hello)
    assert 'Hello' == t.get_or_else('Bye')

    def get_error():
        raise Exception('Error')
    t = Try.of(get_error)
    assert 'Bye' == t.get_or_else('Bye')


# Generated at 2022-06-21 19:21:25.639600
# Unit test for constructor of class Try
def test_Try():
    try_test = Try(5, True)

    assert try_test.value == 5
    assert try_test.is_success == True


# Generated at 2022-06-21 19:21:29.663256
# Unit test for method __str__ of class Try
def test_Try___str__():
    t = Try(lambda x: 1, False)
    assert str(t) == 'Try[value=<function <lambda> at 0x7ffaf57caf28>, is_success=False]'



# Generated at 2022-06-21 19:21:34.034279
# Unit test for method on_success of class Try
def test_Try_on_success():
    def some_function(arg):
        return arg + 1

    assert Try(1, True).on_success(some_function).is_success
    assert not Try(1, False).on_success(some_function).is_success


# Generated at 2022-06-21 19:21:38.364921
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(0, True).filter(lambda v: v == 0) == Try(0, True)
    assert Try(0, False).filter(lambda v: v == 0) == Try(0, False)
    assert Try(1, True).filter(lambda v: v == 0) == Try(1, False)


# Generated at 2022-06-21 19:21:47.362357
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def test_func(x):
        return x % 2 == 0
    assert Try(1, True).filter(test_func) == Try(1, False)
    assert Try(2, True).filter(test_func) == Try(2, True)
    assert Try(Exception('Oops'), False).filter(test_func) == Try(Exception('Oops'), False)


# Generated at 2022-06-21 19:21:54.695453
# Unit test for method on_success of class Try
def test_Try_on_success():
    mock_function = MagicMock(return_value=None)

    mock_function.side_effect = lambda x: x
    assert Try(1, True).on_success(mock_function) == Try(1, True)
    mock_function.assert_called_once_with(1)

    mock_function.reset_mock()
    assert Try(2, False).on_success(mock_function) == Try(2, False)
    mock_function.assert_not_called()


# Generated at 2022-06-21 19:22:04.871240
# Unit test for method map of class Try
def test_Try_map():
    # When Call Try.of with function that don't throw exception,
    # and applied on this Try.map with function that don't throw exception.
    # Then function is successfully, so returned Try is successfully.
    assert Try.of(lambda x: x + 1, 1)\
        .map(lambda x: x + 1) == Try(3, True)

    # When Call Try.of with function that don't throw exception,
    # and applied on this Try.map with function that throw exception.
    # Then function is not successfully, so returned Try is not successfully.
    assert Try.of(lambda x: x + 1, 1)\
        .map(lambda x: 1 / 0) == Try(ZeroDivisionError(), False)

    # When Call Try.of with function that throw exception,
    # and applied on this Try.map with function that don't throw exception

# Generated at 2022-06-21 19:22:17.593075
# Unit test for method filter of class Try
def test_Try_filter():
    value_to_test = 0

    # Create Try[Int] monad
    Try(1, True)\
        # Call method filter with lambda which returns False when argument is equal 0,
        # in othercase returns True

# Generated at 2022-06-21 19:22:28.317701
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Call method filter of class Try.

    :returns: None
    """

    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 != 0

    # successfully Try with even number
    assert Try(4, True).filter(is_even) == Try(4, True)

    # unsuccessfully Try with even number
    assert Try(4, True).filter(is_odd) == Try(4, False)

    # unsuccessfully Try with odd number
    assert Try(3, True).filter(is_even) == Try(3, False)

    # unsuccessfully Try with odd number
    assert Try(3, True).filter(is_odd) == Try(3, True)

# Generated at 2022-06-21 19:22:39.850665
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Define unit test of the Try class's method on_success.
    """
    def c(a):
        if not a:
            return True
        return False

    def t1():
        """
        Call on_success when  new Try instance is successfully.
        """
        a = Try(1, True)

# Generated at 2022-06-21 19:22:47.512344
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def print_error(e):
        print("Error: {0}".format(e))

    def div(x, y):
        return x / y

    Try(div, 4, 2).on_fail(print_error)

    # Should print error: division by zero
    Try(div, 4, 0).on_fail(print_error)


# Generated at 2022-06-21 19:22:50.700093
# Unit test for method get of class Try
def test_Try_get():
    def f():
        return 1
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try.of(f).get() == 1



# Generated at 2022-06-21 19:22:55.404618
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    u1 = Try(1, True)
    u2 = Try(1, True)
    u3 = Try(2, False)
    u4 = Try(1, False)

    assert u1 == u2
    assert not u1 == u3
    assert not u2 == u3
    assert not u1 == u4
    assert not u2 == u4
    assert not u3 == u4


# Generated at 2022-06-21 19:22:59.886573
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)

    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-21 19:23:09.881709
# Unit test for method get of class Try
def test_Try_get():
    try_success = Try('success', True)
    try_fail = Try('fail', False)

    assert try_success.get() == 'success'
    assert try_fail.get() == 'fail'
    assertTry('get', Try('success', True), 'success')
    assertTry('get', Try('fail', False), 'fail')



# Generated at 2022-06-21 19:23:19.360570
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # successfully
    assert Try(1, True) == Try(1, True)
    assert Try('success', True) == Try('success', True)
    assert Try(lambda x: x ** power, True) == Try(lambda x: x ** power, True)
    # not successfully
    assert Try(1, False) == Try(1, False)
    assert Try('fail', False) == Try('fail', False)
    assert Try(lambda x: x ** power, False) == Try(lambda x: x ** power, False)
    # different
    assert Try(1, True) != Try(1, False)
    assert Try('success', True) != Try('success', False)
    assert Try(lambda x: x ** power, True) != Try(lambda x: x ** power, False)



# Generated at 2022-06-21 19:23:23.404470
# Unit test for constructor of class Try
def test_Try():
    try_: Try = Try(42, True)
    assert Try(42, True) == try_

    try_: Try = Try(42, False)
    assert Try(42, False) == try_



# Generated at 2022-06-21 19:23:30.235095
# Unit test for method map of class Try
def test_Try_map():
    def test_func(x):
        return x * 10

    assert Try.of(test_func, 1).map(test_func) == Try(100, True)
    assert Try.of(test_func, 1).map(test_func).map(test_func) == Try(1000, True)
    assert Try.of(test_func, 1).map(test_func).map(test_func).map(test_func) == Try(10000, True)



# Generated at 2022-06-21 19:23:33.995240
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'



# Generated at 2022-06-21 19:23:42.683783
# Unit test for method __eq__ of class Try
def test_Try___eq__():

    # !!! Everything is OK !!!
    assert Try(1, True) == Try(1, True)

    # !!! NOT OK - different is_success attributes !!!
    assert Try(1, False) != Try(1, True)

    # !!! NOT OK - different values !!!
    assert Try(2, True) != Try(1, True)

    # !!! NOT OK - different is_success and values !!!
    assert Try(2, False) != Try(1, True)



# Generated at 2022-06-21 19:23:44.934810
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_function(value):
        assert value == 1
    assert Try(1, True).on_success(success_function) == Try(1, True)

# Generated at 2022-06-21 19:23:46.595799
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: '42').get() == '42'



# Generated at 2022-06-21 19:23:51.074451
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    value = object()
    try_one = Try(value, True)
    assert try_one == Try(value, True)
    assert try_one != Try(object(), True)
    assert try_one != Try(value, False)
    assert try_one != 12


# Generated at 2022-06-21 19:24:04.117889
# Unit test for method filter of class Try
def test_Try_filter():
    try_success = Try(1, True)
    try_not_success = Try(1, False)
    try_not_success_2 = Try(0, False)

    true_filterer = lambda x: True
    false_filterer = lambda x: False

    assert try_success.filter(true_filterer) == try_success
    assert try_success.filter(false_filterer) == Try(1, False)
    assert try_not_success == try_not_success.filter(true_filterer)
    assert try_not_success == try_not_success.filter(false_filterer)
    assert try_not_success_2 == try_not_success_2.filter(true_filterer)
    assert try_not_success_2 == try_not_success_2.filter

# Generated at 2022-06-21 19:24:18.795881
# Unit test for method filter of class Try
def test_Try_filter():
    # given
    def is_even(n):
        return n % 2 == 0

    # when
    try_even = Try.of(lambda: 2)
    try_odd = Try.of(lambda: 3)

    # then
    try_even.filter(is_even) == Try(2, True)
    try_even.filter(lambda n: not is_even(n)) == Try(2, False)
    try_odd.filter(is_even) == Try(3, False)
    try_odd.filter(lambda n: not is_even(n)) == Try(3, True)


# Generated at 2022-06-21 19:24:22.118842
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(100, True).get_or_else(200) == 100
    assert Try(100, False).get_or_else(200) == 200


# Generated at 2022-06-21 19:24:30.414037
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def fn(value):
        return value + 2

    try_success = Try.of(fn, 1)
    assert try_success.get() == 3

    try_fail = Try.of(fn, '1')
    assert try_fail.get() == TypeError

    result = '0'
    try_fail.on_success(lambda value: result.__add__(str(value)))
    assert result == '0'

    result = '0'
    try_success.on_success(lambda value: result.__add__(str(value)))
    assert result == '03'



# Generated at 2022-06-21 19:24:34.017946
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(42, True) == Success(42)
    assert Try(Exception('Booom!'), False) == Failure(Exception('Booom!'))
    assert Try(42, True) == Try(42, True)
    assert Try(Exception('Booom!'), False) == Try(Exception('Booom!'), False)



# Generated at 2022-06-21 19:24:40.332692
# Unit test for method bind of class Try
def test_Try_bind():
    # Given
    def method_that_raise_error():
        raise AssertionError

    def mapper(x):
        return x

    @Try.of  # noqa
    def method():
        return 10

    # When
    try_ = Try.of(method_that_raise_error)
    try_2 = method()

    try_3 = try_2.bind(mapper)

    # Then
    assert Try(method_that_raise_error, False) == try_
    assert Try(10, True) == try_2
    assert Try(10, True) == try_3


# Generated at 2022-06-21 19:24:41.388904
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 10, ).get() == 10



# Generated at 2022-06-21 19:24:49.924081
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Test Try__eq__ method of class Try
    """
    try1 = Try(None, 1)
    try2 = Try(None, 1)
    try3 = Try(None, 0)
    try4 = Try('', 1)
    assert try1 == try2, "First and second tries should be equal."
    assert try1 != try3, "First and third tries should not be equal."
    assert try1 != try4, "First and fourth tries should not be equal."


# Generated at 2022-06-21 19:24:53.734245
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    # testing on_success case
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    # testing on_fail case
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-21 19:24:56.871854
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(int, '10').get_or_else(1) == 10
    assert Try.of(int, 'N/A').get_or_else(1) == 1

# Generated at 2022-06-21 19:25:08.554147
# Unit test for method bind of class Try
def test_Try_bind():
    def _fib(n):
        a, b = 1, 1
        while n:
            a, b = b, a + b
            n -= 1

        return a

    def _fib_try(n: int) -> Try[int]:
        """
        :params n: argument for fib function
        :type n: int
        :returns: Try[int]
        :rtype: Try[int]
        """
        return Try.of(_fib, n)

    assert _fib_try(10).bind(lambda x: Try(x * 2, True)) == Try(165580141, True)
    assert _fib_try(-1).bind(lambda x: Try(x * 2, True)) == Try(ValueError(), False)


# Generated at 2022-06-21 19:25:36.469828
# Unit test for method bind of class Try
def test_Try_bind():
    def div(a, b):
        if b > 0:
            return a / b
        raise ZeroDivisionError()

    def round_to_string(a):
        return str(round(a))

    result_monad = Try.of(div, 6, 2).bind(lambda a: Try.of(round_to_string, a))
    assert result_monad == Try(result_monad.value, True)

    result_monad = Try.of(div, 6, 0).bind(lambda a: Try.of(round_to_string, a))
    assert result_monad == Try(result_monad.value, False)



# Generated at 2022-06-21 19:25:42.649995
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(123, True)
    try_2 = Try('ABC', False)
    try_3 = Try(123, True)
    try_4 = Try('ABC', False)

    assert try_1 == try_3
    assert try_2 == try_4
    assert not (try_1 == try_2)
    assert not (try_3 == try_4)


# Generated at 2022-06-21 19:25:51.870180
# Unit test for method map of class Try
def test_Try_map():
    assert isinstance(Try.of(lambda x: x**2, 2), Try)
    assert Try.of(lambda x: x**2, 3) == Try(9, True)
    assert Try.of(lambda x: x**2, 3).map(lambda x: x + 1) == Try(10, True)
    assert Try.of(lambda x: x**2, 3).map(lambda x: x + 1).map(lambda x: x**2) == Try(100, True)
    assert isinstance(Try.of(lambda x: 1 / x, 3), Try)
    assert Try.of(lambda x: 1 / x, 3) == Try(0.3333333333333333, True)
    assert Try.of(lambda x: 1 / x, 0) == Try(ZeroDivisionError('division by zero'), False)
    assert Try

# Generated at 2022-06-21 19:25:55.469481
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception('BAD'), False)) == 'Try[value=BAD, is_success=False]'


# Generated at 2022-06-21 19:26:00.273785
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    # Test case [input, expected_result]
    test_cases = [
        [Try(1, True), True],
        [Try(1, False), False],
        [Try(2, True), False],
    ]

    def filterer(value):
        return value == 1
    for input, expected_result in test_cases:
        result = input.filter(filterer)
        assert result.is_success == expected_result

# Generated at 2022-06-21 19:26:05.081199
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(a):
        return a > 5
    success = Try(10, True)
    not_successful = Try(1, False)
    assert success.filter(filterer) == Try(10, True)
    assert not_successful.filter(filterer) == Try(1, False)
    print('test_Try_filter - OK!')


# Generated at 2022-06-21 19:26:08.370629
# Unit test for method get of class Try
def test_Try_get():
    def f():
        return 1
    try_result = Try.of(f)
    assert try_result.get() == 1

# Generated at 2022-06-21 19:26:14.481887
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 10 + 1, None).get_or_else(0) == 11
    assert Try.of(lambda: 10/0, None).get_or_else(0) == 0
    assert Try.of(lambda: 10/1, None).get_or_else(0) == 10


# Generated at 2022-06-21 19:26:18.596504
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(10, True) == Try(10, True)
    assert Try(10, True) != Try(10, False)
    assert Try(10, True) != Try(5, True)
    assert Try(10, True) != Try(5, False)


# Generated at 2022-06-21 19:26:26.193201
# Unit test for method map of class Try
def test_Try_map():
    # Test case when mapped value is not successfully
    value1 = Try(1, True)
    mapped_value1 = value1.map(lambda v: v / 0)
    assert type(mapped_value1) == Try
    assert mapped_value1.is_success == False
    assert isinstance(mapped_value1.get(), ZeroDivisionError)

    # Test case when mapped value is successfully
    value2 = Try(1, True)
    mapped_value2 = value2.map(lambda v: v * 2)
    assert type(mapped_value2) == Try
    assert mapped_value2.is_success == True
    assert mapped_value2.get() == 2


# Generated at 2022-06-21 19:27:09.208929
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(e):
        is_not_exception = not isinstance(e, Exception)
        assert is_not_exception
    Try.of(int, '1').on_fail(fail_callback)
    ex = Exception('fail')
    Try(ex, False).on_fail(fail_callback)
    Try('success', True).on_fail(fail_callback)
    Try('success', False).on_fail(fail_callback)


# Generated at 2022-06-21 19:27:13.369366
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try.of(int, '1') == Try.of(int, '1')
    assert Try.of(int, '1') != Try.of(int, '2')
    assert Try(1, True) != Try(1, False)
    assert Try.of(int, '1') != Try(1, False)


# Generated at 2022-06-21 19:27:17.720316
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try("v", True)) == 'Try[value=v, is_success=True]'
    assert str(Try("v", False)) == 'Try[value=v, is_success=False]'


# Generated at 2022-06-21 19:27:21.928349
# Unit test for constructor of class Try
def test_Try():
    assert Try(2, True).value == 2 and Try(2, True).is_success == True
    assert Try(2, False).value == 2 and Try(2, False).is_success == False
    assert Try(2, True) == Try(2, True)
    assert Try(2, False) == Try(2, False)
    assert Try(2, True) != Try(2, False)
    assert Try(2, False) != Try(2, True)

# Generated at 2022-06-21 19:27:27.787885
# Unit test for method map of class Try
def test_Try_map():
    """
    Simple test for Try class map method.

    :returns:
    """

    def square(x):
        return x * x

    assert Try.of(square, 2).map(square) == Try(16, 1)
    assert Try.of(lambda: 1 / 0).map(square).is_success == 0


# Generated at 2022-06-21 19:27:32.010536
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    test Try.get_or_else method with not successfully Try
    """
    try_object = Try(Exception, False)

    assert try_object.get_or_else('foobar') == 'foobar'

if __name__ == '__main__':  # pragma: no cover
    test_Try_get_or_else()

# Generated at 2022-06-21 19:27:42.803109
# Unit test for method filter of class Try
def test_Try_filter():
    # Test simple scenario, when value is greater than 10
    test_case = Try.of(lambda a, b: a+b, 2, 8)
    assert test_case.filter(lambda x: x > 10) == Try(10, True)

    # Test when value is less than 10 so filter return not successfully Try
    test_case = Try.of(lambda a, b: a + b, 2, 8)
    assert test_case.filter(lambda x: x < 10) == Try(10, False)

    # Test when binder raise exception, it will return not successfully Try
    test_case = Try.of(lambda a, b: a + b, 2, 8)
    assert test_case.filter(lambda x: x / 0) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-21 19:27:44.361988
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(None, False).get() is None


# Generated at 2022-06-21 19:27:52.068840
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value < 10

    try_value = Try(5, True)
    assert try_value.filter(filterer) == Try(5, True)

    try_value = Try(50, True)
    assert try_value.filter(filterer) == Try(50, False)

    try_value = Try(Exception(), False)
    assert try_value.filter(filterer) == Try(Exception(), False)

# Generated at 2022-06-21 19:27:54.689676
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0



# Generated at 2022-06-21 19:29:14.796164
# Unit test for constructor of class Try
def test_Try():
    try_empty = Try(1, True)
    try_error = Try(ValueError('value error'), False)
    assert try_empty == Try(1, True)
    assert try_error == Try(ValueError('value error'), False)


# Generated at 2022-06-21 19:29:20.510389
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def f():
        pass

    assert Try(1, True) == Try(1, True)
    assert Try(f, True) == Try(f, True)
    assert Try(Exception(), False) == Try(Exception(), False)
    assert Try(1, True) != Try("1", True)
    assert Try(f, True) != Try("f", True)
    assert Try("2", True) != Try(2, True)
    assert Try(Exception("1"), False) != Try(Exception("2"), False)



# Generated at 2022-06-21 19:29:23.906031
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    value = Try(2, True).get_or_else(3)
    assert value == 2

    value = Try(2, False).get_or_else(3)
    assert value == 3



# Generated at 2022-06-21 19:29:32.690985
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda x: x, 1).filter(lambda x: x == 2) == Try(1, False)
    assert Try.of(lambda x: x / 0, 1).filter(lambda x: x == 1) == Try(ZeroDivisionError, False)
    assert Try.of(lambda x: x * 0, 1).filter(lambda x: x == 0) == Try(0, True)
    assert Try.of(lambda x: x * 0, 1).filter(lambda x: x == 1) == Try(0, False)


# Generated at 2022-06-21 19:29:41.818492
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def success_mapper(arg):
        return Try(arg, True)

    def fail_mapper(arg):
        return Try(arg, False)

    assert Try(3, True).bind(success_mapper) == Try(3, True)
    assert Try(3, True).bind(fail_mapper) == Try(3, False)
    assert Try(3, False).bind(success_mapper) == Try(3, False)
    assert Try(3, False).bind(fail_mapper) == Try(3, False)



# Generated at 2022-06-21 19:29:53.638709
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v > 0) == Try(1, True)
    assert Try(1, True).filter(lambda v: v < 0) == Try(1, False)
    assert Try(-1, True).filter(lambda v: v < 0) == Try(-1, True)
    assert Try(-1, True).filter(lambda v: v > 0) == Try(-1, False)
    assert Try(1, False).filter(lambda v: v > 0) == Try(1, False)
    # Unit test for function of class Try
    assert Try.of(lambda x: x + 1, 1) == Try(2, True)
    assert Try.of(lambda x: x / 0, 1) == Try(ZeroDivisionError(), False)
    # Unit test for method map of class Try

# Generated at 2022-06-21 19:30:03.965960
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Unit test for Try method bind.

    :returns:
    """
    print('Try.bind -> ')

    def some_func(a):
        return a
    def another_func(b):
        return Try(b, False)

    a = Try.of(some_func, 1)
    b = Try.of(another_func, 1)
    assert a.bind(lambda a: Try(a + 1, True)) == Try(2, True)
    assert a.bind(lambda a: Try(a + 1, False)) == Try(2, False)
    assert (a == b) is False
    assert a.bind(lambda a: b) == Try(1, False)
    assert a.bind(lambda a: Try(a + 1, False)).bind(lambda b: Try(b + 1, True))

# Generated at 2022-06-21 19:30:06.568465
# Unit test for method on_fail of class Try

# Generated at 2022-06-21 19:30:10.439000
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert True == Try(1, True).on_fail(lambda _: False).on_fail(lambda _: True).is_success
    assert False == Try(1, False).on_fail(lambda _: False).on_fail(lambda _: True).is_success


# Generated at 2022-06-21 19:30:17.395461
# Unit test for method bind of class Try
def test_Try_bind():
    bind_fn = lambda x: Try(x * 2, True)
    # Successfully case
    value = Try(3, True).bind(bind_fn)
    assert value.value == 6
    assert value.is_success

    # Not successfully case
    value = Try(3, False).bind(bind_fn)
    assert value.value == 3
    assert value.is_success is False

