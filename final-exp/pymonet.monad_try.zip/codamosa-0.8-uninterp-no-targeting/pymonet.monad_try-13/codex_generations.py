

# Generated at 2022-06-21 19:20:48.928888
# Unit test for method filter of class Try
def test_Try_filter():
    def predicate(v):
        return v == 1
    assert Try.of(lambda: 1).filter(predicate) == Try(1, True)
    assert Try.of(lambda: 2).filter(predicate) == Try(2, False)



# Generated at 2022-06-21 19:20:54.912767
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True).is_success
    assert Try(1, False).is_success is False
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-21 19:21:03.071078
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, True) == Try(None, True)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)

    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)

    assert Try(None, True) == Try(None, True)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)

    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)



# Generated at 2022-06-21 19:21:07.095391
# Unit test for method get of class Try
def test_Try_get():
    assert Try(None, True).get() is None
    assert Try(1, True).get() == 1
    assert Try("a", True).get() == "a"
    assert Try("b", False).get() == "b"  # pragma: no cover



# Generated at 2022-06-21 19:21:12.118511
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(2, True)
    got = str(try_)
    expected = 'Try[value=2, is_success=True]'
    assert expected == got, got

    try_ = Try('e', False)
    got = str(try_)
    expected = "Try[value='e', is_success=False]"
    assert expected == got, got



# Generated at 2022-06-21 19:21:16.480996
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_of_42 = Try.of(lambda: 42)
    try_of_fail = Try.of(lambda: 1/0)
    assert try_of_42.get_or_else(1) == 42
    assert try_of_fail.get_or_else(1) == 1



# Generated at 2022-06-21 19:21:27.103544
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Method Try.bind tests
    """

    # Test for successfully case
    value = Try.of(
        lambda x: 2+x, 2
    )\
    .bind(
        lambda x: Try.of(
            lambda y: x+y, 2
        )
    )\
    .get()
    assert value == 6, 'Incorrect successfully bind'

    # Test for not successfully case
    value = Try.of(
        lambda x: 2+x, 'a'
    )\
    .bind(
        lambda x: Try.of(
            lambda y: x+y, 2
        )
    )\
    .get()
    assert value != 6, 'Incorrect not successfully bind'



# Generated at 2022-06-21 19:21:34.779246
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(int, 1).get() == 1
    assert Try.of(int, 1).filter(lambda i: i > 0) == Try.of(int, 1)
    assert Try.of(int, 1).filter(lambda i: i < 0) == Try.of(int, 1)
    assert Try.of(int, '1').filter(lambda i: i > 0) == Try('1', False)
    assert Try.of(int, '1').filter(lambda i: i < 0) == Try('1', False)



# Generated at 2022-06-21 19:21:38.433844
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    t = Try(1, True).map(lambda a: a + 1)
    assert t == Try(2, True)
    t = Try(1, False).map(lambda a: a + 1)
    assert t == Try(1, False)



# Generated at 2022-06-21 19:21:46.257192
# Unit test for method bind of class Try
def test_Try_bind():
    print('test for method bind of class Try')

    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    def test_Case(n):
        return (Try(n, True)\
                .bind(double)\
                .bind(triple)\
                .get()) == (n * 6)

    assert test_Case(2) == True, "Error in function test_Case(2)"



# Generated at 2022-06-21 19:21:52.054052
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:21:54.848472
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try('test', True).get_or_else('default') == 'test'
    assert Try('test', False).get_or_else('default') == 'default'

# Generated at 2022-06-21 19:21:56.311772
# Unit test for constructor of class Try
def test_Try():
    assert Try(5, True) == Try(5, True)


# Generated at 2022-06-21 19:22:03.581776
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test Try class filter method.
    """
    def even(x):
        return x % 2 == 0

    def odd(x):
        return x % 2 != 0

    assert Try(1, True).filter(even).is_success == False
    assert Try(1, True).filter(odd).is_success == True
    assert Try(2, True).filter(even).is_success == True
    assert Try(2, True).filter(odd).is_success == False



# Generated at 2022-06-21 19:22:10.693408
# Unit test for method filter of class Try
def test_Try_filter():
    try_value = Try(1, True)
    not_try_value = Try(1, False)
    def filterer(value):
        return value == 1
    assert try_value.filter(filterer) == Try(1, True)
    assert not_try_value.filter(filterer) == Try(1, False)

# Generated at 2022-06-21 19:22:16.465594
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    t = Try.of(lambda x: x + 1, 'hoge')
    assert isinstance(t.on_fail(lambda x: None), Try)
    assert t.on_fail(lambda x: None).is_success
    assert not Try.of(lambda x: 1/0, 1).on_fail(lambda x: None).is_success


# Generated at 2022-06-21 19:22:26.686698
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """Unit test for method get_or_else of class Try."""
    class ExceptionMock(Exception):
        pass

    assert Try.of(lambda x: x, None).get_or_else(None) is None
    assert Try.of(lambda x: x, 'abc').get_or_else('') == 'abc'
    assert Try.of(lambda x: x / 0, 0).get_or_else('') == ''
    assert Try.of(lambda x: x, ExceptionMock()).get_or_else(None) == ExceptionMock()

if __name__ == '__main__':
    test_Try_get_or_else()

# Generated at 2022-06-21 19:22:29.282561
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:22:31.709067
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x < 0) == Try(5, False)
    assert Try(5, True).filter(lambda x: x >= 0) == Try(5, True)
    assert Try(5, False).filter(lambda x: x >= 0) == Try(5, False)

# Generated at 2022-06-21 19:22:36.339906
# Unit test for constructor of class Try
def test_Try():
    assert Try(10, True) == Try(10, True)
    assert Try(10, False) == Try(10, False)
    assert Try(10, True) != Try(10, False)
    assert Try(10, False) != Try(11, False)


# Generated at 2022-06-21 19:22:52.873327
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 10, None)\
        .bind(lambda a: Try(a + 1, True))\
        .bind(lambda b: Try(b * 2, True))\
        .bind(lambda c: Try(c + 2, True))\
        == Try(24, True)

    assert Try.of(lambda: 10, None)\
        .bind(lambda a: Try(a + 1, True))\
        .bind(lambda b: Try(b * 2, True))\
        .bind(lambda c: Try(10 / 0, True))\
        == Try(ZeroDivisionError(), False)

    assert Try.of(lambda: 10 / 0, None)\
        .bind(lambda a: Try(a + 1, True))\
        .bind(lambda b: Try(b * 2, True))\
       

# Generated at 2022-06-21 19:22:57.102855
# Unit test for method map of class Try
def test_Try_map():
    def f(x):
        return x**2

    try_monad_success = Try(1, True)
    try_monad_failure = Try(1, False)

    assert try_monad_success.map(f) == Try(f(1), True)
    assert try_monad_failure.map(f) == Try(1, False)



# Generated at 2022-06-21 19:23:00.566844
# Unit test for method __str__ of class Try
def test_Try___str__():
    # setup
    example_value = 100500
    example_is_success = True

    # target
    result = Try(example_value, example_is_success)

    # expect
    expected = 'Try[value={}, is_success={}]'.format(example_value, example_is_success)

    # assert
    assert str(result) == expected



# Generated at 2022-06-21 19:23:07.354813
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    t1 = Try.of(lambda x: x, 'abc')
    assert t1.get_or_else('d') == 'abc'

    t2 = Try.of(lambda x: x, None)
    assert t2.get_or_else('d') == 'd'

    t3 = Try.of(lambda x: x / 0, 3)
    assert t3.get_or_else('d') == 'd'

# Generated at 2022-06-21 19:23:14.109857
# Unit test for constructor of class Try
def test_Try():
    value = None
    assert Try(value, True) == Try(value, True)
    assert Try(value, False) == Try(value, False)
    assert Try(value, True) != Try(value, False)
    assert Try(value, False) != Try(value, True)
    assert Try(value, True) == Try(value, True)
    assert str(Try(value, True)) == 'Try[value=None, is_success=True]'


# Generated at 2022-06-21 19:23:20.305555
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_handler(value):
        pass

    def fail_handler(value):
        pass

    try_success = Try(123, True)
    try_success.on_success(success_handler)
    try_success.on_fail(fail_handler)
    assert try_success.value == 123
    assert try_success.is_success is True

    try_fail = Try(ValueError('value error'), False)
    try_fail.on_success(success_handler)
    try_fail.on_fail(fail_handler)
    assert try_fail.value == ValueError('value error')
    assert try_fail.is_success is False


# Generated at 2022-06-21 19:23:25.104104
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)


# Generated at 2022-06-21 19:23:30.115905
# Unit test for method __str__ of class Try
def test_Try___str__():
    some_value = 42
    for value in (some_value, None):
        for is_success in (True, False):
            try_value = Try(value, is_success)
            assert str(try_value) == 'Try[value={}, is_success={}]'.format(value, is_success)


# Generated at 2022-06-21 19:23:33.910533
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_fail_callback(exception):
        assert exception.args[0] == 'Test exception'

    _ = Try.of(lambda: 1/0, )\
        .on_fail(test_fail_callback)


# Generated at 2022-06-21 19:23:37.196312
# Unit test for method on_success of class Try
def test_Try_on_success():
    def foo(x): return x + 1

    assert Try(3, True).on_success(foo) == Try(4, True)


# Generated at 2022-06-21 19:23:45.977838
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, False)


# Generated at 2022-06-21 19:23:48.298167
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    result = Try(1, True) == Try(1, True)
    assert result is True


# Generated at 2022-06-21 19:23:51.074276
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else(0) == 42
    assert Try('value', False).get_or_else('default') == 'default'


# Generated at 2022-06-21 19:23:55.353182
# Unit test for constructor of class Try
def test_Try():
    value = 10
    try_value = Try(value, True)
    assert try_value.value == value
    assert try_value.is_success


# Generated at 2022-06-21 19:23:58.712980
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == "Try[value=5, is_success=True]"
    assert str(Try(5, False)) == "Try[value=5, is_success=False]"


# Generated at 2022-06-21 19:24:05.630622
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Return monad value when is successfully.
    Othercase return default_value argument.

    :params default_value: value to return when monad is not successfully.
    :type default_value: B
    :returns: monad value
    :rtype: A | B
    """
    assert Try('a', True).get_or_else('b') == 'a'
    assert Try('a', False).get_or_else('b') == 'b'


# Generated at 2022-06-21 19:24:08.310300
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2
# end


# Generated at 2022-06-21 19:24:12.451541
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def f():
        return 2/0

    assert Try.of(f).get_or_else(1) == 1
    assert Try.of(lambda: 2).get_or_else(1) == 2


# Generated at 2022-06-21 19:24:23.313090
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    from src.types.functional.match import match

    def add(a):
        return a + 1

    def add_default(a):
        return a

    def add_error():
        raise Exception()

    assert Try.of(add, 10) == Try(11, True)
    assert Try.of(add, 10).map(add) == Try(12, True)
    assert Try.of(add, 10).map(add).map(add) == Try(13, True)

    assert Try.of(add, 10) == Try(11, True)
    assert Try.of(add, 10).bind(lambda a: Try(add(a), True)) == Try(12, True)

# Generated at 2022-06-21 19:24:33.568323
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(None, True).get_or_else(None) is None
    assert Try(None, True).get_or_else(0) == 0
    assert Try(None, True).get_or_else(1) == 1
    assert Try(None, False).get_or_else(None) is None
    assert Try('Hello', True).get_or_else(None) == 'Hello'
    assert Try('Hello', True).get_or_else(1) == 'Hello'
    assert Try('Hello', False).get_or_else(None) is None
    assert Try('Hello', False).get_or_else('World') == 'World'
test_Try_get_or_else()



# Generated at 2022-06-21 19:24:48.364599
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(False, False) == Try(False, False)
    assert Try(None, True) != Try(False, False)
    assert Try('abc', True) == Try('abc', True)
    assert Try(1, False) == Try(1, False)


# Generated at 2022-06-21 19:24:58.377600
# Unit test for method bind of class Try
def test_Try_bind():
    def _test_simple_func():
        return 'simple call'

    def _test_raise_exception():
        raise Exception('Raising exception')

    def _test_mapper_success_case(value):
        return 'mapped value = {}'.format(value)

    def _test_mapper_fail_case(value):
        return 'mapped value = {}'.format(value)

    def _test_binder_success_case(value):
        return Try(value, True)

    def _test_binder_fail_case(value):
        return Try(value, False)

    # test 1
    assert Try.of(_test_simple_func).bind(_test_binder_success_case) == Try('simple call', True)
    # test 2

# Generated at 2022-06-21 19:25:00.942957
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 1 + 1).get() == 2
    with pytest.raises(TypeError):
        assert Try.of(lambda: 1 + '1').get() == 2



# Generated at 2022-06-21 19:25:06.359275
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    @Try.of
    def divide_by_zero():
        return 1 / 0

    def on_fail_callback(value):
        print(value)
        assert isinstance(value, ZeroDivisionError)

    divide_by_zero.on_fail(on_fail_callback)


# Generated at 2022-06-21 19:25:11.910307
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(int, '123').map(len) == Try(3, True)
    assert Try.of(lambda a: a, 'test').map(lambda a: a.upper()).map(len) == Try(4, True)
    assert Try.of(int, 'a').map(len) == Try('a', False)


# Generated at 2022-06-21 19:25:22.187906
# Unit test for method bind of class Try
def test_Try_bind():
    def div(x, y):
        if y == 0:
            raise ValueError('Division by zero')
        return x / y

    assert Try.of(
        div,
        2,
        2
    ).bind(
        lambda z: Try.of(
            lambda a: a * a,
            z
        )
    ) == Try(4, True)

    assert Try.of(
        div,
        2,
        0
    ).bind(
        lambda z: Try.of(
            lambda a: a * a,
            z
        )
    ) == Try(ValueError('Division by zero'), False)


# Generated at 2022-06-21 19:25:23.898874
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x: x, 10).get() == 10


# Generated at 2022-06-21 19:25:32.205199
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        print('Executed when succefully. Value: {}'.format(value))

    def fail_callback(value):
        print('Executed when not succefully. Value: {}'.format(value))

    success_try = Try(123, True)
    not_success_try = Try('error', False)

    assert id(success_try.on_success(success_callback)) == id(success_try)
    assert id(success_try.on_fail(fail_callback)) == id(success_try)
    assert id(not_success_try.on_success(success_callback)) == id(not_success_try)
    assert id(not_success_try.on_fail(fail_callback)) == id(not_success_try)



# Generated at 2022-06-21 19:25:37.133271
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(5, True)
    try_2 = Try(5, True)
    try_3 = Try(5, False)
    assert try_1 == try_2
    assert try_1 != try_3


# Generated at 2022-06-21 19:25:39.330425
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(None, True).get_or_else(None) is None
    assert Try(None, False).get_or_else(None) is None
    assert Try(None, False).get_or_else(None) == None


# Generated at 2022-06-21 19:25:51.945831
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try.of(lambda: 's', 's') == Try('s', True)
    assert Try.of(lambda: 's', 's').get() == 's'



# Generated at 2022-06-21 19:25:57.499045
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) != Try(2, True)
    assert Try("A", True) != Try("B", False)
    assert Try("", True) == Try("", True)



# Generated at 2022-06-21 19:26:03.966160
# Unit test for method map of class Try
def test_Try_map():
    """
    :test:
    >>> Try.of(lambda: 1+2*2).map(lambda x: x+1)
    Try[value=7, is_success=True]

    >>> Try.of(lambda: 1+2/0).map(lambda x: x+1)
    Try[value=ZeroDivisionError('division by zero',), is_success=False]
    """
    pass

# Generated at 2022-06-21 19:26:10.209429
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try(1, True).filter(lambda _: _ == 1).get() == 1
    assert Try(1, True).filter(lambda _: _ != 1).get() == 1


# Generated at 2022-06-21 19:26:15.966104
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Test 1
    assert Try.of(lambda x: x + 1, 2).on_fail(lambda x: x + 1) == Try(3, True)

    # Test 2
    assert Try.of(lambda x: 1 / 0, 2).on_fail(lambda x: x + 1) == Try(4, False)

# Generated at 2022-06-21 19:26:21.998113
# Unit test for method on_fail of class Try
def test_Try_on_fail(): # pragma: no cover
    def callback(e):
        print('Hello exception ' + str(e))

    t = Try.of(lambda: 1 / 0, None)

    assert t == Try(ZeroDivisionError('division by zero'), False)
    assert t.on_fail(callback).get() == ZeroDivisionError('division by zero')

    t = Try.of(lambda: 1 + 1, None)
    assert t == Try(2, True)
    assert t.on_fail(callback).get() == 2


# Generated at 2022-06-21 19:26:25.977278
# Unit test for method get of class Try
def test_Try_get():
    assert Try('abc', True).get() == 'abc'
    assert Try(3, True).get() == 3


# Generated at 2022-06-21 19:26:27.492520
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(2, False).get() == 2


# Generated at 2022-06-21 19:26:34.380804
# Unit test for method map of class Try
def test_Try_map():
    def safe_int(value):
        try:
            return int(value)
        except ValueError:
            return 0

    t1 = Try.of(safe_int, '10')
    t2 = Try.of(safe_int, 'a')

    mapper = lambda x: x + 1
    assert t1.map(mapper) == Try(11, True)
    assert t2.map(mapper) == Try(0, False)


# Generated at 2022-06-21 19:26:37.566822
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0

# Generated at 2022-06-21 19:26:49.605419
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-21 19:26:54.779361
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():                     # pragma: no cover
    assert Try.of(lambda: 1, None) \
        .get_or_else(2) == 1
    assert Try.of(lambda: '', None) \
        .map(lambda x: x + '1') \
        .get_or_else('2') == '1'


# Generated at 2022-06-21 19:26:58.073803
# Unit test for method bind of class Try
def test_Try_bind():
    result = Try(10, True).bind(safe_divide(2))
    assert result == Try(5, True)

    result = Try(10, True).bind(safe_divide(0))
    assert result == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-21 19:27:05.891717
# Unit test for method bind of class Try
def test_Try_bind():
    def fn_with_exception():
        raise Exception('Try test exception')

    def fn_without_exception():
        return 10

    def binder_fn(value):
        return Try('This is message to return', True)

    result = Try.of(fn_with_exception).bind(binder_fn)
    assert result == Try('This is message to return', True)

    result = Try.of(fn_without_exception).bind(binder_fn)
    assert result == Try('This is message to return', True)



# Generated at 2022-06-21 19:27:08.138479
# Unit test for method on_success of class Try
def test_Try_on_success():
    result = Try('success', True)
    result.on_success(lambda res: print(res))
    assert True



# Generated at 2022-06-21 19:27:10.794479
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(int, '1').get_or_else(0) == 1
    assert Try.of(int, 'a').get_or_else(0) == 0


# Generated at 2022-06-21 19:27:17.508916
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def test_exception_handler(value):
        return value + 1

    def test_success(value):
        return value + 1

    def test_not_success(value):
        raise TypeError()

    assert Try.of(test_exception_handler, 1).map(test_success) == Try(2, True)
    assert Try.of(test_exception_handler, 1).map(test_not_success) == Try(1, True)
    assert Try.of(test_not_success, 1).map(test_success) == Try(TypeError(), False)
    assert Try.of(test_not_success, 1).map(test_not_success) == Try(TypeError(), False)
    return True


# Generated at 2022-06-21 19:27:18.677911
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)



# Generated at 2022-06-21 19:27:22.392543
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1, ).filter(lambda x: x == 1).is_success
    assert not Try.of(lambda: 1, ).filter(lambda x: x == 2).is_success

    assert Try.of(lambda: 1, ).filter(lambda x: x == 1).get() == 1
    assert Try.of(lambda: 1, ).filter(lambda x: x == 2).get() == 1


# Generated at 2022-06-21 19:27:28.721282
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda: 1 + 1, 'aaa', 'bbb').get_or_else(None) == 2
    assert Try.of(lambda: 1 + 1, 'aaa', 'bbb').get_or_else(None) != 3
    assert Try.of(lambda: 1 + 1, 1, 'bbb').get_or_else(None) != 3


# Generated at 2022-06-21 19:27:42.006153
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(None, False).get_or_else(0) == 0

test_Try_get_or_else()

# Generated at 2022-06-21 19:27:45.516712
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    eq_(Try(1, True), Try(1, True))
    assert_false(Try(1, True) == Try(1, False))
    assert_false(Try(1, True) == Try(2, True))
    assert_false(Try(1, True) == Try(2, False))



# Generated at 2022-06-21 19:27:47.706109
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert_equal(Try(1, True).on_success(lambda x: assert_equal(x, 1)), Try(1, True))



# Generated at 2022-06-21 19:27:55.609578
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Unit test for method bind of class Try.
    """
    def add(num):
        return Try(num + 1, True)

    def raise_error():
        raise Exception("message")

    try_with_value = Try(1, True)
    try_with_error = Try("msg", False)

    assert Try(2, True) == try_with_value.bind(add)
    assert try_with_value == try_with_value.bind(raise_error)
    assert try_with_error == try_with_error.bind(add)
    assert try_with_error == try_with_error.bind(raise_error)


# Generated at 2022-06-21 19:28:04.174837
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        if value % 2 == 0:
            return True
        else:
            return False
    assert Try(2, True).filter(filterer) == Try(2, True)
    assert Try(5, True).filter(filterer) == Try(5, False)
    assert Try(5, False).filter(filterer) == Try(5, False)
    assert Try(Exception, False).filter(filterer) == Try(Exception, False)



# Generated at 2022-06-21 19:28:08.999050
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda x, y: x + y, 3, 2).map(lambda x: x * 2) == Try(10, True)
    assert Try.of(lambda: 10 / 0).map(lambda x: x * 2) == Try(None, False)


# Generated at 2022-06-21 19:28:14.284094
# Unit test for method bind of class Try
def test_Try_bind():
    def test_binder(value):
        return Try(value * 2, True)

    assert Try(1, True).bind(test_binder) == Try(2, True)
    assert Try("error", False).bind(test_binder) == Try("error", False)


# Generated at 2022-06-21 19:28:17.946945
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def raise_exception():
        raise Exception('test')

# Generated at 2022-06-21 19:28:22.893081
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Given
    value = 2
    # When
    t1 = Try.of(lambda: 1)
    t2 = Try.of(lambda: 1 / 0)
    # Then
    assert t1.get_or_else(value) == 1
    assert t2.get_or_else(value) == value



# Generated at 2022-06-21 19:28:29.196467
# Unit test for method map of class Try
def test_Try_map():
    def add10(x):
        return x + 10

    def divide(x, y):
        return x / y

    assert Try.of(divide, 20, 4).map(add10) == Try(22, True)
    assert Try.of(divide, 20, 0).map(add10) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-21 19:28:41.946896
# Unit test for method get of class Try
def test_Try_get():
    value = 'value'
    assert Try.of(lambda x: x, value).get() == value


# Generated at 2022-06-21 19:28:44.784567
# Unit test for method get of class Try
def test_Try_get():
    success_try = Try("Hello", True)
    failed_try = Try("Hello", False)

    assert success_try.get() == "Hello"
    assert failed_try.get() == "Hello"



# Generated at 2022-06-21 19:28:48.600313
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_eq_try = Try(1, True) == Try(1, True)
    assert try_eq_try == True

    try_eq_bad_try = Try(1, True) == Try("1", True)
    assert try_eq_bad_try == False


# Generated at 2022-06-21 19:28:55.873892
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(Exception('ex'), False) == Try(Exception('ex'), False)
    assert Try(1, True) != Try(1, False)
    assert Try(Exception('ex'), False) != Try(Exception('ex2'), False)
    assert Try(Exception('ex'), False) != Try(Exception('ex'), True)

# Generated at 2022-06-21 19:29:03.506493
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 'foo', ()).get() == 'foo'
    assert Try.of(lambda: 'foo', ()).get_or_else('bar') == 'foo'
    assert Try.of(lambda: 1, ()).get_or_else(2) == 1
    assert Try.of(lambda: {}, ()).get_or_else({'foo': 'bar'}) == {}
    assert Try.of(lambda: [], ()).get_or_else(['foo', 'bar']) == []
    assert Try.of(lambda: 1, ()).get_or_else([]).__class__.__name__ == 'int'
    assert Try.of(lambda: {}, ()).get_or_else({}).__class__.__name__ == 'dict'

# Generated at 2022-06-21 19:29:12.582193
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def divide(a, b):
        return a / b

    def safe_divide(a, b):
        return Try.of(divide, a, b)

    def safe_divide_by_five(a):
        return safe_divide(a, 5)

    # This is test case
    assert safe_divide(5, 2).bind(safe_divide_by_five) == Try(2, True)
    assert safe_divide(5, 0).bind(safe_divide_by_five) == Try(ZeroDivisionError("division by zero"), False)



# Generated at 2022-06-21 19:29:17.617409
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(5, False)) == 'Try[value=5, is_success=False]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'



# Generated at 2022-06-21 19:29:28.552128
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Function test_Try_on_fail for module control.py.

    :returns: True when tests pass
    :rtype: Boolean
    """

    def assert_equals(actual, expected):
        assert expected == actual, '''
        Expected: {}
        Actual: {}
        '''.format(expected, actual)

    t1 = Try.of(lambda x: x / 2, 30)
    t2 = Try.of(lambda x: x / 0, 30)

    def fail_callback(value):
        assert_equals(value.args[0], 'division by zero')

    t2.on_fail(fail_callback)

    assert_equals(t1, Try(15, True))
    assert_equals(t2, Try(ZeroDivisionError('division by zero'), False))

    return True

# Generated at 2022-06-21 19:29:40.974459
# Unit test for method map of class Try
def test_Try_map():
    def f1(x: int) -> int:
        return x + 1
    def f2(x: int) -> str:
        return str(x)
    def f3(x: str) -> int:
        return int(x)
    t1 = Try(1, True)
    t2 = Try(2, False)
    val1 = t1.map(f1).get()
    val2 = t2.map(f1).get()
    assert val1 == 2
    assert val2 == 2
    val1 = t1.map(f2).map(f3).get()
    val2 = t2.map(f2).map(f3).get()
    assert val1 == 1
    assert val2 == 2
    assert t1 == t1.map(lambda x: x)
    assert t2

# Generated at 2022-06-21 19:29:42.350479
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 2, None) == Try(2, True)



# Generated at 2022-06-21 19:30:06.437098
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value

    try_success = Try(10, True)
    try_fail = Try(10, False)

    assert try_success.filter(filterer) == Try(10, True)
    assert try_fail.filter(filterer) == Try(10, False)

# Generated at 2022-06-21 19:30:14.689598
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    def get_my_default_value():
        return 40
    def get_my_value():
        return 100
    def get_my_exception():
        raise Exception('Some error!')

    my_default_value = get_my_default_value()
    my_value = get_my_value()
    my_exception = get_my_exception()
    my_try_success = Try(my_value, True)
    my_try_fail = Try(my_default_value, False)
    my_try_exception = Try(my_exception, False)
    assert my_try_success.get() == my_value, 'Value is correct!'
    assert my_try_fail.get() == my_default_value, 'Value is correct!'
    assert my_try_ex

# Generated at 2022-06-21 19:30:18.237869
# Unit test for method get of class Try
def test_Try_get():
    """
    Unit test for method get of class Try
    """
    assert Try(1, True).get() == 1
    assert Try(2, False).get() == 2


# Generated at 2022-06-21 19:30:20.765677
# Unit test for constructor of class Try
def test_Try():
    try1 = Try(1, True)
    try2 = Try(2, False)

    assert try1 != try2


# Generated at 2022-06-21 19:30:25.207812
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Test for monad Try method on_success.

    :returns: None.
    :rtype: None.
    """
    def callback(x):
        assert x == 10
    Try(10, True).on_success(callback)
    assert Try(10, False).on_success(callback) == Try(10, False)



# Generated at 2022-06-21 19:30:27.815571
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(40, True).get_or_else(50) == 40
    assert Try(None, False).get_or_else(50) == 50
    assert Try(None, True).get_or_else(50) == None


# Generated at 2022-06-21 19:30:29.775009
# Unit test for constructor of class Try
def test_Try():
    t = Try(3, True)
    assert 0 == cmp(t, Try(3, True))


# Generated at 2022-06-21 19:30:38.863618
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_func(val: int):
        if val == 5:
            return Try(val, True)
        return Try(val, False)

    assert test_func(5).on_fail(lambda v: v) == Try(5, True)
    assert test_func(5).on_fail(lambda v: v) == 5
    assert test_func(5).on_fail(lambda v: v) == Try(5, True)
    assert test_func(5).on_fail(lambda v: v) != 2



# Generated at 2022-06-21 19:30:45.747694
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Arrange
    value = 0
    try_failing_example = Try.of(lambda: 1 / value, value)
    try_failing_example_copy = Try.of(lambda: 1 / value, value)
    def test_callback(exception):
        nonlocal exception_raised
        exception_raised = True

    # Act
    try_failing_example.on_fail(test_callback)

    # Assert
    assert exception_raised
    assert try_failing_example_copy == try_failing_example

