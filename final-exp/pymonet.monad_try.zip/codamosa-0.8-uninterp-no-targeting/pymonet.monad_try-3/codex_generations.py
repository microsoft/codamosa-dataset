

# Generated at 2022-06-21 19:20:54.760770
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try_success = Try(1, True)
    try_fail = Try(1, False)

    assert try_success.on_fail(lambda x: x) == try_success
    assert try_fail.on_fail(lambda x: x) == try_fail


# Generated at 2022-06-21 19:20:59.145634
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    test_Try_on_success is unit test for method on_success of class Try.
    """
    def _test_callback(value):
        assert value == 1

    Try(1, True).on_success(_test_callback)
    Try(1, False).on_success(_test_callback)


# Generated at 2022-06-21 19:21:08.789453
# Unit test for constructor of class Try
def test_Try():
    assert Try(5, True) == Try(5, True)
    assert Try(5, True) != Try(5, False)
    assert Try(5, True) != Try(3, True)
    assert Try(-7, False) != Try(-7, True)

    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'
    assert str(Try(5, False)) == 'Try[value=5, is_success=False]'
    assert str(Try(-7, True)) == 'Try[value=-7, is_success=True]'
    assert str(Try(-7, False)) == 'Try[value=-7, is_success=False]'



# Generated at 2022-06-21 19:21:15.061235
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # prepare
    failure_monad = Try(Exception('error'), False)
    good_monad = Try(1, True)

    # execute
    failure_monad.on_fail(lambda e: print(e))
    good_monad.on_fail(lambda e: print(e))

    # verify
    assert failure_monad.is_success is False
    assert success_monad.is_success is True
    # example of side effect, print to console
    # TODO: mock print function
# end of unit test



# Generated at 2022-06-21 19:21:21.016131
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(lambda: 4, '')) == 'Try[value=4, is_success=True]', 'The Try does not work well'
    assert str(Try.of(lambda: 4/0, '')) == 'Try[value=ZeroDivisionError(\'division by zero\',), is_success=False]', 'The Try does not work well'


# Generated at 2022-06-21 19:21:24.634735
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 10).get() == 10



# Generated at 2022-06-21 19:21:31.837984
# Unit test for method map of class Try
def test_Try_map():
    """
    Test for method map of class Try.
    """
    def add_10(x):
        return x + 10

    def f(x):
        return Try(x + 1, True)

    assert Try(add_10(1), True) == Try.of(add_10, 1).map(add_10)
    assert Try(2, False) == Try.of(f, 1).map(add_10)


# Generated at 2022-06-21 19:21:39.746265
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit-test for method filter of class Try.

    :returns: True when test passed, False when not passed.
    :rtype: Boolean
    """
    t = Try(lambda x: x, True)
    f = Try(lambda x: x, False)

    return t.filter(lambda x: x(3) == 3) == Try(lambda x: x, True) and\
        t.filter(lambda x: x(3) == 4) == Try(lambda x: x, False) and\
        f.filter(lambda x: x(3) == 3) == Try(lambda x: x, False)

# Generated at 2022-06-21 19:21:51.971191
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(10, True) == Try(10, True)
    assert Try(10, True) == Try(10, True)
    assert Try(10, False) == Try(10, False)
    assert Try(10, True) != Try(10, False)
    assert Try(10, False) != Try(10, True)
    assert Try(10, True) != Try(20, True)
    assert Try(10, False) != Try(20, False)
    assert Try('monad', True) == Try('monad', True)
    assert Try('monad', True) == Try('monad', True)
    assert Try('monad', False) == Try('monad', False)
    assert Try('monad', True) != Try('monad', False)

# Generated at 2022-06-21 19:21:54.743441
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Given
    try_monad = Try(1, True)

    # When

# Generated at 2022-06-21 19:22:03.507675
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try('a', True).get_or_else(0) == 'a'
    assert Try(1, False).get_or_else(0) == 0
    assert Try('a', False).get_or_else(0) == 0


if __name__ == "__main__":  # pragma: no cover
    test_Try_get_or_else()

# Generated at 2022-06-21 19:22:07.747351
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    s = Try(3, True)
    assert s.get_or_else(3) == 3

    s = Try(3, False)
    assert s.get_or_else(3) == 3


# Generated at 2022-06-21 19:22:15.593698
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    print('\n\n----Test for get method of Try----')
    some = Try(1, True)
    print('some')
    print(some)
    print('some.get')
    print(some.get())
    none = Try(Exception(), False)
    print('none')
    print(none)
    print('none.get')
    print(none.get())


# Generated at 2022-06-21 19:22:20.390157
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'\
        and str(Try(5, False)) == 'Try[value=5, is_success=False]'



# Generated at 2022-06-21 19:22:26.102485
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():

    t = Try(lambda x: x + 1, x=1)
    assert t.get_or_else(0) == 2, \
        'get_or_else works incorrectly with successfully monad'

    t = Try(None, False)
    assert t.get_or_else(0) == 0, \
        'get_or_else works incorrectly with not successfully monad'



# Generated at 2022-06-21 19:22:28.500199
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    result = Try(10, True)
    expected = "Try[value=10, is_success=True]"
    assert str(result) == expected



# Generated at 2022-06-21 19:22:31.889815
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(1, True)
    try_1_1 = Try(1, True)
    try_2 = Try(2, True)
    try_3 = Try('z', False)
    try_4 = Try('z', False)

    assert try_1 == try_1_1
    assert not try_1 == try_2
    assert not try_1 == try_3
    assert try_3 == try_4



# Generated at 2022-06-21 19:22:36.148598
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(2, True).on_fail(lambda x: x + 1) == Try(2, True)
    assert Try('exception', False).on_fail(lambda x: x + 1) == Try(2, False)


# Generated at 2022-06-21 19:22:43.819185
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def add(a, b):
        return a + b

    def divide(a, b):
        return a / b

    assert Try(2, True) \
        .bind(lambda value: Try(add(value, 5), True)
              ) \
        .bind(lambda value: Try(divide(value, 3), True)
              ) \
        == Try(2, True).bind(lambda value: Try(add(value, 5), True).bind(lambda value: Try(divide(value, 3), True))
                             )

    assert Try(10, True) \
        .bind(lambda value: Try(divide(value, 0), True)
              ) \
        == Try(10, True).bind(lambda value: Try(divide(value, 0), True))



# Generated at 2022-06-21 19:22:47.565527
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'



# Generated at 2022-06-21 19:22:55.813035
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(e):
        print(e)

    # Call on_fail method with exist exception
    Try(1, False).on_fail(fail_callback)

    # Call on_fail method with not exist exception
    Try(1, True).on_fail(fail_callback)


# Generated at 2022-06-21 19:22:59.679693
# Unit test for method on_success of class Try
def test_Try_on_success():
    # Test case 1
    happy = True
    t = Try.of(lambda: 1 / 0)
    t.on_success(lambda x: happy)
    assert not happy

    # Test case 2
    t = Try.of(lambda x: x ** 2, 5)
    happy = False
    t.on_success(lambda x: happy)
    assert happy


# Generated at 2022-06-21 19:23:01.287077
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0


# Generated at 2022-06-21 19:23:06.777561
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Successful Try
    a = Try("Successful Try!", True)
    assert a.get_or_else("Not successful Try!") == "Successful Try!"

    # Not successful Try
    b = Try("Not successful Try!", False)
    assert b.get_or_else("Not successful Try!") == "Not successful Try!"


# Generated at 2022-06-21 19:23:10.428638
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) != Try(1, True)



# Generated at 2022-06-21 19:23:18.990780
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test get_or_else method of clas Try.
    """
    def get_value() -> int:
        return 1

    def get_exception():
        raise Exception('get_exception exception')

    def get_value_or_zero(value):
        """
        This function use get_or_else method and return value
        when it is successfully.
        Othercase when it's not successfully, return 0.
        """
        return value.get_or_else(0)

    expect(get_value_or_zero(Try.of(get_value))).to_be(1)
    expect(get_value_or_zero(Try.of(get_exception))).to_be(0)

# Generated at 2022-06-21 19:23:22.665509
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(Exception(), False).get_or_else(2) == 2


# Generated at 2022-06-21 19:23:25.221492
# Unit test for method __str__ of class Try
def test_Try___str__(): # pragma: no cover
    assert str(Try(98, True)) == 'Try[value=98, is_success=True]'


# Generated at 2022-06-21 19:23:28.990743
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(None, True).get_or_else(2) == None
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-21 19:23:31.849430
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else(0) == 42
    assert Try(0, False).get_or_else(1) == 1


# Generated at 2022-06-21 19:23:43.896835
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 5, ()).get_or_else(None) == 5
    assert Try.of(lambda: 1 / 0, ()).get_or_else(None) == None


# Generated at 2022-06-21 19:23:53.854303
# Unit test for method map of class Try
def test_Try_map():
    def test_map(fn, *args):
        def mapper(x):
            return x + 1

        try_value = Try.of(fn, *args)
        assert try_value is Try.of(fn, *args)

        mapped_value = Try.of(fn, *args).map(mapper)
        assert isinstance(mapped_value, Try) and mapped_value.is_success == try_value.is_success
        if mapped_value.is_success:
            assert mapped_value.get() == mapper(try_value.get())

    test_map(lambda: 3)
    test_map(lambda *args: 3)
    test_map(lambda *args: args[0], 3)
    test_map(lambda *args: args, 3)

    def raise_exception():
        raise Exception

# Generated at 2022-06-21 19:23:58.384307
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    """
    Test get method of class Try.
    """
    assert Try('string', True).get() == 'string'
    assert Try(Exception(), False).get() == Exception()
    assert Try('string', False).get() == 'string'


# Generated at 2022-06-21 19:24:07.736603
# Unit test for constructor of class Try
def test_Try():
    assert Try(3, True) == Try(3, True)
    assert Try(3, True) != Try(4, False)
    assert Try(3, True) != Try(4, True)
    assert Try(3, False) != Try(4, False)

    assert Try(3, True).map(str) == Try('3', True)
    assert Try(3, True).map(str).map(int) == Try(3, True)
    assert Try(3, False).map(str) == Try(3, False)
    assert Try(3, False).map(str).map(int) == Try(3, False)

    assert Try(3, True).bind(lambda v: Try(v, True)) == Try(3, True)

# Generated at 2022-06-21 19:24:13.080252
# Unit test for method map of class Try
def test_Try_map():
    # Successfully
    try_ = Try(1, True)
    mapper = lambda x: x + 1
    assert try_.map(mapper) == Try(2, True)

    # Not successfully
    try_ = Try(1, False)
    assert try_.map(mapper) == Try(1, False)


# Generated at 2022-06-21 19:24:20.961852
# Unit test for method __str__ of class Try
def test_Try___str__():
    t = Try(4, True)
    assert str(t) == 'Try[value=4, is_success=True]'
    t = Try(4, False)
    assert str(t) == 'Try[value=4, is_success=False]'
    t = Try('value', True)
    assert str(t) == 'Try[value=value, is_success=True]'
    t = Try('value', False)
    assert str(t) == 'Try[value=value, is_success=False]'



# Generated at 2022-06-21 19:24:28.863903
# Unit test for constructor of class Try
def test_Try():
    assert True == Try(True, True).is_success
    assert False == Try(True, False).is_success
    assert False == Try(False, True).is_success
    assert False == Try(False, False).is_success
    assert None == Try(None, True).value
    assert None == Try(None, False).value
    assert True == Try(True, True).get()
    assert False == Try(False, False).get()
    assert 1 == Try(1, True).get()
    assert 'test' == Try('test', True).get()


# Generated at 2022-06-21 19:24:37.167762
# Unit test for method map of class Try
def test_Try_map():
    def add1(x):
        return x + 1

    def add2(x):
        return x + 2

    def remove3(x):
        return x - 3

    assert Try.of(add1, 2).map(remove3) == Try(0, True)
    assert Try.of(add1, 2).map(add2) == Try(5, True)
    assert Try.of(add1, 2).map(remove3).map(add2) == Try(2, True)
    assert Try.of(add1, 2).map(add2).map(remove3) == Try(3, True)
    assert Try(2, True).map(add2).map(remove3) == Try(3, True)
    assert Try(2, False).map(add2).map(remove3) == Try(2, False)

# Generated at 2022-06-21 19:24:39.305923
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda x: x * 2, 4).bind(lambda x: Try.of(lambda y: x + y, 1)) == Try(9, True)



# Generated at 2022-06-21 19:24:41.597000
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_function(value):
        return value + 'world'
    assert_equals(Try.of(test_function, 'Hello ').on_success(print).get(), 'Helloworld')

# Generated at 2022-06-21 19:25:05.520205
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1, ()).get_or_else(2) == 1
    assert Try.of(lambda: 1/0, ()).get_or_else(2) == 2


# Generated at 2022-06-21 19:25:10.722264
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def test_fn(val):
        raise Exception(val)
    def fail_callback(val):
        assert val == 'test_value'
    try_test = Try.of(test_fn, 'test_value')
    try_test.on_fail(fail_callback)


# Generated at 2022-06-21 19:25:13.648737
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda i: i + 2) == Try(3, True)
    assert Try(1, False).map(lambda i: i + 2) == Try(1, False)


# Generated at 2022-06-21 19:25:17.871870
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test for Try.bind method
    """
    def f(x):
        return Try(x*2, True)

    assert Try(1, True).bind(f) == Try(2, True)
    assert Try(1, False).bind(f) == Try(1, False)
    assert Try(None, True).bind(f) == Try(None, True)


# Generated at 2022-06-21 19:25:28.388747
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    def f():
        raise ValueError('test_Try_get')
    def g():
        return 2
    def h(x):
        return x + 2
    def i(x):
        raise ValueError('test_Try_get')
    assert Try(1, True).get() == 1
    assert Try(2, True).get() == 2
    assert Try(1, False).get() == 1
    assert Try(2, False).get() == 2
    assert Try.of(f).get() == ValueError('test_Try_get')
    assert Try.of(g).get() == 2
    assert Try.of(g).bind(h).get() == 4
    assert Try.of(f).bind(h).get() == ValueError('test_Try_get')

# Generated at 2022-06-21 19:25:32.003497
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Given
    some = Try(1, True)
    none = Try(1, False)
    expected = 1

    # When
    result_some = some.get_or_else(2)
    result_none = none.get_or_else(2)

    # Then
    assert expected == result_some
    assert expected == result_none



# Generated at 2022-06-21 19:25:39.546377
# Unit test for constructor of class Try
def test_Try():
    try_success = Try(1, True)
    try_fail = Try('fail', False)
    assert try_success == Try(1, True)
    assert try_fail != Try('fail', False)
    assert str(try_success) == 'Try[value=1, is_success=True]'
    assert str(try_fail) == 'Try[value=fail, is_success=False]'



# Generated at 2022-06-21 19:25:43.712869
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x, y: x+y, 1, 2).get() == 3
    assert Try.of(lambda x, y: x//y, 1, 0).get() == ZeroDivisionError()


# Generated at 2022-06-21 19:25:49.189090
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # __eq__ compare only is_success and value
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try('a', True)
    assert Try(1, True) != Try('a', False)


# Generated at 2022-06-21 19:25:55.591833
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(-1) == 1
    assert Try('1', True).get_or_else(-1) == '1'
    assert Try(None, True).get_or_else(-1) is None
    assert Try(1, False).get_or_else(-1) == -1
    assert Try('1', False).get_or_else(-1) == -1
    assert Try(None, False).get_or_else(-1) == -1


# Generated at 2022-06-21 19:26:21.019937
# Unit test for method get of class Try
def test_Try_get():
    def add(a, b):
        return a + b

    def sub(a, b):
        raise ValueError('test')
        return a - b

    assert Try.of(add, 1, 3).get() == 4
    assert Try.of(sub, 10, 1).get() is ValueError


# Generated at 2022-06-21 19:26:28.476550
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try.
    """
    def f(x): return x+4

    try_1: Try[int] = Try(1, True)
    try_2: Try[int] = Try(Try.of(f, 1).value, Try.of(f, 1).is_success)
    try_3: Try[int] = Try(5, True)
    assert try_1 == try_1
    assert try_1 == try_2
    assert not try_1 == try_3
    assert not try_2 == try_3


# Generated at 2022-06-21 19:26:32.143316
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2



# Generated at 2022-06-21 19:26:35.596662
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try("Hello", True).get_or_else("") == "Hello"
    assert Try("Hello", False).get_or_else("") == ""


# Generated at 2022-06-21 19:26:41.952763
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for filter method of class Try

    :return: True when test finished successfully.
    :rtype: Boolean
    """

    def filterer(value): return value > 3

    assert Try.of(lambda: 2).filter(filterer) == Try(2, False)
    assert Try.of(lambda: 3).filter(filterer) == Try(3, False)
    assert Try.of(lambda: 4).filter(filterer) == Try(4, True)
    return True



# Generated at 2022-06-21 19:26:48.863901
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 1,).filter(lambda x: x == 1) == Try(1, True)
    assert Try.of(lambda: 1,).filter(lambda x: x != 1) == Try(1, False)
    assert Try.of(lambda: 1,).filter(lambda x: x != 1).bind(lambda x: Try(x + 2, False)) == Try(3, False)

# Generated at 2022-06-21 19:26:51.918105
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x: x, 1).get() == 1
    assert Try.of(lambda x: x / 0, 1).get() == "division by zero"


# Generated at 2022-06-21 19:27:00.119121
# Unit test for method map of class Try
def test_Try_map():
    def double(v): return 2 * v
    assert Try.of(double, 2) == Try(4, True)
    assert Try.of(double, '2') == Try('2', False)
    assert Try.of(double, 2).map(str) == Try('4', True)
    assert Try.of(double, '2').map(str) == Try('2', False)
    assert Try.of(double, '2').map(double) == Try('2', False)
    assert Try.of(double, 2) == Try(4, True)


# Generated at 2022-06-21 19:27:04.437042
# Unit test for method map of class Try
def test_Try_map():
    def square(value):
        return value * value

    assert Try.of(square, 2) == Try(4, True)
    assert Try.of(square, 2).map(square) == Try(16, True)

    error = Try(-1, False)
    assert error.map(square) == error


# Generated at 2022-06-21 19:27:07.489301
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 'ok', 10).get_or_else('not ok') == 'ok'
    assert Try.of(lambda: None, 10).get_or_else('not ok') == 'not ok'


# Generated at 2022-06-21 19:27:51.181647
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('v1', True)) == 'Try[value=v1, is_success=True]'
    assert str(Try('v2', False)) == 'Try[value=v2, is_success=False]'
test_Try___str__()


# Generated at 2022-06-21 19:27:53.719261
# Unit test for method __str__ of class Try
def test_Try___str__():
    an_value = 'Test value'
    try_instance = Try(an_value, True)
    assert str(try_instance) == 'Try[value=Test value, is_success=True]'


# Generated at 2022-06-21 19:27:56.574892
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x: x * 2, 3).get() == 6



# Generated at 2022-06-21 19:28:06.165407
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 0).is_success == True
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 1).is_success == False
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 2).is_success == False

    assert Try.of(lambda x: x, 1).filter(lambda x: x > 0).value == 1
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 1).value == 1
    assert Try.of(lambda x: x, 1).filter(lambda x: x > 2).value == 1

# Generated at 2022-06-21 19:28:10.828405
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Unit test for method __str__ of class Try
    """
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try('1', False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:28:13.672239
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(ValueError(), False) == Try(ValueError(), False)



# Generated at 2022-06-21 19:28:17.056857
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(123, True)) == "Try[value=123, is_success=True]"
    assert str(Try("123123", False)) == "Try[value=123123, is_success=False]"


# Generated at 2022-06-21 19:28:20.517110
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('v', True)) == 'Try[value=v, is_success=True]'
    assert str(Try('v', False)) == 'Try[value=v, is_success=False]'


# Generated at 2022-06-21 19:28:30.840868
# Unit test for method map of class Try
def test_Try_map():
    from pymonad.func import compose

    result = Try.of(lambda x, y: x / y, 4, 2).map(lambda x: x**3)
    assert result == Try(8, True)

    # Function compose
    result = Try.of(lambda x, y: x / y, 4, 2)\
                .map(compose(lambda x: x**3, lambda x: x + 1))
    assert result == Try(9, True)

    result = Try.of(lambda x, y: x / y, 4, 0)\
                .map(compose(lambda x: x**3, lambda x: x + 1))
    assert result == Try(ZeroDivisionError(), False)



# Generated at 2022-06-21 19:28:37.887137
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test():
        """
        Call on_success with succeed.

        :returns: True when function executes without errors
        :rtype: Boolean
        """

        @Try.of
        def fn():
            # Call on_success with succeed.
            try:
                return 1
            except:
                return 'error'

        actual_result = fn.on_success(lambda x: x + 1).get()

        # Check if Try with correct value
        assert actual_result == 2

        # when function executes without errors return True
        return True

    assert test()



# Generated at 2022-06-21 19:29:56.464775
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(2, False).get() == 2
    assert Try(3, True).get() != 2

    def another_func():
        raise Exception()

    assert Try.of(another_func).get() is None


# Generated at 2022-06-21 19:30:02.809153
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def fn_is_not_exception():
        return 1

    def fn_is_exception():
        raise Exception('test error')

    assert 1 == Try.of(fn_is_not_exception).get_or_else(2)
    assert 2 == Try.of(fn_is_exception).get_or_else(2)



# Generated at 2022-06-21 19:30:06.477534
# Unit test for method get of class Try
def test_Try_get():
    value = 5
    monad_success = Try(value, True)
    monad_fail = Try(value, False)
    assert monad_success.get() == value
    assert monad_fail.get() == value


# Generated at 2022-06-21 19:30:09.941490
# Unit test for constructor of class Try
def test_Try():
    """
    >>> test_Try()
    Try[value=1, is_success=True]
    Try[value=Exception(), is_success=False]
    """
    print(Try(1, True))
    print(Try(Exception(), False))



# Generated at 2022-06-21 19:30:12.342811
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(10, False)
    assert str(try_) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-21 19:30:14.197993
# Unit test for method get of class Try
def test_Try_get():
    assert Try(5, True).get() == 5



# Generated at 2022-06-21 19:30:17.256962
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('a', True)) == 'Try[value=a, is_success=True]'


# Generated at 2022-06-21 19:30:24.541811
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x):
        return x % 2 == 0

    assert Try(2, True) \
        .filter(filterer) == Try(2, True)
    assert Try(1, True) \
        .filter(filterer) == Try(1, False)
    assert Try(1, False) \
        .filter(filterer) == Try(1, False)
    assert Try(Exception('exception'), False) \
        .filter(filterer) == Try(Exception('exception'), False)


# Generated at 2022-06-21 19:30:26.220599
# Unit test for method get of class Try
def test_Try_get():
    get_result = Try('test_value', True).get()
    assert get_result == 'test_value'


# Generated at 2022-06-21 19:30:29.364791
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(2, True).map(lambda x: x + 1).get() == 3
    assert Try(2, False).map(lambda x: x + 1).get() != 3

test_Try_on_success()

