

# Generated at 2022-06-21 19:20:55.862135
# Unit test for method get of class Try
def test_Try_get():
    # Given
    def f(a: int, b: int) -> int:
        return a + b
    # When
    success_try = Try(f(4, 5), True)
    fail_try = Try("failure", False)
    # Then
    assert success_try.get() == 9
    assert fail_try.get() == "failure"


# Generated at 2022-06-21 19:20:56.561363
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    raise Exception()

# Generated at 2022-06-21 19:21:00.824933
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) == Try(1, False)



# Generated at 2022-06-21 19:21:02.504766
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = 'some value'
    def success_callback(value):
        assert value == 'some value'
    Try(value, True).on_success(success_callback)


# Generated at 2022-06-21 19:21:09.454191
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    :returns: True or False
    :rtype: Boolean
    """
    try:
        return Try(10, True).__eq__(Try(10, True))\
               and not Try(10, True).__eq__(Try(10, False))\
               and not Try(10, False).__eq__(Try(5, False))\
               and not Try(10, False).__eq__(Try(10, True))
    except:
        return False

assert test_Try___eq__()


# Generated at 2022-06-21 19:21:16.974894
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    """
    Test method get_or_else.
    """
    def div_by_zero(a, b):
        return a / b

    print('Test method get_or_else with dividing by zero')
    print('#1 result', Try.of(div_by_zero, 1, 0).get_or_else('Division by zero'))
    print('#2 result', Try.of(div_by_zero, 1, 1).get_or_else(None))
    print('#3 result', Try.of(div_by_zero, 1, 1).get_or_else('Division by zero'))


# Generated at 2022-06-21 19:21:20.304633
# Unit test for method get of class Try
def test_Try_get():
    try_instance = Try(42, True)
    assert try_instance.get() == 42
    assert try_instance.get_or_else(0) == 42

    try_instance = Try(None, False)
    assert try_instance.get_or_else(0) == 0



# Generated at 2022-06-21 19:21:21.909140
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(10, True).get_or_else(20) == 10
    assert Try(None, False).get_or_else(20) == 20


# Generated at 2022-06-21 19:21:25.217745
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(3, True)) == 'Try[value=3, is_success=True]'


# Generated at 2022-06-21 19:21:34.599827
# Unit test for constructor of class Try
def test_Try():
    """
    Test cases:
    1. Constructor is instance of Try
    2. Constructor is successfully return
    3. Constructor not successfully return
    """

    # 1. Constructor is instance of Try
    success_try = Try(5, True)
    assert isinstance(success_try, Try)

    fail_try = Try(5, False)
    assert isinstance(fail_try, Try)

    # 2. Constructor is successfully return
    assert success_try.is_success

    # 3. Constructor not successfully return
    assert not fail_try.is_success



# Generated at 2022-06-21 19:21:39.812704
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    value = 'test'
    t = Try(value, False)

    def assert_fail_callback(assert_value):
        assert assert_value == value

    t.on_fail(assert_fail_callback)



# Generated at 2022-06-21 19:21:47.421085
# Unit test for method bind of class Try
def test_Try_bind():
    # Test for successful monad
    def test_func(value):
        return Try(value, True)
    try_ = Try.of(lambda x: x, 1).bind(test_func)
    assert 1 == try_.get()
    assert True == try_.is_success

    # Test for failure monad
    try_ = Try(1, False).bind(test_func)
    assert 1 == try_.get()
    assert False == try_.is_success


# Generated at 2022-06-21 19:21:51.497712
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: print(x)) == Try(1, True)
    assert Try(1, False).on_success(lambda x: print(x)) == Try(1, False)


# Generated at 2022-06-21 19:21:54.422436
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Success Try with value 'Success'
    success = Try('Success', True)
    # Fail Try with value 'Fail'
    fail = Try('Fail', False)

    assert success.get_or_else('Fail') == 'Success'
    assert fail.get_or_else('Success') == 'Success'


# Generated at 2022-06-21 19:21:59.194789
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(error):
        assert error == 'error'
    def success_callback(error):
        raise AssertionError('No call success_callbak')
    Try('error', False).on_fail(fail_callback).on_success(success_callback)


# Generated at 2022-06-21 19:22:06.138719
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_func(x): return x*2
    def fail_func(x): return x*2

    actual = Try.of(lambda: 10).on_success(success_func)
    assert actual == Try(10, True)

    actual = Try.of(lambda: 10).on_success(fail_func)
    assert actual == Try(10, True)

    actual = Try.of(lambda: 10/0).on_success(success_func)
    assert actual == Try(ZeroDivisionError('division by zero'), False)

    actual = Try.of(lambda: 10/0).on_success(fail_func)
    assert actual == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-21 19:22:12.207309
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(3, True) == Try(3, True)
    assert Try(3, False) == Try(3, False)
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)



# Generated at 2022-06-21 19:22:20.139015
# Unit test for method map of class Try
def test_Try_map():
    def map_fn(x):
        return x + 1

    assert Try.of(lambda: 1).map(map_fn) == Try(2, True)
    assert Try.of(lambda: [1]).map(map_fn) == Try([1], True)
    assert Try.of(lambda: str(1)).map(map_fn) == Try('1', True)
    assert Try.of(lambda: {'a': 1}).map(map_fn) == Try({'a': 1}, True)
    assert Try.of(lambda: 1).map(map_fn).is_success
    assert not Try.of(lambda: None).map(map_fn).is_success
    assert Try.of(lambda: None).map(map_fn) == Try(None, False)


# Generated at 2022-06-21 19:22:22.124069
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-21 19:22:30.225499
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    class MyExc(Exception):
        pass

    assert Try.of(lambda: 1 / 1).on_fail(lambda e: e.args[0] == 'division by zero')

    assert isinstance(Try.of(lambda: 1/0).on_fail(lambda e: e.args[0] == 'division by zero').get(), MyExc)

    assert Try.of(lambda: 1/1).on_fail(lambda e: e.args[0] == 'division by zero').get_or_else(
        'Got exception') == 1

    assert Try.of(lambda: 1/0).on_fail(lambda e: e.args[0] == 'division by zero').get_or_else(
        'Got exception') == 'Got exception'

# Generated at 2022-06-21 19:22:39.971527
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    value = 1
    try_with_value = Try(value, True)
    try_without_value = Try(value, False)
    filterer = lambda x: x > 0

    assert try_with_value.filter(filterer) == Try(value, True)
    assert try_without_value.filter(filterer) == Try(value, False)


# Generated at 2022-06-21 19:22:47.669377
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-21 19:22:50.436734
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert True == Try(10, True).get_or_else(False)
    assert False == Try(10, False).get_or_else(False)


# Generated at 2022-06-21 19:22:53.001383
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test():
        assert Try.of(lambda: 1 + 1).on_success(lambda value: print(value)) == Try(2, True)

    test()


# Generated at 2022-06-21 19:22:55.566402
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-21 19:22:57.679954
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    fail = Try(0, False)
    success = Try(42, True)

    assert fail.get_or_else(42) == success.get_or_else(0)

# Generated at 2022-06-21 19:22:59.886360
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(10, False) == Try(10, False)
    assert not Try(10, True) == Try(10, False)
    assert Try(10, True) == Try(10, True)


# Generated at 2022-06-21 19:23:03.248504
# Unit test for constructor of class Try
def test_Try():
    assert Try('Success', True) == Try('Success', True)
    assert Try('Success', True) != Try('Success', False)
    assert Try('Success', True).is_success is True
    assert Try('Success', False).is_success is False
    assert Try('Success', True).value == 'Success'
    assert Try('Success', False).value == 'Success'



# Generated at 2022-06-21 19:23:07.649405
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert(str(Try(42, True)) == 'Try[value=42, is_success=True]')
    assert(str(Try(42, False)) == 'Try[value=42, is_success=False]')



# Generated at 2022-06-21 19:23:13.963076
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(10, True).on_fail(lambda x: None) == Try(10, True)
    assert Try(None, False).on_fail(lambda x: None) == Try(None, False)
    assert Try(10, True).on_fail(lambda x: x) == Try(10, True)
    assert Try(10, False).on_fail(lambda x: x) == Try(10, False)


# Generated at 2022-06-21 19:23:25.740481
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1 / 0, None).map(lambda _: 2).get_or_else(3) == 3
    assert Try.of(lambda a: a + 2, 5).map(lambda a: a + 2).get_or_else(3) == 9


# Generated at 2022-06-21 19:23:28.053318
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(42, True).on_success(lambda val: val + 2) == Try(42, True)
    assert Try(42, False).on_success(lambda val: val + 2) == Try(42, False)


# Generated at 2022-06-21 19:23:39.746902
# Unit test for method __eq__ of class Try

# Generated at 2022-06-21 19:23:45.959020
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Function test_Try___eq__
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != None


# Generated at 2022-06-21 19:23:54.583482
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try('test', False) == Try('test', False)
    assert Try(1, True) == Try(1, True)
    assert Try(None, True) == Try(None, True)
    #
    assert Try(1, True) != None

    assert Try('test', True) != Try('test', False)
    assert Try(1, False) != Try(1, True)
    assert Try(None, False) != Try(None, True)
    #
    assert Try(1, True) != 1

    assert Try(1, False) != Try('test', False)
    assert Try('test', True) != Try(1, True)
    assert Try(1, True) != Try(None, True)
    #
    assert Try(True, True) != True


# Generated at 2022-06-21 19:23:59.377615
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    try:
        raise ValueError('hello')
    except Exception as e:
        result = Try(e, False)\
            .on_fail(print)
        assert result
        assert result.get() == e
        assert result.is_success == False


# Generated at 2022-06-21 19:24:06.334839
# Unit test for method on_success of class Try
def test_Try_on_success():
    def succ_callback(value):
        assert value == 1
        pass

    def fail_callback(value):
        assert False

    Try.of(lambda: 1, None).on_success(succ_callback)
    Try.of(lambda: 1, None).on_fail(fail_callback)
    Try.of(lambda: 1/0, None).on_fail(succ_callback)
    Try.of(lambda: 1/0, None).on_success(fail_callback)


# Generated at 2022-06-21 19:24:11.135678
# Unit test for constructor of class Try
def test_Try():
    assert Try(2, True) == Try(2, True)
    assert Try(2, False) != Try(2, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-21 19:24:14.197579
# Unit test for method get of class Try
def test_Try_get():
    """
    >>> test_Try_get()
    >>>
    """
    val = 10
    assert Try(val, True).get() == val
    assert Try(val, False).get() == val


# Generated at 2022-06-21 19:24:18.175392
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Given a successful Try
    When call get_or_else method
    Then return value stored in Try
    """
    value = 1
    try_ = Try(value, True)
    assert value == try_.get_or_else(0)



# Generated at 2022-06-21 19:24:33.865541
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        assert value == 4

    def fail_callback(value):
        assert value == Exception('Exception')

    assert Try(4, True).on_success(success_callback).on_fail(fail_callback).get() == 4


# Generated at 2022-06-21 19:24:40.484200
# Unit test for method on_success of class Try
def test_Try_on_success():
    def f(value):
        return value*2

    def g(value):
        return value*3

    def h(value):
        return value*0

    assert Try(5, True).on_success(f).get() == 10
    assert Try(5, True).on_success(g).get() == 15
    assert Try(5, True).on_success(h).get() == 0

    assert Try(5, False).on_success(f).get() == 5
    assert Try(5, False).on_success(g).get() == 5
    assert Try(5, False).on_success(h).get() == 5



# Generated at 2022-06-21 19:24:52.360856
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    def test_map():  # pragma: no cover
        def fn(x: int) -> int:
            return x
        assert Try.of(fn, 1).map(fn) == Try(1, True)
        assert Try.of(fn, 'a').map(fn) == Try('a', True)
        assert Try.of(fn, []).map(fn) == Try([], True)
        assert Try.of(fn, (1, )).map(fn) == Try((1, ), True)
        assert Try.of(fn, {1: 1}).map(fn) == Try({1: 1}, True)
        assert Try.of(fn, {1}).map(fn) == Try({1}, True)

        def fn_raise():
            raise Exception('123')

# Generated at 2022-06-21 19:25:04.230202
# Unit test for method bind of class Try
def test_Try_bind():
    # Successfully Try with value 3
    v = Try.of(lambda: 3 + 1)
    # Apply on successfully Try method bind.
    # Function argument return Successfully Try with value 5
    vb = v.bind(lambda x: Try.of(lambda: x + 2))
    # Method bind application result is successfully Try with value 5.
    assert vb == Try(5, True)
    # Not successfully Try with value NotImplementedError
    v = Try.of(lambda: 3 + '2')
    # Apply on not successfully Try method bind.
    # Function argument returns not successfully Try with value TypeError.
    vb = v.bind(lambda x: Try.of(lambda: x + 2))
    # Method bind application result is not successfully Try with previous value.
    assert vb == Try(3, False)

# Unit test

# Generated at 2022-06-21 19:25:10.918859
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    def _test(test_value, default_value):
        assert Try(test_value, True).get_or_else(default_value) == test_value
        assert Try(test_value, False).get_or_else(default_value) == default_value

    _test("test_value", "default_value")
    _test(10, 15)
    _test(None, "default_value")


# Generated at 2022-06-21 19:25:15.176446
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda x: 1, 1).on_success(lambda x: print('Some text')) == Try(1, True)
    assert Try.of(lambda x: 1 / 0, 1).on_success(lambda x: print('Some text')) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-21 19:25:26.141563
# Unit test for method on_success of class Try
def test_Try_on_success():
    import unittest

    class TestTry(unittest.TestCase):
        def test_when_test_is_success(self):
            value_to_test = 'some_value'
            result = Try(value_to_test, True)
            is_call = False
            arg_value = None
            def callable_func(val):
                nonlocal is_call, arg_value
                is_call = True
                arg_value = val
            # test
            result.on_success(callable_func)
            self.assertTrue(is_call)
            self.assertEqual(arg_value, value_to_test)

        def test_when_test_is_not_success(self):
            value_to_test = 'some_value'
            result = Try(value_to_test, False)

# Generated at 2022-06-21 19:25:29.801889
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    "Test Try class method __str__"
    assert str(Try(6, True)) == 'Try[value=6, is_success=True]'
    assert str(Try(6, False)) == 'Try[value=6, is_success=False]'


# Generated at 2022-06-21 19:25:33.415220
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'
    assert str(Try(5, False)) == 'Try[value=5, is_success=False]'

# Generated at 2022-06-21 19:25:37.835975
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try(1, True).__str__() == 'Try[value=1, is_success=True]'
    assert Try('Error', False).__str__() == 'Try[value=Error, is_success=False]'


# Generated at 2022-06-21 19:26:04.360024
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(2,True).on_success(lambda x: x+1) == Try(3,True)


# Generated at 2022-06-21 19:26:09.867056
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != '1'
    assert Try(1, True) == Try(1, True)


# Generated at 2022-06-21 19:26:13.521190
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try(Exception(), False).get() is not None



# Generated at 2022-06-21 19:26:21.832440
# Unit test for method on_success of class Try

# Generated at 2022-06-21 19:26:27.531388
# Unit test for method bind of class Try
def test_Try_bind():
    def fn(value):
        if value < 0:
            return Try(value, False)
        return Try(value, True)

    assert Try(4, True).bind(fn).get() == 4
    assert not Try(4, True).bind(fn).is_success
    assert Try(-4, True).bind(fn).get() == -4
    assert not Try(-4, True).bind(fn).is_success
    assert Try(-4, False).bind(fn).get() == -4
    assert not Try(-4, False).bind(fn).is_success

# Generated at 2022-06-21 19:26:31.878082
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try('Error', False) == Try('Error', False)
    assert Try(False, True) != Try(True, True)
    assert Try(True, False) != Try(True, True)


# Generated at 2022-06-21 19:26:34.605349
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(10, True).get_or_else(5) == 10
    assert Try(None, False).get_or_else(5) == 5


# Generated at 2022-06-21 19:26:40.779355
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(100, True).get_or_else(None) == 100
    assert Try(100, False).get_or_else(None) is None
    assert Try(100, False).get_or_else(-100) == -100
    assert Try(None, False).get_or_else(-100) == -100
    assert Try(None, True).get_or_else(-100) is None

# Generated at 2022-06-21 19:26:43.088605
# Unit test for constructor of class Try
def test_Try():
    res = Try(12, True)
    assert res.value == 12
    assert res.is_success
    assert str(res) == 'Try[value=12, is_success=True]'


# Generated at 2022-06-21 19:26:46.601207
# Unit test for method map of class Try
def test_Try_map():
    """Test successful Try.map() call.
    """
    assert Try.of(lambda a:  a + a, 2) == Try(4, True)



# Generated at 2022-06-21 19:27:46.208530
# Unit test for constructor of class Try
def test_Try():
    # Test for successfully Try
    try_1 = Try("success", True)
    assert str(try_1) == 'Try[value=success, is_success=True]'
    assert try_1 == Try("success", True)
    assert try_1.is_success

    # Test for not successfully Try
    try_2 = Try("fail", False)
    assert str(try_2) == 'Try[value=fail, is_success=False]'
    assert try_2 == Try("fail", False)
    assert not try_2.is_success



# Generated at 2022-06-21 19:27:53.469761
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # setup
    default_value = 'default value'
    called = False

    # exercise
    try_val = Try.of(lambda: 1 / 0)
    try_val = try_val.on_fail(lambda e: None)
    try_val = try_val.on_fail(lambda e: setattr(called, True, True))
    try_val = try_val.on_fail(lambda e: default_value)

    # verify
    assert called

    # tear down



# Generated at 2022-06-21 19:27:56.763605
# Unit test for method on_success of class Try
def test_Try_on_success():
    def action(value):
        assert value == 'action'

    Try.of(lambda: 'action').on_success(action)



# Generated at 2022-06-21 19:28:01.088756
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'\
        and str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:28:08.556404
# Unit test for method bind of class Try
def test_Try_bind():
    def test_function(a, b):
        return a + b

    def test_function_one(test_function):
        return Try.of(test_function, 1, 1)

    def test_function_two(test_function):
        return Try.of(test_function, 1, 0)

    def test_function_three(test_function):
        return Try.of(test_function, 0, 's')

    @test
    def bind_function_return_Try_with_2(value):
        assert value == 2

    for monad_value in [test_function_one(test_function), test_function_two(test_function)]:
        monad_value.bind(bind_function_return_Try_with_2)


# Generated at 2022-06-21 19:28:13.466819
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try
    """
    assert Try(42, True).get_or_else(None) == 42
    assert Try("error", False).get_or_else("default") == "default"



# Generated at 2022-06-21 19:28:18.485839
# Unit test for method filter of class Try
def test_Try_filter():
    test_data = [
        (Try(5, True), lambda x: x > 3, True),
        (Try(5, True), lambda x: x > 7, False),
        (Try(5, False), lambda x: x > 3, False)
    ]
    for data in test_data:
        assert data[0].filter(data[1]) == Try(data[0].get(), data[2])

# Generated at 2022-06-21 19:28:24.713076
# Unit test for constructor of class Try
def test_Try():
    result = Try(1, True)
    assert result.value == 1
    assert result.is_success == True

    try:
        raise Exception('test exception')
    except Exception as e:
        result = Try(e, False)
        assert isinstance(result.value, Exception)
        assert result.value.args[0] == 'test exception'
        assert result.is_success == False


# Generated at 2022-06-21 19:28:31.028499
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    import operator

    def divide(x, y):
        return x / y

    def remainder(x, y):
        return x % y

    assert not Try.of(divide, 4, 0).filter(operator.eq(0)).is_success
    assert Try.of(remainder, 4, 2).filter(operator.eq(0)).is_success



# Generated at 2022-06-21 19:28:34.284378
# Unit test for method on_success of class Try
def test_Try_on_success():

    def success_callback(value):
        assert value == 4

    def fail_callback(value):
        assert False

    try_ = Try.of(lambda: 4, 1)
    try_.on_success(success_callback).on_fail(fail_callback)

    try_ = Try.of(lambda: 1/0)
    try_.on_success(success_callback).on_fail(fail_callback)


# Generated at 2022-06-21 19:29:36.756665
# Unit test for method on_success of class Try
def test_Try_on_success():
    try_monad = Try(42, True)


# Generated at 2022-06-21 19:29:42.206903
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Create Try monad. When monad is successfully return inner value of monad,
    othercase return default_value.

    :returns: monad value
    :rtype: A
    """
    assert Try('Hello', True).get_or_else('hi') == 'Hello'
    assert Try('Hello', False).get_or_else('hi') == 'hi'


# Generated at 2022-06-21 19:29:46.279035
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # GIVEN
    default_value = 2
    # WHEN
    value = Try.of(lambda x: x + 1, 1).get_or_else(default_value)
    # THEN
    assert value == 2


# Generated at 2022-06-21 19:29:51.472685
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_success = Try(10, True)
    assert str(try_success) == 'Try[value=10, is_success=True]'

    try_fail = Try(10, False)
    assert str(try_fail) == 'Try[value=10, is_success=False]'


# Generated at 2022-06-21 19:29:53.862565
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    >>> assert Try(1, True).get_or_else(2) == 1
    >>> assert Try(Exception(), False).get_or_else(2) == 2
    """
    pass


# Generated at 2022-06-21 19:29:59.316061
# Unit test for method map of class Try
def test_Try_map():
    a = 1
    t = Try(a, True)
    mapper = lambda a: a + 1
    res = t.map(mapper)
    assert res.value == a + 1
    assert res.is_success is True

    t = Try(a, False)
    res = t.map(mapper)
    assert res.value == a
    assert res.is_success is False


# Generated at 2022-06-21 19:30:03.335468
# Unit test for method bind of class Try
def test_Try_bind():
    def return_Try(value):
        return Try(value, True)
    assert Try(1, True).bind(return_Try) == Try(1, True)
    assert Try(1, False).bind(return_Try) == Try(1, False)


# Generated at 2022-06-21 19:30:13.177428
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Arrange
    try_1 = Try(5, True)
    try_2 = Try(5, True)
    # Act
    result = try_1 == try_2
    # Assert
    assert result == True

    # Arrange
    try_1 = Try(5, True)
    try_2 = Try(4, True)
    # Act
    result = try_1 == try_2
    # Assert
    assert result == False

    # Arrange
    try_1 = Try(5, True)
    try_2 = Try(4, False)
    # Act
    result = try_1 == try_2
    # Assert
    assert result == False

    # Arrange
    try_1 = Try(5, False)
    try_2 = Try(5, False)
    # Act
   

# Generated at 2022-06-21 19:30:19.004312
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try('a', True).get() == 'a'
    assert Try(None, True).get() == None

    assert Try(None, True).get() != 'a'
    assert Try(1, False).get() != 1



# Generated at 2022-06-21 19:30:21.211009
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(42, True)
    assert str(try_) == 'Try[value=42, is_success=True]'

