

# Generated at 2022-06-21 19:20:57.015876
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Test of method __eq__ of class Try

    :returns: True when test passed and False when not passed
    :rtype: Boolean
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    return True


# Generated at 2022-06-21 19:21:00.316897
# Unit test for method get of class Try
def test_Try_get():
    """
    Unit test for method get of class Try
    """
    assert Try(1, True).get() == 1
    assert Try(NotImplementedError(), False).get() == NotImplementedError()
    assert Try('1', True).get() == '1'


# Generated at 2022-06-21 19:21:06.415714
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.

    :returns: status of test
    :rtype: Boolean
    """
    def dummy_function():
        return 1

    def dummy_function_fail():
        1 / 0

    def is_even(number):
        return number % 2 == 0

    def is_negative(number):
        return number < 0

    try_success = Try.of(dummy_function)

    try_success = try_success.filter(is_even)
    if try_success.get() == 1 and not try_success.is_success:
        raise Exception('unit test Try_filter failed on line {}'.format(inspect.currentframe().f_lineno))

    try_success = Try.of(dummy_function)

# Generated at 2022-06-21 19:21:11.874939
# Unit test for method bind of class Try
def test_Try_bind():
    def to_try(a):
        if a is 3:
            return Try(a, True)
        else:
            return Try(a, False)

    assert Try(3, True).bind(to_try) == Try(3, True)
    assert Try(1, True).bind(to_try) == Try(1, False)
    assert Try(2, False).bind(to_try) == Try(2, False)

# Generated at 2022-06-21 19:21:15.525195
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(2, True).on_fail(lambda error: error) == Try(2, True)
    assert Try(2, False).on_fail(lambda error: error) == Try(2, False)


# Generated at 2022-06-21 19:21:22.473160
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    asserteq(
        Try.of(lambda:1).on_fail(lambda e: None),
        Try(1, True)
    )

    asserteq(
        Try.of(lambda:int('a')).on_fail(lambda e: None),
        Try(TypeError("int() argument must be a string, a bytes-like object or a number, not 'a'"), False)
    )

    asserteq(
        Try.of(lambda:int('a')).on_fail(lambda e: 123),
        Try(TypeError("int() argument must be a string, a bytes-like object or a number, not 'a'"), False)
    )



# Generated at 2022-06-21 19:21:27.994442
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1, 2).get_or_else(3) == 3
    assert Try.of(lambda x: x, 2).get_or_else(3) == 2
    assert Try.of(lambda x: x, 2, 3).get_or_else(4) == 4


# Generated at 2022-06-21 19:21:34.948632
# Unit test for constructor of class Try
def test_Try():
    error = Exception()

    # Successful Try
    try_success = Try('value', True)
    assert try_success.value == 'value'
    assert try_success.is_success

    # Not successful Try
    try_fail = Try(error, False)
    assert try_fail.value == error
    assert not try_fail.is_success


# Generated at 2022-06-21 19:21:39.998763
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(
        Try(1, True).filter(lambda value: value > 0), True
    ) == Try(Try(1, True), True)
    assert Try(
        Try(-1, True).filter(lambda value: value > 0), False
    ) == Try(-1, False)
    assert Try(
        Try(None, False).filter(lambda value: value > 0), False
    ) == Try(None, False)


# Generated at 2022-06-21 19:21:52.153717
# Unit test for method bind of class Try
def test_Try_bind():
    """
    When monad is successfully, bind method returns result of function
    applied on monad value.

    :retruns: None
    """
    def mapping_fn(a):
        return a + 1

    def bind_fn(a):
        return Try(a + 1, True)

    @Try.of
    def success_fn(a):
        return a + 1

    assert (Try(1, True).bind(bind_fn) == Try(2, True))
    assert (Try(1, True).bind(mapping_fn) == Try(2, True))

    assert (Try(1, True).map(mapping_fn).bind(bind_fn) == Try(3, True))
    assert (Try(1, True).bind(bind_fn).map(mapping_fn) == Try(3, True))

   

# Generated at 2022-06-21 19:22:00.085808
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, True).map(lambda x: x - 1) == Try(0, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-21 19:22:06.768492
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, False).filter(lambda value: value == 0) == Try(1, False)
    assert Try(1, False).filter(lambda value: value == 1) == Try(1, False)
    assert Try(1, True).filter(lambda value: value == 0) == Try(1, False)
    assert Try(1, True).filter(lambda value: value == 1) == Try(1, True)
    assert Try.of(lambda: 1).filter(lambda value: value == 0) == Try(1, False)
    assert Try.of(lambda: 1).filter(lambda value: value == 1) == Try(1, True)
    assert Try.of(lambda: 1/0).filter(lambda value: True) == Try(1, False)

# Generated at 2022-06-21 19:22:12.375221
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_handler(value):
        assert value == 'Fail'

    try_ = Try(10, True)
    try_.on_fail(fail_handler)

    try_ = Try('Fail', False)
    try_.on_fail(fail_handler)


# Generated at 2022-06-21 19:22:16.769267
# Unit test for method __str__ of class Try
def test_Try___str__():
    t = Try(5, True)
    assert str(t) == 'Try[value=5, is_success=True]'
    t = Try(ValueError(), False)
    assert str(t) == 'Try[value=ValueError(), is_success=False]'



# Generated at 2022-06-21 19:22:28.169980
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def test_case_one():
        assert Try.of(int, "100").get_or_else(200) == 100
        assert Try.of(int, "100a").get_or_else(200) == 200

    def test_case_two():
        assert Try.of(lambda x: x + 1, 1).get_or_else(0) == 2

    def test_case_three():
        assert Try.of(int, "100").map(lambda x: x - 200).get_or_else(0) == -100

    def test_case_four():
        assert Try.of(int, "100a").map(lambda x: x - 200).get_or_else(0) == 0

    test_case_one()
    test_case_two()
    test_case_three()
    test_case

# Generated at 2022-06-21 19:22:31.709052
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(a):
        assert a == 10, 'success_callback value'

    def fail_callback(a):
        assert False, 'fail_callback value'

    Try(10, True).on_success(success_callback).on_fail(fail_callback)
    Try(10, False).on_success(success_callback).on_fail(fail_callback)
test_Try_on_success()


# Generated at 2022-06-21 19:22:36.340742
# Unit test for method get_or_else of class Try
def test_Try_get_or_else(): # pragma: no cover
    """
    Unit test for method get_or_else of class Try
    """
    assert Try(0, True).get_or_else(-1) == 0
    assert Try(0, False).get_or_else(-1) == -1

# Generated at 2022-06-21 19:22:39.523536
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: print(x)) == Try(1, True)
    assert Try(1, False).on_fail(lambda x: print(x)) == Try(1, False)


# Generated at 2022-06-21 19:22:43.765744
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    try_one = Try(1, False)
    try_two = Try(1, False)

    assert try_one == try_two


# Generated at 2022-06-21 19:22:49.298005
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 2) == Try(1, False)


# Generated at 2022-06-21 19:22:56.672806
# Unit test for method get of class Try
def test_Try_get():
    # Given
    obj = Try(1, True)
    # When
    value = obj.get()
    # Then
    assert value == 1


# Generated at 2022-06-21 19:23:03.796377
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, False) == Try(1, True)
    assert not Try(1, True) == Try(2, True)
    assert not Try(2, True) == Try(1, True)
    assert not Try(1, False) == Try(2, False)
    assert not Try(2, False) == Try(1, False)
    assert not Try(1, True) == Try(2, False)
    assert not Try(1, False) == Try(2, True)
    assert Try(Any, True) == Try(Any, True)
    assert Try(Any, False) == Try(Any, False)

# Generated at 2022-06-21 19:23:06.964613
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(2, True).get_or_else(1) == 2
    assert Try(None, False).get_or_else(1) == 1

# Generated at 2022-06-21 19:23:17.393481
# Unit test for method map of class Try
def test_Try_map():
    """
    1. When trying call function by Try.of and function return 1, then Try should contain value 1 and be successfully.
    2. When trying call function by Try.of and function raise exception, then Try should contain exception and be not successfully.
    3. When trying call function by Try.of and function return 1, then Try should contain value 2 and be successfully.
    4. When trying call function by Try.of and function raise exception, then Try should contain exception and be not successfully.
    """
    # 1
    test_value = 1
    assert Try.of(lambda: test_value) == Try(1, True)
    # 2
    def test_fn():
        raise Exception("exception")
    assert Try.of(test_fn) == Try("exception", False)
    # 3
    test_value = 1
    assert Try.of

# Generated at 2022-06-21 19:23:22.931148
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Given
    fn = lambda x: x
    try_monad = Try.of(fn, 1)
    default_value = 0

    # When
    result = try_monad.get_or_else(default_value)

    # Then
    assert result == 1


# Generated at 2022-06-21 19:23:34.120046
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer_even(x):
        return x % 2 == 0

    def filterer_odd(x):
        return x % 2 != 0

    def test_filter_with_even_filterer():
        assert_equal(Try(1, True).filter(filterer_even), Try(1, False))
        assert_equal(Try(2, True).filter(filterer_even), Try(2, True))

    def test_filter_with_odd_filterer():
        assert_equal(Try(1, True).filter(filterer_odd), Try(1, True))
        assert_equal(Try(2, True).filter(filterer_odd), Try(2, False))
    test_filter_with_even_filterer()
    test_filter_with_odd_filterer()

# Generated at 2022-06-21 19:23:43.976414
# Unit test for method filter of class Try
def test_Try_filter():
    input = random.randint(0, 10000000)
    is_positive = input > 0
    is_negative = input < 0

    actual = Try(input, True).filter(lambda x: x > 0)
    expected = Try(input, is_positive)

    assert actual == expected,\
        "Expected: {}, but actual: {}".format(expected, actual)

    actual = Try(input, True).filter(lambda x: x < 0)
    expected = Try(input, is_negative)

    assert actual == expected,\
        "Expected: {}, but actual: {}".format(expected, actual)

# Generated at 2022-06-21 19:23:52.702256
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Test Case:
        The test case for method on_success of class Try:
            case1: when try is successfully
            case2: when try is not successfully

    Expectation:
        The expectation for method on_success of class Try:
            case1: return self
            case2: return self
    """
    # case1: when try is successfully
    assert Try(2, True).on_success(lambda x: x ** 2) == Try(2, True)

    # case2: when try is not successfully
    assert Try('Error', False).on_success(lambda x: x ** 2) == Try('Error', False)



# Generated at 2022-06-21 19:23:56.827699
# Unit test for method get of class Try
def test_Try_get():
    result = Try.of(lambda x: x, 1).get()
    assert result == 1
    result = Try.of(lambda x: 1/x, 0).get()
    assert result is not None


# Generated at 2022-06-21 19:24:00.728885
# Unit test for method on_success of class Try
def test_Try_on_success():
    x = Try(1, True)

# Generated at 2022-06-21 19:24:15.585987
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try('text', True)) == 'Try[value=text, is_success=True]'
    assert str(Try('text', False)) == 'Try[value=text, is_success=False]'
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-21 19:24:22.460558
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def f():
        return 'one'

    def div(a, b):
        return int(a / b)

    def test_fail_callback(exception):
        assert type(exception) == Exception

    assert Try.of(f).on_fail(test_fail_callback) == Try(None, True)
    assert Try.of(div, 1, 0).on_fail(test_fail_callback) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:24:24.967156
# Unit test for method map of class Try
def test_Try_map():
    assert Try(2, True).map(lambda x: x * 2) == Try(4, True)
    assert Try(2, False).map(lambda x: x * 2) == Try(2, False)


# Generated at 2022-06-21 19:24:29.045040
# Unit test for method on_success of class Try
def test_Try_on_success():
    actual = Try.of(lambda x: x, 1).on_success(lambda x: x + 2)
    assert actual == Try(3, True)


# Generated at 2022-06-21 19:24:33.790003
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    func = lambda: 1 / 0
    try_ = Try.of(func)
    assert not try_.is_success and try_.value.__class__.__name__ == 'ZeroDivisionError'

    try_.on_fail(lambda e: e.args)
    assert try_.value.args == ('division by zero',)


if __name__ == '__main__':  # pragma: no cover
    test_Try_on_fail()

# Generated at 2022-06-21 19:24:37.736178
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, False).value == 1
    assert Try(1, True).value == 1
    assert Try(1, False).is_success == False
    assert Try(1, True).is_success == True


# Generated at 2022-06-21 19:24:42.385426
# Unit test for method map of class Try
def test_Try_map():
    import unittest

    class TestTryMap(unittest.TestCase):
        def test_success_map(self):
            self.assertEqual(Try(2, True).map(lambda x: x * 3), Try(6, True))

        def test_fail_map(self):
            self.assertEqual(Try(2, False).map(lambda x: x * 3), Try(2, False))
    unittest.main()


# Generated at 2022-06-21 19:24:53.694172
# Unit test for method filter of class Try
def test_Try_filter():
    # Define result test
    test_values = [
        (
            Try(5, True).filter(lambda v: v > 0),
            Try(5, True)
        ),
        (
            Try(5, True).filter(lambda v: v < 0),
            Try(5, False)
        ),
        (
            Try(5, False).filter(lambda v: v > 0),
            Try(5, False)
        ),
        (
            Try(Exception(), False).filter(lambda v: v > 0),
            Try(Exception(), False)
        ),
    ]

    # Run test
    failed = []
    for (actual, expected) in test_values:
        actual == expected or failed.append('For actual: %s, expected: %s' % (actual, expected))
    assert not failed

# Generated at 2022-06-21 19:24:56.828910
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(4, True).get() == 4
    assert Try('46', False).get() == '46'



# Generated at 2022-06-21 19:24:59.118526
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(2, True).get() == 2
    assert Try(3, True).get() == 3


# Generated at 2022-06-21 19:25:18.494805
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-21 19:25:24.934511
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(1, True)
    try_2 = Try(2, True)
    try_3 = Try(1, False)
    try_4 = Try((1, 2), True)

    assert try_1 == try_1
    assert not try_1 == None
    assert not try_1 == try_2
    assert try_1 == try_3
    assert not try_1 == try_4


# Generated at 2022-06-21 19:25:28.956033
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        raise Exception('Some exception')
    except Exception as e:
        instance = Try(e, False)

    def callback(v):
        try:
            assert isinstance(v, Exception)
            raise v
        except Exception as e:
            return True

    assert callback(instance.value)
    assert instance.on_fail(callback) == instance
    assert instance.is_success is False


# Generated at 2022-06-21 19:25:33.559683
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda v: v > 0) == Try(1, True)
    assert Try(1, True).filter(lambda v: v % 2 == 0) == Try(1, False)
    assert Try({}, False).filter(lambda v: True) == Try({}, False)

# Generated at 2022-06-21 19:25:36.109972
# Unit test for method get of class Try
def test_Try_get():
    x = Try(10, True)

    assert x.get() == 10



# Generated at 2022-06-21 19:25:38.181551
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 2 + 2, None).get() == 4


# Generated at 2022-06-21 19:25:44.862026
# Unit test for method filter of class Try
def test_Try_filter():
    test_value = 42
    assert Try(test_value, True).filter(lambda x: x > 10) == Try(test_value, True)
    assert Try(test_value, True).filter(lambda x: x > 50) == Try(test_value, False)
    assert Try(test_value, False).filter(lambda x: x > 50) == Try(test_value, False)


# Generated at 2022-06-21 19:25:49.028003
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def my_callback(v):
        print('Value is: ' + v)

    Try.of(lambda: 'Hello', None).on_success(my_callback)
    Try.of(lambda: 'Hello', None).on_success(lambda v: print('Value is: ' + v))



# Generated at 2022-06-21 19:25:53.327351
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(
        lambda x: Try(x + 1, True)
    ) == Try(2, True)
    assert Try(1, True).bind(
        lambda x: Try(x / 0, True)
    ) == Try(ZeroDivisionError('division by zero'), False)
    assert Try(1, False).bind(
        lambda x: Try(x + 1, True)
    ) == Try(1, False)



# Generated at 2022-06-21 19:26:01.143696
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Unit test for Try.bind method.

    :returns:
    :rtype:
    """
    def gen_fn(i):
        def fn(a):
            return i + a
        return fn

    def t(a, b):
        return Try(a + b, True)

    def f(a, b):
        return Try(a + b, False)

    assert Try(2, True).bind(t) == Try(4, True)
    assert Try(2, True).bind(f) == Try(4, False)

    assert Try(2, False).bind(t) == Try(2, False)
    assert Try(2, False).bind(f) == Try(2, False)

    assert Try(2, True).bind(gen_fn(2)) == Try(4, True)
   

# Generated at 2022-06-21 19:26:22.413196
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:26:26.870064
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def division(x, y):
        return x / y

    def test_fail(value):
        print(value)
        assert not isinstance(value, ZeroDivisionError)

    try_ = Try.of(division, 1, 0)
    try_.on_fail(test_fail)

    try_.on_fail(test_fail)
    assert try_.is_success is False



# Generated at 2022-06-21 19:26:36.364915
# Unit test for method filter of class Try
def test_Try_filter():
    # Test for when monad have value and filterer returns True
    assert Try(1, True).filter(lambda x: True) == Try(1, True)

    # Test for when monad have value and filterer returns False
    assert Try(1, True).filter(lambda x: False) == Try(1, False)

    # Test for when monad have no value and filterer returns True
    assert Try(1, False).filter(lambda x: True) == Try(1, False)

    # Test for when monad have no value and filterer returns False
    assert Try(1, False).filter(lambda x: False) == Try(1, False)

# Generated at 2022-06-21 19:26:37.949198
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    

# Generated at 2022-06-21 19:26:45.035981
# Unit test for method map of class Try
def test_Try_map():
    """
    Test if map method works correctly.
    """
    result = Try.of(lambda a, b: a + b, 1, 2).map(lambda x: x + 1)
    expected_result = Try(4, True)
    assert result == expected_result, "Expected result: %s, but %s was returned." % (expected_result, result)
    result = Try.of(lambda a, b: a / b, 1, 0).map(lambda x: x + 1)
    expected_result = Try(ZeroDivisionError('division by zero'), False)
    assert result == expected_result, "Expected result: %s, but %s was returned." % (expected_result, result)


# Generated at 2022-06-21 19:26:49.817964
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert\
        (Try(1, True)
         .on_fail(lambda v: None)
         .value) == 1

    assert\
        (Try(1, False)
         .on_fail(lambda v: None)
         .value) == 1


# Generated at 2022-06-21 19:26:52.703543
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 5, None).get() == 5
    assert Try.of(lambda: 5/0, None).get() is not None


# Generated at 2022-06-21 19:26:59.452156
# Unit test for method bind of class Try
def test_Try_bind():
    def add(_, x):
        return x + 1

    add_try = Try.of(add, 1, 1)
    assert add_try.bind(add) == Try(3, True)

    def one_error(_, x):
        raise ValueError(x)

    one_error_try = Try.of(one_error, 1, 1)
    assert one_error_try.bind(add) == Try(ValueError(1), False)


# Generated at 2022-06-21 19:27:02.743908
# Unit test for method bind of class Try
def test_Try_bind():
    """
    :returns: dot_info
    :rtype: String
    """
    import doctest
    return doctest.run_docstring_examples(Try.bind, globals(), True)

# Generated at 2022-06-21 19:27:08.225996
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    exception_message = "exception message"
    first_try = Try(exception_message, False)
    second_try = Try(exception_message, False)
    assert first_try == second_try

    exception_message_2 = "exception message 2"
    third_try = Try(exception_message_2, False)
    assert third_try != first_try


# Generated at 2022-06-21 19:27:33.011752
# Unit test for method on_success of class Try
def test_Try_on_success():
    result = Try.of(lambda: 2/0)
    assert result == Try(ZeroDivisionError(), False)

    result.on_success(lambda x: print(x))
    result.on_success(lambda x: print(x - 2))
    result.on_success(lambda x: print(x + 2))

    result.on_fail(lambda x: print(x))



# Generated at 2022-06-21 19:27:44.589553
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """Unit test for method __eq__ of class Try"""

    def run_test(test_name, actual, expected):
        """Run single test"""
        print(test_name, actual == expected)

    run_test('True', Try('value', True), Try('value', True))
    run_test('False', Try('value', False), Try('value', True))
    run_test('False', Try('value1', True), Try('value2', True))
    run_test('True', Try('value', False), Try('value', False))
    run_test('False', Try(1, False), Try('1', False))
    run_test('False', Try('value', True), Try('value', False))
    run_test('False', Try('value', False), Try('value', False))


# Generated at 2022-06-21 19:27:50.942142
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def raise_exception():
        raise Exception('')

    assert Try.of(raise_exception).on_fail(lambda _: print('exception')) == Try(Exception(), False)
    assert Try(1, True).on_fail(lambda _: print('exception')) == Try(1, True)


# Generated at 2022-06-21 19:27:56.469967
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Some test for bind method of class Try.
    """
    assert Try.of(int, '10').bind(lambda x: Try(x * 2, True)) == Try(20, True)
    func_exception = lambda x: x[0]
    assert Try.of(func_exception, []) == Try(IndexError(), False)
    assert Try.of(func_exception, []).bind(lambda x: Try(x * 2, True)) == Try(IndexError(), False)
    assert Try.of(int, '').bind(lambda x: Try(x * 2, True)) == Try(ValueError(), False)

# Generated at 2022-06-21 19:28:06.976048
# Unit test for method bind of class Try
def test_Try_bind():
    # Success bind
    def binder(arg):
        return Try(arg + 1, True)

    assert Try.of(lambda: 2, None).bind(binder) == Try(3, True)
    assert Try.of(lambda: '2', None).bind(binder) == Try(None, False)
    assert Try.of(lambda: 2, None).bind(lambda arg: Try(arg + 1, False)) == Try(3, False)
    # Failure bind
    def failure_binder(arg):
        raise Exception('test')

    assert Try.of(lambda: 2, None).bind(failure_binder) == Try(None, False)
    assert Try.of(lambda: 2, None).bind(lambda: failure_binder(None)) == Try(None, False)



# Generated at 2022-06-21 19:28:11.239806
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert 'Try[value=1, is_success=True]' == str(Try(1, True))
    assert 'Try[value=1, is_success=False]' == str(Try(1, False))


# Generated at 2022-06-21 19:28:15.122464
# Unit test for method map of class Try
def test_Try_map():
    """
    Test method map of class Try.
    """
    assert Try.success(2).map(lambda x: 2 * x) == Try(4, True)
    assert Try.fail(2).map(lambda x: 2 * x) == Try(2, False)



# Generated at 2022-06-21 19:28:25.863185
# Unit test for method filter of class Try
def test_Try_filter():
    def plus_100(a: int) -> int:
        return a + 100
    def div_by_2(a: int) -> int:
        return a / 2
    def is_gt_100(a: int) -> bool:
        return a > 100
    def less_then_1000(a: int) -> bool:
        return a < 1000

    try_result = Try.of(plus_100, 10)
    try_result = try_result.map(div_by_2)
    assert try_result == Try(105, True)
    try_result = try_result.filter(less_then_1000)
    assert try_result == Try(105, True)
    try_result = try_result.filter(is_gt_100)
    assert try_result == Try(105, True)
    try_result

# Generated at 2022-06-21 19:28:29.500950
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    mock = MagicMock()
    t = Try(factory.get('Error'), False)
    t.on_fail(mock)
    assert mock.called



# Generated at 2022-06-21 19:28:36.608685
# Unit test for method bind of class Try
def test_Try_bind():
    def test_success(value: Try):
        assert value.bind(lambda v: Try(v, True)) == Try(True, True)
    def test_fail(value: Try):
        assert value.bind(lambda v: Try(v, True)) == Try(True, False)

    test_success(Try(True, True))
    test_success(Try(2, True))
    test_success(Try('test', True))

    test_fail(Try(1, False))
    test_fail(Try('test', False))


# Generated at 2022-06-21 19:29:00.946786
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception(), False)) == 'Try[value=Exception(), is_success=False]'


# Generated at 2022-06-21 19:29:06.421659
# Unit test for method map of class Try
def test_Try_map():
    result = Try.of(lambda: 3).map(lambda n: n+1)
    assert result == Try(4, True)

    result = Try.of(lambda: 3).map(lambda n: n/0)
    exc = ArithmeticError()
    assert result == Try(exc, False)


# Generated at 2022-06-21 19:29:11.793036
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def divider(divident):
        return divident//10

    assert Try.of(int, '10').bind(divider) == Try(1, True)
    assert Try.of(int, 's').bind(divider) == Try(ValueError("invalid literal for int() with base 10: 's'"), False)



# Generated at 2022-06-21 19:29:14.653121
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    assert Try.of(lambda: 1/0, None)\
        .on_fail(lambda ex: print('not successfully: {}'.format(ex)))



# Generated at 2022-06-21 19:29:18.789236
# Unit test for method get of class Try
def test_Try_get():
    try_test = Try(1, True)
    assert try_test.get() == 1
    assert try_test.get_or_else(2) == 1
    try_test = Try(1, False)
    assert try_test.get_or_else(2) == 2


# Generated at 2022-06-21 19:29:22.405892
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(Exception, False).get_or_else(0) == 0



# Generated at 2022-06-21 19:29:25.303995
# Unit test for method get of class Try
def test_Try_get():
    assert Try(100, True).get() == 100

    try:
        assert Try(None, False).get() is None
    except Exception as e:
        assert type(e) == Exception


# Generated at 2022-06-21 19:29:32.531273
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # arrange
    default_value = 'default_value'
    success_try = Try('success_try', True)

    # action
    success_try_result = success_try.get_or_else(default_value)

    # assert
    assert success_try_result == 'success_try'

    # arrange
    fail_try = Try('fail_try', False)

    # action
    fail_try_result = fail_try.get_or_else(default_value)

    # assert
    assert fail_try_result == default_value

# Generated at 2022-06-21 19:29:36.625278
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(100) == 1
    assert Try(None, False).get_or_else(100) == 100

# Generated at 2022-06-21 19:29:37.999518
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try('OK', True).on_fail(lambda value: isinstance(value, Exception))
    assert not Try(Exception(), False).on_fail(lambda value: isinstance(value, Exception))


# Generated at 2022-06-21 19:30:19.770776
# Unit test for method get of class Try
def test_Try_get():
    assert Try(4, True).get() == 4
    assert Try(4, False).get() == 4



# Generated at 2022-06-21 19:30:26.187603
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    t1 = Try(10, True).filter(lambda x: x % 2 == 0)
    t2 = Try(10, True).filter(lambda x: x > 6)
    t3 = Try(10, True).filter(lambda x: x % 2 == 1)
    t4 = Try(10, False).filter(lambda x: x % 2 == 0)

    assert t1 == Try(10, True)
    assert t2 == Try(10, True)
    assert t3 == Try(10, False)
    assert t4 == Try(10, False)

# Generated at 2022-06-21 19:30:30.459517
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(ValueError, True)) == 'Try[value=ValueError, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'


# Generated at 2022-06-21 19:30:35.889467
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filterer(a):
        return a > 0

    assert Try(0, True).filter(test_filterer) == Try(0, False)
    assert Try(1, True).filter(test_filterer) == Try(1, True)


# Generated at 2022-06-21 19:30:43.904446
# Unit test for method on_success of class Try
def test_Try_on_success(): # type: ignore
    """Test for method on_success of class Try"""
    dummy_data = 'result'
    dummy_default = 'default'
    dummy_callback = lambda value: dummy_data == value

    failed_result = Try(ValueError('error'), False)
    assert failed_result.on_success(dummy_callback).get() == failed_result.get()

    successfully_result = Try(dummy_data, True)
    assert successfully_result.on_success(dummy_callback).get() == successfully_result.get()


# Generated at 2022-06-21 19:30:47.000490
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(0) == 1
    assert Try(None, True).get_or_else(0) == 0
    assert Try(1, False).get_or_else(0) == 0
    assert Try('str', True).get_or_else(0) == 'str'


# Generated at 2022-06-21 19:30:50.758590
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    value = 12
    try_ = Try.of(lambda x: 1/x, value)
    try_.on_fail(lambda x: print('Fail with err: {!s}'.format(x)))
    assert True