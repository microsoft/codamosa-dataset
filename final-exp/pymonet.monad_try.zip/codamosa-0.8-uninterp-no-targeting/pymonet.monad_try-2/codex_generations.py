

# Generated at 2022-06-21 19:20:52.495189
# Unit test for method get of class Try
def test_Try_get():
    assert Try('hello', True).get() == 'hello'
    assert Try('world', True).get() == 'world'



# Generated at 2022-06-21 19:20:54.853084
# Unit test for method filter of class Try
def test_Try_filter():
    expected = Try("value", True)
    actual = Try.of(lambda a: a.upper(), "value").filter(lambda a: len(a) <= 7)

    assert expected == actual

    expected = Try("value", False)
    actual = Try.of(lambda a: a.upper(), "value").filter(lambda a: len(a) > 7)

    assert expected == actual


# Generated at 2022-06-21 19:21:00.824696
# Unit test for method filter of class Try
def test_Try_filter():
    # Test for successfully
    # 1. when filterer returns True
    assert Try(2, True).filter(lambda v: v % 2 == 0) == Try(2, True)
    # 2. when filterer returns False
    assert Try(3, True).filter(lambda v: v % 2 == 0) == Try(3, False)
    # Test for not successfully
    assert Try('error', False).filter(lambda v: v % 2 == 0) == Try('error', False)



# Generated at 2022-06-21 19:21:02.262022
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 1 / 0, {}).on_fail(lambda x: 1) == Try(ZeroDivisionError(), False)

# Generated at 2022-06-21 19:21:06.747124
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(8, True)) == 'Try[value=8, is_success=True]'
    assert str(Try(8, False)) == 'Try[value=8, is_success=False]'
    print(str(Try(8, True)))
    print(str(Try(8, False)))


# Generated at 2022-06-21 19:21:15.155178
# Unit test for method filter of class Try
def test_Try_filter():
    data = [
        "",
        "1",
        "a",
        "?",
        "A",
        "Ok",
        "asd",
        " ",
        "t",
        "q"
    ]
    assert Try.of(lambda x: x, "").filter(lambda x: len(x) == 0) == Try("", True)
    assert Try.of(lambda x: x, "").filter(lambda x: len(x) == 1) == Try("", False)
    for x in data:
        assert Try.of(lambda x: x, x).filter(lambda x: len(x) == 1) == Try(x, len(x) == 1)



# Generated at 2022-06-21 19:21:20.192847
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try('a', True).get() == 'a'
    assert Try('a', False).get() == 'a'


# Generated at 2022-06-21 19:21:22.041696
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)



# Generated at 2022-06-21 19:21:31.304318
# Unit test for method bind of class Try
def test_Try_bind():
    def i_dont_like_raise():
        return 1 + 1

    def i_like_raise():
        raise Exception("i like raise")

    try_1 = Try.of(i_dont_like_raise)
    try_2 = Try.of(i_like_raise)

    assert try_1.bind(lambda x: Try(x, True)) == Try(2, True)
    assert try_2.bind(lambda x: Try(x, False)) == Try("i like raise", False)

# Generated at 2022-06-21 19:21:37.769620
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) == Try('something', True)
    assert Try(1, True) != Try(1, False)
    assert Try('some', True) == Try('some', True)
    assert Try('some', False) == Try('some', False)
    assert Try(1, False) == Try(1, False)
    assert Try('some', False) != Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try('something', True)



# Generated at 2022-06-21 19:21:46.759786
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    assert Try(12, True).filter(lambda v: v > 10) == Try(12, True)
    assert Try(12, True).filter(lambda v: v < 10) == Try(12, False)

# Generated at 2022-06-21 19:21:50.830292
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # given
    try1 = Try(True, True)
    try2 = Try(True, True)
    try3 = Try(False, True)

    # then
    assert try1 == try2
    assert try1 != try3



# Generated at 2022-06-21 19:22:02.199194
# Unit test for method bind of class Try
def test_Try_bind():
    def test_map_on_success(result: int):
        assert result == 1

    def test_map_on_fail(result: Exception):
        assert result.args == ('Exception in Try',)

    def test_bind_on_success(result: int):
        assert result == 1

    def test_bind_on_fail(result: Exception):
        assert result.args == ('Exception in Try',)

    def test_filter(result: int):
        assert result == 1

    def filter_is_fail(value):
        return False

    def filter_is_ok(value):
        return True

    def fn_raise_exception():
        raise Exception('Exception in Try')

    def fn_success():
        return 1

    def fn_map(value):
        return value

    def fn_bind(value):
        return

# Generated at 2022-06-21 19:22:05.590462
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(int, 'non_int').on_fail(
        lambda e: print(e)
    ) == Try(ValueError, False)


# Generated at 2022-06-21 19:22:16.258984
# Unit test for method bind of class Try
def test_Try_bind():
    def add_one(x):
        return x + 1

    def fail_add_one(x):
        raise Exception('Error when adding 1 to ' + str(x))

    def multiply(x):
        return x * x

    def try_bind(bind_fn, to, should_be):
        try_monad = Try.of(bind_fn, 1)
        result = try_monad.bind(to)
        assert result == Try(should_be, True)

    try_bind(add_one, multiply, 4)
    try_bind(fail_add_one, multiply, Exception('Error when adding 1 to 1'))

# Generated at 2022-06-21 19:22:26.484687
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(5, True) == Try(5, True)
    assert Try(5, False) == Try(5, False)
    assert Try(5, True) != Try(5, False)
    assert Try(5, False) != Try(5, True)
    assert Try(Exception(5), False) != Try(Exception(5), True)
    assert Try(Exception(5), True) != Try(Exception(5), False)
    assert Try(Exception(5), True) == Try(Exception(5), True)
    assert Try(5, True) != Try(6, True)
    assert Try(5, False) != Try(6, False)


# Generated at 2022-06-21 19:22:31.276551
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda a, b: a + b, 'a', 'b').filter(lambda x: len(x) == 2) == Try('ab', True)
    assert Try.of(lambda a, b: a + b, 'a', 'b').filter(lambda x: len(x) == 3) == Try('ab', False)
    assert Try.of(lambda a, b: a + b, 'a', 'b').filter(lambda x: len(x) == 3) == Try('ab', False)


# Generated at 2022-06-21 19:22:34.072288
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-21 19:22:36.911179
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-21 19:22:42.938324
# Unit test for constructor of class Try
def test_Try():
    assert Try(123, True) == Try(123, True)
    assert Try(123, False) == Try(123, False)
    assert Try(123, True) != Try(123, False)
    assert Try(123, False) != Try(321, False)
    assert Try(123, True) != Try(321, False)
    assert Try(123, False) != Try(321, True)

    assert Try(123, True) == Try.of(lambda x: x, 123)
    assert Try(123, False) == Try.of(lambda x: x/0, 123)



# Generated at 2022-06-21 19:22:50.699749
# Unit test for method get of class Try
def test_Try_get():
    def get_some_int():
        return 42

    try_some_int = Try.of(get_some_int)
    assert try_some_int.get() == 42


# Generated at 2022-06-21 19:22:53.355507
# Unit test for constructor of class Try
def test_Try():
    try_class = Try(1, True)
    assert try_class == Try(1, True)
    assert str(try_class) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-21 19:22:54.966912
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x: x, 'value').get() == 'value'


# Generated at 2022-06-21 19:23:00.077294
# Unit test for method filter of class Try
def test_Try_filter():
    def should_pass(value):
        return value == 1

    def should_fail(value):
        return value == 2

    assert Try.of(lambda: 1, )\
        .map(lambda x: x + 1)\
        .filter(should_pass)\
        .get() == 2

    assert Try.of(lambda: 1, )\
        .map(lambda x: x + 1)\
        .filter(should_fail)\
        .get() == 1


# Generated at 2022-06-21 19:23:03.599879
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert not Try(1, True).on_fail(lambda e: e + 1).is_success
    assert Try(1, False).on_fail(lambda e: e + 1).is_success
    assert Try(1, True).on_fail(lambda e: e + 1).value == 2
    assert Try(1, False).on_fail(lambda e: e + 1).value == 1



# Generated at 2022-06-21 19:23:09.835527
# Unit test for method bind of class Try
def test_Try_bind():
    def f(x):
        return Try(x * 2, True)

    x = Try(10, True)
    assert x.bind(f) == Try(100, True)
    assert x.bind(f).bind(f) == Try(10000, True)

    def f(x):
        return Try(x * 2, False)

    assert x.bind(f) == Try(None, False)



# Generated at 2022-06-21 19:23:15.905719
# Unit test for constructor of class Try
def test_Try():  # type: () -> None
    with pytest.raises(TypeError):
        Try('Test', 1)
    try_ = Try('Test', True)
    assert str(try_) == 'Try[value=Test, is_success=True]'
    assert try_ == Try('Test', True)
    assert try_.value == 'Test'
    assert try_.is_success == True



# Generated at 2022-06-21 19:23:28.478862
# Unit test for method filter of class Try

# Generated at 2022-06-21 19:23:32.319858
# Unit test for method map of class Try
def test_Try_map():
    def add(x):
        return x + 2

    assert(Try(2, True).map(add) == Try(4, True))
    assert(Try(2, False).map(add) == Try(2, False))


# Generated at 2022-06-21 19:23:38.293104
# Unit test for constructor of class Try
def test_Try():
    """
    >>> m = Try(1, True)
    >>> n = Try(2, False)
    >>> m == Try(1, True)
    True
    >>> n == Try(2, False)
    True
    >>> m == Try(2, False)
    False
    >>> n == Try(1, True)
    False
    """


# Generated at 2022-06-21 19:23:53.516542
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Unit test for method filter of class Try.

    :returns: unit test pass flag
    :rtype: Boolean
    """
    def is_even(value):
        return value % 2 == 0

    assert Try(2, True).filter(is_even) == Try(2, True)
    assert Try(1, True).filter(is_even) == Try(1, False)
    assert Try('error', False).filter(is_even) == Try('error', False)

    return True


# Generated at 2022-06-21 19:24:04.219917
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Runs unit test for on_fail method of class Try
    """
    def test_fn(arg1, arg2):
        """
        Function to test with diffrent args.
        """
        if arg1 == arg2:
            raise Exception('isset')
        else:
            return arg1

    def fail_callback(ex):
        """
        Fail callback function to testing
        """
        assert ex == Exception('isset')

    assert Try.of(test_fn, 1, 2).on_fail(fail_callback) == Try(1, True)
    assert Try.of(test_fn, 2, 2).on_fail(fail_callback) == Try(Exception('isset'), False)

# Generated at 2022-06-21 19:24:06.074684
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try('value', True) == Try('value', True) == Try('value', False)
    assert Try('value', True) != Try('value', False)

# Generated at 2022-06-21 19:24:10.796267
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(err):
        assert err.args[0] == 'test'

    try:
        raise Exception('test')
    except Exception as e:
        monad = Try(e, False)
        monad.on_fail(fail_callback)



# Generated at 2022-06-21 19:24:15.302339
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda a, b: a + b, 1, 2).filter(lambda value: value > 1)

    assert result == Try(3, True)

    result = Try.of(lambda a, b: a + b, 1, 2).filter(lambda value: value > 5)

    assert result == Try(3, False)


# Generated at 2022-06-21 19:24:22.271195
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_some_value = Try('Some value', True)
    assert try_some_value.__str__() == 'Try[value=Some value, is_success=True]', '__str__ of Try some value was fail!'

    try_some_exception = Try(Exception('Some exception'), False)
    assert try_some_exception.__str__() == 'Try[value=Some exception, is_success=False]', '__str__ of Try some exception was fail!'



# Generated at 2022-06-21 19:24:26.047988
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    # Test for not successfully
    try_ = Try(Exception('error'), False)

    assert try_.value == Exception('error')
    assert not try_.is_success

    # Test for successfully
    try_ = Try('value', True)

    assert try_.value == 'value'
    assert try_.is_success


# Generated at 2022-06-21 19:24:30.049866
# Unit test for constructor of class Try
def test_Try():
    success_monad = Try(10, True)
    assert success_monad == Try(10, True)
    fail_monad = Try(10, False)
    assert fail_monad == Try(10, False)


# Generated at 2022-06-21 19:24:33.779453
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    def add(a, b):
        return a + b

    assert Try.of(add, 2, 3).map(lambda x: x * 2) == Try(10, True)
    assert Try.of(add, 2, 'b').map(lambda x: x * 2) == Try('bb', False)



# Generated at 2022-06-21 19:24:41.288263
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def add(a, b):
        return a + b

    assert Try.of(add, 1, 2) == Try(3, True)
    assert Try.of(add, 1, 2) != Try(3, False)
    assert Try.of(add, 1, 2) != Try(4, True)
    assert Try.of(add, 1, 2) != Try(4, False)
    assert Try(3, True) == Try(3, True)
    assert Try(3, True) != Try(3, False)
    assert Try(3, False) == Try(3, False)
    assert Try(3, False) != Try(4, True)
    assert Try(3, False) != Try(4, False)



# Generated at 2022-06-21 19:25:06.561727
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_success = Try("Hello, World", True)
    assert str(try_success) == 'Try[value=Hello, World, is_success=True]'

    try_fail = Try("Hello, World", False)
    assert str(try_fail) == 'Try[value=Hello, World, is_success=False]'



# Generated at 2022-06-21 19:25:09.545122
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2

# Generated at 2022-06-21 19:25:16.467903
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def get_error_message(error):
        assert type(error) == TypeError
        assert error.args[0] == 'Can\'t convert \'list\' object to str implicitly'

    Try.of(int, '123').on_fail(get_error_message)

    def get_error_message_again(error):
        assert type(error) == Exception
        assert error.args[0] == 'Error'
    Try.of(int, '123').bind(lambda x: Try.of(int, [4, 5])).on_fail(get_error_message_again)

# Generated at 2022-06-21 19:25:20.844507
# Unit test for constructor of class Try
def test_Try():
    try_success = Try(1, True)
    try_fail = Try(RuntimeError('test'), False)
    assert try_success != try_fail
    assert try_success == Try(1, True)
    assert not try_success == Try(2, True)


# Generated at 2022-06-21 19:25:26.186519
# Unit test for method map of class Try
def test_Try_map():
    value = 3
    assert Try(value, True).map(lambda x: x * 2) == Try(value * 2, True)
    assert Try(value, True).map(lambda x: x / 0) == Try(ZeroDivisionError(), False)
    assert Try(value, False).map(lambda x: x / 0) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:25:29.404315
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    """
    Test for Try.__str__
    """
    assert str(Try('1', True)) == "Try[value=1, is_success=True]"
    assert str(Try('1', False)) == "Try[value=1, is_success=False]"


# Generated at 2022-06-21 19:25:31.792034
# Unit test for method __str__ of class Try
def test_Try___str__():
    my_try = Try('test', True)
    assert str(my_try) == 'Try[value=test, is_success=True]'


# Generated at 2022-06-21 19:25:37.486024
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-21 19:25:46.010416
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Check example of equality of instances
    assert Try(10, True) == Try(10, True)
    assert Try(10, False) == Try(10, False)

    # Check equality with not equal value
    assert Try(10, True) != Try(11, True)
    assert Try(10, False) != Try(11, False)

    # Check equality with not equal is_success
    assert Try(10, True) != Try(10, False)
    assert Try(10, False) != Try(10, True)
    print('Test passed!')



# Generated at 2022-06-21 19:25:50.867496
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Unit test for method __eq__ of class Try
    """
    assert Try(1, True) == Try(1, True)
    assert Try('aa', False) == Try('aa', False)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, False) == Try(2, False)



# Generated at 2022-06-21 19:26:32.338375
# Unit test for method on_success of class Try
def test_Try_on_success():
    Try.of(lambda x: 1 / x, 1).on_success(lambda x: print(x))
    Try.of(lambda x: 1 / x, 0).on_success(lambda x: print(x))


# Generated at 2022-06-21 19:26:38.817805
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.
    """
    assert Try(2, True).filter(lambda v: v % 2 == 0) == Try(2, True)
    assert Try(3, True).filter(lambda v: v % 3 == 0) == Try(3, True)
    assert Try(3, True).filter(lambda v: v % 2 == 0) == Try(3, False)

# Generated at 2022-06-21 19:26:43.220002
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(5, True).filter(lambda x: x > 4) == Try(5, True)
    assert Try('s', True).filter(lambda x: x > 'a') == Try('s', True)
    assert Try('s', False).filter(lambda x: x > 'a') == Try('s', False)
    assert Try('s', True).filter(lambda x: x > 's') == Try('s', False)

# Generated at 2022-06-21 19:26:48.169811
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert_equal(Try.of(int, 'abc').on_fail(lambda e: print(e)), Try('abc', False))
    assert_equal(Try.of(int, '1').on_fail(lambda e: print(e)), Try(1, True))



# Generated at 2022-06-21 19:26:51.828642
# Unit test for constructor of class Try
def test_Try():
    def_1 = Try(1, True)

    assert def_1.value is 1
    assert def_1.is_success is True

    assert Try(2, False) != Try(2, True)


# Generated at 2022-06-21 19:26:54.682337
# Unit test for constructor of class Try
def test_Try(): # pragma: no cover
    try_ = Try(value=1, is_success=True)
    assert try_ == Try(value=1, is_success=True)



# Generated at 2022-06-21 19:26:57.293731
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    assert Try(2, True) == Try(2, True)
    assert Try(2, True) != Try(2, False)


# Generated at 2022-06-21 19:27:01.017427
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2, 'Get monad value of successful Try'
    assert Try(ValueError(), False).get() == ValueError(), 'Get monad value of not successful Try'



# Generated at 2022-06-21 19:27:06.362868
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) != Try(2, True)



# Generated at 2022-06-21 19:27:08.959106
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(None, False) == Try(None, False)


# Generated at 2022-06-21 19:28:22.413909
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:28:30.261087
# Unit test for method on_success of class Try
def test_Try_on_success():
    from hamcrest import assert_that, equal_to, is_, instance_of
    from .fixtures import s_add

    result = Try.of(s_add, 1, 2).on_success(lambda x: assert_that(x, equal_to(3)))

    assert_that(result, is_(instance_of(Try)))
    assert_that(result.is_success, equal_to(True))
    assert_that(result.value, equal_to(3))



# Generated at 2022-06-21 19:28:38.336952
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Check correctness of method bind for class Try.

    :returns: None
    :rtype: None
    """
    assert Try(1, True).bind(lambda x: Try(x + 1, True)) == Try(2, True)
    assert Try(1, True).bind(lambda x: Try(x, False)) == Try(1, False)
    assert Try(1, True).bind(lambda x: Try(x, False)).bind(lambda x: Try(x + 1, True)) == Try(1, False)
    assert Try(1, False).bind(lambda x: Try(x + 1, True)) == Try(1, False)


# Generated at 2022-06-21 19:28:43.237471
# Unit test for method get of class Try
def test_Try_get():       # pragma: no cover
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1
    assert Try("one", True).get() == "one"
    assert Try("one", False).get() == "one"


# Generated at 2022-06-21 19:28:50.685422
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try('abc', True) == Try('abc', True)
    assert Try('abc', True) != Try('abc', False)
    assert Try('abc', False) != Try('abc', True)
    assert Try('abc', True) != Try('a', True)
    assert Try('abc', False) != Try('a', False)
    assert Try('abc', True) != Try('a', False)
    assert Try('abc', False) != Try('a', True)



# Generated at 2022-06-21 19:29:01.432368
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Unit test for method Try.bind

    :returns: True when there are no errors
    :rtype: Boolean
    """
    def func_to_bind(value):
        if value > 4:
            return Try.of(lambda: type(value), )
        else:
            return Try(None, False)

    def func_to_bind_raise_error(value):
        if value > 10:
            raise ZeroDivisionError('Zero division!')
        else:
            return Try(1, True)

    try_result = Try.of(lambda x: x, 5).bind(func_to_bind)
    if not isinstance(try_result.get(), type):
        return False

    try_result = Try.of(lambda x: x, 1).bind(func_to_bind)

# Generated at 2022-06-21 19:29:05.319917
# Unit test for method on_fail of class Try

# Generated at 2022-06-21 19:29:12.533778
# Unit test for method filter of class Try
def test_Try_filter():
    def add5(v):
        return v + 5

    def greater5(v):
        return v > 5

    try_obj = Try.of(add5, 10)
    try_obj = try_obj.filter(greater5)
    assert try_obj.is_success

    try_obj = Try.of(add5, 2)
    try_obj = try_obj.filter(greater5)
    assert not try_obj.is_success
    assert try_obj.value == 2

# Generated at 2022-06-21 19:29:18.284783
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(1, True)
    try_2 = Try(1, True)

    assert try_1 == try_2
    assert try_1 is not try_2

    try_1 = Try(1, False)
    try_2 = Try(1, True)

    assert try_1 is not try_2

    try_1 = Try(1, False)
    try_2 = Try(2, False)

    assert try_1 is not try_2


# Generated at 2022-06-21 19:29:21.697453
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def failer():
        raise RuntimeError("fail")

    def fail_callback(value):
        assert value.__class__.__name__ == 'RuntimeError'

    try_fail = Try.of(failer)
    try_fail.on_fail(fail_callback)

    assert try_fail == Try(RuntimeError('fail'), False)

