

# Generated at 2022-06-21 19:20:53.512762
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2



# Generated at 2022-06-21 19:20:57.695725
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2
    assert Try(Exception(1), False).get_or_else(Exception(2)) == Exception(2)


# Generated at 2022-06-21 19:21:01.026928
# Unit test for method get of class Try
def test_Try_get():
    assert Try(2, True).get() == 2
    assert Try(Exception('Error'), False).get() == Exception('Error')



# Generated at 2022-06-21 19:21:06.895204
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) != Try(1, True)



# Generated at 2022-06-21 19:21:11.442258
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def is_True_function(value):
        assert value
    def is_False_function(value):
        assert not value
    assert Try(1, True).on_fail(is_False_function) == Try(1, True)
    assert Try(None, False).on_fail(is_True_function) == Try(None, False)


# Generated at 2022-06-21 19:21:16.383992
# Unit test for method map of class Try
def test_Try_map():
    # Successfully monad
    successfully = Try(1, True)
    # Not successfully monad
    not_successfully = Try(Exception(), False)

    assert successfully.map(lambda v: v + 1) == Try(2, True)
    assert not_successfully.map(lambda v: v + 1) == not_successfully


# Generated at 2022-06-21 19:21:22.861445
# Unit test for method bind of class Try
def test_Try_bind():
    def _test_Try_bind_fail():
        def raise_error():
            raise RuntimeError

        t0 = Try.of(lambda: 1)
        assert t0 == Try(1, True)

        t1 = t0.bind(lambda x: Try.of(lambda: x + 1))
        assert t1 == Try(2, True)

        t2 = t1.bind(raise_error)
        assert t2 == Try(RuntimeError(), False)

        t3 = t2.bind(lambda x: Try.of(lambda: x + 1))
        assert t3 == Try(RuntimeError(), False)
    _test_Try_bind_fail()

    def _test_Try_bind_success():
        def raise_error():
            raise RuntimeError

        t0 = Try.of(lambda: 1)
        assert t0

# Generated at 2022-06-21 19:21:27.194192
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'


# Generated at 2022-06-21 19:21:38.065779
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test function for method Try.map.
    """
    def sum(a, b):
        return a + b

    def mult(a, b):
        return a * b

    def fail(a, b):
        return a / b
    
    def f(a):
        return a * 2

    assert Try.of(sum, 5, 10).map(f) == Try(20, True)
    assert Try.of(mult, 5, 10).map(f) == Try(100, True)
    assert Try.of(fail, 5, 0).map(f) == Try(ZeroDivisionError(), False)



# Generated at 2022-06-21 19:21:43.228483
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def divide(a, b): return a / b
    assert Try.of(divide, 10, 2).get_or_else(0) == 5
    assert Try.of(divide, 10, 0).get_or_else(0) == 0



# Generated at 2022-06-21 19:21:48.108866
# Unit test for method get of class Try
def test_Try_get():
    t = Try(7, True)
    assert t.get() == 7
    t = Try(7, False)
    assert t.get() == 7



# Generated at 2022-06-21 19:21:54.298705
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def testFunction():
        raise RuntimeError('An error occured')

    def fail(e):
        assert e == 'An error occured'
        return True

    try_ = Try.of(testFunction)
    assert not try_.is_success
    assert try_.on_fail(fail).is_success
    assert try_.equals(Try('An error occured', False))



# Generated at 2022-06-21 19:22:04.636034
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    def divide_by_two(number):
        """
        Return half of number when number is even,
        othercase return not successfully Try.

        :params number: number which will be divided by half
        :type number: Integer
        :returns: Successfully Try with half number value when number is even,
        othercase Not successfully Try with 'number is not even'
        :rtype: Try[Integer | 'number is not even']
        :raises: TypeError when number is not Integer type
        """
        if not isinstance(number, int):
            raise TypeError('number must be Integer')
        if number % 2 == 0:
            return Try(number // 2, True)
        return Try('number is not even', False)

    assert Try(1, True).bind(divide_by_two) == Try

# Generated at 2022-06-21 19:22:13.261872
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda a_value: a_value == 1) == Try(1, True)
    assert Try(1, True).filter(lambda a_value: a_value == 2) == Try(1, False)
    assert Try(1, False).filter(lambda a_value: a_value == 1) == Try(1, False)
    assert Try(1, False).filter(lambda a_value: a_value == 2) == Try(1, False)


# Generated at 2022-06-21 19:22:17.909390
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    success_value = Try(3, True)
    fail_value = Try("error", False)
    assert_equal(success_value.get_or_else("mock"), 3)
    assert_equal(fail_value.get_or_else("mock"), "mock")



# Generated at 2022-06-21 19:22:23.094697
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(42, True).on_success(lambda x: x + 1) == Try(42, True)
    assert Try(42, False).on_success(lambda x: x + 1) == Try(42, False)


# Generated at 2022-06-21 19:22:28.207599
# Unit test for method map of class Try
def test_Try_map():
    assert Try(lambda x: x + 1, True).map(lambda x: x(4)) == Try(5, True)

# Generated at 2022-06-21 19:22:36.099818
# Unit test for method map of class Try
def test_Try_map():
    """
    Test for method map of class Try
    """
    assert Try.of(lambda x: x * 2, 1) == Try(2, True)
    assert Try.of(lambda x: x * 2, 1).map(lambda x: x * 3) == Try(6, True)
    assert Try.of(lambda x: x + 1, 1).map(lambda x: 1 / x) == Try(1.0, True).map(lambda x: 1 / x)


# Generated at 2022-06-21 19:22:42.370877
# Unit test for method map of class Try
def test_Try_map():
    """ Test Try.map method """
    assert Try(10, True).map(lambda x: x + 2) \
        == Try(12, True)
    assert Try(10, False).map(lambda x: x + 2) \
        == Try(10, False)


# Generated at 2022-06-21 19:22:47.917796
# Unit test for method __str__ of class Try
def test_Try___str__():
    t1 = Try(1, True)
    assert 'Try[value=1, is_success=True]' == t1.__str__()

    t2 = Try(ZeroDivisionError('division by zero'), False)
    assert 'Try[value=division by zero, is_success=False]' == t2.__str__()


# Generated at 2022-06-21 19:22:58.489752
# Unit test for method on_success of class Try
def test_Try_on_success():
    a = Try(2, True).on_success(lambda x: print('Value is {}'.format(x)))
    b = Try(None, False).on_success(lambda x: print('Value is {}'.format(x)))
    c = a.on_success(lambda x: print('Value is {}'.format(x)))
    d = b.on_success(lambda x: print('Value is {}'.format(x)))
    assert a.value == 2
    assert a.is_success
    assert b.value is None
    assert not b.is_success
    assert c.value == 2
    assert c.is_success
    assert d.value is None
    assert not d.is_success



# Generated at 2022-06-21 19:23:04.766429
# Unit test for method map of class Try
def test_Try_map():
    def inc(x):
        return x + 1

    def div(x):
        return x / 2

    def pow(x):
        return x**2

    def div_by_zero(x):
        return 1 / 0

    def str_to_int(x):
        return int(x)

    assert Try.of(inc, 0).map(div) == Try.of(div, 1)
    assert Try.of(inc, 10).map(div).map(pow) == Try.of(pow, 6)
    assert Try.of(inc, 10).map(div).map(div_by_zero) == Try.of(div_by_zero, 5)
    assert Try.of(str_to_int, '10').map(inc) == Try.of(inc, 10)

# Generated at 2022-06-21 19:23:16.229877
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Method __eq__ of class Try test.
    """
    def test(): pass

    assert Try(42, True) == Try(42, True)
    assert Try(42, False) == Try(42, False)
    assert Try(test, True) == Try(test, True)
    assert Try(test, False) == Try(test, False)
    assert Try(42, True) != Try(42, False)
    assert Try(test, True) != Try(test, False)
    assert Try(test, False) != Try(42, True)
    assert Try(test, True) != Try(42, False)
    assert Try(test, False) != Try(42, False)
    assert Try(42, True) != Try(test, True)
    assert Try(42, False) != Try(test, False)


# Generated at 2022-06-21 19:23:28.093657
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_1_success_on_success_should_do_something():
        actual = Try.of(lambda: 10, 1)
        expected = 10

        def check_actual_value(actual):
            assert actual == expected
        actual.on_success(check_actual_value)

    def test_1_fail_on_success_should_do_nothing():
        expected_message = 'Test'
        actual = Try.of(lambda: 1/0, 1)

        def check_actual_value(actual):
            assert actual == expected_message
        actual.on_success(check_actual_value)

    test_1_success_on_success_should_do_something()
    test_1_fail_on_success_should_do_nothing()


# Generated at 2022-06-21 19:23:30.329736
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert 'Try[value=1, is_success=True]' == Try(1, True).__str__()


# Generated at 2022-06-21 19:23:35.303039
# Unit test for constructor of class Try
def test_Try():
    true_try = Try(10, True)
    assert true_try.value == 10
    assert true_try.is_success is True

    false_try = Try(10, False)
    assert false_try.value == 10
    assert false_try.is_success is False
    assert not false_try


# Generated at 2022-06-21 19:23:44.641217
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test representation of on_fail method of Try class.
    """
    def fail_callback(e):
        print('error:', e)

    try_with_value = Try(10, True)
    try_with_error = Try(ZeroDivisionError('test'), False)

    try_with_value.on_fail(fail_callback)
    assert try_with_value == Try(10, True)

    try_with_error.on_fail(fail_callback)
    assert try_with_error == Try(ZeroDivisionError('test'), False)


# Generated at 2022-06-21 19:23:46.693629
# Unit test for method on_success of class Try
def test_Try_on_success():
    value = Try(True, True).on_success(print)
    assert value.is_success


# Generated at 2022-06-21 19:23:52.974462
# Unit test for method filter of class Try
def test_Try_filter():
    """ Unit test for method filter of class Try """
    assert Try(True, True).filter(lambda value: value)\
        == Try(True, True), 'first case with successful filter'
    assert Try(True, True).filter(lambda value: not value)\
        == Try(True, False), 'second case with successful filter'
    assert Try(False, False).filter(lambda value: not value)\
        == Try(False, False), 'third case with successful filter'


# Generated at 2022-06-21 19:23:57.443295
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 1).on_success(lambda x: x+1).value == 2
    assert Try.of(lambda: 1).on_success(lambda x: x+1) == Try(2, True)



# Generated at 2022-06-21 19:24:01.784936
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == "Try[value=1, is_success=True]"


# Generated at 2022-06-21 19:24:07.398369
# Unit test for method filter of class Try
def test_Try_filter():
    is_success = True
    value = 'hello'
    t = Try(value, is_success)
    assert t.filter(lambda x: True) == Try(value, True)
    assert t.filter(lambda x: False) == Try(value, False)
    is_success = False
    t = Try(value, is_success)
    assert t.filter(lambda x: True) == Try(value, False)
    assert t.filter(lambda x: False) == Try(value, False)

# Generated at 2022-06-21 19:24:14.389905
# Unit test for constructor of class Try
def test_Try():
    assert Try(3, True) == Try(3, True)
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(None, True)
    assert Try(None, True) != Try(3, False)
    assert Try(None, False) != Try(3, True)



# Generated at 2022-06-21 19:24:17.623161
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        1 / 0
    except ZeroDivisionError as e:
        tr = Try(e, False).on_fail(lambda val: True)
        assert tr.is_success == False


# Generated at 2022-06-21 19:24:23.351924
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 2).filter(lambda e: e % 2 == 0) == Try(2, True)
    assert Try.of(lambda: 3).filter(lambda e: e % 2 == 0) == Try(3, False)
    assert Try.of(lambda: 1 / 0).filter(lambda e: e % 2 == 0) == Try(ZeroDivisionError("division by zero"), False)


# Generated at 2022-06-21 19:24:29.417717
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(lambda x: x, 1)) == 'Try[value=1, is_success=True]'
    assert str(Try.of(lambda x: x / 0, 1)) == 'Try[value=ZeroDivisionError(), is_success=False]'


# Generated at 2022-06-21 19:24:30.713965
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)



# Generated at 2022-06-21 19:24:31.855174
# Unit test for method get of class Try
def test_Try_get():
    assert Try(123, True).get() == 123


# Generated at 2022-06-21 19:24:34.164457
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'


# Generated at 2022-06-21 19:24:38.257759
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_one = Try(1, True)
    try_two = Try(1, True)
    try_three = Try(1, False)
    try_four = Try(2, True)

    assert try_one == try_one
    assert try_one == try_two
    assert try_one != try_three
    assert try_one != try_four


# Generated at 2022-06-21 19:24:46.892259
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(None, True).filter(lambda x: x == True) == Try(None, False), 'Try simple filter test'
    assert Try(None, True).filter(lambda x: x == None) == Try(None, True), 'Try simple filter test'


# Generated at 2022-06-21 19:24:53.437113
# Unit test for method map of class Try
def test_Try_map():
    result = Try.of(lambda x: x * 2, 2)
    assert result == Try(4, True)
    assert result.value == 4
    assert result.is_success == True

    result = Try.of(lambda x: x / 0, 2)
    assert result == Try(ZeroDivisionError(), False)
    assert isinstance(result.value, ZeroDivisionError)
    assert result.is_success == False



# Generated at 2022-06-21 19:24:58.228786
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def raise_exception():
        raise Exception

    try_ = Try.of(raise_exception)

    assert isinstance(try_.on_fail(lambda x: 'exception'), Try)



# Generated at 2022-06-21 19:25:01.089966
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try(8, True).__str__() == 'Try[value=8, is_success=True]'
    assert Try(Exception('Some exception'), False).__str__() == 'Try[value=Some exception, is_success=False]'


# Generated at 2022-06-21 19:25:08.133977
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    """
    Test for method Try.__eq__

    :returns: None
    :rtype: None
    """
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False) == Try(1, False)


# Generated at 2022-06-21 19:25:16.572147
# Unit test for method filter of class Try
def test_Try_filter():
    """ Test filter method """

    value = lambda: 'try'
    error = lambda: Exception('failed')
    monad = Try.of(value).map(lambda x: x.upper()).filter(lambda x: len(x) == 3)
    assert monad == Try('TRY', True)
    monad = Try.of(value).map(lambda x: x.upper()).filter(lambda x: len(x) == 4)
    assert monad == Try('TRY', False)
    monad = Try.of(error)
    monad = monad.filter(lambda x: len(x.args[0]) == 5)
    assert monad == Try(Exception('failed'), False)

# Generated at 2022-06-21 19:25:18.354947
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-21 19:25:22.080951
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try.of(lambda x: x, 1) == Try.of(lambda x: x, 1)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-21 19:25:29.347340
# Unit test for method filter of class Try
def test_Try_filter():
    def remove_negative(number):
        return Try.of(lambda: number + 4).filter(lambda x: x > 4)

    assert remove_negative(2).is_success == False, \
        "remove_negative(2) should return Try monad with is_success: False"
    assert remove_negative(10).is_success == True, \
        "remove_negative(2) should return Try monad with is_success: True"
    assert remove_negative(10).get() == 14, \
        "remove_negative(2).get() should be 14"


# Generated at 2022-06-21 19:25:34.699457
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    mock = Mock()
    assert Try(1, True).on_fail(mock) == Try(1, True)
    mock.assert_not_called()

    assert Try(None, False).on_fail(mock) == Try(None, False)
    mock.assert_called_once()



# Generated at 2022-06-21 19:25:43.181915
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Unit test for method get_or_else of class Try

    """
    def divider(a, b):
        """ return a / b """
        return a / b

    assert Try(4, True).get_or_else(2) == 4
    assert Try(4, False).get_or_else(2) == 2
    assert Try.of(divider, 4, 2).get_or_else(0) == 2
    assert Try.of(divider, 4, 0).get_or_else(0) == 0


# Generated at 2022-06-21 19:25:44.944964
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10


# Generated at 2022-06-21 19:25:53.507114
# Unit test for method bind of class Try
def test_Try_bind():
    def divide_optional_int(numerator, denominator):
        try:
            return Try(numerator / denominator, True)
        except Exception as e:
            return Try(e, False)

    def div_by_three(n):
        return divide_optional_int(n, 3)

    def div_by_four(n):
        return divide_optional_int(n, 3)

    def div_by_twelve(n):
        return div_by_four(n).bind(div_by_three)

    assert div_by_four(1) == Try(0.3333333333333333, True)
    assert div_by_four(2) == Try(0.6666666666666666, True)
    assert div_by_four(3) == Try(1.0, True)
    assert div_by_

# Generated at 2022-06-21 19:25:56.881982
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) != Try(None, True)
    assert Try(None, True) != Try(None, False)


# Generated at 2022-06-21 19:26:06.289392
# Unit test for method filter of class Try
def test_Try_filter():
    try_with_value_10_is_success = Try(10, True)
    try_with_value_10_is_success_filtered = try_with_value_10_is_success.filter(lambda x: x == 10)

    try_with_value_10_is_not_success = Try(10, False)
    try_with_value_10_is_not_success_filtered = try_with_value_10_is_not_success.filter(lambda x: x == 10)

    assert try_with_value_10_is_success == try_with_value_10_is_success_filtered
    assert not try_with_value_10_is_success != try_with_value_10_is_success_filtered

    assert try_with_value_10_is_not_success != try_

# Generated at 2022-06-21 19:26:11.141484
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    default_value = 'default'
    assert Try(1, True).get_or_else(default_value) == 1
    assert Try(ValueError, False).get_or_else(default_value) == default_value


# Generated at 2022-06-21 19:26:20.987935
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, True) == Try(2, True)
    assert Try(Exception(), False) == Try(Exception(), False)
    assert not Try(Exception(), False) == Try(Exception(), True)
    assert Try(Exception(), False) == Try('Exception', False)
    assert not Try(Exception(), False) == Try('Exception', True)
    assert not Try(Exception(), False) == Try(Exception, False)
    assert not Try(Exception(), False) == Try(Exception, True)
    assert not Try(Exception(), False) == Try(1, False)

# Generated at 2022-06-21 19:26:22.875945
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)


# Generated at 2022-06-21 19:26:32.184250
# Unit test for method bind of class Try
def test_Try_bind():
    class Person:
        def __init__(self, age, name, surname) -> None:
            self.age = age
            self.name = name
            self.surname = surname

    def age_to_str(age):
        return str(age)

    def name_to_str(name):
        return str(name)

    def surname_to_str(surname):
        return str(surname)

    def person_to_str(person):
        return '{};{};{}'.format(
            person.age,
            person.name,
            person.surname
        )

    # test step 1
    monad_age = Try.of(lambda: 1)

    # test step 2

# Generated at 2022-06-21 19:26:40.132075
# Unit test for method map of class Try
def test_Try_map():
    def abc(arg):  # type: (int) -> str
        return str(arg)

    cases = {
        'ok': [Try(123, True), Try('123', True)],
        'fail': [Try(123, False), Try(123, False)],
    }

    for case, results in cases.items():
        input, result = results
        print('case = {}, input = {}, result = {}'.format(case, input, result))
        assert input.map(abc) == result



# Generated at 2022-06-21 19:26:51.027188
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    Test get_or_else method from class Try.

    :returns: None
    :rtype: None
    """
    success_try = Try(1, True)
    assert success_try.get_or_else(2) == 1

    fail_try = Try(1, False)
    assert fail_try.get_or_else(2) == 2


# Generated at 2022-06-21 19:27:01.700533
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    first_try = Try(1, True)
    second_try = Try(1, True)
    assert (first_try == second_try)

    first_try = Try(1, True)
    second_try = Try(2, True)
    assert (first_try != second_try)

    first_try = Try(1, False)
    second_try = Try(1, False)
    assert (first_try == second_try)

    first_try = Try(1, False)
    second_try = Try(2, False)
    assert (first_try != second_try)

    first_try = Try(1, True)
    second_try = Try(1, False)
    assert (first_try != second_try)



# Generated at 2022-06-21 19:27:11.401369
# Unit test for constructor of class Try
def test_Try():
    value = 'foo'
    try_true = Try(value, True)
    assert try_true.value == value
    assert try_true.is_success == True
    try_false = Try(value, False)
    assert try_false.value == value
    assert try_false.is_success == False
    value = 42
    try_true = Try(value, True)
    assert try_true.value == value
    assert try_true.is_success == True
    try_false = Try(value, False)
    assert try_false.value == value
    assert try_false.is_success == False
    value = '42'
    try_true = Try(value, True)
    assert try_true.value == value
    assert try_true.is_success == True

# Generated at 2022-06-21 19:27:15.485653
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    import random
    success_value = random.randint(0, 100)
    success_try = Try(success_value, True)
    fail_value = random.randint(0, 100)
    fail_try = Try(fail_value, False)
    assert success_try == success_try
    assert fail_try == fail_try


# Generated at 2022-06-21 19:27:18.119322
# Unit test for method on_success of class Try
def test_Try_on_success():

    def run_on_success():
        side_effect_arg = None

        def side_effect(arg):
            nonlocal side_effect_arg
            side_effect_arg = arg

        Try("1", True).on_success(side_effect)
        return side_effect_arg

    assert run_on_success() == "1"



# Generated at 2022-06-21 19:27:20.722071
# Unit test for method map of class Try
def test_Try_map():
    assert Try(5, True).map(lambda x: x * 2 - 1) == Try(9, True)
    assert Try(5, True).map(lambda x: x / 0) == Try(ZeroDivisionError('division by zero'), False)
    assert Try(ZeroDivisionError('division by zero'), False).map(lambda x: x * 2 - 1) == Try(ZeroDivisionError('division by zero'), False)



# Generated at 2022-06-21 19:27:26.621779
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    try_1 = Try(5, True)
    try_2 = Try(5, True)
    assert try_1 == try_2, '__eq__ method of Try class error'
    assert not try_1 == 5, '__eq__ method of Try class error'



# Generated at 2022-06-21 19:27:30.977025
# Unit test for method bind of class Try
def test_Try_bind():
    # Test 1
    assert Try(1, True)\
        .bind(lambda value: Try(value + 1, True))\
        == Try(2, True)
    # Test 2
    assert Try(1, False)\
        .bind(lambda value: Try(value + 1, True))\
        == Try(1, False)


# Generated at 2022-06-21 19:27:36.155030
# Unit test for method bind of class Try
def test_Try_bind():  # pragma: no cover
    from random import choice

    def test(value):
        if value % 2 == 0:
            return Try(value, True)
        return Try(value, False)

    values = list(range(0, 100))
    value = choice(values)
    try_ = Try.of(lambda v: v + 1, value)
    try_ = try_.bind(test)
    assert try_.is_success == (True if value % 2 == 0 else False)
    assert try_.value == (value + 1 if value % 2 == 0 else value)



# Generated at 2022-06-21 19:27:40.436906
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 10).on_success(lambda x: print(str(x))) == Try(10, True)
    assert Try.of(lambda: 10/0).on_success(lambda x: print(str(x))) == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-21 19:27:55.380799
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(exception):
        fail_exception.append(exception)
        pass

    def success_callback(value):
        success_value.append(value)
        pass

    fail_exception = []
    success_value = []
    exc = Exception()

    Try.of(lambda: 1).on_success(success_callback).on_fail(fail_callback)

    Try.of(lambda: 1/0).on_success(success_callback).on_fail(fail_callback)

    assert(success_value == [1])
    assert(fail_exception == [ZeroDivisionError()])

# Generated at 2022-06-21 19:28:06.829198
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Unit test for method bind of class Try

    :returns: True value if test is passed.
    :rtype: Boolean
    """
    print("test method bind of class Try")
    test_is_passed = True

    def add_one(number):
        return number + 1

    def div_five(number):
        if number is None:
            return None
        if number % 5 == 0:
            return Try(number / 5, True)
        return Try(None, False)

    try:
        assert Try(3, True).bind(add_one).bind(div_five) == Try(1, True)
        assert Try(None, True).bind(add_one).bind(div_five) == Try(None, False)
    except:
        test_is_passed = False

# Generated at 2022-06-21 19:28:09.084789
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(10, True)
    assert str(try_) == 'Try[value=10, is_success=True]'


# Generated at 2022-06-21 19:28:15.794821
# Unit test for constructor of class Try
def test_Try():
    success_try = Try(1, True)
    assert success_try.value == 1
    assert success_try.is_success is True

    fail_try = Try('exception', False)
    assert fail_try.value == 'exception'
    assert fail_try.is_success is False

    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-21 19:28:24.712298
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(None, True).on_fail(lambda x: x) == Try(None, True)
    assert Try(None, False).on_fail(lambda x: x) == Try(None, False)
    assert Try(0, True).on_fail(lambda x: x) == Try(0, True)
    assert Try(0, False).on_fail(lambda x: x) == Try(0, False)
    assert Try(1, True).on_fail(lambda x: x) == Try(1, True)
    assert Try(1, False).on_fail(lambda x: x) == Try(1, False)



# Generated at 2022-06-21 19:28:35.871150
# Unit test for method bind of class Try
def test_Try_bind():
    # GIVEN
    # Two Try: unsuccessfully and successfully
    unsuccessfully_try = Try(ZeroDivisionError('Division by zero'), False)
    successfully_try = Try(10, True)
    # Function that create new Try with value of old Try, when old Try is successfully
    def new_value_try(value):
        return Try(value+1, True)
    # Function that returns unsuccessfully Try with value of old Try, when old Try is not successfully
    def new_error_try(value):
        return Try(value, False)

    # WHEN
    # New Try created with bind method of unsuccessfully and successfully Try
    unsuccessfully_try_bind_new_value_try = unsuccessfully_try.bind(new_value_try)
    successfully_try_bind_new_value_try = successfully_try.bind(new_value_try)
   

# Generated at 2022-06-21 19:28:42.925607
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(None, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(None, False)
    assert Try(None, True) != Try(None, False)
    assert Try(1, False) == Try(1, False)
    assert Try(None, False) == Try(None, False)


# Generated at 2022-06-21 19:28:51.849541
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_eq_true = Try(1, True)
    try_eq_false = Try(1, False)
    try_eq_true_2 = Try(1, True)
    try_eq_false_2 = Try(1, False)
    try_eq_false_3 = Try(2, False)

    assert try_eq_true == try_eq_true_2
    assert try_eq_false == try_eq_false_2
    assert try_eq_false != try_eq_true
    assert try_eq_false_2 != try_eq_false_3


# Generated at 2022-06-21 19:28:58.285484
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(x: int) -> bool:
        return x > 1

    assert Try(0, True).filter(filterer) == Try(0, False)
    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, False).filter(filterer) == Try(2, False)
    assert Try(3, True).filter(filterer) == Try(3, True)

# Generated at 2022-06-21 19:29:00.621912
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(99, True).get() == 99
    assert Try(0, False).get() == 0


# Generated at 2022-06-21 19:29:21.111148
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    print('Test method get of class Try')
    expected = 'TEST'
    result = Try('TEST', True).get()
    assert result == expected, "Expected {}, got {}".format(expected, result)
    print('test_Try_get passed')


# Generated at 2022-06-21 19:29:25.434684
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(lambda: 1, None)) == 'Try[value=1, is_success=True]'
    assert str(Try.of(lambda: 1 / 0, None)) == 'Try[value=division by zero, is_success=False]'


# Generated at 2022-06-21 19:29:30.953792
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, True) == Try(Exception, True)
    assert not Try(1, True) == Try(1, True).get()


# Generated at 2022-06-21 19:29:38.533391
# Unit test for method filter of class Try
def test_Try_filter():
    def predicate(value):
        return True

    def fake_predicate(value):
        return False

    assert Try(None, False) == Try(None, False).filter(predicate)
    assert Try(None, True) == Try(None, True).filter(predicate)
    assert Try(None, True) != Try(None, True).filter(fake_predicate)
    assert Try(None, False) == Try(None, True).filter(fake_predicate)

# Generated at 2022-06-21 19:29:41.573082
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(10, True) == Try(10, True)
    assert Try(10, False) == Try(10, False)
    assert Try(10, False) != Try(10, True)


# Generated at 2022-06-21 19:29:46.393557
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda a: a, 1).get_or_else(0) == 1
    assert Try.of(lambda a: a, 0).get_or_else(1) == 0
    assert Try.of(lambda a: 1/0, 0).get_or_else(1) == 1


# Generated at 2022-06-21 19:29:54.109186
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # Given
    value = 5
    test_try = Try(value, True)
    exception = Exception()
    exception_try = Try(exception, False)
    function = lambda e: e == exception

    # When
    test_try.on_fail(function)
    exception_try.on_fail(function)

    # Then
    assert test_try.value == value
    assert test_try.is_success
    assert exception_try.value == exception
    assert not exception_try.is_success


# Generated at 2022-06-21 19:29:58.918801
# Unit test for method on_success of class Try
def test_Try_on_success():
    def assert_try_on_success(value, expected_value) -> None:
        assert Try(value, True).on_success(lambda x: assertEqual(x, expected_value)).value == value

    assert_try_on_success(1, 1)
    assert_try_on_success([], [])


# Generated at 2022-06-21 19:30:01.906717
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_object = Try(1, True)
    assert str(try_object) == 'Try[value=1, is_success=True]'



# Generated at 2022-06-21 19:30:06.316708
# Unit test for method bind of class Try
def test_Try_bind():
    def f(x):
        return Try.of(lambda: x ** 2, x)

    def g(x):
        return Try.of(lambda: x + 1, x)

    assert Try(2, True).bind(f).bind(g) == Try(5, True)



# Generated at 2022-06-21 19:30:45.654350
# Unit test for method get of class Try
def test_Try_get():
    t = Try(5, True)
    assert 5 == t.get()

    t = Try(None, True)
    assert None == t.get()

    t = Try(5, False)
    assert 5 == t.get()

    t = Try(None, False)
    assert None == t.get()


# Generated at 2022-06-21 19:30:54.408167
# Unit test for method __str__ of class Try
def test_Try___str__():
    # GIVEN
    successfull_try = Try(42, True)
    fail_try = Try(Exception, False)

    # WHEN
    successfull_result = successfull_try.__str__()
    fail_result = fail_try.__str__()

    # THEN
    assert successfull_result == 'Try[value=42, is_success=True]'
    assert fail_result == 'Try[value=Exception, is_success=False]'
