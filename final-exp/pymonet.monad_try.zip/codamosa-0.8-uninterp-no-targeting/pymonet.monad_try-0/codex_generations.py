

# Generated at 2022-06-21 19:20:55.022470
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def raise_exception(x):
        raise Exception(x)

    result = Try.of(raise_exception, 'something happend').on_fail(lambda e: print(e))
    assert result.value == 'something happend' and not result.is_success

# Generated at 2022-06-21 19:20:57.993957
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(2, True)) == 'Try[value=2, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'


# Generated at 2022-06-21 19:21:05.092443
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_success = Try(5, True)
    try_failure = Try(5, False)
    try_another_failure = Try(4, False)
    try_another_success = Try(4, True)

    assert try_success == try_success
    assert not try_success == try_failure
    assert not try_success == try_another_failure
    assert not try_success == try_another_success



# Generated at 2022-06-21 19:21:10.903602
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of Try monad class.
    """
    assert Try(None, True).filter(lambda _: True) == Try(None, True)
    assert Try(None, True).filter(lambda _: False) == Try(None, False)
    assert Try(None, False).filter(lambda _: True) == Try(None, False)
    assert Try(None, False).filter(lambda _: False) == Try(None, False)



# Generated at 2022-06-21 19:21:15.849539
# Unit test for constructor of class Try
def test_Try():
    success = Try(1, True)
    fail = Try('test', False)

    assert success.value == 1
    assert success.is_success

    assert fail.value == 'test'
    assert not fail.is_success


# Generated at 2022-06-21 19:21:20.640792
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda: 10).map(lambda x: x + 10) == Try(20, True)
    assert Try.of(lambda: 10).map(lambda: 2 / 0) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:21:24.159431
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def assert_not_called(*args):
        assert False

    def assert_call_with_raise_exception(e):
        assert e == ValueError('foo')

    def assert_call_with_value(value):
        assert value == 1

    Try.of(lambda: 1).on_fail(assert_not_called).on_success(assert_call_with_value)
    Try.of(lambda: 1/0).on_fail(assert_call_with_raise_exception).on_success(assert_not_called)


# Generated at 2022-06-21 19:21:29.564960
# Unit test for method on_fail of class Try

# Generated at 2022-06-21 19:21:34.996164
# Unit test for method map of class Try
def test_Try_map():
    assert Try(4, True).map(lambda x: x ** 2) == Try(16, True)
    assert Try(-4, True).map(lambda x: x ** 2) == Try(16, True)
    assert Try(None, False).map(lambda x: x ** 2) == Try(None, False)


# Generated at 2022-06-21 19:21:39.214750
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try('a', False).map(lambda x: x + 'b') == Try('a', False)
    assert Try('a', True).map(lambda x: x + 'b') == Try('ab', True)


# Generated at 2022-06-21 19:21:44.672984
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(100, True).get_or_else(200) == 100
    assert Try(100, False).get_or_else(200) == 200

# Generated at 2022-06-21 19:21:50.004079
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(5, True).get_or_else(4) == 5
    assert Try(-5, True).get_or_else(4) == -5
    assert Try(5, False).get_or_else(4) == 4
    assert Try(-5, False).get_or_else(4) == 4

# Generated at 2022-06-21 19:21:53.229931
# Unit test for method bind of class Try
def test_Try_bind():
    def add_one(val):
        return Try.of(lambda: val + 1, 0)

    try_ = Try.of(lambda: 2, 0)
    assert try_.bind(add_one) == Try(3, True)



# Generated at 2022-06-21 19:21:56.963758
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda x: x, 5).map(lambda x: x + 1) == Try(6, True)
    assert Try.of(lambda x: x, '5').map(lambda x: x + 1) is None


# Generated at 2022-06-21 19:22:00.359482
# Unit test for method on_success of class Try
def test_Try_on_success():
    def func(a):
        print(a)
    a = Try.of(int, '1').on_success(func)
    assert a.value == 1
    assert a.is_success
    a = Try.of(int, 'f').on_success(func)
    assert a.value == 'f'
    assert not a.is_success


# Generated at 2022-06-21 19:22:02.323246
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-21 19:22:06.945694
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    >>> t = Try(5, True)
    >>> t.on_success(lambda v: print(v))
    5

    >>> t = Try('SomeError', False)
    >>> t.on_success(lambda v: print(v))
    """



# Generated at 2022-06-21 19:22:12.987396
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    """
    Test for constructor of class Try.
    """

    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)


# Generated at 2022-06-21 19:22:18.400143
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)

    def raise_exception():
        raise ValueError('Foo')

    assert Try(1, True).map(lambda x: raise_exception()) == Try(1, True)
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-21 19:22:29.144457
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    TestTryOnFail.
    """
    binder_called = False
    binder = lambda v: Try(v, True)
    try_success = Try.of(lambda a: a, 1)
    try_fail = Try.of(lambda a: a / 0, 1)
    try_success.bind(binder).map(lambda a: a + 1).on_fail(lambda v: setattr(v, 'binder_called', True))
    assert not hasattr(try_success.value, 'binder_called')
    try_fail.bind(binder).map(lambda a: a + 1).on_fail(lambda v: setattr(v, 'binder_called', True))
    assert hasattr(try_fail.value, 'binder_called')


# Generated at 2022-06-21 19:22:40.013718
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    is_exception = False
    error_value = None

# Generated at 2022-06-21 19:22:43.610490
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try(42, True).__str__() == 'Try[value=42, is_success=True]'
#

# Generated at 2022-06-21 19:22:49.556829
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(value):
        value.append(1)

    assert Try(None, False).on_fail(fail_callback) == Try(None, False)
    assert Try(1, True).on_fail(fail_callback) == Try(1, True)
    assert Try([], False).on_fail(fail_callback) == Try([1], False)


# Generated at 2022-06-21 19:22:54.638732
# Unit test for method map of class Try
def test_Try_map():
    def add_one(x):
        return x + 1
    assert Try.of(1, None).map(add_one) == Try(2, True)  # Mapping on successfully monad
    assert Try.of(ValueError("error"), Exception).map(add_one) == Try(ValueError("error"), False)  # Mapping on not successfully monad


# Generated at 2022-06-21 19:22:59.240424
# Unit test for method on_success of class Try
def test_Try_on_success():
    actual = Try(10, True)
    expected = Try(None, False)

    success_counter = 0

    def success_handler(value):
        nonlocal success_counter
        success_counter += value

    actual.on_success(success_handler)
    actual.on_success(success_handler)

    expected.on_success(success_handler)

    assert success_counter == 20
    assert expected == actual


# Generated at 2022-06-21 19:23:03.689369
# Unit test for method filter of class Try
def test_Try_filter():
    try_success = Try(5, True)
    try_fail = Try(5, False)
    assert try_success.filter(lambda x: x > 2) == Try(5, True)
    assert try_success.filter(lambda x: x < 2) == Try(5, False)
    assert try_fail.filter(lambda x: x > 2) == Try(5, False)
    assert try_fail.filter(lambda x: x < 2) == Try(5, False)


# Generated at 2022-06-21 19:23:08.821366
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(message):
        print(message)

    Try(2, True).on_fail(fail_callback)
    Try(Exception("It is error!"), False).on_fail(fail_callback)


if __name__ == '__main__':
    test_Try_on_fail()

# Generated at 2022-06-21 19:23:11.214731
# Unit test for method get of class Try
def test_Try_get():
    assert(Try(3, True).get() == 3)
    assert(Try(ZeroDivisionError, False).get() == ZeroDivisionError)



# Generated at 2022-06-21 19:23:12.622489
# Unit test for method on_success of class Try

# Generated at 2022-06-21 19:23:14.514227
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(None, False).get() == None


# Generated at 2022-06-21 19:23:24.702311
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    try_1 = Try('Hello', True)

# Generated at 2022-06-21 19:23:29.756800
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(42, True).get_or_else(0) == 42
    assert Try('foo', True).get_or_else('') == 'foo'
    assert Try(42, False).get_or_else(0) == 0
    assert Try('foo', False).get_or_else('') == ''


# Generated at 2022-06-21 19:23:31.853897
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == "Try[value=1, is_success=True]"


# Generated at 2022-06-21 19:23:37.149356
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Given
    default = 'default'
    success = Try('success', True)
    fail = Try('fail', False)

    # When & Then
    assert success.get_or_else(default) == 'success'
    assert fail.get_or_else(default) == 'default'


# Generated at 2022-06-21 19:23:45.349301
# Unit test for constructor of class Try
def test_Try():
    try1 = Try(1, True)
    try2 = Try(1, False)
    try3 = Try(2, True)
    try4 = Try(2, False)

    assert try1 == try1
    assert try2 == try2
    assert try3 == try3
    assert try4 == try4

    assert try1 != try2
    assert try1 != try3
    assert try1 != try4
    assert try2 != try3
    assert try2 != try4
    assert try3 != try4


# Generated at 2022-06-21 19:23:48.445175
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(1) == 1
    assert Try(None, False).get_or_else(1) == 1


# Generated at 2022-06-21 19:23:52.450647
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    value = 'Just try'
    assert Try(value, True).map(lambda v: v.lower()) == Try(value.lower(), True)
    assert Try(value, False).map(lambda v: v.lower()) == Try(value, False)


# Generated at 2022-06-21 19:24:00.359826
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(10, True).bind(lambda x: Try('Successfully', True)) == Try('Successfully', True)
    assert Try(10, True).bind(lambda x: Try('Successfully', False)) == Try('Successfully', False)
    assert Try(10, False).bind(lambda x: Try('Successfully', True)) == Try(10, False)
    assert Try(10, False).bind(lambda x: Try('Successfully', False)) == Try(10, False)



# Generated at 2022-06-21 19:24:06.988912
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, False)
    assert Try(1, False) != Try(2, True)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)


# Generated at 2022-06-21 19:24:17.317562
# Unit test for method map of class Try
def test_Try_map():
    """
    Testing method map of class Try.

    :rtype: None
    """
    # Test successfully case and map function
    t: Try[int] = Try.of(lambda x: x**2, 2)
    t2: Try[int] = t.map(lambda x: x/2)
    assert isinstance(t2, Try)
    assert t2.is_success == True
    assert t2.get() == 1

    # Test successfully case and map function
    t: Try[str] = Try.of(int, '10')
    t2: Try[int] = t.map(lambda x: x/2)
    assert isinstance(t2, Try)
    assert t2.is_success == True
    assert t2.get() == 5

    # Test not successfully case and mapping not applied
    t

# Generated at 2022-06-21 19:24:32.436030
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(x):
        if x % 2 == 0:
            return Try(x, True)
        return Try('{} is odd'.format(x), False)

    # successful bind
    assert Try.of(lambda x: x, 4).bind(binder) == Try(4, True)

    # unsuccessful bind
    assert Try.of(lambda x: x, 5).bind(binder) == Try('5 is odd', False)



# Generated at 2022-06-21 19:24:37.938474
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        assert value == 'success'

    def fail_callback(value):
        assert False

    try_success = Try.of(lambda: 'success', None)
    try_fail = Try.of(lambda: 1 / 0, None)
    try_success.on_success(success_callback)
    try_fail.on_success(fail_callback)


# Generated at 2022-06-21 19:24:41.528845
# Unit test for method map of class Try
def test_Try_map():
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True)
    assert Try(1, True).map(lambda x: 1 / x) == Try(1, False)
    assert Try(1, False).map(lambda x: 1 / x) == Try(1, False)



# Generated at 2022-06-21 19:24:47.856920
# Unit test for method map of class Try
def test_Try_map():
    try_success_mapped = Try.of(lambda: 10).map(lambda i: i * 2)
    assert Try(20, True) == try_success_mapped

    try_fail_mapped = Try(ValueError('Some error'), False).map(lambda i: i * 2)
    assert Try(ValueError('Some error'), False) == try_fail_mapped


# Generated at 2022-06-21 19:24:58.080490
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert_is_instance(Try(None, False).on_fail(lambda _: None), Try)
    assert_is_instance(Try(None, True).on_fail(lambda _: None), Try)
    assert_is_instance(Try(None, False).on_fail(lambda _: None), Try)

    def side_effect(value):
        side_effect.called = True
        side_effect.value = value

    side_effect.called = False
    side_effect.value = None

    assert_equal(Try(None, False).on_fail(side_effect), Try(None, False))
    assert_true(side_effect.called)
    assert_equal(Try(None, True).on_fail(side_effect), Try(None, True))
    assert_false(side_effect.called)
    assert_

# Generated at 2022-06-21 19:25:00.984340
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda x: x, 1).get_or_else(0) == 1
    assert Try.of(lambda x: x/0, 1).get_or_else(0) == 0


# Generated at 2022-06-21 19:25:02.772818
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1/0, None) \
        .bind(lambda value: Try(5, True)) \
        == Try(5, False)



# Generated at 2022-06-21 19:25:10.252284
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert Try(1, True).__str__() == 'Try[value=1, is_success=True]'
    assert Try(1, False).__str__() == 'Try[value=1, is_success=False]'
    assert Try('test', True).__str__() == 'Try[value=test, is_success=True]'
    assert Try('test', False).__str__() == 'Try[value=test, is_success=False]'


# Generated at 2022-06-21 19:25:13.319837
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try('test', True).get_or_else('or else value') == 'test'
    assert Try('test', False).get_or_else('or else value') == 'or else value'



# Generated at 2022-06-21 19:25:16.657068
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda x: x + 1, 5).map(lambda x: x + 1) == Try(7, True)
    assert Try.of(lambda x: x + 1, 5).map(lambda x: 1 / 0) == Try(0, False)



# Generated at 2022-06-21 19:25:48.062239
# Unit test for method filter of class Try
def test_Try_filter():

    # Assertion on single filter
    def filter_positive(value):
        return value > 0
    assert Try.of(lambda x: x - 1, 1).filter(filter_positive) == Try(0, True)
    assert Try.of(lambda x: x / 0, 1).filter(filter_positive) == Try(ZeroDivisionError('division by zero'), False)

    # Assertion on filter chain
    filter_chain = filter_positive\
        .and_then(lambda x: x >= 0 and x < 10)
    assert Try.of(lambda x: int(x), '1').filter(filter_chain) == Try(1, True)

# Generated at 2022-06-21 19:25:52.549222
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1 + 2).bind(lambda x: Try(x + 1, True)) == Try(4, True)
    assert Try.of(lambda: 1 + '2').bind(lambda x: Try(x + 1, True)) == Try('2', False)



# Generated at 2022-06-21 19:25:56.000508
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try('a', True) == Try('a', True)
    assert Try('a', True) != Try('b', True)
    assert Try('a', True) != Try('a', False)
    assert Try('a', False) != Try('b', False)


# Generated at 2022-06-21 19:25:57.538215
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1


# Generated at 2022-06-21 19:26:04.576880
# Unit test for method map of class Try
def test_Try_map():
    def succ_fn(value):
        return value + 2
    def fail_fn(value):
        raise ValueError('Fail')

    # Successfully
    assert Try.of(succ_fn, 1).map(succ_fn) == Try(3, True)
    assert Try.of(succ_fn, 1).map(fail_fn) == Try(ValueError('Fail'), False)
    # Not successfully
    assert Try.of(fail_fn, 1).map(succ_fn) == Try(ValueError('Fail'), False)
    assert Try.of(fail_fn, 1).map(fail_fn) == Try(ValueError('Fail'), False)


# Generated at 2022-06-21 19:26:09.035319
# Unit test for method get of class Try
def test_Try_get():
    assert Try('test', False).get() == Try('test', True).get()
    assert Try('test', False).get() == 'test'
    assert Try(1, False).get() == 1



# Generated at 2022-06-21 19:26:20.088152
# Unit test for method get of class Try
def test_Try_get():
    # not successfully case
    assert Try(1, False).get() == 1
    assert Try(1.0, False).get() == 1.0
    assert Try('1', False).get() == '1'
    assert Try([1], False).get() == [1]
    assert Try({'1': 1}, False).get() == {'1': 1}

    # successfully case
    assert Try(1, True).get() == 1
    assert Try(1.0, True).get() == 1.0
    assert Try('1', True).get() == '1'
    assert Try([1], True).get() == [1]
    assert Try({'1': 1}, True).get() == {'1': 1}



# Generated at 2022-06-21 19:26:23.717401
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(2, True).value == 2
    assert Try(2, True).is_success == True
    assert Try(1, False).value == 1
    assert Try(1, False).is_success == False


# Generated at 2022-06-21 19:26:27.026111
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    a = Try.of(lambda: 1 / 0, None)
    assert a.get_or_else('NaN') == 'NaN'
    a = Try(1, True)
    assert a.get_or_else('NaN') == 1



# Generated at 2022-06-21 19:26:33.217173
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try("successful", False)) == "Try[value=successful, is_success=False]"
    assert str(Try("successful", True)) == "Try[value=successful, is_success=True]"
    assert str(Try(1, False)) == "Try[value=1, is_success=False]"
    assert str(Try(1, True)) == "Try[value=1, is_success=True]"


# Generated at 2022-06-21 19:27:16.444220
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(lambda: 5/0, False).on_success(print) == Try(ZeroDivisionError(), False)
    assert Try(5/5, True).on_success(print) == Try(1, True)

# Generated at 2022-06-21 19:27:21.052765
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, True) == Try(2, True)
    assert not Try(1, True) == Try(2, False)
    assert Try(1, False) == Try(1, False)
    assert not Try(1, False) == Try(2, False)


# Generated at 2022-06-21 19:27:30.132721
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Test for successful Try
    try_monad = Try(1, True)
    assert try_monad.get_or_else(-1) == 1

    try_monad = Try(0, True)
    assert try_monad.get_or_else(-1) == 0

    # Test for not successful Try
    try_monad = Try(1, False)
    assert try_monad.get_or_else(-1) == -1

    try_monad = Try(0, False)
    assert try_monad.get_or_else(-1) == -1


# Generated at 2022-06-21 19:27:33.114723
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, False) == Try(1, False)
    assert Try(1, False) != Try(2, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) == Try(1, True)



# Generated at 2022-06-21 19:27:41.067524
# Unit test for method bind of class Try
def test_Try_bind():
    def binder1(x: int) -> Try[int]:
        if x < 10:
            return Try(x, True)
        else:
            return Try(x, False)

    assert Try.of(binder1, 1) == Try(Try(1, True), True)
    assert Try.of(binder1, 10) == Try(Try(10, False), True)
    assert Try.of(binder1, 10) == Try(10, False)

# Generated at 2022-06-21 19:27:47.092382
# Unit test for method map of class Try
def test_Try_map():
    success_try = Try.of(lambda: 'test-value', (None,))
    assert success_try.is_success == True
    assert success_try.value == 'test-value'

    mapped_try = success_try.map(lambda s: s.upper())
    assert mapped_try.is_success == True
    assert mapped_try.value == 'TEST-VALUE'

    other_mapped_try = mapped_try.map(lambda s: s.lower())
    assert other_mapped_try.is_success == True
    assert other_mapped_try.value == 'test-value'


# Generated at 2022-06-21 19:27:52.329145
# Unit test for method __str__ of class Try
def test_Try___str__():
    try_ = Try(1, True)
    assert str(try_) == 'Try[value=1, is_success=True]'
    try_ = Try(Exception('test exception'), False)
    assert str(try_) == "Try[value=test exception, is_success=False]"



# Generated at 2022-06-21 19:28:04.028366
# Unit test for method __eq__ of class Try
def test_Try___eq__():  # pragma: no cover
    try_ = Try(1, True)
    assert try_ == Try(1, True)

    try_ = Try(1, False)
    assert try_ == Try(1, False)

    try_ = Try(1, True)
    assert not try_ == Try(1, False)

    try_ = Try(2, True)
    assert not try_ == Try(1, True)

    try_ = Try(1, False)
    assert not try_ == Try(2, False)

    try_ = Try(3, True)
    assert not try_ == Try(2, False)

    try_ = Try(4, False)
    assert not try_ == Try(3, True)


# Generated at 2022-06-21 19:28:08.627981
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try.of(lambda: 1, None).get() == 1
    assert Try.of(lambda: 2 / 0, None).get() == ZeroDivisionError('division by zero')



# Generated at 2022-06-21 19:28:12.777881
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Test method on_success.

    :returns: None
    """

# Generated at 2022-06-21 19:28:54.742646
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_success_callback(value):
        assert value == 1
    def test_fail_callback(value):
        assert False
    def mock_fn():
        return 1
    assert Try.of(mock_fn).on_success(test_success_callback) \
        == Try(1, True).on_success(test_success_callback)
    assert Try.of(mock_fn).on_fail(test_fail_callback) \
        == Try(1, True).on_fail(test_fail_callback)


# Generated at 2022-06-21 19:28:58.199586
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    """
    >>> test_Try_get_or_else()
    1
    """
    print(Try.of(int, '1').get_or_else(0))



# Generated at 2022-06-21 19:29:02.308783
# Unit test for method on_success of class Try
def test_Try_on_success():
    # given
    success_try = Try(2, True)
    fail_try = Try(RuntimeError, False)

    # when
    success_try.on_success(lambda value: print(value))
    fail_try.on_success(lambda value: print(value))

    # then
    assert success_try == Try(2, True)
    assert fail_try == Try(RuntimeError, False)



# Generated at 2022-06-21 19:29:04.867208
# Unit test for method __str__ of class Try
def test_Try___str__():
    res = Try(1, True)
    assert str(res) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-21 19:29:09.328371
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)


# Generated at 2022-06-21 19:29:12.681145
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_value = Try(1, False)
    assert try_value.get_or_else(0) == 0
    try_value = Try(1, True)
    assert try_value.get_or_else(0) == 1


# Generated at 2022-06-21 19:29:15.338032
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    s = Try(1, True)
    assert s.get_or_else(0) == 1

    f = Try(0, False)
    assert f.get_or_else(1) == 1


# Generated at 2022-06-21 19:29:20.925799
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test for method on_fail of class Try.

    :return: nothing
    """
    class MyException(Exception):
        pass

    def fail_callback(value):
        assert isinstance(value, MyException)

    # testing when monad is successfully

# Generated at 2022-06-21 19:29:31.533552
# Unit test for method map of class Try
def test_Try_map():
    from random import uniform

    def _map_func(num: float) -> float:
        return num * uniform(0.7, 2)

    def _bad_fn() -> Try:
        raise Exception('Error')

    def _map_fn():
        return Try.of(_bad_fn).map(_map_func)

    def _map_fn2():
        return Try.of(lambda: uniform(1, 10)).map(_map_func)

    assert Try.of(_map_fn) == Try(_map_fn().get(), False)
    assert _map_fn2().is_success
    assert isinstance(_map_fn2().get(), float)
    assert Try.of(_map_fn2).get() == _map_fn2().get()



# Generated at 2022-06-21 19:29:36.807713
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)


# Generated at 2022-06-21 19:30:17.529988
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True).value == 1
    assert Try(1, True).is_success == True
    assert Try(1, False).value == 1
    assert Try(1, False).is_success == False


# Generated at 2022-06-21 19:30:22.970785
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    a = Try(1, True)
    b = Try(2, True)
    c = Try(1, True)
    d = Try(1, False)
    e = Try(2, False)
    f = Try(1, False)
    g = Try('a', True)

    assert a == c
    assert a != b
    assert d == f
    assert d != e
    assert a != g

# Generated at 2022-06-21 19:30:26.993525
# Unit test for method on_fail of class Try

# Generated at 2022-06-21 19:30:32.614173
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def test(value):
        print('Test: on_fail with value: ' + str(value))

    result = Try(None, True).on_fail(test)
    assert result == Try(None, True)

    result = Try(None, False).on_fail(test)
    assert result == Try(None, False)



# Generated at 2022-06-21 19:30:39.811295
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test method filter of class Try.
    """
    from hamcrest import assert_that, equal_to

    try_value = Try(0, True)
    assert_that(try_value.filter(lambda x: x == 0), equal_to(Try(0, True)))
    assert_that(try_value.filter(lambda x: x == 1), equal_to(Try(0, False)))



# Generated at 2022-06-21 19:30:45.293279
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Unit test for method __str__ of class Try.
    """
    try_success = Try(2, True)
    assert str(try_success) == 'Try[value=2, is_success=True]'
    try_fail = Try(ValueError, False)
    assert str(try_fail) == 'Try[value=ValueError, is_success=False]'
