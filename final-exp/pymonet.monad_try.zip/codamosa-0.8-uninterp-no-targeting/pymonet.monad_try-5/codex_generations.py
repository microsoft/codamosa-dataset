

# Generated at 2022-06-21 19:20:48.767001
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(7, True).bind(lambda v: Try(v + 1, True)) == Try(8, True)
    assert Try(7, True).bind(lambda v: Try(v + 1, False)) == Try(7, True)
    assert Try(7, False).bind(lambda v: Try(1, True)) == Try(7, False)
    assert Try(8, False).bind(lambda v: Try(1, False)) == Try(8, False)


# Generated at 2022-06-21 19:20:59.290216
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value == 'test'

    def filterer_throw(value):
        raise Exception('test')

    try_monad = Try(None, True)\
        .filter(filterer)\
        .filter(filterer_throw)
    assert try_monad == Try(None, False)

    try_monad = Try(None, True)\
        .filter(filterer)\
        .filter(filterer)
    assert try_monad == Try(None, False)

    try_monad = Try('test', True)\
        .filter(filterer)
    assert try_monad == Try('test', True)



# Generated at 2022-06-21 19:21:04.189489
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(1, True).bind(lambda x: Try(x ** 2, True)) == Try(1, True).map(lambda x: x ** 2)
    assert Try(1, True).bind(lambda x: Try(x ** 2, False)) == Try(1, False)



# Generated at 2022-06-21 19:21:05.722447
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(33, True).get_or_else(0) == 33
    assert Try(33, False).get_or_else(0) == 0


# Generated at 2022-06-21 19:21:06.644757
# Unit test for method get of class Try
def test_Try_get():
    assert(Try(5, True).get() == 5)


# Generated at 2022-06-21 19:21:11.829679
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_function(*args):
        return args[0] + args[1]

    def success_callback(value):
        return value

    assert Try.of(test_function, 1, 2).on_success(success_callback) == Try(3, True)
    assert Try.of(test_function, 1, 2).on_success(success_callback) != Try(3, False)


# Generated at 2022-06-21 19:21:14.523579
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try('test', True).get() == 'test'


# Generated at 2022-06-21 19:21:16.975474
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(1, True).on_success(lambda x: x + 1) == Try(1, True)
    assert Try(1, False).on_success(lambda x: x + 1) == Try(1, False)


# Generated at 2022-06-21 19:21:27.898022
# Unit test for method on_success of class Try
def test_Try_on_success():
    """Unit test for method on_success of class Try"""
    def _test_on_success_for_successfully_monad(value, assert_function):
        assert_function(Try.of(lambda: value, None).on_success(lambda a: assert_function(value, a)))

    def _test_on_success_for_fail_monad(value, assert_function):
        assert_function(Try.of(lambda: raise_exception(), None).on_success(lambda a: assert_function(value, a)))

    def _test_on_success(value, assert_function):
        _test_on_success_for_successfully_monad(value, assert_function)
        _test_on_success_for_fail_monad(value, assert_function)


# Generated at 2022-06-21 19:21:33.353795
# Unit test for method bind of class Try
def test_Try_bind():
    def f(x):
        if x > 0:
            return Try(x, True)
        return Try(x, False)
    assert Try(100, True).bind(f) == Try(100, True)
    assert Try(100, False).bind(f) == Try(100, False)
    assert Try(-100, True).bind(f) == Try(-100, False)



# Generated at 2022-06-21 19:21:41.157692
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert not Try(1, True) == Try(2, True)


# Generated at 2022-06-21 19:21:45.752732
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # Given
    sut = Try(9, True)
    another_sut = Try(9, True)

    # When
    result = sut.__eq__(another_sut)

    # Then
    assert result



# Generated at 2022-06-21 19:21:56.765813
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Execute Try.on_fail method on successfully and not successfully Try object.
    """
    # Test on successfully Try object
    mock_success_fn = Mock()
    mock_error_fn = Mock()
    Try(1, True).on_fail(mock_error_fn).on_success(mock_success_fn)
    assert mock_error_fn.called is False
    assert mock_success_fn.called is True
    assert mock_success_fn.call_args[0][0] == 1

    # Test on not successfully Try object
    mock_success_fn = Mock()
    mock_error_fn = Mock()
    Try(1, False).on_fail(mock_error_fn).on_success(mock_success_fn)
    assert mock_error_fn.called is True
    assert mock

# Generated at 2022-06-21 19:22:02.400428
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda x: x) == Try(1, True)
    assert Try(1, False).on_fail(lambda x: x) == Try(1, False)
    assert Try(1, False).on_fail(lambda x: x) != Try(2, False)



# Generated at 2022-06-21 19:22:10.028559
# Unit test for constructor of class Try
def test_Try():
    assert Try('foo', True) == Try('foo', True)
    assert Try('foo', True) != Try('bar', True)
    assert Try('foo', False) == Try('foo', False)
    assert Try('foo', False) != Try('bar', False)
    assert Try('foo', True) != Try('foo', False)
    assert Try('foo', False) != Try('bar', True)


# Generated at 2022-06-21 19:22:15.593706
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)  # equal
    assert Try(1, True) != Try(2, True)  # not equal
    assert Try(1, False) != Try(1, True)  # not equal
    assert Try(2, False) != Try(1, True)  # not equal


# Generated at 2022-06-21 19:22:21.313675
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Unit test for method on_success of class Try.
    """
    assert Try(1, True).on_success(lambda _: 'test') == Try(1, True)
    assert Try(1, False).on_success(lambda _: 'test') == Try(1, False)


# Generated at 2022-06-21 19:22:28.057559
# Unit test for method filter of class Try
def test_Try_filter():
    def test_filter_success():
        assert Try(12, True).filter(lambda x: x > 5) == Try(12, True)

    def test_filter_false():
        assert Try(12, True).filter(lambda x: x < 5) == Try(12, False)

    def test_filter_fail():
        assert Try(12, False).filter(lambda x: x < 5) == Try(12, False)

    test_filter_success()
    test_filter_false()
    test_filter_fail()



# Generated at 2022-06-21 19:22:29.459148
# Unit test for method get of class Try
def test_Try_get():
    def get_value():
        return 5
    assert Try(get_value(), True).get() == 5



# Generated at 2022-06-21 19:22:41.078602
# Unit test for method map of class Try
def test_Try_map():
    def add(x):
        return x + 2

    def mul(x):
        return x * 10

    def f(x):
        return mul(x) + add(x)

    try_val = Try.of(f, 5)
    assert try_val.is_success
    assert try_val.value == 75

    try_val = Try.of(f, 0)
    assert try_val.is_success
    assert try_val.value == 20

    try_val_mapper = Try.of(add, 2)
    assert try_val_mapper.is_success
    assert try_val_mapper.value == 4

    try_val_mapper = Try.of(add, 0)
    assert try_val_mapper.is_success
    assert try_val_mapper.value == 2



# Generated at 2022-06-21 19:22:48.735509
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(x):
        if x % 2 == 0:
            return True
        return False

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(2, True).filter(filterer) == Try(2, True)


# Generated at 2022-06-21 19:22:50.276993
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    print(Try('aaa', True))


# Generated at 2022-06-21 19:22:53.929299
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(0, True) == Try(0, True)
    assert Try(0, False) == Try(0, False)
    assert Try(0, True) != Try(0, False)
    assert Try(0, False) != Try(0, True)



# Generated at 2022-06-21 19:22:57.361817
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try(123, True).__str__() == 'Try[value=123, is_success=True]'
    assert Try('abc', False).__str__() == 'Try[value=abc, is_success=False]'


# Generated at 2022-06-21 19:22:59.709613
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-21 19:23:03.585593
# Unit test for method map of class Try
def test_Try_map():
    def add_one(x):
        return x + 1

    def divide(x):
        return x / 2

    def multiply(x):
        return x * 2

    assert Try(1, True).map(add_one) == Try(2, True)
    assert Try(1, True).map(multiply) == Try(2, True)
    assert Try(1, True).map(divide) == Try(0.5, True)
    assert Try(None, True).map(add_one) == Try(1, True)

    assert Try(None, False).map(add_one) == Try(None, False)


# Generated at 2022-06-21 19:23:07.939198
# Unit test for method get of class Try
def test_Try_get():
    assert Try(10, True).get() == 10
    assert Try(10, True).get() != 20
    assert Try(20, True).get() != 10
    assert Try(None, False).get() == None



# Generated at 2022-06-21 19:23:11.174377
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def t(): return 5

    assert Try.of(t) == Try.of(t)

    def t1(a): return a + a

    assert Try.of(t1, 5) == Try.of(t1, 5)



# Generated at 2022-06-21 19:23:12.379956
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(4, True).get_or_else(0) == 4
    assert Try(4, False).get_or_else(0) == 0



# Generated at 2022-06-21 19:23:15.308208
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def assert_on_fail(monad, exception):
        try:
            monad = monad.on_fail(lambda f: f.args)
            assert monad.value == exception.args
        except AssertionError:
            raise AssertionError('Error in assert that monad.value == exception.args')

    try:
        assert_on_fail(Try(1, True), Exception(1))
    except AssertionError:
        print('Error in test_Try_on_fail()')



# Generated at 2022-06-21 19:23:23.033572
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda value: True) == Try(1, True)
    assert Try(1, True).filter(lambda value: False) == Try(1, False)
    assert Try('initial value', False).filter(lambda value: True) == Try('initial value', False)



# Generated at 2022-06-21 19:23:29.142303
# Unit test for method map of class Try
def test_Try_map():
    def f1(x):
        return x + 1

    def f2(x):
        raise Exception('Lorem ipsum')

    assert Try.of(lambda: 3).map(f1) == Try(4, True)
    assert Try.of(f1, 3) == Try(4, True)
    assert Try.of(f2) == Try('Lorem ipsum', False)



# Generated at 2022-06-21 19:23:32.036353
# Unit test for method __eq__ of class Try
def test_Try___eq__():

    # Arrange
    actual = "test"

    # Act
    actual = Try(actual, True) == Try(actual, True)

    # Assert
    assert actual



# Generated at 2022-06-21 19:23:35.020553
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == "Try[value=1, is_success=True]"
    assert str(Try(1, False)) == "Try[value=1, is_success=False]"


# Generated at 2022-06-21 19:23:39.533200
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(value):
        return value > 3

    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(4, True).filter(filterer) == Try(4, True)

# Generated at 2022-06-21 19:23:41.412247
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(10, True).get() == 10
    assert Try(10, False).get() == 10


# Generated at 2022-06-21 19:23:45.403472
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try('foo', True).get() == 'foo'
    assert Try(Exception('123'), False).get() == Exception('123')


# Generated at 2022-06-21 19:23:50.729231
# Unit test for method filter of class Try
def test_Try_filter():
    """
    :test: Try.filter(f)
    :precondition: Monad Try with true is_success and previuos value = 5
    :postcondition: Try with value 5 and is_success = True
    """
    assert Try(5, True).filter(lambda x: x == 5) == Try(5, True)



# Generated at 2022-06-21 19:23:53.994114
# Unit test for method bind of class Try
def test_Try_bind():
    def binder(value):
        if value > 0:
            return Try(value * 2, True)
        return Try(value, False)

    assert Try(10, True).bind(binder) == Try(20, True)
    assert Try(-1, True).bind(binder) == Try(-1, False)


# Generated at 2022-06-21 19:24:00.028232
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 3 / 2, None).bind(lambda value: Try(value * 2, True)) \
        == Try(3, True)
    assert Try.of(lambda: 3 / 0, None).bind(lambda value: Try(value * 2, True)) \
        == Try(ZeroDivisionError('division by zero'), False)


# Generated at 2022-06-21 19:24:07.496219
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try('value', True).__str__() == "Try[value=value, is_success=True]"
    assert Try('value', False).__str__() == "Try[value=value, is_success=False]"


# Generated at 2022-06-21 19:24:14.486140
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # given
    def exception_func(args):
        """
        Function that raise exception.

        :params *args:
        :rtype: None
        """
        raise Exception("some exception")

    # when
    result = Try.of(exception_func, 1, 2)
    on_fail_result = result.on_fail(lambda e: print(e))

    # then
    assert on_fail_result == Try(Exception("some exception"), False)

# Generated at 2022-06-21 19:24:21.299082
# Unit test for method map of class Try
def test_Try_map():
    t = Try.of(lambda x: x**2, 2)
    t1 = t.map(lambda x: x**3)
    assert isinstance(t1, Try)
    assert t1 == Try(8, True)

    t = Try.of(lambda x: 1/0, None)
    t1 = t.map(lambda x: x**3)
    assert isinstance(t1, Try)
    assert t1 == t



# Generated at 2022-06-21 19:24:29.588976
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception(), False) == Try(Exception(), False)
    assert Try(None, True) == Try(None, True)
    assert Try('ok', True) != Try('ok', False)
    assert Try('ok', True) != Try('ok', True)
    assert Try(1, False) != Try(2, False)
    assert Try(None, True) != Try('ok', True)
    assert Try(Exception(), False) != Try(Exception(), True)
    # TODO: add test for type of exception



# Generated at 2022-06-21 19:24:33.040413
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(None, True) == Try(None, True)
    assert not Try(None, True) == Try(None, False)
    assert not Try(None, True) == Try(None, True, None)
    assert not Try(None, True) == ValueError('Exception')


# Generated at 2022-06-21 19:24:35.267461
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(e):
        print(e)

    fail = Try('some value', False)
    assert fail == fail.on_fail(fail_callback)



# Generated at 2022-06-21 19:24:39.983682
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try('s', True)) == 'Try[value=s, is_success=True]'
    assert str(Try(2, False)) == 'Try[value=2, is_success=False]'
    assert str(Try('s', False)) == 'Try[value=s, is_success=False]'


# Generated at 2022-06-21 19:24:42.831357
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 10 / 2, None) == Try(5, True)
    try:
        Try.of(lambda: 10 / 0, None).on_fail(lambda x: print(x)) == Try(10 / 0, False)
    except:
        pass



# Generated at 2022-06-21 19:24:44.566530
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    For successfully monad call on_fail method.
    """
    try:
        Try(1, True).on_fail(lambda e: print(e))
    except Exception:
        assert False


# Generated at 2022-06-21 19:24:48.734824
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try('value', True) == Try('value', True)
    assert Try(Exception(), False) == Try(Exception(), False)


# Generated at 2022-06-21 19:25:03.507942
# Unit test for method on_success of class Try
def test_Try_on_success():
    def test_success(value):
        global is_success
        is_success = True

    def test_fail(value):
        global is_fail
        is_fail = True

    is_success = False
    is_fail = False

    Try(10, True).on_success(test_success)
    assert is_success

    Try(10, False).on_success(test_success)
    assert not is_success

    Try(10, False).on_fail(test_fail)
    assert is_fail

    Try(10, True).on_fail(test_fail)
    assert not is_fail

# Generated at 2022-06-21 19:25:09.340903
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def check_Try_get_or_else():
        def throw_number():
            raise Exception(3)

        assert Try.of(lambda: throw_number()).get_or_else(2) == 2
        assert Try.of(lambda: 2).get_or_else(1) == 2
    SolidTest.run(check_Try_get_or_else)


# Generated at 2022-06-21 19:25:11.703065
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(4, True) == Try(4, True)
    assert Try(4, True) != Try(4, False)

# Generated at 2022-06-21 19:25:15.139883
# Unit test for method get of class Try
def test_Try_get():
    try:
        assert Try(5, True).get() == 5
    except AssertionError:
        print("Test for method get of class Try is failed.")
        raise AssertionError
    print("Test for method get of class Try is passed.")



# Generated at 2022-06-21 19:25:20.486348
# Unit test for method on_success of class Try

# Generated at 2022-06-21 19:25:24.786042
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert not Try(1, True) == Try(1, False)
    assert not Try(1, True) == Try(2, True)


# Generated at 2022-06-21 19:25:29.336910
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def test_failure_callback(failure_value):
        assert failure_value == 'failure'

    assert Try('failure', False).on_fail(test_failure_callback) == Try('failure', False)
    assert Try('success', True).on_fail(test_failure_callback) == Try('success', True)


# Generated at 2022-06-21 19:25:37.129335
# Unit test for method on_success of class Try
def test_Try_on_success():
    x = [0]
    def incr(value = 0):
        x[0] += value
    # Test case when Try is successfully
    Try.of(divmod, 16, 4).on_success(incr)
    assert x == [0]
    # Test case when Try is not successfully
    Try.of(divmod, 16, 0).on_success(incr)
    assert x == [0]
test_Try_on_success()


# Generated at 2022-06-21 19:25:40.815455
# Unit test for method on_success of class Try
def test_Try_on_success():
    def on_success(value: str) -> str:
        return value + ' on_success'

    assert Try('Try 1', True).on_success(on_success) == Try('Try 1 on_success', True)
    assert Try('Try 2', False).on_success(on_success) == Try('Try 2', False)


# Generated at 2022-06-21 19:25:42.474066
# Unit test for method on_success of class Try

# Generated at 2022-06-21 19:25:58.779372
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Try.on_fail(fail_callback)
    Call success_callback function with monad value when monad is not successfully.

    :params fail_callback: function to apply with monad value.
    :type fail_callback: Function(A)
    :returns: self
    :rtype: Try[A]
    """
    exception_test = Exception()
    fail_test = Try(exception_test, False)

# Generated at 2022-06-21 19:26:03.526105
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    Try(42, True).on_fail(lambda e: e) #do nothing


# Generated at 2022-06-21 19:26:13.519984
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Unit test for method on_success of class Try.

    :returns: True when unit test is passed, False when not.
    :rtype: Boolean
    """
    def test_callback_function(value):
        assert value == "success"

    success = Try("success", True)
    unsuccess = Try("unsuccess", False)

    success.on_success(test_callback_function)
    unsuccess.on_success(test_callback_function)

    return True


# Generated at 2022-06-21 19:26:17.440817
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def print_error(e) -> None:
            print(e)

    Try.of(lambda: 4 * 5).on_fail(print_error)
    Try.of(lambda: 4 * "5").on_fail(print_error)

# Generated at 2022-06-21 19:26:21.924544
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(3, True)
    assert Try(1, False) != Try(3, False)


# Generated at 2022-06-21 19:26:26.489700
# Unit test for method get of class Try
def test_Try_get():
    # GIVEN
    # successful Try
    try_a = Try(10, True)

    # WHEN
    a = try_a.get()

    # THEN
    assert a == 10



# Generated at 2022-06-21 19:26:29.140853
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'


# Generated at 2022-06-21 19:26:39.143450
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True).__str__() == 'Try[value=1, is_success=True]'
    assert Try(1, False) == Try(1, False)
    assert Try(1, False).__str__() == 'Try[value=1, is_success=False]'
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(2, True)



# Generated at 2022-06-21 19:26:48.363560
# Unit test for method on_success of class Try
def test_Try_on_success():
    is_success = True
    value = 'test'

    def test_try_on_success(value_):
        nonlocal value
        value = value_

    try_ = Try(value, is_success).on_success(test_try_on_success)
    assert try_.value == value and try_.is_success == is_success
    assert value == test_try_on_success.__name__


# Generated at 2022-06-21 19:26:59.544073
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)

    assert Try(1, False).value == 1
    assert Try(1, False).is_success == False
    assert Try(1, True).value == 1
    assert Try(1, True).is_success == True
    assert Try(Exception(), False).value != None
    assert Try(Exception(), False).is_success == False
    assert Try(Exception(), False).value.__class__ == Exception

# Generated at 2022-06-21 19:27:24.900514
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    error_msg = 'Try instance is equal to `other`. But method __eq__ does not work'
    result = Try(False, True)
    other = Try(False, True)
    if result == other:
        assert True
    else:
        assert False, error_msg



# Generated at 2022-06-21 19:27:26.621496
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1


# Generated at 2022-06-21 19:27:30.634823
# Unit test for method map of class Try
def test_Try_map():
    def calc_10(value):
        return value + 10

    assert Try.of(calc_10, 0).map(lambda v: v*10) == Try(100, True)
    assert Try.of("asd", 0).map(lambda v: v*10) == Try("asd", False)


# Generated at 2022-06-21 19:27:34.323215
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)



# Generated at 2022-06-21 19:27:35.264972
# Unit test for method get of class Try
def test_Try_get():
    assert Try(42, True).get() == 42


# Generated at 2022-06-21 19:27:39.069657
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    from pytest import raises
    with raises(Exception) as exc:
        Try.of(lambda: 1 / 0)

    assert str(exc.value) == 'Try[value=division by zero, is_success=False]'


# Generated at 2022-06-21 19:27:41.856471
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_value = Try(lambda: 1 / 0, False)
    assert try_value.get_or_else('Success') == 'Success'

# Generated at 2022-06-21 19:27:48.211282
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test for method bind of class Try.

    :returns: nothing
    :rtype: None
    """
    assert Try.of(lambda x : x + 1, 1) == Try(2, True)
    assert Try.of(lambda x : x + 1, 1).bind(lambda x : Try(x * 2, True)) == Try(4, True)
    assert Try.of(lambda x : x + 1, 1).bind(lambda x : Try(x * 2, False)) == Try(2, True)
    assert Try.of(lambda x : x + 1, 1).bind(lambda x : Try(x * 2, False)).bind(lambda x : Try(x + 1, True)) == Try(2, True)

# Generated at 2022-06-21 19:27:51.132555
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    try_ = Try(10, True)
    assert try_ == Try(10, True)

# Generated at 2022-06-21 19:27:54.481512
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def test_method():
        raise ValueError('Text error')

    def fail_callback(value: ValueError):
        print(value)

    test = Try.of(test_method)
    test.on_fail(fail_callback)
    #> Text error


# Generated at 2022-06-21 19:28:39.845159
# Unit test for method filter of class Try
def test_Try_filter():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except:
        exception = sys.exc_info()[0]

    assert not Try.of(lambda: 1).filter(lambda v: True).is_success
    assert Try.of(lambda: 1).filter(lambda v: True).value == 1
    assert Try.of(lambda: 1).filter(lambda v: False).value == 1
    assert Try.of(lambda: 1).filter(lambda v: False).is_success
    assert Try.of(lambda: 1).filter(lambda v: False).filter(lambda v: True).is_success
    assert Try.of(lambda: 1).filter(lambda v: False).filter(lambda v: False).value == 1

# Generated at 2022-06-21 19:28:48.559218
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def filterer(a):
        return a % 2 == 0

    try_ = Try.of(lambda: 2)

    assert(try_.filter(filterer).get() == 2)
    assert(try_.filter(filterer).is_success == True)
    assert(try_.filter(filterer) == Try(2, True))

    try_ = Try.of(lambda: 3)

    assert(try_.filter(filterer).get() == 3)
    assert(try_.filter(filterer).is_success == False)
    assert(try_.filter(filterer) == Try(3, False))



# Generated at 2022-06-21 19:28:53.255441
# Unit test for constructor of class Try
def test_Try():
    try_s = Try(1, True)
    try_f = Try(2, False)

    assert try_s.value == 1 and try_s.is_success
    assert not try_f.is_success



# Generated at 2022-06-21 19:29:01.184481
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test for method on_fail of class Try
    """
    fail_value = None
    fn_exception = lambda: 1/0
    fn_success = lambda x: x

    def set_value(x):
        nonlocal fail_value
        fail_value = x

    assert fail_value is None

    Try.of(fn_success, 0).on_fail(set_value)
    assert fail_value is None

    Try.of(fn_exception, 0).on_fail(set_value)
    assert fail_value is not None


# Generated at 2022-06-21 19:29:12.879672
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter method of class Try.
    Test cases:
        1. Test filter on not successfully Try.
        2. Test filter on not successfully Try when filterer returns True.
        3. Test filter on successfully Try.
        4. Test filter on successfully Try when filterer returns False.
    """
    def test_one():
        """
        Test filter on not successfully Try.
        """
        assert Try(4, False)\
            .filter(lambda _: True) == Try(4, False)

    def test_two():
        """
        Test filter on not successfully Try when filterer returns Ture.
        """
        assert Try(4, False) \
            .filter(lambda _: False) == Try(4, False)

    def test_three():
        """
        Test filter on successfully Try.
        """


# Generated at 2022-06-21 19:29:16.850958
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def assert_on_success(value, expected):
        def check_value(v):
            return assert_equals(v, expected)
        return Try(value, True).on_success(check_value)

    assert_equals(assert_on_success(10, 10), Try(10, True))


# Generated at 2022-06-21 19:29:23.300033
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: {'a': 'b'}) == Try({'a': 'b'}, True)
    assert Try.of(lambda: {'a': {'b': 'c'}}).bind(lambda d: d['a']) == Try({'b': 'c'}, True)
    assert Try.of(lambda: {'a': {'b': 'c'}}).bind(lambda d: d['a']).bind(lambda d: d['b']) == Try('c', True)
    assert Try.of(lambda: {'a': {'b': 'c'}}).bind(lambda d: d['a']).bind(lambda d: d['b']).bind(lambda e: e.upper()) == Try('C', True)

# Generated at 2022-06-21 19:29:33.972096
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test for method filter of class Try

    1. Create successfull Try with value 10
    2. Call filter with lambda condition x > 5
    3. Check if result Try is successfull and if result Try value is 10
    4. Create successfull Try with value 3
    5. Call filter with lambda condition x > 5
    6. Check if result Try is not successfull and if result Try value is 3
    """
    t1 = Try(10, True)
    r1 = t1.filter(lambda x: x > 5)
    assert r1.is_success
    assert r1.get() == 10

    t2 = Try(3, True)
    r2 = t2.filter(lambda x: x > 5)
    assert not r2.is_success
    assert r2.get() == 3


# Generated at 2022-06-21 19:29:37.104189
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(1, False).get() == 1

# Generated at 2022-06-21 19:29:41.678656
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    try_1_true = Try(1, True)
    try_2_true = Try(2, True)
    try_1_false = Try(1, False)
    try_2_false = Try(2, False)

    assert try_1_true.get_or_else(2) == 1
    assert try_1_false.get_or_else(2) == 2
    assert try_2_true.get_or_else(1) == 2
    assert try_2_false.get_or_else(1) == 1


# Generated at 2022-06-21 19:30:27.062890
# Unit test for method map of class Try
def test_Try_map():
    def _get_mod_7(num: int) -> int:
        return num % 7
    check = 'Check map result {}, expected {}, when num is {}'
    assert Try(5, True).map(_get_mod_7) == Try(5 % 7, True),\
        check.format(Try(5, True).map(_get_mod_7), Try(5 % 7, True), 5)
    assert Try(0 / 1, False).map(_get_mod_7) == Try(0 / 1, False),\
        check.format(Try(0 / 1, False).map(_get_mod_7), Try(0 / 1, False), 'division by zero')


# Generated at 2022-06-21 19:30:34.892856
# Unit test for method bind of class Try
def test_Try_bind():
    from random import randint

    def if_none_zero(value):
        if value is None:
            return Try(0, True)
        return Try(value, True)

    def add_one(value):
        return Try(value + 1, True)

    def generate_number():
        return randint(0, 100)

    number = generate_number()
    maybe_result = Try(number, True)\
        .bind(if_none_zero)\
        .bind(add_one)
    assert maybe_result.get() == number + 1

# Generated at 2022-06-21 19:30:40.952003
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(0, True)) == 'Try[value=0, is_success=True]'
    assert str(Try(0, False)) == 'Try[value=0, is_success=False]'
    assert str(Try(Exception(0), False)) == 'Try[value=0, is_success=False]'
