

# Generated at 2022-06-21 19:21:00.729495
# Unit test for method bind of class Try
def test_Try_bind():
    def fn(x):
        # type: (float)->Try[float]
        if 3/2 <= x:
            return Try(x, True)
        return Try(0, False)

    assert Try(7.0, True).bind(fn) == Try(7.0, True)
    assert Try(7.0, True).bind(fn).bind(fn) == Try(7.0, True)
    assert Try(2.0, True).bind(fn) == Try(2.0, True).bind(fn).bind(fn)
    assert Try(4.0, True).bind(fn) == Try(4.0, True).bind(lambda x: Try(x, True))

# Generated at 2022-06-21 19:21:04.034165
# Unit test for method bind of class Try
def test_Try_bind():
    # Prepare
    def binder(value):
        return Try(value * 10, True)
    successful_try = Try(1, True)
    failed_try = Try(Exception('fail'), False)

    # Assert
    assert successful_try.bind(binder) == Try(10, True)
    assert failed_try.bind(binder) == Try(Exception('fail'), False)


# Generated at 2022-06-21 19:21:09.310887
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(0, True) == Try(0, True)
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) != Try(0, True)
    assert Try(None, False) != Try(0, False)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try(0, True)


# Generated at 2022-06-21 19:21:10.676422
# Unit test for method get of class Try
def test_Try_get():
    assert 1 == Try('2', True).map(int).get()


# Generated at 2022-06-21 19:21:16.350785
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try.of(lambda: 1, None)) == 'Try[value=1, is_success=True]'
    assert str(Try.of(lambda: 1, None).bind(lambda x: Try.of(lambda: 2 / 0, None))) == 'Try[value=ZeroDivisionError("division by zero"), is_success=False]'


# Generated at 2022-06-21 19:21:21.603749
# Unit test for method filter of class Try
def test_Try_filter():
    square = lambda x: x * x
    is_positive = lambda x: x > 0
    assert Try.of(square, 4).bind(Try.of(square)).filter(is_positive).get() == 16
    assert Try.of(square, -4).bind(Try.of(square)).filter(is_positive).is_success == False



# Generated at 2022-06-21 19:21:30.685676
# Unit test for method filter of class Try
def test_Try_filter():
    def is_even(x: int) -> bool:
        return x % 2 == 0

    try_mapped = Try.of(lambda x: x + 1, 10).filter(is_even)
    assert type(try_mapped) is Try

    try_mapped = Try.of(lambda x: x + 1, 11).filter(is_even)
    assert type(try_mapped) is Try
    assert not try_mapped.is_success

# Generated at 2022-06-21 19:21:32.748550
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try('', True).get_or_else('failure') == ''


# Generated at 2022-06-21 19:21:34.772885
# Unit test for constructor of class Try
def test_Try():
    assert Try(10, True) == Try(10, True)



# Generated at 2022-06-21 19:21:39.030953
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    result = Try.of(lambda x: x * 2, 5)

    assert(result.map(lambda x: x + 5) == Try(15, True))

    result = Try.of(lambda x: x / 0, 5)

    assert(result.map(lambda x: x + 5) == result)



# Generated at 2022-06-21 19:21:50.253962
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    def success_callback(value):
        print('value: {}'.format(value))

    def fail_callback(value):
        print('exception: {}'.format(value))

    Try(1, True)\
        .on_success(success_callback)\
        .on_fail(fail_callback)

    Try(ValueError('1'), False)\
        .on_success(success_callback)\
        .on_fail(fail_callback)
    # value: 1
    # exception: 1


# Generated at 2022-06-21 19:21:52.011214
# Unit test for method get of class Try
def test_Try_get():
    assert Try(3, True).get() == 3
    assert Try(3, False).get() == 3

# Generated at 2022-06-21 19:22:03.211953
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda: 10).filter(lambda x: True) == Try(10, True)
    assert Try.of(lambda: 10).filter(lambda x: False) == Try(10, False)
    assert Try.of(lambda: 10, 5).filter(lambda x: x > 5) == Try(10, True)
    assert Try.of(lambda: 10, 5).filter(lambda x: x > 15) == Try(10, False)
    assert Try.of(lambda: 10 / 0).filter(lambda x: True) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 10 / 0).filter(lambda x: False) == Try(ZeroDivisionError(), False)

# Generated at 2022-06-21 19:22:10.142109
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, False) != Try('1', False)



# Generated at 2022-06-21 19:22:16.516954
# Unit test for method map of class Try
def test_Try_map():
    def get_value(a: int) -> int:
        return a + 1

    value = Try.of(get_value, 1).map(lambda a: a * 2).get()
    assert value == 4

    value = Try.of(get_value, 1).filter(lambda a: a > 3).map(lambda a: a * 2).get_or_else(0)
    assert value == 0



# Generated at 2022-06-21 19:22:24.963661
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(10, True).bind(lambda x: Try(x + 1, True)) == Try(11, True)
    assert Try(10, False).bind(lambda x: Try(x + 1, True)) == Try(10, False)
    assert Try(10, True).bind(lambda x: Try(x + 1, False)) == Try(11, False)
    assert Try(10, False).bind(lambda x: Try(x + 1, False)) == Try(10, False)


# Generated at 2022-06-21 19:22:27.246592
# Unit test for method get of class Try
def test_Try_get():
    value = 3
    method_result = Try(value, True).get()
    assert method_result == value
    assert method_result is not None

# Generated at 2022-06-21 19:22:30.983261
# Unit test for method map of class Try
def test_Try_map():
    # when Try is successfully, map apply mapper on value
    assert Try(1, True).map(lambda x: x + 1) == Try(2, True), 'Test Try.map in case Success'

    # when Try is not successfully, map return previous value
    assert Try(1, False).map(lambda x: x + 1) == Try(1, False), 'Test Try.map in case Failure'


# Generated at 2022-06-21 19:22:40.820714
# Unit test for method filter of class Try
def test_Try_filter():
    """
    Test filter Try method.
    For example: when you need filter Try with callback function,
    when callback return True and Try is successfully will return
    successfully Try with same value, othercase not successfully Try with same value.

    This test tests filter method of Try.
    """

    # when successfully Try and filterer return True
    assert Try(1, True).filter(lambda x: x < 2) == Try(1, True)

    # when not successfully Try and filterer return True
    assert Try(1, False).filter(lambda x: x < 2) == Try(1, False)

    # when successfully Try and filterer return False
    assert Try(1, True).filter(lambda x: x > 2) == Try(1, False)

# Generated at 2022-06-21 19:22:45.236340
# Unit test for method on_success of class Try
def test_Try_on_success():
    def callback(value):
        assert value == 5
        value += 5
        assert value == 10

    try_with_value_5 = Try(5, True)
    try_with_value_5.on_success(callback)

# Generated at 2022-06-21 19:22:49.503255
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(5, True)) == 'Try[value=5, is_success=True]'


# Generated at 2022-06-21 19:22:52.526471
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, True) == Try(None, True)
    assert Try(None, True) != Try(None, False)
    assert Try(None, False) != Try('Test Exception', False)


# Generated at 2022-06-21 19:22:54.416236
# Unit test for method get of class Try
def test_Try_get():
    success_try = Try("Hello world!", True)
    assert success_try.get() == "Hello world!"



# Generated at 2022-06-21 19:22:58.788677
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    def is_even(value):
        return value % 2 == 0

    assert Try.of(int, '10').filter(is_even) == Try(10, True)
    assert Try.of(int, 10).filter(is_even) == Try(10, True)
    assert Try.of(int, 11).filter(is_even) == Try(11, False)


# Generated at 2022-06-21 19:23:00.955231
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    eq_(Try.of(lambda x: x + 1, 2).map(lambda x: x + 1), Try.of(lambda x: x + 2, 2))



# Generated at 2022-06-21 19:23:12.242891
# Unit test for method filter of class Try
def test_Try_filter():
    # Declare variable with function to throw exception (exception raise)
    def throw_exception():
        raise Exception('Throw exception')

    # Declare variable to test
    test_obj = Try.of(throw_exception)

    # Check that test_obj is instance of class Try and successfully is False
    assert isinstance(test_obj, Try)
    assert not test_obj.is_success

    # Declare variable to test
    test_obj_2 = test_obj.filter(lambda e: e.args[0] == 'Throw exception')

    # Check that test_obj and test_obj_2 are instance of class Try and successfully is False
    assert isinstance(test_obj_2, Try)
    assert test_obj == test_obj_2
    assert not test_obj_2.is_success

    # Declare variable with

# Generated at 2022-06-21 19:23:15.890104
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try1 = Try(1, True)
    try2 = Try(1, True)
    try3 = Try(2, True)
    assert try1 == try2
    assert try1 != try3
    assert try2 != try3



# Generated at 2022-06-21 19:23:19.473870
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Call success_callback function with monad value when monad is not successfully.
    """
    def fail_callback(fail_value):
        fail_value.append(1)
    fail_value = []
    assert(Try('ok', False).on_fail(fail_callback) == Try('ok', False))
    assert(fail_value == [1])

# Generated at 2022-06-21 19:23:25.441900
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    value = 'value'
    try_obj = Try(value, True)
    assert(try_obj == Try(value, True))
    assert(try_obj != Try(value, False))
    assert(try_obj != Try(None, None))
    assert(Try(None, None) == Try(None, None))


# Generated at 2022-06-21 19:23:28.785423
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(1, True).on_fail(lambda _: None).is_success
    assert not Try(1, False).on_fail(lambda _: None).is_success


# Generated at 2022-06-21 19:23:36.785804
# Unit test for constructor of class Try
def test_Try():
    assert Try('value', True) == Try('value', True)
    assert Try('value', True) != Try('value1', True)
    assert Try('value', True) != Try('value', False)
    assert Try('value', True) != Try('value1', False)
    assert Try('value', True) != None


# Generated at 2022-06-21 19:23:48.690173
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    This method test on_fail method in class Try with different cases.
    """
    value = ['value', 'not_value']

    with mock.patch('Try.Try.on_fail') as mock_on_fail:
        Try.of(lambda x: 1, 1).on_fail(value[0])
        mock_on_fail.assert_not_called()

        Try.of(lambda x: x / 0, 1).on_fail(value[0])
        mock_on_fail.assert_called_once_with(value[0])
        mock_on_fail.reset_mock()

        mock_on_fail.return_value = value[1]
        assert Try.of(lambda x: x / 0, 1).on_fail(value[0]) == value[1]



# Generated at 2022-06-21 19:23:55.309451
# Unit test for method map of class Try
def test_Try_map():
    def f(x: float) -> float:
        return x * 2

    try_float = Try(float(1.0), True)
    try_float_map = try_float.map(f)
    assert try_float_map == Try(2.0, True)
    try_float = Try(float(0.0), True)
    try_float_map = try_float.map(f)
    assert try_float_map == Try(0.0, True)

    try_int = Try(int(1), True)
    try_int_map = try_int.map(f)
    assert try_int_map == Try(2.0, True)


# Generated at 2022-06-21 19:23:57.837641
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(lambda: 1 / 0).on_fail(lambda _: None).is_success is False



# Generated at 2022-06-21 19:24:02.283463
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(2, False).get() == 2
    assert Try(-1, True).get() == -1
    assert Try(0, False).get() == 0
    assert Try(None, True).get() is None


# Generated at 2022-06-21 19:24:05.457071
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:24:12.352300
# Unit test for method map of class Try
def test_Try_map():
    """Test Try map method"""
    # happy path
    t1 = Try.of(lambda: 1, 1)
    assert str(t1.map(lambda x: x + 2)) == 'Try[value=3, is_success=True]'
    # unhappy path
    t2 = Try.of(lambda: int('a'), 1)
    assert str(t2.map(lambda x: x + 2)) == 'Try[value=ValueError(), is_success=False]'


# Generated at 2022-06-21 19:24:15.302224
# Unit test for constructor of class Try
def test_Try():
    assert Try(0, True) == Try(0, True)
    assert Try(0, True) != Try(1, True)
    assert Try(0, True) != Try(0, False)



# Generated at 2022-06-21 19:24:20.752343
# Unit test for method get of class Try
def test_Try_get():
    # Test when monad is successfully
    assert Try.of(lambda x: x*2, 5).get() == 10
    # Test when monad is not successfully
    try:
        Try.of(lambda x: x/0, 5).get()
    except Exception as e:
        assert e.__class__.__name__ == 'ZeroDivisionError'



# Generated at 2022-06-21 19:24:22.866574
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x: x + 2, 1).get() == 3


# Generated at 2022-06-21 19:24:29.779245
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 10, ()).get() == 10
    assert Try.of(lambda: None, ()).get() is None
    assert Try.of(lambda r: 1 / 0, ()).get() is None


# Generated at 2022-06-21 19:24:32.285271
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try(1, True).get_or_else(0) == 1
    assert Try(1, False).get_or_else(0) == 0



# Generated at 2022-06-21 19:24:39.833472
# Unit test for method on_success of class Try
def test_Try_on_success():
    def callback(value):
        return value * 2
    try_ = Try.of(callback, 2) # type: Try
    assert try_.is_success == True
    assert try_.on_success(callback).is_success == True
    assert try_.on_success(callback).value == 8
    assert try_.filter(lambda x: x % 2 == 0)
    assert try_.filter(lambda x: x % 2 == 0).is_success
    assert try_.filter(lambda x: x % 2 == 0).get() == 8
    assert try_.filter(lambda x: x % 2 == 0).get_or_else(1) == 8
    assert try_.filter(lambda x: x % 2 == 0).on_success(callback) == 16


# Generated at 2022-06-21 19:24:42.031335
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:24:45.123948
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try(1, True).__str__() == 'Try[value=1, is_success=True]'
    assert Try(1, False).__str__() == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:24:57.025856
# Unit test for method bind of class Try
def test_Try_bind():
    def add_and_sqrt(x):
        return x + 1, x ** 0.5

    def test_Try_bind_with_success(x):
        return Try(x, True).bind(lambda x: Try.of(add_and_sqrt, x))

    def test_Try_bind_with_fail(x):
        return Try(x, False).bind(lambda x: Try.of(add_and_sqrt, x))

    def test_Try_bind_with_success_function_fail(x):
        return Try(x, True).bind(lambda x: Try.of(int, x))

    assert Try(100, True) == test_Try_bind_with_success(0)

# Generated at 2022-06-21 19:25:02.157262
# Unit test for method on_success of class Try
def test_Try_on_success():

    def callback(value):
        global result_value
        result_value = value

    test_value = 1
    result_value = None

    # Call callback when is successfully
    assert Try(test_value, True).on_success(
        callback).get() == test_value

    # Don't call callback when is not successfully
    assert Try(test_value, False).on_success(
        callback).get() == test_value and result_value is None


# Generated at 2022-06-21 19:25:08.732388
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda: 'test').get_or_else('default_value') == 'test'
    assert Try.of(lambda: None).get_or_else('default_value') == 'default_value'
    assert Try.of(lambda: 3).get_or_else(4) == 3
    assert Try.of(lambda: None).get_or_else(4) == 4


# Generated at 2022-06-21 19:25:11.445762
# Unit test for method get of class Try
def test_Try_get():
    """
    Test Try.get() method.
    """
    value = 'test'
    success_try = Try(value, True)
    assert success_try.get() == value
    assert success_try.get_or_else('not test') == value

    exception = Exception('try error')
    fail_try = Try(exception, False)
    assert fail_try.get() == exception
    assert fail_try.get_or_else(value) == value
    assert fail_try.get_or_else(exception) == exception



# Generated at 2022-06-21 19:25:14.637100
# Unit test for constructor of class Try
def test_Try():
    # success case
    assert Try(True, True) == Try(True, True)
    # fail case
    assert Try("error", False) == Try("error", False)

# Generated at 2022-06-21 19:25:27.656966
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    def fail_callback(e):
        print('Error: {}'.format(e))

    Try.of(1, 2).on_fail(fail_callback)
    Try.of(lambda x: x+1, 1).on_fail(fail_callback)
    Try.of(lambda x: x+1, 'a').on_fail(fail_callback)
    Try.of(lambda x: x+1, 'a').on_fail(fail_callback)
    Try.of(lambda x: x[1], 'abc').on_fail(fail_callback)
    Try.of(lambda x: x[1], 'abc').on_fail(fail_callback)
    Try.of(lambda x: x.lower(), 'Abc').on_fail(fail_callback)



# Generated at 2022-06-21 19:25:31.976112
# Unit test for method __eq__ of class Try
def test_Try___eq__():

    # Test when Try objects has same values and is_success
    assert Try(2, True) == Try(2, True) == Try(2, True)

    # Test when Try objects has different values and is_success
    assert not Try(3, True) == Try(4, True)

    # Test when Try objects has different values and different is_success
    assert not Try(3, True) == Try(4, False)


# Generated at 2022-06-21 19:25:36.417491
# Unit test for method get of class Try
def test_Try_get():
    # Test successfully monad
    assert Try(1, True).get() == 1

    # Test not successfully monad
    assert Try(Exception('exception'), False).get() == Exception('exception')


# Generated at 2022-06-21 19:25:41.896290
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        5 / 0
    except ZeroDivisionError as e:
        test_exception = e

    assert(Try(5, True).on_fail(lambda x: None) == Try(5, True))
    assert(Try(test_exception, False).on_fail(lambda x: None) == Try(test_exception, False))

# Generated at 2022-06-21 19:25:48.464313
# Unit test for method filter of class Try
def test_Try_filter():
    def filterer(n):
        return n > 3

    try_1 = Try(1, True)
    try_2 = Try(5, True)
    try_3 = Try(2, True)

    assert try_1.filter(filterer) == Try(1, False)
    assert try_2.filter(filterer) == Try(5, True)
    assert try_3.filter(filterer) == Try(2, False)

# Generated at 2022-06-21 19:25:53.893902
# Unit test for method bind of class Try
def test_Try_bind():
    def raises_exc(s):
        raise Exception('some message')
    def f(s):
        print(s)

    # bind return copy of monad when bind function raise exception.
    m = Try.of(f, 'it\'s ok').bind(lambda s: Try.of(raises_exc, s))
    assert m == Try('it\'s ok', True)

    # bind return result of bind function when bind function don\'t raise exception.
    m = Try.of(f, 'it\'s ok').bind(lambda s: Try.of(f, s))
    assert m == Try('it\'s ok', True)


# Generated at 2022-06-21 19:26:01.421319
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Unit test for method on_fail of class Try
    """

    def fn(a, b):
        return a + b

    # Call Try.of with two arguments and assert that if is successfully is False

# Generated at 2022-06-21 19:26:03.840045
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(Exception(), False).get() == Exception()



# Generated at 2022-06-21 19:26:10.110178
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda x: x, 1).get() == 1
    assert Try.of(lambda x: x, 1).get_or_else(lambda x: 2) == 1
    assert Try.of(lambda x: x / 0, 1).get_or_else(2) == 2


# Generated at 2022-06-21 19:26:16.327941
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    # assert that Try(42, True).__eq__(Try(42, True))
    assert Try(42, True).__eq__(Try(42, True))
    # assert that not Try(42, True).__eq__(Try(42, False))
    assert not Try(42, True).__eq__(Try(42, False))
    # assert that not Try(42, False).__eq__(Try(42, True))
    assert not Try(42, False).__eq__(Try(42, True))
    # assert that Try(42, False).__eq__(Try(42, False))
    assert Try(42, False).__eq__(Try(42, False))


# Generated at 2022-06-21 19:26:20.415216
# Unit test for method get of class Try
def test_Try_get():
    unit = Try(1, True)
    assert unit.get() == 1
    assert unit.get_or_else(0) == 1


# Generated at 2022-06-21 19:26:22.256238
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1
    assert Try(Exception('error'), False).get() == Exception('error')


# Generated at 2022-06-21 19:26:30.944780
# Unit test for method bind of class Try
def test_Try_bind():
    def multiply(x):
        return x * 2

    def divide(x):
        return x / 2

    def throw_exception(x):
        raise ValueError('some error')

    def bind_fn(x):
        return Try.of(divide, x)

    def bind_exception(x):
        return Try.of(throw_exception, x)

    assert Try(4, True).bind(bind_fn) == Try(2, True) # noqa
    assert Try(6, True).bind(bind_fn) == Try(3, True) # noqa
    assert Try(4, True).bind(bind_exception) == Try(None, False) # noqa
    assert Try('', False).bind(bind_fn) == Try('', False) # noqa

# Generated at 2022-06-21 19:26:32.442132
# Unit test for constructor of class Try
def test_Try():
    assert Try(10, True) == Try(10, True)



# Generated at 2022-06-21 19:26:38.927559
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(10, True).on_fail(lambda x: print('x')).is_success
    assert not Try(10, False).on_fail(lambda x: print('x')).is_success
    assert Try(10, True).on_fail(lambda x: print('x')).value == 10
    assert Try(10, False).on_fail(lambda x: print('x')).value == 10


# Generated at 2022-06-21 19:26:41.874944
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1, None).get_or_else("error!") == 1
    assert Try.of(lambda: 1/0, None).get_or_else("error!") == "error!"


# Generated at 2022-06-21 19:26:45.642838
# Unit test for constructor of class Try
def test_Try():
    assert Try(None, False) == Try(None, False)
    assert Try(None, True) == Try(None, True)
    assert Try(None, False) != Try(None, True)


# Generated at 2022-06-21 19:26:48.264746
# Unit test for constructor of class Try
def test_Try():
    t = Try(1, True)
    assert Try(1, True) == t



# Generated at 2022-06-21 19:26:50.246651
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-21 19:26:53.087201
# Unit test for method on_success of class Try
def test_Try_on_success():
    def success_callback(value):
        print('Successfully callback')
        assert value == 'my value'

    def fail_callback(value):
        print('Fail callback')
        assert value == Exception()

    assert Try.of(lambda: 'my value').on_success(success_callback) == Try('my value', True)
    assert Try(Exception(), False).on_success(success_callback) == Try(Exception(), False)

# Generated at 2022-06-21 19:27:07.805304
# Unit test for method map of class Try
def test_Try_map():
    """
    Test case:
        - given try_one = Try(1, True), successfully monad Try with value 1
        - given second_try = try_one.map(lambda x: x * 2)
        - expect second_try == Try(2, True)
        - expect second_try == Try.of(lambda: try_one.map(lambda x: x * 2))
    """

    import pytest

    with pytest.raises(Exception) as exc:
        Try.of(lambda: 1 / 0)

    assert Try(1, True) == Try(1, True)
    assert Try(2, True) == Try.of(lambda: 2)
    assert Try(exc.value, False) == Try.of(lambda: 1 / 0)


# Generated at 2022-06-21 19:27:12.063218
# Unit test for method get of class Try
def test_Try_get():
    def fn(value) -> Try:
        return Try(value, True)

    assert_equals(Try.of(fn, 'foo').get(), 'foo')
    assert_equals(Try.of(fn, 123).get(), 123)
    assert_equals(Try.of(fn, {'a': 1}).get(), {'a': 1})


# Generated at 2022-06-21 19:27:13.874288
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'


# Generated at 2022-06-21 19:27:19.516907
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    # When do not raise exception, then do nothing
    assert Try.of(lambda: 1).on_fail(lambda x: 'Error') == Try(1, True)
    # When raise exception, then execute fail_callback with exception
    assert Try.of(lambda: 1/0).on_fail(lambda x: 'Error') == Try('Error', False)


# Generated at 2022-06-21 19:27:31.140117
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Call success_callback function with monad value when monad is successfully.
    """
    # Case 1: when monad is successfully
    success_callback_mock = Mock(return_value=None)
    Try.of(lambda a: a, 'test').on_success(success_callback_mock)

    success_callback_mock.assert_called_with('test')

    # Case 2: when monad is not successfully
    success_callback_mock = Mock(return_value=None)
    Try.of(lambda a: a/0, 'test').on_success(success_callback_mock)

    success_callback_mock.assert_not_called()

    # Case 3: return self
    actual = Try(1, True)
    expected = actual.on_success(lambda *_: _)
   

# Generated at 2022-06-21 19:27:40.492084
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) != Try(1, False)
    assert Try(1, False) != Try(1, True)
    assert Try(1, True) != Try(2, True)
    assert Try(1, False) != Try(2, False)
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)
# End unit test for constructor of class Try


# Generated at 2022-06-21 19:27:42.405127
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try(0, False).on_fail(lambda x: x) == Try(0, False)



# Generated at 2022-06-21 19:27:44.670097
# Unit test for method get of class Try
def test_Try_get():
    m = Try(10, True).get()
    assert m == 10

    m = Try(10, False).get()
    assert m == 10


# Generated at 2022-06-21 19:27:53.719674
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def test_get_or_else(expected: Any, default_value: str) -> None:
        assert Try.of(lambda: 'result', ()).get_or_else(default_value) == expected

    def test_get_or_else_with_exception(expected: Any, default_value: str) -> None:
        assert Try.of(lambda: 1/0).get_or_else(default_value) == expected

    test_get_or_else('result', 'default')
    test_get_or_else_with_exception('default', 'default')


# Generated at 2022-06-21 19:27:56.575199
# Unit test for method get of class Try
def test_Try_get():
  try_value = Try(1, True)
  assert try_value.get() == 1



# Generated at 2022-06-21 19:28:15.168499
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Unit test for method on_success of class Try.
    """
    mock_success_callback = Mock()
    mock_fail_callback = Mock()

    success_try = Try(1, True)
    fail_try = Try(1, False)

    success_try.on_fail(mock_fail_callback)
    fail_try.on_fail(mock_fail_callback)

    success_try.on_success(mock_success_callback)
    fail_try.on_success(mock_success_callback)

    mock_success_callback.assert_called_once_with(1)
    mock_fail_callback.assert_called_once_with(1)


# Generated at 2022-06-21 19:28:17.500028
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try('success', True).get_or_else('fail') == 'success'
    assert Try(None, False).get_or_else('fail') == 'fail'


# Generated at 2022-06-21 19:28:24.105701
# Unit test for method bind of class Try
def test_Try_bind():
    # Success case
    assert Try.of(lambda x: x, 1).bind(lambda x: Try(x ** 2, True)) == Try(1, True).bind(lambda x: Try(x ** 2, True))
    # Fail
    assert Try.of(lambda x: x, Exception).bind(lambda x: Try(x ** 2, True)) == Try(Exception, False).bind(lambda x: Try(x ** 2, True))


# Generated at 2022-06-21 19:28:30.839893
# Unit test for method map of class Try
def test_Try_map():
    assert Try(lambda x: x + 1, True).map(lambda x: x(1)) == Try(2, True)
    assert Try(lambda x: x + 1, True).map(lambda x: 1 / x(0)) == Try(ZeroDivisionError(), False)
    assert Try(lambda x: x + 1, False).map(lambda x: 1 / x(0)) == Try(lambda x: x + 1, False)


# Generated at 2022-06-21 19:28:33.988513
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    def fail_callback(value):
        assert True

    def success_callback(value):
        assert False

    Try(10, False).on_fail(fail_callback).on_success(success_callback)


# Generated at 2022-06-21 19:28:38.951336
# Unit test for method map of class Try
def test_Try_map():  # pragma: no cover
    """
    To check work of method Try.map
    """

    def function_to_wrap(a: int, b: int) -> int:
        return a + b
    assert Try.of(function_to_wrap, 4, 5) == Try(9, True)
    assert Try.of(function_to_wrap, 4, 5).map(lambda a: a + 1) == Try(10, True)

# Generated at 2022-06-21 19:28:46.705028
# Unit test for method map of class Try
def test_Try_map():
    try_function = lambda x: x
    assert Try.of(try_function, 1) == Try(1, True)
    assert Try.of(try_function, 1).map(lambda x: x + 1) == Try(2, True)

    def failing_function():
        raise Exception()

    assert Try.of(failing_function) == Try(Exception(), False)
    assert Try.of(failing_function).map(lambda x: 1) == Try(Exception(), False)


# Generated at 2022-06-21 19:28:53.466409
# Unit test for method bind of class Try
def test_Try_bind():
    def foo(x: int) -> Try[int]:
        if x == 0:
            raise ZeroDivisionError('division by zero')
        return Try(100 / x, True)

    assert Try.of(foo, 2).bind(foo).value == 25
    assert Try.of(foo, 0).bind(foo).value.__class__ == ZeroDivisionError
    assert not Try.of(foo, 0).bind(foo).is_success


# Generated at 2022-06-21 19:29:00.587970
# Unit test for method map of class Try
def test_Try_map():
    x = Try.of(lambda x: x+1, 0)
    y = Try.of(lambda x: x-1, 0).map(lambda x: x+1)
    z = Try.of(lambda x: x/0, 1).map(lambda x: x+1)
    assert x == Try(1, True)
    assert y == Try(1, True)
    assert z == Try(DivisionByZeroError("division by zero"), False)


# Generated at 2022-06-21 19:29:08.481115
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    def function(value):
        return value + 1

    assert Try(function(0), True) == Try(1, True)
    assert Try(function(0), True) == Try(function(0), True)
    assert Try(function(0), True) != Try(1, False)
    assert Try(function(0), True) != Try(1, True)
    assert Try(function(0), True) != Try(function(0), False)


# Generated at 2022-06-21 19:29:33.683849
# Unit test for method bind of class Try
def test_Try_bind():
    s = 'test'
    t = Try.of(lambda: s + 'success')
    f = Try.of(lambda: 1/0)
    tt = lambda x: Try.of(x)
    ff = lambda x: Try.of(lambda: 1/0)

    assert t.bind(tt) == Try.of(s + 'success', True)
    assert t.bind(ff) == Try.of(lambda: 1/0, False)
    assert f.bind(ff) == Try.of(lambda: 1/0, False)
    assert f.bind(tt) == Try.of(lambda: 1/0, False)


# Generated at 2022-06-21 19:29:37.648657
# Unit test for method on_success of class Try

# Generated at 2022-06-21 19:29:41.132324
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    assert Try(5, True).get() == 5
    assert Try('Hello', True).get() == 'Hello'
    assert Try(Exception('Exception'), False).get() == Exception('Exception')


# Generated at 2022-06-21 19:29:42.780701
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(Exception(), False) == Try(Exception(), False)
    assert Try(1, True) != Try(1, False)
    assert Try(Exception(), False) != Try(Exception(), True)


# Generated at 2022-06-21 19:29:47.842409
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try('test', False)) == 'Try[value=test, is_success=False]'
    assert str(Try('test', True)) == 'Try[value=test, is_success=True]'
    assert str(Try(['a', 'b', 'c'], False)) == "Try[value=['a', 'b', 'c'], is_success=False]"

# Generated at 2022-06-21 19:29:53.571527
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    try:
        raise Exception('raised exception')
    except Exception as e:
        value_expected = e
        value = None
        monad = Try.of(lambda x: x, 0).on_fail(lambda x: value.append(x))  # Exception here
        value_actual = value
        assert (value_actual == value_expected)


# Generated at 2022-06-21 19:29:56.116803
# Unit test for method on_success of class Try
def test_Try_on_success():
    def check_add(arg):
        assert arg == 2 + 2

    Try(2 + 2, True).on_success(check_add)
    Try(2 + 2, False).on_success(check_add)



# Generated at 2022-06-21 19:30:03.373262
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    true_monad = Try(1, True)
    false_monad = Try(1, False)

    assert true_monad == Try(1, True)
    assert false_monad == Try(1, False)

    assert true_monad != Try(1, False)
    assert false_monad != Try(1, True)

    assert true_monad != Try(2, True)
    assert false_monad != Try(2, False)


# Generated at 2022-06-21 19:30:08.179926
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try('error', False)) == 'Try[value=error, is_success=False]'


# Generated at 2022-06-21 19:30:13.350924
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Function that unit test for on_success method of Try class.

    :return: True if all unit test run successfully and False othercase
    """
    def init_try():
        return Try(10, True)

    def validate_res(res):
        return res == 20

    def success_callback(value):
        return value*2

    return init_try().on_success(success_callback).value == 20

