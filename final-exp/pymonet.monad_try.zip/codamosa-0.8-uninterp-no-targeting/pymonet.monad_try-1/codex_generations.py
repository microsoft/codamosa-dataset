

# Generated at 2022-06-21 19:20:54.764416
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 1, None) == Try(1, True)
    assert Try.of(lambda: 1, None).get_or_else(0) == 1
    assert Try.of(lambda: 1 / 0, None).get_or_else(0) == 0

# Generated at 2022-06-21 19:20:59.097720
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    """
    The test shows what string representation of class Try.
    """
    assert str(Try(1, True)) == 'Tru[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Tru[value=1, is_success=False]'



# Generated at 2022-06-21 19:21:09.704751
# Unit test for method bind of class Try
def test_Try_bind():
    def my_error() -> Try[int]:
        try:
            return Try(1/0, True)
        except ZeroDivisionError as e:
            return Try(e, False)

    def my_test() -> Try[int]:
        try:
            return Try(2 / 2, True)
        except Exception as e:
            return Try(e, False)

    assert my_error().bind(lambda _: Try(1, True)) == Try(1, True)
    assert my_test().bind(lambda _: Try(1, True)) == Try(1, True)
    assert my_error().bind(lambda _: Try(1, False)) == Try(1, False)
    assert my_test().bind(lambda _: Try(1, False)) == Try(1, False)


# Generated at 2022-06-21 19:21:15.036967
# Unit test for constructor of class Try
def test_Try():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) != Try(2, True)
    assert Try(2, False) != Try(1, True)
    assert Try(1, True) != 'Try[value=1, is_successful=True]'
    assert 'Try[value=1, is_successful=True]' == str(Try(1, True))


# Generated at 2022-06-21 19:21:20.445536
# Unit test for method on_fail of class Try
def test_Try_on_fail():  # pragma: no cover
    t = Try(1, True)
    assert t.on_fail(lambda v: print(v)) == t
    t = Try(1, False)
    assert t.on_fail(lambda v: print(v)) == t


# Generated at 2022-06-21 19:21:25.115935
# Unit test for method bind of class Try
def test_Try_bind():
    def div(a, b):
        return a / b

    result = Try.of(div, 2, 0).bind(lambda x: Try.of(div, x, 0))
    assert result != None
    assert result.value != None
    assert type(result.value) == ZeroDivisionError
    assert result.is_success == False

# Generated at 2022-06-21 19:21:30.008279
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 1, ).on_success(lambda v: print('success with value:', v)).is_success
    assert not Try.of(lambda: 1 / 0, ).on_success(lambda v: print('success with value:', v)).is_success


# Generated at 2022-06-21 19:21:33.636710
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    tt = Try(1, True)
    ff = Try(2, False)
    assert tt == Try(1, True)
    assert ff == Try(2, False)


# Generated at 2022-06-21 19:21:38.840893
# Unit test for method on_success of class Try
def test_Try_on_success():
    """
    Run test for method on_success of class Try.
    """
    assert Try(0, True)\
        .on_success(lambda value: setattr(value, 'test', True))\
        .get().test

    assert not hasattr(Try(0, False).on_success(
        lambda value: setattr(value, 'test', True)).get(), 'test')



# Generated at 2022-06-21 19:21:44.301430
# Unit test for method map of class Try
def test_Try_map():
    """
    Unit test for method map of class Try
    """
    test = Try(10, True)
    new_test = test.map(lambda x: x + 10)

    assert new_test.get() == 20
    assert new_test.is_success

# Generated at 2022-06-21 19:21:51.496191
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Method on_fail(fail_callback) should call fail_callback function
    when monad is not successfully.
    """
    assert Try(1, True).on_fail(lambda x: None).is_success is True
    assert Try('Error', False).on_fail(lambda x: None).is_success is False


# Generated at 2022-06-21 19:21:54.645020
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'



# Generated at 2022-06-21 19:21:56.913105
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, True) != Try(2, True)



# Generated at 2022-06-21 19:22:06.034340
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Tests for method bind of class Try.

    Test case for successfully test case:
    1. Create Try class with successfully value.
    2. Check is value successfully.
    3. Create binder function, which return Try.
    4. Bind created function with Try.
    5. Check is result Try successfully.
    6. Check value in result Try.

    Test case for not successfully test case:
    1. Create Try class with not successfully value.
    2. Check is not successfully value.
    3. Create binder function, which return Try.
    4. Bind created function with Try.
    5. Check is result Try not successfully.
    6. Check value in result Try.

    :returns: nothing
    :rtype: None
    """

# Generated at 2022-06-21 19:22:14.164539
# Unit test for method bind of class Try
def test_Try_bind():
    def fn_with_exception(num):
        if num == 0:
            raise Exception("Dividing by zero")
        return 1 / num

    func = lambda: fn_with_exception(0)
    try_exception = Try.of(func)
    result = try_exception.bind(lambda: Try.of(fn_with_exception, 1))
    expected = Try(1, True)
    assert result == expected

# Generated at 2022-06-21 19:22:19.316507
# Unit test for method bind of class Try
def test_Try_bind():
    # Given
    try_get_foo_from_bar_baz_dictionary_with_success = Try(lambda: {'bar': 'baz'}['foo'], True)

    # When
    binded_try = try_get_foo_from_bar_baz_dictionary_with_success.bind(lambda x: Try(x, True))

    # Then
    assert binded_try is try_get_foo_from_bar_baz_dictionary_with_success


# Generated at 2022-06-21 19:22:25.069218
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():  # pragma: no cover
    assert Try.of(lambda : 2, []).get_or_else(1) == 2
    assert Try.of(lambda: 1 / 0, []).get_or_else(1) == 1
    assert Try.of(lambda : 2, []).get_or_else(lambda: 1 / 0) == 2

# Generated at 2022-06-21 19:22:29.310205
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Case when monad is not successfully.
    """
    def assert_on_fail(e: Exception):
        assert isinstance(e, Exception)
    try:
        raise Exception()
    except Exception as e:
        try_ = Try(e, False)
    try_.on_fail(assert_on_fail)


# Generated at 2022-06-21 19:22:40.897518
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    assert Try.of(int, '123').on_fail(print) == Try(123, True)
    assert Try.of(int, '123').on_fail(print).is_success
    assert Try.of(int, '123').on_fail(print).value == 123

    assert Try.of(int, 'a123').on_fail(print) == Try('invalid literal for int() with base 10: \'a123\'', False)
    assert not Try.of(int, 'a123').on_fail(print).is_success
    assert Try.of(int, 'a123').on_fail(print).value == 'invalid literal for int() with base 10: \'a123\''


# Generated at 2022-06-21 19:22:45.287065
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(Exception(), False)) == 'Try[value=Exception, is_success=False]'



# Generated at 2022-06-21 19:22:51.891906
# Unit test for method get of class Try
def test_Try_get():
    # Setup
    exception = Exception('error')
    expected = 'result'

    # Exercise
    try_result = Try.of(lambda: expected)
    try_exception = Try.of(lambda _: raise_exception(exception))

    # Verify
    assert try_result.get() == expected


# Generated at 2022-06-21 19:22:54.418643
# Unit test for method __str__ of class Try
def test_Try___str__():  # pragma: no cover
    try_ = Try(Exception('Test exception'), False)
    assert str(try_) == "Try[value=Test exception, is_success=False]"


# Generated at 2022-06-21 19:23:02.030620
# Unit test for method map of class Try
def test_Try_map():
    def double(x):
        return x * 2
    def fail(x):
        raise ValueError(x)
    assert Try.of(double, 0) == Try(0, True)
    assert Try.of(fail, 0) == Try(ValueError('0'), False)
    assert Try.of(double, 0).map(double) == Try(0, True).map(double)
    assert Try.of(fail, 0).map(double) == Try(ValueError('0'), False).map(double)
    assert Try.of(double, 0).map(fail) == Try(0, True).map(fail)
    assert Try.of(fail, 0).map(fail) == Try(ValueError('0'), False).map(fail)


# Generated at 2022-06-21 19:23:05.383446
# Unit test for method __str__ of class Try
def test_Try___str__():
    # arrange
    t = Try('foo', True)

    # act
    res = str(t)

    # assert
    assert res == 'Try[value=foo, is_success=True]'


# Generated at 2022-06-21 19:23:16.694299
# Unit test for method bind of class Try
def test_Try_bind():
    def raise_value_error():
        raise ValueError('Test exception')
    def upper(x):
        return x.upper()
    def upper_try(x):
        return Try(x.upper(), True)

    assert Try(lambda x:x, True).bind(upper_try) == Try('<function <lambda> at 0x7fa80f81b488>', True)
    assert Try(lambda x:x, True).bind(raise_value_error) == Try(ValueError('Test exception'), False)
    assert Try(lambda x:x, False).bind(upper_try) == Try(lambda x:x, False)
    assert Try(lambda x:x, False).bind(raise_value_error) == Try(lambda x:x, False)


# Generated at 2022-06-21 19:23:19.933870
# Unit test for method __str__ of class Try
def test_Try___str__():
    value = 'success'
    success_try = Try(value, True)
    assert 'Try[value=success, is_success=True]' == success_try.__str__()
    value = 'fail'
    fail_try = Try(value, False)
    assert 'Try[value=fail, is_success=False]' == fail_try.__str__()


# Generated at 2022-06-21 19:23:23.908222
# Unit test for method map of class Try
def test_Try_map():
    assert Try(2, True).map(lambda x: x + 2) == Try(4, True)
    assert Try(2, False).map(lambda x: x + 2) == Try(2, False)


# Generated at 2022-06-21 19:23:27.904753
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try.of(lambda: 4).on_success(lambda x: x+2) == Try(4, True)
    assert Try.of(lambda: 4).on_success(lambda x: x+2) == Try(4, True)


# Generated at 2022-06-21 19:23:31.265756
# Unit test for method map of class Try
def test_Try_map():
    f = lambda x: x ** 2
    assert Try(100, True).map(f) == Try(10000, True)
    assert Try(100, False).map(f) == Try(100, False)


# Generated at 2022-06-21 19:23:36.496819
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(1, True).filter(lambda x: x == 1) == Try(1, True)
    assert Try(1, True).filter(lambda x: x == 2) == Try(1, False)
    assert Try(1, False).filter(lambda x: x == 1) == Try(1, False)

# Generated at 2022-06-21 19:23:50.868292
# Unit test for constructor of class Try
def test_Try():
    assert Try('Success', True) == Try('Success', True)
    assert Try(Exception('Fail'), False) == Try(Exception('Fail'), False)
    assert Try('Not_equal', True) != Try('Not_equal', False)
    assert Try('Success', True) != Try('Not_equal', True)
    assert Try('Not_equal', False) != Try('Not_equal', True)
    assert Try('Success', True).__str__() == 'Try[value=Success, is_success=True]'
    assert Try(Exception('Fail'), False).__str__() == 'Try[value=Fail, is_success=False]'


# Generated at 2022-06-21 19:23:59.861476
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    """
    Test for method on_fail of class Try.

    :returns: pass to test runner when test is successfully
    :rtype: None
    """
    msg = None
    Try.of(lambda: 1 / 0).on_fail(lambda e: setattr(e, 'msg', 'test'))
    assert 'test' == e.msg

    success_call = False

    Try.of(lambda: 1 / 0).on_success(lambda e: success_call)
    assert not success_call


# Generated at 2022-06-21 19:24:02.387104
# Unit test for method get of class Try
def test_Try_get():  # pragma: no cover
    def test():
        raise Exception("Testing")
    assert Try.of(test).get() == "Testing"



# Generated at 2022-06-21 19:24:05.188441
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try(1, True).get_or_else(2) == 1
    assert Try(1, False).get_or_else(2) == 2


# Generated at 2022-06-21 19:24:14.108560
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(None, True)) == 'Try[value=None, is_success=True]'
    assert str(Try(None, False)) == 'Try[value=None, is_success=False]'
    assert str(Try(10, True)) == 'Try[value=10, is_success=True]'
    assert str(Try(10, False)) == 'Try[value=10, is_success=False]'
    assert str(Try('hello', True)) == 'Try[value=hello, is_success=True]'
    assert str(Try('hello', False)) == 'Try[value=hello, is_success=False]'


# Generated at 2022-06-21 19:24:19.095505
# Unit test for constructor of class Try
def test_Try():
    try_monad = Try(1, True)
    assert try_monad.is_success is True
    assert try_monad.value == 1

    try_monad = Try('value', False)
    assert try_monad.is_success is False
    assert try_monad.value == 'value'
    assert not try_monad.is_success is True


# Generated at 2022-06-21 19:24:30.143030
# Unit test for method bind of class Try
def test_Try_bind():
    """
    Test for method bind of class Try
    """
    def to_int(value):
        return Try(int(value), True)

    def to_string(value):
        return Try(str(value), True)

    assert Try(2, True).bind(to_string) == Try('2', True), 'test 1'
    assert Try('2', True).bind(to_int).bind(to_string) == Try('2', True), 'test 2'
    assert Try('two', True).bind(to_int).bind(to_string) == Try('two', False), 'test 3'
    assert Try(2, True).bind(to_int).bind(to_int) == Try(2, True), 'test 4'
    assert Try(2, True).bind(to_string).bind(to_int) == Try

# Generated at 2022-06-21 19:24:38.297558
# Unit test for method filter of class Try
def test_Try_filter():
    result = Try.of(lambda: [1, 2, 3]) \
        .filter(lambda x: len(x) == 3) \
        .bind(lambda x: Try.of(lambda: x[3]))
    assert result == Try(IndexError('list index out of range'), False)

    result = Try.of(lambda: [1, 2, 3]) \
        .bind(lambda x: Try.of(lambda: x[3])) \
        .filter(lambda x: len(x) == 3)
    assert result == Try(IndexError('list index out of range'), False)

    result = Try.of(lambda: [1, 2, 3]) \
        .filter(lambda x: len(x) == 3) \
        .bind(lambda x: Try.of(lambda: x[3])) \
        .filter

# Generated at 2022-06-21 19:24:39.463127
# Unit test for method get of class Try
def test_Try_get():
    assert Try.of(lambda: 5, None).get() == 5


# Generated at 2022-06-21 19:24:41.183407
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert Try(1, True) == Try(1, True)
    assert Try(1, False) == Try(1, False)



# Generated at 2022-06-21 19:24:59.087896
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_success = Try(1, True)
    try_fail = Try(Exception('Exception'), False)

    assert try_success == try_success, "__eq__"
    assert try_fail == try_fail, "__eq__"
    assert try_success != try_fail, "__eq__"
    assert try_fail != try_success, "__eq__"

    assert Try(2, True) == Try(2, True), "__eq__"
    assert Try(1, False) == Try(1, False), "__eq__"
    assert Try(2, True) != Try(1, True), "__eq__"
    assert Try(2, True) != Try(1, False), "__eq__"
    assert Try(1, False) != Try(2, True), "__eq__"

# Generated at 2022-06-21 19:25:03.157114
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert(Try.of(lambda: 1, ()).get_or_else(2) == 1)
    assert(Try.of(lambda: 1, ()).map(lambda x: x+1).get_or_else(2) == 2)
    assert(Try.of(lambda x: x+1, 2).map(lambda y: y+1).get_or_else(0) == 4)


# Generated at 2022-06-21 19:25:08.335493
# Unit test for method filter of class Try
def test_Try_filter():
    x = 3
    assert Try(x, True).filter(lambda x: x < 10) == Try(3, True)
    assert Try(x, True).filter(lambda x: x == 10) == Try(3, False)
    assert Try(x, False).filter(lambda x: x < 10) == Try(3, False)


# Generated at 2022-06-21 19:25:14.361569
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda v: 2/v, 2).filter(lambda v: v > 0) == Try(1.0, True)

    assert Try.of(lambda v: 2/v, 0).filter(lambda v: v > 0) == Try(0.0, False)
    assert Try.of(lambda v: 2/v, 0).filter(lambda v: v > 0).get() == 0.0


# Generated at 2022-06-21 19:25:18.090547
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    def f():
        return False

    def g():
        raise Exception('qwq')

    def h():
        return True

    assert Try.of(f).get_or_else(True)
    assert Try.of(g).get_or_else(True)
    assert not Try.of(h).get_or_else(False)



# Generated at 2022-06-21 19:25:22.600484
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    assert Try.of(lambda: 5, ).get_or_else(6) == 5
    assert Try.of(lambda: 1/0, ).get_or_else(6) == 6
    assert Try.of(lambda: "a", ).get_or_else(6) == "a"


# Generated at 2022-06-21 19:25:29.986928
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda a: a, 1) == Try(1, True)
    assert Try.of(lambda: 1 / 0, None) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda a: a, 1).map(lambda a: a + 1) == Try(2, True)
    assert Try.of(lambda: 1 / 0, None).map(lambda a: a + 1) == Try(ZeroDivisionError(), False)
    assert Try.of(lambda: 1 / 0, None).map(lambda: 1 / 0) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:25:33.693546
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try('value', True)) == 'Try[value=value, is_success=True]'
    assert str(Try('value', False)) == 'Try[value=value, is_success=False]'


# Generated at 2022-06-21 19:25:43.666416
# Unit test for method map of class Try
def test_Try_map():
    assert Try.of(lambda x: x ** 2, 5) == Try(25, True)
    assert Try.of(lambda x: x ** 2, 5).map(lambda x: x / 5) == Try(5, True)
    assert Try.of(lambda x: x ** 2, 0) == Try(0, True)
    assert Try.of(lambda x: x ** 2, 0).map(lambda x: x / 5) == Try(0, True)
    assert Try.of(lambda x: 1 / x, 0).map(lambda x: x / 5) == Try(0, False)



# Generated at 2022-06-21 19:25:47.101111
# Unit test for method on_success of class Try
def test_Try_on_success():
    def inc(value):
        return value + 1
    assert Try(1, True).on_success(inc) == Try(1, True)
    assert Try(1, False).on_success(inc) == Try(1, False)


# Generated at 2022-06-21 19:26:07.445666
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert(str(Try(12, True)) == 'Try[value=12, is_success=True]')
    assert(str(Try(12, False)) == 'Try[value=12, is_success=False]')



# Generated at 2022-06-21 19:26:10.110056
# Unit test for method get of class Try
def test_Try_get():
    value = 42
    try_monad = Try.of(lambda: value)
    assert try_monad.get() == value



# Generated at 2022-06-21 19:26:17.093624
# Unit test for method bind of class Try
def test_Try_bind():
    from re import compile

    pattern = compile('^[0-9]+$')

    assert Try.of(lambda: pattern.search('45').group(0)).bind(lambda x: Try.of(int, x)) == Try(45, True)
    assert Try.of(lambda: pattern.search('ab').group(0)).bind(lambda x: Try.of(int, x)) == Try('ab', False)


# Generated at 2022-06-21 19:26:20.956785
# Unit test for method on_success of class Try
def test_Try_on_success():
    def add_two(number):
        return number + 2

    def mock_success_callback(number):
        assert number == 3

    mock_value = Try(1, True)
    mock_value.map(add_two)
    mock_value.on_success(mock_success_callback)



# Generated at 2022-06-21 19:26:21.937317
# Unit test for method get of class Try
def test_Try_get():
    assert Try(1, True).get() == 1

# Generated at 2022-06-21 19:26:27.730251
# Unit test for method __str__ of class Try
def test_Try___str__():
    """
    Test of Try.__str__(self) method.

    :return:
    """
    assert str(Try('value', True)) == "Try[value='value', is_success=True]"
    assert str(Try('value', False)) == "Try[value='value', is_success=False]"


# Generated at 2022-06-21 19:26:32.942633
# Unit test for constructor of class Try
def test_Try():
    assert Try(4, False) == Try(4, False)
    assert Try(4, True) == Try(4, True)
    assert Try(4, False) != Try(4, True)
    assert Try(4, True) != Try(2, True)
    assert Try(4, False) != Try(3, False)


# Generated at 2022-06-21 19:26:37.449496
# Unit test for method on_success of class Try
def test_Try_on_success():
    # Arrange
    def fn():
        print('fn()')

    # Act
    Try.of(fn).on_success(lambda _: print('fn() was called'))

    # Assert
    assert True



# Generated at 2022-06-21 19:26:45.451073
# Unit test for method filter of class Try
def test_Try_filter():
    import collections
    import random

    def square(value):
        return value * value

    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def is_zero(value):
        return value == 0

    def is_not_zero(value):
        return value != 0

    def raise_exception():
        raise Exception()

    def get_random_number(lower_bound, upper_bound):
        return random.randint(lower_bound, upper_bound)

    TestCase = collections.namedtuple('TestCase', ['name', 'fn', 'filterer', 'expected'])


# Generated at 2022-06-21 19:26:52.126297
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    assert Try.of(lambda _: 2).on_success(lambda _: 1 / 0) == Try(2, True)
    assert Try\
        .of(lambda _: 1 / 0)\
        .on_success(lambda _: 1 / 0)\
        .on_success(lambda _: 1 / 0)\
        == Try(ZeroDivisionError(), False)



# Generated at 2022-06-21 19:27:33.803819
# Unit test for constructor of class Try
def test_Try():
    """
    Testing __init__ method in Try class.

    :returns: assert that all works correctly.
    :rtype: None
    """
    _Try = Try(1, True)
    assert _Try.value == 1
    assert _Try.is_success == True
    assert _Try == Try(1, True)


# Generated at 2022-06-21 19:27:38.417438
# Unit test for method __eq__ of class Try
def test_Try___eq__():
    try_1 = Try(5, True)
    try_2 = Try('5', True)
    assert try_1 == try_1
    assert try_2 == try_2
    assert not (try_1 == try_2)


# Generated at 2022-06-21 19:27:41.957068
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'


# Generated at 2022-06-21 19:27:48.267573
# Unit test for constructor of class Try
def test_Try():
    with pytest.raises(TypeError):
        Try("success", True)
    with pytest.raises(TypeError):
        Try("fail", False)
    with pytest.raises(TypeError):
        Try("success", "True")

    # Test creating of successfully Try
    test_value = Try("success", True)
    assert test_value.get() == "success"
    assert test_value.is_success
    assert test_value == Try("success", True)
    assert str(test_value) == 'Try[value=success, is_success=True]'

    # Test creating of not successfully Try
    test_value = Try("fail", False)
    assert test_value.get() == "fail"
    assert not test_value.is_success
    assert test_value == Try("fail", False)
   

# Generated at 2022-06-21 19:27:56.645761
# Unit test for method __str__ of class Try
def test_Try___str__():
    assert str(Try(1, True)) == 'Try[value=1, is_success=True]'
    assert str(Try(1, False)) == 'Try[value=1, is_success=False]'
    assert str(Try('str', True)) == 'Try[value=str, is_success=True]'
    assert str(Try('str', False)) == 'Try[value=str, is_success=False]'
    assert str(Try([], True)) == 'Try[value=[], is_success=True]'
    assert str(Try([], False)) == 'Try[value=[], is_success=False]'
    assert str(Try({}, True)) == 'Try[value={}, is_success=True]'
    assert str(Try({}, False)) == 'Try[value={}, is_success=False]'

# Generated at 2022-06-21 19:28:01.898003
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try(42, True).filter(lambda x: x == 42) == Try(42, True)
    assert Try(42, True).filter(lambda x: x != 42) == Try(42, False)
    assert Try(Exception(), False).filter(lambda x: True) == Try(Exception(), False)

# Generated at 2022-06-21 19:28:05.605190
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try(Try(1, True).bind(lambda x: Try(x + 1, True)).get(), True) == Try(2, True)
    assert Try(Try(1, True).bind(lambda x: Try(x / 0, True)).get(), False) == Try(1, False)
    assert Try.of(lambda x: x / 0, 1).bind(lambda x: Try(x + 1, True)) \
        == Try(1, False)
    assert Try.of(lambda x: x + 1, 1).bind(lambda x: Try(x / 0, True)) \
        == Try(1, False)



# Generated at 2022-06-21 19:28:11.790930
# Unit test for method filter of class Try
def test_Try_filter():  # pragma: no cover
    filterer = lambda x: x > 8
    assert Try(9, True).filter(filterer) == Try(9, True)
    assert Try(1, True).filter(filterer) == Try(1, False)
    assert Try(9, False).filter(filterer) == Try(9, False)


# Generated at 2022-06-21 19:28:22.086854
# Unit test for method on_success of class Try
def test_Try_on_success():  # pragma: no cover
    assert Try.of(lambda a: 'ok')('ok').on_success(lambda a: print(a)) == Try('ok', True)
    assert Try.of(lambda a: 'ok')('ok').on_success(lambda a: print(a)).on_success(lambda a: print(a)) == Try('ok', True)
    assert Try.of(lambda a: 'ok')('ok').on_success(lambda a: print(a)).on_success(lambda a: print(a)).on_success(lambda a: print(a)) == Try('ok', True)

# Generated at 2022-06-21 19:28:28.790996
# Unit test for constructor of class Try
def test_Try():  # pragma: no cover
    print('')
    print('Try')
    print('--------------------------------------------------------------------------------')
    try_ = Try(1, True)
    assert try_ == Try(1, True)
    print(try_)
    try_ = Try('error', False)
    assert try_ == Try('error', False)
    print(try_)
    print('--------------------------------------------------------------------------------')


# Generated at 2022-06-21 19:29:40.312573
# Unit test for method on_fail of class Try

# Generated at 2022-06-21 19:29:45.483512
# Unit test for method map of class Try
def test_Try_map():
    """
    Test Try map method
    """
    assert Try.of(lambda x: x, 1).map(lambda x: x + 1) == Try(2, True)

    assert Try.of(lambda x: 1/0, 1).map(lambda x: x + 1) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:29:50.473466
# Unit test for method on_fail of class Try
def test_Try_on_fail():
    value = 1
    try_p = Try(value, True)
    try_n = Try(None, False)

# Generated at 2022-06-21 19:29:54.695899
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Given
    value = "Success!"
    default_value = "Default!"

    # When
    try_success = Try(value, True)
    try_fail = Try(value, False)

    # Then
    assert try_success.get_or_else(default_value) == value
    assert try_fail.get_or_else(default_value) == default_value

# Generated at 2022-06-21 19:30:02.422164
# Unit test for method get_or_else of class Try
def test_Try_get_or_else():
    # Prepare
    try_obj_success = Try(100, True)
    try_obj_fail = Try(100, False)

    # Do
    try_obj_success_get_or_else = try_obj_success.get_or_else(0)
    try_obj_fail_get_or_else = try_obj_fail.get_or_else(0)

    # Assert
    assert try_obj_success_get_or_else == 100
    assert try_obj_fail_get_or_else == 0



# Generated at 2022-06-21 19:30:05.774962
# Unit test for constructor of class Try
def test_Try():
    assert Try('value', True) == Try('value', True)
    assert Try(1, False) != Try('1', False)
    assert Try(1, True) != Try(1, False)



# Generated at 2022-06-21 19:30:11.845922
# Unit test for method filter of class Try
def test_Try_filter():
    assert Try.of(lambda x: x * 2, 10).bind(
        lambda x: Try.of(lambda x: x + 2, x)
    ).filter(lambda x: x % 2 == 0) == Try(24, True)
    assert Try.of(lambda x: x * 2, 10).bind(
        lambda x: Try.of(lambda x: x + 2, x)
    ).filter(lambda x: x % 3 == 0) == Try(22, False)



# Generated at 2022-06-21 19:30:17.664927
# Unit test for method bind of class Try
def test_Try_bind():
    assert Try.of(lambda: 1).bind(lambda v: Try(v + 1, True)) == Try(2, True)
    assert Try.of(lambda: 1/0).bind(lambda v: Try(v + 1, True)) == Try(ZeroDivisionError(), False)


# Generated at 2022-06-21 19:30:23.826736
# Unit test for method on_success of class Try
def test_Try_on_success():
    # given
    some_value = None
    not_successfully_monad = Try(None, False)
    successfully_monad = Try(None, True)

    # when
    successfully_monad.on_success(lambda _: setattr(some_value, 'a', 42))
    not_successfully_monad.on_success(lambda _: setattr(some_value, 'a', 42))

    # then
    assert some_value.a == 42


# Generated at 2022-06-21 19:30:26.478172
# Unit test for method on_success of class Try
def test_Try_on_success():
    assert Try(42, False).on_success(lambda x: x + 1) == Try(42, False)
    assert Try(42, True).on_success(lambda x: x + 1) == Try(43, True)
