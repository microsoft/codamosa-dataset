

# Generated at 2022-06-25 17:10:34.506824
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:10:44.409227
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)

    test_cached_property___get__()

    if True:
        with open(__file__, 'w') as file_0:
            file_0.write('\n')
            file_0.write('\n')
            file_0.write('# noinspection PyPep8Naming\n')
            file_0.write('class cached_property:')
            file_0.write('    """A property decorator that is only computed once per instance and then  replaces itself with an ordinary attribute.\n')
            file_

# Generated at 2022-06-25 17:10:45.407300
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True

# Generated at 2022-06-25 17:10:52.704942
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)
    # Ensure the assertion below isn't triggered by a refactoring change
    assert 'cached_property' in str(cached_property_0)


# Generated at 2022-06-25 17:10:55.150696
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:11:02.322416
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)


# Generated at 2022-06-25 17:11:12.080350
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        cached_property_0 = cached_property(0)
        cached_property_0.__get__(0, 0)
        # Exception from Cache_Property.__get__
    except AttributeError:
        pass
    except Exception:
        raise AssertionError()

    # Exception from Cache_Property.__get__
    try:
        cached_property_0 = cached_property(0)
        cached_property_0.__get__('', 0)
        raise AssertionError('exception was not raised')
    except AttributeError:
        pass
    except Exception:
        raise AssertionError()

    # Exception from Cache_Property.__get__

# Generated at 2022-06-25 17:11:16.891041
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-25 17:11:24.073371
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyClassHasNoInit
    class TestClass:
        # noinspection PyUnusedLocal
        @cached_property
        def my_property(self):
            return "I'm a cached_property!"

    test_obj = TestClass()
    result = test_obj.my_property
    assert result == "I'm a cached_property!"



# Generated at 2022-06-25 17:11:29.030760
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # import builtins
    cached_property_0 = cached_property(1)
    # assert isinstance(cached_property_0.__get__(None, builtins.str), property)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:11:34.447929
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """test_cached_property___get__"""

    # Set up test data

    # Execute the test
    test_case_0()


# Generated at 2022-06-25 17:11:36.756584
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:11:43.309728
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x17\xb5\xcd\x04\xd1\x9f\xdc\x03\xb4\x1d\x1ex\xbe\xc4\xb8'
    cached_property_0 = cached_property(bytes_0)
    int_0 = cached_property_0.__get__(None, int)
    pass


# Generated at 2022-06-25 17:11:44.479123
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert False


# Generated at 2022-06-25 17:11:51.048524
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_cached_property___get__.stypy_localization = localization
    test_cached_property___get__.stypy_type_of_self = None
    test_cached_property___get__.stypy_type_store = module_type_store
    test_cached_property___get__.stypy_function_name = 'test_cached_property___get__'
    test_cached_property___get__.stypy_param_names_list = []
    test_cached_property___get__.stypy_varargs_param_name = None
    test_cached_property___get__.stypy_kwargs_param_name = None
    test_cached_property___get__.stypy_call_defaults = defaults
    test_cached_property

# Generated at 2022-06-25 17:12:04.024878
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'mV\xe9\x13\x1c\xf1\x15\x17\xac \xe6G\x15\xceb\xe9\xc9\x1e\x1f\xd3\xac\x8b\xfe\x08\xde\x03\x16\xd4\xed\xc4\x04\x0c\xf1\x01\x1f\x13\xb8'
    cached_property_0 = cached_property(bytes_0)

    # @cached_property
    # def y(self):
    #     return self.x + 1

    # class MyClass:
    #     def __init__(self):
    #         self.x = 5

    # obj = MyClass()
    # obj.y
    #

# Generated at 2022-06-25 17:12:16.652212
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x0f\x88\xa8\xb4\x1e\xca\xb8h'
    cached_property_0 = cached_property(bytes_0)

    # Test __get__ method

# Generated at 2022-06-25 17:12:22.679717
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)

if __name__ == "__main__":
    test_case_0()
    test_cached_property___get__()
    print('haha')

# Generated at 2022-06-25 17:12:27.078379
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x88\xfe\x80\xc5\xb2\x84\x95k\x98\x9e\xfb\xd6\xac\xad\x97\r\xc4'
    cached_property_0 = cached_property(bytes_0)


# Generated at 2022-06-25 17:12:34.437575
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a')
    bytes_0 = cached_property_0.__get__(None, bytes_0)


# Generated at 2022-06-25 17:12:44.778328
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for cached_property.__get__"""
    cached_property_0 = cached_property(b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a')
    obj_0 = (b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a',)
    cls_0 = (b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a',)
    cached_property_0.__get__

# Generated at 2022-06-25 17:12:51.634754
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property()
    io_0 = io()
    io_1 = io()
    io_2 = io()
    io_3 = io()
    io_4 = io()
    io_5 = io()
    io_6 = io()
    io_7 = io()
    io_8 = io()
    io_9 = io()
    io_10 = io()
    io_11 = io()
    io_12 = io()
    io_13 = io()
    io_14 = io()
    io_15 = io()
    io_16 = io()
    io_17 = io()
    io_18 = io()
    io_19 = io()
    io_20 = io()
    io_21 = io()
    io_22 = io()
    io_

# Generated at 2022-06-25 17:12:54.430163
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property()
    # print(obj_0.__get__(obj_0, obj_0))
    # print(obj_0.__get__(None, obj_0))


# Generated at 2022-06-25 17:13:02.809647
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)
    with pytest.raises(NameError):
        cached_property_0.__get__(None, None)


# Generated at 2022-06-25 17:13:09.933397
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)
    obj_0 = cached_property_0
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(obj_0, bytes_0)
    return True


# Generated at 2022-06-25 17:13:13.266439
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = True
    assert bool_0


# Generated at 2022-06-25 17:13:27.787576
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x96\x1c\xed\x86\xf3\x9b\x9d\xaa\xfdK@\x1f\x19\x07\xe0Y?\xfdk\x9c\x8d\x16\x92\xc2'
    cached_property_0 = cached_property(bytes_0)
    obj_0 = ""

# Generated at 2022-06-25 17:13:35.122279
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)
    bytes_1 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    type_0 = type(bytes_1)
    cached_property_0.__get__(bytes_0, type_0)


# Generated at 2022-06-25 17:13:42.452872
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property()
    cls = cached_property()
    cached_property.__get__(obj, cls)
    error_msg = '''No exception raised.'''
    assert False, error_msg
    obj = cached_property()
    cls = cached_property()
    cached_property.__get__(obj, cls)
    error_msg = '''No exception raised.'''
    assert False, error_msg


# Generated at 2022-06-25 17:13:46.192548
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x8d\xcb\x01\xbe\xcf\xec\xfe\xef\xb9\xba\x0cT\xda\xcf\x1f'
    cached_property_0 = cached_property(bytes_0)


# Generated at 2022-06-25 17:14:06.857163
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)
    bytes_1 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    actual = cached_property_0.__get__(bytes_1)

if __name__ == "__main__":
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:14:16.220334
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from flutils.decorators import cached_property
    from typing import Any
    bytes_0 = b'\xfe\xad\xdf\xfe\x84\xf0X\xcb\xae\x14P\xed\x96\x1a\x1e\x857'
    cached_property_0 = cached_property(bytes_0)
    class Class_0:
        def __init__(self):
            self.var = 0
        @cached_property
        def cached(self):
            return self.var + 1
    class_0 = Class_0()
    class_1 = Class_0()
    class_2 = Class_0()
    class_3 = Class_0()
    class_4 = Class_0()
    class_5 = Class_0

# Generated at 2022-06-25 17:14:23.643019
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    __tracebackhide__ = True

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

    obj2 = MyClass()
    assert obj2.y == 6

    assert obj.y == 6



# Generated at 2022-06-25 17:14:26.941752
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x7f\x18\xba_\xc5\x05\xa1\x06\x00\x02'
    cached_property_0 = cached_property(bytes_0)



# Generated at 2022-06-25 17:14:40.046163
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property___get__0 = cached_property
    str_0 = '@\x8d\x1a\xcf^\x87I\xc8\x1d\xee\xd6\xab\x08\x0b\x99\x9b\x92\x8b\x13\xe8\xfa\x0f\x9c\xef,\x9a\x11\x1a\x12'
    cached_property___get__0 = cached_property

# Generated at 2022-06-25 17:14:42.693452
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass  # Tested in TestFlutils


# Generated at 2022-06-25 17:14:51.081045
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xa6\xb0\xf9\x81\xcf\xa9\xf4\xfd\xec\x1b\x84\x0c\x1f\xb8'
    cached_property_0 = cached_property(bytes_0)
    def func_0():
        return '\x95\x06\x14\x15\x18\x1f\x1e\x1d\x10\x0e\x03\x02\x01'
    list_0 = [1, 18, 9, 5, 19, 10, 9, 5, 3, 16, 10, 17, 10, 6, 8]
    list_0.append(16)
    list_0.append(1)
    str_0 = func_0()

# Generated at 2022-06-25 17:15:01.097698
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)

    # Unit test for method __get__ of class cached_property
    def test_cached_property___get__():
        bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
        cached_property_0 = cached_property(bytes_0)

        # Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:15:10.544164
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)
    assert type(cached_property_0) is cached_property
    assert type(cached_property_0.__get__) is MethodType
    cached_property_0.__get__(cached_property_0, cached_property)
    assert cached_property_0.__doc__ is not None
    assert cached_property_0.func == bytes_0
    cached_property_0.__get__(None, cached_property)

# Generated at 2022-06-25 17:15:22.775152
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'E\x05\x87q\xf9\x9f\x1f.\xa2\x020\xbe\x15\x12\x01\xf8\x9d]\x9f\xb7'
    cached_property_0 = cached_property(bytes_0)
    bytes_1 = b'\xb9\x18V^\xf2\x03\x1c\x0f\xa8\xee\x9c\x9b\xed;\x98\xfb\x96'

# Generated at 2022-06-25 17:15:52.192174
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:16:02.136834
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)
    class_creator_0 = type(bytes_0)
    class_creator_0.__dict__['module'] = cached_property_0
    class_creator_0.__dict__['module'].__module__ = class_creator_0.__name__
    int_0 = (1 // cached_property_0) ** -512
    class_creator_1 = type(bytes_0)
    class_creator_1.__dict__['module'] = int_0
    class_creator_1.__dict__['module'].__module

# Generated at 2022-06-25 17:16:15.333984
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(bytes)
    dict_0 = dict()
    bytes_0 = b'{\x8e\xbd\x9a\x9d\x83\xed~\x84\xd4_\xdb\x19\x0f\x91\x1e\x8f\xa6'
    dict_0[1] = bytes_0
    dict_0[2] = bytes_0
    dict_0[3] = bytes_0
    dict_0[4] = bytes_0
    dict_0[5] = bytes_0
    dict_0[6] = bytes_0
    dict_0[7] = bytes_0
    dict_0[8] = bytes_0
    dict_0[9] = bytes_0
    dict_0[10]

# Generated at 2022-06-25 17:16:18.322402
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xb92\xe6\x0f\x9f\x9a\xdd\xed\x0e\x98\xbeI\xee\x87\xba\xd9d\xc0\x1c'
    cached_property_0 = cached_property(bytes_0)
    test_case_0()

# Generated at 2022-06-25 17:16:21.632752
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property()
    cached_property_0.__get__()



# Generated at 2022-06-25 17:16:25.109562
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

if __name__ == '__main__':
    test_cached_property___get__()
    import sys; sys.exit()

# EOF

# Generated at 2022-06-25 17:16:38.135248
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x9a\xc6\xfcW\xbd\xde\xdb\xbb\x89\xb1\x9f\xbf\xd5\xda\xaf\xdblN\xe3\x1f\x92\r\x9b\x0c\x8aB'
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(None, None)

if (__name__ == '__main__'):
    import sys
    import os
    import stat
    import atexit
    import tempfile
    import subprocess
    import string
    import random
    import pdb
    # exec(open('/Users/twalker/flutils/flutils/decorators.py').read(), globals(), locals

# Generated at 2022-06-25 17:16:42.880674
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass_0:
        @cached_property_0
        def method_0(self):
            return 'foo'
    TestClass_0_0 = TestClass_0()
    test_cached_property___get__()


# Generated at 2022-06-25 17:16:47.056397
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)
    obj_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
    cls_0 = type(obj_0)
    assert bool(cached_property_0.__get__(obj_0, cls_0))


# Generated at 2022-06-25 17:16:57.256540
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(66.0)
    assert cached_property_0.__get__((71, ), None) == 66.0
    assert cached_property_0.__get__(None, None) == 66.0
    cached_property_1 = cached_property(cached_property_0)
    assert cached_property_1.__get__(None, 42) == 66.0
    cached_property_2 = cached_property(cached_property_1)
    assert cached_property_1.__get__(None, tuple()) == 66.0
    assert cached_property_1.__get__((35, ), None) == 66.0
    assert cached_property_1.__get__(None, None) == 66.0
    assert cached_property_2.__get__((), None) == 66

# Generated at 2022-06-25 17:18:03.296057
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Checks if cached_property.__get__ was called when we access an attribute from cache_property class.
    It accesses the cached_property___get__, which is a method of cached_property
    """
    test_string = "This is a test string"
    test_case_0.bytes_0


if __name__ == "__main__":
    # @cached_property
    # def b(self):
    #     return self.a + 1
    #
    #
    # obj = MyClass()
    # obj.y
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:18:04.783578
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(__randint__)
    cached_property_0.__get__(cached_property_0, cached_property_0)


# Generated at 2022-06-25 17:18:06.501885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xe3\x0bVR\xed\x8b\xaa@\x1f\x19\x07\xe0\x17#\xfc4n,\x8a'
    cached_property_0 = cached_property(bytes_0)
    return


# Generated at 2022-06-25 17:18:08.867333
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test if instance is of the correct type
    obj = cached_property(0)

    # Test if the returned value is correct
    assert cached_property.__get__(obj, cached_property) == 0

    # Test if the returned value is correct
    assert cached_property.__get__(obj, cached_property) == 0

# Generated at 2022-06-25 17:18:15.889155
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test the method __get__ of class cached_property

    # unit test 2
    # Test the method __get__ of class cached_property
    # without parameters
    try:
        # Test the method __get__ of class cached_property
        # without parameters
        test_case_0()
    except TypeError as e:
        print("Exception raised:", e)



# Generated at 2022-06-25 17:18:28.760084
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xfb\xff\xb0\x8b\x01\xd3\xe3\x9dG\x8d\xe3\xeb\xed\x96'
    cached_property_0 = cached_property(bytes_0)
    class_0 = re.compile('(?<!)', (re.VERBOSE | re.MULTILINE))
    int_0 = re.match('\x0c(S\x17', '\t\x1e\x0c(S\x17\x0c(S\x17\x0c(S\x17\x0c(S\x17\x0c(S\x17')
    int_1 = re.match('(?:[^\\\\)\\\\]|\\\\.)*', '')
    int_2

# Generated at 2022-06-25 17:18:39.718192
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:18:47.656817
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for cached_property.__get__

    test for method __get__ of class cached_property
    """
    cached_property_0 = cached_property(b'X\x05\xca\x8e\x1bb\x0c\x12\x7f\x91L')
    bytes_0 = b'\\\xbb\xcd\xfa\xed\x8e\xf9\x96c\x9eUv\xe3q\xa3\x88\xfd\xc2'
    description_0 = '\n    test for method __get__ of class cached_property\n'
    test_method_doc_0 = """Test for cached_property.__get__

    test for method __get__ of class cached_property
    """

# Generated at 2022-06-25 17:18:55.581526
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # @cached_property
    # def a(self):
    #     return self.x + 1
    #
    # class MyClass:
    #     __qualname__ = 'MyClass'
    #
    #     def __init__(self):
    #         self.x = 5
    #
    #     def __get__(self, obj, cls):
    #         return self
    #
    #     def __set__(self, obj, value):
    #         pass
    #
    #     def __delete__(self, obj):
    #         pass
    #
    # myclass = MyClass()

    # See the notes in the class docstring
    from functools import cached_property
    import types
    from types import MethodType

# Generated at 2022-06-25 17:18:57.867798
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
