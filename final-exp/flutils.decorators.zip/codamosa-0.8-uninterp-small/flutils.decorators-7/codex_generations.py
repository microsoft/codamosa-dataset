

# Generated at 2022-06-25 17:10:43.856503
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test with constant parameter 'obj' of type 'Any' and python built-in constant 'None'
    cached_property_0 = cached_property(test_case_0())
    cached_property_0.__get__(None)
    # Test with constant parameter 'obj' of type 'Any' and python built-in constant 'NoneType'
    cached_property_0 = cached_property(test_case_0())
    cached_property_0.__get__(NoneType)
    # Test with constant parameter 'obj' of type 'Any' and python built-in constant 'NotImplemented'
    cached_property_0 = cached_property(test_case_0())
    cached_property_0.__get__(NotImplemented)
    # Test with constant parameter 'obj' of type 'Any' and python built-in constant 'NotIm

# Generated at 2022-06-25 17:10:45.660818
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:10:47.067382
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:10:48.070394
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:10:52.906510
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    self_0_0 = cached_property(bool_0)
    self_0_0.__get__((bool_0 if bool_0 else (None if not None else object())), (type if type else object()))


# Generated at 2022-06-25 17:10:53.344555
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-25 17:10:54.030859
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True == False


# Generated at 2022-06-25 17:10:59.806851
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(3)
    try:
        cached_property_0.__get__(2, 2, 2)
    except TypeError:
        bool_0 = bool(2)


# Generated at 2022-06-25 17:11:07.659525
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_obj = MyClass()
    result_0 = my_obj.y
    expected_0 = 6
    assert result_0 == expected_0

    result_1 = my_obj.y
    expected_1 = 6
    assert result_1 == expected_1


# Generated at 2022-06-25 17:11:12.142445
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    # Test case 0
    obj = "test"
    cls = None
    val = cached_property.__get__(obj, cls)
    expected = "<bound method Test.test of <class 'flutils.decorators.test.Test'>>"
    assert str(val) == expected


# Generated at 2022-06-25 17:11:21.354693
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)

    # Coroutine: noinspection PyUnboundLocalVariable
    def test_coroutine():
        await asyncio.sleep(0.01)

    test_coroutine = asyncio.coroutine(test_coroutine)

    bool_1 = bool_0 is not None
    if bool_1:

        # Statement: noinspection PyUnboundLocalVariable
        test_coroutine()

    else:
        pass


test_case_0()
test_cached_property___get__()

# Generated at 2022-06-25 17:11:27.429653
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass_0:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj_0 = MyClass_0()
    cached_property_1 = obj_0.y
    # AssertionError: 6 != 7
    assert cached_property_1 == 8

# Generated at 2022-06-25 17:11:29.501574
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

test_cached_property___get__()

# Generated at 2022-06-25 17:11:34.483969
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Get attribute value
    cached_property_0 = cached_property(int)
    attribute_value_cached_property_0 = cached_property_0.__get__(int)


# Generated at 2022-06-25 17:11:43.565623
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    # __get__(...)
    # Return self.__dict__[self.name] if the attribute exists, otherwise
    # call the __getter__ function and set the attribute
    # __get__(self, obj, type=None)

    # Assert the method exists
    assert hasattr(cached_property_0, '__get__')
    assert callable(getattr(cached_property_0, "__get__"))



# Generated at 2022-06-25 17:11:53.077441
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    __get__ = cached_property_0.__get__
    int_0 = __get__(int(), int)
    assert int_0 is None
    object_0 = object()
    object_1 = object()
    object_2 = object_1.__get__(object_0, object_0)
    assert object_2 is object_1



# Generated at 2022-06-25 17:12:05.283295
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from copy import copy
    from random import randint

    from pytest import raises

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = randint(1, 5)

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == obj.x + 1
    assert obj.y == obj.x + 1
    assert obj.y == obj.x + 1
    assert obj.y == obj.x + 1

    obj_2 = copy(obj)
    assert obj_2.x == obj.x
    assert obj_2.y == obj.y

    obj_2.x = randint(6, 10)
    assert obj_2.x != obj.x


# Generated at 2022-06-25 17:12:12.262884
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class AClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    instance = AClass()

    assert instance.y == 6
    assert instance.__dict__ == {'x': 5, 'y': 6}

# Generated at 2022-06-25 17:12:21.749848
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _0 = None  # line: 2
    if type(_0) == cached_property:
        def func_0(cached_property_0):  # line: 4
            try:
                pass
            finally:
                pass
    else:
        def func_0(cached_property_0):  # line: 6
            try:
                pass
            finally:
                pass
    # ENDIF
    # ENDIF
    pass


# Generated at 2022-06-25 17:12:22.915916
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = True
    assert True


# Generated at 2022-06-25 17:12:27.931599
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:12:28.917950
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test case
    test_case_0()

# Generated at 2022-06-25 17:12:33.586778
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property()
    cls = cached_property_0.__get__(None, None)
    assert cls is cached_property_0


# Generated at 2022-06-25 17:12:38.245509
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass(object):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-25 17:12:41.766175
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


async def test_case_1():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    await cached_property_0.__get__(0)


# Generated at 2022-06-25 17:12:46.493986
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_obj = cached_property(None)
    assert test_obj.__get__(None, None) is None



# Generated at 2022-06-25 17:12:48.000858
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True


# Generated at 2022-06-25 17:12:49.186957
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert test_case_0() == None


# EOF

# Generated at 2022-06-25 17:12:59.595467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    n = 0
    cached_property_0 = cached_property(n)
    n = 3
    float_0 = float(n)
    bool_0 = bool(float_0)
    bool_1 = bool(bool_0)
    bool_0 = bool(bool_1)
    bool_0 = bool(bool_0)
    bool_1 = bool(bool_0)
    bool_2 = bool(bool_1)
    bool_0 = bool(float_0)
    bool_3 = bool(bool_0)
    bool_4 = bool(bool_3)
    bool_0 = bool(bool_4)
    bool_5 = bool(bool_0)
    bool_0 = bool(bool_5)
    bool_3 = bool(bool_0)

# Generated at 2022-06-25 17:13:00.879799
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property
    pass


# Generated at 2022-06-25 17:13:19.371306
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass_1:
        x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class MyClass_2:

        @cached_property
        def y(self):
            return self.x + 1

        x = 5

    obj_1 = MyClass_1()
    obj_2 = MyClass_2()

    obj_1.y = 6
    obj_1.y = 7

    obj_2.y = 6
    obj_2.y = 7

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:13:29.362979
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class test_cached_property___get___test0:
        def __init__(self):
            self.test_var_0 = False

        def __getattribute__(self, test_attr_name):
            if test_attr_name == "test_attr_0":
                return self.test_var_0

    class test_cached_property___get___test1(test_cached_property___get___test0):
        def __init__(self):
            super(test_cached_property___get___test1, self).__init__()
            self.test_0 = False

        @cached_property
        def test_attr_0(self):
            return self.test_0

    test_cached_property___get___test1_obj_0 = test_cached_property___

# Generated at 2022-06-25 17:13:35.867951
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    obj, cls = 0, 4
    cached_property_0.__get__(obj, cls)
    assert cls == 4
    assert obj == 0



# Generated at 2022-06-25 17:13:41.031793
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(None)
    cached_property_0.__get__(None, None)
    cached_property_0.__get__(None, None)


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:13:42.031459
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:13:56.039802
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    int_0 = 0
    int_1 = 1
    int_2 = 2
    cached_property_0 = cached_property(bool_0)
    try:
        cached_property_0.__get__(int_0, int_0)
    except TypeError as e:
        bool_0 = True
    assert bool_0
    try:
        cached_property_0.__get__(int_0, int_1)
    except TypeError as e:
        bool_0 = False
    assert bool_0
    try:
        cached_property_0.__get__(int_1, int_0)
    except TypeError as e:
        bool_0 = True
    assert bool_0

# Generated at 2022-06-25 17:14:04.000195
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    flag_0 = True
    if flag_0:
        class Class_0:
            def __init__(self, param_0: Any) -> None:
                variable_0 = cached_property(self.method_0)
        variable_1 = Class_0
        variable_1 = Class_0(Class_0.method_0)
        assert (variable_1 is not None)


# Generated at 2022-06-25 17:14:06.171121
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('in method test_cached_property___get__ of module test_decorators')
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 17:14:09.713579
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class ClassA:

        def __init__(self, x):
            self.x = x

        @cached_property
        def y(self):
            return self.x + 1

    obj_a = ClassA(5)
    assert obj_a.y == 6



# Generated at 2022-06-25 17:14:13.847477
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(bool)

    obj_0.__get__(cached_property(bool_0), cached_property(bool))


# Generated at 2022-06-25 17:14:32.914828
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        # Test Function Here
        test_case_0()
    except Exception:
        raise AssertionError()

# Generated at 2022-06-25 17:14:39.554634
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    bool_0 = True
    cached_property_0 = cached_property(bool_0)
    my_class_0 = MyClass()
    # Testing if the return value of cached_property.__get__(my_class_0, MyClass) equals 6
    assert cached_property_0.__get__(my_class_0, MyClass) == 6


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 17:14:44.066306
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    cached_property_0.__get__(bool_0, bool_0)


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-25 17:14:49.572088
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = True
    cached_property_0 = cached_property(bool_0)
    cached_property_0.set_func(bool_0)
    cached_property_0.__get__(cached_property_0, bool_0)


if __name__ == '__main__':
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:14:59.164095
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(None)
    cached_property_1 = cached_property_0.__get__(None, None)
    assert cached_property_1

    cached_property_0 = cached_property(None)
    cached_property_1 = cached_property_0.__get__(None, None)
    assert cached_property_1 is cached_property_0

    cached_property_0 = cached_property(None)
    cached_property_1 = cached_property_0.__get__(None, None)
    assert cached_property_1 is cached_property_0

    cached_property_0 = cached_property(None)
    cached_property_1 = cached_property_0.__get__(None, None)
    assert cached_property_1 is cached_property_0

    cached_property_

# Generated at 2022-06-25 17:15:01.733113
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:15:09.573215
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import asyncio
    from async_generator import async_generator, yield_

    @async_generator
    @asyncio.coroutine
    def coro():
        yield

    class MyClass(object):

        def __init__(self):
            pass

        @cached_property
        def y(self):
            return coro()

    async def main():
        obj = MyClass()
        obj.y
        obj.y
        obj.y
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())



# Generated at 2022-06-25 17:15:12.129516
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    str_0 = '_'
    cached_property_0 = cached_property(str_0)



# Generated at 2022-06-25 17:15:12.656751
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:15:18.176361
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)


if __name__ == '__main__':
    test_case_0()

    test_case_1()
    test_case_2()
    test_cached_property___get__()
    test_case_3()
    test_case_4()
    test_cached_property___get__()
    test_case_5()
    test_case_6()
    test_cached_property___get__()
    test_case_7()

# Generated at 2022-06-25 17:16:02.440758
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Case: 0
    test_case_0()
    pass


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:16:08.506272
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    obj_0 = None
    cached_property_0.__get__(obj_0, None)


# Generated at 2022-06-25 17:16:18.229716
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    int_0 = 100
    lst_0 = [int_0]
    lst_0.append(cached_property_0)
    lst_0[0] = 100
    try:
        str_0 = ''
        str_0 = ' ' * 0x00000100
        str_0 = str_0.strip()
    except Exception:
        cached_property_0 = cached_property(bool_0)
        lst_0.append(cached_property_0)
    else:
        lst_0[0] = lst_0[1]


# Generated at 2022-06-25 17:16:21.633230
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        test_case_0()
    except TypeError:
        pass  # Expected to throw type error

# Generated at 2022-06-25 17:16:26.714573
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test for method __get__ of class cached_property
    class A:
        def __init__(self, x):
            self.x = x

        @cached_property
        def foo(self):
            return self.x

    a = A(1)
    assert a.foo == 1
    a.x = 2
    assert a.foo == 1
    del a.foo
    assert a.foo == 2


# Generated at 2022-06-25 17:16:38.260475
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create an instance of class cached_property
    # with argument type int
    cached_property_0 = cached_property(5)

    # Create an instance of class cached_property
    # with argument type int
    cached_property_1 = cached_property(5)
    # Create an instance of class cached_property
    # with argument type int
    cached_property_2 = cached_property(5)

    # Create an instance of class cached_property
    # with argument type int
    cached_property_3 = cached_property(5)

    # Create an instance of class cached_property
    # with argument type int
    cached_property_4 = cached_property(5)
    # Create an instance of class cached_property
    # with argument type int
    cached_property_5 = cached_property(5)

    # Create an instance of class

# Generated at 2022-06-25 17:16:41.238226
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:16:42.925719
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    a = 1
    try:
        cached_property___get__(a)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 17:16:45.449464
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Define variable
    cached_property___get__0 = None
    with pytest.raises(Exception) as excinfo:
        # Execute function
        cached_property___get__0 = cached_property.__get__(None)
    # Assert expected state


# Generated at 2022-06-25 17:16:50.558540
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass_0:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj_0 = MyClass_0()
    test_case_0 = obj_0.y
    assert test_case_0 == 6


# Generated at 2022-06-25 17:18:56.194864
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    bool_1 = True
    assert bool_0 == bool_1


# Generated at 2022-06-25 17:19:06.529456
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_case_0():
        bool_0 = True
        assert (bool_0 == bool_0)
    def test_case_1():
        bool_0 = True
        assert (bool_0 == bool_0)
    def test_case_2():
        bool_0 = True
        assert (not bool_0 != bool_0)
    def test_case_3():
        bool_0 = True
        assert (not bool_0 != bool_0)
    def test_case_4():
        bool_0 = True
        assert (bool_0 == bool_0)
    def test_case_5():
        bool_0 = True
        assert (bool_0 == bool_0)
    def test_case_6():
        bool_0 = True
        assert (not bool_0 != bool_0)


# Generated at 2022-06-25 17:19:10.962554
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Python3.6: TypeError: descriptor '__get__' requires a 'bool' object but
    #  received a 'cached_property'
    obj = cached_property(True)
    cls = cached_property(True)
    _ = obj.__get__(cls)


# Generated at 2022-06-25 17:19:13.276022
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    obj_1 = None
    cached_property_0.__get__(obj_1, None)


# Generated at 2022-06-25 17:19:15.579166
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test signature and return type for method __get__ of class cached_property
    assert True



# Generated at 2022-06-25 17:19:23.738771
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for cached_property.__get__"""
    # Invoke method __get__ of class cached_property with argument None
    # Test raises no Exception
    test_case_0()



# Generated at 2022-06-25 17:19:26.212232
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        if not isinstance(cached_property_0, cached_property):
            raise TypeError
    except TypeError:
        pass

# Generated at 2022-06-25 17:19:28.271396
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True



# Generated at 2022-06-25 17:19:31.364322
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bool_0 = False
    cached_property_0 = cached_property(bool_0)
    cached_property_0.__get__(None, None)


# Generated at 2022-06-25 17:19:35.394575
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = test_case_0()
    class_0 = MyClass()
    retval = cached_property_0.__get__(class_0)
    assert retval == 6