

# Generated at 2022-06-25 17:10:38.898876
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Example:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Note: This test will ONLY pass in Python 3.8+
    from functools import cached_property

    class Example:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1



# Generated at 2022-06-25 17:10:45.990662
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from random import random
    from collections import namedtuple
    from random import random
    from random import random
    from random import random
    from collections import namedtuple
    from random import random
    from random import random
    from random import random
    from random import random
    from collections import namedtuple
    from random import random
    from random import random
    from random import random
    from random import random
    from random import random
    from random import random
    from random import random
    from collections import namedtuple
    from random import random
    from random import random
    from random import random
    from random import random
    from collections import namedtuple
    from random import random
    from random import random
    from random import random
    from random import random
    from collections import namedtuple
    from random import random
    from random import random
   

# Generated at 2022-06-25 17:10:52.086477
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    x = 5
    d = {"x": x, "y": cached_property_0}
    e = {"x": x, "y": cached_property_0}
    f = d["y"]
    g = e["y"]



# Generated at 2022-06-25 17:11:02.878603
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    # Test normal case:
    class class_0:
        def func_0(self):
            pass

        @cached_property
        def func_1(self):
            pass

    class_0_instance_0 = class_0()

    # Test normal case:
    result = cached_property.__get__(class_0.func_1, class_0_instance_0)

    assert result is not None

    # Test with TypeError:
    class class_1:
        def func_0(self):
            pass

        def func_1(self):
            pass

    class_1_instance_0 = class_1()


# Generated at 2022-06-25 17:11:07.716998
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)

    obj = MyClass()
    cached_property_0.__get__(obj)


# Generated at 2022-06-25 17:11:08.757999
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert False, "Test not implemented"


# Generated at 2022-06-25 17:11:12.314734
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)

    # Verify method __get__ is equal to expected value
    expected = None
    value = cached_property_0.__get__
    assert value == expected


# Generated at 2022-06-25 17:11:20.892782
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    val_0 = bool()
    # Deliberate assignment of a non-coroutine function
    # to a coroutine function attribute
    val_1 = bool()
    val_2 = bool()
    val_3 = bool()
    val_4 = bool()
    val_5 = bool()
    val_6 = bool()
    val_7 = bool()
    val_8 = bool()
    val_9 = bool()
    val_10 = bool()
    val_11 = bool()
    val_12 = bool()
    val_13 = bool()
    val_14 = bool()
    val_15 = bool()
    val_16 = bool()
    val_17 = bool()
    val_18 = bool()
    val_19 = bool()
    val_20 = bool()
    val_21 = bool()


# Generated at 2022-06-25 17:11:29.785288
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from os.path import join
    from os.path import sep
    from types import ModuleType
    from typing import Dict
    from types import FunctionType
    from typing import List
    from types import MethodType
    from typing import Optional
    from types import SimpleNamespace
    from typing import Union

    from flutils.decorators import cached_property
    from flutils.pathutils import fix_path
    from flutils.pathutils import full_split
    from flutils.pathutils import is_eager
    from flutils.pathutils import is_lazy
    from flutils.pathutils import lazy_path
    from flutils.pathutils import split_path
    from flutils.pathutils import strip_path
    from flutils.pathutils import strip_path_ext
    from flutils.pathutils import strip_path_name

# Generated at 2022-06-25 17:11:40.844808
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from builtins import str  # @UnusedImport

    # Must be run in test_cached_property to pass
    # @cached_property
    # def foo(self):
    #     return "bar"
    #
    # assert test_cached_property.foo.__doc__ == "bar"
    # doc_1_1 = test_cached_property.foo.__doc__
    # doc_1_2 = None
    # assert doc_1_1 == doc_1_2
    # doc_2_1 = test_cached_property.foo.__doc__
    # doc_2_2 = None
    # assert doc_2_1 != doc_2_2

    class Bar(object):
        @cached_property
        def foo(self):
            return "bar"
    #
    #

# Generated at 2022-06-25 17:11:45.379380
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    instance = cached_property()
    object_0 = object()
    object_1 = object()
    object_1 = instance.__get__(object_0, object_1)


# Generated at 2022-06-25 17:11:47.886380
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    any_0 = None
    cached_property___get___0 = cached_property_0.__get__(any_0, cached_property_0)


# Generated at 2022-06-25 17:11:54.178237
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


if __name__ == '__main__':
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:11:57.534347
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(cached_property_0, cached_property_0)


# Generated at 2022-06-25 17:12:01.208462
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(None, None)
    cached_property_0.__get__(None, None)

test_case_0()
test_cached_property___get__()

# Generated at 2022-06-25 17:12:15.977123
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import unittest
    import pathlib
    import tempfile
    import shutil

    # noinspection PyUnresolvedReferences
    from flutils.decorators import cached_property

    class A:

        def __init__(self):
            self.count = 0

        # noinspection PyMethodMayBeStatic
        @cached_property
        def x(self):
            self.count += 1
            return self.count

    def test_is_instance():
        test_obj = A()
        x_value = test_obj.x
        assert  isinstance(test_obj.x, int)

    def test_value_is_cached():
        test_obj = A()
        x_value = test_obj.x
        assert test_obj.x == 1


# Generated at 2022-06-25 17:12:21.572514
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    class_0 = None
    assert cached_property_0.__get__(class_0) is cached_property_0
    obj_0 = object()
    assert cached_property_0.__get__(obj_0, class_0)


# Generated at 2022-06-25 17:12:29.080479
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)

    class MyClass_0:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass_0()
    assert obj.y == 6

    # Test if attribute is cached
    obj.x = 6
    assert obj.y == 6
    # Test if attribute is cached
    assert obj.y == 6

    del obj.y
    assert 'y' not in obj.__dict__

    # Test if attribute is recomputed
    assert obj.y == 7

    del obj.y
    assert 'y' not in obj.__dict__

    # Test if attribute is recomputed
    assert obj.y == 7



# Generated at 2022-06-25 17:12:32.203516
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-25 17:12:33.232456
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:12:43.902221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('\n--- test_cached_property___get__ ---')
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    MyClass_0 = None
    list_0 = cached_property_0.__get__(MyClass_0)
    print(list_0)


# Generated at 2022-06-25 17:12:45.192298
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:12:51.230682
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__([], int)
    cached_property_0.__get__(int, int)
    cached_property_0.__get__(float(), dict)



# Generated at 2022-06-25 17:13:00.027410
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    str_0 = None
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
    object_15 = object()
    object_16 = object()
    object_17 = object()
    object_18 = object()
    object_19 = object()
    object_20 = object()
   

# Generated at 2022-06-25 17:13:02.521947
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(bytes)
    test_cached_property___get__._result = cached_property_0.__get__(bytes)


# Generated at 2022-06-25 17:13:05.828270
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(bytes_0, bytes_0)

# Generated at 2022-06-25 17:13:10.910443
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    method_0 = cached_property.__get__
    bytes_0 = None

    cached_property_0 = cached_property(bytes_0)
    cached_property_1 = _reconstruct_global_cached_property()

    # Test __get__ of cached_property
    cached_property_1.__get__(cached_property_0, cached_property_1)


# Generated at 2022-06-25 17:13:15.474133
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    obj = None
    assert cached_property_0.__get__(obj) == cached_property_0

# Generated at 2022-06-25 17:13:19.210936
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    return cached_property_0.__get__()



# Generated at 2022-06-25 17:13:20.254790
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True



# Generated at 2022-06-25 17:13:29.579418
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test: Method: __get__
    Expected Output:
    """
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)

# Generated at 2022-06-25 17:13:30.283034
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:13:36.338891
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    obj_0 = object()
    cls_0 = type()
    assert cached_property_0.__get__(obj_0, cls_0)


# Generated at 2022-06-25 17:13:41.078894
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('\n*** test_cached_property___get__')
    def bytes_0(self: Any):
        return self

    cached_property_0 = cached_property(bytes_0)
    test_case_0()


# Generated at 2022-06-25 17:13:44.125463
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from flutils.decorators import cached_property
    from .test_cached_property_0 import test_case_0

    test_case_0()



# Generated at 2022-06-25 17:13:51.600116
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(bytes_0, type)
    with pytest.raises(Exception):
        not_callable_0 = None
        cached_property_1 = cached_property(not_callable_0)
        cached_property_1.__get__(bytes_0, type)

# Generated at 2022-06-25 17:13:53.868788
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

###############################################################################
#

# generic_functions.py

#
###############################################################################

# Generated at 2022-06-25 17:13:57.409948
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:14:06.301387
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    instance_type_0 = cached_property
    arg_type_0 = type
    instance_0 = cached_property_0
    arg_0 = None
    method_type_0 = type
    method_0 = instance_type_0.__get__
    ret_val_0 = method_0(instance_0, arg_0)
    ret_val_1 = isinstance(ret_val_0, method_type_0)
    assert ret_val_1


if __name__ == "__main__":
    test_case_0()
    print('Testing Done!')

# Generated at 2022-06-25 17:14:08.649522
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(None, bytes)


# Generated at 2022-06-25 17:14:43.641961
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # initialization
    import random
    import string
    random_string_0 = ''.join(random.choice(string.ascii_lowercase) for i in range(random.randint(1, 16)))
    random_int_0 = random.randint(1, 16)
    random_float_0 = random.randint(1, 16)
    random_char_0 = ''.join(random.choice(string.ascii_lowercase) for i in range(random.randint(1, 16)))
    # object setup
    test_object = type(random_string_0, (object,), {})()
    test_object.__init__ = lambda: None
    test_object.__init__()
    setattr(test_object, random_string_0, random_int_0)
    # test method


# Generated at 2022-06-25 17:14:47.155612
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    self = cached_property()
    obj = None
    cls = None
    assert self.__get__(obj, cls) == self



# Generated at 2022-06-25 17:14:51.665896
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    cls = None
    cached_property___get___0 = cached_property_0.__get__(None, cls)


# Generated at 2022-06-25 17:15:01.423980
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    exception_0 = Exception()
    obj_0 = exception_0
    cls_0 = None
    try:
        cached_property_0.__get__(obj_0, cls_0)
        TypeError()
    except TypeError:
        pass
    except Exception as e_0:
        AssertionError(e_0)
    else:
        TypeError()



# Generated at 2022-06-25 17:15:10.100329
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    w_0 = None
    w_1 = None
    try:
        w_2 = cached_property
        w_3 = ()
        w_4 = w_2.__get__
        w_5 = (w_4, w_2, w_0, w_1)
        w_6 = w_5[0]
        w_7 = w_5[1]
        w_8 = w_5[2]
        w_9 = w_5[3]
        w_10 = w_6(*w_5)
        w_11 = w_10
    except BaseException as exc:
        w_11 = exc
    assert isinstance(w_11, cached_property)


# Generated at 2022-06-25 17:15:16.231372
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for method cached_property.__get__
    """
    from flutils.decorators import cached_property
    @cached_property
    def some_property(self):
        return 'foo'
    cp = some_property
    assert cp.__name__ == 'some_property'

# Generated at 2022-06-25 17:15:17.194922
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:15:22.564831
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import builtins
    import sys
    import types
    import zlib
    self_0 = cached_property(bytes)
    obj_0 = builtins.object
    cls = types.BuiltinFunctionType
    r = self_0.__get__(obj_0, cls)
    assert r is not None
    assert r == bytes


# Generated at 2022-06-25 17:15:30.369276
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test case for cached_property.__get__()."""

    class Test_cached_property_0:
        """Class to test cached_property.
        """

        @cached_property
        def my_property_0(self):
            return 6

    test_0 = Test_cached_property_0()
    # Testing if an AttributeError is raised
    with pytest.raises(AttributeError):
        test_0.my_property_0.abc

    assert test_0.my_property_0.__doc__ == 'Returns: 6'
    assert test_0.my_property_0 == 6



# Generated at 2022-06-25 17:15:35.609970
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(cached_property.__get__)
    import datetime
    datetime_0 = datetime.datetime
    cached_property__get__ = cached_property.__get__(datetime_0, None)


# Generated at 2022-06-25 17:16:33.482842
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    coroutine_0 = test_cached_property___get__.cached_property_0.__get__
    cached_property_0 = cached_property(coroutine_0)


# Generated at 2022-06-25 17:16:40.574204
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = cached_property_4 = cached_property_0 = iter(bytes_0)
    class CachedProperty0:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class CachedProperty1:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class CachedProperty2:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class CachedProperty3:
        def __init__(self):
            self.x = 5


# Generated at 2022-06-25 17:16:44.217504
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    assert cached_property_0.__get__ is not None


# Generated at 2022-06-25 17:16:45.986624
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    return


# Generated at 2022-06-25 17:16:54.398253
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = 'unit_test_temp'
    int_0 = -125
    float_0 = 1.0
    f_args__0 = [bytes_0, float_0]
    f_kwargs__0 = {'f_kwarg_0': float_0, 'f_kwarg_1': float_0, 'f_kwarg_2': float_0}

    def function_0(*args, **kwargs):
        self = args[0]
        if f_args__0 == args and f_kwargs__0 == kwargs:
            return int_0
        else:
            raise Exception('function_0: Failed unit test!')

    cached_property_0 = cached_property(function_0)
    class_0 = type('', (), {'function_0': cached_property_0})
   

# Generated at 2022-06-25 17:16:56.238553
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property()
    cls = ''
    assert isinstance(obj.__get__(cls), cached_property)


# Generated at 2022-06-25 17:16:57.325075
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:17:02.074415
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class ClassCase0:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Case 0
    obj_0 = ClassCase0()
    assert obj_0.y == 6



# Generated at 2022-06-25 17:17:11.589713
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    BytesIO_0 = None
    cached_property_0.asyncio.iscoroutinefunction(BytesIO_0)
    long_0 = long()
    long_1 = long()
    long_0.__pow__(long_1)
    with open('testfile_0', 'w') as file_0:
        file_0.write(cached_property_0.asyncio.iscoroutinefunction.__doc__)
    with open('testfile_1', 'w') as file_1:
        file_1.write(cached_property_0.asyncio.iscoroutinefunction.__doc__)
    with open('testfile_2', 'w') as file_2:
        file_2

# Generated at 2022-06-25 17:17:14.193429
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_cached_property___get__0()

# Generated at 2022-06-25 17:19:24.855262
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.decorators import test_cached_property___get__ as tested_0
    tested_0 = tested_0(cached_property.__get__)
    cached_property_0 = cached_property(tested_0)
    cached_property_0.func = tested_0


# Generated at 2022-06-25 17:19:34.047884
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    cls_0 = None

    class DummyClass:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1

    obj_0 = DummyClass()
    try:
        cached_property_0.func = cached_property_0
        print(obj_0.y)
    finally:
        pass
    print(obj_0.y)
    print(obj_0.y)

if __name__ == '__main__':
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:19:35.394337
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)

# Generated at 2022-06-25 17:19:38.855406
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        # cached_property
        r0 = cached_property(None).__get__()

        assert(r0 is None)
        print('Passed!')
    except:
        print('Failed!')


# Generated at 2022-06-25 17:19:39.680192
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:19:41.284525
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    with pytest.raises(AssertionError):
        cached_property_0 = cached_property(bytes)
        cached_property_0.__get__(None, bytes)

# Generated at 2022-06-25 17:19:53.838431
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('Unit test for method __get__ of class cached_property')

    from flutils.decorators import cached_property
    from flutils.decorators import cached_property
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    cached_property_0 = cached_property(obj)
    cached_property_0 = cached_property._wrap_in_coroutine(obj)
    cached_property_0 = cached_property.__get__(obj, MyClass)
    assert cached_property_0 == 6


if __name__ == '__main__':
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:19:59.493670
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(bytes_0, str)


# Generated at 2022-06-25 17:20:02.751356
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    bytes_0 = None
    cached_property_0 = cached_property(bytes_0)
    test_case_0()



# Generated at 2022-06-25 17:20:05.666873
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    property_None = None
    cls_None = None
    obj_None = None
    cached_property_instance_None = cached_property_None(property_None)
    cached_property_instance_None.__get__(obj_None, cls_None)
