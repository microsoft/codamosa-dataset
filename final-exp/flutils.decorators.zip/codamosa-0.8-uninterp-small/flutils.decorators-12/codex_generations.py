

# Generated at 2022-06-25 17:10:37.503763
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # test_case_0
    bytes_0 = b'\xae\xb5f9\xf6\x00\x1f\x1a\xd2'
    cached_property_0 = cached_property(bytes_0)
    # test_case_1
    int_0 = 2
    cached_property_1 = cached_property(int_0)


# Generated at 2022-06-25 17:10:42.939530
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Ensure cached_property.__get__ does not raise exception
    pass  # pass statement does nothing


# Generated at 2022-06-25 17:10:52.382975
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Create a dummy instance of class MyClass
    class MyClass:
        pass

    obj = MyClass()

    # Create a dummy class MyClass
    def func(obj_0, self_0):
        if self_0:
            raise Exception("Too many arguments")

        return self_0 + 1
    MyClass.y = cached_property(func)

    result = MyClass.y.__get__(obj)

    assert result == 2

# Generated at 2022-06-25 17:10:55.086174
# Unit test for method __get__ of class cached_property
def test_cached_property___get__(): assert False, ''


# Generated at 2022-06-25 17:10:59.146021
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:11:02.820889
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _cached_property = cached_property(test_case_0)
    expected = '.\x1e]X\x02\xd5\xf5'
    _cached_property.__get__ = expected
    assert _cached_property.__get__ == expected


# Generated at 2022-06-25 17:11:04.754841
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True


# Generated at 2022-06-25 17:11:13.533827
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class class_0:

        def __init__(self):
            self.__dict__['int_0'] = 0
            self.__dict__['int_1'] = 0

        @cached_property
        def func_0(self):
            return self.int_0 + 1

        @cached_property
        def func_1(self):
            return self.int_1 - 2

    class_0_0 = class_0()

    assert class_0_0.func_0 == 1


# Generated at 2022-06-25 17:11:21.155465
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x05\x01\x7f\x10\x00\x00\x05\x16\x00\x00\x06\x00\x00\x00\x0f\x0e\x01\x00\x0e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x1c#'
    cached_property_0 = cached_property(bytes_0)
    int_0 = cached_property_0.__get__(int_0, bytes_0)


# Generated at 2022-06-25 17:11:28.573932
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test for byte objects
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)
    # Test for coroutines
    def coro_0():
        return '', (1, 2), -0.8916003991384686
    async def coro_1():
        # Test for coroutines
        val = (yield from coro_0())
        return val
    cached_property_1 = cached_property(coro_1())
    return


# Generated at 2022-06-25 17:11:33.645399
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert None is cached_property(None).__get__(None, None)


# Generated at 2022-06-25 17:11:34.521203
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # See fixture
    return True


# Generated at 2022-06-25 17:11:38.541319
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)

# Generated at 2022-06-25 17:11:42.605708
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Base case
    bytes_0 = b'J\x02\xe1\x9c\xbb\xa3'
    cached_property_0 = cached_property(bytes_0)


# Generated at 2022-06-25 17:11:43.422596
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:11:50.643635
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_1 = b'\xf9\x0f\xc6\x05\xa0\xdd\x01\xa1\x82\xed\xb9\x8c\x1d\x1f'
    int_0 = 0
    list_0 = [4, 2, 10, 7, 6, 2]
    str_0 = '\x1f\xe7\x0b\x9a\xd9\x1c\x18\xe5\x1d\x1c\x07\x98'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(tuple(list_0), list_0)
    cached_property_0.__get__(list_0, list_0)
    cached_property_0.__get

# Generated at 2022-06-25 17:12:00.608966
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(b'.\x1e]X\x02\xd5\xf5')
    cached_property_1 = cached_property(b'.\x1e]X\x02\xd5\xf5')
    cached_property_2 = cached_property(b'.\x1e]X\x02\xd5\xf5')
    cached_property_4 = cached_property(b'.\x1e]X\x02\xd5\xf5')



# Generated at 2022-06-25 17:12:06.928373
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import types

    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    cached_property_0 = cached_property(bytes_0)
    pos_Arg_0 = cached_property_0
    kwargs = {'1': float, 'cls': float}
    Generator_0 = type(cached_property_0)
    Generator_1 = type(cached_property_0)
    gen = (cached_property_0
           for cached_property_0 in Generator_0
           if (bool(cached_property_0 != Generator_1)
               and (cached_property_0 is None))
           for cached_property_0 in Generator_0)
    pos_Arg_1 = gen

# Generated at 2022-06-25 17:12:10.919196
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x15\x1e'
    bytes_1 = b'.\x1e]X\x02\xd5\xf5'
    obj_0 = MyClass
    bytes_2 = obj_0.cached_property_0 = obj_0.x = bytes_0
    cached_property_0 = bytes_2
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 17:12:12.230255
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('Method __get__ of class cached_property')



# Generated at 2022-06-25 17:12:19.289345
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)

    i = 1

# Generated at 2022-06-25 17:12:22.332170
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(bytes)
    cls_0 = cached_property(bytes)
    ret_0 = obj_0.__get__(obj_0, cls_0)


# Generated at 2022-06-25 17:12:25.285066
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:12:28.787559
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(str)
    def func():
        cached_property_0.__get__(str, str)
    func()



# Generated at 2022-06-25 17:12:41.893106
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)
    cached_property_1 = cached_property(bytes_0)
    cached_property_2 = cached_property(bytes_0)
    cached_property_1 = cached_property(bytes_0)
    cached_property_2 = cached_property(bytes_0)
    cached_property_3 = cached_property(bytes_0)
    cached_property_0 = cached_property(bytes_0)
    cached_property_0 = cached_property(bytes_0)
    cached_property_3 = cached_property(bytes_0)
    cached_property_2 = cached_property(bytes_0)
    cached_property_1 = cached_property(bytes_0)

# Generated at 2022-06-25 17:12:45.979987
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    a = cached_property(0)
    b = a.__get__(0, 0)


# This is a test of the cached_property decorator with a coroutine
async def test_case_1():
    class MyClass_0:
        @cached_property
        async def my_property(self):
            await asyncio.sleep(0.01)
            return "this is a test"

    async def async_main():

        obj = MyClass_0()
        print(await obj.my_property)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(async_main())

# Generated at 2022-06-25 17:12:50.937750
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the method __get__ of class cached_property for correct output for various inputs"""
    # This is a trivial test, because this class does not have any state
    cached_property_0 = cached_property(bytes_0)
    assert cached_proper

# Generated at 2022-06-25 17:12:59.935108
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I'
    int_0 = 3
    str_1 = 'id'
    bytes_0 = b'\x12\x05\x0f\x03\x1f\x1d\x1as\x1f\x18\x0b\x09\x08\x1a\x0f\x14\x10\x02\x1c\x1d\x00\x04\x16\x0c\x00\x0d\x1b}'
    bytes_1 = b'\x1f'
    bytes_2 = b'\x1e\x16\x14\x0e\x17'
    bytes_3 = b'\x1b'

# Generated at 2022-06-25 17:13:00.447240
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:13:10.877487
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x1d\x90\x99\x9f\x19\x8f\x16\x91\xca\x86\xc5\x1e\x1d\x9e\x8e\x12\xd2\x96\x88\xc8\x1c'
    bytes_1 = b'\x8f\x1e\x10\xd1\x8f\x92\xc6\x9e\x94\x1a\xce\x96\x12\x9a\x98\xc1\x1c\xc9\x9a\xcf\x8e\xca'

# Generated at 2022-06-25 17:13:21.881286
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from faker import Faker
    from flutils.decorators import cached_property
    import pytest
    fake = Faker()
    test_obj_ = namedtuple('test_obj_', 'test_prop')
    test_obj = test_obj_(fake.word())
    test_cached_property = cached_property(test_obj.test_prop)
    
    test_assert_mapping = {
    }
    for test_input, test_output in test_assert_mapping.items():
        with pytest.raises(test_output):
            cached_property_0___get__ = test_cached_property.__get__(test_input)


# Generated at 2022-06-25 17:13:22.985172
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(bytes)



# Generated at 2022-06-25 17:13:24.833691
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:13:26.366276
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(bytes(0))

# Generated at 2022-06-25 17:13:38.894498
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(str)
    bytes_0 = b'\x00\x01\x00\x1b\x00\x05\x02\x00\x10\x00\x06\x00\x1d\x00\x03\x02\x00\x1d\x00\x04\x02\x00\x0d\x00\x07\x00\x1e\x00\x1d\x00\x08\x02\x00\x0d\x00\t\x00\x1f\x00\x1d\x00\n\x02\x00\x0d\x00\x0b\x00 '
    instance_01 = cached_property_0.__get__(bytes_0)
    instance_

# Generated at 2022-06-25 17:13:46.034141
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property
    cls = cached_property
    try:
        ret_val = obj.__get__(obj, cls)
    except Exception:
        assert True


# Generated at 2022-06-25 17:13:53.411003
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # cdef void * _c_list_0
    _c_list_0 = None
    # cdef PyObject * _pyo_list_0
    _pyo_list_0 = None
    cached_property_0 = cached_property(_c_list_0)
    _pyo_list_0 = cached_property_0.__get__(_pyo_list_0)


# Generated at 2022-06-25 17:13:57.410334
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()



# Generated at 2022-06-25 17:14:05.354343
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    import asyncio
    def test():
        @cached_property
        def x():
            yield asyncio.sleep(1)
            return 1
        return x
    bytes_0 = b'm1\x1b\x04\xaa'
    cached_property_0 = cached_property(bytes_0)
    cached_property_0._wrap_in_coroutine(dict())


# Generated at 2022-06-25 17:14:13.955523
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test case #0
    print('cached_property.__get__() ## Test case #0')

    cached_property__get_0 = cached_property.__get__(test_case_0)

    # Test case #1
    print('cached_property.__get__() ## Test case #1')

    cached_property__get_1 = cached_property.__get__(test_case_0)

    # Test case #2
    print('cached_property.__get__() ## Test case #2')

    cached_property__get_2 = cached_property.__get__(test_case_0)

# Generated at 2022-06-25 17:14:31.416344
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)
    obj = None
    cls = None
    obj_0 = cached_property_0.__get__(obj, cls)
    if (obj_0 is not None):
        raise Exception('Failed')
    obj_0 = cached_property_0.__get__(obj, cls)
    if (obj_0 is not None):
        raise Exception('Failed')
    obj_0 = cached_property_0.__get__(obj, cls)
    if (obj_0 is not None):
        raise Exception('Failed')
    obj_0 = cached_property_0.__get__(obj, cls)

# Generated at 2022-06-25 17:14:44.067964
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)
    obj = cached_property_0
    cls = cached_property_0
    cached_property_0.__get__(obj, cls)
    cached_property_0.func = ['']
    str_0 = type_str(str)
    str_1 = type_str(str(False == False))
    obj = cache_1 = cached_property_0
    cls = cache_0 = str_1
    obj_0 = cache_2 = cached_property_0.func[0]
    obj_1 = cache_3 = str_0
    obj_2 = cache_4 = str_1
    obj_3 = cache_5 = str_

# Generated at 2022-06-25 17:14:49.775438
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.prop = True
    assert_equals(cached_property_0.__get__(bytes_0), True)
    assert_equals(bytes_0.__dict__['prop'], True)


# Generated at 2022-06-25 17:14:50.779227
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test Case: 0
    test_case_0()

# Generated at 2022-06-25 17:14:55.486221
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)
    test_case_func_0(cached_property_0)

# Generated at 2022-06-25 17:15:04.309173
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    expected_error_count = 0
    expected_error_types = []
    expected_error_count_1p = 0
    expected_error_types_1p = []
    _test_cached_property.run_test(cached_property___get__,
                                   expected_error_count,
                                   expected_error_types,
                                   expected_error_count_1p,
                                   expected_error_types_1p)


# Generated at 2022-06-25 17:15:11.413243
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x07\xdf\xee\xc3\xcc\xac\xb2\xb9\x1b\xaa\x15\x8b\x0e\x89\x1f'
    class_0 = type('', (), {})
    assert cached_property(bytes_0).__get__(class_0, cached_property(bytes_0)) == cached_property(bytes_0)


# Generated at 2022-06-25 17:15:23.232005
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method __get__ of class cached_property
    """
    # Test whether method __get__ of class cached_property raises a TypeError
    # when called without argument.
    try:
        cached_property.__get__()
    except TypeError:
        cached_property_exception_0 = True
    else:
        cached_property_exception_0 = False

    # Test whether method __get__ of class cached_property raises a TypeError
    # when called with arguments.
    try:
        cached_property.__get__(1, 2)
    except TypeError:
        cached_property_exception_1 = True
    else:
        cached_property_exception_1 = False

    assert cached_property_exception_0 is True
    assert cached_property_exception_1 is True

# Unit

# Generated at 2022-06-25 17:15:28.151451
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    bytes_0 = b'\xa1\xf9\xd6U\xc6\x83pF\x8e?\x85'
    cached_property_0 = cached_property(bytes_0)


# Generated at 2022-06-25 17:15:29.291507
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:16:09.127111
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property()
    cached_property___get__ = cached_property_0.__get__(cached_property_0, object)
    cached_property_0.__setattr__ = cached_property___get__
    cached_property_0 = cached_property()
    cached_property___get__ = cached_property_0.__get__(cached_property_0, object)
    cached_property_0.__setattr__ = cached_property___get__
    cached_property___get__()
    cached_property___get__()
    cached_property___get__(cached_property_0, cached_property_0, cached_property_0)
    cached_property___get__(cached_property_0, cached_property_0, cached_property_0)


# Generated at 2022-06-25 17:16:19.142024
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\xd5\x0e\xc7\xf5\x1a\x0eL\xaa\x9f\xa3\x12\x87\xac\xd0\x14\x1f\x1d\xd4\x88\x82\xf3\xe3\xb6'
    cached_property_0 = cached_property(bytes_0)
    # AssertionError: <coroutine object cached_property.__get__.<locals>.wrapper at 0x0000017B7E9D9AE8> <class 'coroutine'>
    assert isinstance(cached_property_0.__get__(bytes_0, str), (type(None), str, int, type(cached_property_0)))


# Generated at 2022-06-25 17:16:24.458995
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x81\x02'
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(b'\x81\x02', cached_property)


# Generated at 2022-06-25 17:16:38.136277
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test if method __get__ of class cached_property is working properly.

    The method __get__ is called when the instance attribute is accessed.
    This method returns the computed value of the property, possibly
    by looking in an instance dict.

    The instance dict is created the first time a property is accessed
    on the instance.

    """

    # Test if __get__ is working properly when the class attribute is accessed
    class MyClass_0:
        def __init__(self):
            self.x = 5

        # @cached_property
        # def y(self):
        #     return self.x + 1
        y = cached_property(lambda: self.x + 1)

    # Test if __get__ is working properly when the instance attribute is accessed

# Generated at 2022-06-25 17:16:43.615145
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:16:51.220276
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from time import time
    from time import sleep

    class A:
        @cached_property
        def time(self):
            """Example usage."""
            return time()

    a = A()

    for i in range(3):
        # Calling the method should return the same value every time
        assert a.time == a.time

        # The first time is slow...
        if i == 0:
            sleep(1)

    assert a.time != a.time  # ...but after a second, it's different

# Generated at 2022-06-25 17:16:58.097990
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class_1(object):

        def __init__(self):
            self.attribute_0 = 0

        @cached_property
        def method_0(self):
            return self.attribute_0 + 1
    instance_0 = Class_1()
    assert instance_0.method_0 == 1


# Generated at 2022-06-25 17:17:08.815584
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from pprint import pprint as pp
    import dill
    from flutils.decorators import cached_property

    pp('test_cached_property___get__')
    bytes_0 = b'\xd8\xaa\x0b\n.'
    cached_property_0 = cached_property(bytes_0)
    bytes_1 = b'\x83\x85'
    cached_property_0 = cached_property_0.__get__(bytes_1, bytes)
    dill_0 = dill.dump_session(filedir='.', filename='dill_0.txt', protocol=2)
    pp('test_cached_property___get__')


# Generated at 2022-06-25 17:17:14.733366
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.__get__(__pypy__.doctest_infrastructure.ModuleObjectForTest, int)



# Generated at 2022-06-25 17:17:21.961955
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from random import randint
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-25 17:18:39.739229
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:18:41.840349
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # __get__ with keyword arguments
    test_case_0()


# Generated at 2022-06-25 17:18:45.738530
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    bytes_0 = b'\xcd\x04\x81\xa7\x10\x1eN\x1c\xbc\xaf\xdf\x99\xcc'
    cached_property_0 = cached_property(bytes_0)


# Generated at 2022-06-25 17:18:46.142263
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:18:51.415600
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(b'\x1fX\x02\xd1\x91')
    x_0 = obj_0.__get__(b'\x0fX\x02\xd1\x91',b'\x0fX\x02\xd1\x91')


# Generated at 2022-06-25 17:18:53.397283
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)



# Generated at 2022-06-25 17:19:02.361712
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:19:04.385953
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(None)
    obj_0.__get__(None, None)


# Generated at 2022-06-25 17:19:07.670053
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'm\xd9\xa2\xfc\xb8\xe5'
    cached_property_0 = cached_property(bytes_0)
    cached_property_0.close()


# Generated at 2022-06-25 17:19:09.987311
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property()
    assert(cached_property_0.__get__() == True)


# Generated at 2022-06-25 17:20:12.864059
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'N\xec\xfd:Q\x1f\xae\xabu[o\x9e'
    cached_property_0 = cached_property(bytes_0)
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    retval_0 = cached_property_0.__get__(obj, MyClass)
    assert retval_0 == 6

# Generated at 2022-06-25 17:20:17.198333
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_cached_property_obj = cached_property()
    test_cached_property_obj2 = cached_property()
    test_cached_property_obj.test_property = 3
    test_cached_property_obj2.test_property = 4
    assert test_cached_property_obj.test_property == test_cached_property_obj2.test_property


# Generated at 2022-06-25 17:20:19.792325
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    bytes_0 = b'.\x1e]X\x02\xd5\xf5'
    cached_property_0 = cached_property(bytes_0)
    int_0 = 0
    cached_property_0.__get__(int_0)


# Generated at 2022-06-25 17:20:24.939924
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(str)
    # Verify that the following statement executes without an exception.
    cached_property_0.__get__(str, str)
    # Verify that the following statement executes without an exception.
    cached_property_0.__get__(str, str)

# Generated at 2022-06-25 17:20:28.387088
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True

