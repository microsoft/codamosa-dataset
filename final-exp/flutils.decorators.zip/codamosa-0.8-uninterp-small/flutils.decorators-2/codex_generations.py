

# Generated at 2022-06-25 17:10:44.123473
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from io import BytesIO
    from io import StringIO
    from pytest import raises
    from tempfile import NamedTemporaryFile

    with raises(TypeError):
        cached_property.__get__(None, None)

    with raises(TypeError):
        cached_property.__get__(None, None)

    if __debug__:
        # Code:
        pass

    if __debug__:
        # Code:
        pass

    if __debug__:
        # Code:
        pass

    # Code:
    assert isinstance(cached_property.__get__(None, None), cached_property)

    if __debug__:
        # Code:
        pass

    if __debug__:
        # Code:
        pass


# Generated at 2022-06-25 17:10:53.882013
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Declarations
    int_0 = None
    # Setup
    cached_property_0 = cached_property(int_0)
    cached_property_0.__doc__ = str()
    cached_property_0.func = int_0
    obj = None
    cls = None
    # Target
    # Warning: func is not set in this test
    try:
        cached_property_0.__get__(obj, cls)
    except TypeError as e:
        pass
    else:
        raise AssertionError(
            'ExpectedTypeError but got no Exception. Check your test code.')


# Generated at 2022-06-25 17:11:00.246714
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property(int_0)
    int_1 = None
    cached_property_0.__get__(int_0, int_1)

if __name__ == '__main__':
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:11:04.508647
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-25 17:11:12.571707
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class class_0(object):

        def __init__(self):
            self.attribute_0 = None

        def function_0(self):
            return self.attribute_0

    class_0_instance_0 = class_0()
    cached_property_0 = cached_property(class_0.function_0)
    cached_property_0.__get__(class_0_instance_0, class_0)

test_cached_property___get__()

# Generated at 2022-06-25 17:11:15.525399
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property()
    cls_0 = obj_0
    unknown_0 = obj_0.__get__(cls_0)


# Generated at 2022-06-25 17:11:20.222803
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-25 17:11:26.976887
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    init_0 = cached_property(None)
    obj_0 = None
    result_0 = init_0.__get__(obj_0, type)
    assert result_0 is not None, \
        "TypeError: Null object or callable object expected."
    assert result_0 is not None, \
        "cached_property.__get__: " \
        "Null object or callable object exception expected."


# Generated at 2022-06-25 17:11:33.106064
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6

# Generated at 2022-06-25 17:11:42.757123
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    int_0 = None
    cached_property_0 = cached_property(str_0)
    try:
        cached_property_0.__get__(int_0, str_0)
    except Exception as exception_0:
        assert type(exception_0) == AttributeError


# Generated at 2022-06-25 17:11:51.046834
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test case 0 for cached_property.__get__

    Test type checks

    Args:
        None

    Raises:
        None

    Returns:
        None

    """

    # From line 249 in flutils/decorators.py
    a = cached_property(int)
    assert a.__get__(None, 10) is a, "expression is false"
    # From line 250 in flutils/decorators.py
    b = a.__get__(None, 10)
    assert b is a, "expression is false"
    # From line 251 in flutils/decorators.py
    c = a.__get__(None, int)
    assert c is a, "expression is false"
    # From line 252 in flutils/decorators.py

# Generated at 2022-06-25 17:12:04.025085
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        bool_0 = None
        cached_property_0 = cached_property(bool_0)
        int_0 = None
        cached_property_1 = cached_property_0.__get__(int_0, bool_0)
    except Exception:
        cached_property_1 = None
    int_1 = None
    cached_property_2 = cached_property(int_1)
    cached_property_3 = cached_property_2.__get__(int_0, bool_0)
    int_2 = None
    cached_property_4 = cached_property(int_2)
    cached_property_5 = cached_property_4.__get__(int_0, bool_0)
    assert_equals(id(cached_property_1), id(cached_property_5))

#

# Generated at 2022-06-25 17:12:13.100693
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property()
    cls_0 = cached_property()
    func_ret_0 = obj_0.cached_property___get__(obj_0, cls_0)
    int_0 = None
    cached_property_0 = cached_property(int_0)
    obj_1 = cached_property()
    cls_1 = cached_property()
    func_ret_1 = obj_0.cached_property___get__(obj_1, cls_1)


# Generated at 2022-06-25 17:12:17.273656
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Arrange
    def int_0():
        try:
            pass
        except Exception as e:
            pass
        finally:
            pass

    cached_property_0 = cached_property(int_0)
    # Act
    result = cached_property_0.__get__(None, Any)
    # Assert
    assert result is None

test_case_0()
test_cached_property___get__()

# Generated at 2022-06-25 17:12:21.392726
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property(int_0)
    obj_0 = cached_property_0
    cached_property_1 = cached_property_0.__get__(obj_0, type(obj_0))


# Generated at 2022-06-25 17:12:30.681176
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    a = 0
    b = 0
    c = 0
    d = 0
    e = 0
    f = 0
    g = 0
    h = 0
    i = 0
    j = 0
    k = 0
    l = 0
    m = 0
    n = 0
    o = 0
    p = 0
    q = 0
    r = 0
    s = 0
    t = 0
    u = 0
    v = 0
    w = 0
    x = 0
    y = 0
    z = 0
    cached_property_0 = cached_property(id)
    cached_property_1 = cached_property(id)
    cached_property_2 = cached_property(id)
    cached_property_3 = cached_property(id)
    cached_property_4 = cached_property(id)

# Generated at 2022-06-25 17:12:33.545013
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-25 17:12:40.164871
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == obj.__dict__['y'] == 6

    obj.x = 7

    assert obj.y == 6

    obj.x = 9

    assert obj.y == 6

    del obj.y

    assert obj.y == 10


# Generated at 2022-06-25 17:12:44.231088
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _self = cached_property()
    obj = None
    cls = None
    # Test for TypeError
    try:
        cached_property.__get__(_self, obj, cls)
    except TypeError as error:
        assert "descriptor '__get__' of 'cached_property' object needs an argument" in str(error)



# Generated at 2022-06-25 17:12:46.685919
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_1 = None
    cached_property_1 = cached_property(int_1)
    cached_property_1.__get__
    pass

# Generated at 2022-06-25 17:12:52.846937
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('testing cached_property.__get__ for cached_property')
    str_0 = 'Test method __get__ of class cached_property'
    cached_property.test_case_0()
    assert 1 == 1


# Generated at 2022-06-25 17:12:57.439804
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    instances_0 = [cached_property(test_case_0)]
    instances_1 = [cached_property(test_case_0)]
    assert instances_0.__get__(None, None) == instances_1.__get__(None, None)


# Generated at 2022-06-25 17:12:59.364571
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()



if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:13:00.248379
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:13:03.140378
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0_exp = 'Test method __get__ of class cached_property'
    str_0_act = test_case_0()
    assert str_0_exp == str_0_act

# Generated at 2022-06-25 17:13:15.187229
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:13:17.893115
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Test method __get__ of class cached_property'

# Generated at 2022-06-25 17:13:20.948149
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

if __name__ == '__main__':
    # Unit test for method __get__ of class cached_property
    test_cached_property___get__()

# Generated at 2022-06-25 17:13:22.104934
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('Test method __get__ of class cached_property')


# Generated at 2022-06-25 17:13:24.462935
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert test_case_0() == 'Test method __get__ of class cached_property'


# Generated at 2022-06-25 17:13:31.237488
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass_0:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass_0()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 11



# Generated at 2022-06-25 17:13:35.346147
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Test method __get__ of class cached_property'



# Generated at 2022-06-25 17:13:38.735312
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    return

if __name__ == "__main__":
    test_cached_property___get__()

# EOF

# Generated at 2022-06-25 17:13:40.451604
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:13:41.814608
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _test_cached_property___get__()


# Generated at 2022-06-25 17:13:44.534132
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Test method __get__ of class cached_property'


# Generated at 2022-06-25 17:13:49.194907
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Test method __get__ of class cached_property'
    obj_0 = cached_property.cached_property
    obj_0.__get__(str_0)


# Generated at 2022-06-25 17:13:55.499899
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""

    # Set up test data
    str_0 = 'Test method __get__ of class cached_property'

    # Run the test
    try:
        actual = cached_property.test_case_0()
        expected = 'Test method __get__ of class cached_property'
        assert actual == expected
    except AssertionError as e:
        raise e

# Generated at 2022-06-25 17:14:03.502943
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print(test_case_0.__doc__)
    print(test_case_0.__name__)
    test_case_0()
    print("Test case passed")


# Scenario:
#   Test method __get__ of class cached_property
test_cached_property___get__()

# Generated at 2022-06-25 17:14:07.807112
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    # Example:
    # Test method __get__ of class cached_property
    class MyClass:

        def __init__(self):
            self.x = 5
            self.y = 0

        @cached_property
        def y(self):
            self.y = self.x + 1
            return self.y

    obj = MyClass()
    result = obj.y
    assert result == 6
    result = obj.y
    assert result == 6


# Generated at 2022-06-25 17:14:17.089226
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:14:19.082164
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert str_0=='Test method __get__ of class cached_property'


# Generated at 2022-06-25 17:14:26.975924
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    print("\nUnit test for method __get__ of class cached_property")

    class Test(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj_0 = Test()

    if obj_0.y == 6:

        print("method __get__ of class cached_property gives expected result\n")

    else:
        print("method __get__ of class cached_property gives unexpected result\n")


# Generated at 2022-06-25 17:14:37.572009
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    expected_type = 'method'
    expected_value = '__get__'
    result = cached_property.__get__.__name__
    assert isinstance(result, str)
    assert result == expected_value
    result = cached_property.__get__.__class__
    assert isinstance(result, type)
    assert result.__name__ == 'method_descriptor'
    result = type(cached_property.__get__).__name__
    assert isinstance(result, str)
    assert result == expected_type


# Generated at 2022-06-25 17:14:40.357342
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Test method __get__ of class cached_property'
    assert str(test_case_0()) == str_0

test_cached_property___get__()

# Generated at 2022-06-25 17:14:52.667671
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class C:

        @cached_property
        def y(self):
            return self.x

        def __init__(self, x):
            self.x = x

    assert C(5).y == 5
    assert C(6).y == 6

    class C:

        @cached_property
        def y(self):
            return self.z

        def __init__(self, x, y):
            self.x = x
            self.z = y

    assert C(5, 6).y == 6
    assert C(6, 5).y == 5

    class C:

        @cached_property
        def y(self):
            return self.z

        def __init__(self, x, y):
            self.x = x
            self.z = y


# Generated at 2022-06-25 17:14:57.073471
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:14:58.737487
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'Test method __get__ of class cached_property'


# Generated at 2022-06-25 17:15:02.568888
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import doctest
    import flutils.decorators

    doctest.testmod(flutils.decorators)



# Generated at 2022-06-25 17:15:09.820744
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Instantiate an instance of class cached_property
    property_0 = cached_property
    # Assign undefined to test property 'value' of the instance property_0
    del property_0
    # Instantiate an instance of class cached_property
    property_0 = cached_property
    # Assign undefined to test property 'value' of the instance property_0
    del property_0
    # Instantiate an instance of class cached_property
    property_0 = cached_property
    # Assign undefined to test property 'value' of the instance property_0
    del property_0


# Generated at 2022-06-25 17:15:20.180438
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test for method ``cached_property.__get__``"""
    pass


# Generated at 2022-06-25 17:15:23.037839
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Call method with arguments
    # No return value expected
    test_case_0()



# Generated at 2022-06-25 17:15:26.988128
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property(int_0)
    cached_property_0.__get__


# Generated at 2022-06-25 17:15:31.374321
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_cached_property___get___0()
    test_cached_property___get___1()
    test_cached_property___get___2()
    test_cached_property___get___3()
    test_cached_property___get___4()
    test_cached_property___get___5()
    test_cached_property___get___6()
    test_cached_property___get___7()
    test_cached_property___get___8()
    test_cached_property___get___9()
    test_cached_property___get___10()
# unit tests for cached_property

# Generated at 2022-06-25 17:15:37.520885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    
    class MyClass_0:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj_0 = MyClass_0()
    actual = obj_0.y
    expected = 6
    assert actual == expected

# Generated at 2022-06-25 17:15:39.854322
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property(int_0)

    try:
        cached_property_0.__get__()
    except TypeError:
        pass



# Generated at 2022-06-25 17:15:50.544280
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Assert that the following example from the module doc string
    # works as described

    # Example:
    # Code::
    #
    #     from flutils.decorators import cached_property
    #
    #     class MyClass:
    #
    #         def __init__(self):
    #             self.x = 5
    #
    #         @cached_property
    #         def y(self):
    #             return self.x + 1
    #
    # Usage:
    #
    #     >>> obj = MyClass()
    #     >>> obj.y
    #     6
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
   

# Generated at 2022-06-25 17:15:51.383684
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:15:59.727099
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def fn(obj, cls):
        return -1

    # Case 0:
    int_0 = None
    cached_property_0 = cached_property(fn)
    cached_property_0.__get__(int_0, int_0)
    # Case 1:
    coro = asyncio.coroutine(fn)
    cached_property_1 = cached_property(coro)
    cached_property_1.__get__(int_0, int_0)


# Generated at 2022-06-25 17:16:01.880885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:16:30.633756
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    @cached_property
    def get_foo_0():
        return 9

    print(get_foo_0)



# Generated at 2022-06-25 17:16:36.971785
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class_1:
        def __init__(self, arg0):
            self.default = arg0
            self.__class__ = cached_property
            pass

        def __get__(self, arg0, arg1):
            self.__class__ = int
            pass

        def __set__(self):
            pass

    class_1 = Class_1(int())
    assert class_1 == class_1
    test_case_0()
    assert class_1 == class_1



# Generated at 2022-06-25 17:16:42.471064
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from .samples.test_cached_property import Test
    test = Test()
    with unittest.TestCase() as testcase:
        assert test.y == 6

# Generated at 2022-06-25 17:16:50.859697
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property(int_0)
    import asyncio
    int_1 = None
    myclass_0 = MyClass(int_1)
    class0 = cached_property_0.__get__(myclass_0, type(myclass_0))
    if __name__ == '__main__':
        assert (class0 is myclass_0)
    if __name__ == '__main__':
        assert (class0.x == int_1)


# Generated at 2022-06-25 17:16:52.482009
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

if __name__ == "__main__":
    run_test(test_cached_property___get__)

# Generated at 2022-06-25 17:16:54.820283
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:16:58.047417
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class_0 = None
    instance_of_class_cached_property = cached_property(class_0)
    obj = None
    cls = None
    cached_property___get__ = instance_of_class_cached_property.__get__(obj, cls)


# Generated at 2022-06-25 17:16:59.727153
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass # TODO: implement your test here


# Generated at 2022-06-25 17:17:04.866380
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    params = {
        '_obj': None,
        '_cls': None,
    }
    cached_property_0 = cached_property(params)
    actual = cached_property_0.__get__( )


# Generated at 2022-06-25 17:17:12.157711
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest

    class TestClass:
        """Test class."""

        def __init__(self):
            """Initialize instance."""
            self.x = self.__class__.__name__

        @cached_property
        def y(self):
            """Get y."""
            return self.x + 'y'

    obj = TestClass()
    assert obj.y == 'TestClassy'

    class TestClass:
        """Test class."""

        def __init__(self):
            """Initialize instance."""
            self.x = self.__class__.__name__

        @cached_property
        def y(self):
            """Get y."""
            return self.x + 'y'

    obj = TestClass()
    assert obj.y == 'TestClassy'


# Unit

# Generated at 2022-06-25 17:18:28.142216
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test against an instance.
    class TestClass:
        def __init__(self):
            self.a = 0
            self.b = 'something'
            self.c = None

        @cached_property
        def increment_a(self):
            self.a += 1
            return self.a

    obj_0 = TestClass()
    cached_property_0 = cached_property(obj_0.increment_a)
    assert cached_property_0.__get__(obj_0) == 1
    assert obj_0.__dict__['increment_a'] == 1
    assert cached_property_0.__get__(obj_0) == 1
    assert obj_0.__dict__['increment_a'] == 1

    # Test against a class.

# Generated at 2022-06-25 17:18:29.307158
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(0)
    try:
        cached_property_0.__get__()
    except TypeError:
        pass


# Generated at 2022-06-25 17:18:37.656183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.misc import Attrs
    class MyClass(Attrs):
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    assert obj.y == 6
    obj.x = 10
    assert obj.y == 11; del obj.y
    assert obj.y == 11


# Generated at 2022-06-25 17:18:44.665654
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property(int_0)
    cached_property___get___0 = cached_property_0.__get__(None, cached_property)
    print(cached_property___get___0)
    print(cached_property___get___0)


# Generated at 2022-06-25 17:18:46.169116
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property(int_0)
    cached_property_1 = cached_property(int_0)

# Generated at 2022-06-25 17:18:51.453643
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(int_0)
    with pytest.raises(TypeError):
        cached_property_0.__get__(int_0, int_0)

    with pytest.raises(TypeError):
        cached_property_0.__get__(str_0, int_0)



# Generated at 2022-06-25 17:18:55.072118
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property(int_0)
    assert isinstance(cached_property_0.__get__(int_0, int), cached_property)
    int_1 = None
    obj_0 = cached_property(int_1)
    obj_0.y
    assert isinstance(obj_0.y, int)
    assert obj_0.y == 1


# Generated at 2022-06-25 17:19:01.872563
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import flutils.decorators.cached_property as cached_property
    from flutils.decorators import cached_property as cached_property0
    from flutils.decorators.cached_property import cached_property as cached_property1

    int_0 = None
    cached_property_0 = cached_property.cached_property(int_0)
    int_1 = None
    object_0 = cached_property_0.__get__(int_1, int_1)
    int_2 = None
    object_1 = cached_property_0.__get__(int_1, int_2)


# Generated at 2022-06-25 17:19:05.393434
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    tc0 = test_case_0()
    assert True


# Generated at 2022-06-25 17:19:08.336852
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property(int_0)
    cached_property_0.__get__(int_0)
