

# Generated at 2022-06-25 17:10:39.528421
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Test():

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = Test()
    cached_property_0 = cached_property(obj)
    assert cached_property_0.y == 6

# Generated at 2022-06-25 17:10:45.272855
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 7
    assert obj.y == 8

    # Verify that deleting the property removes the value
    del obj.y
    assert not hasattr(obj, 'y')

# Generated at 2022-06-25 17:10:47.886750
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test case 0
    test_case_0()
    # Test case 1
    #
    # Test case 2
    #
    # Test case 3
    #
    # Test case 4
    #


# Generated at 2022-06-25 17:10:50.806773
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 17:11:00.101996
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_case_0():
        test_case_0 = 9
        isinstance(cached_property.__get__(test_case_0), cached_property)
        # Test to ensure that TypeError is raised.
        with pytest.raises(TypeError):
            cached_property.__get__(test_case_0)


# Generated at 2022-06-25 17:11:03.327031
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    cached_property_1 = cached_property_0.__get__(cached_property_0, cached_property_0)


# Generated at 2022-06-25 17:11:09.103783
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert_none_equal(
        cached_property_0___get__(['self', 'obj', 'cls'], [None, None, None]), None
    )



# Generated at 2022-06-25 17:11:19.403117
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Capturing the call to the method __get__ of class cached_property
    with pytest.raises(TypeError) as exception_info:
        # Using the following as parameters:
        #   obj = 
        #   cls = 
        # Invoking the method
        cached_property___get__(obj, cls)
    # Asserting "cached_property" is in the error message
    assert "cached_property" in str(exception_info.value)
    # Capturing the call to the method __get__ of class cached_property
    with pytest.raises(TypeError) as exception_info:
        # Using the following as parameters:
        #   obj = 
        #   cls = 
        # Invoking the method
        cached_property___get__(obj, cls)
    # Ass

# Generated at 2022-06-25 17:11:26.662692
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(x_0)
    cached_property_1 = cached_property(x_1)

    assert cached_property_0.func is cached_property_1.func

    assert cached_property_0.__get__ is cached_property_1.__get__

    assert cached_property_0.__get__ is not cached_property_1.__get__

    assert cached_property_0.__get__ is cached_property_1.__get__

# Generated at 2022-06-25 17:11:28.729671
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    obj = cached_property_0
    cls = cached_property_0


# Generated at 2022-06-25 17:11:37.884507
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Using instance MyClass of class MyClass as param obj of __get__
    param_obj = MyClass()
    var_returned = param_obj.y
    assert var_returned == 6, 'Expected return value of MyClass().y is 6, but it returned: ' + repr(var_returned)


# Generated at 2022-06-25 17:11:41.862793
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert hasattr(cached_property, '__get__')
    assert callable(getattr(cached_property, '__get__'))


# Generated at 2022-06-25 17:11:47.453849
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property()
    obj_0.func = lambda: 'y'
    assert obj_0.__get__(obj_0, obj_0) == str('y')


test_case_0()
test_cached_property___get__()

# Generated at 2022-06-25 17:11:48.366655
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'y'


# Generated at 2022-06-25 17:11:52.458599
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(test_case_0)
    obj_1 = obj_0.__get__(None, test_case_0)
    assert obj_1.func == test_case_0, """ Assertion failed """


# Generated at 2022-06-25 17:12:00.433060
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    x = 5
    y = x + 1
    print("=======Begin Unit Test: test_cached_property___get__=======")
    # Test case 0
    obj = MyClass()
    print("Test case 0:", obj.y == y)
    print("========End Unit Test: test_cached_property___get__========")


# Generated at 2022-06-25 17:12:05.437267
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case = 'test_case_0'

    def _test_cached_property___get__():
        local_vars = locals()
        for k in local_vars.keys():
            if k.startswith('test_case_'):
                if not local_vars[k]:
                    print(f'Test case {k} failed')
        print(f'Test cases {test_case} completed')

    test_case_0()
    _test_cached_property___get__()

# Generated at 2022-06-25 17:12:12.426697
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    my_instance = MyClass()
    if asyncio.iscoroutinefunction(my_instance.y):
        assert (my_instance.__get__(my_instance, my_instance) == 6)
    else:
        assert (my_instance.__get__(my_instance, my_instance) == 6)


# Generated at 2022-06-25 17:12:18.050378
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:12:20.840500
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = ''
    cls_0 = 'L'
    var_0 = cached_property.__get__(obj_0, cls_0)


# Generated at 2022-06-25 17:12:32.068288
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import os
    import pytest
    str_0 = 'unit_test_0.txt'
    # delete file if it exists
    if os.path.exists(str_0):
        os.remove(str_0)
    # write a test case
    out_file = open(str_0, 'wb')

# Generated at 2022-06-25 17:12:34.861392
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(test_case_0)
    co_0 = obj_0.__get__(None, None)
    assert True


# Generated at 2022-06-25 17:12:35.428490
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:12:38.334060
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        test_case_0()
    except Exception as e:
        assert False, str(e)
    else:
        assert True


# Generated at 2022-06-25 17:12:42.427480
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        str_0 = 'y'
        obj_0 = MyClass()
        test_case_0(obj_0, str_0)
        test_case_1(obj_0)
    except Exception as e:
        print("cached_property: ", e)


# Generated at 2022-06-25 17:12:47.451040
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test Case 1
    test_case_1(test_case_0)


# Generated at 2022-06-25 17:12:47.991985
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:12:48.828711
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:12:50.597784
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:12:51.835527
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert False


# Generated at 2022-06-25 17:13:05.925224
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def wrapper_0():
        cached_property_0 = cached_property(list.append)
        cached_property_0.__get__(list(), wrapped_function)

    def wrapped_function(self):
        return "result_0"
    test_instance_0 = cached_property(entry_point_0)

    def entry_point_0(arg_0, arg_1):
        var_0 = arg_1
        var_1 = arg_0
        wrapper_0()
        return "result_0"
    result_0 = test_instance_0.__get__(entry_point_0, None)


# Generated at 2022-06-25 17:13:09.363024
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    int_1 = 6
    cached_property.__get__(cached_property_0, int_1)


# Generated at 2022-06-25 17:13:15.834772
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Generic:
        """
        A dummy class used for Generic tests of cached_property
        """

        def __init__(self, x_0=0):
            self.x_0 = x_0
            self.cached_property_0 = cached_property(self.x_0)

    generic_0 = Generic()
    generic_0.cached_property___get__(None, Generic)



# Generated at 2022-06-25 17:13:18.302158
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True


# Generated at 2022-06-25 17:13:21.032302
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = None
    cached_property_0 = cached_property()
    obj_0 = cached_property_0.__get__(int_0, int)


# Generated at 2022-06-25 17:13:21.866094
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:13:22.658797
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:13:24.422805
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-25 17:13:28.279236
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    class_0 = cached_property_0.__get__((),)
    assert class_0._cached_property__doc__ == 'Return the absolute value of the argument.'



# Generated at 2022-06-25 17:13:31.211119
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test function
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-25 17:13:44.552220
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method on class cached_property.

    This method tests the functionality of the method __get__ on the class
    cached_property. Note the method __get__ is not a public method and will
    only be called on by an instance of the class.

    """

    obj = Any()
    cls = Any()
    cached_property_0 = cached_property(int)
    try:
        result = cached_property_0.__get__(obj, cls)
    except Exception as result:
        pass


# Generated at 2022-06-25 17:13:45.810775
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-25 17:13:50.565536
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y



# Generated at 2022-06-25 17:13:55.358680
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(0)
    int_0 = 0
    try:
        cached_property_0.__get__(int_0)
    except KeyError:
        pass
    # Missing break in switch statement.
    pass


# Generated at 2022-06-25 17:13:58.317296
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:14:09.132604
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test when obj is None;
    #   expect a cached_property
    cached_property_0 = cached_property(pow)
    cached_property_0.__get__(None, 0)
    # Test when obj is not None
    cached_property_1 = cached_property(pow)
    class C:
        def __init__(self):
            pass
    obj = C()
    class B:
        def __init__(self):
            pass
    cls = B()
    obj.__dict__['pow'] = 0
    assert (cached_property_1.__get__(obj, cls) == 0)


# Generated at 2022-06-25 17:14:16.039224
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 5
    class_0 = cached_property(int_0)
    class_c_0 = class_0.__get__(int_0, int_0)
    assert class_c_0 == 5, f"expected: {5}, actual: {class_c_0}"


# Generated at 2022-06-25 17:14:27.993296
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print("Test cached_property.__get__()")

    # ----------
    # Set up test

    # Create a cached_property.
    #
    # Arg:
    #     func: The function to be called to compute the attribute value.
    cached_property_0 = cached_property(int)
    cached_property_1 = cached_property(int)
    cached_property_2 = cached_property(int)
    cached_property_3 = cached_property(int)
    cached_property_6 = cached_property(int)
    cached_property_7 = cached_property(int)

    # ----------
    # Test method __get__ of class cached_property
    #
    # Test return type of cached_property.__get__(obj, cls).
    #
    # Call cached_property.__get__(obj

# Generated at 2022-06-25 17:14:37.456343
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    from unittest.mock import Mock

    # Run
    foo = foo()
    foo.bar = Mock()
    foo.bar.__get__ = Mock()
    foo.bar.__get__.return_value = func
    foo.__init__()
    foo.__get__()
    result = foo.bar.__get__.call_count
    # Evaluate
    assert result == 1
    # Teardown


# Generated at 2022-06-25 17:14:42.731952
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    myclass_0 = MyClass()
    str_0 = cached_property_0.__get__(myclass_0)
    assert str_0 == '6'


# Generated at 2022-06-25 17:14:58.571850
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def test_case_0():
        int_0 = 6
        cached_property_0 = cached_property(int_0)
        assert cached_property_0.__get__() == None

    def test_case_1():
        int_0 = 6
        cached_property_0 = cached_property(int_0)
        assert cached_property_0.__get__(None, None) == (int_0, None)

    def test_case_2():
        int_0 = 6
        cached_property_0 = cached_property(int_0)
        assert cached_property_0.__get__(None) == (int_0, None)

    def test_case_3():
        int_0 = 6
        cached_property_0 = cached_property(int_0)

# Generated at 2022-06-25 17:15:03.257055
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    any_0 = cached_property_0.__get__([], [])
    assert 1 == any_0


# Generated at 2022-06-25 17:15:06.971659
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)

    # Test __get__

    assert cached_property_0.__get__(int_0, cached_property) == 6



# Generated at 2022-06-25 17:15:08.785817
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    myclass_0 = MyClass()
    cached_property_0 = myclass_0.y


# Generated at 2022-06-25 17:15:11.226067
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property_0
    cls_0 = None
    cached_property_0.__get__(obj_0, cls_0)

# Generated at 2022-06-25 17:15:22.922204
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from itertools import count
    from unittest.mock import patch
    from flutils.decorators import cached_property
    from flutils.decorators import test_case_0
    from flutils.commons import deprecated_alias
    from flutils.decorators import cached_property
    from flutils.decorators import test_case_0
    from flutils.decorators import test_cached_property___get__
    from flutils.decorators import test_cached_property__wrap_in_coroutine
    from virustotal.virustotal import Virustotal
    from flutils.commons import deprecated_alias
    from flutils.decorators import cached_property
    from flutils.decorators import test_case_0


# Generated at 2022-06-25 17:15:27.960913
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = asyncio.coroutine
    cached_property_0 = cached_property(int_0)
    obj = MyClass()
    cls = MyClass
    cached_property_0.__get__(obj, cls)


# Generated at 2022-06-25 17:15:30.835188
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    try:
        cached_property_0.__get__(cached_property_0, int)
    except:
        pass

# Generated at 2022-06-25 17:15:33.328377
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        test_case_cached_property___get__()
    except:
        print(traceback.format_exc())


# Generated at 2022-06-25 17:15:38.422800
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    int_1 = cached_property_0.__get__(int_0, int)
    assert int_0 == int_1


# Generated at 2022-06-25 17:15:53.019784
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:16:02.718486
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    import os
    import time
    import asyncio
    import random
    from flutils.decorators import cached_property

    import concurrent.futures
    import multiprocessing
    import threading

    class Counter(object):

        @cached_property
        def randint(self):
            return random.randint(1, 100)

    class Counter_async(object):

        @cached_property
        def randint(self):
            return asyncio.sleep(1)

    def test_counter():
        counter = Counter()
        return counter.randint

    def test_counter_async():
        counter = Counter_async()
        return counter.randint

    def test_property_decorator():
        return test_counter()



# Generated at 2022-06-25 17:16:05.258808
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-25 17:16:07.603410
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    cached_property_0.__get__()

# Generated at 2022-06-25 17:16:13.773409
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Ensure that __get__ returns the correct string
    # Test default
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    assert cached_property_0.__get__(5, 7) is None
    # Test simple argument
    int_1 = 7
    cached_property_1 = cached_property(int_1)
    assert cach

# Generated at 2022-06-25 17:16:17.584278
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property("\u0000")
    obj_1 = cached_property("\u0000")
    cls_0 = cached_property(b'')
    try:
        obj_1.__get__(obj_0, cls_0)
    except BaseException:
        print("Couldn't get attribute 'y' on class MyClass")


# Generated at 2022-06-25 17:16:27.747024
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import MagicMock
    import sys
    x_obj = object()
    x_cls = MagicMock()
    type(x_cls).__name__ = 'MyClass'
    cached_property_0 = cached_property(object)
    try:
        r_0 = sys.version_info.minor == 8
    except:
        r_0 = False
    try:
        r_1 = sys.version_info.minor == 7
    except:
        r_1 = False
    except:
        r_1 = None
    try:
        r_2 = sys.version_info.minor == 6
    except:
        r_2 = False
    try:
        r_3 = sys.version_info.minor == 5
    except:
        r_3

# Generated at 2022-06-25 17:16:38.681474
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class ADummyClass:
        dummy_field_0: int
        cached_property_0 = cached_property(dummy_field_0)
        def __init__(self):
            self.dummy_field_0 = 0
            self.dummy_field_1 = 8
            self.cached_property_0 = cached_property(self.dummy_field_1)

    dummy_class_0 = ADummyClass()


# Generated at 2022-06-25 17:16:40.855380
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True

# Generated at 2022-06-25 17:16:43.524827
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:17:09.554521
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:17:11.835341
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = cached_property
    attr_int_0 = int_0.y
    del attr_int_0.x



# Generated at 2022-06-25 17:17:17.462088
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_cached_property___get__0_parameters():
        cached_property_0 = cached_property(int_0)
        obj = object()
        cls = type(obj)
        cached_property___get___return = cached_property_0.__get__(obj,
                                                                   cls)
        # Assert the return value:
        assert cached_property___get___return is None  # returned None



# Generated at 2022-06-25 17:17:22.421589
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    obj_0 = cached_property_0.__get__(obj_0, obj_0)



# Generated at 2022-06-25 17:17:28.647372
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    # Test for normal behavior where the value is cached.
    obj = MyClass()
    res = obj.y
    assert res == 6

    # Test with deletion
    del obj.y
    assert hasattr(obj, "y") == False

# Generated at 2022-06-25 17:17:31.109537
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    obj_0 = cached_property(int_0)
    cls_0 = None
    assert obj_0.__get__(None, None) is obj_0


# Generated at 2022-06-25 17:17:32.526781
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property.__get__(cached_property)
    assert obj is None


# Generated at 2022-06-25 17:17:43.156880
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def test_function_0():
        # Remaining lines of method __get__ of class cached_property

        # Tail call to method __get__ of class cached_property
        try:
            return cached_property___get__(self_0, obj_0, cls_0)
        except Exception as err1:
            raise Exception("Cannot cast __get__ of cached_property to function") from err1

    def test_function_1():
        # Remaining lines of method __get__ of class cached_property

        # Tail call to method __get__ of class cached_property
        try:
            return cached_property___get__(self_0, obj_0, cls_0)
        except Exception as err2:
            raise Exception("Cannot cast __get__ of cached_property to function") from err2


# Generated at 2022-06-25 17:17:46.177512
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:17:50.315810
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        test_case_0()
    except TypeError:    # expected exception
        pass
    else:
        assert False, 'ExpectedException not raised'

# Generated at 2022-06-25 17:19:00.899412
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True


# Generated at 2022-06-25 17:19:06.168371
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    assert cached_property_0.__get__ is cached_property.__get__


# Generated at 2022-06-25 17:19:10.893524
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass_obj:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    MyClass_obj = MyClass_obj()
    result = MyClass_obj.y
    expected = 6
    assert result == expected, result

# Generated at 2022-06-25 17:19:18.940138
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)
    obj_0 = object()
    cls_0 = type(obj_0)

# Generated at 2022-06-25 17:19:22.991246
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1


# Generated at 2022-06-25 17:19:31.408437
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    tempdir = os.path.dirname(os.path.dirname(__file__))
    class_0 = MyClass()
    class_0.x = 5
    y = class_0.y
    try:
        assert y == 6
    except AssertionError as e:
        tempdir = os.path.dirname(os.path.dirname(__file__))
        print("AssertionError: \n{}".format(e), end='')



# Generated at 2022-06-25 17:19:33.425478
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    myclass_0 = MyClass()
    cached_property_0 = myclass_0.y
    assert cached_property_0 == 6


# Generated at 2022-06-25 17:19:34.909116
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = MyClass()
    assert obj_0.y == 6

# Generated at 2022-06-25 17:19:37.236283
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 6
    cached_property_0 = cached_property(int_0)

# Generated at 2022-06-25 17:19:39.235914
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    my_class_0 = MyClass()
    my_class_0.y
