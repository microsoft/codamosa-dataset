

# Generated at 2022-06-25 17:10:37.689556
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # str -> NoneType
    test_case_0()

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass()
    y = obj.y
    assert y == 6



# Generated at 2022-06-25 17:10:43.856339
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('Testing cached_property.__get__')
    instance_of_cached_property_0 = cached_property()
    class_0 = object
    instance_0 = cached_property()
    instance_1 = cached_property()
    cached_property_0 = cached_property.__get__(instance_0, class_0)
    cached_property_1 = cached_property.__get__(instance_1, class_0)
    assert(cached_property_0 == instance_0)
    assert(cached_property_1 == instance_1)


# Generated at 2022-06-25 17:10:50.214356
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(int)
    str_0 = '\x1b\\g\x18\\\x18\x17\x1c'
    assert cached_property_0.__get__(str_0, int) == '\x1b\\g\x18\\\x18\x17\x1c', 'Failed test_cached_property___get__'


# Generated at 2022-06-25 17:10:52.834916
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = MyClass()
    obj.y


# Generated at 2022-06-25 17:11:02.939782
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'test_str_0'
    str_1 = 'test_str_1'
    str_2 = 'test_str_2'
    str_3 = 'test_str_3'
    str_4 = 'test_str_4'
    cached_property_0 = cached_property(str_0)
    cached_property_1 = cached_property(str_1)
    cached_property_2 = cached_property(str_2)
    cached_property_3 = cached_property(str_3)
    cached_property_4 = cached_property(str_4)
    class C:
        def __init__(self):
            pass
        @cached_property_0
        def test_method_0(self):
            return 'test_str_0'

# Generated at 2022-06-25 17:11:12.526795
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def cached_property_0_0():
        # <Value 'self.x' (11:9)> -> <Expression 'self.x' (13:13) (11:4)>
        # <Value 'self.y' (12:15)> -> <Expression 'self.y' (16:15) (12:4)>
        cached_property_1_0 = cached_property(None)
        class Class_0_0:

            def __init__(self):
                self.x = 5
                self.y = 6
            @cached_property
            def y(self):
                return self.x + 1
        instance_0_0 = Class_0_0()
        # <Value 'instance_0_0' (13:13)> -> <Expression 'instance_0_0' (17:9

# Generated at 2022-06-25 17:11:20.968446
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '`V'
    cached_property_1 = cached_property(str_0)
    cached_property_1.__get__(cached_property_1, cached_property_1)
    cached_property_1.__get__(cached_property_1, cached_property_1)
    cached_property_1.__get__(cached_property_1, cached_property_1)
    cached_property_1.__get__(cached_property_1, cached_property_1)
    cached_property_1.__get__(cached_property_1, cached_property_1)
    str_1 = ':;,\\7\x0b,'
    cached_property_2 = cached_property(str_1)
    str_2 = '`V'
    cached_property_

# Generated at 2022-06-25 17:11:28.233879
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property.__get__(cached_property_0, cached_property_0, type)

if (__name__ == '__main__'):
    import sys
    import __main__

    if (len(sys.argv) >= 2):
        globals()[__main__._getFrame().f_code.co_name]()
    else:
        from flutils.decorators import *

        cached_property_0 = None

        test_case_0()

        test_cached_property___get__()

# Generated at 2022-06-25 17:11:35.217727
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'szMKLqPAh;#*TwO'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__('x', 'hbY4<')
    cached_property_0.__get__('szMKLqPAh;#*TwO', 'szMKLqPAh;#*TwO')


# Generated at 2022-06-25 17:11:47.347414
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from mock import Mock
    from mock import patch
    from flutils.decorators import cached_property

    # Assigning parameters
    func_0 = Mock()
    cls_0 = Mock()
    obj_0 = Mock()

    # Call tested function
    cached_property_0 = cached_property(func_0)
    cached_property_0.__get__(obj_0, cls_0)

    # Assertions order
    param_0 = func_0.assert_called_with(obj_0)
    param_1 = obj_0.__dict__.__setitem__.assert_called_with(cached_property_0.func.__name__, func_0.return_value)

# Generated at 2022-06-25 17:12:00.830257
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def __init__(self):
        self.a = '\t\n\t'
        self.b = '"<\t'
        self.c = 'j"Y'
        self.d = '1'
        self.e = 'n'
        self.f = 'g_'
        self.g = 'k!'
        self.h = 'q9'
        self.i = '\x0c'
        self.j = '}'
        self.k = '\x0c'
        self.l = 'm'
        self.m = '\n\n'
        self.n = 'X'
        self.o = '\x1c'
        self.p = '\t\n'
        self.q = '\t'
        self.r = '\n'

# Generated at 2022-06-25 17:12:02.053648
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:12:07.979189
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'none'
    cached_property_0 = cached_property(str_0)
    str_1 = ':;,\\7\x0b,'
    cached_property_0.func = str_1
    str_2 = '((#'
    myclass_0 = MyClass(str_2)
    str_3 = '((#'
    myclass_1 = MyClass(str_3)
    any_0 = cached_property_0.__get__(myclass_0, myclass_1)


# Generated at 2022-06-25 17:12:17.913853
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '<=D5p)\tF\x7f'
    int_0 = -10
    str_1 = '`'
    str_2 = '\x17o8VmWm\x1f'
    str_3 = '1S\x0f3#\x17\x15\x1d\x07\x02\x14'
    str_4 = 'n\x1d\x16\x1c\x01B$\x11\x01'
    str_5 = '\x1b\x1a\x1f\x04\x02\x01/\x01\x0c\x04\x1f'
    str_6 = '`1'
    str_7 = '\x14;~A\x15'
    str_8

# Generated at 2022-06-25 17:12:27.746644
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from collections import OrderedDict
    int_1 = 1
    int_0 = 0
    str_1 = '-'
    str_0 = '>H2'
    list_0 = ['Y', str_0, str_1, 'w', '\<', 'B', '3', 'z', 'D', '-', '{', 'O', '\'', 'P', 'b', 'N', 'r', '3']
    dict_0 = dict()
    dict_0['P'] = list_0
    dict_0['\x0c'] = list_0
    dict_0['d'] = [str_1]
    dict_0['\x0b'] = [str_1]
    dict_1 = dict()

# Generated at 2022-06-25 17:12:28.785578
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:12:33.455290
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('Test case 0 - Unit test for method __get__ of class cached_property')
    test_case_0()

# Test for class cached_property

# Generated at 2022-06-25 17:12:43.846244
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'B'
    tuple_1 = ()
    cached_property_0 = cached_property(tuple_1)
    tuple_2 = (tuple_1,)
    cached_property_0 = cached_property(tuple_2)
    cached_property_1 = cached_property(cached_property_0)
    tuple_3 = (cached_property_0,)
    cached_property_1 = cached_property(tuple_3)
    int_0 = 0
    try:
        int_0 = cached_property_0.__get__(cached_property_1, tuple_1)
    except:
        pass
    try:
        int_0 = cached_property_1.__get__(cached_property_0, tuple_1)
    except:
        pass
    cached_property

# Generated at 2022-06-25 17:12:47.345239
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ':;,\\7\x0b,'
    cached_property_0 = cached_property(str_0)
    assert cached_property_0.__get__(str_0, str_0) is str_0
    assert cached_property_0.__get__(str_0, str_0) is str_0
    assert cached_property_0.__get__(str_0, str_0) is str_0
    assert cached_property_0.__get__(str_0, str_0) is str_0

# Generated at 2022-06-25 17:12:51.523544
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(str)
    assert not cached_property_0.__get__(str(1), str).__doc__
    assert cached_property_0.__get__(str(1), None) == cached_property_0

# Generated at 2022-06-25 17:12:58.797879
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """ Unit test for method __get__ of class cached_property """
    cached_property_0 = cached_property('_sc2_')
    assert( isinstance(cached_property_0.__get__('ye0', '5:,x'), cached_property) )



# Generated at 2022-06-25 17:13:01.208363
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property

    # Case 0
    test_case_0()



# Generated at 2022-06-25 17:13:08.938224
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'cached_property'
    cached_property_0 = cached_property(str_0)
    dict_0 = {str_0: None}
    obj_0 = type('Name',(object,),dict_0)(**{str_0:cached_property_0,str_0:str_0})
    obj_0.__dict__[str_0] = obj_0.__dict__[str_0](obj_0)
    assert obj_0.__dict__[str_0] == str_0


# Generated at 2022-06-25 17:13:19.392950
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = str()
    int_0 = int()
    str_1 = str('84')
    cached_property_0 = cached_property(int_0)
    assert cached_property_0.func == int_0
    assert cached_property_0.__get__(int_0, None) == int_0
    assert cached_property_0.__get__(str_0, None) == cached_property_0
    assert cached_property_0.__get__(str_1, None) == cached_property_0
    assert cached_property_0.__get__(int_0, None) == int_0


# Generated at 2022-06-25 17:13:27.099217
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ':;,\\7\x0b,'
    cached_property_0 = cached_property(str_0)
    assert_equal(cached_property_0.__get__(object, None), cached_property_0)
    str_0 = 'w-mQ\x7f\x14t'
    cached_property_0 = cached_property(str_0)
    assert_equal(cached_property_0.__get__(object, None), cached_property_0)


if __name__ == "__main__":
    runmodule()

# Generated at 2022-06-25 17:13:35.505331
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(str_0)
    
    try:
        cached_property_0.__get__
    except AttributeError:
        print('AttributeError exception')
    else:
        pass
    


# Generated at 2022-06-25 17:13:37.033354
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 17:13:43.449406
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '}mf?xLl??m'
    asyncio_1 = asyncio
    cached_property_0 = cached_property(str_0)
    cached_property_1 = cached_property_0.__get__(None)
    asyncio_0 = asyncio
    return cached_property_0


# Generated at 2022-06-25 17:13:47.067057
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('Testing method __get__ of class cached_property')

    obj_0 = cached_property(None)
    obj_0.__get__('[\r', str())


# Generated at 2022-06-25 17:13:54.168987
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ':;,\\7\x0b,'
    cached_property_0 = cached_property(str_0)
    p = cached_property_0.__get__(None, MyClass)
    # Validate that the property is calculated only once.
    for i in range(10):
        p()
    assert MyClass.x == 5
    assert p == 6


# Generated at 2022-06-25 17:14:02.173470
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test __get__"""
    pass

# Generated at 2022-06-25 17:14:07.726342
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # 1
    str_1 = '=\x1cA\x1b\x05\x0e;'
    cached_property_1 = cached_property(str_1)
    str_2 = '\x1eb6\n\x1e\x0c\x0b,'
    cached_property_1 = cached_property_1.__get__(str_2)


# Generated at 2022-06-25 17:14:13.426559
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ':;,\\7\x0b,'
    cached_property_0 = cached_property(str_0)
    str_1 = 'pgt:;,\\7\x0b,'
    str_1 = cached_property_0.__get__(str_1, str)

# Generated at 2022-06-25 17:14:20.469172
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ':;,\\7\x0b,'
    cached_property_0 = cached_property(str_0)
    str_1 = '5"5\x0c'
    str_2 = '5;9R'
    str_3 = '5;9R'
    str_4 = '5;9R'
    str_5 = '5;9R'
    str_6 = '5;9R'
    str_7 = '5;9R'
    str_8 = '5;9R'
    str_9 = '5;9R'
    str_10 = '5;9R'
    str_11 = '5;9R'
    str_12 = '5;9R'
    str_13 = '5;9R'

# Generated at 2022-06-25 17:14:26.772686
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    class MyClass():

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    instance0 = MyClass()
    cls0 = MyClass
    assert (instance0.y == 6)
    assert (cls0.y == cached_property)


# Generated at 2022-06-25 17:14:39.921317
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(str_0)
    cls_0 = str
    cached_property_0 = obj_0.__get__(obj_0, cls_0)
    cached_property_0 = obj_0.__get__(obj_0, obj_0)
    cached_property_0 = obj_0.__get__(obj_0, obj_0)
    cached_property_0 = obj_0.__get__(obj_0, obj_0)
    cached_property_0 = obj_0.__get__(cls_0, cls_0)
    cached_property_0 = obj_0.__get__(cls_0, cls_0)
    cached_property_0 = obj_0.__get__(cls_0, cls_0)
    cached

# Generated at 2022-06-25 17:14:43.225460
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ':;,\\7\x0b,'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:14:47.388220
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ''
    cached_property_0 = cached_property(str_0)
    obj = None
    cls = None
    cached_property_0.__get__(obj, cls)


# Generated at 2022-06-25 17:14:50.122710
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ',\\7\x0b'
    cached_property_0 = cached_property(str_0)
    obj_0 = MyClass()
    cached_property_0.__get__(obj_0, cached_property)


# Generated at 2022-06-25 17:14:51.314056
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:15:09.300407
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '1^{lq3,!6>vU8JP'
    #  test 0:
    #     cached_property_0 = cached_property(str_0)
    #     test_0 = type(cached_property_0)
    #     assert test_0 is None, test_0


# Generated at 2022-06-25 17:15:11.457220
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(str)
    cached_property_0.deleter = str


# Generated at 2022-06-25 17:15:16.144184
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ':;,\\7\x0b,'
    cached_property_0 = cached_property(str_0)
    assert False


# Generated at 2022-06-25 17:15:22.140821
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '!99@ 9&@@!@ *! *@!@ *! *$'
    cached_property_0 = cached_property(str_0)
    obj_0 = object()
    cls_0 = object()
    obj_1 = cached_property_0.__get__(obj_0, cls_0)
    assert obj_1 is cached_property_0


# Generated at 2022-06-25 17:15:26.948047
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # AssertionError: TypeError not raised
    try:
        cached_property_0 = cached_property('', [], [])
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 17:15:28.629032
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = ',)\x1c\xa7:'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:15:39.940387
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:15:50.591061
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '_y'
    str_1 = '_F'
    str_2 = '-Q'
    str_3 = '_F'
    str_4 = 'BK'
    #Parameters:
    #    arg_0: *
    #    arg_1: *
    #    arg_2: *
    #    arg_3: *
    #    arg_4: *
    #    arg_5: *
    #    arg_6: *
    #    arg_7: *
    #    arg_8: *
    #    arg_9: *
    #    arg_10: *
    #    arg_11: *
    #    arg_12: *
    #    arg_13: *
    #    arg_14: *
    #    arg_15: *


# Generated at 2022-06-25 17:15:54.405748
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = random.sample(string.ascii_letters, len(string.ascii_letters))
    cached_property_0 = cached_property(str_0)
    int_4 = len(str_0)  # len(str-1)
    int_5 = len(str_0)  # len(str-1)
    str_1 = random.sample(string.ascii_letters, len(string.ascii_letters))
    int_6 = len(str_0)  # len(str-1)
    cached_property_0.__get__(str_1, int_6, int_5)
    cached_property_0.__get__(str_1, int_6, int_5)
    int_7 = len(str_0)  # len(str-1)

# Generated at 2022-06-25 17:16:08.290659
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '6'
    str_1 = '!np'
    str_2 = '&'
    str_3 = '8'
    str_4 = 'J['
    str_5 = 'CnG'
    str_6 = '5'
    str_7 = 'Z@'

    # Method __get__ of class cached_property
    # There is a non-empty method body despite the warning message.
    # This can have unexpected behavior when translating.
    #
    # Verdict: INVALID (test incomplete)
    #
    # Rationale:
    # Warnings should not be disabled by default.
    #

# Generated at 2022-06-25 17:16:43.360199
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '\x01\x09\x06'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(None, None)


# Generated at 2022-06-25 17:16:46.176422
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Initialize cached_property_0
    test_case_0()

    test_case_0()

# Generated at 2022-06-25 17:16:50.329259
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    c = MyClass()
    v = c.y
    # Property 'y' should be cached
    v = c.y
    # This should not throw an exception
    del c.y
    # The property should not be cached this time
    v = c.y


# Generated at 2022-06-25 17:16:54.423473
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property

    #
    # Create a new class 'MyClass' using the cached_property decorator.
    #
    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6
    obj.x = 9
    assert obj.y == 10

# Generated at 2022-06-25 17:17:00.602487
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = MyClass()
    str_0 = ':;,\\7\x0b,'
    cached_property_0 = cached_property(str_0)
    #del obj.y
    #obj.y

# Generated at 2022-06-25 17:17:07.409057
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass_0:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj_0 = MyClass_0()
    int_0 = obj_0.y
    assert obj_0.y == obj_0.x + 1
    assert int_0 == obj_0.x + 1


# Generated at 2022-06-25 17:17:16.108358
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property('lg\x0c?H\x1c')
    with pytest.raises(AttributeError):
        cached_property_0 = obj_0.__get__(str, '\x0b\x0c"')
    with pytest.raises(AttributeError):
        cached_property_0 = obj_0.__get__(dict, '}[\x02\x07\x06\x06')
    with pytest.raises(AttributeError):
        cached_property_0 = obj_0.__get__(list, 'ol-?\x1f\x1c<', '\x0b\x0c"')

# Generated at 2022-06-25 17:17:28.509033
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def test_0(cached_property_0):
        test_0.cached_property_0 = cached_property_0
        return test_cached_property___get__.cached_property_0

    test_cached_property___get__.cached_property_0 = test_0
    test_cached_property___get__.cached_property_0 = \
        cached_property(test_cached_property___get__.cached_property_0)
    test_cached_property___get__.cached_property_0 = \
        test_cached_property___get__.cached_property_0(test_cached_property___get__.cached_property_0)
    test_cached_property___get__.cached_property_0 = \
        test_cached_property

# Generated at 2022-06-25 17:17:32.841738
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'a\x1d\x19\x16\x0b\x00\x0c\x0ce\x1c\x1e\x1d:'
    cached_property_0 = cached_property(str_0)
    assert not hasattr(__class__, '_TestCachedProperty__test_method_0')
    assert not hasattr(__class__, '_TestCachedProperty__test_method_1')
    assert not hasattr(__class__, '_TestCachedProperty__test_method_2')
    assert not hasattr(__class__, '_TestCachedProperty__test_method_3')
    assert not hasattr(__class__, '_TestCachedProperty__test_method_4')

# Generated at 2022-06-25 17:17:36.327915
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()

    assert obj.y == 6
    assert obj.y == 6

# Generated at 2022-06-25 17:19:23.383505
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:19:29.185243
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Call method
    # Argument str_0
    str_0 = ':;,\\7\x0b,'
    # Argument cls
    cls = 0
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(str_0, cls)
    pass


# Generated at 2022-06-25 17:19:31.364977
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert None is cached_property_0.__get__()


# Generated at 2022-06-25 17:19:33.639807
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = 0
    cached_property_0 = cached_property(5)
    assert 0 == cached_property_0.__get__(None, int_0)


# Generated at 2022-06-25 17:19:41.555536
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj0 = cached_property(cached_property(None))
    func1 = lambda o: o
    obj2 = func1(obj0)
    str0 = '~'
    func3 = lambda o: str0
    str1 = '\t'
    str2 = '123456789abcdef'
    str3 = str1 + str2
    obj2 = func3(obj2)
    str0 = obj2
    func4 = lambda o: len
    obj0 = func4(obj0)
    obj0 = obj0(str0)
    str1 = '!@#$%^&*()_+'
    str5 = '0123456789'
    str3 = str1 + str5
    obj0 = obj0 + len(str3)


# Generated at 2022-06-25 17:19:47.457137
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'w'
    str_1 = '}'
    str_2 = 'q'
    bool_0 = bool('u')
    class Class_0:
        def __init__(self):
            self.attr_0 = ':;,\\7\x0b,'

        @cached_property
        def method_0(self):
            return self.attr_0 + '|'

    Class_0_0 = Class_0()
    Class_0_0.method_0
    Class_0_0.method_0
    Class_0_0.method_0
    Class_0_0.method_0
    Class_0_0.method_0
    Class_0_0.method_0
    Class_0_0.method_0
    Class_0_0.method_0

# Generated at 2022-06-25 17:19:55.484261
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Argument 1: cached_property_1
    # Argument 2: iscoroutinefunction_0
    # Argument 3: str_1
    # Method __get__
    # Unit test for method __get__ of class cached_property
    # Create instance of class cached_property
    # Unit test for method __init__ of class cached_property
    # Create instance of class cached_property
    # Argument 0: str_2
    # Method __init__
    # Unit test for method __init__ of class cached_property
    # Create instance of class cached_property
    # Argument 0: str_3
    # Method __init__
    str_0 = 'x'
    cached_property_0 = cached_property(str_0)
    str_1 = 'x'
    cached_property_1 = cached_property(str_1)
    str_

# Generated at 2022-06-25 17:20:06.899712
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '9'
    str_1 = '1'
    str_2 = '5'
    str_3 = '8'
    str_4 = '5'
    str_5 = '3'
    str_6 = '\\ '
    str_7 = '\\O'
    str_8 = '\\E'
    str_9 = '\\7'
    str_10 = '\\Q'
    str_11 = '\\g'
    str_12 = ',-'
    str_13 = '?;'
    str_14 = '?l'
    str_15 = '1'
    str_16 = '3'
    str_17 = ':'
    str_18 = '\\L'
    str_19 = '\\U'
    str_20 = '\\7'
   

# Generated at 2022-06-25 17:20:14.438706
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    with pytest.raises(Exception):
        if any([
                    1 < 0,
                    1 > 0
        ]):
            raise Exception('AssertionError')
        else:
            try:
                str_0 = 'C\\\x16\x03\\\r'
                cached_property_0 = cached_property(str_0)
            except:
                pass

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-25 17:20:16.098593
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    res = cached_property_0.__get__(None, str_0)
    assert res == str_0
