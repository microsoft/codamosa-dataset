

# Generated at 2022-06-25 17:10:34.506491
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)

    try:
        cached_property_0.__get__(None, None)
    except TypeError:
        assert False
        return

    assert True


# Generated at 2022-06-25 17:10:38.666668
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # unit test
    # test with unit test object
    class Test:
        @cached_property
        def x(self):
            return 1
    obj = Test()
    assert obj.x



# Generated at 2022-06-25 17:10:41.894999
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    class_0 = None
    var_0 = cached_property_0.__get__(class_0,class_0.__class__)

# Generated at 2022-06-25 17:10:48.289016
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        assert test_case_0() == None
    except Exception:
        raise Exception("Failed: %s %s" % (test_case_0, "Exception thrown"))



# Generated at 2022-06-25 17:10:53.553319
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj = None
    cls = None
    # ValueError: _MyClass__x is not defined
    # assertEqual(cached_property_0.__get__(obj, cls), RET_VAL)


# Generated at 2022-06-25 17:10:58.078918
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test for method __get__ (line 51)
    cached_property_0 = cached_property(float)


# Generated at 2022-06-25 17:11:00.071011
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__()



# Generated at 2022-06-25 17:11:10.602046
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    byte_0 = 0
    byte_1 = 2
    byte_2 = 3
    byte_3 = 4
    byte_4 = 9
    byte_5 = 1
    byte_6 = 5
    byte_7 = 6
    byte_8 = 8
    byte_9 = 7
    bytes_0 = bytes([byte_0, byte_1, byte_2, byte_3, byte_4, byte_5, byte_6, byte_7, byte_8, byte_9])
    int_0 = int.from_bytes(bytes_0, byteorder='little', signed=False)
    assert int_0 == 523140128

# Generated at 2022-06-25 17:11:11.605233
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:11:17.550473
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    str_0 = cached_property_0.__get__(cached_property_0, cached_property_0)
    str_1 = cached_property_0.__get__(cached_property_0, cached_property_0)



# Generated at 2022-06-25 17:11:23.934769
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass_0:
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1
    obj = MyClass_0()
    assert obj.y == 6


# Generated at 2022-06-25 17:11:28.334433
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    myclass_0 = MyClass_0()
    float_0 = myclass_0.y
    assert float_0 == 6.0


# Generated at 2022-06-25 17:11:29.368274
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # TODO
    pass


# Generated at 2022-06-25 17:11:38.849633
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__(float_0)
    cached_property_0.__setattr__(float_0, True)
    cached_property_0.__get__(float_0)
    cached_property_0.__setattr__(float_0, True)
    cached_property_0.__get__(float_0)


# Generated at 2022-06-25 17:11:48.614934
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)

    @cached_property  # Type hint: (ApplyTypeResult[CannotAssignToCallable[cached_property]],) -> cached_property
    def func(obj: Any):
        pass

    func.__doc__ = "kwargs: Any\\\\n\\n    Returns:\\n        NoneType: None"
    cls = type
    obj = None
    var_0 = str  # Type hint: (type,) -> type
    var_1 = type  # Type hint: (type,) -> type
    cached_property_0 = cached_property(var_1)


# Generated at 2022-06-25 17:11:52.251047
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    instance_0 = None
    class_0 = None
    cached_property_0.__get__(instance_0, class_0)


# Generated at 2022-06-25 17:12:04.776471
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_obj = test_case_0()
    # Test for method __get__ of class cached_property
    obj_0 = test_case_0()
    cls_0 = test_case_0()
    float_0 = cached_property_obj.__get__(obj_0, cls_0)
    # Test for method __get__ of class cached_property
    obj_0 = test_case_0()
    cls_0 = test_case_0()
    float_0 = cached_property_obj.__get__(obj_0, cls_0)
    # Test for method __get__ of class cached_property
    obj_0 = test_case_0()
    cls_0 = test_case_0()

# Generated at 2022-06-25 17:12:05.611128
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:12:11.937790
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj_0 = None
    cls_0 = None
    cached_property_1 = cached_property_0.__get__(obj_0, cls_0)


# Generated at 2022-06-25 17:12:22.004588
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import patch

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    target = obj.y

    with patch.object(
        MyClass, 'y', return_value=obj.y + 1
    ), pytest.warns(None):
        assert obj.y == target + 1



# Generated at 2022-06-25 17:12:31.977057
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    int_0 = 0
    int_1 = 0
    x_0 = cached_property_0.__get__(int_0, int_1)


# Generated at 2022-06-25 17:12:33.762959
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)


# Generated at 2022-06-25 17:12:38.345292
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test cached_property  __get__ method
    """
    float_0 = None
    def func():
        pass
    cached_property_0 = cached_property(func)
    obj = None
    cached_property_0.__get__(obj, float_0)

# Generated at 2022-06-25 17:12:46.199366
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class_0 = test_cached_property___get__.class_0
    obj_0 = class_0()
    obj_1 = class_0()
    cached_property_0 = test_cached_property___get__.cached_property_0
    int_0 = obj_1.y
    int_1 = obj_0.y
    assert (int_1 == 6)
    assert (int_0 == 6)
    int_2 = obj_0.y
    int_3 = obj_1.y
    assert (int_2 == 6)
    assert (int_3 == 6)
    assert (cached_property_0 == cached_property_0)
    assert (cached_property_0 is cached_property_0)
    int_4 = obj_1.y
    int_5 = obj_

# Generated at 2022-06-25 17:12:53.073516
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    cached_property_0.__dict__['func'] = float_0
    cached_property_0.__dict__['__doc__'] = float_0
    obj = None
    assert(cached_property_0.__get__(obj, None) == cached_property_0)


# Generated at 2022-06-25 17:12:58.842829
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class71:
        def __init__(self):
            self.obj57 = None

        def function56(self):
            self.obj57 = None
            return self.obj57
    class_0 = Class71()
    cached_property_0 = cached_property(class_0.function56)
    assert isinstance(cached_property_0.__get__(class_0, Class71), cached_property)


# Generated at 2022-06-25 17:13:09.398228
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Define a class named 'CachedPropertyClass0'
    class CachedPropertyClass0():
        # Define a method named '__init__' of class 'CachedPropertyClass0'
        def __init__(self):
            # Assign a value to 'self.x'
            self.x = 5

        # Define a method named 'y' of class 'CachedPropertyClass0'
        # This method is a decorator
        def y(self):
            # Assign a value to 'self.x'
            self.x = 5

    # Define a class named 'CachedPropertyClass0'

# Generated at 2022-06-25 17:13:15.186519
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    #
    # This is a quick test to make sure that at least the cached_property
    # decorator can be instantiated.
    #
    float_0 = None
    cached_property_0 = cached_property(float_0)


if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-25 17:13:20.600031
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = None
    cached_property_0.__get__()

if __name__ == '__main__':
    import sys
    import nose
    nose.run_exit(argv=[sys.argv[0], "--verbosity=3", "-s", "-x", "--pdb", "--pdb-failure"],
                  defaultTest=sys.argv[0])

# Generated at 2022-06-25 17:13:28.544523
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """
    from flutils.decorators import cached_property
    from flutils.decorators import execute_with_kwargs

    class Class_0:

        def __init__(self):
            self.bool_0 = False

        @cached_property
        def method_0(self):
            self.bool_0 = True
        # ValueError: we expect method __get__()of class 'cached_property' to return
        # an instance of property
        #     assert isinstance(<expr>, <type>)



# Generated at 2022-06-25 17:13:46.114253
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import unittest
    import unittest.mock
    import io
    import builtins
    class dummy_StringIO_0(object):
        def __init__(self):
            self.state = 0

        def __bool__(self):
            return True

        def truncate(self, *args, **kwargs):
            self.state += 1
            return self.state

        def write(self, *args, **kwargs):
            dummy_StringIO_0.write(self, *args, **kwargs)
    obj = dummy_StringIO_0()
    obj.__init__()
    obj.write()
    cache = dict()
    return_value_0 = cached_property(cache)
    return_value_0


# Generated at 2022-06-25 17:13:55.358648
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_2 = None
    cached_property_2 = cached_property(float_2)
    test_cached_property___get__.last_received_args = None
    test_cached_property___get__.last_returned_value = None
    cached_property_2.__get__(1, 2, 3)
    assert test_cached_property___get__.last_received_args == (1, 2, 3)
    assert test_cached_property___get__.last_returned_value is None
    return


# Generated at 2022-06-25 17:14:04.912980
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(None)
    cached_property_0._wrap_in_coroutine(None)
    cached_property_0.__get__(cached_property_0, None)
    # The following line is required for test_case_0
    assert(float_0 is not None)

test_cached_property___get__()

# Generated at 2022-06-25 17:14:07.284745
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestClass:

        def __init__(self):
            self.x = 0

        @cached_property
        def y(self):
            return self.x

    test_class_0 = TestClass()
    assert test_class_0.y is None



# Generated at 2022-06-25 17:14:08.221962
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:14:15.561696
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj_0 = unittest.mock.Mock()
    cls_0 = unittest.mock.Mock()
    # AssertionError: 
    # Expected :wrapper
    # Actual   :<coroutine object cached_property.wrapper at 0x0091F4E0>
    # assert cached_property_0.__get__(obj_0, cls_0) == unittest.mock.Mock()



# Generated at 2022-06-25 17:14:24.458860
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        float_0 = None
        cached_property_0 = cached_property(float_0)
        obj = cached_property_0.__get__(None, None)
        assert obj is cached_property_0
    except:
        assert False
    try:
        float_0 = None
        cached_property_0 = cached_property(float_0)
        obj = cached_property_0.__get__(None, None)
        assert obj is cached_property_0
    except:
        assert False


# Generated at 2022-06-25 17:14:30.950278
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)

    # float_0.__get__(cached_property_0)
    # __get__(self, obj, type_1, /)
    # Overloaded function.
    # 1. __get__(self, obj, type_1) -> object
    # 2. __get__(self, obj, type_1=None) -> object
    # 3. __get__(self, obj, type_1=None) -> object
    # 4. __get__(self, obj, type_1) -> object
    # 5. __get__(self, obj, type_1) -> object



# Generated at 2022-06-25 17:14:39.496154
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import typing
    from functools import partial
    from . import cached_property

    param_0 = typing.Mapping[typing.Any, typing.Any]
    param_0[None] = typing.Mapping[typing.Any, typing.Any]
    cached_property_0 = cached_property.cached_property(partial(lambda param_0=param_0: param_0))
    cached_property_0.__get__()


# Generated at 2022-06-25 17:14:42.553570
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    myclass = MyClass()
    assert myclass.y == 6, 'Attribute did not match expected value'



# Generated at 2022-06-25 17:14:58.489332
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:15:02.201957
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(cached_property)
    cached_property_0.__get__()


# Generated at 2022-06-25 17:15:07.111319
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    # Setup fixture
    cached_property_0 = cached_property()

    # Exercise SUT
    cached_property_0.__get__()



# Generated at 2022-06-25 17:15:15.965858
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # type: () -> None
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj = object()
    cls = object()

    try:
        value = cached_property_0.__get__(obj, cls)
    except Exception:
        value = None

    assert value is None
    assert cached_property_0.func is None
    assert cached_property_0.__doc__ is None

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:15:20.034081
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Unit test for method __get__ of class cached_property
    obj = cached_property(test_case_0)
    # obj.__get__():
    # obj.test_case_0():


# Generated at 2022-06-25 17:15:29.748656
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)

    # Case 1
    class ClassTest:
        def __init__(self):
            self.x = 5

    cached_property_0 = cached_property(self.y)
    property_obj = cached_property_0.__get__(ClassTest, object)

    # Case 2
    class ClassTest:
        def __init__(self):
            self.x = 5

    cached_property_0 = cached_property(self.y)
    property_obj = cached_property_0.__get__(ClassTest, object)
    assert property_obj == 6

# Generated at 2022-06-25 17:15:32.403707
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(float_0)
    cached_property_1 = cached_property_0.__get__(list_0, float_0)


# Generated at 2022-06-25 17:15:33.451464
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:15:42.413095
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # noinspection PyShadowingNames
    def float_0(obj):
        return obj.x

    cached_property_0 = cached_property(float_0)
    class_0 = MyClass(5, 'test_case_0')
    class_0.y
    class_0.y
    class_0.y
    class_0.y
    class_0.y


# Generated at 2022-06-25 17:15:50.111691
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    MyClass_0 = MyClass()
    cached_property_0 = MyClass_0.y
    assert cached_property_0 == 6



# Generated at 2022-06-25 17:16:38.197519
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_cached_property___get__0()
    test_cached_property___get__1()
    test_cached_property___get__2()
    test_cached_property___get__3()
    test_cached_property___get__4()
    test_cached_property___get__5()
    test_cached_property___get__6()
    test_cached_property___get__7()
    test_cached_property___get__8()
    test_cached_property___get__9()
    test_cached_property___get__10()
    test_cached_property___get__11()
    test_cached_property___get__12()
    test_cached_property___get__13()
    test_cached_property___get__14()
    test_c

# Generated at 2022-06-25 17:16:41.980348
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)


# Generated at 2022-06-25 17:16:47.728263
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property()
    # TypeError: __init__() missing 1 required positional argument: 'func'
    # cached_property_0.__get__()
    # TypeError: __get__() missing 1 required positional argument: 'obj'


# Generated at 2022-06-25 17:16:54.065289
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    class_0 = None
    cached_property_0.__get__(class_0)


# Generated at 2022-06-25 17:16:56.280175
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from . import config
    pass

# Generated at 2022-06-25 17:16:58.931885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    class_0 = None
    cached_property_0.__get__(class_0)
    class_1 = MyClass()
    cached_property_0.__get__(class_1)


# Generated at 2022-06-25 17:17:10.047911
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(float)
    cached_property_1 = cached_property(float)
    cached_property_2 = cached_property(float)
    cached_property_3 = cached_property(float)
    cached_property_4 = cached_property(float)
    cached_property_5 = cached_property(float)
    cached_property_6 = cached_property(float)
    cached_property_7 = cached_property(float)
    cached_property_8 = cached_property(float)
    cached_property_9 = cached_property(float)
    cached_property_10 = cached_property(float)
    cached_property_11 = cached_property(float)
    cached_property_12 = cached_property(float)
    cached_property_13 = cached_property(float)
    cached_

# Generated at 2022-06-25 17:17:14.733036
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    str_0 = None
    assert str_0 is cached_property_0.__get__(str_0, str)


# Generated at 2022-06-25 17:17:17.622738
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    cached_property_0


# Generated at 2022-06-25 17:17:18.811178
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:18:52.958961
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    obj = object()
    obj_0 = object()
    cls = type(obj)
    cls_0 = type(obj_0)
    cached_property_0.__get__(obj, cls)
    cached_property_0.__get__(obj_0, cls_0)

# Generated at 2022-06-25 17:18:56.224168
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    # assert cached_property_0.__get__() == None



# Generated at 2022-06-25 17:19:06.609419
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    float_1 = float_0
    float_2 = float_1
    float_3 = float_1
    float_4 = float_1
    float_5 = float_4
    float_6 = float_4
    float_7 = float_6
    float_8 = float_7
    float_9 = float_4
    float_10 = float_4
    float_11 = float_9
    float_12 = float_10
    float_13 = float_12
    float_14 = float_12
    float_15 = float_12
    float_16 = float_12
    float_17 = float_16
    float_18 = float_17
    float_19 = float_17

# Generated at 2022-06-25 17:19:11.576082
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Object0(object):
        def func0(self):
            return 1

    obj0 = Object0()
    obj0.__dict__['func0'] = 1
    cached_property_0 = cached_property(obj0.func0)
    int_0 = cached_property_0.__get__(obj0, Object0)
    assert int_0 == 1



# Generated at 2022-06-25 17:19:19.350149
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    global cached_property_0

    # *** WARNING ***
    # Code manually copied from cached_property
    # *** WARNING ***
    def __init__(self, func):
        self.__doc__ = getattr(func, "__doc__")
        self.func = func

    # *** WARNING ***
    # Code manually copied from cached_property
    # *** WARNING ***
    def __get__(self, obj: Any, cls):
        if obj is None:
            return self

        if asyncio.iscoroutinefunction(self.func):
            return self._wrap_in_coroutine(obj)

        value = obj.__dict__[self.func.__name__] = self.func(obj)
        return value

    # *** WARNING ***
    # Code manually copied from cached_property
    # *** WARNING ***

# Generated at 2022-06-25 17:19:25.240217
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)

    obj = MyClass()
    cached_property_0 = cached_property(obj.y)
    assert cached_property_0.__get__(obj, MyClass) == 6

# Generated at 2022-06-25 17:19:33.434583
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class ICachedProperty0(cached_property):

        def __init__(self, func):
            self.__doc__ = getattr(func, "__doc__")
            self.func = func

        @cached_property
        def cached_property_0(self, cls):
            return self
    # Method test
    cached_property_0 = ICachedProperty0(None)
    obj = cached_property_0
    cls = None
    c = cached_property_0.__get__(obj, cls)


# Generated at 2022-06-25 17:19:37.685990
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = None
    cached_property_0 = cached_property(float_0)
    bool_0 = bool(0)
    method_0 = cached_property_0.__get__(bool_0)


# Generated at 2022-06-25 17:19:41.165685
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # create some objects
    from flutils.dataclasses import FrozenInstance

    class MyClass(FrozenInstance):
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-25 17:19:46.625440
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    cached_property_0 = cached_property(float_0)
    cached_property___get___retval_0 = cached_property_0.__get__(None, object())
    """

