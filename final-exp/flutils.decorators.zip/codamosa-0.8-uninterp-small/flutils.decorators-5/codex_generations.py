

# Generated at 2022-06-25 17:10:38.157266
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class :obj:`~flutils.decorators.cached_property`"""
    from flutils.decorators import cached_property

    class TestClass:

        @cached_property
        def test_func(self):
            return 'hello, world!'

    test_obj = TestClass()
    assert test_obj.test_func == 'hello, world!'


# Generated at 2022-06-25 17:10:45.579301
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property('pre_num')
    class_0 = cached_property('pre_num')
    code_obj_0 = cached_property('pre_num')
    str_0 = 'pre_num'
    str_1 = '%c'
    str_2 = 'pre_num'
    str_3 = 'pre_num'
    function_0 = cached_property('pre_num')
    function_1 = cached_property('pre_num')
    function_2 = cached_property('pre_num')
    function_3 = cached_property('pre_num')
    function_4 = cached_property('pre_num')
    attr_0 = cached_property('pre_num')
    int_0 = 5
    str_4 = 'pre_num'
    int_1 = 6
    int

# Generated at 2022-06-25 17:10:54.355048
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # print('\n')
    # print('Unit test for:')
    # print('method __get__ of class cached_property')
    # print('\n')
    # print('Testing:')
    # print('    if obj is None:')
    # print('        return self')
    # print('\n')
    # print('Expected:')
    # print('    None')
    # print('\n')
    # print('Result:')
    # print('    {}'.format(cached_property_0.__get__(None, None)))

    assert cached_property_0.__get__(None, None) is None

# Generated at 2022-06-25 17:10:56.371678
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # TODO
    raise NotImplementedError()


# Generated at 2022-06-25 17:11:02.958946
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    try:
        val_0 = cached_property(None)
        val_1 = val_0.__get__(None, lambda: None)
        val_0.__class__.__get__(val_0, None, lambda: None)
    except:
        pass
    try:
        str_0 = 'pre_num'
        cached_property_0 = cached_property(str_0)
        val_2 = cached_property_0.__get__(None, lambda: None)
    except:
        pass

# Testing class cached_property
if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:11:08.872023
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestClass()
    assert obj.y == 6


# Generated at 2022-06-25 17:11:11.443740
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    int_0 = cached_property_0(int)


# Generated at 2022-06-25 17:11:16.892302
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    obj_0 = cached_property(str_0)
    cls_0 = cached_property(str_0)
    cached_property_0.__get__(obj_0, cls_0)

# Generated at 2022-06-25 17:11:20.010827
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Unit test for method __get__ of class cached_property
    test_case_0()


# Generated at 2022-06-25 17:11:26.874466
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test method __get__ of class cached_property with the following parameters:

      cached_property.__get__(None, None)

    Known exception from this code is not tested.
    """
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)

    # Test for known failure of cached_property.__get__
    cached_property_0.__get__(None, None)


# Generated at 2022-06-25 17:11:33.831871
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    var_0 = cached_property(test_case_0)
    try:
        var_0.__get__(1, 1)
    except NotImplementedError:
        print('expected exception')


# Generated at 2022-06-25 17:11:35.011206
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 17:11:38.081450
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property()
    cls = NotImplementedError()

    # Call method with arguments
    result = obj.__get__(obj, cls)

    # Verify results
    assert result is NotImplementedError()


# Generated at 2022-06-25 17:11:44.894877
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property_test_data
    try:
        assert var_0 == 0
    except NameError:
        test_case_0()
    obj_0 = cached_property_test_data.MyClass()
    with pytest.raises(NotImplementedError):
        cached_property___get__(obj_0)


# Generated at 2022-06-25 17:11:46.842976
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    new_cached_property = cached_property('x')
    assert(new_cached_property.__get__() == None)


# Generated at 2022-06-25 17:11:50.617759
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 17:11:52.454128
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test with input NotImplementedError, NotImplementedError
    test_case_0()

# Generated at 2022-06-25 17:11:55.084124
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:12:00.656444
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(test_case_0)
    obj_1 = obj_0.__get__(NotImplementedError(), NotImplementedError)
    # Test for not iscoroutinefunction
    assert isinstance(obj_1, NotImplementedError)


# Generated at 2022-06-25 17:12:01.955880
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = test_case_0()
    assert obj.__get__() == NotImplementedError()

# Generated at 2022-06-25 17:12:05.250844
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 17:12:17.450917
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import sys
    import types
    import unittest
    from flutils.decorators import cached_property

    class TestCachedProperty___get__(unittest.TestCase):

        # Class method to create an instance of the class to be tested.
        @classmethod
        def setUpClass(cls):
            try:
                cls.test_object = cached_property(None)
            except:
                cls.test_object = None

        def setUp(self):
            pass

        def test_cached_property___get___instance(self):
            self.assertIsNotNone(self.test_object)


# Generated at 2022-06-25 17:12:20.831815
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        test_case_0()
    except:
        self.fail("The test case 0 failed.")

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-25 17:12:23.069184
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    var_0 = test_case_0()

# Class obj_0 is a mock that is used to test the method __get__ of
# class cached_property

# Generated at 2022-06-25 17:12:25.361849
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    pass


# Generated at 2022-06-25 17:12:26.923322
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    var_0 = NotImplementedError()


# Generated at 2022-06-25 17:12:28.921155
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    var_0 = test_case_0()
    assert var_0 is NotImplementedError

# Generated at 2022-06-25 17:12:36.878056
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def test_case_0():
        pass

    def test_case_1():
        pass

    def test_case_2():
        pass

    def test_case_3():
        pass

    def test_case_4():
        pass

    def test_case_5():
        pass

    def test_case_6():
        pass



# Generated at 2022-06-25 17:12:42.601793
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    var_0 = cached_property(test_case_0)
    var_1 = var_0.__get__(None, None)


# Generated at 2022-06-25 17:12:49.277719
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(lambda: NotImplementedError())
    var_0 = obj_0.__get__(None, None)
    var_1 = obj_0.__get__(NotImplementedError(), None)
    var_2 = obj_0.__get__(None, NotImplementedError())
    var_3 = obj_0.__get__(NotImplementedError(), NotImplementedError())
    return ((var_0, var_1, var_2, var_3),)


# Generated at 2022-06-25 17:12:55.168216
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property
    """
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    arg_0 = 'pre_num'
    cached_property_0.__get__(arg_0, None)

# Generated at 2022-06-25 17:13:01.609067
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the class cached_property, method __get__"""
    from test.support import get_attribute
    from functools import _make_key

    class TestClass:

        def __init__(self, x, y):
            self.x = x
            self.y = y

        @cached_property
        def foo(self):
            """The foo property."""
            return self.x + self.y

    test_obj = TestClass(5, 6)
    test_obj.foo
    cached_property_0 = get_attribute(test_obj, 'foo')
    test_str_0 = cached_property_0.__doc__
    test_str_1 = 'The foo property.'
    assert test_str_0 == test_str_1
    assert test_obj.x == 5
    assert test_obj

# Generated at 2022-06-25 17:13:11.655319
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:13:19.758966
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Test cached_property.__get__()
    """
    try:
        # Setup
        from flutils.decorators import cached_property

        # Exercise
        str_0 = 'pre_num'
        cached_property_0 = cached_property(str_0)

        # Verify
        assert isinstance(cached_property_0, cached_property)
        assert cached_property_0.func == str_0
        assert isinstance(cached_property_0.__doc__, str)

    except Exception as e:
        print("Exception: {}".format(e))
        assert False
    else:
        assert True



# Generated at 2022-06-25 17:13:21.441077
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    assert 0

# Generated at 2022-06-25 17:13:26.319555
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    obj = None
    cached_property_0.__get__(obj, object)
    cls = object
    cached_property_0.__get__(None, cls)


# Generated at 2022-06-25 17:13:30.510597
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()



# Generated at 2022-06-25 17:13:36.480025
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = None
    cls = None
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    # AssertionError: None
    test_case_1()
    test_case_0()


# Generated at 2022-06-25 17:13:40.122920
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:13:45.527529
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)

# Generated at 2022-06-25 17:13:51.826970
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property('pre_num')
    obj.__get__('self','func')


# Generated at 2022-06-25 17:13:59.476739
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase
    from random import randint
    from unittest.mock import patch, MagicMock
    import asyncio
    from typing import Any

# Set up mock object for cached_property
    cached_property_0 = MagicMock(cached_property)
    cached_property_0.func = MagicMock(str)

# Set up mock object for object
    object_0 = MagicMock(object)
    object_0.__dict__ = MagicMock(dict)
    object_0.__dict__.__setitem__ = MagicMock(None)
    object_0.__dict__.__getitem__ = MagicMock(int)
# Set up mock object for asyncio.ensure_future
    asyncio.ensure_future = MagicMock(asyncio.Future)


# Generated at 2022-06-25 17:14:06.270651
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class class_0:

        def __init__(self):
            self.str_0 = 'str_0'

        @cached_property
        def str_1(self):
            return self.str_0 + 'str_1'

    class_0 = class_0()
    var_0 = class_0.str_1
    assert var_0 == 'str_0str_1'


# Generated at 2022-06-25 17:14:15.887248
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    # Testing __get__
    #  self.__doc__ = getattr(func, "__doc__")
    #  self.func = func
    #  if obj is None:
    #  if asyncio.iscoroutinefunction(self.func):
    #  value = obj.__dict__[self.func.__name__] = self.func(obj)
    #  return value
    #  @asyncio.coroutine
    #  future = asyncio.ensure_future(self.func(obj))
    #  obj.__dict__[self.func.__name__] = future
    #  return future

    #
if __name__ == '__main__':
    test_case_0

# Generated at 2022-06-25 17:14:20.282249
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    # Testing code
    cached_property_0 = cached_property(str_0)
    try:
        assert (cached_property_0.__get__ is cached_property_0.__get__)
    except AssertionError:
        raise AssertionError('assert #1 of test_cached_property___get__ failed')
    try:
        assert (cached_property_0.__get__ is cached_property_0.__get__)
    except AssertionError:
        raise AssertionError('assert #2 of test_cached_property___get__ failed')


# Generated at 2022-06-25 17:14:22.569937
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:14:30.500669
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'K'
    # cached_property_0 = cached_property(str_0)
    cached_property_0 = cached_property(lambda: str_0)

    assert cached_property_0 is cached_property
    # assert cached_property_0.__doc__ is not None
    assert cached_property_0.__doc__ is None
    assert cached_property_0.func is str_0
    # assert cached_property_0.__get__(None, None) is cached_property
    assert cached_property_0.__get__(None, None) is not cached_property
    assert cached_property_0.__get__(None, None)() is str_0
    with pytest.raises(TypeError):
        assert cached_property_0.__get__(None)

# Generated at 2022-06-25 17:14:42.009814
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    obj_0 = 'str'
    cls_0 = 'str'
    cached_property_0.__get__(obj_0, cls_0)
    obj_0 = 'str'
    cls_0 = 'str'
    cached_property_0.__get__(obj_0, cls_0)
    obj_0 = 'str'
    cls_0 = cached_property
    cached_property_0.__get__(obj_0, cls_0)
    obj_0 = 'str'
    cls_0 = cached_property
    cached_property_0.__get__(obj_0, cls_0)


# Generated at 2022-06-25 17:14:51.393257
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    myclass_0 = MyClass()
    assert str_0 == cached_property_0.func
    assert myclass_0.x == __instance__.x
    assert myclass_0.y == __instance__.y
    myclass_0.x = -5
    assert myclass_0.y == __instance__.y
    myclass_0.y = -5
    assert myclass_0.y == __instance__.y
    assert myclass_0.x == __instance__.x
# Setup to test method __get__ of class cached_property

# Generated at 2022-06-25 17:14:52.668229
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:15:05.000861
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)

# Generated at 2022-06-25 17:15:11.760395
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test the `__get__ <https://bit.ly/2PX9f95>`__ method of
    :class:`~flutils.decorators.cached_property`.

    """

    # noinspection PyUnresolvedReferences
    import typing

    class TestClass0:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    test_case_0 = TestClass0()

    assert test_case_0.y == 6
    assert test_case_0.__class__.__dict__['y'].__class__ == cached_property
    assert isinstance(test_case_0.__dict__['y'], int)

    test_case_0.x = 10

    assert test_case_0

# Generated at 2022-06-25 17:15:12.614244
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:15:17.884354
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

	# Assign function_0 to cached property cp_0
	cp_0 = test_case_0()

	# Assign __doc__ of cp_0 to str_0
	str_0 = cp_0.__get__

	# Assign __doc__ of cp_0 to str_0
	str_1 = cp_0.__get__

	# Assign __doc__ of cp_0 to str_0
	str_2 = cp_0.__get__

# Generated at 2022-06-25 17:15:19.886003
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:15:30.583450
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # AssertionError
    # Unit test for method __init__ of class cached_property
    from flutils.decorators import cached_property
    from nose.tools import raises
    from pprint import pprint

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    # obj.y
    # 6
    cached_property_0 = cached_property(y)
    func_0 = cached_property_0.__get__
    cls_0 = func_0()
    pprint(cls_0)
    # AssertionError
    # Unit test for method __init__ of class cached_property

# Generated at 2022-06-25 17:15:32.993257
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property
    cls = integer
    cached_property_0.__get__(cls)


# Generated at 2022-06-25 17:15:42.039935
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    str_1 = 'post_num'
    str_2 = 'func'
    str_3 = 'y'
    str_4 = 'valu_e'
    str_5 = '_acached_property__wrap_in_coroutine'
    str_6 = 'valu_e'
    str_7 = 'acached_property_func'
    str_8 = 'acached_property_func'
    str_9 = 'wrapper'
    str_10 = 'wrapper'
    str_11 = 'wrapper'
    num_0 = -0.25
    num_1 = 2.1
    num_2 = 0.75
    num_3 = 5.4
    num_4 = 0.15
    num_5 = 4.8

# Generated at 2022-06-25 17:15:43.453717
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test cached_property.__get__(obj: Any, cls)"""

    test_case_0()


# Generated at 2022-06-25 17:15:52.613336
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    num_0 = 0
    num_1 = 1
    num_2 = 2
    num_3 = 3
    num_4 = 4
    num_5 = 5
    num_6 = 6
    str_0 = 'method_0'
    str_1 = 'method_1'
    str_2 = 'method_2'
    str_3 = 'method_3'
    str_4 = 'method_4'
    str_5 = 'method_5'
    str_6 = 'method_6'
    str_7 = 'method_7'
    str_8 = 'method_8'
    str_9 = 'method_9'
    str_10 = 'method_10'
    str_11 = 'class_0'
    str_12 = 'class_1'

# Generated at 2022-06-25 17:16:25.512923
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'i_0'
    int_0 = 1500
    instance_0 = str_0[:int_0]
    class_0 = type(instance_0)
    method_0 = cached_property_0.__get__(class_0)


# Generated at 2022-06-25 17:16:31.431455
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = None
    cls_0 = None
    test_case_0()
    test_value_0 = cache_test_property.__get__(obj_0, cls_0)


# Generated at 2022-06-25 17:16:33.988789
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__()


# Generated at 2022-06-25 17:16:37.632240
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6



# Generated at 2022-06-25 17:16:43.394067
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    obj_0 = str_0
    assert cached_property_0.__get__(obj_0, str_0) == 'pre_num'


# Generated at 2022-06-25 17:16:45.654644
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    raise NotImplementedError()


# Generated at 2022-06-25 17:16:51.524206
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class ClassTest:
        '''
        class to test cached_property
        '''

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x

# test __get__
    class_test = ClassTest()
    assert class_test.y == 5
    class_test.x = 6
    assert class_test.y == 5



# Generated at 2022-06-25 17:16:57.880522
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def func_0(obj):
        return 5

    cls_0 = cached_property(func_0)
    str_0 = cls_0.__get__(None, None)
    str_1 = cls_0.__doc__


# Generated at 2022-06-25 17:17:02.145750
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    str_0 = 'num'
    int_0 = 0
    cached_property_0 = cached_property(str_0)
    cached_property_0 = cached_property_0.__get__(int_0, (int_0))


# Generated at 2022-06-25 17:17:11.638119
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict(a=1, b=2, c=3)
    dict_3 = dict(a=1, b=2, c=3)
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict(a=1, b=2, c=3, d=4)
    dict_9 = dict(a=1, b=2, c=3, d=4)
    dict_10 = dict()
    dict_11 = dict(a=1, b=2, c=3, d=4, e=5)


# Generated at 2022-06-25 17:18:22.100573
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__()



# Generated at 2022-06-25 17:18:29.451190
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    str_0 = 'func_0'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(None, None)


# Generated at 2022-06-25 17:18:36.889521
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    obj_0 = Dummy()
    cls_0 = Dummy()
    obj_0.__dict__[str_0] = classmethod
    assert cached_property_0.__get__(obj_0, cls_0) is classmethod


# Generated at 2022-06-25 17:18:40.635614
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)



# Generated at 2022-06-25 17:18:44.957539
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    class_0 = MyClass_0()
    assert_raises(AttributeError, getattr, class_0, str_0)



# Generated at 2022-06-25 17:18:51.183748
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Make sure this class can be dill serialized
    # This will fail if the cached_property class doesn't define __reduce__
    #  https://github.com/cloudpipe/cloudpickle/issues/293
    #  https://stackoverflow.com/a/44048429
    dill.dump(A(), open('./pickle.dill', 'wb'))
    os.remove('./pickle.dill')
    test_case_0()


# Generated at 2022-06-25 17:18:53.463449
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'post_num'
    cached_property_1 = cached_property(str_0)
    cached_property_1.__get__(None, None)


# Generated at 2022-06-25 17:19:02.392507
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    times_called = 0
    times_called_1 = 0


    class Test0:

        def __init__(self, x):
            self.x = x

        def __repr__(self):
            nonlocal times_called
            times_called += 1
            return f'Test0({self.x})'


    class Test1:
        @cached_property
        def test0(self):
            return Test0(42)

    t0 = Test0(0)
    t1 = Test1()

    assert t0.x == 0
    assert t0 == t1.test0
    assert times_called == 1
    assert t1.test0 == t1.test0

    # test decorator is per instance:
    t2 = Test1()
    assert t2.test0 == t1.test0

# Generated at 2022-06-25 17:19:06.478965
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)
    obj = object()
    cls = type(obj)
    result = cached_property_0.__get__(obj, cls)
    # Verify that result is the expected value
    assert (result is None)


# Generated at 2022-06-25 17:19:09.085582
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'pre_num'
    cached_property_0 = cached_property(str_0)

    pass
