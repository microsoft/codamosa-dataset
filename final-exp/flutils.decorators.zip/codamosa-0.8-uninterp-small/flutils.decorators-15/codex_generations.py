

# Generated at 2022-06-25 17:10:39.956798
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass(object):

        def __init__(self):
            pass

        @cached_property
        def y(self):
            return self.x + 1

    my_instance = MyClass()
    # Case 1:
    # __get__(self, obj, cls) -> value
    # cls must be None
    assert my_instance.x == 5
    assert my_instance.y == 6



# Generated at 2022-06-25 17:10:41.949268
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()



# Generated at 2022-06-25 17:10:47.154996
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)



# Generated at 2022-06-25 17:10:50.075975
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    global test_case_0

    test_case_0()


# Generated at 2022-06-25 17:10:53.205970
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    print(cached_property_0.__get__())

if __name__ == '__main__':

    print('*** Testing flutils.decorators.cached_property')
    import flutils.decorators
    test_cached_property___get__()

# Generated at 2022-06-25 17:10:54.410806
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(str)
    cached_property_0()


# Generated at 2022-06-25 17:11:00.982933
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj = None
    cls = None
    expected = 0
    actual = cached_property_0.__get__(obj, cls)
    assert expected == actual


# Generated at 2022-06-25 17:11:11.046047
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    #  Create an instance of the class.
    #  Call the method cached_property.__get__(obj, cls)
    #     with the parameters,
    #          obj - an instance of the class
    #          cls - the class itself
    #  Make sure that the function runs without error.

    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    cached_property_0 = cached_property(obj.y)
    tr = cached_property_0.__get__(obj, MyClass)
    assert tr

# Generated at 2022-06-25 17:11:13.282268
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-25 17:11:15.048239
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property()
    # This method is not implemented
    pass


# Generated at 2022-06-25 17:11:20.075446
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(lambda: None)
    cached_property_0.obj = cached_property(lambda: None)
    cached_property_0.cls = None
    assert cached_property_0.__get__() is None


# Generated at 2022-06-25 17:11:29.305024
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property()
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)
    obj_0.__get__(obj_0, str)

# Generated at 2022-06-25 17:11:34.331135
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test case for method __get__"""
    # non_existing_instance = missing_method(cached_property())
    # assert cached_property().__get__(non_existing_instance, non_existing_instance) == expected

# Generated at 2022-06-25 17:11:42.823715
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property()
    # Method __get__ of class cached_property accepts the following parameters:
    #   self
    #   obj (type: Any)
    #   cls (type: Any)

    # Note: Start unit test for method __get__ of class cached_property

    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 17:11:43.361425
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:11:44.204918
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:11:46.799525
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Unit test for method __get__ of class cached_property"""
    obj = cached_property()
    cls = None
    result0 = obj.__get__(obj, cls)
    assert result0 is obj



# Generated at 2022-06-25 17:11:51.782168
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property()
    cls = MyClass()
    cached_property_0 = obj_0.__get__(cls, cls)
    return cached_property_0


# Generated at 2022-06-25 17:11:52.732824
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:12:05.105324
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Tests :meth:`~flutils.decorators.cached_property.cached_property.__get__`"""
    def cached_property_0_decorator(func_0):
            return cached_property(func_0)

    class MyClass:
        @cached_property_0_decorator
        def y(self):
            return self.x + 1

    obj_0 = MyClass()
    obj_1 = cached_property_0_decorator(obj_0.y)
    obj_1.__doc__ = "property decorator that is only computed once per instance and then replaces itself with an ordinary attribute"
    assert obj_1.func == obj_0.y
    assert obj_1.__get__(obj_0, MyClass) is obj_0.y

# Generated at 2022-06-25 17:12:10.891787
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Exercise the decorated property
    from flutils.decorators import cached_property

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    obj.y
    assert obj.__dict__["y"] == 6
    # Exercise the decorator
    test_case_0()



# Generated at 2022-06-25 17:12:18.985962
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:12:28.385643
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:

        """Doc string for MyClass"""

        def __init__(self, val: int) -> None:
            self._val = val

        @cached_property
        def cached(self) -> int:
            """Doc string for cached method"""
            return self._val

        @cached_property
        async def async_cached(self) -> int:
            """Doc string for async_cached method"""
            return self._val

    def func(mclass: MyClass) -> int:
        return mclass.cached

    myclass_0 = MyClass(1)
    int_0 = myclass_0.cached
    int_1 = myclass_0.cached
    assert int_0 == int_1
    assert myclass_0.__dict__
    assert int_1 == 1
   

# Generated at 2022-06-25 17:12:41.533448
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Tests if the call to __get__ fails when passed invalid arguments
    try:
        str_0 = None
        cached_property_0 = cached_property(str_0)
        obj_0 = None
        cached_property___get___0 = cached_property_0.__get__(obj_0, )
    except TypeError as raised_exception:
        print('Raised expected TypeError')
    else:
        raise AssertionError('ExpectedTypeError not raised')

    try:
        str_0 = None
        cached_property_0 = cached_property(str_0)
        obj_0 = None
        cached_property___get___0 = cached_property_0.__get__(obj_0, )
    except TypeError as raised_exception:
        print('Raised expected TypeError')

# Generated at 2022-06-25 17:12:47.833847
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    # The str_0 is not callable
    cached_property_0 = cached_property(str_0)
    cached_property___get___0 = cached_property_0.__get__(str_0, str_0)
    return cached_property___get___0


# Generated at 2022-06-25 17:12:52.068476
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    char_0 = '['
    cached_property_0.__get__(char_0, str_0)
    return str_0


# Generated at 2022-06-25 17:12:56.674303
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj = object()
    cls = object()

    # Call method __get__ of class cached_property
    cached_property_0.__get__(obj, cls)


# Generated at 2022-06-25 17:12:59.929409
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__('str_0', None)

# Generated at 2022-06-25 17:13:04.149291
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj_0 = None
    cls_0 = None
    cached_property_1 = cached_property_0.__get__(obj_0, cls_0)
    return

# Generated at 2022-06-25 17:13:08.313822
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj_0 = object()
    cls_0 = object()

    assert cached_property_0.__get__(obj_0, cls_0) is not None

# Generated at 2022-06-25 17:13:19.377078
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None

    # c
    # cdef cached_property cached_property_0 = cached_property(str_0)

    # str_1 = cached_property_0.__get__
    # str_2 = cached_property_0.__get__
    # str_3 = cached_property_0.__get__


# Generated at 2022-06-25 17:13:25.485393
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None

    # test case 0
    try:
        str_0 = cached_property(str_1)
        str_3 = str_0.__get__(str_2, None)
    except Exception as e:
        print('An exception occurred: {l_Exception}'.format(l_Exception=str(e)))


# Generated at 2022-06-25 17:13:26.197502
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:13:35.026485
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    int_0 = None
    cached_property_0.__get__(int_0)


# Generated at 2022-06-25 17:13:42.359440
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass0:

        def __init__(self):
            self.x = 5

        # Usage
        @cached_property
        def y(self):
            return self.x + 1
        
    myClass0 = MyClass0()
    str_0 = cached_property_0.__get__(myClass0, MyClass0)
    str_1 = None
    assert (str_0 == str_1)


# Generated at 2022-06-25 17:13:56.242375
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class cached_property_0:

        def __init__(self, func):
            self.__doc__ = getattr(func, "__doc__")
            self.func = func

        def __get__(self, obj, cls):
            if obj is None:
                return self
            if asyncio.iscoroutinefunction(self.func):
                return self._wrap_in_coroutine(obj)
            value = obj.__dict__[self.func.__name__] = self.func(obj)
            return value

        def _wrap_in_coroutine(self, obj):

            @asyncio.coroutine
            def wrapper():
                future = asyncio.ensure_future(self.func(obj))
                obj.__dict__[self.func.__name__] = future
                return future

            return

# Generated at 2022-06-25 17:13:59.625216
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    int_0 = None
    Any_0 = cached_property_0.__get__(int_0, str_0)


# Generated at 2022-06-25 17:14:12.428610
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from io import StringIO
    from contextlib import redirect_stdout

    class MyClass:

        def __init__(self):
            self.x = 1

        @cached_property
        def y(self):
            self.x += 1
            return self.x

        @cached_property
        def z(self):
            return self.y - 1

    my_obj = MyClass()
    assert my_obj.y == 2
    assert my_obj.z == 1
    my_obj.x = 5
    assert my_obj.y == 2
    assert my_obj.z == 1

    my_obj = MyClass()
    assert my_obj.y == 2
    with redirect_stdout(StringIO()):
        del my_obj.y
    assert my_obj.y == 3
    assert my_

# Generated at 2022-06-25 17:14:20.138834
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    import logging
    import sys
    import unittest

    class TestCachedProperty___get__(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test__get__(self):
            import flutils.decorators
            str_0 = flutils.decorators.cached_property(test_case_0)
            stderr_0 = sys.stderr
            sys.stderr = None
            cached_property_0 = str_0.__get__(test_case_0)

            sys.stderr = stderr_0


if __name__ == "__main__":
    logging.basicConfig(stream=sys.stderr)

# Generated at 2022-06-25 17:14:24.765751
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    try:
        str_0 = None
        with pytest.raises(TypeError):
            cached_property_0 = cached_property(str_0)

    except Exception:
        print('Exception')
        assert False
    else:
        print('No exception')
        assert True

# Generated at 2022-06-25 17:14:34.253681
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    obj = cached_property(str_0)
    obj.__get__(None, None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:14:38.722475
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj_0 = None
    cls_0 = None
    assert cached_property_0.__get__(obj_0, cls_0)


# Generated at 2022-06-25 17:14:44.190984
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    arg_0 = "abcd"

    # Test for method __get__ of class cached_property
    cached_property_0 = cached_property(arg_0)
    assert cached_property_0.__get__(None, None) == cached_property_0
    assert cached_property_0.__get__(1, None) == cached_property_0


# Generated at 2022-06-25 17:14:49.099035
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Make sure it works for subclasses
    class SubClassOfCachedProperty(cached_property):
        pass

    sp = SubClassOfCachedProperty(str)
    assert sp.__get__(None, None) is sp
    assert sp.__get__(1, None) == '1'


# Generated at 2022-06-25 17:14:58.912079
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj_0 = None
    cls_0 = None
    smethod_0 = cached_property_0.__get__(obj_0, cls_0)
    obj_1 = None
    smethod_0 = cached_property_0.__get__(obj_1, cls_0)
    smethod_0 = cached_property_0.__get__(obj_0, cls_0)
    smethod_0 = cached_property_0.__get__(obj_1, cls_0)
    smethod_0 = cached_property_0.__get__(obj_0, cls_0)

# Generated at 2022-06-25 17:15:07.055576
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print("\n# Unit test for method __get__ of class cached_property")

    from math import sqrt

    class A:

        @cached_property
        def constant(self):
            return sqrt(2)

    a = A()
    print("a.constant = {}".format(a.constant))
    print("a.constant = {}".format(a.constant))
    print("a.constant = {}".format(a.constant))



# Generated at 2022-06-25 17:15:12.573960
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test each of these cases.

    obj_0 = None
    cls_0 = None
    cached_property_0 = cached_property(cls_0)
    cached_property_0.__get__(obj_0, cls_0)
    obj_0 = None
    cls_0 = cached_property(cls_0)
    cached_property_0 = cached_property(cls_0)



# Generated at 2022-06-25 17:15:16.472390
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:15:19.833022
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-25 17:15:26.769885
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj = None
    cls = None
    assert isinstance(cached_property_0.__get__(obj, cls), cached_property)


# Generated at 2022-06-25 17:15:42.147400
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_1 = None
    cached_property_3 = cached_property(str_1)
    float_0 = float()
    float_1 = float()
    float_2 = float()

    str_0 = "func"
    cached_property_1 = cached_property(str_0)
    str_2 = "obj"
    cached_property_2 = cached_property_1.__get__(str_2, float_2)

    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = None
    str_8 = None
    str_9 = None
    str_10 = None
    str_11 = None

# Generated at 2022-06-25 17:15:46.557820
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)

test_cached_property___get__()

test_case_0()

# Generated at 2022-06-25 17:15:50.419301
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj = None
    cls = None
    cached_property_0.__get__(obj, cls)


if __name__ == '__main__':
  import doctest
  doctest.testmod()

# EOF

# Generated at 2022-06-25 17:16:01.330275
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Dummy_Class_0(object):
        def __init__(self, dummy_param_0, dummy_param_1):
            self.args_0 = dummy_param_0
            self.args_1 = dummy_param_1

        @cached_property
        def var_0(self):
            return self.args_0 + self.args_1

        @cached_property
        def var_1(self):
            return self.args_0 * self.args_1

    dummy_class_0 = Dummy_Class_0(5, 6)

    if (dummy_class_0.var_0 != 11):
        raise RuntimeError('var_0 not set correctly')

    if (dummy_class_0.var_1 != 30):
        raise RuntimeError('var_1 not set correctly')

   

# Generated at 2022-06-25 17:16:04.896178
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    for i in range(10):
        test_case_0()


# Generated at 2022-06-25 17:16:06.830235
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()



# Generated at 2022-06-25 17:16:13.588901
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class test_cached_property___get___class_0:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = test_cached_property___get___class_0()
    cached_property_0 = test_cached_property___get___class_0.y
    obj.y


# Generated at 2022-06-25 17:16:17.125281
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj = None
    cls = None
    try:
        cached_property.__get__(cached_property_0, obj, cls)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 17:16:27.746377
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = None
    str_8 = None
    str_9 = None
    str_10 = None
    str_11 = None
    str_12 = None
    str_13 = None
    str_14 = None
    str_15 = None
    str_16 = None
    str_17 = None
    str_18 = None
    str_19 = None
    str_20 = None
    str_21 = None
    str_22 = None
    str_23 = None
    str_24 = None
    str_25 = None
   

# Generated at 2022-06-25 17:16:30.839254
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(None)
    assert True


# Generated at 2022-06-25 17:16:50.748710
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj_0 = None
    cls_0 = None
    test_cached_property___get__0 = cached_property_0.__get__(obj_0, cls_0)


# Generated at 2022-06-25 17:16:51.523983
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:16:53.099547
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


if __name__ == '__main__':
    # Run test cases
    test_cached_property___get__()


# EOF

# Generated at 2022-06-25 17:16:57.894191
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(cached_property)
    cached_property_0.__get__(cached_property, cached_property)


# Generated at 2022-06-25 17:17:02.965141
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_1 = cached_property(str_0) #TODO: Complete this line
    cached_property_0 = cached_property(str_0) #TODO: Complete this line
    str_1 = None
    str_2 = None
    str_3 = None


# Generated at 2022-06-25 17:17:07.122556
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)

    class_0 = None
    cached_property_0.__get__(class_0, class_0)

# Generated at 2022-06-25 17:17:11.956361
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from builtins import TypeError
    from flutils.decorators import cached_property
    from flutils.decorators import cached_property
    from typing import Any
    obj = cached_property_0 = cached_property(str_0)
    cls = str_0
    expected = str_0
    actual = cached_property_0.__get__(obj, cls)
    assert actual == expected
    actual = cached_property_0.__get__(obj, cls)
    assert actual == expected


# Generated at 2022-06-25 17:17:15.947065
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(None)
    with pytest.raises(TypeError, match="'cached_property' object is not callable"):
        cached_property_0()


# Generated at 2022-06-25 17:17:28.460959
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:17:37.142719
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    str_1 = None
    int_0 = 0
    int_1 = 0
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    str_2 = None
    str_3 = None
    str_4 = None

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    y = obj.y

    assert y == 6


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(__file__)
   

# Generated at 2022-06-25 17:18:31.693989
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    cached_property_0 = cached_property(obj.y)
    assert cached_property_0.__get__(obj, MyClass) == 6


# Generated at 2022-06-25 17:18:37.837146
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    cached_property_0 = cached_property(bool_0)
    int_0 = 0
    int_1 = 1
    assert isinstance(cached_property_0.__get__(int_0, int_1), bool)


# Generated at 2022-06-25 17:18:39.909311
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:18:46.109224
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    obj_0 = cached_property_0.__get__(cached_property_0, cached_property)
    try:
        assert obj_0 is cached_property_0
    except AssertionError:
        raise AssertionError


if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:18:49.707757
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert cached_property_0.__get__(str_0, cls) is None
    assert cached_property_0.__get__(str_0, cls) is None


# Generated at 2022-06-25 17:18:56.100848
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = None
    cached_property_0 = cached_property(str_0)
    assert not hasattr(cached_property_0, 'x')


# Generated at 2022-06-25 17:18:58.183809
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:19:11.359265
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from typing import cast
    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj_0 = MyClass()
    cached_property_0 = cast(cached_property.DescriptorType, cached_property(obj_0.y))
    int_0 = cached_property_0.__get__(obj_0, 0)
    assert int_0 == 6

if __name__ == '__main__':
    # test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:19:19.226328
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    import io
    import sys
    import unittest
    import textwrap


    L0 = [
        '[',
        '    \'__init__\',',
        '    \'__delattr__\',',
        ']',
    ]
    str_0 = '\n'.join(L0)
    str_1 = '\n'

# Generated at 2022-06-25 17:19:24.364260
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(test_case_0)
    cached_property_0.__get__('', '', None)
