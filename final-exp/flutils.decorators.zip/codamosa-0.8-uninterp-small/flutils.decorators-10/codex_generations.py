

# Generated at 2022-06-25 17:10:37.689552
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)


# Generated at 2022-06-25 17:10:44.092833
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class Class_1:

        def __init__(self):
            self.dict_0 = {}

        @cached_property
        @asyncio.coroutine
        def coroutine_func(self):
            return 'coroutine func'

        @cached_property
        def func(self):
            return 'func'

    class_0 = Class_1()
    assert class_0.coroutine_func == 'coroutine func'
    assert class_0.func == 'func'
    assert class_0.dict_0 == {'coroutine_func': 'coroutine func', 'func': 'func'}

# Generated at 2022-06-25 17:10:54.798327
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:10:59.239907
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    real_0 = test_case_0()
    assert real_0 == None , 'expected: %f, got: %f' % (None, real_0)


# Generated at 2022-06-25 17:11:06.470134
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -902.823
    cached_property_0 = cached_property(float_0)

    # Test plan of cached_property.__get__
    # TODO: Start at line 19
    # TODO: End at line 48
    pass


if __name__ == "__main__":
    import doctest
    import sys

    print(sys.version)
    doctest.testmod(verbose=2)
    doctest.testfile("test_decorators.txt", verbose=1)

# Generated at 2022-06-25 17:11:13.725444
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Test: Method __get__ of class cached_property return float_0
    # float_1 = -0.0
    # Test: Method __get__ of class cached_property return float_0
    float_1 = float
    # Test: Method __get__ of class cached_property return float_1
    float_0 = -261.0
    # Unit test for method __get__ of class cached_property
    test_cached_property___get__()

# Generated at 2022-06-25 17:11:20.185196
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    pytest.raises(AttributeError, cached_property_0.__get__)
    pytest.raises(AttributeError, cached_property_0.__get__)



# Generated at 2022-06-25 17:11:21.041858
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert not True


# Generated at 2022-06-25 17:11:26.024467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    cached_property_1 = cached_property_0.__get__(float_0, float_0)



# Generated at 2022-06-25 17:11:28.323207
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """
    Unit test for method __get__ of class cached_property
    """
    test_case_0()


# Generated at 2022-06-25 17:11:33.215408
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Note: There are no test points
    return


# Generated at 2022-06-25 17:11:42.755182
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    print('Testing cached_property.__get__.')
    cached_property_0 = cached_property(cached_property)
    cached_property_0.__get__(cached_property, cached_property)
    cached_property_0.__get__(cached_property, cached_property)
    return


# Generated at 2022-06-25 17:11:49.201739
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from unittest import mock
    # mock args
    _args = mock.Mock()
    # mock return value
    _retval = mock.Mock()

    # mock __get__ method
    with mock.patch.object(cached_property, '__get__') as mock_method:
        mock_method.return_value = _retval
        _retval = cached_property.__get__(_args)

    assert _retval == mock_method.return_value
    assert mock_method.call_count == 1
    assert mock_method.call_args == mock.call(_args)

# Generated at 2022-06-25 17:11:53.090916
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -113.0
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__(None)
    # Verify that the following call succeeds
    cached_property_0.__get__()

# Unit test to verify functionality of class cached_property

# Generated at 2022-06-25 17:11:56.978687
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 17:11:58.613512
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = 887
    cached_property_0 = cached_property(float_0)


# Generated at 2022-06-25 17:12:03.704800
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__(None, None)

# Generated at 2022-06-25 17:12:04.612900
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()
    return


# Generated at 2022-06-25 17:12:17.040467
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    float_1 = -241.0
    cached_property_1 = cached_property(float_1)
    float_2 = -5.0
    cached_property_2 = cached_property(float_2)
    float_3 = -5.0
    cached_property_3 = cached_property(float_3)
    float_4 = -5.0
    cached_property_4 = cached_property(float_4)
    float_5 = -5.0
    cached_property_5 = cached_property(float_5)
    float_6 = -335.0
    cached_property_6 = cached_property(float_6)
    float_7 = -5.0

# Generated at 2022-06-25 17:12:18.193690
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:12:25.315200
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_1 = -261.0
    cached_property_1 = cached_property(float_1)


# Generated at 2022-06-25 17:12:31.413938
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -270.0
    cached_property_0 = cached_property(float_0)
    float_1 = float("-inf")
    cached_property_0.__get__(float_1)


# Generated at 2022-06-25 17:12:33.704678
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class class_0:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = class_0()
    assert obj.y == 6


# Generated at 2022-06-25 17:12:44.032866
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # === Start of parameter test ===
    # Scenario: TypeError thrown as float value is not callable
    float_0 = float()
    cached_property_0 = cached_property(float_0)
    with pytest.raises(TypeError) as exception_info:
        cached_property_0.__get__(None, None)
    # === End of parameter test ===

    # === Start of parameter test ===
    # Scenario: TypeError thrown as float value is not callable
    float_0 = float()
    cached_property_0 = cached_property(float_0)
    with pytest.raises(TypeError) as exception_info:
        cached_property_0.__get__(None, None)
    # === End of parameter test ===


# Test if the code breaks when there is no input

# Generated at 2022-06-25 17:12:46.295765
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property()
    str_0 = cached_property_0.__get__()


# Generated at 2022-06-25 17:12:48.474916
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-25 17:12:51.230202
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)


# Generated at 2022-06-25 17:12:55.241151
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -99.945
    cached_property_0 = cached_property(float_0)
    object_0 = object()
    object_1 = object()
    assert different_ids((cached_property_0.__get__(object_1, object_1), object_0)) is True


# Generated at 2022-06-25 17:13:01.662921
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    func_0 = test_case_0()

    cached_property_0 = cached_property(func_0)
    obj_0 = object()
    cls_0 = test_case_0()

    # Test for no argument as obj
    try:
        cached_property_0.__get__(None, test_case_0())
    except Exception:
        pass

    # Test for no argument as cls
    try:
        cached_property_0.__get__(obj_0, None)
    except Exception:
        pass

    # Test for all arguments null
    try:
        cached_property_0.__get__(None, None)
    except Exception:
        pass


# Generated at 2022-06-25 17:13:05.687471
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__(0.0, 0.0)
    # Possible errors: ZeroDivisionError


# Generated at 2022-06-25 17:13:20.563044
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -948.72651338
    cached_property_0 = cached_property(float_0)
    obj_0 = MyClass()
    cached_property_0.__get__(obj_0, MyClass)
    assert len(MyClass.__dict__) == 4

# Generated at 2022-06-25 17:13:26.818021
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # __get__ method of cached_property returns cached_property
    # Note: __get__ is implemented in C - C code will not have inspectable
    # return value...
    bool_0 = bool()
    bool_0 = bool_0
    cached_property_0 = cached_property(bool_0)
    assert isinstance(cached_property_0.__get__(None, None), cached_property)


# Generated at 2022-06-25 17:13:34.589178
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -251.0
    class_0 = cached_property(float_0)
    cached_property_0 = cached_property(class_0)

# Generated at 2022-06-25 17:13:38.698985
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import TestCase
    import inspect

    from flutils.decorators import cached_property

    class Object0(object):

        def func_0(self):
            return 'hello'

        @cached_property
        def prop_0(self):
            return self.func_0()

    obj = Object0()
    prop = obj.prop_0

    assert prop == 'hello'
    assert inspect.iscoroutinefunction(obj.prop_0)
    assert isinstance(obj.prop_0, TestCase)




# Generated at 2022-06-25 17:13:46.015520
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = 127.0
    instance_0 = cached_property(float_0)
    try:
        instance_0.__get__(None, None)
        instance_0.__get__(None, None)
        instance_0.__get__(None, None)
        instance_0.__get__(None, None)
        instance_0.__get__(None, None)
        instance_0.__get__(None, None)
        instance_0.__get__(None, None)
    except:
        pass


# Generated at 2022-06-25 17:13:46.699213
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True

# Generated at 2022-06-25 17:13:50.566859
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -271.856
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__()


# Generated at 2022-06-25 17:13:53.105074
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    a = cached_property(None)
    a.__get__(None, cached_property(None))


# Generated at 2022-06-25 17:14:04.940703
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    file_path_0 = 201.157
    cached_property_0.__get__(file_path_0, int)
    # print(cached_property_0)
    int_0 = -1
    cached_property_0.__get__(file_path_0, int_0)
    # print(cached_property_0)


# Generated at 2022-06-25 17:14:06.874488
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    print(cached_property)

if __name__ == "__main__":
    test_cached_property___get__()

# Generated at 2022-06-25 17:14:33.412581
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

if __name__ == "__main__":
    print('Running unit tests for cached_property')
    test_cached_property___get__()

# Generated at 2022-06-25 17:14:42.884889
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    def functools_cached_property_0():
        func_0 = test_cached_property___get__.func_0
        cached_property_0 = functools.cached_property(func_0)
        return cached_property_0

    def func_0():
        return '%c%c%c%c%c'

    test_cached_property___get__.func_0 = func_0

    # Floating-point number with an exponent.
    float_1 = 2.5e-1
    test_case_0()

test_cached_property___get__()

# Generated at 2022-06-25 17:14:44.946596
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = -1686
    cached_property_0 = cached_property(int_0)
    dict_0 = dict()
    cached_property_0.__get__(dict_0, dict)


# Generated at 2022-06-25 17:14:48.581777
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__(bool(), str())


# Generated at 2022-06-25 17:14:49.655493
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass



# Generated at 2022-06-25 17:14:52.190062
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__(obj)


# Generated at 2022-06-25 17:15:01.990962
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class Class_0:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class_0 = Class_0()
    assert (class_0.y == 6)



# Generated at 2022-06-25 17:15:03.574024
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_cached_property___get___0()


# Generated at 2022-06-25 17:15:09.130678
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = 22.942715
    cached_property_0 = cached_property(float_0)

    int_0 = -29
    cached_property_0.__get__(int_0)


# Generated at 2022-06-25 17:15:21.920178
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    float_1 = 1638.4465758271
    cached_property_1 = cached_property(float_1)
    bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_1 = bool()


# Generated at 2022-06-25 17:16:18.657503
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    from unittest.mock import Mock
    # mock an instance of a class
    obj_0 = Mock()

    # create a mock function
    func_0 = Mock()

    # change the value of the name attribute
    func_0.__name__ = 'v'

    # create an instance of the class under test
    c_property = cached_property(func_0)

    # perform the test
    c_property.__get__(obj_0, None)

    # ensure the correct function was called
    func_0.assert_called_once()


# Generated at 2022-06-25 17:16:21.673102
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)


# Generated at 2022-06-25 17:16:24.120311
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass

# Generated at 2022-06-25 17:16:33.064874
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property()
    obj_0 = type(obj_0)
    obj_1 = cached_property()
    obj_1 = obj_1(obj_0)

    try:
        assert obj_1 is not None
    except AssertionError:
        raise AssertionError()



# Generated at 2022-06-25 17:16:36.710561
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    result = cached_property_0.__get__(test_case_0, test_cached_property___get__)
    assert result == -261.0


# Generated at 2022-06-25 17:16:41.270462
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:16:43.593617
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    #
    #  This is a quick test.
    #
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)




if __name__ == '__main__':
    test_case_0()
    test_cached_property___get__()

# Generated at 2022-06-25 17:16:48.126472
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__(float_0, type(None))


# Generated at 2022-06-25 17:16:49.538114
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    """Test method __get__ of class cached_property"""
    pass


# Generated at 2022-06-25 17:16:53.449971
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class MyClass_0:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    my_class_0 = MyClass_0()
    my_class_0.y


if __name__ == '__main__':
    import pytest

    pytest.main(['-v', __file__])

# Generated at 2022-06-25 17:19:05.540236
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    class Class_0():
        def __init__(self):
            self.x = 5
        @cached_property
        def y(self):
            return self.x + 1

    obj = Class_0()
    value_0 = obj.y
    assert value_0 == 6


# Generated at 2022-06-25 17:19:14.110965
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Define parameters for method __get__ of class cached_property
    obj = None
    cls = None

    # Execute method __get__ of class cached_property
    try:
        cached_property_0 = cached_property()
        cached_property_0.__get__(obj, cls)
        # Expected exception: TypeError
        assert False
    except TypeError:
        pass

    # Execute method __get__ of class cached_property
    try:
        cached_property_0 = cached_property()
        cached_property_0.__get__(obj, cls)
        # Expected exception: TypeError
        assert False
    except TypeError:
        pass


# Generated at 2022-06-25 17:19:23.282873
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_1 = -261.0
    cached_property_1 = cached_property(float_1)
    str_0 = '+#,#0.00'


# Generated at 2022-06-25 17:19:33.726028
# Unit test for method __get__ of class cached_property

# Generated at 2022-06-25 17:19:38.158344
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -833.79
    cached_property_0 = cached_property(float_0)
    cached_property.__get__(cached_property_0)
    cached_property.__get__(cached_property_0, float_0)


# Generated at 2022-06-25 17:19:40.585310
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    c = CachedProperty()
    try:
        cached_property_0 = cached_property.__get__(c, CachedProperty)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 17:19:47.053608
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    cached_property_0.__get__(cached_property_0.__doc__, cached_property_0.__doc__)


# Generated at 2022-06-25 17:19:49.066329
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = cached_property(None)
    cls_0 = str
    test_case_0()
    obj_0.__get__(obj_0, cls_0)

# Generated at 2022-06-25 17:19:54.417183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Setup
    cached_property_0 = cached_property(float_0)

    # Target
    obj_0 = None
    cls_0 = cached_property

    # Execute
    result_0 = cached_property_0.__get__(obj_0, cls_0)

    # Verify
    assert result_0 is not None


# Generated at 2022-06-25 17:19:57.151978
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    float_0 = -261.0
    cached_property_0 = cached_property(float_0)
    any_0 = cached_property_0.func