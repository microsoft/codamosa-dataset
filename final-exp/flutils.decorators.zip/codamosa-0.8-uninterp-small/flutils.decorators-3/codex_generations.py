

# Generated at 2022-06-25 17:10:34.981391
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    obj = cached_property_0.__get__(str_0, int)


# Generated at 2022-06-25 17:10:46.226548
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock
    from functools import partial

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    m = mock.patch.object(cached_property.__get__, '__doc__', 'foo')
    with m as patched:
        obj = MyClass()
        obj.y



# Generated at 2022-06-25 17:10:50.807330
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'r_0'
    str_1 = 'r_1'
    cached_property_0 = cached_property(str_0)
    cached_property_0 = cached_property(str_1)

# Generated at 2022-06-25 17:11:02.128616
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest.mock import ANY

    from flutils.decorators import cached_property
    from flutils.decorators import cached_property as cached_property_0

    class MyClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    str_0 = 'y'
    obj = obj.__dict__[str_0]
    assert obj == 6
    cached_property_0 = cached_property(obj)
    obj = cached_property_0.__get__(MyClass(), ANY)
    assert obj == 6


# Generated at 2022-06-25 17:11:03.018297
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:11:05.783937
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # Test a function with no parameters
    def __get__(x):
        return
    pass

# Generated at 2022-06-25 17:11:08.611860
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property('y')
    assert not obj.__get__(obj, None)


# Generated at 2022-06-25 17:11:19.185576
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    class_0 = type('', (), {})

# Generated at 2022-06-25 17:11:25.579928
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    print(cached_property_0.__get__('Na0'))
    print(cached_property_0.__get__('Egd@t'))
    print(cached_property_0.__get__('+IAa'))


# Generated at 2022-06-25 17:11:29.306330
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj_0 = None
    cached_property_0 = cached_property(str)
    assert cached_property_0.__get__(obj_0, str) is cached_property_0



# Generated at 2022-06-25 17:11:33.972483
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'p'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:11:36.415399
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_obj = cached_property()
    assert test_obj.__get__ == 'Not implemented'


# Generated at 2022-06-25 17:11:45.056168
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'ZN8@Lz0>$'
    cached_property_0 = cached_property(str_0)
    str_1 = 's}X,;H'
    str_2 = 'G'
    str_3 = '6qa'
    cached_property_1 = cached_property(str_3)
    b_0 = hasattr(cached_property_1, str_1)
    int_0 = add(0, 1)
    assert not b_0 and int_0 == 1
    b_1 = hasattr(cached_property_0, str_2)
    int_1 = add(0, 1)
    assert b_1 and int_1 == 1

# Generated at 2022-06-25 17:11:45.757752
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:11:52.014043
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:11:54.811167
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert cached_property.__get__ is cached_property.__get__


# Generated at 2022-06-25 17:12:00.671062
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)

    from flutils.decorators import cached_property

    class MyClass:

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = MyClass()
    assert obj.y == 6

# Generated at 2022-06-25 17:12:01.606173
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:12:07.051576
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    str_1 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    new_class_0 = type(str_1, (),)
    new_class_1 = type('__main__.cached_property', (),)
    new_class_0.cached_property = cached_property_0
    new_class_1.cached_property = cached_property_0
    try:
        new_instance_0 = new_class_0()
        cached_property_0.__get__(new_instance_0, )
    except:
        pass
    try:
        cached_property_0.__get__(new_class_1, )
    except:
        pass


# Generated at 2022-06-25 17:12:07.859816
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert True



# Generated at 2022-06-25 17:12:15.890177
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    assert test_case_0() is None


# Generated at 2022-06-25 17:12:25.543711
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # @cached_property
    # def y(self):
    #     return self.x + 1

    # >>> obj = MyClass()
    # >>> obj.y
    # 6

    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    class_0 = type('MyClass', (object,), {})
    obj_0 = class_0()
    obj_0.x = 5
    y = cached_property_0.__get__(obj_0, class_0)
    assert y == 6, 'Failed task test_cached_property___get__: assert y == 6'

# Generated at 2022-06-25 17:12:32.046843
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    class TestCase_2(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    obj = TestCase_2()
    assert obj.y == 6



# Generated at 2022-06-25 17:12:39.602958
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    args = [
    ]
    if len(args) == 0:
        # Test #0.1 with args (self)
        test_cached_property___get__0x0()
    elif len(args) == 1:
        # Test #0.2 with args (self, obj)
        test_cached_property___get__0x1()
    elif len(args) == 2:
        # Test #0.3 with args (self, obj, cls)
        test_cached_property___get__0x2()


# Generated at 2022-06-25 17:12:40.922731
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:12:47.398785
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property(cached_property)
    assert False


# Generated at 2022-06-25 17:12:53.085268
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'M'
    cached_property_0 = cached_property(str_0)
    obj_0 = MyClass()
    cached_property_0.__get__(obj_0, None)
    obj_0.i3r5M5P5o5({'i3r5M5P5o5': []})


# Generated at 2022-06-25 17:12:54.016062
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:13:08.151314
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'lFX}'
    cached_property_0 = cached_property(str_0)
    str_1 = 'FaIK'
    str_2 = '5"R]^.(*'
    str_3 = 'W]eO$'
    obj = type(str_2, (object,), {str_2: str_3})
    class_0 = obj
    str_4 = 'Y7Vu_s'
    str_5 = '*g;o\n'
    str_6 = 'u"h?a'
    tuple_0 = (cached_property_0, str_4, str_5, str_6)
    class_1 = type(str_1, tuple_0, {})

# Generated at 2022-06-25 17:13:13.141237
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    int_0 = cached_property(str)


# Generated at 2022-06-25 17:13:26.981447
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_1 = 'I!rb'
    cached_property_1 = cached_property(str_1)
    cached_property_1.__get__(0, 1, 2)


# Generated at 2022-06-25 17:13:30.566226
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass


# Generated at 2022-06-25 17:13:34.901072
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)

# Generated at 2022-06-25 17:13:45.873141
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    result_0 = cached_property_0.__get__(None, None)
    result_1 = cached_property_0.__get__(None, None)
    result_2 = cached_property_0.__get__(None, None)
    result_3 = cached_property_0.__get__(None, None)
    result_4 = cached_property_0.__get__(None, None)
    result_5 = cached_property_0.__get__(None, None)
    result_6 = cached_property_0.__get__(None, None)
    result_7 = cached_property_0.__get__(None, None)
    result_8 = cached_property_0.__

# Generated at 2022-06-25 17:13:51.986246
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)

    # Case: 0
    cached_property_1 = cached_property_0.__get__(None, None)
    assert cached_property_1 is cached_property_0


# Generated at 2022-06-25 17:13:54.091737
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I.rb'
    cached_property_0 = cached_property(str_0)


# Generated at 2022-06-25 17:13:55.592810
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:14:09.627572
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    str_0 = 'tx7Zl=?t&cYB0'
    assert None is not cached_property_0.__get__(str_0, None)
    str_0 = 'tx7Zl=?t&cYB0'
    assert None is not cached_property_0.__get__(str_0, str_0)
    str_0 = "  -9'&5c5^!@"
    assert None is not cached_property_0.__get__(None, str_0)
    str_0 = "  -9'&5c5^!@"
    assert None is not cached_property_0.__get__(str_0, str_0)


# Generated at 2022-06-25 17:14:12.620745
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = MyClass()
    assert obj.y == 6


# Generated at 2022-06-25 17:14:17.907263
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'L-?O'
    cached_property_0 = cached_property(str_0)
    str_1 = 'j5_5'
    str_2 = 'lC:j'
    str_3 = '0qDd'
    str_4 = 'Nt3q'
    str_5 = 'I$oM'
    str_6 = 'R\x7fZ'
    str_7 = 'L-?O'
    str_8 = 'JsIf'
    str_9 = 'cg>e'
    str_10 = 'x8T^'
    str_11 = 'I$oM'
    str_12 = '3qS&'
    str_13 = 'cg>e'
    str_14 = 'L-?O'
    str_

# Generated at 2022-06-25 17:14:42.928697
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:14:55.029458
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from flutils.decorators import cached_property
    from io import StringIO
    from unittest.mock import Mock
    import sys
    import unittest

    class Foo(object):

        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x

    class TestCachedProperty(unittest.TestCase):

        def setUp(self):
            self.obj = Foo()

        def test_cached_property___get__(self):
            self.assertEqual(self.obj.y, 5)

        def test_cached_property___get___resets_self(self):
            self.obj.y = 10
            self.assertEqual(self.obj.y, 10)

    unittest.main()



# Generated at 2022-06-25 17:14:56.717183
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    cached_property_0 = cached_property('a')
    cached_property_0.__get__(None, 1)


# Generated at 2022-06-25 17:15:05.692426
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)

    obj_0 = MyClass()
    @cached_property
    def func(self):
        return self.x + 1

    assert func(obj_0) == 6
    assert obj_0.y == 6
    assert obj_0.__dict__['func'] == 6
    del obj_0.__dict__['func']
    assert obj_0.y == 6



# Generated at 2022-06-25 17:15:08.860146
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    cached_property_0.__get__(cached_property_0, cached_property)



# Generated at 2022-06-25 17:15:10.917289
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    global str_0, cached_property_0

    pass

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:15:11.963034
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()


# Generated at 2022-06-25 17:15:16.828478
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '{} == {}'.format('<cached_property object at ', '0x')
    assert str_0 == '<cached_property object at 0x'

# Generated at 2022-06-25 17:15:21.954687
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    obj = 'obj'
    cls = 'cls'
    result = cached_property_0.__get__(obj, cls)
    assert result is None


# Generated at 2022-06-25 17:15:23.039013
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    test_case_0()

# Generated at 2022-06-25 17:16:17.736201
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '6i'
    cached_property_0 = cached_property(str_0)
    str_1 = 'I!rb'
    cached_property_1 = cached_property(str_1)

if __name__ == '__main__':
    import pytest as pt
    pt.main()

# Generated at 2022-06-25 17:16:22.554156
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    obj = cached_property(ascii)
    obj.__get__(chr, object)
    obj.__get__(cached_property, complex)


# Generated at 2022-06-25 17:16:26.634524
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    def one():
        return 'one'

    two = cached_property(one)
    assert 'one' == two.__get__(None)

    obj = object()
    obj.two = cached_property(one)
    assert 'one' == obj.two.__get__(None)
    assert 'one' == obj.two.__get__(obj)



# Generated at 2022-06-25 17:16:32.501451
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    obj_0 = cached_property_0.__get__(cached_property_0, cached_property)
    print("TEST PASSED")


# Generated at 2022-06-25 17:16:34.163898
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)

# Generated at 2022-06-25 17:16:36.710562
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    # xfail: py36
    try:
        cached_property_0 = cached_property('a')
    except NameError:
        pass


# Generated at 2022-06-25 17:16:41.270862
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    pass  # Assertion passes; insufficie

# Generated at 2022-06-25 17:16:44.737627
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    # Testing if an exception is thrown and if it is of the right type
    try:
        cached_property_0.__get__(cached_property_0.func)

    except TypeError:
        pass
    else:
        assert False
    # Testing if an exception is thrown and if it is of the right type
    try:
        cached_property_0.__get__(cached_property_0.func)

    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 17:16:51.111844
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    _a = str
    _b = _a.__class__
    _c = _b.__mro__
    _d = _c[1]
    _e = _d.__dict__
    _f = _e.get('__get__', None)
    _g = type(_f)
    test_case_0()

if __name__ == '__main__':
    test_cached_property___get__()

# Generated at 2022-06-25 17:16:53.925228
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '='
    asyncio.iscoroutinefunction('Q')
    cached_property_0 = cached_property(str_0)
    any_0 = None
    cached_property_0.__get__(any_0, cached_property_0)
    pass

test_case_0()

# Generated at 2022-06-25 17:19:01.974564
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    obj_0 = MyClass()
    cached_property_0.__get__(obj_0, None)
    obj_0.y


# Generated at 2022-06-25 17:19:08.200134
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = '{xk-i'
    cached_property_0 = cached_property(str_0)
    str_0 = str_0 + '-A'
    cached_property_0.__get__(str_0, str_0)


# Generated at 2022-06-25 17:19:10.147022
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'q[W'
    cached_property_0 = cached_property(str_0)

# Generated at 2022-06-25 17:19:15.029368
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():

    # Create
    from flutils.decorators import cached_property
    obj = cached_property
    cls = None

    # Check type
    assert isinstance(obj, cached_property)

    # Check __get__
    cached_property_0 = obj.__get__(obj, cls)

    # Check type
    assert isinstance(cached_property_0, cached_property)



# Generated at 2022-06-25 17:19:32.516982
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    str_1 = str_0
    int_0 = int(str_0)
    str_2 = str_0
    int_1 = int(str_1)
    str_3 = str_2
    int_2 = int(str_3)
    str_3 = str_3
    str_4 = str_3
    str_4 = str_4
    str_4 = str_3
    str_4 = str_4
    str_4 = str_4
    str_4 = str_4
    str_4 = str_4
    str_4 = str_4
    str_5 = str_4
    str_5 = str_5
    str_5 = str_5
   

# Generated at 2022-06-25 17:19:33.883536
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    class_0 = cached_property
    obj_0 = class_0

# Generated at 2022-06-25 17:19:37.456545
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    global cached_property_0
    cached_property_0 = cached_property()
    assert type(cached_property_0) is cached_property


# Generated at 2022-06-25 17:19:43.028331
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock
    from flutils.decorators import cached_property
    mock_obj = mock.MagicMock()
    mock_cls = mock.MagicMock()
    mock_cached_property_0 = mock.MagicMock(spec=cached_property)
    mock_cached_property_0.func.return_value = mock_obj
    mock_cached_property_0.func.__name__ = mock_obj
    mock_cached_property_0.func.return_value = mock_obj
    mock_cached_property_0.__get__.return_value = mock_obj
    test_value = mock_cached_property_0.__get__(mock_obj, mock_cls)
    assert test_value == mock_obj

# Generated at 2022-06-25 17:19:45.873260
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    from unittest import mock
    str_0 = 'I!rb'
    cached_property_0 = cached_property(str_0)
    with mock.patch('builtins.print') as mock_print:
        cached_property.__get__(cached_property_0, None)
        # assert mock_print.called



# Generated at 2022-06-25 17:19:54.613833
# Unit test for method __get__ of class cached_property
def test_cached_property___get__():
    str_0 = 'R5B5'
    cached_property_0 = cached_property(str_0)

    str_1 = 'A'
    cached_property_0 = cached_property(str_1)

    str_2 = 'T!eP'
    cached_property_0 = cached_property(str_2)

    str_3 = 'Tr'
    cached_property_0 = cached_property(str_3)

    str_4 = 'X'
    cached_property_0 = cached_property(str_4)

    str_5 = 'iC'
    cached_property_0 = cached_property(str_5)

    str_6 = '0'
    cached_property_0 = cached_property(str_6)

    str_7 = '2'
    cached_property_0 = cached